/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Cryptography.Asymptotic.HardCoreGLColl
import TCSlib.Cryptography.Asymptotic.HardCoreLemmas
-- CP2 WHOLE-FILE SEAL (evidence probe; not library source): 1429 requests for TCSlib.Cryptography.Asymptotic.HardCoreCollection
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "CompileListSpec") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "CompileSpec") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "IsFaninTwo"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "IsWellFormed"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "binarize"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "deMorgan"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "depth"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "depthAt"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "depths"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "eval"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "layerGate"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "layerNodes"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "ofNode"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "rewrite"), "TCSlib.Complexity.CircuitComplexity.DAGTransform", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "size"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "toLayered"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "toLayered_evalNode") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "toNode"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "toTree"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "unfoldVertex_depth_le") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "unfoldVertex_eval") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "unfoldVertex_maxFanin_le") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "unfoldVertex_size_le") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuit") "values"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "Accepts"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "HasFaninTwo"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "HasPolylogDepth"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "IsPolySize"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "IsWellFormed"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "language"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGCircuitFamily") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "FaninTwo"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "NoOr"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "WellFormed"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "depth"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "eval"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "DAGGate") "remap"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GadgetCorrect"), "TCSlib.Complexity.CircuitComplexity.DAGTransform", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GadgetSpec") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGTransform", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "Gate") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "Gate") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateKind") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateKind") "enumList"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateKind") "ofNat"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateKind") "op"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateKind") "op") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateOp") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateOp") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateShape") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateShape") "eval"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GateShape") "eval") "match_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "GatesAcyclic"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "Gate") "eval"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "IsAndOrGate"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "eval"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "evalNode"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "evalNode") "match_1"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "eval₁"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "gatesUpTo"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "gatesUpTo") "_sunfold"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "gatesUpTo") "match_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "gatesUpTo_acyclic") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "gatesUpTo_mono") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "gatesUpTo_wellFormed") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerEnum"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerGate"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerGate") "match_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerVertex"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerVertex") "match_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerVertex_lt") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "layerVertex_value") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "length_gatesUpTo") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "offset"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "onlyUsesGates"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "size"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "succCard"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "toDAG"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuit") "toTreeCircuit"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuitFamily") "Accepts"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuitFamily") "IsPolySize"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuitFamily") "OnlyUsesGates"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuitFamily") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuitFamily") "language"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredCircuitFamily") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "LayeredPPoly"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "Lit") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "Lit") "eval"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "Lit") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "_sizeOf_2"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "_sizeOf_3"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "_sizeOf_4"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "constTrue"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "depth"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "depth") "_mutual"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "depth") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "eval"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "eval") "_mutual"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "eval") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "eval") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "litCount"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "litCount") "_mutual"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "litCount") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "litCount") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "ofVar"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "size"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "size") "_mutual"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "size") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "toTreeCircuit"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "toTreeCircuit") "_mutual"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NAndCircuit") "toTreeCircuit") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "constFalse"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "depth"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "depth") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "eval"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "eval") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "eval") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "litCount"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "litCount") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "litCount") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "ofVar"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "size"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "size") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "toTreeCircuit"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NOrCircuit") "toTreeCircuit") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "NotsSpec") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "PPoly"), "TCSlib.Complexity.CircuitComplexity.PPoly", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "RewriteInv") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGTransform", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "_sizeOf_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "_sizeOf_2"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "depth"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "depth") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "depth_le_maxDepth") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "eval"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "eval") "_unary"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "eval") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "eval") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "ind") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "length_le_sumSize") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "litCount"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "litCount") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "maxDepth"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "maxFanin"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "maxFanin") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "maxFaninL"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "maxFaninL_le_sumSize") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "maxFanin_le_maxFaninL") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "size"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "size") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "sumSize"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toDAG"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toLayered"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toLayeredWrapper"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNAnd"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNAnd") "_mutual"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNAnd") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNAnd") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNOr"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNOr") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeCircuit") "toNOr") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "TreeSpec") "mk") "_flat_ctor"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "allOnesCircuit"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "allOnesCircuit") "match_1"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "allOnesFamily"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "andGateOp"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "binarizeGadget"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "binarizeGadget") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "binarizeGadget_correct") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTree"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTree") "_sunfold"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTree") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTree") "match_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTrees"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTrees") "_sunfold"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTrees") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTrees") "match_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "compileTrees_spec") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "constCircuit"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "constGate"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "deMorganGadget"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "deMorganGadget") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "deMorganGadget_correct") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitNots"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitNots") "_sunfold"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitNots") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitNots") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitNots_spec") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitTree"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitTree") "_unary"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitTree") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitTree") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "emitTree_spec") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "gateShape"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=0 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instDecidableEqDAGGate") "decEq"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instDecidableEqDAGGate") "decEq") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instDecidableEqLit") "decEq"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instDecidableEqLit") "decEq") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instHashableLit") "hash"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instHashableLit") "hash") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instReprDAGGate") "repr"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instReprGateKind") "repr"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instReprGateKind") "repr") "match_1"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instReprLit") "repr"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instReprTreeCircuit") "repr") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "instReprTreeCircuit") "repr") "match_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "layerGateOf"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "layerGateOf") "match_1"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "nodeKind"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "rewriteGates"), "TCSlib.Complexity.CircuitComplexity.DAGTransform", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "rewriteStep"), "TCSlib.Complexity.CircuitComplexity.DAGTransform", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "runWith"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "stdGateOps"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "treeCost"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldGate"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldGate") "match_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldGate_eval") "match_1_10"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldGate_eval") "match_1_12"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldGate_eval") "match_1_4"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldGate_eval") "match_1_6"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldVertex"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldVertex") "_sunfold"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldVertex") "_unsafe_rec"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "unfoldVertex") "match_1"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "vertexDepth"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "BoolCircuit") "vertexValue"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "SlotsLe"), "TCSlib.Complexity.ClassP.BinaryArith.Iterate", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "guardLoop"), "TCSlib.Complexity.ClassP.BinaryArith.Iterate", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "guardNxt"), "TCSlib.Complexity.ClassP.BinaryArith.Iterate", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip") "_sunfold"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip") "_unsafe_rec"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip") "match_1"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "pairO"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "pairδ"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "pairδ") "match_1"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut") "_sunfold"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut") "_unsafe_rec"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut") "match_1"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialState"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialState") "_sunfold"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialState") "_unsafe_rec"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "emit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "step"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes") "mono") "match_1_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Instr") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "LinE") "val"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "act"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "bitsOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "ctl"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "enc"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "init"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "linOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "run"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "shiftInput"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "toTM"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "DTIME"), "TCSlib.Complexity.ClassP.DTIME", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "DTIMEAdvice"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "find?_congr_of_mem") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostCtrl"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostRet"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "step"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal") "_sunfold"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal") "_unsafe_rec"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal") "match_1"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "eq_of_bitsVal_eq") "match_1_1"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW") "_sunfold"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW") "_unsafe_rec"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW") "match_1"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LoopInv"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NP"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Computes"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Uniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "advInput"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "adviceLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsCongr"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquivPoly"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "combineAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "distinguisher"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "distinguisherL"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inArg"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inCoins"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inParam"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inverter"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inverterLit"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "layout"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "mk") "_flat_ctor"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "output"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "precomp"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "precomp_coinsEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "predictor"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "reparam"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "reparamCoins"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAt"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAtL"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runLenPoly"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runLit"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "timeBound"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "withIndexParam"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "withIndexParam_coinsEquiv"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "wrap"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "wrapCoinsEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "wrapFun"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "P"), "TCSlib.Complexity.ClassP.P", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PAdvicePoly"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT") "ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT") "toNUPPT"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyBound"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "normal"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "UnaryPT"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "padDecode"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "padDecode") "match_1"), "TCSlib.Complexity.PolyHierarchy.Padding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "polyTimeComputable_padDecode") "match_1_1"), "TCSlib.Complexity.PolyHierarchy.Padding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode") "_sunfold"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode") "_unsafe_rec"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode") "match_1"), "TCSlib.Complexity.PolyHierarchy.Padding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyTimeComputable"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "drop"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_3"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_5"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "take"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "flag"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=1 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstep"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstepBound"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "length_flatMap_range_le") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_sunfold"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_unsafe_rec"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "match_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "TimeConstructible"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockTests", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockDone"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "coNP"), "TCSlib.Complexity.ClassNP.CoNP", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "guardedStep"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "isNilB"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairFstD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairSndD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_iterateFind") "match_1"), "TCSlib.Complexity.Randomized.Repetition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_unary") "match_1_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceDropAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceTakeAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce") "_sunfold"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce") "_unsafe_rec"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce") "match_1"), "TCSlib.Complexity.ClassNP.Transducer", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transducerTM"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transducerTr"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transducerTr") "match_1"), "TCSlib.Complexity.ClassNP.Transducer", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "xorD"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Language") "InLayeredPPoly"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Language") "InLayeredSIZE"), "TCSlib.Complexity.CircuitComplexity.LayeredPPoly", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Language") "InPPoly"), "TCSlib.Complexity.CircuitComplexity.PPoly", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Language") "InSIZE"), "TCSlib.Complexity.CircuitComplexity.PPoly", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Language") "allOnes"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Light") "AbsLe"), "TCSlib.Programs.Util.List", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Light") "sumLists"), "TCSlib.Programs.Util.List", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "EvalSampled"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "HardCore"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "HardCore") "evaluator") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Collections", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "OneWay") "exists_strongOneWay") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Collections", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "OneWay") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "OutLenBound"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "SampleClose"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "glPadSampleFun"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "index"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "invProbAt"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "owfCoinsEquiv"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "owfFamily"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "owfRaw"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "sample_eq_encD") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Collections", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Collection") "trap"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Distinguishes"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "DistinguishesWith"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "Indist"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "IndistLit"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "NextBitUnpredictable"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "Pseudorandom"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "Samplable"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "copies"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "push"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Ensemble") "uniform"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "emit"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "loopOut"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "p₁"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "p₂"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "p₃"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "p₄"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "p₅"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "p₆"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "st"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "CopiesLoop") "step"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "blocks"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "coinsEquiv"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "consSplit"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "copiesInit"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "copiesSampler"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "padL"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "statClose_copies") "match_1_1"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EnsembleLemmas") "swapAux"), "TCSlib.Cryptography.Asymptotic.EnsemblesLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "Easy"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "LengthRegular"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "StrongOneWay") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "WeakOneWay") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "WorstCaseOneWay") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "WorstCaseOneWayLit") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "blocks"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "invProbAt"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "ofString"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "prod"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "strOutLen"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "toCollection"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "toCollection_domEquiv"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "bound"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "entry"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "fixed"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "fx"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "glEntry"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "glEntryFn"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "glTable"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "input"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "out"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pY"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pb"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pcs"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "ps"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "ptbl"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pu"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "puk"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pum"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pur"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pvotes"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "pα"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "start"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "step"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "vote"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "wfInput"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLLoop") "wfVote"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "adv"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "cb"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "cs₁"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "cs₂"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "r₁"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "tbl"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "uM"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "uk"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "ukm"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "um"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "ur"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GLRaw") "α"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "PairwiseIndep"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "PairwiseUniform") "mk") "_flat_ctor"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "PushesUniform"), "TCSlib.Cryptography.HardcoreBit.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "glBit"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "glInverter"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "glPad"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "guessCoinsCongr"), "TCSlib.Cryptography.HardcoreBit.GoldreichLevin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "guessInverter"), "TCSlib.Cryptography.HardcoreBit.GoldreichLevin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "guessRecover"), "TCSlib.Cryptography.HardcoreBit.GoldreichLevin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "idealRecover"), "TCSlib.Cryptography.HardcoreBit.GoldreichLevin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "ind"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "ip"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "majority"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "majorityInverter"), "TCSlib.Cryptography.HardcoreBit.ThreeQuarters", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "majorityRecover"), "TCSlib.Cryptography.HardcoreBit.ThreeQuarters", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "pairwiseUniform_subsetSum") "match_1_2"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "perfectInverter"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "perfectRecover"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "secProb"), "TCSlib.Cryptography.HardcoreBit.InnerProduct", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "subsetSum"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "subsetSumHom"), "TCSlib.Cryptography.HardcoreBit.PairwiseIndependence", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "trialBit"), "TCSlib.Cryptography.HardcoreBit.ThreeQuarters", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Negligible"), "TCSlib.Cryptography.Foundations.Negligible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Noticeable"), "TCSlib.Cryptography.Foundations.Negligible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "acc"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "rest"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "step"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "trial"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "uM"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "ukk"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "unum"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "cnt"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "emit"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "rest"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "start"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "step"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "u"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "Inv"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "acc"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "capped"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "dbl"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "pad"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "rest"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "start"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "step"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "Data") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "Data") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "acc"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "adv"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "advP"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "alpha1"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ans"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "g"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ipos"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "nkk"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=2 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "off"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "offIn"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "planted"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "posBits"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "rc"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "rcoins"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "sampleAll"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "test"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "uIn"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "uM"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "uOut"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ukk"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "xs"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "yaoRaw"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "yaoRaw'"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "yaoRaw") "match_1"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ys"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "zOut"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ρP"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ρPEquiv"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "bitListToNat"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "blocksE"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "kkOf"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "pad"), "TCSlib.Cryptography.OneWayFunctions.OutputLength", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "padInverter"), "TCSlib.Cryptography.OneWayFunctions.OutputLength", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "padTrue"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "pbOf"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "polyTimeComputable_unaryMulPair") "match_1_1"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "posOf"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "prodFun"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "roundEquiv"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "roundSample"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "tableInverter"), "TCSlib.Cryptography.OneWayFunctions.OutputLength", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoB"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoBad"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoInverter"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoTry"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoTryProb"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWayPermutation"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PRG") "Easy"), "TCSlib.Cryptography.Asymptotic.Pseudorandom", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PRG") "Secure"), "TCSlib.Cryptography.Asymptotic.Pseudorandom", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PRG") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.Pseudorandom", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PRG") "ensemble"), "TCSlib.Cryptography.Asymptotic.Pseudorandom", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PRG") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.Pseudorandom", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermCollection") "OneWay"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermCollection") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermCollection") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermFamily") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermFamily") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermFamily") "toFunFamily"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermFamily") "toFunFamily_codEquiv"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "PermFamily") "toFunFamily_domEquiv"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "bound"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "input"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "out"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "partialSum"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "partialSum") "_sunfold"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "partialSum") "_unsafe_rec"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "partialSum") "match_1"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "start"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "SelXor") "step"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "StatClose"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "TrapdoorCollection") "OneWay"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "TrapdoorCollection") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "TrapdoorCollection") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "TrapdoorCollection") "toCollection_domEquiv"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "acceptProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "betaOf"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsEquiv"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsToNat"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "blocksEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "blocksEquivX"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "blocksStr"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "collPre"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "completePrefix"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "copies"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "decodeFin"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "distAdv"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "expandRedMachine"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "expandRedPre"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "finCastEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "firstHit"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glAdvPoly"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glAdvice"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glBlocks"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glCoins"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glCoinsEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glCollMachine"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glCollPost"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glCollPre"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glKc"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glKcBound"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glMachine"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glMachine_coinsEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glMajFun"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadCollInvMachine"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadCollPost"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadCollPre"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadDecode"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadDecode") "match_1"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadDecode") "match_3"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadInvFun"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadInvMachine"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPadInvPost"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glPredictorOf"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glRawFun"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "glVotesFun"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProbOpt"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "ipFun"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "mixDist"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "mixEnsemble"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "multicopyAvgRed"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "multicopyHybrid"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "multicopyRed"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "nesubsetEquiv"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "nextBitDist"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "nextBitHybrid"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "nextBitHybridFlip"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "nextBitPred"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "nextBitProb"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpBitsEquiv"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpGen"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpGenBits"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpGenNot"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPair"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredMachine"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredPost"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredPre"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredictor"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredictorBits"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "padFin"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "padStr"), "TCSlib.Cryptography.Asymptotic.CollectionsLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "padToLen"), "TCSlib.Cryptography.Asymptotic.HardCoreGLColl", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "predProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prefixOf"), "TCSlib.Cryptography.Asymptotic.NextBit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgAdv"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExt"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtAvgRed"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtBits"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtBitsRed"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtRed"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgHybrid"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgIterEmit"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgIterFun"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgIterStep"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgStep"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "pushSampler"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "rejectionSample"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "selXorFun"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "splitCoins"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "splitPair"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "sunglassRed"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uexp"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "unaryHalf"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "unaryMulFun"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "unaryMulFun") "match_1"), "TCSlib.Cryptography.Asymptotic.HardCoreGL", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uniformFromBits"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uprob"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "yaoBlocks"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "yaoRounds"), "TCSlib.Cryptography.Asymptotic.OneWay", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "HasMinEntropy"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "_sizeOf_1"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "collision"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "map"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "mk") "_flat_ctor"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "prod"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "uniform"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "statDist"), "TCSlib.InformationTheory.StatisticalDistance", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "init"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "inputSymbol"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ofWords"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "select"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "workTapeSymbols"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "serialize"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "toFinTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "Computes"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTimeVia"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "DecidesInTime"), "TCSlib.Complexity.ClassP.DTIME", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "DecidesWithAdviceInTime"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "VirtualTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "appendBitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=3 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferTape"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedFirstCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedScanCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedSecondCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callEntry"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callExit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1"), "TCSlib.Complexity.Randomized.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "constTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "controlAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "emitAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "indexedVisit"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairLenCheckTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyBitsTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rewind_scan") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveWithTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM_computes") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepAct"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_sunfold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "match_1"), "TCSlib.Complexity.TuringMachine.Sweep", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepRevCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepTape"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "tapeBlocks"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualMove"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "Clean"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "entry"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "AgreeOn"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesFunInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "DecidableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "haltsAtStep"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "indicator"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "initCfg"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "outputSymbol"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "relabelState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "runFrom"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsed"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsedByTape"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step") "match_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "visitedByTapeHead"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "cfg"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "rewind_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "SafeRun"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "ones"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT") "match_1"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "actionBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "dbl"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instInhabitedCfg") "default"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "moveInputPos"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "padAction"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_sunfold"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_3"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairEncode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplitWith"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "spaceUsedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "stateWord"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryFin"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "visitedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "adviceOnesTM"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoCfg"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoHalt"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoMove"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoTr"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoTr") "match_1"), "TCSlib.Complexity.CircuitComplexity.Advice", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoTr") "match_3"), "TCSlib.Complexity.CircuitComplexity.Advice", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "aoTr") "match_5"), "TCSlib.Complexity.CircuitComplexity.Advice", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Advice") 0) "Complexity") "onesFrom"), "TCSlib.Complexity.CircuitComplexity.Advice", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "NAndCircuit") "eval") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "NAndCircuit") "litCount") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "NOrCircuit") "eval") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "NOrCircuit") "litCount") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "TreeCircuit") "eval") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "TreeCircuit") "sumSize_add_length_le") "match_1_1"), "TCSlib.Complexity.CircuitComplexity.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "TreeCircuit") "toNAnd") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "TreeCircuit") "toNOr") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "BoolCircuit") "instReprTreeCircuit") "repr") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "Basic") 0) "List") "map_unattach") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "DAGCircuit") 0) "BoolCircuit") "instReprGateKind") "repr") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.DAGCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "DAGFanin") 0) "BoolCircuit") "GateKind") "op") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "DAGFanin") 0) "BoolCircuit") "emitNots") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "DAGFanin") 0) "BoolCircuit") "emitTree") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.DAGFanin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredCircuit") 0) "BoolCircuit") "instReprTreeCircuit") "repr") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredCircuit") 0) "BoolCircuit") "nodeToTreeCircuit"), "TCSlib.Complexity.CircuitComplexity.LayeredCircuit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredDAG") 0) "BoolCircuit") "GateShape") "eval") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredDAG") 0) "BoolCircuit") "LayeredCircuit") "gatesUpTo") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredDAG") 0) "BoolCircuit") "LayeredCircuit") "layerGate") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredDAG") 0) "BoolCircuit") "LayeredCircuit") "layerVertex") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "LayeredDAG") 0) "BoolCircuit") "layerGateOf") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.LayeredDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "SizeClasses") 0) "BoolCircuit") "allOnesNodes"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "SizeClasses") 0) "BoolCircuit") "allOnesNodes") "match_1"), "TCSlib.Complexity.CircuitComplexity.SizeClasses", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "TreeDAG") 0) "BoolCircuit") "compileTree") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "TreeDAG") 0) "BoolCircuit") "compileTrees") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "CircuitComplexity") "TreeDAG") 0) "BoolCircuit") "unfoldVertex") "match_1") "splitter"), "TCSlib.Complexity.CircuitComplexity.TreeDAG", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "certificateSplit"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "paddedVerifier"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "pairedVerifier"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "_sunfold"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "_unsafe_rec"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_3"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_3") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_bound"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=4 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_split"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_split") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_strip"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majInit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "pairMapSnd") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "polyTimeComputable_unary") "match_1_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "_sizeOf_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "match_on_same_ctor") "_@") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 444660554) "_hygCtx") "_hyg") 39), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "proxyTypeEquiv"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "program"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "regs"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "Transducer") 0) "Complexity") "transduce") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "Transducer") 0) "Complexity") "transducerTr") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "lastChunk"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "normChunk"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "padZip") "match_1") "splitter"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "pairδ") "match_1") "splitter"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "serialOut") "match_1") "splitter"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "zipStep"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterBump"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCfg"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterTape"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "FinTM") "lengthBitsTM") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "MultiTapeTM") "step") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "PolyHierarchy") "Padding") 0) "Complexity") "PolyHierarchy") "padDecode") "match_1") "splitter"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "PolyHierarchy") "Padding") 0) "Complexity") "PolyHierarchy") "polyTimeComputable_padDecode") "match_1_1") "splitter"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "PolyHierarchy") "Padding") 0) "Complexity") "PolyHierarchy") "tupleDecode") "match_1") "splitter"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "Inv"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "outWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1") "splitter"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "stepWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "verdictWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFindHost") 0) "Complexity") "IterateFind") "copyCfg"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "PairParse") "rewind_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "StringLoops") 0) "Complexity") "StateLoop") "BlockMapLoop") "blk"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "eval") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "subst") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Primitives") 0) "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Repetition") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "SpaceComplexity") "Machines") "Bin") 0) "Complexity") "LogProg") "bitsVal") "match_1") "splitter"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "SpaceComplexity") "Machines") "Bin") 0) "Complexity") "LogProg") "incW") "match_1") "splitter"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Convention") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnAction"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedSlot"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "copyCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "fullCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_5"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterEmbed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "callTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallBankFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallCleared"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEmbeddedCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallIdleTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallInterval"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLayout"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightScan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSlots"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSpan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackMid"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopForwardCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyDispatch"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyImage"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyPadded"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodySource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopControlAction"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCopyTape"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCaptured"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelSource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHost_bound"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReady"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=5 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padAction"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "List") "filter") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCopyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyMove"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyTape"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPrefixCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2LeftIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2OneIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PairIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2RightIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2SmallIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2Words"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterSplitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extractCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairValidTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "polyUnaryTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "prependTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "rawStripTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "scanCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBank"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitLoop_result") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPos"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareReady"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreClean"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRewindTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitSafe"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitScratch"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitStep"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "stripCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "unaryTokenTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "splitAtLastTrue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "unaryTokenSplit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedBranchCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedCondTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedControlCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedPadTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedReadyCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "captureAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "controlCfg"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "idTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "ifEqTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "tr") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "UnaryTape") "wrT") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgInput") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "MOp") "exec") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Deterministic") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "FinTM") "toCodeTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDecode") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagCfg"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Finite") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBit"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBuffer"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCell"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arDecode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arIndex"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arMoveCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPending"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPos"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReadCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReady"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpaceBlock"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpacePhase"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTail"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTape"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arWriteCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGSpan"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGWindow") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "blankRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCost"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCross"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgLeftRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgRetract"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "headAt"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readState"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "rightRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepBoundary"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepEmbed"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepMove"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepSymbol"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=6 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeCfg"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "virtualNextTag") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Sweep") 0) "Turing") "FinTM") "sweepFold") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Collections") 0) "TCSlib") "Cryptography") "Collection") "collInvRaw"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Collections") 0) "TCSlib") "Cryptography") "Collection") "collInverter"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Collections") 0) "TCSlib") "Cryptography") "Collection") "owfIndexStr"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Collections") 0) "TCSlib") "Cryptography") "Collection") "owfRawStr"), "TCSlib.Cryptography.Asymptotic.Collections", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Ensembles") 0) "TCSlib") "Cryptography") "Ensemble") "blocks"), "TCSlib.Cryptography.Asymptotic.Ensembles", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "HardCoreLemmas") 0) "TCSlib") "Cryptography") "glPadDecode") "match_1") "splitter"), "TCSlib.Cryptography.Asymptotic.HardCoreLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "HardCoreLoops") 0) "TCSlib") "Cryptography") "SelXor") "partialSum") "match_1") "splitter"), "TCSlib.Cryptography.Asymptotic.HardCoreLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Sampling") 0) "TCSlib") "Cryptography") "listToNat_inj") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Sampling", "def/matcher")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=7 requested={reqs.size} active={active} already={already}"
-- CP2 END SEAL


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Goldreich–Levin for collections

The collection form of the Goldreich–Levin theorem [PS10, Theorem 87.3], the one the text uses
for [PS10, Theorem 104.4] and Chapter 4: for a collection `{f_i : D_i → R_i}` of one-way
functions, the padded collection `g_i(x, r) = (f_i(x), r)` is a collection of one-way functions
and `⟨x, r⟩` is hard-core for it; and the same for collections of permutations and of trapdoor
permutations. The machine side is `Asymptotic/HardCoreGLColl.lean` and
`Asymptotic/HardCoreLemmas.lean`. (Moved out of `Asymptotic/HardCore.lean` for size, gate 03c,
finding 11; the declarations, their names and statements are unchanged, and `HardCore.lean`
imports this file, so its importers see them as before.)

**Deviation:** [PS10, Theorem 87.3] for collections (unnumbered): the padded collection
`Collection.glPad F m` pads each element by `|encD_i(default)|` uniform bits; its one-wayness
and hard-core theorems assume length-regular encodings at generated indices
(`∀ n r x, |encD_{index n r} x| = m(n)`), which the text's "`|x| = |r|`" presupposes, at the
cost stated at `Collection.glPad` (no candidate of the library satisfies it as parametrized;
gate 03c, finding 3, ruling G3-7c). Its hard-core proof uses the encoded-domain
Goldreich–Levin lemma `HardcoreBit.invProb_guessInverter_enc_pad`
(`Asymptotic/GoldreichLevinDomain.lean`): the cube lemma does not transfer to a domain `D_i`
whose encoding is a strict subset of the cube (run-3 audit P4-2).

## Main definitions

* `TCSlib.Cryptography.Collection.glPad`, `TCSlib.Cryptography.Collection.glBit` — the padded
  collection `g_i(x, r) = (f_i(x), r)` and the predicate `⟨x, r⟩`.
* `TCSlib.Cryptography.PermCollection.glPad`, `TCSlib.Cryptography.TrapdoorCollection.glPad` —
  the padded collection of (trapdoor) permutations.

## Main results

* `TCSlib.Cryptography.goldreich_levin_coll`, `TCSlib.Cryptography.Collection.OneWay.glPad`,
  `TCSlib.Cryptography.Collection.OneWay.glPad_hardCore` [PS10, Theorem 87.3, collection form].
* `TCSlib.Cryptography.PermCollection.OneWay.glPad`,
  `TCSlib.Cryptography.PermCollection.OneWay.glPad_hardCore`,
  `TCSlib.Cryptography.TrapdoorCollection.OneWay.glPad`,
  `TCSlib.Cryptography.TrapdoorCollection.OneWay.glPad_hardCore` — the (trapdoor) permutation
  forms, for [PS10, Theorem 104.4].

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§2.5: Definition 41.1; §2.10: Definition 55.1; §2.11: Definition 56.1; §3.4.2–3.4.3:
  Theorem 87.3; §3.10: Theorem 104.4.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §2.5 (Theorem 2.3).
* [GL89] O. Goldreich, L. Levin, *A hard-core predicate for all one-way functions*, STOC 1989.
-/

namespace TCSlib.Cryptography

open Complexity Turing Finset

/-! ## Goldreich–Levin for collections [PS10, Theorem 87.3, collection form] -/

namespace Collection

variable (F : Collection)

/-- The **padded collection** `g_i(x, r) = (f_i(x), r)` of [PS10, Theorem 87.3] for a
collection `{f_i : D_i → R_i}` whose elements have encoding length `m(n)` at the indices
generated at parameter `n` (`henc`): the domain `D'_i = D_i × {0,1}^{|encD_i(default)|}` (the
padding has the length of the encoded elements), elements encoded as `⟨encD_i x, r⟩`, the
same index generator `Gen`, the sampler `Sample'(1^n, i) = ⟨Sample(1^n, i), r⟩` with `m(n)`
fresh coins `r`, and the evaluator `⟨i, ⟨x, r⟩⟩ ↦ ⟨eval ⟨i, x⟩, r⟩`. The sampler's outputs
decode (`sample_spec`): the first component by `F.sample_spec`, the padding because it has
exactly `m(n) = |encD_i(default)|` bits by `henc`.

Repair (run-3 audit P3-1): the hypothesis `henc` (previously carried by the theorems only) is
now an argument of the definition, since without it the padding of the sampled string need not
have the length the decoder expects and `Collection.sample_spec` would fail.

**Deviation:** the text's "`|x| = |r|`" presupposes that all elements of `D_i` have the same
encoding length; `glPad` assumes `|encD_i x| = m(n)` at generated indices (`henc`). Cost (gate
03c, finding 3; ruling G3-7c): a non-constant `PolyExpr` is strictly increasing, so an index
generated at two parameters forces `m` constant, and no candidate of the library satisfies `henc`
as parametrized (`rsaTrapdoor`: `2·max(n, 2)`-bit elements; `rabinBlumTrapdoor`: `2·max(n, 3)`;
`expCollection`: `dlDefaultIndex` below `n₀`). A per-index form (`|encD_i x| = |encD_i default|
≤ m(n)`) would admit them; it is not formalized. -/
noncomputable def glPad (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n) :
    Collection where
  D i := F.D i × (Fin (F.encD i default).length → Bool)
  encD i z := pairEncode (F.encD i z.1) (List.ofFn z.2)
  decD i w := match pairDecode w with
    | some (a, b) => match F.decD i a, decodeFin (F.encD i default).length b with
      | some x, some r => some (x, r)
      | _, _ => none
    | none => none
  decD_encD i z := by simp [pairDecode_pairEncode, F.decD_encD, decodeFin_ofFn]
  encD_decD i w z h := by
    rcases hw : pairDecode w with _ | ⟨a, b⟩
    · simp [hw] at h
    cases ha : F.decD i a <;> cases hb : decodeFin (F.encD i default).length b <;> simp [hw, ha, hb] at h
    rw [eq_pairEncode_of_pairDecode w a b hw, ← h, F.encD_decD i a _ ha, ofFn_of_decodeFin_eq_some hb]
  f i z := pairEncode (F.f i z.1) (List.ofFn z.2)
  gen := F.gen
  gen_uniform := F.gen_uniform
  sample := NUPPT.ofPolyTimeUniform (glPadSampleFun_poly F) (.add F.sample.coins m)
  sample_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  eval w := pairEncode (F.eval (pairEncode (pairFstD w) (pairFstD (pairSndD w))))
    (pairSndD (pairSndD w))
  eval_poly := (F.eval_poly.comp (polyTimeComputable_pairFstD.pairEncode
    (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD))).pairEncode
    (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
  eval_spec i z := by simp [F.eval_spec]
  sample_spec n r s := by
    obtain ⟨⟨s₁, s₂⟩, hs⟩ := (Fin.appendEquiv (F.sample.coins.eval n) (m.eval n)).surjective
      (NUPPT.coinsEquiv_ofPolyTimeUniform (glPadSampleFun_poly F) (.add F.sample.coins m) n s)
    have hofn : List.ofFn s = List.ofFn s₁ ++ List.ofFn s₂ := by
      rw [← NUPPT.coinsEquiv_ofPolyTimeUniform_ofFn (glPadSampleFun_poly F)
        (.add F.sample.coins m) n s, ← hs]
      exact List.ofFn_fin_append s₁ s₂
    have hA : (List.ofFn s).take (F.sample.coinLen n) = List.ofFn s₁ := by
      rw [hofn, NUPPT.coinLen_eq, List.take_left' List.length_ofFn]
    have hB : (List.ofFn s).drop (F.sample.coinLen n) = List.ofFn s₂ := by
      rw [hofn, NUPPT.coinLen_eq, List.drop_left' List.length_ofFn]
    have h₁ : List.ofFn ((NUPPT.coinsEquivPoly (A := F.sample) rfl n).symm s₁) = List.ofFn s₁ :=
      NUPPT.coinsEquivPoly_symm_ofFn rfl n s₁
    obtain ⟨x, hx, hev⟩ := F.sample_spec n r ((NUPPT.coinsEquivPoly (A := F.sample) rfl n).symm s₁)
    have hL : (F.encD (pairFstD (F.gen.runAt n [] r)) default).length = m.eval n := by
      have := henc n r default
      rwa [Collection.index_eq] at this
    have hs₂ : List.ofFn s₂ = List.ofFn
        fun j : Fin (F.encD (pairFstD (F.gen.runAt n [] r)) default).length => s₂ (Fin.cast hL j) :=
      List.ofFn_congr hL.symm s₂
    refine ⟨(x, fun j => s₂ (Fin.cast hL j)), ?_, ?_⟩
    · simp only [glPadSample_runAt, hA, hB, pairDecode_pairEncode, ← h₁, ← NUPPT.runAt_eq, hx, hs₂,
        decodeFin_ofFn]
    · simp only [glPadSample_runAt, hA, hB, pairFstD_pairEncode, pairSndD_pairEncode, ← h₁,
        ← NUPPT.runAt_eq, hev, hs₂]

/-- The predicate `h_i(x, r) = ⟨x, r⟩` for the padded collection: the inner product of the
encoding of `x` (padded or truncated to the padding length) with `r`. -/
def glBit : ∀ i, F.D i × (Fin (F.encD i default).length → Bool) → Bool :=
  fun i z => HardcoreBit.ip (padFin _ (F.encD i z.1)) z.2

/-- Unfolding: `h_i(x, r)` is the inner product `⟨padFin(encD_i x), r⟩`, the encoding of `x`
padded or truncated to the padding length `|encD_i(default)|`. -/
theorem glBit_eq (i : List Bool) (z : F.D i × (Fin (F.encD i default).length → Bool)) :
    F.glBit i z = HardcoreBit.ip (padFin _ (F.encD i z.1)) z.2 := rfl

variable {F} in
/-- Unfolding: the padded collection keeps the index generator. -/
theorem glPad_gen (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n) :
    (F.glPad m henc).gen = F.gen := rfl

variable {F} in
/-- Unfolding: `g_i(x, r) = ⟨f_i(x), r⟩`. -/
theorem glPad_f (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i : List Bool) (z : (F.glPad m henc).D i) :
    (F.glPad m henc).f i z = pairEncode (F.f i z.1) (List.ofFn z.2) := rfl

variable {F} in
/-- Unfolding: the sampler of the padded collection runs `Sample(1^n, i)` on its first
`|Sample's coins|` coins and appends the remaining coins. -/
theorem glPad_sample_runAtL (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (n : ℕ) (i r : List Bool) :
    (F.glPad m henc).sample.runAtL n i r =
      pairEncode (F.sample.runAtL n i (r.take (F.sample.coinLen n))) (r.drop (F.sample.coinLen n)) := by
  simp only [glPad, NUPPT.runAtL_eq, NUPPT.ofPolyTimeUniform_def, NUPPT.output_ofPolyTime,
    glPadSampleFun_def, NUPPT.inParam_eq, NUPPT.inArg_eq, NUPPT.inCoins_eq, NUPPT.advInput_eq, NUPPT.layout_eq,
    pairFstD_pairEncode, pairSndD_pairEncode, List.length_replicate, F.sample_uniform n,
    NUPPT.coinLen_eq]

variable {F} in
/-- Unfolding: the decoder of the padded collection is `glPadDecode` at the padding length
`|encD_i(default)|` (propositional: the two `match` expressions are compiled separately). -/
theorem glPad_decD_eq (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i : List Bool) : (F.glPad m henc).decD i = glPadDecode F i (F.encD i default).length := by
  funext w
  unfold Collection.glPad
  dsimp only
  rw [glPadDecode_def]
  cases pairDecode w with
  | none => rfl
  | some ab =>
    obtain ⟨a, b⟩ := ab
    dsimp only
    cases F.decD i a <;> cases decodeFin (F.encD i default).length b <;> rfl

variable {F} in
/-- **The published domain of the padded collection** (ruling "published domain equivalence",
2026-11-06): `D'_i ≃ D_i × {0,1}^{|encD_i(default)|}`, the identity on the definition.
Consumers read the domain of `F.glPad m henc` through it, not by reducing the field `D`. -/
def glPad_domEquiv (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i : List Bool) :
    (F.glPad m henc).D i ≃ F.D i × (Fin (F.encD i default).length → Bool) :=
  Equiv.refl _

variable {F} in
/-- The domain equivalence of the padded collection is the identity on the definition. -/
theorem glPad_domEquiv_apply (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i : List Bool) (z : (F.glPad m henc).D i) : glPad_domEquiv m henc i z = z := rfl

variable {F} in
/-- The encoding of the padded collection through its domain equivalence `e`:
`encD'_i z = ⟨encD_i (e z).1, (e z).2⟩`. -/
theorem glPad_encD (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i : List Bool) (z : (F.glPad m henc).D i) :
    (F.glPad m henc).encD i z =
      pairEncode (F.encD i (glPad_domEquiv m henc i z).1)
        (List.ofFn (glPad_domEquiv m henc i z).2) := rfl

variable {F} in
/-- The decoder of the padded collection through its domain equivalence `e`:
`decD'_i w = e⁻¹ <$> glPadDecode F i |encD_i(default)| w`. -/
theorem glPad_decD (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i w : List Bool) :
    (F.glPad m henc).decD i w =
      (glPadDecode F i (F.encD i default).length w).map (glPad_domEquiv m henc i).symm := by
  rw [glPad_decD_eq]
  cases glPadDecode F i (F.encD i default).length w <;> rfl

variable {F} in
/-- The function of the padded collection through its domain equivalence `e`:
`g_i z = ⟨f_i (e z).1, (e z).2⟩`. -/
theorem glPad_f_domEquiv (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (i : List Bool) (z : (F.glPad m henc).D i) :
    (F.glPad m henc).f i z =
      pairEncode (F.f i (glPad_domEquiv m henc i z).1)
        (List.ofFn (glPad_domEquiv m henc i z).2) := rfl

variable {F} in
/-- The sampler of the padded collection: `ofPolyTimeUniform` of `glPadSampleFun F` with
`Sample.coins + m` coins. -/
theorem glPad_sample (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n) :
    (F.glPad m henc).sample =
      NUPPT.ofPolyTimeUniform (glPadSampleFun_poly F) (.add F.sample.coins m) := rfl

variable {F} in
/-- The evaluator of the padded collection: `⟨i, ⟨x, r⟩⟩ ↦ ⟨eval ⟨i, x⟩, r⟩`. -/
theorem glPad_eval (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (w : List Bool) :
    (F.glPad m henc).eval w =
      pairEncode (F.eval (pairEncode (pairFstD w) (pairFstD (pairSndD w))))
        (pairSndD (pairSndD w)) := rfl

variable {F} in
/-- The padded collection has the indices of `F` (same generator): `index' n r = index n r`. -/
theorem glPad_index (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)),
      (F.encD (F.index n r) x).length = m.eval n)
    (n : ℕ) (r : F.gen.Coins n) : (F.glPad m henc).index n r = F.index n r := by
  rw [Collection.index_eq, Collection.index_eq]; rfl

variable {F} in
/-- The inversion experiment of the padded collection over `D_i × {0,1}^L`, `L = |encD_i(default)|`,
with the answer decoded by `glPadDecode` and compared through `⟨f_i(x), r⟩`. -/
theorem glPad_invProbAt (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)),
      (F.encD (F.index n r) x).length = m.eval n)
    (A : NUPPT) (n : ℕ) :
    (F.glPad m henc).invProbAt A n = uexp fun r : F.gen.Coins n =>
      uprob fun z : (F.D (F.index n r) × (Fin (F.encD (F.index n r) default).length → Bool)) ×
          A.Coins n =>
        ∃ x', glPadDecode F (F.index n r) (F.encD (F.index n r) default).length
            (A.runAt n (pairEncode (F.index n r)
              (pairEncode (F.f (F.index n r) z.1.1) (List.ofFn z.1.2))) z.2) = some x' ∧
          pairEncode (F.f (F.index n r) x'.1) (List.ofFn x'.2) =
            pairEncode (F.f (F.index n r) z.1.1) (List.ofFn z.1.2) := by
  rw [Collection.invProbAt_eq]
  refine congrArg uexp (funext fun r => ?_)
  rw [glPad_index m henc n r, glPad_decD_eq]
  rfl

/-- **The padded collection is one-way** ([PS10, Theorem 87.3], collection form, first clause):
if `F` is a collection of one-way functions whose elements have encoding length `m(n)` at the
indices generated at parameter `n`, then `F.glPad m` is a collection of one-way functions.

**Proof sketch.** *Sampling:* with `h.sampleClose = ⟨δ, hδ, hS⟩`, at index `i = index n r`
the decoded sampler output is `(decD i (Sample(1^n, i; s₁)), decodeFin _ (ofFn s₂))` on the
coin split `splitCoins (Sample.coins n) (m n)` (`glPad_sample_runAtL`, `List.ofFn` of the
split, `uprob_comp_equiv`); `henc` gives `(encD i default).length = m n`, so the second
component decodes exactly (`decodeFin_ofFn`) and `StatClose.prod (hS n r) (StatClose.refl _)`
with `StatClose.map` to the pair gives `SampleClose δ`. *Hard:* for `A : NUPPT` against
`F.glPad m`, the inverter `B` against `F`: coins `m + A.coins` (`NUPPT.exists_split m`, the
first `m n` coins are `r`), on `⟨1^n, ⟨i, y⟩⟩` it calls `A` once on `⟨1^n, ⟨i, ⟨y, r⟩⟩⟩`
(`NUPPT.exists_comp`, `NUPPT.exists_seq`) and returns the first component of the answer
(`pairFstD`). Then `(F.glPad m).invProbAt A n ≤ F.invProbAt B n`: unfold both `uexp` over
`Gen`'s coins (`OneWay.uexp_mono`), split the inner `uprob` over `D_i × ({0,1}^{m n} × A.Coins n)`
against `D_i × B.Coins n` by `uprob_comp_equiv` on `splitCoins`, and `uprob_mono`: a decoded
answer `(x', r')` with `⟨f_i(x'), r'⟩ = ⟨f_i(x), r⟩` has `f_i(x') = f_i(x)`
(`pairEncode_injective`). `Negligible.mono` with `h.hard B`. -/
theorem OneWay.glPad {F : Collection} (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (h : F.OneWay) : (F.glPad m henc).OneWay := by
  obtain ⟨δ, hδ, hS⟩ := h.sampleClose
  refine ⟨⟨δ, hδ, (sampleClose_iff _ _).2 fun n r => ?_⟩, fun A => ?_⟩
  · have key := statClose_glPadSampler F m (F.glPad m henc).sample
      (by rw [glPad_sample, NUPPT.coins_ofPolyTimeUniform]) (glPad_sample_runAtL m henc)
      hS n r _ (henc n r default)
    rw [glPad_index m henc n r, glPad_decD_eq]
    exact key
  · refine (h.hard (glPadCollInvMachine A m)).mono ⟨0, fun n _ => ?_⟩
    rw [abs_of_nonneg (invProbAt_nonneg _ _ _), abs_of_nonneg (invProbAt_nonneg _ _ _),
      glPad_invProbAt m henc A n]
    exact glPad_invProbAt_le F m A n (fun r => (F.encD (F.index n r) default).length)
      (fun r => henc n r default)

/-- **`⟨x, r⟩` is hard-core for the padded collection** ([PS10, Theorem 87.3], collection form,
second clause; inventory Thm-87.3.coll, needed by Theorem 104.4): if `F` is a collection of
one-way functions with encoding length `m(n)` at generated indices, then
`h_i(x, r) = ⟨encD_i x, r⟩` is a hard-core predicate for `F.glPad m` (`Collection.HardCore`).

Repair (run-3 audit P4-2): statement unchanged. The run-2 sketch transferred the cube lemma
`HardcoreBit.invProb_guessInverter` to `D_i` by "identifying `D_i` with `{0,1}^{m n}` through
the injective encoding"; that step is invalid — the image of `encD_i` is in general a strict
subset of the cube (`Z_N^*`, `QR_N`), the uniform `x ∈ D_i` is not a uniform cube element and
the predictor's behaviour off the image is uncontrolled. The transfer is replaced by the
encoded-domain lemma `HardcoreBit.invProb_guessInverter_enc_pad`
(`Asymptotic/GoldreichLevinDomain.lean`), stated for `x` uniform on an arbitrary finite type
with an arbitrary encoding into `{0,1}^m`.

**Proof sketch.** *Easy:* `⟨i, ⟨a, b⟩⟩ ↦ ipFun ⟨padToLen a b, b⟩` — pad `a = encD_i x` to the
length of `b = r` and apply the inner-product evaluator (`exists_glBitCollEvaluator`,
`Asymptotic/HardCoreGLColl.lean`). *Hard:* `glColl_negligible` with the padding length
`L n r = |encD_i(default)| = m(n)` (`henc`) and the one-wayness of the padded collection
(`OneWay.glPad`, its inversion experiment rewritten by `glPad_decD_eq`): by contradiction,
`not_negligible_iff` gives `c` with `1/2 + n^{−c} ≤ E_r[Pr[A(1^n, ⟨i, ⟨f_i x, r⟩⟩) = ⟨encD_i x, r⟩]]`
infinitely often; the good indices (`HardcoreBit.half_le_uprob_threshold`) have per-index
success `≥ 1/2 + n^{−c}/2`, where `HardcoreBit.invProb_guessInverter_enc_pad` with
`enc := padFin (m n) ∘ encD_i` and the hard-wired `k(n) = size (8 m(n) n^{2c})` (`glKc`) makes
the recovery procedure of [PS10, Algorithm 89.6] output `encD_i x` with probability
`≥ ε/(4·2^{k(n)})`, `ε = n^{−c}/2`; the inverter `glCollMachine` (the recovery machine `glMachine`
on the pre-processed predictor `⟨⟨i, y⟩, q⟩ ↦ ⟨i, ⟨y, q⟩⟩`, output `⟨x', r⟩`) realises it
(`glColl_uprob_le`); averaging over the good indices (`HardcoreBit.uprob_mul_le_uexp`) gives
inversion probability `≥ ε²/(4·2^{k(n)})`, inverse polynomial infinitely often, contradicting
`(OneWay.glPad m henc h).hard`. -/
theorem OneWay.glPad_hardCore {F : Collection} (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (h : F.OneWay) : (F.glPad m henc).HardCore F.glBit := by
  refine ⟨?_, fun A => ?_⟩
  · obtain ⟨H, hH, hHx⟩ := exists_glBitCollEvaluator F
    exact ⟨H, hH, fun i x => hHx i x.1 x.2⟩
  · have hmax : ∀ x : ℝ, x ≤ 1 / 2 + max 0 (x - 1 / 2) := fun x => by
      linarith [le_max_right (0 : ℝ) (x - 1 / 2)]
    refine ⟨_, glColl_negligible F m (fun n r => (F.encD (F.index n r) default).length)
      (fun n r => henc n r default) henc A (fun B => ?_), fun n => hmax _⟩
    have key := (OneWay.glPad m henc h).hard B
    simp only [Collection.invProbAt_eq] at key
    simp only [glPad_decD_eq] at key
    exact key

end Collection

/-- **Goldreich–Levin for collections** ([PS10, Theorem 87.3], the collection form the text
uses for Theorem 104.4 and Chapter 4): for a collection `F` of one-way functions with
encoding length `m(n)` at generated indices, `g_i(x, r) = (f_i(x), r)` is a collection of
one-way functions and `⟨x, r⟩` is hard-core for it. -/
theorem goldreich_levin_coll {F : Collection} (m : PolyExpr)
    (henc : ∀ n (r : F.gen.Coins n) (x : F.D (F.index n r)), (F.encD (F.index n r) x).length = m.eval n)
    (h : F.OneWay) : (F.glPad m henc).OneWay ∧ (F.glPad m henc).HardCore F.glBit :=
  ⟨Collection.OneWay.glPad m henc h, Collection.OneWay.glPad_hardCore m henc h⟩

/-- The padded collection of a collection of permutations is a collection of permutations
[PS10, Theorem 87.3, "(OWP)"]: `g_i = perm_i × id` on `D_i × {0,1}^{|encD_i default|}`. -/
noncomputable def PermCollection.glPad (P : PermCollection) (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n) :
    PermCollection :=
  { P.toCollection.glPad m henc with
    perm := fun i => (P.perm i).prodCongr (Equiv.refl _)
    f_perm := fun i z => by simp [Collection.glPad, P.f_perm] }

/-- Unfolding: the underlying collection of `P.glPad m henc` is `P.toCollection.glPad m henc`. -/
theorem PermCollection.glPad_toCollection (P : PermCollection) (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n) :
    (P.glPad m henc).toCollection = P.toCollection.glPad m henc := rfl

/-- **The published domain of the padded permutation collection**:
`(P.glPad m henc).D i ≃ D_i × {0,1}^{|encD_i(default)|}`, the identity on the definition. -/
def PermCollection.glPad_domEquiv (P : PermCollection) (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n)
    (i : List Bool) :
    (P.glPad m henc).D i ≃ P.D i × (Fin (P.encD i default).length → Bool) :=
  Equiv.refl _

/-- The domain equivalence of the padded permutation collection is the identity. -/
theorem PermCollection.glPad_domEquiv_apply (P : PermCollection) (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n)
    (i : List Bool) (z : (P.glPad m henc).D i) : P.glPad_domEquiv m henc i z = z := rfl

/-- The permutation of the padded permutation collection through its domain equivalence `e`:
`e⁻¹ ∘ (perm_i × id) ∘ e`. -/
theorem PermCollection.glPad_perm (P : PermCollection) (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n)
    (i : List Bool) :
    (P.glPad m henc).perm i = ((P.glPad_domEquiv m henc i).trans
      ((P.perm i).prodCongr (Equiv.refl _))).trans (P.glPad_domEquiv m henc i).symm :=
  rfl

/-- **The padded permutation collection is one-way** when the original is (collection form of
[PS10, Theorem 87.3] for Definition 55.1). -/
theorem PermCollection.OneWay.glPad {P : PermCollection} (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n)
    (h : P.OneWay) : (P.glPad m henc).OneWay :=
  Collection.OneWay.glPad m henc h

/-- **`⟨x, r⟩` is hard-core for the padded permutation collection**. -/
theorem PermCollection.OneWay.glPad_hardCore {P : PermCollection} (m : PolyExpr)
    (henc : ∀ n (r : P.gen.Coins n) (x : P.D (P.index n r)), (P.encD (P.index n r) x).length = m.eval n)
    (h : P.OneWay) : (P.glPad m henc).toCollection.HardCore P.glBit :=
  Collection.OneWay.glPad_hardCore m henc h

/-- The padded collection of a collection of trapdoor permutations is a collection of
trapdoor permutations [PS10, Theorem 87.3 for Definition 56.1, as used in Theorem 104.4]:
`Inv'(1^n, ⟨t, ⟨y, r⟩⟩) = ⟨Inv(1^n, ⟨t, y⟩), r⟩`.

**Proof sketch** (of `inv_spec`). Unfold the activation of the `ofPolyTimeUniform` machine
(`NUPPT.output_ofPolyTime`, the layout projections); `T.inv` is uniform so its activation is
its output on the layout with empty advice; `T.inv_spec` decodes the first component to
`(perm i).symm y.1` and `decodeFin_ofFn` the second to `y.2`. -/
noncomputable def TrapdoorCollection.glPad (T : TrapdoorCollection) (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n) :
    TrapdoorCollection :=
  { T.toPermCollection.glPad m henc with
    inv := NUPPT.ofPolyTimeUniform (glPadInvFun_poly T) T.inv.coins
    inv_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
    inv_spec := fun n r y s => by
      have hspec := T.inv_spec n r y.1 (NUPPT.coinsCongr (NUPPT.coins_ofPolyTimeUniform _ _) n s)
      rw [NUPPT.runAt_eq T.inv, NUPPT.coinsCongr_ofFn, T.inv_uniform.runAtL_eq] at hspec
      rw [NUPPT.runAt_eq (NUPPT.ofPolyTimeUniform (glPadInvFun_poly T) T.inv.coins),
        NUPPT.runAtL_ofPolyTimeUniform]
      simp only [glPadInvFun_eq, NUPPT.inParam_eq, NUPPT.inArg_eq, NUPPT.inCoins_eq,
        NUPPT.advInput_eq, NUPPT.layout_eq, pairFstD_pairEncode, pairSndD_pairEncode,
        PermCollection.glPad, Collection.glPad, pairDecode_pairEncode, decodeFin_ofFn,
        NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform] at hspec ⊢
      rw [hspec]
      rfl }

/-- Unfolding: the underlying permutation collection of `T.glPad m henc` is
`T.toPermCollection.glPad m henc`. -/
theorem TrapdoorCollection.glPad_toPermCollection (T : TrapdoorCollection) (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n) :
    (T.glPad m henc).toPermCollection = T.toPermCollection.glPad m henc := rfl

/-- **The published domain of the padded trapdoor collection**:
`(T.glPad m henc).D i ≃ D_i × {0,1}^{|encD_i(default)|}`, the identity on the definition. -/
def TrapdoorCollection.glPad_domEquiv (T : TrapdoorCollection) (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n)
    (i : List Bool) :
    (T.glPad m henc).D i ≃ T.D i × (Fin (T.encD i default).length → Bool) :=
  Equiv.refl _

/-- The domain equivalence of the padded trapdoor collection is the identity. -/
theorem TrapdoorCollection.glPad_domEquiv_apply (T : TrapdoorCollection) (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n)
    (i : List Bool) (z : (T.glPad m henc).D i) : T.glPad_domEquiv m henc i z = z := rfl

/-- The trapdoor inverter of the padded trapdoor collection: `ofPolyTimeUniform` of
`glPadInvFun T` with the coins of `T.inv`. -/
theorem TrapdoorCollection.glPad_inv (T : TrapdoorCollection) (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n) :
    (T.glPad m henc).inv = NUPPT.ofPolyTimeUniform (glPadInvFun_poly T) T.inv.coins := rfl

/-- **The padded trapdoor collection is one-way** when the original is ([PS10, Theorem 87.3]
for Definition 56.1 (5)). -/
theorem TrapdoorCollection.OneWay.glPad {T : TrapdoorCollection} (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n)
    (h : T.OneWay) : (T.glPad m henc).OneWay :=
  Collection.OneWay.glPad m henc h

/-- **`⟨x, r⟩` is hard-core for the padded trapdoor collection**: the hypothesis "trapdoor
permutations with a hard-core predicate" of [PS10, Theorem 104.4] is satisfiable from trapdoor
permutations whose generated indices encode elements in exactly `m(n)` bits (`henc`; no
candidate of the library satisfies it as parametrized, see `Collection.glPad`). -/
theorem TrapdoorCollection.OneWay.glPad_hardCore {T : TrapdoorCollection} (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n)
    (h : T.OneWay) : (T.glPad m henc).toCollection.HardCore T.glBit :=
  Collection.OneWay.glPad_hardCore m henc h

/-- **`⟨x, r⟩` is hard-core for the padded trapdoor collection**, the predicate read through the
published domain equivalence `e = T.glPad_domEquiv m henc`: `z ↦ ⟨(e z).1, (e z).2⟩` is
hard-core for `T.glPad m henc` (the form of `glPad_hardCore` that a consumer states without
reducing the domain of `T.glPad`; `e` is the identity). -/
theorem TrapdoorCollection.OneWay.glPad_hardCore_domEquiv {T : TrapdoorCollection} (m : PolyExpr)
    (henc : ∀ n (r : T.gen.Coins n) (x : T.D (T.index n r)), (T.encD (T.index n r) x).length = m.eval n)
    (h : T.OneWay) :
    (T.glPad m henc).toCollection.HardCore fun i z => T.glBit i (T.glPad_domEquiv m henc i z) :=
  h.glPad_hardCore m henc

end TCSlib.Cryptography

run_cmd Lean.logInfo "CP2-EOF"
