/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency
-- CP2 WHOLE-FILE SEAL (evidence probe; not library source): 944 requests for TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRep
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "emit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "step"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes") "mono") "match_1_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Instr") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "LinE") "val"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "act"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "bitsOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "ctl"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "enc"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "init"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "linOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "run"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "shiftInput"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "toTM"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "DTIME"), "TCSlib.Complexity.ClassP.DTIME", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "find?_congr_of_mem") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostCtrl"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostRet"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "step"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LoopInv"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NP"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Computes"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Uniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "advInput"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "adviceLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsCongr"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquivPoly"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "combineAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inArg"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inCoins"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inParam"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "layout"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "mk") "_flat_ctor"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "output"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAt"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAtL"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runLit"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "timeBound"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "P"), "TCSlib.Complexity.ClassP.P", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyBound"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "normal"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyTimeComputable"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "drop"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_3"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_5"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "take"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "flag"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstep"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstepBound"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "length_flatMap_range_le") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_sunfold"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_unsafe_rec"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "match_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "TimeConstructible"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockTests", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockDone"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "coNP"), "TCSlib.Complexity.ClassNP.CoNP", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "guardedStep"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "isNilB"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairFstD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairSndD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_iterateFind") "match_1"), "TCSlib.Complexity.Randomized.Repetition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_unary") "match_1_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceDropAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceTakeAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "xorD"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EfficientProverProof") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EfficientProverProofErr") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "CountLoop") "acc"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "CountLoop") "out"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "CountLoop") "start"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "CountLoop") "step"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "bitsToNat_eq_blockVal") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "blockVal"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "blockVal_lt") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "cbound"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "cstep"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "divNum"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "findSome?_range_eq") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "firstIdx"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "firstIdx_congr") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "firstIdx_congr") "match_1_3"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "flatMap_range_ite_eq") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "foldr_swap_val") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "fyApply"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "fyFail"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "fyIter"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "fyIter_le") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "fyTarget"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "isBij"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "loopState"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "loopState") "_sunfold"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "loopState") "_unsafe_rec"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "loopState") "match_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "modNum"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "offsetVal"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "permFromCoinsNum"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "permInvNum"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "permNum"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "rowFirst"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "rowInv"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "rowMap"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "swapNum"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "trialIdx"), "TCSlib.Cryptography.ZeroKnowledge.EncodingPermutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "EncodingMachines") "unaryMul_poly") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "Isomorphic"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "Liso"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "Lniso"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "Riso"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "SqrtLoop") "acc"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "SqrtLoop") "out"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "SqrtLoop") "start"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "SqrtLoop") "step"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "argM"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "argX"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "argZ"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "coinSlice"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "decGraphAt"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "encInstance"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=0 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giProtocol"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giProtocolRep"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giProver"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giProver") "match_1"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giProverRep"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giVerifier"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giVerifier") "match_1"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "giVerifierRep"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "gniProtocol"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "gniProtocolRep"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "gniProver"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "gniVerifier"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "gniVerifier") "match_1"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "gniVerifierRep"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "graphTest"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "ilayout"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "instanceG₀"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "instanceG₁"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "instanceVertexCount"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "instanceVertices"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "mulInvStr"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "not_isomorphic_both") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "padSq"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "permCoinLen"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "permFailBound"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "permTest"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "relabelAt"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "risoTest"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "samplePerm"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "sampleStr"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "tapeSplit"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "vcount"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "GI") "wellFormedInstance"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "PushesUniform"), "TCSlib.Cryptography.HardcoreBit.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "IP"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "InteractiveProof") "exists_accept") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "InteractiveProof") "exists_accept") "match_1_3"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "InteractiveProof") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "InteractiveProofErr") "exists_accept") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "InteractiveProofErr") "exists_accept") "match_1_3"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "InteractiveProofErr") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Negligible"), "TCSlib.Cryptography.Foundations.Negligible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Noticeable"), "TCSlib.Cryptography.Foundations.Negligible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "ProverBounded"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "ProverBounded") "exists_complete") "match_1_1"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "_sizeOf_1"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "execution"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "outP"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "outV"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "transcript"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "transcriptWith"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "viewP"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "viewV"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "withV"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Protocol") "withV_vCoinsEquiv"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "StatClose"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "Efficient"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "ReadsPrefix"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "_sizeOf_1"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "coinLen"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "encodeMsgs"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "ofNUPPT"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Strategy") "out"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "View") "_sizeOf_1"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "View") "encode"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "View") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "WitnessRelation") "mk") "_flat_ctor"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "acceptProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsEquiv"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsToNat"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "coinTable"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "copies"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "decColoring"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "decGraph"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "decPerm"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "distAdv"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "encColoring"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "encGraph"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "encPerm"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "exec"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "exec") "_sunfold"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "exec") "_unsafe_rec"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "exec") "match_1"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "firstHit"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "fisherYates"), "TCSlib.Cryptography.Asymptotic.Permutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "fisherYates_injOn") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Permutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "foldr_swap_succ") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Permutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "fyOffsets"), "TCSlib.Cryptography.Asymptotic.Permutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "liftSucc"), "TCSlib.Cryptography.Asymptotic.Permutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "mixDist"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "moverIsV"), "TCSlib.Cryptography.ZeroKnowledge.Interaction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "multicopyAvgRed"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "multicopyHybrid"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "multicopyRed"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "npProtocol"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpBitsEquiv"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpGen"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpGenBits"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpGenNot"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPair"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredictor"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "owpPredictorBits"), "TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "permBits"), "TCSlib.Cryptography.Asymptotic.Permutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "permFromCoins"), "TCSlib.Cryptography.Asymptotic.Permutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "permGraph"), "TCSlib.Cryptography.ZeroKnowledge.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "permTrials"), "TCSlib.Cryptography.Asymptotic.Permutations", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "predProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgAdv"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExt"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtAvgRed"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtBits"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtBitsRed"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgExtRed"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgHybrid"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prgStep"), "TCSlib.Cryptography.Pseudorandom.Generators", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "prod_sub_eq_factorial") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Permutations", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "pushSampler"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "rejectionSample"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "sunglassRed"), "TCSlib.Cryptography.Pseudorandom.Indistinguishability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uexp"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uniformFromBits"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uprob"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "witnessLanguage"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "witnessSet"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "HasMinEntropy"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "_sizeOf_1"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "collision"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "map"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "mk") "_flat_ctor"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "prod"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "uniform"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "statDist"), "TCSlib.InformationTheory.StatisticalDistance", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "init"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "inputSymbol"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ofWords"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "select"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "workTapeSymbols"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "serialize"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "toFinTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "Computes"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTimeVia"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "DecidesInTime"), "TCSlib.Complexity.ClassP.DTIME", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "VirtualTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "appendBitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferTape"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedFirstCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedScanCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedSecondCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callEntry"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callExit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1"), "TCSlib.Complexity.Randomized.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "constTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "controlAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "emitAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "indexedVisit"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairLenCheckTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=1 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyBitsTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rewind_scan") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveWithTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM_computes") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepAct"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_sunfold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "match_1"), "TCSlib.Complexity.TuringMachine.Sweep", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepRevCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepTape"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "tapeBlocks"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualMove"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "Clean"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "entry"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "AgreeOn"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesFunInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "DecidableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "haltsAtStep"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "indicator"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "initCfg"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "outputSymbol"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "relabelState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "runFrom"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsed"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsedByTape"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step") "match_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "visitedByTapeHead"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "cfg"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "rewind_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "SafeRun"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "ones"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT") "match_1"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "actionBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "dbl"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instInhabitedCfg") "default"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "moveInputPos"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "padAction"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_sunfold"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_3"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairEncode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplitWith"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "spaceUsedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "stateWord"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryFin"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "visitedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "certificateSplit"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "paddedVerifier"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "pairedVerifier"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "_sunfold"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "_unsafe_rec"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_3"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_3") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_bound"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_split"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_split") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_strip"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majInit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "pairMapSnd") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "polyTimeComputable_unary") "match_1_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "_sizeOf_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "match_on_same_ctor") "_@") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 444660554) "_hygCtx") "_hyg") 39), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "proxyTypeEquiv"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "program"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "regs"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterBump"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCfg"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterTape"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "FinTM") "lengthBitsTM") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "MultiTapeTM") "step") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "Inv"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "outWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1") "splitter"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "stepWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "verdictWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFindHost") 0) "Complexity") "IterateFind") "copyCfg"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "PairParse") "rewind_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "StringLoops") 0) "Complexity") "StateLoop") "BlockMapLoop") "blk"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "eval") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "subst") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Primitives") 0) "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Repetition") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Convention") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=2 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnAction"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedSlot"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "copyCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "fullCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_5"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterEmbed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "callTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallBankFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallCleared"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEmbeddedCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallIdleTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallInterval"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLayout"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightScan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSlots"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSpan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackMid"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopForwardCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyDispatch"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyImage"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyPadded"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodySource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopControlAction"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCopyTape"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCaptured"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelSource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHost_bound"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReady"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padAction"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "List") "filter") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCopyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyMove"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyTape"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPrefixCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2LeftIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2OneIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PairIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2RightIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2SmallIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2Words"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterSplitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extractCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairValidTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "polyUnaryTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "prependTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "rawStripTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "scanCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBank"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=3 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitLoop_result") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPos"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareReady"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreClean"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRewindTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitSafe"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitScratch"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitStep"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "stripCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "unaryTokenTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "splitAtLastTrue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "unaryTokenSplit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedBranchCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedCondTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedControlCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedPadTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedReadyCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "captureAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "controlCfg"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "idTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "ifEqTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "tr") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "UnaryTape") "wrT") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgInput") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "MOp") "exec") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Deterministic") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "FinTM") "toCodeTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDecode") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagCfg"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Finite") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBit"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBuffer"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCell"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arDecode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arIndex"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arMoveCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPending"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPos"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReadCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReady"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpaceBlock"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpacePhase"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTail"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTape"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arWriteCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGSpan"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGWindow") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "blankRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCost"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCross"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgLeftRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgRetract"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "headAt"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readState"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "rightRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepBoundary"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepEmbed"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepMove"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepSymbol"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeCfg"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "virtualNextTag") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Sweep") 0) "Turing") "FinTM") "sweepFold") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Sampling") 0) "TCSlib") "Cryptography") "listToNat_inj") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Sampling", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "ZeroKnowledge") "EncodingMachines") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "ZeroKnowledge") "EncodingMachines") 0) "TCSlib") "Cryptography") "EncodingMachines") "unaryMul_poly") "match_1_1") "splitter"), "TCSlib.Cryptography.ZeroKnowledge.EncodingMachines", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "ZeroKnowledge") "GraphIsomorphism") "Efficiency") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "ZeroKnowledge") "GraphIsomorphism") "Proofs") 0) "TCSlib") "Cryptography") "GI") "giProver") "match_1") "splitter"), "TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "ZeroKnowledge") "InteractiveProofs") 0) "TCSlib") "Cryptography") "exec") "match_1") "splitter"), "TCSlib.Cryptography.ZeroKnowledge.InteractiveProofs", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=4 requested={reqs.size} active={active} already={already}"
-- CP2 END SEAL


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The graph protocols: efficiency of the repeated parties

The loop infrastructure for the polynomial-time machines behind the `|x|`-fold parties of
[PS10, Protocols 118.3 and 120.6] (inventory item Inf-4.2), and the machine of the
`|x|`-fold graph non-isomorphism verifier `gniVerifierRep`, proved for the shadow strategies
of `GraphIsomorphism/Proofs.lean` (the `|x|`-fold graph isomorphism parties are in
`GraphIsomorphism/EfficiencyRepGI.lean`). The repeated parties read the
*number* of messages received (to select the coin block of the current iteration and to
decide whether the protocol is over), the parity of that number and the last message
received, and the verifiers' verdicts scan the `|x|` iterations. All of these are **peeling
loops** over the nested-pair encoding `encodeMsgs hist = ⟨m₀, ⟨m₁, …⟩⟩` of the history
(`peelLoop_poly`: iterate a shrinking map until a test holds, counting the rounds in unary)
and one **unary-count loop** (`iterUnary_poly`: iterate a step `|u|` times for a unary count
`u` read from the input), both instances of the state-loop lemma `GI.stateFind`.

## Main definitions

* `TCSlib.Cryptography.GI.peelSteps` — the rounds of a peeling loop (with fuel).
* `TCSlib.Cryptography.GI.msgCount`, `GI.halfCount`, `GI.lastSteps` — the number of messages,
  half of it, and the rounds to the last message of an encoded history.

## Main results

* `TCSlib.Cryptography.GI.peelLoop_poly`, `GI.iterUnary_poly` — the two loop schemes.
* `TCSlib.Cryptography.GI.msgCount_poly`, `GI.halfLoop_poly`, `GI.lastMsg_poly` — the
  number of messages in unary, the half count with the remainder (parity), the last message.
* `TCSlib.Cryptography.GI.unaryMul_poly`, `GI.coinSlice_poly` — unary multiplication and the
  coin block of a given iteration.
* `TCSlib.Cryptography.GI.gniVerifierRep_efficient` — the `|x|`-fold graph non-isomorphism
  verifier is efficient (D8).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§4.5 Interactive proofs, pp. 117–120.)
* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*, Cambridge
  University Press, 2009. (§2.2, the class FP.)
-/

namespace TCSlib.Cryptography.GI

open Complexity Turing Complexity.StateLoop

/-! ### Peeling the nested-pair encoding -/

/-- The second component of a nonempty word is shorter than the word. -/
theorem length_pairSndD_lt {w : List Bool} (h : w ≠ []) : (pairSndD w).length < w.length := by
  cases hw : pairDecode w with
  | none =>
    simp only [pairSndD, hw, Option.map_none, Option.getD_none, List.length_nil]
    exact List.length_pos_of_ne_nil h
  | some ab =>
    obtain ⟨a, b⟩ := ab
    have hz := eq_pairEncode_of_pairDecode w a b hw
    subst hz
    rw [pairSndD_pairEncode, length_pairEncode]
    omega

/-- The second component of a word is no longer than the word. -/
theorem length_pairSndD_le (w : List Bool) : (pairSndD w).length ≤ w.length := by
  rcases eq_or_ne w [] with rfl | h
  · rfl
  · exact (length_pairSndD_lt h).le

/-- Iterating a length-non-increasing map never lengthens. -/
theorem length_iterate_le {f : List Bool → List Bool} (hle : ∀ w, (f w).length ≤ w.length)
    (w : List Bool) : ∀ k, (f^[k] w).length ≤ w.length
  | 0 => le_rfl
  | k + 1 => by
    rw [Function.iterate_succ_apply']
    exact (hle _).trans (length_iterate_le hle w k)

/-- Peeling the empty word gives the empty word. -/
theorem iterate_pairSndD_nil : ∀ k : ℕ, pairSndD^[k] [] = []
  | 0 => rfl
  | k + 1 => by rw [Function.iterate_succ_apply]; exact iterate_pairSndD_nil k

/-- Peeling the encoding of a history drops its first message. -/
theorem pairSndD_encodeMsgs (hist : List (List Bool)) :
    pairSndD (Strategy.encodeMsgs hist) = Strategy.encodeMsgs (hist.drop 1) := by
  cases hist with
  | nil => rfl
  | cons m h => rw [Strategy.encodeMsgs_cons, pairSndD_pairEncode, List.drop_succ_cons, List.drop_zero]

/-- Peeling the encoding of a history `k` times leaves the encoding of the history without its
first `k` messages. -/
theorem iterate_pairSndD_encodeMsgs : ∀ (k : ℕ) (hist : List (List Bool)),
    pairSndD^[k] (Strategy.encodeMsgs hist) = Strategy.encodeMsgs (hist.drop k)
  | 0, _ => rfl
  | k + 1, hist => by
    rw [Function.iterate_succ_apply, pairSndD_encodeMsgs, iterate_pairSndD_encodeMsgs k, List.drop_drop]
    congr 2
    omega

/-- The encoding of a history is empty exactly when the history is. -/
theorem encodeMsgs_eq_nil_iff (hist : List (List Bool)) : Strategy.encodeMsgs hist = [] ↔ hist = [] := by
  cases hist with
  | nil => simp
  | cons m h => simp [Turing.pairEncode_ne_nil]

/-- The rounds of a peeling loop, with fuel: `0` once `stop` holds, else one more than from
`f w`. -/
def peelStepsAux (f : List Bool → List Bool) (stop : List Bool → Bool) : ℕ → List Bool → ℕ
  | 0, _ => 0
  | n + 1, w => if stop w then 0 else peelStepsAux f stop n (f w) + 1

/-- The rounds of a peeling loop from `w` (fuel `|w| + 1`): the first round at which `stop`
holds along the orbit of `f`, provided `f` shortens every word that is not stopped. -/
def peelSteps (f : List Bool → List Bool) (stop : List Bool → Bool) (w : List Bool) : ℕ :=
  peelStepsAux f stop (w.length + 1) w

/-- With enough fuel the round count is the first round at which `stop` holds, and it is at
most `|w|`.

**Proof sketch.** Induction on the fuel: if `stop w` holds the count is `0`; otherwise `f w` is
shorter than `w` (`hdec`), the induction hypothesis applies to it, and the three clauses shift
by one round (`Function.iterate_succ_apply`). -/
theorem peelStepsAux_spec (f : List Bool → List Bool) (stop : List Bool → Bool)
    (hdec : ∀ w, stop w = false → (f w).length < w.length) :
    ∀ n w, w.length < n →
      (∀ k < peelStepsAux f stop n w, stop (f^[k] w) = false) ∧
        stop (f^[peelStepsAux f stop n w] w) = true ∧ peelStepsAux f stop n w ≤ w.length := by
  intro n
  induction n with
  | zero => intro w hw; omega
  | succ n ih =>
    intro w hw
    by_cases hs : stop w = true
    · simp only [peelStepsAux, hs, if_true]
      exact ⟨fun k hk => absurd hk (Nat.not_lt_zero _), by simpa using hs, Nat.zero_le _⟩
    · have hs' : stop w = false := by simpa using hs
      have hlt := hdec w hs'
      obtain ⟨h1, h2, h3⟩ := ih (f w) (by omega)
      simp only [peelStepsAux, hs', Bool.false_eq_true, if_false]
      refine ⟨fun k hk => ?_, ?_, by omega⟩
      · cases k with
        | zero => simpa using hs'
        | succ k => rw [Function.iterate_succ_apply]; exact h1 k (by omega)
      · rw [Function.iterate_succ_apply]; exact h2

/-- The specification of `peelSteps`. -/
theorem peelSteps_spec (f : List Bool → List Bool) (stop : List Bool → Bool)
    (hdec : ∀ w, stop w = false → (f w).length < w.length) (w : List Bool) :
    (∀ k < peelSteps f stop w, stop (f^[k] w) = false) ∧
      stop (f^[peelSteps f stop w] w) = true ∧ peelSteps f stop w ≤ w.length :=
  peelStepsAux_spec f stop hdec _ w (Nat.lt_succ_self _)

/-- `peelSteps` is the first round at which `stop` holds. -/
theorem peelSteps_eq (f : List Bool → List Bool) (stop : List Bool → Bool)
    (hdec : ∀ w, stop w = false → (f w).length < w.length) {w : List Bool} {k : ℕ}
    (hk : ∀ j < k, stop (f^[j] w) = false) (hk' : stop (f^[k] w) = true) :
    peelSteps f stop w = k := by
  obtain ⟨h1, h2, -⟩ := peelSteps_spec f stop hdec w
  rcases lt_trichotomy (peelSteps f stop w) k with h | h | h
  · have := hk _ h
    rw [h2] at this
    exact absurd this (by decide)
  · exact h
  · have := h1 _ h
    rw [hk'] at this
    exact absurd this (by decide)

/-- **Peeling loop:** iterate a length-non-increasing polynomial-time map `f` from `w` until
the polynomial-time test `stop` holds (within `|w|` rounds, as `f` shortens unstopped words),
returning the final word paired with the round count in unary.

**Proof sketch.** `stateFind` on the state `⟨rem, 1^k⟩` from `⟨w, []⟩` with the step
`⟨f rem, 1^{k+1}⟩`, the test `stop rem` and the output `⟨rem, 1^k⟩`; the orbit is
`⟨f^[k] w, 1^k⟩`, of length at most `3|w| + 2`, and `peelSteps_spec` gives the first round. -/
theorem peelLoop_poly {f : List Bool → List Bool} (hf : PolyTimeComputable f)
    (hle : ∀ w, (f w).length ≤ w.length) {stop : List Bool → Bool}
    (hstop : PolyTimeComputable fun w => [stop w])
    (hdec : ∀ w, stop w = false → (f w).length < w.length) :
    PolyTimeComputable fun w =>
      pairEncode (f^[peelSteps f stop w] w) (List.replicate (peelSteps f stop w) true) := by
  have horbit : ∀ (w : List Bool) (k : ℕ),
      orbit (fun w => pairEncode w [])
        (fun st => pairEncode (f (pairFstD (pairSndD st))) (true :: pairSndD (pairSndD st))) w k =
        pairEncode (f^[k] w) (List.replicate k true) := by
    intro w k
    induction k with
    | zero => rfl
    | succ k ih =>
      rw [orbit_succ, ih, pairSndD_pairEncode, pairFstD_pairEncode, pairSndD_pairEncode,
        Function.iterate_succ_apply', List.replicate_succ]
  have hstart : PolyTimeComputable fun w => pairEncode w [] :=
    polyTimeComputable_id.pairEncode (polyTimeComputable_const [])
  have hstep : PolyTimeComputable fun st =>
      pairEncode (f (pairFstD (pairSndD st))) (true :: pairSndD (pairSndD st)) :=
    (hf.comp (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD)).pairEncode
      ((cons_poly true).comp (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD))
  have hacc : PolyTimeComputable fun st => [stop (pairFstD (pairSndD st))] :=
    hstop.comp (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD)
  have h := stateFind hstart hstep hacc
    polyTimeComputable_pairSndD .var (.add (.mul (.const 3) .var) (.const 2)) (peelSteps f stop)
    (fun w => (peelSteps_spec f stop hdec w).2.2)
    (fun w k hk => by
      rw [horbit, length_pairEncode, List.length_replicate]
      have h1 := length_iterate_le hle w k
      have h2 := (peelSteps_spec f stop hdec w).2.2
      simp only [PolyExpr.eval_add, PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
      omega)
    (fun w k hk => by
      show stop (pairFstD (pairSndD (pairEncode w _))) = false
      rw [horbit, pairSndD_pairEncode, pairFstD_pairEncode]
      exact (peelSteps_spec f stop hdec w).1 k hk)
    (fun w => by
      show stop (pairFstD (pairSndD (pairEncode w _))) = true
      rw [horbit, pairSndD_pairEncode, pairFstD_pairEncode]
      exact (peelSteps_spec f stop hdec w).2.1)
  refine ptc_congr h fun w => ?_
  rw [horbit, pairSndD_pairEncode]

/-! ### The number of messages, its half and parity, the last message -/

/-- Peeling `pairSndD` until the word is empty shortens every unstopped word. -/
theorem dec_sndD_nil : ∀ w : List Bool, decide (w = []) = false → (pairSndD w).length < w.length :=
  fun w hw => length_pairSndD_lt (by simpa using hw)

/-- The number of messages of an encoded history: the rounds of peeling until empty. -/
def msgCount (w : List Bool) : ℕ := peelSteps pairSndD (fun v => decide (v = [])) w

/-- The number of messages of `encodeMsgs hist` is `|hist|`. -/
theorem msgCount_encodeMsgs (hist : List (List Bool)) : msgCount (Strategy.encodeMsgs hist) = hist.length := by
  apply peelSteps_eq _ _ dec_sndD_nil
  · intro j hj
    rw [iterate_pairSndD_encodeMsgs]
    simp [encodeMsgs_eq_nil_iff, List.drop_eq_nil_iff, hj]
  · rw [iterate_pairSndD_encodeMsgs]
    simp

/-- The number of messages in unary is polynomial-time (`peelLoop_poly`). -/
theorem msgCount_poly : PolyTimeComputable fun w => List.replicate (msgCount w) true :=
  ptc_congr (polyTimeComputable_pairSndD.comp
    (peelLoop_poly polyTimeComputable_pairSndD length_pairSndD_le isNil_poly dec_sndD_nil))
    fun w => by simp [msgCount]

/-- Peeling two messages at a time until at most one is left shortens every unstopped word. -/
theorem dec_sndD_two : ∀ w : List Bool, (decide (w = []) || decide (pairSndD w = [])) = false →
    (pairSndD (pairSndD w)).length < w.length := by
  intro w hw
  simp only [Bool.or_eq_false_iff, decide_eq_false_iff_not] at hw
  exact (length_pairSndD_lt hw.2).trans (length_pairSndD_lt hw.1)

/-- Half the number of messages of an encoded history: the rounds of peeling two messages at a
time until at most one is left. -/
def halfCount (w : List Bool) : ℕ :=
  peelSteps (fun v => pairSndD (pairSndD v)) (fun v => decide (v = []) || decide (pairSndD v = [])) w

/-- Peeling two messages `k` times drops `2k` messages. -/
theorem iterate_sndD_two_encodeMsgs (k : ℕ) (hist : List (List Bool)) :
    (fun v => pairSndD (pairSndD v))^[k] (Strategy.encodeMsgs hist) =
      Strategy.encodeMsgs (hist.drop (2 * k)) := by
  induction k generalizing hist with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply]
    show (fun v => pairSndD (pairSndD v))^[k] (pairSndD^[2] (Strategy.encodeMsgs hist)) = _
    rw [iterate_pairSndD_encodeMsgs, ih, List.drop_drop]
    congr 2
    ring

/-- The half count of `encodeMsgs hist` is `|hist| / 2`. -/
theorem halfCount_encodeMsgs (hist : List (List Bool)) :
    halfCount (Strategy.encodeMsgs hist) = hist.length / 2 := by
  apply peelSteps_eq _ _ dec_sndD_two
  · intro j hj
    rw [iterate_sndD_two_encodeMsgs]
    have h1 : ¬ hist.drop (2 * j) = [] := by
      rw [List.drop_eq_nil_iff]; omega
    have h2 : ¬ (hist.drop (2 * j)).drop 1 = [] := by
      rw [List.drop_drop, List.drop_eq_nil_iff]; omega
    simp only [Bool.or_eq_false_iff, decide_eq_false_iff_not, encodeMsgs_eq_nil_iff, h1,
      not_false_eq_true, true_and, pairSndD_encodeMsgs]
    exact h2
  · rw [iterate_sndD_two_encodeMsgs]
    simp only [Bool.or_eq_true, decide_eq_true_eq, encodeMsgs_eq_nil_iff, pairSndD_encodeMsgs,
      List.drop_drop, List.drop_eq_nil_iff]
    omega

/-- The remainder after the half loop on `encodeMsgs hist`: the history without its first
`2 (|hist| / 2)` messages (empty exactly when `|hist|` is even). -/
theorem halfRem_encodeMsgs (hist : List (List Bool)) :
    (fun v => pairSndD (pairSndD v))^[halfCount (Strategy.encodeMsgs hist)] (Strategy.encodeMsgs hist) =
      Strategy.encodeMsgs (hist.drop (2 * (hist.length / 2))) := by
  rw [halfCount_encodeMsgs, iterate_sndD_two_encodeMsgs]

/-- The half loop (remainder paired with the half count in unary) is polynomial-time. -/
theorem halfLoop_poly : PolyTimeComputable fun w =>
    pairEncode ((fun v => pairSndD (pairSndD v))^[halfCount w] w) (List.replicate (halfCount w) true) :=
  peelLoop_poly (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
    (fun w => (length_pairSndD_le _).trans (length_pairSndD_le w))
    (or_poly isNil_poly (isNil_poly.comp polyTimeComputable_pairSndD)) dec_sndD_two

/-- Peeling until the second component is empty shortens every unstopped word. -/
theorem dec_sndD_last : ∀ w : List Bool, decide (pairSndD w = []) = false → (pairSndD w).length < w.length := by
  intro w hw
  apply length_pairSndD_lt
  rintro rfl
  exact (by simpa using hw : ¬ pairSndD ([] : List Bool) = []) rfl

/-- The rounds to the last message of an encoded history. -/
def lastSteps (w : List Bool) : ℕ := peelSteps pairSndD (fun v => decide (pairSndD v = [])) w

/-- The rounds to the last message of `encodeMsgs hist` are `|hist| - 1`. -/
theorem lastSteps_encodeMsgs (hist : List (List Bool)) :
    lastSteps (Strategy.encodeMsgs hist) = hist.length - 1 := by
  apply peelSteps_eq _ _ dec_sndD_last
  · intro j hj
    rw [iterate_pairSndD_encodeMsgs, pairSndD_encodeMsgs]
    simp only [decide_eq_false_iff_not, encodeMsgs_eq_nil_iff, List.drop_drop, List.drop_eq_nil_iff]
    omega
  · rw [iterate_pairSndD_encodeMsgs, pairSndD_encodeMsgs]
    simp only [decide_eq_true_eq, encodeMsgs_eq_nil_iff, List.drop_drop, List.drop_eq_nil_iff]
    omega

/-- The first component of the remainder after `lastSteps` rounds is the last message. -/
theorem lastMsg_encodeMsgs (hist : List (List Bool)) :
    pairFstD (pairSndD^[lastSteps (Strategy.encodeMsgs hist)] (Strategy.encodeMsgs hist)) =
      hist.getLastD [] := by
  rw [lastSteps_encodeMsgs, iterate_pairSndD_encodeMsgs, Strategy.pairFstD_encodeMsgs,
    List.headD_eq_head?, List.head?_drop, List.getLastD_eq_getLast?, List.getLast?_eq_getElem?]

/-- The last message of an encoded history is polynomial-time (`peelLoop_poly`). -/
theorem lastMsg_poly : PolyTimeComputable fun w => pairFstD (pairSndD^[lastSteps w] w) :=
  ptc_congr (polyTimeComputable_pairFstD.comp (polyTimeComputable_pairFstD.comp
    (peelLoop_poly polyTimeComputable_pairSndD length_pairSndD_le (isNil_poly.comp polyTimeComputable_pairSndD)
      dec_sndD_last))) fun w => by simp [lastSteps]

/-! ### Unary multiplication and coin blocks -/

/-- Unary multiplication `⟨u, v⟩ ↦ 1^{|u| · |v|}` is polynomial-time
(`Turing.FinTM.computesFunInTime_unaryMul`). -/
theorem unaryMul_poly : PolyTimeComputable fun z => match pairDecode z with
    | some (u, v) => List.replicate (u.length * v.length) true
    | none => [] := by
  obtain ⟨M, c, hM⟩ := Turing.FinTM.computesFunInTime_unaryMul
  exact ⟨M, c, 2, hM⟩

/-- The product of two unary counts given by polynomial-time maps. -/
theorem unaryMul_comp {f g : List Bool → ℕ} (hf : PolyTimeComputable fun w => List.replicate (f w) true)
    (hg : PolyTimeComputable fun w => List.replicate (g w) true) :
    PolyTimeComputable fun w => List.replicate (f w * g w) true :=
  ptc_congr (unaryMul_poly.comp (hf.pairEncode hg)) fun w => by simp [pairDecode_pairEncode]

/-- The coin block `coinSlice c i r` for a block length `c = p(|u|)` and an index `i` given in
unary by polynomial-time maps (`polyTimeComputable_pairDropPoly`, `polyTimeComputable_pairTakePoly`). -/
theorem coinSlice_poly (p : PolyExpr) {u i r : List Bool → List Bool} (hu : PolyTimeComputable u)
    (hi : PolyTimeComputable i) (hr : PolyTimeComputable r) :
    PolyTimeComputable fun w => coinSlice (p.eval (u w).length) (i w).length (r w) := by
  have hic : PolyTimeComputable fun w => List.replicate ((i w).length * p.eval (u w).length) true :=
    unaryMul_comp (ptc_congr (polyTimeComputable_unary.comp hi) fun w => rfl) (unaryPoly_comp p hu)
  have hdrop : PolyTimeComputable fun w => (r w).drop ((i w).length * p.eval (u w).length) :=
    ptc_congr ((polyTimeComputable_pairDropPoly .var).comp (hic.pairEncode hr)) fun w => by simp
  refine ptc_congr ((polyTimeComputable_pairTakePoly p).comp (hu.pairEncode hdrop)) fun w => ?_
  simp [coinSlice]

/-! ### Iterating a step a unary number of times -/

/-- **Unary-count loop:** on `x₀ = ⟨u, s₀⟩`, iterate `s ↦ step ⟨x₀, s⟩` exactly `|u|` times from
`s₀` (the step may read `x₀`), provided the orbit stays within the bound `B|x₀|`.

**Proof sketch.** `stateFind` on the state `⟨s, 1^k⟩` from `⟨x₀, ⟨s₀, []⟩⟩` with the test
`|u| ≤ |1^k|`, which fires first at round `|u| ≤ |x₀|`. -/
theorem iterUnary_poly {step : List Bool → List Bool} (hstep : PolyTimeComputable step) (B : PolyExpr)
    (hbound : ∀ x₀ k, k ≤ (pairFstD x₀).length →
      ((fun s => step (pairEncode x₀ s))^[k] (pairSndD x₀)).length ≤ B.eval x₀.length) :
    PolyTimeComputable fun x₀ => (fun s => step (pairEncode x₀ s))^[(pairFstD x₀).length] (pairSndD x₀) := by
  have horbit : ∀ (x₀ : List Bool) (k : ℕ),
      orbit (fun x₀ => pairEncode (pairSndD x₀) [])
        (fun st => pairEncode (step (pairEncode (pairFstD st) (pairFstD (pairSndD st))))
          (true :: pairSndD (pairSndD st))) x₀ k =
        pairEncode ((fun s => step (pairEncode x₀ s))^[k] (pairSndD x₀)) (List.replicate k true) := by
    intro x₀ k
    induction k with
    | zero => rfl
    | succ k ih =>
      rw [orbit_succ, ih, pairSndD_pairEncode, pairFstD_pairEncode, pairFstD_pairEncode,
        pairSndD_pairEncode, Function.iterate_succ_apply', List.replicate_succ]
  have hstart : PolyTimeComputable fun x₀ => pairEncode (pairSndD x₀) [] :=
    polyTimeComputable_pairSndD.pairEncode (polyTimeComputable_const [])
  have hstep' : PolyTimeComputable fun st =>
      pairEncode (step (pairEncode (pairFstD st) (pairFstD (pairSndD st)))) (true :: pairSndD (pairSndD st)) :=
    (hstep.comp (polyTimeComputable_pairFstD.pairEncode
      (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD))).pairEncode
      ((cons_poly true).comp (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD))
  have hacc : PolyTimeComputable fun st =>
      [decide ((pairFstD (pairFstD st)).length ≤ (pairSndD (pairSndD st)).length)] :=
    lenLe_comp (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
      (polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD)
  have hout : PolyTimeComputable fun st => pairFstD (pairSndD st) :=
    polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD
  have h := stateFind hstart hstep' hacc hout .var
    (.add (.mul (.const 2) B) (.add (.const 2) .var)) (fun x₀ => (pairFstD x₀).length)
    (fun x₀ => length_pairFstD_le x₀)
    (fun x₀ k hk => by
      rw [horbit, length_pairEncode, List.length_replicate]
      have hk' : k ≤ (pairFstD x₀).length := hk
      have h1 := hbound x₀ k hk'
      have h2 := length_pairFstD_le x₀
      simp only [PolyExpr.eval_add, PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
      omega)
    (fun x₀ k hk => by
      show decide ((pairFstD (pairFstD (pairEncode x₀ _))).length ≤
        (pairSndD (pairSndD (pairEncode x₀ _))).length) = false
      rw [horbit, pairFstD_pairEncode, pairSndD_pairEncode, pairSndD_pairEncode, List.length_replicate]
      simpa using hk)
    (fun x₀ => by
      show decide ((pairFstD (pairFstD (pairEncode x₀ _))).length ≤
        (pairSndD (pairSndD (pairEncode x₀ _))).length) = true
      rw [horbit, pairFstD_pairEncode, pairSndD_pairEncode, pairSndD_pairEncode, List.length_replicate]
      simp)
  refine ptc_congr h fun x₀ => ?_
  rw [horbit, pairSndD_pairEncode, pairFstD_pairEncode]

/-! ### The verifier of the `|x|`-fold graph non-isomorphism protocol -/

/-- The number of messages of the layout's history, in unary. -/
theorem cnt_poly : PolyTimeComputable fun w => List.replicate (msgCount (argM w)) true :=
  msgCount_poly.comp argM_poly

/-- The test `|hist| < |x|` (the protocol is not over), as the negated length comparison of
`1^{|x|}` with the message count. -/
theorem ltLen_poly : PolyTimeComputable fun w => [decide (msgCount (argM w) < (NUPPT.inParam w).length)] := by
  refine ptc_congr (not_poly (lenLe_comp cnt_poly NUPPT.polyTimeComputable_inParam)) fun w => ?_
  simp only [List.length_replicate]
  exact congrArg (fun b => [b]) (by rw [← decide_not]; exact decide_eq_decide.2 not_le.symm)

/-- The coin polynomial of one iteration of the graph non-isomorphism protocol,
`1 + (N + 1)²`. -/
def gniBlock : PolyExpr := .add (.const 1) (.normal 1 2)

/-- The block length evaluates to `1 + (N + 1)²`. -/
theorem gniBlock_eval (N : ℕ) : gniBlock.eval N = 1 + (N + 1) ^ 2 := by
  simp [gniBlock, PolyExpr.eval_normal]

/-- The coin block of the current iteration of the `|x|`-fold graph non-isomorphism verifier:
`coinSlice (1 + (|x|+1)²) |hist| r`. -/
theorem gniSlice_poly : PolyTimeComputable fun w =>
    coinSlice (gniBlock.eval (NUPPT.inParam w).length) (msgCount (argM w)) (NUPPT.inCoins w) :=
  ptc_congr (coinSlice_poly gniBlock NUPPT.polyTimeComputable_inParam cnt_poly
    NUPPT.polyTimeComputable_inCoins) fun w => by simp

/-- One round of the verdict scan of the `|x|`-fold graph non-isomorphism verifier, on the
state word `⟨x₀, ⟨remMsgs, ⟨remCoins, [bit]⟩⟩⟩` (with `x₀ = ⟨1^{|x|}, …⟩`): peel one message,
drop one coin block, and conjoin the comparison of the message's first bit with the block's
first bit. -/
def gniStep (st : List Bool) : List Bool :=
  pairEncode (pairSndD (pairFstD (pairSndD st)))
    (pairEncode ((pairFstD (pairSndD (pairSndD st))).drop (gniBlock.eval (pairFstD (pairFstD st)).length))
      [(pairSndD (pairSndD (pairSndD st))).headD false &&
        decide ((pairFstD (pairFstD (pairSndD st))).headD false =
          (pairFstD (pairSndD (pairSndD st))).headD false)])

/-- The scan round is polynomial-time. -/
theorem gniStep_poly : PolyTimeComputable gniStep := by
  have hM : PolyTimeComputable fun st => pairFstD (pairSndD st) :=
    polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD
  have hR : PolyTimeComputable fun st => pairFstD (pairSndD (pairSndD st)) :=
    polyTimeComputable_pairFstD.comp (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
  have hB : PolyTimeComputable fun st => pairSndD (pairSndD (pairSndD st)) :=
    polyTimeComputable_pairSndD.comp (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
  have hu : PolyTimeComputable fun st => pairFstD (pairFstD st) :=
    polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD
  have hdrop : PolyTimeComputable fun st =>
      (pairFstD (pairSndD (pairSndD st))).drop (gniBlock.eval (pairFstD (pairFstD st)).length) :=
    ptc_congr ((polyTimeComputable_pairDropPoly gniBlock).comp (hu.pairEncode hR)) fun st => by simp
  have hbit : PolyTimeComputable fun st => [(pairSndD (pairSndD (pairSndD st))).headD false &&
      decide ((pairFstD (pairFstD (pairSndD st))).headD false = (pairFstD (pairSndD (pairSndD st))).headD false)] :=
    polyTimeComputable_and (headBit_poly.comp hB)
      (ptc_congr (polyTimeComputable_pairEq.comp
        ((headBit_poly.comp (polyTimeComputable_pairFstD.comp hM)).pairEncode (headBit_poly.comp hR)))
        fun st => by simp)
  exact (polyTimeComputable_pairSndD.comp hM).pairEncode (hdrop.pairEncode hbit)

/-- The scan after `k` rounds from the input `⟨u, ⟨M, ⟨R, [b]⟩⟩⟩` (with `c = 1 + (|u|+1)²`):
the remaining messages, the remaining coins and the conjunction of the first `k` comparisons
with the initial bit `b`. -/
theorem gniIter_eq (u M R : List Bool) (b : Bool) (k : ℕ) :
    (fun s => gniStep (pairEncode (pairEncode u (pairEncode M (pairEncode R [b]))) s))^[k]
        (pairSndD (pairEncode u (pairEncode M (pairEncode R [b])))) =
      pairEncode (pairSndD^[k] M) (pairEncode (R.drop (k * gniBlock.eval u.length))
        [b && decide (∀ j < k, (pairFstD (pairSndD^[j] M)).headD false =
          (R.drop (j * gniBlock.eval u.length)).headD false)]) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Function.iterate_succ_apply', ih]
    simp only [gniStep, pairFstD_pairEncode, pairSndD_pairEncode, List.headD_cons, List.drop_drop,
      Function.iterate_succ_apply', Nat.forall_lt_succ_right, Bool.decide_and, Bool.and_assoc, Nat.succ_mul]

/-- The scan from an arbitrary input has, after at least one round, the shape of `gniIter_eq`
with the components read off the input (the bit being unspecified). -/
theorem gniIter_shape (x₀ : List Bool) (k : ℕ) (hk : 1 ≤ k) :
    ∃ b : Bool, (fun s => gniStep (pairEncode x₀ s))^[k] (pairSndD x₀) =
      pairEncode (pairSndD^[k] (pairFstD (pairSndD x₀)))
        (pairEncode ((pairFstD (pairSndD (pairSndD x₀))).drop (k * gniBlock.eval (pairFstD x₀).length)) [b]) := by
  induction k with
  | zero => omega
  | succ k ih =>
    rcases Nat.eq_zero_or_pos k with rfl | hpos
    · exact ⟨(pairSndD (pairSndD (pairSndD x₀))).headD false &&
        decide ((pairFstD (pairFstD (pairSndD x₀))).headD false = (pairFstD (pairSndD (pairSndD x₀))).headD false),
        by simp only [Nat.zero_add, Function.iterate_one, gniStep, pairFstD_pairEncode, pairSndD_pairEncode,
          Nat.one_mul]⟩
    · obtain ⟨b, hb⟩ := ih hpos
      refine ⟨b && decide ((pairFstD (pairSndD^[k] (pairFstD (pairSndD x₀)))).headD false =
        ((pairFstD (pairSndD (pairSndD x₀))).drop (k * gniBlock.eval (pairFstD x₀).length)).headD false), ?_⟩
      rw [Function.iterate_succ_apply', hb]
      simp only [gniStep, pairFstD_pairEncode, pairSndD_pairEncode, List.drop_drop,
        Function.iterate_succ_apply', Nat.succ_mul, List.headD_cons]

/-- The scan states are bounded by `4|x₀| + 5`. -/
theorem gniIter_bound (x₀ : List Bool) (k : ℕ) :
    ((fun s => gniStep (pairEncode x₀ s))^[k] (pairSndD x₀)).length ≤
      (PolyExpr.add (.mul (.const 4) .var) (.const 5)).eval x₀.length := by
  simp only [PolyExpr.eval_add, PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
  rcases Nat.eq_zero_or_pos k with rfl | hk
  · have := length_pairSndD_le x₀
    simp only [Function.iterate_zero, id]
    omega
  · obtain ⟨b, hb⟩ := gniIter_shape x₀ k hk
    rw [hb, length_pairEncode, length_pairEncode, List.length_singleton]
    have h1 := length_iterate_le length_pairSndD_le (pairFstD (pairSndD x₀)) k
    have h2 : (pairFstD (pairSndD x₀)).length ≤ x₀.length :=
      (length_pairFstD_le _).trans (length_pairSndD_le _)
    have h3 : ((pairFstD (pairSndD (pairSndD x₀))).drop (k * gniBlock.eval (pairFstD x₀).length)).length ≤
        x₀.length := by
      rw [List.length_drop]
      exact (Nat.sub_le _ _).trans
        ((length_pairFstD_le _).trans ((length_pairSndD_le _).trans (length_pairSndD_le _)))
    omega

/-- The verdict scan of the `|x|`-fold graph non-isomorphism verifier is polynomial-time: the
one-bit word `[decide (∀ j < |x|, bit of message j = bit of coin block j)]`
(`iterUnary_poly` on `gniStep` from `⟨1^{|x|}, ⟨msgs, ⟨r, [true]⟩⟩⟩`, closed form `gniIter_eq`). -/
theorem gniScan_poly : PolyTimeComputable fun w =>
    [decide (∀ j < (NUPPT.inParam w).length, (pairFstD (pairSndD^[j] (argM w))).headD false =
      ((NUPPT.inCoins w).drop (j * gniBlock.eval (NUPPT.inParam w).length)).headD false)] := by
  have hx₀ : PolyTimeComputable fun w =>
      pairEncode (NUPPT.inParam w) (pairEncode (argM w) (pairEncode (NUPPT.inCoins w) [true])) :=
    NUPPT.polyTimeComputable_inParam.pairEncode (argM_poly.pairEncode
      (NUPPT.polyTimeComputable_inCoins.pairEncode (polyTimeComputable_const [true])))
  have h := (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD).comp
    ((iterUnary_poly gniStep_poly _ (fun x₀ k _ => gniIter_bound x₀ k)).comp hx₀)
  refine ptc_congr h fun w => ?_
  simp only [Function.comp_apply, pairFstD_pairEncode]
  rw [gniIter_eq, pairSndD_pairEncode, pairSndD_pairEncode, Bool.true_and]

/-- The first bit of a nonempty prefix is the first bit of the word. -/
theorem headD_take {c : ℕ} (hc : 0 < c) (l : List Bool) : (l.take c).headD false = l.headD false := by
  cases l with
  | nil => simp
  | cons a l =>
    cases c with
    | zero => omega
    | succ c => simp

/-- An entry of a list with default is the first entry of the corresponding suffix. -/
theorem getD_eq_headD_drop {α : Type*} (l : List α) (j : ℕ) (d : α) : l.getD j d = (l.drop j).headD d := by
  rw [List.headD_eq_head?, List.head?_drop, List.getD_eq_getElem?_getD]

/-- The verdict condition of the `|x|`-fold graph non-isomorphism verifier, read through the
scan: message `j` is `pairFstD (pairSndD^[j] msgs)` and the first bit of coin block `j` is the
first bit of `r.drop (j c)`. -/
theorem gni_verdict_iff (hist : List (List Bool)) (r : List Bool) (N c : ℕ) (hc : 0 < c) :
    (∀ j : Fin N, (hist.getD j []).headD false = (coinSlice c j r).headD false) ↔
      ∀ j < N, (pairFstD (pairSndD^[j] (Strategy.encodeMsgs hist))).headD false =
        (r.drop (j * c)).headD false := by
  rw [Fin.forall_iff]
  refine forall_congr' fun j => forall_congr' fun _ => ?_
  rw [iterate_pairSndD_encodeMsgs, Strategy.pairFstD_encodeMsgs, coinSlice, headD_take hc, Fin.val_mk,
    getD_eq_headD_drop]

/-- The verifier of the `|x|`-fold graph non-isomorphism protocol is efficient (D8) (Inf-4.2).

**Proof sketch.** `efficient_of_polyTime`: the message count `1^{|hist|}` (`cnt_poly`), the
test `|hist| < |x|` (`ltLen_poly`), the coin block of the current iteration (`gniSlice_poly`)
and the message `relabel_poly` of `G_b` by the sampled permutation on the one hand, the
well-formedness test conjoined with the verdict scan (`gniScan_poly`) on the other; the
equation with `gniVerifierRep.next` is `msgCount_encodeMsgs`, `gniBlock_eval` and
`gni_verdict_iff`. -/
theorem gniVerifierRep_efficient : gniVerifierRep.Efficient := by
  have hri := gniSlice_poly
  have hsel : PolyTimeComputable fun w =>
      if (coinSlice (gniBlock.eval (NUPPT.inParam w).length) (msgCount (argM w)) (NUPPT.inCoins w)).headD false
        then pairSndD (argX w) else pairFstD (argX w) :=
    polyTimeComputable_ite (headBit_poly.comp hri) w₁_poly w₀_poly
  have hσ : PolyTimeComputable fun w => sampleStr (pairFstD (argX w))
      (coinSlice (gniBlock.eval (NUPPT.inParam w).length) (msgCount (argM w)) (NUPPT.inCoins w)).tail :=
    ptc_congr (sampleStr_poly.comp (w₀_poly.pairEncode (tail_poly.comp hri))) fun w => by simp
  have hmsg := relabel_poly hsel hσ
  have hwf : PolyTimeComputable fun w => [wellFormedInstance (argX w)] := wellFormed_poly.comp argX_poly
  have hverdict := polyTimeComputable_and hwf gniScan_poly
  refine efficient_of_polyTime gniVerifierRep (polyTimeComputable_ite ltLen_poly hmsg hverdict) ?_
  intro x z r hist
  show (if hist.length < x.length then _ else _) = _
  simp only [argM_ilayout, msgCount_encodeMsgs, inParam_ilayout, List.length_replicate, inCoins_ilayout,
    argX_ilayout, vcount_ilayout, gniBlock_eval, decide_eq_true_eq]
  by_cases hlt : hist.length < x.length
  · rw [if_pos hlt, if_pos hlt, relabelAt_replicate, sampleStr, decPerm_encPerm, List.drop_one]
    split_ifs <;> rfl
  · rw [if_neg hlt, if_neg hlt, Bool.decide_and, Bool.decide_eq_true]
    congr 2
    exact decide_eq_decide.2 (gni_verdict_iff hist r x.length _ (by positivity))

end TCSlib.Cryptography.GI

run_cmd Lean.logInfo "CP2-EOF"
