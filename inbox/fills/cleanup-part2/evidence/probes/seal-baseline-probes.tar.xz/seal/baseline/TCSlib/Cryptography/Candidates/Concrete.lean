/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Cryptography.OneWayFunctions.Amplification
import TCSlib.Cryptography.NumberTheory.Chebyshev
import TCSlib.Cryptography.NumberTheory.Units
import TCSlib.Cryptography.Asymptotic.Sampling
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Asymptotic.CollectionsHelpers
import TCSlib.Cryptography.Candidates.Arithmetic
import Mathlib.Logic.Equiv.Prod
-- CP2 WHOLE-FILE SEAL (evidence probe; not library source): 831 requests for TCSlib.Cryptography.Candidates.Concrete
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "emit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "step"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes") "mono") "match_1_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Instr") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "LinE") "val"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "act"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "bitsOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "ctl"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "enc"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "init"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "linOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "run"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "shiftInput"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "toTM"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "DTIME"), "TCSlib.Complexity.ClassP.DTIME", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "find?_congr_of_mem") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostCtrl"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostRet"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "step"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LoopInv"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NP"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Computes"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Uniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "advInput"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "adviceLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsCongr"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquivPoly"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "combineAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "distinguisher"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "distinguisherL"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inArg"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inCoins"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inParam"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inverter"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inverterLit"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "layout"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "mk") "_flat_ctor"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "output"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "predictor"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAt"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAtL"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runLenPoly"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runLit"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "timeBound"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "withIndexParam"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "withIndexParam_coinsEquiv"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "P"), "TCSlib.Complexity.ClassP.P", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyBound"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "normal"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "UnaryPT"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "padDecode"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "padDecode") "match_1"), "TCSlib.Complexity.PolyHierarchy.Padding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "polyTimeComputable_padDecode") "match_1_1"), "TCSlib.Complexity.PolyHierarchy.Padding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode") "_sunfold"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode") "_unsafe_rec"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyHierarchy") "tupleDecode") "match_1"), "TCSlib.Complexity.PolyHierarchy.Padding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyTimeComputable"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "drop"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_3"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_5"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "take"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "flag"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstep"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstepBound"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "length_flatMap_range_le") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_sunfold"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_unsafe_rec"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "match_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "TimeConstructible"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockTests", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockDone"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "coNP"), "TCSlib.Complexity.ClassNP.CoNP", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "guardedStep"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "isNilB"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairFstD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairSndD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_iterateFind") "match_1"), "TCSlib.Complexity.Randomized.Repetition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_unary") "match_1_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceDropAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceTakeAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "xorD"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "ArithmeticFP") "mk") "_flat_ctor"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "addStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "divModStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "leStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "modExpStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "mulStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "natToBits"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "natToList"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "primeStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "sizeStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "subStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Candidates") "xgcdStr"), "TCSlib.Cryptography.Candidates.Arithmetic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "PushesUniform"), "TCSlib.Cryptography.HardcoreBit.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "MRLiar"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "chunk"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "listToNat"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "millerRabin"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "mrExp"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "mrLiars"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "mrOdd"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "samplePrime"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "NumberTheory") "samplePrimeCoins"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "prodFun"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoBad"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoInverter"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoTry"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoTryProb"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "StatClose"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "acceptProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsEquiv"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsToNat"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "decodeFin"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "distAdv"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "firstHit"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProbOpt"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "padFin"), "TCSlib.Cryptography.Asymptotic.Adversary", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=0 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "predProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "rejectionSample"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "splitCoins"), "TCSlib.Cryptography.Asymptotic.CollectionsHelpers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uexp"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uniformFromBits"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uprob"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "HasMinEntropy"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "_sizeOf_1"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "collision"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "map"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "mk") "_flat_ctor"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "prod"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "uniform"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "statDist"), "TCSlib.InformationTheory.StatisticalDistance", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "init"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "inputSymbol"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ofWords"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "select"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "workTapeSymbols"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "serialize"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "toFinTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "Computes"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTimeVia"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "DecidesInTime"), "TCSlib.Complexity.ClassP.DTIME", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "VirtualTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "appendBitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferTape"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedFirstCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedScanCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedSecondCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callEntry"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callExit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1"), "TCSlib.Complexity.Randomized.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "constTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "controlAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "emitAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "indexedVisit"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairLenCheckTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyBitsTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rewind_scan") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveWithTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM_computes") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepAct"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_sunfold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "match_1"), "TCSlib.Complexity.TuringMachine.Sweep", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepRevCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepTape"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "tapeBlocks"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualMove"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "Clean"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "entry"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "AgreeOn"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesFunInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "DecidableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "haltsAtStep"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "indicator"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "initCfg"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "outputSymbol"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "relabelState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "runFrom"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsed"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsedByTape"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step") "match_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "visitedByTapeHead"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "cfg"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "rewind_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "SafeRun"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "ones"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT") "match_1"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "actionBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "dbl"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instInhabitedCfg") "default"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "moveInputPos"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "padAction"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_sunfold"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_3"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairEncode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplitWith"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "spaceUsedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "stateWord"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryFin"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "visitedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "certificateSplit"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "paddedVerifier"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "pairedVerifier"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "_sunfold"), "TCSlib.Complexity.ClassNP.NP", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=1 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "_unsafe_rec"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_3"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "stripCertificate") "match_3") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_bound"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_concat") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_split"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_split") "match_1"), "TCSlib.Complexity.ClassNP.NP", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "NP") 0) "Complexity") "verifier_strip"), "TCSlib.Complexity.ClassNP.NP", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majInit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockMajority") 0) "Complexity") "majStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockMajority", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "pairMapSnd") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "polyTimeComputable_unary") "match_1_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "_sizeOf_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "match_on_same_ctor") "_@") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 444660554) "_hygCtx") "_hyg") 39), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "proxyTypeEquiv"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "program"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "regs"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterBump"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCfg"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterTape"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "FinTM") "lengthBitsTM") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "MultiTapeTM") "step") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "PolyHierarchy") "Padding") 0) "Complexity") "PolyHierarchy") "padDecode") "match_1") "splitter"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "PolyHierarchy") "Padding") 0) "Complexity") "PolyHierarchy") "polyTimeComputable_padDecode") "match_1_1") "splitter"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "PolyHierarchy") "Padding") 0) "Complexity") "PolyHierarchy") "tupleDecode") "match_1") "splitter"), "TCSlib.Complexity.PolyHierarchy.Padding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "Inv"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "outWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1") "splitter"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "stepWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "verdictWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFindHost") 0) "Complexity") "IterateFind") "copyCfg"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "PairParse") "rewind_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "StringLoops") 0) "Complexity") "StateLoop") "BlockMapLoop") "blk"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "eval") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "subst") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Primitives") 0) "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Repetition") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Convention") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnAction"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedSlot"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "copyCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "fullCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_5"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterEmbed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "callTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallBankFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallCleared"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEmbeddedCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallIdleTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallInterval"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLayout"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightScan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSlots"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSpan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackMid"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopForwardCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyDispatch"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyImage"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyPadded"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodySource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopControlAction"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCopyTape"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCaptured"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelSource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHost_bound"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReady"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=2 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padAction"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "List") "filter") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCopyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyMove"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyTape"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPrefixCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2LeftIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2OneIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PairIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2RightIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2SmallIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2Words"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterSplitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extractCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairValidTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "polyUnaryTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "prependTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "rawStripTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "scanCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBank"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitLoop_result") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPos"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareReady"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreClean"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRewindTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitSafe"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitScratch"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitStep"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "stripCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "unaryTokenTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "splitAtLastTrue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "unaryTokenSplit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedBranchCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedCondTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedControlCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedPadTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedReadyCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "captureAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "controlCfg"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "idTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "ifEqTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "tr") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "UnaryTape") "wrT") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgInput") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "MOp") "exec") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Deterministic") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "FinTM") "toCodeTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDecode") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagCfg"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Finite") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBit"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBuffer"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCell"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arDecode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arIndex"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arMoveCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPending"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPos"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReadCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReady"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpaceBlock"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpacePhase"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTail"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTape"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arWriteCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGSpan"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGWindow") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "blankRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCost"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCross"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgLeftRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgRetract"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "headAt"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readState"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "rightRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepBoundary"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepEmbed"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepMove"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepSymbol"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=3 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeCfg"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "virtualNextTag") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Sweep") 0) "Turing") "FinTM") "sweepFold") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Sampling") 0) "TCSlib") "Cryptography") "listToNat_inj") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Sampling", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Chebyshev") 0) "TCSlib") "Cryptography") "NumberTheory") "two_mul_le_two_pow") "match_1_1"), "TCSlib.Cryptography.NumberTheory.Chebyshev", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "firstHit_eq_some_of_first") "match_1_1"), "TCSlib.Cryptography.NumberTheory.Primality", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "powOneSubgroup"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "powPmOneSubgroup"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "spAcc"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "spFind_eq") "match_1"), "TCSlib.Cryptography.NumberTheory.Primality", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "spFind_eq") "match_1") "splitter"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "spOut"), "TCSlib.Cryptography.NumberTheory.Primality", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "NumberTheory") "Primality") 0) "TCSlib") "Cryptography") "NumberTheory") "spStep"), "TCSlib.Cryptography.NumberTheory.Primality", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=4 requested={reqs.size} active={active} already={already}"
-- CP2 END SEAL


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Concrete lemmas for the factoring-based candidates

The concrete-layer content of the reductions of [PS10, §2.3–§2.4, §2.7] (Theorems 33.5,
36.3, 51.1), stated as exact inequalities at one security parameter in the style of
[Gar26] and consumed by `TCSlib.Cryptography.Candidates.Factoring`:

* *conditioning* (lemma C1 of the chapter 2 inventory): the probability of an event on the
  uniform subtype `{a // E a}` is `Pr[E ∧ S] / Pr[E]`, and is at least
  `1 - (1 - Pr[S]) / δ` when `Pr[E] ≥ δ` — the step of [PS10, Theorem 33.5] turning an
  inverter of `f_mult` on uniform pairs into a factorer on uniform *prime* pairs;
* the *diagonal*: a uniform pair of elements of a finite type coincides with probability
  `1 / |γ|` (the switch from `Π_n × Π_n` to pairs of distinct primes);
* *random-position planting with a good set* (lemma C3): the one-call reduction of
  [PS10, Algorithm 37.4] (plant the challenge at a uniform position of a fresh tuple,
  `OneWay.yaoTry`) inverts `f` on a uniform *good* input with probability at least
  `(μ - (1 - Pr[G])^m) / m`, `μ` the success of the inverter of the direct product
  `prodFun f m` — the mirror of `OneWay.invProb_prodFun_le` [Gar26, Theorem 2.1] with the
  bad set replaced by the complement of the good set;
* the *tail bound* `(1 - 1/a)^{a k} ≤ e^{-k}` (lemma C8) and its instance
  `(1 - 1/(4n²))^{4n³} ≤ e^{-n}` [PS10, Claim 36.2], with `e^{-n} ≤ 2^{-n}`;
* the *prime-pair density* on `n`-bit strings and the identification of the uniform subtype
  of prime pairs with `Π_n × Π_n` (`primesPairEquiv`);
* the type `DistinctPrimes n` of pairs of distinct primes of `Π_n` (the restriction `p ≠ q`
  of the decision log "Rabin/RSA scope") with its string encoding, its `NeZero`/`Fact`
  instances and `Φ(pq) = (p−1)(q−1)` (moved here from `RSA.lean`, run-3 audit P7-6);
* *block rejection sampling* on coin lists (`rejectBlocksL`, run-3 audit P7-6): the one
  sampler behind the honest samplers of `Z_N^*`, `Z*_{Φ(N)}` and the restricted prime classes
  of [PS10, §2.9–§2.12], with its closeness lemma `statClose_rejectBlocksL` (lemma C4 on
  coin lists).

## Main definitions

* `TCSlib.Cryptography.Candidates.primesPairEquiv` — prime pairs of `n`-bit strings as
  `Π_n × Π_n`.
* `TCSlib.Cryptography.Candidates.DistinctPrimes` — pairs of distinct primes of `Π_n` (the
  index distribution of the factoring assumption and of the RSA/Rabin moduli), with
  `DistinctPrimes.default`, `encodeDistinctPrimes`, `decodeDistinctPrimes`.
* `TCSlib.Cryptography.Candidates.rejectBlocksL` — block rejection sampling on a coin list.

## Main results

* `TCSlib.Cryptography.Candidates.uprob_and_eq_mul_subtype`,
  `TCSlib.Cryptography.Candidates.one_sub_div_le_uprob_subtype` (C1),
  `TCSlib.Cryptography.Candidates.uprob_le_uprob_subtype_add`,
  `TCSlib.Cryptography.Candidates.uprob_subtype_prod_eq` — conditioning on an event.
* `TCSlib.Cryptography.Candidates.uprob_diag` — the diagonal of a uniform pair.
* `TCSlib.Cryptography.Candidates.invProb_prodFun_le_plant` (C3) — random-position
  planting with a good set [PS10, Algorithm 37.4, Theorem 36.3].
* `TCSlib.Cryptography.Candidates.one_sub_one_div_pow_le_exp_neg` (C8),
  `TCSlib.Cryptography.Candidates.claim_36_2` [PS10, Claim 36.2],
  `TCSlib.Cryptography.Candidates.exp_neg_le_half_pow`.
* `TCSlib.Cryptography.Candidates.one_div_le_uprob_prime_pair_bits`,
  `TCSlib.Cryptography.Candidates.one_div_card_primes_le` — density facts in the forms
  the reductions use.
* `TCSlib.Cryptography.Candidates.decodeDistinctPrimes_encode`,
  `TCSlib.Cryptography.Candidates.DistinctPrimes.isEmpty_of_lt` — the encoding of distinct
  prime pairs is lossless; `Π_n` has no two distinct primes for `n < 2`.
* `TCSlib.Cryptography.Candidates.DistinctPrimes.totient_mul`,
  `TCSlib.Cryptography.Candidates.DistinctPrimes.one_lt_totient` — `Φ(pq) = (p−1)(q−1) ≥ 2`.
* `TCSlib.Cryptography.Candidates.rejectBlocksL_spec`,
  `TCSlib.Cryptography.Candidates.statClose_rejectBlocksL` — accepted values satisfy the
  test; the total sampler is within `(1 − Pr[E])^T` of uniform on `E`.
* `TCSlib.Cryptography.Candidates.rejectBlocksL_eq_find?` — block rejection sampling as a
  search followed by the value read.
* `TCSlib.Cryptography.Candidates.polyTimeComputable_rejectBlocksL` — block rejection sampling
  is polynomial-time via the shared block-rejection host H15.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§2.3.1–§2.3.2, Theorem 33.5, Algorithm 33.6; §2.4.2, Claim 36.2, Theorem 36.3,
  Algorithm 37.4; §2.7, Theorem 51.1; Theorems 52.3, 53.2, 61.7 and 63.10, the samplers of
  block rejection sampling.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §2.3 (Theorem 2.1 and Figure 2.2: planting at a uniform
  position).
-/

namespace TCSlib.Cryptography.Candidates

open Complexity Turing Finset TCSlib.Cryptography.OneWay NumberTheory

/-! ## Conditioning on an event (lemma C1) -/

section Conditioning

variable {α ρ : Type*} [Fintype α] [Fintype ρ]

/-- **Conditioning, multiplicative form**: `Pr[E ∧ S] = Pr[E] · Pr[S | E]`, where `Pr[S | E]`
is the probability of `S` under the uniform distribution on the subtype `{a // E a}`
(lemma C1 of the chapter 2 inventory, [PS10, proof of Theorem 33.5]: "`A'` feeds `A` a
uniformly distributed input … and replaces `xy` with `z` if both are prime"). -/
theorem uprob_and_eq_mul_subtype (E S : α → Prop) [DecidablePred E] :
    uprob (fun a => E a ∧ S a) = uprob E * uprob (fun z : {a // E a} => S z.1) := by
  simp only [uprob_def]
  rw [← Nat.card_congr (Equiv.subtypeSubtypeEquivSubtypeInter E S)]
  rcases (Fintype.card {a // E a}).eq_zero_or_pos with h0 | hpos
  · haveI : IsEmpty {a // E a} := Fintype.card_eq_zero_iff.mp h0
    have h1 : Nat.card {z : {a // E a} // S z.1} = 0 := Nat.card_of_isEmpty
    have h2 : Nat.card {a // E a} = 0 := Nat.card_of_isEmpty
    rw [h1, h2]
    simp
  · rw [Nat.card_eq_fintype_card (α := {a // E a})]
    have hc : (Fintype.card {a // E a} : ℝ) ≠ 0 := by exact_mod_cast hpos.ne'
    field_simp

/-- **Conditioning, lower bound** (lemma C1, [PS10, proof of Theorem 33.5, the union
bound]): if `Pr[E] ≥ δ > 0` then `Pr[S | E] ≥ 1 - (1 - Pr[S]) / δ`. With `Pr[E] ≥ 1/(4n²)`
and `1 - Pr[S] ≤ 1/(8(n+1)²)` this gives `Pr[S | E] ≥ 1/2`.

**Proof sketch.** `Pr[S] ≤ Pr[E ∧ S] + Pr[¬E] = Pr[E]·Pr[S | E] + 1 - Pr[E]`, so
`Pr[E]·(1 - Pr[S | E]) ≤ 1 - Pr[S]`; divide by `Pr[E] ≥ δ`. -/
theorem one_sub_div_le_uprob_subtype (E S : α → Prop) [DecidablePred E] {δ : ℝ} (hδ : 0 < δ)
    (hE : δ ≤ uprob E) : 1 - (1 - uprob S) / δ ≤ uprob (fun z : {a // E a} => S z.1) := by
  haveI : Nonempty α := by
    by_contra h
    rw [not_nonempty_iff] at h
    have h0 : uprob E = 0 := by
      rw [uprob_def]
      simp
    linarith
  have hES := uprob_and_eq_mul_subtype E S
  have hsplit : uprob S ≤ uprob (fun a => E a ∧ S a) + uprob (fun a => ¬ E a) := by
    refine (uprob_mono ?_).trans (uprob_or_le _ _)
    intro a ha
    by_cases hEa : E a
    · exact Or.inl ⟨hEa, ha⟩
    · exact Or.inr hEa
  rw [uprob_not, hES] at hsplit
  have hEpos : 0 < uprob E := lt_of_lt_of_le hδ hE
  have h1 : 1 - uprob (fun z : {a // E a} => S z.1) ≤ (1 - uprob S) / uprob E := by
    rw [le_div_iff₀ hEpos]
    nlinarith
  have h2 : (1 - uprob S) / uprob E ≤ (1 - uprob S) / δ :=
    div_le_div_of_nonneg_left (by linarith [uprob_le_one S]) hδ hE
  linarith

/-- **Dropping a conditioning**: `Pr[S] ≤ Pr[S | E] + Pr[¬E]` (the switch from the uniform
pair of primes `Π_n × Π_n` to the uniform pair of *distinct* primes, whose complement — the
diagonal — has probability `1/|Π_n|`). -/
theorem uprob_le_uprob_subtype_add (E S : α → Prop) [DecidablePred E] :
    uprob S ≤ uprob (fun z : {a // E a} => S z.1) + uprob (fun a => ¬ E a) := by
  have hES := uprob_and_eq_mul_subtype E S
  have hsplit : uprob S ≤ uprob (fun a => E a ∧ S a) + uprob (fun a => ¬ E a) := by
    refine (uprob_mono ?_).trans (uprob_or_le _ _)
    intro a ha
    by_cases hEa : E a
    · exact Or.inl ⟨hEa, ha⟩
    · exact Or.inr hEa
  have h1 : uprob (fun a => E a ∧ S a) ≤ uprob (fun z : {a // E a} => S z.1) := by
    rw [hES]
    exact mul_le_of_le_one_left (uprob_nonneg _) (uprob_le_one _)
  linarith

/-- Conditioning on the first coordinate of a product: the uniform subtype `{a // E a}` with
independent auxiliary coins `ρ` is the uniform subtype of pairs whose first coordinate
satisfies `E` (relabelling by `Equiv.prodSubtypeFstEquivSubtypeProd`). -/
theorem uprob_subtype_prod_eq (E : α → Prop) [DecidablePred E] (S : α × ρ → Prop) :
    uprob (fun z : {a // E a} × ρ => S (z.1.1, z.2)) =
      uprob (fun z : {w : α × ρ // E w.1} => S z.1) :=
  uprob_comp_equiv (Equiv.prodSubtypeFstEquivSubtypeProd (p := E)).symm fun z => S z.1

/-- **The diagonal**: a uniform pair of elements of a nonempty finite type consists of equal
elements with probability `1 / |γ|`. -/
theorem uprob_diag {γ : Type*} [Fintype γ] [DecidableEq γ] [Nonempty γ] :
    uprob (fun z : γ × γ => z.2 = z.1) = 1 / Fintype.card γ := by
  rw [uprob_prod]
  simp only [uprob_eq_one_div_card]
  exact uexp_const _

end Conditioning

/-! ## Random-position planting with a good set (lemma C3) -/

section Planting

variable {α β ρ : Type*} [Fintype α] [Fintype ρ] {m : ℕ}

/-- **Random-position planting with a good set** (lemma C3 of the chapter 2 inventory; the
concrete content of [PS10, Theorem 36.3] with the one-call reduction of
[PS10, Algorithm 37.4] planting the challenge at a *uniform* position): if `B` inverts the
direct product `prodFun f m` with probability `μ`, then either every coordinate of the
uniform tuple is outside the good set `G` (probability `(1 - Pr[G])^m`) or the one-call
reduction `yaoTry f B` (plant `f x` at the uniform position `i` of a fresh tuple, call `B`,
return the `i`-th answer) inverts `f(x)` for a uniform `x` lying in `G`:
`μ ≤ (1 - Pr[G])^m + m · Pr_{x, i, xs, r}[x ∈ G ∧ f(yaoTry f B (f x) (i, xs, r)) = f x]`.
Mirror of `OneWay.invProb_prodFun_le` [Gar26, Theorem 2.1] with the bad set replaced by
`¬G`.

**Deviation:** [PS10, Algorithm 37.4] plants at the first prime pair and tests primality;
planting at a uniform position needs no primality test (the text's exercise, p. 37).

**Proof sketch.** Success of `B` on `(xs, r)` means that every `xs i` is outside `G` or that
some position `i` has `xs i ∈ G` and the `i`-th answer inverts `f (xs i)`
(`uprob_mono`, `uprob_or_le`, `uprob_exists_le`). The first event has probability
`(1 - Pr[G])^m` (`uprob_fst`, `OneWay.uprob_pi_forall`, `uprob_not`). For fixed `i`, planting
a fresh uniform `x` at position `i` leaves the tuple uniform (`OneWay.uprob_update`,
`OneWay.prodFun_update`), which rewrites the `i`-th event as the planted experiment; summing
over `i` makes the position uniform (`OneWay.sum_uprob_eq_card_mul`), and a relabelling of
the coin space finishes. -/
theorem invProb_prodFun_le_plant [Nonempty α] [Nonempty ρ] (f : α → β)
    (B : (Fin m → β) → ρ → (Fin m → α)) (G : α → Prop) :
    invProb (prodFun f m) B ≤ (1 - uprob G) ^ m +
      m * uprob (fun z : α × (Fin m × ((Fin m → α) × ρ)) =>
        G z.1 ∧ f (yaoTry f B (f z.1) z.2) = f z.1) := by
  classical
  rw [invProb_def]
  calc uprob (fun z : (Fin m → α) × ρ =>
        prodFun f m (B (prodFun f m z.1) z.2) = prodFun f m z.1)
      ≤ uprob (fun z : (Fin m → α) × ρ => (∀ i, ¬ G (z.1 i)) ∨
          ∃ i ∈ (univ : Finset (Fin m)),
            G (z.1 i) ∧ f (B (prodFun f m z.1) z.2 i) = f (z.1 i)) := by
        apply uprob_mono
        rintro ⟨xs, r⟩ h
        by_cases hall : ∀ i, ¬ G (xs i)
        · exact Or.inl hall
        · push_neg at hall
          obtain ⟨i, hi⟩ := hall
          have hfi := congrFun h i
          rw [OneWay.prodFun_apply, OneWay.prodFun_apply] at hfi
          exact Or.inr ⟨i, mem_univ _, hi, hfi⟩
    _ ≤ uprob (fun z : (Fin m → α) × ρ => ∀ i, ¬ G (z.1 i)) +
          ∑ i, uprob (fun z : (Fin m → α) × ρ =>
            G (z.1 i) ∧ f (B (prodFun f m z.1) z.2 i) = f (z.1 i)) :=
        (uprob_or_le _ _).trans (add_le_add_left (uprob_exists_le _ _) _)
    _ ≤ _ := by
        apply add_le_add
        · rw [uprob_fst (fun xs : Fin m → α => ∀ i, ¬ G (xs i)),
            uprob_pi_forall (ι := Fin m) (fun x => ¬ G x), uprob_not, Fintype.card_fin]
        · have hplant : ∀ i, uprob (fun z : (Fin m → α) × ρ =>
              G (z.1 i) ∧ f (B (prodFun f m z.1) z.2 i) = f (z.1 i)) =
              uprob (fun z : α × ((Fin m → α) × ρ) =>
                G z.1 ∧ f (yaoTry f B (f z.1) (i, z.2)) = f z.1) := by
            intro i
            rw [← uprob_update i (fun xs r =>
              G (xs i) ∧ f (B (prodFun f m xs) r i) = f (xs i))]
            apply uprob_congr
            rintro ⟨x, xs, r⟩
            simp [yaoTry_eq, prodFun_update]
          simp only [hplant]
          rw [sum_uprob_eq_card_mul, Fintype.card_fin]
          let e : α × (Fin m × ((Fin m → α) × ρ)) ≃ Fin m × (α × ((Fin m → α) × ρ)) :=
            { toFun := fun z => (z.2.1, (z.1, z.2.2))
              invFun := fun z => (z.2.1, (z.1, z.2.2))
              left_inv := fun _ => rfl
              right_inv := fun _ => rfl }
          rw [← uprob_comp_equiv e]
          exact le_rfl

end Planting

/-! ## Tail bounds (lemma C8, Claim 36.2) -/

/-- **Tail bound** (lemma C8 of the chapter 2 inventory): `(1 - 1/a)^{a·k} ≤ e^{-k}` for
`a ≥ 1` (the inequality `1 - t ≤ e^{-t}` raised to the power `a·k`,
`Real.one_sub_div_pow_le_exp_neg`). -/
theorem one_sub_one_div_pow_le_exp_neg (a k : ℕ) (ha : 0 < a) :
    (1 - 1 / (a : ℝ)) ^ (a * k) ≤ Real.exp (-(k : ℝ)) := by
  rcases Nat.eq_zero_or_pos k with rfl | hk
  · simp
  have h := Real.one_sub_div_pow_le_exp_neg (n := a * k) (t := (k : ℝ))
    (by push_cast; nlinarith [(by exact_mod_cast ha : (1 : ℝ) ≤ a), (by exact_mod_cast hk : (0 : ℝ) < k)])
  have heq : (1 - (k : ℝ) / ((a * k : ℕ) : ℝ)) = 1 - 1 / (a : ℝ) := by
    have hk' : (k : ℝ) ≠ 0 := by exact_mod_cast hk.ne'
    have ha' : (a : ℝ) ≠ 0 := by exact_mod_cast ha.ne'
    push_cast
    field_simp
  rw [heq] at h
  exact h

/-- **Claim 36.2** [PS10, (36.2)]: `(1 - 1/(4n²))^{4n³} = ((1 - 1/(4n²))^{4n²})^n ≤ e^{-n}`:
with `4n³` pairs of random `n`-bit numbers, the probability that none of them is a pair of
primes is at most `e^{-n}` (given the density `1/(4n²)` of prime pairs). -/
theorem claim_36_2 (n : ℕ) (hn : 0 < n) :
    (1 - 1 / (4 * (n : ℝ) ^ 2)) ^ (4 * n ^ 3) ≤ Real.exp (-(n : ℝ)) := by
  have h := one_sub_one_div_pow_le_exp_neg (4 * n ^ 2) n (by positivity)
  have hexp : 4 * n ^ 2 * n = 4 * n ^ 3 := by ring
  rw [hexp] at h
  push_cast at h
  exact h

/-- `e^{-n} ≤ (1/2)^n` (the negligible form of the tail bounds, `negligible_two_pow_neg`). -/
theorem exp_neg_le_half_pow (n : ℕ) : Real.exp (-(n : ℝ)) ≤ (1 / 2 : ℝ) ^ n := by
  have h1 : Real.exp (-(n : ℝ)) = Real.exp (-1) ^ n := by
    rw [← Real.exp_nat_mul]; congr 1; ring
  rw [h1]
  apply pow_le_pow_left₀ (Real.exp_pos _).le
  rw [Real.exp_neg]
  have := Real.add_one_le_exp (1 : ℝ)
  rw [inv_eq_one_div, div_le_div_iff₀ (Real.exp_pos 1) (by norm_num)]
  linarith

/-- **Claim 36.2, negligible form**: `(1 - 1/(4n²))^{4n³} ≤ 2^{-n}`. -/
theorem claim_36_2_half_pow (n : ℕ) (hn : 0 < n) :
    (1 - 1 / (4 * (n : ℝ) ^ 2)) ^ (4 * n ^ 3) ≤ (1 / 2 : ℝ) ^ n :=
  (claim_36_2 n hn).trans (exp_neg_le_half_pow n)

/-! ## Prime pairs of bit strings -/

/-- **Prime-pair density on bit strings** [PS10, proof of Theorem 33.5]: for `n ≥ 2`, a
uniform pair of `n`-bit strings reads (`bitsToNat`) as a pair of primes with probability at
least `1/(4n²)` (`NumberTheory.one_div_le_uprob_prime_pair` transported along
`bitsEquiv`). -/
theorem one_div_le_uprob_prime_pair_bits (n : ℕ) (hn : 2 ≤ n) :
    1 / (4 * (n : ℝ) ^ 2) ≤
      uprob (fun z : (Fin n → Bool) × (Fin n → Bool) =>
        (bitsToNat z.1).Prime ∧ (bitsToNat z.2).Prime) := by
  have h := one_div_le_uprob_prime_pair n hn
  rw [← uprob_comp_equiv (Equiv.prodCongr (bitsEquiv n) (bitsEquiv n))] at h
  simpa using h

/-- The uniform subtype of prime pairs of `n`-bit strings is `Π_n × Π_n`: read each string as
a number (`bitsEquiv`) and split the conjunction (`Equiv.subtypeProdEquivProd`). -/
noncomputable def primesPairEquiv (n : ℕ) :
    {z : (Fin n → Bool) × (Fin n → Bool) // (bitsToNat z.1).Prime ∧ (bitsToNat z.2).Prime} ≃
      Primes n × Primes n :=
  (Equiv.subtypeEquiv (Equiv.prodCongr (bitsEquiv n) (bitsEquiv n)) (fun z => by simp)).trans
    Equiv.subtypeProdEquivProd

/-- The components of `primesPairEquiv` are the numbers read from the two strings. -/
@[simp] theorem primesPairEquiv_apply_val (n : ℕ)
    (z : {z : (Fin n → Bool) × (Fin n → Bool) // (bitsToNat z.1).Prime ∧ (bitsToNat z.2).Prime}) :
    ((primesPairEquiv n z).1.1 : ℕ) = bitsToNat z.1.1 ∧
      ((primesPairEquiv n z).2.1 : ℕ) = bitsToNat z.1.2 := by
  simp [primesPairEquiv, Equiv.subtypeProdEquivProd]

/-- `1/|Π_n| ≤ 2n/2^n` for `n ≥ 2` (`NumberTheory.two_pow_le_two_mul_card_primes`): the
probability that two independent uniform primes coincide is negligible. -/
theorem one_div_card_primes_le (n : ℕ) (hn : 2 ≤ n) :
    1 / (Fintype.card (Primes n) : ℝ) ≤ 2 * n / 2 ^ n := by
  have h := two_pow_le_two_mul_card_primes n hn
  have h' : (2 : ℝ) ^ n ≤ 2 * n * Fintype.card (Primes n) := by exact_mod_cast h
  have hpos : (0 : ℝ) < Fintype.card (Primes n) := by
    have : 0 < Fintype.card (Primes n) := by
      by_contra h0
      push_neg at h0
      have : Fintype.card (Primes n) = 0 := by omega
      rw [this, mul_zero] at h
      exact absurd h (not_le.mpr (Nat.two_pow_pos n))
    exact_mod_cast this
  rw [div_le_div_iff₀ hpos (by positivity), one_mul]
  linarith

/-! ## Pairs of distinct primes -/

/-- Pairs of **distinct** primes of `Π_n`: the index distribution of the factoring
assumption and of the RSA/Rabin moduli `N = pq` (decision log "Rabin/RSA scope": `p ≠ q`). -/
abbrev DistinctPrimes (n : ℕ) : Type := {z : Primes n × Primes n // (z.1.1 : ℕ) ≠ z.2.1}

namespace DistinctPrimes

variable {n : ℕ}

/-- The first prime `p`. -/
def p (z : DistinctPrimes n) : ℕ := z.1.1.1

/-- The defining equation of `DistinctPrimes.p`: `z.p` is the value of the first prime of the
pair, `z.p = ((z.1.1 : Fin (2^n)) : ℕ)`. -/
theorem p_eq (z : DistinctPrimes n) : z.p = ((z.1.1 : Fin (2 ^ n)) : ℕ) := rfl

/-- The second prime `q`. -/
def q (z : DistinctPrimes n) : ℕ := z.1.2.1

/-- The defining equation of `DistinctPrimes.q`: `z.q` is the value of the second prime of the
pair, `z.q = ((z.1.2 : Fin (2^n)) : ℕ)`. -/
theorem q_eq (z : DistinctPrimes n) : z.q = ((z.1.2 : Fin (2 ^ n)) : ℕ) := rfl

/-- `p` is prime. -/
theorem p_prime (z : DistinctPrimes n) : z.p.Prime := z.1.1.2

/-- `q` is prime. -/
theorem q_prime (z : DistinctPrimes n) : z.q.Prime := z.1.2.2

/-- `p < 2^n`. -/
theorem p_lt (z : DistinctPrimes n) : z.p < 2 ^ n := z.1.1.1.2

/-- `q < 2^n`. -/
theorem q_lt (z : DistinctPrimes n) : z.q < 2 ^ n := z.1.2.1.2

/-- `p ≠ q`. -/
theorem p_ne_q (z : DistinctPrimes n) : z.p ≠ z.q := z.2

/-- The modulus `N = pq < 2^{2n}`. -/
theorem mul_lt (z : DistinctPrimes n) : z.p * z.q < 2 ^ (2 * n) := by
  rw [two_mul]; exact mul_lt_two_pow_add z.p_lt z.q_lt

/-! ### Instances and the totient (moved from `RSA.lean`, run-3 audit P7-6) -/

/-- The modulus `pq` is nonzero. -/
instance neZero_mul (z : DistinctPrimes n) : NeZero (z.p * z.q) :=
  ⟨mul_ne_zero z.p_prime.ne_zero z.q_prime.ne_zero⟩

/-- `Φ(pq)` is nonzero. -/
instance neZero_totient (z : DistinctPrimes n) : NeZero (Nat.totient (z.p * z.q)) :=
  ⟨(Nat.totient_pos.2 (NeZero.pos _)).ne'⟩

/-- `p` is prime (as a `Fact`). -/
instance fact_p_prime (z : DistinctPrimes n) : Fact z.p.Prime := ⟨z.p_prime⟩

/-- `q` is prime (as a `Fact`). -/
instance fact_q_prime (z : DistinctPrimes n) : Fact z.q.Prime := ⟨z.q_prime⟩

/-- `Φ(pq) = (p−1)(q−1)` for a pair of distinct primes [PS10, p. 47]. -/
theorem totient_mul (z : DistinctPrimes n) : Nat.totient (z.p * z.q) = (z.p - 1) * (z.q - 1) :=
  totient_prime_mul_prime z.p_prime z.q_prime z.p_ne_q

/-- `Φ(pq) ≥ 2`: one of two distinct primes is at least `3`. -/
theorem one_lt_totient (z : DistinctPrimes n) : 1 < Nat.totient (z.p * z.q) := by
  rw [z.totient_mul]
  have hp := z.p_prime.two_le
  have hq := z.q_prime.two_le
  have hne := z.p_ne_q
  rcases Nat.lt_or_ge 2 z.p with h | h
  · calc 1 < 2 * 1 := by norm_num
      _ ≤ (z.p - 1) * (z.q - 1) := Nat.mul_le_mul (by omega) (by omega)
  · have h2 : z.p = 2 := by omega
    have h3 : 3 ≤ z.q := by omega
    calc 1 < 1 * 2 := by norm_num
      _ ≤ (z.p - 1) * (z.q - 1) := Nat.mul_le_mul (by omega) (by omega)

/-- A pair of distinct primes is determined by `(p, q)`. -/
theorem ext {z w : DistinctPrimes n} (hp : z.p = w.p) (hq : z.q = w.q) : z = w := by
  rcases z with ⟨⟨⟨⟨p, hp'⟩, hpp⟩, ⟨⟨q, hq'⟩, hqq⟩⟩, hne⟩
  rcases w with ⟨⟨⟨⟨p', _⟩, _⟩, ⟨⟨q', _⟩, _⟩⟩, _⟩
  simp only [DistinctPrimes.p, DistinctPrimes.q] at hp hq
  subst hp hq
  rfl

/-- `Π_n` has no two distinct primes for `n < 2`. -/
theorem isEmpty_of_lt (hn : n < 2) : IsEmpty (DistinctPrimes n) := by
  refine ⟨fun z => ?_⟩
  have h1 := z.p_prime.two_le
  have h2 := z.q_prime.two_le
  have h3 := z.p_lt
  have h4 := z.q_lt
  have h5 := z.p_ne_q
  interval_cases n <;> omega

/-- The pair `(2, 3)` for `n ≥ 2` (the default element of the collection's domain). -/
def default (hn : 2 ≤ n) : DistinctPrimes n :=
  ⟨(⟨⟨2, lt_of_lt_of_le (by norm_num) ((Nat.pow_le_pow_right (by norm_num) hn).trans_eq' rfl)⟩,
      Nat.prime_two⟩,
    ⟨⟨3, lt_of_lt_of_le (by norm_num) ((Nat.pow_le_pow_right (by norm_num) hn).trans_eq' rfl)⟩,
      Nat.prime_three⟩), (by norm_num : (2 : ℕ) ≠ 3)⟩

/-- The first prime of the default pair is `2`: `(DistinctPrimes.default hn).p = 2`. -/
theorem default_p (hn : 2 ≤ n) : (DistinctPrimes.default hn).p = 2 := rfl

/-- The second prime of the default pair is `3`: `(DistinctPrimes.default hn).q = 3`. -/
theorem default_q (hn : 2 ≤ n) : (DistinctPrimes.default hn).q = 3 := rfl

end DistinctPrimes

/-! ### Encoding pairs of distinct primes -/

/-- Decode `⟨a, b⟩` as a pair of distinct primes of `Π_m`: both components must be `m`-bit
strings (`decodeFin`) reading as distinct primes; anything else is a failure. -/
def decodeDistinctPrimes (m : ℕ) (w : List Bool) : Option (DistinctPrimes m) :=
  match decodeFin m (pairFstD w), decodeFin m (pairSndD w) with
  | some a, some b =>
    if h : (bitsToNat a).Prime ∧ (bitsToNat b).Prime ∧ bitsToNat a ≠ bitsToNat b then
      some ⟨(⟨⟨bitsToNat a, bitsToNat_lt a⟩, h.1⟩, ⟨⟨bitsToNat b, bitsToNat_lt b⟩, h.2.1⟩), h.2.2⟩
    else none
  | _, _ => none

/-- Encode a pair of distinct primes of `Π_m` as `⟨p, q⟩` with `m`-bit numerals. -/
def encodeDistinctPrimes (m : ℕ) (z : DistinctPrimes m) : List Bool :=
  pairEncode (natToList m z.p) (natToList m z.q)

/-- The defining equation of `encodeDistinctPrimes`:
`encodeDistinctPrimes m z = ⟨⟦p⟧_m, ⟦q⟧_m⟩`, the pair of the `m`-bit numerals of the two primes. -/
theorem encodeDistinctPrimes_eq (m : ℕ) (z : DistinctPrimes m) :
    encodeDistinctPrimes m z = pairEncode (natToList m z.p) (natToList m z.q) := rfl

/-- Decoding inverts encoding. -/
theorem decodeDistinctPrimes_encode (m : ℕ) (z : DistinctPrimes m) :
    decodeDistinctPrimes m (encodeDistinctPrimes m z) = some z := by
  unfold decodeDistinctPrimes encodeDistinctPrimes
  rw [natToList_eq, natToList_eq]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode, decodeFin_ofFn,
    bitsToNat_natToBits z.p_lt, bitsToNat_natToBits z.q_lt]
  rw [dif_pos ⟨z.p_prime, z.q_prime, z.p_ne_q⟩]
  congr 1

/-- **Decoding is canonical**: a string that `decodeDistinctPrimes m` decodes to `z` is
`encodeDistinctPrimes m z` (the clause `Collection.encD_decD` of the factoring collection;
gate 03b, finding 1).

**Proof sketch.** Both components decode as `m`-bit strings `a`, `b`, so they are `List.ofFn a`,
`List.ofFn b` (`ofFn_of_decodeFin_eq_some`), the numerals of `p = bitsToNat a`, `q = bitsToNat b`
at width `m` (`natToList_length_listToNat`); the first is nonempty (`Π_m` has two distinct
primes only for `m ≥ 2`, `DistinctPrimes.isEmpty_of_lt`), so the string is the pair of its
components (`eq_pairEncode_of_pairFstD_ne`). -/
theorem encodeDistinctPrimes_of_decode {m : ℕ} {w : List Bool} {z : DistinctPrimes m}
    (h : decodeDistinctPrimes m w = some z) : encodeDistinctPrimes m z = w := by
  have hm : 2 ≤ m := by
    by_contra hm
    exact (DistinctPrimes.isEmpty_of_lt (not_le.1 hm)).false z
  have hnum : ∀ a : Fin m → Bool, natToList m (bitsToNat a) = List.ofFn a := fun a => by
    have := natToList_length_listToNat (List.ofFn a)
    rwa [List.length_ofFn, ← bitsToNat_eq_listToNat] at this
  unfold decodeDistinctPrimes at h
  rcases ha : decodeFin m (pairFstD w) with _ | a <;> rcases hb : decodeFin m (pairSndD w) with _ | b <;>
    simp only [ha, hb, reduceCtorEq] at h
  split_ifs at h with hc
  obtain rfl := Option.some.inj h
  have hne : pairFstD w ≠ [] := fun h0 => by
    have := length_eq_of_decodeFin_eq_some ha
    rw [h0, List.length_nil] at this
    omega
  show pairEncode (natToList m (bitsToNat a)) (natToList m (bitsToNat b)) = w
  rw [hnum, hnum, ofFn_of_decodeFin_eq_some ha, ofFn_of_decodeFin_eq_some hb]
  exact (eq_pairEncode_of_pairFstD_ne hne).symm

/-! ## Block rejection sampling on coin lists (run-3 audit P7-6) -/

/-- **Block rejection sampling** on a coin list, the common shape of the honest samplers of
the candidates [PS10, Theorem 53.2 (`Z_N^*`, `Z*_{Φ(N)}`), Theorem 61.7, Theorem 63.10 (Blum
primes), Theorem 52.3 (`Z_q`)]: `T` trials, trial `t` reading the first `k` bits of the
`t`-th block of `B` bits of `r` as a number `v` (`listToNat`), accepted iff `E v`; `none` if
every trial is rejected. With `k ≤ B` and `r` uniform, the `T` values are independent and
uniform below `2^k`, so the output is `firstHit E` on `Fin (2^k)` (`statClose_rejectBlocksL`).
Repair (run-3 audit P7-6): the one sampler behind `sampleUnitL` (RSA, Rabin) and
`samplePrimePL` (Rabin); `sampleBelowL` (discrete log) has the same shape. -/
def rejectBlocksL (E : ℕ → Prop) [DecidablePred E] (k B T : ℕ) (r : List Bool) : Option ℕ :=
  (List.range T).findSome? fun t =>
    if E (listToNat ((r.drop (t * B)).take k)) then some (listToNat ((r.drop (t * B)).take k))
    else none

/-- Block rejection sampling unfolded: `rejectBlocksL E k B T r` is the first `some v` over
`t ∈ [0, T)` (`List.findSome?` over `List.range T`) with `v` the number read from the first `k`
bits of the `t`-th block of `B` bits of `r`, kept iff `E v`. -/
theorem rejectBlocksL_eq (E : ℕ → Prop) [DecidablePred E] (k B T : ℕ) (r : List Bool) :
    rejectBlocksL E k B T r = (List.range T).findSome? fun t =>
      if E (listToNat ((r.drop (t * B)).take k)) then some (listToNat ((r.drop (t * B)).take k))
      else none :=
  rfl

/-- **Block rejection sampling as a search followed by the value read**: `rejectBlocksL E k B T r`
is the first trial `t < T` whose value `v_t = ⟦(r.drop (t B)).take k⟧` passes `E`, mapped to
`v_t`:
`rejectBlocksL E k B T r = ((List.range T).find? fun t => decide (E v_t)).map fun t => v_t`
(core `List.findSome?_guard`, `List.map_findSome?`, `Option.guard_apply`). -/
theorem rejectBlocksL_eq_find? (E : ℕ → Prop) [DecidablePred E] (k B T : ℕ) (r : List Bool) :
    rejectBlocksL E k B T r =
      ((List.range T).find? fun t => decide (E (listToNat ((r.drop (t * B)).take k)))).map
        fun t => listToNat ((r.drop (t * B)).take k) := by
  rw [rejectBlocksL_eq, ← List.findSome?_guard, List.map_findSome?]
  congr 1
  funext t
  rw [Function.comp_apply, Option.guard_apply]
  by_cases ht : E (listToNat ((r.drop (t * B)).take k))
  · rw [if_pos ht, decide_eq_true ht, if_pos rfl, Option.map_some]
  · rw [if_neg ht, decide_eq_false ht, if_neg Bool.false_ne_true, Option.map_none]

/-- An accepted value satisfies the test and is below `2^k` (it is read from at most `k`
bits, `listToNat_lt_two_pow`). -/
theorem rejectBlocksL_spec {E : ℕ → Prop} [DecidablePred E] {k B T : ℕ} {r : List Bool} {v : ℕ}
    (h : rejectBlocksL E k B T r = some v) : E v ∧ v < 2 ^ k := by
  unfold rejectBlocksL at h
  rw [List.findSome?_eq_some_iff] at h
  obtain ⟨_, t, _, _, ht, _⟩ := h
  split_ifs at ht with hc
  rw [Option.some.injEq] at ht
  subst ht
  refine ⟨hc, lt_of_lt_of_le (listToNat_lt_two_pow _) ?_⟩
  exact Nat.pow_le_pow_right (by norm_num) (List.length_take_le _ _)

/-! ### The trial loop behind `polyTimeComputable_rejectBlocksL` (private)

The state is `⟨⟨⟨bw, kw⟩, par⟩, ⟨counter, coins⟩⟩`: the header carries the block length `|bw|`,
the trial width `|kw|` and the parameter word `par`; the counter carries the remaining trials.
Harvested from the Rabin fill's private block loop, with the parameter word added to the header
and the test applied to `⟨par, trial word⟩`. -/

/-- One trial: keep the header, drop one counter bit and one block of `|bw|` coins. -/
private def rbl_step (x : List Bool) : List Bool :=
  pairEncode (pairFstD x)
    (pairEncode ((pairFstD (pairSndD x)).drop 1)
      ((pairSndD (pairSndD x)).drop (pairFstD (pairFstD (pairFstD x))).length))

/-- The current trial word: the first `|kw|` remaining coins. -/
private def rbl_block (x : List Bool) : List Bool :=
  (pairSndD (pairSndD x)).take (pairSndD (pairFstD (pairFstD x))).length

/-- The acceptance test: the counter is nonempty and `acc` accepts `⟨par, trial word⟩`. -/
private def rbl_acc (acc : List Bool → Bool) (x : List Bool) : Bool :=
  !(decide (pairFstD (pairSndD x) = [])) && acc (pairEncode (pairSndD (pairFstD x)) (rbl_block x))

/-- The payload of an accepted state: a `true` marker, then the trial word. -/
private def rbl_out (x : List Bool) : List Bool := [true] ++ rbl_block x

/-- The loop: the payload of the first accepted state among the first `|x| + 1` states of the
orbit, `[]` if none (the function of `polyTimeComputable_iterateFind`, its `match` written as
`Option.elim`). -/
private def rbl_loop (acc : List Bool → Bool) (x : List Bool) : List Bool :=
  ((List.range (x.length + 1)).find? (fun i => rbl_acc acc (rbl_step^[i] x))).elim []
    (fun i => rbl_out (rbl_step^[i] x))

/-- The step is polynomial-time (`polyTimeComputable_tail`, `polyTimeComputable_pairDropPoly`). -/
private theorem rbl_step_poly : PolyTimeComputable rbl_step := by
  have h := polyTimeComputable_pairFstD.pairEncode
    ((polyTimeComputable_tail.comp
      (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD)).pairEncode
      ((polyTimeComputable_pairDropPoly .var).comp
        ((polyTimeComputable_pairFstD.comp
          (polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD)).pairEncode
          (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD))))
  refine h.congr fun x => ?_
  simp only [rbl_step, Function.comp_apply, pairFstD_pairEncode, pairSndD_pairEncode,
    PolyExpr.eval_var]

/-- The trial word is polynomial-time (`polyTimeComputable_pairTakePoly`). -/
private theorem rbl_block_poly : PolyTimeComputable rbl_block := by
  have h := (polyTimeComputable_pairTakePoly .var).comp
    ((polyTimeComputable_pairSndD.comp
      (polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD)).pairEncode
      (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD))
  refine h.congr fun x => ?_
  simp only [rbl_block, Function.comp_apply, pairFstD_pairEncode, pairSndD_pairEncode,
    PolyExpr.eval_var]

/-- The test is polynomial-time (`polyTimeComputable_isNil`, `_not`, `_and`, the given `acc`). -/
private theorem rbl_acc_poly {acc : List Bool → Bool} (hacc : PolyTimeComputable fun x => [acc x]) :
    PolyTimeComputable fun x => [rbl_acc acc x] := by
  have t1 : PolyTimeComputable fun x => [decide (pairFstD (pairSndD x) = [])] :=
    PolyTimeComputable.comp' polyTimeComputable_isNil
      (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD)
  have t1' : PolyTimeComputable fun x => [!decide (pairFstD (pairSndD x) = [])] :=
    polyTimeComputable_not (p := fun x => decide (pairFstD (pairSndD x) = [])) t1
  have t2 : PolyTimeComputable fun x => [acc (pairEncode (pairSndD (pairFstD x)) (rbl_block x))] :=
    PolyTimeComputable.comp' hacc
      ((polyTimeComputable_pairSndD.comp polyTimeComputable_pairFstD).pairEncode rbl_block_poly)
  exact polyTimeComputable_and (p := fun x => !decide (pairFstD (pairSndD x) = []))
    (q := fun x => acc (pairEncode (pairSndD (pairFstD x)) (rbl_block x))) t1' t2

/-- The payload is polynomial-time (`polyTimeComputable_prepend`). -/
private theorem rbl_out_poly : PolyTimeComputable rbl_out :=
  (polyTimeComputable_prepend [true]).comp rbl_block_poly

/-- The orbit: after `i` trials the state is `⟨h, ⟨c.drop i, s.drop (i · |fst (fst h)|)⟩⟩`. -/
private theorem rbl_step_iterate (h c s : List Bool) (i : ℕ) :
    rbl_step^[i] (pairEncode h (pairEncode c s)) =
      pairEncode h (pairEncode (c.drop i) (s.drop (i * (pairFstD (pairFstD h)).length))) := by
  induction i with
  | zero => rw [Function.iterate_zero_apply, List.drop_zero, Nat.zero_mul, List.drop_zero]
  | succ i ih =>
    rw [Function.iterate_succ_apply', ih]
    simp only [rbl_step, pairFstD_pairEncode, pairSndD_pairEncode, List.drop_drop]
    rw [Nat.succ_mul]

/-- One step at most doubles the length: `|step x| ≤ 2|x| + 4`. -/
private theorem rbl_length_step_le (x : List Bool) : (rbl_step x).length ≤ 2 * x.length + 4 := by
  have h1 := StateLoop.length_pairFstD_add_pairSndD_le x
  have h2 := StateLoop.length_pairFstD_add_pairSndD_le (pairSndD x)
  simp only [rbl_step, length_pairEncode, List.length_drop]
  omega

/-- From the first step on the state is a well-formed word, which only shrinks. -/
private theorem rbl_length_step_step_le (x : List Bool) :
    (rbl_step (rbl_step x)).length ≤ (rbl_step x).length := by
  simp only [rbl_step, pairFstD_pairEncode, pairSndD_pairEncode, length_pairEncode,
    List.length_drop]
  omega

/-- The orbit bound `|step^[i] x| ≤ 2|x| + 4` demanded by the repetition host. -/
private theorem rbl_length_step_iterate_le (x : List Bool) (i : ℕ) :
    (rbl_step^[i] x).length ≤ 2 * x.length + 4 := by
  cases i with
  | zero => rw [Function.iterate_zero_apply]; omega
  | succ i =>
    induction i with
    | zero => exact rbl_length_step_le x
    | succ i ih =>
      rw [Function.iterate_succ_apply'] at ih ⊢
      rw [Function.iterate_succ_apply']
      exact (rbl_length_step_step_le _).trans ih

/-- The loop is polynomial-time: an instance of the repetition host
`polyTimeComputable_iterateFind` (`R = var`, orbit bound `2|x| + 4`), its `match` read by
`split` (its equation lemmas), never by unfolding the matcher. -/
private theorem rbl_loop_poly {acc : List Bool → Bool}
    (hacc : PolyTimeComputable fun x => [acc x]) : PolyTimeComputable (rbl_loop acc) := by
  have hF := polyTimeComputable_iterateFind rbl_step_poly (rbl_acc_poly hacc) rbl_out_poly
    PolyExpr.var (PolyExpr.add (.mul (.const 2) .var) (.const 4)) (fun x i _ => by
      rw [PolyExpr.eval_add, PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var,
        PolyExpr.eval_const]
      exact rbl_length_step_iterate_le x i)
  refine hF.congr fun x => ?_
  rw [rbl_loop, PolyExpr.eval_var]
  split
  · next i h => rw [h, Option.elim_some]
  · next h => rw [h, Option.elim_none]

/-- **The loop computes `rejectBlocksL`**: on the start state `⟨⟨⟨bw, kw⟩, par⟩, ⟨tw, c⟩⟩`, the
loop is `[]` when `rejectBlocksL (E ⟦par⟧) |kw| |bw| |tw| c` is `none`, and otherwise a nonempty
word whose tail reads as the accepted value and has at most `|kw|` bits.

**Proof sketch.** After `i` steps the state is `⟨h, ⟨tw.drop i, c.drop (i |bw|)⟩⟩`
(`rbl_step_iterate`), so trial `i` reads `v_i = ⟦(c.drop (i |bw|)).take |kw|⟧` and the test is
`i < |tw| ∧ E ⟦par⟧ v_i` (`hspec`). The search over `[0, |x| + 1) ⊇ [0, |tw|)` is the search over
`[0, |tw|)` (`IterateFind.find?_range_and_lt`), which is `rejectBlocksL` read as a search
followed by the value (`rejectBlocksL_eq_find?`); the accepted payload is `true :: trial word`
(`List.length_take_le`). -/
private theorem rbl_loop_spec (E : ℕ → ℕ → Prop) [∀ a, DecidablePred (E a)]
    {acc : List Bool → Bool}
    (hspec : ∀ w b : List Bool, acc (pairEncode w b) = decide (E (listToNat w) (listToNat b)))
    (par kw bw tw c : List Bool) :
    (rbl_loop acc (pairEncode (pairEncode (pairEncode bw kw) par) (pairEncode tw c))).tail.length ≤
        kw.length ∧
      rejectBlocksL (E (listToNat par)) kw.length bw.length tw.length c =
        if rbl_loop acc (pairEncode (pairEncode (pairEncode bw kw) par) (pairEncode tw c)) = []
        then none
        else some (listToNat (rbl_loop acc
          (pairEncode (pairEncode (pairEncode bw kw) par) (pairEncode tw c))).tail) := by
  set x0 := pairEncode (pairEncode (pairEncode bw kw) par) (pairEncode tw c) with hx0
  have hblock : ∀ i, rbl_block (rbl_step^[i] x0) = (c.drop (i * bw.length)).take kw.length := by
    intro i
    rw [hx0, rbl_step_iterate]
    simp only [rbl_block, pairFstD_pairEncode, pairSndD_pairEncode]
  have hacc : ∀ i, rbl_acc acc (rbl_step^[i] x0) = (decide (i < tw.length) &&
      decide (E (listToNat par) (listToNat ((c.drop (i * bw.length)).take kw.length)))) := by
    intro i
    rw [rbl_acc, hblock, hspec, hx0, rbl_step_iterate]
    simp only [pairFstD_pairEncode, pairSndD_pairEncode, List.drop_eq_nil_iff]
    by_cases h1 : i < tw.length
    · rw [decide_eq_false (by omega), decide_eq_true h1]
      rfl
    · rw [decide_eq_true (by omega), decide_eq_false h1]
      rfl
  have hrange : tw.length ≤ x0.length + 1 := by
    simp only [hx0, length_pairEncode]
    omega
  have hfind : (List.range (x0.length + 1)).find? (fun i => rbl_acc acc (rbl_step^[i] x0)) =
      (List.range tw.length).find? (fun i =>
        decide (E (listToNat par) (listToNat ((c.drop (i * bw.length)).take kw.length)))) := by
    rw [show (fun i => rbl_acc acc (rbl_step^[i] x0)) = _ from funext hacc]
    exact IterateFind.find?_range_and_lt _ hrange
  rw [rejectBlocksL_eq_find?, rbl_loop, hfind]
  rcases (List.range tw.length).find?
      (fun i => decide (E (listToNat par) (listToNat ((c.drop (i * bw.length)).take kw.length))))
    with _ | i
  · rw [Option.elim_none, Option.map_none, if_pos rfl, List.tail_nil, List.length_nil]
    exact ⟨Nat.zero_le _, rfl⟩
  · rw [Option.elim_some, Option.map_some, rbl_out, hblock, List.singleton_append,
      if_neg (List.cons_ne_nil _ _), List.tail_cons]
    exact ⟨List.length_take_le _ _, rfl⟩

/-- **Block rejection sampling is polynomial-time** (host H15) [PS10, Theorems 52.3, 53.2, 61.7
and 63.10: "the domain is easy to sample"]. Let `E a v` be a test on a parameter `a` and a value
`v`, decided on words by a polynomial-time bit `acc`, so that `acc ⟨w, b⟩ = [E ⟦w⟧ ⟦b⟧]`. Take
polynomial-time words `par z` (the parameter), `kw z`, `bw z` and `tw z`, whose lengths are the
trial width `k`, the block length `B` and the trial count `T`, and `c z` (the coins). Then some
polynomial-time `g` computes the sampler `rejectBlocksL (E ⟦par z⟧) k B T (c z)`:
- `g z = []` when every trial is rejected;
- otherwise `g z` is nonempty, and its tail reads as the accepted value and has at most `k` bits.

That is, `(g z).tail.length ≤ k` and
`rejectBlocksL (E ⟦par z⟧) k B T (c z) = if g z = [] then none else some ⟦(g z).tail⟧`.
In particular `(rejectBlocksL …).getD 0 = ⟦(g z).tail⟧`, since `[].tail = []` reads as `0`
(`listToNat_nil`). The statement is existential: the trial loop that realizes it is internal,
and no consumer reads it.

**Deviation:** [PS10] samples these domains exactly, in expected polynomial time; here the
sampler is truncated to `T` trials (deviations register #15, `statClose_rejectBlocksL` carries
the statistical term), and the host states only the polynomial-time computability of that
truncated sampler on strings.

**Proof sketch.**
- **The loop.** The state is `⟨⟨⟨1^B, 1^k⟩, w⟩, ⟨1^T, r⟩⟩`, with `w = par z` and `r = c z`. One
  step keeps the header `⟨⟨1^B, 1^k⟩, w⟩`, drops one bit of the counter `1^T` and one block of
  `B` coins (`polyTimeComputable_tail`, `polyTimeComputable_pairDropPoly`). The trial word is
  the first `k` coins (`polyTimeComputable_pairTakePoly`). The test accepts iff the counter is
  nonempty and `acc ⟨w, trial word⟩` holds (`polyTimeComputable_isNil`, `polyTimeComputable_not`,
  `polyTimeComputable_and`, with the tests given explicitly). The payload is `true` followed by
  the trial word (`polyTimeComputable_prepend`). The start state is assembled from the given
  words (`polyTimeComputable_unaryPoly`, or `List.replicate` of the lengths, and
  `PolyTimeComputable.pairEncode`), and `g` is the loop on it, in applied form
  (`PolyTimeComputable.comp'`).
- **Polynomial time.** One step at most doubles the length (`|step x| ≤ 2|x| + 4`), and from the
  second step on the state is a well-formed pair that only shrinks
  (`StateLoop.length_pairFstD_add_pairSndD_le`), so every orbit point has length at most
  `2|x| + 4`. The repetition host `Complexity.polyTimeComputable_iterateFind`, with `R = var` and
  orbit bound `2n + 4`, therefore makes the loop polynomial-time. Its `match` on the search
  result is split by `split` (its equation lemmas), never matched by definitional unfolding.
- **Correctness.** After `i` steps the state is `⟨h, ⟨1^T.drop i, r.drop (i B)⟩⟩` (induction on
  `i`, `List.drop_drop`), so trial `i` reads the `k`-bit prefix `v_i = ⟦(r.drop (i B)).take k⟧`
  of block `i`, and the test at step `i` is `i < T ∧ E ⟦w⟧ v_i` (`hspec`). The search over the
  first `|start| + 1 ≥ T` rounds is therefore the search over `[0, T)`
  (`IterateFind.find?_range_and_lt`), which is `rejectBlocksL` read as a search followed by its
  value (`rejectBlocksL_eq_find?`). If the search fails, `g z = []`; otherwise
  `g z = true :: trial word`, whose tail has at most `k` bits (`List.length_take_le`) and reads
  as the accepted value. -/
theorem polyTimeComputable_rejectBlocksL (E : ℕ → ℕ → Prop) [∀ a, DecidablePred (E a)]
    {acc : List Bool → Bool} (hacc : PolyTimeComputable fun x => [acc x])
    (hspec : ∀ w b : List Bool, acc (pairEncode w b) = decide (E (listToNat w) (listToNat b)))
    {par kw bw tw c : List Bool → List Bool} (hpar : PolyTimeComputable par)
    (hkw : PolyTimeComputable kw) (hbw : PolyTimeComputable bw) (htw : PolyTimeComputable tw)
    (hc : PolyTimeComputable c) :
    ∃ g : List Bool → List Bool, PolyTimeComputable g ∧ ∀ z,
      (g z).tail.length ≤ (kw z).length ∧
      rejectBlocksL (E (listToNat (par z))) (kw z).length (bw z).length (tw z).length (c z) =
        if g z = [] then none else some (listToNat (g z).tail) := by
  exact ⟨fun z => rbl_loop acc
        (pairEncode (pairEncode (pairEncode (bw z) (kw z)) (par z)) (pairEncode (tw z) (c z))),
    PolyTimeComputable.comp' (rbl_loop_poly hacc)
      (((hbw.pairEncode hkw).pairEncode hpar).pairEncode (htw.pairEncode hc)),
    fun z => rbl_loop_spec E hspec (par z) (kw z) (bw z) (tw z) (c z)⟩

/-- The position of bit `j < k` of block `t < T` in a string of `T · B` coins (`k ≤ B`):
`t · B + j`. -/
private def dla_blockPos {k B T : ℕ} (hkB : k ≤ B) (p : Fin T × Fin k) : Fin (T * B) :=
  ⟨p.1.val * B + p.2.val, by
    have h1 := p.1.2
    have h2 := p.2.2
    calc p.1.val * B + p.2.val < p.1.val * B + B := by omega
      _ = (p.1.val + 1) * B := by ring
      _ ≤ T * B := Nat.mul_le_mul_right _ h1⟩

/-- Distinct (block, bit) pairs sit at distinct coin positions (`j < k ≤ B`). -/
private theorem dla_blockPos_injective {k B T : ℕ} (hkB : k ≤ B) :
    Function.Injective (dla_blockPos (T := T) hkB) := by
  rintro ⟨t, j⟩ ⟨t', j'⟩ h
  have h' : t.val * B + j.val = t'.val * B + j'.val := congrArg Fin.val h
  have hj := j.2
  have hj' := j'.2
  have hB : 0 < B := lt_of_lt_of_le (Nat.zero_lt_of_lt hj) hkB
  have ht : t.val = t'.val := by
    have e1 : (t.val * B + j.val) / B = t.val := by
      rw [Nat.add_comm, Nat.add_mul_div_right _ _ hB, Nat.div_eq_of_lt (by omega), zero_add]
    have e2 : (t'.val * B + j'.val) / B = t'.val := by
      rw [Nat.add_comm, Nat.add_mul_div_right _ _ hB, Nat.div_eq_of_lt (by omega), zero_add]
    rw [← e1, ← e2, h']
  have hj2 : j.val = j'.val := by rw [ht] at h'; omega
  rw [Fin.ext ht, Fin.ext hj2]

/-- The `k`-bit prefix of block `t` of a coin string, read off the list: for `t < T` and
`k ≤ B`, `((List.ofFn r).drop (t · B)).take k = List.ofFn (fun j => r (t · B + j))`. -/
private theorem dla_take_drop_ofFn {k B T : ℕ} (hkB : k ≤ B) (r : Fin (T * B) → Bool) (t : Fin T) :
    ((List.ofFn r).drop (t.val * B)).take k =
      List.ofFn (fun j : Fin k => r (dla_blockPos hkB (t, j))) := by
  have hlen : t.val * B + k ≤ T * B := by
    have := t.2
    calc t.val * B + k ≤ t.val * B + B := by omega
      _ = (t.val + 1) * B := by ring
      _ ≤ T * B := Nat.mul_le_mul_right _ this
  apply List.ext_getElem
  · rw [List.length_take, List.length_drop, List.length_ofFn, List.length_ofFn]
    omega
  · intro j h1 h2
    rw [List.getElem_take, List.getElem_drop, List.getElem_ofFn, List.getElem_ofFn]
    rfl

/-- **Block rejection sampling is close to uniform on `E`** (lemma C4 of the chapter 2
inventory on coin lists; the sampling clauses of [PS10, Theorems 52.3, 53.2, 61.7, 63.10]):
for `k ≤ B`, a uniform coin string of `T · B` bits and a default `d < 2^k` with `E d`, the
total sampler `(rejectBlocksL E k B T r).getD d` is within `(1 − Pr_{v < 2^k}[E v])^T` of the
uniform element of `{v < 2^k | E v}`. Repair (run-3 audit P7-6): stated once here instead of
in each consumer.

**Proof sketch.** For `r = List.ofFn r'`, `(r.drop (t·B)).take k = List.ofFn (π_t r')` where
`π_t r'` is the `k`-bit prefix of block `t` (`List.ext_get`, `List.getElem_take`,
`List.getElem_drop`, `List.getElem_ofFn`; the length is `k` since `t < T` and `k ≤ B`), so
`rejectBlocksL E k B T r = (firstHit (fun x : Fin (2^k) => E x) (fun t => bitsEquiv k (π_t r'))).map Fin.val`
(`List.map_coe_finRange`, `List.findSome?_map`, `bitsToNat_eq_listToNat`, `bitsEquiv_val`) and
`(·).getD d = Fin.val ((firstHit …).getD ⟨d, hdk⟩)` (`Option.getD_map`). The map
`r' ↦ (π_t r')_t` from `Fin (T·B) → Bool` to `Fin T → Fin k → Bool` pushes the uniform
distribution to the uniform one — it is the first projection of a splitting equivalence
`(Fin (T·B) → Bool) ≃ (Fin T → Fin k → Bool) × (Fin T → Fin (B − k) → Bool)` (`uprob_comp_equiv`,
`uprob_fst`; alternatively `pushesUniform_of_card_fiber`) — as does
`Equiv.piCongrRight (fun _ => bitsEquiv k)`; conclude from `statClose_firstHit` (default
`⟨d, hdk⟩`, `hd`) by `StatClose.comp_pushesUniform` and `StatClose.map Fin.val`. -/
theorem statClose_rejectBlocksL (E : ℕ → Prop) [DecidablePred E] (k B T : ℕ) (hkB : k ≤ B)
    {d : ℕ} (hd : E d) (hdk : d < 2 ^ k) :
    StatClose (fun r : Fin (T * B) → Bool => (rejectBlocksL E k B T (List.ofFn r)).getD d)
      (fun e : {v : Fin (2 ^ k) // E (v : ℕ)} => ((e : Fin (2 ^ k)) : ℕ))
      ((1 - uprob fun v : Fin (2 ^ k) => E (v : ℕ)) ^ T) := by
  -- the numbers read from the blocks, as a uniform draw of `T` elements of `Fin (2^k)`
  let π : (Fin (T * B) → Bool) → Fin T → Fin (2 ^ k) :=
    fun r t => bitsEquiv k (fun j => r (dla_blockPos hkB (t, j)))
  have hπ : HardcoreBit.PushesUniform π := by
    have h1 :=
      HardcoreBit.pushesUniform_restrict (O := Bool) (dla_blockPos_injective (T := T) hkB)
    have h2 := HardcoreBit.pushesUniform_equiv
      ((Equiv.curry (Fin T) (Fin k) Bool).trans (Equiv.piCongrRight fun _ : Fin T => bitsEquiv k))
    exact h1.comp h2
  have h := ((statClose_firstHit (fun v : Fin (2 ^ k) => E (v : ℕ)) T
    (d := ⟨d, hdk⟩) hd).comp_pushesUniform hπ).map Fin.val
  -- the block sampler is the first hit of the numbers read, mapped to `ℕ`
  have hX : ∀ r : Fin (T * B) → Bool, (rejectBlocksL E k B T (List.ofFn r)).getD d =
      ((firstHit (fun v : Fin (2 ^ k) => E (v : ℕ)) (π r)).getD ⟨d, hdk⟩).val := by
    intro r
    have hmap : rejectBlocksL E k B T (List.ofFn r) =
        (firstHit (fun v : Fin (2 ^ k) => E (v : ℕ)) (π r)).map Fin.val := by
      rw [rejectBlocksL_eq, firstHit_eq, List.map_findSome?, ← List.map_coe_finRange,
        List.findSome?_map]
      congr 1
      funext t
      have hv : listToNat (((List.ofFn r).drop (t.val * B)).take k) = (π r t).val := by
        rw [dla_take_drop_ofFn hkB r t, bitsEquiv_val, bitsToNat_eq_listToNat]
      show (if E (listToNat (((List.ofFn r).drop (t.val * B)).take k)) then
          some (listToNat (((List.ofFn r).drop (t.val * B)).take k)) else none) =
        Option.map Fin.val (if E (π r t).val then some (π r t) else none)
      rw [hv]
      by_cases hE : E (π r t).val
      · rw [if_pos hE, if_pos hE, Option.map_some]
      · rw [if_neg hE, if_neg hE, Option.map_none]
    rw [hmap]
    exact Option.getD_map Fin.val ⟨d, hdk⟩ _
  have hX' : (fun r : Fin (T * B) → Bool => (rejectBlocksL E k B T (List.ofFn r)).getD d) =
      fun r => ((firstHit (fun v : Fin (2 ^ k) => E (v : ℕ)) (π r)).getD ⟨d, hdk⟩).val :=
    funext hX
  rw [hX']
  exact h

end TCSlib.Cryptography.Candidates

run_cmd Lean.logInfo "CP2-EOF"
