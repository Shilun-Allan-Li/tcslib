/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Complexity.Randomized.Closure
import TCSlib.Complexity.Randomized.Repetition
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Asymptotic.OneWayLemmas
import TCSlib.Cryptography.Asymptotic.OneWayYao
import TCSlib.Cryptography.Asymptotic.Sampling
import TCSlib.Cryptography.Foundations.Negligible
import TCSlib.Cryptography.OneWayFunctions.Amplification
import Mathlib.Logic.Equiv.Fin.Basic
-- CP2 WHOLE-FILE SEAL (evidence probe; not library source): 866 requests for TCSlib.Cryptography.Asymptotic.OneWay
-- CP2 notation left unsealed (standing rule): Complexity.PolyExpr.eval, Complexity.PolyExpr.eval._sunfold, Complexity.PolyExpr.eval.match_1
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "SlotsLe"), "TCSlib.Complexity.ClassP.BinaryArith.Iterate", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "guardLoop"), "TCSlib.Complexity.ClassP.BinaryArith.Iterate", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "guardNxt"), "TCSlib.Complexity.ClassP.BinaryArith.Iterate", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip") "_sunfold"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip") "_unsafe_rec"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "padZip") "match_1"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "pairO"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "pairδ"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "pairδ") "match_1"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut") "_sunfold"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut") "_unsafe_rec"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialOut") "match_1"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialState"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialState") "_sunfold"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BinArith") "serialState") "_unsafe_rec"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "emit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "BlockLoop") "step"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Goes") "mono") "match_1_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "Instr") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "LinE") "val"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "MOp") "exec") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "St") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "TSt") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "act"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "bitsOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "ctl"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "enc"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "init"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instDecidableEqTSt") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "instFintypeTSt") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "linOps"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "run"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "shiftInput"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_3"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "step") "match_5"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tmplInstr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "toTM"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "CounterProg") "tr") "match_1"), "TCSlib.Complexity.TuringMachine.CounterProg", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "copyTM") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "find?_congr_of_mem") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostCtrl"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "hostRet"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "IterateFind") "step"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal") "_sunfold"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal") "_unsafe_rec"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "bitsVal") "match_1"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "eq_of_bitsVal_eq") "match_1_1"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW") "_sunfold"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW") "_unsafe_rec"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LogProg") "incW") "match_1"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "LoopInv"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Computes"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "Uniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "advInput"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "adviceLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinLen"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsCongr"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquivPoly"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "coinsEquiv_ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "combineAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "distinguisher"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "distinguisherL"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inAdvice"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inArg"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inCoins"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inParam"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inverter"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "inverterLit"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "layout"), "TCSlib.Complexity.Randomized.Closure", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "mk") "_flat_ctor"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "ofPolyTimeUniform"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "output"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "predictor"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAt"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runAtL"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "runLit"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "NUPPT") "timeBound"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT") "ofPolyTime"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PPT") "toNUPPT"), "TCSlib.Complexity.Randomized.PPT", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyBound"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "_sizeOf_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "eval") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "normal"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyExpr") "subst") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PolyTimeComputable"), "TCSlib.Complexity.ClassNP.PolyTime", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "drop"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instDecidableEqLabel") "decEq") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_3"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "instFintypeLabel") "match_5"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "PrefixByLength") "take"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "BlockMapLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EmitLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "flag"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "EqLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "out"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "start"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "IterLoop") "step"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "MajLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "acc"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "orbit_eq") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "out"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "rounds"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "start"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "XorLoop") "step"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstep"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "gstepBound"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "length_flatMap_range_le") "match_1_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_sunfold"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "_unsafe_rec"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "StateLoop") "orbit") "match_1"), "TCSlib.Complexity.Randomized.Build.StateLoop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "TimeConstructible"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "blockDone"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "guardedStep"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instDecidableEqPolyExpr") "decEq") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_sunfold"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "_unsafe_rec"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "instReprPolyExpr") "repr") "match_1"), "TCSlib.Complexity.Randomized.PolyExpr", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "isNilB"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairFstD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairMapSnd") "match_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "pairSndD"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_iterateFind") "match_1"), "TCSlib.Complexity.Randomized.Repetition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "polyTimeComputable_unary") "match_1_1"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceDropAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "sliceTakeAt"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce") "_sunfold"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce") "_unsafe_rec"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transduce") "match_1"), "TCSlib.Complexity.ClassNP.Transducer", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transducerTM"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transducerTr"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "transducerTr") "match_1"), "TCSlib.Complexity.ClassNP.Transducer", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Complexity") "xorD"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "FunFamily") "blocks"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "HardcoreBit") "PushesUniform"), "TCSlib.Cryptography.HardcoreBit.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Negligible"), "TCSlib.Cryptography.Foundations.Negligible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "Noticeable"), "TCSlib.Cryptography.Foundations.Negligible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "acc"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "rest"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "step"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "trial"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "uM"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "ukk"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "PosLoop") "unum"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "cnt"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "emit"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "rest"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "start"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "step"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "ProdEval") "u"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "Inv"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "acc"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "capped"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "dbl"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=0 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "pad"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "rest"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "start"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "UnaryOf") "step"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "Data") "_sizeOf_1"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "Data") "mk") "_flat_ctor"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "acc"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "adv"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "advP"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "alpha1"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ans"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "g"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ipos"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "nkk"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "off"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "offIn"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "planted"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "posBits"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "rc"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "rcoins"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "sampleAll"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "test"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "uIn"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "uM"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "uOut"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ukk"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "xs"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "yaoRaw"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "yaoRaw'"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "yaoRaw") "match_1"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ys"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "zOut"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ρP"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "YaoMachine") "ρPEquiv"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "bitListToNat"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "blocksE"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "kkOf"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "padTrue"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "pbOf"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "polyTimeComputable_unaryMulPair") "match_1_1"), "TCSlib.Cryptography.Asymptotic.OneWayLemmas", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "posOf"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "prodFun"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "roundEquiv"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "roundSample"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoB"), "TCSlib.Cryptography.Asymptotic.OneWayYao", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoBad"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoInverter"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoTry"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "OneWay") "yaoTryProb"), "TCSlib.Cryptography.OneWayFunctions.Amplification", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "StatClose"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "acceptProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsEquiv"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "bitsToNat"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "blocksEquivX"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "decodeFin"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "distAdv"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "firstHit"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "invProbOpt"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "padFin"), "TCSlib.Cryptography.Asymptotic.Adversary", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "predProb"), "TCSlib.Cryptography.Foundations.Experiments", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "rejectionSample"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uexp"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uniformFromBits"), "TCSlib.Cryptography.Asymptotic.Sampling", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "Cryptography") "uprob"), "TCSlib.Cryptography.Foundations.Probability", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "HasMinEntropy"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "_sizeOf_1"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "collision"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "map"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "mk") "_flat_ctor"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "prod"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "FinDist") "uniform"), "TCSlib.InformationTheory.FinDist", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "TCSlib") "InformationTheory") "statDist"), "TCSlib.InformationTheory.StatisticalDistance", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "apply") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Action") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ext") "match_1"), "TCSlib.Complexity.TuringMachine.Configuration", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "init"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "inputSymbol"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mapState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "ofWords"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "select"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "Cfg") "workTapeSymbols"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "serialize"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "CodeTM") "toFinTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "EffectiveMachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "Computes"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesFunInTimeVia"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ComputesInTime"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "VirtualTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "appendBitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "branchTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferTape"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedCompTM") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedFirstCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedScanCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "bufferedSecondCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callEntry"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callExit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "callTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1"), "TCSlib.Complexity.Randomized.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "condTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "constTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "controlAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "emitAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "idTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "ifEqTM") "match_1"), "TCSlib.Complexity.TuringMachine.Composition", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "incFixedTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "indexedVisit"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "leftCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "lengthBitsTM") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairExtractTM") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairLenCheckTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "pairValidTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyBitsTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "polyUnaryTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "prependTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "redirectTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rewind_scan") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightAction"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "rightCfg"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "splitSolveWithTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "stripLastTM_computes") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepAct"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_sunfold"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepFold") "match_1"), "TCSlib.Complexity.TuringMachine.Sweep", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepRevCfg"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "sweepTape"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "tapeBlocks"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "timedCondTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "toCodeTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "unaryTokenTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualMove"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "FinTM") "virtualNextTag") "match_1"), "TCSlib.Complexity.TuringMachine.Simulation", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MachineCode") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "Clean"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "entry"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "ModuleHost") "hostTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "AgreeOn"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesFunInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "ComputesInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "DecidableInTimeAndSpace"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "haltsAtStep"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "indicator"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "initCfg"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "outputSymbol"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "relabelState"), "TCSlib.Complexity.TuringMachine.StateRenaming", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "runFrom"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsed"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "spaceUsedByTape"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "step") "match_1"), "TCSlib.Complexity.TuringMachine.Deterministic", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "MultiTapeTM") "visitedByTapeHead"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "cfg"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "PairParse") "rewind_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "SafeRun"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "ones"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=1 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "UnaryTape") "wrT") "match_1"), "TCSlib.Complexity.TuringMachine.UnaryTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "actionBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "captureCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "dbl"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentRetTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "embedSilentTM"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "emitCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "incFixed") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instDecidableEqBodyState") "decEq") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "instInhabitedCfg") "default"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "moveInputPos"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optOptBoolBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "optStateBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "padAction"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_sunfold"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDecode") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairDiagTM") "match_3"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "pairEncode"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "signBits") "match_1"), "TCSlib.Complexity.TuringMachine.Encoding", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "solveSplitWith"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "spaceUsedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "splitAtLastTrue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "stateWord"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryFin"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "unaryTokenSplit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str Lean.Name.anonymous "Turing") "visitedOfCfgs"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairEmit"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimeBlockLoop") 0) "Complexity") "xorPairStep"), "TCSlib.Complexity.ClassNP.PolyTimeBlockLoop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "pairMapSnd") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Complexity") "polyTimeComputable_unary") "match_1_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePairing") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.PolyTimePairing", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "_sizeOf_1"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "match_on_same_ctor") "_@") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 444660554) "_hygCtx") "_hyg") 39), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "Label") "proxyTypeEquiv"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "program"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "PolyTimePrefix") 0) "Complexity") "PrefixByLength") "regs"), "TCSlib.Complexity.ClassNP.PolyTimePrefix", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "Transducer") 0) "Complexity") "transduce") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassNP") "Transducer") 0) "Complexity") "transducerTr") "match_1") "splitter"), "TCSlib.Complexity.ClassNP.Transducer", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "lastChunk"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "normChunk"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "padZip") "match_1") "splitter"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "pairδ") "match_1") "splitter"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "serialOut") "match_1") "splitter"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "BinaryArith") "Basic") 0) "Complexity") "BinArith") "zipStep"), "TCSlib.Complexity.ClassP.BinaryArith.Basic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterBump"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCarry") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterCfg"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_sunfold"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "_unsafe_rec"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1"), "TCSlib.Complexity.ClassP.TimeConstructible", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterInc") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Complexity") "counterTape"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "FinTM") "lengthBitsTM") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "ClassP") "TimeConstructible") 0) "Turing") "MultiTapeTM") "step") "match_1") "splitter"), "TCSlib.Complexity.ClassP.TimeConstructible", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "Inv"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "outWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "polyTimeComputable_find") "match_1_1") "splitter"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "stepWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFind") 0) "Complexity") "IterateFind") "verdictWord"), "TCSlib.Complexity.Randomized.Build.IterateFind", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "IterateFindHost") 0) "Complexity") "IterateFind") "copyCfg"), "TCSlib.Complexity.Randomized.Build.IterateFindHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "SplitControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "pairSplitTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "splitControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "FinTM") "split_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "PairSplit") 0) "Turing") "PairParse") "rewind_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.PairSplit", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "StringLoops") 0) "Complexity") "StateLoop") "BlockMapLoop") "blk"), "TCSlib.Complexity.Randomized.Build.StringLoops", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "_sizeOf_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "MulControl") "proxyTypeEquiv"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mulControlFintype") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "mul_run") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_3") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Build") "UnaryMul") 0) "Turing") "FinTM") "unaryMulTM") "match_5") "splitter"), "TCSlib.Complexity.Randomized.Build.UnaryMul", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "eval") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "PolyExpr") 0) "Complexity") "PolyExpr") "subst") "match_1") "splitter"), "TCSlib.Complexity.Randomized.PolyExpr", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Primitives") 0) "Turing") "FinTM") "computesFunInTime_pairSplitAt") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "Randomized") "Repetition") 0) "Complexity") "polyTimeComputable_iterateFind") "match_1") "splitter"), "TCSlib.Complexity.Randomized.Repetition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "SpaceComplexity") "Machines") "Bin") 0) "Complexity") "LogProg") "bitsVal") "match_1") "splitter"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "SpaceComplexity") "Machines") "Bin") 0) "Complexity") "LogProg") "incW") "match_1") "splitter"), "TCSlib.Complexity.SpaceComplexity.Machines.Bin", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Convention") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Convention", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedActionCore") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnAction"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedReturnCfg"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Embed") 0) "Turing") "embedSlot"), "TCSlib.Complexity.TuringMachine.Build.Embed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "BodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "copyCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "emitIterBody") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "fullCfg"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_3"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterBody") 0) "Turing") "instFintypeBodyState") "match_5"), "TCSlib.Complexity.TuringMachine.Build.EmitIterBody", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "EmitIterEmbed") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "callTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallBankFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearCfg") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallClearTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallCleared"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEmbeddedCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallEvalTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFinishTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallHi") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallIdleTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallInterval"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLayout"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallLo") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallPairSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightScan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallRightTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSlots"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallSpan"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackMid"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTrackTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleEmbedding"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleIndex"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emCallTripleSelect"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "emLoopForwardCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=2 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyDispatch"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyImage"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyPadded"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodySource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopBorrowPos") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCall"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopControlAction"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopCopyTape"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopDebit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFrame"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCaptured"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopFuelSource"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHostM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopHost_bound"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReady"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayCfg"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopReplayTM"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopValue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loopWrite") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_find_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Loop") 0) "Turing") "FinTM") "loop_rewind_bounded") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Loop", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padAction"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "padTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopCfg"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "ModuleHost") 0) "Turing") "ModuleHost") "stopTM"), "TCSlib.Complexity.TuringMachine.Build.ModuleHost", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "List") "filter") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "CatalogPolyControl") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "EmitterP2State") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "SplitBodyState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "anyTrueTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyControlFintype") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCopyCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_sunfold"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyCost") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyMove"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyTape"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPolyUnaryTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "catalogPrefixCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterCompareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2BodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2EraseTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2LeftIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2OneIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PairIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2PrepareTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2RightIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2SmallIndex"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2StateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterP2Words"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "emitterSplitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extractCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "extract_run") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "incFixedTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "lenCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "mapCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairCountTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairDupTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairExtractTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairMapTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "pairValidTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "polyUnaryTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "prependTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "rawStripTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "scanCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitAccept"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBank"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitBodyTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitCountCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitEmitTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitLoop_result") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPos"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareReady"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitPrepareTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreClean"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreScan"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRestoreTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitRewindTM"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitSafe"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitScratch"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "splitStep"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "stripCfg"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "FinTM") "unaryTokenTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "incFixed") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "splitAtLastTrue") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Primitives") 0) "Turing") "unaryTokenSplit") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Primitives", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectAction"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectState") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "redirectTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedBranchCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedCondTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedControlCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedPadTM"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "FinTM") "timedReadyCfg"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Build") "Wrappers") 0) "Turing") "captureAction") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Build.Wrappers", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "controlCfg"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "idTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Composition") 0) "Turing") "FinTM") "ifEqTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Composition", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Configuration") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Configuration", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Complexity") "CounterProg") "tr") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProg") 0) "Turing") "UnaryTape") "wrT") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProg", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgInput") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgInput", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "MOp") "exec") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "CounterProgRun") 0) "Complexity") "CounterProg") "step") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.CounterProgRun", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Deterministic") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Deterministic", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "FinTM") "toCodeTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDecode") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagCfg"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Encoding") 0) "Turing") "pairDiagTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Encoding", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Finite") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Finite", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBit"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arBuffer"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCell"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arCode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arDecode"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arIndex"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arMoveCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPending"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=3 requested={reqs.size} active={active} already={already}"
run_cmd do
  let env ← Lean.getEnv
  let reqs : Array (Lean.Name × String × String) := #[
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arPos"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReadCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arReady"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpaceBlock"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arSpacePhase"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTail"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arTape"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "AlphabetReduction") 0) "Turing") "FinTM") "arWriteCfg"), "TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "SignType") "fin3Equiv") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGSpan"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "DGWindow") "mk") "_flat_ctor"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "_sizeOf_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "SweepState") "proxyTypeEquiv"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "blankRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCost"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgCross"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgLeftRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgRetract"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "dgTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "headAt"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readState"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "readVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "rightRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepBoundary"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepEmbed"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepInput") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepMove"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepPos"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStart"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepStateFintype") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepSymbol"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_3") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTM") "match_5") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "sweepTime") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeRow"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_sunfold"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "_unsafe_rec"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "tapeZone") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeCfg"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "unusedTapeTM"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Robustness") "SingleTape") 0) "Turing") "FinTM") "writeVisit") "match_1"), "TCSlib.Complexity.TuringMachine.Robustness.SingleTape", "def/matcher"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "Action") "apply") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "bufferedCompTM") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Simulation") 0) "Turing") "FinTM") "virtualNextTag") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Simulation", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Complexity") "TuringMachine") "Sweep") 0) "Turing") "FinTM") "sweepFold") "match_1") "splitter"), "TCSlib.Complexity.TuringMachine.Sweep", "def"),
    ((Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.num (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str (Lean.Name.str Lean.Name.anonymous "_private") "TCSlib") "Cryptography") "Asymptotic") "Sampling") 0) "TCSlib") "Cryptography") "listToNat_inj") "match_1_1"), "TCSlib.Cryptography.Asymptotic.Sampling", "def/matcher")]
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, home, kind) in reqs do
    let some ci := env.find? n | throwError "CP2-SEAL missing {n}"
    let some mi := env.getModuleIdxFor? n | throwError "CP2-SEAL no home {n}"
    unless (env.header.moduleNames[mi.toNat]!).toString == home do throwError "CP2-SEAL wrong home {n}"
    let k := match ci with | .defnInfo _ => "def" | .opaqueInfo _ => "opaque" | _ => "other"
    unless kind.startsWith k do throwError "CP2-SEAL wrong kind {n}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let after ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless after == .irreducible do throwError "CP2-SEAL not installed {n}"
  Lean.logInfo m!"CP2-SEAL chunk=4 requested={reqs.size} active={active} already={already}"
-- CP2 END SEAL


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# One-way functions, asymptotic layer

The one-way function definitions of [PS10, §2.2] and the hardness amplification theorems of
[PS10, §2.4], stated over the machine layer `Complexity.NUPPT` and the typed concrete
experiments of `TCSlib.Cryptography.Foundations.Experiments` (foundation decisions D2, D3,
D5 of `PassShelatChapter2-4Plan.md`).

A *function family* `FunFamily` is `f n : {0,1}^{inLen n} → {0,1}^{outLen n}` with syntactic
polynomial lengths (the textbook `f : {0,1}* → {0,1}*` is `FunFamily.ofString f p`, parameter =
input length; exact for length-regular `f`, `ofFn_ofString_f`, otherwise the `false`-padding to
`p(n)` bits is lossy); `FunFamily.invProbAt 𝓕 A n` is the experiment
`Pr[x ← {0,1}^n; y ← f(x) : f(A(1^n, y)) = y]` for the machine `A`, its output decoded as an
`inLen n`-bit string. The three one-wayness notions of [PS10, Definitions 26.1, 27.3, 28.4]
follow — Definition 26.1 in its `1^n` form `FunFamily.WorstCaseOneWay` (headline) and its
literal form `FunFamily.WorstCaseOneWayLit` (`A(f(x))` only), related by
`WorstCaseOneWay.toLit` and `WorstCaseOneWayLit.toParam` (D5, run-3 audit P3-2) —
then the direct product `FunFamily.prod` with the parameters `yaoBlocks`/`yaoRounds`
(`m = 2nq(n)`, `T = 2nm(n)n^c`) of [PS10, §2.4.3], the theorems `weak_to_strong`
[PS10, Theorem 35.1], `strong_prod_two` [PS10, Theorem 35.2], `claim_38_2` (the parameter
instantiation of the concrete `OneWay.yao_amplification_exp` [Gar26, Theorem 2.1]), the sanity
results `FunFamily.StrongOneWay.weak` and `not_strongOneWay_id`, `not_weakOneWay_id`,
`not_worstCaseOneWay_id` (the adversary classes are not vacuous), and
`PermFamily`/`OneWayPermutation` (the single-function form of [PS10, Definition 55.1], as used
in Theorems 79.4 and 126.4). Every
asymptotic theorem is proved by (i) instantiating the concrete reduction at every `n`,
(ii) exhibiting the reduction as a `Complexity.NUPPT` by the closure calculus of
`TCSlib/Complexity/Randomized/`, (iii) negligible-function arithmetic (`not_negligible_iff`).

**Deviation:** domains are typed at each parameter (D5): the direct product `𝓕.prod q` is the
family at parameter `n` with input length `q(n)·inLen(n)` and its adversaries receive `1^n`
where the text's adversary of `f'` receives `1^{n·m(n)}`; the two are interderivable
(`1^{n·m(n)}` is computed from `1^n` by `polyTimeComputable_unaryPoly`, and `n` is recovered
from `n·m(n)` by a polynomial search, `m` being monotone), so the classes coincide. The
deviations of `Easy`, `invProbAt` and `WeakOneWay` are recorded on the declarations.

## Main definitions

* `TCSlib.Cryptography.FunFamily` (`Easy`, `invProbAt`, `ofString`, `LengthRegular`, `prod`;
  the block bijection `FunFamily.blocks` lives in `Asymptotic/Adversary.lean`); `FunFamily.StrongOneWay`, `FunFamily.WeakOneWay`, `FunFamily.WorstCaseOneWay`
  (`1^n` form, headline) and `FunFamily.WorstCaseOneWayLit` (literal form)
  [PS10, Definitions 27.3, 28.4, 26.1].
* `TCSlib.Cryptography.yaoBlocks`, `yaoRounds` — `m = 2nq(n)`, `T = 2nm(n)n^c` [PS10, §2.4.3].
* `TCSlib.Cryptography.PermFamily`, `TCSlib.Cryptography.OneWayPermutation`.

## Main results

* `TCSlib.Cryptography.weak_to_strong` [PS10, Theorem 35.1], `strong_prod_two`
  [PS10, Theorem 35.2], `claim_38_2` (parameter instantiation, [PS10, §2.4.3]),
  `OneWay.invProb_prodFun_le_yaoTry` (concrete one-call planting, lemma C2 of the inventory).
* `TCSlib.Cryptography.FunFamily.StrongOneWay.weak`, `TCSlib.Cryptography.not_strongOneWay_id`,
  `not_weakOneWay_id`, `not_worstCaseOneWay_id`,
  `TCSlib.Cryptography.FunFamily.invProbAt_ofString_id_eq_one` — sanity and non-vacuity.
* `TCSlib.Cryptography.FunFamily.WorstCaseOneWay.toLit`,
  `TCSlib.Cryptography.FunFamily.WorstCaseOneWayLit.toParam` — the two forms of
  [PS10, Definition 26.1] (always / for injective `outLen`).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §2.3 (Theorem 2.1, Figure 2.2: the concrete amplification).
-/

namespace TCSlib.Cryptography

open Complexity Turing Finset

/-! ## Function families -/

/-- A family `f n : {0,1}^{inLen n} → {0,1}^{outLen n}` with explicit polynomial lengths: the
typed reading (D5) of the textbook `f : {0,1}* → {0,1}*` at security parameter `n`
[PS10, §2.2]. A string function `f` gives the family `ofString f p`, exact for length-regular
`f` (`ofFn_ofString_f`); otherwise the `false`-padding to `p(n)` bits is lossy. -/
structure FunFamily where
  /-- The input length at parameter `n`. -/
  inLen : PolyExpr
  /-- The output length at parameter `n`. -/
  outLen : PolyExpr
  /-- The function at parameter `n`. -/
  f : ∀ n, (Fin (inLen.eval n) → Bool) → (Fin (outLen.eval n) → Bool)

namespace FunFamily

/-- `𝓕` is *easy to compute*: a polynomial-time string function computes `f n x` from
`⟨1^n, x⟩` [PS10, Definitions 26.1 (1) and 27.3 (1)].

**Deviation:** `FunFamily.Easy`: deterministic polynomial-time evaluator on `⟨1^n, x⟩` instead
of a PPT computing with probability one (equivalent by `Computes` + `ofPolyTimeUniform`). -/
def Easy (𝓕 : FunFamily) : Prop :=
  ∃ F : List Bool → List Bool, PolyTimeComputable F ∧
    ∀ n (x : Fin (𝓕.inLen.eval n) → Bool), F (NUPPT.advInput n (List.ofFn x)) = List.ofFn (𝓕.f n x)

/-- The defining property of `Easy`: `𝓕.Easy` iff some polynomial-time `F` satisfies
`F ⟨1^n, x⟩ = f n x` (as strings) for every `n` and every `x`. -/
theorem easy_iff (𝓕 : FunFamily) :
    𝓕.Easy ↔ ∃ F : List Bool → List Bool, PolyTimeComputable F ∧
      ∀ n (x : Fin (𝓕.inLen.eval n) → Bool),
        F (NUPPT.advInput n (List.ofFn x)) = List.ofFn (𝓕.f n x) := Iff.rfl

/-- The inversion probability of the machine `A` against `𝓕` at parameter `n`:
`Pr[x ← {0,1}^{inLen n}; y ← f(x); r : f(A(1^n, y; r)) = y]` with the output of `A` decoded as
an `inLen n`-bit string [PS10, Definitions 27.3 and 28.4, the displayed experiment].

**Deviation:** `inverter`: wrong-length output = failure (D5). -/
noncomputable def invProbAt (𝓕 : FunFamily) (A : NUPPT) (n : ℕ) : ℝ :=
  invProbOpt (𝓕.f n) (A.inverter n (𝓕.inLen.eval n) (𝓕.outLen.eval n))

/-- `𝓕` is a *strong one-way function*: easy to compute, and every non-uniform PPT inverts it
with negligible probability [PS10, Definition 27.3]. -/
structure StrongOneWay (𝓕 : FunFamily) : Prop where
  /-- Easy to compute. -/
  easy : 𝓕.Easy
  /-- Hard to invert: negligible inversion probability for every `A`. -/
  hard : ∀ A : NUPPT, Negligible fun n => 𝓕.invProbAt A n

/-- `𝓕` is a *weak one-way function*: easy to compute, and there is a polynomial `q` such
that every non-uniform PPT inverts it with probability at most `1 - 1/q(n)` for all
sufficiently large `n` [PS10, Definition 28.4].

**Deviation:** `WeakOneWay`: `0 < q n` made explicit (`1 - 1/0 = 1` would make the clause
vacuous). -/
structure WeakOneWay (𝓕 : FunFamily) : Prop where
  /-- Easy to compute. -/
  easy : 𝓕.Easy
  /-- Hard to invert with probability `1 - 1/q(n)`. -/
  hard : ∃ q : PolyExpr, (∀ n, 0 < q.eval n) ∧ ∀ A : NUPPT, ∃ n₀, ∀ n ≥ n₀,
    𝓕.invProbAt A n ≤ 1 - 1 / (q.eval n : ℝ)

/-- `𝓕` is a *worst-case one-way function*: easy to compute, and no non-uniform PPT inverts
it on every input with probability one [PS10, Definition 26.1], in the `1^n` form: the
adversary receives `1^n` and `f(x)` (`inverter`, D5) and must return an `inLen n`-bit
preimage. This is the headline form of the definition; the literal form (the adversary
receives `f(x)` only) is `WorstCaseOneWayLit`, and the two are related by
`WorstCaseOneWay.toLit` (always) and `WorstCaseOneWayLit.toParam` (injective `outLen`), as
`Ensemble.Indist`/`Ensemble.IndistLit` for [PS10, Definition 69.4].

Repair (run-3 audit P3-2): the frozen headline was the literal form (now `WorstCaseOneWayLit`),
which can be vacuously satisfied by families whose output length does not determine `n` (e.g.
the constant family `x ↦ ε`, trivially invertible in the text); the `1^n`
form is now the headline, mirroring D5's treatment of Definition 69.4.

**Deviation:** the adversary receives `1^n` where the text writes `A(f(x))` (D5; the literal
reading is `WorstCaseOneWayLit`); inverses are sought in the domain at the current parameter
(`inverter`, wrong-length output = failure). -/
structure WorstCaseOneWay (𝓕 : FunFamily) : Prop where
  /-- Easy to compute. -/
  easy : 𝓕.Easy
  /-- Hard to invert: no `A` with `∀ x, Pr[A(1^n, f(x)) ∈ f⁻¹(f(x))] = 1`. -/
  hard : ¬ ∃ A : NUPPT, ∀ n (x : Fin (𝓕.inLen.eval n) → Bool),
    uprob (fun r : A.Coins n =>
      ∃ x', A.inverter n (𝓕.inLen.eval n) (𝓕.outLen.eval n) (𝓕.f n x) r = some x' ∧
        𝓕.f n x' = 𝓕.f n x) = 1

/-- `𝓕` is a *worst-case one-way function in the literal form* of [PS10, Definition 26.1]:
easy to compute, and no non-uniform PPT inverts it on every input with probability one, the
adversary receiving `f(x)` only (activation at the output length, `inverterLit`, D5) and
returning an `inLen n`-bit preimage.

Repair (run-3 audit P3-2): renamed from `WorstCaseOneWay`; the `1^n` form `WorstCaseOneWay` is
the headline, and `WorstCaseOneWay.toLit`/`WorstCaseOneWayLit.toParam` relate the two.

**Deviation:** when `outLen` is constant, so that `|f(x)|` does not determine `n`, the literal
form can hold for families that are trivially invertible given `1^n`, an artefact of D5's
typed inverse (the literal adversary cannot know `n`): e.g. the constant family `x ↦ ε` with
`inLen = var`, `outLen = 0` (the adversary cannot know the required output length `inLen n`),
or `f n b = b ⊕ [n odd]` on one bit (it cannot know the parity of `n`; gate 03b, finding 9).
The `1^n` form is the headline; `toParam` applies whenever `outLen` is non-constant (for
`PolyExpr` lengths, injective ⇔ non-constant), so for families with non-constant `outLen` the two
forms coincide (`toLit`, `toParam`); with constant `outLen` they can differ, as above (gate 03b,
round 2, R2-2). -/
structure WorstCaseOneWayLit (𝓕 : FunFamily) : Prop where
  /-- Easy to compute. -/
  easy : 𝓕.Easy
  /-- Hard to invert: no `A` with `∀ x, Pr[A(f(x)) ∈ f⁻¹(f(x))] = 1`. -/
  hard : ¬ ∃ A : NUPPT, ∀ n (x : Fin (𝓕.inLen.eval n) → Bool),
    uprob (fun r : A.Coins (𝓕.outLen.eval n) =>
      ∃ x', A.inverterLit (𝓕.inLen.eval n) (𝓕.outLen.eval n) (𝓕.f n x) r = some x' ∧
        𝓕.f n x' = 𝓕.f n x) = 1

/-- The output length of a string function on inputs of length `n`, read off at `0^n`. -/
def strOutLen (f : List Bool → List Bool) (n : ℕ) : ℕ := (f (List.replicate n false)).length

/-- The textbook `f : {0,1}* → {0,1}*` with the output length `p`: parameter = input length,
the output padded or truncated to `p(n)` bits (exact when `f` is `LengthRegular f p`).

Inversion is typed (D5, `NUPPT.inverter`): an inverter of `ofString f p` at parameter `n` must
return a preimage of length `n`, while [PS10, Definition 27.3] accepts a preimage of any
length. The two experiments agree when `f` is length-regular with non-constant `p` (then
`|f(x)|` determines `|x|`); with constant `p` neither notion is satisfiable. Otherwise the typed
notion can be strictly weaker. An informal example (not formalized; gate 03a, note 15): let `h` be
a length-preserving one-way function and `g(x ‖ b) := h(x) ‖ 1` on non-empty inputs (again
length-preserving and one-way, with every output ending in `1`); put `f(0^k ‖ w) := w` for
`|w| = k ≥ 1` and `f(x) := g(x)` elsewhere, and take `p = var`. In the text's experiment
`y ↦ 0^{|y|} ‖ y` inverts `f` with probability one. In the typed experiment on `ofString f .var`
the special outputs are padded with zeros, so they end in `0` and cannot equal an ordinary output;
an inverter succeeds on an ordinary challenge only by inverting `g`, so its success is at most
its success against `g` plus `O(2^{-n/2})`. The final `1` matters: without it the zero padding can
make special outputs collide with ordinary ones, and the typed experiment is then not harder
(gate 03b, round 2, R2-1). -/
def ofString (f : List Bool → List Bool) (p : PolyExpr) : FunFamily where
  inLen := .var
  outLen := p
  f _ x i := (f (List.ofFn x)).getD i false

/-- The input length of `ofString f p` at `n` is `n` (the parameter is the input length). -/
theorem ofString_inLen_eval (f p) (n : ℕ) : (ofString f p).inLen.eval n = n := rfl

/-- The output length of `ofString f p` at `n` is `p(n)`. -/
theorem ofString_outLen_eval (f p) (n : ℕ) : (ofString f p).outLen.eval n = p.eval n := rfl

/-- The defining equation of `ofString`'s function: bit `i` is `f(x)_i`, `false` past its end. -/
theorem ofString_f_apply (f : List Bool → List Bool) (p : PolyExpr) (n : ℕ)
    (x : Fin ((ofString f p).inLen.eval n) → Bool) (i : Fin ((ofString f p).outLen.eval n)) :
    (ofString f p).f n x i = (f (List.ofFn x)).getD i false := rfl

/-- `f` is *length-regular* with output length `p`: `|f x| = p(|x|)` for every `x`. -/
def LengthRegular (f : List Bool → List Bool) (p : PolyExpr) : Prop :=
  ∀ x, (f x).length = p.eval x.length

/-- The direct product `f'_n = (f_n)^{q n}` of [PS10, Theorem 35.1]:
`f'(x₁, …, x_{q(n)}) = (f(x₁), …, f(x_{q(n)}))` on blocks, encoded as concatenations;
`OneWay.prodFun` [Gar26, Theorem 2.1] blockwise. -/
def prod (𝓕 : FunFamily) (q : PolyExpr) : FunFamily where
  inLen := .mul q 𝓕.inLen
  outLen := .mul q 𝓕.outLen
  f n x := (blocks (q.eval n) (𝓕.outLen.eval n)).symm
    (TCSlib.Cryptography.OneWay.prodFun (𝓕.f n) (q.eval n) (blocks (q.eval n) (𝓕.inLen.eval n) x))

/-! ### Unfolding lemmas -/

/-- The inversion probability is nonnegative. -/
theorem invProbAt_nonneg (𝓕 : FunFamily) (A : NUPPT) (n : ℕ) : 0 ≤ 𝓕.invProbAt A n :=
  invProbOpt_nonneg _ _

/-- The inversion probability is at most one. -/
theorem invProbAt_le_one (𝓕 : FunFamily) (A : NUPPT) (n : ℕ) : 𝓕.invProbAt A n ≤ 1 :=
  invProbOpt_le_one _ _

/-- The inversion probability unfolded: the probability over `x` and the coins `r` that the
activation `A(1^n, f(x); r)` is the encoding of some `x'` with `f(x') = f(x)`. -/
theorem invProbAt_eq_uprob (𝓕 : FunFamily) (A : NUPPT) (n : ℕ) :
    𝓕.invProbAt A n = uprob fun z : (Fin (𝓕.inLen.eval n) → Bool) × A.Coins n =>
      ∃ x', A.runAt n (List.ofFn (𝓕.f n z.1)) z.2 = List.ofFn x' ∧ 𝓕.f n x' = 𝓕.f n z.1 := by
  unfold invProbAt
  simp only [invProbOpt_def]
  congr 1
  funext z
  simp only [NUPPT.inverter_eq_some_iff]

/-! ### The two forms of Definition 26.1 -/

/-- **The `1^n` form implies the literal form** of [PS10, Definition 26.1] (repair of the
run-3 audit, P3-2; the analogue of `Ensemble.Indist.toLit`): a literal inverter `A`, activated at
the output length `|f(x)| = outLen n`, is the `1^n`-inverter `NUPPT.exists_reparam A outLen`,
so if no `1^n`-inverter succeeds on every input, no literal inverter does.

**Proof sketch.** `NUPPT.exists_reparam A 𝓕.outLen` gives `B` with
`B.runAtL n y r = A.runAtL (outLen n) y r` and `B.coins = A.coins.subst outLen`, so
`B.Coins n ≃ A.Coins (outLen n)` (`PolyExpr.eval_subst`, `finCongr`); `uprob_comp_equiv`
transports the success event, and `NUPPT.inverter`/`NUPPT.inverterLit` unfold to the same
`decodeFin` of the same activation (`List.ofFn_congr`). -/
theorem WorstCaseOneWay.toLit {𝓕 : FunFamily} (h : 𝓕.WorstCaseOneWay) : 𝓕.WorstCaseOneWayLit := by
  refine ⟨h.easy, ?_⟩
  rintro ⟨A, hA⟩
  obtain ⟨B, hBc, -, hB⟩ := A.exists_reparam 𝓕.outLen
  refine h.hard ⟨B, fun n x => ?_⟩
  have hlen : B.coinLen n = A.coinLen (𝓕.outLen.eval n) := by
    simp only [NUPPT.coinLen_eq, hBc, PolyExpr.eval_subst]
  let e : A.Coins (𝓕.outLen.eval n) ≃ B.Coins n :=
    Equiv.arrowCongr (finCongr hlen.symm) (Equiv.refl Bool)
  rw [← uprob_comp_equiv e]
  refine (OneWay.uprob_congr fun r => ?_).trans (hA n x)
  have hofn : List.ofFn (e r) = List.ofFn r := (List.ofFn_congr hlen.symm r).symm
  simp only [NUPPT.inverter_def, NUPPT.inverterLit_eq, NUPPT.runAt_eq, hB, hofn]

/-- **The literal form implies the `1^n` form when the output length determines the
parameter** (injective `outLen`, equivalently non-constant output length for these polynomial
lengths; repair of the run-3 audit, P3-2; the analogue of `Ensemble.IndistLit.toIndist`): a
`1^n`-inverter `B` is the literal
inverter `NUPPT.exists_reparam_advice B φ var` with `φ (outLen n) = n`, which hard-wires `1^n`
and `B.advice n` at the output length and leaves its extra coins unread.

**Proof sketch.** An injective monotone `outLen.eval` (`PolyExpr.eval_mono`) is strictly
monotone (`Monotone.strictMono_of_injective`), so `n ≤ outLen n` (`StrictMono.id_le`) and
`φ m := the n with outLen n = m` (`0` if none) is majorised by `var`.
`NUPPT.exists_reparam_advice B φ var` gives `A` with
`A.runAtL m y r = B.runAtL (φ m) y (r.take (B.coinLen (φ m)))`; at `m = outLen n` we have
`φ m = n` and `A.Coins m ≃ B.Coins n × (Fin (B.coinLen m − B.coinLen n) → Bool)`
(`Fin.appendEquiv`, `finCongr`, `PolyExpr.eval_mono`); `List.ofFn_fin_append` and
`List.take_left'` identify the literal event with the `1^n` event on the first factor
(`uprob_comp_equiv`, `uprob_fst`). -/
theorem WorstCaseOneWayLit.toParam {𝓕 : FunFamily} (hinj : Function.Injective 𝓕.outLen.eval)
    (h : 𝓕.WorstCaseOneWayLit) : 𝓕.WorstCaseOneWay := by
  classical
  refine ⟨h.easy, ?_⟩
  rintro ⟨B, hB⟩
  have hsm : StrictMono 𝓕.outLen.eval := 𝓕.outLen.eval_mono.strictMono_of_injective hinj
  have hle : ∀ n, n ≤ 𝓕.outLen.eval n := fun n => hsm.id_le n
  let φ : ℕ → ℕ := fun m => if hm : ∃ n, 𝓕.outLen.eval n = m then hm.choose else 0
  have hφ : ∀ m, φ m ≤ PolyExpr.var.eval m := by
    intro m
    simp only [φ, PolyExpr.eval_var]
    split_ifs with hm
    · exact (hle _).trans_eq hm.choose_spec
    · exact Nat.zero_le _
  have hφn : ∀ n, φ (𝓕.outLen.eval n) = n := by
    intro n
    have hm : ∃ n', 𝓕.outLen.eval n' = 𝓕.outLen.eval n := ⟨n, rfl⟩
    simp only [φ, dif_pos hm]
    exact hinj hm.choose_spec
  obtain ⟨A, hAc, hA⟩ := B.exists_reparam_advice φ .var hφ
  refine h.hard ⟨A, fun n x => ?_⟩
  have hAlen : A.coinLen (𝓕.outLen.eval n) =
      B.coinLen n + (B.coinLen (𝓕.outLen.eval n) - B.coinLen n) := by
    have h1 : A.coinLen (𝓕.outLen.eval n) = B.coinLen (𝓕.outLen.eval n) := by
      simp only [NUPPT.coinLen_eq, hAc, PolyExpr.eval_subst, PolyExpr.eval_var]
    have h2 : B.coinLen n ≤ B.coinLen (𝓕.outLen.eval n) := by
      rw [NUPPT.coinLen_eq, NUPPT.coinLen_eq]
      exact B.coins.eval_mono (hle n)
    omega
  let e : B.Coins n × (Fin (B.coinLen (𝓕.outLen.eval n) - B.coinLen n) → Bool) ≃
      A.Coins (𝓕.outLen.eval n) :=
    (Fin.appendEquiv _ _).trans (Equiv.arrowCongr (finCongr hAlen.symm) (Equiv.refl Bool))
  rw [← uprob_comp_equiv e]
  have key : ∀ z : B.Coins n × (Fin (B.coinLen (𝓕.outLen.eval n) - B.coinLen n) → Bool),
      (∃ x', A.inverterLit (𝓕.inLen.eval n) (𝓕.outLen.eval n) (𝓕.f n x) (e z) = some x' ∧
        𝓕.f n x' = 𝓕.f n x) ↔
      ∃ x', B.inverter n (𝓕.inLen.eval n) (𝓕.outLen.eval n) (𝓕.f n x) z.1 = some x' ∧
        𝓕.f n x' = 𝓕.f n x := by
    intro z
    have hofn : List.ofFn (e z) = List.ofFn z.1 ++ List.ofFn z.2 := by
      rw [← List.ofFn_fin_append]
      exact (List.ofFn_congr hAlen.symm (Fin.append z.1 z.2)).symm
    simp only [NUPPT.inverter_def, NUPPT.inverterLit_eq, NUPPT.runAt_eq, hA, hφn, hofn,
      List.take_left', List.length_ofFn]
  rw [OneWay.uprob_congr key]
  exact (uprob_fst fun r : B.Coins n => ∃ x',
    B.inverter n (𝓕.inLen.eval n) (𝓕.outLen.eval n) (𝓕.f n x) r = some x' ∧
      𝓕.f n x' = 𝓕.f n x).trans (hB n x)

/-- On a length-regular `f`, the family `ofString f p` is exactly `f` on encoded strings. -/
theorem ofFn_ofString_f {f : List Bool → List Bool} {p : PolyExpr} (hf : LengthRegular f p)
    (n : ℕ) (x : Fin n → Bool) : List.ofFn ((ofString f p).f n x) = f (List.ofFn x) := by
  have hlen : (f (List.ofFn x)).length = p.eval n := by rw [hf, List.length_ofFn]
  refine List.ext_get (by simp [ofString, hlen]) fun i h₁ h₂ => ?_
  simp [ofString, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem h₂]

/-- `ofFn_ofString_f` on the family's input space `{0,1}^{inLen(n)}`. -/
theorem ofFn_ofString_apply {f : List Bool → List Bool} {p : PolyExpr} (hf : LengthRegular f p)
    (n : ℕ) (x : Fin ((ofString f p).inLen.eval n) → Bool) :
    List.ofFn ((ofString f p).f n x) = f (List.ofFn x) :=
  ofFn_ofString_f hf n x

/-- The identity family is the identity at every parameter. -/
theorem ofString_id_f (n : ℕ) (x : Fin n → Bool) : (ofString id .var).f n x = x := by
  have h := ofFn_ofString_f (f := id) (p := .var) (fun x => by simp) n x
  exact List.ofFn_injective (by simpa using h)

/-- The encoding of a tuple of blocks is the concatenation of the encodings of the blocks. -/
theorem ofFn_blocks_symm (q ℓ : ℕ) (t : Fin q → Fin ℓ → Bool) :
    List.ofFn ((blocks q ℓ).symm t) = (List.ofFn fun i => List.ofFn (t i)).flatten := by
  rw [List.ofFn_mul]
  congr 1
  congr 1
  funext i
  congr 1
  funext j
  rw [blocks_symm_apply]
  have hℓ : 0 < ℓ := Nat.pos_of_ne_zero (by rintro rfl; exact j.elim0)
  congr 1
  · refine Fin.ext ?_
    simp only [Fin.coe_divNat]
    rw [Nat.add_comm, Nat.add_mul_div_right _ _ hℓ, Nat.div_eq_of_lt j.2, zero_add]
  · refine Fin.ext ?_
    simp only [Fin.coe_modNat]
    rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt j.2]

/-- The input length of the direct product is `q · inLen`. -/
@[simp] theorem prod_inLen (𝓕 : FunFamily) (q : PolyExpr) : (𝓕.prod q).inLen = .mul q 𝓕.inLen :=
  rfl

/-- The output length of the direct product is `q · outLen`. -/
@[simp] theorem prod_outLen (𝓕 : FunFamily) (q : PolyExpr) :
    (𝓕.prod q).outLen = .mul q 𝓕.outLen := rfl

/-- The direct product unfolded: `prodFun` between the block bijections. -/
theorem prod_f (𝓕 : FunFamily) (q : PolyExpr) (n : ℕ) (x : Fin (q.eval n * 𝓕.inLen.eval n) → Bool) :
    (𝓕.prod q).f n x = (blocks (q.eval n) (𝓕.outLen.eval n)).symm
      (OneWay.prodFun (𝓕.f n) (q.eval n) (blocks (q.eval n) (𝓕.inLen.eval n) x)) := rfl

/-- The inversion probability of the direct product is the concrete `invProbOpt` of
`OneWay.prodFun (f n) (q n)` against the inverter that encodes its challenge tuple by
`blocks` and decodes its answer: the bridge from `𝓕.prod q` to [Gar26, Theorem 2.1].

**Proof sketch.** Reindex the uniform input `x : {0,1}^{q·ℓ}` by the bijection `blocks`
(`uprob_comp_equiv` on the first coordinate); `f'` is `blocks⁻¹ ∘ prodFun ∘ blocks` by
`prod_f`, and `blocks⁻¹` is injective, so the success events coincide pointwise. -/
theorem invProbAt_prod_eq (𝓕 : FunFamily) (q : PolyExpr) (A : NUPPT) (n : ℕ) :
    (𝓕.prod q).invProbAt A n =
      invProbOpt (OneWay.prodFun (𝓕.f n) (q.eval n)) fun ys r =>
        (A.inverter n (q.eval n * 𝓕.inLen.eval n) (q.eval n * 𝓕.outLen.eval n)
          ((blocks (q.eval n) (𝓕.outLen.eval n)).symm ys) r).map (blocks (q.eval n) (𝓕.inLen.eval n)) := by
  unfold invProbAt
  simp only [invProbOpt_def]
  rw [← uprob_comp_equiv (Equiv.prodCongr (blocks (q.eval n) (𝓕.inLen.eval n)) (Equiv.refl _))]
  congr 1
  funext z
  simp only [Equiv.prodCongr_apply, Equiv.coe_refl, Prod.map_fst, Prod.map_snd, id_eq, prod_f,
    Option.map_eq_some_iff]
  apply propext
  constructor
  · rintro ⟨x', hx', hf⟩
    refine ⟨blocks _ _ x', ⟨x', hx', rfl⟩, ?_⟩
    have := congrArg (blocks (q.eval n) (𝓕.outLen.eval n)) hf
    simpa using this
  · rintro ⟨t, ⟨x', hx', rfl⟩, hf⟩
    exact ⟨x', hx', by simp [hf]⟩

/-- **The direct product is easy to compute.** If `𝓕` is easy then so is `𝓕.prod q`
[PS10, Theorem 35.1, "`f'` is easy to compute"].

**Proof sketch.** Let `F` be the evaluator of `𝓕`. The evaluator of `𝓕.prod q` is the
blockwise evaluator `OneWay.exists_prodEval F inLen q` (an instance of
`Complexity.polyTimeComputable_iterateEmit` with `R := q` on the state word `⟨⟨1^n, cnt⟩, rest⟩`:
while the unary counter `cnt` is shorter than `1^{q(n)}` a round emits `F ⟨1^n, rest.take (inLen n)⟩`
and drops `inLen n` bits, afterwards it emits `[]`; `q` is evaluated at the state-word length
`≥ n`, so exactly `q(n)` rounds emit). Its specification gives the concatenation over `i < q(n)`
of `F ⟨1^n, block i⟩`, which is the concatenation of `List.ofFn (f n (blocks x i))`
(`ofFn_blocks_symm`, the hypothesis on `F`). -/
theorem Easy.prod {𝓕 : FunFamily} (h : 𝓕.Easy) (q : PolyExpr) : (𝓕.prod q).Easy := by
  obtain ⟨F, hF, hFx⟩ := h
  obtain ⟨F', hF', hspec⟩ := OneWay.exists_prodEval hF 𝓕.inLen q
  refine ⟨F', hF', fun n x => ?_⟩
  rw [NUPPT.advInput_eq, hspec, prod_f, ofFn_blocks_symm]
  congr 2
  funext i
  have hb : (fun j => x (finProdFinEquiv (i, j))) = blocks (q.eval n) (𝓕.inLen.eval n) x i :=
    funext fun j => (blocks_apply _ _ x i j).symm
  rw [OneWay.prodFun_apply, ← NUPPT.advInput_eq, hb]
  exact hFx n (blocks (q.eval n) (𝓕.inLen.eval n) x i)

end FunFamily

/-! ## Yao's parameters and the concrete one-call reduction -/

/-- The number of blocks `m = 2 n q(n)` of [PS10, §2.4.3] ("we pick `m = 2nq(n)`"), as a
syntactic polynomial. -/
def yaoBlocks (q : PolyExpr) : PolyExpr := .mul (.const 2) (.mul .var q)

/-- The number of repetitions `T = 2 n m(n) n^c` of the one-call inverter [PS10, §2.4.3, the
definition of `A`]: the text's `2nm²p(n)` with `p(n) = n^c` and one factor `m` saved by the
threshold `θ = μ₀/(2m)` of `OneWay.yao_amplification_exp`. -/
def yaoRounds (q : PolyExpr) (c : ℕ) : PolyExpr :=
  .mul (.const 2) (.mul .var (.mul (yaoBlocks q) (.pow .var c)))

/-- `m(n) = 2 n q(n)`. -/
@[simp] theorem eval_yaoBlocks (q : PolyExpr) (n : ℕ) : (yaoBlocks q).eval n = 2 * (n * q.eval n) :=
  rfl

/-- `T(n) = 2 n m(n) n^c`. -/
@[simp] theorem eval_yaoRounds (q : PolyExpr) (c : ℕ) (n : ℕ) :
    (yaoRounds q c).eval n = 2 * (n * ((yaoBlocks q).eval n * n ^ c)) := rfl

/-- `m(n)` is positive for `n ≥ 1` and positive `q`. -/
theorem yaoBlocks_pos (q : PolyExpr) (hq : ∀ n, 0 < q.eval n) {n : ℕ} (hn : 0 < n) :
    0 < (yaoBlocks q).eval n := by
  simp only [eval_yaoBlocks]
  exact Nat.mul_pos (by norm_num) (Nat.mul_pos hn (hq n))

namespace OneWay

/-- **One-call planting reduction** (lemma C2 of the Chapter 2 inventory, the concrete
content of [PS10, Theorem 35.2]): for every fixed position `i`, the inverter that samples
fresh inputs `xs`, plants the challenge `y` at position `i` of `(f(x₁), …, f(x_q))`, calls `B`
and returns the `i`-th component of the answer (`yaoTry` at the fixed position `i`) inverts
`f` with at least the probability with which `B` inverts `prodFun f q`. [PS10, Theorem 35.2,
proof]; the text's test "`f(a) = u`" is unnecessary for the inequality.

**Proof sketch.** In the planted experiment `(x, xs, r)` the tuple `update xs i x` is uniform
(`OneWay.uprob_update`), so the planted experiment is the direct-product experiment with the
answer projected to position `i`; an inverse of the whole tuple inverts every coordinate
(`uprob_mono`). -/
theorem invProb_prodFun_le_yaoTry {α β ρ : Type*} [Fintype α] [Nonempty α] [DecidableEq β]
    [Fintype ρ] {q : ℕ} (f : α → β) (B : (Fin q → β) → ρ → (Fin q → α)) (i : Fin q) :
    invProb (prodFun f q) B ≤ invProb f fun y c => yaoTry f B y (i, c) := by
  simp only [invProb_def]
  have h := uprob_update (α := α) (ρ := ρ) i fun xs r => f (B (prodFun f q xs) r i) = f (xs i)
  simp only [prodFun_update, Function.update_self] at h
  simp only [yaoTry_eq]
  rw [h]
  apply uprob_mono
  rintro ⟨xs, r⟩ hxs
  simpa only [prodFun_apply] using congrFun hxs i

end OneWay

/-- Polynomial times `2^{-n}` is eventually below one. -/
private theorem eventually_poly_mul_two_pow_lt_one (p : PolyExpr) :
    ∃ n₀, ∀ n ≥ n₀, (p.eval n : ℝ) * (2 : ℝ)⁻¹ ^ n < 1 := by
  obtain ⟨C, e, hCe⟩ := p.eval_le
  have hneg : Negligible fun n => ((C * 2 ^ e : ℕ) : ℝ) * ((n : ℝ) ^ e * (2 : ℝ)⁻¹ ^ n) :=
    (negligible_two_pow_neg.mul_pow e).const_mul _
  have hμ : Negligible fun n => (p.eval n : ℝ) * (2 : ℝ)⁻¹ ^ n := by
    refine hneg.mono ⟨1, fun n hn => ?_⟩
    rw [abs_of_nonneg (by positivity), abs_of_nonneg (by positivity)]
    have h1 : (p.eval n : ℝ) ≤ (C : ℝ) * ((n : ℝ) + 1) ^ e := by exact_mod_cast hCe n
    have h2 : ((n : ℝ) + 1) ^ e ≤ (2 * (n : ℝ)) ^ e := by
      apply pow_le_pow_left₀ (by positivity)
      have : (1 : ℝ) ≤ n := by exact_mod_cast hn
      linarith
    calc (p.eval n : ℝ) * (2 : ℝ)⁻¹ ^ n ≤ (C : ℝ) * (2 * (n : ℝ)) ^ e * (2 : ℝ)⁻¹ ^ n :=
          mul_le_mul_of_nonneg_right (h1.trans (mul_le_mul_of_nonneg_left h2 (by positivity)))
            (by positivity)
      _ = ((C * 2 ^ e : ℕ) : ℝ) * ((n : ℝ) ^ e * (2 : ℝ)⁻¹ ^ n) := by push_cast; ring
  obtain ⟨n₀, h⟩ := (negligible_iff _).1 hμ 0
  refine ⟨n₀, fun n hn => lt_of_le_of_lt (le_abs_self _) ?_⟩
  simpa using h n hn

/-- `e^{-n} ≤ 2^{-n}`. -/
private theorem exp_neg_le_two_pow (n : ℕ) : Real.exp (-(n : ℝ)) ≤ (2 : ℝ)⁻¹ ^ n := by
  have h1 : Real.exp (-(n : ℝ)) = Real.exp (-1) ^ n := by
    rw [← Real.exp_nat_mul]; congr 1; ring
  rw [h1]
  apply pow_le_pow_left₀ (Real.exp_pos _).le
  rw [Real.exp_neg]
  have := Real.add_one_le_exp (1 : ℝ)
  exact inv_anti₀ (by norm_num) (by linarith)

/-- **Parameter instantiation** [PS10, §2.4.3, Claim 38.2 of the inventory]: with
`m(n) = 2nq(n)` blocks (`yaoBlocks q`) and `T(n) + 1 = 2nm(n)n^c + 1` repetitions
(`yaoRounds q c`), for all large `n` and every `f`, `B` such that `B` inverts `prodFun f (m n)`
with probability at least `1/n^c`, `yaoInverter f B (T n + 1)` inverts `f` with probability
exceeding `1 - 1/q(n) + (T(n) + 1)·2^{-n}` (the margin is the statistical term of the
rejection-sampled positions that `weak_to_strong` subtracts). The concrete inequality is
`OneWay.yao_amplification_exp` [Gar26, Theorem 2.1].

**Deviation:** the text takes `T = 2nm²p(n)` and the threshold `1/(2m²p(n))`; with the
threshold `μ₀/(2m)` of `yao_amplification_exp` one factor `m` is saved. The statistical margin
is absent from the text (exact sampling of `i ← [m]`).

**Proof sketch.** Apply `OneWay.yao_amplification_exp` with `α' := 1/q(n) ≤ 1`, `q := m(n)`
(so `α' m(n) = 2n`), `μ₀ := 1/n^c`, `T' := T(n) + 1` (so `μ₀ T' ≥ 2n m(n)`); it needs
`2e^{-n} < 1/n^c` and yields `invProb f (yaoInverter …) ≥ 1 - 1/(2q(n)) - e^{-n}`. Both this
and the tail bound `e^{-n} + (T(n) + 1) 2^{-n} < 1/(2q(n))` follow from `e^{-n} ≤ 2^{-n}` and
`eventually_poly_mul_two_pow_lt_one` (polynomial times `2^{-n}` is negligible,
`negligible_two_pow_neg`, `Negligible.mul_pow`). `NeZero (m n)` is `yaoBlocks_pos`. -/
theorem claim_38_2 (q : PolyExpr) (hq : ∀ n, 0 < q.eval n) (c : ℕ) :
    ∃ n₀, ∀ n ≥ n₀, ∀ {α β ρ : Type} [Fintype α] [Inhabited α] [DecidableEq β] [Fintype ρ]
      [Nonempty ρ] (f : α → β) (B : (Fin ((yaoBlocks q).eval n) → β) → ρ → (Fin ((yaoBlocks q).eval n) → α)),
      1 / (n : ℝ) ^ c ≤ invProb (OneWay.prodFun f ((yaoBlocks q).eval n)) B →
      1 - 1 / (q.eval n : ℝ) + ((yaoRounds q c).eval n + 1) * (2 : ℝ)⁻¹ ^ n <
        invProb f (OneWay.yaoInverter f B ((yaoRounds q c).eval n + 1)) := by
  obtain ⟨n₁, h₁⟩ := eventually_poly_mul_two_pow_lt_one (.mul (.const 2) (.pow .var c))
  obtain ⟨n₂, h₂⟩ := eventually_poly_mul_two_pow_lt_one
    (.mul (.add (yaoRounds q c) (.const 2)) (.mul (.const 2) q))
  refine ⟨max 1 (max n₁ n₂), fun n hn => ?_⟩
  set m : ℕ := (yaoBlocks q).eval n with hm
  set T : ℕ := (yaoRounds q c).eval n with hT
  intro α β ρ _ _ _ _ _ f B hμ
  have hn1 : 1 ≤ n := le_of_max_le_left hn
  have hn1R : (1 : ℝ) ≤ n := by exact_mod_cast hn1
  have hqR : (1 : ℝ) ≤ q.eval n := by exact_mod_cast hq n
  have hexp := exp_neg_le_two_pow n
  have hb := h₁ n (le_of_max_le_left (le_of_max_le_right hn))
  have hc := h₂ n (le_of_max_le_right (le_of_max_le_right hn))
  simp only [PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_pow, PolyExpr.eval_var,
    PolyExpr.eval_add] at hb hc
  push_cast at hb hc
  have hμ₀ : 2 * Real.exp (-(n : ℝ)) < 1 / (n : ℝ) ^ c := by
    rw [lt_div_iff₀ (by positivity)]
    nlinarith [pow_pos (show (0 : ℝ) < 2⁻¹ by norm_num) n, pow_pos (show (0:ℝ) < n by linarith) c]
  haveI : NeZero m := ⟨(yaoBlocks_pos q hq hn1).ne'⟩
  have hmR : (m : ℝ) = 2 * (n * q.eval n) := by rw [hm, eval_yaoBlocks]; push_cast; ring
  have hTR : (T : ℝ) = 2 * (n * (m * (n : ℝ) ^ c)) := by rw [hT, eval_yaoRounds]; push_cast; ring
  have hα₁ : 1 / (q.eval n : ℝ) ≤ 1 := by rw [div_le_one (by linarith)]; exact hqR
  have hq' : 2 * (n : ℝ) ≤ 1 / (q.eval n : ℝ) * (m : ℝ) := by
    have : 1 / (q.eval n : ℝ) * (2 * (n * q.eval n)) = 2 * n := by field_simp
    rw [hmR, this]
  have hT' : 2 * (n : ℝ) * (m : ℝ) ≤ 1 / (n : ℝ) ^ c * ((T + 1 : ℕ) : ℝ) := by
    push_cast
    rw [hTR]
    have hpos : (0 : ℝ) < (n : ℝ) ^ c := by positivity
    have : 1 / (n : ℝ) ^ c * (2 * (n * (m * (n : ℝ) ^ c)) + 1) = 2 * n * m + 1 / (n : ℝ) ^ c := by
      field_simp
    rw [this]
    linarith [show 0 < 1 / (n : ℝ) ^ c by positivity]
  have hmain := OneWay.yao_amplification_exp f B (n := n) (α' := 1 / (q.eval n : ℝ))
    (μ₀ := 1 / (n : ℝ) ^ c) (T + 1) hα₁ hq' hT' hμ₀ hμ
  have htail : Real.exp (-(n : ℝ)) + ((T : ℝ) + 1) * (2 : ℝ)⁻¹ ^ n < 1 / (q.eval n : ℝ) / 2 := by
    have hT0 : (0 : ℝ) ≤ T := Nat.cast_nonneg _
    have h2 : (0 : ℝ) < (2 : ℝ)⁻¹ ^ n := by positivity
    rw [lt_div_iff₀ (by norm_num), lt_div_iff₀ (by linarith)]
    nlinarith
  linarith

/-! ## Hardness amplification -/

/-- The block bijection of this file is the one of `OneWayLemmas`/`OneWayYao`. -/
private theorem blocks_eq_blocksE (q ℓ : ℕ) : FunFamily.blocks q ℓ = OneWay.blocksE q ℓ :=
  (OneWay.blocksE_eq q ℓ).symm

/-- **Yao's hardness amplification** [PS10, Theorem 35.1]: for every weak one-way function
`𝓕` there is a polynomial `m` (the proof takes `m(n) = 2nq(n)`, `q` the polynomial of weak
one-wayness) such that the direct product `𝓕.prod m`, `f'(x₁, …, x_{m(n)}) = (f(x₁), …,
f(x_{m(n)}))`, is strongly one-way.

**Deviation:** `WeakOneWay`: `0 < q n` made explicit; Theorem 35.1 with the text's
`m = 2nq(n)` and a rejection-sampled position (statistical term absorbed). The direct product
is a family at parameter `n` whose adversaries receive `1^n` (module docstring); the text's
`T = 2nm²p(n)` repetitions become `T(n) + 1`, `T(n) = 2nm(n)n^c` (`yaoRounds`).

**Proof sketch.** Let `q_w` be the polynomial of `h.hard` and `m := yaoBlocks q_w`
(`m(n) = 2nq_w(n)`). *Easy:* `FunFamily.Easy.prod`. *Hard:* fix `A' : NUPPT` and suppose
`fun n => (𝓕.prod m).invProbAt A' n` is not negligible; `not_negligible_iff` gives `c` with
`1/n^c ≤ (𝓕.prod m).invProbAt A' n` for infinitely many `n` (the function is nonnegative,
`invProbAt_nonneg`). Put `T := yaoRounds q_w c`.

*The reduction `A`* (Algorithm 38.5 repeated) is the machine of `OneWay.exists_yaoReduction`
(`TCSlib.Cryptography.Asymptotic.OneWayYao`, sub-machines in `OneWayLemmas`), applied to the
evaluator `F` of `h.easy` and to `A'`. It is `NUPPT.ofPolyTime` of the loop
`YaoMachine.yaoRaw'` (`Complexity.polyTimeComputable_iterateFind`) with coins
`(T + 1)·ρ`, `ρ(n) = n·m(n) + m(n)·inLen(n) + A'.coins(n)` the coins of one round, and advice
`⟨A'.advice n, 1^{kk}⟩`, `kk = kkOf (m n) = ⌊log₂ m(n)⌋ + 1` (so `m(n) < 2^{kk} ≤ 2m(n)`).
Round `t` consumes the `t`-th block of `ρ(n)` coins: it reads `n·kk` of its `n·m(n)` position
bits and samples the
position `i ← [m(n)]` by rejection (`n` trials of `kk` bits, D10), evaluates `f` on the `m(n)`
fresh inputs, plants `y` at block `i`, calls `A'` on the planted tuple, takes block `i` of the
answer padded with `true` to `inLen(n)` bits (the total inverter `OneWay.yaoB`), and tests
`f(z_i) = y`; the machine returns the first success and `1^{inLen n}` on exhaustion.

*Functional identity.* On `⟨⟨⟨1^n, y⟩, ⟨A'.advice n, 1^{kk}⟩⟩, r⟩` the machine returns
`OneWay.yaoInverter (𝓕.f n) (yaoB … A' n) (T n + 1) y (sampleAll r)` (`YaoMachine.yaoRaw'_layout`),
where `sampleAll r` reads the typed coins of the `T(n) + 1` rounds (position, inputs, coins of
`A'`) off `r`.

*Probability.* Each round's position is within `(1 − m/2^{kk})^n ≤ 2^{-n}` of uniform
(`statClose_rejectionSample`); `YaoMachine.statClose_sampleAll` and
`StatClose.abs_uprob_sub_le_prod` give, for `n ≥ 1`,
`𝓕.invProbAt A n ≥ invProb (𝓕.f n) (yaoInverter (𝓕.f n) (yaoB … A' n) (T n + 1)) − (T n + 1)·2^{-n}`
(`exists_yaoReduction`).

*Conclusion.* `yaoB` inverts the direct product at least as often as `A'` (when `A'`'s answer
decodes, `yaoB` returns its blocks: `invProbAt_prod_eq`, `NUPPT.inverter_eq_some_iff`,
`OneWay.padTrue_drop_ofFn`), so at the infinitely many `n` with
`1/n^c ≤ (𝓕.prod m).invProbAt A' n`, also `1/n^c ≤ invProb (prodFun (𝓕.f n) (m n)) (yaoB … A' n)`.
There `claim_38_2` (which packages `OneWay.yao_amplification_exp` with `α' = 1/q_w(n)`,
`μ₀ = 1/n^c`, `T' = T n + 1`) gives
`invProb (𝓕.f n) (yaoInverter …) > 1 − 1/q_w(n) + (T n + 1)·2^{-n}`, hence
`𝓕.invProbAt A n > 1 − 1/q_w(n)` for infinitely many `n`, contradicting `h.hard` for `A`
(`∃ n₀, ∀ n ≥ n₀, … ≤ 1 − 1/q_w(n)`). -/
theorem weak_to_strong {𝓕 : FunFamily} (h : FunFamily.WeakOneWay 𝓕) :
    ∃ q : PolyExpr, FunFamily.StrongOneWay (𝓕.prod q) := by
  obtain ⟨qw, hqw, hhard⟩ := h.hard
  refine ⟨yaoBlocks qw, h.easy.prod _, fun A' => ?_⟩
  by_contra hneg
  obtain ⟨c, hc⟩ := not_negligible_iff.1 hneg
  obtain ⟨F, hF, hFx⟩ := h.easy
  have hFe_spec : ∀ n (a : Fin (𝓕.inLen.eval n) → Bool),
      F (pairEncode (List.replicate n true) (List.ofFn a)) = List.ofFn (𝓕.f n a) :=
    fun n a => by simpa only [NUPPT.advInput_eq] using hFx n a
  have hm : ∀ n, 1 ≤ n → 0 < (yaoBlocks qw).eval n := fun n hn => yaoBlocks_pos qw hqw hn
  -- the reduction machine of Algorithm 38.5
  obtain ⟨A, hA⟩ := OneWay.exists_yaoReduction 𝓕.inLen 𝓕.outLen (yaoBlocks qw) (yaoRounds qw c)
    𝓕.f hF hFe_spec A' hm
  obtain ⟨n₀, hn₀⟩ := hhard A
  obtain ⟨n₁, hn₁⟩ := claim_38_2 qw hqw c
  obtain ⟨n, hn, hlow⟩ := hc (max 1 (max n₀ n₁))
  have hn1 : 1 ≤ n := le_of_max_le_left hn
  have hnn₀ : n₀ ≤ n := le_of_max_le_left (le_of_max_le_right hn)
  have hnn₁ : n₁ ≤ n := le_of_max_le_right (le_of_max_le_right hn)
  rw [abs_of_nonneg (FunFamily.invProbAt_nonneg _ _ _)] at hlow
  -- the total inverter `yaoB` inverts the direct product at least as often as `A'`
  have hB : 1 / (n : ℝ) ^ c ≤ invProb (OneWay.prodFun (𝓕.f n) ((yaoBlocks qw).eval n))
      (OneWay.yaoB 𝓕.inLen 𝓕.outLen (yaoBlocks qw) A' n) := by
    refine hlow.trans ?_
    rw [FunFamily.invProbAt_prod_eq]
    simp only [invProbOpt_def, invProb_def]
    apply uprob_mono
    rintro ⟨xs, r⟩ ⟨xs', hxs', hf⟩
    rw [Option.map_eq_some_iff] at hxs'
    obtain ⟨x'', hx'', rfl⟩ := hxs'
    rw [NUPPT.inverter_eq_some_iff, blocks_eq_blocksE] at hx''
    have hyB : OneWay.yaoB 𝓕.inLen 𝓕.outLen (yaoBlocks qw) A' n
        (OneWay.prodFun (𝓕.f n) ((yaoBlocks qw).eval n) xs) r =
        FunFamily.blocks ((yaoBlocks qw).eval n) (𝓕.inLen.eval n) x'' := by
      funext j
      simp only [OneWay.yaoB_apply]
      rw [hx'', OneWay.padTrue_drop_ofFn]
      exact funext fun k => (FunFamily.blocks_apply _ _ x'' j k).symm
    rw [hyB]
    exact hf
  -- the parameter instantiation and the reduction's bound
  have hclaim := @hn₁ n hnn₁ (Fin (𝓕.inLen.eval n) → Bool) (Fin (𝓕.outLen.eval n) → Bool)
    (A'.Coins n) _ ⟨fun _ => true⟩ _ _ _ (𝓕.f n)
    (OneWay.yaoB 𝓕.inLen 𝓕.outLen (yaoBlocks qw) A' n) hB
  have hred := hA n hn1
  have hup := hn₀ n hnn₀
  unfold FunFamily.invProbAt at hup
  rw [one_div] at hred
  linarith

/-- Two blocks: the encoding of `blocks⁻¹ t` is `ofFn (t 0) ++ ofFn (t 1)`. -/
private theorem ofFn_blocks_two_symm (ℓ : ℕ) (t : Fin 2 → Fin ℓ → Bool) :
    List.ofFn ((FunFamily.blocks 2 ℓ).symm t) = List.ofFn (t 0) ++ List.ofFn (t 1) := by
  rw [FunFamily.ofFn_blocks_symm, OneWay.flatten_ofFn_two]

/-- **The simple security reduction** [PS10, Theorem 35.2]: if `𝓕` is a strong one-way
function then `g(x, y) = (f(x), f(y))`, the direct product with two blocks (input length
`2·inLen(n)`), is a strong one-way function.

**Deviation:** `g` is `𝓕.prod (const 2)` (two blocks of the typed domain), a family at
parameter `n` whose adversaries receive `1^n` rather than `1^{2n}` (module docstring).

**Proof sketch.** *Easy:* `FunFamily.Easy.prod`. *Hard:* fix `A' : NUPPT`. The reduction `A`
of the text ("choose a random `y`, compute `v ← f(y)`, submit `(u, v)` to `A'`, output `a`")
is `NUPPT.ofPolyTime` of an FP function of the raw input `⟨⟨⟨1^n, u⟩, A'.advice n⟩, r⟩` with
coins `add (mul (const 2) inLen) A'.coins` and advice `A'.advice`: cut the first `2·inLen n`
coins as a fresh pair of blocks whose second block is `y` (`polyTimeComputable_pairTakePoly`,
`polyTimeComputable_pairDropPoly` on `⟨1^n, r⟩`; the first block is the overwritten coordinate of
the planting lemma), evaluate `v := F ⟨1^n, y⟩` with the evaluator of `h.easy`, call `A'.output`
on the layout `⟨⟨⟨1^n, u ++ v⟩, A'.advice n⟩, r'⟩` (`PolyTimeComputable.append`,
`polyTimeComputable_layout`, `A'.polyTimeComputable_output`) and return the first `inLen n`
bits of the answer (`polyTimeComputable_pairTakePoly inLen`; no length test is needed for an
upper bound). Functional identity: `A.runAt n u (xs, r') = (A'.runAt n (u ++ f (xs 1)) r').take (inLen n)`
after reindexing `A.Coins n ≃ (Fin 2 → Fin (inLen n) → Bool) × A'.Coins n` (`blocks`,
`Fin.appendEquiv`, `uprob_comp_equiv`, `ofFn_blocks_symm`). Probability: `invProbAt_prod_eq`
writes `(𝓕.prod 2).invProbAt A' n` as `invProbOpt (prodFun (f n) 2) B'`, the planting lemma
`OneWay.invProbOpt_prodFun_le_yaoTryOpt` at position `0` bounds it by the planted experiment, and
`uprob_mono` (a `2·inLen n`-bit answer of `A'` decodes to the first block of `A`'s answer,
`ofFn_block_eq_take_drop`) gives `(𝓕.prod 2).invProbAt A' n ≤ 𝓕.invProbAt A n`; conclude by
`h.hard A` and `Negligible.mono` (`invProbAt_nonneg`). -/
theorem strong_prod_two {𝓕 : FunFamily} (h : FunFamily.StrongOneWay 𝓕) :
    FunFamily.StrongOneWay (𝓕.prod (.const 2)) := by
  classical
  obtain ⟨F, hF, hFx⟩ := h.easy
  refine ⟨h.easy.prod _, fun A' => ?_⟩
  -- the reduction: cut two fresh blocks, evaluate `f` on the second, plant, call `A'`, return
  -- the first block of the answer
  have hcut := NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inCoins
  have hxs := (polyTimeComputable_pairTakePoly (.mul (.const 2) 𝓕.inLen)).comp hcut
  have hr' := (polyTimeComputable_pairDropPoly (.mul (.const 2) 𝓕.inLen)).comp hcut
  have hy2 := (polyTimeComputable_pairDropPoly 𝓕.inLen).comp
    (NUPPT.polyTimeComputable_inParam.pairEncode hxs)
  have hv := hF.comp (NUPPT.polyTimeComputable_inParam.pairEncode hy2)
  have hout := A'.polyTimeComputable_output.comp
    (NUPPT.polyTimeComputable_layout NUPPT.polyTimeComputable_inParam
      (NUPPT.polyTimeComputable_inArg.append hv) NUPPT.polyTimeComputable_inAdvice hr')
  have hG := (polyTimeComputable_pairTakePoly 𝓕.inLen).comp
    (NUPPT.polyTimeComputable_inParam.pairEncode hout)
  let A : NUPPT := NUPPT.ofPolyTime hG (.add (.mul (.const 2) 𝓕.inLen) A'.coins) A'.adv A'.advice
    A'.advice_length
  refine (h.hard A).mono ⟨0, fun n _ => ?_⟩
  rw [abs_of_nonneg (FunFamily.invProbAt_nonneg _ _ _), abs_of_nonneg (FunFamily.invProbAt_nonneg _ _ _)]
  set ℓ := 𝓕.inLen.eval n with hℓ
  set f := 𝓕.f n with hf
  -- the coin bijection `(xs, r') ↦ ⟨xs⟩ ++ r'`
  have hlen : 2 * ℓ + A'.coinLen n = A.coinLen n := by
    simp only [A, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTime]; rfl
  let e : (Fin 2 → Fin ℓ → Bool) × A'.Coins n ≃ A.Coins n :=
    (Equiv.prodCongr (FunFamily.blocks 2 ℓ).symm (Equiv.refl _)).trans
      ((Fin.appendEquiv _ _).trans (Equiv.arrowCongr (finCongr hlen) (Equiv.refl Bool)))
  have hofn : ∀ (xs : Fin 2 → Fin ℓ → Bool) (r' : A'.Coins n),
      List.ofFn (e (xs, r')) = (List.ofFn (xs 0) ++ List.ofFn (xs 1)) ++ List.ofFn r' := by
    intro xs r'
    rw [← ofFn_blocks_two_symm, ← List.ofFn_fin_append]
    exact (List.ofFn_congr hlen (Fin.append ((FunFamily.blocks 2 ℓ).symm xs) r')).symm
  -- the functional identity of the reduction
  have hrun : ∀ (y : Fin (𝓕.outLen.eval n) → Bool) (xs : Fin 2 → Fin ℓ → Bool) (r' : A'.Coins n),
      A.runAt n (List.ofFn y) (e (xs, r')) =
        (A'.runAt n (List.ofFn y ++ List.ofFn (f (xs 1))) r').take ℓ := by
    intro y xs r'
    rw [NUPPT.runAt_eq]
    show (NUPPT.ofPolyTime hG _ _ _ _).runAtL n _ _ = _
    rw [NUPPT.runAtL_ofPolyTime]
    simp only [Function.comp_apply, NUPPT.advInput_eq, NUPPT.inParam_eq, NUPPT.inArg_eq,
        NUPPT.inAdvice_eq,
      NUPPT.inCoins_eq, NUPPT.layout_eq, pairFstD_pairEncode, pairSndD_pairEncode, hofn,
      PolyExpr.eval_mul, PolyExpr.eval_const, List.length_replicate]
    have h2 : (List.ofFn (xs 0) ++ List.ofFn (xs 1)).length = 2 * ℓ := by simp; ring
    rw [List.take_left' h2, List.drop_left' h2,
      List.drop_left' (by simp only [List.length_ofFn]; try exact hℓ)]
    have := hFx n (xs 1)
    simp only [NUPPT.advInput_eq] at this
    rw [this, NUPPT.runAt_eq, NUPPT.runAtL_eq, NUPPT.advInput_eq]
  -- the planting bound
  let B' : (Fin 2 → Fin (𝓕.outLen.eval n) → Bool) → A'.Coins n → Option (Fin 2 → Fin ℓ → Bool) :=
    fun ys r => (A'.inverter n (2 * ℓ) (2 * 𝓕.outLen.eval n)
      ((FunFamily.blocks 2 (𝓕.outLen.eval n)).symm ys) r).map (FunFamily.blocks 2 ℓ)
  have h1 : (𝓕.prod (.const 2)).invProbAt A' n = invProbOpt (OneWay.prodFun f 2) B' :=
    FunFamily.invProbAt_prod_eq 𝓕 (.const 2) A' n
  have h2 := OneWay.invProbOpt_prodFun_le_yaoTryOpt f B' 0
  refine h1.trans_le (h2.trans ?_)
  unfold FunFamily.invProbAt
  simp only [invProbOpt_def]
  rw [← uprob_comp_equiv (Equiv.prodCongr (Equiv.refl _) e)]
  apply uprob_mono
  rintro ⟨x, xs, r'⟩ ⟨x', hx', hfx⟩
  refine ⟨x', ?_, hfx⟩
  simp only [Equiv.prodCongr_apply, Equiv.coe_refl, Prod.map_fst, Prod.map_snd, id_eq]
  rw [Option.map_eq_some_iff] at hx'
  obtain ⟨xs', hxs', rfl⟩ := hx'
  simp only [B', Option.map_eq_some_iff] at hxs'
  obtain ⟨x'', hx'', rfl⟩ := hxs'
  rw [NUPPT.inverter_eq_some_iff, ofFn_blocks_two_symm, Function.update_self,
    Function.update_of_ne (by decide), OneWay.prodFun_apply] at hx''
  rw [NUPPT.inverter_eq_some_iff, hrun, hx'']
  have hblk := OneWay.ofFn_block_eq_take_drop x'' 0
  simp only [Fin.val_zero, Nat.zero_mul, List.drop_zero] at hblk
  rw [← hblk]
  exact congrArg List.ofFn (funext fun j => (FunFamily.blocks_apply _ _ x'' 0 j).symm)

/-- **Strong implies weak** (sanity, [PS10, §2.2, the remark after Definition 28.4]): a strong
one-way function is a weak one-way function with `q = 2`.

**Proof sketch.** Negligibility with `c = 1` gives `invProbAt A n < 1/n ≤ 1/2 = 1 - 1/2` for
all `n ≥ max n₀ 2`. -/
theorem FunFamily.StrongOneWay.weak {𝓕 : FunFamily} (h : 𝓕.StrongOneWay) : 𝓕.WeakOneWay := by
  refine ⟨h.easy, .const 2, fun _ => by simp, fun A => ?_⟩
  obtain ⟨n₀, hn₀⟩ := (negligible_iff _).1 (h.hard A) 1
  refine ⟨max n₀ 2, fun n hn => ?_⟩
  have h1 := hn₀ n (le_of_max_le_left hn)
  have hn2 : (2 : ℝ) ≤ n := by exact_mod_cast le_of_max_le_right hn
  have h2 : 1 / (n : ℝ) ^ 1 ≤ 1 / 2 := by
    rw [pow_one]; exact one_div_le_one_div_of_le (by norm_num) hn2
  simp only [PolyExpr.eval_const, Nat.cast_ofNat]
  linarith [le_abs_self (𝓕.invProbAt A n)]

/-- A machine that returns its argument exists: `A(1^n, y; r) = y` (`ofPolyTimeUniform` of the
argument projection, no coins). -/
private theorem exists_runAt_eq_arg : ∃ A : NUPPT, ∀ n y (r : A.Coins n), A.runAt n y r = y :=
  ⟨NUPPT.ofPolyTimeUniform NUPPT.polyTimeComputable_inArg (.const 0), fun n y r => by
    rw [NUPPT.runAt_eq, NUPPT.runAtL_ofPolyTimeUniform, NUPPT.advInput_eq, ← NUPPT.layout_eq]
    exact NUPPT.inArg_layout _ _ _ _⟩

/-- **A machine that returns its argument inverts the identity with probability one**: if
`A(1^n, y; r) = y` for all `n`, `y`, `r`, then `(ofString id var).invProbAt A n = 1` at every
parameter `n` (the common step of the non-vacuity results below and of
`FunFamily.not_toCollection_oneWay_id`).

**Proof sketch.** By `invProbAt_eq_uprob` the event is that `A(1^n, x)` is the encoding of a
preimage of `x`; it holds for every `(x, r)` with the preimage `x` itself (`ofString_id_f`), so
the probability is `uprob True = 1`. -/
theorem FunFamily.invProbAt_ofString_id_eq_one {A : NUPPT}
    (hA : ∀ n y (r : A.Coins n), A.runAt n y r = y) (n : ℕ) :
    (FunFamily.ofString id .var).invProbAt A n = 1 := by
  rw [FunFamily.invProbAt_eq_uprob]
  have hp : (fun z : (Fin ((FunFamily.ofString id .var).inLen.eval n) → Bool) × A.Coins n =>
      ∃ x', A.runAt n (List.ofFn ((FunFamily.ofString id .var).f n z.1)) z.2 = List.ofFn x' ∧
        (FunFamily.ofString id .var).f n x' = (FunFamily.ofString id .var).f n z.1) =
      fun _ => True := by
    funext z
    refine propext ⟨fun _ => trivial, fun _ => ⟨z.1, ?_, rfl⟩⟩
    rw [hA, FunFamily.ofString_id_f]
  rw [hp, uprob_true]

/-- **The identity is not one-way** (non-vacuity of the adversary class, [PS10, §2.2]): the
machine that returns its argument inverts `FunFamily.ofString id var` with probability one at
every parameter, and the constant `1` is not negligible.

**Proof sketch.** `A := NUPPT.ofPolyTimeUniform polyTimeComputable_inArg (const 0)` returns
`y` on `⟨⟨⟨1^n, y⟩, []⟩, r⟩` (`runAtL_ofPolyTimeUniform`, `inArg_layout`), so
`invProbAt … A n = 1` (`FunFamily.invProbAt_ofString_id_eq_one`); `Negligible (fun _ => 1)`
fails at `c = 0`. -/
theorem not_strongOneWay_id : ¬ FunFamily.StrongOneWay (FunFamily.ofString id .var) := by
  intro h
  obtain ⟨A, hA⟩ := exists_runAt_eq_arg
  obtain ⟨n₀, hn₀⟩ := (negligible_iff _).1 (h.hard A) 0
  have := hn₀ n₀ le_rfl
  simp [FunFamily.invProbAt_ofString_id_eq_one hA] at this

/-- **The identity is not weakly one-way** (non-vacuity of [PS10, Definition 28.4]; gate 03b,
finding 13): the machine that returns its argument inverts `FunFamily.ofString id var` with
probability `1 > 1 − 1/q(n)` at every parameter, for every positive polynomial `q`.

**Proof sketch.** As `not_strongOneWay_id`: `invProbAt … A n = 1`
(`FunFamily.invProbAt_ofString_id_eq_one`), and `1 ≤ 1 − 1/q(n₀)` contradicts `q(n₀) > 0`. -/
theorem not_weakOneWay_id : ¬ FunFamily.WeakOneWay (FunFamily.ofString id .var) := by
  intro h
  obtain ⟨q, hq, hhard⟩ := h.hard
  obtain ⟨A, hA⟩ := exists_runAt_eq_arg
  obtain ⟨n₀, hn₀⟩ := hhard A
  have h1 := hn₀ n₀ le_rfl
  rw [FunFamily.invProbAt_ofString_id_eq_one hA] at h1
  have h2 : (0 : ℝ) < 1 / (q.eval n₀ : ℝ) := one_div_pos.mpr (Nat.cast_pos.mpr (hq n₀))
  linarith

/-- **The identity is not worst-case one-way** (non-vacuity of [PS10, Definition 26.1], `1^n`
form; gate 03b, finding 13): the machine that returns its argument inverts
`FunFamily.ofString id var` on every input with probability one.

**Proof sketch.** On `⟨1^n, x⟩` the machine returns `x`, which the inverter decodes to `x`
(`NUPPT.inverter_eq_some_iff`), a preimage of `x` (`ofString_id_f`); so the event holds for
every coin string and its probability is `uprob True = 1`. -/
theorem not_worstCaseOneWay_id : ¬ FunFamily.WorstCaseOneWay (FunFamily.ofString id .var) := by
  intro h
  obtain ⟨A, hA⟩ := exists_runAt_eq_arg
  refine h.hard ⟨A, fun n x => ?_⟩
  have hp : (fun r : A.Coins n => ∃ x', A.inverter n ((FunFamily.ofString id .var).inLen.eval n)
      ((FunFamily.ofString id .var).outLen.eval n) ((FunFamily.ofString id .var).f n x) r =
        some x' ∧ (FunFamily.ofString id .var).f n x' = (FunFamily.ofString id .var).f n x) =
      fun _ => True := by
    funext r
    refine propext ⟨fun _ => trivial, fun _ => ⟨x, ?_, rfl⟩⟩
    rw [NUPPT.inverter_eq_some_iff, hA, FunFamily.ofString_id_f]
  rw [hp, uprob_true]

/-! ## One-way permutations -/

/-- A family of permutations of `{0,1}^n` (the single one-way permutation of
[PS10, Theorems 79.4 and 126.4]; the *collection* of permutations of [PS10, Definition 55.1] is
`PermCollection` in `Asymptotic/Collections.lean`). -/
structure PermFamily where
  /-- The permutation at parameter `n`. -/
  f : ∀ n, (Fin n → Bool) ≃ (Fin n → Bool)

/-- The function family underlying a permutation family: `inLen = outLen = var`. -/
def PermFamily.toFunFamily (P : PermFamily) : FunFamily where
  inLen := .var
  outLen := .var
  f n := P.f n

/-- `P` is a *one-way permutation* when its underlying family is strongly one-way
[PS10, §2.10, Definition 55.1, single-function form, as used in Theorems 79.4 and 126.4]. -/
def OneWayPermutation (P : PermFamily) : Prop := P.toFunFamily.StrongOneWay

/-- The defining equivalence: `OneWayPermutation P ↔ P.toFunFamily.StrongOneWay`. -/
theorem oneWayPermutation_iff (P : PermFamily) :
    OneWayPermutation P ↔ P.toFunFamily.StrongOneWay := Iff.rfl

/-- **The evaluator of a one-way permutation**: a polynomial-time `F` with `F⟨1^n, x⟩ = f_n(x)`. -/
theorem OneWayPermutation.evaluator {P : PermFamily} (hP : OneWayPermutation P) :
    ∃ F : List Bool → List Bool, PolyTimeComputable F ∧
      ∀ n (x : Fin n → Bool), F (NUPPT.advInput n (List.ofFn x)) = List.ofFn (P.f n x) :=
  (FunFamily.easy_iff _).1 hP.easy

/-- The function of a permutation family is the permutation. -/
@[simp] theorem PermFamily.toFunFamily_f (P : PermFamily) (n : ℕ) (x : Fin n → Bool) :
    P.toFunFamily.f n x = P.f n x := rfl

/-- The input length of `P.toFunFamily` at `n` is `n`. -/
theorem PermFamily.toFunFamily_inLen_eval (P : PermFamily) (n : ℕ) :
    P.toFunFamily.inLen.eval n = n := rfl

/-- The output length of `P.toFunFamily` at `n` is `n`. -/
theorem PermFamily.toFunFamily_outLen_eval (P : PermFamily) (n : ℕ) :
    P.toFunFamily.outLen.eval n = n := rfl

/-- **The domain of `P.toFunFamily` is `{0,1}^n`**: `{0,1}^{inLen(n)} ≃ {0,1}^n` (identity). -/
def PermFamily.toFunFamily_domEquiv (P : PermFamily) (n : ℕ) :
    (Fin (P.toFunFamily.inLen.eval n) → Bool) ≃ (Fin n → Bool) := Equiv.refl _

/-- **The range of `P.toFunFamily` is `{0,1}^n`**: `{0,1}^{outLen(n)} ≃ {0,1}^n` (identity). -/
def PermFamily.toFunFamily_codEquiv (P : PermFamily) (n : ℕ) :
    (Fin (P.toFunFamily.outLen.eval n) → Bool) ≃ (Fin n → Bool) := Equiv.refl _

/-- The domain equivalence keeps the string. -/
theorem PermFamily.toFunFamily_domEquiv_ofFn (P : PermFamily) (n : ℕ)
    (x : Fin (P.toFunFamily.inLen.eval n) → Bool) :
    List.ofFn (P.toFunFamily_domEquiv n x) = List.ofFn x := rfl

/-- The inverse domain equivalence keeps the string. -/
theorem PermFamily.toFunFamily_domEquiv_symm_ofFn (P : PermFamily) (n : ℕ) (x : Fin n → Bool) :
    List.ofFn ((P.toFunFamily_domEquiv n).symm x) = List.ofFn x := rfl

/-- The range equivalence keeps the string. -/
theorem PermFamily.toFunFamily_codEquiv_ofFn (P : PermFamily) (n : ℕ)
    (y : Fin (P.toFunFamily.outLen.eval n) → Bool) :
    List.ofFn (P.toFunFamily_codEquiv n y) = List.ofFn y := rfl

/-- Through the equivalences `P.toFunFamily` is `P`: `codEquiv (f_n x) = P.f n (domEquiv x)`. -/
theorem PermFamily.toFunFamily_f_domEquiv (P : PermFamily) (n : ℕ)
    (x : Fin (P.toFunFamily.inLen.eval n) → Bool) :
    P.toFunFamily_codEquiv n (P.toFunFamily.f n x) = P.f n (P.toFunFamily_domEquiv n x) := rfl

end TCSlib.Cryptography

run_cmd Lean.logInfo "CP2-EOF"
