import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Circular
open Lean in
run_cmd do
  for n in [`TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters.neZero_columns,
            `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.fheView_fst,
            `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.fheView_snd] do
    let some ci := (← getEnv).find? n | logInfo m!"KIND {n} absent"
    let k := match ci with | .thmInfo _ => "theorem" | .defnInfo _ => "def" | _ => "other"
    logInfo m!"KIND {n} {k} instance={Lean.Meta.isInstanceCore (← getEnv) n}"
