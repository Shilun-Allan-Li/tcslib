# Immutable BobViewShape handoff v6

One generic OT-hybrid encoded Bob-view theorem, adapted from the lead's checked probe.
Only rounds, move order, Bob's zero coins and Alice's sender equation are assumptions.
Bob's actual singleton-history next function supplies the reply equation reflexively.
The theorem covers arbitrary raw input words and the actual typed hybrid tapes.

Final exact-source normal check has zero errors/warnings. All four clean-source seals,
controls and complete sixteen-owned-module trace pass. No admissions/nonstandard axioms.
Source and matching completed olean are included; TwoMoveViews remains lead-owned.
No child commits or exchange delivery were performed.
