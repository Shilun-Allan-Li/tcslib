# Immutable CoordinateSwap handoff v5

The generic matched-coordinate law is complete. swap/equiv exchange a partial matching while
retaining its control value and every unmatched padded coordinate. Values need no equality
or distinctness assumption. acceptProb_swap and transported acceptProb_fill reuse existing
probability relabeling and ignored-coordinate contracts. Concrete addresses, coordinate
splits, fill identity and cryptographic sampler identity remain b/c-owned.

Normal05, all four full-file seals and style pass. Full fifteen-owned-module trace has no
admissions/nonstandard axioms; all sixty final owned-module seal variants pass. Controls
behave as expected. Complete failed sources/logs and search/overlap notes are retained.
Source and matching completed olean are included; no child commits or exchange delivery.
