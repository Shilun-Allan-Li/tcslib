/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RowFromCoins

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Polynomial-time garbled tables from coin words

The total table adapter reads an encoded argument list. It computes the table only for
arity at most two, using three arbitrary constant assignment enumerations; higher arities
return the empty word. Thus malformed descriptions cannot induce exponential enumeration.

## Main definitions

* `TablesFromCoins.tableWord`: the encoded row list of one raw gate description.

## Main results

* `TablesFromCoins.tableWord_poly`: polynomial time on every string.
* `TablesFromCoins.tableWord_garbledTable`: identification through a row-level contract.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January
  2010, Protocol 162.6 (at most four encrypted rows per gate).
-/

namespace TCSlib.Cryptography.SecureComputation.YaoHybridProof.TablesFromCoins

open Complexity Turing BoolCircuit TCSlib.Cryptography.EncodingMachines

/-- The encoded row list of the supplied raw gate data for arity at most two; other
arities return `[]`. The finite assignment list is a constant for each arity.
[PS10, Protocol 162.6] -/
noncomputable def tableWord (E₁ E₂ : List Bool → List Bool)
    (width bound inputs gate : List Bool → ℕ) (kind args coins : List Bool → List Bool)
    (z : List Bool) : List Bool :=
  let count := (BinArith.decWords (args z)).length
  let arity := min count 2
  if count ≤ 2 then BinArith.encWords
    ((Finset.univ : Finset (Fin arity → Bool)).toList.map fun a =>
      RowFromCoins.rowWord E₁ E₂ width bound inputs gate kind args coins arity a z)
  else []

/-- `tableWord ... z` is the encoded constant-enumeration row list at `min count 2`
when the decoded argument count is at most two, and is `[]` otherwise. -/
theorem tableWord_eq (E₁ E₂ : List Bool → List Bool)
    (width bound inputs gate : List Bool → ℕ) (kind args coins : List Bool → List Bool)
    (z : List Bool) :
    tableWord E₁ E₂ width bound inputs gate kind args coins z =
      let count := (BinArith.decWords (args z)).length
      let arity := min count 2
      if count ≤ 2 then BinArith.encWords
        ((Finset.univ : Finset (Fin arity → Bool)).toList.map fun a =>
          RowFromCoins.rowWord E₁ E₂ width bound inputs gate kind args coins arity a z)
      else [] := rfl

/-- The total table adapter is polynomial-time if the evaluators, coin/kind/argument words,
and unary numeric maps are polynomial-time. [PS10, Protocol 162.6]

**Proof sketch.** Count the argument words with the public polynomial-time list counter.
Cap the enumeration arity at two, so the enumeration is one of three fixed finite lists.
Every row is computed by the polynomial-time raw row machine. The finite-list assembly
contract gives the encoded table; a unary length test returns the empty word when the
uncapped count is larger than two. This covers all malformed input strings. -/
theorem tableWord_poly {E₁ E₂ : List Bool → List Bool} (hE₁ : PolyTimeComputable E₁)
    (hE₂ : PolyTimeComputable E₂) {width bound inputs gate : List Bool → ℕ}
    {kind args coins : List Bool → List Bool}
    (hwidth : PolyTimeComputable fun z => List.replicate (width z) true)
    (hbound : PolyTimeComputable fun z => List.replicate (bound z) true)
    (hinputs : PolyTimeComputable fun z => List.replicate (inputs z) true)
    (hgate : PolyTimeComputable fun z => List.replicate (gate z) true)
    (hkind : PolyTimeComputable kind) (hargs : PolyTimeComputable args)
    (hcoins : PolyTimeComputable coins) :
    PolyTimeComputable (tableWord E₁ E₂ width bound inputs gate kind args coins) := by
  -- Read the count in unary, then cap the enumerated arity at two.
  have hcount : PolyTimeComputable fun z =>
      List.replicate (BinArith.decWords (args z)).length true := by
    convert BinArith.polyTimeComputable_countW.comp hargs using 1
    funext z
    rw [Function.comp_apply, BinArith.countW_eq]
  have hcap := unaryMin_poly hcount (unaryConst_poly 2)
  have htable := Garbling.smallArityTable_poly
    (fun z => min (BinArith.decWords (args z)).length 2)
    (fun l => (Finset.univ : Finset (Fin l → Bool)).toList)
    (fun l a => RowFromCoins.rowWord E₁ E₂ width bound inputs gate kind args coins l a)
    (fun _ => Nat.min_le_right _ _)
    (eqTest_poly hcap (unaryConst_poly 0)) (eqTest_poly hcap (unaryConst_poly 1))
    (fun l _ a => RowFromCoins.rowWord_poly hE₁ hE₂ hwidth hbound hinputs hgate
      hkind hargs hcoins l a)
  -- The uncapped count controls the malformed-description fallback.
  convert polyTimeComputable_ite (leTest_poly hcount (unaryConst_poly 2)) htable
    (polyTimeComputable_const []) using 1
  funext z
  simp only [tableWord_eq, decide_eq_true_eq]

/-- On a genuine argument-word list, if every raw row equals the corresponding garbled
row after the seed permutation, the table adapter equals the encoded garbled table.
[PS10, Protocol 162.6]

**Proof sketch.** Canonical decoding identifies the argument count, so the cap and guard
leave the genuine arity unchanged. The fixed enumeration is then exactly the public
garbled-table enumeration, and the supplied row identity agrees at every enumerated row. -/
theorem tableWord_garbledTable (E₁ E₂ : List Bool → List Bool)
    (width bound inputs gate : List Bool → ℕ) (kind args coins : List Bool → List Bool)
    (z : List Bool) (C : DAGCircuit (inputs z))
    (s : GarbleSeed C (Fin (width z) → Bool)
      ((Fin (width z) → Bool) × (Fin (width z) → Bool)))
    (i : Fin C.gates.length) (hfan : (C.gates[i]).args.length ≤ 2)
    (hargs : args z = BinArith.encWords ((C.gates[i]).args.map fun v => List.replicate v true))
    (hrow : ∀ a,
      RowFromCoins.rowWord E₁ E₂ width bound inputs gate kind args coins
          (C.gates[i]).args.length a z =
        garbledRow (nestedSpecial E₁ E₂ (width z)) C s i (s.2.2 i a)) :
    tableWord E₁ E₂ width bound inputs gate kind args coins z =
      BinArith.encWords (garbledTable (nestedSpecial E₁ E₂ (width z)) C s i) := by
  have hcount : (BinArith.decWords (args z)).length = (C.gates[i]).args.length := by
    rw [hargs, BinArith.decWords_encWords, List.length_map]
  have hcap : min (BinArith.decWords (args z)).length 2 = (C.gates[i]).args.length := by
    rw [hcount, min_eq_left hfan]
  let emit (l : ℕ) := BinArith.encWords
    ((Finset.univ : Finset (Fin l → Bool)).toList.map fun a =>
      RowFromCoins.rowWord E₁ E₂ width bound inputs gate kind args coins l a z)
  rw [tableWord_eq]
  change (if (BinArith.decWords (args z)).length ≤ 2 then
    emit (min (BinArith.decWords (args z)).length 2) else []) = _
  rw [if_pos (by rw [hcount]; exact hfan), hcap]
  dsimp only [emit]
  rw [garbledTable_eq]
  apply congrArg BinArith.encWords
  apply List.map_congr_left
  intro a _
  exact hrow a

end TCSlib.Cryptography.SecureComputation.YaoHybridProof.TablesFromCoins
