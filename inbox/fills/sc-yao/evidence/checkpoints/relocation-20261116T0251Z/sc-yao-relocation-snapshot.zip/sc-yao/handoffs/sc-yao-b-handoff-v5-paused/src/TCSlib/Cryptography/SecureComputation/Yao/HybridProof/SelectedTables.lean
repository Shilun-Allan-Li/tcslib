/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedPlan
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Lengths

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Exact selected-key table and view reconstruction

Every challenge message, record and surrounding field is fixed before the sampled key and
nonce vector are supplied. Reconstruction uses every occurrence of the selected inactive
label, including occurrences at gates outside the gate currently switched by the hybrid.
The plaintext-key family is a generic fixed parameter, so the helper cannot see any
particular hybrid's semantic definitions.

## Main definitions

None.

## Main results

* `SelectedTables.record_reconstruct`: exact reconstruction for every sampler seed.
* Complete table and encoded-view reconstruction from the padded slice experiment.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January
  2010, Theorem 163.7 (joint multi-message embedding under one inactive key).
* [LP09] Y. Lindell, B. Pinkas, *A proof of security of Yao's protocol for two-party
  computation*, Journal of Cryptology 22(2), 2009, pp. 161–188.
-/

namespace TCSlib.Cryptography.SecureComputation.YaoHybridProof.SelectedTables

open Complexity Turing BoolCircuit TCSlib.Cryptography

section Joint

variable {L L₂ : ℕ → ℕ}
  (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L n) → Bool))
  (G₁ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool))
  (G₂ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L₂ n) → Bool))
  (E₁ E₂ : List Bool → List Bool)
  (hG : ∀ n (s x : Fin n → Bool),
    List.ofFn (G n s x) = List.ofFn (G₁ n s x) ++ List.ofFn (G₂ n s x))
  (hGE₁ : ∀ n (s x : Fin n → Bool), E₁ (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (G₁ n s x))
  (hGE₂ : ∀ n (s x : Fin n → Bool), E₂ (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (G₂ n s x))

include hG hGE₁ hGE₂ in
/-- Every row record reconstructs precisely the nested encryption using the filled seed's
argument keys and nonce pair and the fixed plaintext key, for every challenge key and nonce
vector. The capacity covers the complete all-gate occurrence list. [PS10, Theorem 163.7]

**Proof sketch.** An unselected row retains both its argument-key list and nonce pair, so its
fixed record is already the required row. For a selected argument, its occurrence rank fits
the padded capacity. Reading that slot recovers the row's exact slice shape and precomputed
message. The selected-row reconstruction theorem replaces precisely the argument key and
nonce half described by the filled-seed readers. All gates using the selected key share this
same sampler key while receiving their own independent slot nonce. -/
theorem record_reconstruct {m n : ℕ} (C : DAGCircuit m)
    (rows : (i : Fin C.gates.length) → List (Fin C.gates[i.val].args.length → Bool))
    (s : GarbleSeed C (Fin n → Bool) ((Fin n → Bool) × (Fin n → Bool)))
    (u : Fin C.size) (q : ℕ)
    (o : (i : Fin C.gates.length) → (Fin C.gates[i.val].args.length → Bool) → (Fin n → Bool))
    (hargs : ∀ i : Fin C.gates.length, C.gates[i.val].args.Nodup)
    (hfan : ∀ i : Fin C.gates.length, C.gates[i.val].args.length ≤ 2)
    (hcomplete : ∀ i a, a ∈ rows i)
    (hcap : (GateOccurrences.occurrences C rows s.2.2 u.val).length ≤ q + 1)
    (i : Fin C.gates.length) (a : Fin C.gates[i.val].args.length → Bool)
    (k : Fin n → Bool) (rs : Fin (q + 1) → Fin n → Bool) :
    SliceReconstruction.row E₂ (pairEncode
      (sliceMultiEncDist G n q (SelectedPlan.slotOffset C rows s u q)
        (SelectedPlan.slotLength C rows s u q) (SelectedPlan.slotMessage C rows s u q E₁ o)
          (k, rs)) (SelectedPlan.record C rows s u E₁ E₂ o i a)) =
      (nestedSpecial E₁ E₂ n).enc (argKeys C (SelectedSeed.fill C rows s u q k rs) i a)
        (o i a) ((SelectedSeed.fill C rows s u q k rs).2.1 i a) := by
  cases hsel : GateOccurrences.selectedPosition C.gates[i.val] a u.val with
  | none =>
    rw [SelectedPlan.record_eq, hsel, Option.elim_none, SliceReconstruction.row_fixedRecord,
      SelectedSeed.fill_argKeys_none C rows s u q k rs i a (hargs i) hsel,
      SelectedSeed.fill_nonce, SelectedSeed.nonce_of_none C rows s u.val q rs i a hsel]
  | some p =>
    obtain ⟨hvertex, hbit⟩ :=
      (GateOccurrences.selectedPosition_eq_some_iff _ _ _ (hargs i) p).mp hsel
    have hslot := lt_of_lt_of_le
      (SelectedSeed.slotIndex_lt C rows s.2.2 u.val i a p (hargs i)
        (hcomplete i) hvertex hbit) hcap
    let j : Fin (q + 1) := ⟨SelectedSeed.slotIndex C rows s.2.2 u.val i a p, hslot⟩
    have hpad := SelectedSeed.slotIndex_padded C rows s.2.2 u.val q i a p (hargs i)
      (hcomplete i) hvertex hbit hslot
    have hread := SelectedPlan.slotReaders_of_padded C rows s u q E₁ o j i
      (SelectedSeed.rowIndex C rows s.2.2 i a) p.val hpad
    have hactual := SelectedSeed.rowIndex_actual C rows s.2.2 i a (hcomplete i)
    obtain ⟨hOff, _, hWord⟩ := hread
    have hOff' := hOff.trans (congrArg
      (fun b => SelectedRows.offset n (argKeys C s i b) p.val) hactual)
    have hWord' := hWord.trans (congrArg
      (fun b => SelectedRows.word E₁ n (argKeys C s i b) (o i b) (s.2.1 i b) p.val) hactual)
    have hMsg := (SelectedPlan.slotMessage_ofFn C rows s u q hGE₁ o j).trans hWord'
    have hlen : (argKeys C s i a).length = C.gates[i.val].args.length := by
      simp only [argKeys_eq, List.length_ofFn, Fin.getElem_fin]
    have hks : (argKeys C s i a).length ≤ 2 := by rw [hlen]; exact hfan i
    have hp : p.val < (argKeys C s i a).length := by rw [hlen]; exact p.isLt
    rw [SelectedPlan.record_eq, hsel, Option.elim_some,
      SelectedSeed.fill_argKeys_some C rows s u q k rs i a p (hargs i) hsel,
      SelectedSeed.fill_nonce, SelectedSeed.nonce_of_some C rows s u.val q rs i a p hsel hslot]
    exact SelectedRows.reconstruct G G₁ G₂ E₁ E₂ hG hGE₁ hGE₂ n q (argKeys C s i a)
      (o i a) (s.2.1 i a) p.val j hks hp (SelectedPlan.slotOffset C rows s u q)
      (SelectedPlan.slotLength C rows s u q) (SelectedPlan.slotMessage C rows s u q E₁ o)
      hOff' hMsg k rs

end Joint

end TCSlib.Cryptography.SecureComputation.YaoHybridProof.SelectedTables
