/-
Copyright (c) 2026 Anthropic, PBC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
SPDX-License-Identifier: Apache-2.0

Vendored from [AFM26] anthropics/formal-math (https://github.com/anthropics/formal-math), folder
`3sum-apsp`, file `ThreeSumApsp/Lang/RunsStayInLimits.lean`, at commit e1a4e6508154ea59f030480661590a9fe3018011 (2026-10-05).
Local modifications (see policy.md §2, vendored code, and the repository NOTICE):
* removed the Lean module-system syntax (`module`, `public import`, `@[expose] public section`)
  for compatibility with our v4.25.0 toolchain;
* moved to `TCSlib/Programs/Light/RunsStayInLimits.lean`, with imports remapped;
* namespaces `EndStatement` and `ThreeSumApsp.WordRam` renamed to `WordRAM`, and `ThreeSumApsp` to `Light`, with module names and paths in comments updated;
* added a `## References` section citing [AFM26];
* added the repository-standard `set_option` header.
* added input, output, coin and halving constructs, and threaded output and coin indices
  through the affected syntax, semantics and run witnesses.
The remaining content is unchanged.
-/
import TCSlib.Programs.Light.Syntax
import TCSlib.Programs.Util.List
import Mathlib.Tactic.SplitIfs
import Mathlib.Algebra.Order.Ring.Abs

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Runs stay within their limits

Facts about the semantics of the light language; none of them mentions the compiler.  A state is
bounded if every variable and every cell holds a number of absolute value at most `lim.word`.

* The value of a safe expression in a bounded state is such a number (`Expr.abs_val_le`).
* A run that starts in a bounded state ends in one (`Exec.bounded`): induction on the run.  An
  assignment and a store write the value of a safe expression; a call starts in a frame that holds
  the values of safe expressions and zeros (`bounded_callFrame`, a case of `bounded_frame`).
* A run does not change the cells from `lim.space` on (`Exec.mem_outside`).

The compiler's proof needs the first two because a word of the machine stands for a number only as
long as the number is in the range of words, and the third because its end theorem speaks of all
cells of the memory, also of those that the run may not touch.

## References

* [AFM26] anthropics/formal-math, folder `3sum-apsp`, commit e1a4e650, Apache-2.0: the source of this file.
-/

section

namespace Light

variable {lim : Limits} {P : Program} {d : ℕ}

/-- Writing a bounded number into a bounded function. -/
private theorem abs_update_le {f : ℕ → ℤ} {B v : ℤ} (hf : ∀ y, |f y| ≤ B) (hv : |v| ≤ B)
    (x y : ℕ) : |Function.update f x v y| ≤ B := by
  rw [Function.update_apply]
  split_ifs
  exacts [hv, hf y]

/-- The value of a safe expression in a bounded state fits in a word. -/
theorem Expr.abs_val_le {σ : State} (hσ : σ.Bounded lim) :
    ∀ e : Expr, e.Safe lim σ → |e.val σ| ≤ lim.word
  | .const n, h => by
    rw [Expr.val, abs_of_nonneg (Int.natCast_nonneg n)]
    exact h
  | .var x, _ => hσ.1 x
  | .op _ _ _, h => h.2.2
  | .load _, _ => hσ.2 _

/-- A frame that holds words, over a memory that holds words, is a bounded state. -/
theorem bounded_frame {args : List ℤ} {μ : ℕ → ℤ} (hargs : ∀ v ∈ args, |v| ≤ lim.word)
    (hμ : ∀ a, |μ a| ≤ lim.word) : State.Bounded lim ⟨frame args, μ⟩ :=
  ⟨Light.AbsLe.abs_getD_le ((abs_nonneg _).trans (hμ 0)) hargs, hμ⟩

/-- The state in which a procedure starts is bounded, if the state of the caller is bounded and the
arguments of the call are safe. -/
theorem bounded_callFrame {σ : State} (hσ : σ.Bounded lim) (args : List Expr)
    (ha : ∀ e ∈ args, e.Safe lim σ) : State.Bounded lim ⟨frame (args.map (·.val σ)), σ.mem⟩ := by
  refine bounded_frame (fun v hv => ?_) hσ.2
  obtain ⟨e, he, rfl⟩ := List.mem_map.1 hv
  exact Expr.abs_val_le hσ e (ha e he)

variable {s : Stmt} {σ σ' : State} {o r : List Bool} {c : ℕ}

/-- A run that starts with words in all variables and cells ends with words in all of them,
provided the word limit holds `1`.

**Proof sketch.** Induct on `Exec`. Existing assignments use `Expr.abs_val_le`, and calls use
`bounded_callFrame`. Input reads and coins write `0` or `1`; integer halving preserves the
absolute-value bound. The other rules propagate boundedness. -/
theorem Exec.bounded (h : Exec lim P d s σ σ' o r c) (hw : (1 : ℤ) ≤ lim.word)
    (hσ : σ.Bounded lim) : σ'.Bounded lim := by
  induction h with
  | skip => exact hσ
  | set hs => exact ⟨abs_update_le hσ.1 (Expr.abs_val_le hσ _ hs) _, hσ.2⟩
  | store _ he _ => exact ⟨hσ.1, abs_update_le hσ.2 (Expr.abs_val_le hσ _ he) _⟩
  | seq _ _ ih₁ ih₂ => exact ih₂ (ih₁ hσ)
  | iteTrue _ _ _ ih => exact ih hσ
  | iteFalse _ _ _ ih => exact ih hσ
  | whileFalse _ _ => exact hσ
  | whileTrue _ _ _ _ ih₁ ih₂ => exact ih₂ (ih₁ hσ)
  | call ha _ _ _ ih =>
    have hbody := ih (bounded_callFrame hσ _ ha)
    exact ⟨abs_update_le hσ.1 (hbody.1 0) _, hbody.2⟩
  | @inBit d σ x e hs =>
    have hv : |inBitVal lim.input (e.val σ)| ≤ lim.word := by
      rw [inBitVal_eq]
      split_ifs <;> simp only [abs_one, abs_zero] <;> omega
    exact ⟨abs_update_le hσ.1 hv _, hσ.2⟩
  | emit _ => exact hσ
  | coin b =>
    have hv : |(if b then 1 else 0 : ℤ)| ≤ lim.word := by
      cases b <;> simp only [Bool.false_eq_true, ite_false, ite_true, abs_zero, abs_one] <;> omega
    exact ⟨abs_update_le hσ.1 hv _, hσ.2⟩
  | @half d σ x e hs =>
    have hv := Expr.abs_val_le hσ _ hs
    have hd : |(e.val σ / 2 : ℤ)| ≤ lim.word := by
      rw [abs_le] at hv ⊢
      omega
    exact ⟨abs_update_le hσ.1 hd _, hσ.2⟩

/-- A run does not change the cells from lim.space on. -/
theorem Exec.mem_outside (h : Exec lim P d s σ σ' o r c) (a : ℕ) (ha : lim.space ≤ a) :
    σ'.mem a = σ.mem a := by
  induction h with
  | skip => rfl
  | set _ => rfl
  | store _ _ haddr =>
    obtain ⟨h0, hlt⟩ := haddr
    exact Function.update_of_ne (by omega) _ _
  | seq _ _ ih₁ ih₂ => rw [ih₂, ih₁]
  | iteTrue _ _ _ ih => exact ih
  | iteFalse _ _ _ ih => exact ih
  | whileFalse _ _ => rfl
  | whileTrue _ _ _ _ ih₁ ih₂ => rw [ih₂, ih₁]
  | call _ _ _ _ ih => exact ih
  | inBit _ => rfl
  | emit _ => rfl
  | coin _ => rfl
  | half _ => rfl

end Light
end
