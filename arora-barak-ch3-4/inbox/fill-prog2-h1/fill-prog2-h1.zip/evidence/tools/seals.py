from pathlib import Path
import re
W=Path('/Users/seyoonr/.codex/worktrees/fill-prog2-h1/tcslib-exchange');P=Path('/tmp/fill-prog2-h1/evidence/probes')
seeds='Light.Op.eval Light.Expr.val Light.Expr.cost Light.Limits.Addr Light.Expr.Safe Light.Cond.Holds Light.Cond.cost Light.Cond.Safe Light.frame Light.memOf Light.inBitVal Light.State.Bounded Light.Ends'
simple='Light.Expr.val Light.Expr.cost Light.Expr.Safe Light.Op.eval Light.Cond.Holds Light.Cond.cost Light.Cond.Safe Light.frame'
for n in ['IO/Exec','IO']:
 s=(W/f'TCSlib/Programs/Light/{n}.lean').read_text()
 extra=' Light.Meets Light.Stmt.shift Light.Program.behind' if n=='IO' else ''
 pos=s.index('set_option maxHeartbeats')
 s=s[:pos]+'attribute [local irreducible] '+seeds+extra+'\nattribute [-simp] '+simple+'\n\n'+s[pos:]
 (P/('Seal_'+n.replace('/','_')+'.lean')).write_text(s)
control='''import TCSlib.Programs.Light.IO
open Light
set_option autoImplicit false
attribute [local irreducible] Light.inBitVal Light.State.Bounded Light.Ends Light.Meets
  Light.Stmt.shift Light.Program.behind

example (x : List Bool) (p : ℤ) :
    inBitVal x p = if 0 ≤ p ∧ x.getD p.toNat false = true then 1 else 0 := by
  fail_if_success rfl
  exact inBitVal_eq x p

example (lim : Limits) (σ : State) :
    σ.Bounded lim ↔ (∀ x, |σ.loc x| ≤ lim.word) ∧ ∀ a, |σ.mem a| ≤ lim.word := by
  fail_if_success exact Iff.rfl
  exact State.bounded_iff lim σ

example (lim : Limits) (P : Program) (d : ℕ) (s : Stmt) (σ : State) (T : ℕ)
    (Q : State → Prop) :
    Ends lim P d s σ T Q ↔ ∃ σ' o r c, Exec lim P d s σ σ' o r c ∧ c ≤ T ∧ Q σ' := by
  fail_if_success exact Iff.rfl
  exact ends_iff lim P d s σ T Q

example (lim : Limits) (P : Program) (p d : ℕ) (vals : List ℤ) (μ : ℕ → ℤ)
    (T : ℕ) (R : ℤ → (ℕ → ℤ) → Prop) :
    Meets lim P p d vals μ T R ↔ ∃ body, P[p]? = some body ∧
      Ends lim P d body ⟨frame vals, μ⟩ T fun σ' => R (σ'.loc 0) σ'.mem := by
  fail_if_success exact Iff.rfl
  exact meets_iff lim P p d vals μ T R

example (n : ℕ) : Stmt.skip.shift n = .skip := by
  fail_if_success rfl
  exact Stmt.shift_skip n

example (Q P : Program) : Program.behind Q P = Q ++ P.map (Stmt.shift Q.length) := by
  fail_if_success rfl
  exact Program.behind_eq Q P
'''
(P/'SealControls.lean').write_text(control)
# Unsealed versions verify that each rejected delta step is a genuine seal control.
c=control.replace('attribute [local irreducible] Light.inBitVal Light.State.Bounded Light.Ends Light.Meets\n  Light.Stmt.shift Light.Program.behind\n','')
c=re.sub(r'  fail_if_success (rfl|exact Iff.rfl)\n  exact [^\n]+',lambda m:'  '+m[1],c)
(P/'UnsealedControls.lean').write_text(c)
print('2 sealed module copies; 6 positive/negative reader controls')
