from pathlib import Path
import re,json,subprocess
W=Path('/Users/seyoonr/.codex/worktrees/fill-prog2-h1/tcslib-exchange');S=Path('/tmp/fill-prog2-h1');E=S/'evidence';P=E/'probes';P.mkdir(exist_ok=True)
src=(W/'devtools/seyoon/declfreeze.py').read_text();ns={};exec(src[:src.index('a = chunks(open')],ns)
chunks=ns['chunks']
def strip(s):
 out=[];i=0;d=0
 while i<len(s):
  if s.startswith('/-',i):d+=1;i+=2;continue
  if d and s.startswith('-/',i):d-=1;i+=2;continue
  if d:i+=1;continue
  if s.startswith('--',i):i=s.find('\n',i) if '\n' in s[i:] else len(s);continue
  out.append(s[i]);i+=1
 return ''.join(out)
def splitbody(t):
 t=strip(t).strip();d=0
 for i,c in enumerate(t):
  if c in '({[⟨':d+=1
  if c in ')}]⟩':d-=1
  if d==0 and (t.startswith(':=',i) or c=='|' or (t.startswith('where',i) and (i==0 or t[i-1].isspace()))):return t[:i].strip(),t[i:].strip()
 return t,''
def ren(s):
 for a,b in [('lim.toLimits','lim'),('EndsIO.toXEnds','EndsIO.toEnds'),('EndsIO.ofXEnds','EndsIO.ofEnds'),('MeetsIO.ofXMeets','MeetsIO.ofMeets'),('xEnds_iff','ends_iff'),('xMeets_iff','meets_iff'),('XProgram','Program'),('XLimits','Limits'),('XStmt','Stmt'),('XExec','Exec'),('XEnds','Ends'),('XMeets','Meets')]:s=s.replace(a,b)
 return s
M=Path('/tmp/fill-prog2-h1-inputs/campaign/items/ram-tm/prog2/PROG2Mirror.lean.txt').read_text()
mc={n.removeprefix('TCSlib.Draft.PROG2.'):(p,t) for n,p,t in chunks(M)}
names=[]
for n in mc:
 if n in ['XStmt','XProgram','XLimits','inBitVal','inBitVal_eq','XExec','XStmt.assigns','XEnds','xEnds_iff','XMeets','xMeets_iff','XStmt.shift','XProgram.behind','XExec.shift','EndsIO','endsIO_iff','MeetsIO','meetsIO_iff'] or (
  n.startswith('XExec.') and n not in ['XExec.ofExec']) or n.startswith(('EndsIO.','XEnds.coin','MeetsIO.','XStmt.silent','XStmt.calls','XProgram.SilentSet','XProgram.silentSet_iff')) or n in ['inBitVal_boundary','half_boundary','check_two_coins','check_det_length','check_bounded_needs_word','XStmt.size','XStmt.width'] or n.startswith('XStmt.width_'):
  names.append(n)
actual={}
files=sorted((W/'TCSlib/Programs/Light').rglob('*.lean'))
for f in files:
 for n,p,t in chunks(f.read_text()):actual[n]=(f,p,t)
rows=[];frozen=['import Lean','import TCSlib.Programs.Light.IO','import TCSlib.Programs.Light.Compiler.StatementCode',
 'set_option autoImplicit false','set_option maxHeartbeats 0',
 '''open Lean Meta Elab Command in
elab "#same_type " expected:ident actual:ident : command => liftTermElabM do
  let e ← getConstInfo expected.getId
  let a ← getConstInfo actual.getId
  unless ← isDefEq e.type a.type do
    throwError "type mismatch: {actual.getId}\\nexpected {e.type}\\nactual {a.type}"
  logInfo m!"MIRROR|{actual.getId}|PASS"
''','namespace FrozenCheck','open Light','open Light.Compiler']
for i,n in enumerate(names):
 an='Light.'+ren(n);assert an in actual,(n,an)
 f,_,at=actual[an];h,b=splitbody(ren(mc[n][1]));ah,ab=splitbody(at)
 # The axiom only supplies the frozen signature in this scratch probe. Its type is compared
 # with the landed constant; no expected axiom is used by any library proof.
 h=re.sub(r'^@\[[\s\S]*?\]\s*','',h)
 h=re.sub(r'^(?:theorem|def|abbrev|inductive|structure)\s+\S+',f'axiom expected_{i}',h, count=1)
 if n=='XLimits':h='axiom expected_'+str(i)+' : Type'
 context=[]
 if n.startswith('XExec.') and n not in ['XExec.shift','XExec.traces_nil']:
  context=["variable {lim : Limits} {P : Program} {d : ℕ} {s : Stmt} {σ σ' : State} {o r : List Bool} {c : ℕ}"]
 if n in ['EndsIO.toXEnds','EndsIO.mono','EndsIO.skip','EndsIO.set','EndsIO.store','EndsIO.seq','EndsIO.ite','EndsIO.whileStep','EndsIO.whileDone','EndsIO.call','EndsIO.inBit','EndsIO.emit','EndsIO.coin','EndsIO.half','XEnds.coin']:
  context=['variable {lim : Limits} {P : Program} {d : ℕ} {σ : State} {ρ : List Bool} {T : ℕ} {Q : State → List Bool → List Bool → Prop}']
 frozen+=['section',*context,h,f'#same_type FrozenCheck.expected_{i} {an}','end']
 def norm(x):return re.sub(r'\s+','',x).replace('_root_.','').replace('Light.Compiler.','').replace('Light.','')
 bodycheck='n/a (theorem proof)'
 headercheck='MATCH' if norm(re.sub(r'^(?:@\[[\s\S]*?\]\s*)?(?:theorem|def|abbrev|inductive|structure)\s+\S+','',splitbody(ren(mc[n][1]))[0],count=1))==norm(re.sub(r'^(?:@\[[\s\S]*?\]\s*)?(?:theorem|def|abbrev|inductive|structure)\s+\S+','',ah,count=1)) else 'REVIEW'
 if not re.search(r'\btheorem\s', mc[n][1]) and n!='XLimits':
  bodycheck='MATCH' if norm(b)==norm(ab) else 'REVIEW'
 if n=='XLimits':bodycheck='input field, inherited limits integrated in place'
 rows.append({'mirror':n,'landed':an,'file':str(f.relative_to(W)),'body':bodycheck,'header':headercheck})
frozen+=['end FrozenCheck']
(P/'FrozenStatements.lean').write_text('\n\n'.join(frozen)+'\n')
(E/'landing.json').write_text(json.dumps(rows,indent=2))
targets=[r['landed'] for r in rows if re.search(r'\btheorem\s',actual[r['landed']][2])]
# Include all new pure readers, plus the required reverse-simulation root.
basepub=set()
for f in files:
 old=subprocess.run(['git','show','3bc2d5f34c0a9c9d67ff89dd1e2e0bd68e3805b7:'+str(f.relative_to(W))],cwd=W,text=True,capture_output=True)
 if old.returncode==0:basepub.update(n for n,p,t in chunks(old.stdout) if not p)
for n,(f,p,t) in actual.items():
 if n not in basepub and not p and re.search(r'\btheorem\s',t) and n not in targets:targets.append(n)
targets+=['Light.exists_tmProc','Light.Compiler.length_compileStmt','Light.Compiler.sim','Light.Compiler.compileProgram_correct']
(P/'Axioms.lean').write_text('import TCSlib.Programs.Light.IO\nimport TCSlib.Programs.Light.Compiler.WholeProgram\nimport TCSlib.Programs.Light.TMProc\n'+''.join('#print axioms '+n+'\n' for n in targets))
walk=(W/'campaign/gates/163-ram-fill-classes/evidence/AdmissionWalk.lean.txt').read_text()
walk=walk[walk.index('open Lean'):walk.index('#walk WordRAM')]
(P/'AdmissionWalk.lean').write_text('import Lean\nimport TCSlib.Programs.Light.IO\nimport TCSlib.Programs.Light.Compiler.WholeProgram\nimport TCSlib.Programs.Light.TMProc\n'+walk+''.join('#walk '+n+'\n' for n in targets))
(P/'CacheProbe.lean').write_text('import Mathlib.Algebra.Group.Int.Defs\nimport Mathlib.Data.List.Infix\nimport Mathlib.Algebra.Order.Ring.Abs\n')
print(len(rows),'frozen signatures,',len(targets),'axiom/dependency roots')
for r in rows:
 if r['body']=='REVIEW':print('BODY REVIEW',r['landed'])
 if r['header']=='REVIEW':print('HEADER REVIEW',r['landed'])
