from pathlib import Path
import subprocess,os,time,json
W=Path('/Users/seyoonr/.codex/worktrees/fill-prog2-h1/tcslib-exchange');S=Path('/tmp/fill-prog2-h1');E=S/'evidence';B=S/'screen-base'
files=sorted(set(subprocess.check_output(['git','diff','--name-only','--','TCSlib/Programs/Light'],cwd=W,text=True).splitlines()+[str(p.relative_to(W)) for p in (W/'TCSlib/Programs/Light').glob('IO*/**/*.lean')]+['TCSlib/Programs/Light/IO.lean']))
# pathlib's recursive glob above includes IO children; include them explicitly for clarity.
files=sorted(set(files+[str(p.relative_to(W)) for p in (W/'TCSlib/Programs/Light/IO').glob('*.lean')]))
(E/'owned-files.txt').write_text('\n'.join(files)+'\n')
base=[]
for f in files:
 r=subprocess.run(['git','show','3bc2d5f34c0a9c9d67ff89dd1e2e0bd68e3805b7:'+f],cwd=W,text=True,capture_output=True)
 if r.returncode==0:
  p=B/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(r.stdout);base.append(f)
while any('copy-text-screen-v3.py' in x and 'screen.py' not in x for x in subprocess.check_output(['ps','-axo','args='],text=True).splitlines()):
 print('WAIT other copy screen',flush=True);time.sleep(2)
for label,root,fs in [('base',B,base),('head',W,files)]:
 print('SCREEN',label,len(fs),'files',flush=True)
 with (E/'logs'/('copy-screen-'+label+'.log')).open('w') as log:
  r=subprocess.run(['nice','-n','10','python3','-I',str(W/'scripts/copy-text-screen-v3.py'),str(root),*fs],stdout=log,stderr=subprocess.STDOUT)
  log.write(f'\nEXIT {r.returncode}\n')
 if r.returncode:raise SystemExit(r.returncode)
 print((E/'logs'/('copy-screen-'+label+'.log')).read_text().splitlines()[0],flush=True)
