from pathlib import Path
import subprocess,json,re,hashlib,zipfile,datetime,io,tarfile,csv
W=Path('/Users/seyoonr/.codex/worktrees/fill-prog2-h1/tcslib-exchange');S=Path('/tmp/fill-prog2-h1');E=S/'evidence'
BASE='3bc2d5f34c0a9c9d67ff89dd1e2e0bd68e3805b7';HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
files=(E/'owned-files.txt').read_text().splitlines();rows=json.loads((E/'landing.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
patch=git('diff','--binary',BASE,HEAD,'--',*files);(S/'delivery.patch').write_bytes(patch)
stat=git('diff','--stat',BASE,HEAD,'--',*files).decode();(E/'logs/diff-stat.log').write_text(stat)
assert set(git('diff','--name-only',BASE,HEAD).decode().splitlines())==set(files)
check=S/'patch-check';check.mkdir(exist_ok=True)
oldfiles=[f for f in files if subprocess.run(['git','cat-file','-e',BASE+':'+f],cwd=W,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0]
if not (E/'logs/patch-check.log').exists():
 with tarfile.open(fileobj=io.BytesIO(git('archive',BASE,'--',*oldfiles))) as tar:tar.extractall(check,filter='data')
 with (E/'logs/patch-check.log').open('w') as log:
  for flag in ['--check','']:
   args=['git','apply',*([flag] if flag else []),str(S/'delivery.patch')]
   r=subprocess.run(args,cwd=check,stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0
  for f in files:assert (check/f).read_bytes()==(W/f).read_bytes(),f
  log.write('Patch checks and applies against the base; all 13 resulting files byte-identical. EXIT 0\n')
sizes=[];admissions=[]
for f in files:
 old=subprocess.run(['git','show',BASE+':'+f],cwd=W,text=True,capture_output=True)
 s=(W/f).read_text();sizes.append((f,len(old.stdout.splitlines()) if old.returncode==0 else 0,len(s.splitlines())))
 for i,line in enumerate(s.splitlines(),1):
  if re.search(r'\bsorry\b',line):
   assert '/Compiler/' in f
   admissions.append((f,i,line.strip()))
assert len(admissions)==12
# Check all recorded root walks and all axiom inventories, rather than relying on exit alone.
walk=(E/'logs/AdmissionWalk.log').read_text();ax=(E/'logs/Axioms.log').read_text()
walks=dict(re.findall(r'WALK\|([^|]+)\|(\[[^]]*\])',walk))
assert len(walks)==79
for n,v in walks.items():
 if not n.startswith('Light.Compiler.'):assert v=='[]',(n,v)
 else:assert set(re.findall(r'Light\.Compiler\.\w+',v))<=set(['Light.Compiler.compileStmt','Light.Compiler.length_compileStmt','Light.Compiler.sim'])
for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",ax):
 assert set(x.strip() for x in a.split(',') if x.strip()) <= {'propext','Classical.choice','Quot.sound','sorryAx'}
 if not n.startswith('Light.Compiler.'):assert 'sorryAx' not in a
assert (E/'logs/FrozenStatements.log').read_text().count('|PASS')==79
for p in ['CacheProbe','FrozenStatements','Axioms','AdmissionWalk','Seal_IO_Exec','Seal_IO','SealControls','UnsealedControls']:
 t=(E/f'logs/{p}.log').read_text();assert 'EXIT 0' in t and 'error:' not in t
for row in rows:
 if row['landed']=='Light.Limits':
  row['header']='MATCH (in-place limits plus input)'
  assert 'word : ℤ\n  space : ℕ\n  depth : ℕ' in (W/'TCSlib/Programs/Light/Syntax.lean').read_text()
 else:assert row['header']=='MATCH',row
 assert row['body']!='REVIEW',row
landing=['| Mirror | In-place name | File | Statement/body comparison |','|---|---|---|---|']
for r in rows:
 landing.append(f"| `{r['mirror']}` | `{r['landed']}` | `{r['file']}` | {r['header']}; {r['body']} |")
(E/'LANDING.md').write_text('\n'.join(landing)+'\n')
(E/'frozen-signatures.diff').write_text('')
# Every reported screen pair gets an individual review row.
base=(E/'logs/copy-screen-base.log').read_text();screen=(E/'logs/copy-screen-head.log').read_text()
basepairs=set(re.findall(r'^\s+(\S+)  reproduces  (\S+):',base,re.M))
copy=['| Pair (target → source) | Fraction | Review |','|---|---|---|']
for a,b,ratio in re.findall(r'^\s+(\S+)  reproduces  (\S+): (.+)$',screen,re.M):
 if 'Exec.shift' in a or 'Exec.shift' in b:
  reason='Inherited append/relocation inductions; the added matching text is the four required leaf cases. Their distinct program transports remain in their owned homes.'
 elif 'TMProc.lean::' in a:
  reason='Inherited job-G code, unchanged by this delivery. The only TMProc edit is its meets_iff witness-reader invocation.'
 elif 'Simulation.lean::' in a:
  reason='Inherited vendored code-location or simulation case pair. Only the required trace/word-bound arguments changed; the old compiler cases stay in place.'
 elif (a,b) not in basepairs:
  reason='Existing Ends.seq/Ends.whileStep witness proofs; adding the mandatory output/coin existentials crosses the screen threshold. No new rule proof was copied.'
 else:
  reason='Inherited vendored lookup proof pair; no mathematical proof was added. Section-variable text changes the scanner denominator for one direction.'
 copy.append(f'| `{a}` → `{b}` | {ratio} | {reason} |')
(E/'COPY_REVIEW.md').write_text('Final screen: 31 pairs; base: 29. No final pair involves a new IO proof.\n\n'+'\n'.join(copy)+'\n')
# Bind the final source tree to our private, dependency-ordered compilation products.
mods=(E/'logs/order.txt').read_text().splitlines();state=json.loads((S/'compile-state.json').read_text());digests={}
def digest(m):
 if m in digests:return digests[m]
 f=W/(m+'.lean');h=hashlib.sha256(f.read_bytes())
 ds=[x.replace('.','/') for l in f.read_text().splitlines() if l.startswith('import ') for x in l.split()[1:] if x.startswith('TCSlib.')]
 for d in ds:h.update(digest(d).encode())
 digests[m]=h.hexdigest();return digests[m]
with (E/'build-manifest.csv').open('w') as out:
 cw=csv.writer(out);cw.writerow(['module','source_sha256','dependency_digest','olean_sha256','passing_log'])
 for m in mods:
  dh=digest(m);assert state[m]==dh,m
  o=S/'oleans'/(m+'.olean');assert o.exists() and o.stat().st_size>0
  key=m.replace('/','_')
  ls=[p for p in (E/'logs').glob('*-'+key+'.log') if 'EXIT 0' in p.read_text() and 'error:' not in p.read_text()]
  assert ls,m
  log=max(ls,key=lambda p:p.stat().st_mtime)
  cw.writerow([m,hashlib.sha256((W/(m+'.lean')).read_bytes()).hexdigest(),dh,hashlib.sha256(o.read_bytes()).hexdigest(),str(log.relative_to(E))])
assert len(mods)==74
with (E/'source-sha256.txt').open('w') as f:
 for n in files:f.write(hashlib.sha256((W/n).read_bytes()).hexdigest()+'  '+n+'\n')
waits=sum(int(x) for p in (E/'logs').glob('*.log') for x in re.findall(r'WAIT_SECONDS (\d+)',p.read_text()))
sz='\n'.join(f'| `{f}` | {a} | {b} |' for f,a,b in sizes)
adm='\n'.join(f'| `{f}:{i}` | `{t}` |' for f,i,t in admissions)
report=f'''# fill-prog2-h1 — complete

Base: `{BASE}` on `complexity/ram-simulation`.
Local implementation head: `{HEAD}` (`codex/fill-prog2-h1`), not pushed.
Input bundle SHA-256: `85264595a5ec372a3f83937cf5a428bbd47ddd0540a678911588b5d06c77197d`, checked before reading its first two sections and again before packaging.

All H1 targets are implemented and proved. The only unfinished code is the explicitly authorized compiler frontier for H2: 12 sites in three constants. The compiler still returns `List Instr`.

## Landing and statement freeze

The complete 79-row landing table is [evidence/LANDING.md](evidence/LANDING.md), with the mirror name, in-place name, home and comparison for every target. All 79 elaborated signatures match the renamed mirror (`FrozenStatements.log`, exit 0). The 78 ordinary source headers match after renaming, namespace qualification and whitespace normalization; the limits record keeps the base's three fields and adds exactly `input : List Bool`, in place of the mirror's `extends Limits` wrapper. All 16 remaining frozen definition bodies/equation tables match; theorems have independently checked proofs. `evidence/frozen-signatures.diff` is empty.

`Light/IO.lean` is the 491-line home of the stream logic, silent-code lifting, relocation, stream truncation and permanent checks; `Light/IO/Exec.lean` holds determinism, trace lengths and inversions. `Compiler/WholeProgram` imports `IO`, exporting it through the existing Light facade without editing a non-owned facade. No H2 acceptance definitions, extended instruction types or deliverables were added.

## Forced changes

* `Syntax`: `Stmt` gains `inBit`, `emit`, `coin`, `half`; `Limits` gains `input`; `Exec` gains the output and coin indices, threads them through old rules and adds the four new rules. `inBitVal` and its reader are the frozen definitions.
* `Logic`: `Exec.append` gains both indices. `Ends` keeps its public type and hides `σ' o r c` instead of `σ' c`. Existing rule proofs thread these witnesses; their statements remain unchanged. The new reader is `ends_iff`.
* `Assigns`: the four new defining arms, plus the two indices in `Exec.loc_eq_of_notMem_assigns`. Existing keeping rules only change witness lines.
* `RunsStayInLimits`: both execution lemmas gain the indices; `Exec.bounded` also gains the frozen hypothesis `(1 : ℤ) ≤ lim.word`. Its new cases bound the two bit values and integer halving.
* `Renumber`: four unchanged-statement arms in `Stmt.shift`, indices and four cases in `Exec.shift`; `Ends.shift` only changes witnesses. `Program.behind` is unchanged.
* `Rules`: `Ends.of_blockSafe` gains four impossible cases (the existing default `BlockSafe` arm is false). Sequence/branch/skip inversions thread extra witnesses. No rule statement changes.
* `Calls`: this base already has `meets_iff` from job G, with implicit arguments. H1 explicitly requires the mirror's reader, so it is reconciled to the frozen explicit-argument signature, with identical proposition and `Iff.rfl` proof. `Meets` itself is unchanged. The sole consumer adjustment is the witness-reader line in `TMProc` (`meets_iff ..`); no TMProc statement changes.
* `Compiler/StatementCode`: final frozen size/width arms and four proved width readers; the four `compileStmt` arms and the corresponding four length cases are admitted. Existing code and code type stay in place.
* `Compiler/Simulation`: the two private execution hypotheses gain traces; `sim_seq`, `sim_whileTrue` and `sim` receive the word-bound hypothesis needed by `Exec.bounded`. Only `sim`'s four new cases are admitted.
* `Compiler/WholeProgram.compileProgram_correct`: traces in the execution hypothesis and the forced word-bound hypothesis; the existing proof passes these to boundedness and simulation. It has no admission site of its own.

The static inventory is `evidence/changed-statements.json` (it also counts equation-style bodies as source statements). All other existing signatures are unchanged. No edits were needed in Frames, Regions, Lib or RAMSimulation. Out-of-scope generated blueprint metadata in the working checkout is excluded from both commit and delivery.

## Admission sites and walks

| Site | Authorized new case |
|---|---|
{adm}

The direct-admission walk checks **both types and values** for every axiom root, using the existing gate-163 traversal. There are 79 roots: the 62 frozen theorem targets, 13 additional pure readers, `Light.exists_tmProc`, and three compiler checks.

* All 76 non-compiler walks are empty, including `EndsIO.ofEnds`, `MeetsIO.ofMeets`, `Exec.det`, `EndsIO.take_iff`, `EndsIO.callLast` and `Light.exists_tmProc`.
* `length_compileStmt`: `{{compileStmt, length_compileStmt}}`.
* `sim` and `compileProgram_correct`: `{{compileStmt, length_compileStmt, sim}}`.

Every axiom print is in `evidence/logs/Axioms.log`. Non-compiler roots use only `propext`, `Classical.choice`, `Quot.sound` (or subsets); only the three compiler roots also use `sorryAx`. No new axiom or admission is present elsewhere.

## New helpers, readers and reuse

The five new private declarations are `rest_prefix` (drop the consumed prefix, using `List.IsPrefix.drop`), `trace_length` (one induction bounds the sum of both trace lengths), `of_empty` (transport existing `Ends` rules for runs with empty traces), `map_run` (share stream-preserving rule transport with a fixed overhead), and `shift_facts` (one induction proves both relocation facts). Existing local helper `abs_update_le` is reused unchanged.

Before adding these, the import closure was searched for prefix/drop/take equations, execution-length bounds, trace transports and relocation readers. Reused facts include `List.IsPrefix.drop`, `List.prefix_append`, `List.prefix_append_right_inj`, `List.prefix_take_iff`, the existing `Ends.skip/set/store/whileDone/mono`, `Program.getElem?_behind_right`, `Expr.abs_val_le`, `bounded_callFrame`, and the existing procedure/routine proofs. No new host or machine is constructed.

The additional public surface consists only of 13 pure home-file readers: `State.bounded_iff` in Syntax, the 11 `Stmt.shift_*` equations and `Program.behind_eq` in Renumber. All are `rfl`/`Iff.rfl`. No new simp attribute is added beyond the frozen/existing `Stmt.assigns` declaration.

Other-file definitions read by IO are consumed through `ends_iff`/the existing Ends rules, `meets_iff`, `inBitVal_eq`, `State.bounded_iff`, the `Stmt.shift_*` equations and the existing program lookup/relocation lemma. `Exec` is an inductive relation, inspected through its rules. Expression values and safety remain opaque parameters in IO. Core/Mathlib lemmas supply list and arithmetic operations; none of their definitions is named in a simp/rw/unfold argument.

Both IO source files re-elaborate with the imported Light definitions marked locally irreducible and their inherited simp attributes removed (exit 0). Six reader controls pass: delta/Iff.rfl succeeds unsealed, fails sealed, and the published reader still succeeds. See the `Seal_*`, `SealControls` and `UnsealedControls` probes/logs.

## Checks and copy screen

* All **74** modules in the dependency-ordered plan pass: 39 modules in the Syntax downstream closure (including both new IO modules), plus 35 prerequisites. Their final source/dependency/olean hashes and passing logs are in `evidence/build-manifest.csv`; no missing prerequisite or copied TCSlib olean is used.
* Final library checks have zero errors. The only sorry warnings are the authorized compiler constants. Existing upstream notation docstring warnings remain.
* Cache probe, 79 frozen type comparisons, 79 axiom prints/walks, both sealed module copies and all reader controls: exit 0.
* Patch check/application against the base, byte comparison of all 13 resulting files and `git diff --check`: exit 0.
* Final copy screen: **31 pairs**, versus **29** at the base; all 31 are individually reviewed in `evidence/COPY_REVIEW.md`. The two additional threshold crossings are the existing `Ends.seq`/`Ends.whileStep` witness templates after adding the required traces. No final pair involves a new IO proof. The shared length, transport and relocation arguments are factored into the five private helpers above.

## Size

| File | Base lines | Delivered lines |
|---|---:|---:|
{sz}

Every core/compiler/new IO file stays below 600 lines. TMProc was already 2172 lines at the base and remains 2172; its one allowed witness-reader change does not add lines or refactor the inherited file.

## Environment and reproduction

macOS/APFS host; 12 CPUs, 18 GiB physical memory, `memory_pressure` reported 55% available (about 9.9 GiB), and 65.3 GiB free disk at preflight. These exceed the addendum's 4 GiB memory/12 GiB initial disk floors. The Linux-only `/proc`, cgroup and GNU df requests are recorded with their macOS equivalents. The sandbox read override was needed for `sysctl`/machine-wide `ps` and managed-worktree writes. No runtime shim, `lake build`, Lake update, unfiltered cache fetch, external web source or sub-agent was used.

The pre-existing Mathlib package tree is symlinked at its exact manifest pins (allowed alternative in the addendum); every present package matched, and four documentation packages are ABSENT. No package/dependency tree was copied. The installed Lean 4.25.0 toolchain was selected explicitly. The cache probe ran after the initial bootstrap rather than before it; all planned Mathlib imports and the final cache probe passed. No cache download was necessary.

All TCSlib modules were bootstrapped into this job's fresh private `/tmp/fill-prog2-h1/oleans`. Checks use the repository's `leanelab-o.sh`/`leanelab.sh`, `lean -j4` under nice, one job-owned Lean process at a time, after a machine-wide process count. Recorded Lean slot waits total **{waits} seconds**. Copy screens ran one at a time. Logs were written in place from the start. Intermediate failed elaborations were corrected; the manifest selects final passing checks. The build scripts, probes, manifests, original verified bundle and final logs are shipped, without compiled products.

`evidence/tools/check.py` and `probe.py` record the exact host paths and environment. For another host, repoint their worktree/scratch roots, link a manifest-matched package tree, then run `check.py final all` followed by the shipped probes (rename `.lean.txt` back to `.lean`). Probe-only expected-signature axioms are confined to the scratch frozen-type checker and never used by library proofs.

## Diff stat

```text
{stat.rstrip()}
```

Only the delivery zip is published to `arora-barak-ch3-4/inbox/fill-prog2-h1/` on the exchange branch, with pull --rebase and no force. No checkpoint archives were produced; no implementation branch or PR is pushed.
'''
assert '491-line' in report and len((W/'TCSlib/Programs/Light/IO.lean').read_text().splitlines())==491
(S/'REPORT.md').write_text(report)
inputs=Path('/tmp/fill-prog2-h1-inputs')
archive=S/'fill-prog2-h1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(S/'REPORT.md','REPORT.md');z.write(S/'delivery.patch','delivery.patch')
 for f in files:z.write(W/f,f)
 for f in E.rglob('*'):
  if f.is_file():z.write(f,str(f.relative_to(S))+('.txt' if f.suffix=='.lean' else ''))
 for n in ['check.py','probe.py','audit.py','seals.py','screen.py','deliver.py']:
  z.write(S/'tools'/n,'evidence/tools/'+n)
 for n in ['fill-prog2-h1-bundle.md','SHA256SUMS','README.md']:
  z.write(inputs/n,'evidence/inputs/'+n)
 assert z.testzip() is None
print('ARCHIVE',archive,archive.stat().st_size,'bytes',hashlib.sha256(archive.read_bytes()).hexdigest())
