from pathlib import Path
import hashlib,subprocess,sys,os,time,json,datetime
W=Path('/Users/seyoonr/.codex/worktrees/fill-prog2-h1/tcslib-exchange')
S=Path('/tmp/fill-prog2-h1'); O=S/'oleans'; logs=S/'evidence/logs'
env=os.environ.copy();env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH']
env['TCSLIB_SCRATCH']=str(S);env['TCSLIB_LEAN_SLOTS']='3'
files={str(p.relative_to(W)).removesuffix('.lean'):p for p in (W/'TCSlib').rglob('*.lean')}
deps={m:[x.replace('.','/') for line in p.read_text().splitlines() if line.startswith('import ') for x in line.split()[1:] if x.startswith('TCSlib.')] for m,p in files.items()}
seed='TCSlib/Programs/Light/Syntax';down={seed}
while True:
    n=down|{m for m,ds in deps.items() if any(d in down for d in ds)}
    if n==down:break
    down=n
def order(roots):
    seen=set();out=[]
    def visit(m):
        if m in seen:return
        seen.add(m)
        for d in deps[m]:visit(d)
        out.append(m)
    for m in sorted(roots):visit(m)
    return out
allorder=order(down)
(logs/'downstream.txt').write_text('\n'.join(m for m in allorder if m in down)+'\n')
(logs/'order.txt').write_text('\n'.join(allorder)+'\n')
roots=sorted({line.split()[1] for m in allorder for line in files[m].read_text().splitlines() if line.startswith('import Mathlib')})
(logs/'mathlib-roots.txt').write_text('\n'.join(roots)+'\n')
statefile=S/'compile-state.json'
state=json.loads(statefile.read_text()) if statefile.exists() else {}
def digest(m):
    h=hashlib.sha256(files[m].read_bytes())
    for d in deps[m]:h.update(digest(d).encode())
    return h.hexdigest()
def lean_count():
    s=subprocess.check_output(['ps','-axo','comm='],text=True)
    return sum(Path(x.strip()).name=='lean' for x in s.splitlines())
def run(m,label):
    f=files[m] if m in files else W/(m+'.lean')
    dest=O/(m+'.olean');dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():dest.unlink()
    start=time.time();waits=0
    while lean_count()>=3:
        if waits%30==0:print('WAIT Lean slots',m,flush=True)
        waits+=1;time.sleep(2)
    p=logs/(label+'-'+m.replace('/','_')+'.log')
    with p.open('w') as log:
        log.write(f'START {datetime.datetime.now(datetime.timezone.utc).isoformat()}\nWAIT_SECONDS {waits*2}\n');log.flush()
        c=subprocess.run(['/usr/bin/time','-l','bash',str(W/'devtools/seyoon/leanelab-o.sh'),str(W),str(O),str(f.relative_to(W)),str(O)],cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
        log.write(f'\nEXIT {c.returncode}\nEND {datetime.datetime.now(datetime.timezone.utc).isoformat()}\n')
    s=p.read_text();ok=c.returncode==0 and 'error:' not in s and dest.exists() and dest.stat().st_size>0
    print(('PASS' if ok else 'FAIL'),m,round(time.time()-start,1),'s',flush=True)
    if not ok:print(s,flush=True);return False
    return True
args=sys.argv[1:]
if args[0]=='plan':
    print(len(down),'downstream',len(allorder),'including prerequisites',len(roots),'Mathlib roots');sys.exit()
label=args.pop(0)
todo=allorder if args==['all'] else order({a.replace('.lean','').replace('.','/') for a in args})
for m in todo:
    dh=digest(m)
    if state.get(m)==dh and (O/(m+'.olean')).exists():continue
    print('START',m,flush=True)
    if not run(m,label):sys.exit(1)
    state[m]=dh;statefile.write_text(json.dumps(state,indent=2))
print('COMPLETE',len(todo),'modules; exit 0',flush=True)
