from pathlib import Path
import subprocess,sys,os,time,datetime
W=Path('/Users/seyoonr/.codex/worktrees/fill-prog2-h1/tcslib-exchange');S=Path('/tmp/fill-prog2-h1')
env=os.environ.copy();env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH']
env['TCSLIB_SCRATCH']=str(S);env['TCSLIB_LEAN_SLOTS']='3'
for arg in sys.argv[1:]:
 p=Path(arg);log=S/'evidence/logs'/(p.stem+'.log');waits=0
 while sum(Path(x.strip()).name=='lean' for x in subprocess.check_output(['ps','-axo','comm='],text=True).splitlines())>=3:
  if waits%30==0:print('WAIT Lean slots',p.stem,flush=True)
  time.sleep(2);waits+=1
 print('PROBE',p.name,flush=True)
 with log.open('w') as f:
  f.write(f'START {datetime.datetime.now(datetime.timezone.utc).isoformat()}\nWAIT_SECONDS {waits*2}\n');f.flush()
  r=subprocess.run(['/usr/bin/time','-l','bash',str(W/'devtools/seyoon/leanelab.sh'),str(W),str(S/'oleans'),str(p)],env=env,cwd=W,stdout=f,stderr=subprocess.STDOUT)
  f.write(f'\nEXIT {r.returncode}\nEND {datetime.datetime.now(datetime.timezone.utc).isoformat()}\n')
 text=log.read_text();ok=(r.returncode==0 and 'error:' not in text)
 print(('PASS' if ok else 'FAIL'),str(log),flush=True)
 if not ok:print(text,flush=True);sys.exit(1)
