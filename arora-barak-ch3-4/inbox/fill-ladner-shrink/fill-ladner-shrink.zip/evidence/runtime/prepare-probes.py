from pathlib import Path
import re
R=Path('/private/tmp/fill-ladner-shrink');WT=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-shrink/tcslib-exchange')
s=(WT/'TCSlib/Complexity/Diagonalization/Ladner.lean').read_text()
new=(R/'shrink.lean.txt').read_text()
names=re.findall(r'^private theorem (ladner_\w+)',new,re.M)+['SAT_mem_P_of_padSAT_NPHard']
wrappers='\n'.join('def fill6_axioms_'+n+' := @'+n for n in names)
prints='\n'.join('#print axioms Complexity.fill6_axioms_'+n for n in names)
assert s.endswith('end Complexity\n')
dependency='''open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let (_, st) := ((Lean.CollectAxioms.collect ``Complexity.SAT_mem_P_of_padSAT_NPHard).run env).run {}
  unless st.visited.contains ``Complexity.SAT_mem_P_of_padSAT_NPHard do
    throwError "Target dependency walk did not visit the target"
  unless st.visited.contains ``Complexity.SAT_mem_NP do
    throwError "Target dependency walk did not reach the prescribed SAT_mem_NP premise"
  for n in [``Complexity.ladnerH_polyTime, ``Complexity.SAT_H_mem_NP,
      ``Complexity.ladnerH_bounded_of_mem_P, ``Complexity.ladnerH_unbounded_of_not_mem_P] do
    if st.visited.contains n then throwError m!"Forbidden Ladner dependency: {n}"
    logInfo m!"Dependency control: {n} absent"
'''
(R/'probes/AxiomWalk.lean').write_text(s.removesuffix('end Complexity\n')+wrappers+'\nend Complexity\n'+prints+'\n'+dependency)
foreign=['Complexity.PolyTimeComputable','Complexity.PolyTimeReducible','Complexity.NPHard',
'Complexity.P','Complexity.NP','Complexity.SAT','Complexity.pairFstD','Complexity.pairSndD','Turing.pairEncode',
'Complexity.BinArith.lt']
seal='section\nattribute [local irreducible] '+' '.join(foreign)+'\n'
sealed=s.replace(new,seal+new+'\nend\n',1)
a=sealed.index('/-- Polynomial-time computable, diverging padding cannot be NP-hard')
b=sealed.index('\n\n/--',sealed.index('theorem SAT_mem_P_of_padSAT_NPHard ',a))
sealed=sealed[:a]+seal+sealed[a:b]+'\nend\n'+sealed[b:]
(R/'probes/Sealed.lean').write_text(sealed)
(R/'evidence/logs/sealed-definitions.txt').write_text('\n'.join(foreign)+'\n')
for sealedflag in [False,True]:
    header='import TCSlib.Complexity.ClassNP.Reductions\nimport TCSlib.Complexity.ClassNP.PClosure\nimport TCSlib.Complexity.ClassNP.SAT\nimport TCSlib.Complexity.ClassP.BinaryArith.Loops\n\n'
    if sealedflag:header+='attribute [local irreducible] '+' '.join(foreign)+'\n'
    expr=',\n    '.join('``'+n for n in foreign)
    expected='false' if sealedflag else 'true'
    body=f'''open Lean Elab Command Meta in
run_cmd do
  liftTermElabM do
    for n in [{expr}] do
      let ci ← getConstInfo n
      let c := mkConst n (ci.levelParams.map Level.param)
      let v := ci.value!
      let ok ← withNewMCtxDepth <| withTransparency .default <| isDefEq c v
      let expected := {expected}
      unless ok == expected do
        throwError m!"delta control {{n}}: got {{ok}}, expected {{expected}}"
      logInfo m!"delta control {{n}}: {{ok}} (expected {{expected}})"
'''
    (R/('probes/DeltaSealed.lean' if sealedflag else 'probes/DeltaUnsealed.lean')).write_text(header+body)
print('Prepared',len(names),'public axiom aliases, a two-section production seal, and',len(foreign),'delta controls')
