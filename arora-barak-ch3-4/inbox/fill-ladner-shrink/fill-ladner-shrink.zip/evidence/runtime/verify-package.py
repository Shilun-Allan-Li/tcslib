from pathlib import Path, PurePosixPath
import hashlib, subprocess, sys, tempfile, zipfile
R=Path('/private/tmp/fill-ladner-shrink')
WT=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-shrink/tcslib-exchange')
F='TCSlib/Complexity/Diagonalization/Ladner.lean'
BASE='34643146ee1fe6bf6d7ffdf2e543e8342a3e16a0'
EXPECTED='c46143d91a8db4ee57bf0f81b3d8008c0b6f0288f6eb6834e4292f790428211a'
archive=Path(sys.argv[1])
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None, 'zip CRC failure'
    names=z.namelist()
    assert len(names)==len(set(names)), 'duplicate members'
    for name in names:
        p=PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts
        assert p.suffix not in {'.olean','.ilean','.o','.so','.dylib','.a'}, name
    required=['REPORT.md','Ladner.lean','Ladner.patch','SHA256SUMS']
    required += ['evidence/logs/'+n for n in ['concurrency.log','runs.tsv','ladner-final.log','facade-final.log','axioms-1.log','axiom-audit.log','sealed-final.log','delta-unsealed-final.log','delta-sealed-final.log','reader-controls-final.log','freeze-audit.log','package-pins.log','archive-attempt.log']]
    assert set(required)<=set(names), set(required)-set(names)
    for line in z.read('SHA256SUMS').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==digest, name
    source=z.read('Ladner.lean')
    assert hashlib.sha256(source).hexdigest()==EXPECTED
    assert source==(WT/F).read_bytes()
    patch=z.read('Ladner.patch')
    assert patch==subprocess.check_output(['git','-C',str(WT),'diff',BASE,'--',F])
    with tempfile.TemporaryDirectory(prefix='patch-check-',dir=R) as td:
        root=Path(td); target=root/F; target.parent.mkdir(parents=True)
        target.write_bytes(subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+F]))
        pp=root/'change.patch'; pp.write_bytes(patch)
        subprocess.run(['git','apply','--check',str(pp)],cwd=root,check=True)
        subprocess.run(['git','apply',str(pp)],cwd=root,check=True)
        assert target.read_bytes()==source, 'patch did not reproduce source'
print('PASS: zip integrity, safe unique members, required evidence and no build products')
print('PASS: source/patch manifest hashes match; source matches checked worktree')
print('PASS: patch applies to exact base '+BASE+' and reproduces delivered source byte-for-byte')
print('PASS: source SHA-256 '+EXPECTED)
print('Archive SHA-256 '+hashlib.sha256(archive.read_bytes()).hexdigest())
