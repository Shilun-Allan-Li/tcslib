from pathlib import Path
import subprocess
ROOT=Path('/private/tmp/fill-ladner-shrink')
WT=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-shrink/tcslib-exchange')
NAME='TCSlib/Complexity/Diagonalization/Ladner.lean'
BASE='34643146ee1fe6bf6d7ffdf2e543e8342a3e16a0'
base=subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+NAME],text=True)
last=ROOT/'last-synced.lean.txt'
expected=last.read_text() if last.exists() else base
assert (WT/NAME).read_text()==expected,'Unexpected source edits; inspect rather than overwrite'
anchor='/-! ### Polynomial-time preparation for the bounded candidate test -/'
assert base.count(anchor)==1
new=base.replace(anchor,(ROOT/'shrink.lean.txt').read_text()+'\n'+anchor,1)
body=ROOT/'target-body.lean.txt'
if body.exists():
    start=new.index('theorem SAT_mem_P_of_padSAT_NPHard ')
    end=new.index('\n\n/--',start)
    old=new[start:end]
    assert old.endswith(':=\n  sorry')
    new=new[:start]+old[:-len(':=\n  sorry')]+':= by\n'+body.read_text().rstrip() +new[end:]
(WT/NAME).write_text(new)
last.write_text(new)
print('Synchronized additive shrinking section; target body '+('replaced' if body.exists() else 'unchanged'))
