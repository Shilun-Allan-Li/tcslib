from pathlib import Path
import sys,subprocess,time,datetime
ROOT=Path('/private/tmp/fill-ladner-shrink'); LOG=ROOT/'evidence/logs/concurrency.log'
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
label=sys.argv[1]
(ROOT/('gate-'+label)).write_text(stamp())
while True:
    p=subprocess.run(['ps','-axo','comm='],text=True,capture_output=True,check=True)
    count=sum(c.strip().split('/')[-1]=='lean' for c in p.stdout.splitlines())
    with LOG.open('a') as out: out.write(f'{stamp()} SLOT-HELD COUNT {count} {label}\n')
    if count<3: break
    with LOG.open('a') as out: out.write(f'{stamp()} WAIT count={count} {label}; recount in 10s\n')
    time.sleep(10)
sys.exit(subprocess.run(sys.argv[2:]).returncode)
