# Ladner shrinking argument — complete target 5

`Complexity.SAT_mem_P_of_padSAT_NPHard` is proved with its original statement, citation and docstring. All required arithmetic, FP step, invariant/progress, all-orbit size and final readout leaves are complete. No frontier or escalation remains. A checked transitive dependency walk confirms that the proof does not use Ladner targets 1–4.

Base: `34643146ee1fe6bf6d7ffdf2e543e8342a3e16a0` (after #321). Local branch: `fill/ladner-shrink`, never rebased; local source commit `3ff8cca825730a60514425bdc632d0828be76e8c` is not pushed. Worktree: `/Users/seyoonr/.codex/worktrees/fill-ladner-shrink/tcslib-exchange`. Records pin: `739faba95499d3e054e7d23a6366328988ca69e5`; dispatch exchange pin: `e4facafb14e037762b7f5291a403c9c6f6c26b94`. The exchange was successfully pulled before reading the bundle and before publication.

The verified bundle SHA-256 is `5a2740abb2164fb4339426afd695b5c52cf2e5ebf7629c24468dcf82b2eb46b7`, 13 sections. Digest verification preceded brief reading/extraction. Its framed Ladner source also matches the exact pinned base (`source-binding.log`).

## Scope and freeze

Only `TCSlib/Complexity/Diagonalization/Ladner.lean` changes: 363 insertions, 2 deletions. The 15 new private declarations (4 definitions, 11 proofs) occur in the required `Shrinking a reduction into the padded language` section immediately before the polynomial-time candidate preparation header, after the finite-table leaves. The only other edit replaces target 5's admitted body. Removing that section and restoring that one body reproduces every byte of the base file. The target's header/docstring, imports, all other targets and all existing private leaves are unchanged. This preserves the prescribed disjoint placement relative to the concurrent target-2 fill; no other fill's branch or working files were merged or modified.

No public declarations, imports, new admissions, axioms, simp attributes, library files or machine hosts were added. All named pre-ship contracts retain their meaning; no statement correction was necessary. The two extra private proofs (`ladner_shrink_terminal_result` and `ladner_shrink_initial`) factor common semantic bookkeeping instead of copying branch proofs.

## Proof and computational construction

Hardness is read through `NPHard_iff` and `polyTimeReducible_iff`, specialized at `SAT_mem_NP`. The reduction's public output-length bound gives `A(|x|+1)^d`. Divergence supplies B with `h(m)≥2(d+1)` above B, and K is exactly `A*2^d+2`. For any syntactically valid output, including a no-instance's output, its suffix is at most the output length. If `m²>n`, then `(n+1)^(d+1)≤(m²)^(d+1)≤m^(h(m))≤A(n+1)^d`, contradicting `A≤n`. The stated threshold is preserved even though this integer proof needs only the weaker coefficient comparison. Since K≥2, `m²≤n` also yields `m<n`. No monotonicity of h is assumed.

The FP step uses the existing parser and saturated syntax test; hp imposes no numeric growth restriction on h, so no full power is allocated. It has two independent fixed finite tables: input length below K, and parsed prefix length below B. Failed parsing or a wrong padding length is rejected before the next live word is chosen. A terminal false answer is `[false]`, which is nonempty and fixed just like `[true]`. Each continuing round stores exactly one parsed prefix, with no branching over separators and no new recursion/search host. Reduction output and parser scratch costs are included in the FP step theorem, independently of hardness/divergence premises.

The invariant preserves SAT equivalence and bounds every live word by the original input length. `iterate_invariant` yields a serialized bound `4(|x|+1)` on every reached state, including states after termination. The live measure is current length plus one and is zero on terminal flags. The existing decreasing-measure iterator theorem finishes within `|x|+1` rounds, identifies the final Boolean bit, and the public polynomial iterator plus `mem_P_of_test` puts SAT in P. A classical membership equation is not used as an FP implementation: fixed tables and the existing FP closure/iteration theorems supply the implementation.

## New declarations and reuse inventory

| Declaration | Role | Existing facts searched/cited |
|---|---|---|
| `ladner_smallSAT` | The fixed finite SAT table below a length threshold.. | Required specification; existing `ladner_small_SAT_table` and `ladner_finite_lookup_FP` cover its implementation. |
| `ladner_shrinkStep` | One shrinking round: finish small inputs, reject invalid padding, tabulate short prefixes, and otherwise keep just the parsed prefix. A nonempty answer flag is fixed.. | Required specification; existing parser and capped `ladner_syntax_FP`, then the public FP iterator. |
| `ladner_ShrinkInv` | A live state holds a word no longer than the original input with the same SAT answer; a terminal state holds that answer as one bit. In particular `[false]` is terminal.. | Required invariant specification; owner-state pairs and SAT equivalence. |
| `ladner_shrinkMeasure` | The live-word length plus one is the shrinking measure; terminal states have measure zero.. | Required measure specification; live/terminal flag projections. |
| `ladner_reduction_from_hardness` | NP-hardness supplies a polynomial reduction from SAT through the published `NPHard_iff` and `polyTimeReducible_iff` readers.. | `NPHard_iff`, `polyTimeReducible_iff`, `SAT_mem_NP`; the pre-shipped proved reader application. |
| `ladner_prefix_square_bound` | A sufficiently large exponent forces every polynomially bounded padded prefix below the square root of the original input length. | No matching prefix-square bound found in the import closure; uses `Nat.pow_le_pow_left/right`, `pow_mul`, `pow_succ`, and positive natural multiplication. |
| `ladner_reduction_shrinks` | Every syntactically valid reduction output with a sufficiently long prefix shrinks that prefix below both the square root and the length of the current input. | `PolyTimeComputable.output_length_le`, `ladner_parsed_length`, and the new square bound; no re-derivation of parser length facts. |
| `ladner_smallSAT_FP` | A fixed short-input SAT test is polynomial-time by the existing finite-table leaves.. | The existing finite-table and finite-lookup leaves; the pre-shipped proved construction. |
| `ladner_shrinkStep_FP` | A shrinking round is FP independently of hardness or divergence of the padding. | Existing `ladner_lengthBits_FP`, `ladner_parse_FP`, `ladner_syntax_FP`, `BinArith.lt_pairEncode`, and FP composition/conditional/pair contracts. |
| `ladner_shrink_terminal_result` | A correct one-bit terminal answer preserves the invariant and strictly lowers the measure of any live state. This common ledger covers both answers and both finite tables.. | New common terminal ledger; public pair projection equations and the owner measure. Factored once for all terminal branches. |
| `ladner_shrink_progress` | A shrinking round preserves the SAT answer, lowers every positive live measure, and fixes terminal states, including the false terminal bit. | Existing `ladner_pad_membership`, parser equation, core option/product/exists equations, reduction equivalence, and the shared terminal ledger. |
| `ladner_shrink_initial` | The shrinking iterator starts live with the original input and its unchanged SAT answer.. | Owner invariant constructors, `le_rfl`, `Iff.rfl`; shared by both orbit consumers. |
| `ladner_shrink_orbit_size` | Every state in the initialized shrinking orbit has a linear serialized length bound.. | `BinArith.iterate_invariant`, `length_pairEncode`, standard list length equations. |
| `ladner_shrink_final_readout` | The bounded shrinking orbit finishes with exactly the original SAT decision bit. | `BinArith.iterate_measure_eq_zero`, `iterate_invariant`, `Bool.eq_iff_iff`, `decide_eq_true_eq`. |
| `ladner_shrinking_transfer` | The public polynomial iterator and a correct shrinking readout put SAT in P. | `BinArith.polyTimeComputable_iterate` with (1,1,4,1), FP init/projection, and `mem_P_of_test`; the pre-shipped transfer. |

The existing-fact candidate searches and inspection are in `proof-search.log`; this is not claimed an exhaustive duplication certificate. In particular, existing parser, syntax, length-bits and finite-table facts are cited rather than reconstructed. Successful-parse membership is obtained by simplifying `ladner_pad_membership` with its parse equation and core existential equalities, rather than copying an old witness-uniqueness proof. The pre-shipped proved reader/table/transfer/assembly terms were used in their authorized scope. No known public fact was rederived, and no new host/API request is needed.

## Other-file definitions and public readings

| Definition/interface reached | Published equation or contract used |
|---|---|
| `PolyTimeComputable` | FP closure contracts (`comp`, pairing, constants, identity, conditional), `output_length_le`, and the iterator theorem; no predicate-body extraction. `polyTimeComputable_iff` is exercised as a reader control. |
| `PolyTimeReducible` | `polyTimeReducible_iff` |
| `NPHard` | `NPHard_iff` |
| `P` | `mem_P_of_test`; `mem_P_iff` is exercised as a reader control. |
| `NP`, `SAT` | Public `SAT_mem_NP` contract; SAT is otherwise opaque finite-table membership. No SAT decoder or private verifier is read, and no sharp linear-SAT-verifier premise is added. |
| `pairFstD`, `pairSndD` | `pairFstD_pairEncode`, `pairSndD_pairEncode`, and the FP projection contracts |
| `pairEncode` | `length_pairEncode`, projection equations, and FP pairing contracts |
| `BinArith.lt` | `lt_pairEncode` on canonical binary length/constant inputs, plus its FP contract |
| Public iteration | `BinArith.polyTimeComputable_iterate`, `iterate_invariant`, `iterate_measure_eq_zero`; no host body is read. |
| Existing owner leaves | `ladner_lengthBits_FP`, `ladner_parse_FP`, `ladner_parsed_length`, `ladner_syntax_FP`, `ladner_pad_membership`, `ladner_small_SAT_table`, `ladner_finite_lookup_FP`; all are unchanged in this owned file. |

The production section and target body both elaborate with all ten reached foreign definitions (`PolyTimeComputable`, `PolyTimeReducible`, `NPHard`, P, NP, SAT, both projections, pairing, `BinArith.lt`) locally irreducible. Ten unsealed delta controls succeed, the corresponding sealed controls fail, and public reader/contract controls still succeed. The delta controls use Lean's default definitional equality on each constant versus its body, equivalent to checking an `rfl` delta goal, without spelling private implementation names. No unsafe reducibility setting is used. `BinArith.decWords`, already irreducible, is not read by these new proofs.

Explicit simplifier/rewriter arguments in the production additions were inspected. No other-file TCSlib definition or core/Mathlib definition is passed to `simp`, `rw`, or `unfold`. The first draft needed the core theorem `ne_eq` (not the core definition `Ne`) and `exists_eq_left'` to normalize branch predicates and parsed witnesses; `ladner-draft-1.log` records those failed goals. The corrected source (`ladner-draft-2`, final checks) has no such errors. There was no mathematical statement change, new admission, resource crash or proof interruption.

## Verification

All checks below have exit code zero. Full outputs, memory/time measurements and exit statuses are under `evidence/logs`.

| Check | Evidence | Result |
|---|---|---|
| Dependency cache | `package-pins.log`, `cache-check.log`, `mathlib-roots.log` | All 11 present package pins match; all 46 direct Mathlib roots elaborate; no zero-sized package oleans. |
| Fresh import/facade prerequisites | `bootstrap-001.log` through `bootstrap-139.log` (127 skipped) and `runs.tsv` | 138 non-owned/non-facade modules, all exit 0; exact pinned source, own scratch olean tree. |
| Whole owned source | `ladner-draft-2.log`, `ladner-final.log` | Zero errors; only the two unchanged admitted targets warn. |
| Foreign-definition seal | `sealed-final.log` | New section and target body, all ten foreign definitions opaque; exit 0. |
| Delta sensitivity | `delta-unsealed-final.log`, `delta-sealed-final.log` | Ten positive unsealed and ten negative sealed comparisons. |
| Sealed reader contracts | `reader-controls-final.log` | All public readings remain usable; exit 0. |
| Target and leaf axioms | `axioms-1.log`, `axiom-audit.log` | Target and all 11 new proofs have only standard axioms; no `sorryAx`. |
| Independence from targets 1–4 | `axioms-1.log` | Checked transitive dependency walk finds none of the four targets; it does reach the required `SAT_mem_NP` premise. |
| Facade | `facade-final.log` | Fresh nonempty olean, zero errors and warnings. |
| Toolchain | `toolchain-version.log` | Lean 4.25.0, arm64-apple-darwin24.6.0, commit cdd38ac5115bdeec5f609e9126cce00f51ae88b3. |
| Freeze, scope, formatting, sketches | `freeze-audit.log`, `diff-stat.log`, `proof-sketch-audit.log` | Only the approved file/section/body changes; `git diff --check` passes; all long new proofs have sketches and citations. |

The initial nine-definition seal/control checks also passed; the final checks conservatively add NP itself to cover the hardness premise. The production source did not change during that coverage expansion.

Final owned-file warnings:

```text
TCSlib/Complexity/Diagonalization/Ladner.lean:2472:8: warning: declaration uses 'sorry'
TCSlib/Complexity/Diagonalization/Ladner.lean:2499:8: warning: declaration uses 'sorry'
```

These are exactly `SAT_H_mem_NP` and `SAT_H_intermediate`; their original admitted bodies are untouched.

Diff against the base:

```text
 TCSlib/Complexity/Diagonalization/Ladner.lean | 365 +++++++++++++++++++++++++-
 1 file changed, 363 insertions(+), 2 deletions(-)
```

Authoritative public scratch-wrapper axiom prints and dependency controls:

```text
'Complexity.fill6_axioms_ladner_reduction_from_hardness' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_prefix_square_bound' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_reduction_shrinks' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_smallSAT_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_shrinkStep_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_shrink_terminal_result' depends on axioms: [propext, Quot.sound]
'Complexity.fill6_axioms_ladner_shrink_progress' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_shrink_initial' does not depend on any axioms
'Complexity.fill6_axioms_ladner_shrink_orbit_size' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_shrink_final_readout' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_ladner_shrinking_transfer' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill6_axioms_SAT_mem_P_of_padSAT_NPHard' depends on axioms: [propext, Classical.choice, Quot.sound]

Dependency control: Complexity.ladnerH_polyTime absent
Dependency control: Complexity.SAT_H_mem_NP absent
Dependency control: Complexity.ladnerH_bounded_of_mem_P absent
Dependency control: Complexity.ladnerH_unbounded_of_not_mem_P absent
```

## Environment, waits and deviations

- Work used a separate managed worktree at the exact base, never rebased. Source commit `3ff8cca825730a60514425bdc632d0828be76e8c` is local only. Attempted app-managed cleanup was refused: “The task's primary checkout cannot be removed.” The clean worktree is therefore retained; no manual removal or protection bypass was attempted (`archive-attempt.log`).
- Preflight used native macOS 26.5.2 commands: 12 CPUs, 19327352832 bytes physical memory (18 GiB), `memory_pressure` 69% system-wide memory free, approximately 12.42 GiB as the Mac analogue of available-memory headroom. APFS free space was 166521094144 bytes for exchange, scratch and the new worktree, above 12 GiB. `sysctl`, `vm_stat`, `memory_pressure`, `df -k`, `mount` and `statvfs` replace unavailable Linux nproc/cgroup/procfs/df flags. This is explicitly a native-memory interpretation, not a Linux cgroup measurement.
- Existing pinned Lean 4.25.0 was used; no toolchain download, runtime shim, cache fetch, Lake command or `lake build`. The addendum's exact-pin symlink alternative links `.lake/packages` to the populated campaign package tree. All 11 present URLs/revisions match the manifest; four documentation packages are absent and unused. No other fill's TCSlib oleans or object tree were reused or combined. All 138 prerequisite modules were freshly bootstrapped into `/private/tmp/fill-ladner-shrink/oleans`; the 12 remaining facade prerequisites were built before the final facade check.
- Each Lean-running command acquires one slot through the unchanged issued `lean-slot.sh`, SHA-256 `ff64d8d5b6baf4e7b1c15172a7faeb70246f22c6acf76134bbdb70c017f41f1a`, using default `~/.lean-slots`, cap 3, tag `ladner-shrink`. Inherited slot overrides were absent (`slot-environment.json`). Inside the held slot, checked host `ps -axo comm=` output counts both bare `lean` and full paths ending `/lean`, and a count of three or more would wait/recount with timestamps. The parent separately logs shared-slot queue waits. At most one own Lean runs; every command uses the repository leanelab helper, `-j4`, `nice -n 10`.
- The task's explicit cap three and no-new-admissions rule take precedence over the generic five-slot/sorry-ladder text. The direct brief's prescribed command-line checks take precedence over the generic LeanInfoView-only workflow. No sub-agents were spawned, no work was delegated, and no other worker's source, processes or package builds were modified.
- All logs were written at their final scratch paths from the start; zips contain snapshots, not moved live logs. Five-second process polls are observational and never terminate a module. The first source check's 126.8-second overall duration includes about 121 seconds waiting for a shared slot; the native Lean elaboration itself took 5.72 seconds. A later resource observation found 68% system-wide memory free and no live controller because that check had already finished. No self-imposed proof/module timeout, resource kill or process interruption was used.
- The concurrency log has 24 shared-slot wait events. Maximum observed process count in these observations was 1, and the maximum immediate prelaunch count was 1, always below three. Waits reflect the shared slot protocol even when fewer than three native Lean processes were visible. Maximum logged resident set size was 4499111936 bytes in `bootstrap-084.log`; no resource-shortage condition or crash occurred.

## Delivery

Checkpoint 1 (`b08be6d6b`) preserved the unverified draft and bootstrap logs. A subsequent verified checkpoint and the final zip carry the completed proof and final checks. Zips are generated outside the exchange checkout; the exchange is successfully pulled before copying/staging only the authorized `arora-barak-ch3-4/inbox/fill-ladner-shrink/` artifact. No source branch is pushed, no force push is used, and no pull request is opened. The final zip is also linked in chat as a fallback.

The archive contains this report, the delivered `Ladner.lean`, `Ladner.patch` against `34643146`, source/patch hashes, check/concurrency logs, and public scratch probes as `.lean.txt`. No olean or native build product is shipped. Final artifact verification checks zip integrity and hashes and applies the patch to the exact base, reproducing the delivered source byte-for-byte.

Delivered source SHA-256: `c46143d91a8db4ee57bf0f81b3d8008c0b6f0288f6eb6834e4292f790428211a`.
