# RAM run calculus: checkpoint 1

Base: `25040f435bba85ad563d5c1f1ceb42744aefc3eb` (PR #370, `ram/readers`), fetched read-only from origin. Work branch: `codex/fill-ram-steps`; no rebase of that proof branch. This is a relocation checkpoint, not the final delivery. All edits in the patch are to `TCSlib/Programs/WordRAM/Extended.lean`.

## Target status

The following 14 targets are proved, elaborate successfully, and have no `sorryAx` dependency:

- `WordRAM.XSteps.trans`
- `WordRAM.xstep_map_base`
- `WordRAM.XSteps.of_steps`
- `WordRAM.XSteps.of_steps_proj`
- `WordRAM.XInstr.card_touches_le`
- `WordRAM.StepsIn.toSteps`
- `WordRAM.Steps.exists_stepsIn`
- `WordRAM.StepsIn.mono`
- `WordRAM.StepsIn.trans`
- `WordRAM.StepsIn.agreeOutside`
- `WordRAM.stepsIn_straight`
- `WordRAM.XStepsIn.toXSteps`
- `WordRAM.XSteps.exists_xStepsIn`
- `WordRAM.XStepsIn.of_stepsIn_proj`

The remaining targets retain their original `sorry`: `HaltsWithin.mono`, `HaltsWithin.touches_le`, `HaltsWithin.unique`, and `HaltsWithin.coin_irrel`. No statement or reader obstruction has been found; this frontier records interrupted ongoing work. Final sketch synchronization, removing an unused private helper, sealing, and the downstream sweep remain pending.

Original remaining proof sketches:

- `HaltsWithin.mono`: **Proof sketch.** The same witnesses: `n < t ≤ t'` and `K.card ≤ f ≤ f'`.
- `HaltsWithin.touches_le`: **Proof sketch.** Forget the footprint (`XStepsIn.toXSteps`) and take the one of `XSteps.exists_xStepsIn`: at most `3 n ≤ 3 t` cells for the `n < t` steps before the verdict.
- `HaltsWithin.unique`: **Proof sketch.** `xstep` is a function, so the two `XSteps` runs agree up to the shorter length. There one of them gives a verdict; the other cannot continue past it, so the lengths agree, and the last configurations, verdicts and outputs coincide.
- `HaltsWithin.coin_irrel`: **Proof sketch.** `xstep` reads `ρ` only at a `coin` instruction; induction on the run.

## Verification

- `checkpoint-1-owned.log`: exit 0; exactly the four still-open target admission warnings, plus nonfatal style warnings. Fresh owned-module olean generated.
- `checkpoint-1-axioms.log`: exit 0. All 14 proved targets use only `propext`, `Classical.choice`, and/or `Quot.sound`. None reaches `sorryAx`, so no admitted-dependency walk is required for them.
- `checkpoint-1-freeze.log`: 34 public declarations before and after; no added or removed public declaration; only the 14 authorized theorem bodies differ. Final byte-level statement audit is pending.
- `checkpoint-1-diff-stat.log`: the delivered patch changes only the owned file (260 lines changed at this checkpoint).
- Bootstrap: `WordRAM/Basic`, `Programs/Util/Basic`, `WordRAM/Steps`, each exit 0 at the pinned base, into a fresh private olean tree. The remaining dependency closure and five downstream modules are listed in `evidence/` and have not yet been replayed.

## Private helpers and reuse

- `mapped_fetch`: derives mapped fetches from the imported `List.getD_eq_getElem?_getD`, `List.getElem?_map`, and `Option.getD_map`. The brief's `List.getD_map` is not in the fixed import closure.
- `xstep_base_fetch`: one shared instruction comparison using the published `step_def` and `effect_def` equations. Memory functions are identified by `Function.update_apply`.
- `projected_fetch`: projection fetches in a non-verdict step are base instructions; excludes replacement instructions by `step_reject`.
- `lift_run`: shared induction for step-preserving maps, used by conservativity and footprint forgetting.
- `footprint_mono`: shared induction for footprint inclusion.
- `exists_footprint`: shared finite-union construction for base and extended runs, using `Finset.card_union_le`.
- `stepsIn_mono`: base-run instance of `footprint_mono`, supporting the frozen declaration order.
- `step_agreeOutside`: the one-step frame, using `step_def`, `AgreeOutside.refl`, and `AgreeOutside.update`.
- `xStepsIn_mono`: extended-run instance of `footprint_mono`; currently unused and scheduled for removal.

Searched the import closure, especially `WordRAM/Steps.lean`, before adding these helpers. Reused the existing `steps_straight` (including its singleton specialization), `Steps.zero_iff`, `Steps.succ_iff`, `CodeAt.head/left/tail`, `effects_nil/cons`, and the `AgreeOutside` API. Other-file TCSlib definitions read are `step`, `effect`, and `Steps` through their published equations; `CodeAt` and `AgreeOutside` are consumed only through their lemmas, while `effects` uses `effects_nil/cons`. `wd` is a reducible abbreviation. No imports or public statements change.

## Environment and waits

macOS/APFS, 12 logical CPUs, 18 GiB RAM, about 120.6 GiB free disk at preflight, system memory free percentage 75%; raw observations are in `preflight.log`. Linux-only cgroup and `/proc` checks were replaced with native macOS memory and filesystem readings. Existing toolchain Lean 4.25.0. The package directory is a symlink to the populated main checkout cache, permitted by the environment addendum. Every present package matches the manifest URL and revision; documentation packages are absent. No cache download or package mutation occurred.

Checks ran one at a time through `leanelab.sh` / `leanelab-o.sh`, under `nice -n 10`, `lean -j4`, with `TCSLIB_LEAN_SLOTS=3` and a process-count check before each start. There were no waits. Sandbox elevation was needed for process inspection, isolated-worktree writes, and Git metadata operations. No `lake build` was run. The worktree's checkout machinery also produced unrelated dataset diffs; they are excluded from this delivery and have not been edited by the proof work.

The bundle and README passed SHA-256 verification. Bundle hash: `5625e8f27fe1c325550231c6482c72611db0fa2f03ab638b97c848256813423c`.
