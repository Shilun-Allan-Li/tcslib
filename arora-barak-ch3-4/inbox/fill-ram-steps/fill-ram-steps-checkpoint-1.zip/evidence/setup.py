import pathlib, json, subprocess, re
wt=pathlib.Path('/Users/seyoonr/.codex/worktrees/fill-ram-steps/tcslib-exchange')
r=pathlib.Path('/private/tmp/fill-ram-steps')
log=[]
for p in json.loads((wt/'lake-manifest.json').read_text())['packages']:
    name=p['name'].strip('«»'); d=wt/'.lake/packages'/name
    if not d.exists() and name=='Qq': d=wt/'.lake/packages/Qq'
    if not d.exists(): log.append(f'{name}: ABSENT'); continue
    rev=subprocess.check_output(['git','-C',str(d),'rev-parse','HEAD'],text=True).strip()
    url=subprocess.check_output(['git','-C',str(d),'remote','get-url','origin'],text=True).strip()
    ok=(rev==p['rev'] and url==p['url'])
    log.append(f'{name}: {"MATCH" if ok else "MISMATCH"} {rev} {url}')
    if not ok: raise SystemExit('\n'.join(log))
log.append('PASS: every present package matches manifest URL and revision.')
(r/'evidence/logs/package-pins.log').write_text('\n'.join(log)+'\n')
print('\n'.join(log))
paths=list((wt/'TCSlib').rglob('*.lean'))
graph={str(p.relative_to(wt)).removesuffix('.lean'):[m.replace('.','/') for m in re.findall(r'^import\s+(TCSlib\S*)',p.read_text(),re.M)] for p in paths}
owner='TCSlib/Programs/WordRAM/Extended'
down={owner}
while True:
    newer=down|{m for m,imps in graph.items() if any(i in down for i in imps)}
    if newer==down: break
    down=newer
order=[]
def visit(m):
    if m in order: return
    for i in graph[m]: visit(i)
    order.append(m)
visit(owner)
(r/'evidence/import-order.txt').write_text('\n'.join(order[:-1])+'\n')
for m in sorted(down): visit(m)
(r/'evidence/downstream-order.txt').write_text('\n'.join(m for m in order if m in down and m!=owner)+'\n')
(r/'evidence/full-order.txt').write_text('\n'.join(order)+'\n')
roots=sorted({m for p in order for m in re.findall(r'^import\s+(Mathlib\S*)',(wt/(p+'.lean')).read_text(),re.M)})
(r/'evidence/logs/mathlib-roots.txt').write_text('\n'.join(roots)+'\n')
print(f'{len(order)} modules in full closure; {len(down)-1} downstream; {len(roots)} Mathlib roots')
