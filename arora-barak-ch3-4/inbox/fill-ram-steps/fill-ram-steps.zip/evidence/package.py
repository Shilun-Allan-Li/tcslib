from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,subprocess
r=Path('/private/tmp/fill-ram-steps');owner='TCSlib/Programs/WordRAM/Extended.lean'
assert Path(owner).read_bytes()==(r/'Extended.lean').read_bytes()
assert subprocess.check_output(['git','show','HEAD:'+owner])==(r/'Extended.lean').read_bytes()
assert subprocess.check_output(['git','show','25040f435bba85ad563d5c1f1ceb42744aefc3eb:'+owner])==(r/'Base.lean').read_bytes()
assert subprocess.check_output(['git','diff','25040f435bba85ad563d5c1f1ceb42744aefc3eb','HEAD','--',owner])==(r/'fill-ram-steps.patch').read_bytes()
p=subprocess.run(['git','diff','--check','25040f435bba85ad563d5c1f1ceb42744aefc3eb','HEAD','--',owner],text=True,capture_output=True)
assert p.returncode==0
(r/'evidence/logs/final-whitespace.log').write_text('git diff --check BASE HEAD -- '+owner+f'\nExit code: {p.returncode}\n'+p.stdout+p.stderr)
files={'REPORT.md':r/'REPORT.md',owner:r/'Extended.lean','fill-ram-steps.patch':r/'fill-ram-steps.patch','evidence/Base.lean.txt':r/'Base.lean'}
for name in ['full-order.txt','import-order.txt','downstream-order.txt','targets.txt','sealed-definitions.txt']:
 files['evidence/'+name]=r/'evidence'/name
for name in ['FinalAxioms.lean','Sealed.lean','UnsealedControls.lean','SealedControls.lean']:
 files['evidence/'+name+'.txt']=r/'evidence'/name
for name in ['check.py','setup.py','make_controls.py','write_report.py','package.py']:
 files['evidence/'+name]=r/name
for p in (r/'evidence/logs').iterdir():
 if p.name.startswith(('final-','bootstrap-','replay-')) or p.name in ['preflight.log','package-pins.log','mathlib-roots.txt','import-closure-search.log']:
  files['evidence/logs/'+p.name]=p
sums=''.join(hashlib.sha256(files[n].read_bytes()).hexdigest()+'  '+n+'\n' for n in sorted(files))
out=r/'fill-ram-steps.zip'
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for n in sorted(files):z.write(files[n],n)
 z.writestr('SHA256SUMS',sums)
with ZipFile(out) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for line in z.read('SHA256SUMS').decode().splitlines():
  sha,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==sha
 assert z.read(owner)==(r/'Extended.lean').read_bytes()
 assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
sha=hashlib.sha256(out.read_bytes()).hexdigest()
(r/'package-summary.txt').write_text(f'{out.name}\nSHA-256: {sha}\nBytes: {out.stat().st_size}\nEntries: {len(files)+1}\nZIP CRC and all internal SHA-256 checks passed.\n')
print((r/'package-summary.txt').read_text())
