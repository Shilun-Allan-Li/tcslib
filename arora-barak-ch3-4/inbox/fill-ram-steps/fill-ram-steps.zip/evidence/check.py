import subprocess, pathlib, os, sys, time, datetime
r=pathlib.Path('/private/tmp/fill-ram-steps')
wt='/Users/seyoonr/.codex/worktrees/fill-ram-steps/tcslib-exchange'
env=os.environ.copy(); env.update(TCSLIB_SCRATCH=str(r),TCSLIB_LEAN_SLOTS='3')
def run(file, label, output=False):
    log=r/'evidence/logs'/(label+'.log')
    with log.open('w') as f:
        while True:
            ps=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
            processes=[s for s in ps.splitlines() if s.split() and s.split()[-1].rsplit('/',1)[-1]=='lean']
            f.write(f'Lean count before start: {len(processes)} {processes}\n'); f.flush()
            if len(processes)<3: break
            f.write('WAIT: machine-wide Lean cap\n'); f.flush(); time.sleep(2)
        f.write('Start UTC: '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n');f.flush()
        cmd=['/usr/bin/time','-l','bash',wt+'/devtools/seyoon/'+('leanelab-o.sh' if output else 'leanelab.sh'),wt,str(r/'oleans'),file]
        if output: cmd.append(str(r/'oleans'))
        outfile=None
        if output:
            assert not file.startswith('/')
            outfile=r/'oleans'/file.removesuffix('.lean')
            outfile=outfile.with_suffix('.olean')
            if outfile.exists(): outfile.unlink()
            f.write('Removed stale output before compilation: '+str(outfile)+'\n');f.flush()
        started=time.time()
        result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,cwd=wt)
        if outfile is not None:
            fresh=outfile.is_file() and outfile.stat().st_size>0 and outfile.stat().st_mtime>=started
            f.write('Fresh nonempty output: '+str(fresh)+'\n');f.flush()
            if not fresh: raise RuntimeError('Missing fresh olean: '+str(outfile))
        f.write('End UTC: '+datetime.datetime.now(datetime.timezone.utc).isoformat()+f'\nExit code: {result.returncode}\n')
    text=log.read_text(); print(f'{label}: exit {result.returncode}',flush=True)
    if result.returncode or 'error:' in text:
        print(text,flush=True);return False
    return True
if sys.argv[1]=='bootstrap':
    for mod in (r/'evidence/import-order.txt').read_text().splitlines():
        if not run(mod+'.lean','bootstrap-'+mod.replace('/','_'),True): sys.exit(1)
elif sys.argv[1]=='rest':
    before=set((r/'evidence/import-order.txt').read_text().splitlines())
    before.add('TCSlib/Programs/WordRAM/Extended')
    for mod in (r/'evidence/full-order.txt').read_text().splitlines():
        if mod in before: continue
        if not run(mod+'.lean','replay-'+mod.replace('/','_'),True):sys.exit(1)
else:
    file=sys.argv[1];label=sys.argv[2]
    sys.exit(0 if run(file,label,len(sys.argv)>3) else 1)
