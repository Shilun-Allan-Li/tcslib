from pathlib import Path
import re
r=Path('/private/tmp/fill-ram-steps');wt=Path('/Users/seyoonr/.codex/worktrees/fill-ram-steps/tcslib-exchange')
s=(wt/'TCSlib/Programs/WordRAM/Steps.lean').read_text()
attrs='attribute [local irreducible] '+ ' '.join((r/'evidence/sealed-definitions.txt').read_text().splitlines())+'\nattribute [-simp] WordRAM.effects_nil WordRAM.effects_cons\n'
header='import TCSlib.Programs.WordRAM.Steps\n\n'
examples=[
('exec','(P : List Instr) (pc : ℕ) (m : ℤ → BitVec W)', 'exec P 0 pc m = none'),
('loadWords','(ws : List ℤ) (a : ℤ)', 'loadWords W ws a = (if a < 0 then 0 else BitVec.ofInt W (ws.getD a.toNat 0))'),
('InRange','(v : ℤ)', 'InRange W v ↔ -(2 : ℤ) ^ W ≤ 2 * v ∧ 2 * v < (2 : ℤ) ^ W'),
('step','(P : List Instr) (c : Cfg W)',None),
('Steps','(P : List Instr) (c d : Cfg W)', 'Steps P 0 c d ↔ c = d'),
('CodeAt','(P : List Instr) (pc : ℕ) (l : List Instr)', 'CodeAt P pc l ↔ l <+: P.drop pc'),
('Straight','(i : ℤ)', 'Straight (.one i) ↔ True'),
('effect','(i : ℤ) (m : ℤ → BitVec W)', 'effect (.one i) m = Function.update m i (wd W 1)'),
('effects','(m : ℤ → BitVec W)', 'effects [] m = m'),
('AgreeOutside','(K : Set ℤ) (m m\' : ℤ → BitVec W)', 'AgreeOutside K m m\' ↔ Set.EqOn m\' m Kᶜ'),
('WritesIn','(K : Set ℤ) (i : ℤ)', 'WritesIn K (.one i) ↔ i ∈ K')]
step=re.search(r'theorem step_def \(P.*? := rfl',s,re.S)[0]
step=step.split(':\n',1)[1].rsplit(' := rfl',1)[0].strip()
examples[3]=(examples[3][0],examples[3][1],step)
unsealed=header+'namespace WordRAM\nvariable {W : ℕ}\n\n'
sealed=header+attrs+'namespace WordRAM\nvariable {W : ℕ}\n\n'
for name,bind,goal in examples:
 unsealed+=f'-- Definitional control: {name}\nexample {bind} :\n    {goal} := by rfl\n\n'
 sealed+=f'-- Sealed definitional control: {name}\nexample {bind} : True := by\n  fail_if_success\n    have _ : {goal} := by rfl\n  trivial\n\n'
# Published API control goals remain provable with the same seals.
for n,args in [('step_def','P c'),('effect_def','i m')]:
 text=re.search(r'theorem '+n+r' .*? := rfl',s,re.S)[0]
 text=text.replace('theorem '+n,'example',1).removesuffix(' := rfl')+' := '+n+' '+args+'\n\n'
 sealed+='-- Published equation control\n'+text
sealed+='''example (P : List Instr) (c d : Cfg W) : Steps P 0 c d ↔ c = d := Steps.zero_iff
example (P : List Instr) (n : ℕ) (c d : Cfg W) :
    Steps P (n + 1) c d ↔ ∃ e, step P c = .inl e ∧ Steps P n e d := Steps.succ_iff
example (m : ℤ → BitVec W) : effects [] m = m := effects_nil m
example (P : List Instr) : CodeAt P 0 P := codeAt_self P
example (K : Set ℤ) (m : ℤ → BitVec W) : AgreeOutside K m m := AgreeOutside.refl K m
example (i : Instr) (hi : Straight i) : Straight i := hi
'''
(r/'evidence/UnsealedControls.lean').write_text(unsealed+'end WordRAM\n')
(r/'evidence/SealedControls.lean').write_text(sealed+'end WordRAM\n')
print('Wrote 11 definitional controls and the published API controls.')
