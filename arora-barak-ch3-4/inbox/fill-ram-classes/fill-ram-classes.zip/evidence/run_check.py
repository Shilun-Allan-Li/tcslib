import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-classes/tcslib-exchange')
SCRATCH = Path('/private/tmp/fill-ram-classes')
LOGS = SCRATCH / 'evidence/logs'
ENV = dict(os.environ, TCSLIB_SCRATCH=str(SCRATCH), TCSLIB_LEAN_SLOTS='3')
ENV['PATH'] = '/Users/seyoonr/.elan/bin:' + ENV.get('PATH', '')


def check(module, label=None, write=True, overlay=None):
    label = label or module.replace('/', '__').removesuffix('.lean')
    ol = str(overlay or SCRATCH / 'oleans')
    with (LOGS / (label + '.log')).open('w') as log:
        while True:
            lines = subprocess.check_output(['ps', 'ax', '-o', 'pid=,comm='], text=True).splitlines()
            processes = [line for line in lines if line.split() and Path(line.split()[-1]).name == 'lean']
            log.write(f'{datetime.datetime.now().isoformat()} machine Lean count: {len(processes)}\n')
            if processes:
                log.write('\n'.join(processes) + '\n')
            log.flush()
            if len(processes) < 3:
                break
            log.write('WAIT: machine-wide Lean cap\n')
            log.flush()
            time.sleep(5)
        wrapper = 'leanelab-o.sh' if write else 'leanelab.sh'
        cmd = ['/usr/bin/time', '-l', 'bash', str(WT / 'devtools/seyoon' / wrapper), str(WT), ol, module]
        if write:
            cmd.append(ol)
        if write:
            target = Path(ol) / (module.removesuffix('.lean') + '.olean')
            target.parent.mkdir(parents=True, exist_ok=True)
            target.unlink(missing_ok=True)
        log.write('START ' + datetime.datetime.now().isoformat() + '\n')
        log.flush()
        start = time.monotonic()
        run = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, env=ENV, cwd=WT)
        elapsed = time.monotonic() - start
        log.write(f'END {datetime.datetime.now().isoformat()} exit={run.returncode} seconds={elapsed:.3f}\n')
    text = (LOGS / (label + '.log')).read_text()
    passed = run.returncode == 0 and 'error:' not in text and (not write or target.is_file() and target.stat().st_size > 0)
    with (LOGS / 'check-results.jsonl').open('a') as out:
        out.write(json.dumps(dict(module=module, label=label, exit=run.returncode, pass_check=passed, seconds=elapsed)) + '\n')
    print(f'{"PASS" if passed else "FAIL"} {module} ({elapsed:.1f}s)', flush=True)
    if not passed:
        print(text, flush=True)
    return passed


if __name__ == '__main__':
    if sys.argv[1] == 'bootstrap':
        for module in (LOGS / 'bootstrap-order.txt').read_text().splitlines():
            if not check(module + '.lean'):
                sys.exit(1)
    else:
        sys.exit(0 if check(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None, write=not os.path.isabs(sys.argv[1])) else 1)
