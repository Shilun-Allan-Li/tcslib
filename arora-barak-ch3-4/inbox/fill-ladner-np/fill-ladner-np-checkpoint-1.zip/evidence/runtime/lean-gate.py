#!/usr/bin/env python3
import os,sys,subprocess,datetime,time
log='/private/tmp/ladner-np-20261115/evidence/logs/concurrency.log'
while True:
    p=subprocess.run(['ps','-axo','comm='],text=True,capture_output=True,check=True)
    count=sum(s.strip().rsplit('/',1)[-1]=='lean' for s in p.stdout.splitlines())
    with open(log,'a') as f:f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+f' {"LAUNCH" if count<3 else "WAIT"} machine_lean_count={count} argv={sys.argv[1:]!r}\n')
    if count<3:break
    time.sleep(5)
os.execv('/usr/bin/time',['/usr/bin/time','-l','/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin/lean',*sys.argv[1:]])
