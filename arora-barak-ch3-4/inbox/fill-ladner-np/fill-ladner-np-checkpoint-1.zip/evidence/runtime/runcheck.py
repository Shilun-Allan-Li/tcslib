from pathlib import Path
import subprocess,os,datetime,sys,hashlib
r=Path('/private/tmp/ladner-np-20261115')
w=Path('/Users/seyoonr/.codex/worktrees/ladner-np/tcslib-exchange')
env=dict(os.environ,PATH=str(r/'bin')+':'+os.environ['PATH'],TCSLIB_LEAN_SLOTS='3',TCSLIB_SCRATCH='/Users/seyoonr/.tcslib-scratch')
def run(label,file,compile=False):
    log=r/'evidence/logs'/f'{label}.log'
    cmd=['bash',str(w/'devtools/seyoon'/('leanelab-o.sh' if compile else 'leanelab.sh')),str(w),str(r/'oleans'),file]
    if compile:cmd.append(str(r/'oleans'))
    source=Path(file) if Path(file).is_absolute() else w/file
    digest=hashlib.sha256(source.read_bytes()).hexdigest() if source.is_file() else ''
    product=r/'oleans'/Path(file).with_suffix('.olean') if compile else None
    if product is not None and product.exists():product.unlink()
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(f'{start} START {label}',flush=True)
    with log.open('w') as f:
        f.write(f'{start} START {cmd!r}\nsource_sha256={digest}\n');f.flush()
        p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
        end=datetime.datetime.now(datetime.timezone.utc).isoformat()
        f.write(f'\n{end} END exit_code={p.returncode}\n')
    out=log.read_text()
    failed=p.returncode!=0 or 'error:' in out or (product is not None and (not product.is_file() or product.stat().st_size==0))
    with (r/'evidence/logs/check-summary.log').open('a') as f:f.write(f'{start} {end} {label} exit_code={p.returncode} verified={not failed}\n')
    print(f'{end} END {label} exit_code={p.returncode}',flush=True)
    if failed:print(out,flush=True)
    return 1 if failed else 0
if sys.argv[1]=='bootstrap':
    for m in (r/'evidence/logs/bootstrap-order.txt').read_text().splitlines():
        if m in ['TCSlib/Complexity/Diagonalization/Ladner','TCSlib/Complexity/Diagonalization']:continue
        if run('bootstrap-'+m.replace('/','_'),m+'.lean',True):sys.exit(1)
else:sys.exit(run(sys.argv[1],sys.argv[2],len(sys.argv)>3 and sys.argv[3]=='olean'))
