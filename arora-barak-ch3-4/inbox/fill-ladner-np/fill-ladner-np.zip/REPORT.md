# Ladner fill 5 — SAT_H_mem_NP proved

Date: 2026-11-15 (America/Los_Angeles).

- [x] Target 2 `Complexity.SAT_H_mem_NP` proved, with the verifier, its two leaves and the generic padding-NP assembly.
- [x] Base recorded; no rebase; only the owned file changed at the specified anchor.
- [x] New declarations, prior fact searches and definition readers documented below.
- [x] Source, axiom, sealing/control, semantic edge and facade checks pass, with logs and exit codes.
- [x] Environment adaptations, shared slot protocol, and concurrency log included.

There is no remaining E-READER, E-HOST, E-STATEMENT or E-RES escalation. The delivered target is complete, rather than a frontier. The two unrelated admitted targets remain unchanged.

## Pins and scope

Repository: Shilun-Allan-Li/tcslib.
Base: `34643146ee1fe6bf6d7ffdf2e543e8342a3e16a0` (campaign after #321).
Local branch: `fill/ladner-np`, never rebased or pushed.
Proof commit: `a6f7ab4e41db39723dd67dad655b4a885ac2ea67`.
Worktree: `/Users/seyoonr/.codex/worktrees/ladner-np/tcslib-exchange`.

The exchange was pulled with `git pull --rebase` before bundle reading. The bundle's SHA-256 was checked first: `8972bd217a69b0c939202f58a61c9579094e5b438358f908c8e2c2acdd593749`, 13 sections. Input records pin: `739faba95499d3e054e7d23a6366328988ca69e5`; input exchange pin: `e4facafb14e037762b7f5291a403c9c6f6c26b94`.

All four new declarations are private `ladner_` declarations under exactly `/-! ### NP membership of the padded language -/`, immediately before `/-! ### The theorem and its remaining targets -/`. No other section or target body is touched, including the parallel shrinking fill's region and target. No new public declaration, library file, import, simp attribute, sorry, admit or axiom is introduced.

`SAT_H_mem_NP` retains its statement and citation. Its proof sketch is updated under brief ground rule 5's explicit exception: the old sketch guessed the prefix, whereas this route deterministically parses it and guesses only the SAT certificate. This is the sole docstring change. `scope-freeze.log` proves that removing the new section and restoring only this target body and sketch reproduces the base file byte-for-byte. Every other declaration, proof, docstring and import is unchanged.

```
 TCSlib/Complexity/Diagonalization/Ladner.lean | 117 +++++++++++++++++++++++++-
 1 file changed, 113 insertions(+), 4 deletions(-)
```

The delivered file has 2255 lines. The fill worktree is clean, with exactly one commit above the fixed base. All new docstrings cite [AB09, Theorem 3.3 and its proof]; both proofs longer than 20 lines carry a proof sketch.

| Artifact | SHA-256 |
|---|---|
| Base Ladner | `d9defae31494007ecce07944e1ca4aa0fa20ca91e74a89ef32a4e2fb344c5dcb` |
| Delivered Ladner | `dbe5989d84f80e6f0fa2fb1e7991365125387d838d1c5ca40d577dd407bee978` |
| `Ladner.patch` against the full base | `b983bed1baf56a3bf43780ecde8118d9578117d0d6f1822d88033c84c9fa846c` |

The patch applied cleanly in a fresh source-only scratch tree containing the exact base file, reproducing the delivered bytes (`patch-roundtrip.log`). The final successful source check records the same delivered source hash. The library source did not change after that check.

## New declarations, reuse and proof route

| New private declaration | Role and existing facts used |
|---|---|
| `ladner_verifier` | The prescribed paired verifier: parse `pairFstD S`, check the suffix power, require the second component's length to be prefix length plus one, and consult `V` on the concatenation of prefix and certificate. This is the bundled specification. |
| `ladner_verifier_P` | Recover the prefix with frozen `ladner_parse_FP` and `BinArith.polyTimeComputable_slot2`. Intersect the test from frozen `ladner_syntax_FP` with `lenEq_preimage_mem_P` and `preimage_mem_P hV`, using `mem_P_of_test` and `inter_mem_P`. Reconstruction is FP append. |
| `ladner_verifier_equiv` | Use frozen `ladner_pad_membership` and `ladner_parsed_length`, the supplied linear SAT certificate equivalence and the named pair projections. The parser's strict prefix bound gives the NP certificate bound. A single local paired-reader fact is shared by the two directions. |
| `ladner_padded_NP` | Consume the previous two leaves through `mem_NP_iff_exists_length_le`, with coefficient and degree both one. Its binding statement has exactly the prescribed meaning, with no extra premise. |

The target assembly is the prescribed `SAT_H_eq`, `ladner_padded_NP`, proved `ladnerH_polyTime`, and public `SAT_exists_linear_verifier`. No other Ladner target is used. There are no new hosts or loops, and no private parser implementation is repeated.

Before drafting the helpers, `helper-search.log` recorded candidate enumeration over the exact 140-module import closure and inspection of matching parser, syntax, padding, verifier and class-closure facts. It found and cited the existing parser/membership/strict-prefix leaves and the public FP/P/NP closures above. In particular, the length comparison uses the published `lenEq_preimage_mem_P`; syntax uses the existing saturated-power implementation. A follow-up inspection identified Mathlib's `Language` membership wrapper and its permitted `show` normalization. The search record is candidate enumeration and inspection, not an exhaustive semantic-duplication claim.

The official copy screen ran under the shared screen lock on Ladner plus PClosure, Reductions, NP, PolyTimePairing, PolyTime, ClassP/P, BinaryArith/Loops, BinaryArith/Words and TuringMachine/Encoding. Base/head: 272/277 screened declarations; 135/136 pairs; 20,302/20,410 reproduced characters. The sole new pair is `ladner_verifier_P` versus the frozen `ladner_memoStep_FP` (108/162 characters): common FP-composition/append/projection syntax for different functions. Inspection found no re-derived published fact in this match. The full population and screen script are included as text; raw base/head/delta logs are included. No new copied proved-material debt is claimed.

## Definition boundaries and Rule 10

| Other-file TCSlib definition | Reader or contract |
|---|---|
| `Turing.pairEncode` | Construct the NP reader's input; read it only with `pairFstD_pairEncode` and `pairSndD_pairEncode`. Its equation control uses `pairEncode_eq`. |
| `pairFstD`, `pairSndD` | Named pair projection equations and public FP projection/slot2 theorems. |
| `P` | Public `mem_P_of_test`, `preimage_mem_P`, `inter_mem_P`, `lenEq_preimage_mem_P`; control uses `mem_P_iff`. No class-definition body is read. |
| `NP` | `mem_NP_iff_exists_length_le`, preserving the paired certificate layout. No class-definition body is read. |
| `PolyTimeComputable` | Public FP composition, append, constant and projection closures; control uses `polyTimeComputable_iff`. No existential machine witness is destructed here. |

`SAT` occurs atomically through the supplied/public linear-verifier contract; its implementation and private verifier representation are not opened. All parser, syntax and padding definitions reached directly are in this owned file and reused through its frozen leaves. `BinArith.decWords` is not read by the new section and keeps its native irreducibility.

Mathlib's `Language` is a type synonym with a separate membership instance. `show` normalizes this wrapper and the local language `W`; no core/Mathlib definition is an explicit argument to simp/rw/unfold. Core list lengths use their equation lemmas. The new section's complete rewrite arguments are recorded in `rewrite-arguments.log` and were inspected. Only owned definitions/local definitions and equation lemmas appear explicitly.

The scratch sealed copy places the new section and the changed target in separate sections, marking pairEncode, both projections, P, NP and PolyTimeComputable locally irreducible. These six definitions have no definition-level simp attributes to remove. Six delta controls pass unsealed and are required to fail sealed; six equation/reader controls pass sealed. No unsafe reducibility override or new library attribute is used.

## Layout, arithmetic and semantic edge checks

The SAT reader receives `prefix ++ u`; the outer NP reader receives `pairEncode y u`. The deterministic parser supplies the prefix, so no split is guessed. The exponent function is applied at that prefix length by frozen `ladner_syntax_FP`/`ladner_padSyntax_FP`. Full powers occur only in semantic statements: their computational comparison is the existing capped power. No full power is allocated on the strength of a bit-length bound.

`semantic-edges-pass.log` checks the following via the new equivalence and the existing parser/padding equations, without duplicating a parser:

- Exponent zero gives a one-true-bit suffix for any SAT prefix and provides the correctly paired NP certificate.
- Empty prefix with exponent zero uses `[false, true]`, including `0 ^ 0 = 1`.
- `[false, true, false, false, true]` parses at its last false, yielding prefix `[false, true, false]` and suffix length one.
- All-true words are rejected for every length, including the empty word.
- Empty prefix with a positive exponent uses `[false]`, since `0 ^ e = 0` for positive `e`.
- `[false]` is rejected when the exponent is zero: suffix length zero cannot equal `0 ^ 0 = 1`.

Acceptance examples with an empty SAT prefix carry an explicit `[] ∈ SAT` hypothesis, and all verifier examples carry the stated linear certificate equivalence. They do not assert unverified nonemptiness. The target itself is unconditional, since it supplies the public linear-verifier existence theorem.

## Final verification

| Check | Exit | Evidence |
|---|---:|---|
| Pinned Lean version | 0 | `toolchain.log`: 4.25.0, cdd38ac5115bdeec5f609e9126cce00f51ae88b3 |
| Mathlib-root cache probe | 0 | `cache-probe.log` |
| Fresh import-closure bootstrap | 0 each | 138 prerequisites, order and every per-module log included |
| Delivered source | 0 | `Ladner-attempt-2.log`, zero errors, exactly two sorry warnings |
| Axiom wrappers and target | 0 | `axiom-prints.log`, all four new declarations and target |
| Sealed new section/target | 0 | `sealed-source.log` |
| Unsealed delta controls | 0 | `controls-unsealed.log` |
| Sealed delta/reader controls | 0 | `controls-sealed.log` |
| Semantic edge checks | 0 | `semantic-edges-pass.log` |
| Diagonalization facade | 0 | `facade.log`, fresh nonempty olean, zero errors |
| Scope/freeze and patch roundtrip | 0 | `scope-freeze.log`, `patch-roundtrip.log`, `final-verification.json` |
| Copy screen | 0 each | `copy-screen-base.log`, `copy-screen-head.log`, `copy-screen-delta.log` |

`Complexity.SAT_H_mem_NP`, `ladner_verifier_P`, `ladner_verifier_equiv` and `ladner_padded_NP` use only `propext`, `Classical.choice`, `Quot.sound`; the verifier definition itself uses only `propext`. No `sorryAx` occurs in these prints. Public scratch wrappers expose the private declarations only in the scratch probe, not in the library.

The only final source warnings are the unchanged admissions `SAT_mem_P_of_padSAT_NPHard` and `SAT_H_intermediate`; the `ladner` packaging theorem remains byte-identical and still depends on the latter. The source proof, its citation and every earlier filled target remain unchanged except for target 2 as stated above.

All attempts are preserved. Attempt 1 exposed the Mathlib Language/Set membership presentation and a reflexive parse equality; attempt 2 fixed them. The semantic harness initially needed its Turing namespace opening, then the exact published `List.replicate_one` equation. These resolved probe iterations required no further library-source change. No checks needed to be skipped for missing prerequisites.

## Environment and concurrency

Native macOS 26.5.2 / arm64 / APFS. Linux nproc/procfs/cgroups are unavailable, so native equivalents are recorded in `preflight.log`: 12 logical CPUs, 19,327,352,832 bytes (18 GiB) RAM, memory_pressure initially 67% free (about 12.06 GiB), 167,052,208 KiB filesystem free (about 159.31 GiB). The 4 GiB memory and 12 GiB disk floors passed. A follow-up with two live Lean processes showed 53% memory_pressure free, about 9.54 GiB. No shortage, crash or self-imposed timeout occurred. Source, scratch and olean paths are disk-backed APFS.

The permitted `.lake/packages` symlink points to `/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`. Every present package's origin URL and HEAD match the manifest (`manifest.log`: `PASS: every present package matches manifest`); absent documentation packages are listed ABSENT and none is imported. All 7,544 package oleans checked were nonempty. The 46 direct Mathlib roots are recorded. No cache fetch, archive-store use, dependency-tree copy, TCSlib object reuse or lake build occurred. The pinned toolchain was preinstalled; no executable-path shim was needed.

A new, initially empty scratch olean tree `/private/tmp/ladner-np-20261115/oleans` was bootstrapped from this base's sources. The owned module and facade were checked after all 138 prerequisites. Each Lean launch runs through the inspected leanelab[-o].sh under nice -n 10, -j4. The Mathlib probe uses this required throttled wrapper rather than the addendum's unthrottled example script. Native platform readings and this permitted symlink are the environment adaptations; sandbox escalation was needed for Git metadata/native process access and succeeded.

Shared slot protocol: `/Users/seyoonr/.tcslib-scratch/locks/lean-slot-*`, with TCSLIB_LEAN_SLOTS=3. A task-specific PATH gate supplements it by executing `ps -axo comm=` immediately before the actual pinned Lean executable and counting both bare `lean` and full executable paths ending in `/lean`. Count >=3 would log a UTC timestamp, wait five seconds and recount. The user-specific cap of three overrides the older generic cap of five. At most one Lean of this fill runs at a time, including the bootstrap and all probes.

Totals: **150 Lean launches; 0 machine-count waits; maximum prelaunch machine Lean count 2**. Every launch satisfied count <3; other jobs' Lean processes were included. Every module/check has start/end times, exit status and `/usr/bin/time -l` peak memory in its final log path. No log was relocated while active. `concurrency.log` and `check-summary.log` provide the complete launch/serialization evidence.

## Delivery

`fill-ladner-np.zip` includes this report, exact `Ladner.lean`, `Ladner.patch` against the full base, all check/concurrency/search/screen logs, and the scratch probes and reproduction scripts as text. No compiled artifacts are shipped.

Checkpoint 1 was pushed in exchange commit `b8023ee2228cd828c8f0a5ef8508593ce96333d6` and is explicitly marked as an unverified in-progress draft; this final zip supersedes it. The final authorized destination is `arora-barak-ch3-4/inbox/fill-ladner-np/` on `exchange/pass-shelat-ch5-8`, with git pull --rebase before push, only that folder added and no force push. No other branch is pushed and no PR is opened. The same final zip is linked in chat as fallback.
