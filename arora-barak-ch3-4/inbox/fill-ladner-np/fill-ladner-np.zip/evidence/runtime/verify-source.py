from pathlib import Path
import subprocess,re,hashlib
r=Path('/private/tmp/ladner-np-20261115')
w=Path('/Users/seyoonr/.codex/worktrees/ladner-np/tcslib-exchange')
base='34643146ee1fe6bf6d7ffdf2e543e8342a3e16a0'
p='TCSlib/Complexity/Diagonalization/Ladner.lean'
s=(w/p).read_text()
b=subprocess.check_output(['git','show',base+':'+p],cwd=w).decode()
start='/-! ### NP membership of the padded language -/'
end='/-! ### The theorem and its remaining targets -/'
assert s.count(start)==1 and s.count(end)==1
new=s[s.index(start):s.index(end)]
rest=s[:s.index(start)]+s[s.index(end):]
pat=r'(theorem SAT_H_mem_NP : SAT_H ∈ NP) := by\n.*?(?=\n\n/-- Polynomial-time computable, diverging padding)'
rest,n=re.subn(pat,lambda m:m[1]+' :=\n  sorry',rest,flags=re.S)
assert n==1
newsketch='**Proof sketch.** Parse the final false separator to recover the prefix and guess its\nSAT certificate. Compute the index at the prefix length and check the prescribed unary suffix.'
oldsketch='**Proof sketch.** Guess the satisfiable prefix and its SAT certificate. Compute the\nindex at that prefix length and check the separator and exactly prescribed unary suffix.'
assert rest.count(newsketch)==1
rest=rest.replace(newsketch,oldsketch)
assert rest==b
assert 'sorry' not in new and 'admit' not in new and 'axiom ' not in new and '@[simp]' not in new
names=re.findall(r'^private (?:noncomputable )?(?:def|theorem) (\w+)',new,re.M)
assert names==['ladner_verifier','ladner_verifier_P','ladner_verifier_equiv','ladner_padded_NP']
assert len(names)==len(re.findall(r'^(?:private )?(?:noncomputable )?(?:def|theorem) ',new,re.M))
assert subprocess.check_output(['git','diff','--name-only',base],cwd=w,text=True).splitlines()==[p]
assert subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip()=='fill/ladner-np'
ms=list(re.finditer(r'/--[\s\S]*?-/\s*private (def|theorem) (\w+)',new))
for i,m in enumerate(ms):
    body=new[m.end():ms[i+1].start() if i+1<len(ms) else len(new)]
    assert '[AB09,' in m[0]
    if m[1]=='theorem' and len(body.splitlines())>20:assert '**Proof sketch.**' in m[0]
log='PASS: only the new NP section at the exact prescribed anchor, SAT_H_mem_NP body, and its conditionally permitted proof sketch differ from the base.\nPASS: after restoring those target elements and removing that section, the base file is reproduced byte-for-byte.\nPASS: all four new declarations private; no new sorry/admit/axiom/import/simp attribute.\nPASS: attribution and proof sketches.\n'
log+='base_sha256='+hashlib.sha256(b.encode()).hexdigest()+'\nsource_sha256='+hashlib.sha256(s.encode()).hexdigest()+'\n'
log+='\n'.join(names)+'\n'+subprocess.check_output(['git','diff','--stat',base],cwd=w,text=True)
(r/'evidence/logs/scope-freeze.log').write_text(log)
(r/'evidence/logs/rewrite-arguments.log').write_text(new)
print(log)
