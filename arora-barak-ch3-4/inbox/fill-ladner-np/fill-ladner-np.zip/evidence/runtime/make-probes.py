from pathlib import Path
import re

r = Path('/private/tmp/ladner-np-20261115')
w = Path('/Users/seyoonr/.codex/worktrees/ladner-np/tcslib-exchange')
s = (w / 'TCSlib/Complexity/Diagonalization/Ladner.lean').read_text()
start = '/-! ### NP membership of the padded language -/'
end = '/-! ### The theorem and its remaining targets -/'
names = re.findall(r'^private (?:def|theorem) (\w+)', s[s.index(start):s.index(end)], re.M)

axioms = s + '\nnamespace Complexity\n'
for name in names:
    axioms += f'noncomputable def LadnerNPProbe_{name} := @{name}\n'
    axioms += f'#print axioms Complexity.LadnerNPProbe_{name}\n'
axioms += 'end Complexity\n#print axioms Complexity.SAT_H_mem_NP\n'
(r / 'AxiomProbe.lean').write_text(axioms)

attrs = '''section
attribute [local irreducible] Turing.pairEncode pairFstD pairSndD P NP PolyTimeComputable

'''
sealed = s.replace(start, attrs + start, 1).replace(end, 'end\n\n' + end, 1)
target_doc = '/-- The padded SAT witness is in NP.'
next_doc = '/-- Polynomial-time computable, diverging padding'
assert sealed.count(target_doc) == 1 and sealed.count(next_doc) == 1
sealed = sealed.replace(target_doc, attrs + target_doc, 1)
sealed = sealed.replace(next_doc, 'end\n\n' + next_doc, 1)
(r / 'Sealed.lean').write_text(sealed)

header = '''import TCSlib.Complexity.Diagonalization.Ladner
namespace Complexity
open Turing
open scoped Classical
'''
deltas = [
    'pairEncode ([] : List Bool) [] = [false, true]',
    'pairFstD ([] : List Bool) = []',
    'pairSndD ([] : List Bool) = []',
    'P = ⋃ c : ℕ, DTIME (fun n => n ^ c + 1)',
    '''NP = {L | ∃ (C c : ℕ) (V : Language Bool), V ∈ P ∧
      ∀ x : List Bool, x ∈ L ↔ ∃ u : List Bool,
        u.length = C * (x.length + 1) ^ c ∧ x ++ u ∈ V}''',
    '''PolyTimeComputable (fun x : List Bool => x) ↔
      ∃ (M : FinTM Bool) (C c : ℕ),
        M.ComputesFunInTime (fun x => x) (fun n => C * (n + 1) ^ c)''',
]
unsealed = header
for goal in deltas:
    unsealed += f'example : {goal} := by rfl\n'
unsealed += 'end Complexity\n'
(r / 'ControlsUnsealed.lean').write_text(unsealed)

controls = header + attrs
for goal in deltas:
    controls += f'''example : True := by
  fail_if_success
    have : {goal} := by rfl
  exact True.intro
'''
controls += '''example (a b : List Bool) :
    pairEncode a b = (a.flatMap fun c => [c, c]) ++ [false, true] ++ b := pairEncode_eq a b
example (a b : List Bool) : pairFstD (pairEncode a b) = a := pairFstD_pairEncode a b
example (a b : List Bool) : pairSndD (pairEncode a b) = b := pairSndD_pairEncode a b
example (L : Language Bool) : L ∈ P ↔ ∃ (C d : ℕ) (M : FinTM Bool),
    M.DecidesInTime L (fun n => C * (n + 1) ^ d) := mem_P_iff
example (L : Language Bool) : L ∈ NP ↔ ∃ (C c : ℕ) (V : Language Bool), V ∈ P ∧
    ∀ x : List Bool, x ∈ L ↔ ∃ u : List Bool,
      u.length ≤ C * (x.length + 1) ^ c ∧ pairEncode x u ∈ V :=
  mem_NP_iff_exists_length_le
example (f : List Bool → List Bool) : PolyTimeComputable f ↔
    ∃ (M : FinTM Bool) (C c : ℕ), M.ComputesFunInTime f (fun n => C * (n + 1) ^ c) :=
  polyTimeComputable_iff f
end
end Complexity
'''
(r / 'ControlsSealed.lean').write_text(controls)

semantic = s + '''
namespace Complexity
open Turing

theorem LadnerNPProbe_zeroExponent {V : Language Bool}
    (hcert : ∀ x : List Bool, x ∈ SAT ↔
      ∃ u : List Bool, u.length = x.length + 1 ∧ x ++ u ∈ V)
    (p : List Bool) (hp : p ∈ SAT) :
    ∃ u : List Bool, u.length ≤ (p ++ false :: [true]).length + 1 ∧
      pairEncode (p ++ false :: [true]) u ∈ ladner_verifier (fun _ => 0) V := by
  apply (ladner_verifier_equiv hcert _).mp
  refine mem_padSAT_iff.mpr ⟨p, hp, ?_⟩
  simp only [pow_zero, List.replicate_one]

example {V : Language Bool}
    (hcert : ∀ x : List Bool, x ∈ SAT ↔
      ∃ u : List Bool, u.length = x.length + 1 ∧ x ++ u ∈ V)
    (hSAT : ([] : List Bool) ∈ SAT) :
    ∃ u : List Bool, u.length ≤ 3 ∧
      pairEncode [false, true] u ∈ ladner_verifier (fun _ => 0) V := by
  simpa only [List.nil_append, List.length_cons, List.length_nil] using
    LadnerNPProbe_zeroExponent hcert [] hSAT

example : ladner_parse [false, true, false, false, true] = some ([false, true, false], 1) := by
  simpa only [List.cons_append, List.nil_append, List.replicate_succ,
    List.replicate_zero] using ladner_parse_pad [false, true, false] 1

example {h : ℕ → ℕ} {V : Language Bool}
    (hcert : ∀ x : List Bool, x ∈ SAT ↔
      ∃ u : List Bool, u.length = x.length + 1 ∧ x ++ u ∈ V) (n : ℕ) :
    ¬ ∃ u : List Bool, u.length ≤ (List.replicate n true).length + 1 ∧
      pairEncode (List.replicate n true) u ∈ ladner_verifier h V := by
  intro hu
  have hy := (ladner_verifier_equiv hcert _).mpr hu
  obtain ⟨p, t, hparse, _, _⟩ := ladner_pad_membership.mp hy
  have hn : ladner_parse (List.replicate n true) = none :=
    (ladner_parse_none _).mpr (by simp only [List.mem_replicate]; aesop)
  rw [hn] at hparse
  cases hparse

example {V : Language Bool}
    (hcert : ∀ x : List Bool, x ∈ SAT ↔
      ∃ u : List Bool, u.length = x.length + 1 ∧ x ++ u ∈ V)
    (hSAT : ([] : List Bool) ∈ SAT) (e : ℕ) (he : 0 < e) :
    ∃ u : List Bool, u.length ≤ 2 ∧
      pairEncode [false] u ∈ ladner_verifier (fun _ => e) V := by
  apply (ladner_verifier_equiv hcert [false]).mp
  refine mem_padSAT_iff.mpr ⟨[], hSAT, ?_⟩
  simp only [List.length_nil, zero_pow (Nat.ne_of_gt he), List.nil_append, List.replicate_zero]

example {V : Language Bool}
    (hcert : ∀ x : List Bool, x ∈ SAT ↔
      ∃ u : List Bool, u.length = x.length + 1 ∧ x ++ u ∈ V) :
    ¬ ∃ u : List Bool, u.length ≤ 2 ∧
      pairEncode [false] u ∈ ladner_verifier (fun _ => 0) V := by
  intro hu
  have hy := (ladner_verifier_equiv hcert [false]).mpr hu
  obtain ⟨p, t, hp, hpower, _⟩ := ladner_pad_membership.mp hy
  have hparse : ladner_parse [false] = some ([], 0) := by
    simpa only [List.nil_append, List.replicate_zero] using ladner_parse_pad [] 0
  rw [hparse] at hp
  obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj hp)
  have hbad : (0 : ℕ) = 1 := by simpa only [List.length_nil, pow_zero] using hpower
  exact Nat.zero_ne_one hbad
end Complexity
'''
(r / 'SemanticProbe.lean').write_text(semantic)
print('Generated axiom wrappers, scoped seals, six paired controls, and semantic edge probes.')
