from pathlib import Path
import subprocess, datetime, time, hashlib

r = Path('/private/tmp/ladner-np-20261115')
w = Path('/Users/seyoonr/.codex/worktrees/ladner-np/tcslib-exchange')
base = '34643146ee1fe6bf6d7ffdf2e543e8342a3e16a0'
baseline = r / 'Ladner-base.lean.txt'
baseline.write_bytes(subprocess.check_output(
    ['git', 'show', base + ':TCSlib/Complexity/Diagonalization/Ladner.lean'], cwd=w))
refs = [w / ('TCSlib/Complexity/' + p + '.lean') for p in [
    'ClassNP/PClosure', 'ClassNP/Reductions', 'ClassNP/NP', 'ClassNP/PolyTimePairing',
    'ClassNP/PolyTime', 'ClassP/P', 'ClassP/BinaryArith/Loops', 'ClassP/BinaryArith/Words',
    'TuringMachine/Encoding']]
lock = Path('/Users/seyoonr/.tcslib-scratch/locks/screen')
while True:
    try:
        lock.mkdir()
        break
    except FileExistsError:
        with (r / 'evidence/logs/screen-lock.log').open('a') as f:
            f.write(datetime.datetime.now(datetime.timezone.utc).isoformat() + ' WAIT shared screen lock\n')
        time.sleep(3)
try:
    outputs = {}
    for label, owned in [('base', baseline), ('head', w / 'TCSlib/Complexity/Diagonalization/Ladner.lean')]:
        cmd = ['nice', '-n', '10', 'python3', '-I', str(w / 'scripts/copy-text-screen-v3.py'),
               '/', str(owned)[1:], *[str(p)[1:] for p in refs]]
        p = subprocess.run(cmd, text=True, capture_output=True)
        (r / f'evidence/logs/copy-screen-{label}.log').write_text(
            p.stdout + p.stderr + '\nsource_sha256=' + hashlib.sha256(owned.read_bytes()).hexdigest()
            + f'\nexit_code={p.returncode}\n')
        assert p.returncode == 0
        outputs[label] = p.stdout.replace('Ladner-base.lean.txt', 'Ladner.lean')
    new = set(outputs['head'].splitlines()[1:]) - set(outputs['base'].splitlines()[1:])
    (r / 'evidence/logs/copy-screen-delta.log').write_text('\n'.join(sorted(new)) + '\n')
    print(outputs['base'].splitlines()[0])
    print(outputs['head'].splitlines()[0])
    print('New pairs:', len(new))
finally:
    lock.rmdir()
