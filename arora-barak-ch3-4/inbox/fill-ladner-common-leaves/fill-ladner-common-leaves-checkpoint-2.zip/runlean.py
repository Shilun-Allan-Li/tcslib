import sys,os,subprocess,time,datetime
from pathlib import Path
root=Path('/private/tmp/ladner-common-leaves')
src=root/'src';ol=root/'oleans';logs=root/'evidence/logs'
env=os.environ.copy();env['TCSLIB_LEAN_SLOTS']='3'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def count():
 rows=subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines()
 return [r.strip() for r in rows if len(r.split(None,1))==2 and os.path.basename(r.split(None,1)[1])=='lean']
args=sys.argv[1:]
wt=src
if args and args[0]=='--qa':
 wt=root/'qa';args=args[1:]
mods=(root/'evidence/logs/order.txt').read_text().splitlines() if args == ['--bootstrap'] else args
for mod in mods:
 f=mod if mod.endswith('.lean') else mod+'.lean'
 tag=f.replace('/','__').removesuffix('.lean')
 log=logs/(tag+'.log')
 while True:
  procs=count()
  with (logs/'lean-slots.log').open('a') as out:out.write(f'{stamp()} count={len(procs)} before {f}: {procs}\n')
  if len(procs)<3:break
  with (logs/'lean-waits.log').open('a') as out:out.write(f'{stamp()} WAIT count={len(procs)} before {f}\n')
  time.sleep(10)
 cmd=['/usr/bin/time','-l','bash',str(src/'devtools/seyoon/leanelab-o.sh'),str(wt),str(ol),f,str(ol)]
 print(stamp(),'START',f,flush=True)
 with log.open('w') as out:
  out.write(stamp()+' START '+f+'\n');out.flush()
  result=subprocess.run(cmd,cwd=src,env=env,stdout=out,stderr=subprocess.STDOUT)
  out.write(stamp()+f' END exit={result.returncode}\n')
 data=log.read_text()
 print(stamp(),'END',f,'exit',result.returncode,flush=True)
 if result.returncode or 'error:' in data:
  print(data,flush=True);sys.exit(result.returncode or 1)
