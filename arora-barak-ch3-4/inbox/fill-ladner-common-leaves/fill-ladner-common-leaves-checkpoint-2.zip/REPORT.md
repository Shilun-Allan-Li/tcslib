# Ladner common leaves — progress report

## Summary

Checkpoint 2: part 1 is complete. All four public `powCap` declarations are proved, `Mul.lean` checks with zero errors, and a sealed copy passes with only `propext`, `Classical.choice`, and `Quot.sound` in its axiom inventories. Boundary smoke checks, including all 225 combinations of base 0–4, exponent 0–8, and cap parameter 0–4, and a 257-bit exponent, pass. Part 2 has not begun. No Ladner target is changed or proved.

Base: `a052f8891d3c4520407bf9d976421148fc0f7a02`.
Bundle SHA-256: `41db5579adb6a8dc07ebe041909fb6d889642ce1db8f2a2a1cbcb8c4caed6945` (verified; 13 sections).
Work occurs on local branch `codex/fill-ladner-common-leaves` in a separate shared-object clone, not the exchange checkout. This branch is never pushed or rebased.

## Implementation and boundary

The state is `⟨c+1, ⟨remaining exponent, ⟨saturated base, saturated accumulator⟩⟩⟩`.
The invariant preserves the saturated remaining power, bounds both registers by the cap, and bounds the exponent length by its input length. It yields a bound `16 * (|z| + 1)` on every state; the iterator runs `|z|+1` rounds.

The four public declarations are `powCap`, `powCap_eq`, `powCap_pairEncode`, and `polyTimeComputable_powCap`; no new simp attributes. All algorithmic helpers are private. Existing declarations remain unchanged; `Ladner.lean` is still byte-identical to the base at this checkpoint.

Foreign computational definitions are consumed through equations: pair projections through `pairFstD_pairEncode` and `pairSndD_pairEncode`; pair size through `length_pairEncode`; `LogProg.bitsVal` through `bitsVal_bits`, `bitsVal_eq_headD`, and `bitsVal_lt_two_pow`; `add` through `add_pairEncode`; comparison `le` through `le_pairEncode`. Multiplication uses the existing same-file `mul_pairEncode`. The existing polynomial iterator and its invariant/measure lemmas provide the loop host. Inputs are normalized before canonical arithmetic equations are used, so no all-word arithmetic reader is assumed.

## Environment and checks

Fresh bootstrap: 140 modules, the transitive import closure of Mul, Loops, Ladner, and the Diagonalization facade. Its logs are in `evidence/logs`; checkpoint copies may contain an in-progress log. No other session's TCSlib olean tree is reused. No `lake build` or cache fetch is run.

macOS preflight: 12 CPUs, 18 GiB physical RAM, memory_pressure reports 61% free, APFS scratch filesystem with 242669540 KiB available (about 231 GiB). The Linux cgroup/proc and `df -B1`/`df -T` commands are replaced by macOS `sysctl`, `vm_stat`, `memory_pressure -Q`, `df -k`, and `mount`.

`.lake/packages` is symlinked to the populated main campaign checkout's package tree, as allowed by the addendum. Every present package's URL and commit equals the base manifest; four documentation packages are absent. Manifest result: PASS: every present package matches manifest URL and revision. Zero zero-sized package oleans. Installed Lean is the pinned 4.25.0; no toolchain change or shim.

Lean checks run serially through the repository's `devtools/seyoon/leanelab-o.sh` with its shared slot limit set to 3. A wrapper counts `ps -axo pid=,comm=` entries whose executable basename is exactly `lean`, covering both bare and full paths, before each start. It waits in 10-second intervals if the count is at least 3. There have been no such waits so far. The sandbox denies `ps` and Git metadata writes; the authorized commands use sandbox escalation for those operations.

## Remaining

Implement the private Ladner parser and finite tables, finish the fresh facade bootstrap, and perform the final Loops, Ladner, and facade checks and part 2 axiom/seal checks. The new public-name census finds exactly four added public declarations; the byte-freeze check reports insertions only. No new admissions, axioms, or simp attributes occur in the new code.

## Part 1 verification notes

The first arithmetic check identified four local proof-script issues, all corrected in the next check (exit 0). The initial QA copy lacked `lean-toolchain` and selected the host default version, so it rejected the pinned olean header; adding the exact base toolchain pin fixed that QA-only context error, without changing any cache. `MulSealed.lean` and `MulSmoke.lean` then exited 0. Both source copies and all logs are delivered.

The bootstrap orchestrator was paused while its current Lean child completed uninterrupted, so the arithmetic could be checked before the remaining facade prerequisites. No Lean module was killed or timed out. The remaining bootstrap resumes after the arithmetic consumer checks.
