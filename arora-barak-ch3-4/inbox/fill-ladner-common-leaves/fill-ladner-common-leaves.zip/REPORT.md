# Ladner common leaves — final report

## Summary

Completed both parts: `powCap` and all eleven requested private Ladner leaves. All four required module checks pass. Axiom and sealed-definition checks pass, and every existing declaration remains byte-identical. Only the four pre-existing Ladner admissions remain; no Ladner target was proved.

## Provenance and delivery

- Base: `a052f8891d3c4520407bf9d976421148fc0f7a02`, fetched from origin.
- Bundle SHA-256: `41db5579adb6a8dc07ebe041909fb6d889642ce1db8f2a2a1cbcb8c4caed6945`, verified; 13 sections.
- Local source commit: `5751934aa9fc93c77bb12aadcbd6aa08262909f2` on `codex/fill-ladner-common-leaves`, in a separate shared-object clone at `/private/tmp/ladner-common-leaves/src`. The source branch was never rebased or pushed.
- Both owned files, `changes.patch` against the base, `evidence/source.patch` (format-patch), `evidence/source.bundle`, check logs, probe sources, this report, and `SHA256SUMS` are included.
- Checkpoints 1 and 2 were pushed cumulatively to the requested exchange inbox. The final zip is delivered there too, with pull/rebase before each non-force push. No other branch or PR is used.

## Parts completed

**Part 1.** Exactly the four approved public declarations are added in `Complexity.BinArith`: `powCap`, `powCap_eq`, `powCap_pairEncode`, and `polyTimeComputable_powCap`. None has a simp attribute.

The repeated-squaring state is `⟨c+1, ⟨remaining exponent, ⟨saturated base, saturated accumulator⟩⟩⟩`. The cap, base, and accumulator are normalized, the two numerical registers are at most the cap, and the exponent word loses one bit per live round. The invariant preserves the capped remaining power and proves the length bound `16 * (|z| + 1)` for every intermediate state. The existing polynomial iterator runs `|z|+1` rounds and the measure theorem proves termination of the exponent consumption. Every product is saturated, including base squaring. The algebra handles zero factors and the zero exponent, including `0 ^ 0 = 1`.

**Part 2.** All eleven binding declarations are added privately with `ladner_` prefixes: `parse`, `padSyntax`, `parseWord`, `parse_some`, `parse_none`, `parsed_length`, `parse_FP`, `syntax_FP`, `pad_membership`, `finite_lookup_FP`, and `small_SAT_table`.

The parser is the specified recursive mathematical function. Its FP serialization uses the existing reverse, unary-rest, and false-bit hosts, plus binary length and subtraction. The syntax test uses the public saturated power with cap parameter equal to the available suffix length. The equality `t = min(power, t+1)` is equivalent to `t = power`. Membership uses `mem_padSAT_iff`. Finite lookup is a finite disjunction of fixed-word equality tests. The small SAT table filters a finite enumeration of all shorter Boolean words by SAT using classical choice; the fixed table requires no runtime SAT search.

The only added import is the approved `TCSlib.Complexity.ClassP.BinaryArith.Loops` in Ladner. No new machine host, transition table, public helper, admission, axiom, or simp attribute is introduced. There is no open statement, reader, or host escalation.

## Declaration inventory

The table lists every new source declaration, including private glue.

| File | Visibility | Declaration | Role |
| --- | --- | --- | --- |
| `Mul.lean` | public | `powCap` | The power of the first value to the second, capped at one plus the third value. Computed by repeated squaring with saturation, including `0 ^ 0 = 1`. |
| `Mul.lean` | public | `powCap_eq` | On every word, `powCap` is the binary encoding of the specified capped power. |
| `Mul.lean` | public | `powCap_pairEncode` | On three encoded naturals, `powCap` computes `min (m ^ e) (c + 1)`. This is the canonical input equation for saturated repeated squaring. |
| `Mul.lean` | private | `powCap_min_mul` | Saturating one factor before multiplication preserves the saturated product. |
| `Mul.lean` | private | `powCap_mul_min` | The same saturation law for the right factor. |
| `Mul.lean` | private | `powCap_min_pow` | Saturating a base preserves every saturated natural power. |
| `Mul.lean` | private | `powCap_mul_min_pow` | Saturation of a powered right factor can also be removed. |
| `Mul.lean` | private | `powCapMin` | Normalize the two arguments and select the smaller binary value. |
| `Mul.lean` | private | `powCapMin_eq` | The normalized minimum reads every input through the public comparison equation. |
| `Mul.lean` | private | `powCapMin_FP` | The normalized minimum is polynomial-time. |
| `Mul.lean` | private | `powCapMul` | Multiply the last two slots and saturate at the first slot. |
| `Mul.lean` | private | `powCapMul_FP` | Saturated multiplication is polynomial-time. |
| `Mul.lean` | private | `powCapMul_pair` | The canonical saturated multiplication equation. |
| `Mul.lean` | private | `powCapStep` | One saturated repeated-squaring round on `⟨C, ⟨E, ⟨b, acc⟩⟩⟩`. An empty exponent word fixes the state. |
| `Mul.lean` | private | `powCapStep_FP` | A saturated squaring round is polynomial-time. |
| `Mul.lean` | private | `powCapInit` | The initial saturated squaring state has cap `c+1` and accumulator one. |
| `Mul.lean` | private | `powCapInit_FP` | The initial state is polynomial-time computable. |
| `Mul.lean` | private | `PowCapInv` | The loop invariant bounds all registers and preserves the saturated remaining power. |
| `Mul.lean` | private | `powCapInv_init` | The initial state satisfies the invariant, also for exponent zero and base zero. |
| `Mul.lean` | private | `powCapInv_step` | The round preserves the invariant and drops one exponent bit until fixed. |
| `Mul.lean` | private | `powCapInv_length` | All saturated states have linear length. |
| `Mul.lean` | public | `polyTimeComputable_powCap` | Saturated binary exponentiation is polynomial-time by repeated squaring. |
| `Ladner.lean` | private | `ladner_parse` | Parse the final false separator and its true suffix. This is the mathematical padding parser of [AB09, Theorem 3.3 and its proof]. |
| `Ladner.lean` | private | `ladner_padSyntax` | Padding syntax requires the suffix length to be the prescribed power. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_parseWord` | Serialize a successful parse with a nonempty marker; failure is the empty word. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_parse_none` | The parser fails exactly on words with no false separator. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_parse_sound` | A successful parse reconstructs the input around the final separator. |
| `Ladner.lean` | private | `ladner_parse_pad` | The parser reads any prefix followed by a false separator and a true suffix. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_parse_some` | Parsing succeeds exactly on the indicated padded word. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_parsed_length` | A parsed prefix is shorter than the input, whose length includes the separator. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_hasFalse_false` | The public false-bit test is false exactly on all-true words. |
| `Ladner.lean` | private | `ladner_hasFalse_append` | The public false-bit test distributes over append. |
| `Ladner.lean` | private | `ladner_parse_prefix` | Reverse and the public unary-rest reader recover a successful parse's prefix. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_parse_FP` | The mathematical padding parser has a polynomial-time serialization. |
| `Ladner.lean` | private | `ladner_syntax_FP` | The padding syntax test is polynomial-time when its exponent function is. |
| `Ladner.lean` | private | `ladner_pad_membership` | Padding membership is successful parsing, the prescribed suffix length, and SAT membership of the prefix. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_finite_lookup_FP` | Every fixed finite table of words has a polynomial-time membership test. [AB09, Theorem 3.3 and its proof] |
| `Ladner.lean` | private | `ladner_small_SAT_table` | SAT on words shorter than a fixed bound is represented by a finite table. [AB09, Theorem 3.3 and its proof] |

## Foreign-definition reading ledger

| Definition or interface | Published equations/contracts used |
| --- | --- |
| `Turing.pairEncode` | `pairFstD_pairEncode`, `pairSndD_pairEncode`, `length_pairEncode` |
| `pairFstD`, `pairSndD` | Their pair equations and `length_pairFstD_le`, `length_pairSndD_le`; component-length bounds |
| `LogProg.bitsVal` | `bitsVal_bits`, `bitsVal_eq_headD`, `bitsVal_lt_two_pow`; binary-length bounds `length_bits_le`, `length_bits_mono`, and normalization size |
| `BinArith.add` | `add_pairEncode`; the cap input is normalized before adding one |
| `BinArith.le` | `le_pairEncode`; both compared words are normalized |
| `BinArith.sub` | `sub_pairEncode`, twice on encoded lengths |
| `BinArith.beq` | `beq_pairEncode` on encoded suffix length and capped power |
| `BinArith.uRest` | `uRest_true_cons`, `uRest_false_cons`; induction over the explicit true suffix |
| `BinArith.hasFalse` | `hasFalse_nil`, `hasFalse_cons`; local append/all-true consequences |
| `BinArith.powCap` in Ladner | `powCap_pairEncode` and `polyTimeComputable_powCap` |
| `padSAT` | `mem_padSAT_iff` |
| `SAT` | Used as an atomic membership predicate; its decoder/definition is never read |
| Existing arithmetic and loop hosts | `polyTimeComputable_mul`, `mul_pairEncode` (same file), `polyTimeComputable_normBits`, reverse/tail/head/slot FP lemmas, `polyTimeComputable_iterate`, `iterate_invariant`, `iterate_measure_eq_zero` |
| Pairing and FP closure | `PolyTimeComputable.comp`, `.pairEncode`, the constant/id, Boolean-or, emptiness, and conditional closure theorems |
| Existing machine leaves | `FinTM.computesFunInTime_lengthBits`, `FinTM.computesFunInTime_decideEq`, transferred by `polyTimeComputable_of_linear` |

In the new proofs, no other-file definition is named as a `simp`, `rw`, or `unfold` argument. Core/Mathlib operations are used through equation lemmas or ordinary definitional reduction; they are not passed to those tactics as definitions. The new sections are separately sealed in the delivered probes. `SAT` is also made irreducible in the Ladner probe, even though its body is never reached.

No proved code or machine construction was copied. The parser's local true-suffix calculation is an induction using the specified public `uRest` equations; it does not read the separate unary-code definition. All loop driving comes from the existing public iterator. The private helpers listed above are new arithmetic/invariant or parser/serialization glue.

## Verification

Fresh import closure: **140 modules**, all successful, computed in dependency order from Mul, Loops, Ladner, and the facade. See `order.txt`, `mathlib-roots.txt`, `bootstrap.log`, and per-module logs under `evidence/logs/`.

Final module sweep (fresh outputs in this fill's own olean tree):

| Module | Exit | Errors | Admission warnings |
| --- | --- | --- | --- |
| Mul | 0 | 0 | 0 |
| Loops | 0 | 0 | 0 |
| Ladner | 0 | 0 | 4 |
| Diagonalization facade | 0 | 0 | 0 |

The four unchanged admitted declarations in Ladner are `ladnerH_polyTime`, `SAT_H_mem_NP`, `SAT_mem_P_of_padSAT_NPHard`, and `SAT_H_intermediate`.

- `AxiomsDelivered.log` prints the actual delivered public and private constants, resolving private names from the imported environment. `polyTimeComputable_powCap`, `powCap_pairEncode`, all three private FP lemmas, the finite SAT table, and padding membership use only subsets of `propext`, `Classical.choice`, and `Quot.sound`. There is no `sorryAx` in these results.
- `MulSealed.log` and `LadnerSealed.log`: exit 0; every new proof is checked with the reached foreign computational definitions irreducible. Axiom prints for the auxiliary proofs are clean too.
- `ReaderControlsUnsealed.log` and `ReaderControlsSealed.log`: exit 0. Twelve isolated delta controls succeed unsealed and are required to fail sealed (`fail_if_success`); their corresponding published equations succeed sealed.
- `MulSmoke.log`: exit 0. Checks all 225 combinations of bases 0–4, exponents 0–8, and cap parameters 0–4, plus `0 ^ 0` and a 257-bit exponent using the saturated algorithm. The huge mathematical power is never evaluated in that smoke test.
- `freeze.log`: every base byte remains in order, insertions only, and only the two owned tracked files differ. The declaration census is 14 → 18 public names in Mul and 17 → 17 in Ladner. Existing private declarations are unchanged.
- `style-lint.log`: 0 FAIL on both owned files. The unchanged legacy `mulInit` and `mulStep` lack standalone readers under check 8, as before. The 785-line Ladner file exceeds the preferred 600-line target; the approved ownership keeps these leaves together.
- `git diff --check`: exit 0.

Final diff:

```text
 TCSlib/Complexity/ClassP/BinaryArith/Mul.lean | 276 ++++++++++++++++++++++++++
 TCSlib/Complexity/Diagonalization/Ladner.lean | 245 +++++++++++++++++++++++
 2 files changed, 521 insertions(+)
```

## Environment, process discipline, and deviations

- macOS preflight: 12 CPUs, 18 GiB physical RAM; `memory_pressure -Q` reported 61% free. APFS scratch had 242669540 KiB available (about 231 GiB). Linux cgroup/proc and `df -B1`/`df -T` checks were replaced by `sysctl`, `vm_stat`, `memory_pressure -Q`, `df -k`, and `mount`; full outputs are in `preflight.log`.
- Installed pinned Lean 4.25.0 is used. `.lake/packages` is symlinked to the populated main campaign checkout's package tree, as explicitly allowed by the addendum. Every present package's URL and revision matches the base manifest; the four absent documentation packages are recorded as ABSENT. Zero package oleans are empty. No cache fetch is needed, so no cache archive store is consumed or fetched by this fill.
- No other session's TCSlib olean tree is reused. All 140 import modules are bootstrapped into `/private/tmp/ladner-common-leaves/oleans`. No `lake build`, toolchain installation, or runtime shim is used.
- Every Lean start goes through the repository's `leanelab-o.sh`, under `nice -n 10`, with `-j4` and the shared wrapper slot limit set to 3. The outer driver first counts `ps -axo pid=,comm=` entries whose executable basename is exactly `lean`, covering bare names and full paths. It starts at most one Lean process of its own.
- **Lean-cap waits: 0.** All 163 recorded pre-start counts were below 3 (maximum 0). `lean-slots.log` and `lean-waits.log` record the checks. The bootstrap orchestrator was paused to finish/check part 1 first; its current Lean child completed uninterrupted, then the remaining bootstrap resumed. No Lean module was killed or timed out. The orchestration event log records this pause.
- The sandbox blocks `ps` and exchange Git metadata writes, so authorized commands use sandbox escalation for those operations. No approval rejection occurred.
- Development diagnostics are retained. The first arithmetic and parser proof drafts needed local tactic/lemma-name fixes. An initial QA directory omitted `lean-toolchain` and selected the host default version, causing an incompatible-header error; copying the exact base pin corrected that context, without changing the cache. Early diagnostic/control probe drafts also needed parser fixes and controls isolating raw zero words. All final source, sealed, axiom, control, and smoke checks listed above exit 0.

## Final checklist

- [x] Part 1 complete before part 2.
- [x] Part 2 complete; all requested leaves private.
- [x] Every existing declaration byte-identical; no Ladner target proved.
- [x] Only two owned Lean files changed; only the approved import added.
- [x] All four required final module checks pass.
- [x] Required axiom inventories contain only allowed axioms.
- [x] Sealed reader checks and controls pass.
- [x] Environment deviations and all Lean waits recorded.
- [x] Patch, source bundle, full files, report, probes, logs, and checksums delivered.
