from pathlib import Path
import sys,os,subprocess,time,datetime,fcntl,hashlib,signal
S=Path('/private/tmp/fill-ladner-selectors'); L=S/'evidence/logs'
WT=Path('/Users/seyoonr/.codex/worktrees/ladner-selectors/tcslib-exchange'); OL=S/'oleans'
L.mkdir(parents=True,exist_ok=True); OL.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH'];env['TCSLIB_LEAN_SLOTS']='3'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def inventory():
 rows=[]
 for line in subprocess.check_output(['ps','-axo','pid=,comm=,args='],text=True).splitlines():
  bits=line.strip().split(None,2)
  if len(bits)==3 and Path(bits[1]).name=='lean':rows.append((int(bits[0]),bits[1],bits[2]))
 return rows
def run(file,tag,emit=False):
 with (S/'own-lean.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  retry=0
  while True:
   actualtag=tag if not retry else f'{tag}-retry-{retry}'
   with (L/'concurrency.log').open('a',buffering=1) as f:
    while True:
     rows=inventory();count=len(rows);f.write(f'{now()} ps-basename before={count} file={file} inventory={rows!r}\n')
     if count<2:break
     f.write(f'{now()} WAIT 10 seconds: reserve one slot for Lamport; machine already has {count} Lean processes\n');time.sleep(10)
   wrapper=WT/'devtools/seyoon'/('leanelab-o.sh' if emit else 'leanelab.sh')
   cmd=['/usr/bin/time','-l','bash',str(wrapper),str(WT),str(OL),file]+([str(OL)] if emit else [])
   log=L/(actualtag+'.log');interrupted=False
   with log.open('w') as f:
    f.write(f'START {now()}\nCOMMAND {cmd!r}\nSOURCE-SHA256 {hashlib.sha256((WT/file).read_bytes()).hexdigest()}\n');f.flush()
    p=subprocess.Popen(cmd,cwd=WT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    while p.poll() is None:
     rows=inventory()
     if len(rows)>2:
      interrupted=True
      note=f'{now()} INTERRUPTED OWN PROCESS GROUP {p.pid}: actual machine count={len(rows)} inventory={rows!r}'
      with (L/'concurrency.log').open('a') as cf:cf.write(note+'\n')
      f.write('\n'+note+'\n');f.flush()
      try:os.killpg(p.pid,signal.SIGTERM)
      except ProcessLookupError:pass
      p.wait();break
     time.sleep(0.5)
    status=p.wait();f.write(f'END {now()} exit={status} interrupted={interrupted}\n')
   data=log.read_text();errors=data.count('error:');okay=status==0 and errors==0
   if emit:okay=okay and (OL/(file[:-5]+'.olean')).is_file()
   with (L/'checks.tsv').open('a') as f:f.write(f'{now()}\t{actualtag}\texit={status}\terrors={errors}\tpass={okay}\tinterrupted={interrupted}\n')
   print(f'{actualtag}: exit={status} errors={errors} interrupted={interrupted}',flush=True)
   if interrupted:retry+=1;continue
   if not okay:print(data[-12000:],flush=True)
   return okay
if sys.argv[1] in ('bootstrap','facade-bootstrap'):
 suffix='bootstrap' if sys.argv[1]=='bootstrap' else 'facade-bootstrap'
 order=(L/(suffix+'-order.txt')).read_text().splitlines()
 for i,m in enumerate(order,1):
  if not run(m+'.lean',f'{suffix}-{i:03d}',True):sys.exit(1)
 (L/(suffix+'-result.log')).write_text(f'{now()} base=50bb801a28ffd86ce7b47c91d47c257ab024fade modules={len(order)} failed=0\n')
else:
 sys.exit(0 if run(sys.argv[1],sys.argv[2],len(sys.argv)>3 and sys.argv[3]=='emit') else 1)
