from pathlib import Path
import subprocess,re,hashlib
S=Path('/private/tmp/fill-ladner-selectors');W=Path('/Users/seyoonr/.codex/worktrees/ladner-selectors/tcslib-exchange');F='TCSlib/Complexity/Diagonalization/Ladner.lean';base='50bb801a28ffd86ce7b47c91d47c257ab024fade'
b=subprocess.check_output(['git','-C',str(W),'show',base+':'+F],text=True);s=(W/F).read_text();raw=s
added='import TCSlib.Complexity.ClassP.ModelInvariance\n';assert s.count(added)==1;s=s.replace(added,'')
for start,end in [('/-- The empty word is outside every padded language','/-- A polynomial-time decider for the padded language forces its delayed index'),('/-- A fixed polynomial clock can be prepared','/-- If the padded language is outside P, the delayed index')]:
 if start in s:
  assert s.count(start)==s.count(end)==1
  a=s.index(start);z=s.index(end);s=s[:a]+s[z:]
for name in ['ladnerH_bounded_of_mem_P','ladnerH_unbounded_of_not_mem_P']:
 pat=r'(theorem '+name+r' :\n[^\n]*:=).*?(?=\n\n/--)'
 s,n=re.subn(pat,lambda m:m.group(1)+'\n  sorry',s,flags=re.S);assert n==1,(name,n)
assert s==b,'Frozen source text changed'
changed=subprocess.check_output(['git','-C',str(W),'diff','--name-only',base],text=True).splitlines();assert changed==[F],changed
newnames=re.findall(r'^private theorem (\w+)',raw,re.M)
log='PASS: exact byte reconstruction of every frozen statement, declaration, and docstring.\nPASS: only the owned Ladner.lean changed against the exact base.\nSource SHA256 '+hashlib.sha256(raw.encode()).hexdigest()+'\nPrivate helpers: '+', '.join(newnames)+'\n'+subprocess.check_output(['git','-C',str(W),'diff','--stat',base],text=True)
(S/'evidence/logs/freeze-check.log').write_text(log);print(log)
