from pathlib import Path
S=Path('/private/tmp/fill-ladner-selectors'); W=Path('/Users/seyoonr/.codex/worktrees/ladner-selectors/tcslib-exchange')
s=(W/'TCSlib/Complexity/Diagonalization/Ladner.lean').read_text()
seal='''
attribute [local irreducible] Complexity.P Complexity.NP Complexity.SAT
  Complexity.PolyTimeComputable Turing.FinTM.DecidesInTime
  Turing.MultiTapeTM.indicator Turing.FinTM.ComputesFunInTime
  Turing.FinTM.ComputesInTime Turing.CodeTM.toFinTM Turing.FinTM.toCodeTM
  Complexity.expCode Turing.pairEncode

'''
marker='/-- The empty word is outside every padded language';assert s.count(marker)==1
s=s.replace(marker,seal+marker)
s+='\n#print axioms Complexity.ladnerH_bounded_of_mem_P\n#print axioms Complexity.ladnerH_unbounded_of_not_mem_P\n'
(S/'Sealed.lean').write_text(s)
(S/'evidence/runtime').mkdir(exist_ok=True)
(S/'evidence/runtime/Sealed.lean.txt').write_text(s)
