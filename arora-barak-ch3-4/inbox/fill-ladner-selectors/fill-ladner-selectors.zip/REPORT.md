# Ladner selectors fill report

## Summary

2/2 selector theorems proved: `ladnerH_bounded_of_mem_P` and `ladnerH_unbounded_of_not_mem_P`. Ladner, the diagonalization facade, the opaque-definition proof check, and both axiom prints pass with exit 0 and zero errors. Each selector depends only on `propext`, `Classical.choice`, and `Quot.sound`. Only `Ladner.lean` changes; all frozen statements, declarations, and docstrings are byte-identical, and the four other admissions remain untouched. No mathematical, reader, or host escalation is needed. Twenty-four concurrency waits are logged.

## Binding and scope

- Lean base: `50bb801a28ffd86ce7b47c91d47c257ab024fade`, fetched from `origin/codex/ab34-ladner-readers`.
- Requested records pin: `3efefcf485849900f114dd9902a139760972cf9b`; requested exchange pin: `89aa33b172e31a9ae592b814d824f5805602e3e7`.
- The exchange checkout was pulled with rebase before reading the bundle. Bundle SHA-256: `b4fecc2ccb020a6db6bb2c6c9ac22f6ee8b24ffeb9cef49f6ccf1a749ae18272`, verified; section count: 13, verified.
- Work was done in a separate managed worktree on local-only branch `codex/fill-ladner-selectors`, without rebasing the Lean branch. Its HEAD remains the exact base.
- Owned source: `TCSlib/Complexity/Diagonalization/Ladner.lean`, 540 lines. The only additional import is the approved `TCSlib.Complexity.ClassP.ModelInvariance`.
- Final source SHA-256: `24d4c77d550d91caf1b3215dce3abbf0d7cad8c00343e8064774b61612d41d65`.

The exact reconstruction check removes the one permitted import and ten private helpers, restores only the two target proof bodies, and byte-compares the entire result with the base. It passes. There is no new public declaration, attribute, definition, axiom, or admission.

## Proofs and private helpers

| Private declaration | Role |
| --- | --- |
| `ladner_pad_nil` | A separator makes every padded word nonempty. |
| `ladner_padded_index` | A fixed coded machine has arbitrarily large canonical binary indices, using a positive all-true suffix and prepending the encoding. |
| `ladner_indexed_deadline` | The indexed clock absorbs both a decider's degree and its coefficient on nonempty inputs. |
| `ladner_correct_index` | Converts a P decider through the one-work-tape theorem and coded normal form; handles the empty input and uses output uniqueness on rejecting inputs. |
| `ladner_selector_bound` | One globally correct index bounds every stage, including the cap/fallback cases. |
| `ladner_fixed_clock_preparation` | Builds the exact paired simulator input in FP. It evaluates the successor-length polynomial on the tail of a nonempty word and handles the empty word by a fixed test and constant branch. |
| `ladner_fixed_clock_budget` | Bounds the simulator's polynomial in the numerical deadline by a polynomial in the original input length. |
| `ladner_fixed_clock_FP` | Uses the uniform simulator and composition on the preparation function's image to obtain a total bounded-acceptance bit. |
| `ladner_all_tests_imply_P` | Agreement of one indexed test everywhere supplies P membership through the total simulator, without assuming the indexed machine halts on negative inputs. |
| `ladner_selector_threshold` | A finite maximum of failing-word lengths yields a single threshold after which every stage excludes all smaller indices. |

The boundedness target was finished and axiom-checked before the divergence proof was inserted. The divergence target retains the full conclusion `∀ C, ∃ N, ∀ n ≥ N, C ≤ ladnerH n`; no monotonicity assumption is made. Empty input, index zero, coefficient/degree zero, and `0^0` are covered by the actual formulas and cases, without changing SAT's malformed-input convention.

The padded-index, deadline, and two selector arguments adapt the checked scratch arguments in the supplied route materials. This reuse is disclosed here; no existing public library theorem or machine construction was privately duplicated. The computational work uses the existing polynomial evaluator, equality test, branching, pairing, and image-composition contracts. No new computational host is introduced. Each new declaration has a source citation, and every proof exceeding twenty lines has a proof sketch.

## Other-file definition boundaries

| Foreign definition or boundary | Published equation or contract used |
| --- | --- |
| `Complexity.P` | `mem_P_iff_one_work_tape` extracts the decider; `mem_P_of_test` constructs membership from the simulator's Boolean test. No body reduction. |
| `Complexity.PolyTimeComputable` | `polyTimeComputable_iff` extracts or constructs machine witnesses; existing `PolyTimeComputable.comp`, `.pairEncode`, `polyTimeComputable_const`, `_id`, `_of_linear`, `_ite`, and `_tail` supply closure. |
| `FinTM.DecidesInTime` | `FinTM.decidesInTime_iff`. |
| `FinTM.ComputesFunInTime` | `FinTM.computesFunInTime_iff`; evaluator, fixed equality-test, and composition contracts. |
| `FinTM.ComputesInTime` | `FinTM.not_computesInTime_zero`, `ComputesInTime.mono`, `ComputesInTime.output_unique`, and the uniform simulator's two clauses. No run definition is read. |
| `MultiTapeTM.indicator` | `MultiTapeTM.indicator_of_mem` and `_of_not_mem`. |
| `FinTM.toCodeTM`, `CodeTM.toFinTM` | `FinTM.toCodeTM_computesInTime_iff`; coded machines otherwise remain opaque. |
| `Complexity.expCode` and the inherited encoding/decoding projections | Public structure fields `MachineCode.decode_encode_pad`, `UniformMachineCode.simulator_accepts`, and `_rejects`. The choice witness is never read. |
| `Turing.pairEncode` | Kept opaque; `PolyTimeComputable.pairEncode` and the simulator's exact paired-input contract. |
| `Complexity.SAT` | Only a membership proposition carried by `mem_padSAT_iff`; no decoding or semantic definition is read. |
| `Complexity.NP` | Occurs only in unchanged declarations; no new proof reads it. |

The owned definitions are read through `mem_padSAT_iff`, `ladnerMachine_eq`, `ladnerH_eq`, and `SAT_H_eq`. Core/Mathlib arithmetic and list operations use their lemmas; no definition is an explicit simp/rw/unfold argument in the added proofs.

The scratch sealed copy marks all the foreign definitions above locally irreducible before the new proof sections. Both targets still check and print exactly the permitted axioms. Three direct-reader controls (`PolyTimeComputable`, `ComputesFunInTime`, `DecidesInTime`) additionally demonstrate that their published characterizations close by reflexivity unsealed, fail by reflexivity sealed, and close by the named reader while sealed. This is fill verification, not a claim of a separate campaign audit gate.

## Verification

All logs are under `evidence/logs/`. Their module checks record commands, start/end times, exit codes, and macOS `/usr/bin/time -l` memory figures. Final checks also bind source hashes.

| Check | Exit | Result |
| --- | --- | --- |
| Mathlib cache import probe | 0 | Zero errors. |
| Fresh Ladner/model-invariance import bootstrap | 0 | All 116 modules passed; no TCSlib object snapshot reused. |
| Facade prerequisite bootstrap | 0 | All 12 additional modules passed. |
| `final-ladner.log` | 0 | Zero errors; exactly four admission warnings, all in the untouched targets. |
| `final-axioms-clean.log` | 0 | Both targets: `[propext, Classical.choice, Quot.sound]`. |
| `sealed-proof-clean.log` | 0 | Zero errors with the foreign definitions opaque; both target axiom prints are unchanged. |
| `seal-controls.log` | 0 | Positive reader and negative reflexivity controls pass. |
| `final-facade.log` | 0 | `TCSlib/Complexity/Diagonalization.lean` checks with zero errors. |
| `style-lint.log` | 0 | Zero findings. |
| `freeze-check.log` / `diff-check.log` | 0 | Exact frozen-byte comparison and whitespace check pass. |
| `patch-replay.log` | 0 | Applying the patch to the exact base reproduces the delivered source byte-for-byte. |

The two axiom lines are:

```text
'Complexity.ladnerH_bounded_of_mem_P' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.ladnerH_unbounded_of_not_mem_P' depends on axioms: [propext, Classical.choice, Quot.sound]
```

The remaining four `sorry` declarations are exactly `ladnerH_polyTime`, `SAT_H_mem_NP`, `SAT_mem_P_of_padSAT_NPHard`, and `SAT_H_intermediate`. The unchanged packaging theorem `ladner` consequently still depends on the admitted intermediate-language theorem. Neither completed selector depends on it.

The first boundedness check exited 1 on one list-length elaboration mismatch; replacing that step with a direct list case split gave exit 0. The divergence proof passed its first check. Its one unused simp argument was then removed, and the owned file, both axiom prints, sealed proof, and facade were rechecked on the final bytes. Earlier attempts remain in the logs.

```text
 TCSlib/Complexity/Diagonalization/Ladner.lean | 296 +++++++++++++++++++++++++-
 1 file changed, 292 insertions(+), 4 deletions(-)
```

## Environment and concurrency

macOS adaptations replace Linux-only resource commands with `sysctl`, `memory_pressure`, `vm_stat`, `df -k`, and `mount`. Preflight recorded 12 CPUs, 18 GiB physical memory, 48% memory free (about 8.64 GiB), and about 232 GiB free disk on APFS. A later resource check reported 64% free memory. Exact output is in `preflight.log`.

The worktree's `.lake/packages` symlinks the existing populated campaign dependency tree. Every present package URL and revision matches the base manifest; missing documentation packages are recorded as ABSENT. The manifest log ends: `PASS: all present packages match manifest; linked existing populated package tree, no fetch.` All 7,544 dependency oleans are nonempty. The cache archive store inventory is recorded; no cache was fetched or claimed as downloaded by this fill.

All TCSlib oleans were compiled into this fill's own fresh scratch tree. No project `lake build`, package rebuild, mixed TCSlib snapshot, toolchain change, or runtime shim was used. Checks use the pinned v4.25.0 toolchain through the repository's `leanelab-o.sh` / `leanelab.sh`, `nice -n 10`, and `-j4`.

This fill started at most one Lean process at a time. Initially each launch used the user-suggested `pgrep -x lean` guard, waiting if the count was at least three. There were 24 logged ten-second waits (240 seconds nominal); see `concurrency.log` for every wait.

A later coordination note reported that other runs had observed counts above three using full executable paths. The guard was strengthened to count `ps` executable basenames, including both bare `lean` and full paths, and to monitor while running and terminate only this fill's own process group if capacity is exceeded. The immediate inventory found one Lean process, this fill's seal-control check. Subsequent facade-prerequisite launches all observed zero existing Lean processes. The final four checks additionally reserve one slot for Lamport by waiting at counts of two and stopping this fill's own process group if the total rises above two; none was interrupted. Earlier pre-launch logs record the original pgrep counts and cannot certify a retrospective full-machine maximum. This process-accounting limitation does not affect the recorded Lean proof checks.

Sandbox permission was needed for Git metadata, isolated-worktree writes, and actual machine process inventory. No operation was blocked by approval review. Repository content was inspected as data; the dispatched brief supplied the task rules.

## Delivery

Cumulative checkpoint 1 (draft proof plus partial bootstrap) and checkpoint 2 (verified boundedness, including its axiom print) were pushed to the designated inbox. The final `fill-ladner-selectors.zip` contains this report, the full final `Ladner.lean`, `changes.patch` against the exact base, complete check logs, and verification probe/runner sources. It is delivered only under `arora-barak-ch3-4/inbox/fill-ladner-selectors/` on `exchange/pass-shelat-ch5-8`, with `git pull --rebase` before each push and no force push. No other branch is pushed and no pull request is opened. The same final zip is attached in chat as a fallback.
