from pathlib import Path
import sys,os,subprocess,time,datetime,fcntl,hashlib
S=Path('/private/tmp/fill-ladner-selectors'); L=S/'evidence/logs'
WT=Path('/Users/seyoonr/.codex/worktrees/ladner-selectors/tcslib-exchange'); OL=S/'oleans'
L.mkdir(parents=True,exist_ok=True); OL.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH'];env['TCSLIB_LEAN_SLOTS']='3'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(file,tag,emit=False):
 with (S/'own-lean.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  with (L/'concurrency.log').open('a',buffering=1) as f:
   while True:
    p=subprocess.run(['pgrep','-x','lean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if p.returncode not in (0,1) or p.stderr:raise RuntimeError('Cannot count Lean processes: '+p.stderr)
    count=len(p.stdout.splitlines());f.write(f'{now()} before={count} file={file}\n')
    if count<3:break
    f.write(f'{now()} WAIT 10 seconds: machine already has {count} Lean processes\n');time.sleep(10)
  wrapper=WT/'devtools/seyoon'/('leanelab-o.sh' if emit else 'leanelab.sh')
  cmd=['/usr/bin/time','-l','bash',str(wrapper),str(WT),str(OL),file]+([str(OL)] if emit else [])
  log=L/(tag+'.log')
  with log.open('w') as f:
   f.write(f'START {now()}\nCOMMAND {cmd!r}\nSOURCE-SHA256 {hashlib.sha256((WT/file).read_bytes()).hexdigest()}\n');f.flush()
   p=subprocess.run(cmd,cwd=WT,env=env,stdout=f,stderr=subprocess.STDOUT)
   f.write(f'END {now()} exit={p.returncode}\n')
  data=log.read_text();errors=data.count('error:');okay=p.returncode==0 and errors==0
  if emit:okay=okay and (OL/(file[:-5]+'.olean')).is_file()
  with (L/'checks.tsv').open('a') as f:f.write(f'{now()}\t{tag}\texit={p.returncode}\terrors={errors}\tpass={okay}\n')
  print(f'{tag}: exit={p.returncode} errors={errors}',flush=True)
  if not okay:print(data[-12000:],flush=True)
  return okay
if sys.argv[1]=='bootstrap':
 order=(L/'bootstrap-order.txt').read_text().splitlines()
 for i,m in enumerate(order,1):
  if not run(m+'.lean',f'bootstrap-{i:03d}',True):sys.exit(1)
 (L/'bootstrap-result.log').write_text(f'{now()} base=50bb801a28ffd86ce7b47c91d47c257ab024fade modules={len(order)} failed=0\n')
else:
 sys.exit(0 if run(sys.argv[1],sys.argv[2],len(sys.argv)>3 and sys.argv[3]=='emit') else 1)
