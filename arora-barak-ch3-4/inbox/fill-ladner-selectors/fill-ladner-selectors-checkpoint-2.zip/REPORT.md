# Ladner selectors fill report

## Summary

Checkpoint 2: target 1, `ladnerH_bounded_of_mem_P`, is complete and checked. The file check exited 0 with zero errors, and the theorem depends only on `[propext, Classical.choice, Quot.sound]`. The divergence proof is drafted in scratch and is next. No escalation is required.

Base: `50bb801a28ffd86ce7b47c91d47c257ab024fade`.
Bundle SHA-256 verified: `b4fecc2ccb020a6db6bb2c6c9ac22f6ee8b24ffeb9cef49f6ccf1a749ae18272`, 13 sections.

Only `TCSlib/Complexity/Diagonalization/Ladner.lean` is modified in the Lean worktree. The only added import is the approved `ClassP.ModelInvariance`. All original text except the first target's proof body is byte-identical after removing this import and the new private helpers; an exact reconstruction against the base passed.

## Current proof work

- `ladner_pad_nil`: separator excludes empty padded words.
- `ladner_padded_index`: arbitrarily large canonical binary indices for a fixed code, adapted from the supplied checked scratch proof.
- `ladner_indexed_deadline`: absorbs the coefficient and degree, adapted from the supplied checked scratch proof.
- `ladner_correct_index`: one-work-tape decider conversion, empty input, output uniqueness, and deadline monotonicity.
- `ladner_selector_bound`: least-index/cap bound, adapted from the supplied checked scratch proof.

No new public declaration, axiom, or admission was introduced. Existing unowned targets are retained. The first target is certified by `bounded-attempt-2.log` and `bounded-axioms.log`. Its initial check found one list-length elaboration mismatch, corrected before the successful check; both attempts are retained.

## Boundary ledger so far

Foreign definitions are used through these published contracts: `P` through `mem_P_iff_one_work_tape`; `DecidesInTime` through `FinTM.decidesInTime_iff`; `ComputesFunInTime` through `FinTM.computesFunInTime_iff`; `ComputesInTime` through `not_computesInTime_zero`, `ComputesInTime.mono`, and `ComputesInTime.output_unique`; the language indicator through `MultiTapeTM.indicator_of_mem` and `_of_not_mem`; code conversion through `FinTM.toCodeTM_computesInTime_iff`; the uniform scheme through its public `decode_encode_pad` field. SAT occurs only as a membership proposition. No foreign definition is an explicit simp/rw/unfold argument.

## Environment and checks

macOS adaptations: `sysctl`, `memory_pressure`, `vm_stat`, `df -k`, and `mount` replace Linux-only resource commands. Preflight found 12 CPUs, 18 GiB physical memory, 48% memory free (about 8.64 GiB), and about 232 GiB free disk. See `preflight.log` for exact output.

The worktree is separate from the exchange checkout, at the exact base, on local-only branch `codex/fill-ladner-selectors`. `.lake/packages` links the existing populated package tree in the campaign checkout. Every present package URL/revision matches the base manifest; absent documentation packages are listed in `manifest.log`. No cache fetch, project Lake build, shared TCSlib object tree, or toolchain modification was used. A Mathlib import probe exited 0 with zero errors.

A fresh scratch olean tree was bootstrapped from the Ladner import closure and the approved model-invariance import, using the repository's `leanelab-o.sh`, `nice -n 10`, and `lean -j4`. There is at most one Lean process of this fill at a time. The runner checks `pgrep -x lean` before each invocation and waits when the count is at least three. Such waits have occurred and are recorded verbatim in `evidence/logs/concurrency.log`; the final report will total them. All 116 import-bootstrap modules passed, with exit 0 and zero errors. Target 1 then passed the owned-file check and its axiom print. Target 2, the sealed check, and the facade check remain to be completed.

The source for the counted runner is included under `evidence/runtime/`. Raw earlier bootstrap warnings belong to unchanged base modules.

## Delivery

This is a cumulative checkpoint with 1/2 target proofs complete. The final zip will include the delivered source, base patch, complete check logs, both target axiom prints, facade check, declaration freeze check, and the final boundary inventory.
