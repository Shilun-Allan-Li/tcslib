from pathlib import Path
import subprocess,json,sys
queries={
 'sph_record_suffix':r'sph_record_suffix|recordInit.*(runner|window)|recordLength.*spaceUsed',
 'sph_record_size':r'sph_record_size|recordLength.*(logSpace|bits)|posWidth.*(log|length)|indicator_eq_decide',
 'sph_valid_machine':r'sph_valid_machine|embedSilentRetTM|space_hierarchy|window.*diagonal',
 'sph_halt_contract':r'sph_halt_contract|exists_first_halt|def ofSegment|Contract.*halt|first.*halt.*Contract',
 'sph_validated_machine':r'sph_validated_machine|inputFoldTM.*Contract|alphabetReduction|validated.*machine|foreign.*symbols',
 'sph_diagonal_language':r'sph_diagonal_language|indicator_eq_decide|space_hierarchy|decidesInSpace_of_alphabetReduction|toFinNDTM_haltsWithin_and_accepts_iff',

 'sph_select_fields':r'sph_select_fields|select.*state|select.*inputPos|embedEmitCfg_select',
 'sph_runner_run':r'sph_runner_run|sphRunnerSel|exists_configWindowRunnerTM|embedEmitTM.*windowRunner',
 'sph_test_run':r'sph_test_run|sphRecordSel|exists_recordTestTM|recordTest.*embed',
 'sph_verdict_run':r'sph_verdict_run|sphVerdictTM|seamCompTM₂.*emit|Contract.branch',
 'sph_summary':r'sph_summary|windowRun_stop_unique|outSummaryCode_eq_one_iff|windowRun_summary_of_halts',
 'sph_seam_heads':r'sph_seam_heads|seamComp.*(head|envelope|spaceUsed)|Contract.seq|seq_traj',
 'sph_seam_avoids':r'sph_seam_avoids|seamComp.*(avoid|cut)|branch_traj|runFrom_right',
 'sph_written_record':r'sph_written_record|RecordAt.*workTapes|recordAt.*(write|update)|fieldsTape_of_length_le',
 'sph_runner_tail_run':r'sph_runner_tail_run|sphRunnerTailTM|WindowExit.*halted|windowRunner.*verdict',
 'sph_suffix':r'sph_suffix|space_hierarchy|windowRun.*outSummary|ComputesInTime.*configBound',
 'sph_rewinds_run':r'sphRewindsTM|sph_rewinds_run|inputRewindTM.*rewindTM|seamCompTM.*inputRewindTM',
 'sph_input_rewind_run':r'sphEmptySel|sph_input_rewind_run|inputRewindTM_run|inputRewindTM.*liftSymbols',
 'sph_initial_record':r'sphInitSel|sph_initial_record|exists_recordInitTM|embedEmitTM.*recordInit',
 'sph_code_window':r'sph_code_window|one_work_tape_binary_spaceUsed|exists_codeTM_spaceUsed|windowRun_summary_of_halts|Computation.*configBound',
 'sph_linear_ne_NP_of_padding':r'sph_linear_ne_NP_of_padding|SPACE_linear_ne_NP|preimage_mem_NP|polyTimeComputable_polyUnary|SPACE.*n \^ 2 \+ 1',
 'sph_right_run':r'sphRightTM|sph_right_run|moveInputPos_pos_of_ne_right|moveInputPos_rightBoundary|step_of_inputMoveAction',
 'sph_emit_run':r'sphEmitTM|sph_emit_run|output := .*output \+\+ \[|emit.*run_ofCfg',
 'sph_fold_valid':r'sphDigit|sph_fold_valid|foldl.*digit|digit.*foldl|decodeBool_eq_some',
 'sph_validation_run':r'sph_validation_run|inputFoldTM_run_ofCfg|inputFoldTM.*digit',
 'sph_witness_cap':r'sphWitnessSel|sph_witness_cap|cap.*Set.range|tape.*bank',
 'sph_radius_run':r'sph_radius_run|embedSilentRetTM_run|bits.*map RecSym.digit|ComputesInSpace.*bits',
}
refs=['e6bc196838b4e2675e4214306c730e7404624ab8']+['refs/remotes/audit/pr-'+str(n) for n in [211,210,208,195]]
for name in sys.argv[1:] or queries:
 with Path('evidence/logs/semantic-'+name+'.log').open('w') as f:
  f.write('Name and statement-family search for '+name+'\n')
  for ref in refs:
   f.write('\nREF '+ref+'\nQUERY '+queries[name]+'\n');f.flush()
   subprocess.run(['git','grep','-n','-E',queries[name],ref,'--','TCSlib/**/*.lean'],stdout=f,stderr=subprocess.STDOUT)
 print(name,'searched base and all four open PR heads')
