from pathlib import Path
import json, re
root=Path.cwd()/'evidence'
identity=json.loads((root/'logs/final-delivery-identity.json').read_text())
edge='''## Required edge cases

| Case | Checked lemma or public reading |
|---|---|
| Empty binary input | `sph_fold_valid` proves the empty-list case; `sph_valid_machine` and `sph_diagonal_language` quantify over every `List Bool` with no nonempty premise; the floors give a positive radius |
| Rich input containing a foreign symbol | `sph_fold_valid` characterizes the valid image; `sph_validated_machine` sends the false branch directly to the stationary-head false emitter |
| Witness halts with input head at zero | `sph_right_run` uses `moveInputPos_pos_of_ne_right` and `moveInputPos_rightBoundary` to obtain positivity, then `sph_input_rewind_run` restores position one |
| Witness's final transition emits | `sph_radius_run` uses `embedSilentRetTM_run` at the first halt; `embedSilentCfg_cap` reads the complete captured output |
| Universal output is not `[true]` | `sph_summary` uses `outSummaryCode_eq_one_iff`; `sph_verdict_run` emits the complement of the test, hence true |
| Window exit is `left` | The `left` branch of `sph_runner_tail_run` dispatches directly to the true emitter |
| Clock exit is `exhausted` | The `exhausted` branch of `sph_runner_tail_run` dispatches directly to the true emitter without reading or testing the unspecified record |
| Run clock is beyond an earlier halt | `sph_code_window` uses `FinTM.ComputesInTime.spaceUsed_le_of_halt`; `sph_summary` uses `windowRun_stop_unique` to align endpoint round counts |
| Input length below the domination threshold | `sph_inclusion` absorbs the finite prefix; the diagonal contradiction's `sph_code_window` chooses a payload whose paired length is at least the threshold by `length_pairEncode` |
| The lower bound needs `1 ≤ f n` | `sph_code_window` derives it from `spaceConstructible_iff` and `logSpace_eq` before bounding the universal simulation coefficient |

'''
base_sorries='''## Baseline admissions by name

The bootstrap has exactly 26 warnings in the following ten modules. The only removals are
`space_hierarchy` and `LOGSPACE_ssubset_PSPACE`; the remaining 24 admissions are unchanged.
The complete original list is also in `evidence/logs/base-sorries.txt`.

| Module under `TCSlib/Complexity` | Baseline declarations |
|---|---|
| `TuringMachine/Simulation` | `branchTM_spaceUsed` |
| `TuringMachine/Encoding` | `pairDiagTM_computes` |
| `TuringMachine/Composition` | `idTM_computes`, `ifEqTM_computes`, `condTM_computes_iff` |
| `ClassP/TimeConstructible` | `_root_.Turing.FinTM.lengthBitsTM_computes`, `_root_.Turing.FinTM.lengthBitsTM_spaceUsed` |
| `TuringMachine/Build/Wrappers` | `timedCondTM_computes`, `timedCondTM_spaceUsed` |
| `TuringMachine/Build/Loop` | `loopHostTM_contracts`, `loopHostTM_decides`, `loopHostTM_finds`, `loopHostTM_spaceUsed_le_budget`, `emitLoopTM_computes` |
| `TuringMachine/Build/Primitives` | `polyUnaryTM_spaceUsed`, `unaryTokenTM_computes`, `appendBitTM_computes` |
| `TuringMachine/Build/RecordTable` | `exists_tableFindTM`, `exists_tableAppendTM`, `exists_recordValidTM`, `exists_recordNextTM` |
| `SpaceComplexity/Savitch` | `savitch` |
| `SpaceComplexity/Hierarchy` | `space_universal`, `space_hierarchy`, `LOGSPACE_ssubset_PSPACE`, `SPACE_linear_ne_NP` |

'''
citations='''The final citation inventory combines elaborated proof references with explicit source
identifier resolution: 900 outside constants, 272 from TCSlib, with no directly cited foreign
`_private` constant. The elaborated walk alone records 882 constants, 269 from TCSlib; explicit
source resolution contributes three further TCSlib readings that simplification removed from
proof terms. The final import probe has 321 checks, adding 150 to the supplied 171. Its source
is `FinalImportProbe.lean`; the complete citation list is `evidence/citations/final.md`.
The bundled ND field readings' source modules are correctly recorded as
`TuringMachine/Nondeterministic`. No additional definition needed sealing.

The source-identifier diagnostic initially used two incompatible metaprogramming calls;
`final-source-citations-v2` is the successful run on the corrected source, with the earlier
errors retained. The inspection table `evidence/inspection/final_v2.md` enumerates all 442
rewriting/reduction tactic sites, including complete multiline arguments and public target
bodies. Own lets/leaves and public equations are the only explicit reduction arguments.

'''
validation='''Current checkpoint-8 validation is `final-v2-edit`: the corrected owned module and facade,
the elaborated walk, all 43-private/three-public axiom prints, and the complete 71-definition
seal all pass. `final-v2-import` passes all 321 checks (12.247 seconds; peak RSS 2,080,164 KiB).
The unchanged 71-definition seal has the same 75 effective controls as `cp8-final`, all passing
unsealed and failing sealed. The inspection has 442 sites. The final lint logs are
`final-v2-campaign-lint.txt` (0 FAIL, 81 WARN) and `final-v2-style-lint.txt` (only the baseline
heading finding and permitted file-length finding).
'''
for label in ['cp8','final']:
 p=root/'reports'/(label+'.md');s=p.read_text()
 s=s.replace('Source: 2,576 physical lines','Source: 2,563 physical lines').replace('line 2,577','line 2,564')
 s=s.replace('The remaining open public bodies are `space_hierarchy` and\n`SPACE_linear_ne_NP`, both with literal **Proof sketch** text. The untouched F6 body remains\n`sorry`. No other source file or admission was changed.',
 'The only open target is `SPACE_linear_ne_NP`, with literal **Proof sketch** text. The\nuntouched F6 body `space_universal` remains `sorry` with its original docstring. Both completed\npublic target bodies and all 43 private declarations are admission-free. No other source file\nor admission was changed.')
 start=s.index('The final citation inventory combines') if 'The final citation inventory combines' in s else s.index('The elaborated walk records ')
 end=s.index('| Axiom walk |',start)
 s=s[:start]+citations+s[end:]
 if '## Required edge cases' not in s:s=s.replace('## Environment and verification',edge+'## Environment and verification')
 if '## Baseline admissions by name' not in s:s=s.replace('## Duplication and lint',base_sorries+'## Duplication and lint')
 s=s.replace('FINAL_SEMANTIC_SEALED_STATUS',
 'both searches also reached the 1,000,000-heartbeat budget (156.367 seconds total). The raw errors remain in `final-semantic-sealed`; no complete published replacement was certified by these diagnostics')
 # Replace the stale checkpoint validation paragraph, preserving later sections.
 s=re.sub(r'Checkpoint-8 validation:.*?(?=\n\n## |\Z)',validation.rstrip(),s,flags=re.S)
 if label=='final':
  s=s.replace('bf4d026a7bea613fa9649bc8fe9ca05dbe6632d1',identity['head'])
  s=s.replace('aa0c43fa6f1567ff5c560d4f3385e0af1ad73a63','e7b54ea9ddf1cda851f0d31838a4f4b43c8bf5d5')
  s=re.sub(r'The full 52-module downstream sweep passes.*?FINAL_SCREEN_HEADLINE',
   'FINAL_SWEEP_HEADLINE\nThe 71-definition seal passes, all 75 controls pass unsealed and fail sealed, and the final\n321-name import probe passes. Campaign lint: 0 FAIL, 81 WARN. FINAL_SCREEN_HEADLINE',s,count=1,flags=re.S)
  s=re.sub(r'Final citation verification:.*',
   'Final citation verification: `final-v2-import` checks the 321-name union; all checks pass\n(12.247 seconds; peak RSS 2,080,164 KiB).',s)
  history='''

The first frozen-final screen, at `bf4d026a7bea613fa9649bc8fe9ca05dbe6632d1`, found
12 new pairs, all below 90%, with 1,893 declarations, 1,701 pairs and 539,440 reproduced
characters. Inspection identified two pure `mapState` composition calculations inside
`sph_valid_machine`. They now directly cite the public `Cfg.mapState_mapState`, removing
13 lines. This is a re-derivation repaired by citation, not merely an idiom disposition.
Only the unpublished checkpoint-8 commit was amended; its refreshed archive supersedes its
first version. All raw first-screen evidence is retained as history. The final screen and
sweep below concern the amended commit.
'''
  s=s.replace('FINAL_SCREEN_RESULT',history+'\nFINAL_SCREEN_RESULT')
 p.write_text(s)
# The final package must be gated on the corrected commit's full screen.
p=root/'runtime/package_checkpoint.py';s=p.read_text().replace('screen-after-final-resource.json','screen-after-final-v2-resource.json');p.write_text(s)
print('Updated final and checkpoint-8 reports, edge-case ledger, baseline admissions, and final archive gate.')
