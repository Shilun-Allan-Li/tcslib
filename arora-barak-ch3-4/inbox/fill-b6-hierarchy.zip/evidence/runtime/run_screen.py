import datetime,hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path.cwd(); tree=pathlib.Path(sys.argv[1]).resolve(); label=sys.argv[2]
paths=(root/'campaign/fills/b6/inputs/b6-fill-hierarchy/screen-population.txt').read_text().splitlines()
script=root/'scripts/copy-text-screen-v3.py'
cmd=['nice','-n','10','python3','-I',str(script),str(tree)]+paths
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (root/'evidence/logs'/('screen-'+label+'.txt')).open('w') as out:
 p=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT)
 _,status,use=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
row={'commit':subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip(),'command':cmd,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':round(time.monotonic()-t,3),'max_rss_kib':use.ru_maxrss,'exit':p.returncode}
(root/'evidence/logs'/('screen-'+label+'-resource.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));sys.exit(p.returncode)
