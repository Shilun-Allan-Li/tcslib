from pathlib import Path
import hashlib, json, shutil, subprocess, sys, zipfile
base='e6bc196838b4e2675e4214306c730e7404624ab8'
label=sys.argv[1]
repo=Path.cwd()
workspace=repo.parent
name='fill-b6-hierarchy'+('' if label=='final' else '-'+label)
stage=workspace/'deliverables'/name
stage.mkdir(parents=True,exist_ok=True)
def git(*args): return subprocess.check_output(['git',*args],cwd=repo,text=True)
head=git('rev-parse','HEAD').strip()
if label=='final':
 report=(workspace/'evidence/reports/final.md').read_text()
 assert not __import__('re').search(r'FINAL_[A-Z_]+',report)
 screen=json.loads((workspace/'evidence/logs/screen-after-final-v2-resource.json').read_text())
 assert screen['exit']==0 and screen['commit']==head
 sweep=json.loads((workspace/'evidence/logs/final-sweep-accounting.json').read_text())
 assert sweep['modules']==52 and sweep['head']==head
 assert (workspace/'evidence/logs/screen-final-classification.txt').exists()
 assert (workspace/'evidence/logs/final-citation-accounting.json').exists()
assert git('diff','--name-only').strip()==''
assert git('diff','--cached','--name-only').strip()==''
changed=git('diff','--name-only',base,head).splitlines()
assert changed==['TCSlib/Complexity/SpaceComplexity/Hierarchy.lean'], changed
source=Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean')
(stage/source).parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,stage/source)
shutil.copy2(workspace/'evidence'/'reports'/(label+'.md'),stage/'REPORT.md')
patchdir=stage/'patches';patchdir.mkdir(exist_ok=True)
subprocess.run(['git','format-patch','--output-directory',str(patchdir),base+'..'+head],check=True)
bundle=stage/'fill-b6-hierarchy.bundle'
subprocess.run(['git','bundle','create',str(bundle),base+'..HEAD'],check=True)
res=subprocess.run(['git','bundle','verify',str(bundle)],capture_output=True,text=True)
(stage/'bundle-verify.log').write_text(res.stdout+res.stderr)
assert res.returncode==0
assert 'requires this ref:' in res.stdout+res.stderr or 'requires this ref' in res.stdout+res.stderr
shutil.copytree(workspace/'evidence'/'logs',stage/'evidence'/'logs',dirs_exist_ok=True)
shutil.copytree(workspace/'evidence'/'runtime',stage/'evidence'/'runtime',dirs_exist_ok=True)
shutil.copytree(repo/'FillProbes',stage/'evidence'/'probes',dirs_exist_ok=True)
shutil.copytree(workspace/'dispatch',stage/'evidence'/'dispatch',dirs_exist_ok=True)
for extra in ['inspection','citations','reports','drafts']:
 p=workspace/'evidence'/extra
 if p.exists():shutil.copytree(p,stage/'evidence'/extra,dirs_exist_ok=True)
(stage/'COMMIT').write_text(head+'\n')
sums=[]
for p in sorted(stage.rglob('*')):
 if p.is_file() and p != stage/'SHA256SUMS':
  sums.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(stage)))
(stage/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
zip_path=workspace/(name+'.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(stage))
with zipfile.ZipFile(zip_path) as z: assert z.testzip() is None
print(json.dumps({'file':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'commit':head}))
