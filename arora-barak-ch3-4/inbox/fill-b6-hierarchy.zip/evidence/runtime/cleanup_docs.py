from pathlib import Path
p=Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean')
s=p.read_text()
repls={
'([AB09, Exercise 3.2], restated with the positive normalization per the P0\nconvention — `AroraBarakChapters3-4Plan.md` §2.4). Phase P4.3; on 2026-10-12\n`space_universal` was restated forward-only and `space_hierarchy`\'s sketch\nmoved to the window route (`machine-library-design.md` §16b item 3,\n`backlog.md` RD-3; statement gate passed 2026-10-13), and on 2026-10-13\n`space_universal` was strengthened to the addend-free `C · s`, whose hosts\n(H3, H5 and `U₀`) passed their statement gate on 2026-10-14.':
'([AB09, Exercise 3.2], stated with the positive normalization). The universal\nmachine statement has a forward clause with the addend-free bound `C · s`;\nthe hierarchy uses a fixed self-application universal machine inside a\nspace-bounded configuration window.',
"suffix of its input, is read through H5's bounded-prefix ruler device":
'suffix of its input, is read through the bounded-prefix ruler device',
'qualifying run visits a cell (strengthened\n  2026-10-13 from a `+ logSpace n` addend).':
'qualifying run visits a cell.',
'**The hierarchy takes the window route** (design §16b item 3):':
'**The hierarchy takes the window route**:',
'`S` (Finding B, recorded in the sketches).':'`S`.',
'bundled floor `1 ≤ logSpace n ≤ f n` (round-1 confirmed, recorded in the\n  sketch).':'bundled floor `1 ≤ logSpace n ≤ f n`.',
'* Facade wiring: root-wired while the P4.1 gate was live; the\n  `SpaceComplexity.lean` facade has carried this module since that gate\n  closed.':'* The `SpaceComplexity.lean` facade imports this module.',
'## Main results (all sorried; phase-P4.3 statements)':'## Main results',
'[AB09]; spec, fill pending — phase P4.3, sketch moved to the window route\n2026-10-12 by design §16b item 3, RD-3 statement gate passed 2026-10-13): for':
'[AB09]): for',
'bundled floor (recorded here, seeded to the audit). Positivity of both bounds\nis automatic from the bundled `logSpace` floor, so the P0 zero-bound\nconvention needs no side condition.':
'bundled floor. Positivity of both bounds is automatic from the bundled\n`logSpace` floor, so the zero-bound convention needs no side condition.',
"head as the simulated one (H5's native device: the simulated input is all of":
'head as the simulated one (the native device: the simulated input is all of',
'and the H2 step block on the canonical table.':'and the step block on the canonical table.',
'(i) validate the input (`Turing.inputFoldTM`, R8.5d; decision O6), so that':
'(i) validate the input (`Turing.inputFoldTM`), so that',
'(iii) run the H3 windowed runner: each round':'(iii) run the configuration-count windowed runner: each round',
'coded in `Fin 3` by design §12.8a decision O4), so the emitted word is\nnever buffered (W1).':'coded in `Fin 3`), so the emitted word is never buffered.',
'(`Turing.counterLoopTMVia`, §12.7 and R8.0b) on an':'(`Turing.counterLoopTMVia`) on an',
'simulation (round-1 finding 5);':'simulation;',
'Fill obligations, named in\nthe host vocabulary of design §14: `U₀` with its forward ledger (the H2 step\nblock at one coded work tape, H5\'s native input device, the chapter-1\nstartup), a public row as H2\'s named consumer, not a private host of this\nproof; the H3 windowed runner at `U₀` with the output-summary tag, over the\nrecord rows `exists_recordInitTM` (record-table row 18; row 17,\n`exists_recordTemplateTM`, beneath it), `exists_recordTestTM` and':
'The construction uses\n`U₀` with its forward ledger (the step block at one coded work tape, the\nnative input device and the chapter-1 startup); the configuration-count\nwindowed runner at `U₀` with the output-summary tag, over the record rows\n`exists_recordInitTM` (with `exists_recordTemplateTM` beneath it),\n`exists_recordTestTM` and',
'"the hierarchy theorems imply `L ⊊ PSPACE`"]; spec, fill pending).':
'"the hierarchy theorems imply `L ⊊ PSPACE`"]).',
'`Complexity.spaceConstructible_linear` of phase P4.1; domination:':
'`Complexity.spaceConstructible_linear`; domination:',
'normalization `n + 1` per the P0 convention — the literal `SPACE(n)` is the\nzero-work-tape class; spec, fill pending).':'normalization `n + 1` — the literal `SPACE(n)` is the zero-work-tape class).',
'membership restricted to padded members of `L` (round-2 finding 5); padded':
'membership restricted to padded members of `L`; padded'
}
# Protect F6's entire docstring and declaration while editing the surrounding documentation.
a=s.index('/-- **The space-bounded universal machine**')
b=s.index('/-- **The space hierarchy theorem**')
f6=s[a:b]
surround=s[:a]+'\x00F6\x00'+s[b:]
for old,new in repls.items():
 assert old in surround, repr(old)
 surround=surround.replace(old,new,1)
s=surround.replace('\x00F6\x00',f6)
p.write_text(s)
print('Applied allowed public-facing documentation cleanup; F6 byte-preserved')
