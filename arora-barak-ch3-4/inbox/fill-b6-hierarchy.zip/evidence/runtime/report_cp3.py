from pathlib import Path
s=Path('evidence/reports/cp2.md').read_text()
s=s.replace('checkpoint 2','checkpoint 3',1)
a=s.index('**Partial delivery.**'); b=s.index('## Identity')
s=s[:a]+'''**Partial delivery.** Checkpoints 1, 2, 3, 5 and 7 have landed as independent commits.
The full clocked simulation suffix now compiles and passes the seal: runner, all three exits,
record test, opposite-bit emitter, and a uniform suffix head bound. The assembled diagonalizer's
all-input space bound, alphabet-reduction packaging and hierarchy strictness remain open.
The logarithmic-space corollary has a proof body but inherits `sorryAx` from `space_hierarchy`.

This checkpoint preserves checked source immediately. The final after-screen and the final
52-module downstream sweep are pending. No mathematical obstruction is asserted for the
remaining hierarchy work. Checkpoint 8 remains last.

'''+s[b:]
s=s.replace('`aae09bb9510e75b7760bdd1ac7ce190749c086be`','`CHECKPOINT_COMMIT`')
s=s.replace('1,016 lines, four public declarations and 21 private declarations','1,805 lines, four public declarations and 36 private declarations')
s=s.replace('| 3 | Open: runner, test, verdict and assembled run; emitter leaf is already proved |','| 3 | Complete simulation suffix: runner, test, all three exits, opposite answer and head envelope |')
pos=s.index('\nEvery new private lemma')
s=s[:pos]+'''| `sph_select_fields` | Shared R1 selected-configuration readings via reconstruction; also used by the initializer |
| `sphRunnerSel` | Runner bank: record zero plus its separate scratch bank |
| `sph_runner_run` | Published runner by R1, including cuts, all exits, record endpoint and displacement bound |
| `sphRecordSel` | Single record-tape selection for the test |
| `sph_test_run` | Published record test by R1 with complete physical frame |
| `sphEmitContract` | Existing one-step emitter packaged as a stationary-head contract |
| `sphVerdictTM` | Published two-exit seam from record test to opposite-bit emitters |
| `sph_verdict_run` | Tested bit complement and shared head envelope |
| `sph_summary` | Returned stopped record aligned with a certified halting summary by stop uniqueness |
| `sph_seam_heads` | Common absolute interval transported through a published single-exit seam |
| `sph_seam_avoids` | A dispatched seam cannot revisit a different left-hand exit |
| `sph_written_record` | Shared record-boundary argument after an interior layout write |
| `sphRunnerTailTM` | Three published seams route halted, left and exhausted runner exits |
| `sph_runner_tail_run` | Complete three-exit suffix run and absolute head bound |
| `sph_suffix` | Uniform initial-record-to-halt suffix with opposite acceptance and displacement bound |
'''+s[pos:]
a=s.index('The combined diagonalizer is not yet assembled.'); b=s.index('## Normalization',a)
s=s[:a]+'''## Simulation suffix

`sph_suffix` applies `exists_configWindowRunnerTM` at the fixed finite machine with `Fin 3`,
`summaryTag` and initial tag zero. The tape-zero record and separate runner scratch bank are
selected by R1. On a halted exit, the returned record for an unspecified stopped round count
is matched to the certified halting summary by `windowRun_stop_unique`. The published record
test checks state `none` and tag one; the emitter writes the complementary bit. Left and
exhausted exits emit true. Exhaustion does not inspect the unspecified record.

Three existing single-exit seams handle the runner's three anchors. This is a composition of
published hosts, not a new seam transformer. The two verdict-test anchors use the published
two-exit seam and its branch contract. Every head stays within

```text
(CR + CT) * (recordLength M.k |x| s + 1)
```

of its initial physical position throughout the suffix. `CR` is the runner coefficient,
`CT` the record-test coefficient, `M` the fixed simulated machine, `x` its binary input and
`s` the radius. These constants do not depend on the input's code part. The suffix halts with
one output symbol on every valid initial record. Whenever `M` halts within the radius at its
configuration-count bound, that symbol is the opposite of its singleton-true acceptance.

The combined validator/radius/rewind/initializer/suffix machine and its total all-rich-input
space bound are not yet assembled. No complete diagonal language or strictness is claimed.

'''+s[b:]
a=s.index('`cp2-edit`'); b=s.index('## Duplication and lint',a)
s=s[:a]+'''`cp3-edit`, `cp3-discover` and `cp3-seal-fix2` check the owned module and facade after the
source edits. The final full seal, controls, extended import probe and axiom copy pass.
The initial seal detected four `WindowExit` equality-instance reductions in constructor
inequalities; those were replaced by constructor-disjointness proofs, and the strengthened
seal then passed. These diagnostic failures and all repair logs are retained.

The 55-definition seal covers all reached foreign TCSlib `def` declarations (including
instance definitions), the required five base definitions, transports, records, summaries,
machine operations and code scheme. Generated structure projections and recursor abbreviations
are not implementation definitions. The four primitive simp attributes are removed.
There are 59 effective controls: 54 whole-definition delta controls, the recursive `windowRun`
equation usage control and four primitive simp controls. All pass unsealed and fail sealed.
`runFrom` is an iterate wrapper, not a recursive source definition. Both raw outputs and all
probe sources are included.

The elaborated walk records 752 outside constants, 205 from TCSlib. The extended host probe
adds 118 checks/axiom prints beyond the supplied list and passes. No foreign `_private`
constant is reached directly. The rewrite inspection table expands every bracketed argument
list and contains 264 tactic sites. Only own definitions/local lets and public equation lemmas
are supplied to rewriting; the full seal checks residual definitional closure.

| Axiom walk | Result |
|---|---|
| All 36 private declarations | Subsets of `propext`, `Classical.choice`, `Quot.sound`; no `sorryAx` |
| `space_hierarchy` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `LOGSPACE_ssubset_PSPACE` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `SPACE_linear_ne_NP` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |

The three source sorry warnings remain the untouched F6 and the two open target bodies.
The corollary's admission dependency is through the hierarchy target; its conditional helper
and all machine-phase proofs are admission-free.

'''+s[b:]
a=s.index('The before-screen is byte-identical'); b=s.index('Every new private lemma has name',a)
s=s[:a]+'''The before-screen is byte-identical to the supplied base: 1,854 declarations, 1,689 pairs and
534,736 reproduced characters, no pair on Hierarchy. The frozen-checkpoint-1 after-screen
completed: 1,855 declarations, exactly the same 1,689 pairs byte for byte, no new pair.
For that completed comparison, **new copies: none**. A low-priority screen on frozen
checkpoint 2 is running; its partial output is included. A final after-screen must cover
the final head, so a final new-copy attestation remains pending. The final 52-module tail
is also pending.

'''+s[b:]
a=s.index('Campaign lint:')
s=s[:a]+'''For checkpoint 3, ten further exact? probes run against the base overlay plus the checked
checkpoint-2 declarations and new machine definitions, excluding all ten checkpoint-3 lemma
proofs. The per-lemma name/statement searches cover all four observed open PR heads. Hosts
found by those searches are cited, rather than copied. The exact? results are recorded in
`CP3Semantic.lean` and its raw diagnostic log. SEMANTIC_RESULT

'''+s[a:]
s=s.replace('No promotion is requested\nat this checkpoint. The next work is the runner and record-test R1 transport, seam assembly,\nspace bound and alphabet reduction.','Potential promotion candidates are `sph_select_fields`, the generic seam head/avoidance\nconsumers, and `sph_written_record`; no matching public lemma was found. These are consequences\nof public readings, not replacements for foreign private implementations. The next work is\nfull phase assembly, the all-input space bound and alphabet reduction.')
Path('evidence/reports/cp3.md').write_text(s)
