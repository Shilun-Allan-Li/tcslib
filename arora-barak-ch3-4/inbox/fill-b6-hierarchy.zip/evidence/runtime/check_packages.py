from pathlib import Path
import json,subprocess,sys
packages=json.loads(Path('lake-manifest.json').read_text())['packages']; bad=False; absent=[]
for p in packages:
 name=p['name'].strip('«»'); path=Path('.lake/packages')/name
 if not path.exists():print('ABSENT',name);absent.append(name);continue
 url=subprocess.check_output(['git','-C',str(path),'remote','get-url','origin'],text=True).strip()
 rev=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
 ok=url==p['url'] and rev==p['rev'];bad|=not ok
 print('MATCH' if ok else 'MISMATCH',name,url,rev)
order=Path('campaign/fills/b6/orders/b6-fill-hierarchy.txt').read_text().splitlines()
for m in order:
 for line in Path(m+'.lean').read_text().splitlines():
  if line.startswith('import ') and any(line.split()[1].split('.')[0].lower()==a.lower() for a in absent):
   print('ABSENT_IMPORT',m,line);bad=True
print('PACKAGES PASS: every present package matches manifest URL and revision; no order-list import names an absent package.' if not bad else 'E-RES: package manifest check failed')
sys.exit(int(bad))
