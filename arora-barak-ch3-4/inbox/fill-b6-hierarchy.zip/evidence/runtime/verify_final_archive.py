from pathlib import Path
import hashlib,json,re,subprocess,zipfile
repo=Path.cwd();path=repo.parent/'fill-b6-hierarchy.zip'
base='e6bc196838b4e2675e4214306c730e7404624ab8'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
src='TCSlib/Complexity/SpaceComplexity/Hierarchy.lean'
with zipfile.ZipFile(path) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
 entries=[]
 for line in z.read('SHA256SUMS').decode().splitlines():
  wanted,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==wanted,name;entries.append(name)
 assert set(entries)==set(names)-{'SHA256SUMS'}
 assert z.read('COMMIT').decode().strip()==head
 assert z.read(src)==(repo/src).read_bytes()
 assert len([n for n in names if n.startswith('patches/') and n.endswith('.patch')])==8
 assert not re.search(r'FINAL_[A-Z_]+',z.read('REPORT.md').decode())
 verify=z.read('bundle-verify.log').decode()
 prereq=verify.split('The bundle requires this ref:\n',1)[1].split('\n',1)[0].strip()
 assert prereq==base
 screen=json.loads(z.read('evidence/logs/screen-after-final-v2-resource.json'))
 sweep=json.loads(z.read('evidence/logs/final-sweep-v2-accounting.json'))
 assert screen['commit']==head and screen['exit']==0
 assert sweep['head']==head and sweep['modules']==52
 checks=json.loads(z.read('evidence/logs/final-proof-snapshot-integrity.json'))
 assert checks['source_sha256']==hashlib.sha256(z.read(src)).hexdigest()
 assert checks['control_results']=={'unsealed_pass':75,'sealed_fail':75}
 for filename,expected in [('b6-fill-hierarchy.md','3c92e156529b5a7f1f061e3b1d5beaf0918fe3b11355e34362441b56c36bd357'),('fill-environment-addendum.md','9f5bd5e74bb767e50a6e7a372e98a5567998ec14be432c1dfb7ff8856eb9bd28')]:
  assert hashlib.sha256(z.read('evidence/dispatch/'+filename)).hexdigest()==expected
 assert len(json.loads(z.read('evidence/logs/final-axiom-accounting.json')))==46
 result={'file':str(path),'head':head,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'entries_verified':len(entries),'crc':'PASS','patches':8,'sole_bundle_prerequisite':base,'final_screen':'PASS','final_sweep_modules':52}
print(json.dumps(result,indent=2))
