from pathlib import Path
import json,re,shutil,subprocess
root=Path('evidence/logs');d=root/'final-sweep-v2'
rows=[json.loads(x) for x in (d/'summary.jsonl').read_text().splitlines()]
order=[x for x in (root/'final-order.txt').read_text().splitlines() if x.strip()]
assert len(rows)==len(order)==52
assert [r['module'] for r in rows]==order
assert all(r['exit']==0 for r in rows)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='30222bbd264a75057ae0779535a32e1a30dd2394'
warnings={p.name:[x for x in p.read_text().splitlines() if 'warning:' in x] for p in d.glob('*.log')}
warnings={k:v for k,v in warnings.items() if v}
expected=["TCSlib/Complexity/SpaceComplexity/Hierarchy.lean:147:8: warning: declaration uses 'sorry'", "TCSlib/Complexity/SpaceComplexity/Hierarchy.lean:2560:8: warning: declaration uses 'sorry'"]
assert warnings['001-TCSlib_Complexity_SpaceComplexity_Hierarchy.log']==expected
style_warnings={}
for row in rows[1:]:
 suffix=row['module'].replace('/','_')+'.log'
 current=next(d.glob('*-'+suffix))
 baseline=next((root/'bootstrap').glob('*-'+suffix))
 now_w=[x for x in current.read_text().splitlines() if 'warning:' in x]
 base_w=[x for x in baseline.read_text().splitlines() if 'warning:' in x]
 assert now_w==base_w,(row['module'],base_w,now_w)
 if now_w:style_warnings[row['module']]=now_w
assert all('error:' not in p.read_text() and 'FAIL(' not in p.read_text() for p in d.glob('*.log'))
result={'head':head,'modules':len(rows),'seconds_sum':round(sum(r['seconds'] for r in rows),3),'max_rss_kib':max(r['max_rss_kib'] for r in rows),'warnings':warnings,'sorry_warnings':expected,'unchanged_baseline_style_warnings':style_warnings,'first_start':rows[0]['start'],'last_end':rows[-1]['end'],'log_directory':'evidence/logs/final-sweep-v2'}
for name in ['final-sweep-accounting.json','final-sweep-summary.md']:
 old=root/name;backup=root/name.replace('final-sweep','final-sweep-v1')
 if old.exists() and not backup.exists():shutil.copy2(old,backup)
for name in ['final-sweep-accounting.json','final-sweep-v2-accounting.json']:(root/name).write_text(json.dumps(result,indent=2)+'\n')
md=['# Final downstream sweep','',f'Commit: `{head}`. All 52 modules pass. Summed module wall time: {result["seconds_sum"]:.3f} seconds. Maximum peak RSS: {result["max_rss_kib"]:,} KiB. The two expected Hierarchy sorry warnings and two unchanged baseline style warnings in Randomized/Classes occur.','','| Module | Wall seconds | Peak RSS (KiB) | Exit |','|---|---:|---:|---:|']
for r in rows:md.append(f'| `{r["module"]}` | {r["seconds"]:.3f} | {r["max_rss_kib"]} | {r["exit"]} |')
(root/'final-sweep-summary.md').write_text('\n'.join(md)+'\n')
p=Path('evidence/reports/final.md');s=p.read_text().replace('FINAL_SWEEP_HEADLINE',f'The full 52-module downstream sweep passes with the two expected Hierarchy sorry warnings\nand two unchanged baseline style warnings in `Randomized/Classes`\n({result["seconds_sum"]:,.3f} seconds summed wall time; peak RSS {result["max_rss_kib"]:,} KiB).')
s=s.replace('The final tail has only\nthe two expected Hierarchy warnings.', 'The final tail has the two expected Hierarchy sorry warnings and two unchanged baseline\nstyle warnings in `Randomized/Classes.lean` (unnecessary `<;>` at line 499 and unused simp\nargument `hp` at line 1215). These also occur in the bootstrap and first final sweep; the\nearlier summary recorded only admission warnings. The affected source is byte-identical\nto the pinned base. Every other final-tail module has exactly its baseline warning list.')
p.write_text(s)
p=root/'final-delivery-identity.json';ident=json.loads(p.read_text());ident.pop('compiled_sweep_modules_pending',None);ident['compiled_sweep_modules']=52;p.write_text(json.dumps(ident,indent=2)+'\n')
print(json.dumps(result,indent=2))
