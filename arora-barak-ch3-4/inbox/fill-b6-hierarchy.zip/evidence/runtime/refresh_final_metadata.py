from pathlib import Path
import hashlib, json, re, subprocess
repo=Path.cwd(); ev=repo/'evidence'; src=repo/'TCSlib/Complexity/SpaceComplexity/Hierarchy.lean'
def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
base='e6bc196838b4e2675e4214306c730e7404624ab8'
head=git('rev-parse','HEAD')
log=(ev/'logs/final-v2-edit/004-FillProbes_final_v2_Axioms.log').read_text()
axioms={n:[x.strip() for x in s.replace('\n',' ').split(',') if x.strip()] for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",log)}
axioms.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",log)})
assert len(axioms)==46
assert sum(n.startswith('_private.') for n in axioms)==43
standard={'propext','Classical.choice','Quot.sound'}
for n,ax in axioms.items():
 assert set(ax)<=standard|({'sorryAx'} if n=='Complexity.SPACE_linear_ne_NP' else set()),(n,ax)
assert 'sorryAx' in axioms['Complexity.SPACE_linear_ne_NP']
(ev/'logs/final-axiom-accounting.json').write_text(json.dumps(axioms,indent=2)+'\n')
cites=json.loads((ev/'citations/final.json').read_text())
acct=json.loads((ev/'logs/final-citation-accounting.json').read_text())
assert len(cites)==acct['outside_constants']==900
assert sum(v[0].startswith('TCSlib.') for v in cites.values())==acct['TCSlib_constants']==272
assert all(not n.startswith('_private.') for n in cites)
identity={'base':base,'head':head,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
'source_blob':git('rev-parse','HEAD:TCSlib/Complexity/SpaceComplexity/Hierarchy.lean'),
'lines':len(src.read_text().splitlines()),'commits':int(git('rev-list','--count',base+'..HEAD')),
'compiled_sweep_modules_pending':52,'seal_definitions':71,'controls':75,'import_checks':321,
'outside_citations':900,'TCSlib_citations':272}
(ev/'logs/final-delivery-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity,indent=2)); print('46 axiom prints checked; all 43 privates and both completed targets are standard-axiom only.')
