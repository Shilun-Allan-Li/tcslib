from pathlib import Path
import hashlib,json,re,subprocess
root=Path('evidence/logs');head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
resource=json.loads((root/'screen-after-final-v2-resource.json').read_text());assert resource['exit']==0 and resource['commit']==head
script=Path('scripts/copy-text-screen-v3.py').read_bytes();assert hashlib.sha256(script).hexdigest()==resource['script_sha256']
assert script==subprocess.check_output(['git','show','e6bc196838b4e2675e4214306c730e7404624ab8:scripts/copy-text-screen-v3.py'])
assert (root/'screen-before.txt').read_bytes()==Path('campaign/fills/b6/logs/b6-fill-hierarchy-screen-base.txt').read_bytes()
def read(p):
 lines=p.read_text().splitlines();m=re.fullmatch(r'declarations screened: (\d+); copy pairs \(target reproduces >= half of source\): (\d+); reproduced text: ([\d,]+) chars',lines[0]);assert m
 rows=[]
 for line in lines[1:]:
  if not line.strip():continue
  r=re.fullmatch(r'\s+(\S+)  reproduces  (\S+): (\d+)/(\d+) = (\d+)%',line);assert r,line
  a,b,n,d,pct=r.groups();rows.append({'target':a,'source':b,'chars':int(n),'source_chars':int(d),'percent':int(pct),'raw':line})
 assert len(rows)==int(m[2])
 return {'declarations':int(m[1]),'pairs':int(m[2]),'characters':int(m[3].replace(',',''))},rows
before,old=read(root/'screen-before.txt');after,rows=read(root/'screen-after-final-v2.txt')
oldkeys={(r['target'],r['source']) for r in old};keys={(r['target'],r['source']) for r in rows}
added=[r for r in rows if (r['target'],r['source']) not in oldkeys]
removed=[r for r in old if (r['target'],r['source']) not in keys]
assert not removed
D={
('sph_valid_machine','Cfg.mapState_mapState'):('idiom; earlier pure re-derivations repaired','The remaining match is the concrete initial-configuration comparison through capture, lift, blank-frame and initialization fields. Both pure composition calculations now cite Cfg.mapState_mapState directly.'),
('sph_verdict_run','Cfg.mapState_mapState'):('idiom','Public field readings establish a branch precondition using its live-state hypothesis and emitted endpoints with changed state/output; this is not the generic composition equation.'),
('sph_rewinds_run','Cfg.mapState_mapState'):('idiom','Public field readings for a framed endpoint that changes input position and the radius head; not pure state-map composition.'),
('sph_record_suffix','Cfg.mapState_mapState'):('idiom','Restore the original live entry configuration using its state hypothesis and unchanged physical fields; the conclusion is not the generic composition equation.'),
('sph_validated_machine','Cfg.mapState_mapState'):('idiom','Concrete initialization and branch-precondition identities through Cfg.init and mapState field readings.'),
('sph_right_run','sph_emit_run'):('same-file leaf idiom','The two explicitly permitted one-step leaves have different effects and share public action-field readings.'),
('sph_emit_run','sph_right_run'):('same-file leaf idiom','Reverse direction of the same permitted-leaf comparison.'),
('sphWitnessSel','sphInitSel'):('same-file arithmetic idiom','Distinct bank selections share elementary embedding-injectivity arithmetic.'),
('sph_valid_machine','sph_witness_cap'):('same-file arithmetic idiom','This excludes the entire initializer/runner bank from the witness bank; sph_witness_cap is already cited for the distinct claim excluding radius tape one.'),
('sph_runner_run','sph_initial_record'):('same-file R1 consumer idiom','Distinct published clocked-runner and initializer hosts, both embedded through R1; shared field transport already factors through sph_select_fields.'),
('sph_runner_run','sph_test_run'):('same-file R1 consumer idiom','Distinct published clocked-runner and Boolean record-test hosts, with shared R1 field transport through sph_select_fields.'),
('sph_seam_avoids','sph_seam_heads'):('same-file public-trajectory idiom','The same public seam case split supports different conclusions: exit-state avoidance and a physical head envelope.')}
for r in added:
 assert r['target'].startswith('Hierarchy.lean::') or r['source'].startswith('Hierarchy.lean::')
 key=(r['target'].split('::')[-1],r['source'].split('::')[-1]);assert key in D,('UNCLASSIFIED',r)
 assert r['percent']<90 and r['chars']/r['source_chars']<.9,('COPY',r)
 r['disposition'],r['explanation']=D[key]
result={'head':head,'baseline':before,'final':after,'new_pairs':added,'removed_pairs':removed,'new_copies':[],'screen_seconds':resource['seconds'],'screen_max_rss_kib':resource['max_rss_kib']}
(root/'screen-final-accounting.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'screen-final-new-pairs.txt').write_text('\n'.join(r['raw'] for r in added)+'\n')
(root/'screen-final-removed-pairs.txt').write_text('\n'.join(r['raw'] for r in removed))
lines=[f'Final frozen commit: {head}.',f'Baseline: {before["declarations"]} declarations, {before["pairs"]} pairs, {before["characters"]} reproduced characters.',f'Final: {after["declarations"]} declarations, {after["pairs"]} pairs, {after["characters"]} reproduced characters.',f'{len(added)} new pairs; {len(removed)} removed pairs. No new pair reaches 90%.','']
for r in added:lines += [r['raw'],f'  Disposition: {r["disposition"]}. {r["explanation"]}','']
lines += ['New copies: none. No new pair rederives a foreign private declaration.', 'Historical first-screen finding: two pure mapState-composition calculations in sph_valid_machine were replaced by citations before this final run; see screen-first-final-classification.txt.']
(root/'screen-final-classification.txt').write_text('\n'.join(lines)+'\n')
p=Path('evidence/reports/final.md');s=p.read_text()
s=s.replace('FINAL_SCREEN_HEADLINE',f'The final text screen has {len(added)} new pairs, all below 90%; **new copies: none**.')
block=[f'The amended commit\'s final screen completes with {after["declarations"]:,} declarations,',f'{after["pairs"]:,} pairs and {after["characters"]:,} reproduced characters. There are {len(added)} new pairs',f'and no removed baseline pairs. It ran under `nice -n 10` in {resource["seconds"]:,.3f} seconds',f'(peak RSS {resource["max_rss_kib"]:,} KiB), with the unmodified pinned v3 script. Each new pair is', 'classified below; the complete raw outputs and `screen-final-classification.txt` are included.', '', '| Target in `Hierarchy.lean` | Source | Match | Disposition |','|---|---|---:|---|']
for r in added:block.append(f'| `{r["target"].split("::")[-1]}` | `{r["source"]}` | {r["chars"]}/{r["source_chars"]} ({r["percent"]}%) | {r["disposition"]}: {r["explanation"]} |')
block += ['', '**New copies: none.** No new pair rederives a foreign private declaration; no promotion is', 'required by the text screen. Optional general-consumer promotions are listed below.']
s=s.replace('FINAL_SCREEN_RESULT','\n'.join(block));p.write_text(s)
print(json.dumps({k:v for k,v in result.items() if k not in ['new_pairs','removed_pairs']},indent=2));print('New pairs:',len(added));print('\n'.join(r['raw'] for r in added))
