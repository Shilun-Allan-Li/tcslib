from pathlib import Path
s=Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean').read_text()
a=s.index('/-- The constructibility witness returns');b=s.index('/-- The input rewind uses no work tapes',a)
s=s[:a]+Path('evidence/drafts/sph_radius_envelope.lean.txt').read_text()+'\n'+s[b:]
a=s.index('/-- A common absolute head interval');b=s.index('/-- Once a seam dispatches',a)
heads=s[a:b];s=s[:a]+s[b:]
a=s.index('/-- The paired rewinds');b=s.index('/-- Read a selected configuration',a)
s=s[:a]+heads+Path('evidence/drafts/sph_rewinds_envelope.lean.txt').read_text()+'\n'+s[b:]
a=s.index('/-- **The space hierarchy theorem**')
parts=['sph_record_suffix','sph_record_size','sph_valid_machine','sph_halt_contract','sph_validated_machine','sph_diagonal_language']
s=s[:a]+'\n\n'.join(Path('evidence/drafts/'+n+'.lean.txt').read_text() for n in parts)+'\n\n'+s[a:]
Path('FillProbes/SpaceDraft.lean').write_text(s)
