from pathlib import Path
import re, subprocess, json, sys
label=sys.argv[1]
base='e6bc196838b4e2675e4214306c730e7404624ab8'
path='TCSlib/Complexity/SpaceComplexity/Hierarchy.lean'
s=Path(path).read_text()
b=subprocess.check_output(['git','show',base+':'+path],text=True)
start='/-- **The space-bounded universal machine**'
a=s.index(start);z=s.index('  sorry',s.index('theorem space_universal'))+len('  sorry\n')
ba=b.index(start);bz=b.index('  sorry',b.index('theorem space_universal'))+len('  sorry\n')
assert s[a:z]==b[ba:bz], 'F6 differs'
entry='* `Complexity.space_universal` — [AB09, Exercise 4.1], forward clause\n  (restated 2026-10-12; addend-free `C · s` since 2026-10-13).'
assert entry in s
for name in ['space_universal','space_hierarchy','LOGSPACE_ssubset_PSPACE','SPACE_linear_ne_NP']:
 def sig(t):
  st=t.index('theorem '+name+' ')
  return t[st:t.index(':= by',st)]
 assert sig(s)==sig(b),name+' statement changed'
imports=re.findall(r'^import .+$',s,re.M)
expected=re.findall(r'^import .+$',Path('campaign/fills/b6/inputs/b6-fill-hierarchy/HierarchyOverlay.lean.txt').read_text(),re.M)
assert imports==expected
names=re.findall(r'^private\s+(?:noncomputable\s+)?(?:def|lemma|theorem|abbrev|structure|inductive)\s+(\w+)',s,re.M)
assert all(n.startswith(('sph_','sph','Sph')) for n in names)
public=re.findall(r'^(?:theorem|lemma|def|abbrev|structure|inductive)\s+(\w+)',s,re.M)
assert public==['space_universal','space_hierarchy','LOGSPACE_ssubset_PSPACE','SPACE_linear_ne_NP'],public
diff=subprocess.check_output(['git','diff',base,'--',path],text=True)
added=[l[1:] for l in diff.splitlines() if l.startswith('+') and not l.startswith('+++')]
long=[l for l in added if len(l)>100]
forbidden=['copyTM_run','transferTM_run','clearTM_run','compareTM_run','incrementTM_run_succ','incrementTM_run_overflow']
violations=[]
for line in added:
 for n in forbidden:
  if re.search(r'\b'+n+r'\b',line):violations.append(line)
assert not violations,violations
assert not long,long
report={'base':base,'lines':len(s.splitlines()),'public':len(public),'private':len(names),'private_names':names,'sorry_count':len(re.findall(r'^\s+sorry\s*$',s,re.M)),'imports':'PASS exact overlay','F6':'PASS byte-identical docstring/declaration and module entry','statements':'PASS all four frozen','R3':'PASS no forbidden row in added lines','new_lines_over_100':len(long)}
Path('evidence/logs/'+label+'-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
# Preserve every relevant proof-tactic line, with adjacent continuation lines.
ins=Path('evidence/inspection');ins.mkdir(exist_ok=True)
rows=[]
in_new=False
for i,l in enumerate(s.splitlines(),1):
 if l.startswith('private '):in_new=True
 if l.startswith('/-- **The space hierarchy theorem**'):in_new=False
 if in_new and re.search(r'\b(?:rw|rwa|simp|simpa|simp_rw|dsimp|unfold|show|change)\b',l):
  rows.append(f'| {i} | `{l.strip().replace("|","&#124;")}` | Public equation/iff theorem, own local definition, or tactic without an explicit definition argument; see source and seal. |')
(ins/(label+'.md')).write_text('# Rewrite and reduction inspection\n\nAll matching tactic lines in new private declarations are enumerated below. Multi-line arguments are retained in the accompanying full source.\n\n| Line | Tactic | Inspection |\n|---|---|---|\n'+'\n'.join(rows)+'\n')
