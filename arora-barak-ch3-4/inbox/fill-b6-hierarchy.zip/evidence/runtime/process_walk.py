from pathlib import Path
import json,re,sys
label=sys.argv[1]
logs=sorted({p for prefix in {label,label.replace('_','-')} for p in Path('evidence/logs').glob(prefix+'*/**/*Walk.log')}, key=lambda p:p.stat().st_mtime)
assert logs
items={}
for line in logs[-1].read_text().splitlines():
 if not line.startswith('CITE '):continue
 _,name,mod,kind=line.split(' | ')
 if mod=='TCSlib.Complexity.SpaceComplexity.Hierarchy':continue
 items[name]=(mod,kind)
# Explicit simp arguments can disappear from elaborated proof terms.
for n in ['Turing.FinTM.toFinNDTM_k','Turing.FinTM.toFinNDTM_State']:
 if n.split('.')[-1] in Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean').read_text():
  items[n]=('TCSlib.Complexity.TuringMachine.Nondeterministic','theorem')
p=Path('evidence/citations');p.mkdir(exist_ok=True)
(p/(label+'.json')).write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n')
foreign={n:v for n,v in items.items() if v[0].startswith('TCSlib.')}
assert not any(n.startswith('_private.') for n in foreign)
sealed=[n for n,(mod,kind) in foreign.items() if kind=='def']
(p/(label+'-sealed.txt')).write_text('\n'.join(sorted(sealed))+'\n')
rows=['| Declaration | Module | Kind |','|---|---|---|']
for n,(mod,kind) in sorted(items.items()):rows.append(f'| `{n}` | `{mod}` | {kind} |')
(p/(label+'.md')).write_text('# Outside citations from elaborated proof terms\n\n'+'\n'.join(rows)+'\n')
probe=Path('FillProbes')/label/'HImportProbe2.lean'
s=probe.read_text()
checked=set(re.findall(r'^#check @?(\S+)',s,re.M))
extra=sorted(set(foreign)-checked)
s+='\n-- Additional outside constants appearing in the elaborated consumer.\n'
for n in extra:s+='#check @'+n+'\n#print axioms '+n+'\n'
probe.write_text(s)
(p/(label+'-extra-probe.txt')).write_text('\n'.join(extra)+'\n')
print(json.dumps({'outside_constants':len(items),'TCSlib_constants':len(foreign),'sealed_additions':sealed,'extended_probe':extra},ensure_ascii=False))
