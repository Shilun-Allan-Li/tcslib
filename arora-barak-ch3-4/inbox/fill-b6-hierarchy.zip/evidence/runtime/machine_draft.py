from pathlib import Path
parts=['sph_leaves','sph_validation','sph_radius','sph_input_rewind','sph_rewinds','sph_initial_record']
s='import TCSlib.Complexity.SpaceComplexity.Hierarchy\nset_option maxHeartbeats 0\nset_option autoImplicit false\nnamespace Complexity\nopen Turing\n\n'
for n in parts:s+=Path('evidence/drafts/'+n+'.lean.txt').read_text()+'\n\n'
s+='end Complexity\n'
Path('FillProbes/MachineDraft.lean').write_text(s)
