export PATH=/workspace/scratch/d2941d02d296/runtime-toolchain/lean-4.25.0-linux/bin:$PATH
export TMPDIR=/workspace/scratch/d2941d02d296/runtime-tmp
export XDG_CACHE_HOME=/workspace/scratch/d2941d02d296/runtime-cache
export TCSLIB_OLEANS=/workspace/scratch/d2941d02d296/tcslib/.lake/tcslib-check-oleans
