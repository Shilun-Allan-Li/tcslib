from pathlib import Path
import re,sys
label=sys.argv[1]
s=Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean').read_text()
a=s.index('/-- The inclusion half'); b=len(s)
rows=[]
pat=re.compile(r'\b(rw|rwa|simp|simpa|simp_rw|simp_all|dsimp|unfold|show|change)\b')
for m in pat.finditer(s,a,b):
 line=s.count('\n',0,m.start())+1
 end=s.find('\n',m.start()); end=len(s) if end<0 else end
 site=s[m.start():end]
 if m[1] in ['show','change']:
  line_start=s.rfind('\n',0,m.start())+1
  indent=len(s[line_start:])-len(s[line_start:].lstrip(' '))
  pos=end+1
  while pos<len(s):
   next_end=s.find('\n',pos);next_end=len(s) if next_end<0 else next_end
   following=s[pos:next_end]
   next_indent=len(following)-len(following.lstrip(' '))
   if not following.strip() or next_indent<=indent:break
   end=next_end;pos=end+1
  site=s[m.start():end]
 # Expand each bracket list, retaining all explicit arguments across lines.
 left=s.find('[',m.end(),end) if m[1] not in ['show','change'] else -1
 if left>=0:
  depth=0; pos=left
  while pos<len(s):
   if s[pos]=='[':depth+=1
   elif s[pos]==']':
    depth-=1
    if depth==0:break
   pos+=1
  site=s[m.start():pos+1]
 site=' '.join(site.split()).replace('|','&#124;')
 if m[1] in ['show','change']:
  verdict='Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked.'
 elif m[1]=='dsimp':
  verdict='Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument.'
 elif 'sph' in site:
  verdict='Own definition(s) plus local equalities and published equation lemmas.'
 elif left>=0:
  verdict='Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument.'
 else:
  verdict='No explicit definition argument; theorem simplification checked under the full seal.'
 rows.append(f'| {line} | `{site}` | {verdict} |')
(Path('evidence/inspection')/(label+'.md')).write_text('# Rewrite and reduction inspection\n\nEvery tactic occurrence in the owned proof region is listed; multiline bracket arguments are expanded. Other-file TCSlib definitions are never explicit reduction arguments. Local lets and this file\'s definitions may reduce. Core/Mathlib definitions are not passed to rewriting or unfolding. The accompanying full seal checks residual definitional closure.\n\n| Line | Tactic and arguments | Inspection |\n|---|---|---|\n'+'\n'.join(rows)+'\n')
print('Inspection sites:',len(rows))
