import datetime,json,os,pathlib,subprocess,sys,time
root=pathlib.Path.cwd()
label=sys.argv[1]
mods=pathlib.Path(sys.argv[2]).read_text().splitlines() if len(sys.argv)==3 and pathlib.Path(sys.argv[2]).is_file() else sys.argv[2:]
logdir=root/'evidence'/'logs'/label
logdir.mkdir(parents=True,exist_ok=True)
summary=logdir/'summary.jsonl'
for i,mod in enumerate(mods):
 if not mod.strip():continue
 path=logdir/(f'{i+1:03d}-'+mod.replace('/','_')+'.log')
 started=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
 with path.open('w') as out:
  out.write(f'START {started}\nMODULE {mod}\nCOMMAND bash scripts/lean_check_tree.sh {mod}\n');out.flush()
  p=subprocess.Popen(['bash','scripts/lean_check_tree.sh',mod],stdout=out,stderr=subprocess.STDOUT)
  pid,status,usage=os.wait4(p.pid,0)
  p.returncode=os.waitstatus_to_exitcode(status)
  ended=datetime.datetime.now(datetime.timezone.utc).isoformat()
  row={'module':mod,'start':started,'end':ended,'seconds':round(time.monotonic()-t,3),'max_rss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'exit':p.returncode}
  out.write('\nRESOURCE '+json.dumps(row)+'\n')
 with summary.open('a') as out:out.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 if p.returncode:sys.exit(p.returncode if p.returncode>0 else 1)
