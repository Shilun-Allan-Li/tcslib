from pathlib import Path
import json,re
p=Path('evidence/reports/cp8.md');s=p.read_text()
s=s.replace('# B6 hierarchy fill — checkpoint 8','# B6 hierarchy fill — final report')
a=s.index('**Delivery with named escalation E-PAD.**');b=s.index('## Identity',a)
s=s[:a]+'''**Outcome:** `Complexity.space_hierarchy` and `Complexity.LOGSPACE_ssubset_PSPACE` are
proved on `[propext, Classical.choice, Quot.sound]`, with no `sorryAx`. All 43 new private
declarations are also admission-free. Checkpoint 8, reached last, proves the padding implication
and ends in the specifically permitted escalation **E-PAD**: the exact padded-language
linear-space decider. `SPACE_linear_ne_NP` keeps its original `sorry` and literal “Proof sketch”.
F6 is byte-preserved. No new admission, push or PR.

FINAL_VERIFICATION_SUMMARY

'''+s[b:]
s=s.replace('- Checkpoint commit:', '- Final commit:')
s=s.replace('## Checkpoints and declarations','## Checkpoints and declarations')
s=s.replace('This checkpoint proves the actual\nexistence', 'The construction proves the actual\nexistence')
s=s.replace('No hierarchy API or mathematical obstruction has been established.','No hierarchy API or mathematical obstruction remains.')
s=s.replace('Compiler-generated projections\nand recursor abbreviations are not implementation definitions.', '''Reducible abbreviations are excluded by the pinned `policy.md:72–79` and
`campaign/standards/TEMPLATE.md:43–49`: they are notation and Lean's default reducibility
validation rejects sealing them. In particular, `Cfg.Halted` is read as its state equation in
the two first-halt consumers, exactly the policy's explicit example; it is never an argument to
`simp`, `rw` or `unfold`. Generated structure projections and recursors are also recorded as
abbreviations. No unsafe reducibility override is used. The exact policy excerpt is shipped.''')
s=s.replace('The final\nhead still needs its screen and 52-module sweep; those attestations remain pending.', 'FINAL_SCREEN_RESULT')
s=s.replace('Proposed implementation paragraphs for the maintainer, **for the completed proofs rather than\nas claims about this checkpoint**:', 'Proposed implementation paragraphs for the maintainer (not inserted into the frozen target docstrings):')
s=s.replace('The supplied base sorry inventory is included verbatim in `evidence/logs/base-sorries.txt`;\nall out-of-scope admissions remain untouched. Resume from the checkpoint commit and the\ncommitted source, not from the unchecked drafts.', '''The supplied base sorry inventory is included verbatim in `evidence/logs/base-sorries.txt`.
Only the two completed target warnings disappear: the 220-module closure has 24 remaining
admissions versus 26 at baseline, all unchanged except those removals. The final tail has only
the two expected Hierarchy warnings. Use the committed source and patches, not unchecked drafts.''')
# Record the explicit per-private semantic search accounting required by the brief.
lemmas=re.findall(r'^private lemma (\w+)',Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean').read_text(),re.M)
cp2={'sph_right_run','sph_emit_run','sph_fold_valid','sph_validation_run','sph_witness_cap','sph_radius_run','sph_input_rewind_run','sph_rewinds_run','sph_initial_record'}
cp3={'sph_select_fields','sph_runner_run','sph_test_run','sph_verdict_run','sph_summary','sph_seam_heads','sph_seam_avoids','sph_written_record','sph_runner_tail_run','sph_suffix'}
cp4={'sph_record_suffix','sph_record_size','sph_valid_machine','sph_halt_contract','sph_validated_machine','sph_diagonal_language'}
rows=[]
for n in lemmas:
 search='`semantic-'+n+'.log`'
 if n in ['sph_inclusion','sph_sq_le_two_pow','sph_logSpace_dom']:
  search='`semantic-search-initial.log`';probe='`baseline-dup`: exact? found no replacement';result='Required renamed route-probe copy; public supporting lemmas cited'
 elif n=='sph_logspace_ssubset':
  search='`semantic-search-initial.log`';probe='`cp7-dup`: finds the admitted public target, unusable as an external proved replacement';result='Required renamed route-probe copy, with explicit hierarchy hypothesis'
 elif n=='sph_code_window':probe='`cp5-dup`: exact? found no replacement';result='Consumer of normalization, coding, universal and window hosts'
 elif n in cp2:probe='`cp2-dup`: exact? found no replacement';result='Distinct framed consumer of the named host, or permitted leaf'
 elif n in cp3:probe='`cp3-semantic-bounded`: apply? found no complete replacement';result='Public-host composition/reading; partial generic candidates and two search-budget errors retained'
 elif n in cp4:probe='`cp4-seal-final`: exact? found no replacement';result='Public-host composition/space packaging; no search-budget error'
 else:
  assert n=='sph_linear_ne_NP_of_padding';probe='`cp8-semantic-final`: exact? found no replacement';result='Conditional consequence of the exact missing padding interface'
 rows.append('| `'+n+'` | '+search+' | '+probe+' | '+result+' |')
assert len(rows)==31
section='''## Per-private semantic duplication ledger

Each search covers the exact base and the four observed open PR heads listed above, by name
and statement family. Paths in this table are under `evidence/logs/`; diagnostic probe sources
are under `evidence/probes/`. Expected failed-search errors are not source-check failures.
The twelve remaining private declarations are definitions of permitted leaves, bank selections
or compositions of named hosts; their roles are listed in the complete declaration table.

| Private lemma | Name/statement search | Search tactic and result | Disposition |
|---|---|---|---|
'''+ '\n'.join(rows)+'\n\n'
a=s.index('## Escalation E-PAD');s=s[:a]+section+s[a:]
# Explicit checkpoint identity table and ZIP reconstruction results.
data=json.loads(Path('evidence/logs/delivery-integrity.json').read_text())
section='''## Delivery integrity

All eight checkpoint archives pass every entry of their `SHA256SUMS` manifests and ZIP CRC
validation; each source matches its recorded commit. The eight format-patches were applied,
in order, to an isolated Git index at the pinned base. The reconstructed tree exactly equals
`'''+data['replay_tree']+'''`, the final commit's tree. This did not change any branch.
The bundle has only the pinned base as a prerequisite; its verification log is included.
The tracked working tree is clean and the only tracked change against base is Hierarchy.

| Checkpoint | Commit | ZIP SHA-256 |
|---|---|---|
'''
for r in data['checkpoints']:section+='| '+r['checkpoint']+' | `'+r['commit']+'` | `'+r['zip_sha256']+'` |\n'
s+='\n'+section
Path('evidence/reports/final.md').write_text(s)
print('Final report draft',len(s.splitlines()),'lines; private-lemma rows',len(rows))
