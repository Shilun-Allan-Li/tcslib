from pathlib import Path
import re,sys
label=sys.argv[1]
source=Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean').read_text()
dest=Path('FillProbes')/label;dest.mkdir(parents=True,exist_ok=True)
names=re.findall(r'^private\s+(?:noncomputable\s+)?(?:lemma|theorem|def|abbrev|structure|inductive|instance)\s+(\w+)',source,re.M)
sealed=['Complexity.SpaceConstructible','Complexity.SPACE','Complexity.logSpace','Complexity.LOGSPACE','Complexity.PSPACE']
extra=Path('evidence/citations')/(label+'-sealed.txt')
if extra.exists(): sealed=list(dict.fromkeys(sealed+extra.read_text().splitlines()))
attrs='attribute [-simp] Turing.Action.apply Turing.Cfg.init Turing.MultiTapeTM.initCfg Turing.NDTM.initCfg\nattribute [local irreducible]\n  '+'\n  '.join(sealed)+'\n\n'
first=source.index('/-- The inclusion half') if '/-- The inclusion half' in source else source.index('private ')
(dest/'Seal.lean').write_text(source[:first]+attrs+source[first:])
prints='\n'.join('#print axioms Complexity.'+n for n in names+['space_hierarchy','LOGSPACE_ssubset_PSPACE','SPACE_linear_ne_NP'])+'\n'
(dest/'Axioms.lean').write_text(source+'\n'+prints)
inputs=Path('campaign/fills/b6/inputs/b6-fill-hierarchy')
for n in ['HImportProbe2','HSealControl_unsealed','HSealControl_sealed','HDupProbe']:
 text=(inputs/(n+'.lean.txt')).read_text()
 if n.startswith('HSealControl_') and extra.exists():
  if n.endswith('_sealed'):
   at=text.index('#ctl_rfl Complexity.SpaceConstructible')
   text=text[:at]+'attribute [local irreducible]\n  '+'\n  '.join(sealed[5:])+'\n\n'+text[at:]
  cards=['Turing.instFintypeInputRewindPhase','Turing.instFintypeRewindPhase']
  calls='\n'.join('#ctl_rfl '+d for d in sealed[5:] if d not in ['Turing.windowRun','Turing.NDTM.runWith']+cards)+'\n'
  for d in cards:
   if d in sealed: calls+='#ctl_card '+d+'\n'
  for recursive in ['Turing.windowRun','Turing.NDTM.runWith']:
   if recursive in sealed: calls+='#ctl_eqn '+recursive+'\n'
  text=text.replace('end Controls',calls+'\nend Controls')
  text=text.replace('section Controls', '''open Lean Elab Command Meta in
elab "#ctl_card " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ci ← getConstInfo n
  let ok ← liftTermElabM do
    try
      Term.withoutErrToSorry do
        let ty := ci.type.getAppArgs[0]!
        let c := mkConst n
        let lhs := mkApp2 (mkConst ``Fintype.card [Level.zero]) ty c
        let goal ← mkEq lhs (mkNatLit 3)
        let proof ← Term.elabTermEnsuringType (← `(by rfl)) goal
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} card {n}"

section Controls''')
 (dest/(n+'.lean')).write_text(text)
(dest/'Walk.lean').write_text('''import TCSlib.Complexity.SpaceComplexity.Hierarchy
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for (n, ci) in env.constants.toList do
    if (n.toString.startsWith "_private.TCSlib.Complexity.SpaceComplexity.Hierarchy." &&
        (decide ((n.toString.splitOn ".sph").length > 1 ||
          (n.toString.splitOn ".Sph").length > 1))) ||
        ["Complexity.space_hierarchy", "Complexity.LOGSPACE_ssubset_PSPACE",
          "Complexity.SPACE_linear_ne_NP"].any (fun t =>
            n.toString == t || n.toString.startsWith (t ++ ".")) then
      logInfo m!"LOCAL_DECL {n}"
      for c in ci.getUsedConstantsAsSet.toArray do
        let modName := match env.getModuleIdxFor? c with
          | some idx => env.header.moduleNames[idx.toNat]!
          | none => env.mainModule
        let kind := match env.find? c with
          | some (.defnInfo d) => match d.hints with
            | .abbrev => "abbrev"
            | _ => "def"
          | some (.thmInfo _) => "theorem"
          | _ => "other"
        logInfo m!"CITE {n} | {c} | {modName} | {kind}"
''')
print('Prepared',dest,'private declarations:',names)
