from pathlib import Path
import hashlib,json,os,re,subprocess,zipfile
root=Path.cwd();base='e6bc196838b4e2675e4214306c730e7404624ab8'
def git(*args,env=None):return subprocess.check_output(['git',*args],text=True,env=env).strip()
rows=[]
for label in ['cp1','cp5','cp7','cp2','cp3','cp4','cp6','cp8']:
 p=root.parent/('fill-b6-hierarchy-'+label+'.zip')
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS').decode().splitlines():
   expected,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==expected,(label,name)
  commit=z.read('COMMIT').decode().strip()
  src='TCSlib/Complexity/SpaceComplexity/Hierarchy.lean'
  assert z.read(src)==subprocess.check_output(['git','show',commit+':'+src])
  assert git('diff','--name-only',base,commit)==src
  assert git('rev-list','--count',base+'..'+commit)==str(len(rows)+1)
  assert 'CHECKPOINT_COMMIT' not in z.read('REPORT.md').decode()
 rows.append({'checkpoint':label,'commit':commit,'zip_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
# Replay the eight textual patches against an isolated Git index, without changing a branch.
index=root.parent/'evidence/runtime/patch-replay.index'
if index.exists(): index.unlink()
env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
git('read-tree',base,env=env)
patches=sorted((root.parent/'deliverables/fill-b6-hierarchy-cp8/patches').glob('*.patch'))
assert len(patches)==8
for p in patches:
 subprocess.run(['git','apply','--cached','--check',str(p)],check=True,env=env)
 subprocess.run(['git','apply','--cached',str(p)],check=True,env=env)
assert git('write-tree',env=env)==git('rev-parse','HEAD^{tree}')
index.unlink()
result={'checkpoints':rows,'patches_replayed':8,'replay_tree':git('rev-parse','HEAD^{tree}'),'tracked_changed_files':git('diff','--name-only',base,'HEAD').splitlines(),'working_tree_tracked_clean':not git('diff','--name-only') and not git('diff','--cached','--name-only')}
(root/'evidence/logs/delivery-integrity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
