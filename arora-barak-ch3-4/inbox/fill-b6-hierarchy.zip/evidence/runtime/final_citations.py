from pathlib import Path
import json
items=json.loads(Path('evidence/citations/final_v2.json').read_text())
for n in ['Turing.FinTM.toFinNDTM_k','Turing.FinTM.toFinNDTM_State']:
 items[n]=['TCSlib.Complexity.TuringMachine.Nondeterministic','theorem']
logs=sorted(Path('evidence/logs').glob('final-source-citations*/**/*SourceCitations.log'),key=lambda p:p.stat().st_mtime)
assert logs
logs=[logs[-1]]
assert 'error:' not in logs[0].read_text() and 'FAIL(' not in logs[0].read_text()
source={}
for line in logs[0].read_text().splitlines():
 if not line.startswith('SOURCE_CITE '):continue
 _,name,mod,kind=line.split(' | ')
 if mod=='TCSlib.Complexity.SpaceComplexity.Hierarchy':continue
 source[name]=[mod,kind]
items.update(source)
assert not any(n.startswith('_private.') and m.startswith('TCSlib.') for n,(m,k) in items.items())
Path('evidence/citations/final.json').write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n')
rows=['# Final outside-citation inventory','','Union of the elaborated private/public proof walk and source identifier resolution. Explicit unused simp arguments are included. The two bundled ND field readings are in `TuringMachine/Nondeterministic`; this corrects their manually entered module labels in the checkpoint inventory.','','| Declaration | Module | Kind | Explicit source token |','|---|---|---|---|']
for n,(m,k) in sorted(items.items()):rows.append(f'| `{n}` | `{m}` | {k} | {"yes" if n in source else "no"} |')
Path('evidence/citations/final.md').write_text('\n'.join(rows)+'\n')
foreign={n:v for n,v in items.items() if v[0].startswith('TCSlib.')}
sealed={n for n,v in foreign.items() if v[1]=='def'}
oldsealed=set(Path('evidence/citations/final_v2-sealed.txt').read_text().splitlines())
print('Added definitions to seal:',sorted(sealed-oldsealed))
assert sealed<=oldsealed,'Additional source-only definitions must be sealed before completion'
# An independent copy of the extended probe covers any additional TCSlib source citations.
probe=Path('FillProbes/final_v2/HImportProbe2.lean').read_text();import re
checked=set(re.findall(r'^#check @?(\S+)',probe,re.M));extra=sorted(set(foreign)-checked)
for n in extra:probe+='\n#check @'+n+'\n#print axioms '+n+'\n'
Path('FillProbes/FinalImportProbe.lean').write_text(probe)
result={'outside_constants':len(items),'source_resolved':len(source),'TCSlib_constants':len(foreign),'sealed_definitions':len(oldsealed),'additional_TCSlib_probe_names':extra,'probe_checks':len(re.findall(r'^#check',probe,re.M))}
Path('evidence/logs/final-citation-accounting.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
