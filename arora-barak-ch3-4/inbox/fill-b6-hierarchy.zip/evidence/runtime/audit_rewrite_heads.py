from pathlib import Path
import json,re
src=Path('TCSlib/Complexity/SpaceComplexity/Hierarchy.lean').read_text()
a=src.index('/-- The inclusion half')
resolved={}
for line in Path('evidence/logs/final-source-citations-v2/001-FillProbes_SourceCitations.log').read_text().splitlines():
 if line.startswith('SOURCE_CITE '):
  token,name,mod,kind=line.removeprefix('SOURCE_CITE ').split(' | ')
  resolved[token]=(name,mod,kind)
rows=[]
for m in re.finditer(r'\b(rw|rwa|simp|simpa|simp_rw|simp_all|dsimp|unfold)\b',src[a:]):
 pos=a+m.start();line=src.count('\n',0,pos)+1
 end=src.find('\n',pos);left=src.find('[',pos,end)
 if left<0:continue
 stack=[];start=left+1
 for i in range(left+1,len(src)):
  c=src[i]
  if c in '([{⟨':stack.append(c)
  elif c==']' and not stack:
   parts=[src[start:i]];done=True
  elif c in ')]}⟩':
   if stack:stack.pop()
   continue
  elif c==',' and not stack:parts=[src[start:i]];done=False;start=i+1
  else:continue
  for part in parts:
   cleaned=part.strip().lstrip('←').lstrip().lstrip('(').strip()
   hm=re.match(r"[\w][\w.']*",cleaned)
   if not hm:continue
   h=hm.group();r=resolved.get(h)
   rows.append({'line':line,'tactic':m[1],'head':h,'resolution':r})
  if done:break
bad=[r for r in rows if r['resolution'] and r['resolution'][2] in ('def','abbrev') and not r['resolution'][1].endswith('.Hierarchy')]
assert not bad,bad
result={'sites_with_bracket_arguments':len(set((r['line'],r['tactic']) for r in rows)),
 'explicit_argument_heads':len(rows),'distinct_resolved_public_heads':len({r['resolution'][0] for r in rows if r['resolution']}),
 'foreign_definition_heads':bad,'rows':rows}
Path('evidence/logs/final-rewrite-heads.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print({k:v for k,v in result.items() if k!='rows'})
p=Path('evidence/reports/final.md');s=p.read_text().replace('all 442\nrewriting/reduction tactic sites','all 443\nrewriting/reduction tactic sites').replace('The inspection has 442 sites.','The inspection has 443 sites, including the `simp_all` site.');s=s.replace('bodies. Own lets/leaves and public equations are the only explicit reduction arguments.',
'bodies. The final extraction also includes `simp_all` and complete multiline `change` targets,\nwhich were not fully displayed by the earlier 442-site checkpoint table. The accompanying\n`final-rewrite-heads.json` checks explicit bracket heads against Lean-resolved declaration\nkinds; no foreign definition or abbreviation is supplied as a reduction rule. Own lets/leaves\nand public equations are the only explicit reduction arguments.')
p.write_text(s)
