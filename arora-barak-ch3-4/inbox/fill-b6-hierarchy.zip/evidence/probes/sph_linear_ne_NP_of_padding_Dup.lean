import TCSlib.Complexity.SpaceComplexity.Hierarchy
open Turing Complexity

example
    (hH : ∀ f g : ℕ → ℕ, SpaceConstructible f → SpaceConstructible g →
      (∀ A : ℕ, ∃ N, ∀ n ≥ N, A * f n ≤ g n) → SPACE f ⊂ SPACE g)
    (hpad : ∀ L : Language Bool, L ∈ SPACE (fun n => n ^ 2 + 1) →
      ({y | ∃ x ∈ L,
        y = pairEncode x (List.replicate (1 * (x.length + 1) ^ 2) true)} : Language Bool) ∈
        SPACE (fun n => n + 1)) :
    SPACE (fun n => n + 1) ≠ NP := by exact?
