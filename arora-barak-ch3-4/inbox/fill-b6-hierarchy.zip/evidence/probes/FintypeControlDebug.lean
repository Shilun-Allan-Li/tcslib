import TCSlib.Complexity.SpaceComplexity.Hierarchy
#print Turing.instFintypeInputRewindPhase
#print Turing.instFintypeRewindPhase
#print Turing.instFintypeScanPhase
set_option pp.all true in
#print Turing.instFintypeInputRewindPhase
example : @Fintype.card Turing.InputRewindPhase Turing.instFintypeInputRewindPhase = 3 := by rfl
attribute [local irreducible] Turing.instFintypeInputRewindPhase
example : @Fintype.card Turing.InputRewindPhase Turing.instFintypeInputRewindPhase = 3 := by rfl
