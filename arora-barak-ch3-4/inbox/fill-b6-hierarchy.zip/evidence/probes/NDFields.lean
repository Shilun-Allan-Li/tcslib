import TCSlib.Complexity.SpaceComplexity.Hierarchy
#print Turing.FinTM.toFinNDTM_tm
#print Turing.MultiTapeTM.toNDTM_q₀
#print Turing.MultiTapeTM.toNDTM_tr
#print Turing.FinTM.toFinNDTM_k
#print Turing.FinTM.toFinNDTM_State
#print Turing.MultiTapeTM.toNDTM_initCfg
#print Turing.MultiTapeTM.toNDTM_runWith
