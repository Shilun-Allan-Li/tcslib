import TCSlib.Complexity.SpaceComplexity.Hierarchy
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for (n, ci) in env.constants.toList do
    if (n.toString.startsWith "_private.TCSlib.Complexity.SpaceComplexity.Hierarchy." &&
        (decide ((n.toString.splitOn ".sph").length > 1 ||
          (n.toString.splitOn ".Sph").length > 1))) ||
        ["Complexity.space_hierarchy", "Complexity.LOGSPACE_ssubset_PSPACE",
          "Complexity.SPACE_linear_ne_NP"].any (fun t =>
            n.toString == t || n.toString.startsWith (t ++ ".")) then
      logInfo m!"LOCAL_DECL {n}"
      for c in ci.getUsedConstantsAsSet.toArray do
        let modName := match env.getModuleIdxFor? c with
          | some idx => env.header.moduleNames[idx.toNat]!
          | none => env.mainModule
        let kind := match env.find? c with
          | some (.defnInfo d) => match d.hints with
            | .abbrev => "abbrev"
            | _ => "def"
          | some (.thmInfo _) => "theorem"
          | _ => "other"
        logInfo m!"CITE {n} | {c} | {modName} | {kind}"
