import TCSlib.Complexity.SpaceComplexity.Hierarchy
open Turing Complexity

example (f g : ℕ → ℕ) (hf : SpaceConstructible f)
    (hfg : ∀ A : ℕ, ∃ N, ∀ n ≥ N, A * f n ≤ g n) (U₀ : FinTM Bool)
    (hU : ∀ α : List Bool, ∃ C : ℕ, 0 < C ∧
      ∀ (w output : List Bool) (t s : ℕ),
        (TimeHierarchy.code.decode α).toFinTM.ComputesInTime (pairEncode α w) output t →
        (TimeHierarchy.code.decode α).toFinTM.tm.spaceUsed
          ((TimeHierarchy.code.decode α).toFinTM.tm.initCfg (pairEncode α w)) t ≤ s →
        ∃ t' : ℕ, U₀.ComputesInTime (pairEncode α w) output t' ∧
          U₀.tm.spaceUsed (U₀.tm.initCfg (pairEncode α w)) t' ≤ C * (s + 1))
    (L : Language Bool) (c₀ : ℕ) (M : FinTM Bool)
    (hM : M.DecidesInSpace L (fun n => c₀ * f n)) :
    ∃ (x : List Bool) (t : ℕ),
      U₀.ComputesInTime x [MultiTapeTM.indicator (L : Set (List Bool)) x] t ∧
      U₀.tm.spaceUsed (U₀.tm.initCfg x) t ≤ g x.length ∧
      t = U₀.configBound x.length (g x.length) ∧
      windowRun U₀.tm (g x.length) summaryTag (t + 1) (U₀.tm.initCfg x) 0 =
        (.halted, U₀.tm.runFrom (U₀.tm.initCfg x) t,
          outSummaryCode (outSummary [MultiTapeTM.indicator (L : Set (List Bool)) x])) := by exact?
