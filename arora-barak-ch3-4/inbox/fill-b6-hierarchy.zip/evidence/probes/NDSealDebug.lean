import TCSlib.Complexity.SpaceComplexity.Hierarchy
open Turing
attribute [local irreducible] FinTM.toFinNDTM MultiTapeTM.toNDTM NDTM.runWith NDTM.initCfg
set_option pp.explicit true
example (E : FinTM Bool) (x w : List Bool) :
    (E.toFinNDTM.tm.runWith w (E.toFinNDTM.tm.initCfg x)).output =
      (E.tm.runFrom (E.tm.initCfg x) w.length).output := by
  simp only [FinTM.toFinNDTM_k, FinTM.toFinNDTM_State, FinTM.toFinNDTM_tm,
    MultiTapeTM.toNDTM_initCfg, MultiTapeTM.toNDTM_runWith]
