import TCSlib.Complexity.SpaceComplexity.Hierarchy
open Complexity Turing
example
    (hH : ∀ f g : ℕ → ℕ, SpaceConstructible f → SpaceConstructible g →
      (∀ A : ℕ, ∃ N, ∀ n ≥ N, A * f n ≤ g n) → SPACE f ⊂ SPACE g) :
    LOGSPACE ⊂ PSPACE := by exact?
