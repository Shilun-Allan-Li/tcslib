/-
Seal controls for H's route probe (`HRouteProbe.lean`), with the generic control commands of E-Q
cont1's review: for each of the 5 sealed definitions a delta goal (`#ctl_rfl`), and for the four
erased `@[simp]` definitions a pointwise unfolding goal by `intros; simp` (`#ctl_simp`). Each logs
`CONTROL_PASS` or `CONTROL_FAIL`. Expected: unsealed, every control passes; sealed, every control
fails. A probe record, not library code.
-/
import TCSlib.Complexity.SpaceComplexity.Hierarchy

open Lean Elab Command Meta in
elab "#ctl_rfl " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ci ← getConstInfo n
  let some value := ci.value? | throwError "not a definition: {n}"
  let ok ← liftTermElabM do
    try
      Term.withoutErrToSorry do
        let goal ← mkEq (mkConst n (ci.levelParams.map Level.param)) value
        let proof ← Term.elabTermEnsuringType (← `(by rfl)) goal
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} rfl {n}"

open Lean Elab Command Meta in
elab "#ctl_eqn " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ok ← liftTermElabM do
    try
      let some eqs ← getEqnsFor? n | return false
      let ty := (← getConstInfo eqs[0]!).type
      let ty ← instantiateForall ty #[]
      Term.withoutErrToSorry do
        let proof ← Term.elabTermEnsuringType (← `(by intros; rfl)) ty
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} eqn {n}"

open Lean Elab Command Meta in
elab "#ctl_simp " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ci ← getConstInfo n
  let some value := ci.value? | throwError "not a definition: {n}"
  let ok ← liftTermElabM do
    try
      Term.withoutErrToSorry do
        let c := mkConst n (ci.levelParams.map Level.param)
        let goal ← forallTelescopeReducing ci.type fun xs _ => do
          mkForallFVars xs (← mkEq (mkAppN c xs) (mkAppN value xs).headBeta)
        let proof ← Term.elabTermEnsuringType (← `(by intros; simp)) goal
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} simp {n}"

section Controls

attribute [-simp] Turing.Action.apply Turing.Cfg.init Turing.MultiTapeTM.initCfg Turing.NDTM.initCfg
attribute [local irreducible]
  Complexity.SpaceConstructible
  Complexity.SPACE
  Complexity.logSpace
  Complexity.LOGSPACE
  Complexity.PSPACE

attribute [local irreducible]
  Turing.FinTM.ComputesInSpace

#ctl_rfl Complexity.SpaceConstructible
#ctl_rfl Complexity.SPACE
#ctl_rfl Complexity.logSpace
#ctl_rfl Complexity.LOGSPACE
#ctl_rfl Complexity.PSPACE
#ctl_simp Turing.Action.apply
#ctl_simp Turing.Cfg.init
#ctl_simp Turing.MultiTapeTM.initCfg
#ctl_simp Turing.NDTM.initCfg

#ctl_rfl Turing.FinTM.ComputesInSpace

end Controls
