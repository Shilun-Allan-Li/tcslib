# Rewrite and reduction inspection

Every tactic occurrence in the owned proof region is listed; multiline bracket arguments are expanded. Other-file TCSlib definitions are never explicit reduction arguments. Local lets and this file's definitions may reduce. Core/Mathlib definitions are not passed to rewriting or unfolding. The accompanying full seal checks residual definitional closure.

| Line | Tactic and arguments | Inspection |
|---|---|---|
| 169 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 174 | `simpa using this` | No explicit definition argument; theorem simplification checked under the full seal. |
| 220 | `simp only [x, length_pairEncode, List.length_replicate]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 225 | `rw [hα]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 230 | `rw [hα, hsp]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 235 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 241 | `dsimp only [A]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 260 | `rw [pow_succ]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 277 | `rw [logSpace_eq, ← hL]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 290 | `simpa only [pow_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 294 | `rw [← LOGSPACE_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 320 | `rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero, MultiTapeTM.step_of_some hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 323 | `rw [Action.apply_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 324 | `rw [Action.apply_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 326 | `rw [Action.apply_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 327 | `simp only [sphRightTM, Option.getD_none, Cfg.workTapeSymbols_eq, Function.update_eq_self]` | Own definition(s) plus local equalities and published equation lemmas. |
| 330 | `rw [Action.apply_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 331 | `simp only [sphRightTM, SignType.coe_zero, add_zero]` | Own definition(s) plus local equalities and published equation lemmas. |
| 332 | `rw [Action.apply_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 333 | `simp only [sphRightTM, Option.toList_none, List.append_nil]` | Own definition(s) plus local equalities and published equation lemmas. |
| 337 | `rw [hp, SignType.pos_eq_one, moveInputPos_rightBoundary]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 339 | `rw [moveInputPos_pos_of_ne_right _ h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 344 | `rw [MultiTapeTM.runFrom_zero, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 349 | `rw [MultiTapeTM.runFrom_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 350 | `rw [hstep]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 367 | `rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero, MultiTapeTM.step_of_some hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 370 | `rw [Action.apply_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 371 | `rw [Action.apply_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 374 | `rw [Action.apply_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 375 | `simp only [sphEmitTM, Option.getD_none, Cfg.workTapeSymbols_eq, Function.update_eq_self]` | Own definition(s) plus local equalities and published equation lemmas. |
| 378 | `rw [Action.apply_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 379 | `simp only [sphEmitTM, SignType.coe_zero, add_zero]` | Own definition(s) plus local equalities and published equation lemmas. |
| 380 | `rw [Action.apply_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 386 | `rw [MultiTapeTM.runFrom_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 387 | `rw [hstep]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 406 | `rw [List.foldl_nil]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 409 | `rw [List.foldl_cons, ih]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 417 | `rw [List.map_cons, RecSym.digitEmb_apply, ← hx]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 425 | `rw [List.map_cons]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 428 | `rw [hy, RecSym.digitEmb_apply]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 471 | `simp only [sphWitnessSel, Function.Embedding.coeFn_mk, Fin.val_one]` | Own definition(s) plus local equalities and published equation lemmas. |
| 509 | `dsimp only` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 524 | `rw [Cfg.liftSymbols_state, MultiTapeTM.initCfg_eq, Cfg.init_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 527 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_state, heq, hhalt]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 530 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 537 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 542 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 543 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 546 | `simpa only [List.nil_append, hout']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 547 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 550 | `simpa only [List.nil_append, hout', List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 552 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 556 | `rw [hpre u hu, Cfg.mapState_output, embedSilentCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 557 | `rw [hr, embedSilentCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 558 | `rw [MultiTapeTM.spaceUsed_eq_sum]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 564 | `rw [MultiTapeTM.spaceUsedByTape_eq_card, embedSilentRetTM_visitedByTapeHead, ← MultiTapeTM.spaceUsedByTape_eq_card]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 569 | `rw [(embedSilentTM_visitedByTapeHead ι 1 hcap _ tapes heads [] out a t i).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 582 | `rw [hout', List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 584 | `rw [(embedSilentTM_visitedByTapeHead_frame ι 1 hcap _ tapes heads [] out a t j hj hjc).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 588 | `rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 595 | `rw [hpre u hlt, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 596 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 597 | `rw [hpos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 600 | `rw [embedSilentCfg_selected_pos, MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 607 | `rw [(embedSilentCfg_cap ι 1 hcap tapes heads [] out _).2, MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_output, List.nil_append, List.length_map, abs_of_nonneg (by omega)]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 611 | `rw [ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 615 | `rw [(embedSilentCfg_unselected ι 1 tapes heads [] out _ j hj hjc).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 641 | `simpa only [List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 645 | `rw [Cfg.liftSymbols_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 650 | `rw [Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 652 | `rw [Cfg.liftSymbols_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 663 | `rw [hs, MultiTapeTM.liftSymbols_runFrom]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 666 | `rw [hrun, ← ha, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 668 | `rw [Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 669 | `rw [Cfg.liftSymbols_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 671 | `rw [Cfg.liftSymbols_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 676 | `rw [hrun, embedEmitCfg_state, Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 679 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 713 | `rw [seamCompTM_runFrom_left A exit B entry hc u h, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 716 | `rw [seamCompTM_runFrom_right A exit B entry hr he hc w, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 757 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 758 | `rw [Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 767 | `rw [Cfg.mapState_state, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 771 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 774 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 777 | `rw [List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 779 | `rw [hbt, hbh, hpos, sub_self, zero_add, hcap]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 791 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 792 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 794 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 797 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 798 | `dsimp only [d₃]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 799 | `rw [hbh, hpos, sub_self]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 800 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 804 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 806 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 811 | `rw [hh₁ u hu, sub_self, abs_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 816 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 817 | `rw [h, sub_self, abs_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 820 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 823 | `change &#124;((rewindTM k 1).runFrom b u).workTapePos j - d.workTapePos j&#124; ≤ ((ws.length + 1 : ℕ) : ℤ)` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 827 | `rw [if_pos hj, hbh, Finset.mem_Icc]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 829 | `rw [if_neg hj, hbh]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 830 | `rw [h, sub_self, abs_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 848 | `rwa [embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 850 | `rwa [embedEmitCfg_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 852 | `rwa [embedEmitCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 856 | `rwa [embedEmitCfg_selected_tape]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 860 | `rwa [embedEmitCfg_selected_pos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 916 | `rw [htapes, hheads, h1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 917 | `rw [htapes, hheads, h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 920 | `rw [htapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 926 | `rwa [hrecon]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 929 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 932 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 935 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 937 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 938 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 939 | `rw [hrun, hr, MultiTapeTM.initCfg_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 941 | `rw [embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 942 | `rw [embedEmitCfg_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 947 | `rw [embedEmitCfg_selected_tape]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 948 | `rw [← h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 949 | `simp only [a, hheads, htapes, hz]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 950 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 952 | `simp only [hj0, false_and, ite_false]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 956 | `rw [embedEmitCfg_selected_pos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 959 | `rw [embedEmitCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1021 | `dsimp only` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1025 | `simp only [ι, sphRunnerSel, Function.Embedding.coeFn_mk, Fin.val_zero, if_pos]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1032 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1034 | `rw [htapes, hheads, h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1039 | `rw [htapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1041 | `rw [hv i hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1044 | `rw [hv i hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1050 | `rwa [embedEmitCfg_select]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1052 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1055 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1058 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1061 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1063 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1064 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1066 | `rw [hrun, embedEmitCfg_output, hs u hu]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1071 | `rw [hrun, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1073 | `rw [embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1074 | `rw [embedEmitCfg_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1079 | `rw [embedEmitCfg_selected_tape]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1080 | `rw [← h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1081 | `simp only [a, hheads, htapes, h0, hz]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1082 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1084 | `simp only [hj0, false_and, ite_false]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1088 | `rw [embedEmitCfg_selected_pos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1091 | `rw [embedEmitCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1130 | `dsimp only` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1136 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1138 | `rw [htapes, hheads, h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1141 | `rw [joinFields_cfgRecord_length]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1145 | `rwa [embedEmitCfg_select]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1148 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1151 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1154 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1156 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1157 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1158 | `rw [hrun, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1160 | `simp only [decide_eq_true_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1182 | `rw [MultiTapeTM.runFrom_zero, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1186 | `rw [(sph_emit_run b d hd).2 u hu]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1238 | `simp only [Set.mem_insert_iff, Set.mem_singleton_iff, not_or]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1248 | `rw [Cfg.mapState_state, Cfg.mapState_state, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1251 | `rw [Contract.branch_pre]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1252 | `change (d₀.mapState fun _ => entry) = d` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 1254 | `rw [Cfg.mapState_state, hd₀, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1255 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1257 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1259 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1260 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1262 | `rw [Contract.branch_time]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1263 | `dsimp only [C₀, sphEmitContract]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1264 | `rw [ite_self]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1269 | `rw [ht]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1272 | `rw [(sph_emit_run (RecSym.digit true) _ (by rw [Cfg.mapState_state]; rfl)).1]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1273 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1274 | `rw [h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1276 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1277 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1279 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1281 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1282 | `rw [Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1285 | `rw [(sph_emit_run (RecSym.digit false) _ (by rw [Cfg.mapState_state]; rfl)).1]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1286 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1287 | `rw [h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1289 | `rw [Cfg.mapState_state, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1290 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1292 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1294 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1295 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1299 | `rw [Contract.branch_lo, Contract.branch_hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1300 | `dsimp only [C₀, sphEmitContract]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1301 | `simp only [Cfg.mapState_workTapePos, ite_self]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1302 | `dsimp only [d']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1303 | `rw [min_eq_left (by omega), max_eq_left (by omega), Finset.mem_Icc]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1304 | `dsimp only [d₀, sphVerdictTM]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1321 | `rw [hN]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1322 | `rw [h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1323 | `rw [heq, h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1342 | `rw [seamCompTM_runFrom_left A exit B entry hc u h, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1347 | `rw [hr, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1350 | `rw [seamCompTM_runFrom_right A exit B entry hr he hc w, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1352 | `rw [hq, Option.map_none]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1353 | `rw [hq, Option.map_some]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1373 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1375 | `rw [hL]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1376 | `change (if (0 : Fin (k + 1)) = 0 ∧ d.workTapePos 0 ≤ d.workTapePos 0 + p ∧ d.workTapePos 0 + p < d.workTapePos 0 + (L : ℤ) then fieldsTape fs (d.workTapePos 0 + p - d.workTapePos 0) else d.workTapes 0 (d.workTapePos 0 + p)) = fieldsTape fs p` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 1381 | `rw [if_pos ⟨rfl, by omega, by omega⟩]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1384 | `rw [if_neg (by rintro ⟨_, h₁, h₂⟩; exact h ⟨by omega, by omega⟩)]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1387 | `rw [fieldsTape_of_neg fs (by omega), ← sub_eq_add_neg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1389 | `rw [fieldsTape_of_length_le fs (by rw [hL])]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1389 | `rw [hL]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1448 | `rw [hAp t le_rfl, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1451 | `rw [hAp u hu.le, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1457 | `rw [hCp t le_rfl, hAr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1460 | `rw [hCp u hu.le, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1476 | `rw [hC, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1481 | `rw [seamCompTM_runFrom_left C (Sum.inl (Sum.inl (exit .exhausted))) E () (fun u _ => hCe u) u le_rfl, hC]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1488 | `rw [hW, hA, Cfg.mapState_state, Cfg.mapState_state, Cfg.mapState_state, hvs]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1490 | `rw [hW, hA, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, hvo, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1492 | `rw [hW, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1496 | `rw [Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1506 | `rw [Cfg.mapState_state, ha']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1512 | `rw [hAp u hu, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1517 | `rw [heh u hu, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1522 | `rw [hw, hC, Cfg.mapState_state, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1523 | `rw [hw, hC, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1526 | `rw [hw, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1530 | `rw [Cfg.mapState_state, Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1532 | `rw [Cfg.mapState_state, hc']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1538 | `rw [hCp u hu, Cfg.mapState_workTapePos, hAp u hu, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1543 | `rw [heh u hu, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1549 | `rw [hW, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1550 | `rw [hW, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1598 | `rw [Cfg.mapState_state, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1600 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1602 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1607 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1611 | `simp only [a, Cfg.mapState_state, hd, Option.map_some]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1613 | `simp only [a, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1615 | `simp only [a, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1617 | `simp only [a, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1618 | `simp only [a, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1620 | `rw [MultiTapeTM.initCfg_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1639 | `rw [hout]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1644 | `rw [fieldsTape_of_neg _ (by omega), ← sub_eq_add_neg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1648 | `rw [joinFields_cfgRecord_length]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1649 | `rw [fieldsTape_of_length_le _ (by rw [joinFields_cfgRecord_length])]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1649 | `rw [joinFields_cfgRecord_length]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1652 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1653 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1657 | `rw [Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1659 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1661 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1666 | `simpa only [b, decide_eq_true_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1669 | `simp only [z, Cfg.mapState_state, ha', Option.map_some]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1671 | `simp only [z, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1673 | `simp only [z, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1675 | `simp only [z, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1676 | `simp only [z, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1677 | `rw [hmaps]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1679 | `rw [hvr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1680 | `rw [hvr, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1685 | `dsimp only [b]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1690 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1691 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1692 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1693 | `rw [hzhead]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1698 | `rw [hstart]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1700 | `rw [Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1704 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1710 | `rw [hsummary]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1712 | `rw [hsummary]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1754 | `rw [Cfg.mapState_state, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1757 | `rw [Cfg.mapState_state, Cfg.mapState_state, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1758 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1759 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1760 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1761 | `rw [Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1765 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1768 | `rw [Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1771 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1775 | `rw [Fin.val_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1777 | `rw [Fin.val_zero, Fin.val_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1781 | `rw [Fin.val_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1783 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1783 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1785 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1785 | `rw [hr, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1786 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1786 | `rw [hr, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1790 | `rw [Fin.val_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1792 | `rw [Fin.val_zero, Fin.val_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1793 | `rw [Fin.val_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1795 | `rw [Fin.val_zero, Fin.val_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1796 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1797 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1799 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1802 | `rw [Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1804 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1806 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1810 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1811 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1812 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1813 | `rw [Fin.val_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1814 | `simpa only [hj0, false_and, ↓reduceIte]` | Public equalities plus Lean `reduceIte`, which constructs an `ite_cond_eq_false` proof; no definition is supplied for unfolding. |
| 1815 | `rw [Fin.val_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1819 | `rw [hstart]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1827 | `rw [hrun, Cfg.mapState_state, hvs, Option.map_none]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1828 | `rw [hrun, Cfg.mapState_output, hvo, Cfg.mapState_output, hao]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1834 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1839 | `rw [Cfg.mapState_workTapePos, hah]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1841 | `rw [hstart]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1853 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1856 | `rw [posWidth_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1862 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1864 | `rw [recordLength_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1865 | `simpa only [mul_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1915 | `rw [Cfg.mapState_state, Cfg.mapState_state, embedSilentCfg_state, Cfg.liftSymbols_state, MultiTapeTM.initCfg_eq, Cfg.init_state, Cfg.init_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1918 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, embedSilentCfg_inputPos, Cfg.liftSymbols_inputPos, MultiTapeTM.initCfg_eq, Cfg.init_inputPos, Cfg.init_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1921 | `change (1 : Fin (x.length + 2)).val = (1 : Fin ((x.map e).length + 2)).val` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 1922 | `rw [Fin.val_one, Fin.val_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1924 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.init_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1927 | `rw [embedSilentCfg_selected_tape, Cfg.liftSymbols_workTapes, MultiTapeTM.initCfg_eq, Cfg.init_workTapes, Option.map_none]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1931 | `rw [(embedSilentCfg_cap ι 1 hcap _ _ [] [] _).1, Cfg.liftSymbols_output, MultiTapeTM.initCfg_eq, Cfg.init_output, List.map_nil, List.nil_append, FinTM.bufferTape_nil]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1934 | `rw [(embedSilentCfg_unselected ι 1 _ _ [] [] _ j hj hjc).1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1936 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.init_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1939 | `rw [embedSilentCfg_selected_pos, Cfg.liftSymbols_workTapePos, MultiTapeTM.initCfg_eq, Cfg.init_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1943 | `rw [(embedSilentCfg_cap ι 1 hcap _ _ [] [] _).2, Cfg.liftSymbols_output, MultiTapeTM.initCfg_eq, Cfg.init_output, List.map_nil, List.nil_append, List.length_nil, Nat.cast_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1946 | `rw [(embedSilentCfg_unselected ι 1 _ _ [] [] _ j hj hjc).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1947 | `rw [Cfg.mapState_output, Cfg.mapState_output, embedSilentCfg_output, Cfg.init_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1953 | `rw [Cfg.mapState_state, hrs']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1955 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1956 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1958 | `dsimp only [d]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1959 | `rw [Cfg.mapState_mapState, Cfg.mapState_mapState]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1961 | `rw [hwi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1963 | `dsimp only [z]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1963 | `rw [hwr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1965 | `dsimp only [z]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1965 | `rw [hwr, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1967 | `dsimp only [z]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1967 | `rw [hwr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1970 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1971 | `rw [hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1973 | `dsimp only [z]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1973 | `rw [hwr, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1976 | `rw [Cfg.mapState_state, hze]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1979 | `rw [Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1979 | `dsimp only [z]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1979 | `rw [hwr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1982 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos, hzh, Function.update_self, zero_add, hzt, hrt]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1986 | `rw [Cfg.mapState_workTapes, hzt]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1990 | `simp only [ι, sphWitnessSel, Function.Embedding.coeFn_mk]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1994 | `rw [Cfg.mapState_mapState]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1999 | `rw [hai]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2002 | `rw [hstart]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2008 | `simpa only [abs_zero, zero_add]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2012 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2017 | `simpa only [sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2020 | `dsimp only [rW]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2023 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2027 | `simpa only [sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2030 | `dsimp only [radius]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2035 | `rw [sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2036 | `dsimp only [radius]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2037 | `rw [sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2038 | `rw [hai]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2043 | `rw [sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2044 | `dsimp only [radius, rW]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2045 | `rw [hstart]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2049 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2051 | `dsimp only [radius, rW, rR, rS, B]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2054 | `rw [hDr, Cfg.mapState_state, Cfg.mapState_state, hss, Option.map_none, Option.map_none]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2055 | `rw [hDr, Cfg.mapState_output, Cfg.mapState_output, hso, Cfg.mapState_output, hzo, List.nil_append]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2059 | `rw [sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2090 | `rw [Finset.mem_Icc]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2146 | `simp only [Set.mem_insert_iff, Set.mem_singleton_iff, a', or_true, true_or]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2156 | `rw [hheads j u hu, Cfg.init_workTapePos, Finset.mem_Icc]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2160 | `rw [Cfg.mapState_state, Cfg.init_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2161 | `rw [Cfg.mapState_inputPos, Cfg.init_inputPos, Cfg.init_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2162 | `rw [Cfg.mapState_workTapes, Cfg.init_workTapes, Cfg.init_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2163 | `rw [Cfg.mapState_workTapePos, Cfg.init_workTapePos, Cfg.init_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2164 | `rw [Cfg.mapState_output, Cfg.init_output, Cfg.init_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2177 | `simpa only [radius, List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2181 | `rw [hpost]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2182 | `rw [hpost]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2207 | `change C₁.pre () (a'.mapState fun _ => entry)` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 2208 | `rw [hstart₁]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2214 | `rw [Contract.branch_pre]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2215 | `change (d₀.mapState fun _ => ScanPhase.fwd true) = a` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 2217 | `rw [Cfg.mapState_state, Cfg.init_state, Cfg.init_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2218 | `rw [Cfg.mapState_inputPos, Cfg.init_inputPos, Cfg.init_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2219 | `rw [Cfg.mapState_workTapes, Cfg.init_workTapes, Cfg.init_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2220 | `rw [Cfg.mapState_workTapePos, Cfg.init_workTapePos, Cfg.init_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2221 | `rw [Cfg.mapState_output, Cfg.init_output, Cfg.init_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2225 | `rw [Contract.branch_lo, Contract.branch_hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2226 | `dsimp only [C₀, sphEmitContract]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2227 | `rw [(henv₁ _ j).1, (henv₁ _ j).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2228 | `simp only [a', a, Cfg.mapState_workTapePos, Cfg.init_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2230 | `simpa only [min_self, max_self, Finset.mem_Icc, ← abs_le]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2231 | `rw [min_eq_left (by omega), max_eq_left hrad, Finset.mem_Icc]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2238 | `rw [Contract.branch_post]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2239 | `dsimp only [C₀]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2242 | `rw [if_pos (by change some (ScanPhase.done b) = some (.done true); rw [hb]), hstart₁]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2242 | `change some (ScanPhase.done b) = some (.done true); rw [hb]), hstart₁] at hr'` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 2242 | `rw [hb]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2245 | `rw [hr', Cfg.mapState_state, Cfg.mapState_state, hs, Option.map_none, Option.map_none]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2246 | `rw [hr', Cfg.mapState_output, Cfg.mapState_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2247 | `rw [if_neg (by intro h; exact hb (ScanPhase.done.inj (Option.some.inj h)))]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2249 | `rw [hr', Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2251 | `rw [hr', Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2252 | `dsimp only [sphEmitContract]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 2253 | `rw [Cfg.mapState_output, Cfg.init_output, List.nil_append]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2258 | `rw [MultiTapeTM.initCfg_with_q₀, MultiTapeTM.runFrom_with_q₀]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2261 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2265 | `rw [hrun, MultiTapeTM.initCfg_with_q₀, Cfg.init_workTapePos, sub_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2305 | `rw [MultiTapeTM.initCfg_eq, Cfg.init_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2308 | `rw [hleaf]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2310 | `rw [MultiTapeTM.initCfg_eq, Cfg.init_output, List.nil_append]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2313 | `rw [FinNDTM.acceptsWithin_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2316 | `simp only [FinTM.toFinNDTM_k, FinTM.toFinNDTM_State, FinTM.toFinNDTM_tm, MultiTapeTM.toNDTM_initCfg, MultiTapeTM.toNDTM_runWith, hw]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2319 | `rw [hleaf, MultiTapeTM.initCfg_eq, Cfg.init_output, List.nil_append]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2323 | `simp only [FinTM.toFinNDTM_k, FinTM.toFinNDTM_State, FinTM.toFinNDTM_tm, MultiTapeTM.toNDTM_initCfg, MultiTapeTM.toNDTM_runWith, List.length_singleton, hleaf]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2326 | `simp only [FinTM.toFinNDTM_k, FinTM.toFinNDTM_State, FinTM.toFinNDTM_tm, MultiTapeTM.toNDTM_initCfg, MultiTapeTM.toNDTM_runWith, List.length_singleton]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2329 | `rw [hleaf, MultiTapeTM.initCfg_eq, Cfg.init_output, List.nil_append, hb]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2331 | `change bit = answer (x.map e)` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 2333 | `simp_all only [Bool.false_eq_true, iff_false, iff_true, not_true_eq_false]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2339 | `rw [hind, List.map_singleton, RecSym.digitEmb_apply]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2346 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2353 | `rw [hind]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2386 | `show ∃ y ∈ L, p x = p y from hx)` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 2388 | `simpa only [p, pairFstD_pairEncode]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2391 | `show ∃ y ∈ L, p x = p y from ⟨x, hx, rfl⟩)` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 2393 | `rw [hpull]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2513 | `rw [htime]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 2516 | `simp only [hb, List.cons.injEq, and_true, Bool.false_eq_true, Bool.true_eq_false, decide_false, decide_true, Bool.not_false, Bool.not_true]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
