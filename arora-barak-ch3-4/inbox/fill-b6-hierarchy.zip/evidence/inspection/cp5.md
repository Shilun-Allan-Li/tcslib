# Rewrite and reduction inspection

Every rewrite/reduction tactic in both added proofs is listed below; no `unfold`, `show` or `change` occurs.

| Line | Arguments | Disposition |
|---|---|---|
| 169 | `rw [logSpace_eq]` | Public equation theorem. |
| 174 | `simpa using this` | Standard simplification of multiplication by one; no explicit definition argument. |
| 220 | `simp only [x, length_pairEncode, List.length_replicate]` | `x` is this proof's local padded input; the other two are published equation lemmas. |
| 225 | `rw [hα]` | Local equality obtained from `MachineCode.decode_encode`. |
| 230 | `rw [hα, hsp]` | Local code equality and public coding theorem's exact space equality. |
| 235 | `rw [logSpace_eq]` | Public equation theorem; the floor comes from `spaceConstructible_iff`. |
| 241 | `dsimp only [A]` | This proof's own domination constant; followed by ring normalization. |

No core/Mathlib definition is explicitly passed to any rewrite or simplification tactic. All direct other-file TCSlib definitions in the elaborated proof terms are included in the expanded seal; reducible abbreviations and structure projections are identified separately in the citation walk.
