# Rewrite and reduction inspection — checkpoint 2

Each explicit tactic site in the owned proof region is listed with its complete bracketed argument list, including multiline lists. All nonlocal equation names were checked against the elaborated citation table. TCSlib operations are read only through public lemmas; the only definitions supplied explicitly are this file’s leaves/selection and local lets. The full 49-definition seal also passes.

| Line | Tactic and arguments | Inspection |
|---|---|---|
| 169 | `rw [logSpace_eq]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 174 | `simpa using this` | No explicit definition argument; local equality or default theorem simplification, checked under the full seal. |
| 220 | `simp only [x, length_pairEncode, List.length_replicate]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 225 | `rw [hα]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 230 | `rw [hα, hsp]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 235 | `rw [logSpace_eq]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 241 | `dsimp only [A]` | Own local let only (`A` or `d₃`). |
| 260 | `rw [pow_succ]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 277 | `rw [logSpace_eq, ← hL]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 290 | `simpa only [pow_one]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 294 | `rw [← LOGSPACE_eq]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 320 | `rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero, MultiTapeTM.step_of_some hd]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 323 | `rw [Action.apply_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 324 | `rw [Action.apply_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 326 | `rw [Action.apply_workTapes]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 327 | `simp only [sphRightTM, Option.getD_none, Cfg.workTapeSymbols_eq, Function.update_eq_self]` | Own leaf/selection definition; all remaining arguments are public equations. |
| 330 | `rw [Action.apply_workTapePos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 331 | `simp only [sphRightTM, SignType.coe_zero, add_zero]` | Own leaf/selection definition; all remaining arguments are public equations. |
| 332 | `rw [Action.apply_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 333 | `simp only [sphRightTM, Option.toList_none, List.append_nil]` | Own leaf/selection definition; all remaining arguments are public equations. |
| 337 | `rw [hp, SignType.pos_eq_one, moveInputPos_rightBoundary]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 339 | `rw [moveInputPos_pos_of_ne_right _ h]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 344 | `rw [MultiTapeTM.runFrom_zero, hd]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 349 | `rw [MultiTapeTM.runFrom_zero]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 350 | `rw [hstep]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 367 | `rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero, MultiTapeTM.step_of_some hd]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 370 | `rw [Action.apply_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 371 | `rw [Action.apply_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 374 | `rw [Action.apply_workTapes]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 375 | `simp only [sphEmitTM, Option.getD_none, Cfg.workTapeSymbols_eq, Function.update_eq_self]` | Own leaf/selection definition; all remaining arguments are public equations. |
| 378 | `rw [Action.apply_workTapePos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 379 | `simp only [sphEmitTM, SignType.coe_zero, add_zero]` | Own leaf/selection definition; all remaining arguments are public equations. |
| 380 | `rw [Action.apply_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 386 | `rw [MultiTapeTM.runFrom_zero]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 387 | `rw [hstep]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 406 | `rw [List.foldl_nil]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 409 | `rw [List.foldl_cons, ih]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 417 | `rw [List.map_cons, RecSym.digitEmb_apply, ← hx]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 425 | `rw [List.map_cons]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 428 | `rw [hy, RecSym.digitEmb_apply]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 471 | `simp only [sphWitnessSel, Function.Embedding.coeFn_mk, Fin.val_one]` | Own leaf/selection definition; all remaining arguments are public equations. |
| 506 | `dsimp only` | Beta/zeta/projection normalization of the statement’s local lets; all foreign TCSlib definitions sealed. |
| 521 | `rw [Cfg.liftSymbols_state, MultiTapeTM.initCfg_eq, Cfg.init_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 524 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_state, heq, hhalt]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 527 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 534 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_output, ho]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 539 | `rw [hr]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 540 | `rw [hr]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 543 | `simpa only [List.nil_append, hout']` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 544 | `rw [hr]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 547 | `simpa only [List.nil_append, hout', List.length_map]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 549 | `rw [hr]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 553 | `rw [hpre u hu, Cfg.mapState_output, embedSilentCfg_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 554 | `rw [hr, embedSilentCfg_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 555 | `rw [MultiTapeTM.spaceUsed_eq_sum]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 561 | `rw [MultiTapeTM.spaceUsedByTape_eq_card, embedSilentRetTM_visitedByTapeHead, ← MultiTapeTM.spaceUsedByTape_eq_card]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 566 | `rw [(embedSilentTM_visitedByTapeHead ι 1 hcap _ tapes heads [] out a t i).2]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 579 | `rw [hout', List.length_map]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 581 | `rw [(embedSilentTM_visitedByTapeHead_frame ι 1 hcap _ tapes heads [] out a t j hj hjc).2]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 585 | `rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 609 | `simpa only [List.length_map]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 613 | `rw [Cfg.liftSymbols_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 618 | `rw [Cfg.liftSymbols_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 620 | `rw [Cfg.liftSymbols_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 631 | `rw [hs, MultiTapeTM.liftSymbols_runFrom]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 634 | `rw [hrun, ← ha, hr]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 636 | `rw [Cfg.liftSymbols_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 637 | `rw [Cfg.liftSymbols_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 639 | `rw [Cfg.liftSymbols_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 644 | `rw [hrun, embedEmitCfg_state, Cfg.liftSymbols_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 647 | `rw [hrun]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 698 | `rw [Cfg.mapState_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 699 | `rw [Cfg.mapState_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 708 | `rw [Cfg.mapState_state, Cfg.mapState_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 712 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 715 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 718 | `rw [List.length_map]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 720 | `rw [hbt, hbh, hpos, sub_self, zero_add, hcap]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 732 | `rw [Cfg.mapState_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 733 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 735 | `rw [Cfg.mapState_workTapes]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 738 | `rw [Cfg.mapState_workTapePos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 739 | `dsimp only [d₃]` | Own local let only (`A` or `d₃`). |
| 740 | `rw [hbh, hpos, sub_self]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 741 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 745 | `rw [Cfg.mapState_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 747 | `rw [Cfg.mapState_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 803 | `rwa [embedEmitCfg_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 806 | `rwa [embedEmitCfg_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 809 | `rwa [embedEmitCfg_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 813 | `rwa [embedEmitCfg_selected_tape]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 817 | `rwa [embedEmitCfg_selected_pos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 819 | `rw [htapes, hheads, h1]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 820 | `rw [htapes, hheads, h0]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 823 | `rw [htapes]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 829 | `rwa [hrecon]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 832 | `rw [hrun, embedEmitCfg_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 835 | `rw [hrun]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 838 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 840 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 841 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 842 | `rw [hrun, hr, MultiTapeTM.initCfg_eq]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 844 | `rw [embedEmitCfg_state]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 845 | `rw [embedEmitCfg_inputPos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 850 | `rw [embedEmitCfg_selected_tape]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 851 | `rw [← h0]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 852 | `simp only [hheads, htapes, hz]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 853 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).1]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 855 | `simp only [hj0, false_and, ite_false]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 859 | `rw [embedEmitCfg_selected_pos]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
| 862 | `rw [embedEmitCfg_output]` | Local hypotheses/equalities and public proved reading/equation lemmas; no definition passed to the tactic. |
