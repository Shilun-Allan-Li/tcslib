# Rewrite and reduction inspection

Every rewrite/reduction tactic in the added proof is listed here. No `dsimp`, `unfold`, `show`, `change` or other rewrite tactic occurs in the added proof.

| Source line | Argument | Disposition |
|---|---|---|
| 169 | `rw [logSpace_eq]` | Public equation theorem in `SpaceComplexity/Basic`; no definition unfolded. |
| 174 | `simpa using this` | Uses the standard simplification of `1 * f n`. The full seal passes with all reached TCSlib definitions opaque and the four primitive simp definitions removed. |

The finite supremum is introduced by the local `set F := (Finset.range N).sup f with hF`; its only uses are the published `Finset.le_sup` and arithmetic lemmas. No core/Mathlib definition is explicitly passed to a rewrite or simplification tactic.
