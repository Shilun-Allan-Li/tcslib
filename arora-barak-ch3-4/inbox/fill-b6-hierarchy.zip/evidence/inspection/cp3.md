# Rewrite and reduction inspection

Every tactic occurrence in the owned proof region is listed; multiline bracket arguments are expanded. Other-file TCSlib definitions are never explicit reduction arguments. Local lets and this file's definitions may reduce. Core/Mathlib definitions are not passed to rewriting or unfolding. The accompanying full seal checks residual definitional closure.

| Line | Tactic and arguments | Inspection |
|---|---|---|
| 169 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 174 | `simpa using this` | No explicit definition argument; theorem simplification checked under the full seal. |
| 220 | `simp only [x, length_pairEncode, List.length_replicate]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 225 | `rw [hα]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 230 | `rw [hα, hsp]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 235 | `rw [logSpace_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 241 | `dsimp only [A]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 260 | `rw [pow_succ]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 277 | `rw [logSpace_eq, ← hL]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 290 | `simpa only [pow_one]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 294 | `rw [← LOGSPACE_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 320 | `rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero, MultiTapeTM.step_of_some hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 323 | `rw [Action.apply_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 324 | `rw [Action.apply_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 326 | `rw [Action.apply_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 327 | `simp only [sphRightTM, Option.getD_none, Cfg.workTapeSymbols_eq, Function.update_eq_self]` | Own definition(s) plus local equalities and published equation lemmas. |
| 330 | `rw [Action.apply_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 331 | `simp only [sphRightTM, SignType.coe_zero, add_zero]` | Own definition(s) plus local equalities and published equation lemmas. |
| 332 | `rw [Action.apply_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 333 | `simp only [sphRightTM, Option.toList_none, List.append_nil]` | Own definition(s) plus local equalities and published equation lemmas. |
| 337 | `rw [hp, SignType.pos_eq_one, moveInputPos_rightBoundary]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 339 | `rw [moveInputPos_pos_of_ne_right _ h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 344 | `rw [MultiTapeTM.runFrom_zero, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 349 | `rw [MultiTapeTM.runFrom_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 350 | `rw [hstep]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 367 | `rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero, MultiTapeTM.step_of_some hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 370 | `rw [Action.apply_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 371 | `rw [Action.apply_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 374 | `rw [Action.apply_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 375 | `simp only [sphEmitTM, Option.getD_none, Cfg.workTapeSymbols_eq, Function.update_eq_self]` | Own definition(s) plus local equalities and published equation lemmas. |
| 378 | `rw [Action.apply_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 379 | `simp only [sphEmitTM, SignType.coe_zero, add_zero]` | Own definition(s) plus local equalities and published equation lemmas. |
| 380 | `rw [Action.apply_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 386 | `rw [MultiTapeTM.runFrom_zero]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 387 | `rw [hstep]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 406 | `rw [List.foldl_nil]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 409 | `rw [List.foldl_cons, ih]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 417 | `rw [List.map_cons, RecSym.digitEmb_apply, ← hx]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 425 | `rw [List.map_cons]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 428 | `rw [hy, RecSym.digitEmb_apply]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 471 | `simp only [sphWitnessSel, Function.Embedding.coeFn_mk, Fin.val_one]` | Own definition(s) plus local equalities and published equation lemmas. |
| 506 | `dsimp only` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 521 | `rw [Cfg.liftSymbols_state, MultiTapeTM.initCfg_eq, Cfg.init_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 524 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_state, heq, hhalt]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 527 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 534 | `rw [MultiTapeTM.liftSymbols_runFrom, Cfg.liftSymbols_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 539 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 540 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 543 | `simpa only [List.nil_append, hout']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 544 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 547 | `simpa only [List.nil_append, hout', List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 549 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 553 | `rw [hpre u hu, Cfg.mapState_output, embedSilentCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 554 | `rw [hr, embedSilentCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 555 | `rw [MultiTapeTM.spaceUsed_eq_sum]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 561 | `rw [MultiTapeTM.spaceUsedByTape_eq_card, embedSilentRetTM_visitedByTapeHead, ← MultiTapeTM.spaceUsedByTape_eq_card]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 566 | `rw [(embedSilentTM_visitedByTapeHead ι 1 hcap _ tapes heads [] out a t i).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 579 | `rw [hout', List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 581 | `rw [(embedSilentTM_visitedByTapeHead_frame ι 1 hcap _ tapes heads [] out a t j hj hjc).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 585 | `rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 609 | `simpa only [List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 613 | `rw [Cfg.liftSymbols_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 618 | `rw [Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 620 | `rw [Cfg.liftSymbols_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 631 | `rw [hs, MultiTapeTM.liftSymbols_runFrom]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 634 | `rw [hrun, ← ha, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 636 | `rw [Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 637 | `rw [Cfg.liftSymbols_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 639 | `rw [Cfg.liftSymbols_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 644 | `rw [hrun, embedEmitCfg_state, Cfg.liftSymbols_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 647 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 698 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 699 | `rw [Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 708 | `rw [Cfg.mapState_state, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 712 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 715 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 718 | `rw [List.length_map]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 720 | `rw [hbt, hbh, hpos, sub_self, zero_add, hcap]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 732 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 733 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 735 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 738 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 739 | `dsimp only [d₃]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 740 | `rw [hbh, hpos, sub_self]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 741 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 745 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 747 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 763 | `rwa [embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 765 | `rwa [embedEmitCfg_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 767 | `rwa [embedEmitCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 771 | `rwa [embedEmitCfg_selected_tape]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 775 | `rwa [embedEmitCfg_selected_pos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 831 | `rw [htapes, hheads, h1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 832 | `rw [htapes, hheads, h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 835 | `rw [htapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 841 | `rwa [hrecon]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 844 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 847 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 850 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 852 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 853 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 854 | `rw [hrun, hr, MultiTapeTM.initCfg_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 856 | `rw [embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 857 | `rw [embedEmitCfg_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 862 | `rw [embedEmitCfg_selected_tape]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 863 | `rw [← h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 864 | `simp only [a, hheads, htapes, hz]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 865 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 867 | `simp only [hj0, false_and, ite_false]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 871 | `rw [embedEmitCfg_selected_pos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 874 | `rw [embedEmitCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 936 | `dsimp only` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 940 | `simp only [ι, sphRunnerSel, Function.Embedding.coeFn_mk, Fin.val_zero, if_pos]` | Own definition(s) plus local equalities and published equation lemmas. |
| 947 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 949 | `rw [htapes, hheads, h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 954 | `rw [htapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 956 | `rw [hv i hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 959 | `rw [hv i hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 965 | `rwa [embedEmitCfg_select]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 967 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 970 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 973 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 976 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 978 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 979 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 981 | `rw [hrun, embedEmitCfg_output, hs u hu]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 986 | `rw [hrun, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 988 | `rw [embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 989 | `rw [embedEmitCfg_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 994 | `rw [embedEmitCfg_selected_tape]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 995 | `rw [← h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 996 | `simp only [a, hheads, htapes, h0, hz]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 997 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).1]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 999 | `simp only [hj0, false_and, ite_false]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1003 | `rw [embedEmitCfg_selected_pos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1006 | `rw [embedEmitCfg_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1045 | `dsimp only` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1051 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1053 | `rw [htapes, hheads, h0]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1056 | `rw [joinFields_cfgRecord_length]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1060 | `rwa [embedEmitCfg_select]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1063 | `rw [hrun, embedEmitCfg_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1066 | `rw [hrun]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1069 | `rw [embedEmitCfg_selected_pos, ← hheads]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1071 | `rw [(embedEmitCfg_unselected ι d.workTapes d.workTapePos d.output _ j hj).2]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1072 | `simp only [sub_self, abs_zero, Nat.cast_nonneg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1073 | `rw [hrun, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1075 | `simp only [decide_eq_true_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1097 | `rw [MultiTapeTM.runFrom_zero, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1101 | `rw [(sph_emit_run b d hd).2 u hu]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1153 | `simp only [Set.mem_insert_iff, Set.mem_singleton_iff, not_or]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1163 | `rw [Cfg.mapState_state, Cfg.mapState_state, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1166 | `rw [Contract.branch_pre]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1167 | `change (d₀.mapState fun _ => entry) = d` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 1169 | `rw [Cfg.mapState_state, hd₀, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1170 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1172 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1174 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1175 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1177 | `rw [Contract.branch_time]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1178 | `dsimp only [C₀, sphEmitContract]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1179 | `rw [ite_self]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1184 | `rw [ht]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1187 | `rw [(sph_emit_run (RecSym.digit true) _ (by rw [Cfg.mapState_state]; rfl)).1]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1188 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1189 | `rw [h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1191 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1192 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1194 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1196 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1197 | `rw [Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1200 | `rw [(sph_emit_run (RecSym.digit false) _ (by rw [Cfg.mapState_state]; rfl)).1]` | Own definition(s) plus local equalities and published equation lemmas. |
| 1201 | `rw [Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1202 | `rw [h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1204 | `rw [Cfg.mapState_state, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1205 | `rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1207 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1209 | `rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1210 | `rw [Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1214 | `rw [Contract.branch_lo, Contract.branch_hi]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1215 | `dsimp only [C₀, sphEmitContract]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1216 | `simp only [Cfg.mapState_workTapePos, ite_self]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1217 | `dsimp only [d']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1218 | `rw [min_eq_left (by omega), max_eq_left (by omega), Finset.mem_Icc]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1219 | `dsimp only [d₀, sphVerdictTM]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1236 | `rw [hN]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1237 | `rw [h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1238 | `rw [heq, h]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1259 | `rw [seamCompTM_runFrom_left A exit B entry hc u h, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1262 | `rw [seamCompTM_runFrom_right A exit B entry hr he hc w, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1280 | `rw [seamCompTM_runFrom_left A exit B entry hc u h, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1285 | `rw [hr, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1288 | `rw [seamCompTM_runFrom_right A exit B entry hr he hc w, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1290 | `rw [hq, Option.map_none]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1291 | `rw [hq, Option.map_some]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1311 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1313 | `rw [hL]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1314 | `change (if (0 : Fin (k + 1)) = 0 ∧ d.workTapePos 0 ≤ d.workTapePos 0 + p ∧` | Target reshaping through own local lets/structures or core syntax; no foreign definition is opened. Full seal checked. |
| 1319 | `rw [if_pos ⟨rfl, by omega, by omega⟩]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1322 | `rw [if_neg (by rintro ⟨_, h₁, h₂⟩; exact h ⟨by omega, by omega⟩)]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1325 | `rw [fieldsTape_of_neg fs (by omega), ← sub_eq_add_neg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1327 | `rw [fieldsTape_of_length_le fs (by rw [hL])]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1327 | `rw [hL]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1386 | `rw [hAp t le_rfl, hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1389 | `rw [hAp u hu.le, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1395 | `rw [hCp t le_rfl, hAr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1398 | `rw [hCp u hu.le, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1414 | `rw [hC, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1419 | `rw [seamCompTM_runFrom_left C (Sum.inl (Sum.inl (exit .exhausted))) E () (fun u _ => hCe u) u le_rfl, hC]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1426 | `rw [hW, hA, Cfg.mapState_state, Cfg.mapState_state, Cfg.mapState_state, hvs]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1428 | `rw [hW, hA, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, hvo, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1430 | `rw [hW, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1434 | `rw [Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1444 | `rw [Cfg.mapState_state, ha']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1450 | `rw [hAp u hu, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1455 | `rw [heh u hu, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1460 | `rw [hw, hC, Cfg.mapState_state, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1461 | `rw [hw, hC, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1464 | `rw [hw, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1468 | `rw [Cfg.mapState_state, Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1470 | `rw [Cfg.mapState_state, hc']` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1476 | `rw [hCp u hu, Cfg.mapState_workTapePos, hAp u hu, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1481 | `rw [heh u hu, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1487 | `rw [hW, Cfg.mapState_state]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1488 | `rw [hW, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, Cfg.mapState_output, ho]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1536 | `rw [Cfg.mapState_state, hd]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1538 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1540 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1545 | `rw [Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1549 | `simp only [a, Cfg.mapState_state, hd, Option.map_some]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1551 | `simp only [a, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1553 | `simp only [a, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1555 | `simp only [a, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1556 | `simp only [a, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1558 | `rw [MultiTapeTM.initCfg_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1577 | `rw [hout]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1582 | `rw [fieldsTape_of_neg _ (by omega), ← sub_eq_add_neg]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1586 | `rw [joinFields_cfgRecord_length]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1587 | `rw [fieldsTape_of_length_le _ (by rw [joinFields_cfgRecord_length])]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1587 | `rw [joinFields_cfgRecord_length]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1590 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1591 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1595 | `rw [Cfg.mapState_state, he]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1597 | `rw [recordAt_iff]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1599 | `rw [Cfg.mapState_workTapes, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1604 | `simpa only [b, decide_eq_true_eq]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1607 | `simp only [z, Cfg.mapState_state, ha', Option.map_some]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1609 | `simp only [z, Cfg.mapState_inputPos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1611 | `simp only [z, Cfg.mapState_workTapes]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1613 | `simp only [z, Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1614 | `simp only [z, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1615 | `rw [hmaps]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1617 | `rw [hvr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1618 | `rw [hvr, Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1623 | `dsimp only [b]` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1628 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1629 | `dsimp only [a']` | Only own local let-bindings/definitions (or anonymous let binders); no foreign definition argument. |
| 1630 | `rw [hr]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1631 | `rw [hzhead]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1636 | `rw [hstart]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1638 | `rw [Cfg.mapState_output]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1642 | `rw [Cfg.mapState_workTapePos]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1648 | `rw [hsummary]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
| 1650 | `rw [hsummary]` | Local let-bindings/equalities and public proved reading/equation lemmas; no foreign definition argument. |
