# Final downstream sweep

All 52 modules pass. Sum of module wall times: 1030.9 seconds. Maximum peak RSS: 2530816 KiB.

| Module | Wall seconds | Peak RSS (KiB) | Exit |
|---|---:|---:|---:|
| `TCSlib/Complexity/SpaceComplexity/Hierarchy` | 10.982 | 2277128 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PreimageHost` | 6.729 | 1980252 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/QueryReshape` | 71.607 | 2530816 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/Reductions` | 2.417 | 1910620 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/ARMReach` | 3.667 | 1843128 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARM` | 3.331 | 1881908 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMKit` | 4.122 | 1909932 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathWalkMachine` | 22.637 | 2337104 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMCompile` | 10.727 | 2095680 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMRun` | 2.969 | 1870360 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMProof` | 3.867 | 1901436 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathWalkProof` | 11.374 | 2097764 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHard` | 7.142 | 2054520 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardRegs` | 6.631 | 2144308 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardMachine` | 37.598 | 2399232 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardRun` | 12.373 | 2289380 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardWalk` | 9.281 | 2183756 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardDecide` | 16.226 | 2144276 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/Path` | 2.517 | 2056512 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountRegs` | 7.024 | 2168776 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountMath` | 2.846 | 1880636 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenMachine` | 35.777 | 2311668 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenWalk` | 42.35 | 2173596 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenStage` | 8.286 | 2202388 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenLoop` | 9.49 | 2211436 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Radius` | 3.718 | 1997824 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenRadius` | 2.639 | 1982576 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenCorrect` | 9.324 | 2123700 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ImmermanSzelepcsenyi` | 2.37 | 2043208 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/Mult` | 20.074 | 2211188 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/ARMWidthExample` | 3.68 | 1911916 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMExample` | 2.481 | 1852504 | 0 |
| `TCSlib/Complexity/Randomized/Classes` | 11.214 | 2011700 | 0 |
| `TCSlib/Complexity/Randomized/RandomBits` | 4.025 | 1898472 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMProb` | 362.269 | 1964032 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMPSem` | 6.545 | 1966796 | 0 |
| `TCSlib/Complexity/Randomized/PTM` | 3.54 | 1865536 | 0 |
| `TCSlib/Complexity/Randomized/SpaceAmplify` | 7.148 | 1948100 | 0 |
| `TCSlib/Complexity/Randomized/SpaceAmplifyRun` | 5.08 | 1964496 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/MARM` | 4.967 | 1874436 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/MARMCompile` | 17.096 | 2093216 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/MARMTime` | 9.413 | 2004144 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Machine` | 18.173 | 2142168 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Run` | 15.113 | 2168284 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Relax` | 20.581 | 2024744 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Search` | 13.083 | 2021948 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Main` | 115.824 | 2380528 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpTime` | 4.982 | 2030888 | 0 |
| `TCSlib/Complexity/Randomized/Space` | 3.882 | 2113432 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMLogspace` | 4.953 | 2108440 | 0 |
| `TCSlib/Complexity/SpaceComplexity/SavitchARM/Window` | 3.148 | 1995144 | 0 |
| `TCSlib/Complexity/SpaceComplexity` | 3.608 | 2190776 | 0 |
