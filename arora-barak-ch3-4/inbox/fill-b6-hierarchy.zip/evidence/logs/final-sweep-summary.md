# Final downstream sweep

Commit: `30222bbd264a75057ae0779535a32e1a30dd2394`. All 52 modules pass. Summed module wall time: 1274.870 seconds. Maximum peak RSS: 2,528,956 KiB. The two expected Hierarchy sorry warnings and two unchanged baseline style warnings in Randomized/Classes occur.

| Module | Wall seconds | Peak RSS (KiB) | Exit |
|---|---:|---:|---:|
| `TCSlib/Complexity/SpaceComplexity/Hierarchy` | 11.898 | 2261900 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PreimageHost` | 6.471 | 1970196 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/QueryReshape` | 74.669 | 2528956 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/Reductions` | 2.542 | 1914432 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/ARMReach` | 5.968 | 1840240 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARM` | 5.333 | 1877612 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMKit` | 4.132 | 1906800 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathWalkMachine` | 22.820 | 2323384 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMCompile` | 11.307 | 2066596 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMRun` | 3.642 | 1864556 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMProof` | 5.193 | 1909252 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathWalkProof` | 35.140 | 2129556 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHard` | 5.625 | 2052848 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardRegs` | 17.033 | 2147492 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardMachine` | 34.246 | 2392516 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardRun` | 14.013 | 2280768 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardWalk` | 9.162 | 2193316 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/PathHardDecide` | 15.654 | 2153636 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/Path` | 2.578 | 2049096 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountRegs` | 5.908 | 2163288 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountMath` | 3.070 | 1880676 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenMachine` | 31.842 | 2347664 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenWalk` | 14.567 | 2173508 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenStage` | 22.323 | 2208408 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenLoop` | 23.437 | 2228644 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Radius` | 3.544 | 1996324 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenRadius` | 2.985 | 1976148 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ISCountGenCorrect` | 33.421 | 2101804 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/ImmermanSzelepcsenyi` | 6.500 | 2043280 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Logspace/Mult` | 21.970 | 2257656 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/ARMWidthExample` | 4.860 | 1914772 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMExample` | 2.640 | 1856660 | 0 |
| `TCSlib/Complexity/Randomized/Classes` | 11.463 | 2001020 | 0 |
| `TCSlib/Complexity/Randomized/RandomBits` | 3.517 | 1897880 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMProb` | 654.432 | 1956280 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMPSem` | 6.223 | 1964552 | 0 |
| `TCSlib/Complexity/Randomized/PTM` | 2.632 | 1864072 | 0 |
| `TCSlib/Complexity/Randomized/SpaceAmplify` | 4.051 | 1943740 | 0 |
| `TCSlib/Complexity/Randomized/SpaceAmplifyRun` | 3.898 | 1962844 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/MARM` | 2.909 | 1871492 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/MARMCompile` | 11.558 | 2115344 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/MARMTime` | 7.266 | 1999252 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Machine` | 16.563 | 2123096 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Run` | 13.039 | 2162488 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Relax` | 20.678 | 2013328 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Search` | 6.365 | 2002708 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpBFS/Main` | 29.677 | 2352272 | 0 |
| `TCSlib/Complexity/SpaceComplexity/ExpTime` | 2.560 | 2027440 | 0 |
| `TCSlib/Complexity/Randomized/Space` | 3.946 | 2105748 | 0 |
| `TCSlib/Complexity/SpaceComplexity/Machines/NARMLogspace` | 4.062 | 2108320 | 0 |
| `TCSlib/Complexity/SpaceComplexity/SavitchARM/Window` | 2.648 | 1991284 | 0 |
| `TCSlib/Complexity/SpaceComplexity` | 2.890 | 2188064 | 0 |
