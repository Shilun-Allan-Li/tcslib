# B6 hierarchy fill — checkpoint 5

**Partial delivery.** Checkpoints 1 and 5 are committed and checked: the overlay, inclusion,
permitted documentation cleanup, and the normalization/window lemma. The three target bodies
remain open. Checkpoint 5 is independent of the unfinished machine assembly and lands separately.
This early archive preserves the checkpoint while the after-screen and final downstream sweep
are pending. It is not an attestation that the entire fill or its final verification is complete.

## Identity and scope

- Base: `e6bc196838b4e2675e4214306c730e7404624ab8`.
- Base `Hierarchy.lean` blob: `287acce8326a1de271dfa6be2cc3776f3a2caa32`.
- Checkpoint commit: `eec4e0a5e9dd3533340250f845369e04b1a07535`.
- Local branch: `fill/b6-hierarchy`, branched at exactly the base. The required ancestor check
  passed before branching. No rebase, merge, cherry-pick, push or PR.
- Only tracked file changed: `TCSlib/Complexity/SpaceComplexity/Hierarchy.lean`; changes are in
  the permitted import, private-declaration and documentation regions. All four public
  statements are byte-identical to the base. `space_universal`'s complete docstring and body,
  and its module main-results entry, are byte-identical.
- Source size: 403 lines, four public declarations, two private declarations. No added line
  exceeds 100 characters. No added admission.

The exchange brief and addendum were fetched with their manifest and verified before reading:

| File | Verified SHA-256 |
|---|---|
| `b6-fill-hierarchy.md` | `3c92e156529b5a7f1f061e3b1d5beaf0918fe3b11355e34362441b56c36bd357` |
| `fill-environment-addendum.md` | `9f5bd5e74bb767e50a6e7a372e98a5567998ec14be432c1dfb7ff8856eb9bd28` |

The first local serialization added a newline; the exact fetched UTF-8 contents were then
written and both checks passed. There was no mismatch in the fetched artifacts.

## Checkpoints and declarations

| Checkpoint | Status at this commit |
|---|---|
| 1: overlay and inclusion | Source complete; compiled, sealed, axiom-checked; after-screen and final tail pending |
| 2: validation, radius, rewinds, initial record | Open |
| 3: runner, test and verdict | Open |
| 4: space bound and alphabet-reduction packaging | Open |
| 5: normalization and window containment | Source complete; compiled, sealed and axiom-checked |
| 6: `space_hierarchy` | Open |
| 7: `LOGSPACE_ssubset_PSPACE` | Open |
| 8: `SPACE_linear_ne_NP` or named padding escalation | Open |

The first private is `sph_inclusion`, the brief's mandated private renaming of
`hr_inclusion`. It applies domination with constant one, bounds the finite exceptional prefix
by a finite supremum, uses the positive floor of the larger bound, and cites `SPACE.mono_const`.
No other-file definition is unfolded.

The second private is `sph_code_window`. It normalizes an arbitrary smaller-space decider by
`one_work_tape_binary_spaceUsed` and `exists_codeTM_spaceUsed`, then uses the supplied universal
machine's per-code simulation contract. It returns a padded input and the exact time
`U₀.configBound x.length (g x.length)`, together with the correct one-bit output, space at most
`g x.length`, and the exact halted window-run summary at the next round.

The constant is chosen after the code and its universal constant:

```text
A = C * (c₁ * c₀ + c₁ + 1)
C * (c₁ * (c₀ * f n + 1) + 1)
  ≤ C * (c₁ * (c₀ * f n + f n) + f n)
  = A * f n ≤ g n.
```

Here the first inequality uses `1 ≤ f n`, and the final inequality uses the domination
threshold. The payload is `List.replicate N₀ true`, so the paired input's length is at least
`N₀`; the code itself is unchanged. The published halting-space theorem supplies the
configuration-bound time, and `windowRun_summary_of_halts` supplies the window conclusion.
No statement of `space_hierarchy` is used in this private proof.

The new symbols in this calculation are the existing proof parameters: `c₀` is the original
decider's coefficient, `c₁` the normal-form coefficient, `C` the fixed code's universal
simulation coefficient, `A` their domination coefficient, and `N₀` the resulting threshold.

**Open declarations:** `space_hierarchy`, `LOGSPACE_ssubset_PSPACE`, and `SPACE_linear_ne_NP`.
Each retains its literal **Proof sketch** in the source. `space_universal` is out of scope and
untouched, with its original Proof sketch and admission.

No diagonalizer or tape-plan declaration has landed at this checkpoint. The normalization
lemma does establish the floor, threshold, unchanged-code padding, halting and window-summary
parts of the contradiction. In particular, no
combined space bound, verdict correctness, empty-input handling or foreign-input rejection is
claimed. The intended layout is record tape 0, radius tape 1, separate initializer and runner
scratch banks, then the witness bank. The runner will exclude the radius and dirty witness
bank. Exploratory drafts, if included under `evidence/drafts`, are **unchecked continuation
material**, not part of the committed source or patch series.

## Environment and checks

Part 1 preflight passed before bootstrap: 57.747 GiB free on the work filesystem and 9.075 GiB
MemAvailable. No cgroup controller was exposed. The first attempt to read a cgroup limit failed;
the logged fallback used `/proc/meminfo`. `/tmp` is tmpfs; all compilation/cache temporary files
used the disk-backed task `TMPDIR` instead. A later resource check still found over 51 GiB free
and 8.6 GiB MemAvailable.

Lean 4.25.0 was installed from the official release archive into a fresh task directory. It
starts normally (commit `cdd38ac5115bdeec5f609e9126cce00f51ae88b3`); no loader shim or borrowed
compiled artifact was used. Every present package matched both its manifest revision and URL;
absent optional packages were not named by the module order. The cache was fetched for exactly
the 63 derived Mathlib roots, never unfiltered.

The first narrowed cache fetch succeeded. A subsequent probe was rejected because its source
resolved through a symlink outside the repository root. Conservatively, the single cleaned
retry was taken: package/build configuration artifacts were removed, preflight and pin checks
repeated, and the same roots fetched again using the freshly obtained 1,057 archives. A physical
`FillProbes/CacheProbe.lean` then passed. No empty `.olean` was found. This was a path-validation
error, not evidence of corrupt cached proofs.

The fresh **220-module bootstrap passed**, with exactly the supplied 26 sorry warnings in ten
modules. Per-module wall time and peak RSS are recorded using `os.wait4` in
`evidence/logs/bootstrap/`; summed module time was 2,834.864 seconds, maximum RSS 2,994,428 KiB.
The cache probe and every other Lean invocation also have separate resource logs. Only one
agent-started Lean invocation ran at a time; the permitted low-priority text screen ran beside it.
No `lake build`, unfiltered cache fetch or module timeout was used.

After the proof edit, both the owned module and its facade passed. A documentation line-wrap
repair was then checked again. `cp1-verify` contains the owned/facade, seal, axiom, extended
host-probe, controls and elaborated constant-walk logs. The expanded seal also covers
`Turing.FinTM.ComputesInSpace`, which appeared in the elaborated term. An initial generated
control repeated the five already-sealed attributes and was rejected; its corrected rerun is
in `cp1-full-seal-fixed`. No unsafe reducibility override was used.

The after-screen is running on a frozen checkpoint worktree, under
`nice -n 10`. Its current raw output is included, but **completion and new-pair classification
are pending**. That running screen is frozen at checkpoint 1
(`fd925fa2ee9de1509a74300ae7ea5202f7461605`); a final screen must cover the final source. The final 52-module tail from `Hierarchy` is also pending; the completed
220-module baseline and the post-edit owned/facade checks do not substitute for that final tail.
These outstanding verification items must be completed before a final attestation.

## Axioms, seal and rewrite inspection

| Declaration | Axioms at this checkpoint |
|---|---|
| `sph_inclusion` | `propext`, `Classical.choice`, `Quot.sound` |
| `sph_code_window` | `propext`, `Classical.choice`, `Quot.sound` |
| `space_hierarchy` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `LOGSPACE_ssubset_PSPACE` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `SPACE_linear_ne_NP` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |

The expanded checkpoint-5 seal covers all 21 direct other-file TCSlib definitions from the
elaborated terms, including the five required class/bound definitions, computations in space
and time, the fixed code, coded-machine transport, pairing, configuration bound, run and space
functions, indicator, output summary/code, summary update and window run. It removes the four
primitive simp attributes. The scratch source passes under this seal.

The effective control suite has 25 checks: 20 whole-definition `rfl` controls, a recursive
usage/equation `rfl` control for `windowRun`, and four primitive simp controls. All 25 pass
unsealed and fail sealed (`cp5-controls-fixed`). The generic whole-value `windowRun` control
failed even unsealed, so it was replaced by its effective equation control; both the initial
and corrected raw outputs are preserved. No unsafe reducibility override was used.

The owned module and facade passed after adding the proof (`cp5-edit-1`). The expanded seal,
controls and extended host probe passed (`cp5-verify`, with the corrected controls above).
The axiom log is `cp5-discover/002-FillProbes_cp5_Axioms.log`.

`evidence/inspection/cp5.md` enumerates all seven rewrite/reduction tactic sites and classifies
each argument. The elaborated walk records 229 outside constants, 43 from TCSlib; the full
citation table and machine-readable list are in `evidence/citations/`. The copied import probe
was extended by 18 checks and axiom prints, covering every additional TCSlib constant. All
direct TCSlib citations are public at the base. The six forbidden R3 rows and foreign private
citations are absent. The frozen-statement, F6, import and added-line checks all pass.

## Duplication and lint

The before-screen is **byte-identical** to the supplied base: 1,854 declarations, 1,689 pairs,
534,736 reproduced characters, no pair on `Hierarchy`. The after-screen is pending; therefore
**new copies: not yet determined**, not certified absent.

For `sph_inclusion`, name and statement-family searches were run with `git grep` on the exact
base and every open PR head observed in this session:

| PR | Read-only fetched head |
|---|---|
| 211 | `f239dafd09f060ec87ca0992103ae8eb48bce31e` |
| 210 | `fff0430c7c9db136e60ed14b069e972c2ea56fc8` |
| 208 | `d01c56a4ed9487fa2c84c7d62470cee2c6bef960` |
| 195 | `40553944417ba519d736985a300e61fbd13eaffc` |

The inclusion searches found no `sph_` collision or published eventual-domination inclusion to cite
instead. The supplied semantic probe was rerun before adding the private: `exact?` did not
close the inclusion, square bound, logarithmic-domination or linear-to-PSPACE goals; it found
exactly `logSpace_le_succ` and `LOGSPACE_subset_PSPACE` for the other two goals, as in the
pre-ship. Its four intentional failures are recorded as a nonzero diagnostic probe, not a
failed source check. The mandated inclusion proof is copied with the required private name.

For `sph_code_window`, searches on the same base and all four heads covered its name, normal
form, coding-space clause and window-summary statement family. The component hosts exist and
are cited; no published combined normalization/padding/window lemma was found. Its separate
`exact?` probe did not close the stated goal (`cp5-dup`).

Campaign lint: **0 FAIL, 80 WARN over 111 files**, identical to the baseline. File style lint:
the same one finding as the base, the module docstring's missing `## Main definitions`.

## Escalations, implementation paragraphs and continuation

No mathematical obstruction has been established for checkpoints 1 and 5. No promotion is
requested for their helpers. Checkpoint 8's optional padding escalation has not yet been reached.
The source's other open obligations remain work to do, not claimed API obstructions.

Proposed implementation paragraphs for the maintainer, **for the completed proofs rather than
as claims about this checkpoint**:

- `space_hierarchy`: **Implementation.** Absorb the finite exceptional prefix for inclusion.
  For strictness, compute the radius under `embedSilentRetTM`, rewind the radius and input,
  initialize the fixed self-universal machine's record, and use the configuration-count runner
  with `summaryTag`. The clock belongs to the runner. Test a halted endpoint and emit the
  opposite verdict, with foreign inputs rejected before the radius computation. Normalize a
  putative smaller-space decider through the published space-preserving normal form and coding
  clauses, fix its per-code universal constant, then pad only the payload.
- `LOGSPACE_ssubset_PSPACE`: **Implementation.** Apply the space hierarchy to `logSpace` and
  `n + 1`, using the integer-logarithm domination lemma, and transport strictness through the
  published linear-space inclusion into `PSPACE`.
- `SPACE_linear_ne_NP`: **Implementation.** Use the polynomial-time quadratic-padding map and
  `preimage_mem_NP`. A linear-space decider for the precisely padded language would turn an
  assumed equality of linear space and `NP` into the reverse of the linear/quadratic hierarchy.
  If that padded decider cannot be assembled from the named hosts, retain the admission and
  escalate its exact missing statement.

The supplied base sorry inventory is included verbatim in `evidence/logs/base-sorries.txt`;
all out-of-scope admissions remain untouched. Resume from the checkpoint commit and the
committed source, not from the unchecked drafts.
