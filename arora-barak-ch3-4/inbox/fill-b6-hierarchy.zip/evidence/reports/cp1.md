# B6 hierarchy fill — checkpoint 1

**Partial delivery.** Checkpoint 1's source is committed and checked: the four-import overlay,
`sph_inclusion`, and the permitted documentation cleanup. The three target bodies remain open.
This early archive preserves the checkpoint while the after-screen and final downstream sweep
are pending. It is not an attestation that the entire fill or its final verification is complete.

## Identity and scope

- Base: `e6bc196838b4e2675e4214306c730e7404624ab8`.
- Base `Hierarchy.lean` blob: `287acce8326a1de271dfa6be2cc3776f3a2caa32`.
- Checkpoint commit: `fd925fa2ee9de1509a74300ae7ea5202f7461605`.
- Local branch: `fill/b6-hierarchy`, branched at exactly the base. The required ancestor check
  passed before branching. No rebase, merge, cherry-pick, push or PR.
- Only tracked file changed: `TCSlib/Complexity/SpaceComplexity/Hierarchy.lean`; changes are in
  the permitted import, private-declaration and documentation regions. All four public
  statements are byte-identical to the base. `space_universal`'s complete docstring and body,
  and its module main-results entry, are byte-identical.
- Source size: 332 lines, four public declarations, one private declaration. No added line
  exceeds 100 characters. No added admission.

The exchange brief and addendum were fetched with their manifest and verified before reading:

| File | Verified SHA-256 |
|---|---|
| `b6-fill-hierarchy.md` | `3c92e156529b5a7f1f061e3b1d5beaf0918fe3b11355e34362441b56c36bd357` |
| `fill-environment-addendum.md` | `9f5bd5e74bb767e50a6e7a372e98a5567998ec14be432c1dfb7ff8856eb9bd28` |

The first local serialization added a newline; the exact fetched UTF-8 contents were then
written and both checks passed. There was no mismatch in the fetched artifacts.

## Checkpoints and declarations

| Checkpoint | Status at this commit |
|---|---|
| 1: overlay and inclusion | Source complete; compiled, sealed, axiom-checked; after-screen and final tail pending |
| 2: validation, radius, rewinds, initial record | Open |
| 3: runner, test and verdict | Open |
| 4: space bound and alphabet-reduction packaging | Open |
| 5: normalization and window containment | Open |
| 6: `space_hierarchy` | Open |
| 7: `LOGSPACE_ssubset_PSPACE` | Open |
| 8: `SPACE_linear_ne_NP` or named padding escalation | Open |

The sole new private is `sph_inclusion`, the brief's mandated private renaming of
`hr_inclusion`. It applies domination with constant one, bounds the finite exceptional prefix
by a finite supremum, uses the positive floor of the larger bound, and cites `SPACE.mono_const`.
No other-file definition is unfolded.

**Open declarations:** `space_hierarchy`, `LOGSPACE_ssubset_PSPACE`, and `SPACE_linear_ne_NP`.
Each retains its literal **Proof sketch** in the source. `space_universal` is out of scope and
untouched, with its original Proof sketch and admission.

No diagonalizer or tape-plan declaration has landed at this checkpoint. In particular, no
combined space bound, verdict correctness, empty-input handling or foreign-input rejection is
claimed. The intended layout is record tape 0, radius tape 1, separate initializer and runner
scratch banks, then the witness bank. The runner will exclude the radius and dirty witness
bank. Exploratory drafts, if included under `evidence/drafts`, are **unchecked continuation
material**, not part of the committed source or patch series.

## Environment and checks

Part 1 preflight passed before bootstrap: 57.747 GiB free on the work filesystem and 9.075 GiB
MemAvailable. No cgroup controller was exposed. The first attempt to read a cgroup limit failed;
the logged fallback used `/proc/meminfo`. `/tmp` is tmpfs; all compilation/cache temporary files
used the disk-backed task `TMPDIR` instead. A later resource check still found over 51 GiB free
and 8.6 GiB MemAvailable.

Lean 4.25.0 was installed from the official release archive into a fresh task directory. It
starts normally (commit `cdd38ac5115bdeec5f609e9126cce00f51ae88b3`); no loader shim or borrowed
compiled artifact was used. Every present package matched both its manifest revision and URL;
absent optional packages were not named by the module order. The cache was fetched for exactly
the 63 derived Mathlib roots, never unfiltered.

The first narrowed cache fetch succeeded. A subsequent probe was rejected because its source
resolved through a symlink outside the repository root. Conservatively, the single cleaned
retry was taken: package/build configuration artifacts were removed, preflight and pin checks
repeated, and the same roots fetched again using the freshly obtained 1,057 archives. A physical
`FillProbes/CacheProbe.lean` then passed. No empty `.olean` was found. This was a path-validation
error, not evidence of corrupt cached proofs.

The fresh **220-module bootstrap passed**, with exactly the supplied 26 sorry warnings in ten
modules. Per-module wall time and peak RSS are recorded using `os.wait4` in
`evidence/logs/bootstrap/`; summed module time was 2,834.864 seconds, maximum RSS 2,994,428 KiB.
The cache probe and every other Lean invocation also have separate resource logs. Only one
agent-started Lean invocation ran at a time; the permitted low-priority text screen ran beside it.
No `lake build`, unfiltered cache fetch or module timeout was used.

After the proof edit, both the owned module and its facade passed. A documentation line-wrap
repair was then checked again. `cp1-verify` contains the owned/facade, seal, axiom, extended
host-probe, controls and elaborated constant-walk logs. The expanded seal also covers
`Turing.FinTM.ComputesInSpace`, which appeared in the elaborated term. An initial generated
control repeated the five already-sealed attributes and was rejected; its corrected rerun is
in `cp1-full-seal-fixed`. No unsafe reducibility override was used.

The after-screen is running on the frozen checkpoint worktree at the commit above, under
`nice -n 10`. Its current raw output is included, but **completion and new-pair classification
are pending**. The final 52-module tail from `Hierarchy` is also pending; the completed
220-module baseline and the post-edit owned/facade checks do not substitute for that final tail.
These outstanding verification items must be completed before a final attestation.

## Axioms, seal and rewrite inspection

| Declaration | Axioms at this checkpoint |
|---|---|
| `sph_inclusion` | `propext`, `Classical.choice`, `Quot.sound` |
| `space_hierarchy` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `LOGSPACE_ssubset_PSPACE` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `SPACE_linear_ne_NP` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |

The sealed scratch copy places local irreducibility attributes before the first private on
`SpaceConstructible`, `SPACE`, `logSpace`, `LOGSPACE`, `PSPACE` and `FinTM.ComputesInSpace`, and
removes the simp attributes of `Action.apply`, `Cfg.init`, `MultiTapeTM.initCfg` and `NDTM.initCfg`.
The source seal passes. Its ten controls pass unsealed and fail sealed in the corrected run.
Raw sources and outputs are included; none of these six sealed definitions is recursive.

`evidence/inspection/cp1.md` enumerates every rewrite/reduction tactic in the added proof. The
elaborated walk records all 128 outside constants, including tactic-generated constants; eight
are from TCSlib. The full citation table and machine-readable list are in `evidence/citations/`.
All direct TCSlib citations are public at the base. The extended import probe adds
`#check @Turing.FinTM` and its axiom print to the supplied probe. The six forbidden canonical R3
rows and other files' private declarations are absent from the added source.

## Duplication and lint

The before-screen is **byte-identical** to the supplied base: 1,854 declarations, 1,689 pairs,
534,736 reproduced characters, no pair on `Hierarchy`. The after-screen is pending; therefore
**new copies: not yet determined**, not certified absent.

For `sph_inclusion`, name and statement-family searches were run with `git grep` on the exact
base and every open PR head observed in this session:

| PR | Read-only fetched head |
|---|---|
| 211 | `f239dafd09f060ec87ca0992103ae8eb48bce31e` |
| 210 | `fff0430c7c9db136e60ed14b069e972c2ea56fc8` |
| 208 | `d01c56a4ed9487fa2c84c7d62470cee2c6bef960` |
| 195 | `40553944417ba519d736985a300e61fbd13eaffc` |

The searches found no `sph_` collision or published eventual-domination inclusion to cite
instead. The supplied semantic probe was rerun before adding the private: `exact?` did not
close the inclusion, square bound, logarithmic-domination or linear-to-PSPACE goals; it found
exactly `logSpace_le_succ` and `LOGSPACE_subset_PSPACE` for the other two goals, as in the
pre-ship. Its four intentional failures are recorded as a nonzero diagnostic probe, not a
failed source check. The mandated inclusion proof is copied with the required private name.

Campaign lint: **0 FAIL, 80 WARN over 111 files**, identical to the baseline. File style lint:
the same one finding as the base, the module docstring's missing `## Main definitions`.

## Escalations, implementation paragraphs and continuation

No mathematical obstruction has been established for checkpoint 1. No promotion is requested
for its mandated helper. Checkpoint 8's optional padding escalation has not yet been reached.
The source's other open obligations remain work to do, not claimed API obstructions.

Proposed implementation paragraphs for the maintainer, **for the completed proofs rather than
as claims about this checkpoint**:

- `space_hierarchy`: **Implementation.** Absorb the finite exceptional prefix for inclusion.
  For strictness, compute the radius under `embedSilentRetTM`, rewind the radius and input,
  initialize the fixed self-universal machine's record, and use the configuration-count runner
  with `summaryTag`. The clock belongs to the runner. Test a halted endpoint and emit the
  opposite verdict, with foreign inputs rejected before the radius computation. Normalize a
  putative smaller-space decider through the published space-preserving normal form and coding
  clauses, fix its per-code universal constant, then pad only the payload.
- `LOGSPACE_ssubset_PSPACE`: **Implementation.** Apply the space hierarchy to `logSpace` and
  `n + 1`, using the integer-logarithm domination lemma, and transport strictness through the
  published linear-space inclusion into `PSPACE`.
- `SPACE_linear_ne_NP`: **Implementation.** Use the polynomial-time quadratic-padding map and
  `preimage_mem_NP`. A linear-space decider for the precisely padded language would turn an
  assumed equality of linear space and `NP` into the reverse of the linear/quadratic hierarchy.
  If that padded decider cannot be assembled from the named hosts, retain the admission and
  escalate its exact missing statement.

The supplied base sorry inventory is included verbatim in `evidence/logs/base-sorries.txt`;
all out-of-scope admissions remain untouched. Resume from the checkpoint commit and the
committed source, not from the unchecked drafts.
