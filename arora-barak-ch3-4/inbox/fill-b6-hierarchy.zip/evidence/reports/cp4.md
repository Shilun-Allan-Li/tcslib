# B6 hierarchy fill — checkpoint 4

**Partial delivery.** Checkpoints 1, 2, 3, 4, 5 and 7 are reached. The full diagonal
machine now has a uniform space proof on every rich-alphabet input, and its binary diagonal
language is proved to belong to `SPACE g`. The private construction is admission-free.
The public hierarchy body is the next checkpoint; the logarithmic corollary still inherits its
admission. Checkpoint 8 remains last.

The final after-screen and the final 52-module downstream sweep remain pending. This is an
immediate checkpoint, not a final-verification attestation. No hierarchy obstruction is asserted.

## Identity and authorized scope

- Exact base: `e6bc196838b4e2675e4214306c730e7404624ab8`.
- Base source blob: `287acce8326a1de271dfa6be2cc3776f3a2caa32`.
- Local branch: `fill/b6-hierarchy`, created at exactly the base after the ancestor check passed.
- Checkpoint commit: `f32dc1709aca0c6c24ca08c9492f5269b4a8ccf8`.
- No rebase, merge, cherry-pick, push or PR.
- Only tracked change: `TCSlib/Complexity/SpaceComplexity/Hierarchy.lean`, in regions (a)–(d).
  All four public statements are byte-identical to the base. The complete `space_universal`
  docstring/body and its module main-results entry are byte-identical. Imports are exactly the
  five base imports plus the four required overlay imports.
- Source: 2,521 lines, four public declarations and 42 private declarations. No new admission,
  no forbidden R3 row, no directly cited foreign private, and no added line over 100 characters.

The dispatch files were verified against the supplied manifest before reading:

| File | SHA-256 |
|---|---|
| `b6-fill-hierarchy.md` | `3c92e156529b5a7f1f061e3b1d5beaf0918fe3b11355e34362441b56c36bd357` |
| `fill-environment-addendum.md` | `9f5bd5e74bb767e50a6e7a372e98a5567998ec14be432c1dfb7ff8856eb9bd28` |

The first local serialization appended a newline; writing the fetched bytes exactly corrected
that local serialization before verification/read. Neither remote artifact mismatched.

## Checkpoints and declarations

| Checkpoint | Status |
|---|---|
| 1 | Overlay, inclusion and permitted documentation cleanup committed and checked |
| 2 | Validation, returning radius capture, both rewinds and framed initializer committed and checked |
| 3 | Complete simulation suffix: runner, test, all three exits, opposite answer and head envelope |
| 4 | Full validation/capture/rewind/record/suffix composition; all-input space bound; binary language in SPACE g |
| 5 | Normalization and universal-machine window lemma committed and checked |
| 6 | Open: `space_hierarchy` body |
| 7 | Corollary body filled; conditional helper axiom-clean; public theorem still inherits the hierarchy admission |
| 8 | Open; its allowed padding-decider escalation has not yet been reached |

| Private declaration | Role |
|---|---|
| `sph_inclusion` | Mandatory inclusion proof via the finite exceptional prefix and SPACE.mono_const |
| `sph_code_window` | Normalize a smaller-space decider, pad only its payload, and obtain the universal halted window summary |
| `sph_sq_le_two_pow` | Mandatory square-versus-exponential arithmetic |
| `sph_logSpace_dom` | Mandatory eventual logarithmic domination |
| `sph_logspace_ssubset` | Mandatory corollary from an explicit hierarchy hypothesis |
| `sphRightTM` | Permitted one-step input-head move leaf |
| `sph_right_run` | Framed run, positive input position, first return and unchanged work heads |
| `sphEmitTM` | Permitted one-step verdict emitter leaf |
| `sph_emit_run` | One-symbol emission and halt, with unchanged work heads |
| `sphDigit` | Finite validator predicate on the rich alphabet |
| `sph_fold_valid` | The fold accepts exactly digit-embedded binary words, including empty input |
| `sph_validation_run` | Framed validation with first-exit cut and unchanged work heads |
| `sphWitnessSel` | Witness bank after record, radius and both scratch banks |
| `sph_witness_cap` | Radius tape is outside the witness selection |
| `sph_radius_run` | Returning capture, complete output buffer, framed endpoint, silence and per-run space bound |
| `sphEmptySel` | Empty selection for the zero-work-tape input rewind |
| `sph_input_rewind_run` | Lifted input rewind via R1 on an arbitrary positive input position |
| `sphRewindsTM` | Published seams joining the right move, input rewind and radius rewind |
| `sph_rewinds_run` | Framed composed rewind endpoint and first return, with radius head at zero |
| `sphInitSel` | Initializer selection preserving the runner and witness banks |
| `sph_initial_record` | Framed initial record on the full tape plan, with first return and head envelope |
| `sph_select_fields` | Shared R1 selected-configuration readings via reconstruction; also used by the initializer |
| `sphRunnerSel` | Runner bank: record zero plus its separate scratch bank |
| `sph_runner_run` | Published runner by R1, including cuts, all exits, record endpoint and displacement bound |
| `sphRecordSel` | Single record-tape selection for the test |
| `sph_test_run` | Published record test by R1 with complete physical frame |
| `sphEmitContract` | Existing one-step emitter packaged as a stationary-head contract |
| `sphVerdictTM` | Published two-exit seam from record test to opposite-bit emitters |
| `sph_verdict_run` | Tested bit complement and shared head envelope |
| `sph_summary` | Returned stopped record aligned with a certified halting summary by stop uniqueness |
| `sph_seam_heads` | Common absolute interval transported through a published single-exit seam |
| `sph_seam_avoids` | A dispatched seam cannot revisit a different left-hand exit |
| `sph_written_record` | Shared record-boundary argument after an interior layout write |
| `sphRunnerTailTM` | Three published seams route halted, left and exhausted runner exits |
| `sph_runner_tail_run` | Complete three-exit suffix run and absolute head bound |
| `sph_suffix` | Uniform initial-record-to-halt suffix with opposite acceptance and displacement bound |
| `sph_record_suffix` | Initializer and complete runner suffix joined on the disjoint tape plan |
| `sph_record_size` | Record, radius digits and fixed overhead bounded by `(4*k+9)*g(n)` |
| `sph_valid_machine` | Complete post-validation machine and absolute head envelope on embedded words |
| `sph_halt_contract` | Public first-halt theorem packages a known bounded run as a branch contract |
| `sph_validated_machine` | Published two-exit validation branch, total on all rich inputs, with a summed space bound |
| `sph_diagonal_language` | Total Boolean language, alphabet reduction and membership in SPACE g |

Every new private lemma has a literal Proof sketch; the small selection/leaf definitions have
public-facing descriptions. The remaining open public bodies are `space_hierarchy` and
`SPACE_linear_ne_NP`, both with literal **Proof sketch** text. The untouched F6 body remains
`sorry`. No other source file or admission was changed.

## Tape plan and first phases

The physical tape count is `KI + KR + M.k + 2`: record 0, radius 1, initializer scratch
2 through `KI + 1`, runner scratch `KI + 2` through `KI + KR + 1`, then the witness bank.
The initializer selects only its own bank plus record/radius. The witness selection starts
strictly after both scratch banks, so its dirty endpoint cannot enter the future runner bank.

The validator uses `inputFoldTM_run_ofCfg` and recognizes exactly the image of `digitEmb`.
The returning radius phase chooses a first halting time of the constructibility witness,
lifts its binary run, and calls `embedSilentRetTM_run`. Its last emitted bit is included.
The radius tape ends at the buffer's length; outside the witness selection and radius tape,
all tape contents and heads are the supplied arbitrary frame. The physical output is unchanged.
Its proved per-run space bound is

```text
(KI + KR + M.k + 2) * (c * g |x| + |bits (g |x|)| + 1).
```

Here `KI` and `KR` are the initializer and runner scratch counts, `M` is the constructibility
witness, `c` its space coefficient, `g` the target bound, and `x` the binary input. This bound
is for the radius phase only, not yet a full-machine space claim.

The one-step right move handles a witness stopped at input position zero, and also handles the
right boundary. The lifted zero-tape input rewind runs by `embedEmitTM` on an empty selection.
`sphRewindsTM` joins it and `rewindTM` by two published general-configuration seams.
`sph_rewinds_run` restores input position one and radius-head position zero, preserves every
work-tape cell and the accumulated output, and proves the first-return cut. Empty captured
words are admitted. The initializer then calls `exists_recordInitTM` by R1, reading the selected
configuration through reconstruction and public field equations. Only its scratch bank must be
blank; the endpoint changes record tape zero only, with the published time and head bounds.

## Simulation suffix

`sph_suffix` applies `exists_configWindowRunnerTM` at the fixed finite machine with `Fin 3`,
`summaryTag` and initial tag zero. The tape-zero record and separate runner scratch bank are
selected by R1. On a halted exit, the returned record for an unspecified stopped round count
is matched to the certified halting summary by `windowRun_stop_unique`. The published record
test checks state `none` and tag one; the emitter writes the complementary bit. Left and
exhausted exits emit true. Exhaustion does not inspect the unspecified record.

Three existing single-exit seams handle the runner's three anchors. This is a composition of
published hosts, not a new seam transformer. The two verdict-test anchors use the published
two-exit seam and its branch contract. Every head stays within

```text
(CR + CT) * (recordLength M.k |x| s + 1)
```

of its initial physical position throughout the suffix. `CR` is the runner coefficient,
`CT` the record-test coefficient, `M` the fixed simulated machine, `x` its binary input and
`s` the radius. These constants do not depend on the input's code part. The suffix halts with
one output symbol on every valid initial record. Whenever `M` halts within the radius at its
configuration-count bound, that symbol is the opposite of its singleton-true acceptance.

## Full-machine space and binary packaging

The strengthened `sph_radius_run` additionally bounds every intermediate physical head by the
absolute ambient frame position plus `c*g(n) + |bits(g(n))|`. Selected heads use the public
space-to-window bound; the capture head uses output-prefix monotonicity; frame heads do not
move. `sph_rewinds_run` retains the published rewind envelope: displacement at most
`|bits(g(n))|+1`, with all cells preserved. The generic seam head lemma is moved earlier solely
so both compositions can share it.

Let `K = KI + KR + G.k + 2` be the physical tape count, `G` the constructibility witness,
`c` its space coefficient, `M` the fixed simulated machine, `n` the binary input length,
`s = g(n)`, and `L = recordLength M.k n s`. Put `C = CI + CR + CT`, the sum of the
initializer, runner and record-test head coefficients. The proof establishes, term by term:

```text
radius capture:       rR = c*s + |bits(s)|
through both rewinds: rW = rR + |bits(s)| + 1
record/suffix motion: rS = C*(L + |bits(s)| + s + 1)
combined radius:      rW + rS
                    <= (c + 3 + C*(4*M.k + 9))*s = B*s.
```

The arithmetic uses `|bits(s)| <= s`, `posWidth n <= 2*logSpace n <= 2*s`, the public formula
`L = M.k*(2*s+1) + posWidth n + M.k + 4`, and `1 <= s`. It does not cite the pending #208
bit-length lemma. Constants are chosen from fixed machines before the input and its code are
known. The record and both scratch banks are initially blank because the radius capture frames
them, and the initializer changes only record zero.

The actual `FinTM` starts the published input fold and uses `seamCompTM₂`/`Contract.branch`.
On a valid embedded word it enters the above machine; on a foreign symbol it emits false.
The branch contract uses a first halt of the valid run without changing its completed output.
Every work head is in `[-B*g(n), B*g(n)]` through the final halt, including on invalid rich
inputs. The public interval theorem gives

```text
D.spaceUsed(init ys, haltTime ys) <= K*(2*B*g(|ys|)+1).
```

The public halted-run space theorem extends this to every time. Applying
`decidesInSpace_of_alphabetReduction` yields a binary decider within
`c'*(K*(2*B*g(n)+1)+1)`. `SPACE.mono_const` absorbs this into `SPACE g`, since

```text
K*(2*B*g(n)+1)+1 <= (K*(2*B+1)+1)*g(n).
```

The language is the set of binary inputs on which the chosen total output of `D` is true.
The indicator equation is obtained through the already imported
`FinTM.toFinNDTM_haltsWithin_and_accepts_iff`: the permitted one-symbol emitter, instantiated
at that indicator bit, identifies acceptance using the public ND embedding/acceptance
readings. No indicator definition is unfolded. The shorter published
`LogProg.indicator_eq_decide` is outside the frozen nine-import closure, so no import was added
and no duplicate generic indicator lemma was introduced. Moving that convenience reading into
a lower imported module would simplify this local consumer calculation.

New notation in these displayed bounds: `rR`, `rW`, `rS` are the three intermediate radii;
`B` is their fixed combined coefficient; `c'` is alphabet reduction's coefficient. Other
symbols are defined immediately above the calculation. This checkpoint proves the actual
existence of the diagonal language in `SPACE g`, not only a conditional packaging statement.

## Normalization and contradiction arithmetic already proved

The second private is `sph_code_window`. It normalizes an arbitrary smaller-space decider by
`one_work_tape_binary_spaceUsed` and `exists_codeTM_spaceUsed`, then uses the supplied universal
machine's per-code simulation contract. It returns a padded input and the exact time
`U₀.configBound x.length (g x.length)`, together with the correct one-bit output, space at most
`g x.length`, and the exact halted window-run summary at the next round.

The constant is chosen after the code and its universal constant:

```text
A = C * (c₁ * c₀ + c₁ + 1)
C * (c₁ * (c₀ * f n + 1) + 1)
  ≤ C * (c₁ * (c₀ * f n + f n) + f n)
  = A * f n ≤ g n.
```

Here the first inequality uses `1 ≤ f n`, and the final inequality uses the domination
threshold. The payload is `List.replicate N₀ true`, so the paired input's length is at least
`N₀`; the code itself is unchanged. The published halting-space theorem supplies the
configuration-bound time, and `windowRun_summary_of_halts` supplies the window conclusion.
No statement of `space_hierarchy` is used in this private proof.

The new symbols in this calculation are the existing proof parameters: `c₀` is the original
decider's coefficient, `c₁` the normal-form coefficient, `C` the fixed code's universal
simulation coefficient, `A` their domination coefficient, and `N₀` the resulting threshold.


## Environment and verification

Part 1 preflight passed before bootstrap: 57.747 GiB free on the work filesystem and 9.075 GiB
MemAvailable. No cgroup controller was exposed. The first attempt to read a cgroup limit failed;
the logged fallback used `/proc/meminfo`. `/tmp` is tmpfs; all compilation/cache temporary files
used the disk-backed task `TMPDIR` instead. A later resource check still found over 51 GiB free
and 8.6 GiB MemAvailable.

Lean 4.25.0 was installed from the official release archive into a fresh task directory. It
starts normally (commit `cdd38ac5115bdeec5f609e9126cce00f51ae88b3`); no loader shim or borrowed
compiled artifact was used. Every present package matched both its manifest revision and URL;
absent optional packages were not named by the module order. The cache was fetched for exactly
the 63 derived Mathlib roots, never unfiltered.

The first narrowed cache fetch succeeded. A subsequent probe was rejected because its source
resolved through a symlink outside the repository root. Conservatively, the single cleaned
retry was taken: package/build configuration artifacts were removed, preflight and pin checks
repeated, and the same roots fetched again using the freshly obtained 1,057 archives. A physical
`FillProbes/CacheProbe.lean` then passed. No empty `.olean` was found. This was a path-validation
error, not evidence of corrupt cached proofs.

The fresh **220-module bootstrap passed**, with exactly the supplied 26 sorry warnings in ten
modules. Per-module wall time and peak RSS are recorded using `os.wait4` in
`evidence/logs/bootstrap/`; summed module time was 2,834.864 seconds, maximum RSS 2,994,428 KiB.
The cache probe and every other Lean invocation also have separate resource logs. Only one
agent-started Lean invocation ran at a time; the permitted low-priority text screen ran beside it.
No `lake build`, unfiltered cache fetch or module timeout was used.


The draft checks build each composition before landing it. `cp4-edit` and the final
`cp4-seal-final` and `cp4-controls-final` series check the owned module and facade after every landed proof edit.
All final source, full-seal, controls, extended-host and axiom checks pass. A first seal attempt
caught a repeated ND embedding field occurrence that `rw` had left to definitional reduction;
explicit public simplification of both transport occurrences fixed it. All diagnostic failures
and repairs remain in the evidence.

The 68-definition seal includes every reached other-file TCSlib `def`, including the extra
ND acceptance/embedding operations, `posWidth`, `counterValue` and finite-state instances.
The four primitive simp attributes are removed. There are 72 effective controls: 64 delta
controls, cardinality usage controls for the two enumerated rewind-state instances, recursive equation usage controls for `windowRun` and `NDTM.runWith`, and four
primitive simp controls. All pass unsealed and fail sealed. The generic whole-instance delta goal was initially ineffective for two enumerated Fintype structures (eta contraction); their cardinality goals replace it and detect the seal. Both raw runs are retained. Compiler-generated projections
and recursor abbreviations are not implementation definitions.

The elaborated walk records 854 outside constants, 258 from TCSlib, with no directly cited
foreign `_private` constant. The extended host probe adds 146 checks/axiom prints to the
supplied probe. The inspection table enumerates every rewriting/reduction tactic site,
including complete multiline arguments (443 tactic sites). Two explicit bundled-field simp readings, optimized out of the proof terms, are additionally listed and checked. Own lets/leaves and public equations are the only
explicit reduction arguments.

| Axiom walk | Result |
|---|---|
| All 42 private declarations, including the complete diagonal-language construction | Subsets of `propext`, `Classical.choice`, `Quot.sound`; no `sorryAx` |
| `space_hierarchy` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `LOGSPACE_ssubset_PSPACE` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |
| `SPACE_linear_ne_NP` | `propext`, `sorryAx`, `Classical.choice`, `Quot.sound` |

The three source sorry warnings remain the untouched F6 and the two open target bodies.
The remaining public hierarchy admission is not used by any machine or diagonal-language
construction proof. Its conditional logarithmic corollary is already present.

## Duplication and lint

The before-screen is byte-identical to the supplied base: 1,854 declarations, 1,689 pairs and
534,736 reproduced characters, no pair on Hierarchy. The frozen-checkpoint-1 screen has exactly
the same pair lines. The frozen-checkpoint-2 screen completed with 1,871 declarations,
1,693 pairs and 536,116 reproduced characters: four added pairs, none at 90% or higher.
Its only added cross-file pair is the five-field `Cfg.ext`/public-map-state-reading idiom in
`sph_rewinds_run`, 82% against `Cfg.mapState_mapState`. The framed endpoint also changes input
and radius head, so it does not restate that public pure relabeling lemma. The other three
pairs are between this file's distinct leaves/bank selections. Full dispositions are in
`screen-cp2-classification.txt`. For completed screens, **new copies: none**.

A frozen-checkpoint-3 screen is running, one at a time under `nice -n 10`. The final head
still needs its final screen and 52-module downstream sweep; those attestations remain pending.

Every new private lemma has name and statement-family searches against the exact base and all
four open PR heads observed during this task:

| PR | Read-only fetched head |
|---|---|
| 211 | `f239dafd09f060ec87ca0992103ae8eb48bce31e` |
| 210 | `fff0430c7c9db136e60ed14b069e972c2ea56fc8` |
| 208 | `d01c56a4ed9487fa2c84c7d62470cee2c6bef960` |
| 195 | `40553944417ba519d736985a300e61fbd13eaffc` |


The initial route searches and probes cover `sph_inclusion`, the square, logarithmic domination,
and strictness helper. The mandated route copies are renamed exactly as required. The separate
normalization/window exact? probe fails to find a published replacement. The corollary probe
finds the owned admitted public target, which is not a usable proved external lemma.

For checkpoint 2, nine exact? goals run against the base overlay imports and own definitions
only, deliberately excluding the new lemma proofs: right move, emitter, fold characterization,
validation run, witness-cap disjointness, radius capture, input rewind, paired rewinds and
initial record. All nine fail to find an exact proof. The companion per-lemma git-grep logs
record the named hosts that are cited in the implementation. The diagnostic probe's nonzero
exit is expected and is not an owned-source failure. The nine probes are in `CP2Semantic.lean`.

For checkpoint 3, ten further apply? probes run against the base overlay plus the checked
checkpoint-2 declarations and new machine definitions, excluding all ten checkpoint-3 lemma
proofs. The per-lemma name/statement searches cover all four observed open PR heads. Hosts
found by those searches are cited, rather than copied. The apply? results are recorded in
`CP3Semantic.lean` and its raw diagnostic log. No complete published replacement was found. Generic logical candidates and partial proofs are not replacements. The initial unrestricted exact? and apply? diagnostics were interrupted after failing to return promptly; the final apply? run used Lean's standard 200,000-heartbeat per-declaration search budget and completed in 55.129 seconds. Its expected nonzero exit, partial suggestions and any search-budget failures are retained. This diagnostic does not certify absence of equivalents; the base/open-PR statement searches were also reviewed. No wall-clock timeout was imposed on an owned module check, and no item was stopped.

Checkpoint 4 has six further per-lemma searches and exact? probes, using the base overlay
and earlier checkpoint proofs while excluding all six new lemma proofs. All six fail to find an exact published replacement (15.833 seconds total); there are no heartbeat failures. The expected diagnostic exit is nonzero.
The two strengthened earlier lemmas still consume their already searched capture/rewind hosts.
The generic first-halt contract cites `exists_first_halt`; it does not reimplement first-halt
selection. The six searches also cover `Contract.ofSegment`, record/suffix compositions,
validation hosts and the indicator-reading alternative. Raw searches/probes are shipped.

Campaign lint: **0 FAIL, 81 WARN over 111 files**. The sole additional campaign warning is
file length above 1,000 lines. Justification: the brief explicitly imposes no size cap and
restricts ownership to this one file's private region; splitting into another source file would
violate that ownership. The standalone linter reports the same size threshold and the baseline
missing Main definitions heading. No new proof-sketch or long-line finding remains.

## Escalations and continuation

No hierarchy API or mathematical obstruction has been established. Potential promotion candidates are `sph_select_fields`, the generic seam head/avoidance
consumers, and `sph_written_record`; no matching public lemma was found. These are consequences
of public readings, not replacements for foreign private implementations. The next work is
the public hierarchy contradiction, then the final padding corollary or its named escalation. Checkpoint 8 remains last. Its optional padding-decider
escalation must name the missing statement if used. Draft files are continuation material;
only the committed Hierarchy source and patch series are landed code.

Proposed implementation paragraphs for the maintainer, **for the completed proofs rather than
as claims about this checkpoint**:

- `space_hierarchy`: **Implementation.** Absorb the finite exceptional prefix for inclusion.
  For strictness, compute the radius under `embedSilentRetTM`, rewind the radius and input,
  initialize the fixed self-universal machine's record, and use the configuration-count runner
  with `summaryTag`. The clock belongs to the runner. Test a halted endpoint and emit the
  opposite verdict, with foreign inputs rejected before the radius computation. Normalize a
  putative smaller-space decider through the published space-preserving normal form and coding
  clauses, fix its per-code universal constant, then pad only the payload.
- `LOGSPACE_ssubset_PSPACE`: **Implementation.** Apply the space hierarchy to `logSpace` and
  `n + 1`, using the integer-logarithm domination lemma, and transport strictness through the
  published linear-space inclusion into `PSPACE`.
- `SPACE_linear_ne_NP`: **Implementation.** Use the polynomial-time quadratic-padding map and
  `preimage_mem_NP`. A linear-space decider for the precisely padded language would turn an
  assumed equality of linear space and `NP` into the reverse of the linear/quadratic hierarchy.
  If that padded decider cannot be assembled from the named hosts, retain the admission and
  escalate its exact missing statement.

The supplied base sorry inventory is included verbatim in `evidence/logs/base-sorries.txt`;
all out-of-scope admissions remain untouched. Resume from the checkpoint commit and the
committed source, not from the unchecked drafts.
