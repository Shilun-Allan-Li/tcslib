from pathlib import Path
import hashlib,json,subprocess,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[2]
META=json.loads((ROOT/'evidence/final/metadata.json').read_text())
BASE=META['base']; SOURCE=META['source']; FILES=list(META['files'])
OUT=Path('/private/tmp/fill-ram-input-startup-r2.zip')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==SOURCE
members={}
for f,meta in META['files'].items():
 data=git('show',f'{SOURCE}:{f}');assert sha(data)==meta['sha256']
 assert data==(ROOT/f).read_bytes()
 members[f]=data;members['evidence/base/'+f+'.txt']=git('show',f'{BASE}:{f}')
for label,owner in [('inputbit','TCSlib/Complexity/TuringMachine/Build/InputBit.lean'),('startup','TCSlib/Complexity/RAMSimulation/Sim/Startup.lean')]:
 log=(ROOT/f'evidence/logs/final/{label}-native.log').read_text()
 assert log.rstrip().endswith('EXIT 0') and 'warning:' not in log and 'error:' not in log
 assert 'SOURCE_SHA256 '+sha(members[owner]) in log
for p in (ROOT/'evidence/logs/final').rglob('*.log'):
 if p.name == 'tactic-definition-audit-01.log':continue
 text=p.read_text()
 if 'SOURCE_SHA256 ' not in text:continue
 wanted=1 if 'negative-expected-fail' in p.name else 0
 assert text.rstrip().endswith('EXIT '+str(wanted)),p
for name,count in [('inputbit',425),('startup',722)]:
 text=(ROOT/f'evidence/logs/final/{name}-sealed.log').read_text()
 assert f'SEALED|{count}' in text
 assert 'ADMISSION_SET_OK' in (ROOT/f'evidence/logs/final/{name}-axioms.log').read_text()
assert 'DIRECT_TACTIC_DEFINITION_AUDIT_OK' in (ROOT/'evidence/logs/final/tactic-definition-audit.log').read_text()
patch=git('diff','--full-index','--binary',BASE,SOURCE,'--',*FILES)
members['source.patch']=patch
with tempfile.TemporaryDirectory(prefix='ram-input-r2-final-replay-') as tmp:
 dest=Path(tmp)
 for f in FILES:
  p=dest/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(git('show',f'{BASE}:{f}'))
 pp=dest/'source.patch';pp.write_bytes(patch)
 subprocess.run(['git','apply','--check',str(pp)],cwd=dest,check=True)
 subprocess.run(['git','apply',str(pp)],cwd=dest,check=True)
 for f in FILES:assert (dest/f).read_bytes()==members[f]
members['evidence/patch-replay.log']=b'git apply --check: exit 0\ngit apply: exit 0\nAll four replayed files equal the delivered source bytes.\n'
members['evidence/BASE_COMMIT']=(BASE+'\n').encode();members['evidence/SOURCE_COMMIT']=(SOURCE+'\n').encode()
members['evidence/source-history.log']=git('log','--oneline',f'{BASE}..{SOURCE}')
members['evidence/owned-and-readers-diff-stat.log']=git('diff','--stat',BASE,SOURCE,'--',*FILES)
for directory in ['evidence/logs/final','evidence/logs/bootstrap']:
 for p in (ROOT/directory).rglob('*'):
  if p.is_file() and p.name != 'tactic-definition-audit-01.log':members[str(p.relative_to(ROOT))]=p.read_bytes()
# These unchanged prerequisites were already elaborated into the isolated cache for checkpoint 1.
# Current owners and their reverse import closure have fresh final logs above.
final_modules={str(Path(f).with_suffix('')) for f in FILES}
final_modules.update((ROOT/'evidence/logs/final/downstream-order.txt').read_text().splitlines())
oldorder=(ROOT/'evidence/logs/checkpoint-1/downstream-order.txt').read_text().splitlines()
for i,m in enumerate(oldorder):
 if m in final_modules:continue
 p=ROOT/f'evidence/logs/checkpoint-1/downstream/{i:03d}-{m.replace("/","_")}.log'
 assert p.read_text().rstrip().endswith('EXIT 0'),p
 members[f'evidence/cache-bootstrap/{p.name}']=p.read_bytes()
for rel in [
 'evidence/InputBitAxioms.lean','evidence/StartupAxioms.lean',
 'evidence/InputBitSealed.lean','evidence/StartupSealed.lean',
 'evidence/InputBitSealNegative.lean','evidence/StartupSealNegative.lean',
 'evidence/ForeignDefs.lean','evidence/StartupForeignDefs.lean','evidence/TacticDefAudit.lean',
 'evidence/probes/foreign-definitions.json','evidence/probes/startup-foreign-definitions.json',
 'evidence/probes/private-declarations.json','evidence/probes/tactic-argument-heads.json',
 'evidence/runtime/check.py','evidence/runtime/final_checks.py','evidence/runtime/refresh_startup_seal.py',
 'evidence/runtime/package_final.py','evidence/logs/preflight.log','evidence/logs/manifest-pins.log',
 'evidence/logs/process-waits.log','evidence/logs/round1-zip-verification.log',
 'evidence/logs/bootstrap-order.txt','evidence/logs/mathlib-roots.txt','evidence/final/metadata.json']:
 members[rel]=(ROOT/rel).read_bytes()
ledger=json.loads((ROOT/'evidence/probes/private-declarations.json').read_text())
rows='\n'.join(f'| `{f}` | {m["lines"]} | `{m["sha256"]}` |' for f,m in META['files'].items())
ledger_text='\n'.join(f'- `{d["name"]}` ({d["file"]}): {d["role"]}' for d in ledger)
walks='\n'.join('\n'.join(v) for v in META['walks'].values())
report=f'''# Input-bit and RAM startup — final round 2 delivery

Both requested theorems are proved modulo only the explicitly permitted word-arithmetic and
keyed-assignment rows. There are no admissions in either owned file. All final checks pass.

Base: `{BASE}` (`ram/readers-2`, PR #375), fetched read-only. Source commit:
`{SOURCE}` on local branch `codex/fill-ram-input-startup-r2`. The source branch was neither
rebased nor pushed. Rules and brief were read at
`e40383d88d79e23026c95e20608ee8827d45e59b`. The earlier dispatch bundle was checked in round 1;
round 2 retrieved the round-1 archive from the exchange, verified all 189 member checksums,
and applied its patch to this new base before continuing. This archive's patch is against
the new base, not the old round-1 base.

Delivery destination: `exchange/pass-shelat-ch5-8`,
`arora-barak-ch3-4/inbox/fill-ram-input-startup/fill-ram-input-startup-r2.zip`.
The delivery checkout is separate from the source checkout and uses pull/rebase before push;
no force push or PR is part of this delivery. Checkpoint 1 was already delivered there as
`fill-ram-input-startup-r2-checkpoint-1.zip`, SHA256
`292c5b6e49086ba4b8b59b60107f49f7a0c7ac31db040ab6d43e14fb1d5b0467`,
exchange delivery commit `fb6682950fbb2a683fa8be54a20d9dc9cddb2f96`.

## Targets and admitted dependencies

| Target | Result | Reachable direct admissions |
| --- | --- | --- |
| `Turing.exists_inputBitTM` | Proved, statement byte-identical | `Turing.exists_wordIntTM`, `Turing.exists_wordSignTM` |
| `WordRAM.Sim.exists_startup` | Proved, statement byte-identical | `Turing.exists_keyAssignTM`, `Turing.exists_wordIntTM` |

Neither proof reaches an admitted `Build/RecordTable` declaration. The dependency walks traverse
types and values, identify constants that directly use `sorryAx`, and assert the exact permitted
sets. The printed results are:

```text
{walks}
```

## Input-bit construction and reuse

The equality comparator against empty scratch handles width zero. The permitted sign row
handles negative indices. The private unequal-width numeric comparator scans little-endian
words while retaining the highest differing bit pair, then uses two catalog backward skips
to restore both heads. The catalog comparator supplies equality, not this numeric verdict.

For an in-range nonnegative index, catalog copy and successful increment prepare the seek
word. The existing two-tape native seek is embedded on scratch tapes 3/4; catalog clear restores
those tapes. A fixed stationary native-input verdict selects the permitted zero/one integer
writers. No catalog leaf returns that verdict without moving a head. Calls compose through
`Contract.ofReaches`, `seq`, `branch` and `inPhase`; no replacement dispatch host was written.
The seek's linear input-time bound is kept separate from its small work radius.

### Requested shared lemma

`inputBit_increment_value` is the explicitly authorized fresh private induction:
`incFixed w = some v → Nat.ofDigits 2 (v.map Bool.toNat) = Nat.ofDigits 2 (w.map Bool.toNat) + 1`.
It uses the published nil/false-cons/true-cons equations of `incFixed`, without copying the
private proof in CodeSimulator. **Requested shared lemma:** publish `incFixed_value` in
Build/Convention and retire both private copies, as requested in the dispatch.

## Startup construction and bounds

The returning silent embedding captures the width witness's output at its first live exit.
Its visited-set lemmas count the witness bank exactly once. The sum over the actual tape
partition gives the witness's original space plus a constant times `|bits W| + 1`.

A fixed one-step native advance ensures positivity even when the witness finishes at input
position zero. The published input rewind then returns to position one. The published input
length row runs in its own blank bank; its logarithmic work radius is preserved separately
from its linear time through the contract composition.

The ordinary preparation uses ten selected tapes: the eight simulation tapes, the captured
width master, and a reusable counter. It rewinds the master, copies it to the counter, expands
`W` zero cells using `expandTM`, rewinds the register and copies its zero word to the two
other registers. A fixed advancing writer supplies the key's `a` cells; a second counter copy
and expansion supply its `W` cells. The writer is routed through `ReturnContract.release`,
retaining its positive first return rather than treating a cyclic anchor as an ordinary exit.
The permitted integer row installs the key of `-1`.

Copying the full binary length over the zero register pads short words and temporarily leaves
long words beyond width `W`. A catalog walk guided by the width register reaches `W + 1`.
A fixed two-action leaf erases the preceding cell and restores the head; catalog backward
skips then restore both heads. The register predicate only needs the two delimiters, so the
unused tail remains framed beyond cell `W`. `startup_padded_low` proves the register is exactly
the low-width length word, including width zero. No truncating-copy host or suffix-clearing
routine is introduced.

The permitted keyed assignment installs the singleton in the buffered empty table. The range
fact follows from `inRange_iff` for every positive key width, including `W = 0, a = 1`.
All first-eight heads return to zero, both scratch tapes are globally blank, and physical output
is empty in either output mode. `startup_finished_encodes` verifies the complete initial RAM
encoding.

The only new startup transition tables are the one-step native advance and the two-step
previous-cell erasure; their docstrings state the missing catalog operation. All other runtime
composition uses the existing contract and seam hosts. The native length radius plus the
ordinary preparation's time-derived radius is `O(W + |bits |x|| + 1)`. The final shared seam
space sum therefore gives **`sw + C * (W + |bits |x|| + 1)`**, with coefficient exactly one on
`sw`. Time is weakened to `tw + C * (|x| + W² + 1)` using `|bits n| ≤ n` and `W ≤ W²`.

## Authorized exact readers and imports

The tier-2 missing-reader exception was used only for these four pure restatements, all with
proof `rfl`, beside the definitions in their home files, without simp attributes:

| Reader | Home file | Reads |
| --- | --- | --- |
| `Turing.Cfg.select_eq` | `TCSlib/Complexity/TuringMachine/Build/Embed.lean` | Exact selected configuration, including empty source output |
| `Turing.Contract.embed_pre` | `TCSlib/Complexity/TuringMachine/Build/Contract/Embed.lean` | Embedded precondition |
| `Turing.Contract.embed_time` | same | Embedded chosen time |
| `Turing.Contract.embed_post` | same | Embedded physical endpoint |

These were absent from the pinned base, including PR #375, before they were added. Every
existing declaration in both home files is unchanged. Every other new library declaration
is private and in an owned file. There are no new library files or global simp attributes.

InputBit adds `Build.Contract` for shared composition and `Build.SeamLayout` to expose the
existing BufferWords off-buffer blank theorem. Startup adds `Build.Contract` for shared
composition, `Build.InterpreterStartup` for the published returning capture/initialization
lemmas, and `RAMSimulation.WordSize` for the published monotonic space API through its import
closure. The original imports are retained.

## Searches, foreign definitions and published readers

Searches covered the imported catalog, contract, counter-loop, input-call/input-length,
embedding, word-arithmetic, keyed-table, buffer/layout and core bit-vector APIs before adding
helpers. The declaration ledger below gives each helper's particular role; the following
families describe the existing facts searched and used by those helpers.

- Comparison: catalog comparison is equality. The new numeric verdict uses a fresh list
  induction and the public `Nat.ofDigits_cons` arithmetic; restoration cites `skipBackTM`.
- Increment: searched Convention and CodeSimulator. The needed value law was private and is
  reproduced only under the dispatch's explicit exception; the other increment facts cite
  the published equations, nonoverflow characterization and `incFixed_length`.
- Buffer replacement: inspected `wordPatch_append`, `wordPatch_self`, `wordPatch_twice`,
  `wordPatch_frame` and `wordPatch_replicate`. The general unequal-length prefix overlay is a
  private cell identity; adjacent appending cites `wordPatch_append`. Existing buffer clipping
  and off-buffer blank lemmas are cited rather than duplicated.
- Fixed actions: searched the catalog input and tape actions, writer/scan/seek rows, and their
  contracts. No row supplies the stationary input verdict, positive-input advance, or previous-
  cell erase/return operation. Their small leaves use the public one-step action equations.
- Layout: inspected `joinFields_singleton`, `joinFields_cons_cons`, `fieldsTape_of_nonneg`,
  `fieldsTape_of_neg`, `fieldsTape_of_length_le`, `tableFields_eq` and table predicate readers.
  The empty/singleton keyed-table facts specialize those APIs, without invoking admitted record
  table machines.
- Bit-vector and input-length arithmetic: uses `bvBits_def`, `bvBits_length`, core signed-value
  and bit-access lemmas, `BitVec.ofInt_natCast`, `Nat.testBit_eq_inth`, `counterValue_eq`,
  `counterValue_bits`, `counterOverhead_le` and `length_bits_le_self`.
- Runtime calls: `copyTM`, `clearTM`, `incrementTM`, `compareTM`, `skipBackTM` and their contracts
  are read through the contracts' pre/time/post/lo/hi equations. `walkTM_contract` uses its
  published pre/time/post equations. `rewindTM` and `writeAdvTM` use their public framed runs.
- Contract hosts: `Contract.ofReaches` uses its published field equations and time bound;
  `Contract.seq`, `branch`, `inPhase` use their field equations and trajectory compositions;
  `Contract.embed` uses the four authorized/new and existing public interfaces;
  `ReturnContract.release` uses its pre/time/post equations. Private stage/route records carry
  specifications only; their machines are the shared hosts.
- `Cfg.mapState`, `Cfg.bindState`, `Cfg.init`, `Cfg.inputSymbol` and `MultiTapeTM.initCfg` use
  their published field, congruence, initialization and input-symbol readers. Whole-tape
  equalities are proved pointwise using the tape-cell reader.
- `MultiTapeTM.step`, `Action.apply`, `inputMoveAction`, `tapeAction` use the published step and
  action field readers. Runs use zero/one/successor equations and `catalog_trace_run` with
  `catalogTrace_eq`; no foreign transition table is unfolded.
- `embedEmitTM` and `embedSilentRetTM` use the public run/first-return lemmas. Forwarding
  configurations use `embedEmitCfg_eq`, `embedEmitCfg_mapState_eq`, selected/unselected field
  equations and `embedEmitCfg_select`. Silent capture uses `embedSilentCfg_initCfg`,
  `embedSilentCfg_cap`, returning visited-set equality, selected-bank visited sets, the frame
  singleton and the capture-space bound.
- `expandTM`, `counterLoopCfg` and `counterLoopBody` use `expandTM_run` and the published body
  reconstruction/state/input/tape/head/output equations. The loop's amortized bound is cited.
- `WordAt`, `ScratchBlank`, `ReachesWithin`, `TableAt`, `KeyTableAt`, `TableOf`, `Encodes` and
  `InRange` use their `_iff` readers. `wordWrite`, `keyTableWrite`, `keyAssign`, `keyFields`,
  `keyTableLength`, `keyBits`, `initMem` and `XCfg.init` use their published apply/definition
  equations. The transparent word constructor abbreviation is converted using core bit-vector
  equations.
- Visited space uses `spaceUsed_eq_sum`, `spaceUsedByTape_eq_card`, embedding visited-set and
  frame lemmas, `spaceUsed_mono`, `spaceUsed_le_of_abs_le`, and
  `seamCompTM_spaceUsed_le_add_ofCfg`. General-configuration seam run and first-return lemmas
  supply the final machine's exact endpoint and strict cut.

The sealed mirrors make all valid public ordinary imported TCSlib definition names
irreducible: 425 for InputBit and 722 for Startup, including unused definitions. They remove
three active definition simp rules and assert every seal. Startup's inventory separately lists
one generated hygienic internal matcher whose name is not a source-level API identifier;
it is excluded from the attribute list. Private imported names, projections and transparent
aliases are outside the ordinary-definition inventory. The strict tactic-argument audit
checks that direct rewrite/simp arguments name no foreign/core/Mathlib definitions; it excludes
procedural simproc hints and nested term arguments. Core/Mathlib values reduce only through
permitted computation or published equations.

## Verification and environment

Final checks, all in `evidence/logs/final/`:

| Check | Exit/result |
| --- | --- |
| Both reader home modules and contract facade | 0 |
| InputBit and Startup native elaboration | 0, **zero warnings** |
| Both complete sealed replays | 0, seal guards passed |
| Both axiom/dependency walks | 0, exact allowed admission sets |
| Direct tactic-definition audit | 0 |
| Both negative seal controls | **1 expected**, `rfl` cannot read sealed `bvBits` |
| Sim/Phases, Simulation, Classes, RAMSimulation facade, TuringMachine facade | 0 |
| Literal target statements and existing declarations | frozen |
| Patch check plus actual four-file replay | 0; bytes match delivered SHA256 |

The five downstream modules are exactly the reverse import closure of the owned files after
excluding the standing-workflow root `TCSlib` facade; both owned files are checked separately.
The isolated import cache was bootstrapped earlier: 129 TCSlib modules in the complete required
closure, 53 present Mathlib roots, the initial 45-module bootstrap plus additional prerequisites.
The archive includes those unchanged-prerequisite logs separately as cache-bootstrap evidence;
final proof validation is exclusively in the final logs, whose source hashes match this delivery.
Unrelated base admissions may warn in prerequisite logs. No owned proof emits an admission warning.

Every Lean launch checks the machine-wide executable-name count below three, runs at most one
of ours, and uses `nice -n 10`, Lean `-j4`, and the isolated
`.lake/fill-ram-input-startup-r2-oleans` tree. The process log contains {META['process_samples']}
count samples, including {META['wait_samples']} wait/recheck samples at the limit. No `lake build`
was run. Exact package revisions match the manifest. This host is macOS ARM64; native
`vm_stat`, `memory_pressure` and `/usr/bin/time -l` replace Linux procfs/time fields. Preflight
records 12 CPUs, 18 GiB RAM, about 117.8 GiB free disk and conservative headroom above 3 GiB.
Native time/RSS records accompany every check.

InputBit is {META['files'][FILES[0]]['lines']} lines and Startup is
{META['files'][FILES[1]]['lines']} lines. Both exceed 1,500 lines, as permitted by the tier-2
addendum; the maintainer can split them at landing. All proofs over twenty lines have named
proof sketches. New library documentation contains no campaign labels. Unrelated generated
blueprint changes and the untracked evidence directory are excluded from the source commit
and patch.

```
{META['diff_stat'].rstrip()}
```

## Delivered source hashes

| File | Lines | SHA256 |
| --- | ---: | --- |
{rows}

## New private declaration ledger

There are {len(ledger)} new private declarations across the two owned files. Each role below
comes from its declaration's documentation; the delivered source contains its proof and named
API references.

{ledger_text}
'''
members['REPORT.md']=report.encode()
(ROOT/'evidence/final/REPORT.md').write_text(report)
manifest='\n'.join(f'{sha(data)}  {name}' for name,data in sorted(members.items()))+'\n'
members['SHA256SUMS']=manifest.encode()
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(OUT) as z:
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split(None,1);assert sha(z.read(name))==digest
receipt={'file':str(OUT),'bytes':OUT.stat().st_size,'members':len(members),'sha256':sha(OUT.read_bytes()),'source_commit':SOURCE}
(ROOT/'evidence/final/archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
