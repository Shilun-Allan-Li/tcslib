from pathlib import Path
p = Path("evidence/StartupSealed.lean")
old = p.read_text()
attrs = old[old.index("\nattribute [local irreducible]"):old.index("\nset_option maxHeartbeats")]
attrs = attrs.replace(" Turing.Contract.ofReaches ", " ")
guard = old[old.index("\nopen Lean Elab Command Meta in\nrun_cmd do", old.index("end WordRAM.Sim")):]
src = Path("TCSlib/Complexity/RAMSimulation/Sim/Startup.lean").read_text()
i = src.index("\nset_option maxHeartbeats")
p.write_text("import Lean\n" + src[:i] + attrs + src[i:] + guard)
