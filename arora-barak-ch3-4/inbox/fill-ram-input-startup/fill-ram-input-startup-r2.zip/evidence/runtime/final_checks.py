from check import check
from pathlib import Path
import sys
checks = [
 ('TCSlib/Complexity/TuringMachine/Build/Embed', 'final/home-embed.log'),
 ('TCSlib/Complexity/TuringMachine/Build/Contract/Embed', 'final/home-contract-embed.log'),
 ('TCSlib/Complexity/TuringMachine/Build/Contract', 'final/contract-facade.log'),
 ('TCSlib/Complexity/TuringMachine/Build/InputBit', 'final/inputbit-native.log'),
 ('TCSlib/Complexity/RAMSimulation/Sim/Startup', 'final/startup-native.log'),
 ('evidence/InputBitSealed', 'final/inputbit-sealed.log'),
 ('evidence/StartupSealed', 'final/startup-sealed.log'),
 ('evidence/InputBitAxioms', 'final/inputbit-axioms.log'),
 ('evidence/StartupAxioms', 'final/startup-axioms.log'),
 ('evidence/TacticDefAudit', 'final/tactic-definition-audit.log'),
]
for m, label in checks:
 if check(m, label): sys.exit(1)
for m, label in [('evidence/InputBitSealNegative', 'final/inputbit-negative-expected-fail.log'),
                 ('evidence/StartupSealNegative', 'final/startup-negative-expected-fail.log')]:
 if check(m, label) == 0: sys.exit('Negative seal control unexpectedly passed')
for i, m in enumerate(Path('evidence/logs/final/downstream-order.txt').read_text().splitlines()):
 if check(m, f'final/downstream/{i:02d}-{m.replace("/", "_")}.log'): sys.exit(1)
print('FINAL_CHECKS_PASS', flush=True)
