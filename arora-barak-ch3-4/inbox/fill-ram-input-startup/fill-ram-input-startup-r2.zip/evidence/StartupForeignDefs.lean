import Lean
import TCSlib.Complexity.RAMSimulation.Sim.Encoding
import TCSlib.Complexity.TuringMachine.Build.Embed
import TCSlib.Complexity.TuringMachine.Build.InputLength
import TCSlib.Complexity.TuringMachine.Build.Contract
import TCSlib.Complexity.TuringMachine.Build.InterpreterStartup
import TCSlib.Complexity.RAMSimulation.WordSize
open Lean Elab Command Meta in
run_cmd do
  let env ← getEnv
  let st ← liftTermElabM getSimpTheorems
  for (n, ci) in env.constants.toList do
    let .defnInfo _ := ci | continue
    let some mod := env.getModuleIdxFor? n |>.bind (env.header.modules[·]?) | continue
    unless mod.module.toString.startsWith "TCSlib." do continue
    if isPrivateName n || env.isProjectionFn n || getReducibilityStatusCore env n == .reducible then continue
    logInfo m!"SEAL_DEF|{n}|{st.toUnfold.contains n || st.isLemma (.decl n)}"
