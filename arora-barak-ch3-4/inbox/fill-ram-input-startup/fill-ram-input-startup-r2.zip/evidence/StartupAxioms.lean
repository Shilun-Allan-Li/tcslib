import Lean
import TCSlib.Complexity.RAMSimulation.Sim.Startup
open Lean Meta Elab Command

/-- The constants reachable from `root` (types and values) whose own value or type uses `sorryAx`
directly. -/
partial def directAdmissions (env : Environment) (root : Name) : Array Name := Id.run do
  let mut seen : NameSet := {}
  let mut stack : Array Name := #[root]
  let mut out : Array Name := #[]
  while h : stack.size > 0 do
    let n := stack.back
    stack := stack.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | none => pure ()
    | some ci =>
      let refs := ci.type.getUsedConstants ++ (ci.value?.map (·.getUsedConstants)).getD #[]
      if refs.contains ``sorryAx then out := out.push n
      for r in refs do
        unless seen.contains r do stack := stack.push r
  return out

elab "#walk " id:ident : command => do
  let env ← getEnv
  let n := id.getId
  let adm := directAdmissions env n
  logInfo m!"WALK|{n}|{adm.toList}"


#print axioms WordRAM.Sim.exists_startup
#walk WordRAM.Sim.exists_startup
open Lean Elab Command in
run_cmd do
  let admits := directAdmissions (← getEnv) `WordRAM.Sim.exists_startup
  let allowed : List Name := [`Turing.exists_wordIntTM, `Turing.exists_keyAssignTM]
  unless admits.toList.all (· ∈ allowed) && allowed.all (· ∈ admits.toList) do
    throwError "UNEXPECTED_ADMISSIONS|{admits.toList}"
  logInfo "ADMISSION_SET_OK"
