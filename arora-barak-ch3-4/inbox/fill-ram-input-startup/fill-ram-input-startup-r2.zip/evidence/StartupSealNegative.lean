import TCSlib.Complexity.RAMSimulation.Sim.Startup
attribute [local irreducible] Turing.bvBits
example : Turing.bvBits (0 : BitVec 0) = [] := by rfl
