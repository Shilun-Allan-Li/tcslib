# fill-ram-input-startup: frontier delivery

This is a partial fill. Neither requested existential machine theorem is proved. The two original admissions, their statements, their proof sketches, and the imports are byte-identical to the base. The delivery adds one private comparison function and ten proved private lemmas to the two owned files. It does not claim that either machine has been constructed.

Base: `cb44316a22c258628bf571da8c84b72c347ee493`, fetched read-only from `complexity/ram-simulation` in `Shilun-Allan-Li/tcslib`. Source commit: `3d382cd982f8cd7e51e8e579a479db62b0cf1d08`. Work branch: `codex/fill-ram-input-startup`, created at that exact commit and never rebased. Only the delivery archive is to be pushed, to `arora-barak-ch3-4/inbox/fill-ram-input-startup/` on `exchange/pass-shelat-ch5-8`.

The fetched handoff commit was `9f49ba0f3`. The bundle SHA-256 matches `211b22c1e8f98a5ecc529ff23fb868b3920dc38d6323fc3b9afa5a4309ae8bfd`; README matches `d719daba166000997e39dee957ba16c2c2b0e4777d30f98a96c92d497849182d`. See `evidence/logs/input-sha256.log`. The first two sections, the tier 2 addendum, environment addendum, policy, maintainer rules, design and gate 162 notes were read.

## Target status and continuation frontiers

| Target | Status | Frontier |
|---|---|---|
| `Turing.exists_inputBitTM` | Still `sorry` | Comparison semantics, overflow existence and native-seek packaging are proved. The numeric increment law needed by the prescribed route exists only as a private lemma elsewhere. The comparison machine, its restoration, branching and the complete composite have not been constructed. |
| `WordRAM.Sim.exists_startup` | Still `sorry`; E-READER | The singleton table and final encoding are proved conditional on the signed range fact. At `W = 0`, `a = 1`, the necessary `InRange 1 (-1)` has no usable published reader in the permitted closure. The startup machine stages and their combined bounds have not been constructed. |

### Startup: the signed-range boundary

`TableOf` requires the stored cell `-1` to satisfy `WordRAM.InRange (W + a) (-1)`. The brief permits `W = 0`, `a = 1`. The definition in `Programs/WordRAM/Steps.lean` makes `InRange 1 (-1)` true, but has no `_iff` reader. The only general public producer in this closure is:

```lean
WordRAM.inRange_of_abs_le
  (hB : 2 * B < (2 : ℤ) ^ W) (h : |v| ≤ B) : InRange W v
```

For width one and `v = -1`, its premises cannot both hold: `|(-1 : ℤ)| ≤ B` forces `B ≥ 1`, while `2 * B < 2 ^ 1` forces `B < 1`. `evidence/RangeStrictBound.lean.txt` proves this incompatibility. The direct boundary proof passes unsealed and fails when `InRange` is irreducible; the deliberate `change` in that diagnostic control is not used in library code. See `RangeNative.lean.txt`, `RangeSealed.lean.txt` and their logs.

Requested shared reader, beside `InRange` in `Steps.lean`:

```lean
theorem inRange_iff (W : ℕ) (v : ℤ) :
    InRange W v ↔ -(2 : ℤ) ^ W ≤ 2 * v ∧ 2 * v < (2 : ℤ) ^ W
```

Alternatively, a public `inRange_neg_one (hk : 1 ≤ k) : InRange k (-1)` suffices for this boundary. The delivered `startup_inRange_neg_one_of_two_le` uses only the existing public producer and handles widths at least two. No definition has been unfolded to cross the missing boundary, and the frozen target has not been changed.

### Input bit: increment-value citation frontier

The route copies the unsigned position, increments it and feeds the result to `exists_inputSeekTM`. The required value law is already proved as the private `canonStageInc_value` in `TuringMachine/CodeSimulator.lean`:

```lean
∀ (w v : List Bool), incFixed w = some v →
  Nat.ofDigits 2 (v.map Bool.toNat) = Nat.ofDigits 2 (w.map Bool.toNat) + 1
```

It is outside the owned file's import closure and is private. The brief permits adding existing `Build/*` imports, not an import of `CodeSimulator`; importing that file would not publish the private lemma. The public increment interfaces in the permitted closure provide case equations, overflow and length, and machine-run contracts, but no numeric value law. The environment inventory in `DependencyWalk` lists every public type directly mentioning `incFixed`, including generated equations for diagnostic completeness; no proof cites a generated equation.

COMMON's cite-do-not-reprove rule rules out copying or rederiving the existing proof. This is the citation/API frontier for the prescribed route; no impossibility claim is made about other constructions. Requested shared change: promote the existing value lemma to `Build/Convention.lean`, beside its other `incFixed` laws, for example as `incFixed_value` with the displayed statement. `evidence/logs/reader-gap-sources.txt` records the exact source signatures and file hashes. No proved material from that private proof was copied.

After these interfaces are available, substantial construction work remains: realize the unequal-width comparison as a framed leaf row; connect sign/range branches, copy, increment, seek, clear and constant-write rows; and assemble startup's silent witness, register preparation, length count and table installation with their bounds. The private seek adapter is ready to feed `Contract.ofReaches`; this delivery does not yet instantiate a composite contract.

## New private declarations and reuse searches

All are in the owned files. No public declaration, source file, import, axiom, `@[simp]` attribute or admission was added.

| Private declaration | Role and facts searched/cited |
|---|---|
| `Turing.inputBitOrder` | Pure finite-state order update on unequal little-endian bit lists. Searched the imported catalog's equality comparison and scan interfaces and Mathlib's `Nat.ofDigits` comparison/digit lemmas; no existing row gives this unequal-width order. This definition is a list function, not a machine or a private host. |
| `Turing.inputBitOrder_spec` | Correctness, including high zero padding and an incoming tie-break bit. Uses Mathlib's `Nat.ofDigits_cons`/`ofDigits_nil` and Boolean equations. |
| `Turing.inputBitOrder_lt` | Strict unsigned comparison by starting the remembered order at false; cites the preceding specification. |
| `Turing.inputBit_seek_row` | Packages the native seek's fieldwise endpoint as `ReachesWithin`; cites `reachesWithin_iff`, `Cfg.ext`, `Fin.ext`. Searched the contract and input-call interfaces before this adapter. |
| `Turing.inputBit_increment_exists` | Chooses a successor of unchanged width from nonoverflow. Directly cites `incFixed_eq_none_iff_replicate`, `incFixed_length`, `Option.ne_none_iff_exists'`; does not reprove the increment's arithmetic law. |
| `Turing.inputBit_exists_seek_row` | Chooses the existing native seek witness and applies the preceding adapter, using `wordAt_iff`. No replacement input device is built. |
| `WordRAM.Sim.startup_initMem_neg_one` | Direct application of `initMem_def` and `Function.update_self`. |
| `WordRAM.Sim.startup_initMem_of_ne` | Direct application of `initMem_def` and `Function.update_of_ne`. |
| `WordRAM.Sim.startup_tableOf` | Singleton-table correctness conditional on the range fact. Uses `tableOf_iff` and the two initialization equations. Searched `Extended`, `Steps`, `Sim/Encoding` and the word-RAM range consumers. |
| `WordRAM.Sim.startup_inRange_neg_one_of_two_le` | Discharges the nonboundary widths via `inRange_of_abs_le` and Mathlib's power monotonicity. |
| `WordRAM.Sim.startup_encodes_of_tapes` | Turns the eight final tape facts into the initial encoding, conditional on the range fact, using `encodes_iff`, `XCfg.init_def` and `startup_tableOf`. |

No transition table, private host or duplicate proved-material copy was introduced. The pure comparison function and its specification are original local glue. The existing private increment proof was located and left uncopied. All public statements and existing proof text in the owned files remain unchanged; `evidence/logs/freeze.log` contains the repository declaration-freeze tool's output and an additional byte comparison of each entire original theorem declaration/body.

## Other-file definitions and their readers

| Definition encountered | How read |
|---|---|
| `Turing.WordAt` | `wordAt_iff` |
| `Turing.ReachesWithin` | `reachesWithin_iff` |
| `Turing.incFixed` | `incFixed_eq_none_iff_replicate` and `incFixed_length`; the missing numeric law is reported above |
| `WordRAM.initMem` | `initMem_def` |
| `WordRAM.Sim.TableOf` | `tableOf_iff` |
| `WordRAM.XCfg.init` | `XCfg.init_def` |
| `WordRAM.Sim.Encodes` | `encodes_iff` |
| `WordRAM.InRange` | `inRange_of_abs_le` for widths at least two; no single-bit unfolding |
| `Turing.MultiTapeTM.runFrom` | Only the run facts supplied by `exists_inputSeekTM`; endpoints compared by structure extensionality |
| `Turing.FinTM.bufferTape` | Appears in the seek's published premise, converted with `wordAt_iff`; no unfolding |
| `Turing.bvBits`, `WordRAM.Sim.keyBits`, `Turing.KeyTableAt` | Kept opaque in table/encoding statements; no definition read |

`WordRAM.wd` is an abbreviation, used as permitted by policy. Core/Mathlib facts are read by their equation lemmas. The sealed-helper probe marks all thirteen ordinary foreign heads listed in its guard irreducible and confirms each seal is active; all delivered helper proofs elaborate under these seals.

## Axioms and reachable admissions

The actual imported constants were inspected with `#print axioms` for both targets and `Lean.collectAxioms` for the eleven private declarations. A full scratch walk traverses types and values and lists every reachable constant whose value directly contains `sorryAx`.

| Root | Reachable admitted declarations |
|---|---|
| `Turing.exists_inputBitTM` | `[Turing.exists_inputBitTM]` — the unchanged frontier itself |
| `WordRAM.Sim.exists_startup` | `[WordRAM.Sim.exists_startup]` — the unchanged frontier itself |
| Every new private declaration | `[]` |

Each target's printed axiom set is `propext`, `Classical.choice`, `Quot.sound`, `sorryAx`. The new helpers use only subsets of the first three. No helper reaches any job A/B admission or any admission in `Build/RecordTable`. There is no proved target for which an allowed-dependency admission list is needed. See the complete `DependencyWalk` source and log.

## Verification

All required scoped checks finished. The initial real-Mathlib probe and 45-module import bootstrap passed (46 checks). The additional prerequisite/downstream pass and its positive scratch probes passed (90 checks); the deliberate sealed range control returned 1 as expected. After removing a redundant tactic warning, both owners, both scratch proof probes and all five downstream modules/facades were rechecked against the final source (9 checks, all exit 0).

| Final-source check | Exit |
|---|---|
| `TCSlib/Complexity/TuringMachine/Build/InputBit` | 0 |
| `TCSlib/Complexity/RAMSimulation/Sim/Startup` | 0 |
| `evidence/HelperSeals` | 0 |
| `evidence/DependencyWalk` | 0 |
| `TCSlib/Complexity/RAMSimulation/Sim/Phases` | 0 |
| `TCSlib/Complexity/RAMSimulation/Simulation` | 0 |
| `TCSlib/Complexity/RAMSimulation/Classes` | 0 |
| `TCSlib/Complexity/RAMSimulation` | 0 |
| `TCSlib/Complexity/TuringMachine` | 0 |

Final-source logs contain no error diagnostics. The owners each have exactly their existing target admission warning; the new helper code and sealed-helper probe have no warnings. Axiom/dependency assertions passed for all eleven private declarations. The native range control and strict-bound incompatibility proof passed; the sealed range control failed at the deliberate definitional `change`, as expected. `git diff --check` passed. See `final-source-results.json`, `final-results.json`, `SUMMARY.json`, `freeze.log` and the corresponding individual logs. The final source logs include source SHA-256 values.

```text
 TCSlib/Complexity/RAMSimulation/Sim/Startup.lean   |  64 ++++++++++++
 .../Complexity/TuringMachine/Build/InputBit.lean   | 115 +++++++++++++++++++++
 2 files changed, 179 insertions(+)
```

The source change is confined to the two owned files; the final committed diff stat is included under `evidence/logs/`. There are two existing `sorry` occurrences, one in each target, and none in the added helper code. Both target sketches and module introductions were retained because their machine proofs remain pending. Neither file exceeds 1,500 lines.

The downstream set contains both owners, `Sim/Phases`, `Simulation`, `Classes`, and the `RAMSimulation` and `TuringMachine` facades. Its complete prerequisite closure has 129 modules. The root `TCSlib` is excluded in accordance with `campaign/maintainer/WORKFLOW.md` §2 and the repository downstream driver; both requested area facades are included. The order and additional-prerequisite lists are shipped.

## Environment and process accounting

This host is macOS arm64, so native `sysctl`, `vm_stat`, `memory_pressure`, `df -k` and `mount` replace Linux `nproc`, cgroup and `df -B1`/`df -T` readings. Initial preflight: 12 logical CPUs; 19,327,352,832 bytes (18 GiB) physical memory; native system-wide memory free percentage 68%; APFS with 124,993,268 KiB (about 119.2 GiB) available at the worktree and `/private/tmp`. A conservative macOS headroom proxy, physical memory minus anonymous, wired and compressor pages, gives 5.90 GiB initially and 4.19 GiB at the later long-module recheck; the native free percentage at that recheck was 57%. These readings exceed the resource floors. The proxy and native percentage are macOS adaptations, not Linux cgroup measurements. Raw readings are in `preflight.log`. No memory-backed scratch directory was used.

The installed unmodified toolchain is `leanprover/lean4:v4.25.0`. No runtime shim, Lake build, cache executable or cache fetch was run. The environment addendum's populated-cache alternative was used: `.lake/packages` is a symlink to `/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`. Every package present was checked against this base's manifest URL and revision; documentation packages absent from that cache are recorded as ABSENT. The check ends `PASS: every present package matches manifest`. No absent package is imported by this fill's verification order. All 53 direct Mathlib roots required by the final closure are cached; the zero-sized-olean scan found none. The initial real-Mathlib import probe passed.

TCSlib itself was bootstrapped from source into this fill's own `.lake/fill-ram-input-startup-oleans`. No other session's TCSlib oleans, snapshot, or composite `LEAN_PATH` was used. The initial 45-module import closure was built first, then 84 additional modules needed for the downstream closure. Logs were written in place under `evidence/logs/` from process start. Each check used `scripts/lean_check_tree.sh`, `lean -j4`, `nice -n 10` and `/usr/bin/time -l`, with start/end times, exit codes and maximum resident memory. There were no self-imposed module timeouts.

Only one Lean process belonging to this fill ran at a time. Before every start, the driver counted machine-wide processes whose executable basename is `lean`, waiting while the count was at least three. It recorded 32 full-capacity samples in 3 wait events, totalling 65.315 seconds from each first waiting sample to its subsequent launch sample. The maximum observed pre-start/wait count was 3; every launch sample was below three. The log is `process-waits.log`. The maximum resident set reported by any shipped check log was 3,892,903,936 bytes (3.63 GiB). No overlapping checks of this fill, process-count deviation, crash, OOM or ENOSPC was observed. This records pre-start observations, not a continuous trace of other fills.

The managed worktree appeared with unrelated generated blueprint changes immediately after creation; these were preserved, excluded from the source commit, patch and bundle, and are not delivered. The source commit's parent is the dispatched base and its diff touches only the two owned files. Worktree setup and Git operations used the host's normal sandbox approvals; none was rejected. These macOS-native resource readings and the permitted populated-package symlink are the environment adaptations.

## Payload and handoff

The archive contains this report, the full two owned source files, a patch and format-patch against the base, a Git bundle with the base as prerequisite, SHA256SUMS, verification order files, scratch probes as `.lean.txt`, runtime scripts and check logs. No olean, package tree, toolchain, compiled binary, or compiled shim is shipped. No target was closed, so no target checkpoint archive was created.

The source branch is local only. Delivery uses a separate exchange checkout, an artifact-only commit, `git pull --rebase origin exchange/pass-shelat-ch5-8` before push, and `git push origin HEAD:exchange/pass-shelat-ch5-8`, without force. No PR is opened and nothing is pushed to `complexity/ram-simulation`.
