from pathlib import Path
import subprocess, hashlib, json, re
root=Path.cwd()
ib=Path('TCSlib/Complexity/TuringMachine/Build/InputBit.lean')
st=Path('TCSlib/Complexity/RAMSimulation/Sim/Startup.lean')
base='cb44316a22c258628bf571da8c84b72c347ee493'
helpers={
 'Turing':['inputBitOrder','inputBitOrder_spec','inputBitOrder_lt','inputBit_seek_row','inputBit_increment_exists','inputBit_exists_seek_row'],
 'WordRAM.Sim':['startup_initMem_neg_one','startup_initMem_of_ne','startup_tableOf','startup_inRange_neg_one_of_two_le','startup_encodes_of_tapes']}
imports='\n'.join(sorted({l for p in (ib,st) for l in p.read_text().splitlines() if l.startswith('import ')}))
opts='\nset_option maxHeartbeats 0\nset_option relaxedAutoImplicit false\nset_option autoImplicit false\n'
seals=['Turing.WordAt','Turing.ReachesWithin','Turing.incFixed','Turing.FinTM.bufferTape','Turing.MultiTapeTM.runFrom','WordRAM.InRange','WordRAM.initMem','WordRAM.XCfg.init','WordRAM.Sim.TableOf','WordRAM.Sim.Encodes','WordRAM.Sim.keyBits','Turing.bvBits','Turing.KeyTableAt']
attrs='\nattribute [local irreducible] '+' '.join(seals)+'\n'
ibbody=ib.read_text().split('/-! ## Private input-position arithmetic -/')[1].split('/-- **Reading an input bit at a word\'s position.**')[0]
stbody=st.read_text().split('/-! ## Private facts about the initial memory -/')[1].split('/-- **The start-up.**')[0]
sealcode=imports+opts+attrs+'\nnamespace Turing\n'+ibbody+'\nend Turing\nnamespace WordRAM.Sim\nopen Turing\n'+stbody+'\nend WordRAM.Sim\n'
sealcode+='\nopen Lean Elab Command Meta in\nrun_cmd do\n  let env ← getEnv\n'
for n in seals:
 sealcode+=f'  match getReducibilityStatusCore env `{n} with\n  | .irreducible => logInfo m!"GUARD_ACTIVE|{n}"\n  | _ => throwError "seal inactive: {n}"\n'
Path('evidence/HelperSeals.lean').write_text(sealcode)
Path('evidence/RangeStrictBound.lean').write_text('import TCSlib.Complexity.RAMSimulation.Sim.Startup\nexample (B : ℤ) (h : |(-1 : ℤ)| ≤ B) : ¬ (2 * B < (2 : ℤ)^1) := by\n  norm_num at h ⊢\n  omega\n')
wanted=['Turing.exists_inputBitTM','WordRAM.Sim.exists_startup']+[ns+'.'+n for ns,names in helpers.items() for n in names]
source='import TCSlib.Complexity.TuringMachine.Build.InputBit\nimport TCSlib.Complexity.RAMSimulation.Sim.Startup\nimport Lean.Util.CollectAxioms\nset_option maxHeartbeats 0\n#print axioms Turing.exists_inputBitTM\n#print axioms WordRAM.Sim.exists_startup\nopen Lean Elab Command in\nrun_cmd do\n  let env ← getEnv\n  let table := env.constants.toList\n  let wanted : List Name := ['+', '.join('`'+n for n in wanted)+']\n'
source+='''  for surface in wanted do
    let roots := table.filterMap fun (n, _) =>
      if (privateToUserName? n).getD n == surface then some n else none
    unless roots.length == 1 do throwError "root count: {surface} {roots.length}"
    let root := roots.head!
    let axs ← liftCoreM <| collectAxioms root
    logInfo m!"AXIOMS|{surface}|{axs.toList}"
    let mut todo := [root]
    let mut seen : NameSet := {}
    let mut admitted : Array Name := #[]
    while !todo.isEmpty do
      let n := todo.head!
      todo := todo.tail!
      if seen.contains n then continue
      seen := seen.insert n
      let some ci := env.find? n | continue
      if let some v := ci.value? then
        if v.getUsedConstants.contains `sorryAx then
          admitted := admitted.push ((privateToUserName? n).getD n)
        todo := v.getUsedConstants.toList ++ todo
      todo := ci.type.getUsedConstants.toList ++ todo
    logInfo m!"ADMITTED|{surface}|{(admitted.qsort Name.lt).toList}"
    if surface != `Turing.exists_inputBitTM && surface != `WordRAM.Sim.exists_startup then
      unless admitted.isEmpty do throwError "helper reaches admission: {surface}"
  let incLemmas := table.filter fun (n, ci) =>
    !isPrivateName n && ci.type.getUsedConstants.contains `Turing.incFixed
  for (n, ci) in incLemmas do
    logInfo m!"PUBLIC_INCREMENT_TYPE|{n}|{ci.type}"
'''
Path('evidence/DependencyWalk.lean').write_text(source)
lines=[]
for p in (ib,st):
 orig=subprocess.check_output(['git','show',f'{base}:{p}'])
 dest=Path('evidence/base')/p; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(orig)
 marker=b'theorem exists_inputBitTM' if p==ib else b'theorem exists_startup'
 now=p.read_bytes()
 assert orig[orig.index(marker):]==now[now.index(marker):],p
 assert [l for l in orig.splitlines() if l.startswith(b'import ')]==[l for l in now.splitlines() if l.startswith(b'import ')]
 lines.append(f'{p}: original theorem declaration and body byte-identical; imports unchanged')
 run=subprocess.run(['python3','devtools/seyoon/declfreeze.py',str(dest),str(p)],text=True,capture_output=True)
 lines.append(run.stdout)
Path('evidence/logs/freeze.log').write_text('\n'.join(lines))
Path('evidence/logs/owned-diff-stat.log').write_text(subprocess.check_output(['git','diff','--stat',base,'--',str(ib),str(st)],text=True))
Path('evidence/logs/input-sha256.log').write_text('bundle expected/actual: 211b22c1e8f98a5ecc529ff23fb868b3920dc38d6323fc3b9afa5a4309ae8bfd '+hashlib.sha256(Path('/tmp/fill-ram-input-startup-bundle.md').read_bytes()).hexdigest()+'\nREADME expected/actual: d719daba166000997e39dee957ba16c2c2b0e4777d30f98a96c92d497849182d '+hashlib.sha256(Path('/tmp/fill-ram-input-startup-README.md').read_bytes()).hexdigest()+'\n')
print(Path('evidence/logs/freeze.log').read_text())
print('Generated sealed-helper, range-bound, axiom and full dependency-walk probes')
