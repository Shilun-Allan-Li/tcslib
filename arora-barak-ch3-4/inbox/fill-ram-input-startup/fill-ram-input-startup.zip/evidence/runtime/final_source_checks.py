import json,pathlib,sys
from check import check
mods=['TCSlib/Complexity/TuringMachine/Build/InputBit','TCSlib/Complexity/RAMSimulation/Sim/Startup','evidence/HelperSeals','evidence/DependencyWalk','TCSlib/Complexity/RAMSimulation/Sim/Phases','TCSlib/Complexity/RAMSimulation/Simulation','TCSlib/Complexity/RAMSimulation/Classes','TCSlib/Complexity/RAMSimulation','TCSlib/Complexity/TuringMachine']
results=[]
for i,m in enumerate(mods):
 log=f'final-source/{i:02d}-{m.replace("/","_")}.log'
 code=check(m,log);results.append({'module':m,'exit_code':code,'log':'evidence/logs/'+log})
 pathlib.Path('evidence/logs/final-source-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if code:sys.exit(code)
