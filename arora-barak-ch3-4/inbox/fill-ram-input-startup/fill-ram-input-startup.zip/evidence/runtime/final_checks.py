import pathlib,json,sys,datetime
from check import check
outcomes=[]
owned=['TCSlib/Complexity/TuringMachine/Build/InputBit','TCSlib/Complexity/RAMSimulation/Sim/Startup']
mods=owned+['evidence/HelperSeals','evidence/DependencyWalk','evidence/RangeNative','evidence/RangeStrictBound']+pathlib.Path('evidence/logs/downstream-bootstrap-order.txt').read_text().splitlines()
for i,m in enumerate(mods):
 log=f'final/{i:03d}-{m.replace("/","_")}.log'
 code=check(m,log)
 outcomes.append({'module':m,'exit_code':code,'log':'evidence/logs/'+log})
 pathlib.Path('evidence/logs/final-results.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 if code:sys.exit(code)
code=check('evidence/RangeSealed','final/range-sealed-expected-fail.log')
outcomes.append({'module':'evidence/RangeSealed','exit_code':code,'expected_exit_code':1,'log':'evidence/logs/final/range-sealed-expected-fail.log'})
pathlib.Path('evidence/logs/final-results.json').write_text(json.dumps(outcomes,indent=2)+'\n')
if code!=1:sys.exit(1)
print('Final checks passed; intentional sealed countercontrol failed as expected.',flush=True)
