from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path.cwd()
base='cb44316a22c258628bf571da8c84b72c347ee493'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
owned=['TCSlib/Complexity/TuringMachine/Build/InputBit.lean','TCSlib/Complexity/RAMSimulation/Sim/Startup.lean']
changed=subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines();assert set(changed)==set(owned)
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==base
report=Path('REPORT.md').read_text();assert '_PLACEHOLDER' not in report
if 'Source commit: `' not in report:
 report=report.replace('Work branch: `codex/fill-ram-input-startup`,','Source commit: `'+head+'`. Work branch: `codex/fill-ram-input-startup`,',1)
Path('REPORT.md').write_text(report)
package=root/'delivery/payload';package.mkdir(parents=True,exist_ok=True)
def copy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
copy(root/'REPORT.md',package/'REPORT.md')
for p in owned:copy(root/p,package/p)
for p in (root/'evidence/logs').rglob('*'):
 if p.is_file() and 'development' not in p.relative_to(root/'evidence/logs').parts:
  copy(p,package/p.relative_to(root))
for name in ['CacheProbe','HelperSeals','DependencyWalk','RangeNative','RangeSealed','RangeStrictBound']:
 copy(root/f'evidence/{name}.lean',package/f'evidence/probes/{name}.lean.txt')
for p in (root/'evidence/runtime').glob('*.py'):copy(p,package/'evidence/runtime'/p.name)
for p in owned:copy(root/'evidence/base'/p,package/'evidence/base'/(p+'.txt'))
source={'base':base,'source_commit':head,'source_branch':'codex/fill-ram-input-startup','owned_files':{p:{'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(),'lines':len((root/p).read_text().splitlines())} for p in owned},'proved_targets':[],'open_targets':['Turing.exists_inputBitTM','WordRAM.Sim.exists_startup'],'new_private_declarations':11}
(package/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
(package/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary',base,head,'--',*owned]))
(package/'patches').mkdir(exist_ok=True)
(package/'patches/0001-frontier-helpers.patch').write_bytes(subprocess.check_output(['git','format-patch','--stdout',base+'..'+head]))
subprocess.run(['git','bundle','create',str(package/'source.bundle'),base+'..codex/fill-ram-input-startup'],check=True)
r=subprocess.run(['git','bundle','verify',str(package/'source.bundle')],text=True,capture_output=True)
(package/'evidence/logs/bundle-verify.log').write_text(r.stdout+r.stderr+'EXIT '+str(r.returncode)+'\n');assert r.returncode==0
checkbase=Path('/private/tmp/ram-input-startup-patch-check-01a1ed3f');checkbase.mkdir(parents=True,exist_ok=True)
for p in owned:copy(root/'evidence/base'/p,checkbase/p)
r=subprocess.run(['git','apply','--check',str(package/'source.patch')],cwd=checkbase,text=True,capture_output=True)
(package/'evidence/logs/patch-check.log').write_text(r.stdout+r.stderr+'EXIT '+str(r.returncode)+'\n');assert r.returncode==0
# Verify the final-source log hashes against the bytes committed and shipped.
for p,i in zip(owned,[0,1]):
 rel='evidence/logs/final-source/'+f'{i:02d}-'+p[:-5].replace('/','_')+'.log'
 assert 'SOURCE_SHA256 '+hashlib.sha256((root/p).read_bytes()).hexdigest() in (package/rel).read_text()
entries=sorted(p for p in package.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(package/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(package).as_posix()+'\n' for p in entries))
zipname=root/'delivery/fill-ram-input-startup.zip'
with zipfile.ZipFile(zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(package.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(package).as_posix())
with zipfile.ZipFile(zipname) as z:
 assert z.testzip() is None
 sums=z.read('SHA256SUMS').decode().splitlines()
 for line in sums:
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 assert len(sums)==len(z.namelist())-1
 assert not any(name.endswith(('.olean','.ilean','.so','.o','.pyc')) for name in z.namelist())
 print('Entries:',len(z.namelist()),'checksums verified:',len(sums))
print('Archive:',zipname)
print('Bytes:',zipname.stat().st_size)
print('SHA256:',hashlib.sha256(zipname.read_bytes()).hexdigest())
print('Source:',head)
