/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.RAMSimulation.Sim.Encoding
import TCSlib.Complexity.TuringMachine.Build.Embed
import TCSlib.Complexity.TuringMachine.Build.InputLength

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Stage 2's simulation: the start-up

Before the first instruction, the simulating machine computes the word size `W = W (|x|)` with
the word-size witness, prepares its eight tapes and installs the start memory: the cell `-1`
holds `|x|` modulo `2^W` and every other cell `0` (`WordRAM.initMem`). This file states that
start-up for any word-size witness `Mw`; its extra tapes hold `Mw`'s tapes, and its output, which
is captured on a work tape.

## Main results

* `WordRAM.Sim.exists_startup`: the start-up reaches a configuration encoding
  `XCfg.init W |x|` within `tw + O(|x| + W² + 1)` steps and `sw + O(W + log |x| + 1)` cells,
  where `Mw` writes `Nat.bits W` within `tw` steps and `sw` cells.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (Exercise 1.9; §4.1, space-constructible functions.)
-/

namespace WordRAM.Sim

open Turing

/-! ## Private facts about the initial memory -/

/-- The marked startup entry stores the length word at the distinguished cell. -/
private theorem startup_initMem_neg_one (W n : ℕ) : initMem W n (-1) = wd W n := by
  rw [initMem_def, Function.update_self]

/-- Every other startup cell holds zero. -/
private theorem startup_initMem_of_ne (W n : ℕ) (z : ℤ) (hz : z ≠ -1) :
    initMem W n z = 0 := by
  rw [initMem_def, Function.update_of_ne hz]

/-- The singleton table is the initial memory as soon as the distinguished cell's signed
range obligation is supplied. This isolates that obligation from the tape construction.

**Proof sketch.** Use `tableOf_iff`. The singleton has distinct keys and its entry is the key
of `-1`, with the word given by `initMem_def`. For completeness, a nonzero cell must equal
`-1`, since `initMem_def` makes every other cell zero. -/
private theorem startup_tableOf (a W n : ℕ) (hr : InRange (W + a) (-1)) :
    TableOf a W {-1} (initMem W n) [(keyBits a W (-1), bvBits (wd W n))] := by
  rw [tableOf_iff]
  refine ⟨by simp only [List.map_cons, List.map_nil, List.nodup_cons, List.not_mem_nil,
      not_false_eq_true, List.nodup_nil, and_self], ?_, ?_⟩
  · intro e he
    simp only [List.mem_singleton] at he
    subst e
    refine ⟨-1, Finset.mem_singleton_self _, hr, ?_⟩
    rw [startup_initMem_neg_one]
  · intro z _ hz
    have he : z = -1 := by
      by_contra hne
      exact hz (startup_initMem_of_ne W n z hne)
    subst z
    simp only [List.map_cons, List.map_nil, List.mem_singleton]

/-- Every width at least two represents `-1` in the signed range, by the strict
absolute-value range bound. -/
private theorem startup_inRange_neg_one_of_two_le (k : ℕ) (hk : 2 ≤ k) : InRange k (-1) := by
  apply inRange_of_abs_le (B := 1)
  · have hp : (2 : ℤ) ^ 2 ≤ 2 ^ k := pow_le_pow_right₀ (by norm_num) hk
    norm_num at hp ⊢
    omega
  · norm_num

/-- The finished eight tapes encode the initial RAM configuration once the distinguished
address's range fact is supplied.

**Proof sketch.** Read the encoding with `encodes_iff` and initialization with `XCfg.init_def`.
The table clause is `startup_tableOf`; the register, length, scratch and origin clauses are the
hypotheses. The initial output is empty in either output mode. -/
private theorem startup_encodes_of_tapes {K : ℕ} {S : Type} {x : List Bool} {W : ℕ}
    (a : ℕ) (fn : Bool) (σ : Fin 8 ↪ Fin K) (o : Fin 8 → ℤ) (d : Turing.Cfg K Bool S x)
    (hr : InRange (W + a) (-1))
    (hheads : ∀ j : Fin 8, d.workTapePos (σ j) = o j)
    (htable : KeyTableAt d (σ 0) (o 0)
      [(keyBits a W (-1), bvBits (wd W x.length))])
    (hkey : ∃ w, WordAt d (σ 1) w ∧ w.length = W + a)
    (hregs : ∀ r : Fin 8, 2 ≤ r.val → r.val ≤ 4 → ∃ w, WordAt d (σ r) w ∧ w.length = W)
    (hlen : WordAt d (σ 5) (Nat.bits x.length))
    (hblank : ∀ r : Fin 8, 6 ≤ r.val → ∀ q : ℤ, d.workTapes (σ r) q = none)
    (hout : d.output = []) : Encodes a fn {-1} (XCfg.init W x.length) σ o d := by
  rw [encodes_iff, XCfg.init_def]
  refine ⟨hheads, ⟨_, htable, startup_tableOf a W x.length hr⟩, hkey, hregs, hlen, hblank, ?_⟩
  cases fn <;> simpa only [Bool.false_eq_true, if_false, if_true] using hout

/-- **The start-up.** For `a ≥ 1`, an output mode `fn` and a word-size witness `Mw`, there is a
machine with the eight tapes of `WordRAM.Sim.Encodes` first and `k'` more, and a constant `C`, such
that: whenever `Mw`, run on `x`, writes `Nat.bits W` within `tw` steps having visited at most `sw`
work cells, the machine, started at its entry on `x` with blank tapes, reaches its exit at some
time `t ≤ tw + C·(|x| + W² + 1)`, not earlier, in a configuration whose first eight tapes encode
`XCfg.init W |x|` over the cells `{-1}` with some origins, having visited at most
`sw + C·(W + log |x| + 1)` work cells. [AB09, Exercise 1.9]

**Proof sketch.**
1. Run `Mw` with its output captured on a work tape (`Turing.embedSilentTM`, its tapes and the
   capture tape among the `k'`), within `tw` steps and `sw` cells, plus the capture's
   `|Nat.bits W| + 1` cells.
2. Make the three word registers and the key register: expand `Nat.bits W` into `W` cells of `0`
   (`Turing.expandTM` with the pattern `[false]`, `O(W)` steps plus the counter overhead), copy
   it to the other registers, and extend the key register by `a` cells.
3. Rewind the input head and count `|x|` onto tape `5` (`Turing.exists_inputLengthTM`, `O(|x|)`
   steps, `O(log |x|)` cells).
4. Install the table `[(keyBits a W (-1), bvBits (wd W |x|))]`: the key by the integer-constant
   row with `c = -1`, the value by copying the low `W` bits of `Nat.bits |x|` into a register
   padded with zeros (modulo `2^W`), then the keyed assignment into the empty table.
   `TableOf` holds: `-1` is in range because `a ≥ 1`, and `initMem` is `0` elsewhere.
5. Return every head to its origin, clear the scratch tapes, and exit.
Each stage after the first costs `O(|x| + W² + 1)` steps and `O(W + log |x| + 1)` cells. -/
theorem exists_startup (a : ℕ) (ha : 1 ≤ a) (fn : Bool) (Mw : FinTM Bool) :
    ∃ (k' : ℕ) (S : Type) (_ : Fintype S) (_ : DecidableEq S)
      (R : MultiTapeTM (8 + k') Bool S) (entry exit : S) (C : ℕ),
      ∀ (x : List Bool) (W tw sw : ℕ), Mw.ComputesInTime x (Nat.bits W) tw →
        Mw.tm.spaceUsed (Mw.tm.initCfg x) tw ≤ sw →
        ∃ (t : ℕ) (o : Fin 8 → ℤ), t ≤ tw + C * (x.length + W ^ 2 + 1) ∧
          (∀ s < t, (R.runFrom (Turing.Cfg.init entry x) s).state ≠ some exit) ∧
          (R.runFrom (Turing.Cfg.init entry x) t).state = some exit ∧
          Encodes a fn {-1} (XCfg.init W x.length) (Fin.castAddEmb k') o
            (R.runFrom (Turing.Cfg.init entry x) t) ∧
          R.spaceUsed (Turing.Cfg.init entry x) t ≤
            sw + C * (W + (Nat.bits x.length).length + 1) := by
  sorry

end WordRAM.Sim
