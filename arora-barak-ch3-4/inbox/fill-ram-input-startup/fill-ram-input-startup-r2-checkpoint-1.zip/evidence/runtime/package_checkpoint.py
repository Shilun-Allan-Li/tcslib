from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = '7342f98b58704d6c25faf668ed1a64ea0b27c4af'
SOURCE = '21f1d2b3448d0877d5283db11c796b8bd99179d6'
OWNERS = [
    'TCSlib/Complexity/TuringMachine/Build/InputBit.lean',
    'TCSlib/Complexity/RAMSimulation/Sim/Startup.lean',
]
OUT = Path('/private/tmp/fill-ram-input-startup-r2-checkpoint-1.zip')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def digest(data):
    return hashlib.sha256(data).hexdigest()

order = (ROOT/'evidence/logs/checkpoint-1/downstream-order.txt').read_text().splitlines()
logs = sorted((ROOT/'evidence/logs/checkpoint-1/downstream').glob('*.log'))
assert len(logs) == len(order), (len(logs), len(order))
for p in logs:
    assert p.read_text().rstrip().endswith('EXIT 0'), p
for label in ['inputbit-native', 'inputbit-sealed', 'inputbit-axioms']:
    assert (ROOT/f'evidence/logs/checkpoint-1/{label}.log').read_text().rstrip().endswith('EXIT 0')
assert (ROOT/'evidence/logs/checkpoint-1/inputbit-seal-negative-expected-fail.log').read_text().rstrip().endswith('EXIT 1')
assert 'ALL_FOREIGN_DEFS_SEALED|425' in (ROOT/'evidence/logs/checkpoint-1/inputbit-sealed.log').read_text()
assert 'ADMISSION_SET_OK' in (ROOT/'evidence/logs/checkpoint-1/inputbit-axioms.log').read_text()

parser = ROOT/'devtools/seyoon/declfreeze.py'
tree = ast.parse(parser.read_text())
ns = {}
keep = {'KW', 'DECL', 'ANON', 'STOP', 'SCOPE'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom, ast.FunctionDef))
    or isinstance(n, ast.Assign) and all(isinstance(t, ast.Name) and t.id in keep for t in n.targets)],
    type_ignores=[]), str(parser), 'exec'), ns)

members = {}
freeze = []
ledger = []
for owner in OWNERS:
    before = git('show', f'{BASE}:{owner}')
    after = git('show', f'{SOURCE}:{owner}')
    members[owner] = after
    members['evidence/base/'+owner+'.txt'] = before
    target = 'theorem exists_inputBitTM' if 'InputBit' in owner else 'theorem exists_startup'
    def statement(data):
        t = data[data.index(target.encode()):]
        return t[:t.index(b':= by')]
    assert statement(before) == statement(after), owner
    aa = {n: (p, c) for n, p, c in ns['chunks'](before.decode())}
    bb = {n: (p, c) for n, p, c in ns['chunks'](after.decode())}
    assert {n for n, (p, _) in aa.items() if not p} == {n for n, (p, _) in bb.items() if not p}
    freeze.append(f'{owner}: public declaration names and literal target statement byte-identical; '
                  f'BASE_SHA256={digest(before)}; SOURCE_SHA256={digest(after)}')
    for name, (private, chunk) in bb.items():
        if not private or name in aa:
            continue
        doc = chunk.split('-/', 1)[0].removeprefix('/--').strip()
        role = re.sub(r'\s+', ' ', doc.split('\n\n', 1)[0])
        ledger.append(f'- `{name}`: {role}')

patch = git('diff', '--full-index', '--binary', BASE, SOURCE, '--', *OWNERS)
members['source.patch'] = patch
members['evidence/statement-freeze.log'] = ('\n'.join(freeze)+'\n').encode()
members['evidence/owned-diff-stat.log'] = git('diff', '--stat', BASE, SOURCE, '--', *OWNERS)
with tempfile.TemporaryDirectory(prefix='ram-input-r2-patch-') as tmp:
    dest = Path(tmp)
    for owner in OWNERS:
        p = dest/owner
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(git('show', f'{BASE}:{owner}'))
    pp = dest/'source.patch'
    pp.write_bytes(patch)
    subprocess.run(['git', 'apply', '--check', str(pp)], cwd=dest, check=True)
    subprocess.run(['git', 'apply', str(pp)], cwd=dest, check=True)
    for owner in OWNERS:
        assert (dest/owner).read_bytes() == members[owner]
members['evidence/patch-replay.log'] = b'git apply --check: exit 0\ngit apply: exit 0\nBoth replayed owner files match delivered SHA256 bytes.\n'

for p in (ROOT/'evidence/logs/checkpoint-1').rglob('*'):
    if p.is_file():
        members[str(p.relative_to(ROOT))] = p.read_bytes()
for rel in ['evidence/InputBitAxioms.lean', 'evidence/InputBitSealed.lean',
            'evidence/InputBitSealNegative.lean', 'evidence/ForeignDefs.lean',
            'evidence/probes/foreign-definitions.json', 'evidence/runtime/check.py',
            'evidence/runtime/checkpoint_checks.py', 'evidence/runtime/package_checkpoint.py',
            'evidence/logs/preflight.log', 'evidence/logs/manifest-pins.log',
            'evidence/logs/process-waits.log', 'evidence/logs/round1-zip-verification.log',
            'evidence/logs/bootstrap-order.txt', 'evidence/logs/mathlib-roots.txt']:
    members[rel] = (ROOT/rel).read_bytes()
for p in (ROOT/'evidence/logs/bootstrap').glob('*.log'):
    members[str(p.relative_to(ROOT))] = p.read_bytes()
for rel in ['add-buffer-words', 'add-seam-layout']:
    p = ROOT/f'evidence/logs/development/{rel}.log'
    members[str(p.relative_to(ROOT))] = p.read_bytes()
members['evidence/BASE_COMMIT'] = (BASE+'\n').encode()
members['evidence/SOURCE_COMMIT'] = (SOURCE+'\n').encode()

process = [json.loads(line) for line in (ROOT/'evidence/logs/process-waits.log').read_text().splitlines()]
waits = sum(row['lean_count'] >= 3 for row in process)
line_count = len(members[OWNERS[0]].splitlines())
stat = members['evidence/owned-diff-stat.log'].decode().strip()
report = f'''# Input/startup round 2 — checkpoint 1

This is a proved-target checkpoint, not the final r2 delivery. Work continues on startup.

Base: `{BASE}` (`ram/readers-2`, PR #375), fetched read-only. Rules and brief were read at
`e40383d88d79e23026c95e20608ee8827d45e59b`. Local source commit: `{SOURCE}` on
`codex/fill-ram-input-startup-r2`; it has not been rebased or pushed. The round-1 zip was
retrieved from the exchange, all 189 member checksums verified, and its patch applied to
this new base before continuing. The patch in this zip is against the new base.

## Targets

| Target | Status at this checkpoint |
| --- | --- |
| `Turing.exists_inputBitTM` | **Proved modulo the explicitly permitted job-A rows.** Complete finite-state construction, original statement unchanged. Native and sealed elaborations exit 0. |
| `WordRAM.Sim.exists_startup` | **Unfinished, original admission retained.** The range obligation is now proved for every positive width, including `W = 0, a = 1`. The runtime startup construction and its time/space bounds remain to be written. |

The completed reader's reachable direct admissions are exactly
`Turing.exists_wordIntTM` and `Turing.exists_wordSignTM`. Its axiom print is
`[propext, sorryAx, Classical.choice, Quot.sound]`. The dependency walk checks both the
presence of these two permitted admissions and the absence of every other admission.
It does not depend on any admitted `Build/RecordTable` declaration.

## Construction and reuse

The reader first uses the catalog equality comparator against empty scratch to handle width
zero, then the permitted sign row and the private unequal-width numeric comparator. The
numeric comparator scans little-endian digits while remembering the highest differing pair,
then composes two catalog backward skips to restore both heads. The catalog's existing
comparator tests equality, so it does not supply this numeric verdict.

For an in-range nonnegative index, the composite uses catalog copy, catalog successful
increment, the existing two-tape native seek embedded on scratch tapes 3/4, and catalog clear.
A stationary one-step native-input verdict selects the permitted zero/one integer writers.
There is no catalog leaf that returns that native-input verdict without moving a head.
All calls compose through `Contract.ofReaches`, `Contract.seq`, `Contract.branch` and
`Contract.inPhase`; no private replacement dispatch host was written. Physical-data adapters
retain exact tape frames, returned head origins, and separate time/radius bounds. In particular
the seek's `O(n)` time is never used as its work-radius bound.

Two imports were added to InputBit: `Build.Contract` for the shared composition layer, and
`Build.SeamLayout` to expose the existing `BufferWords` clipping theorem rather than proving
another buffer-outside lemma. No public declaration, public reader, or simp attribute was added.
InputBit is {line_count} lines; per COMMON's tier-2 addendum, the maintainer may split it at landing.

### Requested shared lemma

`inputBit_increment_value` proves
`incFixed w = some v → Nat.ofDigits 2 (v.map Bool.toNat) = Nat.ofDigits 2 (w.map Bool.toNat) + 1`.
This is the dispatch's explicitly authorized private lemma, proved by a fresh induction on
`w` using `incFixed_nil`, `incFixed_false_cons` and `incFixed_true_cons`. It was not copied
from CodeSimulator. Please publish the common `incFixed_value` in Build/Convention and retire
both private copies as requested in the dispatch.

### Searches before helper proofs

- Catalog comparison was checked and supplies equality, not unequal-width unsigned order.
- Catalog `copyTM`, `incrementTM`, `clearTM`, `skipBackTM`, their contracts, native seek,
  and the existing contract hosts are consumed directly.
- `wordPatch_self`, `wordPatch_twice`, `wordPatch_frame` and buffer clipping were inspected;
  the global scratch invariant uses the published buffer clipping lemma.
- Bit-vector decomposition/value proofs use core `cons_msb_setWidth`, `getLsbD_cons`,
  `toNat_cons'`, signed-value/sign-bit lemmas, and published `bvBits` readers.
- Counter values and binary lengths use `counterValue_eq`, `counterValue_bits`, and
  `length_bits_le_self` instead of re-proving their arithmetic.
- Startup's singleton table and encoding use `tableOf_iff`, `encodes_iff`,
  `initMem_def`, `XCfg.init_def`, and the newly published `inRange_iff`.

### Other-file definitions and their readers

- `bvBits`: `bvBits_def`, `bvBits_length`; `WordAt`: `wordAt_iff`;
  `ScratchBlank`: `scratchBlank_iff`; `wordWrite`: `wordWrite_apply`.
- `incFixed`: the nil/false-cons/true-cons equations, nonoverflow characterization and
  `incFixed_length`; counter value: `counterValue_eq`, `counterValue_bits`.
- `FinTM.bufferTape`: `bufferTape_nil`, `bufferTape_nat`, `bufferTape_left`, and
  `bufferTape_eq_none_of_not_mem`.
- `MultiTapeTM.step` and `Action.apply`: published step/action field readers and
  `step_of_inputMoveAction`; `inputMoveAction`: its published step reader.
- `MultiTapeTM.runFrom`: zero, one, successor, and catalog trace/run equations;
  `catalogTrace`: `catalogTrace_eq`.
- `Cfg.mapState`: its state/input/tape/head/output readers; `Cfg.bindState`: its field readers;
  `Cfg.inputSymbol`: `Cfg.inputSymbol_congr` and `FinTM.inputSymbol_at`.
- `Contract.ofReaches`: pre/post/lo/hi readers and `ofReaches_time_le`;
  `Contract.seq`, `branch`, `inPhase`: their pre/time/post/lo/hi readers.
- Catalog `copyTM_contract`, `clearTM_contract`, `incrementTM_contract`,
  `compareTM_contract`, `skipBackTM_contract`: their published field readers;
  `sweepPost` and `seekPost`: their field readers; `compareStop`: `compareStop_le`.
- `embedEmitTM`: `embedEmitTM_runFrom`; `embedEmitCfg`: `embedEmitCfg_eq`, state,
  selected-position and unselected-frame readers.
- `ReachesWithin`: `reachesWithin_iff`, `ReachesWithin.mono`.
- Startup definitions: `initMem_def`, `inRange_iff`, `tableOf_iff`, `encodes_iff`,
  `XCfg.init_def`. No missing-reader exception was needed.

The stronger replay seals **all 425 ordinary imported TCSlib definitions**, including
unused ones, and removes the three active definition simp rules. A guard checks every seal.
The negative control intentionally attempts `bvBits = []` by `rfl` and fails, exit 1.
All positive native, sealed, axiom and downstream checks exit 0.

## Verification and environment

The initial own-tree bootstrap checked 45 TCSlib modules and a real Mathlib probe; the new
buffer/SeamLayout import was bootstrapped separately. The required six downstream targets
and their missing prerequisites then checked serially: {len(order)} additional/rechecked
modules, 129 modules in the full import closure, 53 present Mathlib roots. The root TCSlib
facade is excluded by the standing maintainer workflow; the TuringMachine and RAMSimulation
facades are included. Existing admitted targets elsewhere retain their normal warnings.

Every Lean invocation went through the recorded driver: machine-wide executable-name count
below 3 before launch, at most one of ours, `nice -n 10`, Lean `-j4`, and an isolated scratch
olean tree. The process log records {waits} count samples at or above 3 (wait/recheck samples).
No `lake build` was run. The populated `.lake/packages` symlink has the exact manifest revisions.
This host is macOS ARM64, so native `vm_stat`, `memory_pressure`, and `/usr/bin/time -l`
were used instead of Linux procfs/time fields. Preflight logged 12 CPUs, 18 GiB RAM,
about 117.8 GiB free disk and conservative memory headroom above 3 GiB.

The owner statement headers are byte-identical to the base. The supplied patch passed
`git apply --check` and an actual replay against fresh copies of the two base files; both
replayed files match the delivered SHA256 bytes. Unrelated generated blueprint changes in
the source worktree were preserved and excluded.

```
{stat}
```

## New private declaration ledger

{chr(10).join(ledger)}
'''
members['REPORT.md'] = report.encode()
manifest = '\n'.join(f'{digest(data)}  {name}' for name, data in sorted(members.items()))+'\n'
members['SHA256SUMS'] = manifest.encode()
with zipfile.ZipFile(OUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
with zipfile.ZipFile(OUT) as z:
    for line in z.read('SHA256SUMS').decode().splitlines():
        sha, name = line.split(None, 1)
        assert digest(z.read(name)) == sha
(ROOT/'evidence/checkpoint-1').mkdir(parents=True, exist_ok=True)
(ROOT/'evidence/checkpoint-1/REPORT.md').write_text(report)
print(f'{OUT}: {len(members)} members, {OUT.stat().st_size} bytes, SHA256={digest(OUT.read_bytes())}')
