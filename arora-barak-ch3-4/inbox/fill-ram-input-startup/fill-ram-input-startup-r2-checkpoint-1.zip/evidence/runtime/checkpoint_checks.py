from check import check
from pathlib import Path
import sys
for m,label in [('evidence/InputBitSealed','checkpoint-1/inputbit-sealed.log'),('evidence/InputBitAxioms','checkpoint-1/inputbit-axioms.log')]:
 if check(m,label):sys.exit(1)
if check('evidence/InputBitSealNegative','checkpoint-1/inputbit-seal-negative-expected-fail.log')==0:sys.exit('Negative seal control unexpectedly passed')
for j,m in enumerate(Path('evidence/logs/checkpoint-1/downstream-order.txt').read_text().splitlines()):
 if check(m,f'checkpoint-1/downstream/{j:03d}-{m.replace("/","_")}.log'):sys.exit(1)
print('CHECKPOINT_CHECKS_PASS',flush=True)
