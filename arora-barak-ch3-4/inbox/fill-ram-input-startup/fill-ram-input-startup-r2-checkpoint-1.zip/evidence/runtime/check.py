import os, sys, subprocess, pathlib, datetime, time, json, hashlib
root=pathlib.Path(__file__).resolve().parents[2]
os.chdir(root)
olean=root/'.lake/fill-ram-input-startup-r2-oleans'
olean.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH']
env['TCSLIB_OLEANS']=str(olean)
env['TCSLIB_LEAN_SLOTS']='3'
locks=pathlib.Path.home()/'.tcslib-scratch/locks'
locks.mkdir(parents=True,exist_ok=True)
def processes():
 rows=[]
 for row in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines():
  a=row.strip().split(None,1)
  if len(a)==2 and os.path.basename(a[1])=='lean': rows.append(a)
 return rows
def check(module,label):
 with (root/'evidence/logs/process-waits.log').open('a') as f:
  while True:
   rows=processes()
   f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'module':module,'lean_count':len(rows),'pids':[x[0] for x in rows]})+'\n'); f.flush()
   if len(rows)<3: break
   time.sleep(2)
 log=root/'evidence/logs'/label
 log.parent.mkdir(parents=True,exist_ok=True)
 start=time.monotonic()
 with log.open('w') as f:
  f.write('START '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\nSOURCE_SHA256 '+hashlib.sha256(pathlib.Path(module+'.lean').read_bytes()).hexdigest()+'\n');f.flush()
  cmd=['/usr/bin/time','-l','nice','-n','10','bash','scripts/lean_check_tree.sh',module]
  r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  f.write('END '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\nEXIT '+str(r.returncode)+'\n');f.flush()
 print(f'{module}: exit {r.returncode}, {time.monotonic()-start:.1f}s',flush=True)
 if r.returncode: print(log.read_text()[-12000:],flush=True)
 return r.returncode
if __name__=='__main__':
 if sys.argv[1]=='bootstrap':
  mods=['evidence/CacheProbe']+pathlib.Path('evidence/logs/bootstrap-order.txt').read_text().splitlines()
  for i,m in enumerate(mods):
   if check(m,f'bootstrap/{i:03d}-{m.replace("/","_")}.log'):sys.exit(1)
 else:sys.exit(check(sys.argv[1],sys.argv[2]))
