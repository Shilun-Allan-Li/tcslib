# Input/startup round 2 — checkpoint 1

This is a proved-target checkpoint, not the final r2 delivery. Work continues on startup.

Base: `7342f98b58704d6c25faf668ed1a64ea0b27c4af` (`ram/readers-2`, PR #375), fetched read-only. Rules and brief were read at
`e40383d88d79e23026c95e20608ee8827d45e59b`. Local source commit: `21f1d2b3448d0877d5283db11c796b8bd99179d6` on
`codex/fill-ram-input-startup-r2`; it has not been rebased or pushed. The round-1 zip was
retrieved from the exchange, all 189 member checksums verified, and its patch applied to
this new base before continuing. The patch in this zip is against the new base.

## Targets

| Target | Status at this checkpoint |
| --- | --- |
| `Turing.exists_inputBitTM` | **Proved modulo the explicitly permitted job-A rows.** Complete finite-state construction, original statement unchanged. Native and sealed elaborations exit 0. |
| `WordRAM.Sim.exists_startup` | **Unfinished, original admission retained.** The range obligation is now proved for every positive width, including `W = 0, a = 1`. The runtime startup construction and its time/space bounds remain to be written. |

The completed reader's reachable direct admissions are exactly
`Turing.exists_wordIntTM` and `Turing.exists_wordSignTM`. Its axiom print is
`[propext, sorryAx, Classical.choice, Quot.sound]`. The dependency walk checks both the
presence of these two permitted admissions and the absence of every other admission.
It does not depend on any admitted `Build/RecordTable` declaration.

## Construction and reuse

The reader first uses the catalog equality comparator against empty scratch to handle width
zero, then the permitted sign row and the private unequal-width numeric comparator. The
numeric comparator scans little-endian digits while remembering the highest differing pair,
then composes two catalog backward skips to restore both heads. The catalog's existing
comparator tests equality, so it does not supply this numeric verdict.

For an in-range nonnegative index, the composite uses catalog copy, catalog successful
increment, the existing two-tape native seek embedded on scratch tapes 3/4, and catalog clear.
A stationary one-step native-input verdict selects the permitted zero/one integer writers.
There is no catalog leaf that returns that native-input verdict without moving a head.
All calls compose through `Contract.ofReaches`, `Contract.seq`, `Contract.branch` and
`Contract.inPhase`; no private replacement dispatch host was written. Physical-data adapters
retain exact tape frames, returned head origins, and separate time/radius bounds. In particular
the seek's `O(n)` time is never used as its work-radius bound.

Two imports were added to InputBit: `Build.Contract` for the shared composition layer, and
`Build.SeamLayout` to expose the existing `BufferWords` clipping theorem rather than proving
another buffer-outside lemma. No public declaration, public reader, or simp attribute was added.
InputBit is 2055 lines; per COMMON's tier-2 addendum, the maintainer may split it at landing.

### Requested shared lemma

`inputBit_increment_value` proves
`incFixed w = some v → Nat.ofDigits 2 (v.map Bool.toNat) = Nat.ofDigits 2 (w.map Bool.toNat) + 1`.
This is the dispatch's explicitly authorized private lemma, proved by a fresh induction on
`w` using `incFixed_nil`, `incFixed_false_cons` and `incFixed_true_cons`. It was not copied
from CodeSimulator. Please publish the common `incFixed_value` in Build/Convention and retire
both private copies as requested in the dispatch.

### Searches before helper proofs

- Catalog comparison was checked and supplies equality, not unequal-width unsigned order.
- Catalog `copyTM`, `incrementTM`, `clearTM`, `skipBackTM`, their contracts, native seek,
  and the existing contract hosts are consumed directly.
- `wordPatch_self`, `wordPatch_twice`, `wordPatch_frame` and buffer clipping were inspected;
  the global scratch invariant uses the published buffer clipping lemma.
- Bit-vector decomposition/value proofs use core `cons_msb_setWidth`, `getLsbD_cons`,
  `toNat_cons'`, signed-value/sign-bit lemmas, and published `bvBits` readers.
- Counter values and binary lengths use `counterValue_eq`, `counterValue_bits`, and
  `length_bits_le_self` instead of re-proving their arithmetic.
- Startup's singleton table and encoding use `tableOf_iff`, `encodes_iff`,
  `initMem_def`, `XCfg.init_def`, and the newly published `inRange_iff`.

### Other-file definitions and their readers

- `bvBits`: `bvBits_def`, `bvBits_length`; `WordAt`: `wordAt_iff`;
  `ScratchBlank`: `scratchBlank_iff`; `wordWrite`: `wordWrite_apply`.
- `incFixed`: the nil/false-cons/true-cons equations, nonoverflow characterization and
  `incFixed_length`; counter value: `counterValue_eq`, `counterValue_bits`.
- `FinTM.bufferTape`: `bufferTape_nil`, `bufferTape_nat`, `bufferTape_left`, and
  `bufferTape_eq_none_of_not_mem`.
- `MultiTapeTM.step` and `Action.apply`: published step/action field readers and
  `step_of_inputMoveAction`; `inputMoveAction`: its published step reader.
- `MultiTapeTM.runFrom`: zero, one, successor, and catalog trace/run equations;
  `catalogTrace`: `catalogTrace_eq`.
- `Cfg.mapState`: its state/input/tape/head/output readers; `Cfg.bindState`: its field readers;
  `Cfg.inputSymbol`: `Cfg.inputSymbol_congr` and `FinTM.inputSymbol_at`.
- `Contract.ofReaches`: pre/post/lo/hi readers and `ofReaches_time_le`;
  `Contract.seq`, `branch`, `inPhase`: their pre/time/post/lo/hi readers.
- Catalog `copyTM_contract`, `clearTM_contract`, `incrementTM_contract`,
  `compareTM_contract`, `skipBackTM_contract`: their published field readers;
  `sweepPost` and `seekPost`: their field readers; `compareStop`: `compareStop_le`.
- `embedEmitTM`: `embedEmitTM_runFrom`; `embedEmitCfg`: `embedEmitCfg_eq`, state,
  selected-position and unselected-frame readers.
- `ReachesWithin`: `reachesWithin_iff`, `ReachesWithin.mono`.
- Startup definitions: `initMem_def`, `inRange_iff`, `tableOf_iff`, `encodes_iff`,
  `XCfg.init_def`. No missing-reader exception was needed.

The stronger replay seals **all 425 ordinary imported TCSlib definitions**, including
unused ones, and removes the three active definition simp rules. A guard checks every seal.
The negative control intentionally attempts `bvBits = []` by `rfl` and fails, exit 1.
All positive native, sealed, axiom and downstream checks exit 0.

## Verification and environment

The initial own-tree bootstrap checked 45 TCSlib modules and a real Mathlib probe; the new
buffer/SeamLayout import was bootstrapped separately. The required six downstream targets
and their missing prerequisites then checked serially: 83 additional/rechecked
modules, 129 modules in the full import closure, 53 present Mathlib roots. The root TCSlib
facade is excluded by the standing maintainer workflow; the TuringMachine and RAMSimulation
facades are included. Existing admitted targets elsewhere retain their normal warnings.

Every Lean invocation went through the recorded driver: machine-wide executable-name count
below 3 before launch, at most one of ours, `nice -n 10`, Lean `-j4`, and an isolated scratch
olean tree. The process log records 1 count samples at or above 3 (wait/recheck samples).
No `lake build` was run. The populated `.lake/packages` symlink has the exact manifest revisions.
This host is macOS ARM64, so native `vm_stat`, `memory_pressure`, and `/usr/bin/time -l`
were used instead of Linux procfs/time fields. Preflight logged 12 CPUs, 18 GiB RAM,
about 117.8 GiB free disk and conservative memory headroom above 3 GiB.

The owner statement headers are byte-identical to the base. The supplied patch passed
`git apply --check` and an actual replay against fresh copies of the two base files; both
replayed files match the delivered SHA256 bytes. Unrelated generated blueprint changes in
the source worktree were preserved and excluded.

```
TCSlib/Complexity/RAMSimulation/Sim/Startup.lean   |   66 +
 .../Complexity/TuringMachine/Build/InputBit.lean   | 2005 +++++++++++++++++++-
 2 files changed, 2061 insertions(+), 10 deletions(-)
```

## New private declaration ledger

- `Turing.inputBitOrder`: The remembered order after scanning two little-endian words. Missing high digits are zero, and a higher unequal pair replaces the order remembered from the lower digits.
- `Turing.inputBitOrder_spec`: The remembered comparison equals the order of the words' values; the incoming comparison breaks ties. This includes unequal word lengths and high zero padding.
- `Turing.inputBitOrder_lt`: Starting with equality compares the unsigned values of any two bit lists.
- `Turing.inputBitNext`: A higher unequal digit pair decides the order of two little-endian prefixes.
- `Turing.inputBitPrefix`: The remembered order after `r` synchronized input-word positions.
- `Turing.inputBitPrefix_shift`: Processing the first digit pair first shifts the rest of the prefix scan to the tails.
- `Turing.inputBitPrefix_complete`: Scanning through the longer word computes the full unsigned comparison.
- `Turing.InputBitComparePhase`: The comparison sweep carries the remembered order and then returns it at an exit.
- `Turing.inputBitCompareForward`: A read-only comparison pass over tapes zero and one. The catalog's `compareTM` tests equality and stops at its first differing cell; no row compares unequal-width numeric words. This pass remembers the highest unequal bit pair, parking a head at its right delimiter while the other word continues. Its exit advances both heads one cell beyond the delimiters, so the published `skipBackTM` can restore each head.
- `Turing.inputBitCompareCfg`: The forward sweep at index `r`: each head stops advancing at its word's delimiter.
- `Turing.inputBitCompareDone`: The forward comparison's exit, one cell beyond each right delimiter.
- `Turing.inputBit_move_step`: A nonwriting action with an arbitrary work-head displacement vector preserves all data. The published one-tape action lemmas do not cover the comparison's two moving heads.
- `Turing.inputBitCompareCfg_reads`: The two parked-or-advancing heads read the corresponding optional digits.
- `Turing.inputBitCompareForward_step`: One forward comparison step advances each unfinished word head and updates the order.
- `Turing.inputBitCompareForward_turn`: At both delimiters the comparison exits with the complete remembered order.
- `Turing.inputBitCompareForward_reaches`: The forward comparison has a first exit after the longer word's length plus one step.
- `Turing.inputBitContractOn`: Reindex a contract while retaining an additional invariant in its precondition.
- `Turing.inputBit_mapState_heads`: The published pointwise state-map head reader also identifies the whole head vector.
- `Turing.inputBit_mapState_tapes`: The pointwise tape reader identifies the whole unchanged tape bank.
- `Turing.inputBit_seekPost_heads`: The published seek endpoint reader identifies its whole updated head vector.
- `Turing.inputBitCompareBack`: The two published backward skips restore the two comparison heads in sequence.
- `Turing.inputBitCompareBackContract`: The restoration contract retains both word premises and uses the catalog rows.
- `Turing.inputBitCompareBack_pre`: The backward composite requires the two words immediately before their parked heads.
- `Turing.inputBitCompareBack_post`: The two backward skips preserve all data and subtract each word length plus one.
- `Turing.inputBitCompareBack_time`: The two backward skips cost the sum of the word lengths plus seven steps.
- `Turing.inputBitCompareForwardContract`: The numeric comparison pass as a composable framed contract.
- `Turing.inputBitCompare_link`: The forward exit places both delimited words exactly where the backward skips expect.
- `Turing.InputBitCompareState`: The comparison control consists of its forward pass and the two tagged restorations.
- `Turing.inputBitCompareTM`: The comparison first branches on its remembered order, then restores both heads.
- `Turing.inputBitCompareEntry`: The comparison entry is the false-initialized forward scan.
- `Turing.inputBitCompareExit`: The tagged backward exit retains the comparison result in finite control.
- `Turing.inputBitCompareExits`: The exit set supplied by the branch contract, before simplifying the two images.
- `Turing.inputBitCompareContract`: The complete comparison contract composes one forward pass with a tagged restoration.
- `Turing.inputBitCompare_pre`: The complete comparison has exactly the original two-word precondition.
- `Turing.inputBitCompareForward_time_le`: The chosen running time of the forward contract is at most its stated linear bound.
- `Turing.inputBitCompare_time_le`: The full comparison, including both head restorations, has linear running time.
- `Turing.inputBitCompareExits_eq`: The branch contract's image exits are exactly the false and true comparison anchors.
- `Turing.inputBitCompare_post`: The complete comparison restores both heads and all data, retaining only its verdict.
- `Turing.inputBitCompare_reaches`: Comparing two unequal-width words preserves every physical field and returns their unsigned order in linear time and radius.
- `Turing.inputBit_bvBits_cons`: Adding a most-significant bit appends it to the little-endian tape word.
- `Turing.inputBit_bvBits_value`: The unsigned value of a word's tape bits is its `BitVec.toNat` value.
- `Turing.inputBit_seek_row`: The native seek's framed conclusion is a `ReachesWithin` row. The input position in the endpoint is the unique position with value `p`, and all work-tape contents are restored.
- `Turing.inputBit_increment_exists`: A nonoverflowing bit list has a successor of exactly the same width.
- `Turing.inputBit_increment_value`: A successful fixed-width increment adds one to the unsigned value of the bits.
- `Turing.inputBitSuccBits`: The fixed-width successor bits used by the input-head counter.
- `Turing.inputBitSuccBits_spec`: A positive-width nonnegative signed position has a nonoverflowing successor counter.
- `Turing.inputBit_exists_seek_row`: A native seek witness with the endpoint and the head envelope packaged for composition. Its position word is restored, its scratch tape remains blank, and the input head lands at `p`.
- `Turing.InputBitData`: The physical fields of a reader configuration, independent of its control states.
- `Turing.InputBitData.cfg`: Attach a live control state to physical fields.
- `Turing.InputBitData.ofCfg`: Forget a configuration's control state.
- `Turing.InputBitData.ofCfg_cfg`: Forgetting an attached state recovers the physical fields.
- `Turing.InputBitData.cfg_ofCfg`: Reattaching a configuration's live state recovers it.
- `Turing.InputBitData.cfg_mapState`: Re-tagging a live configuration only changes its attached state.
- `Turing.InputBitData.ofCfg_mapState`: Forgetting control is invariant under a re-tagging.
- `Turing.InputBitCall`: A single-exit catalog composition with a state-independent physical specification. The head-return clause lets subsequent calls use the same origins.
- `Turing.InputBitCall.contract`: Package a physical call as the published `Contract.ofReaches` adapter.
- `Turing.InputBitCall.time_le`: The call's chosen contract time obeys its advertised bound.
- `Turing.InputBitCall.seq`: Sequence two head-returning calls with the published seam host.
- `Turing.InputBitCall.adapt`: Strengthen a call's precondition, identify its physical endpoint and enlarge its bounds.
- `Turing.InputBitJoinPhase`: The original machine and a terminal catalog phase used to identify live exits.
- `Turing.inputBitJoinMachines`: Place a source machine beside the terminal phase in the published phase host.
- `Turing.inputBitJoinRed`: Redirect exactly the live exits to one terminal anchor.
- `Turing.InputBitCall.close`: Identify a finite family's live exits using `Contract.inPhase`.
- `Turing.InputBitCall.branch`: Compose a read-only test with two calls and identify the resulting exits.
- `Turing.InputBitCall.ofContract`: Use a catalog contract with a bounded time as a head-returning call.
- `Turing.InputBitData.scratch`: Install a globally delimited scratch word at tape three's current origin.
- `Turing.InputBitData.hasScratch`: Whether tape three globally holds a scratch word.
- `Turing.InputBitData.wordAt`: `WordAt` does not inspect the attached control state.
- `Turing.InputBitData.blank`: The scratch-tape predicate does not inspect the attached control state.
- `Turing.InputBitData.scratch_wordAt`: A globally stored scratch word is delimited at its origin.
- `Turing.InputBitData.hasScratch_scratch`: Installing a scratch word satisfies its global specification.
- `Turing.InputBitData.hasScratch_nil`: A globally blank tape three is the empty scratch word.
- `Turing.InputBitData.scratch_nil`: Emptying an originally blank scratch tape recovers all physical fields.
- `Turing.InputBitData.scratch_twice`: A second scratch installation keeps only the final word.
- `Turing.InputBitData.write_scratch`: Writing a same-width replacement over a globally stored word installs exactly the new scratch word; writing the first word into an empty scratch tape does too.
- `Turing.InputBitArgs`: The logical parameters shared by the calls in one input-read operation.
- `Turing.inputBitReady`: The external tape precondition, with the control state forgotten.
- `Turing.inputBitCopyCall`: Copy the position word to the globally blank scratch tape using the catalog row.
- `Turing.inputBitIncrementCall`: Increment the copied nonnegative positive-width position using the catalog counter.
- `Turing.inputBitClearCall`: Clear the globally stored successor counter with the catalog's clearing sweep.
- `Turing.inputBitWrite`: Replace the register by a Boolean integer constant, leaving its surroundings framed.
- `Turing.inputBitConstantCall`: The permitted integer-constant row supplies each branch's register writer.
- `Turing.inputBitCanRead`: The in-range case of a positive-width, nonnegative signed index.
- `Turing.inputBitSeek`: Move the input head to the index's shifted input position; outside the intended precondition the minimum merely keeps the configuration well typed.
- `Turing.inputBitSeekCall`: Place the restored two-tape native seek on scratch tapes three and four.
- `Turing.inputBitSeek_scratch`: A scratch installation commutes with the input-only head change.
- `Turing.inputBitReady_seek`: Seeking does not change the work-tape precondition.
- `Turing.inputBitValidSeekCall`: The whole valid-index seek: copy, increment, native seek, and erase the scratch counter.
- `Turing.inputBitNativeBit`: The bit currently under the native input head, with blanks read as false.
- `Turing.inputBitReadTM`: A one-step native-input test. No catalog row returns a Boolean native-input read as a verdict without moving a head; this leaf only uses the published stationary input action.
- `Turing.inputBitRead_reaches`: Read the native bit without changing any physical field.
- `Turing.inputBitNativeBit_seek`: The shifted seek position reads precisely the requested list digit.
- `Turing.inputBitTest_ofContract`: Derive a read-only verdict row from a catalog contract and its endpoint equation.
- `Turing.inputBitWidth_reaches`: The catalog equality comparator detects width zero by comparing with blank scratch.
- `Turing.inputBitOrder_index`: Unsigned tape comparison agrees with the signed natural index when its sign is clear.
- `Turing.inputBitReadWriteCall`: Read the current native bit and write its Boolean word using the two constant rows.
- `Turing.inputBitAnswer`: The Boolean answer specified by a signed input read.
- `Turing.inputBitResult`: The finished physical data, retaining whichever input position the selected path used.
- `Turing.inputBitAnswer_nonneg`: With a nonnegative index, the Boolean answer is the requested list digit.
- `Turing.inputBitResult_negative`: Negative indices take the zero-writing path without seeking.
- `Turing.inputBitResult_past`: An index past the input takes the zero-writing path without seeking.
- `Turing.inputBitWrite_width_zero`: At width zero every Boolean constant is the same empty register word.
- `Turing.inputBitResult_width_zero`: The width-zero branch can always write zero.
- `Turing.inputBitValidReadCall`: A complete valid-index input read, with scratch already cleared before the bit test.
- `Turing.inputBitRangeCall`: The range decision: read a valid index and write zero for a position past the input.
- `Turing.inputBitSignCall`: The signed decision: a negative index writes zero, and a nonnegative index tests its range.
- `Turing.inputBitFullCall`: The full reader call, including the empty-width boundary case.
- `Turing.inputBitResult_cfg`: The physical result has precisely the public row's framed endpoint shape.
- `WordRAM.Sim.startup_initMem_neg_one`: The marked startup entry stores the length word at the distinguished cell.
- `WordRAM.Sim.startup_initMem_of_ne`: Every other startup cell holds zero.
- `WordRAM.Sim.startup_tableOf`: The singleton table is the initial memory as soon as the distinguished cell's signed range obligation is supplied. This isolates that obligation from the tape construction.
- `WordRAM.Sim.startup_inRange_neg_one`: Every positive width represents `-1`, including the single-bit boundary.
- `WordRAM.Sim.startup_inRange_neg_one_of_two_le`: Every width at least two represents `-1` in the signed range.
- `WordRAM.Sim.startup_encodes_of_tapes`: The finished eight tapes encode the initial RAM configuration once the distinguished address's range fact is supplied.
