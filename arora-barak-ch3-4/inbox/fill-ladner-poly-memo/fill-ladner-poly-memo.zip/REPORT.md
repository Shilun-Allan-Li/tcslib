# Ladner fill 4 — target 1 complete

Date: 2026-11-15 (America/Los_Angeles).

- [x] Target 1 proved: `Complexity.ladnerH_polyTime`, with the selection scan, `stage_correct`, memo driver, orbit, size ledger and readout completed.
- [x] Exact approved reorder committed separately and its SHA-256 checked.
- [x] Every new declaration, reuse search and foreign-definition reader documented below.
- [x] Source, facade, axiom, sealed-source and control checks passed, with exit codes and logs.
- [x] Only `TCSlib/Complexity/Diagonalization/Ladner.lean` changed; frozen declarations and imports verified byte-for-byte.
- [x] Environment, shared slot protocol and machine-wide concurrency log included.

No E-READER, E-HOST, E-STATEMENT or E-RES escalation remains. There are no pending proofs in the owned target. The three other admitted targets remain as supplied.

## Pins, commits and scope

Repository: Shilun-Allan-Li/tcslib. Base: `1320a5c8ce93f4644c2c92ed32e2768ed07ea9bb`.
Local branch: `fill/ladner-poly-memo`, never rebased and never pushed.
Managed worktree: `/Users/seyoonr/.codex/worktrees/ladner-poly-memo/tcslib-exchange`.

1. `a3516fbcacc6ce16fda7f082defb7f2804143886` — applied the bundled `Ladner-move.patch.txt` exactly with `git apply`; no other change in this commit.
2. `3b1995a986e2b93257f18a3a755469418f9a0a28` — adds part B and replaces only the body of `ladnerH_polyTime`.

The bundle SHA-256 is `cadf4790adac6c7c80431dc6b7e22a30ab5440a9f8713adccd1bf9e148462725`, with 15 sections; verified before reading the brief. Its records pin is `3d7848267a07c3bc3a6144e58b844b795ff83538`, and its exchange pin is `6e846acb1238f7c365a9e136837d5bf7957c2a79`.

| Artifact | SHA-256 |
|---|---|
| Base Ladner | `29e0b907c0aba0929f3b5a66b6a706b0e0a0bda81efcebf2b07ecf0bdb5754c3` |
| Bundled reorder patch | `e16134f47a83ad3e95a5c71e30867b800a42e46affcd679ada2164b88f7461b1` |
| After reorder | `4c9a04c3b28ae8a43cfded8ebdca4bf57b638214e82dabdccce7cd966ff0d914` (required hash: PASS) |
| Delivered Ladner | `d9defae31494007ecce07944e1ca4aa0fa20ca91e74a89ef32a4e2fb344c5dcb` |
| Cumulative `Ladner.patch` | `9188a17d5526775e9c49c0a917a1f9d8a088910a33f1354ca7f628f6b1dfb3a2` |

`Ladner.patch` covers both commits against the full base hash. A fresh source-only scratch tree at the base accepted the patch, and the result matched the delivered file byte-for-byte (`patch-roundtrip.log`). The fill worktree is clean. The delivered file has 2146 lines.

```
 TCSlib/Complexity/Diagonalization/Ladner.lean | 413 +++++++++++++++++++++++---
 1 file changed, 369 insertions(+), 44 deletions(-)
```

`scope-freeze.log` verifies that removing the new private section and restoring only the target's admitted body reproduces the approved reordered file exactly. This checks all existing statements, docstrings, imports, part A, earlier leaves and the other four target declarations. There are 21 new declarations, all private `ladner_` names, with no new `sorry`, `admit`, axiom, import or simp attribute. Every new docstring cites [AB09, Theorem 3.3 and its proof]; every proof over 20 lines has a proof sketch.

## Every new declaration

| Private name | Role |
|---|---|
| `ladner_selectCtx` | Prepare candidate context using the decoded entry count. |
| `ladner_selectInit` | Initialize rank and completion flag. |
| `ladner_selectStep` | Advance rank, record first success or exact cap, then remain fixed. |
| `ladner_selectOut` | Fourth-slot selection readout. |
| `ladner_candidate_selectCtx` | Identify the prepared candidate with the stage's bounded test. |
| `ladner_stage_spec` | Stage cap, failure of every earlier candidate, and success below the cap. |
| `ladner_selectInit_FP` | FP initialization by the existing pairing closure. |
| `ladner_selectStep_FP` | FP transition using countW, the frozen logarithmic-index helper and conditionals. |
| `ladner_select_orbit` | Exact state at every iteration, including all iterations after completion. |
| `ladner_stage_length_le` | Factor the common cap-to-serialized-table-length bound. |
| `ladner_select_size` | Uniform `12(|T|+1)` selection-state bound, for every natural iteration count. |
| `ladner_select_readout` | Exact stage value after `|T|+1` rounds. |
| `ladner_stage_FP` | Apply the public iterator and fourth-slot readout. |
| `ladner_stage_correct` | Identify a stage over correct earlier memo values with the global delayed index. |
| `ladner_memoInit` | Immutable unary requested index and empty table. |
| `ladner_memoStep` | Append the next stage value as an encoded word. |
| `ladner_memoStep_FP` | FP stage/append/pair composition. |
| `ladner_memoInit_FP` | FP unary-marker initialization. |
| `ladner_memo_orbit` | Exact history of the first `j` delayed-index values, for every `j`. |
| `ladner_memo_size` | `4(|z|+1)^2` bound at every required memo round. |
| `ladner_memo_readout` | Existing `getW` reads the value at index `|z|`. |

The three binding helper meanings (`ladner_stage_FP`, `ladner_stage_correct`, `ladner_memo_readout`) are unchanged from the probe. Instead of the suggested `SelectInv`, measure and progress helpers, the stronger exact `ladner_select_orbit` equation handles least success, exact-cap fallback and the absorbing final state directly. Other specified helper meanings also follow the probe. No host is invented: both new loops are applications of `BinArith.polyTimeComputable_iterate`.

`stage_correct` uses `padSAT_congr` at every queried shorter prefix: `m < |x| ≤ log₂ |vs| ≤ |vs|`, so the table hypothesis applies. This also handles the empty-table case without a separate nonzero assumption. The memo bound uses the per-index `ladnerH_le`, never monotonicity of `ladnerH`.

## Reuse searches and readers

Before the proof draft, `helper-search.log` recorded candidate enumeration over the exact 140-module import closure, followed by inspection of matching declarations and the frozen private leaves. It is a search-and-inspection record, not a claim of exhaustive semantic screening.

| Helpers | Existing facts inspected and cited |
|---|---|
| Prepared candidate and stage spec | The frozen `ladner_candidate`/`ladner_stage`, pairing projections, `bitsVal_bits`, `Nat.find_spec`, `Nat.find_min`. |
| Selection FP | `polyTimeComputable_countW`, `countW_eq`, frozen `ladner_lengthBits_FP`, `ladner_binary_log_FP`, `ladner_values_length_FP`, `ladner_index_lt_loglog_FP`; public pairing, append, constant, conditional and projection closures. |
| Selection orbit/size/readout | Public iterator invariant/measure APIs were searched; the required exact orbit uses `Function.iterate_succ_apply'`. Use `List.replicate_succ'`, `length_pairEncode`, `length_bits_le_self`, `Nat.log_le_self`, frozen `ladner_values_length_le`. The shared stage-length proof is factored once. |
| Stage FP and target | Public `polyTimeComputable_iterate`, slot4 and getW FP; supplied assembly; frozen `ladner_candidate_FP` with public `SAT_exists_linear_verifier`. |
| Stage correctness | `padSAT_congr`, `ladnerH_eq`, `Nat.log_le_self`, `forall_congr'`, `imp_congr_right`, `iff_congr`. |
| Memo FP | Public unary, append, pairing and composition closures; no memo host. |
| Memo orbit | `decWords_encWords`, `bitsVal_bits`, `encWords_append_singleton`; List range/map/lookup equations. |
| Memo size | `length_encWords_le`, `length_pairEncode`, `ladnerH_le`, `length_bits_le_self`, `Nat.log_le_self`, `Nat.mul_le_mul_right`. |
| Memo readout | `getW_pairEncode_bits`, `List.map_map`, `List.getD_eq_getElem`, `List.getElem_map`, `List.getElem_range`. |

The new section reads other-file TCSlib definitions as follows:

| Definition | Published equation or contract used |
|---|---|
| `Turing.pairEncode` | `length_pairEncode`; FP pairing closure. No body unfolding. |
| `pairFstD`, `pairSndD` | `pairFstD_pairEncode`, `pairSndD_pairEncode`; FP projections. |
| `LogProg.bitsVal` | `bitsVal_bits`. |
| `BinArith.countW` | `countW_eq`, `polyTimeComputable_countW`; entries are counted, never substituted by serialized length. |
| `BinArith.decWords` | `decWords_encWords`; remains natively irreducible. |
| `BinArith.encWords` | `encWords_nil`, `encWords_append_singleton`, `length_encWords_le`. |
| `BinArith.getW` | `getW_pairEncode_bits`, `polyTimeComputable_getW`. |
| `BinArith.lt` | Reached through the frozen `ladner_index_lt_loglog_FP`; the scratch equation control cites `lt_pairEncode`. |
| `PolyTimeComputable` | Used through the existing closure/iterator theorems, with its definition opaque in the sealed check. |

Machine acceptance is used as an atomic proposition, with no machine-model definition opened. In-file `ladnerH` is read through `ladnerH_eq` and `ladnerH_le`; padding uses `padSAT_congr`. Core/Mathlib reads use published equations or `show`/definitional conversion. No core/Mathlib definition is an explicit simp/rw/unfold argument; the new rewrite arguments were inspected (`rewrite-arguments.log`).

The official text screen ran serially under the shared screen lock, on Ladner plus BinaryArith Basic/AddSub/Words/Loops/Iterate and PolyTimePairing. Final base/head: 202/221 screened declarations, 117/148 pairs, 17,456/21,778 reproduced characters; 31 new textual pairs are archived. Inspection found common FP-constructor syntax and induction/iterate syntax, rather than repeated mathematical facts. In particular, the logarithmic-index test cites the existing helper; generic FP witnesses are composed from existing closure theorems, and the two history equations describe their distinct Ladner states. No published theorem was re-proved and no copied proved-material debt is claimed. The initial common selection length derivation was factored into `ladner_stage_length_le` before the final check.

## Final checks and axiom inventory

| Check | Exit | Result / log |
|---|---:|---|
| Pinned Lean version | 0 | 4.25.0, commit cdd38ac5115bdeec5f609e9126cce00f51ae88b3; `toolchain.log` |
| Mathlib root probe | 0 | `cache-probe.log` |
| Fresh prerequisite bootstrap | 0 each | 138 modules; order, per-module logs, starts/ends and peak RSS included |
| Delivered Ladner | 0 | `Ladner-attempt-2.log`: 0 errors, exactly 3 sorry warnings |
| Public scratch axiom wrappers | 0 | `axiom-prints.log`: all 21 new declarations plus the target |
| Sealed new section and target | 0 | `sealed-source-final.log` |
| Unsealed controls | 0 | `controls-unsealed.log` |
| Sealed delta/equation controls | 0 | `controls-sealed.log` |
| Diagonalization facade | 0 | `facade.log`, fresh nonempty olean, 0 errors |
| Scope, cumulative patch roundtrip, final hashes | 0 | `scope-freeze.log`, `patch-roundtrip.log`, `final-verification.json` |
| Final copy screen | 0 each | `final-copy-screen-*.log` |

The only final source warnings are the supplied admissions `SAT_H_mem_NP`, `SAT_mem_P_of_padSAT_NPHard`, `SAT_H_intermediate`. The target and every new private declaration have at most `propext`, `Classical.choice`, `Quot.sound`; **no `sorryAx`** occurs in these axiom prints. `Complexity.ladnerH_polyTime` has exactly those three standard axioms.

The seal covers pairing, both projections, numeric reading, encoding/count/lookup/comparison and the FP predicate. Eight ordinary definitions have delta controls that pass unsealed and fail under the seal; all nine computational reader equations pass sealed. `decWords` is already irreducible, so its delta control fails even in the baseline and its published equation succeeds. No unsafe reducibility override was used.

All attempts are preserved: the first source check found a wrong flag projection in the FP assembly and three local elaboration issues, all fixed in attempt 2. The first sealing harness redundantly attempted to reapply irreducibility to native-irreducible `decWords`; Lean rejected the attribute. The final harness leaves that existing seal intact. These are resolved proof/harness iterations, not remaining failures or environment escalations. The library source did not change after its successful check; the logged source hash matches the delivered file.

## Environment and Lean concurrency

Native macOS 26.5.2 / arm64 / APFS. Linux `nproc`, `/proc` and cgroups do not apply. Native preflight: 12 logical CPUs, 19,327,352,832 bytes (18 GiB) physical RAM, `memory_pressure -Q` initially 58% free (about 10.44 GiB), filesystem 172,414,648 KiB free (about 164.43 GiB). The 4 GiB memory / 12 GiB disk floors passed. Native followups recorded 50% and 55% free while longer modules ran; no shortage, crash or timeout occurred. All source and scratch paths are disk-backed APFS. Raw readings are in `preflight.log` and `resource-followup.log`.

Preinstalled pinned toolchain; no installation or readlink shim. Authorized `.lake/packages` symlink to `/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`; every present package's origin URL and HEAD match the manifest (`manifest.log`: `PASS: every present package matches manifest`). The documentation packages are listed ABSENT and none is imported. All 7,544 existing dependency oleans were nonempty. There was no cache fetch, archive-store use, copying/merging package trees, reuse of another session's TCSlib olean tree, or `lake build`. The 46 direct Mathlib roots are recorded; a root probe and the full bootstrap validated the cache.

A new scratch olean tree `/private/tmp/ladner-poly-memo-20261115/oleans` was bootstrapped serially from this base's source closure. The owned module and facade were checked after those prerequisites. Each Lean launch goes through the inspected `devtools/seyoon/leanelab[-o].sh`, under `nice -n 10`, `-j4`. This uses the existing shared `/Users/seyoonr/.tcslib-scratch/locks/lean-slot-*` protocol with `TCSLIB_LEAN_SLOTS=3`, supplemented by the task's PATH gate. Immediately before invoking the unmodified pinned executable, that gate runs `ps -axo comm=` and counts both bare `lean` and full paths whose last slash component is `lean`. A count at least 3 would log a UTC timestamp, wait five seconds and recount. No own Lean process overlaps another of this fill.

Concurrency totals: **148 launches, 0 waits, maximum prelaunch machine Lean count 0**. Thus each observed launch added this fill's single Lean process to an otherwise empty Lean process set. `concurrency.log` records every count/launch; `check-summary.log` records serial starts/ends/statuses. `/usr/bin/time -l` records maximum resident memory for every module/check. No slot-protocol or concurrency deviation occurred. The global process-count gate was also used for `--version` and the Mathlib probe. No short self-imposed timeout was used.

The Mathlib probe used the same throttled leanelab wrapper as the bootstrap instead of the addendum's example `lean_check_tree.sh`; it imported `Mathlib.Data.Nat.Log`. macOS native measurements and the permitted packages symlink are the environment adaptations. Git metadata and native process inspection required sandbox escalation, which succeeded.

## Delivery

`fill-ladner-poly-memo.zip` contains this report, the exact delivered `Ladner.lean`, `Ladner.patch` against the base covering both commits, all check/concurrency/search/screen logs, the approved reorder patch, and reproducible scratch probes/scripts as text. No compiled artifacts are included.

Checkpoint 1 was pushed to the requested inbox as exchange commit `a3cbc0d4270cdbe03d92597f0f93e97b6ff74b3e`. It is explicitly marked as an unverified in-progress draft; this final zip supersedes it. The final zip's authorized destination is `arora-barak-ch3-4/inbox/fill-ladner-poly-memo/` on `exchange/pass-shelat-ch5-8`, after `git pull --rebase`, adding only that folder and without force. No other branch is pushed and no PR is opened. A chat download link to the same final zip is supplied as fallback.
