from pathlib import Path
import subprocess,datetime,time,hashlib
r=Path('/private/tmp/ladner-poly-memo-20261115')
w=Path('/Users/seyoonr/.codex/worktrees/ladner-poly-memo/tcslib-exchange')
lock=Path('/Users/seyoonr/.tcslib-scratch/locks/screen')
while True:
    try: lock.mkdir(); break
    except FileExistsError:
        with (r/'evidence/logs/screen-lock.log').open('a') as f: f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' WAIT shared screen lock\n')
        time.sleep(3)
refs=[w/('TCSlib/Complexity/'+p+'.lean') for p in ['ClassP/BinaryArith/Basic','ClassP/BinaryArith/AddSub','ClassP/BinaryArith/Words','ClassP/BinaryArith/Loops','ClassP/BinaryArith/Iterate','ClassNP/PolyTimePairing']]
try:
    outs={}
    for label,owned in [('base',r/'Ladner-reordered.lean.txt'),('head',w/'TCSlib/Complexity/Diagonalization/Ladner.lean')]:
        cmd=['nice','-n','10','python3','-I',str(w/'scripts/copy-text-screen-v3.py'),'/',str(owned)[1:],*[str(p)[1:] for p in refs]]
        p=subprocess.run(cmd,text=True,capture_output=True)
        (r/f'evidence/logs/final-copy-screen-{label}.log').write_text(p.stdout+p.stderr+f'\nsource_sha256={hashlib.sha256(owned.read_bytes()).hexdigest()}\nexit_code={p.returncode}\n')
        assert p.returncode==0
        outs[label]=p.stdout.replace('Ladner-reordered.lean.txt','Ladner.lean')
    new=set(outs['head'].splitlines()[1:])-set(outs['base'].splitlines()[1:])
    (r/'evidence/logs/final-copy-screen-delta.log').write_text('\n'.join(sorted(new))+'\n')
    print(outs['base'].splitlines()[0])
    print(outs['head'].splitlines()[0])
    print('New pairs:',len(new))
finally: lock.rmdir()
