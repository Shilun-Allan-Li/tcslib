from pathlib import Path
import re,subprocess,hashlib
r=Path('/private/tmp/ladner-poly-memo-20261115')
w=Path('/Users/seyoonr/.codex/worktrees/ladner-poly-memo/tcslib-exchange')
base='1320a5c8ce93f4644c2c92ed32e2768ed07ea9bb'
move='a3516fbcacc6ce16fda7f082defb7f2804143886'
p='TCSlib/Complexity/Diagonalization/Ladner.lean'
s=(w/p).read_text()
old=subprocess.check_output(['git','show',move+':'+p],cwd=w).decode()
assert hashlib.sha256(old.encode()).hexdigest()=='4c9a04c3b28ae8a43cfded8ebdca4bf57b638214e82dabdccce7cd966ff0d914'
a=s.index('/-! ### Polynomial-time selection and memo-table evaluation -/')
b=s.index('/-! ### The theorem and its remaining targets -/')
new=s[a:b]
rest=s[:a]+s[b:]
pat=r'(theorem ladnerH_polyTime :\n    PolyTimeComputable \(fun x => Nat.bits \(ladnerH x.length\)\)) := by\n.*?(?=\n\n/-- The padded SAT witness)'
rest,n=re.subn(pat,lambda m:m[1]+' :=\n  sorry',rest,flags=re.S)
assert n==1 and rest==old
assert 'sorry' not in new and 'admit' not in new and 'axiom ' not in new and '@[simp]' not in new
names=re.findall(r'^private (?:noncomputable )?(?:def|theorem) (\w+)',new,re.M)
assert all(name.startswith('ladner_') for name in names)
assert len(names)==len(re.findall(r'^(?:private )?(?:noncomputable )?(?:def|theorem) ',new,re.M))
changed=subprocess.check_output(['git','diff','--name-only',base],cwd=w,text=True).splitlines()
assert changed==[p]
assert subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip()=='fill/ladner-poly-memo'
log='PASS: exact reordered SHA-256.\nPASS: stripping new private section and restoring only target body reproduces approved reorder byte-for-byte.\nPASS: every other declaration/docstring and all imports frozen.\n'
log+=f'PASS: {len(names)} new declarations, all private ladner_ names; no new sorry/admit/axiom/simp attributes.\n'
log+='delivered_source_sha256='+hashlib.sha256(s.encode()).hexdigest()+'\n'
log+='\n'.join(names)+'\n'
log+=subprocess.check_output(['git','diff','--stat',base],cwd=w,text=True)
(r/'evidence/logs/scope-freeze.log').write_text(log)
(r/'evidence/logs/rewrite-arguments.log').write_text('\n'.join(line for line in new.splitlines() if any(k in line for k in ['simp','rw [','unfold']))+'\n')
print(log)
