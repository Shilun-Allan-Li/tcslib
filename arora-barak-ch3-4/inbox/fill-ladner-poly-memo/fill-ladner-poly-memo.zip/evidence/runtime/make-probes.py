from pathlib import Path
import re
r=Path('/private/tmp/ladner-poly-memo-20261115')
w=Path('/Users/seyoonr/.codex/worktrees/ladner-poly-memo/tcslib-exchange')
s=(w/'TCSlib/Complexity/Diagonalization/Ladner.lean').read_text()
marker='/-! ### Polynomial-time selection and memo-table evaluation -/'
end='/-! ### The theorem and its remaining targets -/'
new=s[s.index(marker):s.index(end)]
names=re.findall(r'^private (?:noncomputable )?(?:def|theorem) (\w+)',new,re.M)
axioms=s+'\nnamespace Complexity\n'
for name in names:
    axioms+=f'noncomputable def LadnerProbe_{name} := @{name}\n#print axioms Complexity.LadnerProbe_{name}\n'
axioms+='end Complexity\n#print axioms Complexity.ladnerH_polyTime\n'
(r/'AxiomProbe.lean').write_text(axioms)
seals='section\nattribute [local irreducible] Turing.pairEncode pairFstD pairSndD LogProg.bitsVal\n  BinArith.encWords BinArith.countW BinArith.lt BinArith.getW\n  PolyTimeComputable\n\n'
sealed=s.replace(marker,seals+marker,1)
needle='/-- The padded SAT witness is in NP.'
assert sealed.count(needle)==1
sealed=sealed.replace(needle,'end\n\n'+needle,1)
(r/'Sealed.lean').write_text(sealed)
header='import TCSlib.Complexity.Diagonalization.Ladner\nnamespace Complexity\nopen Turing\nopen scoped Classical\n'
deltas=['pairEncode ([] : List Bool) [] = [false, true]',
        'pairFstD ([] : List Bool) = []',
        'pairSndD ([] : List Bool) = []',
        'LogProg.bitsVal [] = 0',
        'BinArith.encWords [] = []',
        'BinArith.decWords [] = []',
        'BinArith.countW [] = []',
        'BinArith.lt [] = false',
        'BinArith.getW [] = []']
unsealed=header
for goal in deltas:
    if 'BinArith.decWords' in goal:
        unsealed+=f'example : True := by\n  fail_if_success\n    have : {goal} := by rfl\n  exact True.intro\n'
    else: unsealed+=f'example : {goal} := by rfl\n'
unsealed+='end Complexity\n'
(r/'ControlsUnsealed.lean').write_text(unsealed)
control=header+seals
for goal in deltas:
    control+=f'example : True := by\n  fail_if_success\n    have : {goal} := by rfl\n  exact True.intro\n'
control+='example (a b : List Bool) :\n    pairEncode a b = (a.flatMap fun c => [c, c]) ++ [false, true] ++ b :=\n  pairEncode_eq a b\nexample (a b : List Bool) : pairFstD (pairEncode a b) = a := pairFstD_pairEncode a b\nexample (a b : List Bool) : pairSndD (pairEncode a b) = b := pairSndD_pairEncode a b\nexample (n : ℕ) : LogProg.bitsVal (Nat.bits n) = n := LogProg.bitsVal_bits n\nexample (L : List (List Bool)) (w : List Bool) :\n    BinArith.encWords (L ++ [w]) = BinArith.encWords L ++ pairEncode w [] :=\n  BinArith.encWords_append_singleton L w\nexample (L : List (List Bool)) : BinArith.decWords (BinArith.encWords L) = L :=\n  BinArith.decWords_encWords L\nexample (w : List Bool) : BinArith.countW w = List.replicate (BinArith.decWords w).length true :=\n  BinArith.countW_eq w\nexample (a b : ℕ) : BinArith.lt (pairEncode (Nat.bits a) (Nat.bits b)) = decide (a < b) :=\n  BinArith.lt_pairEncode a b\nexample (J : List Bool) (vs : List ℕ) :\n    BinArith.getW (pairEncode J (BinArith.encWords (vs.map Nat.bits))) =\n      Nat.bits (vs.getD J.length 0) :=\n  BinArith.getW_pairEncode_bits J vs\nend\nend Complexity\n'
(r/'ControlsSealed.lean').write_text(control)
print('Generated axiom wrappers, sealed source, 8 paired delta controls, native-irreducible decWords control, and 9 equation controls.')
