from pathlib import Path
import subprocess,os,datetime,sys
r=Path('/private/tmp/ladner-poly-memo-20261115')
wt=Path('/Users/seyoonr/.codex/worktrees/ladner-poly-memo/tcslib-exchange')
env=dict(os.environ,PATH=str(r/'bin')+':'+os.environ['PATH'],TCSLIB_LEAN_SLOTS='3',TCSLIB_SCRATCH='/Users/seyoonr/.tcslib-scratch')
def run(label,file,compile=False):
    log=r/'evidence/logs'/f'{label}.log'
    cmd=['bash',str(wt/'devtools/seyoon'/('leanelab-o.sh' if compile else 'leanelab.sh')),str(wt),str(r/'oleans'),file]
    if compile: cmd.append(str(r/'oleans'))
    source=Path(file) if Path(file).is_absolute() else wt/file
    digest=''
    if source.is_file():
        import hashlib
        digest=hashlib.sha256(source.read_bytes()).hexdigest()
    product=r/'oleans'/Path(file).with_suffix('.olean') if compile else None
    if product is not None and product.exists(): product.unlink()
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(f'{start} START {label}',flush=True)
    with log.open('w') as f:
        f.write(f'{start} START {cmd!r}\nsource_sha256={digest}\n'); f.flush()
        p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
        end=datetime.datetime.now(datetime.timezone.utc).isoformat()
        f.write(f'\n{end} END exit_code={p.returncode}\n')
    output=log.read_text()
    if p.returncode==0 and ('error:' in output or (product is not None and (not product.is_file() or product.stat().st_size==0))):
        print('FAIL: diagnostic or missing fresh olean',flush=True)
        return 1
    with (r/'evidence/logs/check-summary.log').open('a') as f: f.write(f'{start} {end} {label} exit_code={p.returncode}\n')
    print(f'{end} END {label} exit_code={p.returncode}',flush=True)
    if p.returncode: print(log.read_text(),flush=True)
    return p.returncode
if sys.argv[1]=='bootstrap':
    for module in (r/'evidence/logs/bootstrap-order.txt').read_text().splitlines():
        if module in ['TCSlib/Complexity/Diagonalization/Ladner','TCSlib/Complexity/Diagonalization']: continue
        if run('bootstrap-'+module.replace('/','_'),module+'.lean',True): sys.exit(1)
else:
    sys.exit(run(sys.argv[1],sys.argv[2],len(sys.argv)>3 and sys.argv[3]=='olean'))
