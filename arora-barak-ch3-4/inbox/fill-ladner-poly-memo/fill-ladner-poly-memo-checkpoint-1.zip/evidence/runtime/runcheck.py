from pathlib import Path
import subprocess,os,datetime,sys
r=Path('/private/tmp/ladner-poly-memo-20261115')
wt=Path('/Users/seyoonr/.codex/worktrees/ladner-poly-memo/tcslib-exchange')
env=dict(os.environ,PATH=str(r/'bin')+':'+os.environ['PATH'],TCSLIB_LEAN_SLOTS='3',TCSLIB_SCRATCH='/Users/seyoonr/.tcslib-scratch')
def run(label,file,compile=False):
    log=r/'evidence/logs'/f'{label}.log'
    cmd=['bash',str(wt/'devtools/seyoon'/('leanelab-o.sh' if compile else 'leanelab.sh')),str(wt),str(r/'oleans'),file]
    if compile: cmd.append(str(r/'oleans'))
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(f'{start} START {label}',flush=True)
    with log.open('w') as f:
        f.write(f'{start} START {cmd!r}\n'); f.flush()
        p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
        end=datetime.datetime.now(datetime.timezone.utc).isoformat()
        f.write(f'\n{end} END exit_code={p.returncode}\n')
    with (r/'evidence/logs/check-summary.log').open('a') as f: f.write(f'{start} {end} {label} exit_code={p.returncode}\n')
    print(f'{end} END {label} exit_code={p.returncode}',flush=True)
    if p.returncode: print(log.read_text(),flush=True)
    return p.returncode
if sys.argv[1]=='bootstrap':
    for module in (r/'evidence/logs/bootstrap-order.txt').read_text().splitlines():
        if module in ['TCSlib/Complexity/Diagonalization/Ladner','TCSlib/Complexity/Diagonalization']: continue
        if run('bootstrap-'+module.replace('/','_'),module+'.lean',True): sys.exit(1)
else:
    sys.exit(run(sys.argv[1],sys.argv[2],len(sys.argv)>3 and sys.argv[3]=='olean'))
