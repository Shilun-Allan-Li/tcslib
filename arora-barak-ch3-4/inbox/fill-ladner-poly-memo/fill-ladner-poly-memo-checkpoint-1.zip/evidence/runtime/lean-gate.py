#!/usr/bin/env python3
import subprocess,datetime,time,os,sys
log='/private/tmp/ladner-poly-memo-20261115/evidence/logs/concurrency.log'
while True:
    p=subprocess.run(['ps','-axo','comm='],capture_output=True,text=True,check=True)
    count=sum(s.strip().rsplit('/',1)[-1]=='lean' for s in p.stdout.splitlines())
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with open(log,'a') as f: f.write(f'{stamp} {"LAUNCH" if count < 3 else "WAIT"} machine_lean_count={count} argv={sys.argv[1:]!r}\n')
    if count < 3: break
    time.sleep(5)
os.execv('/usr/bin/time',['/usr/bin/time','-l','/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin/lean',*sys.argv[1:]])
