# Ladner fill 4 — checkpoint 1

Status: IN PROGRESS, unverified proof draft. This checkpoint is not a passing final delivery.

Base: `1320a5c8ce93f4644c2c92ed32e2768ed07ea9bb`. Local branch: `fill/ladner-poly-memo`; never rebased.

The exact bundled reorder was committed alone as `a3516fbcacc6ce16fda7f082defb7f2804143886`.
Its Ladner SHA-256 is `4c9a04c3b28ae8a43cfded8ebdca4bf57b638214e82dabdccce7cd966ff0d914` (PASS).
Bundle SHA-256 and all 15 sections verified.

The draft adds selection through an exact all-round orbit equation (in place of the suggested measure helper), `stage_correct`, memo FP/orbit/size/readout, and the target assembly. This code has not been elaborated yet. The serial import-closure bootstrap is active; final source/facade/axiom/sealing checks are pending. No escalation is declared.

The native macOS preflight passed: 12 logical CPUs, 18 GiB physical RAM, memory_pressure 58% free initially, about 164 GiB APFS free. `.lake/packages` is the authorized main-campaign symlink; every present package matches the manifest, 7544 dependency oleans checked, none empty; Mathlib root probe exit 0. No cache fetched. No other TCSlib object tree reused, no `lake build`.

Lean runs through the inspected `leanelab[-o].sh` with the existing shared `/Users/seyoonr/.tcslib-scratch/locks/lean-slot-*` protocol, `TCSLIB_LEAN_SLOTS=3`. A PATH shim counts `ps -axo comm=` names whose last slash component is exactly `lean` immediately before each launch, logs count/timestamp, and waits/recounts every five seconds if the count is at least 3. One Lean process of this fill at a time. Module starts/ends, statuses and `/usr/bin/time -l` peak RSS are in the logs. No slot waits so far. The checkpoint snapshots active logs without relocating them.

Helper search evidence is `evidence/logs/helper-search.log`. Foreign definitions used by the draft are read via pairing/projection equations, `countW_eq`, `decWords_encWords`, `encWords_append_singleton`, `length_encWords_le`, `lt_pairEncode`, `bitsVal_bits`, and `getW_pairEncode_bits`; final Rule 10 verification remains pending.

Only `TCSlib/Complexity/Diagonalization/Ladner.lean` is modified in the Lean worktree. The included patch is cumulative against the base and includes the reorder plus the uncommitted draft. The four other target declarations remain byte-identical. No branch other than the exchange is pushed and no PR is opened.
