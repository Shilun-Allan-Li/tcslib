from pathlib import Path
import json

WT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-bridge/tcslib-exchange')
P = WT / 'evidence/probes'
rows = [json.loads(s.split('BOUNDARY|', 1)[1]) for s in (WT / 'evidence/logs/metadata.log').read_text().splitlines() if 'BOUNDARY|' in s]
assert len(rows) == 4
(WT / 'evidence/logs/boundaries.json').write_text(json.dumps(rows, indent=2) + '\n')
parser = (WT / 'devtools/seyoon/declfreeze.py').read_text().split('a = chunks(open(sys.argv[1]).read())')[0]
ns = {}
exec(compile(parser, 'declfreeze', 'exec'), ns)

guard = '''
open Lean Elab Command Meta in
run_cmd do
  let env ← getEnv
  let st ← liftTermElabM getSimpTheorems
  let heads : List Name := HEADS
  for n in heads do
    match getReducibilityStatusCore env n with
    | .irreducible => pure ()
    | _ => throwError "NOT_IRREDUCIBLE|{n}"
    if st.toUnfold.contains n || st.isLemma (.decl n) then
      throwError "SIMP_STILL_ACTIVE|{n}"
    logInfo m!"GUARD_ACTIVE|{n}"
'''

def names(heads):
    return '[' + ', '.join('`' + h for h in heads) + ']'

for i, row in enumerate(rows, 1):
    owner = row['owner'].replace('.', '/') + '.lean'
    whole = (WT / owner).read_text()
    root = row['root']
    chunk = next(t for n, _, t in ns['chunks'](whole) if n == root)
    assert whole.count(chunk) == 1
    start = whole.index(chunk)
    heads = row['ordinary_foreign_heads']
    remove = sorted(d['name'] for d in row['foreign_definitions'] if d['ordinary'] and (d['simp'] or d['unfold']))
    source = whole[:start] + 'section ReaderSeal\nattribute [local irreducible] ' + ' '.join(heads) + '\n'
    if remove:
        source += 'attribute [-simp] ' + ' '.join(remove) + '\n'
    source += chunk + '\n' + guard.replace('HEADS', names(heads)) + '\nend ReaderSeal\nend WordRAM\n'
    assert source.count('import TCSlib.') > 0
    first_import = source.index('import TCSlib.')
    source = source[:first_import] + 'import Lean\n' + source[first_import:]
    (P / f'Seal{i}.lean').write_text(source)

heads = sorted({h for row in rows for h in row['ordinary_foreign_heads']})
remove = sorted({d['name'] for row in rows for d in row['foreign_definitions'] if d['ordinary'] and (d['simp'] or d['unfold'])})
control = '''
open Lean Meta Elab Command in
run_cmd do
  let env ← getEnv
  let heads : List Name := HEADS
  for n in heads do
    let some (.defnInfo di) := env.find? n | throwError "missing definition {n}"
    let lhs := mkConst n (di.levelParams.map Level.param)
    let delta ← liftTermElabM <| withTransparency .default <| isDefEq lhs di.value
    let equation ← liftTermElabM <| withTransparency .default do
      let actual ← inferType (← mkEqRefl lhs)
      let expected ← mkEq lhs di.value
      isDefEq actual expected
    logInfo m!"DELTA_CONTROL|{n}|{delta}"
    logInfo m!"EQUATION_CONTROL|{n}|{equation}"
    unless delta == EXPECTED && equation == EXPECTED do
      throwError "control failed for {n}"
'''.replace('HEADS', names(heads))
imports = 'import Lean\nimport TCSlib.Complexity.RAMSimulation.Classes\nset_option maxHeartbeats 0\n'
(P / 'ControlsOpen.lean').write_text(imports + control.replace('EXPECTED', 'true'))
sealed = imports + 'attribute [local irreducible] ' + ' '.join(heads) + '\n'
if remove:
    sealed += 'attribute [-simp] ' + ' '.join(remove) + '\n'
sealed += control.replace('EXPECTED', 'false')
(P / 'ControlsSealed.lean').write_text(sealed)
print('Prepared four target seals and two control probes for', len(heads), 'definitions')
