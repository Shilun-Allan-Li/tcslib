from pathlib import Path
import datetime, os, subprocess, sys, time

WT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-bridge/tcslib-exchange')
LOG = WT / 'evidence/logs'
OL = WT / 'evidence/oleans'
env = os.environ.copy()
env['TCSLIB_LEAN_SLOTS'] = '3'
env['PATH'] = '/Users/seyoonr/.elan/bin:' + env['PATH']

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def lean_processes():
    out = subprocess.check_output(['ps', '-axww', '-o', 'pid=,stat=,comm='], text=True)
    return [line for line in out.splitlines() if len(line.split()) >= 3
            and Path(line.split()[2]).name == 'lean' and not line.split()[1].startswith('Z')]

def check(file, name, emit=True):
    with (LOG / 'lean-processes.log').open('a', buffering=1) as processes:
        while True:
            active = lean_processes()
            processes.write(f'{stamp()} before {name}: count={len(active)}\n' + '\n'.join(active) + '\n')
            if len(active) < 3:
                break
            processes.write('WAIT: machine-wide limit\n')
            time.sleep(2)
    output = OL / (file.removesuffix('.lean') + '.olean')
    if emit:
        output.unlink(missing_ok=True)
    log_path = LOG / (name + '.log')
    wrapper = WT / 'devtools/seyoon' / ('leanelab-o.sh' if emit else 'leanelab.sh')
    cmd = ['/usr/bin/time', '-l', 'bash', str(wrapper), str(WT), str(OL), file]
    if emit:
        cmd.append(str(OL))
    start = stamp()
    print(start, 'START', name, flush=True)
    with log_path.open('w', buffering=1) as log:
        log.write('START ' + start + '\n$ ' + ' '.join(cmd) + '\n')
        p = subprocess.run(cmd, cwd=WT, env=env, stdout=log, stderr=subprocess.STDOUT)
        log.write('END ' + stamp() + '\nLEAN_EXIT=' + str(p.returncode) + '\n')
    text = log_path.read_text()
    success = p.returncode == 0 and 'error:' not in text and (not emit or output.is_file() and output.stat().st_size > 0)
    with (LOG / 'checks.tsv').open('a') as index:
        index.write(f'{name}\t{file}\t{start}\t{stamp()}\t{p.returncode}\t{int(success)}\n')
    print(stamp(), 'PASS' if success else 'FAIL', name, flush=True)
    if not success:
        print(text[-16000:], flush=True)
        raise SystemExit(1)

if __name__ == '__main__':
    if sys.argv[1] == 'bootstrap':
        check('evidence/probes/CacheProbe.lean', 'cache-probe', False)
        for i, module in enumerate((LOG / 'bootstrap-order.txt').read_text().splitlines()):
            check(module + '.lean', f'bootstrap-{i:03d}-' + module.rsplit('/', 1)[-1])
    elif sys.argv[1] == 'seals':
        for i in range(1, 5):
            check(f'evidence/probes/Seal{i}.lean', f'seal-{i}', False)
        check('evidence/probes/ControlsOpen.lean', 'controls-open', False)
        check('evidence/probes/ControlsSealed.lean', 'controls-sealed', False)
    else:
        check(sys.argv[1], sys.argv[2], '--no-emit' not in sys.argv)
