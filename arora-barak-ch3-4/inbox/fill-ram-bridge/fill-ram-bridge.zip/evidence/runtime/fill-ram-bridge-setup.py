from pathlib import Path
import datetime, hashlib, json, os, re, subprocess

WT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-bridge/tcslib-exchange')
LOG = WT / 'evidence/logs'
LOG.mkdir(parents=True, exist_ok=True)

def run(args):
    p = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return p.returncode, p.stdout

with (LOG / 'preflight.log').open('w') as log:
    log.write(datetime.datetime.now(datetime.timezone.utc).isoformat() + '\n')
    for args in [['uname', '-a'], ['sysctl', 'hw.ncpu', 'hw.memsize'], ['vm_stat'],
                 ['memory_pressure'], ['df', '-kP', str(WT), '/private/tmp'],
                 ['stat', '-f', '%T', str(WT), '/private/tmp']]:
        code, out = run(args)
        log.write('$ ' + ' '.join(args) + '\n' + out + 'exit=' + str(code) + '\n')
    log.write('macOS/APFS: no cgroup or /proc/meminfo; sysctl, vm_stat and memory_pressure are native equivalents.\n')
    log.write('No toolchain installation or cache fetch; pinned installed v4.25.0 and explicitly allowed package symlink.\n')
    code, out = run(['ps', '-axww', '-o', 'pid=,stat=,comm='])
    active = [s for s in out.splitlines() if len(s.split()) >= 3 and Path(s.split()[2]).name == 'lean' and not s.split()[1].startswith('Z')]
    log.write('Initial Lean processes=' + str(len(active)) + '\n' + '\n'.join(active) + '\n')
    free = os.statvfs(WT).f_bavail * os.statvfs(WT).f_frsize
    _, pressure = run(['memory_pressure'])
    pct = int(re.search(r'System-wide memory free percentage: (\d+)%', pressure).group(1))
    _, mem = run(['sysctl', '-n', 'hw.memsize'])
    headroom = int(mem.strip()) * pct // 100
    log.write(f'Free disk bytes={free}; memory_pressure free={pct}%; estimated headroom bytes={headroom}\n')
    assert free >= 12 * 1024**3, 'E-RES disk'
    assert headroom >= 4 * 1024**3, 'E-RES memory'
    log.write('PREFLIGHT PASS\n')

manifest = json.loads((WT / 'lake-manifest.json').read_text())
with (LOG / 'package-pins.log').open('w') as log:
    present = 0
    for p in manifest['packages']:
        path = WT / '.lake/packages' / p['name']
        if not path.exists():
            log.write(p['name'] + ' ABSENT\n')
            continue
        _, url = run(['git', '-C', str(path), 'remote', 'get-url', 'origin'])
        _, rev = run(['git', '-C', str(path), 'rev-parse', 'HEAD'])
        assert url.strip() == p['url'], (p['name'], url, p['url'])
        assert rev.strip() == p['rev'], (p['name'], rev, p['rev'])
        present += 1
        log.write(f"{p['name']} {url.strip()} {rev.strip()} MATCH\n")
    log.write(f'PASS: all {present} present packages match manifest URL and revision.\n')

seen = set()
order = []
roots = set()
def visit(module):
    if module in seen:
        return
    seen.add(module)
    source = WT / (module.replace('.', '/') + '.lean')
    assert source.is_file(), module
    for line in source.read_text().splitlines():
        if line.startswith('import '):
            for imp in line.split()[1:]:
                if imp.startswith('TCSlib'):
                    visit(imp)
                elif imp.startswith('Mathlib'):
                    roots.add(imp)
    order.append(module.replace('.', '/'))

visit('TCSlib.Complexity.RAMSimulation.WordSize')
visit('TCSlib.Complexity.RAMSimulation.Classes')
visit('TCSlib.Complexity.RAMSimulation')
(LOG / 'bootstrap-order.txt').write_text('\n'.join(order) + '\n')
(LOG / 'mathlib-roots.txt').write_text('\n'.join(sorted(roots)) + '\n')
(WT / 'evidence/probes/CacheProbe.lean').write_text('import ' + sorted(roots)[0] + '\n')
with (LOG / 'cache-validation.log').open('w') as log:
    empty = []
    for p in (WT / '.lake/packages').glob('*/.lake/build/lib/lean/**/*.olean'):
        if p.stat().st_size == 0:
            empty.append(str(p))
    log.write(f'Package symlink: {(WT / ".lake/packages").resolve()}\n')
    log.write(f'Mathlib roots={len(roots)}; TCSlib bootstrap modules={len(order)}\n')
    log.write('Zero-size oleans: ' + json.dumps(empty) + '\n')
    assert not empty

print('Setup complete:', len(order), 'TCSlib modules;', len(roots), 'Mathlib roots')
