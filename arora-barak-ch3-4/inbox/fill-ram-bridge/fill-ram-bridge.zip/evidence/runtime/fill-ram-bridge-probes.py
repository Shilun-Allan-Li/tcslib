from pathlib import Path
import ast, json, subprocess

WT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-bridge/tcslib-exchange')
PROBES = WT / 'evidence/probes'
TARGETS = [
    'WordRAM.wordSizeComputable_of_timeConstructible',
    'WordRAM.wordSizeComputable_poly',
    'WordRAM.polyTimeComputable_of_computes',
    'WordRAM.polyTimeComputable_progOut',
]
owners = ['TCSlib/Complexity/RAMSimulation/WordSize.lean', 'TCSlib/Complexity/RAMSimulation/Classes.lean']

walk = (WT / 'campaign/gates/163-ram-fill-classes/evidence/AdmissionWalk.lean.txt').read_text()
walk = walk.split('#walk WordRAM.mem_DTIME_of_decides')[0]
walk += '\n'.join('#print axioms ' + n for n in TARGETS) + '\n'
walk += '\n'.join('#walk ' + n for n in TARGETS) + '\n'
walk += '#eval Lean.versionString\n'
(PROBES / 'Axioms.lean').write_text(walk)

metadata = (WT / 'devtools/seyoon/gatekit/templates/MetadataBody.lean.txt').read_text()
start = metadata.index('  let target := ')
end = metadata.index('  for root in roots do')
metadata = metadata[:start] + '  let roots : List Name := [' + ', '.join('`' + n for n in TARGETS) + ']\n' + metadata[end:]
metadata = 'import Lean\nimport TCSlib.Complexity.RAMSimulation.Classes\n' + metadata
(PROBES / 'Metadata.lean').write_text(metadata)

parser = (WT / 'devtools/seyoon/declfreeze.py').read_text().split('a = chunks(open(sys.argv[1]).read())')[0]
ns = {}
exec(compile(parser, 'declfreeze', 'exec'), ns)
with (WT / 'evidence/logs/statement-freeze.log').open('w') as log:
    for path in owners:
        base = subprocess.check_output(['git', 'show', 'e5fe99819b8ceb11f43894964630a594eb61ff0a:' + path], cwd=WT, text=True)
        current = (WT / path).read_text()
        before, after = ns['chunks'](base), ns['chunks'](current)
        assert [n for n, _, _ in before] == [n for n, _, _ in after]
        log.write(f'{path}: declarations before={len(before)} after={len(after)}; ordered names identical\n')
        for (name, priv, old), (_, new_priv, new) in zip(before, after):
            assert priv == new_priv
            def signature(s):
                s = s.split('-/', 1)[1] if s.startswith('/--') else s
                return s.split(':=', 1)[0]
            assert signature(old) == signature(new), name
            if old != new:
                assert name in TARGETS, name
                log.write('AUTHORIZED TARGET BODY/SKETCH: ' + name + '\n')
        log.write('PASS: byte-identical existing statements; no declarations added or removed.\n')
print('Wrote axiom, dependency and metadata probes; statement freeze PASS')
