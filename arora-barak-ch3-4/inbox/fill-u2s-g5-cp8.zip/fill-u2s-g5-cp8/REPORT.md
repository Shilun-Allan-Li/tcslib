# Fill u2s-g5 — checkpoint 8 zip (`fill-u2s-g5-cp8.zip`)

**Checkpoint 8 of 9**, at commit `03e13d294718b07b5e9b4c0db3262a5100711212` of `fill/u2s-g5` (base
`335d31d408f1b4b4164f5b1b3a37d246a42b25cc`); 1651 lines. Contents at this commit: checkpoint 5 plus the converse property (`tt_converse`).
The target's body ends in its own `sorry`, the open time bound (checkpoints 6–7).

**This zip was assembled after the fill was complete** (the final delivery, `fill-u2s-g5.zip`,
proves `two_work_tapes_run` with no admission; its `REPORT.md` is the full report). Run on this
commit's file (`evidence/logs/cp8/`):
- module check: exit 0, one warning, the target's `declaration uses 'sorry'`;
- seal (43 definitions, `evidence/seal/`): **exit 1** — one rule-10 violation: a `show` in `tt_cs_start` (`[] = List.map Sum.inl (tt_c M x 0).output`, the equation the wrong way round) closed only by unfolding `runFrom`/`Cfg.init`. Found by the final seal and **fixed in `71046be0`** (it now rewrites with `Cfg.init_output`); the delivered final file passes the seal with no diagnostic;
- controls: 89 CONTROL_PASS unsealed, 89 CONTROL_FAIL sealed;
- axiom prints: `sorryAx` only in `two_work_tapes_run` and `two_work_tapes_binary`.

Environment, cache and bootstrap logs are the session's; the before screen is in `screens/`; the
after screens were run at checkpoint 3 and at the final commit (see those zips). Escalations: none.
