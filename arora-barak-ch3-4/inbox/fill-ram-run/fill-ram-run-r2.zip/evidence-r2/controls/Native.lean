import Lean
import TCSlib.Complexity.RAMSimulation.Simulation
set_option maxHeartbeats 0
set_option maxErrors 1000
set_option maxRecDepth 4096
set_option smartUnfolding false
set_option autoImplicit false
set_option relaxedAutoImplicit false
attribute [-simp] Turing.Action.apply Turing.Cfg.init Turing.MultiTapeTM.initCfg Turing.NDTM.initCfg
open Lean Elab Command Meta in
run_cmd do
  let targets : List Name := [``Complexity.logSpace, ``Turing.Action.apply, ``Turing.Action.mapState, ``Turing.Cfg.init, ``Turing.Cfg.inputSymbol, ``Turing.Cfg.mapState, ``Turing.Cfg.workTapeSymbols, ``Turing.FinNDTM.AcceptsWithin, ``Turing.FinTM.ComputesInTime, ``Turing.FinTM.bufferTape, ``Turing.KeyTableAt, ``Turing.MultiTapeTM.initCfg, ``Turing.MultiTapeTM.runFrom, ``Turing.MultiTapeTM.spaceUsed, ``Turing.MultiTapeTM.spaceUsedByTape, ``Turing.MultiTapeTM.step, ``Turing.MultiTapeTM.toNDTM, ``Turing.MultiTapeTM.visitedByTapeHead, ``Turing.NDTM.HaltsWithin, ``Turing.NDTM.fixChoice, ``Turing.NDTM.initCfg, ``Turing.NDTM.phaseHostND, ``Turing.NDTM.runWith, ``Turing.NDTM.spaceUsedWith, ``Turing.NDTM.stepWith, ``Turing.NDTM.visitedWith, ``Turing.ReachesWithin, ``Turing.TableAt, ``Turing.WordAt, ``Turing.embedEmitCfg, ``Turing.embedEmitTM, ``Turing.fieldsTape, ``Turing.joinFields, ``Turing.keyFields, ``Turing.keyTableLength, ``Turing.phaseHostTM, ``Turing.tableFields, ``WordRAM.HaltsWithin, ``WordRAM.InRange, ``WordRAM.Sim.Encodes, ``WordRAM.Sim.ImmBound, ``WordRAM.Sim.RunCoinsAgree, ``WordRAM.Sim.RunCoinsSatisfy, ``WordRAM.Sim.RunDriver.Follows, ``WordRAM.Sim.RunDriver.Respects, ``WordRAM.Sim.RunDriver.ofCoins, ``WordRAM.Sim.RunDriver.ofSchedule, ``WordRAM.Sim.RunSetup.blockRadius, ``WordRAM.Sim.RunSetup.blockTime, ``WordRAM.Sim.RunSetup.boundCost, ``WordRAM.Sim.RunSetup.host, ``WordRAM.Sim.RunSetup.phase, ``WordRAM.Sim.RunSetup.phaseCost, ``WordRAM.Sim.RunSetup.phaseDecidableEq, ``WordRAM.Sim.RunSetup.phaseFintype, ``WordRAM.Sim.RunSetup.redirect, ``WordRAM.Sim.RunSetup.resumeTag, ``WordRAM.Sim.TableOf, ``WordRAM.Sim.immediates, ``WordRAM.Sim.isCoin, ``WordRAM.Sim.isVerdict, ``WordRAM.Sim.jumpTarget, ``WordRAM.Sim.runBank, ``WordRAM.Sim.runChoices, ``WordRAM.Sim.runEmbedND, ``WordRAM.Sim.runNextCoins, ``WordRAM.Sim.runPosition, ``WordRAM.WordSizeComputable, ``WordRAM.XCfg.init, ``WordRAM.XInstr.touches, ``WordRAM.XStepsIn, ``WordRAM.coinWord, ``WordRAM.effect, ``WordRAM.inBitWord, ``WordRAM.initMem, ``WordRAM.xstep]
  let mut i : Nat := 0
  for name in targets do
    let some (.defnInfo info) := (← getEnv).find? name | throwError "not ordinary definition {name}"
    for mode in ["point", "abstract"] do
      i := i + 1
      let result ← liftTermElabM do
        let levels := info.levelParams.map Level.param
        let head := mkConst name levels
        let solve := fun (lhs rhs : Expr) => do
          let ty ← mkEq lhs rhs
          let goal ← mkFreshExprSyntheticOpaqueMVar ty
          try
            withConfig (fun config => { config with etaStruct := .notClasses }) goal.mvarId!.refl
            pure (some (ty, ← instantiateMVars goal))
          catch _ =>
            logInfo m!"CONTROL|{i}|{name}|{mode}|FAIL"
            logError m!"CONTROL_RFL|{i}|{name}|{mode}|rfl did not close reflected identity"
            pure none
        if mode == "abstract" then solve head info.value
        else forallTelescopeReducing info.type fun xs _ => do
          if xs.isEmpty then
            let unitTy := mkConst ``Unit
            solve (Expr.lam `_u unitTy head .default)
              (Expr.lam `_u unitTy info.value .default)
          else
            let result ← solve (mkAppN head xs) ((mkAppN info.value xs).headBeta)
            match result with
            | none => pure none
            | some (ty, value) => pure (some (← mkForallFVars xs ty, ← mkLambdaFVars xs value))
      if let some (ty, value) := result then
        let ty ← liftTermElabM <| instantiateMVars ty
        let value ← liftTermElabM <| instantiateMVars value
        if ty.hasFVar || ty.hasMVar || value.hasFVar || value.hasMVar then
          throwError "unclosed control {i}"
        let kernelName := Name.mkSimple ("ReaderRepairControl_" ++ toString i)
        liftCoreM <| addDecl (.thmDecl { name := kernelName, levelParams := info.levelParams, type := ty, value := value })
        logInfo m!"CONTROL|{i}|{name}|{mode}|PASS|kernelChecked={kernelName}"
  logInfo m!"CONTROL_COMPLETE|{i}"
