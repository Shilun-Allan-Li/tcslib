from pathlib import Path
import json,hashlib,shutil,zipfile,re
root=Path.cwd();stage=root/'delivery-r2';stage.mkdir(exist_ok=True)
paths=(root/'evidence-r2/logs/delivery-paths.txt').read_text().splitlines()
assert json.loads((root/'evidence-r2/logs/patch-roundtrip.json').read_text())['pass']
assert json.loads((root/'evidence-r2/seals/RESULT.json').read_text())['pass']
assert json.loads((root/'evidence-r2/controls/RESULT.json').read_text())['pass']
for name in ['README.md','SHA256SUMS','BUNDLE-FILES.txt','fill-ram-run-bundle.md']:
    shutil.copyfile(root/'evidence/inputs'/name,root/'evidence-r2/inputs'/name)
for line in (root/'evidence-r2/inputs/SHA256SUMS').read_text().splitlines():
    digest,name=line.split();assert hashlib.sha256((root/'evidence-r2/inputs'/name).read_bytes()).hexdigest()==digest
for p in paths:
    target=stage/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,target)
shutil.copyfile(root/'fill-ram-run-r2.patch',stage/'fill-ram-run-r2.patch')
summary={'pass':True,'payload_sha256_verified':True,'zip_crc_verified':True,'patch_roundtrip_verified':True,'source_files':len(paths),'note':'The packaging script validates CRC, exact entry set and every SHA256SUMS entry after building; it aborts on any failure. The ZIP hash is recorded outside the archive to avoid a self-hash.'}
(root/'evidence-r2/logs/package-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
if (stage/'evidence-r2').exists():shutil.rmtree(stage/'evidence-r2')
shutil.copytree(root/'evidence-r2',stage/'evidence-r2',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
files=sorted(p for p in stage.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
# Keep nested input manifests: only the top-level manifest is excluded from its own hash.
files=sorted(p for p in stage.rglob('*') if p.is_file() and p!=stage/'SHA256SUMS')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(stage))+'\n' for p in files)
(stage/'SHA256SUMS').write_text(manifest)
files=sorted(p for p in stage.rglob('*') if p.is_file())
assert not any('.git' in p.relative_to(stage).parts or '.lake' in p.relative_to(stage).parts or p.suffix in ['.olean','.ilean'] for p in files)
archive=root/'fill-ram-run-r2.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,str(p.relative_to(stage)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert sorted(z.namelist())==sorted(str(p.relative_to(stage)) for p in files)
    for line in z.read('SHA256SUMS').decode().splitlines():
        digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
    assert z.read('REPORT.md')==(stage/'REPORT.md').read_bytes()
    for p in paths:assert z.read(p)==(root/p).read_bytes()
result=summary|{'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'archive_entries':len(files)}
(root/'package-verification-r2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
