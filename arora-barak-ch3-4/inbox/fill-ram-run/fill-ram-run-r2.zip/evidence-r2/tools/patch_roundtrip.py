from pathlib import Path
import subprocess,tempfile,tarfile,io,hashlib,json
root=Path.cwd();paths=Path('evidence-r2/logs/delivery-paths.txt').read_text().splitlines();base='7342f98b58704d6c25faf668ed1a64ea0b27c4af'
old=[]
for p in paths:
    r=subprocess.run(['git','cat-file','-e',base+':'+p],capture_output=True)
    if r.returncode==0:old.append(p)
archive=subprocess.check_output(['git','archive',base,'--']+old)
with tempfile.TemporaryDirectory(prefix='fill-ram-run-r2-roundtrip-',dir='/private/tmp') as tmp:
    dest=Path(tmp)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for m in tar.getmembers():
            if not m.isfile():continue
            assert not m.name.startswith('/') and '..' not in Path(m.name).parts
            p=dest/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
    patch=str(root/'fill-ram-run-r2.patch')
    subprocess.run(['git','apply','--check',patch],cwd=dest,check=True)
    subprocess.run(['git','apply',patch],cwd=dest,check=True)
    rows=[]
    for rel in paths:
        a=(dest/rel).read_bytes();b=(root/rel).read_bytes();assert a==b,rel
        rows.append({'path':rel,'sha256':hashlib.sha256(a).hexdigest(),'bytes':len(a)})
    actual=sorted(str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file());assert actual==sorted(paths)
Path('evidence-r2/logs/patch-roundtrip.json').write_text(json.dumps({'pass':True,'base':base,'patch_apply_check_exit':0,'patch_apply_exit':0,'exact_source_files':rows},ensure_ascii=False,indent=2)+'\n')
print('Patch round-trip PASS:',len(rows),'exact source files')
