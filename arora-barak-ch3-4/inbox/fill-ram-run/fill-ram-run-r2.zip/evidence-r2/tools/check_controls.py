from pathlib import Path
import json,re,subprocess,sys
req=json.loads(Path('evidence-r2/controls/REQUEST.json').read_text());results=[]
for arm,heads in [('Native',req['heads']),('Sealed0',req['heads'][::2]),('Sealed1',req['heads'][1::2])]:
    tag='controls-'+arm.lower();expected_fail=arm!='Native'
    if expected_fail or '--reuse-native' not in sys.argv:
        r=subprocess.run([sys.executable,'evidence-r2/tools/check.py','evidence-r2/controls/'+arm,tag]);assert r.returncode==(1 if expected_fail else 0)
    log=Path('evidence-r2/logs/'+tag+'.log').read_text()
    rows=re.findall(r'CONTROL\|(\d+)\|([^|\n]+)\|(point|abstract)\|(PASS|FAIL)',log)
    expected={(n,k) for n in heads for k in ['point','abstract']}
    assert len(rows)==len(expected) and {(n,k) for _,n,k,_ in rows}==expected
    assert all(status==('FAIL' if expected_fail else 'PASS') for _,_,_,status in rows)
    errors=re.findall(r'^.*?:\d+:\d+: error:.*$',log,re.M)
    assert len(errors)==(len(expected) if expected_fail else 0) and all('CONTROL_RFL|' in e for e in errors)
    assert log.count('kernelChecked=')==(0 if expected_fail else len(expected))
    results.append({'arm':arm,'pass':True,'heads':len(heads),'identities':len(rows),'exit':1 if expected_fail else 0,'expected_failure':expected_fail,'log':'evidence-r2/logs/'+tag+'.log'})
Path('evidence-r2/controls/RESULT.json').write_text(json.dumps({'pass':True,'heads':len(req['heads']),'paired_identities':req['identities'],'arms':results},indent=2)+'\n')
print('PAIRED CONTROLS PASS',req['identities'],'identities for',len(req['heads']),'heads',flush=True)
