from pathlib import Path
import json, hashlib, re
root=Path.cwd(); data=json.loads((root/'evidence-r2/logs/metadata.json').read_text())
out=root/'evidence-r2/seals';out.mkdir(exist_ok=True)
rows=[]
owners=sorted({r['owner'] for r in data['BOUNDARY'].values() if '/Sim/' in r['owner'].replace('.','/') or r['owner'].endswith('.Simulation')})
for owner in owners:
    path=Path(owner.replace('.','/')+'.lean'); source=path.read_text()
    selected=[r for r in data['BOUNDARY'].values() if r['owner']==owner]
    heads={h['name']:h for r in selected for h in r['foreign_definitions'] if h['ordinary']}
    names=sorted(heads)
    removed=[n for n in names if heads[n]['simp'] or heads[n]['unfold']]
    attrs=('attribute [local irreducible] '+' '.join(names)+'\n') if names else ''
    if removed:attrs+='attribute [-simp] '+' '.join(removed)+'\n'
    at=source.index('\nnamespace ')
    probe=source[:at]+'\n'+attrs+source[at:]
    at=probe.index('import ');probe=probe[:at]+'import Lean\n'+probe[at:]
    probe+='''\nopen Lean Elab Command Meta in
run_cmd do
  let env ← getEnv
  let st ← liftTermElabM getSimpTheorems
  let names : List Name := ['''+', '.join('``'+n for n in names)+''']
  for n in names do
    match getReducibilityStatusCore env n with
    | .irreducible => pure ()
    | _ => throwError "NOT_IRREDUCIBLE|{n}"
    if st.toUnfold.contains n || st.isLemma (.decl n) then
      throwError "SIMP_STILL_ACTIVE|{n}"
    logInfo m!"GUARD_ACTIVE|{n}"
'''
    target=out/('Sealed'+path.stem+'.lean');target.write_text(probe)
    rows.append({'owner':owner,'source':str(path),'probe':str(target.relative_to(root)), 'heads':names,'simp_removed':removed,'proofs':len(selected),'source_sha256':hashlib.sha256(source.encode()).hexdigest()})
(out/'REQUEST.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('Prepared',len(rows),'complete-source seals for',sum(r['proofs'] for r in rows),'compiled proofs')
