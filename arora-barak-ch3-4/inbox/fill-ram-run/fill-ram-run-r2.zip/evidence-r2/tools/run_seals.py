from pathlib import Path
import sys,json,subprocess,re,datetime
rows=json.loads(Path('evidence-r2/seals/REQUEST.json').read_text());results=[]
for row in rows:
    mod=row['probe'][:-5];tag='seal-final-'+Path(mod).name
    r=subprocess.run([sys.executable,'evidence-r2/tools/check.py',mod,tag])
    log=Path('evidence-r2/logs/'+tag+'.log').read_text()
    active=sorted(re.findall(r'GUARD_ACTIVE\|([^\n]+)',log))
    ok=r.returncode==0 and active==row['heads']
    results.append(row|{'exit':r.returncode,'guards_match':active==row['heads'],'pass':ok,'log':'evidence-r2/logs/'+tag+'.log'})
    Path('evidence-r2/seals/RESULT.json').write_text(json.dumps({'pass':all(x['pass'] for x in results),'complete':len(results)==len(rows),'owners':results},ensure_ascii=False,indent=2)+'\n')
    if not ok:sys.exit(1)
print('ALL SEALS PASSED',len(results),'owners',flush=True)
