from pathlib import Path
import subprocess,sys,json
paths=[p for p in Path('evidence-r2/logs/delivery-paths.txt').read_text().splitlines() if '/Sim/Run' in p]
ordered=[];seen=set()
def visit(p):
    if p in seen:return
    seen.add(p)
    for l in Path(p).read_text().splitlines():
        if l.startswith('import '):
            dep=l[7:].replace('.','/')+'.lean'
            if dep in paths:visit(dep)
    ordered.append(p)
for p in paths:visit(p)
ordered=['TCSlib/Complexity/TuringMachine/Build/Embed.lean','TCSlib/Complexity/TuringMachine/NondeterministicSpace.lean','TCSlib/Complexity/RAMSimulation/WordSize.lean']+ordered+['TCSlib/Complexity/RAMSimulation/Simulation.lean','TCSlib/Complexity/RAMSimulation/Classes.lean','TCSlib/Complexity/RAMSimulation.lean','evidence-r2/probes/Axioms.lean']
results=[]
for p in ordered:
    mod=p[:-5];tag='final-'+mod.replace('/','__')
    r=subprocess.run([sys.executable,'evidence-r2/tools/check.py',mod,tag])
    results.append({'module':mod,'exit':r.returncode,'log':'evidence-r2/logs/'+tag+'.log'})
    Path('evidence-r2/logs/final-checks.json').write_text(json.dumps(results,indent=2)+'\n')
    if r.returncode:sys.exit(r.returncode)
print('ALL FINAL NATIVE CHECKS PASSED',len(results),flush=True)
r=subprocess.run([sys.executable,'evidence-r2/tools/run_seals.py']);sys.exit(r.returncode)
