from pathlib import Path
import json,re,subprocess,sys
results=[]
def check(mod,tag,expect=0):
    r=subprocess.run([sys.executable,'evidence-r2/tools/check.py',mod,tag])
    log=Path('evidence-r2/logs/'+tag+'.log').read_text()
    results.append({'module':mod,'tag':tag,'exit':r.returncode,'expected_exit':expect})
    Path('evidence-r2/logs/extra-checks.json').write_text(json.dumps(results,indent=2)+'\n')
    assert r.returncode==expect,(mod,r.returncode,expect)
    return log
check('evidence-r2/probes/PublicInventory','public-inventory')
check('evidence-r2/probes/DownstreamAxioms','downstream-axioms')
readerrows=json.loads(Path('evidence-r2/reader-seals/REQUEST.json').read_text())
for row in readerrows:
    tag='reader-seal-'+Path(row['probe']).stem
    log=check(row['probe'][:-5],tag)
    assert sorted(re.findall(r'GUARD_ACTIVE\|([^\n]+)',log))==row['heads']
subprocess.run([sys.executable,'evidence-r2/tools/check_controls.py'],check=True)
print('ALL EXTRA CHECKS PASSED',flush=True)
