from pathlib import Path
import re,json
D=json.loads(Path('evidence-r2/logs/metadata.json').read_text())['BOUNDARY']
heads={h['name']:h for r in D.values() for h in r['foreign_definitions'] if h['ordinary']}
names=sorted(heads);simp=sorted(n for n,h in heads.items() if h['simp'] or h['unfold'])
s=Path('devtools/seyoon/gatekit/templates/Native.lean.txt').read_text()
s=re.sub(r'^import TCSlib[^\n]*\n','',s,flags=re.M)
s=s.replace('import Lean\n','import Lean\nimport TCSlib.Complexity.RAMSimulation.Simulation\n')
s=re.sub(r'^attribute \[-simp\][^\n]*\n','',s,flags=re.M)
s=s.replace('set_option maxHeartbeats 0','set_option maxHeartbeats 0\nset_option maxErrors 1000')
s=s.replace('goal.mvarId!.refl','withConfig (fun config => { config with etaStruct := .notClasses }) goal.mvarId!.refl')
s=re.sub(r'^  let targets : List Name := .*$',lambda _: '  let targets : List Name := ['+', '.join('``'+n for n in names)+']',s,flags=re.M)
out=Path('evidence-r2/controls');out.mkdir(exist_ok=True)
for mode, selected in [('Native',names),('Sealed0',names[::2]),('Sealed1',names[1::2])]:
    attrs='attribute [-simp] '+' '.join(simp)+'\n' if simp else ''
    if mode!='Native':attrs+='attribute [local irreducible] '+' '.join(names)+'\n'
    body=re.sub(r'^  let targets : List Name := .*$',lambda _: '  let targets : List Name := ['+', '.join('``'+n for n in selected)+']',s,flags=re.M)
    (out/(mode+'.lean')).write_text(body.replace('open Lean Elab Command Meta in\n',attrs+'open Lean Elab Command Meta in\n'))
(out/'REQUEST.json').write_text(json.dumps({'heads':names,'simp_removed':simp,'identities':len(names)*2,'sealed_parts':2},ensure_ascii=False,indent=2)+'\n')
print('Prepared',len(names)*2,'paired reflected identities')
