from pathlib import Path
import json,sys
s=Path('evidence-r2/logs/'+sys.argv[1]+'.log').read_text();result={k:{} for k in ['SELECTED','BOUNDARY']}
for line in s.splitlines():
    for kind in result:
        if kind+'|' in line:
            r=json.loads(line.split(kind+'|',1)[1]);result[kind][r.get('name',r.get('root'))]=r
assert set(result['SELECTED'])==set(result['BOUNDARY']) and result['BOUNDARY']
assert all(not(set(r['axioms'])-{'propext','Quot.sound','Classical.choice','sorryAx'}) for r in result['SELECTED'].values())
Path('evidence-r2/logs/metadata.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Compiled metadata:',len(result['BOUNDARY']),'proofs')
