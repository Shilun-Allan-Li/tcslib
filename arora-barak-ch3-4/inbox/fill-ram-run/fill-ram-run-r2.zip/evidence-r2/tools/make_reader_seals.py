from pathlib import Path
import json,re
ns={};exec(compile(Path('devtools/seyoon/declfreeze.py').read_text().split('a = chunks(open(sys.argv[1]).read())')[0],'declfreeze','exec'),ns)
D=json.loads(Path('evidence-r2/logs/metadata.json').read_text())['BOUNDARY']
selected=['WordRAM.wordSizeComputable_iff','Turing.embedEmitTM_q₀','Turing.NDTM.visitedWith_eq','Turing.NDTM.spaceUsedWith_eq']
out=Path('evidence-r2/reader-seals');out.mkdir(exist_ok=True);rows=[]
for i,n in enumerate(selected,1):
    row=D[n];p=Path(row['owner'].replace('.','/')+'.lean');source=p.read_text()
    chunk=next(t for name,_,t in ns['chunks'](source) if name==n)
    at=source.index(chunk);end=at+len(chunk)
    heads={h['name']:h for h in row['foreign_definitions'] if h['ordinary']};names=sorted(heads)
    attrs='section ReaderSeal\n'
    if names:attrs+='attribute [local irreducible] '+' '.join(names)+'\n'
    removed=[n for n in names if heads[n]['simp'] or heads[n]['unfold']]
    if removed:attrs+='attribute [-simp] '+' '.join(removed)+'\n'
    guard='''\nopen Lean Elab Command Meta in
run_cmd do
  let env ← getEnv
  let st ← liftTermElabM getSimpTheorems
  let names : List Name := ['''+', '.join('``'+h for h in names)+''']
  for h in names do
    unless getReducibilityStatusCore env h == .irreducible do throwError "NOT_IRREDUCIBLE|{h}"
    if st.toUnfold.contains h || st.isLemma (.decl h) then throwError "SIMP_STILL_ACTIVE|{h}"
    logInfo m!"GUARD_ACTIVE|{h}"
end ReaderSeal
'''
    probe=source[:at]+attrs+chunk+guard+source[end:]
    at=probe.index('import ');probe=probe[:at]+'import Lean\n'+probe[at:]
    target=out/f'Reader{i}.lean';target.write_text(probe)
    rows.append({'name':n,'probe':str(target),'heads':names})
(out/'REQUEST.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('Prepared four home-file reader seals')
