import Lean
import TCSlib.Complexity.RAMSimulation.Simulation
set_option maxHeartbeats 0
#print axioms WordRAM.exists_simulation
#print axioms WordRAM.exists_ndSimulation
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for root in [``WordRAM.exists_simulation, ``WordRAM.exists_ndSimulation] do
    let mut todo : List Name := [root]
    let mut seen : Std.HashSet Name := {}
    let mut admissions : Array Name := #[]
    while !todo.isEmpty do
      let n := todo.head!
      todo := todo.tail!
      if seen.contains n then continue
      seen := seen.insert n
      let some ci := env.find? n | continue
      let usedValue := ci.value?.map Expr.getUsedConstants |>.getD #[]
      if usedValue.contains ``sorryAx then admissions := admissions.push n
      todo := ci.type.getUsedConstants.toList ++ usedValue.toList ++ todo
    for n in admissions.qsort Name.lt do
      logInfo m!"ADMISSION|{root}|{n}"
    logInfo m!"WALK|{root}|visited={seen.size}|direct_admissions={admissions.size}"
