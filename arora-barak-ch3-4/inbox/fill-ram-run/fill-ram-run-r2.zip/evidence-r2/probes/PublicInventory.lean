import Lean
import TCSlib.Complexity.RAMSimulation.Simulation
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut rows : Array (String × String) := #[]
  for (n, ci) in env.constants.toList do
    let home := match env.getModuleIdxFor? n with
      | some i => env.header.moduleNames[i.toNat]!.toString
      | none => ""
    if !home.startsWith "TCSlib.Complexity.RAMSimulation.Sim.Run" ||
        isPrivateName n || n.isInternalDetail then continue
    let k := match ci with
      | .thmInfo _ => "theorem"
      | .defnInfo _ => "definition"
      | .inductInfo _ => "inductive"
      | .ctorInfo _ => "constructor"
      | .recInfo _ => "recursor"
      | _ => "other"
    let r := Json.mkObj [("name",toJson n.toString),("owner",toJson home),("kind",toJson k)]
    rows := rows.push (n.toString,r.compress)
  for (_, r) in rows.qsort (fun a b => a.1 < b.1) do logInfo m!"DECL|{r}"
  logInfo m!"PUBLIC_DECLARATIONS|{rows.size}"
