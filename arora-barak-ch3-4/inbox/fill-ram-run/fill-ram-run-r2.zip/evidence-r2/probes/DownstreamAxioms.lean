import Lean
import TCSlib.Complexity.RAMSimulation.Classes
set_option maxHeartbeats 0
#print axioms WordRAM.exists_simulation
#print axioms WordRAM.exists_ndSimulation
#print axioms WordRAM.mem_DTIME_of_decides
#print axioms WordRAM.mem_P_of_decides
#print axioms WordRAM.mem_P_of_decides_logWord
#print axioms WordRAM.mem_SPACE_of_decides
#print axioms WordRAM.mem_LOGSPACE_of_decides
#print axioms WordRAM.computesInSpace_of_computes
#print axioms WordRAM.mem_SPACE_mul_of_decides
#print axioms WordRAM.mem_NSPACE_of_accepts
#print axioms WordRAM.mem_NL_of_accepts
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for root in [``WordRAM.exists_simulation, ``WordRAM.exists_ndSimulation, ``WordRAM.mem_DTIME_of_decides, ``WordRAM.mem_P_of_decides, ``WordRAM.mem_P_of_decides_logWord, ``WordRAM.mem_SPACE_of_decides, ``WordRAM.mem_LOGSPACE_of_decides, ``WordRAM.computesInSpace_of_computes, ``WordRAM.mem_SPACE_mul_of_decides, ``WordRAM.mem_NSPACE_of_accepts, ``WordRAM.mem_NL_of_accepts] do
    let mut todo : List Name := [root]
    let mut seen : Std.HashSet Name := {}
    let mut admissions : Array Name := #[]
    while !todo.isEmpty do
      let n := todo.head!
      todo := todo.tail!
      if seen.contains n then continue
      seen := seen.insert n
      let some ci := env.find? n | continue
      let usedValue := ci.value?.map Expr.getUsedConstants |>.getD #[]
      if usedValue.contains ``sorryAx then admissions := admissions.push n
      todo := ci.type.getUsedConstants.toList ++ usedValue.toList ++ todo
    for n in admissions.qsort Name.lt do
      logInfo m!"ADMISSION|{root}|{n}"
    logInfo m!"WALK|{root}|visited={seen.size}|direct_admissions={admissions.size}"
