import os,sys,time,subprocess,datetime
from pathlib import Path
root=Path.cwd(); logs=root/'evidence/logs'; logs.mkdir(parents=True,exist_ok=True)
os.environ['TCSLIB_OLEANS']=str(root/'.lake/fill-ram-run-oleans')
locks=Path('/Users/seyoonr/.tcslib-scratch/locks'); locks.mkdir(parents=True,exist_ok=True)
lean=Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin')
os.environ['PATH']=str(lean)+':'+os.environ['PATH']
def lean_count():
    rows=subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines()
    return sum(1 for row in rows if row.strip().split(maxsplit=1)[-1].split('/')[-1]=='lean')
def acquire():
    started=time.monotonic(); announced=False
    while True:
        for i in range(1,4):
            slot=locks/f'lean-slot-{i}'
            try:slot.mkdir()
            except FileExistsError:
                try:
                    pid=int((slot/'pid').read_text()); os.kill(pid,0)
                except ProcessLookupError:
                    (slot/'pid').unlink(missing_ok=True)
                    try:slot.rmdir()
                    except OSError:pass
                except (ValueError,FileNotFoundError,PermissionError):pass
                continue
            (slot/'pid').write_text(str(os.getpid()))
            count=lean_count()
            if count<3:
                with (logs/'lean-slots.log').open('a') as f:
                    f.write(f'{datetime.datetime.now(datetime.timezone.utc).isoformat()} acquired={i} other_lean={count} wait_seconds={time.monotonic()-started:.2f}\n')
                return slot
            (slot/'pid').unlink(); slot.rmdir()
            break
        if not announced:
            print('Waiting for a machine-wide Lean slot',flush=True);announced=True
        time.sleep(2)
def check(mod,tag=None):
    slot=acquire(); tag=tag or mod.replace('/','__')
    log=logs/(tag+'.log'); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START '+mod+' '+start,flush=True)
    try:
        with log.open('w') as f:
            f.write('START '+start+' module='+mod+'\n');f.flush()
            r=subprocess.run(['/usr/bin/time','-l','bash','scripts/lean_check_tree.sh',mod],stdout=f,stderr=subprocess.STDOUT)
            f.write('\nEXIT '+str(r.returncode)+' END '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n')
        print('END '+mod+' exit='+str(r.returncode),flush=True)
        if r.returncode:print(log.read_text()[-12000:],flush=True)
        return r.returncode
    finally:
        (slot/'pid').unlink(missing_ok=True);slot.rmdir()
if sys.argv[1]=='bootstrap':
    first=(logs/'mathlib-roots.txt').read_text().splitlines()[0]
    Path('evidence/probes/Cache.lean').write_text('import '+first+'\n')
    if check('evidence/probes/Cache','cache-probe'):sys.exit(1)
    for mod in (logs/'bootstrap-order.txt').read_text().splitlines():
        if check(mod):sys.exit(1)
else:
    sys.exit(check(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else None))
