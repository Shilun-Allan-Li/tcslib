import re,subprocess,json,datetime
from pathlib import Path
heads=re.compile(r'\bTableAt\b|\btableAt_[A-Za-z0-9_]*|\bKeyTableAt\b|\bEncodes\b')
rows=[]
for p in sorted(Path('TCSlib').rglob('*.lean')):
    for i,line in enumerate(p.read_text().splitlines(),1):
        if heads.search(line):rows.append(f'{p}:{i}:{line}')
Path('evidence/logs/table-source-inventory.log').write_text('\n'.join(rows)+'\n')
owned='TCSlib/Complexity/RAMSimulation/Simulation.lean'
base='cb44316a22c258628bf571da8c84b72c347ee493'
a=Path(owned).read_bytes(); b=subprocess.check_output(['git','show',base+':'+owned])
status={'base':base,'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
 'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'owned_byte_identical':a==b,'formal_source_byte_identical_after_comment_removal': re.sub(rb'/\-.*?\-/',b'',a,flags=re.S)==re.sub(rb'/\-.*?\-/',b'',b,flags=re.S),'owned_diff_stat':subprocess.check_output(['git','diff','--stat',base,'--',owned],text=True),
 'library_diff_stat':subprocess.check_output(['git','diff','--stat',base,'--','TCSlib'],text=True),
 'new_library_files':subprocess.check_output(['git','ls-files','--others','--exclude-standard','TCSlib'],text=True).splitlines()}
Path('evidence/logs/source-freeze.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps(status,indent=2))
