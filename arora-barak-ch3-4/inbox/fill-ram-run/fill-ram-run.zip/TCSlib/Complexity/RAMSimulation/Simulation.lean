/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Programs.WordRAM.Extended
import TCSlib.Complexity.RAMSimulation.WordSize
import TCSlib.Complexity.ClassNP.NTIME
import TCSlib.Complexity.TuringMachine.NondeterministicSpace
import TCSlib.Complexity.RAMSimulation.Sim.Startup
import TCSlib.Complexity.RAMSimulation.Sim.Phases

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Stage 2: the word RAM on Turing machines

A program `P` of the extended word RAM (`WordRAM.XProgram`) runs on an input `x`, a coin stream
`ρ` and a word size `W = W (|x|)`. One finite binary Turing machine is intended to simulate its
instructions with the following bounds, where `n = |x|`:

* time `TW n + A·(t + 1)·(f·(W + 1) + W² + n + 1)`;
* space `SW n + A·(f·(W + 1) + W + logSpace n + 1)`.

Here `t` bounds the RAM's steps, `f` bounds the number of cells it touches, and the word size is
computed within time `TW` and space `SW` (`WordRAM.WordSizeComputable`). The constant may depend
on the program, output mode and word-size witness, but not on the input or its resource bounds.
The nondeterministic form uses one binary choice per `coin`, with bounds uniform over streams.
Both simulation proofs are pending.

**Bounds and model.** An address computed by `load` or `store` is a word's signed value; the
program's immediate addresses are fixed integers (`WordRAM.Sim.ImmBound`). A memory-table entry
therefore has `W + O_P(1)` bits. Input access uses `Turing.exists_inputSeekTM`, whose time is
linear in the position and input length. The word-size computation's time and space costs are
added once, using the silent embedding `Turing.embedSilentTM`.

## Main definitions

* `WordRAM.simTime`, `WordRAM.simSpace`: the time and space bounds, with readers `simTime_eq`
  and `simSpace_eq`.
* `WordRAM.outputOf`: the verdict or emitted word, with readers `outputOf_false` and
  `outputOf_true`.

## Main results (proofs pending)

* `WordRAM.exists_simulation`: stage 2, deterministic form.
* `WordRAM.exists_ndSimulation`: stage 2, nondeterministic form.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (Exercise 1.9, p. 35: a RAM Turing machine is simulated with
  polynomial overhead; §2.1.2: NDTMs; Definition 4.1; §4.3.1: read-once certificates.)
* [AFM26] Anthropic, PBC, `anthropics/formal-math`, project `3sum-apsp`, commit
  `e1a4e6508154ea59f030480661590a9fe3018011` (2026-10-05), Apache-2.0: the word RAM of
  `EndStatement.lean` (vendored as `TCSlib/Programs/WordRAM/Basic.lean`), extended in
  `TCSlib/Programs/WordRAM/Extended.lean`, is the simulated model.
-/

namespace WordRAM

/-- **The time bound of stage 2**: computing the word size, then `t + 1` simulated steps, each at
most one scan of a table of `f` entries of `W + O(1)` bits, one shift-and-add multiplication of
`W`-bit words, and one input seek. -/
def simTime (A : ℕ) (TW : ℕ → ℕ) (n W t f : ℕ) : ℕ :=
  TW n + A * (t + 1) * (f * (W + 1) + W ^ 2 + n + 1)

/-- **The space bound of stage 2**: computing the word size, then the memory table (`f` entries
of `W + O(1)` bits), `O(1)` words of scratch, and the input length in binary. -/
def simSpace (A : ℕ) (SW : ℕ → ℕ) (n W f : ℕ) : ℕ :=
  SW n + A * (f * (W + 1) + W + Complexity.logSpace n + 1)

/-- What the stage-2 machine leaves on its output tape: in verdict mode (`fn = false`) the
one-bit verdict, as `Turing.FinTM.DecidesInTime` and `Turing.FinTM.DecidesInSpace` read it; in
function mode (`fn = true`) the emitted word, as `Turing.FinTM.ComputesInSpace` reads it. -/
def outputOf (fn v : Bool) (o : List Bool) : List Bool := if fn then o else [v]

/-- The time bound, as an equation:
`simTime A TW n W t f = TW n + A·(t + 1)·(f·(W + 1) + W² + n + 1)`. -/
theorem simTime_eq (A : ℕ) (TW : ℕ → ℕ) (n W t f : ℕ) :
    simTime A TW n W t f = TW n + A * (t + 1) * (f * (W + 1) + W ^ 2 + n + 1) := rfl

/-- The space bound, as an equation:
`simSpace A SW n W f = SW n + A·(f·(W + 1) + W + logSpace n + 1)`. -/
theorem simSpace_eq (A : ℕ) (SW : ℕ → ℕ) (n W f : ℕ) :
    simSpace A SW n W f = SW n + A * (f * (W + 1) + W + Complexity.logSpace n + 1) := rfl

/-- In verdict mode the output is the one-bit verdict. -/
theorem outputOf_false (v : Bool) (o : List Bool) : outputOf false v o = [v] := rfl

/-- In function mode the output is the emitted word. -/
theorem outputOf_true (v : Bool) (o : List Bool) : outputOf true v o = o := rfl

/-- **Stage 2, deterministic form** (design §15a, §16b; backlog PROG-4). For every program `P` of
the extended word RAM, every output mode `fn` and every word size `W` computable within `TW` and
`SW`, there are a finite binary machine `M` and a constant `A` such that: whenever `P`, run on
`x` with word size `W (|x|)` and the empty coin stream (coins read `0`), gives the verdict `v`
within `t` steps, having emitted `o` and touched at most `f` cells, then `M` halts on `x` within
`TW n + A·(t + 1)·(f·(W + 1) + W² + n + 1)` steps with `outputOf fn v o` on its output tape,
having visited at most `SW n + A·(f·(W + 1) + W + logSpace n + 1)` work cells (`n = |x|`).
[AB09, Exercise 1.9]

Deviations: [AB09] has a RAM Turing machine with a symbol array and the bound `T(n)²`; this is
[AFM26]'s word RAM with input, output and coins, and the bound is explicit in steps, cells and
word size. From design §15a's draft shape: no separate address width, a seek term `n` rather than
`n·log n`, and the word size's own cost added (module docstring).

**Proof sketch.** The intended machine is a phase host (`Turing.phaseHostTM`) over the
program positions and an alternating parity, following `WordRAM.Sim.exists_startup`. The parity
allows a jump to the current position to dispatch into a different phase. The eight-tape
instruction machines of `WordRAM.Sim.exists_phase` are placed among the start-up's tapes by
`Turing.embedEmitTM`; verdicts use `WordRAM.Sim.exists_verdictPhase`. No unary ruler is needed:
the registers are words of fixed width with blank delimiters.

Induction on `WordRAM.XStepsIn` tracks the cells touched so far together with `-1`, bounds their
number by `f + 1`, and preserves `WordRAM.Sim.Encodes` at every phase boundary. Each ordinary
phase takes time linear in the table size, quadratic in the word size, and linear in the input
length; every phase restores its work heads to the fixed origins. These origins bound the union
of visited cells independently of the number of phases. The final phase halts with `[v]` in
verdict mode or the emitted word in function mode. Fixing every choice to `false` matches the
empty coin stream. This proof is pending; transporting `Encodes` through the state tags and tape
embedding first requires a published reader or transport lemma for `Turing.TableAt`. -/
theorem exists_simulation (P : XProgram) (fn : Bool) {W TW SW : ℕ → ℕ}
    (hW : WordSizeComputable W TW SW) :
    ∃ (M : Turing.FinTM Bool) (A : ℕ), ∀ (x : List Bool) (t f : ℕ) (v : Bool) (o : List Bool),
      HaltsWithin P x [] (W x.length) t v o f →
        M.ComputesInTime x (outputOf fn v o) (simTime A TW x.length (W x.length) t f) ∧
        M.tm.spaceUsed (M.tm.initCfg x) (simTime A TW x.length (W x.length) t f) ≤
          simSpace A SW x.length (W x.length) f := by
  sorry

/-- **Stage 2, nondeterministic form** (design §15c, §16b item 4; backlog PROG-4). For every
program `P` of the extended word RAM and every word size `W` computable within `TW` and `SW`,
there are a finite binary nondeterministic machine `N` and a constant `A` such that: if, on the
input `x`, **every** coin stream lets `P` give a verdict within `t` steps touching at most `f`
cells (bounds uniform over the streams, as `NTIME` and `NSPACE` require), then every branch of
`N` of length `T = simTime …` has halted, every such branch has visited at most `simSpace …` work
cells, and `N` accepts `x` within `T` exactly when some coin stream makes `P` accept.
[AB09, Exercise 1.9 with §2.1.2 and Definition 4.1; the coins are read once, as the certificate
of §4.3.1]

**Proof sketch.** The intended construction is `Turing.NDTM.phaseHostND` over the same
start-up and instruction phases as `exists_simulation`, in verdict mode. A `coin` phase takes
its choice at entry. Away from that entry the two transition functions agree, and the entry is
never revisited; `Turing.NDTM.runWith_eq_fixChoice_runFrom` therefore transfers the remaining
slice to a deterministic run. A branch supplies a coin stream by reading its bits at the coin
entries, and a coin stream supplies a branch by placing its bits at those entries and padding
the remaining positions. The uniform halting hypothesis bounds every branch; acceptance in
both directions follows from `WordRAM.HaltsWithin.unique`. This proof is pending at the same
encoding-transport reader as the deterministic form. -/
theorem exists_ndSimulation (P : XProgram) {W TW SW : ℕ → ℕ} (hW : WordSizeComputable W TW SW) :
    ∃ (N : Turing.FinNDTM Bool) (A : ℕ), ∀ (x : List Bool) (t f : ℕ),
      (∀ ρ : List Bool, ∃ (v : Bool) (o : List Bool), HaltsWithin P x ρ (W x.length) t v o f) →
        N.tm.HaltsWithin x (simTime A TW x.length (W x.length) t f) ∧
        (∀ w : List Bool, w.length = simTime A TW x.length (W x.length) t f →
          N.tm.spaceUsedWith w (N.tm.initCfg x) ≤ simSpace A SW x.length (W x.length) f) ∧
        (N.AcceptsWithin x (simTime A TW x.length (W x.length) t f) ↔
          ∃ (ρ o : List Bool), HaltsWithin P x ρ (W x.length) t true o f) := by
  sorry

end WordRAM
