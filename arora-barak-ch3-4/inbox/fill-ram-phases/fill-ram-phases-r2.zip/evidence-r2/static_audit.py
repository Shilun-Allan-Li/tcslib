from pathlib import Path
import subprocess,re,json,hashlib
root=Path.cwd();base='7342f98b58704d6c25faf668ed1a64ea0b27c4af'
folder=Path('TCSlib/Complexity/RAMSimulation/Sim')
owned=sorted(folder.glob('Phase*.lean'))
readers={
'TCSlib/Complexity/TuringMachine/Build/Embed.lean':'Cfg.select_eq',
'TCSlib/Complexity/TuringMachine/Build/Seam.lean':'seamCompTM_tr_inl',
'TCSlib/Complexity/TuringMachine/Build/NDHost.lean':'phaseHostND_tr'}
report=[]
for path,name in readers.items():
 p=Path(path);old=subprocess.check_output(['git','show',base+':'+path],text=True);s=p.read_text()
 a=s.index('theorem '+name+' ');a=s.rfind('/--',0,a);b=s.index('\n\n',s.index('theorem '+name+' ',a))+2
 block=s[a:b];assert block.rstrip().endswith(':= rfl'),path
 assert s[:a]+s[b:]==old,('foreign file has other changes',path)
 report.append({'home':path,'reader':name,'proof':'rfl','only_reader_inserted':True})
p=folder/'Phases.lean';old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);s=p.read_text()
for name in ['exists_phase','exists_verdictPhase']:
 pattern=r'theorem '+name+r'\b.*?:= by'
 assert re.search(pattern,old,re.S).group()==re.search(pattern,s,re.S).group(),name
 report.append({'target':name,'statement_byte_identical':True})
a=old.index('def isCoin');b=old.index('/-- **The phase of an instruction')
assert old[a:b]==s[s.index('def isCoin'):s.index('/-- **The phase of an instruction')]
for p in owned:
 s=p.read_text()
 assert not re.search(r'\b(sorry|admit|axiom)\b',s),p
 assert not re.search(r'@\[simp\]|attribute\s+\[simp\]',s),p
 assert all(x in s for x in ['Copyright (c)','set_option maxHeartbeats 0','set_option relaxedAutoImplicit false','set_option autoImplicit false','## Main definitions','## Main results','## References']),p
 assert s.count('namespace WordRAM.Sim')==1,p
 report.append({'source':str(p),'lines':len(s.splitlines()),'sha256':hashlib.sha256(s.encode()).hexdigest(),'no_new_admission_or_simp':True})
# The facade may change only imports and Contents.
p=Path('TCSlib/Complexity/RAMSimulation.lean');old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);s=p.read_text()
def keep(t):
 t='\n'.join(l for l in t.splitlines() if not l.startswith('import '))
 a=t.index('## Contents');b=t.index('## References',a)
 return t[:a]+t[b:]
assert keep(old)==keep(s),'facade changed outside imports/Contents'
for p in owned:
 if p.stem=='Phases':continue
 assert 'import TCSlib.Complexity.RAMSimulation.Sim.'+p.stem+'\n' in s,p
 assert '`RAMSimulation.Sim.'+p.stem+'`' in s,p
paths=[str(p) for p in owned]+['TCSlib/Complexity/RAMSimulation.lean']+list(readers)
Path('evidence-r2/logs/final-authorized-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
Path('evidence-r2/logs/final-static-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: target statements and existing controls frozen; three home readers only; source scope, no admissions/simp, facade and headers checked.')
