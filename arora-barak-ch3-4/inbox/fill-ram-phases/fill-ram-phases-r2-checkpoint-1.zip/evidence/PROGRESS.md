# Round-2 continuation state

Objective remains the FULL `WordRAM.Sim.exists_phase` proof and a verified delivery against
7342f98b58704d6c25faf668ed1a64ea0b27c4af. Do not mark complete on a checkpoint/frontier.
User explicitly resumed after the first-round missing readers were published. Pure missing
readers may now be added beside their home definition, rfl/Iff.rfl only. Briefs were read with
git show at e40383d88d79e23026c95e20608ee8827d45e59b and saved here.

Branch codex/fill-ram-phases-r2 is directly off the new base, never rebased. Original round-1 ZIP
was fetched from origin/exchange/pass-shelat-ch5-8, checked/extracted, and its patch applied.
Old evidence/ and .lake/fill-ram-phases-oleans are round 1; DO NOT use their oleans for round 2.
Round-2 private olean tree: .lake/fill-ram-phases-r2-oleans. Checker:
`python3 evidence-r2/check.py MODULE/PATH LABEL` through approved leanelab-o.sh, shared 3 slots,
per-fill exclusive lock, ps count gating. Shell needs sandbox escalation for ps/shared locks.
Run at most ONE own Lean, never lake build. Existing packages symlink is pinned and manifest
checked. Fresh round-2 47-module bootstrap PASS; after adding Embed reader, 35-module downstream
recheck PASS. Preflight APFS free 118478614528 bytes, conservative available memory 5663850496.
Thirty unrelated blueprint modifications were carried across branch switch and must be preserved,
excluded from source commits/delivery. Old report got these too.

## Files and checks

Restored round 1: PhaseTable.lean (8 public algebraic lemmas, 2 private), verdict proof in
Phases.lean, import/contents in RAMSimulation.lean. Exists_phase is still the original sorry.

New round-2 files, all under TCSlib/Complexity/RAMSimulation/Sim/:

- PhaseLayout.lean: range widening via inRange_iff; signed word range (BitVec.le_two_mul_toInt
  and two_mul_toInt_lt); immediate/computed range; sign-extension key equality; exact table
  length = 1 + es.length*(K+V+4); footprint layout bound; assignment entry-count and layout
  nonshrinking; `phase_keyTableAt_write`, full physical table and blank-tail preservation.
  Latest successful check: phase-layout-05.log. 158 lines.
- PhaseCore.lean: PhaseFrame (inputPos, workTapes, workTapePos, output), ofCfg/cfg and their
  equation/reconstruction/mapState lemmas; PhaseRow bundle of finite State/machine/entry/exit,
  pre/effect and B/E functions indexed by I : List Bool -> Type, restores heads and has exact
  ReachesWithin endpoint. `phase_reaches_seq` proves seam composition of a single-exit first
  run followed by ANY live exit set; explicit seamCompTM conclusion, uses Contract.ofReaches
  and Contract.seq. Radius E1+E2 uses returned first heads. `PhaseRow.seq` wraps it, combines
  pre1 F AND pre2 (f1 F), effect f2(f1 F), time B1+1+B2, radius E1+E2. Latest native
  phase-core-05 PASS. An earlier equivalent composition version passed a 330-definition seal;
  regenerate/recheck final copy after all edits. 192 lines.
- PhaseTape.lean: word/table/encoding congruence by fields; `phase_reaches_embed` transfers a
  source run on d.select into eight tapes; `phase_wordAt_write` preserves delimiters for equal
  lengths; `phase_embed_update` for one selected tape plus state/inputPos; generic private
  `phase_single_tape_update` factors conditional-patch to Function.update; public wordWrite and
  keyTableWrite as_update; selection WordAt/KeyTableAt bridges; exact embedded word/table-write
  endpoints. Latest phase-tape-13 PASS. 234 lines.
- PhaseInvariant.lean: `phase_encodes_mono`, `phase_encodes_wordWrite` (any register 1..4,
  correct width), `phase_encodes_keyAssign` (explicit old es, table predicate and TableOf,
  range premise, output Encodes insert z T with c.mem updated). Latest phase-invariant-05 PASS.
  Fin-index pitfalls: pass (j := j) / (j := 5) to local keep helper to avoid an opaque
  Function.Embedding.refl j confusing omega. Explicit target updated cfg in phase_wordAt_congr.
- PhaseRows.lean: PhaseFrame.write + write_eq, PhaseReady and PhaseScratch with iff readers;
  arithmetic bank ![2,3,4,6,7] (injectivity by decide, own definition) + apply reader;
  control-independent WordAt frame bridge, blank-scratch selection; `phase_intRow` native
  integer constant row uniform in index width, arbitrary bank satisfying scratch coords.
  `phase_wordRow` converts a native five-tape word-write to a PhaseRow. It was factored
  through more general `phase_nativeRow` (arbitrary native post and frame effect), pending
  phase-rows-06 check at time this note is written. All earlier rows-01..05 PASS.

One new foreign-home reader: Cfg.select_eq in Build/Embed.lean, pure rfl, exact record body.
Allowed by updated COMMON. Record it in final report. No other foreign source edits.

New files are NOT yet wired into Phases.lean / RAMSimulation facade (wire before checkpoint).
No round-2 checkpoint or final ZIP pushed yet. No round-2 source commit yet.

## Next implementation route

1. Finish all native row factories, then instruction cases. The key range/layout/table-write
   problems are resolved; do not restart reader investigation or settle for those helpers.
2. Native `phase_intRow` already checked. General PhaseRow index family I supports width and
   operands as functions. Native arithmetic factory: enum add/sub/mul, own eval and cost
   (mul (W+1)^2, others W+1) with equation readers; unify native exists_wordAdd/Sub/Mul by
   cases once, use phase_wordRow on arithmetic bank. Pre = WordAt reg2 u AND WordAt reg3 v
   AND PhaseReady W 4 AND PhaseScratch, effect write4 bits(op u v).
3. Unary half/signExtend can be factored similarly with width extra 0/a, source reg2, destination
   reg4 for half, reg1 for signExtend. Add key bank ![2,3,1,6,7]. Input bank ![2,5,4,6,7].
   Lookup bank ![0,1,dst,6,7], dst=2,3,4; use generic dest Fin3 plus 2 or three constant banks.
   Bank definitions are new/owned here, so decide/rfl may reduce them; publish apply equations
   for cross-file readers. Other-file defs must ONLY use published readers, never simp [Def].
4. Memory rows need actual table es from Encodes. A noncomputable selector can choose the table
   from (encodes_iff ...).mp he when Encodes holds, [] otherwise, with pure equation reader and
   spec lemma. Use this SAME chosen es for native calls and post function, avoiding any table
   uniqueness/parser proof. Lookup post can instead be write bits(c.mem address) by the proved
   tableOf_keyLookup_default; assignment post writes keyAssign of selected es. Its encoding
   is phase_encodes_keyAssign. Bound old L via phase_tableOf_layout_bound. Table values all W
   via tableOf_widths. Never cite admitted RecordTable rows.
5. `PhaseRow` effect is an explicit function on frames, so composition pre is a conjunction of
   native preconditions at intermediate frames. Prove Encodes supplies these by repeated
   phase_encodes_wordWrite, operand WordAt keep lemmas from function-update frame, and finally
   phase_encodes_keyAssign. An external pre-restriction/bounds-mono wrapper on PhaseRow can
   keep the machine while changing pre/bounds; use ReachesWithin.mono.
6. InputBit returns an existential ip. Use a total function ip i F chosen from the native row
   under its precondition (arbitrary old inputPos off pre), and return it existentially with
   the Row. Effect has {F.write 4 bits(result) with inputPos := ip i F}; frame encoding does
   not inspect inputPos. `phase_nativeRow` was generalized exactly to share this/table lifting.
7. Tests (sign and nonzero) need a PhaseTest bundle with two distinct yes/no exits and a Bool
   branch function of the index. Prefix ordinary rows into a test via `phase_reaches_seq`,
   which already supports arbitrary second exits. A no-write embedding endpoint follows from
   phase_embed_update with tape 0 set to its original function, using update_eq_self.
8. Normal instructions write result4, key1, then assign; each memory write occurs only once at
   the end, so all lookups charge the original T.card. Arithmetic schedule: key j, lookup2;
   key k, lookup3; op->4; key i; assign4. Load: key j lookup2; signextend2->key1; lookup4;
   key i; assign. Store: key j lookup4 FIRST, key i lookup2, signextend2->key1, assign4.
   rdIn: key j lookup2; inputBit->4; key i; assign. Half similarly. Coin: const b->4,
   key i, assign. Bltz/emit use sign/nonzero test after key i lookup2.
9. Final wrapper must add a fresh entry that is never targeted and distinct next/jump, enforce
   deterministic transitions except coin entry, transfer correct memory/pc/output and bounds.
   Use existing phaseHostTM/phaseHostND with contracts; inspect their APIs before constructing
   transitions. For noncoin single-exit Row, a prefix seam whose left machine has Bool state,
   entry=exit=false, all tr halt gives one dispatch into Row; jump=inl true unused,
   entry=inl false, next=inr Row.exit. `phase_reaches_seq` with a zero-time first frame run
   gives its bounded run. Need tr readers (pure rfl home additions allowed) for no-entry and
   no-jump, or existing run transfer. Important: DO NOT choose jump=entry (cut would fail at 0).
   For coin: fresh entry choice -> remember b, then deterministic continuation R_b. Existing
   NDTM.phaseHostND can host start, bank false/true, out with redirects; fixed choice lemma
   reduces to deterministic phaseHostTM. No red goes back to start. Start transitions differ
   only at entry; red overrides any chosen-return state. Bank exit to shared next. Uniform
   choice paths have one coin choice, no entry reentry. Bltz can direct yes/no to next/jump;
   emit needs one stationary emission step depending test exit before a common next.
10. Common units for final bounds: Utime=(T.card+1)*(W+1)+W^2+x.length+1,
    Uradius=(T.card+1)*(W+1)+bits(x.length).length+1. Word/native table/input costs fit constant
    multiples; factor per-row constants and seam steps (units >=1). Multiplication's (W+1)^2
    fits W^2 plus O(W+1). Final C may depend a, ins, not W/input/T.

Keep source/checkpoint commits local; push only designated exchange inbox ZIPs, pull --rebase
first on exchange checkout and no force. Final r2 ZIP patch must be against NEW base.

## Lean details already learned

- `Function.comp_def` is a THEOREM in Init/Core, allowed in simp; comp_apply alone does not
  rewrite a pointfree function inside List.map. Exact layout formula uses joinFields_length,
  keyFields_def, tableFields_eq, sum_flatten/map_map/map_const'/sum_replicate_nat.
- Read ReachesWithin via reachesWithin_iff, never destruct it directly through its definition.
- Published Cfg.mapState_eq_of_fields in CfgFacts avoids repeated five-field ext proofs.
- `rw` does not automatically expose projections of record updates; use `change` that reduces
  only constructor projections (no foreign definition) or simp only of published cfg_eq.
- Multiline record updates should put each field on its own line; a comma after inline fields
  followed by too-low indentation caused parser errors in phase_embed_update.
- Phases source headline statements must remain byte-identical. Add only helpers/imports as
  allowed; no new final sorry/axiom/simp attributes. Core/Mathlib defs can reduce by rfl/change/
  decide but may not be explicitly passed to simp/rw/unfold. New public defs need readers.
