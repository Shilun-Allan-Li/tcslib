from pathlib import Path
import re,subprocess,sys
root=Path.cwd()
base=root/'TCSlib/Complexity/RAMSimulation/Sim'
names=['PhaseTable','PhaseLayout','PhaseCore','PhaseTape','PhaseInvariant','PhaseRows','PhaseRegister','Phases']
invbody=(root/'evidence-r2/probes/InventoryCore.lean').read_text().split('import Lean',1)[1]
def check(m,l):
    subprocess.run([sys.executable,'evidence-r2/check.py',m,l],check=True)
for name in names:
    src=(base/(name+'.lean')).read_text()
    imports='\n'.join(re.findall(r'^import .*$',src,re.M))
    inv='evidence-r2/probes/Inventory'+name
    Path(inv+'.lean').write_text(imports+'\nimport Lean'+invbody)
    label='checkpoint-inventory-'+name
    check(inv,label)
    rows=re.findall(r'SEALDEF\|([^|\s]+)\|(true|false)',Path('evidence-r2/logs/'+label+'.log').read_text())
    attrs='\n'.join('attribute [local irreducible] '+n+ ('\nattribute [-simp] '+n if simp=='true' else '') for n,simp in rows)
    seal='evidence-r2/probes/Sealed'+name
    at=src.index('set_option')
    Path(seal+'.lean').write_text(src[:at]+attrs+'\n\n'+src[at:])
    check(seal,'checkpoint-sealed-'+name)
roots=[]
for name in names:
    src=(base/(name+'.lean')).read_text()
    roots.extend('WordRAM.Sim.'+n for n in re.findall(r'^(?:noncomputable )?(?:def|theorem|inductive|structure) ([\w.]+)',src,re.M) if n!='exists_phase')
walk=(root/'evidence/probes/AxiomsWalk.lean').read_text()
body=walk[walk.index('  for root in roots do'):]
probe='import TCSlib.Complexity.RAMSimulation.Sim.Phases\nimport Lean\nset_option maxHeartbeats 0\n'
probe+='\n'.join('#print axioms '+n for n in roots)+'\n\nopen Lean Elab Command in\nrun_cmd do\n  let env ← getEnv\n  let roots := #['+', '.join('`'+n for n in roots)+']\n'+body
Path('evidence-r2/probes/CheckpointAxioms.lean').write_text(probe)
Path('evidence-r2/logs/checkpoint-declaration-roots.txt').write_text('\n'.join(roots)+'\n')
check('evidence-r2/probes/CheckpointAxioms','checkpoint-axioms')
mods=[];seen=set()
def dfs(m):
    if m in seen:return
    seen.add(m)
    p=Path(m+'.lean')
    if not p.exists():return
    for d in re.findall(r'^import (\S+)',p.read_text(),re.M):dfs(d.replace('.','/'))
    mods.append(m)
dfs('TCSlib/Complexity/RAMSimulation')
missing=[m for m in mods if not Path('.lake/fill-ram-phases-r2-oleans/'+m+'.olean').exists()]
Path('evidence-r2/logs/checkpoint-downstream-order.txt').write_text('\n'.join(missing)+'\n')
subprocess.run([sys.executable,'evidence-r2/check.py','order','evidence-r2/logs/checkpoint-downstream-order.txt','checkpoint-downstream'],check=True)
