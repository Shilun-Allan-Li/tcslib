# fill-ram-phases, round 2, checkpoint 1

This is a verified progress checkpoint. The full `exists_phase` objective remains active;
this package is not a claim that its instruction cases are complete.

## Provenance and scope

- Repository: Shilun-Allan-Li/tcslib.
- Exact read-only base: `7342f98b58704d6c25faf668ed1a64ea0b27c4af` (`ram/readers-2`, PR #375).
- Instructions: COMMON.md and fill-ram-phases.md at
  `e40383d88d79e23026c95e20608ee8827d45e59b`, read by `git show` and included here.
- Local branch: `codex/fill-ram-phases-r2`, directly off the base, never rebased or pushed.
- Local checkpoint commit: `bc3eab3af3378fc2f21987e1a650602b2abd8b71`.
- Round-1 delivery SHA256:
  `0010aa48f09bbd1253cb93e46fb5771aba057c7ac59ee4f363b737f99f4e8ad3`;
  its patch was applied to this new base. The new package's patch is against the new base.
- Original README/bundle integrity and round-1 report are included for input provenance.

## Target status and remaining work

| Target | Status | Directly admitted dependencies |
|---|---|---|
| `WordRAM.Sim.exists_verdictPhase` | Proved; statement unchanged | none |
| `WordRAM.Sim.exists_phase` | Original `sorry` retained; work continuing | no proved claim |

The new published range readers resolved the prior frontier. This checkpoint proves range
extension, signed-word address range, exact keyed-layout length and its footprint bound,
nonshrinking assignment layout, and physical table-write preservation. It also builds
state-independent eight-tape frames, native row placement, seam composition through the existing
contracts, register/scratch invariants, and constant, arithmetic, half and sign-extension rows.
The remaining work is keyed-memory and input rows, tests/emit/coin control, instruction schedules
and their total bounds. No E-READER or E-STATEMENT stop is asserted.

## New files and declarations

Seven new files live under `TCSlib/Complexity/RAMSimulation/Sim/`:

- `PhaseTable`: the eight round-1 key/table algebra lemmas, retained unchanged.
- `PhaseLayout`: range and physical layout bounds; table rewrite preservation.
- `PhaseCore`: `PhaseFrame`, `PhaseRow`, control reconstruction and contract seam composition.
- `PhaseTape`: layout/encoding congruence, native run placement and exact write endpoints.
- `PhaseInvariant`: footprint enlargement, register-write and keyed-assignment encoding.
- `PhaseRows`: placed constant/binary/unary word rows and selected tape banks.
- `PhaseRegister`: register readiness, scratch, write and frame encoding invariants.

The owned file imports the helpers. The facade changes only imports and Contents entries.
All new public declarations are in `WordRAM.Sim`; the exact declaration inventory follows:

```text
WordRAM.Sim.keyBits_eq_iff
WordRAM.Sim.tableOf_mono
WordRAM.Sim.tableOf_widths
WordRAM.Sim.tableOf_length_le
WordRAM.Sim.tableOf_keyLookup
WordRAM.Sim.phase_bvBits_zero
WordRAM.Sim.tableOf_keyLookup_default
WordRAM.Sim.tableOf_keyAssign
WordRAM.Sim.phase_inRange_mono
WordRAM.Sim.phase_toInt_inRange
WordRAM.Sim.phase_immediate_inRange
WordRAM.Sim.phase_computed_inRange
WordRAM.Sim.phase_keyBits_signExtend
WordRAM.Sim.phase_keyTableLength
WordRAM.Sim.phase_tableOf_layout_bound
WordRAM.Sim.phase_keyAssign_length_le
WordRAM.Sim.phase_keyAssign_layout_mono
WordRAM.Sim.phase_keyTableAt_write
WordRAM.Sim.PhaseFrame
WordRAM.Sim.PhaseFrame.ofCfg
WordRAM.Sim.PhaseFrame.ofCfg_eq
WordRAM.Sim.PhaseFrame.cfg
WordRAM.Sim.PhaseFrame.cfg_eq
WordRAM.Sim.PhaseFrame.cfg_ofCfg
WordRAM.Sim.PhaseFrame.ofCfg_cfg
WordRAM.Sim.PhaseFrame.cfg_mapState
WordRAM.Sim.PhaseRow
WordRAM.Sim.phase_reaches_seq
WordRAM.Sim.PhaseRow.seq
WordRAM.Sim.phase_wordAt_congr
WordRAM.Sim.phase_keyTableAt_congr
WordRAM.Sim.phase_encodes_congr
WordRAM.Sim.phase_reaches_embed
WordRAM.Sim.phase_wordAt_write
WordRAM.Sim.phase_embed_update
WordRAM.Sim.phase_wordWrite_as_update
WordRAM.Sim.phase_wordAt_select
WordRAM.Sim.phase_keyTableAt_select
WordRAM.Sim.phase_embed_wordWrite
WordRAM.Sim.phase_keyTableWrite_as_update
WordRAM.Sim.phase_embed_keyTableWrite
WordRAM.Sim.phase_encodes_mono
WordRAM.Sim.phase_encodes_wordWrite
WordRAM.Sim.phase_encodes_keyAssign
WordRAM.Sim.PhaseFrame.write
WordRAM.Sim.PhaseFrame.write_eq
WordRAM.Sim.phase_nativeRow
WordRAM.Sim.phase_wordRow
WordRAM.Sim.PhaseReady
WordRAM.Sim.phaseReady_iff
WordRAM.Sim.PhaseScratch
WordRAM.Sim.phaseScratch_iff
WordRAM.Sim.phaseArithBank
WordRAM.Sim.phaseArithBank_apply
WordRAM.Sim.phase_wordAt_frame
WordRAM.Sim.phase_scratch_select
WordRAM.Sim.phase_intRow
WordRAM.Sim.PhaseArith
WordRAM.Sim.PhaseArith.value
WordRAM.Sim.PhaseArith.value_eq
WordRAM.Sim.PhaseArith.steps
WordRAM.Sim.PhaseArith.steps_eq
WordRAM.Sim.PhaseArith.native
WordRAM.Sim.phase_arithRow
WordRAM.Sim.phaseKeyBank
WordRAM.Sim.phaseKeyBank_apply
WordRAM.Sim.phase_unaryRow
WordRAM.Sim.phase_halfRow
WordRAM.Sim.phase_signExtendRow
WordRAM.Sim.phase_frame_scratch
WordRAM.Sim.phase_frame_ready
WordRAM.Sim.phase_frame_write_encodes
WordRAM.Sim.phase_frame_write_word
WordRAM.Sim.phase_frame_write_other
WordRAM.Sim.phase_frame_ofCfg_encodes
WordRAM.Sim.isCoin
WordRAM.Sim.isCoin_def
WordRAM.Sim.isVerdict
WordRAM.Sim.isVerdict_def
WordRAM.Sim.jumpTarget
WordRAM.Sim.jumpTarget_def
WordRAM.Sim.exists_verdictPhase
```

There are three new private glue lemmas: `phase_keyAssign_mem` and
`phase_keyAssign_nodup` in PhaseTable (assignment membership and distinctness), and
`phase_single_tape_update` in PhaseTape (conditional patch equals one Function.update),
shared by word and table placement rather than copied for those variants.

One foreign-home pure reader was added, as authorized by the revised COMMON.md:
`Turing.Cfg.select_eq` beside `Cfg.select` in `Build/Embed.lean`. Its statement is the exact
record body, and its proof is `rfl`. No existing statement or visibility was changed.

## Reuse and definition boundaries

Before each helper cluster, the import closure and the construction registry were searched for
the relevant range, key/table, layout, configuration, embedding, seam and native-row facts.
The delivered proofs consume the existing `Contract.ofReaches` and `Contract.seq`; they do not
rebuild a sequencing host. `phase_nativeRow` factors the placement of arbitrary native endpoint
frames, and `phase_unaryRow` factors the half/sign-extension adapters. The only handwritten
machine remains the round-1 optional verdict emission and halt, whose catalog gap is documented
in the target proof sketch. New frame datatypes/package structures contain no transition table.

| Other-file definition | Published readers used |
|---|---|
| `InRange`, `wd` | `inRange_iff`, `toInt_wd`; `wd` is a reducible abbreviation |
| `keyBits`, `TableOf`, `Encodes` | `keyBits_def`, `tableOf_iff`, `encodes_iff` |
| `bvBits`, keyed operations/layout | `bvBits_def`, `bvBits_length`, `bvBits_injective`, `keyLookup_def`, `keyAssign_def`, `keyFields_def`, `keyTableLength_def`, `keyTableAt_iff`, `keyTableWrite_apply` |
| Record/word layout | `tableFields_eq`, `tableAt_iff`, `joinFields_length`, `fieldsTape_of_neg`, `fieldsTape_of_length_le`, `wordAt_iff`, `wordWrite_apply`, `bufferTape_left`, `bufferTape_nat` |
| Configuration transports | `Cfg.select_eq` (new home reader), `Cfg.mapState_eq_of_fields`, field equations of `Cfg.mapState`, `embedEmitCfg_eq`, selection and framing equations |
| Machine transports/composition | `embedEmitTM_runFrom`, `Contract.ofReaches_*`, `Contract.seq_*`, `reachesWithin_iff`, `ReachesWithin.mono` |
| Native word rows | `exists_wordIntTM`, `exists_wordAddTM`, `exists_wordSubTM`, `exists_wordMulTM`, `exists_wordHalfTM`, `exists_wordSignExtendTM`, `scratchBlank_iff` |
| Frame/row helpers from this patch | published `cfg_eq`, `ofCfg_eq`, `write_eq`, `phaseReady_iff`, `phaseScratch_iff`, bank apply equations and `PhaseArith.value_eq`/`steps_eq` |
| Verdict machine primitives | `MultiTapeTM.runFrom_one`, `runFrom_zero`, `step_of_some`, `Action.apply_state`, `apply_output`, `apply_workTapePos` |

All eight delivered modules pass seals that make every ordinary public foreign TCSlib definition
in their actual import closure locally irreducible and remove its simp attribute, if any.
Abbreviations, primitive projections, private and internal-detail names are excluded by the
standard inventory. The proof sources and inventories are included as `.lean.txt` scratch files.
No other-file definition is explicitly unfolded, and there are no new simp attributes,
axioms or admissions.

## Axioms and checks

The scratch CheckpointAxioms probe prints axioms and walks every reachable constant's type and
value for all 82 listed roots. The walk's only directly admitted declarations are:

- `Turing.bvBits_injective` (job A, Build/WordArith)
- `Turing.exists_wordAddTM` (job A, Build/WordArith)
- `Turing.exists_wordHalfTM` (job A, Build/WordArith)
- `Turing.exists_wordIntTM` (job A, Build/WordArith)
- `Turing.exists_wordMulTM` (job A, Build/WordArith)
- `Turing.exists_wordSignExtendTM` (job A, Build/WordArith)
- `Turing.exists_wordSubTM` (job A, Build/WordArith)

Each root's exact list is in `checkpoint-axioms.log`; roots not using one of these have no
reachable admission. `exists_verdictPhase` has no reachable admission. In particular, no
admitted RecordTable routine is used. The audit asserts the allowed set automatically.

Final checkpoint verification receipts, all exit 0:

- Fresh round-2 private-tree bootstrap: 47 modules; after adding the home reader, 35 dependent
  modules were replayed. No round-1 TCSlib olean was reused.
- PhaseTable, PhaseLayout, PhaseCore, PhaseTape, PhaseInvariant, PhaseRows, PhaseRegister and
  Phases: native checks and `checkpoint-sealed-*` checks pass. The only retained owned-file
  warning is the original unproved `exists_phase`.
- `checkpoint-axioms.log`: all axiom prints and transitive direct-admission walks pass.
- `checkpoint-downstream-00..29`: all 30 remaining prerequisite/consumer modules pass, including
  Simulation, Classes and RAMSimulation. The root TCSlib facade is excluded by the standing
  campaign replay rule. No full-library build is claimed.
- Existing target statement headers checked byte-identical through `:= by`; existing control
  definitions/readers unchanged. `git diff --cached --check` passes.
- Patch applies cleanly to an export of the exact new base; delivered-file bytes match the
  local checkpoint commit. `checkpoint-package-validation.json` records these checks.

Iteration logs are retained; final successful labels supersede earlier failed experiments.
Scratch probes are delivered as `.lean.txt`, not as library Lean source.

## Environment and shared process discipline

Native macOS arm64, 12 logical CPUs and 18 GiB RAM. The v2.6 preflight recorded APFS free
118,478,614,528 bytes and conservative free+inactive+speculative memory 5,663,850,496 bytes,
above the required floors. Native sysctl/vm_stat/df replace Linux /proc/cgroup interfaces.
The existing pinned package-tree symlink is reused; package URLs and revisions were checked
against the manifest, 39 Mathlib roots are available, and no cache fetch or cross-tree TCSlib
olean reuse occurred. See preflight/manifest/bootstrap logs.

Every round-2 check uses the repository's leanelab-o.sh, nice -n10, lean -j4, a fresh nonempty
output in `.lake/fill-ram-phases-r2-oleans`, and rejects error diagnostics or nonzero exit.
The driver holds an exclusive per-fill lock, checks the machine-wide Lean count before each
launch, waits at counts of three or more, and uses TCSLIB_LEAN_SLOTS=3. It starts at most one
owned Lean at a time. Round-2 logged wait polls at packaging: 0 (5 seconds nominal each).
The logs contain all waits. No lake build was run. The original round-1 report discloses its
brief historical bootstrap overlap; that deviation has not recurred in round 2.

Thirty unrelated modified blueprint files were preserved and excluded from this commit/patch.
Source commits remain local; only the designated checkpoint ZIP is pushed on the exchange
branch, following pull --rebase and without force or a PR.

## Source diff

```text
 TCSlib/Complexity/RAMSimulation.lean               |  14 +
 TCSlib/Complexity/RAMSimulation/Sim/PhaseCore.lean | 192 +++++++++++++
 .../RAMSimulation/Sim/PhaseInvariant.lean          | 135 +++++++++
 .../Complexity/RAMSimulation/Sim/PhaseLayout.lean  | 158 +++++++++++
 .../RAMSimulation/Sim/PhaseRegister.lean           | 104 +++++++
 TCSlib/Complexity/RAMSimulation/Sim/PhaseRows.lean | 310 +++++++++++++++++++++
 .../Complexity/RAMSimulation/Sim/PhaseTable.lean   | 246 ++++++++++++++++
 TCSlib/Complexity/RAMSimulation/Sim/PhaseTape.lean | 234 ++++++++++++++++
 TCSlib/Complexity/RAMSimulation/Sim/Phases.lean    |  31 ++-
 TCSlib/Complexity/TuringMachine/Build/Embed.lean   |   7 +
 10 files changed, 1428 insertions(+), 3 deletions(-)
```
