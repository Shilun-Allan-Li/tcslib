# fill-ram-phases

This is a **clean frontier / E-READER delivery**, permitted by COMMON.md rule 6. One of the two
requested targets is proved. The instruction-phase target remains admitted, with its original
statement and body, because its prescribed construction needs unpublished readers in files
outside this fill's ownership. No claim of a completed instruction-phase construction is made.

## Base and inputs

- Repository: Shilun-Allan-Li/tcslib.
- Read-only source base: `cb44316a22c258628bf571da8c84b72c347ee493`, fetched from
  `complexity/ram-simulation`.
- Local branch: `codex/fill-ram-phases`, created directly off that base; never rebased or pushed.
- Source commits: `b7c4bf1239da377d050ab71aca9ca077c3925334` (verdict proof), followed by `942a4aead91c49c868d211ec1c7ed3d73222f0af`
  (table invariants and permitted imports).
- Input: `arora-barak-ch3-4/outbox/fills/fill-ram-phases/` on
  `exchange/pass-shelat-ch5-8`. README and both first bundle sections were read, including the
  tier 2 addendum, as were the policy, environment addendum, design and gate 162 notes.
- Bundle SHA-256: `8ac131f6e08c0b89a52ee0cf6baf09d852e5f92cf565384fba02b556082a79da`.
  README SHA-256: `637446f075c2b2162d766a6c54539aa2c40cc4d8ccd20804fe9cdaa9e26fd16e`.
  Both match SHA256SUMS; `evidence/logs/input-integrity.log` records the checks.

## Target status

| Target | Status | Admitted dependencies reached |
|---|---|---|
| `WordRAM.Sim.exists_verdictPhase` | **Proved**, statement byte-identical | None |
| `WordRAM.Sim.exists_phase` | **Unproved**, original `sorry` retained | Not claimed as proved; no new dependency introduced |

The verdict machine has one unit state and a stationary, non-writing action. In function mode it
emits nothing; in verdict mode it emits `v`; it then halts. `encodes_iff` supplies the initial
output, and the published run/step/action field equations establish the result at time 1.
The catalog search found no plain-machine optional-emission-and-halt row from arbitrary framed
configurations. The existing guess-then-run host's verdict leaf (`Build/NDHost`) describes this
same catalog gap. The one action is therefore supplied directly; no host or transition-table
family is rebuilt.

The complete target statements were compared byte-for-byte against the base through `:= by`.
All six preexisting control declarations remain unchanged. See `statement-freeze.log`.

## Exact reader frontier

COMMON.md rule 2 says: **"A missing reader is an E-READER stop. Report it; do not unfold."**
The following equations are missing in the base's published API. They have **not** been added
here, nor read by unfolding in any delivered library proof.

1. **`WordRAM.InRange`**, defined in `TCSlib/Programs/WordRAM/Steps.lean`.
   A reader of the following form is needed:

   ```lean
   theorem inRange_iff (W : ℕ) (z : ℤ) :
       WordRAM.InRange W z ↔ -(2 : ℤ) ^ W ≤ 2 * z ∧ 2 * z < (2 : ℤ) ^ W
   ```

   This lets a consumer prove that `ImmBound` addresses remain in range at width `W + a`, and
   that signed word values lie in that range. `toInt_wd` consumes a range premise; it does not
   supply one. The only general public range constructor in the closure,
   `inRange_of_abs_le`, requires the strict symmetric bound `2 * B < 2^W`. It does not cover the
   most negative signed value at an unextended width: for `W = 1`, `a = 0`, `z = -1`, its
   premises would require both `B ≥ 1` and `2 * B < 2`. This endpoint is allowed by the phase
   statement, so it cannot simply be dropped. A suitable published range-monotonicity and
   signed-value API could serve instead of the displayed characterization.

2. **`Turing.tableFields`**, defined in `Build/RecordTable.lean`.
   The layout bound requires its equation:

   ```lean
   theorem tableFields_eq {Γ : Type*} (h : List Γ) (es : List (List (List Γ))) :
       Turing.tableFields h es = h :: es.flatten
   ```

   `keyTableLength_def` exposes a `joinFields (tableFields ...)` length, and
   `joinFields_length` is already public, but the header/flattened-fields decomposition is
   unavailable without this reader. Thus the proved entry count and widths cannot yet be
   converted into the phase's prescribed time and radius bound through that route.

3. **`Turing.TableAt`**, also defined in `Build/RecordTable.lean`.
   Reestablishing the encoded memory tape after `exists_keyAssignTM` needs its predicate reader:

   ```lean
   theorem tableAt_iff {K : ℕ} {Γ S : Type*} {x : List Γ}
       (d : Turing.Cfg K Γ S x) (r : Fin K) (o : ℤ) (h : List Γ)
       (es : List (List (List Γ))) :
       Turing.TableAt d r o h es ↔
         ∀ p : ℤ, -2 ≤ p →
           p ≤ ((Turing.joinFields (Turing.tableFields h es)).length : ℤ) + 1 →
           d.workTapes r (o + p) = Turing.fieldsTape (Turing.tableFields h es) p
   ```

   `keyTableAt_iff` still requires this opaque predicate, and `TableAt.recordAt_take` is an
   elimination lemma for a selected entry, not a constructor for the updated table. An
   equivalent published frame/update API would also serve.

`missing-readers-search.log` records the base-closure search. The three identities are tested
only as **negative controls**, in scratch probes: the native file passes (exit 0); making the
three definitions irreducible makes all three `rfl` closures fail (exit 1 as expected).
See `missing-readers-native-final.log` and `missing-readers-sealed-final.log`. These are evidence
of a forbidden definitional route, not proofs used by the library or counterexamples to the
phase statement. **No E-STATEMENT is asserted.**

The remaining construction is the instruction case split, embedding/sequencing the existing
five-tape rows, maintaining `Encodes`, the coin entry/no-reentry argument, and the aggregate
bounds. This delivery stops before claiming any such phase machine. Publishing the identified
readers in their defining files is outside this fill's allowed edits.

## New file and declarations

`TCSlib/Complexity/RAMSimulation/Sim/PhaseTable.lean` (246 lines) is the only new library file.
It is imported by `Sim/Phases.lean` and added to the `RAMSimulation.lean` facade's imports and
contents, as the brief permits. All its public declarations are in `WordRAM.Sim`:

| New public theorem | Role |
|---|---|
| `keyBits_eq_iff` | In-range key equality is cell equality |
| `tableOf_mono` | Enlarge a represented memory's allowed footprint |
| `tableOf_widths` | Every key has width `W+a`, every value width `W` |
| `tableOf_length_le` | The table has at most `T.card` entries |
| `tableOf_keyLookup` | A lookup, with the zero-word default, returns the memory word |
| `phase_bvBits_zero` | The zero word's bits are `List.replicate W false` |
| `tableOf_keyLookup_default` | Lookup correctness in the machine row's actual default form |
| `tableOf_keyAssign` | Assignment represents `Function.update m z v` over `insert z T` |

There are two new private declarations, under the assignment section:

- `phase_keyAssign_mem`: assignment consists of the new key/value pair plus the old entries
  with different keys. Factored once and used for both soundness and coverage.
- `phase_keyAssign_nodup`: replacement preserves the key list, and appending an absent key
  preserves distinctness.

There are no new definitions, machines shared between files, axioms, admissions or simp
attributes. The new helper file has no `sorry` warnings. All proofs exceeding 20 lines carry
proof sketches. No new public prose contains campaign labels.

## Reuse and definition boundaries

Before proving helpers, the base's entire 46-module import closure was searched for the
`TableOf`, key, lookup/assignment, bit-list and table APIs (`reuse-search.log`). The base has
`tableOf_iff` and the operation readers, but no lookup/assignment correctness lemmas for this
RAM invariant. The existing `bvBits_length`, `bvBits_injective`, `toInt_wd`,
`List.find?_eq_none`, `List.find?_some`, `List.mem_of_find?_eq_some`, `List.any_eq_true`,
`List.nodup_singleton`, `List.nodup_append`, `List.toFinset_card_of_nodup`,
`Finset.card_le_card`, `Finset.card_image_le`, `BitVec.getLsbD_zero` and `List.ofFn_const`
are cited. No independent cardinality, lookup search, duplicate-removal, bit-injectivity or
machine-host proof is rebuilt.

The other-file TCSlib definitions read in the delivered proofs are:

| Definition | Published reader used |
|---|---|
| `WordRAM.Sim.keyBits` | `keyBits_def` |
| `WordRAM.Sim.TableOf` | `tableOf_iff` |
| `WordRAM.Sim.Encodes` | `encodes_iff` |
| `Turing.bvBits` | `bvBits_def`, `bvBits_length`, `bvBits_injective` |
| `Turing.keyLookup` | `keyLookup_def` |
| `Turing.keyAssign` | `keyAssign_def` |
| `Turing.MultiTapeTM.runFrom` | `runFrom_one`, `runFrom_zero` |
| `Turing.MultiTapeTM.step` | `step_of_some` |
| `Turing.Action.apply` | `apply_state`, `apply_output`, `apply_workTapePos` |

`InRange` is used opaquely as an explicit premise, with `toInt_wd`, and is never unfolded.
`WordRAM.wd` is a reducible abbreviation. Configuration and action record fields are structure
projections. Core/Mathlib names in explicit rewrite/simp lists are equations, not definitions.
`WordAt`/`KeyTableAt` occur inside the encoding predicate but are not opened by the verdict proof.
The missing readers' negative controls are separate from these library proofs.

## Axioms and reachable admissions

`evidence/probes/AxiomsWalk.lean.txt` contains all nine `#print axioms` checks and a dependency
walk. The walk follows every reachable constant's type and value and reports those whose own
value directly mentions `sorryAx`; it does not stop at theorem boundaries.

| Proved declaration | Axioms | Reachable directly admitted declarations |
|---|---|---|
| `exists_verdictPhase` | `propext`, `Quot.sound` | none |
| `keyBits_eq_iff` | `propext`, `Classical.choice`, `Quot.sound`, `sorryAx` | `Turing.bvBits_injective` |
| `tableOf_mono` | `propext`, `Quot.sound` | none |
| `tableOf_widths` | `propext`, `Quot.sound` | none |
| `tableOf_length_le` | `propext`, `Classical.choice`, `Quot.sound` | none |
| `tableOf_keyLookup` | `propext`, `Classical.choice`, `Quot.sound`, `sorryAx` | `Turing.bvBits_injective` |
| `phase_bvBits_zero` | `propext`, `Quot.sound` | none |
| `tableOf_keyLookup_default` | `propext`, `Classical.choice`, `Quot.sound`, `sorryAx` | `Turing.bvBits_injective` |
| `tableOf_keyAssign` | `propext`, `Classical.choice`, `Quot.sound`, `sorryAx` | `Turing.bvBits_injective` |

The sole admission is explicitly permitted: it belongs to `Build/WordArith`, job A.
Nothing from admitted `Build/RecordTable` declarations is used. Full prints and walks are in
`axioms-walk.log`; `axioms-summary.log` checks the allowed set.

## Verification receipts

All checks used Lean 4.25.0 through the repository's `leanelab-o.sh`, `nice -n 10`, `lean -j4`,
with fresh nonempty oleans required and any error diagnostic rejected. This is the standing
maintainer wrapper and pass test; no `lake build` or project Lake command was run.

- `bootstrap-00.log` through `bootstrap-44.log`: **exit 0** for all 45 TCSlib prerequisites,
  compiled from the exact base into this fill's private `.lake/fill-ram-phases-oleans` tree.
- `cache-probe.log`: **exit 0**, importing a Mathlib root from the actual closure.
- `phase-table-final.log`: **exit 0**, no errors or warnings.
- `phases-final.log`: **exit 0**, no errors; the single admission warning is the retained
  `exists_phase`, not the proved verdict target.
- `phase-table-sealed-final.log`: **exit 0** with 330 public, ordinary foreign TCSlib
  definitions irreducible and their 3 simp attributes removed.
- `phases-sealed.log`: **exit 0** with 338 such definitions irreducible and 4 simp attributes
  removed. These inventories cover the actual respective import closures; reducible
  abbreviations, projections and unavailable private constants are excluded.
- `axioms-walk.log`: **exit 0** for all prints and dependency walks above.
- `downstream-00.log` through `downstream-29.log`: **all exit 0**, 30 remaining prerequisites
  and consumers, including `Simulation` (25), `Classes` (28) and `RAMSimulation` (29).
  The RAM facade's complete closure has 77 modules including the new helper. The repository's
  standing replay rule excludes the root `TCSlib` facade; no full-library/root build is claimed.
- `statement-freeze.log`: all declaration statements checked byte-identical, existing control
  declarations unchanged, no new admission or simp attribute.
- `git diff --check`: **exit 0** for all three delivered files.
- `package-validation.log`: patch application to the base export and delivered-file byte
  comparisons; archive CRC/SHA validation is also recorded in the exchange delivery receipt.

The earlier failed iteration logs are retained transparently. The initial bootstrap's final
owned-file attempt failed on proof elaboration and was superseded by the successful final
checks. An initial PhaseTable seal inventory mistakenly included nondeterministic constants
unavailable in its smaller import closure; its correctly scoped final seal passes. Expected
negative-control failures are labeled as such and are not failed final library checks.

## Environment, process limits and waits

- Native macOS arm64; 12 logical CPUs (`nproc` equivalent). Memory is 19,327,352,832 bytes.
  There is no cgroup or `/proc`; `sysctl`, `vm_stat`, `memory_pressure`, `df -k` and `mount`
  provide the native preflight. Initial APFS free space was **127,992,655,872 bytes**, above
  12 GiB. Excluding file cache, the conservative free + inactive + speculative estimate was
  **6,846,070,784 bytes**, above 4 GiB. The pressure tool reported 70% system-wide free.
- `.lake/packages` is a symlink to the existing main checkout's package tree at
  `/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`.
  This is the addendum's allowed pinned-package link. Every present package's URL and revision
  matches `lake-manifest.json`; the documentation packages are recorded ABSENT, not mismatched.
  The closure has 39 Mathlib roots. There are zero empty package oleans. No cache fetch,
  dependency copying, snapshot reuse, cross-tree TCSlib LEAN_PATH, or executable shim was used.
  The existing pinned user-installed toolchain was used on this native host.
- All TCSlib oleans were rebuilt by this fill; only the package link is shared. Scratch and
  temporary locations use APFS, not a memory-backed filesystem.
- `evidence/check.py` checks the machine-wide Lean process count before each check and waits
  at counts of 3 or more. It uses the common slot-lock wrapper with
  `TCSLIB_LEAN_SLOTS=3`. Later checks also hold an exclusive per-fill lock.
- **Known per-fill deviation:** the first verdict check was mistakenly started during the
  bootstrap, before its Encoding prerequisite existed. It exited 1 in 0.255 seconds. It
  briefly overlapped this fill's bootstrap process; the precheck machine count was 2.
  It is not a proof finding. No repeat occurred; subsequent checks are serial. The environment
  addendum says a process deviation does not end a fill, and work continued.
- There are **9 logged wait polls, 45 seconds nominal**, listed in `lean-waits.json`.
  At 22:14:29 local time, `phase-table-06.log` observed **4 other Lean processes** while this
  fill was between checks; it withheld its own launch until the count dropped to 2.
  Thus a machine-wide count of at most 3 throughout other workers' activity is not certified.
  No check was launched with a precheck count of 3 or more. All waits remain in their original
  log paths, and no running log was moved.
- Thirty unrelated modified blueprint files were observed in the worktree. They were left
  untouched, excluded from both local source commits and the delivery patch. The committed
  source diff against the base touches exactly the three authorized files below.

## Source diff and continuation

```text
 TCSlib/Complexity/RAMSimulation.lean               |   2 +
 .../Complexity/RAMSimulation/Sim/PhaseTable.lean   | 246 +++++++++++++++++++++
 TCSlib/Complexity/RAMSimulation/Sim/Phases.lean    |  30 ++-
 3 files changed, 275 insertions(+), 3 deletions(-)
```

`fill-ram-phases.patch` is against the exact base, and includes only these paths. The eight
new public table theorems can be reused when the reader API is published; none of the missing
readers is smuggled into a helper. The original `exists_phase` proof sketch remains unchanged in the source:

> **Proof sketch.** By cases on `ins`, each phase a sequence of the rows of
> `Build/WordArith`, `Build/KeyTable` and `Build/InputBit`, placed on the eight tapes by
> `Turing.embedEmitTM` and composed by `Turing.Contract.ofReaches` and `Turing.Contract.seq`:
> * an address `i` written in `ins` is written as a key on tape `1` (`Turing.exists_wordIntTM`
>   with `c = i`); a computed address `[j]` is looked up into a register and sign-extended into tape
>   `1` (`Turing.exists_wordSignExtendTM`);
> * operands are looked up into registers `2` and `3` (`Turing.exists_keyLookupTM`), the result is
>   computed into register `4` by the arithmetic rows (`one`, `add`, `sub`, `mul`, `half`), read
>   from the input (`rdIn`, `Turing.exists_inputBitTM`) or written from the coin (`coin`: one
>   choice step, then `Turing.exists_wordIntTM` with `c = 0` or `1`), and stored back
>   (`Turing.exists_keyAssignTM`);
> * `bltz` looks up its cell and branches on `Turing.exists_wordSignTM`; `emit` looks up its cell,
>   tests it with `Turing.exists_wordNonzeroTM`, and in function mode emits the bit.
> The table stays a `TableOf` because every key written is that of a cell of `T ∪ touches` in
> range (`ImmBound`; a word's signed value is in range), and keys of cells in range are distinct.
> The table has at most `|T|` entries of `O(W + a)` cells, which gives the bounds; the seek adds
> `O(|x|)` steps and the multiplication `O(W²)`.

No individual instruction phase was claimed proved. No checkpoint or final package is a PR;
only the exchange inbox is pushed. Checkpoint 1 contains the proved verdict phase. The final
package includes that proof plus the complete table invariant frontier. Evidence copies are
shipped as `.lean.txt`; rename a probe to `.lean` before replaying it with `evidence/check.py`.
