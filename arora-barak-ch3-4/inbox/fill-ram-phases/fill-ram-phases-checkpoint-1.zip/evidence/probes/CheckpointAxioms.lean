import TCSlib.Complexity.RAMSimulation.Sim.Phases
#print axioms WordRAM.Sim.exists_verdictPhase
