# fill-ram-phases checkpoint 1

Base: `cb44316a22c258628bf571da8c84b72c347ee493`. Local branch: `codex/fill-ram-phases`; source commit `b7c4bf1239da377d050ab71aca9ca077c3925334`.

`WordRAM.Sim.exists_verdictPhase` is proved. Its statement is unchanged. The machine uses one stationary action, emitting `v` in verdict mode and nothing in function mode, then halts. `WordRAM.Sim.exists_phase` remains admitted.

Checks: the 45 prerequisite modules were bootstrapped from the base into this fill's private olean tree. `verdict-check.log` exits 0, with only the retained `exists_phase` admission warning. `checkpoint-axioms.log` exits 0 and prints no `sorryAx` for the verdict theorem. Downstream checks and a sealed replay will accompany the final delivery.

The independent PhaseTable work is ongoing and is excluded from this checkpoint. The range and table-layout readers required by the prescribed phase route are missing; the final report will contain exact E-READER statements and probes.

The packages are linked to the main checkout's pinned `.lake/packages`, with every present URL and revision checked against the manifest. macOS equivalents of the Linux resource preflight are recorded. Initial free APFS space was 127992655872 bytes, memory headroom estimate 6846070784 bytes, and CPU count 12. Shared Lean-slot limit is 3, and the fill runs at most one check after the early overlap disclosed in `process-deviations.log`. Waits are recorded in each check log.

No new library declarations, imports or files in this checkpoint. Foreign definitions read: `Encodes` through `encodes_iff`, `MultiTapeTM.runFrom` through `runFrom_one`/`runFrom_zero`, `MultiTapeTM.step` through `step_of_some`, and `Action.apply` through its state/output/workTapePos equations. Stationary optional-emission halt has no catalog row; its single action is supplied directly.
