from pathlib import Path
import json,re,hashlib,subprocess,sys
root=Path.cwd();logs=root/'evidence-r3/logs';base='59c7b4be4a3d22b64e390ebc8b9b141ef7786c29'
with (logs/'final-static-audit.log').open('w') as f:subprocess.run([sys.executable,'evidence-r3/static_audit.py'],check=True,stdout=f,stderr=subprocess.STDOUT)
order=(logs/'base-full-order.txt').read_text().splitlines();boot=(logs/'bootstrap-order.txt').read_text().splitlines();owned=(logs/'final-owned-order.txt').read_text().splitlines();down=(logs/'downstream-order.txt').read_text().splitlines()
rows=[]
for module in order:
 name=Path(module).name
 if module in owned:label='final-doc-'+name if name in ['PhaseCompute','PhaseControl'] else f'final-owned-{owned.index(module):02d}'
 elif module in down:label=f'final-downstream-{down.index(module):02d}'
 else:label=f'bootstrap-{boot.index(module):02d}'
 p=logs/(label+'.log');s=p.read_text();sha=hashlib.sha256(Path(module+'.lean').read_bytes()).hexdigest()
 assert re.search(r'^SOURCE_SHA256 '+sha+r'$',s,re.M),(module,label,'stale source')
 assert re.search(r'^END .* exit=0$',s,re.M) and 'error:' not in s,(module,label)
 product=root/'.lake/fill-ram-phases-r3-oleans'/(module+'.olean');assert product.exists() and product.stat().st_size
 if module in owned:assert "declaration uses 'sorry'" not in s,(module,label)
 rows.append({'module':module,'log':str(p.relative_to(root/'evidence-r3')),'sha256':sha,'olean_bytes':product.stat().st_size,'exit':0})
seals=json.loads((logs/'final-seals.json').read_text());assert len(seals)==26
for row in seals:
 f=root/'TCSlib/Complexity/RAMSimulation/Sim'/(row['module']+'.lean')
 assert row['sha256']==hashlib.sha256(f.read_bytes()).hexdigest(),row
 s=(logs/('final-sealed-'+row['module']+'.log')).read_text();probe=root/'evidence-r3/probes'/('FinalSealed_'+row['module']+'.lean')
 assert 'SOURCE_SHA256 '+hashlib.sha256(probe.read_bytes()).hexdigest() in s
 assert 'error:' not in s and re.search(r'^END .* exit=0$',s,re.M)
walks={}
for p in sorted(logs.glob('full-walk-*.json')):
 v=json.loads(p.read_text());assert v['direct_admissions']==[] and v['unresolved']==[]
 names={r['name'] for r in v['constants']};assert len(names)==v['visited_count'] and v['root'] in names and 'sorryAx' not in names
 for row in v['constants']:assert set(row['type_constants']+row['value_constants'])<=names
 walks[v['root']]={'visited_count':v['visited_count'],'direct_admissions':[],'unresolved':[],'closed_type_and_value_graph':True,'file':str(p.relative_to(root/'evidence-r3'))}
assert len(walks)==2
adm=json.loads((logs/'final-admissions.json').read_text());assert all(v==[] for v in adm.values())
axiomlog=(logs/'final-axioms.log').read_text();target_axioms={}
for name in walks:
 match=re.search(r"'"+re.escape(name)+r"' depends on axioms: \[([^\]]*)\]",axiomlog);assert match,name
 target_axioms[name]=[s.strip() for s in match[1].split(',') if s.strip()]
for raw in re.findall(r'depends on axioms: \[([^\]]*)\]',axiomlog):assert {s.strip() for s in raw.split(',') if s.strip()}<={'propext','Classical.choice','Quot.sound'}
assert len(re.findall(r'^DIRECT_SORRY\|',axiomlog,re.M))==len(adm)
for label in ['final-axioms','full-target-walks','final-declarations']:
 s=(logs/(label+'.log')).read_text();assert 'error:' not in s and re.search(r'^END .* exit=0$',s,re.M)
copy=json.loads((logs/'copy-audit.json').read_text());assert copy['before']['pair_count']==151 and copy['after']['pair_count']==140
for pair in copy['after']['pairs']:assert pair['reason'] and sum(t['chars'] for t in pair['tiles'])==pair['shared']
copy['source_sha256_after']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in copy['population']}
copy['source_sha256_before']={p:hashlib.sha256(subprocess.check_output(['git','show',base+':'+p])).hexdigest() for p in copy['population']}
(logs/'copy-audit.json').write_text(json.dumps(copy,indent=2,ensure_ascii=False)+'\n')
counts=[];waits=[];rss=[];checks=[]
for p in sorted(logs.glob('*.log')):
 s=p.read_text(errors='replace')
 counts += [int(n) for n in re.findall(r'machine_lean_count=(\d+)',s)]
 if 'WAIT:' in s:waits.append({'log':p.name,'count':s.count('WAIT:')})
 rss += [int(n) for n in re.findall(r'(\d+)\s+maximum resident set size',s)]
 for m in re.finditer(r'^END (.*) seconds=([\d.]+) exit=(-?\d+)$',s,re.M):checks.append({'log':p.name,'ended':m[1],'seconds':float(m[2]),'exit':int(m[3])})
assert all(n<3 for n in counts)
styles=json.loads((logs/'style-audit.json').read_text());assert styles['new_findings']==[] and styles['runs'][1]['exit']==0
summary={'base':base,'module_checks':rows,'checked_import_closure_modules':len(rows),'sealed_modules':26,'owned_reader_roots_without_admissions':len(adm),'target_axioms':target_axioms,'full_target_walks':walks,'copy_screen':{'before_pairs':151,'after_pairs':140,'before_summed_chars':30442,'after_summed_chars':26358,'remaining_pairs_with_reasons':140},'resources':{'observed_prestart_lean_counts':sorted(set(counts)),'own_concurrency':1,'machine_limit':3,'waits':waits,'peak_maximum_resident_bytes':max(rss)},'all_checks':checks,'style':styles,'pass':True}
(logs/'final-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS:',len(rows),'source-matched module receipts; 26 final seals;',len(adm),'roots admission-free; both complete graphs closed; full copy ledger and statement/style audits valid.')
print('Target walks:',json.dumps(walks));print('Target axioms:',json.dumps(target_axioms));print('Peak RSS bytes:',max(rss),'waits:',waits)
