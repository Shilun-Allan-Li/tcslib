from pathlib import Path
import ast,json,re,hashlib
root=Path.cwd();log=root/'evidence-r3/logs/copy-audit.json';data=json.loads(log.read_text())
# Use the mandatory screen's actual extraction and matching functions, without rerunning its population screen.
tree=ast.parse(Path('scripts/copy-text-screen-v3.py').read_text());env={'re':re}
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in {'body','lcs'}:exec(compile(ast.Module([node],type_ignores=[]),'<screen-functions>','exec'),env)
DECL=re.compile(r'^(?:@\[[^\]]*\]\s*)?((?:(?:noncomputable|private|protected)\s+)*)(def|theorem|lemma|abbrev|instance|structure|inductive)\s+(\S+)',re.M)
def stripped(src):
 out=[];mapping=[];i=0;depth=0
 while i<len(src):
  if src.startswith('/-',i):depth+=1;i+=2;continue
  if depth and src.startswith('-/',i):depth-=1;i+=2;continue
  if depth:i+=1;continue
  if src.startswith('--',i):j=src.find('\n',i);i=len(src) if j<0 else j;continue
  out.append(src[i]);mapping.append(i);i+=1
 return ''.join(out),mapping
cache={}
def get(meta):
 key=(meta['file'],meta['declaration_line'])
 if key in cache:return cache[key]
 src=Path(meta['file']).read_text();t,mapping=stripped(src);ms=list(DECL.finditer(t))
 for i,m in enumerate(ms):
  if src.count('\n',0,mapping[m.start()])+1!=meta['declaration_line']:continue
  end=ms[i+1].start() if i+1<len(ms) else len(t);raw=t[m.start():end];bd=env['body'](raw);start=m.start()+len(raw)-len(bd)
  chars=[(c,mapping[start+j]) for j,c in enumerate(bd) if not c.isspace()]
  normal=''.join(c for c,_ in chars);assert hashlib.sha256(normal.encode()).hexdigest()==meta['body_sha256']
  lines=[src.count('\n',0,p)+1 for _,p in chars];cache[key]=(normal,lines);return cache[key]
 raise AssertionError(key)
for pair in data['after']['pairs']:
 left,lmap=get(pair['source_span']);right,rmap=get(pair['target_span']);li=list(range(len(left)));ri=list(range(len(right)));tiles=[]
 while True:
  n,seg=env['lcs'](left,right)
  if n<25:break
  a=left.index(seg);b=right.index(seg)
  tiles.append({'chars':n,'source_normalized_offset':li[a],'target_normalized_offset':ri[b],'source_start_line':lmap[li[a]],'source_end_line':lmap[li[a+n-1]],'target_start_line':rmap[ri[b]],'target_end_line':rmap[ri[b+n-1]],'sha256':hashlib.sha256(seg.encode()).hexdigest()})
  left=left[:a]+'\x00'+left[a+n:];li=li[:a]+[-1]+li[a+n:]
  right=right[:b]+'\x01'+right[b+n:];ri=ri[:b]+[-1]+ri[b+n:]
 assert sum(t['chars'] for t in tiles)==pair['shared'],(pair['target'],pair['source'])
 pair['tiles']=tiles
log.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
print('Recorded exact tile offsets and source line spans for all',len(data['after']['pairs']),'pairs, with matching reproduced-character totals.')
