#!/usr/bin/env bash
set -u
LOCKS="${TCSLIB_SCRATCH:-$HOME/.tcslib-scratch}"/locks
SLOT_LIMIT="${TCSLIB_LEAN_SLOTS:-5}"
case "$SLOT_LIMIT" in 1|2|3|4|5) ;; *) echo 'TCSLIB_LEAN_SLOTS must be 1..5' >&2; exit 2 ;; esac
mkdir -p "$LOCKS"
SLOT=""
release() { if [ -n "$SLOT" ]; then rm -f "$SLOT/pid"; rmdir "$SLOT" 2>/dev/null; SLOT=""; fi; }
trap release EXIT
trap 'release; exit 130' INT TERM
while [ -z "$SLOT" ]; do
  for ((i=1; i<=SLOT_LIMIT; i++)); do
    s="$LOCKS/lean-slot-$i"
    if mkdir "$s" 2>/dev/null; then echo $$ > "$s/pid"; SLOT="$s"; break; fi
    p=$(cat "$s/pid" 2>/dev/null)
    # reclaim a stale slot: its holder is gone, or it never recorded a pid within a minute
    if { [ -n "$p" ] && ! kill -0 "$p" 2>/dev/null; } || { [ -z "$p" ] && [ -n "$(find "$s" -maxdepth 0 -mmin +1 2>/dev/null)" ]; }; then
      rm -f "$s/pid"; rmdir "$s" 2>/dev/null
    fi
  done
  [ -z "$SLOT" ] && sleep 2
done
export TCSLIB_OLEANS="$PWD/.lake/fill-ram-phases-r3-oleans"
bash scripts/lean_check_tree.sh "$1"
