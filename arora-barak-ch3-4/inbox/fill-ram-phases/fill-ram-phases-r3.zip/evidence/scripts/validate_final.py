from pathlib import Path
import re,subprocess,sys,json,hashlib
root=Path.cwd();base=root/'TCSlib/Complexity/RAMSimulation/Sim'
facade=(root/'TCSlib/Complexity/RAMSimulation.lean').read_text()
names=re.findall(r'^import TCSlib\.Complexity\.RAMSimulation\.Sim\.(Phase\w*)$',facade,re.M)
assert len(names)==len(set(names))
invbody=(root/'evidence-r3/probes/InventoryCore.lean').read_text().split('import Lean',1)[1]
def check(m,l):subprocess.run([sys.executable,'evidence-r3/check.py',m,l],check=True)
resume=sys.argv[1] if len(sys.argv)>1 else None
seals=json.loads(Path('evidence-r3/logs/final-seals.json').read_text()) if resume else []
for name in names:
 if resume and names.index(name)<names.index(resume):
  old=next(r for r in seals if r['module']==name)
  assert old['sha256']==hashlib.sha256((base/(name+'.lean')).read_bytes()).hexdigest()
  continue
 src=(base/(name+'.lean')).read_text();imports='\n'.join(re.findall(r'^import .*$',src,re.M))
 inv='evidence-r3/probes/FinalInventory_'+name
 Path(inv+'.lean').write_text(imports+'\nimport Lean'+invbody)
 label='final-inventory-'+name;check(inv,label)
 rows=re.findall(r'SEALDEF\|([^|\s]+)\|(true|false)',Path('evidence-r3/logs/'+label+'.log').read_text())
 attrs='\n'.join('attribute [local irreducible] '+n+ ('\nattribute [-simp] '+n if simp=='true' else '') for n,simp in rows)
 seal='evidence-r3/probes/FinalSealed_'+name;at=src.index('set_option')
 Path(seal+'.lean').write_text(src[:at]+attrs+'\n\n'+src[at:]);check(seal,'final-sealed-'+name)
 seals=[r for r in seals if r['module']!=name]
 seals.append({'module':name,'definitions':len(rows),'simp_removed':sum(s=='true' for _,s in rows),'sha256':hashlib.sha256(src.encode()).hexdigest(),'exit':0})
 Path('evidence-r3/logs/final-seals.json').write_text(json.dumps(seals,indent=2)+'\n')
# Inventory public declarations in every owned module, including generated field readers.
mods=['TCSlib.Complexity.RAMSimulation.Sim.'+n for n in names]
probe='''import TCSlib.Complexity.RAMSimulation.Sim.Phases
import Lean
set_option maxHeartbeats 0
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let owners : List String := [OWNERS]
  for (n, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let mod := env.header.moduleNames[mi.toNat]!.toString
    unless owners.contains mod do continue
    if isPrivateName n || n.isInternalDetail then continue
    let kind := match ci with
      | .thmInfo _ => "theorem"
      | .defnInfo _ => "definition"
      | .inductInfo _ => "inductive"
      | .ctorInfo _ => "constructor"
      | .recInfo _ => "recursor"
      | .axiomInfo _ => "axiom"
      | .opaqueInfo _ => "opaque"
      | .quotInfo _ => "quotient"
    logInfo m!"OWNDECL|{mod}|{n}|{kind}"
'''.replace('OWNERS',', '.join('"'+n+'"' for n in mods))
Path('evidence-r3/probes/FinalDeclarations.lean').write_text(probe);check('evidence-r3/probes/FinalDeclarations','final-declarations')
decls=re.findall(r'OWNDECL\|([^|\n]+)\|([^|\n]+)\|([^\n]+)',Path('evidence-r3/logs/final-declarations.log').read_text())
assert decls
assert all(k!='axiom' for _,_,k in decls)
Path('evidence-r3/logs/final-declarations.tsv').write_text('module\tname\tkind\n'+'\n'.join('\t'.join(row) for row in sorted(decls))+'\n')
roots=sorted({n for _,n,_ in decls}|{'Turing.Cfg.select_eq','Turing.seamCompTM_tr_inl','Turing.NDTM.phaseHostND_tr'})
Path('evidence-r3/logs/final-declaration-roots.txt').write_text('\n'.join(roots)+'\n')
walk=(root/'evidence-r3/probes/WalkCore.lean').read_text();body=walk[walk.index('  for root in roots do'):]
probe='import TCSlib.Complexity.RAMSimulation.Sim.Phases\nimport Lean\nset_option maxHeartbeats 0\n'
probe+='\n'.join('#print axioms '+n for n in roots)+'\n\nopen Lean Elab Command in\nrun_cmd do\n  let env ← getEnv\n  let roots := #['+', '.join('`'+n for n in roots)+']\n'+body
Path('evidence-r3/probes/FinalAxioms.lean').write_text(probe);check('evidence-r3/probes/FinalAxioms','final-axioms')
# Every type-and-value root must be admission-free at this base.
log=Path('evidence-r3/logs/final-axioms.log').read_text();rows=re.findall(r'DIRECT_SORRY\|([^|\n]+)\|\[([^\]]*)\]',log)
assert len(rows)==len(roots),(len(rows),len(roots))
summary={}
for n,raw in rows:
 admissions={x.strip() for x in raw.split(',') if x.strip()};assert not admissions,(n,admissions)
 summary[n]=sorted(admissions)
for raw in re.findall(r'depends on axioms: \[([^\]]*)\]',log):
 axioms={x.strip() for x in raw.split(',') if x.strip()};assert axioms<={'propext','Classical.choice','Quot.sound'},axioms
assert 'WordRAM.Sim.exists_phase' in summary and 'WordRAM.Sim.exists_verdictPhase' in summary
Path('evidence-r3/logs/final-admissions.json').write_text(json.dumps(summary,indent=2)+'\n')
Path('evidence-r3/logs/final-target-admissions.json').write_text(json.dumps({n:summary[n] for n in ['WordRAM.Sim.exists_phase','WordRAM.Sim.exists_verdictPhase']},indent=2)+'\n')
print('PASS: all final seals, public declarations, standard axioms and empty full dependency walks.',flush=True)
