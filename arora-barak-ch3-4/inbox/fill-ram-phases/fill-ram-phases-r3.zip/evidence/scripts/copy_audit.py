from pathlib import Path
import sys,runpy,contextlib,re,json,subprocess,hashlib
root=Path.cwd();folder=root/'evidence-r3/logs'
files=(folder/'copy-population-before.txt').read_text().splitlines()
(folder/'copy-population-after.txt').write_text('\n'.join(files)+'\n')
sys.argv=['scripts/copy-text-screen-v3.py',str(root),*files]
with (folder/'copy-screen-after.log').open('w') as f,contextlib.redirect_stdout(f):
 env=runpy.run_path('scripts/copy-text-screen-v3.py',run_name='__main__')
def mapped_strip(src):
 out=[];mapping=[];i=0;depth=0
 while i<len(src):
  if src.startswith('/-',i):depth+=1;i+=2;continue
  if depth and src.startswith('-/',i):depth-=1;i+=2;continue
  if depth:i+=1;continue
  if src.startswith('--',i):
   j=src.find('\n',i);i=len(src) if j<0 else j;continue
  out.append(src[i]);mapping.append(i);i+=1
 return ''.join(out),mapping

def inventory(sources):
 result={}
 for p,src in sources.items():
  t,mapping=mapped_strip(src);assert t==env['strip'](src)
  ms=list(env['DECL'].finditer(t));ev=env['scopes'](p,t);found=[]
  for i,m in enumerate(ms):
   end=ms[i+1].start() if i+1<len(ms) else len(t)
   raw=t[m.start():end];bd=env['body'](raw);normal=re.sub(r'\s+','',bd)
   if len(normal)<60:continue
   ns=[n for o,n in ev if o<=m.start()][-1]
   found.append((m.start(),end,len(raw)-len(bd),m.group(3),env['qualify'](ns,m.group(3)),normal))
  short={};qual={};seen={}
  for _,_,_,nm,qn,_ in found:short[nm]=short.get(nm,0)+1;qual[qn]=qual.get(qn,0)+1
  for pos,end,skip,nm,qn,bd in found:
   if short[nm]==1:name=nm
   elif qual[qn]==1:name=qn
   else:seen[qn]=seen.get(qn,0)+1;name=f'{qn}#{seen[qn]}'
   label=env['label'](p)+'::'+name
   result[label]={'file':p,'name':name,'declaration_line':src.count('\n',0,mapping[pos])+1,'body_start_line':src.count('\n',0,mapping[min(pos+skip,len(mapping)-1)])+1,'screen_span_end_line':src.count('\n',0,mapping[end-1])+1,'normalized_chars':len(bd),'body_sha256':hashlib.sha256(bd.encode()).hexdigest()}
 return result
before_sources={p:subprocess.check_output(['git','show','59c7b4be4a3d22b64e390ebc8b9b141ef7786c29:'+p],text=True) for p in files}
after_sources={p:Path(p).read_text() for p in files}
before_meta=inventory(before_sources);after_meta=inventory(after_sources)
before_pairs=[]
for line in (folder/'copy-screen-before.log').read_text().splitlines():
 m=re.match(r'\s+(.+)  reproduces  (.+): (\d+)/(\d+) = (\d+)%$',line)
 if m:before_pairs.append({'target':m[1],'source':m[2],'shared':int(m[3]),'source_length':int(m[4]),'fraction':int(m[3])/int(m[4])})
base_keys={(p['target'],p['source']):p for p in before_pairs};after_pairs=[]
for frac,sh,ln,target,source in env['pairs']:
 prior=base_keys.get((target,source));status='new pair'
 if prior:
  status='unchanged bodies' if before_meta[target]['body_sha256']==after_meta[target]['body_sha256'] and before_meta[source]['body_sha256']==after_meta[source]['body_sha256'] else 'existing pair, edited body'
 after_pairs.append({'target':target,'source':source,'shared':sh,'source_length':ln,'fraction':frac,'baseline_status':status,'before_shared':prior['shared'] if prior else None,'target_span':after_meta[target],'source_span':after_meta[source]})
def ledger(pairs,meta):
 rows={p:{'directed_pairs':0,'summed_reproduced_chars':0,'target_declarations':set(),'spans':{}} for p in files}
 for pair in pairs:
  label=pair['target'];m=meta[label];row=rows[m['file']];row['directed_pairs']+=1;row['summed_reproduced_chars']+=pair['shared'];row['target_declarations'].add(label);row['spans'][label]={k:m[k] for k in ['declaration_line','body_start_line','screen_span_end_line','normalized_chars']}
 for row in rows.values():row['target_declarations']=sorted(row['target_declarations'])
 return rows
result={'base':'59c7b4be4a3d22b64e390ebc8b9b141ef7786c29','population':files,'method':'v3 directed greedy tiling; all pairs with shared >=60 and >=half of source; summed chars are not unique copied characters','before':{'declarations':len(before_meta),'pair_count':len(before_pairs),'summed_reproduced_chars':sum(p['shared'] for p in before_pairs),'pairs':before_pairs,'ledger':ledger(before_pairs,before_meta)},'after':{'declarations':len(after_meta),'pair_count':len(after_pairs),'summed_reproduced_chars':sum(p['shared'] for p in after_pairs),'pairs':after_pairs,'ledger':ledger(after_pairs,after_meta)},'removed_pairs':[p for p in before_pairs if (p['target'],p['source']) not in {(q['target'],q['source']) for q in after_pairs}]}
(folder/'copy-audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print((folder/'copy-screen-after.log').read_text().splitlines()[0])
print('New or edited pairs:')
for p in after_pairs:
 if p['baseline_status']!='unchanged bodies':print(p['baseline_status'],p['target'],'->',p['source'],f"{p['shared']}/{p['source_length']}")
print('Removed pairs:',len(result['removed_pairs']))
