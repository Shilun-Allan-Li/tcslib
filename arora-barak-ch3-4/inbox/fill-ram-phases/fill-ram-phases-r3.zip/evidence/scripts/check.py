from pathlib import Path
import os,sys,time,subprocess,datetime,fcntl,hashlib,shutil
root=Path.cwd(); own_lock=(root/'evidence-r3/own-check.lock').open('w'); fcntl.flock(own_lock,fcntl.LOCK_EX)
ol=root/'.lake/fill-ram-phases-r3-oleans'; ol.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env['TCSLIB_LEAN_SLOTS']='3'

def check(module,label):
    import re
    for dep in re.findall(r'^import\s+(TCSlib\.[^\s]+)',Path(module+'.lean').read_text(),re.M):
        product=ol/(dep.replace('.','/')+'.olean')
        assert product.exists() and product.stat().st_size,('missing prerequisite',module,dep)
    log=root/'evidence-r3/logs'/f'{label}.log'
    target=ol/(module+'.olean'); target.parent.mkdir(parents=True,exist_ok=True)
    if log.exists():
        serial=1
        while log.with_name(f'{label}-prior-{serial}.log').exists(): serial+=1
        shutil.copyfile(log,log.with_name(f'{label}-prior-{serial}.log'))
    with log.open('w') as f:
        while True:
            r=subprocess.check_output(['ps','-axo','pid=,comm=','-ww'],text=True)
            rows=[l for l in r.splitlines() if l.split() and Path(l.split(maxsplit=1)[1]).name=='lean']
            f.write(f'{datetime.datetime.now().isoformat()} machine_lean_count={len(rows)}\n');f.flush()
            if len(rows)<3: break
            f.write('WAIT: machine-wide Lean limit; retry in 5 seconds\n');f.flush();time.sleep(5)
        target.unlink(missing_ok=True)
        start=time.time()
        cmd=['/usr/bin/time','-l','nice','-n','10','bash','evidence-r3/lean-check-slot.sh',module]
        f.write('START '+datetime.datetime.now().isoformat()+'\n');f.write('SOURCE_SHA256 '+hashlib.sha256(Path(module+'.lean').read_bytes()).hexdigest()+'\n');f.write('COMMAND '+' '.join(cmd)+'\n');f.flush()
        p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
        f.write(f'END {datetime.datetime.now().isoformat()} seconds={time.time()-start:.3f} exit={p.returncode}\n')
    text=log.read_text();ok=p.returncode==0 and 'error:' not in text and target.exists() and target.stat().st_size>0
    print(f'{label}: {"PASS" if ok else "FAIL"}',flush=True)
    if not ok: print(text,flush=True);sys.exit(1)

if sys.argv[1]=='bootstrap':
    check('evidence-r3/probes/CacheProbe','cache-probe')
    for i,m in enumerate(Path('evidence-r3/logs/bootstrap-order.txt').read_text().splitlines()): check(m,f'bootstrap-{i:02d}')
elif sys.argv[1]=='order':
    for i,m in enumerate(Path(sys.argv[2]).read_text().splitlines()): check(m,f'{sys.argv[3]}-{i:02d}')
else: check(sys.argv[1],sys.argv[2])
