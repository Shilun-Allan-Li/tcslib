from pathlib import Path
import subprocess,sys,re,json,hashlib
root=Path.cwd();base=root/'TCSlib/Complexity/RAMSimulation/Sim'
def check(m,l):subprocess.run([sys.executable,'evidence-r3/check.py',m,l],check=True)
seals=json.loads(Path('evidence-r3/logs/final-seals.json').read_text())
invbody=Path('evidence-r3/probes/InventoryCore.lean').read_text().split('import Lean',1)[1]
for name in ['PhaseCompute','PhaseControl']:
 check('TCSlib/Complexity/RAMSimulation/Sim/'+name,'final-doc-'+name)
 src=(base/(name+'.lean')).read_text();imports='\n'.join(re.findall(r'^import .*$',src,re.M))
 inv='evidence-r3/probes/FinalInventory_'+name;Path(inv+'.lean').write_text(imports+'\nimport Lean'+invbody)
 label='final-inventory-'+name;check(inv,label)
 rows=re.findall(r'SEALDEF\|([^|\s]+)\|(true|false)',Path('evidence-r3/logs/'+label+'.log').read_text())
 attrs='\n'.join('attribute [local irreducible] '+n+ ('\nattribute [-simp] '+n if simp=='true' else '') for n,simp in rows)
 seal='evidence-r3/probes/FinalSealed_'+name;at=src.index('set_option');Path(seal+'.lean').write_text(src[:at]+attrs+'\n\n'+src[at:]);check(seal,'final-sealed-'+name)
 for row in seals:
  if row['module']==name:row.update(definitions=len(rows),simp_removed=sum(s=='true' for _,s in rows),sha256=hashlib.sha256(src.encode()).hexdigest(),exit=0)
Path('evidence-r3/logs/final-seals.json').write_text(json.dumps(seals,indent=2)+'\n')
# Only documentation changed. Re-read the complete axiom/admission and graph probes against the final products.
check('evidence-r3/probes/FinalAxioms','final-axioms')
check('evidence-r3/probes/FullTargetWalks','full-target-walks')
print('Documentation-only final receipts refreshed.',flush=True)
