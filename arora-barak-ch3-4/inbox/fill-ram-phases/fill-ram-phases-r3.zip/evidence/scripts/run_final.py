from pathlib import Path
import subprocess,sys
for mode,args in [('order',['evidence-r3/logs/final-owned-order.txt','final-owned']),('order',['evidence-r3/logs/downstream-order.txt','final-downstream'])]:
 subprocess.run([sys.executable,'evidence-r3/check.py',mode,*args],check=True)
subprocess.run([sys.executable,'evidence-r3/validate_final.py'],check=True)
subprocess.run([sys.executable,'evidence-r3/check.py','evidence-r3/probes/FullTargetWalks','full-target-walks'],check=True)
