from pathlib import Path
import subprocess,sys,json,hashlib,zipfile,shutil,tempfile,re,datetime
root=Path.cwd();ev=root/'evidence-r3';logs=ev/'logs';dest=ev/'delivery';dest.mkdir(exist_ok=True)
base='59c7b4be4a3d22b64e390ebc8b9b141ef7786c29'
info=json.loads((logs/'source-commit.json').read_text());commit=info['source_commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
metrics=json.loads((logs/'final-validation.json').read_text());assert metrics['pass']
paths=json.loads((logs/'final-authorized-paths.json').read_text());sourcefiles=sorted(paths)
for p in sourcefiles:
 f=dest/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(Path(p).read_bytes())
patch=subprocess.check_output(['git','diff','--binary','--full-index',base,commit,'--',*sourcefiles]);(dest/'changes.patch').write_bytes(patch)
stat=subprocess.check_output(['git','diff','--stat',base,commit,'--',*sourcefiles],text=True);(logs/'diff-stat.txt').write_text(stat)
# Apply the patch outside any checkout, using only text exports of the exact base.
with tempfile.TemporaryDirectory(prefix='ram-phases-r3-apply-',dir='/private/tmp') as tmp:
 for p in sourcefiles:
  f=Path(tmp)/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','show',base+':'+p]))
 subprocess.run(['git','apply','--check',str(dest/'changes.patch')],cwd=tmp,check=True)
 subprocess.run(['git','apply',str(dest/'changes.patch')],cwd=tmp,check=True)
 for p in sourcefiles:assert (Path(tmp)/p).read_bytes()==Path(p).read_bytes()==(dest/p).read_bytes(),p
validation={'base':base,'source_commit':commit,'patch_apply_check_exit':0,'patch_apply_exit':0,'delivered_source_files':len(sourcefiles),'all_patched_bytes_match':True,'diff_stat':stat}
(logs/'package-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
static=json.loads((logs/'final-static-audit.json').read_text());counts=[r for r in static if 'before_lines' in r];seals=json.loads((logs/'final-seals.json').read_text());copy=json.loads((logs/'copy-audit.json').read_text());styles=json.loads((logs/'style-audit.json').read_text());pre=json.loads((logs/'preflight-summary.json').read_text())
def line(file,name):
 s=Path('TCSlib/Complexity/RAMSimulation/Sim/'+file+'.lean').read_text();m=re.search(r'^(?:structure|abbrev|theorem) '+re.escape(name)+r'\b',s,re.M);assert m,(file,name);return s.count('\n',0,m.start())+1
counttable='\n'.join(f"| `{Path(r['source']).name}` | {r['before_lines']} | {r['after_lines']} | {r['after_lines']-r['before_lines']:+d} |" for r in counts)
sealtable='\n'.join(f"| `{r['module']}` | {r['definitions']} | {r['simp_removed']} | 0 |" for r in seals)
ledgertable=[]
for p,b in copy['before']['ledger'].items():
 a=copy['after']['ledger'][p];name=p.removeprefix('TCSlib/Complexity/RAMSimulation/Sim/').removeprefix('TCSlib/Complexity/TuringMachine/Build/')
 ledgertable.append(f"| `{name}` | {len(b['target_declarations'])} / {len(a['target_declarations'])} | {b['directed_pairs']} / {a['directed_pairs']} | {b['summed_reproduced_chars']} / {a['summed_reproduced_chars']} |")
ledger='\n'.join(ledgertable)
def short(label):return label.replace('TCSlib/Complexity/TuringMachine/Build/','').replace('.lean::','::')
pairtable=[]
for i,p in enumerate(copy['after']['pairs'],1):
 a=p['target_span'];b=p['source_span'];span=f"{a['body_start_line']}–{a['screen_span_end_line']} / {b['body_start_line']}–{b['screen_span_end_line']}"
 status='baseline' if p['baseline_status']=='unchanged bodies' else p['baseline_status']
 pairtable.append(f"| {i} | `{short(p['target'])}` → `{short(p['source'])}` | {p['shared']}/{p['source_length']} ({p['fraction']:.1%}) | {span} | {status}; {p['reason']} |")
pairs='\n'.join(pairtable)
removed='\n'.join(f"| `{short(p['target'])}` → `{short(p['source'])}` | {p['shared']}/{p['source_length']} ({p['fraction']:.1%}) |" for p in copy['removed_pairs'])
report=f'''# fill-ram-phases-r3

Completed the two gate-170 repairs against **{base}**, exactly the dispatch base (PR #386,
`ram/fill-phases`). Local source branch: `codex/fill-ram-phases-r3`; local source commit:
**{commit}**. The source branch is not pushed, and no PR is opened.

Input: `exchange/pass-shelat-ch5-8:arora-barak-ch3-4/outbox/fills/fill-ram-phases-r3/`.
The bundle's SHA-256 is **ec5e73b93a79ebabb8bf52d6e887733a8c3c58c1916b486fcf2c54115ce64ffc**,
matching both the dispatch literal and `SHA256SUMS`; the README checksum also matches.
The first two bundle sections (COMMON including tier 2, then the R3 brief) were read first.
The bundled findings, policy, workflows and environment addendum were then consulted.
The integrity and pinned input records are under `evidence/inputs/`.

Both targets remain proved. Their admission lists are empty, with no allowance for inherited
admissions. **The entire `Sim/Phases.lean` module is byte-identical to the base**, hence both
headline statements are byte-identical. All TCSlib files outside the owned population are
unchanged except the facade's permitted Contents descriptions. No foreign declaration,
statement, reader, attribute, or proof body was changed. In particular, the existing
`Turing.Cfg.select_eq` is consumed rather than added again.

## Unified certificate and caller moves

`PhaseCertificate E P Q selected` (PhaseBlock:{line('PhaseBlock','PhaseCertificate')}) stores one finite machine,
an injective `E ↪ State` exit map, a common constant, and a restored-head run to
`exit (selected x i)` whose cut is `Set.range (fun e => some (exit e))`.
Its exit type has `Fintype` and `DecidableEq` parameters.

- `PhaseBlock` is the Unit specialization, selected by `()`.
- `PhaseBranch` is the Bool specialization, selected by its existing input/data flag.
- `PhaseCertificate.seq` (PhaseBlock:{line('PhaseBlock','PhaseCertificate.seq')}) has the only certificate composition
  proof: a Unit-exit prefix followed by any finite-exit certificate. It cites
  `phase_reaches_seq`, transports the exit range through `Sum.inr`, and absorbs dispatch once.
- `phase_machine_ofCertificate` (PhaseControl:{line('PhaseControl','phase_machine_ofCertificate')}) has the only fresh-entry packaging
  proof. Its two `Option E` slots route the native labels to next/jump. A present slot is the
  corresponding native exit on the seam's right; an empty slot uses the never-targeted left
  true state. The routing witness is necessary because `PhaseMachine` has exactly two distinct
  external exits. Certificate composition itself remains generic over every finite E.
  The Unit instance uses next=`some ()`, jump=`none`, classify=false. The Bool instance uses
  next=`some false`, jump=`some true`, classify=id. This fully shares seam construction,
  zero-prefix composition, fresh-entry proof, allowance absorption, and exit-cut restriction.
- `phase_machine_ofBlock` and `phase_machine_ofBranch` retain their statements and are thin
  citations supplying those routing data. Neither contains a seam/run/allowance proof.

Declarations removed, merged or renamed:

| Former declaration/interface | Replacement and callers |
|---|---|
| `structure PhaseBlock`, `structure PhaseBranch` | One `structure PhaseCertificate`; old names retained as Unit/Bool abbreviations. Their separate constructors/field families are removed. |
| `PhaseBlock.seq`, `PhaseBranch.seq` | One `PhaseCertificate.seq`. Dot calls in PhaseSchedules and PhaseOperations resolve to it; PhaseBranchMachines now explicitly cites it. |
| `PhaseBlock.weaken` | `PhaseCertificate.weaken`, generalized over E. There was no direct use of the old block-specific helper in this closure. `PhaseMachine.weaken` is unchanged. |
| Native branch `yes`, `no`, `distinct` fields | Injective Bool exit map in `phase_testBlock`, whose applications recover the same native yes/no endpoints. `Bool.range_eq` reads its two-exit cut. |
| Block's state-valued `exit` | `exit ()`; PhaseFork's redirection and continuation contract use this label and `Set.range_unique` for the singleton cut. |
| Two substantive `phase_machine_of*` proofs | One `phase_machine_ofCertificate`; the two old entry points are citation-only specializations. |
| Singleton-only `phase_reaches_add_unused` | Same owned name, generalized to restrict any cut to a subset of its old exits plus one unused state. It supports the one common packaging proof. |

New explicit public names, all in `WordRAM.Sim`: `PhaseCertificate`, `PhaseBlock_eq`,
`PhaseBranch_eq`, `PhaseCertificate.weaken`, `PhaseCertificate.seq`,
`phase_machine_ofCertificate`. The generated record constructor/projections/recursors replace
the two old generated families. Both abbreviations have published equality readers.
The complete final generated and explicit surface is in `final-declarations.tsv`.
No new private declaration, file, host, simp attribute, axiom or admission was introduced.
Local `loc`, `hloc`, `X`, `hmem`, and `hcut` establish routing inside the one packaging proof.
The existing seam/host contracts are reused; the halted Boolean padding leaf performs no
computation and the existing seam supplies dispatch. No native transition table is rederived.

Two inherited missing proof-sketch markers (phase_sourceBlock and phase_seam_fresh) were
filled in; their proof bodies were not changed. Every owned file passes the repository style
lint. No file was added/removed. The facade imports stay identical and its two Contents lines
now name the unified interface and the Bool specialization.

## Segment citations

`phase_reaches_zero` (PhaseControl:{line('PhaseControl','phase_reaches_zero')}) obtains its segment from `Turing.Segment.zero`,
reads it with `Turing.segment_iff`, and returns the bounded form through
`Turing.reachesWithin_iff`. It no longer proves the zero-time run/cut/envelope by cases.

`phase_reaches_trans` (PhaseHost:{line('PhaseHost','phase_reaches_trans')}) reads both bounded witnesses through
`reachesWithin_iff`, widens both head predicates to the summed radius about F, and uses restored
intermediate heads to identify G's center with F's. It constructs the two segments through
`segment_iff`, cites **`Turing.Segment.trans`**, then reads the result back through both
published readers. Its only additional proof work is radius and time-bound transport.
There is no `runFrom_add` call, run-prefix split, or reconstructed segment concatenation.
Both public ReachesWithin wrappers remain because their callers need that interface.

The import closure and construction registry were searched before these adapters: Segment.zero,
trans and mono; reachesWithin_iff/mono; Contract.ofReaches/seq; seam transition equations;
Mathlib Set.range_unique/range_comp', Bool.injective_iff/range_eq, and
Function.Embedding.coeFn_mk. The selected facts are cited rather than reproved.

## Source sizes

All counts are physical source lines; every owned file is below 600. Full source digests and
scope/freeze receipts are in `final-static-audit.json`.

| Owned file | Base | Delivered | Delta |
|---|---:|---:|---:|
{counttable}

## Readers, homes and seals

No home-file reader was added. The important changed-code reads are Segment via segment_iff;
ReachesWithin via reachesWithin_iff; frame configurations via PhaseFrame.cfg_eq; deterministic
embedding/fixed choice via their q₀/tr equations; seam transitions via seamCompTM_tr_inl/inr and
Action.mapState_state. Certificate fields are structure projections, and Unit/Bool aliases are
reducible notation with equality readers. Core/Mathlib definitions are not passed to explicit
simp/rw/unfold lists; the embedding application is read by Function.Embedding.coeFn_mk.

The unchanged proof population continues to read these other-file definitions through their
published API (the seal inventories enumerate all eligible imported TCSlib definitions, a
superset of those reached by the proofs):

| Definition family | Equations/contracts consumed |
|---|---|
| InRange; keyBits; TableOf; Encodes; ImmBound; immediates | inRange_iff; keyBits_def; tableOf_iff; encodes_iff; immBound_iff; immediates_def |
| xstep; effect; inBitWord; coinWord; touches/baseTouches | xstep_def; effect_def; inBitWord_def; coinWord_def; XInstr.touches_def; baseTouches_def |
| bvBits; word/scratch layout | bvBits_def/length/injective; wordAt_iff; wordWrite_apply; scratchBlank_iff |
| keyed/table layouts and operations | keyFields_def; keyTableLength_def; keyTableAt_iff; keyLookup_def; keyAssign_def; keyTableWrite_apply; tableFields_eq; tableAt_iff; joinFields_length; fieldsTape_of_neg/of_length_le; bufferTape_left/nat |
| Cfg.select/mapState/bindState | select_eq; mapState field equations and mapState_eq_of_fields; bindState field equations |
| embedEmitTM/embedEmitCfg | embedEmitTM_runFrom; embedEmitCfg_eq/select/state/selected_pos/unselected |
| machine run/step; action application | runFrom_zero/one/succ_eq_step'; step_of_some/of_halt; Action.apply field equations; moveInputPos_zero |
| FinTM.controlAction | controlAction_def; controlAction_apply |
| seamCompTM | tr_inl/tr_inr; Contract.seq; phase_reaches_seq |
| Segment; ReachesWithin | segment_iff; Segment.zero/trans; reachesWithin_iff; ReachesWithin.mono |
| Contract.ofReaches/seq/inPhase | pre/time/post/lo/hi equations; ofReaches_time_le; run/cut/env projections |
| phaseHostTM; NDTM.phaseHostND | phaseHostTM_run_le; phaseHostND_tr; phaseHostND_fixChoice |
| NDTM.fixChoice; MultiTapeTM.toNDTM | q₀/tr equations; phase_toNDTM_fixChoice |
| frame/register interfaces | cfg_eq, ofCfg and write/assign/emit generated field equations; phaseReady_iff; phaseScratch_iff; phaseState_iff; phasePost_iff; bank apply equations; PhaseArith.value_eq/steps_eq; PhaseTestKind.bit_eq and their contracts |

All **104 pinned base source homes** in the TCSlib import closure are archived under
`evidence/citation-homes/` as text, with paths and SHA-256 in `citation-homes.json`, including
all Segment/Reach/Seam/NDHost and catalog/word/RAM homes. The delivered owned sources supply
the corresponding current homes. No reviewer needs to retrieve an omitted citation home.

Every one of the 26 owned modules was re-elaborated in a scratch copy with all eligible
other-file TCSlib definitions locally irreducible and their simp-unfold attributes removed.
The standard inventory excludes reducible abbreviations, projections, private and internal
constants. Exact inventory names, attributes, source hashes, probe sources and logs are shipped.

| Sealed owned module | Foreign definitions | Simp attributes removed | Exit |
|---|---:|---:|---:|
{sealtable}

## Complete admission walks and axiom prints

The final probe audits **all {metrics['owned_reader_roots_without_admissions']} owned/reader roots** by traversing both the type and
value of every reachable constant, including theorem bodies and foreign definition values.
Every direct-admission list is empty: no allowed-frontier shortcut or theorem-boundary stop.
The exact probe, prints, lists and assertions are in `FinalAxioms.lean.txt`, `final-axioms.log`,
`final-admissions.json`, and `final-target-admissions.json`.

```text
'WordRAM.Sim.exists_phase' depends on axioms: [propext, Classical.choice, Quot.sound]
'WordRAM.Sim.exists_verdictPhase' depends on axioms: [propext, Quot.sound]
DIRECT_SORRY|WordRAM.Sim.exists_phase|[]
DIRECT_SORRY|WordRAM.Sim.exists_verdictPhase|[]
```

Separate complete graph exports make the walks independently inspectable. Each records every
visited constant and its direct type/value edges; the final checker verifies graph closure,
no unresolved constant, and no sorryAx node:

| Target | Visited constants | Direct admissions | Unresolved | Full type-and-value graph |
|---|---:|---|---|---|
| exists_phase | 9301 | `[]` | `[]` | `full-walk-WordRAM.Sim.exists_phase.json` |
| exists_verdictPhase | 2036 | `[]` | `[]` | `full-walk-WordRAM.Sim.exists_verdictPhase.json` |

Both full JSON graphs, not just their metadata allowance, are included in this delivery.

## Verification and resources

- Exact-base bootstrap: **96 TCSlib modules** plus a Mathlib-root cache probe, all exit 0,
  into a newly created `.lake/fill-ram-phases-r3-oleans`. No R1/R2 TCSlib olean was reused.
- Final official `scripts/lean_check_tree.sh` sweep: all **26 owned modules** and **8 remaining
  downstream modules** exit 0, including Phases, Simulation, Classes and RAMSimulation.
  The two doc-only fixes have refreshed source and seal receipts, followed by fresh admission
  and complete-graph probes. No proved owned target has a sorry warning.
- Every module of the final **104-module closure** has a successful receipt matching its current
  source SHA-256 and a nonempty product in the new private tree. See final-validation.json and
  the supplied order lists. The root TCSlib facade was not built.
- All 26 final seals, declaration inventory, axiom prints, all-root walks and both full-graph
  probes exit 0. The static/scope/statement audit and git diff --check pass.
- Owned style lint: exit 0, zero findings. Combined owned+facade lint: exit 1, exactly three
  pre-existing missing-option findings in the facade (baseline five findings). Adding facade
  options is outside this job's permitted imports/Contents edit. No new style finding remains.
- The patch applies cleanly to text exports of the exact base; all 27 delivered source files
  match the applied patch byte-for-byte and the local commit. `package-validation.json` records it.

Native macOS arm64, 12 logical CPUs, 18 GiB physical RAM. The addendum's Linux probes were
replaced by sysctl, vm_stat, memory_pressure, native df/mount, and /usr/bin/time -l; raw outputs
are in preflight.log. Conservative available memory was **{pre['conservative_memory_available_bytes']} bytes**
(free + inactive + speculative pages, {pre['conservative_memory_available_bytes']/1024**3:.2f} GiB) and APFS free space was
**{pre['filesystem_free_bytes']} bytes** ({pre['filesystem_free_bytes']/1024**3:.2f} GiB), exceeding the 4/12 GiB floors.
Observed maximum RSS was **{metrics['resources']['peak_maximum_resident_bytes']} bytes**
({metrics['resources']['peak_maximum_resident_bytes']/1024**2:.1f} MiB). No E-RES condition or executable shim occurred.

The existing `.lake/packages` symlink points to
`/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`.
Every present package URL and revision matches the current manifest; doc-gen4, UnicodeBasic,
BibtexQuery and MD4Lean are correctly recorded ABSENT. No module imports an absent package.
There are zero empty package oleans, and the real Mathlib-root probe passes. Bool's precise
Set import was already cached. No cache fetch, dependency-tree copy or cross-tree TCSlib
product reuse occurred. No `lake build` command was used.

At most **one Lean process of this job** ran at a time. Before each it checked the machine count,
then held one of the repository's three shared slot locks. Prestart counts were
{metrics['resources']['observed_prestart_lean_counts']}; **no Lean waits** were needed. Bootstrap used the pinned leanelab wrapper;
final checks use the official tree checker under the same shared-slot discipline. Text screens
ran one at a time under nice -n10; the sandboxed initial baseline screen could not lower priority
and logged that harmless native permission message. Later screens ran with the requested
priority. Development failures are retained (Bool embedding equation and frame/radius adapter
elaboration); final successful receipts and source hashes distinguish them from final checks.

## Copy screen: complete baseline, after and cumulative ledger

The required `scripts/copy-text-screen-v3.py` ran over all **26 Phase*.lean files including
Phases**, plus Build/Contract/Basic, Build/Contract/Seam, Build/Seam and Build/NDHost.
Both full logs, the exact population, per-pair dispositions, hashes and exact matched tile
spans are included. There are no omitted >=half pairs.

| Run | Screened declarations | Directed >=half pairs | Summed reproduced characters |
|---|---:|---:|---:|
| Exact base | 285 | 151 | 30442 |
| Delivered | 284 | 140 | 26358 |
| Difference | -1 | -11 | -4084 |

Twelve former pairs disappear, including both directions of the 661-character seq overlap and
806-character packaging overlap, and the two duplicated Unit/Bool records. Of the 140 remaining
pairs, 138 have unchanged normalized bodies, one is the same native-test adapter pair with the
same 188/343 overlap after its Bool-map edit, and one is the merged certificate/PhaseRow record
interface (159/300). The latter replaces the old records' corresponding interface matches;
it is not a new copied proof. Neither shared certificate seq nor shared packaging appears in
any remaining >=half pair. Segment algebra is cited regardless of its former textual score.

The following ledger is cumulative over the **whole supplied population**, including unchanged
construction homes. Counts and sums are directed screen accounting; they double-count
bidirectional matches and overlapping tiles across different pairs and therefore are **not**
unique lines or an assertion that each match is copied proved material. `copy-audit.json`
contains each involved declaration/body span, every tile's exact source/target line range and
normalized offset, shared characters, denominator, fraction, baseline status and explicit reason.
Frozen-home similarities and structural/contract adapters are reported rather than silently
excluded. This report does not request acceptance of either repaired major as debt.

| File | Distinct matched target declarations before/after | Directed pairs before/after | Summed chars before/after |
|---|---:|---:|---:|
{ledger}

All remaining directed pairs and reasons (the two span ranges are target/source screen-extracted
body spans; exact subspans are in the JSON tiles):

| # | Target reproduces source | Shared/source chars | Body lines target/source | Baseline status and reason retained |
|---|---|---:|---|---|
{pairs}

All baseline pairs absent after the refactor:

| Former target → source | Baseline shared/source |
|---|---:|
{removed}

## Patch and delivery

```text
{stat.rstrip()}
```

The archive contains REPORT.md, all 26 delivered owned files, the facade, the base-relative
patch, check/probe scripts and logs, full graph exports, and all pinned citation homes. No
olean, package tree, toolchain or compiled binary is shipped. Scratch probes are archived as
`.lean.txt`; rename to `.lean` to replay them. Paths referenced above are under `evidence/logs/`
unless a source/probe path is given. `SHA256SUMS` covers every other archive entry.

Delivery is only `arora-barak-ch3-4/inbox/fill-ram-phases/fill-ram-phases-r3.zip` on
`exchange/pass-shelat-ch5-8`, after `git pull --rebase`, without force or a source-branch push.
A separate managed delivery checkout avoids the shared exchange checkout's unrelated ahead
commit and untracked inbox files. Existing source-checkout blueprint edits are preserved and
excluded from the commit/patch/archive. No checkpoint is required for this completed round.
'''
(dest/'REPORT.md').write_text(report)
# Export evidence without scratch compiled products or recursive delivery files.
for sub in ['logs','inputs','citation-homes']:
 for p in sorted((ev/sub).rglob('*')):
  if not p.is_file() or p.name in {'final-zip-validation.json','exchange-delivery.json'}:continue
  rel=p.relative_to(ev);out=dest/'evidence'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
for p in sorted((ev/'probes').glob('*.lean')):
 out=dest/'evidence/probes'/(p.name+'.txt');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
for p in sorted(ev.glob('*.py')):
 out=dest/'evidence/scripts'/p.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
for p in [ev/'lean-check-slot.sh',ev/'refactor-plan.json']:
 out=dest/'evidence/scripts'/p.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
# Include pinned verification tools as replay references.
for rel in ['scripts/lean_check_tree.sh','scripts/copy-text-screen-v3.py','scripts/style_lint.py','devtools/seyoon/leanelab-o.sh']:
 out=dest/'evidence/pinned-tools'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(Path(rel).read_bytes())
entries=[p for p in sorted(dest.rglob('*')) if p.is_file() and p!=dest/'SHA256SUMS' and p.suffix!='.zip']
(dest/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(dest).as_posix()+'\n' for p in entries))
zip_path=ev/'fill-ram-phases-r3.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(dest.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(dest).as_posix())
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 assert {row.split('  ',1)[1] for row in z.read('SHA256SUMS').decode().splitlines()}==set(names)-{'SHA256SUMS'}
 for row in z.read('SHA256SUMS').decode().splitlines():
  sha,rel=row.split('  ',1);assert hashlib.sha256(z.read(rel)).hexdigest()==sha,rel
 assert not any(n.endswith(('.olean','.ilean','.so','.dylib')) for n in names)
 for p in sourcefiles:assert z.read(p)==Path(p).read_bytes()
sha=hashlib.sha256(zip_path.read_bytes()).hexdigest()
(ev/'fill-ram-phases-r3.zip.sha256').write_text(sha+'  fill-ram-phases-r3.zip\n')
receipt={'zip':str(zip_path),'sha256':sha,'bytes':zip_path.stat().st_size,'entries':len(names),'manifest_entries':len(entries),'crc_pass':True,'manifest_pass':True,'source_files_match':True,'base_patch_pass':True,'source_commit':commit}
(logs/'final-zip-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
