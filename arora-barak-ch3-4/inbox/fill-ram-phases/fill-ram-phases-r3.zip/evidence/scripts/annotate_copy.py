from pathlib import Path
import json
p=Path('evidence-r3/logs/copy-audit.json');v=json.loads(p.read_text())
def reason(pair):
 t=pair['target'];s=pair['source'];both=t+' '+s
 tf=pair['target_span']['file'];sf=pair['source_span']['file']
 if '::PhaseCertificate' in both:
  return 'Record interface fields, not a copied proof: an existential postcondition certificate and an exact frame-transforming row both store finite control and a bounded run. This replaces the two former Unit/Bool records; only one certificate composition and packaging proof remains.'
 if 'PhaseTests.lean::phase_testBlock' in both:
  return 'Existing native-row adapter overlap (188/343 in both runs): select the arithmetic bank, supply the known word and scratch, embed and enlarge native bounds. The edited test additionally installs an injective Bool exit map and reads Bool.range_eq; it cites the shared packaging rather than copying it.'
 if all('/TuringMachine/Build/' in f for f in [tf,sf]):
  if any('::'+n in both for n in ['RoundContract','ReturnContract','Contract']) and not any('release' in x for x in [t,s]):
   return 'Unchanged construction-home record fields: finite-run/return/round contracts share endpoint, cut and envelope data but impose different return or repeated-round interfaces. Both files are frozen outside this job.'
  if 'positive' in both:return 'Unchanged construction-home positivity adapters: both discharge positivity from their published composition time equations. These frozen homes are outside this job.'
  if any('::'+n in both for n in ['segment_iff','safeSegment_iff','round_iff','traj_iff']):
   return 'Unchanged construction-home characterization/endpoint clauses. The screen includes common formula tails surrounding definitional readers; these are not new phase proofs. The frozen homes are outside this job.'
  if 'hullLo' in both or 'hullHi' in both:return 'Unchanged dual lower/upper hull equations in the frozen construction home; the only differing operation is the appropriate minimum/maximum.'
  if 'phaseHost' in both:return 'Unchanged deterministic/nondeterministic registered-host definitions. Their redirect and mapped-action branches coincide structurally; this job consumes their contracts and does not copy either implementation.'
  if 'instDecidableEqCtlState' in both or 'instFintypeCtlState' in both:return 'Unchanged finite-control instance enumerations in the frozen nondeterministic host. Equality and finiteness enumerate the same control tags but supply different instances.'
  if 'release' in both:return 'Unchanged return/round release combinator proofs in the frozen Contract/Seam home. Their similar endpoint/envelope transport predates the job and is included in the baseline ledger.'
  if '::Frames.seq' in both or '::Traj.seq' in both:return 'Unchanged construction-home adapters composing framed and trajectory contracts; both cite the shared seam contract with their different wrapper fields.'
  if '::branch' in both and '::seq' in both:return 'Unchanged generic branch/sequential construction proofs in the frozen Contract/Seam home. The baseline already contains this shared seam setup; the phase refactor cites these contracts.'
  if any('::'+n in both for n in ['time_box','time_envelope','locate','cut','Frames.trans','Cfg.SameOutside.keep_blank','endpoint_not_mem']):
   return 'Unchanged contract projection/transport glue in the frozen Basic home: destruct a contract witness, retain its endpoint/cut/envelope or infer blankness. The overlap is baseline construction material, not a new phase proof.'
  if any('Cfg' in x or '::wr_cfg' in x for x in [t,s]):return 'Unchanged nondeterministic-host configuration constructors copy their input, tapes, heads and output fields into different control layouts; baseline record syntax, not a new proof.'
  if 'guess' in both:return 'Unchanged guess-host run/handoff proofs in the frozen NDHost home. They share the fixed-choice/host transport setup but establish the stated live, handoff or controlled endpoint; included unchanged in the baseline.'
  if 'wr_prefix' in both or 'ndWriterTM' in both:return 'Unchanged writer-host prefix/block proof setup in the frozen NDHost home; different prefix/block conclusions consume the same host run equations.'
  return 'Unchanged seam construction-home readers and run/space corollaries: the same mapped step or run equation supplies distinct endpoint, first-return or head-visit bounds. Both homes are frozen outside this job.'
 if ('PhaseFrame.' in both or 'guessRunCfg' in both or 'streamStartCfg' in both or 'Cfg.bindState' in both) and not ('phase_frame_emit_encodes' in both):
  return 'Existing configuration/frame record syntax: the constructors preserve input position, work tapes, heads and output while installing, erasing, binding or changing control/one frame field. These term bodies are distinct operations, not copied tactic proofs.'
 if 'PhaseMemoryMachines.lean' in tf and 'PhaseMemoryMachines.lean' in sf:
  return 'Unchanged instruction-specific adapters: obtain the named schedule, cite shared phase_machine_ofBlock, and weaken its postcondition using the RAM step reader. The shared fresh-entry, run and allowance proof lives only in phase_machine_ofCertificate.'
 if 'PhaseRows.lean' in tf and 'PhaseRows.lean' in sf:
  return 'Unchanged native-row adapters: select the arithmetic bank, supply the native row premise, and cite shared phase_wordRow/phase_nativeRow plus embedding readers. Constants, unary and binary arithmetic have different native contracts and frame updates; no seam/packaging proof is copied.'
 if ('PhaseCompute.lean' in tf or 'PhaseAtoms.lean' in tf) and ('PhaseCompute.lean' in sf or 'PhaseAtoms.lean' in sf):
  return 'Unchanged block adapters over different native rows: choose its row witness, invoke PhaseBlock.ofRow, and provide its register/frame postcondition and allowance inequalities. The common block construction and sequencing are factored separately.'
 if ('PhaseOperations.lean' in tf or 'PhaseSchedules.lean' in tf) and ('PhaseOperations.lean' in sf or 'PhaseSchedules.lean' in sf):
  return 'Unchanged instruction schedules: common register specifications and fetch/store citations recur, but the instruction-dependent middle operation and dependency order differ. Actual block composition now resolves to the single PhaseCertificate.seq proof.'
 if 'phase_frame_emit_encodes' in both and 'phase_encodes_congr' in both:
  return 'Unchanged encoding field-congruence glue: emission preserves the encoded memory/tape fields, so its adapter uses the existing encoding congruence reader with the same equality premises.'
 if 'PhaseInput.lean' in both and 'PhaseRows.lean' in both:
  return 'Unchanged native placement adapters: select the bank, establish scratch/word premises, embed the native contract and recover the frame. Input additionally controls inputPos; arithmetic uses its own native word row. Their reused transport is supplied by shared phase_reaches_embed and frame readers.'
 if 'phase_keyAssign_layout_mono' in both and 'phase_tableOf_layout_bound' in both:
  return 'Unchanged layout-bound adapters sharing the same nonnegative/cardinality arithmetic; assignment uses its keyed-update layout theorem, while the canonical table uses its table layout theorem.'
 if 'phase_post_of_write' in both and 'phase_post_of_read' in both:
  return 'Unchanged RAM postcondition adapters: read the phase-state encoding and transport it to the extended RAM configuration through effect/xstep and encoding-congruence readers. A write changes memory; a read retains it.'
 if 'phaseMemoryEntries' in both and 'PhaseState' in both:
  return 'Screen extraction includes adjacent type/record formula text: both refer to encoded cells/configurations and a frame cfg. These are different definitions (canonical entries versus state invariant), not copied proofs.'
 if 'phase_encoded_heads' in both and 'phase_frame_scratch' in both:
  return 'Unchanged projections of the same encodes_iff witness: one reads the head center and the other reads scratch blankness. Shared destructuring syntax is incidental; conclusions differ.'
 if 'Phases.lean::exists_phase' in both and 'PhaseMachine.weaken' in both:
  return 'Unchanged packaging/projection tail: the headline installs a chosen internal machine into the frozen external certificate, while weaken retains that machine and changes predicates. Both copy existing fields and adapt a run; neither reimplements finite-exit packaging.'
 if 'phase_emitMachine' in both and 'phase_bltzMachine' in both:
  return 'Unchanged instruction-specific final wrappers: both adapt a selected native Boolean test and weaken the encoded postcondition. Emission joins two continuations through phase_forkMachine; signed branch keeps the routed jump. Shared routing/packaging proofs are cited.'
 if 'phase_assignRow' in both and 'phase_frame_assign_encodes' in both:
  return 'Unchanged assignment adapters both obtain layout/write invariants and read frame fields, but one certifies the bounded native run while the other establishes the encoded keyed-memory postcondition.'
 raise AssertionError(('UNREVIEWED',t,s))
for pair in v['after']['pairs']:pair['reason']=reason(pair)
p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
print('Every one of',len(v['after']['pairs']),'remaining directed pairs has an explicit reason; no default/unreviewed disposition.')
