from pathlib import Path
import subprocess,sys,json
root=Path.cwd();base='59c7b4be4a3d22b64e390ebc8b9b141ef7786c29'
owned=sorted(map(str,Path('TCSlib/Complexity/RAMSimulation/Sim').glob('Phase*.lean')));files=owned+['TCSlib/Complexity/RAMSimulation.lean']
for p in files:
 out=Path('evidence-r3/baseline')/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(subprocess.check_output(['git','show',base+':'+p]))
rows=[]
for name,ps in [('style-lint-before',['evidence-r3/baseline/'+p for p in files]),('style-lint-owned',owned),('style-lint-final',files)]:
 with Path('evidence-r3/logs/'+name+'.log').open('w') as f:
  p=subprocess.run([sys.executable,'scripts/style_lint.py',*ps],stdout=f,stderr=subprocess.STDOUT)
 rows.append({'check':name,'exit':p.returncode,'population':ps})
owned_log=Path('evidence-r3/logs/style-lint-owned.log').read_text();assert rows[1]['exit']==0,owned_log
before=Path('evidence-r3/logs/style-lint-before.log').read_text().replace('evidence-r3/baseline/','')
after=Path('evidence-r3/logs/style-lint-final.log').read_text()
find=lambda s:{l for l in s.splitlines() if l.startswith('TCSlib/')}
assert not find(after)-find(before),(find(after)-find(before))
assert len(find(after))==3 and all('RAMSimulation.lean: missing `set_option' in l for l in find(after))
Path('evidence-r3/logs/style-audit.json').write_text(json.dumps({'runs':rows,'baseline_findings':sorted(find(before)),'final_findings':sorted(find(after)),'resolved_findings':sorted(find(before)-find(after)),'new_findings':[]},indent=2)+'\n')
print('Owned style lint: 0 findings; combined lint: 3 unchanged facade option findings (baseline 5); no new findings.')
