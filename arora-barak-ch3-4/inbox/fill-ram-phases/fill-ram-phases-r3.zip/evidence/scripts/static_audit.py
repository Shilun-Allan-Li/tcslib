from pathlib import Path
import subprocess,re,json,hashlib
root=Path.cwd();base='59c7b4be4a3d22b64e390ebc8b9b141ef7786c29'
folder=Path('TCSlib/Complexity/RAMSimulation/Sim');owned=sorted(folder.glob('Phase*.lean'));report=[]
for p in owned:
 s=p.read_text();old=subprocess.check_output(['git','show',base+':'+str(p)],text=True)
 assert len(s.splitlines())<600,p
 assert not re.search(r'\b(sorry|admit|axiom)\b',s),p
 assert not re.search(r'@\[simp\]|attribute\s+\[simp\]',s),p
 assert all(x in s for x in ['Copyright (c)','set_option maxHeartbeats 0','set_option relaxedAutoImplicit false','set_option autoImplicit false','## Main definitions','## Main results','## References']),p
 assert s.count('namespace WordRAM.Sim')==1,p
 report.append({'source':str(p),'before_lines':len(old.splitlines()),'after_lines':len(s.splitlines()),'sha256':hashlib.sha256(s.encode()).hexdigest(),'no_admission_or_simp':True,'changed':s!=old})
p=folder/'Phases.lean';old=subprocess.check_output(['git','show',base+':'+str(p)],text=True)
assert p.read_text()==old,'Entire Phases module changed'
for name in ['exists_phase','exists_verdictPhase']:
 report.append({'target':name,'statement_byte_identical':True,'entire_module_byte_identical':True})
p=Path('TCSlib/Complexity/RAMSimulation.lean');old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);s=p.read_text()
def keep(t):
 t='\n'.join(l for l in t.splitlines() if not l.startswith('import '));a=t.index('## Contents');b=t.index('## References',a);return t[:a]+t[b:]
assert keep(old)==keep(s),'facade changes outside imports/Contents'
assert re.findall(r'^import .*$',old,re.M)==re.findall(r'^import .*$',s,re.M),'unexpected import changes'
for p in owned:
 if p.stem!='Phases':
  assert 'import TCSlib.Complexity.RAMSimulation.Sim.'+p.stem+'\n' in s,p
  assert '`RAMSimulation.Sim.'+p.stem+'`' in s,p
changed=subprocess.check_output(['git','diff','--name-only',base,'--','TCSlib'],text=True).splitlines()
assert all(p in {str(f) for f in owned}|{'TCSlib/Complexity/RAMSimulation.lean'} for p in changed),changed
report.append({'outside_owned_statements_byte_identical':True,'no_new_home_reader':True,'facade_only_contents':True,'changed_paths':changed})
control=(folder/'PhaseControl.lean').read_text();host=(folder/'PhaseHost.lean').read_text();block=(folder/'PhaseBlock.lean').read_text();branch=(folder/'PhaseBranching.lean').read_text()
zero=control.split('theorem phase_reaches_zero',1)[1].split('/--',1)[0]
trans=host.split('theorem phase_reaches_trans',1)[1].split('end WordRAM.Sim',1)[0]
assert all(n in zero for n in ['Segment.zero','segment_iff','reachesWithin_iff'])
assert all(n in trans for n in ['Segment.trans','segment_iff','reachesWithin_iff'])
assert 'runFrom_add' not in trans and 'runFrom_zero' not in zero
assert 'theorem PhaseBlock.seq' not in block and 'theorem PhaseBranch.seq' not in branch
assert block.count('theorem PhaseCertificate.seq')==1
assert 'structure PhaseCertificate' in block and 'abbrev PhaseBlock' in block and 'abbrev PhaseBranch' in block
for s,name in [(control,'phase_machine_ofBlock'),(branch,'phase_machine_ofBranch')]:
 body=s.split('theorem '+name,1)[1].split(':=',1)[1].split('end WordRAM.Sim',1)[0]
 assert 'phase_machine_ofCertificate' in body and 'seamCompTM' not in body and 'phase_reaches_seq' not in body
report.append({'single_certificate':True,'single_seq_proof':True,'single_packaging_proof':True,'Segment_citations':True})
Path('evidence-r3/logs/final-authorized-paths.json').write_text(json.dumps([str(p) for p in owned]+['TCSlib/Complexity/RAMSimulation.lean'],indent=2)+'\n')
Path('evidence-r3/logs/final-static-audit.json').write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['git','diff','--check',base,'--',*[str(p) for p in owned],'TCSlib/Complexity/RAMSimulation.lean'],check=True)
print('PASS: target module byte-identical; all outside-owned TCSlib sources frozen; facade Contents only; no new readers; 26 owned files under 600 lines; no admissions or simp attributes; shared proofs and Segment citations verified.')
