"""Check the frozen target, home-file exception, and required proof documentation."""
from pathlib import Path
import subprocess,re,json
base='0de483083650950569a96b0a3da4fb3f2103e997'
files=['TCSlib/Programs/Light/TMProc.lean','TCSlib/Programs/Light/Syntax.lean','TCSlib/Programs/Light/Rules.lean','TCSlib/Programs/Light/Calls.lean']
s=Path(files[0]).read_text();old=subprocess.check_output(['git','show',base+':'+files[0]],text=True)
def signature(t):
 j=t.index('theorem exists_tmProc');return t[j:t.index(':= by',j)]
assert signature(s)==signature(old)
assert not re.search(r'\b(sorry|admit|axiom)\b',s)
readers=[]
for f,mark in zip(files[1:],['/-! ## Equations for reading expressions and tests -/','/-! ## Equations for reading blocks -/','theorem meets_iff']):
 text=Path(f).read_text().split(mark,1)[1]
 if mark=='theorem meets_iff':text='theorem meets_iff'+text.split('section\nvariable {p : ℕ}',1)[0]
 names=re.findall(r'^theorem\s+([\w.]+)',text,re.M)
 for n in names:assert re.search(re.escape(n)+r'\b',s),n
 assert len(re.findall(r':=\s*(?:Iff\.)?rfl',text))==len(names)
 assert '@[simp]' not in text
 readers.extend(names)
 diff=subprocess.check_output(['git','diff','--no-ext-diff','--unified=0',base,'--',f],text=True)
 assert not any(x.startswith('-') and not x.startswith('---') for x in diff.splitlines()),f
for m in re.finditer(r'(?m)^(?:private )?theorem\s+(\w+)',s):
 end=s.find('\n/--',m.end());end=len(s) if end<0 else end
 dec=s[m.start():end]
 if ':= by' not in dec:continue
 n=len(dec.split(':= by',1)[1].strip().splitlines())
 ds=s.rfind('/--',0,m.start());de=s.rfind('-/',0,m.start())
 doc=s[ds:de] if ds>=0 and not s[de+2:m.start()].strip() else ''
 assert n<=20 or '**Proof sketch.**' in doc,(m.group(1),n)
subprocess.run(['git','diff','--check',base,'--',*files],check=True)
print(json.dumps({'base':base,'statement_freeze':'PASS','owned_admissions':0,'base_reader_home_statements':'UNCHANGED','retained_pure_used_readers':len(readers),'owned_lines':len(s.splitlines()),'explicit_private_proofs':len(re.findall(r'^private theorem',s,re.M)),'long_proof_sketches':'PASS','controlled_diff_check':'PASS'},indent=2))
print('EXIT 0')
