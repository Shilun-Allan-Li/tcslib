# fill-ram-tmproc — checkpoint 3

Status: **active fill; not a completed proof**. `Light.exists_tmProc` retains its one original
`sorry`. This checkpoint preserves the concrete simulator construction and its proved foundations.
The complete round invariant is now proved; setup and the timed loop remain open. No E-STATEMENT, E-READER,
E-HOST, or E-RES stop is claimed.

## Provenance and scope

- Base: `0de483083650950569a96b0a3da4fb3f2103e997` (`ram/tmproc-statement`, PR #382), fetched read-only from origin.
- Local proof branch: `codex/fill-ram-tmproc`; checkpoint source commit: `fbd8dae40161ec1ff798cbf03a81386d2c94d99d`. The proof
  branch has never been rebased and has not been pushed.
- Exchange: `exchange/pass-shelat-ch5-8`; delivery folder:
  `arora-barak-ch3-4/inbox/fill-ram-tmproc/`. No PR is opened.
- The exchange README and bundle were read. Bundle SHA-256:
  `1c4387c89fa8ec76770c2200050077eea0598c6a1e765ac0d266c0092d90ee57`, matching `SHA256SUMS`.
  README SHA-256: `3fd0930595bdc517899be7b9cbfc459510b37f739f1b5ecaf6f29ca531782d83`, also matching.
  The campaign-text snapshot is `3fc27517af938fec0b3e0f53f85766a5e81f82e6`.
- The first two bundle sections, including the tier 2 missing-readers rule, policy, workflow,
  and the environment addendum were read. The exact target signature is byte-identical to base.
- The patch changes the owned file and, under the explicit pure-reader exception, three reader
  homes. All 39 new public readers have proof `rfl` or `Iff.rfl`; no existing declaration is changed.
- The fresh source worktree showed unrelated blueprint case-collision differences on this
  case-insensitive macOS filesystem. They were not edited, staged, committed, or packaged.

## Construction and proved frontier

Chosen route: **code branches**. The private `tmBody M` is one procedure, with no procedure calls.
`tmDispatch` generates a branch per live-state/input/work-symbol row, using a fixed finite
state enumeration (`List.idxOf` on `Finset.univ.toList`) rather than `Fintype.equivFin`.
Blank/false/true use 0/1/2. `tmAddr sc tapes j z = sc + tmCell z * tapes + j` interleaves signed
tape positions. The address map is injective and has a proved linear radius bound.

Each round clears the next two cell-code rows through the existing `pass`, freezes the old
work-head positions, reads input and work symbols, dispatches the transition, and increments
the round number. The loop stops at control code zero and returns the output count.

Proved parts include:

- injectivity/radius arithmetic for signed tape positions and addresses;
- initialized head envelopes and blankness outside the prior radius, through published Turing readers;
- first-halt extraction from `ComputesInTime` and relocation of a procedure specification;
- finite test selection, finite dispatch, and uniqueness of an encoded transition row;
- the static tape-bank invariant rule;
- lazy ring initialization's preservation and new-cell values;
- `tmClearRing_ends`: exact ring memory and the cost `26 * M.k + 18`, preserving every local
  outside the three initialization temporaries;
- the signed work-head displacement expression and its exact assignment semantics.

Additional proved parts since checkpoint 2 include the complete read-only preparation bank,
clamped input motion, exact optional output emission, the simultaneous work-tape action bank,
and `tmActionBody_runs` for a whole fixed transition action. `tmTail_runs` proves that finite
row selection implements precisely `MultiTapeTM.step`. Finally `tmRound_ends` includes the
scratch-ring initialization and preserves `TMRunInv` at the next round, with cost
`26 * M.k + 18 + (tmTail M).blockCost`. It preserves the represented tapes, output prefix,
and `SameOutside2`, and recovers the original input via that promise and region separation.

**Open target:** `Light.exists_tmProc` retains its original admission. The remaining obligations
are to initialize the invariant, instantiate `Ends.whileConst` up to `tmFirstHalt`, choose one
machine-dependent constant bounding time/scratch/intermediate words, return the output length,
and apply `tmMeets_behind`. The one-round theorem is fully proved; no timed-loop or headline
completion is claimed.

The owned file now has 1,896 lines, above the brief's approximate 1,500-line threshold. As the
brief instructs, work continues in the owned file; the maintainer can split it at landing.

## Every private declaration

| Declaration | Status | Role |
|---|---|---|
| `tmCell` | definition / notation | A signed work-tape position has an even code on the nonnegative side and an odd code on its negative side. This is the direct-address layout used for the work tapes. |
| `tmCell_injective` | proved theorem | Distinct signed positions have distinct cell codes. |
| `tmCell_le` | proved theorem | Positions within radius `n` use cell codes at most `2 * n + 1`. |
| `tmCell_lt_iff` | proved theorem | The first `2 * i` cell codes are exactly the signed positions of absolute value below `i`. |
| `tmAddr` | definition / notation | Tape `j` uses the corresponding residue class in an interleaved scratch array. |
| `tmIndex_injective` | proved theorem | Quotient and remainder uniquely identify a bank number and its finite index. |
| `tmLocal_ne` | proved theorem | Two static local-bank indices differ if their banks or finite indices differ. |
| `tmAddr_injective` | proved theorem | The interleaved address identifies both the tape and its signed position. |
| `tmAddr_lt` | proved theorem | A cell in radius `n` lies in the first `tapes * (2 * n + 2)` scratch cells. |
| `tmHead_abs_le` | proved theorem | Before step `i`, every work head is within radius `i` of the origin. |
| `tmTape_blank` | proved theorem | At time `i`, cells at distance at least `i` are still blank. A simulator may initialize these cells as it expands its scratch region, without a time bound supplied to the program. |
| `tmFirstHalt` | proved theorem | A completed computation has a positive first halting time no greater than its deadline, with the prescribed output and live states at every earlier time. |
| `tmMeets_behind` | proved theorem | Relocating a procedure and appending other procedures preserves its specification. |
| `tmSet_runs` | proved theorem | A safe assignment with a known expression value has the displayed exact local update. |
| `tmStore_runs` | proved theorem | A safe store with a known in-range natural address and value has the displayed exact memory update and preserves the local variables. |
| `tmMatches` | definition / notation | The listed locals have the listed natural values. |
| `tmSelect` | definition / notation | Test a fixed finite list of local values, choosing `yes` only when all agree. |
| `tmSelect_runs` | proved theorem | Finite branch selection preserves any common postcondition of its two alternatives. |
| `tmDispatch` | definition / notation | A finite table compiled as code branches, with no transition table stored in memory. |
| `tmDispatch_runs` | proved theorem | A compiled finite table executes the selected row whenever that row occurs in the table. |
| `tmSym` | definition / notation | Blank, false, and true have codes zero, one, and two. |
| `tmSym_some_eq` | proved theorem | The nonblank symbol code is the bit value plus one. |
| `tmSym_le_two` | proved theorem | Every encoded work symbol is at most two. |
| `tmBits` | definition / notation | A bit string represented as one integer word per bit in memory. |
| `tmRingMemory` | definition / notation | Zero the next pair of cell-code rows, leaving all previously initialized rows alone. |
| `tmRingMemory_old` | proved theorem | Initializing the next ring preserves every earlier represented cell. |
| `tmRingMemory_new` | proved theorem | Every cell in the new pair of cell-code rows is initialized to blank. |
| `tmSym_injective` | proved theorem | The three symbol codes distinguish blank and the two bits. |
| `tmRingMemory_tapes` | proved theorem | Clearing the next ring extends a correct tape encoding from strict radius `i` to radius `i`. |
| `tmStateCode` | definition / notation | The live states have positive indices in a fixed enumeration; zero denotes halt. |
| `tmStateCode_injective` | proved theorem | Distinct optional machine states have distinct control-state codes. |
| `tmStateCode_le` | proved theorem | All control-state codes are bounded by the size of the fixed state enumeration plus one. |
| `TMRow` | definition / notation | A transition row specifies a live state and the input and work symbols it scans. |
| `tmRows` | definition / notation | All transition rows of a finite binary machine, enumerated once when generating the code. |
| `tmSeq` | definition / notation | Sequential composition of a fixed list of statements. |
| `tmSeq_accumulate` | proved theorem | A static bank preserves its invariant, establishes the property of every visited index, and preserves that property at any index where it already held. |
| `tmBank` | definition / notation | One statically generated block per work tape. |
| `tmHead` | definition / notation | Local numbers for work heads, scanned work symbols, and computed tape addresses. The first ten locals hold the arguments, input position, control state, output length, and round number. |
| `tmScan` | definition / notation | Local index for the scanned work symbol. |
| `tmAddress` | definition / notation | Local index for the computed work-tape address. |
| `tmOldHead` | definition / notation | Local index for the frozen work-head position. |
| `TMFrame` | definition / notation | The stable locals describing one simulated configuration. The temporary locals for addresses, frozen heads, scans, and scratch initialization are deliberately unconstrained. |
| `TMLocated` | definition / notation | The frozen work heads and their direct addresses for one simulated configuration. |
| `TMScanned` | definition / notation | The scanned input and work symbols captured before the transition writes any tape. |
| `TMTapes` | definition / notation | The represented cells of all work tapes within a strict radius. |
| `TMTapesAway` | definition / notation | The represented work cells away from the old head on each tape; old head cells may be rewritten while a transition's static tape bank is executing. |
| `tmTapesAway_write` | proved theorem | Writing at an old work head preserves every represented cell away from all old heads. The address injectivity theorem separates both different tapes and different signed cells. |
| `tmKeyLocal` | definition / notation | The locals constrained by `TMFrame`: the eight scalar locals and the current work heads. |
| `tmFrame_transfer` | proved theorem | Preserving the stable locals other than the round counter, and assigning a new counter, preserves the configuration frame at that new round. |
| `tmFrame_round` | proved theorem | Assigning the round local changes only the round index of the represented frame. |
| `tmFrame_tmp` | proved theorem | Changing a temporary local outside the scalar and head banks preserves the frame, with no restriction on the replacement memory. |
| `tmLocated_tmp` | proved theorem | A local update outside the frozen-head/address interval preserves the located data, independently of the replacement memory. |
| `tmScanned_tmp` | proved theorem | Updating a local outside the captured input/work scan slots preserves their old symbol codes, independently of the replacement memory. |
| `tmAddrExpr` | definition / notation | The scratch address of the nonnegative cell code `code` on tape `j`. |
| `tmAddrExpr_read` | proved theorem | A natural cell-code expression gives the corresponding safe interleaved address whenever its code, the two constants, and the resulting address fit the limits. |
| `tmClearRing` | definition / notation | Initialize the next two interleaved cell-code rows using the existing pass routine. Locals eight and nine hold its destination and length; its counter is beyond the tape locals. |
| `tmClearRing_ends` | proved theorem | Clearing one newly reachable ring costs `26 * M.k + 18` steps, leaves the represented memory `tmRingMemory`, and changes only the pass's three temporary locals. |
| `tmCodeExpr` | definition / notation | The two arithmetic branches computing a signed tape position's cell code. |
| `tmCodeExpr_read` | proved theorem | The selected sign branch safely computes the signed cell code using only linear arithmetic in the head position. |
| `tmLocate` | definition / notation | Compute a head's direct scratch address by branching on its sign. |
| `tmLocate_runs` | proved theorem | Locating one tape freezes its head and records its direct scratch address, changing no memory and no other locals. |
| `tmLocateBank_runs` | proved theorem | Locating the whole work-head bank preserves the frame and memory and records every frozen head and direct address. |
| `tmReadTape` | definition / notation | Read the symbol at one previously computed work-tape address into its scan local. |
| `tmScanBank_runs` | proved theorem | Reading all work symbols preserves the frame, located data, input code, and memory. |
| `tmInputZeroTest` | proved theorem | The zero-position test is safe and identifies exactly the left input end marker. |
| `tmInputEnd_read` | proved theorem | The expression for the right input end marker is safe and has value `n + 1`. |
| `tmReadInput` | definition / notation | Read the input in place, encoding either end marker as blank. |
| `tmReadInput_runs` | proved theorem | Reading the input changes only the scanned-input local, and returns the machine's actual input symbol under the blank/bit encoding. |
| `tmPrepare` | definition / notation | The read-only preparation of a transition: locate the work heads and read all symbols. |
| `tmPrepare_runs` | proved theorem | Transition preparation preserves memory and the stable frame and captures all addresses, frozen heads, and scanned symbols. |
| `tmDisplace` | definition / notation | A fixed transition displacement applied to a frozen work-head local. |
| `tmDisplace_read` | proved theorem | A displacement expression is safe under its unit and result bounds and returns the signed head position plus the transition displacement. |
| `tmMoveWork` | definition / notation | Move a work head from its frozen position. The frozen locals make all tape updates independent, so the static bank implements simultaneous work-tape actions. |
| `tmMoveWork_runs` | proved theorem | A work-head update changes only its destination local and returns the prescribed signed position; its expression safety is `tmDisplace_read`. |
| `tmMoveInput` | definition / notation | Move the input head, clamping outward moves at the two end markers. |
| `tmMoveInput_runs` | proved theorem | Input-head motion changes only its local and agrees with the machine's clamped movement. |
| `tmWriteMove` | definition / notation | One tape's transition writes the chosen symbol, or writes back the scanned symbol when there is no write, then moves the head. |
| `tmWriteMove_runs` | proved theorem | One tape's write and head movement have the normalized optional-write effect used by `Action.apply_workTapes` and change only that tape cell and head local. |
| `tmWriteBank_runs` | proved theorem | The complete tape-action bank preserves the eight scalar locals and old output, updates all heads and represented tape cells as the action prescribes, and keeps the external memory. |
| `tmEmit` | definition / notation | Append the optional output bit and advance the output length. |
| `tmEmitState` | definition / notation | The exact state after an optional output emission. |
| `tmEmitState_locals` | proved theorem | The output cursor is the only local changed by emission, with absent emission leaving its existing value unchanged. |
| `tmEmitState_data` | proved theorem | Emission extends the output segment and keeps represented work tapes and external memory when the final output region is apart from scratch. |
| `tmEmit_runs` | proved theorem | Output emission appends the optional bit at the output cursor, advances its length, and leaves every other local and memory cell unchanged. |
| `tmFinishState` | definition / notation | Finish a transition after the work-tape bank: move the input head, emit output, and install the next control state, as an exact-state description. |
| `tmFinishState_frame` | proved theorem | Finishing the scalar updates after a correct tape bank gives the complete next frame. |
| `tmActionBody` | definition / notation | The executable block for one fixed action. |
| `tmActionBody_runs` | proved theorem | A fixed transition action updates the complete configuration representation, output, and external-memory promise within the supplied word and region bounds. |
| `tmRowBody` | definition / notation | The block implementing one fixed row of the machine's transition function. |
| `tmRowTests` | definition / notation | The local-value tests identifying a transition row. |
| `tmRowTests_matches_iff` | proved theorem | Reading a row's tests gives exactly its control state and scanned symbols. |
| `tmRowTests_unique` | proved theorem | If the scanned locals encode `actual`, a row's tests succeed exactly for that row. |
| `tmTail` | definition / notation | The block after scratch initialization: read the old configuration, execute its transition row, and advance the round count. |
| `tmAction` | definition / notation | The transition selected by a live configuration. |
| `tmTail_runs` | proved theorem | Reading a live configuration, selecting its row, and advancing the counter simulates exactly one machine step under the given word and region bounds. |
| `tmRound` | definition / notation | One simulator round initializes its newly reachable cells, then executes the transition. |
| `TMRunInv` | definition / notation | Before round `i`, the stable frame, initialized work cells, output prefix, and untouched external memory encode the machine after exactly `i` steps. |
| `tmRound_ends` | proved theorem | A simulator round preserves the run invariant when its next initialized ring and all intermediate words fit the supplied limits. |
| `tmBody` | definition / notation | The generated simulator has one procedure and no calls. The loop observes the encoded halting state, and local zero receives the final output length only after the loop. |

## Reader additions and imports

The following are exact constructor equations or exact predicate restatements in the definitions'
home files. They carry no simp attribute, and all are independently checked by the reader controls.
Some are prepared for the still-open expression and transition proofs; the final delivery should
retain only the readers actually needed by that proof.

- `TCSlib/Programs/Light/Syntax.lean`: `Light.Op.eval_add`, `Light.Op.eval_sub`, `Light.Op.eval_mul`, `Light.Expr.val_const`, `Light.Expr.val_var`, `Light.Expr.val_op`, `Light.Expr.val_load`, `Light.Expr.cost_const`, `Light.Expr.cost_var`, `Light.Expr.cost_op`, `Light.Expr.cost_load`, `Light.Limits.addr_iff`, `Light.Expr.safe_const_iff`, `Light.Expr.safe_var_iff`, `Light.Expr.safe_op_iff`, `Light.Expr.safe_load_iff`, `Light.Cond.holds_lt_iff`, `Light.Cond.cost_lt`, `Light.Cond.safe_lt_iff`, `Light.Cond.holds_eq_iff`, `Light.Cond.cost_eq`, `Light.Cond.safe_eq_iff`, `Light.frame_apply`.
- `TCSlib/Programs/Light/Rules.lean`: `Light.Stmt.after_skip`, `Light.Stmt.blockCost_skip`, `Light.Stmt.blockSafe_skip_iff`, `Light.Stmt.after_set`, `Light.Stmt.blockCost_set`, `Light.Stmt.blockSafe_set_iff`, `Light.Stmt.after_store`, `Light.Stmt.blockCost_store`, `Light.Stmt.blockSafe_store_iff`, `Light.Stmt.after_seq`, `Light.Stmt.blockCost_seq`, `Light.Stmt.blockSafe_seq_iff`, `Light.Stmt.after_ite`, `Light.Stmt.blockCost_ite`, `Light.Stmt.blockSafe_ite_iff`.
- `TCSlib/Programs/Light/Calls.lean`: `Light.meets_iff`.

Authorized added imports:

- `TCSlib.Programs.Light.Lib.Pass`: reuse of the verified zeroing pass for the expanding scratch ring.
- `TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction`: existing finite-function,
  finite-product, and optional-alphabet instances for enumerating transition rows.

External definitions are read through:

- `Light.Meets`: `meets_iff`, `Meets.of_body`, and the existing lookup/relocation rules.
- `Light.Ends`: `Ends.set`, `Ends.seq`, `Ends.skip`, `Ends.pass`, `Ends.mono`, and `Ends.shift_append`.
- `Light.Expr.val`, `Expr.Safe`, `Expr.cost`, `Op.eval`, `Cond.Holds`, `Cond.Safe`:
  the constructor readers listed above. The initialization proof explicitly cites `Expr.val_const`
  after both assignments rather than reducing expression evaluation.
- `Light.Stmt.after`, `Stmt.BlockSafe`: their constructor readers and `Stmt.Runs` rules.
  `Stmt.Runs` itself is an abbreviation. The new helpers never unfold another file's definitions.
- `Light.wrote`: `wrote_done`, `wrote_rest`, and the `Ends.pass` contract.
- `Light.Program.behind` / `Stmt.shift`: `Program.getElem?_behind_right`,
  `getElem?_append_of_eq_some`, and `Ends.shift_append`; no implementation is read.
- `Turing.MultiTapeTM.runFrom`: `runFrom_zero`, `runFrom_succ_eq_step'`,
  `workTapePos_runFrom_mem_Icc`, and `exists_first_halt`.
- `Turing.MultiTapeTM.initCfg`: `initCfg_eq`; `Turing.Cfg.init`:
  `init_state`, `init_workTapes`, and `init_workTapePos`.
- `Light.Limits.Addr`: `Limits.addr_iff`.
- `Turing.Cfg.inputSymbol`: `inputSymbol_of_zero`, `inputSymbol_of_end`, and `inputSymbolInner`.
- `Turing.MultiTapeTM.step`: `step_of_halt`, `step_of_some`; `Turing.Action.apply`:
  `apply_workTapes`.
- `Turing.FinTM.ComputesInTime`: `computesInTime_iff`.

The seal additionally closes every candidate external definition that the remaining program
proof may read, including `frame`, `Limits.Addr`, `Cond.cost`, `Stmt.blockCost`, `SameOn`, `Seg`,
`moveInputPos`, `Cfg.inputSymbol`, `Cfg.workTapeSymbols`, and `MultiTapeTM.outputSymbol`.
The checkpoint does not inspect these latter implementations in a proof.

## Reuse searches

The import closure was searched before the helpers: existing `copy_meets`, `fill_meets`,
`Ends.pass`, `Stmt.Runs.seq`, branch rules, `Ends.whileConst`, `Ends.shift_append`,
`exists_first_halt`, the head-envelope theorem, initialization field equations,
`Action.apply_workTapes`, and the list index-injectivity theorem were inspected.
The scratch clear cites `Ends.pass`; first-halt and relocation combine the existing APIs.
No existing Light TM interpreter was found in the searched source. The new static dispatch
and bank helpers implement the specifically authorized private simulator construction;
no hand-written Turing transition table or RecordTable admission is used.
The search log records candidate enumeration, not a claim of exhaustive semantic duplicate checking.

## Verification

All commands use `scripts/lean_check_tree.sh`, a private olean tree, and one of this fill's Lean
processes at a time. Final checkpoint exit codes:

| Check | Exit | Result |
|---|---:|---|
| Owned file | 0 | zero errors; only the original headline admission warning |
| 39 unsealed reader controls | 0 | each exact restatement closes by reflexivity |
| Sealed owned-file replay | 0 | 29 external definitions irreducible, their simp definitions removed |
| 39 sealed reader controls | 0 | reflexivity is rejected; the published reader succeeds |
| Axiom prints and dependency walks | 0 | 270 private theorem constants, including generated constants, use only standard axioms |
| Mathlib-root cache probe | 0 | cache is usable |
| Light facade | 0 | its 50-module closure bootstrapped serially; facade has zero errors |
| Target signature freeze | 0 | byte-identical against base |
| `git diff --check` | 0 | controlled source paths |

The axiom probe checks every private theorem constant in this module, including generated
equations and proof auxiliaries: no `sorryAx` and no nonstandard axiom is reachable from them.
The headline's print is `[propext, sorryAx, Classical.choice, Quot.sound]`, and its dependency
walk is exactly `[Light.exists_tmProc]`. There are no admitted external dependencies, and no
proved headline target is claimed. Full logs and the exact probes are packaged.

Owned-file-only diff stat:

```text
 TCSlib/Programs/Light/TMProc.lean | 1836 ++++++++++++++++++++++++++++++++++++-
 1 file changed, 1822 insertions(+), 14 deletions(-)
```

Whole controlled patch (reader-home exception included):

```text
 TCSlib/Programs/Light/Calls.lean  |    9 +
 TCSlib/Programs/Light/Rules.lean  |   62 ++
 TCSlib/Programs/Light/Syntax.lean |   94 ++
 TCSlib/Programs/Light/TMProc.lean | 1836 ++++++++++++++++++++++++++++++++++++-
 4 files changed, 1987 insertions(+), 14 deletions(-)
```

## Environment and waits

macOS/APFS, 12 logical CPUs, 19,327,352,832 bytes physical RAM (18 GiB). Initial memory-pressure
available percentage: 47%, approximately 8.46 GiB, above the 4 GiB floor. The worktree and scratch
filesystem had 116,680,932 KiB available (about 111.28 GiB), above the 12 GiB floor. Linux `/proc`,
cgroup counters, `df -B1`, and `time -v` do not apply here; `sysctl`, `vm_stat`, `memory_pressure`,
`df -k`, `mount`, and `/usr/bin/time -l` are recorded instead. The installed v4.25.0 toolchain is used.

The explicitly permitted dependency-tree symlink is
`/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`.
Every present package's URL and revision matches the manifest; absent documentation packages are
listed as ABSENT. Zero-byte dependency oleans: zero. No cache fetch, package build, project build,
or borrowed TCSlib olean tree was used. All TCSlib oleans were built into this fill's private tree.
The cache archive store was not fetched or modified.

The shared-pool log records 29 full-pool polls and 59.083 seconds in completed wait
segments at packaging time. Each module log includes UTC start/end, exit code, and maximum RSS.
The first base bootstrap did not use `nice -n 10`; subsequent checks do. Two premature checks were
attempted during setup: `Seg` before its newly imported `Util.Index` prerequisite, and a reader
probe after a failed owned-file elaboration had removed its olean. They were development/setup
errors, not findings; the complete prerequisites were then bootstrapped. The check driver now
refuses missing TCSlib prerequisites before starting Lean. Waiting wrappers are also serialized
with a per-fill lock, in addition to the machine-wide count check.

## Progress since checkpoint 2

There are now 54 explicit private theorem proofs, and the dynamic axiom probe checked all 270
private theorem constants including generated equations and auxiliaries. Every one uses only
standard axioms and has an empty direct-admission dependency walk. All 39 reader controls and
the 29-definition irreducibility seal passed at the source commit recorded above. No new reader-home
edits or imports were needed for this checkpoint.

The fixed-action theorem uses the published `Action.apply_state`, `apply_inputPos`,
`apply_workTapePos`, `apply_output`, and `apply_workTapes` equations. Input motion reads
`moveInputPos` through its zero, boundary, and interior equations. Output uses `Seg.snoc`,
`Seg.update_out`, and list map/append readers. Memory preservation uses `SameOn.cell`,
`SameOn.mono`, `SameOn.then`, `SameOutside.mono`, `SameOutside2.update`, and
`Seg.of_sameOutside`. Round simulation uses `MultiTapeTM.step_of_some`,
`runFrom_succ_eq_step'`, the initialized head envelope, and the already-proved lazy-ring lemma.
The arithmetic index-injectivity helper cites core `Nat.div_mod_unique`; the control-code bound
cites core `List.idxOf_le_length`. Primitive assignment and store rules are factored as
`tmSet_runs` and `tmStore_runs` and reused by the transition components.

The original headline statement is byte-identical to base, and still contains its one original
admission. The goal remains active and work continues with setup and the finite timed loop.

