/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Programs.Light.Renumber
import TCSlib.Programs.Light.Calls
import TCSlib.Programs.Light.Regions
import TCSlib.Programs.Light.Lib.Pass
import TCSlib.Complexity.TuringMachine.Finite
import TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Running a Turing machine inside a Light program

For every finite binary Turing machine `M` there is a Light procedure that runs `M` on a bit string
held in memory and writes `M`'s output to memory, within a time linear in `M`'s running time plus
the input length (`Light.exists_tmProc`). The procedure is part of a program `Q` that depends on
`M` only. Placed behind any program with `Program.behind` (`Light/Renumber`), and followed by any
procedures, it keeps its specification, so other programs can call it as a subroutine.

This is the reverse of stage 2 (`WordRAM.exists_simulation`, a word-RAM program run by a Turing
machine). It lets a program call any polynomial-time function given only by a machine, for
instance an abstract operation known to be `PolyTimeComputable`.

## Main results

* `Light.exists_tmProc`: the procedure and its specification.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (§1.2, §1.6: Turing machines and their simulation; Exercise
  1.9.)
* [AFM26] Anthropic, PBC, `anthropics/formal-math`, project `3sum-apsp`, commit `e1a4e650`,
  Apache-2.0: the language Light and its logic (`TCSlib/Programs/Light`).
-/

namespace Light

/-! ## Private encoding and placement lemmas -/

/-- A signed work-tape position has an even code on the nonnegative side and an odd code on
its negative side. This is the direct-address layout used for the work tapes. -/
private def tmCell (z : ℤ) : ℕ :=
  if z < 0 then 2 * (-z).toNat + 1 else 2 * z.toNat

/-- Distinct signed positions have distinct cell codes. -/
private theorem tmCell_injective : Function.Injective tmCell := by
  intro z w h
  unfold tmCell at h
  split_ifs at h <;> omega

/-- Positions within radius `n` use cell codes at most `2 * n + 1`. -/
private theorem tmCell_le {z : ℤ} {n : ℕ} (h : |z| ≤ (n : ℤ)) :
    tmCell z ≤ 2 * n + 1 := by
  rw [abs_le] at h
  unfold tmCell
  split_ifs <;> omega

/-- The first `2 * i` cell codes are exactly the signed positions of absolute value below `i`. -/
private theorem tmCell_lt_iff (z : ℤ) (i : ℕ) :
    tmCell z < 2 * i ↔ |z| < (i : ℤ) := by
  rw [abs_lt]
  unfold tmCell
  split_ifs <;> omega

/-- Tape `j` uses the corresponding residue class in an interleaved scratch array. -/
private def tmAddr (sc tapes : ℕ) (j : Fin tapes) (z : ℤ) : ℕ :=
  sc + tmCell z * tapes + j.val

/-- The interleaved address identifies both the tape and its signed position.

**Proof sketch.** If the cell codes differ, multiplying their strict order by the number of
tapes leaves a full tape-width gap, larger than either tape index. Thus the codes coincide;
`tmCell_injective` identifies the positions, and cancellation identifies the indices. -/
private theorem tmAddr_injective {sc tapes : ℕ} {j l : Fin tapes} {z w : ℤ}
    (h : tmAddr sc tapes j z = tmAddr sc tapes l w) : j = l ∧ z = w := by
  have hj := j.isLt
  have hl := l.isLt
  unfold tmAddr at h
  have hc : tmCell z = tmCell w := by
    by_contra hn
    rcases lt_or_gt_of_ne hn with hz | hw
    · have hm := Nat.mul_le_mul_right tapes (show tmCell z + 1 ≤ tmCell w by omega)
      rw [Nat.add_mul, Nat.one_mul] at hm
      omega
    · have hm := Nat.mul_le_mul_right tapes (show tmCell w + 1 ≤ tmCell z by omega)
      rw [Nat.add_mul, Nat.one_mul] at hm
      omega
  rw [hc] at h
  exact ⟨Fin.ext (by omega), tmCell_injective hc⟩

/-- A cell in radius `n` lies in the first `tapes * (2 * n + 2)` scratch cells. -/
private theorem tmAddr_lt {sc tapes n : ℕ} (j : Fin tapes) {z : ℤ}
    (hz : |z| ≤ (n : ℤ)) : tmAddr sc tapes j z < sc + tapes * (2 * n + 2) := by
  have hc := tmCell_le hz
  have hm := Nat.mul_le_mul_right tapes hc
  have hj := j.isLt
  unfold tmAddr
  nlinarith

/-- Before step `i`, every work head is within radius `i` of the origin. -/
private theorem tmHead_abs_le (M : Turing.FinTM Bool) (x : List Bool) (i : ℕ)
    (j : Fin M.k) :
    |(M.tm.runFrom (M.tm.initCfg x) i).workTapePos j| ≤ (i : ℤ) := by
  have h := M.tm.workTapePos_runFrom_mem_Icc (M.tm.initCfg x) i j
  rw [Turing.MultiTapeTM.initCfg_eq, Turing.Cfg.init_workTapePos] at h
  rw [Turing.MultiTapeTM.initCfg_eq, abs_le]
  simpa only [Finset.mem_Icc, zero_sub, zero_add] using h

/-- At time `i`, cells at distance at least `i` are still blank. A simulator may initialize
these cells as it expands its scratch region, without a time bound supplied to the program.

**Proof sketch.** Induct on `i`. The initial tapes are blank by `Cfg.init_workTapes`. A live
step writes only at its current head (`Action.apply_workTapes`), which has distance at most
`i` by `tmHead_abs_le`; a cell at distance at least `i + 1` is different. A halted step is
stationary (`MultiTapeTM.step_of_halt`). -/
private theorem tmTape_blank (M : Turing.FinTM Bool) (x : List Bool) (i : ℕ)
    (j : Fin M.k) (z : ℤ) (hz : (i : ℤ) ≤ |z|) :
    (M.tm.runFrom (M.tm.initCfg x) i).workTapes j z = none := by
  induction i with
  | zero =>
    rw [Turing.MultiTapeTM.runFrom_zero, Turing.MultiTapeTM.initCfg_eq,
      Turing.Cfg.init_workTapes]
  | succ i ih =>
    have hi : (i : ℤ) ≤ |z| := by omega
    have hb := tmHead_abs_le M x i j
    have hne : z ≠ (M.tm.runFrom (M.tm.initCfg x) i).workTapePos j := by
      intro he
      rw [he] at hz
      omega
    rw [Turing.MultiTapeTM.runFrom_succ_eq_step']
    cases hs : (M.tm.runFrom (M.tm.initCfg x) i).state with
    | none =>
      rw [Turing.MultiTapeTM.step_of_halt hs]
      exact ih hi
    | some q =>
      rw [Turing.MultiTapeTM.step_of_some hs, Turing.Action.apply_workTapes,
        Function.update_of_ne hne]
      exact ih hi

/-- A completed computation has a positive first halting time no greater than its deadline,
with the prescribed output and live states at every earlier time. -/
private theorem tmFirstHalt (M : Turing.FinTM Bool) {x out : List Bool} {t : ℕ}
    (h : M.ComputesInTime x out t) :
    ∃ u ≤ t, 0 < u ∧
      (M.tm.runFrom (M.tm.initCfg x) u).state = none ∧
      (M.tm.runFrom (M.tm.initCfg x) u).output = out ∧
      ∀ i < u, (M.tm.runFrom (M.tm.initCfg x) i).state ≠ none := by
  obtain ⟨hh, ho⟩ := (Turing.FinTM.computesInTime_iff M x out t).mp h
  obtain ⟨u, hu, hlive, he⟩ := M.tm.exists_first_halt (M.tm.initCfg x) hh
  have hhalt : (M.tm.runFrom (M.tm.initCfg x) u).state = none := by rw [he]; exact hh
  have hpos : 0 < u := by
    by_contra hn
    have hz : u = 0 := by omega
    rw [hz, Turing.MultiTapeTM.runFrom_zero, Turing.MultiTapeTM.initCfg_eq,
      Turing.Cfg.init_state] at hhalt
    cases hhalt
  exact ⟨u, hu, hpos, hhalt, by rw [he]; exact ho, hlive⟩

/-- Relocating a procedure and appending other procedures preserves its specification. -/
private theorem tmMeets_behind {lim : Limits} {Q : Program} {p d T : ℕ}
    {args : List ℤ} {μ : ℕ → ℤ} {R : ℤ → (ℕ → ℤ) → Prop}
    (h : Meets lim Q p d args μ T R) (Pre Post : Program) :
    Meets lim (Program.behind Pre Q ++ Post) (p + Pre.length) d args μ T R := by
  obtain ⟨body, hp, he⟩ := (meets_iff).mp h
  exact Meets.of_body (getElem?_append_of_eq_some (Program.getElem?_behind_right Pre hp) Post)
    (he.shift_append Pre Post)

/-! ## Private finite branch selection -/

/-- The listed locals have the listed natural values. -/
private def tmMatches (tests : List (ℕ × ℕ)) (σ : State) : Prop :=
  ∀ pair ∈ tests, σ.loc pair.1 = (pair.2 : ℤ)

/-- Test a fixed finite list of local values, choosing `yes` only when all agree. -/
private def tmSelect : List (ℕ × ℕ) → Stmt → Stmt → Stmt
  | [], yes, _ => yes
  | pair :: rest, yes, no =>
      .ite (.eq (.var pair.1) (.const pair.2)) (tmSelect rest yes no) no

/-- Finite branch selection preserves any common postcondition of its two alternatives.

**Proof sketch.** Induct on the tests. `Stmt.Runs.ite_pos` removes a matching head test,
and `Stmt.Runs.ite_neg` selects the failure alternative as soon as a local differs. The
constructor readers of `Expr` and `Cond` discharge the safe comparison and its value. -/
private theorem tmSelect_runs {lim : Limits} {σ : State} {tests : List (ℕ × ℕ)}
    {yes no : Stmt} {R : State → Prop}
    (hs : ∀ pair ∈ tests, (pair.2 : ℤ) ≤ lim.word)
    (hy : tmMatches tests σ → yes.Runs lim σ R)
    (hn : ¬tmMatches tests σ → no.Runs lim σ R) :
    (tmSelect tests yes no).Runs lim σ R := by
  induction tests with
  | nil => exact hy (by simp only [tmMatches, List.not_mem_nil, false_implies, implies_true])
  | cons pair rest ih =>
    have hsafe : (Cond.eq (.var pair.1) (.const pair.2)).Safe lim σ := by
      rw [Cond.safe_eq_iff, Expr.safe_var_iff, Expr.safe_const_iff]
      exact ⟨trivial, hs pair (List.mem_cons_self ..)⟩
    have hholds : (Cond.eq (.var pair.1) (.const pair.2)).Holds σ ↔
        σ.loc pair.1 = (pair.2 : ℤ) := by
      rw [Cond.holds_eq_iff, Expr.val_var, Expr.val_const]
    by_cases hp : σ.loc pair.1 = (pair.2 : ℤ)
    · apply Stmt.Runs.ite_pos (c := .eq (.var pair.1) (.const pair.2))
        (ih (fun p h => hs p (List.mem_cons_of_mem _ h)) ?_ ?_) (hholds.mpr hp) hsafe
      · intro hr
        apply hy
        intro p h
        rcases List.mem_cons.mp h with he | he
        · subst p; exact hp
        · exact hr p he
      · intro hr
        apply hn
        intro hall
        exact hr fun p h => hall p (List.mem_cons_of_mem _ h)
    · apply Stmt.Runs.ite_neg (c := .eq (.var pair.1) (.const pair.2))
        (hn ?_) (fun hh => hp (hholds.mp hh)) hsafe
      intro hall
      exact hp (hall pair (List.mem_cons_self ..))

/-- A finite table compiled as code branches, with no transition table stored in memory. -/
private def tmDispatch {α : Type} (tests : α → List (ℕ × ℕ)) (body : α → Stmt) : List α → Stmt
  | [] => .skip
  | row :: rest => tmSelect (tests row) (body row) (tmDispatch tests body rest)

/-- A compiled finite table executes the selected row whenever that row occurs in the table.

**Proof sketch.** Induct on the rows and use `tmSelect_runs` for the first row. A successful
test identifies that row with `actual`. A failed test excludes it, so the occurrence of
`actual` is in the tail, where the induction hypothesis applies. -/
private theorem tmDispatch_runs {α : Type} {lim : Limits} {σ : State}
    {tests : α → List (ℕ × ℕ)} {body : α → Stmt} {rows : List α} {actual : α}
    {R : State → Prop} (ha : actual ∈ rows)
    (hs : ∀ row ∈ rows, ∀ pair ∈ tests row, (pair.2 : ℤ) ≤ lim.word)
    (hm : ∀ row ∈ rows, tmMatches (tests row) σ ↔ row = actual)
    (hr : (body actual).Runs lim σ R) :
    (tmDispatch tests body rows).Runs lim σ R := by
  induction rows with
  | nil => exact False.elim (List.not_mem_nil ha)
  | cons row rest ih =>
    apply tmSelect_runs (hs row (List.mem_cons_self ..))
    · intro ht
      have he := (hm row (List.mem_cons_self ..)).mp ht
      subst row
      exact hr
    · intro hn
      have hat : actual ∈ rest := by
        rcases List.mem_cons.mp ha with he | he
        · exact False.elim (hn ((hm row (List.mem_cons_self ..)).mpr he.symm))
        · exact he
      exact ih hat (fun r hh => hs r (List.mem_cons_of_mem _ hh))
        (fun r hh => hm r (List.mem_cons_of_mem _ hh))

/-! ## Private simulator program -/

/-- Blank, false, and true have codes zero, one, and two. -/
private def tmSym : Option Bool → ℕ
  | none => 0
  | some false => 1
  | some true => 2

/-- The nonblank symbol code is the bit value plus one. -/
private theorem tmSym_some_eq (bit : Bool) : tmSym (some bit) = bit.toNat + 1 := by
  cases bit <;> rfl

/-- Zero the next pair of cell-code rows, leaving all previously initialized rows alone. -/
private def tmRingMemory (sc tapes i : ℕ) (μ : ℕ → ℤ) : ℕ → ℤ :=
  wrote μ (sc + 2 * i * tapes) (fun _ => 0) (2 * tapes)

/-- Initializing the next ring preserves every earlier represented cell. -/
private theorem tmRingMemory_old {sc tapes i : ℕ} (μ : ℕ → ℤ) (j : Fin tapes) (z : ℤ)
    (hz : tmCell z < 2 * i) :
    tmRingMemory sc tapes i μ (tmAddr sc tapes j z) = μ (tmAddr sc tapes j z) := by
  have hm := Nat.mul_le_mul_right tapes (show tmCell z + 1 ≤ 2 * i by omega)
  rw [Nat.add_mul, Nat.one_mul] at hm
  have hj := j.isLt
  apply wrote_rest
  left
  unfold tmAddr
  omega

/-- Every cell in the new pair of cell-code rows is initialized to blank. -/
private theorem tmRingMemory_new {sc tapes i : ℕ} (μ : ℕ → ℤ) (j : Fin tapes) (z : ℤ)
    (hlo : 2 * i ≤ tmCell z) (hhi : tmCell z < 2 * i + 2) :
    tmRingMemory sc tapes i μ (tmAddr sc tapes j z) = 0 := by
  have hj := j.isLt
  have hlow : sc + 2 * i * tapes ≤ tmAddr sc tapes j z := by
    unfold tmAddr
    nlinarith
  have hhigh : tmAddr sc tapes j z < sc + 2 * i * tapes + 2 * tapes := by
    unfold tmAddr
    nlinarith
  have hoff : tmAddr sc tapes j z - (sc + 2 * i * tapes) < 2 * tapes := by omega
  have he : sc + 2 * i * tapes + (tmAddr sc tapes j z - (sc + 2 * i * tapes)) =
      tmAddr sc tapes j z := Nat.add_sub_of_le hlow
  exact he ▸ (wrote_done (μ := μ) (f := fun _ => (0 : ℤ)) hoff)

/-- The three symbol codes distinguish blank and the two bits. -/
private theorem tmSym_injective : Function.Injective tmSym := by
  intro a b h
  cases a with
  | none => cases b with
    | none => rfl
    | some b => cases b <;> simp only [tmSym, Nat.reduceEqDiff] at h
  | some a => cases b with
    | none => cases a <;> simp only [tmSym, Nat.reduceEqDiff] at h
    | some b => cases a <;> cases b <;> simp_all only [tmSym, Nat.reduceEqDiff]

/-- Clearing the next ring extends a correct tape encoding from strict radius `i` to radius `i`. -/
private theorem tmRingMemory_tapes (M : Turing.FinTM Bool) (x : List Bool) (i sc : ℕ)
    (μ : ℕ → ℤ)
    (hμ : ∀ (j : Fin M.k) (z : ℤ), |z| < (i : ℤ) →
      μ (tmAddr sc M.k j z) = (tmSym ((M.tm.runFrom (M.tm.initCfg x) i).workTapes j z) : ℤ)) :
    ∀ (j : Fin M.k) (z : ℤ), |z| ≤ (i : ℤ) →
      tmRingMemory sc M.k i μ (tmAddr sc M.k j z) =
        (tmSym ((M.tm.runFrom (M.tm.initCfg x) i).workTapes j z) : ℤ) := by
  intro j z hz
  by_cases hc : tmCell z < 2 * i
  · rw [tmRingMemory_old μ j z hc]
    exact hμ j z ((tmCell_lt_iff z i).mp hc)
  · have hlarge : (i : ℤ) ≤ |z| := by
      have hn : ¬ |z| < (i : ℤ) := fun hh => hc ((tmCell_lt_iff z i).mpr hh)
      omega
    have hhi : tmCell z < 2 * i + 2 := by have := tmCell_le hz; omega
    rw [tmRingMemory_new μ j z (by omega) hhi, tmTape_blank M x i j z hlarge]
    rfl

/-- The live states have positive indices in a fixed enumeration; zero denotes halt. -/
private noncomputable def tmStateCode (M : Turing.FinTM Bool) : Option M.State → ℕ
  | none => 0
  | some q => 1 + (Finset.univ.toList : List M.State).idxOf q

/-- Distinct optional machine states have distinct control-state codes. -/
private theorem tmStateCode_injective (M : Turing.FinTM Bool) :
    Function.Injective (tmStateCode M) := by
  classical
  intro a b h
  cases a with
  | none => cases b with
    | none => rfl
    | some b => simp only [tmStateCode] at h; omega
  | some a => cases b with
    | none => simp only [tmStateCode] at h; omega
    | some b =>
      have ha : a ∈ (Finset.univ.toList : List M.State) :=
        Finset.mem_toList.mpr (Finset.mem_univ a)
      have hb : b ∈ (Finset.univ.toList : List M.State) :=
        Finset.mem_toList.mpr (Finset.mem_univ b)
      simp only [tmStateCode] at h
      exact congrArg some ((List.idxOf_inj ha hb).mp (by omega))

/-- A transition row specifies a live state and the input and work symbols it scans. -/
private abbrev TMRow (M : Turing.FinTM Bool) :=
  M.State × (Option Bool × (Fin M.k → Option Bool))

/-- All transition rows of a finite binary machine, enumerated once when generating the code. -/
private noncomputable def tmRows (M : Turing.FinTM Bool) : List (TMRow M) :=
  Finset.univ.toList

/-- Sequential composition of a fixed list of statements. -/
private def tmSeq : List Stmt → Stmt
  | [] => .skip
  | s :: rest => .seq s (tmSeq rest)

/-- A static bank preserves its invariant, establishes the property of every visited index,
and preserves that property at any index where it already held.

**Proof sketch.** Induct over the statically generated statement list and compose with
`Stmt.Runs.seq`. Each single block preserves the invariant and all previously established
index properties; the tail therefore preserves the head's property as well as its own. -/
private theorem tmSeq_accumulate {α : Type} {lim : Limits} {body : α → Stmt}
    {I : State → Prop} {F : α → State → Prop} {rows : List α} {σ : State}
    (hi : I σ)
    (hr : ∀ j ∈ rows, ∀ τ, I τ → (body j).Runs lim τ fun τ' =>
      I τ' ∧ F j τ' ∧ ∀ l, F l τ → F l τ') :
    (tmSeq (rows.map body)).Runs lim σ fun τ =>
      I τ ∧ (∀ j ∈ rows, F j τ) ∧ ∀ j, F j σ → F j τ := by
  induction rows generalizing σ with
  | nil =>
    constructor
    · exact (Stmt.blockSafe_skip_iff lim σ).mpr trivial
    · simp only [List.map_nil, tmSeq, Stmt.after_skip]
      exact ⟨hi, fun _ hh => False.elim (List.not_mem_nil hh), fun _ hh => hh⟩
  | cons j rest ih =>
    apply Stmt.Runs.seq
    apply (hr j (List.mem_cons_self ..) σ hi).mono
    intro τ hτ
    apply (ih hτ.1 (fun l hl => hr l (List.mem_cons_of_mem _ hl))).mono
    intro τ' hτ'
    refine ⟨hτ'.1, ?_, fun l hl => hτ'.2.2 l (hτ.2.2 l hl)⟩
    intro l hl
    rcases List.mem_cons.mp hl with he | he
    · subst l
      exact hτ'.2.2 j hτ.2.1
    · exact hτ'.2.1 l he

/-- One statically generated block per work tape. -/
private def tmBank (M : Turing.FinTM Bool) (body : Fin M.k → Stmt) : Stmt :=
  tmSeq ((List.finRange M.k).map body)

/-- Local numbers for work heads, scanned work symbols, and computed tape addresses. The first
ten locals hold the arguments, input position, control state, output length, and round number. -/
private def tmHead (j : ℕ) : ℕ := 10 + j
private def tmScan (tapes j : ℕ) : ℕ := 10 + tapes + j
private def tmAddress (tapes j : ℕ) : ℕ := 10 + 2 * tapes + j
private def tmOldHead (tapes j : ℕ) : ℕ := 10 + 3 * tapes + j

/-! ## Private representation invariant -/

/-- The stable locals describing one simulated configuration. The temporary locals for
addresses, frozen heads, scans, and scratch initialization are deliberately unconstrained. -/
private structure TMFrame (M : Turing.FinTM Bool) {x : List Bool}
    (c : Turing.Cfg M.k Bool M.State x) (a b sc i : ℕ) (σ : State) : Prop where
  src : σ.loc 0 = (a : ℤ)
  len : σ.loc 1 = (x.length : ℤ)
  dst : σ.loc 2 = (b : ℤ)
  scratch : σ.loc 3 = (sc : ℤ)
  inputPos : σ.loc 4 = (c.inputPos.val : ℤ)
  control : σ.loc 5 = (tmStateCode M c.state : ℤ)
  outputLen : σ.loc 6 = (c.output.length : ℤ)
  round : σ.loc 7 = (i : ℤ)
  heads : ∀ j : Fin M.k, σ.loc (tmHead j.val) = c.workTapePos j

/-- The locals constrained by `TMFrame`: the eight scalar locals and the current work heads. -/
private def tmKeyLocal (M : Turing.FinTM Bool) (v : ℕ) : Prop :=
  v < 8 ∨ ∃ j : Fin M.k, v = tmHead j.val

/-- Preserving the stable locals preserves the configuration frame, regardless of memory. -/
private theorem tmFrame_transfer {M : Turing.FinTM Bool} {x : List Bool}
    {c : Turing.Cfg M.k Bool M.State x} {a b sc i : ℕ} {σ τ : State}
    (hf : TMFrame M c a b sc i σ)
    (he : ∀ v, tmKeyLocal M v → τ.loc v = σ.loc v) : TMFrame M c a b sc i τ := by
  constructor
  · exact (he 0 (Or.inl (by decide))).trans hf.src
  · exact (he 1 (Or.inl (by decide))).trans hf.len
  · exact (he 2 (Or.inl (by decide))).trans hf.dst
  · exact (he 3 (Or.inl (by decide))).trans hf.scratch
  · exact (he 4 (Or.inl (by decide))).trans hf.inputPos
  · exact (he 5 (Or.inl (by decide))).trans hf.control
  · exact (he 6 (Or.inl (by decide))).trans hf.outputLen
  · exact (he 7 (Or.inl (by decide))).trans hf.round
  · intro j
    exact (he (tmHead j.val) (Or.inr ⟨j, rfl⟩)).trans (hf.heads j)

/-- The scratch address of the nonnegative cell code `code` on tape `j`. -/
private def tmAddrExpr (tapes j : ℕ) (code : Expr) : Expr :=
  .op .add (.var 3) (.op .add (.op .mul code (.const tapes)) (.const j))

/-- A natural cell-code expression gives the corresponding safe interleaved address whenever
its code, the two constants, and the resulting address fit the limits. -/
private theorem tmAddrExpr_read {lim : Limits} {σ : State} {tapes j sc n : ℕ}
    (code : Expr) (hsc : σ.loc 3 = (sc : ℤ)) (hc : code.Safe lim σ)
    (hv : code.val σ = (n : ℤ)) (hw : (lim.space : ℤ) ≤ lim.word)
    (hk : (tapes : ℤ) ≤ lim.word) (hj : (j : ℤ) ≤ lim.word)
    (hs : sc + n * tapes + j ≤ lim.space) :
    (tmAddrExpr tapes j code).Safe lim σ ∧
      (tmAddrExpr tapes j code).val σ = ((sc + n * tapes + j : ℕ) : ℤ) := by
  have hsZ : (sc : ℤ) + (n : ℤ) * tapes + j ≤ (lim.space : ℤ) := by exact_mod_cast hs
  have hp : 0 ≤ (n : ℤ) * tapes := by positivity
  constructor
  · simp only [tmAddrExpr, Expr.safe_op_iff, Expr.safe_var_iff, Expr.safe_const_iff,
      Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_add, Op.eval_mul,
      hsc, hv, hc, true_and, abs_le]
    omega
  · simp only [tmAddrExpr, Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_add,
      Op.eval_mul, hsc, hv, Nat.cast_add, Nat.cast_mul, add_assoc]

/-- Initialize the next two interleaved cell-code rows using the existing pass routine.
Locals eight and nine hold its destination and length; its counter is beyond the tape locals. -/
private def tmClearRing (M : Turing.FinTM Bool) : Stmt :=
  tmSeq [.set 8 (tmAddrExpr M.k 0 (.op .mul (.const 2) (.var 7))),
    .set 9 (.const (2 * M.k)), pass (10 + 4 * M.k) (.var 9) (.var 8) (.const 0)]

/-- Clearing one newly reachable ring costs `26 * M.k + 18` steps, leaves the represented
memory `tmRingMemory`, and changes only the pass's three temporary locals.

**Proof sketch.** Compute the ring destination and its constant length in locals eight and
nine. Apply `Ends.pass` with the constant-zero expression, using the published expression
readers for its safety and cost. `wrote` is exactly `tmRingMemory`; the pass changes only its
counter, and `Function.update_of_ne` preserves the other locals. -/
private theorem tmClearRing_ends (M : Turing.FinTM Bool) {lim : Limits} {P : Program} {d : ℕ}
    (σ : State) (sc i : ℕ) (hsc : σ.loc 3 = (sc : ℤ)) (hi : σ.loc 7 = (i : ℤ))
    (hw : (lim.space : ℤ) ≤ lim.word)
    (hs : sc + 2 * (i + 1) * M.k ≤ lim.space)
    (hi2 : (2 : ℤ) * ((i : ℤ) + 1) ≤ lim.word)
    (hk2 : (2 : ℤ) * M.k ≤ lim.word) :
    Ends lim P d (tmClearRing M) σ (26 * M.k + 18) fun τ =>
      τ.mem = tmRingMemory sc M.k i σ.mem ∧
      ∀ v, v ≠ 8 → v ≠ 9 → v ≠ 10 + 4 * M.k → τ.loc v = σ.loc v := by
  let dst := sc + 2 * i * M.k
  have hsZ : (sc : ℤ) + 2 * ((i : ℤ) + 1) * M.k ≤ (lim.space : ℤ) := by
    exact_mod_cast hs
  have hdst : dst + 2 * M.k ≤ lim.space := by dsimp only [dst]; nlinarith
  have hzero : (0 : ℤ) ≤ lim.word := by nlinarith [Int.natCast_nonneg M.k]
  have hc : (Expr.op .mul (.const 2) (.var 7)).Safe lim σ := by
    simp only [Expr.safe_op_iff, Expr.safe_const_iff, Expr.safe_var_iff, Expr.val_const,
      Expr.val_var, Op.eval_mul, hi, Nat.cast_ofNat, true_and, abs_le]
    omega
  have hvc : (Expr.op .mul (.const 2) (.var 7)).val σ = ((2 * i : ℕ) : ℤ) := by
    simp only [Expr.val_op, Expr.val_const, Expr.val_var, Op.eval_mul, hi,
      Nat.cast_mul, Nat.cast_ofNat]
  obtain ⟨hsafe, hv⟩ := tmAddrExpr_read (.op .mul (.const 2) (.var 7)) hsc hc hvc hw
    (show (M.k : ℤ) ≤ lim.word by omega) hzero
    (show sc + (2 * i) * M.k + 0 ≤ lim.space by dsimp only [dst] at hdst; omega)
  change (tmAddrExpr M.k 0 (.op .mul (.const 2) (.var 7))).val σ = (dst : ℤ) at hv
  unfold tmClearRing tmSeq
  refine Ends.seq 10 (26 * M.k + 8) (Ends.set hsafe ?_ ?_) (by omega)
  · simp only [tmAddrExpr, Expr.cost_op, Expr.cost_var, Expr.cost_const]
    omega
  · rw [hv]
    refine Ends.seq 2 (26 * M.k + 6) (Ends.set ?_ ?_ ?_) (by omega)
    · rw [Expr.safe_const_iff, Nat.cast_mul, Nat.cast_ofNat]
      exact hk2
    · rw [Expr.cost_const]
    · rw [Expr.val_const]
      refine Ends.seq (26 * M.k + 6) 0 ?_ (by omega)
      refine Ends.pass (c := 10 + 4 * M.k) (x := 9) (y := 8) (n := 2 * M.k)
        (dst := dst) (fun _ => (0 : ℤ)) ?_ ?_ hw hdst ?_ ?_
        (by omega) (by omega) ?_
      · intro j hj
        exact ⟨(Expr.safe_const_iff _ _ 0).mpr hzero, Expr.val_const _ 0⟩
      · apply Ends.skip
        refine ⟨rfl, ?_⟩
        intro v h8 h9 hc
        simp only [Function.update_of_ne hc, Function.update_of_ne h9,
          Function.update_of_ne h8]
      · change Function.update (Function.update σ.loc 8 (dst : ℤ)) 9 ((2 * M.k : ℕ) : ℤ) 9 =
          ((2 * M.k : ℕ) : ℤ)
        exact Function.update_self ..
      · change Function.update (Function.update σ.loc 8 (dst : ℤ)) 9 ((2 * M.k : ℕ) : ℤ) 8 =
          (dst : ℤ)
        rw [Function.update_of_ne (by decide : (8 : ℕ) ≠ 9)]
        exact Function.update_self ..
      · rw [Expr.cost_const]
        omega

/-- The two arithmetic branches computing a signed tape position's cell code. -/
private def tmCodeExpr (src : ℕ) : Bool → Expr
  | false => .op .mul (.const 2) (.var src)
  | true => .op .add (.op .mul (.const 2) (.op .sub (.const 0) (.var src))) (.const 1)

/-- The selected sign branch safely computes the signed cell code using only linear
arithmetic in the head position.

**Proof sketch.** Split on the sign branch and read each arithmetic constructor through its
published equations. `tmCell` has the same two branches; the sign hypothesis identifies
`Int.toNat` with the corresponding nonnegative position. The code bound controls every
intermediate value, and the separate bound on two controls the constants. -/
private theorem tmCodeExpr_read {lim : Limits} {σ : State} {src : ℕ} {z : ℤ}
    (negative : Bool) (hz : σ.loc src = z) (h2 : (2 : ℤ) ≤ lim.word)
    (hc : (tmCell z : ℤ) ≤ lim.word) (hside : if negative then z < 0 else 0 ≤ z) :
    (tmCodeExpr src negative).Safe lim σ ∧
      (tmCodeExpr src negative).val σ = (tmCell z : ℤ) := by
  cases negative with
  | false =>
    change 0 ≤ z at hside
    have hn : ¬z < 0 := by omega
    simp only [tmCodeExpr, Expr.safe_op_iff, Expr.safe_var_iff, Expr.safe_const_iff,
      Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_mul, hz, tmCell, if_neg hn,
      Nat.cast_mul, Nat.cast_ofNat, true_and, abs_le] at hc ⊢
    omega
  | true =>
    change z < 0 at hside
    simp only [tmCodeExpr, Expr.safe_op_iff, Expr.safe_var_iff, Expr.safe_const_iff,
      Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_add, Op.eval_mul, Op.eval_sub,
      hz, tmCell, if_pos hside, Nat.cast_add, Nat.cast_mul, Nat.cast_ofNat,
      Nat.cast_zero, Nat.cast_one, true_and, abs_le] at hc ⊢
    omega

/-- Compute a head's direct scratch address by branching on its sign. -/
private def tmLocate (M : Turing.FinTM Bool) (j : Fin M.k) : Stmt :=
  .seq (.set (tmOldHead M.k j.val) (.var (tmHead j.val)))
    (.ite (.lt (.var (tmHead j.val)) (.const 0))
      (.set (tmAddress M.k j.val) (tmAddrExpr M.k j.val (tmCodeExpr (tmHead j.val) true)))
      (.set (tmAddress M.k j.val) (tmAddrExpr M.k j.val (tmCodeExpr (tmHead j.val) false))))

/-- Locating one tape freezes its head and records its direct scratch address, changing no
memory and no other locals.

**Proof sketch.** The first assignment freezes the work head. Its temporary local is distinct
from both the current head and scratch base. The guard therefore reads the original sign.
In either branch, `tmCodeExpr_read` computes the signed cell code and `tmAddrExpr_read`
computes the interleaved address; the two assignments give the displayed exact state. -/
private theorem tmLocate_runs (M : Turing.FinTM Bool) {lim : Limits} (σ : State)
    (j : Fin M.k) (sc : ℕ) (z : ℤ) (hsc : σ.loc 3 = (sc : ℤ))
    (hz : σ.loc (tmHead j.val) = z) (hw : (lim.space : ℤ) ≤ lim.word)
    (h2 : (2 : ℤ) ≤ lim.word) (hc : (tmCell z : ℤ) ≤ lim.word)
    (hk : (M.k : ℤ) ≤ lim.word) (hj : (j.val : ℤ) ≤ lim.word)
    (ha : sc + tmCell z * M.k + j.val ≤ lim.space) :
    (tmLocate M j).Runs lim σ fun τ =>
      τ = { σ with loc := Function.update (Function.update σ.loc (tmOldHead M.k j.val) z) (tmAddress M.k j.val) (tmAddr sc M.k j z : ℤ) } := by
  unfold tmLocate
  apply Stmt.Runs.seq
  refine ⟨(Stmt.blockSafe_set_iff _ _ _ _).mpr ((Expr.safe_var_iff _ _ _).mpr trivial), ?_⟩
  rw [Stmt.after_set, Expr.val_var, hz]
  let σ₁ : State := { σ with loc := Function.update σ.loc (tmOldHead M.k j.val) z }
  have hs₁ : σ₁.loc 3 = (sc : ℤ) := by
    change Function.update σ.loc (tmOldHead M.k j.val) z 3 = (sc : ℤ)
    rw [Function.update_of_ne (by unfold tmOldHead; omega)]
    exact hsc
  have hz₁ : σ₁.loc (tmHead j.val) = z := by
    change Function.update σ.loc (tmOldHead M.k j.val) z (tmHead j.val) = z
    rw [Function.update_of_ne (by have := j.isLt; unfold tmHead tmOldHead; omega)]
    exact hz
  have hbranch (negative : Bool) (hside : if negative then z < 0 else 0 ≤ z) :
      (Stmt.set (tmAddress M.k j.val)
        (tmAddrExpr M.k j.val (tmCodeExpr (tmHead j.val) negative))).Runs lim σ₁ fun τ =>
          τ = { σ with loc := Function.update (Function.update σ.loc (tmOldHead M.k j.val) z) (tmAddress M.k j.val) (tmAddr sc M.k j z : ℤ) } := by
    obtain ⟨hcode, hval⟩ := tmCodeExpr_read negative hz₁ h2 hc hside
    obtain ⟨haddr, hvaladdr⟩ := tmAddrExpr_read _ hs₁ hcode hval hw hk hj ha
    refine ⟨(Stmt.blockSafe_set_iff _ _ _ _).mpr haddr, ?_⟩
    simp only [Stmt.after_set, hvaladdr, σ₁, tmAddr]
  have hguard : (Cond.lt (.var (tmHead j.val)) (.const 0)).Holds σ₁ ↔ z < 0 := by
    rw [Cond.holds_lt_iff, Expr.val_var, Expr.val_const, hz₁, Nat.cast_zero]
  have hsafe : (Cond.lt (.var (tmHead j.val)) (.const 0)).Safe lim σ₁ := by
    rw [Cond.safe_lt_iff, Expr.safe_var_iff, Expr.safe_const_iff]
    exact ⟨trivial, by omega⟩
  by_cases hn : z < 0
  · exact Stmt.Runs.ite_pos (hbranch true hn) (hguard.mpr hn) hsafe
  · have hznonneg : 0 ≤ z := le_of_not_gt hn
    exact Stmt.Runs.ite_neg (hbranch false hznonneg) (fun hh => hn (hguard.mp hh)) hsafe

/-- Read the input in place, encoding either end marker as blank. -/
private def tmReadInput : Stmt :=
  .ite (.eq (.var 4) (.const 0)) (.set 9 (.const 0))
    (.ite (.eq (.var 4) (.op .add (.var 1) (.const 1))) (.set 9 (.const 0))
      (.set 9 (.op .add
        (.load (.op .add (.var 0) (.op .sub (.var 4) (.const 1)))) (.const 1))))

/-- Reading the input changes only the scanned-input local, and returns the machine's actual
input symbol under the blank/bit encoding.

**Proof sketch.** The two end-marker branches use `Cfg.inputSymbol_of_zero` and
`Cfg.inputSymbol_of_end`. In the interior, `inputSymbolInner` identifies the bit at the
one-shifted head position. Its memory cell is inside the input region; loading its bit value
and adding one gives `tmSym_some_eq`. The word bounds control the address subtraction, address
addition, and final symbol code. -/
private theorem tmReadInput_runs (M : Turing.FinTM Bool) {x : List Bool}
    (c : Turing.Cfg M.k Bool M.State x) {lim : Limits} (σ : State) (a : ℕ)
    (hsrc : σ.loc 0 = (a : ℤ)) (hlen : σ.loc 1 = (x.length : ℤ))
    (hpos : σ.loc 4 = (c.inputPos.val : ℤ))
    (hread : ∀ u < x.length, σ.mem (a + u) = ((x.getD u false).toNat : ℤ))
    (hw : (lim.space : ℤ) ≤ lim.word) (hin : a + x.length ≤ lim.space)
    (h2 : (2 : ℤ) ≤ lim.word) (hL : (x.length : ℤ) + 1 ≤ lim.word) :
    tmReadInput.Runs lim σ fun τ =>
      τ = { σ with loc := Function.update σ.loc 9 (tmSym c.inputSymbol : ℤ) } := by
  have hblank : (Stmt.set 9 (.const 0)).Runs lim σ fun τ =>
      τ = { σ with loc := Function.update σ.loc 9 (0 : ℤ) } := by
    constructor
    · rw [Stmt.blockSafe_set_iff, Expr.safe_const_iff]
      omega
    · rw [Stmt.after_set, Expr.val_const, Nat.cast_zero]
  have hg0 : (Cond.eq (.var 4) (.const 0)).Holds σ ↔ c.inputPos = 0 := by
    rw [Cond.holds_eq_iff, Expr.val_var, Expr.val_const, hpos, Nat.cast_zero]
    constructor
    · intro he
      exact Fin.val_eq_zero_iff.mp (by exact_mod_cast he)
    · intro he
      have hv := Fin.val_eq_zero_iff.mpr he
      exact_mod_cast hv
  have hs0 : (Cond.eq (.var 4) (.const 0)).Safe lim σ := by
    rw [Cond.safe_eq_iff, Expr.safe_var_iff, Expr.safe_const_iff]
    exact ⟨trivial, by omega⟩
  have hgend : (Cond.eq (.var 4) (.op .add (.var 1) (.const 1))).Holds σ ↔
      c.inputPos.val = x.length + 1 := by
    rw [Cond.holds_eq_iff, Expr.val_var, Expr.val_op, Op.eval_add,
      Expr.val_var, Expr.val_const, hpos, hlen, Nat.cast_one]
    constructor <;> intro he <;> exact_mod_cast he
  have hsend : (Cond.eq (.var 4) (.op .add (.var 1) (.const 1))).Safe lim σ := by
    simp only [Cond.safe_eq_iff, Expr.safe_var_iff, Expr.safe_op_iff, Expr.safe_const_iff,
      Expr.val_var, Expr.val_const, Op.eval_add, hlen, Nat.cast_one, true_and, abs_le]
    omega
  unfold tmReadInput
  by_cases hleft : c.inputPos = 0
  · apply Stmt.Runs.ite_pos ?_ (hg0.mpr hleft) hs0
    simpa only [Turing.Cfg.inputSymbol_of_zero hleft, tmSym, Nat.cast_zero] using hblank
  · apply Stmt.Runs.ite_neg ?_ (fun hh => hleft (hg0.mp hh)) hs0
    by_cases hend : c.inputPos.val = x.length + 1
    · apply Stmt.Runs.ite_pos ?_ (hgend.mpr hend) hsend
      simpa only [Turing.Cfg.inputSymbol_of_end hend, tmSym, Nat.cast_zero] using hblank
    · apply Stmt.Runs.ite_neg ?_ (fun hh => hend (hgend.mp hh)) hsend
      let u := c.inputPos.val - 1
      have hp0 : c.inputPos.val ≠ 0 := by
        intro he
        exact hleft (Fin.ext he)
      have hu : u < x.length := by
        have := c.inputPos.isLt
        dsimp only [u]
        omega
      have hpu : c.inputPos.val = 1 + u := by dsimp only [u]; omega
      have hsym : c.inputSymbol = some (x.getD u false) := by
        rw [Turing.inputSymbolInner u hpu hu, List.getD_eq_getElem _ _ hu]
      let ea : Expr := .op .add (.var 0) (.op .sub (.var 4) (.const 1))
      have hpuZ : (c.inputPos.val : ℤ) = 1 + (u : ℤ) := by exact_mod_cast hpu
      have haddrlt : a + u < lim.space := by omega
      have haddrZ : (a : ℤ) + (u : ℤ) < (lim.space : ℤ) := by exact_mod_cast haddrlt
      have hvaladdr : ea.val σ = ((a + u : ℕ) : ℤ) := by
        simp only [ea, Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_add,
          Op.eval_sub, hsrc, hpos, Nat.cast_one, Nat.cast_add]
        omega
      have hsafeaddr : ea.Safe lim σ := by
        simp only [ea, Expr.safe_op_iff, Expr.safe_var_iff, Expr.safe_const_iff,
          Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_add, Op.eval_sub,
          hsrc, hpos, Nat.cast_one, true_and, abs_le]
        omega
      have hloadval : (Expr.load ea).val σ = ((x.getD u false).toNat : ℤ) := by
        rw [Expr.val_load, hvaladdr, Int.toNat_natCast, hread u hu]
      have hloadsafe : (Expr.load ea).Safe lim σ := by
        rw [Expr.safe_load_iff, hvaladdr, Limits.addr_iff]
        exact ⟨hsafeaddr, Int.natCast_nonneg _, by exact_mod_cast haddrlt⟩
      let e : Expr := .op .add (.load ea) (.const 1)
      have hv : e.val σ = (tmSym c.inputSymbol : ℤ) := by
        simp only [e, Expr.val_op, Op.eval_add, hloadval, Expr.val_const, Nat.cast_one,
          hsym, tmSym_some_eq, Nat.cast_add]
      have hsafe : e.Safe lim σ := by
        simp only [e, Expr.safe_op_iff, hloadsafe, Expr.safe_const_iff, hloadval,
          Expr.val_const, Op.eval_add, Nat.cast_one, true_and, abs_le]
        have hbit := Bool.toNat_le (x.getD u false)
        omega
      refine ⟨(Stmt.blockSafe_set_iff lim σ 9 e).mpr hsafe, ?_⟩
      rw [Stmt.after_set]
      change { σ with loc := Function.update σ.loc 9 (e.val σ) } = _
      rw [hv]

/-- A fixed transition displacement applied to a frozen work-head local. -/
private def tmDisplace (src : ℕ) : SignType → Expr
  | .neg => .op .sub (.var src) (.const 1)
  | .zero => .var src
  | .pos => .op .add (.var src) (.const 1)

/-- A displacement expression is safe under its unit and result bounds and returns the
signed head position plus the transition displacement. -/
private theorem tmDisplace_read {lim : Limits} {σ : State} {src : ℕ} {z : ℤ} (m : SignType)
    (hz : σ.loc src = z) (h1 : (1 : ℤ) ≤ lim.word)
    (hm : |z + (m.cast : ℤ)| ≤ lim.word) :
    (tmDisplace src m).Safe lim σ ∧ (tmDisplace src m).val σ = z + (m.cast : ℤ) := by
  cases m <;>
    simp only [tmDisplace, Expr.safe_op_iff, Expr.safe_var_iff, Expr.safe_const_iff,
      Expr.val_op, Expr.val_var, Expr.val_const, Op.eval_sub, Op.eval_add, hz,
      Nat.cast_one, SignType.neg_eq_neg_one, SignType.zero_eq_zero, SignType.pos_eq_one,
      SignType.coe_neg_one, SignType.coe_zero, SignType.coe_one, sub_eq_add_neg,
      add_zero, eq_self, true_and, and_true] at hm ⊢
  all_goals exact ⟨h1, hm⟩

/-- Move a work head from its frozen position. The frozen locals make all tape updates
independent, so the static bank implements simultaneous work-tape actions. -/
private def tmMoveWork (dst src : ℕ) (m : SignType) : Stmt :=
  .set dst (tmDisplace src m)

/-- A work-head update changes only its destination local and returns the prescribed signed
position; its expression safety is `tmDisplace_read`. -/
private theorem tmMoveWork_runs {lim : Limits} {σ : State} {dst src : ℕ} {z : ℤ}
    (m : SignType) (hz : σ.loc src = z) (h1 : (1 : ℤ) ≤ lim.word)
    (hm : |z + (m.cast : ℤ)| ≤ lim.word) :
    (tmMoveWork dst src m).Runs lim σ fun τ =>
      τ = { σ with loc := Function.update σ.loc dst (z + (m.cast : ℤ)) } := by
  obtain ⟨hs, hv⟩ := tmDisplace_read m hz h1 hm
  refine ⟨(Stmt.blockSafe_set_iff lim σ dst (tmDisplace src m)).mpr hs, ?_⟩
  simp only [tmMoveWork, Stmt.after_set, hv]

/-- Move the input head, clamping outward moves at the two end markers. -/
private def tmMoveInput : SignType → Stmt
  | .neg => .ite (.eq (.var 4) (.const 0)) .skip
      (.set 4 (.op .sub (.var 4) (.const 1)))
  | .zero => .skip
  | .pos => .ite (.lt (.var 4) (.op .add (.var 1) (.const 1)))
      (.set 4 (.op .add (.var 4) (.const 1))) .skip

/-- One tape's transition writes the chosen symbol, or writes back the scanned symbol when
there is no write, then moves the head. -/
private def tmWriteMove (M : Turing.FinTM Bool) (action : Turing.Action M.k Bool M.State)
    (j : Fin M.k) : Stmt :=
  .seq (.store (.var (tmAddress M.k j.val))
    (match (action.workTapes j).1 with
      | none => .var (tmScan M.k j.val)
      | some sym => .const (tmSym sym)))
    (tmMoveWork (tmHead j.val) (tmOldHead M.k j.val) (action.workTapes j).2)

/-- Append the optional output bit and advance the output length. -/
private def tmEmit : Option Bool → Stmt
  | none => .skip
  | some bit => .seq (.store (.op .add (.var 2) (.var 6)) (.const bit.toNat))
      (.set 6 (.op .add (.var 6) (.const 1)))

/-- The block implementing one fixed row of the machine's transition function. -/
private noncomputable def tmRowBody (M : Turing.FinTM Bool) (row : TMRow M) : Stmt :=
  let action := M.tm.tr row.1 row.2.1 row.2.2
  tmSeq [tmBank M (tmWriteMove M action), tmMoveInput action.inputTape,
    tmEmit action.output, .set 5 (.const (tmStateCode M action.state))]

/-- The local-value tests identifying a transition row. -/
private noncomputable def tmRowTests (M : Turing.FinTM Bool) (row : TMRow M) : List (ℕ × ℕ) :=
  (5, tmStateCode M (some row.1)) :: (9, tmSym row.2.1) ::
    (List.finRange M.k).map (fun j => (tmScan M.k j.val, tmSym (row.2.2 j)))

/-- Reading a row's tests gives exactly its control state and scanned symbols. -/
private theorem tmRowTests_matches_iff (M : Turing.FinTM Bool) (row : TMRow M) (σ : State) :
    tmMatches (tmRowTests M row) σ ↔
      σ.loc 5 = (tmStateCode M (some row.1) : ℤ) ∧
      σ.loc 9 = (tmSym row.2.1 : ℤ) ∧
      ∀ j : Fin M.k, σ.loc (tmScan M.k j.val) = (tmSym (row.2.2 j) : ℤ) := by
  simp only [tmMatches, tmRowTests, List.forall_mem_cons, List.forall_mem_map,
    List.mem_finRange, forall_true_left]

/-- If the scanned locals encode `actual`, a row's tests succeed exactly for that row. -/
private theorem tmRowTests_unique (M : Turing.FinTM Bool) (actual row : TMRow M) (σ : State)
    (ha : tmMatches (tmRowTests M actual) σ) :
    tmMatches (tmRowTests M row) σ ↔ row = actual := by
  constructor
  · intro hr
    obtain ⟨haq, hai, haw⟩ := (tmRowTests_matches_iff M actual σ).mp ha
    obtain ⟨hrq, hri, hrw⟩ := (tmRowTests_matches_iff M row σ).mp hr
    have hq : some row.1 = some actual.1 :=
      tmStateCode_injective M (by exact_mod_cast hrq.symm.trans haq)
    have hi : row.2.1 = actual.2.1 :=
      tmSym_injective (by exact_mod_cast hri.symm.trans hai)
    have hw : row.2.2 = actual.2.2 := by
      funext j
      exact tmSym_injective (by exact_mod_cast (hrw j).symm.trans (haw j))
    exact Prod.ext (Option.some.inj hq) (Prod.ext hi hw)
  · intro he
    subst row
    exact ha

/-- One simulator round initializes its newly reachable cells, reads the scanned symbols,
executes the finite branch table, and advances the round counter. -/
private noncomputable def tmRound (M : Turing.FinTM Bool) : Stmt :=
  tmSeq [tmClearRing M, tmBank M (tmLocate M), tmReadInput,
    tmBank M (fun j => .set (tmScan M.k j.val) (.load (.var (tmAddress M.k j.val)))),
    tmDispatch (tmRowTests M) (tmRowBody M) (tmRows M),
    .set 7 (.op .add (.var 7) (.const 1))]

/-- The generated simulator has one procedure and no calls. The loop observes the encoded
halting state, and local zero receives the final output length only after the loop. -/
private noncomputable def tmBody (M : Turing.FinTM Bool) : Stmt :=
  tmSeq [.set 4 (.const 1), .set 5 (.const (tmStateCode M (some M.tm.q₀))),
    .set 6 (.const 0), .set 7 (.const 0), tmBank M (fun j => .set (tmHead j.val) (.const 0)),
    .while (.lt (.const 0) (.var 5)) (tmRound M), .set 0 (.var 6)]

/-- **A Turing machine as a Light procedure.** For every finite binary machine `M` there are a
program `Q`, a procedure number `p` in it, and constants `A` and `k` such that, wherever `Q` is
placed (behind any program `Pre`, followed by any procedures `Post`), procedure `p + |Pre|`, called
with the arguments `[a, len, b, sc]`, does the following. If the memory holds the input `x` at
`a`, one cell per bit (`0` or `1`), and `M` computes `out` from `x` within `t` steps, then within
`A·(t + len + 1)` steps it returns `|out|`, holds `out` at `b`, one cell per bit, and changes no
cell outside the output's cells and the scratch region of `A·(t + len + 1)` cells at `sc`. The
hypotheses: the regions fit in memory and are pairwise apart; addresses fit in a word; and the
procedure's call depth `k` fits.

`Q`, `p`, `A` and `k` depend on `M` only, so a uniform machine gives a uniform procedure, and a
program calling it stays one program for all inputs.

**Proof sketch.**
- **Encoding.** `tmStateCode` assigns zero to halt and positive indices from a fixed finite
  enumeration to live states. `tmSym` assigns zero, one, and two to blank, false, and true.
  `tmCell` and `tmAddr` interleave the signed cells of the work tapes in scratch memory;
  `tmAddr_injective` separates the cells and `tmAddr_lt` bounds the memory needed at a radius.
  `TMFrame` records the stable locals.
- **One step.** `tmRound` first clears its next ring with the existing `pass` routine.
  `tmClearRing_ends` bounds that initialization and `tmRingMemory_tapes` extends the valid tape
  representation. `tmLocate_runs` freezes each old head and computes its direct address;
  `tmReadInput_runs` reads the input in place. The finite code branches generated by
  `tmDispatch` choose exactly the row identified by `tmRowTests_unique`. The row writes each
  tape, moves the heads, appends the optional output bit, and updates the control state.
- **The run.** Couple the rounds to `M.tm.runFrom (M.tm.initCfg x) i`: the work-cell memory,
  stable locals, and output prefix encode the configuration after `i` steps. Prove the round
  preserves that invariant and the unchanged-memory promise. `tmFirstHalt` supplies the first
  halting time at most `t`; `Ends.whileConst` then bounds the loop. Its step cost and all
  finite constants depend on `M` only, so one `A` bounds time, scratch, and intermediate words.
- **Placement.** Build the procedure specification for its singleton program and use
  `tmMeets_behind` to carry it to `Program.behind Pre Q ++ Post`. -/
theorem exists_tmProc (M : Turing.FinTM Bool) :
    ∃ (Q : Program) (p A k : ℕ), ∀ (Pre Post : Program) (lim : Limits) (d : ℕ)
      (a len b sc : ℕ) (μ : ℕ → ℤ) (x out : List Bool) (t : ℕ),
      x.length = len →
      (∀ i < len, μ (a + i) = ((x.getD i false).toNat : ℤ)) →
      M.ComputesInTime x out t →
      (lim.space : ℤ) ≤ lim.word →
      a + len ≤ lim.space → b + out.length ≤ lim.space → sc + A * (t + len + 1) ≤ lim.space →
      Apart a len b out.length → Apart a len sc (A * (t + len + 1)) →
      Apart b out.length sc (A * (t + len + 1)) →
      d + k ≤ lim.depth →
      Meets lim (Program.behind Pre Q ++ Post) (p + Pre.length) d [(a : ℤ), len, b, sc] μ
        (A * (t + len + 1)) fun r μ' =>
          r = out.length ∧ (∀ i < out.length, μ' (b + i) = ((out.getD i false).toNat : ℤ)) ∧
          SameOutside2 μ μ' b out.length sc (A * (t + len + 1)) := by
  sorry

end Light
