"""Run module checks serially, respecting the machine-wide three-Lean ceiling."""
from pathlib import Path
import os, subprocess, time, datetime, sys, json, fcntl, re
ROOT=Path(__file__).resolve().parents[2]
os.chdir(ROOT)
LOG=ROOT/'evidence/logs'
SERIAL=(LOG/'own-check.lock').open('w')
fcntl.flock(SERIAL,fcntl.LOCK_EX)
env=os.environ.copy()
env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH']
env['TCSLIB_OLEANS']=str(ROOT/'.lake/fill-ram-tmproc-oleans')
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def active():
 out=subprocess.check_output(['ps','-axo','pid=,args='],text=True)
 return [(int(s[0]),s[1]) for line in out.splitlines() if (s:=line.split(maxsplit=2)) and len(s)>1 and Path(s[1]).name=='lean']
def wait_slot():
 waited=False
 while True:
  procs=active()
  with (LOG/'lean-slots.log').open('a') as f:f.write(f'{stamp()} active={len(procs)} pids={[p[0] for p in procs]}'+(' WAIT' if len(procs)>=3 else ' START_ALLOWED')+'\n')
  if len(procs)<3:return
  time.sleep(2)
mods=sys.argv[1:]
if mods[:1]==['--list']:mods=Path(mods[1]).read_text().splitlines()
for mod in mods:
 if not mod.strip():continue
 deps=re.findall(r'^import\s+(TCSlib[\w.]+)',Path(mod+'.lean').read_text(),re.M)
 missing=[m for m in deps if not (Path(env['TCSLIB_OLEANS'])/(m.replace('.','/')+'.olean')).exists()]
 if missing:
  print('PREREQUISITES_MISSING: '+', '.join(missing),flush=True)
  raise SystemExit(2)
 wait_slot()
 name=mod.replace('/','_')
 start=stamp()
 with (LOG/(name+'.log')).open('w') as f:
  f.write(f'START {start}\nMODULE {mod}\n');f.flush()
  p=subprocess.run(['/usr/bin/time','-l','nice','-n','10','bash','scripts/lean_check_tree.sh',mod],env=env,stdout=f,stderr=subprocess.STDOUT)
  f.write(f'END {stamp()}\nEXIT {p.returncode}\n')
 print(f'{mod}: exit {p.returncode}',flush=True)
 if p.returncode:
  print((LOG/(name+'.log')).read_text()[-12000:],flush=True)
  raise SystemExit(p.returncode)
