from pathlib import Path
import re
source=Path('TCSlib/Programs/Light/TMProc.lean').read_text()
defs='''Light.Op.eval Light.Expr.val Light.Expr.cost Light.Expr.Safe Light.Cond.Holds Light.Cond.cost Light.Cond.Safe Light.Limits.Addr Light.frame Light.Meets Light.Ends Light.Stmt.after Light.Stmt.blockCost Light.Stmt.BlockSafe Light.wrote Light.SameOn Light.Program.behind Light.Stmt.shift Light.Seg Turing.moveInputPos Turing.Cfg.inputSymbol Turing.Cfg.workTapeSymbols Turing.Cfg.init Turing.Action.apply Turing.MultiTapeTM.step Turing.MultiTapeTM.outputSymbol Turing.MultiTapeTM.initCfg Turing.MultiTapeTM.runFrom Turing.FinTM.ComputesInTime'''.split()
simps='''Light.Op.eval Light.Expr.val Light.Expr.cost Light.Expr.Safe Light.Cond.Holds Light.Cond.cost Light.Cond.Safe Light.frame Light.Stmt.after Light.Stmt.blockCost Light.Stmt.BlockSafe Turing.Cfg.init Turing.Action.apply Turing.MultiTapeTM.initCfg'''.split()
controls=[];unsealed=[]
for rel,marker in [('TCSlib/Programs/Light/Syntax.lean','/-! ## Equations for reading expressions and tests -/'),('TCSlib/Programs/Light/Rules.lean','/-! ## Equations for reading blocks -/'),('TCSlib/Programs/Light/Calls.lean','theorem meets_iff')]:
 s=Path(rel).read_text();s=s[s.index(marker):]
 if marker=='theorem meets_iff':s=s[:s.index('section\nvariable {p : ℕ}')]
 for m in re.finditer(r'theorem\s+([\w.]+)\s+(.*?)\s*:=\s*(?:Iff\.)?rfl',s,re.S):
  name,stmt=m.groups()
  controls.append(f'example {stmt} := by\n  fail_if_success rfl\n  apply {name}\n')
  unsealed.append(f'example {stmt} := by rfl\n')
attrs='section TMProcBoundary\nattribute [local irreducible] '+' '.join(defs)+'\nattribute [-simp] '+' '.join(simps)+'\n'
Path('evidence/probes/CheckpointSeal.lean').write_text(source.replace('namespace Light\n',attrs+'namespace Light\n\n'+ '\n'.join(controls)+'\n',1)+'\nend TMProcBoundary\n')
Path('evidence/probes/ReaderControls.lean').write_text('import TCSlib.Programs.Light.TMProc\nnamespace Light\n'+ '\n'.join(unsealed)+'\nend Light\n')
Path('evidence/logs/sealed-definitions.txt').write_text('\n'.join(defs)+'\n')
print('Reader controls:',len(controls),'sealed definitions:',len(defs))
