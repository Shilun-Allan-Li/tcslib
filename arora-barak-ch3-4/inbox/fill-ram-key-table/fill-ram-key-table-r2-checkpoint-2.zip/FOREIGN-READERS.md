# Foreign definition census

All 48 reached foreign definition heads are irreducible throughout the complete new proof block and both targets in seal09. No new reader was required.

| Definition | Published interface or opaque use |
|---|---|
| `Turing.ReachesWithin` | reachesWithin_iff |
| `Turing.RecordAt` | recordAt_iff |
| `Turing.ScratchBlank` | scratchBlank_iff |
| `Turing.TableAt` | tableAt_iff; TableAt.recordAt_take |
| `Turing.TableWF` | tableWF_iff; TableWF.field_ne_nil |
| `Turing.WordAt` | wordAt_iff |
| `Turing.compareStop` | compareStop_le |
| `Turing.compareTM` | Opaque machine, consumed through compareTM_contract |
| `Turing.compareTM_contract` | compareTM_contract_pre, _time, _post; Contract fields run/cut/env |
| `Turing.copyTM` | Opaque machine, consumed through copyTM_contract |
| `Turing.copyTM_contract` | copyTM_contract_pre, _time, _post; Contract fields run/cut/env |
| `Turing.fieldOffset` | fieldOffset_zero, _cons_succ, _succ, _length, _add_length_le |
| `Turing.fieldsTape` | fieldsTape_field, _of_neg, _of_length_le, _of_nonneg |
| `Turing.framedContract` | framedContract_pre, _time, _post; construction from a published row |
| `Turing.inputMoveAction` | Opaque action consumed through step_of_inputMoveAction |
| `Turing.instDecidableEqFlagPhase` | Opaque existing typeclass instance; its body is not read |
| `Turing.instDecidableEqSweepPhase` | Opaque existing typeclass instance; its body is not read |
| `Turing.instFintypeFlagPhase` | Opaque existing typeclass instance; its body is not read |
| `Turing.instFintypeScanPhase` | Opaque existing typeclass instance; its body is not read |
| `Turing.instFintypeSeekPhase` | Opaque existing typeclass instance; its body is not read |
| `Turing.instFintypeSweepPhase` | Opaque existing typeclass instance; its body is not read |
| `Turing.joinFields` | joinFields_singleton, _length, _cons_cons, _nil; length_joinFields_add_one |
| `Turing.mealyRun` | mealyRun_nil; mealyRun_cons |
| `Turing.moveInputPos` | moveInputPos_zero |
| `Turing.phaseHostTM` | phaseHostTM_run; phaseHostTM_run_le |
| `Turing.scanResult` | scanResult_eq |
| `Turing.scanTM` | Opaque machine, consumed through scanTM_contract |
| `Turing.scanTM_contract` | scanTM_contract_pre, _time, _post; Contract fields run/cut/env |
| `Turing.seamCompTM` | Opaque seam consumed through Contract.seq and its public field equations |
| `Turing.seekPost` | seekPost_state, _inputPos, _workTapes, _workTapePos, _output |
| `Turing.skipTM` | Opaque machine, consumed through skipTM_contract |
| `Turing.skipTM_contract` | skipTM_contract_pre, _time, _post; Contract fields run/cut/env |
| `Turing.sweepPost` | sweepPost_state, _inputPos, _workTapes, _workTapePos, _output |
| `Turing.tableFields` | tableFields_eq |
| `Turing.tableOffset` | tableOffset_eq; tableOffset_length |
| `Turing.tableRewindTM` | tableRewindTM_run_ofCfg |
| `Turing.tapeAction` | Opaque action consumed through step_of_tapeAction_move and _write |
| `Turing.wordWrite` | wordWrite_apply |
| `Turing.Cfg.SameOutside` | Cfg.sameOutside_iff; Cfg.SameOutside.keep_word |
| `Turing.Cfg.bindState` | Cfg.bindState_state, _inputPos, _workTapes, _workTapePos, _output |
| `Turing.Cfg.inputSymbol` | Opaque transition input; never unfolded |
| `Turing.Cfg.mapState` | Cfg.mapState_state, _inputPos, _workTapes, _workTapePos, _output; mapState_mapState; CfgFacts |
| `Turing.Cfg.workTapeSymbols` | Opaque transition input; never unfolded |
| `Turing.Contract.inPhase` | Contract.inPhase_pre; Contract.inPhase_time; Contract.inPhase_post; Contract fields |
| `Turing.Contract.seq` | Contract.seq_pre; Contract.seq_time; Contract.seq_post; Contract fields |
| `Turing.FinTM.bufferTape` | FinTM.bufferTape_eq; bufferTape_left; bufferTape_nil |
| `Turing.MultiTapeTM.runFrom` | runFrom_zero; runFrom_one; runFrom_add; runFrom_succ_eq_step; runFrom_succ_eq_step' |
| `Turing.MultiTapeTM.step` | step_of_tapeAction_move/write; step_of_inputMoveAction; phaseHostTM run equations |
