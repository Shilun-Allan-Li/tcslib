from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, tempfile, zipfile

ROOT = Path(__file__).resolve().parents[3]
BASE = "7342f98b58704d6c25faf668ed1a64ea0b27c4af"
OWNER = Path("TCSlib/Complexity/TuringMachine/Build/KeyTable.lean")
SOURCE = (ROOT / OWNER).read_text()
LOGS = ROOT / "evidence/logs/r2"
META = (LOGS / "lookup-metadata-02.log").read_text()
STAGE = Path(tempfile.mkdtemp(prefix="keytable-r2-checkpoint-1-", dir="/private/tmp"))
OUT = ROOT / "evidence/deliveries/fill-ram-key-table-r2-checkpoint-1.zip"
COMMIT = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
SHA = hashlib.sha256((ROOT / OWNER).read_bytes()).hexdigest()
assert SHA == json.loads((LOGS / "seal-07-source.json").read_text())["source_sha256"]
assert "depends on axioms: [propext, Classical.choice, Quot.sound]" in META
for label in ["keytable-116-zero-footprint-split", "lookup-metadata-02", "lookup-seal-07"]:
    assert (LOGS / (label + ".log")).read_text().rstrip().endswith("EXIT 0")
old = subprocess.check_output(["git", "show", BASE + ":" + str(OWNER)], cwd=ROOT, text=True)
trim = SOURCE[:SOURCE.index("/-! ## Private marker adaptation -/")] + SOURCE[SOURCE.index("/-! ## The rows\n"):]
trim = trim.replace("import TCSlib.Complexity.TuringMachine.Build.InputRewind\n", "")
a, b = trim.index("/-- **Keyed lookup.**"), trim.index("/-- **Keyed assignment.**")
oa, ob = old.index("/-- **Keyed lookup.**"), old.index("/-- **Keyed assignment.**")
assert trim[:a] + old[oa:ob] + trim[b:] == old
frozen = {}
for name in ["exists_keyLookupTM", "exists_keyAssignTM"]:
    def statement(text):
        a = text.index("theorem " + name)
        return text[a:text.index(" := by\n", a)]
    assert statement(SOURCE) == statement(old)
    frozen[name] = hashlib.sha256(statement(SOURCE).encode()).hexdigest()
(LOGS / "checkpoint-1-source-freeze.json").write_text(json.dumps(dict(base=BASE, source_commit=COMMIT,
    source_sha256=SHA, statement_sha256=frozen, remaining_admissions=SOURCE.count("  sorry"),
    existing_source_unchanged_except_lookup_body_and_sketch=True, lines=len(SOURCE.splitlines())), indent=2) + "\n")

# Named declarations and their actual source docstrings; generated artifacts are listed separately.
named = []
for m in re.finditer(r"^private\s+(?:noncomputable\s+)?(def|theorem|instance|inductive|abbrev)\s+(\w+)", SOURCE, re.M):
    before = SOURCE[:m.start()]
    da = before.rfind("/--")
    db = before.find("-/", da)
    doc = before[da + 3:db].strip() if da >= 0 and db >= da else "Internal implementation declaration."
    role = re.split(r"\n\s*\n", doc)[0].replace("\n", " ")
    named.append((m.group(2), m.group(1), role))
(STAGE / "INVENTORY.md").write_text("# Named private declarations\n\n" +
    "All are in the owned file. Generated equations, recursors, matchers and derived instances " +
    "are included in AUDITED-CONSTANTS.txt and the full metadata log.\n\n" +
    "| Name | Kind | Role |\n|---|---|---|\n" +
    "".join("| `" + n + "` | " + k + " | " + r.replace("|", "\\|") + " |\n" for n,k,r in named))
roots = re.findall(r"^AXIOMS\|([^|]+)\|(.+)$", META, re.M)
(STAGE / "AUDITED-CONSTANTS.txt").write_text("".join(n + " | " + a + "\n" for n,a in roots))
heads = re.findall(r"SEALHEAD\|([^\s]+)", META)
readers = {
"ReachesWithin":"reachesWithin_iff",
"RecordAt":"recordAt_iff",
"ScratchBlank":"scratchBlank_iff",
"TableAt":"tableAt_iff; TableAt.recordAt_take",
"TableWF":"tableWF_iff; TableWF.field_ne_nil",
"WordAt":"wordAt_iff",
"compareStop":"compareStop_le",
"compareTM":"Opaque machine, consumed through compareTM_contract",
"compareTM_contract":"compareTM_contract_pre, _time, _post; Contract fields run/cut/env",
"copyTM":"Opaque machine, consumed through copyTM_contract",
"copyTM_contract":"copyTM_contract_pre, _time, _post; Contract fields run/cut/env",
"fieldOffset":"fieldOffset_zero, _cons_succ, _succ, _length, _add_length_le",
"fieldsTape":"fieldsTape_field, _of_neg, _of_length_le, _of_nonneg",
"framedContract":"framedContract_pre, _time, _post; construction from a published row",
"inputMoveAction":"Opaque action consumed through step_of_inputMoveAction",
"joinFields":"joinFields_singleton, _length, _cons_cons, _nil; length_joinFields_add_one",
"mealyRun":"mealyRun_nil; mealyRun_cons",
"moveInputPos":"moveInputPos_zero",
"phaseHostTM":"phaseHostTM_run; phaseHostTM_run_le",
"scanResult":"scanResult_eq",
"scanTM":"Opaque machine, consumed through scanTM_contract",
"scanTM_contract":"scanTM_contract_pre, _time, _post; Contract fields run/cut/env",
"seamCompTM":"Opaque seam consumed through Contract.seq and its public field equations",
"seekPost":"seekPost_state, _inputPos, _workTapes, _workTapePos, _output",
"skipTM":"Opaque machine, consumed through skipTM_contract",
"skipTM_contract":"skipTM_contract_pre, _time, _post; Contract fields run/cut/env",
"sweepPost":"sweepPost_state, _inputPos, _workTapes, _workTapePos, _output",
"tableFields":"tableFields_eq",
"tableOffset":"tableOffset_eq; tableOffset_length",
"tableRewindTM":"tableRewindTM_run_ofCfg",
"tapeAction":"Opaque action consumed through step_of_tapeAction_move and _write",
"wordWrite":"wordWrite_apply",
"Cfg.bindState":"Cfg.bindState_state, _inputPos, _workTapes, _workTapePos, _output",
"Cfg.inputSymbol":"Opaque transition input; never unfolded",
"Cfg.mapState":"Cfg.mapState_state, _inputPos, _workTapes, _workTapePos, _output; mapState_mapState; CfgFacts",
"Cfg.workTapeSymbols":"Opaque transition input; never unfolded",
"Contract.inPhase":"Contract.inPhase_pre; Contract.inPhase_time; Contract.inPhase_post; Contract fields",
"Contract.seq":"Contract.seq_pre; Contract.seq_time; Contract.seq_post; Contract fields",
"FinTM.bufferTape":"FinTM.bufferTape_eq; bufferTape_left; bufferTape_nil",
"MultiTapeTM.runFrom":"runFrom_zero; runFrom_one; runFrom_add; runFrom_succ_eq_step; runFrom_succ_eq_step'",
"MultiTapeTM.step":"step_of_tapeAction_move/write; step_of_inputMoveAction; phaseHostTM run equations"
}
rows = []
for head in heads:
    short = head.removeprefix("Turing.")
    if short.startswith("instDecidableEq") or short.startswith("instFintype"):
        role = "Opaque typeclass instance; passed to the existing construction, no definition read"
    else:
        assert short in readers, short
        role = readers[short]
    rows.append("| `" + head + "` | " + role + " |\n")
(STAGE / "FOREIGN-READERS.md").write_text("# Foreign definitions and their reading interfaces\n\n" +
    "This is the complete 47-head census produced by LookupMetadata.lean. The seal leaves " +
    "every head below irreducible throughout the new proof block and target. Foreign theorem " +
    "proofs and reducible abbreviations are not unfolded by this consumer.\n\n" +
    "| Definition | Public interface used, or opaque use |\n|---|---|\n" + "".join(rows))
stat = subprocess.check_output(["git", "diff", "--stat", BASE, "--", str(OWNER)], cwd=ROOT, text=True).strip()
report = f"""# Keyed-table fill, round 2 — checkpoint 1

This is a progress checkpoint. The goal remains active; assignment and final downstream checks
are still outstanding. It is not the final `fill-ram-key-table-r2.zip` delivery.

- Repository: Shilun-Allan-Li/tcslib.
- Read-only base: `{BASE}` (ram/readers-2, PR #375).
- Rules/brief: `e40383d88d79e23026c95e20608ee8827d45e59b`, COMMON.md including its tier 2 addendum.
- Local proof branch: `codex/fill-ram-key-table-r2`, never rebased or pushed.
- Source checkpoint: `{COMMIT}`.
- Owned file SHA256: `{SHA}`.

## Targets and frontier

| Target | Status | Evidence |
|---|---|---|
| `Turing.exists_keyLookupTM` | Proved, frozen statement | Native116, full seal07, metadata02 |
| `Turing.exists_keyAssignTM` | Original sorry remains | Controller and shared entry scan are proved; whole assignment layout invariant and append run remain |

Lookup uses the finite shared phase host, one private marker contract transformer for comparison
and copying, catalog contracts placed with Contract.inPhase, and an induction on the unvisited
entry suffix. Entry costs telescope through the table offsets. The complete row has C = 64.
Its final anchor cannot be revisited, giving the first-exit cut; the model's head bound gives
radius at most the same time bound. The only remaining admission is assignment's original body.
No theorem statement, original definition, or unproved target sketch changed. The lookup sketch
was rewritten to describe the actual proof. The source-freeze check also compares the remaining
pre-existing source byte for byte after restoring only lookup's allowed body and sketch.

## Validation of this checkpoint

| Check | Exit | Result |
|---|---|---|
| `keytable-116-zero-footprint-split` | 0 | Fresh native owner olean; only assignment has a sorry warning |
| `lookup-metadata-02` | 0 | Lookup plus all private generated/explicit constants audited; {len(roots)} roots |
| `lookup-seal-07` | 0 | Entire new proof block and lookup re-elaborated with all {len(heads)} foreign heads irreducible |
| Source freeze and `git diff --check` | 0 | Both target statements byte-identical; no whitespace errors |

`#print axioms Turing.exists_keyLookupTM`:

```text
[propext, Classical.choice, Quot.sound]
```

There is no sorryAx and no admitted dependency, including no admitted RecordTable or WordArith
row. The required admitted-declaration walk is therefore empty. `LookupMetadata.lean` calls
collectAxioms on every root and fails for any axiom outside the three standard ones. The full
root list and axiom output are included. Downstream Sim/*, Simulation, Classes and facades have
not yet been replayed for this checkpoint; that replay is required for the final delivery.
Developmental failed checks remain in the logs for diagnosis. The success labels above identify
the evidence for this exact source; seal-07-source.json binds the sealed copy to the owner hash.

## Scope, readers and reuse

Only the owned library file is in the patch. The added existing import Build/InputRewind supplies
Cfg.mapState_mapState, used to compose state relabelings. No new public declaration, public
reader, axiom, simp attribute, or admitted dependency was added. Original private rt_* lemmas and
admitted RecordTable rows are never cited. Published PR #375 readers are used directly.

All {len(named)} explicitly named private declarations and their actual roles are listed in
[INVENTORY.md](INVENTORY.md). Generated equations, matchers, recursors and derived instances are
included in [AUDITED-CONSTANTS.txt](AUDITED-CONSTANTS.txt) and the metadata log. Each of the
{len(heads)} reached foreign definitions and its reading interface is in
[FOREIGN-READERS.md](FOREIGN-READERS.md). The file has {len(SOURCE.splitlines())} lines; the tier 2
size exception explicitly permits continuing beyond 1,500 lines and leaving the split to landing.
The unused prepared raw-contract family is retained as assignment scaffolding at this checkpoint;
it can be removed before final delivery if assignment does not consume it.

Existing facts were searched in the bootstrapped import closure before adding helpers:

- Marker adaptation: Catalog's framed compare/copy rows, Contract.seq/inPhase, Seam's phaseHostTM
  run theorems, StateRenaming/CfgFacts field interfaces and InputRewind's map composition. Only a
  missing fixed one-cell delimiter eraser requires a raw leaf; the same leaf is reused to restore
  markers and write append markers. No replacement catalog machine was built.
- Layout: RecordTable's tableFields/tableWF/tableAt readers, TableAt.recordAt_take, tableOffset_eq
  and tableOffset_length; Catalog's fieldsTape_field, field offsets and public layout equations.
  Private rt_* facts were excluded. Keyed arithmetic and marker corollaries bridge these APIs.
- Zeroing: public mealyRun_nil/cons and scanResult_eq plus scanTM_contract; no word-arithmetic
  admission. WordAt and wordWrite helpers read only wordAt_iff and wordWrite_apply.
- Traversal: skipTM_contract, compareTM_contract, copyTM_contract and tableRewindTM_run_ofCfg,
  all placed through the shared phase helper. The Segment/SafeSegment/RoundContract interfaces
  were inspected; exact run concatenation and a non-revisited final anchor give the needed row
  without duplicating their envelope composition. Mathematical lookup uses List.find?_cons
  and List.drop_eq_getElem_cons, not another transition-table argument.

Patch statistics against the base:

```text
{stat}
```

Thirty unrelated dirty blueprint files predated this work and were preserved, not staged or
included in this patch or archive. All code checkpoints so far are local only.

## Environment and process record

Native macOS, pinned Lean v4.25.0. Preflight recorded 12 CPUs, 18 GiB physical RAM, 59% available
memory by memory_pressure, and approximately 111 GiB free disk. Native sysctl/vm_stat/time -l
replace unavailable Linux diagnostics. Package URLs/revisions match lake-manifest.json; the
package directory is a pin-verified symlink to the existing cache. No lake build was run.
The base import closure was built fresh in our own `.lake/fill-ram-key-table-r2-oleans` tree:
38 original modules plus the added existing InputRewind module. Other fills' oleans are not used.
All checks run through the campaign leanelab wrappers with TCSLIB_LEAN_SLOTS=3, nice -n10 and -j4.
The driver records machine-wide executable counts and waits before launching when the count is
at least three. It now also holds an OS per-fill fcntl lock for each complete check and deletes
an old olean before recompiling. Process counts/waits and command exit codes are included.

An actual process-control deviation occurred: keytable-55 and -56 overlapped after a still-running
session was mistaken for a terminal result. Two own Lean processes ran concurrently for about
130 seconds; the recorded machine-wide count was two. Both checks failed, both products were
discarded, and no olean remained. They were never used as dependency evidence. The overlap and
resource recheck are logged; a per-fill lock was added, and the fresh serial check57 plus all
subsequent successful checks supersede them. This deviation did not end the fill.
Delivery uses a separate sparse exchange checkout backed by existing local Git objects; the
shared exchange checkout and its pending files from other fills remain untouched.

## Remaining work

Complete assignment's equal-width table rewrite invariant, all-match scan and absent-key append
through the existing shared adapter/controller; prove its frozen target; remove unused scaffolding;
re-run native, axioms, seals and the complete downstream closure; deliver the final round-2 zip.
The goal stays active while this work continues.

## Archive contents

REPORT.md, INVENTORY.md, FOREIGN-READERS.md, AUDITED-CONSTANTS.txt, the owned file at its normal
repository path, a patch against the base, all round-2 logs, all versioned round-2 Lean probes,
and the check/package driver scripts. MANIFEST.sha256 covers every archive file other than itself.
"""
(STAGE / "REPORT.md").write_text(report)
(STAGE / OWNER).parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(ROOT / OWNER, STAGE / OWNER)
patch = subprocess.check_output(["git", "diff", "--binary", BASE, "--", str(OWNER)], cwd=ROOT)
(STAGE / "fill-ram-key-table-r2.patch").write_bytes(patch)
checked = subprocess.run(["git", "apply", "--check", "--reverse", str(STAGE / "fill-ram-key-table-r2.patch")],
    cwd=ROOT, capture_output=True, text=True)
(LOGS / "checkpoint-1-patch-check.log").write_text(checked.stdout + checked.stderr + "EXIT " + str(checked.returncode) + "\n")
assert checked.returncode == 0
shutil.copytree(LOGS, STAGE / "evidence/logs/r2", ignore=shutil.ignore_patterns("checkpoint-1-package.json"))
shutil.copytree(ROOT / "evidence/probes/r2", STAGE / "evidence/probes/r2")
(STAGE / "evidence/runtime/r2").mkdir(parents=True)
for n in ["checks.py", "package_checkpoint1.py"]:
    shutil.copy2(ROOT / "evidence/runtime/r2" / n, STAGE / "evidence/runtime/r2" / n)
manifest = []
for p in sorted(STAGE.rglob("*")):
    if p.is_file():
        manifest.append(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(STAGE).as_posix())
(STAGE / "MANIFEST.sha256").write_text("\n".join(manifest) + "\n")
OUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(STAGE.rglob("*")):
        if p.is_file(): z.write(p, p.relative_to(STAGE).as_posix())
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for line in z.read("MANIFEST.sha256").decode().splitlines():
        digest, name = line.split("  ", 1)
        assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
summary = dict(zip=str(OUT), sha256=hashlib.sha256(OUT.read_bytes()).hexdigest(), bytes=OUT.stat().st_size,
    stage=str(STAGE), source_commit=COMMIT, source_sha256=SHA, named_private=len(named), audited_roots=len(roots), foreign_heads=len(heads))
(LOGS / "checkpoint-1-package.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
