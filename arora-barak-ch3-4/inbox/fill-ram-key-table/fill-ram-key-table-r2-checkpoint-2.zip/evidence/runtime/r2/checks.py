from pathlib import Path
import datetime, json, os, subprocess, time, fcntl

ROOT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-key-table/tcslib-exchange')
LOGS = ROOT / 'evidence/logs/r2'
OLEANS = ROOT / '.lake/fill-ram-key-table-r2-oleans'
ENV = dict(os.environ, TCSLIB_LEAN_SLOTS='3')

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def lean_processes():
    result = subprocess.run(['ps', '-axww', '-o', 'pid=,args='], text=True, capture_output=True, check=True)
    processes = []
    for line in result.stdout.splitlines():
        words = line.split(None, 2)
        if len(words) > 1 and Path(words[1]).name == 'lean':
            processes.append(line)
    return processes

def _check_unlocked(label, source, compile_module=False):
    with (LOGS/'lean-processes.log').open('a') as log:
        while True:
            active = lean_processes()
            log.write(stamp() + ' before ' + label + ': count=' + str(len(active)) + '\n')
            for line in active:
                log.write(line + '\n')
            log.flush()
            if len(active) < 3:
                break
            log.write('WAIT: machine has at least 3 Lean processes; retry in 10s\n')
            log.flush()
            time.sleep(10)
    log_path = LOGS / (label + '.log')
    wrapper = ROOT/'devtools/seyoon'/('leanelab-o.sh' if compile_module else 'leanelab.sh')
    args = ['bash', str(wrapper), str(ROOT), str(OLEANS), source]
    if compile_module:
        args.append(str(OLEANS))
        output = OLEANS / (source.removesuffix('.lean') + '.olean')
        output.unlink(missing_ok=True)
    start = stamp()
    with log_path.open('w') as log:
        log.write('START ' + start + '\nCOMMAND ' + repr(args) + '\n')
        log.flush()
        completed = subprocess.run(['/usr/bin/time', '-l'] + args, cwd=ROOT, env=ENV, stdout=log, stderr=subprocess.STDOUT)
        end = stamp()
        log.write('END ' + end + '\nEXIT ' + str(completed.returncode) + '\n')
    body = log_path.read_text()
    success = completed.returncode == 0 and 'error:' not in body
    if compile_module:
        output = OLEANS / (source.removesuffix('.lean') + '.olean')
        success = success and output.exists() and output.stat().st_size > 0
    entry = dict(label=label, source=source, start=start, end=end, exit=completed.returncode, passed=success)
    with (LOGS/'check-results.jsonl').open('a') as log:
        log.write(json.dumps(entry) + '\n')
    print(json.dumps(entry), flush=True)
    if not success:
        print(body, flush=True)
    return success

def check(label, source, compile_module=False):
    lockpath = ROOT / '.lake/fill-ram-key-table-r2-own-lean.lock'
    with lockpath.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            with (LOGS/'lean-processes.log').open('a') as log:
                log.write(stamp() + ' WAIT: own Lean slot before ' + label + '\n')
            fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            return _check_unlocked(label, source, compile_module)
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)

if __name__ == '__main__':
    if not check('cache-root-probe', 'evidence/probes/r2/MathlibRoot.lean', True):
        raise SystemExit(1)
    for index, module in enumerate((LOGS/'bootstrap-order.txt').read_text().splitlines()):
        source = module.replace('.', '/') + '.lean'
        if not check(f'bootstrap-{index:02d}-' + module.split('.')[-1], source, True):
            raise SystemExit(1)
    print('BOOTSTRAP PASS', flush=True)
