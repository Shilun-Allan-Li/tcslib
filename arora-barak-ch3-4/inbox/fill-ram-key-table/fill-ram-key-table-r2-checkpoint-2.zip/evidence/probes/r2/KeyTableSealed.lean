/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.TuringMachine.Build.RecordTable
import TCSlib.Complexity.TuringMachine.Build.WordArith
import TCSlib.Complexity.TuringMachine.Build.InputRewind

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Keyed tables: lookup and assignment by a key held on another tape

A **keyed table** is a list of entries `(key, value)` of binary words, laid out on one work tape
in the record-table layout of `Build/RecordTable` (`Turing.TableAt`): the header `[true]`, then
for each entry the two fields `true :: key` and `true :: value`, fields separated by one blank,
two blanks before the header and after the last field. The leading `true` of each field keeps
every field nonempty, so the layout is well formed (`Turing.TableWF`) even for empty keys or
values, and a blank pair marks the table's end.

The two rows are the host of a memory: **lookup** copies the value stored under a key, held on
another tape, into a register (the all-`false` word if the key is absent), and **assignment**
overwrites the value stored under a key in place, or appends a new entry. They are the memory of
a word RAM run on a Turing machine (`WordRAM.exists_simulation`), where keys are addresses and
values are words, but they are generic in both.

The record-table rows `Turing.exists_tableFindTM` and `Turing.exists_tableAppendTM` select by a
finite-state predicate and do not read a key from another tape; they are not used here.

## Main definitions

* `Turing.keyFields`, `Turing.keyTableLength`, `Turing.KeyTableAt`: the layout.
* `Turing.keyLookup`, `Turing.keyAssign`: the two operations on lists of entries.
* `Turing.keyTableWrite`: the tapes after laying a keyed table out.

## Main results

* `Turing.exists_keyLookupTM`: lookup, within `O(table + key + value)` steps.
* `Turing.exists_keyAssignTM`: assignment, within the same bound.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (Exercise 1.9: a RAM's memory kept by a Turing machine as a
  list of address and value pairs, scanned at each access.)
-/

namespace Turing

/-! ## The layout -/

/-- **The fields of a keyed table's entries**: each entry `(k, v)` gives the two fields
`true :: k` and `true :: v`. -/
def keyFields (es : List (List Bool × List Bool)) : List (List (List Bool)) :=
  es.map fun e => [true :: e.1, true :: e.2]

/-- The fields of a keyed table's entries, as an equation. -/
theorem keyFields_def (es : List (List Bool × List Bool)) :
    keyFields es = es.map fun e => [true :: e.1, true :: e.2] := rfl

/-- **The length of a keyed table's layout**: the cells from the header's first to the last
field's last, separators included (the sentinels excluded). -/
def keyTableLength (es : List (List Bool × List Bool)) : ℕ :=
  (joinFields (tableFields [true] (keyFields es))).length

/-- The length of a keyed table's layout, as an equation. -/
theorem keyTableLength_def (es : List (List Bool × List Bool)) :
    keyTableLength es = (joinFields (tableFields [true] (keyFields es))).length := rfl

/-- **A keyed table on a tape**: tape `r` holds the record-table layout of the header `[true]`
and the entries `keyFields es` from the origin `o` (`Turing.TableAt`, with its two blank cells on
either side), and every cell after the layout is blank, so that the table can grow. -/
def KeyTableAt {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K) (o : ℤ)
    (es : List (List Bool × List Bool)) : Prop :=
  TableAt d r o [true] (keyFields es) ∧
    ∀ q : ℤ, o + (keyTableLength es : ℤ) ≤ q → d.workTapes r q = none

/-- `KeyTableAt`, as an equivalence with its definition. -/
theorem keyTableAt_iff {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (o : ℤ) (es : List (List Bool × List Bool)) :
    KeyTableAt d r o es ↔ TableAt d r o [true] (keyFields es) ∧
      ∀ q : ℤ, o + (keyTableLength es : ℤ) ≤ q → d.workTapes r q = none :=
  Iff.rfl

/-- **The tapes after laying a keyed table out**: on tape `r`, the cells `[o, o + L)` hold the
layout of `es`, `L = keyTableLength es`; every other cell, of every tape, is unchanged. -/
def keyTableWrite {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K) (o : ℤ)
    (es : List (List Bool × List Bool)) : Fin K → ℤ → Option Bool :=
  fun j q =>
    if j = r ∧ o ≤ q ∧ q < o + (keyTableLength es : ℤ)
      then fieldsTape (tableFields [true] (keyFields es)) (q - o)
    else d.workTapes j q

/-- `keyTableWrite`, as an equation. -/
theorem keyTableWrite_apply {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (o : ℤ) (es : List (List Bool × List Bool)) (j : Fin K) (q : ℤ) :
    keyTableWrite d r o es j q =
      if j = r ∧ o ≤ q ∧ q < o + (keyTableLength es : ℤ)
        then fieldsTape (tableFields [true] (keyFields es)) (q - o)
      else d.workTapes j q :=
  rfl

/-! ## The operations -/

/-- **Lookup**: the value of the first entry whose key is `k`, if any. -/
def keyLookup (es : List (List Bool × List Bool)) (k : List Bool) : Option (List Bool) :=
  (es.find? fun e => e.1 = k).map Prod.snd

/-- Lookup, as an equation. -/
theorem keyLookup_def (es : List (List Bool × List Bool)) (k : List Bool) :
    keyLookup es k = (es.find? fun e => e.1 = k).map Prod.snd := rfl

/-- **Assignment**: if some entry has the key `k`, every such entry's value becomes `v`;
otherwise the entry `(k, v)` is appended. -/
def keyAssign (es : List (List Bool × List Bool)) (k v : List Bool) :
    List (List Bool × List Bool) :=
  if es.any (fun e => e.1 = k) then es.map fun e => if e.1 = k then (k, v) else e
  else es ++ [(k, v)]

/-- Assignment, as an equation. -/
theorem keyAssign_def (es : List (List Bool × List Bool)) (k v : List Bool) :
    keyAssign es k v =
      if es.any (fun e => e.1 = k) then es.map fun e => if e.1 = k then (k, v) else e
      else es ++ [(k, v)] := rfl

/-! ## Private marker adaptation -/

attribute [local irreducible] WordAt FinTM.bufferTape Cfg.mapState MultiTapeTM.runFrom
  seamCompTM phaseHostTM inputMoveAction tapeAction Contract.seq


/-- Erase the marker under head `r` and advance that head to the payload. -/
private def kt_openMarker {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) : Cfg K Bool S x :=
  { d with
    workTapes := Function.update d.workTapes r
      (Function.update (d.workTapes r) (d.workTapePos r) none)
    workTapePos := Function.update d.workTapePos r (d.workTapePos r + 1) }

/-- Clearing a marked field's marker gives a blank-delimited payload, including when the
payload is empty.

**Proof sketch.** Read the marked word using `Turing.wordAt_iff`. The new left delimiter is
the erased cell; every nonnegative payload offset is the next cell of the marked word.
`Turing.FinTM.bufferTape_eq` and list lookup on a cons identify those cells. -/
private theorem kt_openMarker_word {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) (w : List Bool) (hw : WordAt d r (true :: w)) :
    WordAt (kt_openMarker d r) r w := by
  rw [wordAt_iff] at hw ⊢
  intro p hp hp'
  simp only [kt_openMarker, Function.update_self]
  by_cases hneg : p < 0
  · have heq : p = -1 := by omega
    subst p
    rw [show d.workTapePos r + 1 + -1 = d.workTapePos r by omega,
      Function.update_self, FinTM.bufferTape_left]
  · have hp0 : 0 ≤ p := by omega
    rw [Function.update_of_ne (show d.workTapePos r + 1 + p ≠ d.workTapePos r by omega),
      show d.workTapePos r + 1 + p = d.workTapePos r + (1 + p) by omega,
      hw (1 + p) (by omega) (by simp only [List.length_cons, Nat.cast_add, Nat.cast_one]; omega)]
    rw [FinTM.bufferTape_eq, FinTM.bufferTape_eq, if_pos (by omega), if_pos hp0,
      show (1 + p).toNat = p.toNat + 1 by omega, List.getElem?_cons_succ]

/-- Return from a payload head to its marker and restore the marker. -/
private def kt_closeMarker {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) : Cfg K Bool S x :=
  { d with
    workTapes := Function.update d.workTapes r
      (Function.update (d.workTapes r) (d.workTapePos r - 1) (some true))
    workTapePos := Function.update d.workTapePos r (d.workTapePos r - 1) }

/-- Opening and immediately closing a marked field restores the complete configuration.

**Proof sketch.** The head advances and retreats once. Both writes address the old marker
cell; the second replaces its original `some true`. All other tape cells and heads are fixed. -/
private theorem kt_closeMarker_openMarker {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K)
    (hm : d.workTapes r (d.workTapePos r) = some true) :
    kt_closeMarker (kt_openMarker d r) r = d := by
  apply Cfg.ext <;> try rfl
  · funext j q
    by_cases hj : j = r
    · subst j
      simp only [kt_closeMarker, kt_openMarker, Function.update_self, add_sub_cancel_right,
        Function.update_apply]
      split_ifs with hq
      · rw [hq]
        exact hm.symm
      · rfl
    · simp only [kt_closeMarker, kt_openMarker, Function.update_of_ne hj]
  · funext j
    by_cases hj : j = r
    · subst j
      simp only [kt_closeMarker, kt_openMarker, Function.update_self, add_sub_cancel_right]
    · simp only [kt_closeMarker, kt_openMarker, Function.update_of_ne hj]

/-- The catalog has no fixed one-cell delimiter eraser. This two-state leaf performs one
`tapeAction`, then exposes its exit; the table traversal itself uses the phase host. -/
private def kt_cellTM {K : ℕ} (r : Fin K) (wr : Option (Option Bool)) (m : SignType) :
    MultiTapeTM K Bool Bool where
  q₀ := false
  tr := fun b _ _ => if b then inputMoveAction 0 true else tapeAction r 0 wr m true

/-- The complete endpoint of the delimiter leaf, including its unchanged outer frame. -/
private def kt_cellPost {K : ℕ} {x : List Bool} (r : Fin K) (wr : Option (Option Bool))
    (m : SignType) (d : Cfg K Bool Bool x) : Cfg K Bool Bool x :=
  { d with
    state := some true
    workTapes := match wr with
      | none => d.workTapes
      | some b => Function.update d.workTapes r
          (Function.update (d.workTapes r) (d.workTapePos r) b)
    workTapePos := Function.update d.workTapePos r (d.workTapePos r + m) }

/-- The delimiter leaf has the stated one-step endpoint.

**Proof sketch.** Its entry transition is `Turing.tapeAction`. Use
`Turing.step_of_tapeAction_move` when there is no write and
`Turing.step_of_tapeAction_write` otherwise; `Turing.moveInputPos_zero` fixes the input head. -/
private theorem kt_cellTM_run {K : ℕ} {x : List Bool} (r : Fin K)
    (wr : Option (Option Bool)) (m : SignType) (d : Cfg K Bool Bool x)
    (hd : d.state = some false) :
    (kt_cellTM r wr m).runFrom d 1 = kt_cellPost r wr m d := by
  rw [MultiTapeTM.runFrom_succ_eq_step', MultiTapeTM.runFrom_zero]
  cases wr with
  | none =>
    rw [step_of_tapeAction_move (kt_cellTM r none m) d r 0 m hd rfl]
    apply Cfg.ext <;> simp only [kt_cellPost, moveInputPos_zero]
  | some b =>
    rw [step_of_tapeAction_write (kt_cellTM r (some b) m) d r 0 b m hd rfl]
    apply Cfg.ext <;> simp only [kt_cellPost, moveInputPos_zero]

/-- Package the one-cell leaf with any caller-supplied precondition.

**Proof sketch.** `kt_cellTM_run` supplies the endpoint, and the distinct Boolean entry and
exit give its first-exit cut. `Turing.MultiTapeTM.workTapePos_runFrom_mem_Icc` supplies the
one-step head envelope. -/
private def kt_cellContract {K : ℕ} {ι : Type} {x : List Bool} (r : Fin K)
    (wr : Option (Option Bool)) (m : SignType) (pre : ι → Cfg K Bool Bool x → Prop) :
    Contract (kt_cellTM r wr m) false {some true} ι x := by
  refine {
    pre := pre
    time := fun _ _ => 1
    post := fun _ d => kt_cellPost r wr m d
    lo := fun _ d j => d.workTapePos j - 1
    hi := fun _ d j => d.workTapePos j + 1
    run := fun _ d hd _ => kt_cellTM_run r wr m d hd
    exit_mem := fun _ _ _ _ => rfl
    cut := ?_
    env := ?_ }
  · intro _ d hd _ u hu
    have heq : u = 0 := by omega
    subst u
    rw [MultiTapeTM.runFrom_zero]
    simpa only [Set.mem_singleton_iff, hd, Option.some.injEq, Bool.false_eq_true] using
      not_false
  · intro _ d _ _ u hu j
    have h := MultiTapeTM.workTapePos_runFrom_mem_Icc (kt_cellTM r wr m) d u j
    have hu' : (u : ℤ) ≤ 1 := by exact_mod_cast hu
    simp only [Finset.mem_Icc] at h ⊢
    constructor <;> omega

/-- The marker-restoration leaf: move left from the payload, then restore `true`. -/
private def kt_closeTM {K : ℕ} (r : Fin K) : MultiTapeTM K Bool (Bool ⊕ Bool) :=
  seamCompTM (kt_cellTM r none .neg) true (kt_cellTM r (some (some true)) 0) false

/-- The restoration leaf's contract is the seam composition of its two cell contracts. -/
private def kt_closeContract {K : ℕ} {x : List Bool} (r : Fin K) :
    Contract (kt_closeTM r) (.inl false)
      (Option.map (Sum.inr : Bool → Bool ⊕ Bool) '' {some true}) Unit x :=
  Contract.seq
    (kt_cellContract r none .neg (fun (_ : Unit) _ => True))
    (kt_cellContract r (some (some true)) 0 (fun (_ : Unit) _ => True))
    (fun _ => ()) (fun _ _ _ _ => True.intro)

/-- Marker restoration takes three steps, has no data precondition, and changes exactly
the marker and its head.

**Proof sketch.** Read the sequential contract through `Turing.Contract.seq_pre`,
`Turing.Contract.seq_time` and `Turing.Contract.seq_post`. State relabelings keep all tape
fields; the first leaf moves left and the second writes at that cell. -/
private theorem kt_closeContract_spec {K : ℕ} {x : List Bool} (r : Fin K)
    (d : Cfg K Bool (Bool ⊕ Bool) x) :
    (kt_closeContract r).pre () d ∧ (kt_closeContract r).time () d = 3 ∧
      (kt_closeContract r).post () d =
        { kt_closeMarker d r with state := some (.inr true) } := by
  have hneg : (↑SignType.neg : ℤ) = -1 := rfl
  refine ⟨?_, ?_, ?_⟩
  · rw [kt_closeContract, Contract.seq_pre]
    trivial
  · rw [kt_closeContract, Contract.seq_time]
    rfl
  · rw [kt_closeContract, Contract.seq_post]
    apply Cfg.ext
    · simp only [kt_cellContract, kt_cellPost, Cfg.mapState_state, Option.map_some]
    · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_inputPos]
    · funext j q
      by_cases hj : j = r
      · subst j
        simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapes,
          Cfg.mapState_workTapePos, Function.update_self, hneg, ← sub_eq_add_neg,
          Function.update_apply]
      · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapes,
          Cfg.mapState_workTapePos, Function.update_of_ne hj]
    · funext j
      by_cases hj : j = r
      · subst j
        simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapePos,
          Function.update_self, SignType.coe_zero, hneg, add_zero]
        omega
      · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapePos,
          Function.update_of_ne hj]
    · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_output]

/-- The payload phase uses the row's state type. Each restoration phase remembers the row's
exit state and uses the two-cell restoration controller. -/
private def kt_payloadControl (S : Type) : Option S → Type
  | none => S
  | some _ => Bool ⊕ Bool

/-- Payload and restoration routines for the existing phase host. -/
private def kt_payloadParts {K : ℕ} {S : Type} (r : Fin K) (M : MultiTapeTM K Bool S) :
    (p : Option S) → MultiTapeTM K Bool (kt_payloadControl S p)
  | none => M
  | some _ => kt_closeTM r

/-- Redirect each live row exit into its own marker-restoration phase. -/
private def kt_payloadRedirect {S : Type} (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] :
    (p : Option S) → kt_payloadControl S p → Option (Σ p, kt_payloadControl S p)
  | none, s => if some s ∈ X then some ⟨some s, .inl false⟩ else none
  | some _, _ => none

/-- Run a row at the payload and restore the marker at its exit, using `phaseHostTM`. -/
private def kt_payloadTM {K : ℕ} {S : Type} (r : Fin K) (M : MultiTapeTM K Bool S)
    (entry : S) (X : Set (Option S)) [DecidablePred fun s => some s ∈ X] :
    MultiTapeTM K Bool (Σ p, kt_payloadControl S p) :=
  phaseHostTM (kt_payloadParts r M) ⟨none, entry⟩ (kt_payloadRedirect X)

/-- Every restoration phase exposes the same local exit. Its index retains the row's verdict. -/
private def kt_payloadExits (S : Type) : Set (Option (Σ p, kt_payloadControl S p)) :=
  { q | ∃ s : S, q = some ⟨some s, .inr true⟩ }

/-- The adapter follows the row through its first exit, dispatches once, then follows the
restoration leaf. The exit value remains the restoration phase's index.

**Proof sketch.** The row contract supplies its endpoint and excludes redirects before it.
`Turing.phaseHostTM_run` gives the row segment and dispatch. The restoration phase has no
redirect, so `Turing.phaseHostTM_run_le` gives its whole segment. Concatenate with
`Turing.MultiTapeTM.runFrom_add` and `Turing.Cfg.mapState_mapState`. -/
private theorem kt_payloadTrace {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool S x) (hd : d.state = some entry) (hp : C.pre i d) :
    ∃ s : S, (C.post i d).state = some s ∧
      (∀ u ≤ C.time i d,
        (kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none)) u =
          (M.runFrom d u).mapState (Sigma.mk none)) ∧
      (∀ v ≤ 3,
        (kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none))
            (C.time i d + 1 + v) =
          ((kt_closeTM r).runFrom ((C.post i d).mapState fun _ => .inl false) v).mapState
            (Sigma.mk (some s))) := by
  have hne : (C.post i d).state ≠ none := by
    intro he
    have hx := C.exit_mem i d hd hp
    rw [he] at hx
    exact hnone hx
  obtain ⟨s, hs⟩ := Option.ne_none_iff_exists'.mp hne
  have hsX : some s ∈ X := by rw [← hs]; exact C.exit_mem i d hd hp
  have hguard : ∀ u < C.time i d, ∀ q,
      (M.runFrom d u).state = some q → kt_payloadRedirect X none q = none := by
    intro u hu q hq
    have hqX : some q ∉ X := by
      intro hx
      apply C.cut i d hd hp u hu
      rw [hq]
      exact hx
    exact if_neg hqX
  have hrow := phaseHostTM_run (kt_payloadParts r M) ⟨none, entry⟩
    (kt_payloadRedirect X) none d (C.post i d) (C.time i d) (C.run i d hd hp) s hs
    ⟨some s, .inl false⟩ (if_pos hsX) hguard
  have hlast := phaseHostTM_run_le (kt_payloadParts r M) ⟨none, entry⟩
    (kt_payloadRedirect X) (some s) ((C.post i d).mapState fun _ => .inl false) 3
    (fun _ _ _ _ => rfl)
  refine ⟨s, hs, hrow.1, ?_⟩
  intro v hv
  rw [MultiTapeTM.runFrom_add, hrow.2]
  simpa only [Cfg.mapState_mapState] using hlast v hv

/-- The row endpoint after restoring the marker, tagged by the row's retained exit state. -/
private def kt_payloadPost {K : ℕ} {S ι : Type} {x : List Bool}
    {M : MultiTapeTM K Bool S} {entry : S} {X : Set (Option S)}
    (r : Fin K) (C : Contract M entry X ι x) (i : ι) (d : Cfg K Bool S x) :
    Cfg K Bool (Σ p, kt_payloadControl S p) x :=
  let e := C.post i d
  let z := (kt_closeContract r).post () (e.mapState fun _ => .inl false)
  ⟨e.state.map (fun s => ⟨some s, .inr true⟩), z.inputPos, z.workTapes, z.workTapePos, z.output⟩

/-- A payload row followed by marker restoration has four extra steps and cannot expose a
restoration exit earlier.

**Proof sketch.** `kt_payloadTrace` splits the run into the original row and the restoration
leaf. `kt_closeContract_spec` fixes the latter's time to three. Before dispatch the phase
indices exclude every restoration exit; afterwards the leaf's first-exit cut excludes it. -/
private theorem kt_payload_run {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool S x) (hd : d.state = some entry) (hp : C.pre i d) :
    (kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none)) (C.time i d + 4) =
        kt_payloadPost r C i d ∧
      ∀ u < C.time i d + 4,
        ((kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none)) u).state ∉
          kt_payloadExits S := by
  obtain ⟨s, hs, hfirst, hlast⟩ := kt_payloadTrace r M entry X C hnone i d hd hp
  let e : Cfg K Bool (Bool ⊕ Bool) x := (C.post i d).mapState fun _ => .inl false
  have he : e.state = some (.inl false) := by
    rw [Cfg.mapState_state, hs, Option.map_some]
  have hspec := kt_closeContract_spec r e
  have hrun := (kt_closeContract r).run () e he hspec.1
  rw [hspec.2.1] at hrun
  have hcut : ∀ u < 3, ((kt_closeTM r).runFrom e u).state ≠ some (.inr true) := by
    intro u hu h
    apply (kt_closeContract r).cut () e he hspec.1 u (by rw [hspec.2.1]; exact hu)
    simpa only [Set.image_singleton, Option.map_some, Set.mem_singleton_iff] using h
  refine ⟨?_, ?_⟩
  · have h := hlast 3 le_rfl
    rw [hrun] at h
    rw [show C.time i d + 1 + 3 = C.time i d + 4 by omega] at h
    refine h.trans ?_
    apply Cfg.ext
    · rw [Cfg.mapState_state, hspec.2.2]
      simp only [kt_payloadPost, hs, Option.map_some]
    · simp only [kt_payloadPost, e, Cfg.mapState_inputPos]
    · funext j q
      simp only [kt_payloadPost, e, Cfg.mapState_workTapes]
    · funext j
      simp only [kt_payloadPost, e, Cfg.mapState_workTapePos]
    · simp only [kt_payloadPost, e, Cfg.mapState_output]
  · intro u hu
    by_cases hle : u ≤ C.time i d
    · rw [hfirst u hle]
      rintro ⟨q, hq⟩
      exact Cfg.mapState_sigma_state_ne (Ph := kt_payloadControl S) none ⟨some q, .inr true⟩
        (by intro h; cases h) (M.runFrom d u) hq
    · obtain ⟨v, rfl⟩ : ∃ v, u = C.time i d + 1 + v :=
        ⟨u - (C.time i d + 1), by omega⟩
      rw [hlast v (by omega)]
      rintro ⟨q, hq⟩
      rw [Cfg.mapState_state] at hq
      obtain ⟨a, ha, hindex⟩ := Option.map_eq_some_iff.mp hq
      have hsq : s = q := Option.some.inj (congrArg Sigma.fst hindex)
      subst q
      have haExit : a = .inr true := sigma_mk_injective hindex
      exact hcut v (by omega) (ha.trans (congrArg some haExit))

/-- The payload adapter's run and cut from a configuration already tagged at its entry. -/
private theorem kt_payload_run_of_start {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool (Σ p, kt_payloadControl S p) x)
    (hd : d.state = some ⟨none, entry⟩) (hp : C.pre i (d.mapState fun _ => entry)) :
    (kt_payloadTM r M entry X).runFrom d (C.time i (d.mapState fun _ => entry) + 4) =
        kt_payloadPost r C i (d.mapState fun _ => entry) ∧
      ∀ u < C.time i (d.mapState fun _ => entry) + 4,
        ((kt_payloadTM r M entry X).runFrom d u).state ∉ kt_payloadExits S := by
  have hd' : (d.mapState fun _ => entry).state = some entry := by
    rw [Cfg.mapState_state, hd, Option.map_some]
  have hstart : (d.mapState fun _ => entry).mapState (Sigma.mk none) = d := by
    rw [Cfg.mapState_mapState]
    exact Cfg.mapState_eq_of_fields d _ d (by rw [hd]; rfl) rfl rfl rfl rfl
  have h := kt_payload_run r M entry X C hnone i _ hd' hp
  rwa [hstart] at h

/-- Turn a row contract into the payload-and-restoration contract.

**Proof sketch.** `kt_payload_run_of_start` supplies the exact run and first-exit cut.
`kt_payloadTrace` supplies the retained live exit. The general head-displacement bound gives
the time-derived envelope for the whole adapter. -/
private def kt_payloadContract {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X) :
    Contract (kt_payloadTM r M entry X) ⟨none, entry⟩ (kt_payloadExits S) ι x := by
  refine {
    pre := fun i d => C.pre i (d.mapState fun _ => entry)
    time := fun i d => C.time i (d.mapState fun _ => entry) + 4
    post := fun i d => kt_payloadPost r C i (d.mapState fun _ => entry)
    lo := fun i d j => d.workTapePos j - (C.time i (d.mapState fun _ => entry) + 4)
    hi := fun i d j => d.workTapePos j + (C.time i (d.mapState fun _ => entry) + 4)
    run := fun i d hd hp => (kt_payload_run_of_start r M entry X C hnone i d hd hp).1
    cut := fun i d hd hp => (kt_payload_run_of_start r M entry X C hnone i d hd hp).2
    exit_mem := ?_
    env := ?_ }
  · intro i d hd hp
    have hd' : (d.mapState fun _ => entry).state = some entry := by
      rw [Cfg.mapState_state, hd, Option.map_some]
    obtain ⟨s, hs, -, -⟩ := kt_payloadTrace r M entry X C hnone i _ hd' hp
    exact ⟨s, by simp only [kt_payloadPost, hs, Option.map_some]⟩
  · intro i d _ _ u hu j
    have h := MultiTapeTM.workTapePos_runFrom_mem_Icc (kt_payloadTM r M entry X) d u j
    have hu' : (u : ℤ) ≤ ((C.time i (d.mapState fun _ => entry) + 4 : ℕ) : ℤ) := by
      exact_mod_cast hu
    simp only [Finset.mem_Icc] at h ⊢
    constructor <;> omega

/-- The shared marker adapter: clear and advance once, dispatch into the payload adapter,
run the row, then restore the marker. -/
private def kt_markerTM {K : ℕ} {S : Type} (r : Fin K) (M : MultiTapeTM K Bool S)
    (entry : S) (X : Set (Option S)) [DecidablePred fun s => some s ∈ X] :
    MultiTapeTM K Bool (Bool ⊕ (Σ p, kt_payloadControl S p)) :=
  seamCompTM (kt_cellTM r (some none) .pos) true (kt_payloadTM r M entry X) ⟨none, entry⟩

/-- The private marker contract transformer, shared by field comparison and value copying.
Its precondition is the supplied row's precondition after the marker-clear step.

**Proof sketch.** Use `Turing.Contract.seq` to join the marker-clear cell contract to
`kt_payloadContract`. The cell contract is indexed by the caller's data, so its precondition
is exactly the payload contract's required linked precondition. -/
private def kt_markerContract {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X) :
    Contract (kt_markerTM r M entry X) (.inl false)
      (Option.map Sum.inr '' kt_payloadExits S) ι x :=
  Contract.seq
    (kt_cellContract r (some none) .pos (fun i d =>
      (kt_payloadContract r M entry X C hnone).pre i
        ((kt_cellPost r (some none) .pos d).mapState fun _ => ⟨none, entry⟩)))
    (kt_payloadContract r M entry X C hnone) id (fun _ _ _ hp => hp)

/-! ## The rows

Both rows are five-tape machines over `Bool`: tape `0` holds the table, with its head at the
origin; tape `1` the key; tape `2` the value register; tapes `3` and `4` are blank scratch tapes
(`Turing.ScratchBlank`), left blank. Every head ends where it started. -/

/-- **Keyed lookup.** From the entry, with a keyed table `es` at the head of tape `0`, a key `k`
on tape `1` and a register word `w` on tape `2`, every value of the table as long as `w`, and
blank scratch tapes: the row writes over `w` the value stored under `k`, or `|w|` zeros if `k` is
absent, and stops at its exit within `C·(L + |k| + |w| + 1)` steps and radius, where `L` is the
table's layout length. [AB09, Exercise 1.9]

**Proof sketch.** The field payloads follow their markers, so the catalog's word rows, which
need a blank at the word's offset `-1`, apply to a payload only through an adapter: blank the
marker cell (one step), run the row on the payload, now delimited, and write the marker back (one
step). An empty payload is then the empty word between two blanks. For each entry in turn:
compare its key payload with tape `1` in lockstep through the adapter (`Turing.compareTM`'s
method, returning both heads); on a match, copy the value payload to tape `2` through the adapter
(`Turing.copyTM`), return to the origin and exit; otherwise skip the entry's two fields
(`Turing.skipTM`). At the blank pair after the last field, clear tape `2` to
zeros over its own length and return to the origin. Each entry is crossed a constant number of
times. A comparison stops at the first differing cell, so it and the return of tape `1`'s head
cost at most a constant times the entry's key field plus one; summed over the entries this is
`O(L)`, and the final copy and return are `O(L + |k| + |w|)`. -/
theorem exists_keyLookupTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} (o : ℤ) (es : List (List Bool × List Bool)) (k w : List Bool)
        (d : Cfg 5 Bool S x),
        d.state = some entry → d.workTapePos 0 = o → KeyTableAt d 0 o es → WordAt d 1 k →
        WordAt d 2 w → (∀ e ∈ es, e.2.length = w.length) → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (keyTableLength es + k.length + w.length + 1))
          (C * (keyTableLength es + k.length + w.length + 1))
          { d with state := some exit,
                   workTapes :=
                     wordWrite d 2 ((keyLookup es k).getD (List.replicate w.length false)) } := by
  sorry

/-- **Keyed assignment.** From the entry, with a keyed table `es` at the head of tape `0`, a key
`k` on tape `1` and a value `v` on tape `2`, every value of the table as long as `v`, and blank
scratch tapes: the row lays out `keyAssign es k v` from the origin, overwriting the value under
`k` in place or appending `(k, v)`, and stops at its exit within `C·(L + |k| + |v| + 1)` steps
and radius, where `L` is the old table's layout length. [AB09, Exercise 1.9]

**Proof sketch.** Search as in `Turing.exists_keyLookupTM`, with its marker adapter. On a match,
copy tape `2` over the value payload through the adapter (same length, so the layout is unchanged elsewhere), and continue
the search through the rest of the table, overwriting every further match. If there was no match,
the head reaches the first blank of the pair after the table: write a separator, the field
`true :: k` from tape `1`, a separator and the field `true :: v` from tape `2`; the cells beyond
were blank (`KeyTableAt`), so the new layout's trailing blank pair is there. Return to the
origin. -/
theorem exists_keyAssignTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} (o : ℤ) (es : List (List Bool × List Bool)) (k v : List Bool)
        (d : Cfg 5 Bool S x),
        d.state = some entry → d.workTapePos 0 = o → KeyTableAt d 0 o es → WordAt d 1 k →
        WordAt d 2 v → (∀ e ∈ es, e.2.length = v.length) → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (keyTableLength es + k.length + v.length + 1))
          (C * (keyTableLength es + k.length + v.length + 1))
          { d with state := some exit, workTapes := keyTableWrite d 0 o (keyAssign es k v) } := by
  sorry

end Turing
