import TCSlib.Complexity.TuringMachine.Build.KeyTable

#print axioms Turing.exists_keyLookupTM

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let owner := `TCSlib.Complexity.TuringMachine.Build.KeyTable
  let homeOf := fun (n : Name) => match env.getModuleIdxFor? n with
    | some i => env.header.moduleNames[i.toNat]!
    | none => Name.anonymous
  let roots := env.constants.toList.filterMap fun (n, _) =>
    if homeOf n == owner && (isPrivateName n || n == `Turing.exists_keyLookupTM) then some n else none
  unless roots.length > 20 do throwError "unexpected helper census: {roots.length}"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for root in roots do
    let axs ← liftCoreM <| collectAxioms root
    let extra := axs.toList.filter fun n => !allowed.contains n
    unless extra.isEmpty do throwError "unexpected axioms for {root}: {extra}"
    logInfo m!"AXIOMS|{(privateToUserName? root).getD root}|{axs}"
  let mut todo := roots
  let mut seen : List Name := []
  let mut foreign : List Name := []
  while !todo.isEmpty do
    let n := todo.head!
    todo := todo.tail!
    if seen.contains n then continue
    seen := n :: seen
    let some info := env.find? n | continue
    todo := info.type.getUsedConstants.toList ++ todo
    if homeOf n == owner then
      if let some value := info.value? then
        todo := value.getUsedConstants.toList ++ todo
    else if (homeOf n).toString.startsWith "TCSlib." then
      if let .defnInfo di := info then
        let isAbbrev := match di.hints with | .abbrev => true | _ => false
        if !isAbbrev && !(env.isProjectionFn n) then foreign := n :: foreign
  for n in foreign.toArray.qsort Name.lt do logInfo m!"SEALHEAD|{n}"
  logInfo m!"HELPERS VERIFIED|{roots.length}|foreign heads={foreign.length}"
