/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.TuringMachine.Build.RecordTable
import TCSlib.Complexity.TuringMachine.Build.WordArith
import TCSlib.Complexity.TuringMachine.Build.InputRewind

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Keyed tables: lookup and assignment by a key held on another tape

A **keyed table** is a list of entries `(key, value)` of binary words, laid out on one work tape
in the record-table layout of `Build/RecordTable` (`Turing.TableAt`): the header `[true]`, then
for each entry the two fields `true :: key` and `true :: value`, fields separated by one blank,
two blanks before the header and after the last field. The leading `true` of each field keeps
every field nonempty, so the layout is well formed (`Turing.TableWF`) even for empty keys or
values, and a blank pair marks the table's end.

The two rows are the host of a memory: **lookup** copies the value stored under a key, held on
another tape, into a register (the all-`false` word if the key is absent), and **assignment**
overwrites the value stored under a key in place, or appends a new entry. They are the memory of
a word RAM run on a Turing machine (`WordRAM.exists_simulation`), where keys are addresses and
values are words, but they are generic in both.

The record-table rows `Turing.exists_tableFindTM` and `Turing.exists_tableAppendTM` select by a
finite-state predicate and do not read a key from another tape; they are not used here.

## Main definitions

* `Turing.keyFields`, `Turing.keyTableLength`, `Turing.KeyTableAt`: the layout.
* `Turing.keyLookup`, `Turing.keyAssign`: the two operations on lists of entries.
* `Turing.keyTableWrite`: the tapes after laying a keyed table out.

## Main results

* `Turing.exists_keyLookupTM`: lookup, within `O(table + key + value)` steps.
* `Turing.exists_keyAssignTM`: assignment, within the same bound.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (Exercise 1.9: a RAM's memory kept by a Turing machine as a
  list of address and value pairs, scanned at each access.)
-/

namespace Turing

/-! ## The layout -/

/-- **The fields of a keyed table's entries**: each entry `(k, v)` gives the two fields
`true :: k` and `true :: v`. -/
def keyFields (es : List (List Bool × List Bool)) : List (List (List Bool)) :=
  es.map fun e => [true :: e.1, true :: e.2]

/-- The fields of a keyed table's entries, as an equation. -/
theorem keyFields_def (es : List (List Bool × List Bool)) :
    keyFields es = es.map fun e => [true :: e.1, true :: e.2] := rfl

/-- **The length of a keyed table's layout**: the cells from the header's first to the last
field's last, separators included (the sentinels excluded). -/
def keyTableLength (es : List (List Bool × List Bool)) : ℕ :=
  (joinFields (tableFields [true] (keyFields es))).length

/-- The length of a keyed table's layout, as an equation. -/
theorem keyTableLength_def (es : List (List Bool × List Bool)) :
    keyTableLength es = (joinFields (tableFields [true] (keyFields es))).length := rfl

/-- **A keyed table on a tape**: tape `r` holds the record-table layout of the header `[true]`
and the entries `keyFields es` from the origin `o` (`Turing.TableAt`, with its two blank cells on
either side), and every cell after the layout is blank, so that the table can grow. -/
def KeyTableAt {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K) (o : ℤ)
    (es : List (List Bool × List Bool)) : Prop :=
  TableAt d r o [true] (keyFields es) ∧
    ∀ q : ℤ, o + (keyTableLength es : ℤ) ≤ q → d.workTapes r q = none

/-- `KeyTableAt`, as an equivalence with its definition. -/
theorem keyTableAt_iff {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (o : ℤ) (es : List (List Bool × List Bool)) :
    KeyTableAt d r o es ↔ TableAt d r o [true] (keyFields es) ∧
      ∀ q : ℤ, o + (keyTableLength es : ℤ) ≤ q → d.workTapes r q = none :=
  Iff.rfl

/-- **The tapes after laying a keyed table out**: on tape `r`, the cells `[o, o + L)` hold the
layout of `es`, `L = keyTableLength es`; every other cell, of every tape, is unchanged. -/
def keyTableWrite {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K) (o : ℤ)
    (es : List (List Bool × List Bool)) : Fin K → ℤ → Option Bool :=
  fun j q =>
    if j = r ∧ o ≤ q ∧ q < o + (keyTableLength es : ℤ)
      then fieldsTape (tableFields [true] (keyFields es)) (q - o)
    else d.workTapes j q

/-- `keyTableWrite`, as an equation. -/
theorem keyTableWrite_apply {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (o : ℤ) (es : List (List Bool × List Bool)) (j : Fin K) (q : ℤ) :
    keyTableWrite d r o es j q =
      if j = r ∧ o ≤ q ∧ q < o + (keyTableLength es : ℤ)
        then fieldsTape (tableFields [true] (keyFields es)) (q - o)
      else d.workTapes j q :=
  rfl

/-! ## The operations -/

/-- **Lookup**: the value of the first entry whose key is `k`, if any. -/
def keyLookup (es : List (List Bool × List Bool)) (k : List Bool) : Option (List Bool) :=
  (es.find? fun e => e.1 = k).map Prod.snd

/-- Lookup, as an equation. -/
theorem keyLookup_def (es : List (List Bool × List Bool)) (k : List Bool) :
    keyLookup es k = (es.find? fun e => e.1 = k).map Prod.snd := rfl

/-- **Assignment**: if some entry has the key `k`, every such entry's value becomes `v`;
otherwise the entry `(k, v)` is appended. -/
def keyAssign (es : List (List Bool × List Bool)) (k v : List Bool) :
    List (List Bool × List Bool) :=
  if es.any (fun e => e.1 = k) then es.map fun e => if e.1 = k then (k, v) else e
  else es ++ [(k, v)]

/-- Assignment, as an equation. -/
theorem keyAssign_def (es : List (List Bool × List Bool)) (k v : List Bool) :
    keyAssign es k v =
      if es.any (fun e => e.1 = k) then es.map fun e => if e.1 = k then (k, v) else e
      else es ++ [(k, v)] := rfl

/-! ## Private marker adaptation -/

attribute [local irreducible]
  Turing.RecordAt
  Turing.TableAt
  Turing.TableWF
  Turing.WordAt
  Turing.compareStop
  Turing.compareTM
  Turing.compareTM_contract
  Turing.copyTM
  Turing.copyTM_contract
  Turing.fieldOffset
  Turing.fieldsTape
  Turing.inputMoveAction
  Turing.instDecidableEqFlagPhase
  Turing.instDecidableEqSweepPhase
  Turing.joinFields
  Turing.moveInputPos
  Turing.phaseHostTM
  Turing.seamCompTM
  Turing.tableFields
  Turing.tableOffset
  Turing.tapeAction
  Turing.Cfg.inputSymbol
  Turing.Cfg.mapState
  Turing.Cfg.workTapeSymbols
  Turing.Contract.seq
  Turing.FinTM.bufferTape
  Turing.MultiTapeTM.runFrom
  Turing.MultiTapeTM.step


/-- Erase the marker under head `r` and advance that head to the payload. -/
private def kt_openMarker {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) : Cfg K Bool S x :=
  { d with
    workTapes := Function.update d.workTapes r
      (Function.update (d.workTapes r) (d.workTapePos r) none)
    workTapePos := Function.update d.workTapePos r (d.workTapePos r + 1) }

/-- Clearing a marked field's marker gives a blank-delimited payload, including when the
payload is empty.

**Proof sketch.** Read the marked word using `Turing.wordAt_iff`. The new left delimiter is
the erased cell; every nonnegative payload offset is the next cell of the marked word.
`Turing.FinTM.bufferTape_eq` and list lookup on a cons identify those cells. -/
private theorem kt_openMarker_word {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) (w : List Bool) (hw : WordAt d r (true :: w)) :
    WordAt (kt_openMarker d r) r w := by
  rw [wordAt_iff] at hw ⊢
  intro p hp hp'
  simp only [kt_openMarker, Function.update_self]
  by_cases hneg : p < 0
  · have heq : p = -1 := by omega
    subst p
    rw [show d.workTapePos r + 1 + -1 = d.workTapePos r by omega,
      Function.update_self, FinTM.bufferTape_left]
  · have hp0 : 0 ≤ p := by omega
    rw [Function.update_of_ne (show d.workTapePos r + 1 + p ≠ d.workTapePos r by omega),
      show d.workTapePos r + 1 + p = d.workTapePos r + (1 + p) by omega,
      hw (1 + p) (by omega) (by simp only [List.length_cons, Nat.cast_add, Nat.cast_one]; omega)]
    rw [FinTM.bufferTape_eq, FinTM.bufferTape_eq, if_pos (by omega), if_pos hp0,
      show (1 + p).toNat = p.toNat + 1 by omega, List.getElem?_cons_succ]

/-- Return from a payload head to its marker and restore the marker. -/
private def kt_closeMarker {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) : Cfg K Bool S x :=
  { d with
    workTapes := Function.update d.workTapes r
      (Function.update (d.workTapes r) (d.workTapePos r - 1) (some true))
    workTapePos := Function.update d.workTapePos r (d.workTapePos r - 1) }

/-- Opening and immediately closing a marked field restores the complete configuration.

**Proof sketch.** The head advances and retreats once. Both writes address the old marker
cell; the second replaces its original `some true`. All other tape cells and heads are fixed. -/
private theorem kt_closeMarker_openMarker {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K)
    (hm : d.workTapes r (d.workTapePos r) = some true) :
    kt_closeMarker (kt_openMarker d r) r = d := by
  apply Cfg.ext <;> try rfl
  · funext j q
    by_cases hj : j = r
    · subst j
      simp only [kt_closeMarker, kt_openMarker, Function.update_self, add_sub_cancel_right,
        Function.update_apply]
      split_ifs with hq
      · rw [hq]
        exact hm.symm
      · rfl
    · simp only [kt_closeMarker, kt_openMarker, Function.update_of_ne hj]
  · funext j
    by_cases hj : j = r
    · subst j
      simp only [kt_closeMarker, kt_openMarker, Function.update_self, add_sub_cancel_right]
    · simp only [kt_closeMarker, kt_openMarker, Function.update_of_ne hj]

/-- The catalog has no fixed one-cell delimiter eraser. This two-state leaf performs one
`tapeAction`, then exposes its exit; the table traversal itself uses the phase host. -/
private def kt_cellTM {K : ℕ} (r : Fin K) (wr : Option (Option Bool)) (m : SignType) :
    MultiTapeTM K Bool Bool where
  q₀ := false
  tr := fun b _ _ => if b then inputMoveAction 0 true else tapeAction r 0 wr m true

/-- The complete endpoint of the delimiter leaf, including its unchanged outer frame. -/
private def kt_cellPost {K : ℕ} {x : List Bool} (r : Fin K) (wr : Option (Option Bool))
    (m : SignType) (d : Cfg K Bool Bool x) : Cfg K Bool Bool x :=
  { d with
    state := some true
    workTapes := match wr with
      | none => d.workTapes
      | some b => Function.update d.workTapes r
          (Function.update (d.workTapes r) (d.workTapePos r) b)
    workTapePos := Function.update d.workTapePos r (d.workTapePos r + m) }

/-- The delimiter leaf has the stated one-step endpoint.

**Proof sketch.** Its entry transition is `Turing.tapeAction`. Use
`Turing.step_of_tapeAction_move` when there is no write and
`Turing.step_of_tapeAction_write` otherwise; `Turing.moveInputPos_zero` fixes the input head. -/
private theorem kt_cellTM_run {K : ℕ} {x : List Bool} (r : Fin K)
    (wr : Option (Option Bool)) (m : SignType) (d : Cfg K Bool Bool x)
    (hd : d.state = some false) :
    (kt_cellTM r wr m).runFrom d 1 = kt_cellPost r wr m d := by
  rw [MultiTapeTM.runFrom_succ_eq_step', MultiTapeTM.runFrom_zero]
  cases wr with
  | none =>
    rw [step_of_tapeAction_move (kt_cellTM r none m) d r 0 m hd rfl]
    apply Cfg.ext <;> simp only [kt_cellPost, moveInputPos_zero]
  | some b =>
    rw [step_of_tapeAction_write (kt_cellTM r (some b) m) d r 0 b m hd rfl]
    apply Cfg.ext <;> simp only [kt_cellPost, moveInputPos_zero]

/-- Package the one-cell leaf with any caller-supplied precondition.

**Proof sketch.** `kt_cellTM_run` supplies the endpoint, and the distinct Boolean entry and
exit give its first-exit cut. `Turing.MultiTapeTM.workTapePos_runFrom_mem_Icc` supplies the
one-step head envelope. -/
private def kt_cellContract {K : ℕ} {ι : Type} {x : List Bool} (r : Fin K)
    (wr : Option (Option Bool)) (m : SignType) (pre : ι → Cfg K Bool Bool x → Prop) :
    Contract (kt_cellTM r wr m) false {some true} ι x := by
  refine {
    pre := pre
    time := fun _ _ => 1
    post := fun _ d => kt_cellPost r wr m d
    lo := fun _ d j => d.workTapePos j - 1
    hi := fun _ d j => d.workTapePos j + 1
    run := fun _ d hd _ => kt_cellTM_run r wr m d hd
    exit_mem := fun _ _ _ _ => rfl
    cut := ?_
    env := ?_ }
  · intro _ d hd _ u hu
    have heq : u = 0 := by omega
    subst u
    rw [MultiTapeTM.runFrom_zero]
    simpa only [Set.mem_singleton_iff, hd, Option.some.injEq, Bool.false_eq_true] using
      not_false
  · intro _ d _ _ u hu j
    have h := MultiTapeTM.workTapePos_runFrom_mem_Icc (kt_cellTM r wr m) d u j
    have hu' : (u : ℤ) ≤ 1 := by exact_mod_cast hu
    simp only [Finset.mem_Icc] at h ⊢
    constructor <;> omega

/-- The marker-restoration leaf: move left from the payload, then restore `true`. -/
private def kt_closeTM {K : ℕ} (r : Fin K) : MultiTapeTM K Bool (Bool ⊕ Bool) :=
  seamCompTM (kt_cellTM r none .neg) true (kt_cellTM r (some (some true)) 0) false

/-- The restoration leaf's contract is the seam composition of its two cell contracts. -/
private def kt_closeContract {K : ℕ} {x : List Bool} (r : Fin K) :
    Contract (kt_closeTM r) (.inl false)
      (Option.map (Sum.inr : Bool → Bool ⊕ Bool) '' {some true}) Unit x :=
  Contract.seq
    (kt_cellContract r none .neg (fun (_ : Unit) _ => True))
    (kt_cellContract r (some (some true)) 0 (fun (_ : Unit) _ => True))
    (fun _ => ()) (fun _ _ _ _ => True.intro)

/-- Marker restoration takes three steps, has no data precondition, and changes exactly
the marker and its head.

**Proof sketch.** Read the sequential contract through `Turing.Contract.seq_pre`,
`Turing.Contract.seq_time` and `Turing.Contract.seq_post`. State relabelings keep all tape
fields; the first leaf moves left and the second writes at that cell. -/
private theorem kt_closeContract_spec {K : ℕ} {x : List Bool} (r : Fin K)
    (d : Cfg K Bool (Bool ⊕ Bool) x) :
    (kt_closeContract r).pre () d ∧ (kt_closeContract r).time () d = 3 ∧
      (kt_closeContract r).post () d =
        { kt_closeMarker d r with state := some (.inr true) } := by
  have hneg : (↑SignType.neg : ℤ) = -1 := rfl
  refine ⟨?_, ?_, ?_⟩
  · rw [kt_closeContract, Contract.seq_pre]
    trivial
  · rw [kt_closeContract, Contract.seq_time]
    rfl
  · rw [kt_closeContract, Contract.seq_post]
    apply Cfg.ext
    · simp only [kt_cellContract, kt_cellPost, Cfg.mapState_state, Option.map_some]
    · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_inputPos]
    · funext j q
      by_cases hj : j = r
      · subst j
        simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapes,
          Cfg.mapState_workTapePos, Function.update_self, hneg, ← sub_eq_add_neg,
          Function.update_apply]
      · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapes,
          Cfg.mapState_workTapePos, Function.update_of_ne hj]
    · funext j
      by_cases hj : j = r
      · subst j
        simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapePos,
          Function.update_self, SignType.coe_zero, hneg, add_zero]
        omega
      · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_workTapePos,
          Function.update_of_ne hj]
    · simp only [kt_cellContract, kt_cellPost, kt_closeMarker, Cfg.mapState_output]

/-- The payload phase uses the row's state type. Each restoration phase remembers the row's
exit state and uses the two-cell restoration controller. -/
private def kt_payloadControl (S : Type) : Option S → Type
  | none => S
  | some _ => Bool ⊕ Bool

/-- Payload and restoration routines for the existing phase host. -/
private def kt_payloadParts {K : ℕ} {S : Type} (r : Fin K) (M : MultiTapeTM K Bool S) :
    (p : Option S) → MultiTapeTM K Bool (kt_payloadControl S p)
  | none => M
  | some _ => kt_closeTM r

/-- Redirect each live row exit into its own marker-restoration phase. -/
private def kt_payloadRedirect {S : Type} (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] :
    (p : Option S) → kt_payloadControl S p → Option (Σ p, kt_payloadControl S p)
  | none, s => if some s ∈ X then some ⟨some s, .inl false⟩ else none
  | some _, _ => none

/-- Run a row at the payload and restore the marker at its exit, using `phaseHostTM`. -/
private def kt_payloadTM {K : ℕ} {S : Type} (r : Fin K) (M : MultiTapeTM K Bool S)
    (entry : S) (X : Set (Option S)) [DecidablePred fun s => some s ∈ X] :
    MultiTapeTM K Bool (Σ p, kt_payloadControl S p) :=
  phaseHostTM (kt_payloadParts r M) ⟨none, entry⟩ (kt_payloadRedirect X)

/-- Every restoration phase exposes the same local exit. Its index retains the row's verdict. -/
private def kt_payloadExits (S : Type) : Set (Option (Σ p, kt_payloadControl S p)) :=
  { q | ∃ s : S, q = some ⟨some s, .inr true⟩ }

/-- The adapter follows the row through its first exit, dispatches once, then follows the
restoration leaf. The exit value remains the restoration phase's index.

**Proof sketch.** The row contract supplies its endpoint and excludes redirects before it.
`Turing.phaseHostTM_run` gives the row segment and dispatch. The restoration phase has no
redirect, so `Turing.phaseHostTM_run_le` gives its whole segment. Concatenate with
`Turing.MultiTapeTM.runFrom_add` and `Turing.Cfg.mapState_mapState`. -/
private theorem kt_payloadTrace {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool S x) (hd : d.state = some entry) (hp : C.pre i d) :
    ∃ s : S, (C.post i d).state = some s ∧
      (∀ u ≤ C.time i d,
        (kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none)) u =
          (M.runFrom d u).mapState (Sigma.mk none)) ∧
      (∀ v ≤ 3,
        (kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none))
            (C.time i d + 1 + v) =
          ((kt_closeTM r).runFrom ((C.post i d).mapState fun _ => .inl false) v).mapState
            (Sigma.mk (some s))) := by
  have hne : (C.post i d).state ≠ none := by
    intro he
    have hx := C.exit_mem i d hd hp
    rw [he] at hx
    exact hnone hx
  obtain ⟨s, hs⟩ := Option.ne_none_iff_exists'.mp hne
  have hsX : some s ∈ X := by rw [← hs]; exact C.exit_mem i d hd hp
  have hguard : ∀ u < C.time i d, ∀ q,
      (M.runFrom d u).state = some q → kt_payloadRedirect X none q = none := by
    intro u hu q hq
    have hqX : some q ∉ X := by
      intro hx
      apply C.cut i d hd hp u hu
      rw [hq]
      exact hx
    exact if_neg hqX
  have hrow := phaseHostTM_run (kt_payloadParts r M) ⟨none, entry⟩
    (kt_payloadRedirect X) none d (C.post i d) (C.time i d) (C.run i d hd hp) s hs
    ⟨some s, .inl false⟩ (if_pos hsX) hguard
  have hlast := phaseHostTM_run_le (kt_payloadParts r M) ⟨none, entry⟩
    (kt_payloadRedirect X) (some s) ((C.post i d).mapState fun _ => .inl false) 3
    (fun _ _ _ _ => rfl)
  refine ⟨s, hs, hrow.1, ?_⟩
  intro v hv
  rw [MultiTapeTM.runFrom_add, hrow.2]
  simpa only [Cfg.mapState_mapState] using hlast v hv

/-- The row endpoint after restoring the marker, tagged by the row's retained exit state. -/
private def kt_payloadPost {K : ℕ} {S ι : Type} {x : List Bool}
    {M : MultiTapeTM K Bool S} {entry : S} {X : Set (Option S)}
    (r : Fin K) (C : Contract M entry X ι x) (i : ι) (d : Cfg K Bool S x) :
    Cfg K Bool (Σ p, kt_payloadControl S p) x :=
  let e := C.post i d
  let z := (kt_closeContract r).post () (e.mapState fun _ => .inl false)
  ⟨e.state.map (fun s => ⟨some s, .inr true⟩), z.inputPos, z.workTapes, z.workTapePos, z.output⟩

/-- A payload row followed by marker restoration has four extra steps and cannot expose a
restoration exit earlier.

**Proof sketch.** `kt_payloadTrace` splits the run into the original row and the restoration
leaf. `kt_closeContract_spec` fixes the latter's time to three. Before dispatch the phase
indices exclude every restoration exit; afterwards the leaf's first-exit cut excludes it. -/
private theorem kt_payload_run {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool S x) (hd : d.state = some entry) (hp : C.pre i d) :
    (kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none)) (C.time i d + 4) =
        kt_payloadPost r C i d ∧
      ∀ u < C.time i d + 4,
        ((kt_payloadTM r M entry X).runFrom (d.mapState (Sigma.mk none)) u).state ∉
          kt_payloadExits S := by
  obtain ⟨s, hs, hfirst, hlast⟩ := kt_payloadTrace r M entry X C hnone i d hd hp
  let e : Cfg K Bool (Bool ⊕ Bool) x := (C.post i d).mapState fun _ => .inl false
  have he : e.state = some (.inl false) := by
    rw [Cfg.mapState_state, hs, Option.map_some]
  have hspec := kt_closeContract_spec r e
  have hrun := (kt_closeContract r).run () e he hspec.1
  rw [hspec.2.1] at hrun
  have hcut : ∀ u < 3, ((kt_closeTM r).runFrom e u).state ≠ some (.inr true) := by
    intro u hu h
    apply (kt_closeContract r).cut () e he hspec.1 u (by rw [hspec.2.1]; exact hu)
    simpa only [Set.image_singleton, Option.map_some, Set.mem_singleton_iff] using h
  refine ⟨?_, ?_⟩
  · have h := hlast 3 le_rfl
    rw [hrun] at h
    rw [show C.time i d + 1 + 3 = C.time i d + 4 by omega] at h
    refine h.trans ?_
    apply Cfg.ext
    · rw [Cfg.mapState_state, hspec.2.2]
      simp only [kt_payloadPost, hs, Option.map_some]
    · simp only [kt_payloadPost, e, Cfg.mapState_inputPos]
    · funext j q
      simp only [kt_payloadPost, e, Cfg.mapState_workTapes]
    · funext j
      simp only [kt_payloadPost, e, Cfg.mapState_workTapePos]
    · simp only [kt_payloadPost, e, Cfg.mapState_output]
  · intro u hu
    by_cases hle : u ≤ C.time i d
    · rw [hfirst u hle]
      rintro ⟨q, hq⟩
      exact Cfg.mapState_sigma_state_ne (Ph := kt_payloadControl S) none ⟨some q, .inr true⟩
        (by intro h; cases h) (M.runFrom d u) hq
    · obtain ⟨v, rfl⟩ : ∃ v, u = C.time i d + 1 + v :=
        ⟨u - (C.time i d + 1), by omega⟩
      rw [hlast v (by omega)]
      rintro ⟨q, hq⟩
      rw [Cfg.mapState_state] at hq
      obtain ⟨a, ha, hindex⟩ := Option.map_eq_some_iff.mp hq
      have hsq : s = q := Option.some.inj (congrArg Sigma.fst hindex)
      subst q
      have haExit : a = .inr true := sigma_mk_injective hindex
      exact hcut v (by omega) (ha.trans (congrArg some haExit))

/-- The payload adapter's run and cut from a configuration already tagged at its entry. -/
private theorem kt_payload_run_of_start {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool (Σ p, kt_payloadControl S p) x)
    (hd : d.state = some ⟨none, entry⟩) (hp : C.pre i (d.mapState fun _ => entry)) :
    (kt_payloadTM r M entry X).runFrom d (C.time i (d.mapState fun _ => entry) + 4) =
        kt_payloadPost r C i (d.mapState fun _ => entry) ∧
      ∀ u < C.time i (d.mapState fun _ => entry) + 4,
        ((kt_payloadTM r M entry X).runFrom d u).state ∉ kt_payloadExits S := by
  have hd' : (d.mapState fun _ => entry).state = some entry := by
    rw [Cfg.mapState_state, hd, Option.map_some]
  have hstart : (d.mapState fun _ => entry).mapState (Sigma.mk none) = d := by
    rw [Cfg.mapState_mapState]
    exact Cfg.mapState_eq_of_fields d _ d (by rw [hd]; rfl) rfl rfl rfl rfl
  have h := kt_payload_run r M entry X C hnone i _ hd' hp
  rwa [hstart] at h

/-- Turn a row contract into the payload-and-restoration contract.

**Proof sketch.** `kt_payload_run_of_start` supplies the exact run and first-exit cut.
`kt_payloadTrace` supplies the retained live exit. The general head-displacement bound gives
the time-derived envelope for the whole adapter. -/
private def kt_payloadContract {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X) :
    Contract (kt_payloadTM r M entry X) ⟨none, entry⟩ (kt_payloadExits S) ι x := by
  refine {
    pre := fun i d => C.pre i (d.mapState fun _ => entry)
    time := fun i d => C.time i (d.mapState fun _ => entry) + 4
    post := fun i d => kt_payloadPost r C i (d.mapState fun _ => entry)
    lo := fun i d j => d.workTapePos j - (C.time i (d.mapState fun _ => entry) + 4)
    hi := fun i d j => d.workTapePos j + (C.time i (d.mapState fun _ => entry) + 4)
    run := fun i d hd hp => (kt_payload_run_of_start r M entry X C hnone i d hd hp).1
    cut := fun i d hd hp => (kt_payload_run_of_start r M entry X C hnone i d hd hp).2
    exit_mem := ?_
    env := ?_ }
  · intro i d hd hp
    have hd' : (d.mapState fun _ => entry).state = some entry := by
      rw [Cfg.mapState_state, hd, Option.map_some]
    obtain ⟨s, hs, -, -⟩ := kt_payloadTrace r M entry X C hnone i _ hd' hp
    exact ⟨s, by simp only [kt_payloadPost, hs, Option.map_some]⟩
  · intro i d _ _ u hu j
    have h := MultiTapeTM.workTapePos_runFrom_mem_Icc (kt_payloadTM r M entry X) d u j
    have hu' : (u : ℤ) ≤ ((C.time i (d.mapState fun _ => entry) + 4 : ℕ) : ℤ) := by
      exact_mod_cast hu
    simp only [Finset.mem_Icc] at h ⊢
    constructor <;> omega

/-- The shared marker adapter: clear and advance once, dispatch into the payload adapter,
run the row, then restore the marker. -/
private def kt_markerTM {K : ℕ} {S : Type} (r : Fin K) (M : MultiTapeTM K Bool S)
    (entry : S) (X : Set (Option S)) [DecidablePred fun s => some s ∈ X] :
    MultiTapeTM K Bool (Bool ⊕ (Σ p, kt_payloadControl S p)) :=
  seamCompTM (kt_cellTM r (some none) .pos) true (kt_payloadTM r M entry X) ⟨none, entry⟩

/-- The private marker contract transformer, shared by field comparison and value copying.
Its precondition is the supplied row's precondition after the marker-clear step.

**Proof sketch.** Use `Turing.Contract.seq` to join the marker-clear cell contract to
`kt_payloadContract`. The cell contract is indexed by the caller's data, so its precondition
is exactly the payload contract's required linked precondition. -/
private def kt_markerContract {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X) :
    Contract (kt_markerTM r M entry X) (.inl false)
      (Option.map Sum.inr '' kt_payloadExits S) ι x :=
  Contract.seq
    (kt_cellContract r (some none) .pos (fun i d =>
      (kt_payloadContract r M entry X C hnone).pre i
        ((kt_cellPost r (some none) .pos d).mapState fun _ => ⟨none, entry⟩)))
    (kt_payloadContract r M entry X C hnone) id (fun _ _ _ hp => hp)

/-- The marker-clear leaf prepares exactly `kt_openMarker`, independently of state tags.

**Proof sketch.** Compare the five configuration fields through the published state-renaming
equations. The leaf writes the same blank marker and advances by one; a live source gives the
same relabelled row entry on both sides. -/
private theorem kt_markerRowStart {K : ℕ} {S U : Type} {x : List Bool}
    (r : Fin K) (entry : S) (d : Cfg K Bool U x) (hd : d.state.isSome) :
    (kt_cellPost r (some none) .pos (d.mapState fun _ => false)).mapState (fun _ => entry) =
      (kt_openMarker d r).mapState (fun _ => entry) := by
  obtain ⟨q, hq⟩ := Option.isSome_iff_exists.mp hd
  have hpos : (↑SignType.pos : ℤ) = 1 := rfl
  apply Cfg.ext
  · simp only [kt_cellPost, kt_openMarker, Cfg.mapState_state, hq, Option.map_some]
  · simp only [kt_cellPost, kt_openMarker, Cfg.mapState_inputPos]
  · funext j z
    by_cases hj : j = r
    · subst j
      simp only [kt_cellPost, kt_openMarker, Cfg.mapState_workTapes, Cfg.mapState_workTapePos,
        Function.update_self, Function.update_apply]
    · simp only [kt_cellPost, kt_openMarker, Cfg.mapState_workTapes, Cfg.mapState_workTapePos,
        Function.update_of_ne hj]
  · funext j
    simp only [kt_cellPost, kt_openMarker, Cfg.mapState_workTapePos, Function.update_apply, hpos]
  · simp only [kt_cellPost, kt_openMarker, Cfg.mapState_output]

/-- The marker adapter requires the original row's precondition on the opened payload and
adds exactly six steps.

**Proof sketch.** Read the outer seam's precondition and time through
`Turing.Contract.seq_pre` and `Turing.Contract.seq_time`. Collapse the two state relabelings
and use `kt_markerRowStart`; the clear leaf, two dispatches and restoration add six steps. -/
private theorem kt_markerContract_pre_time {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool (Bool ⊕ (Σ p, kt_payloadControl S p)) x)
    (hd : d.state = some (.inl false)) :
    ((kt_markerContract r M entry X C hnone).pre i d ↔
      C.pre i ((kt_openMarker d r).mapState fun _ => entry)) ∧
    (kt_markerContract r M entry X C hnone).time i d =
      C.time i ((kt_openMarker d r).mapState fun _ => entry) + 6 := by
  have hd' : d.state.isSome := by rw [hd]; rfl
  constructor
  · rw [kt_markerContract, Contract.seq_pre]
    change C.pre i (((kt_cellPost r (some none) .pos (d.mapState fun _ => false)).mapState
        fun _ => (⟨none, entry⟩ : Σ p, kt_payloadControl S p)).mapState fun _ => entry) ↔ _
    rw [Cfg.mapState_mapState]
    change C.pre i ((kt_cellPost r (some none) .pos (d.mapState fun _ => false)).mapState
        fun _ => entry) ↔ _
    rw [kt_markerRowStart r entry d hd']
  · rw [kt_markerContract, Contract.seq_time]
    change 1 + 1 + (C.time i (((kt_cellPost r (some none) .pos
      (d.mapState fun _ => false)).mapState
      fun _ => (⟨none, entry⟩ : Σ p, kt_payloadControl S p)).mapState fun _ => entry) + 4) = _
    rw [Cfg.mapState_mapState]
    change 1 + 1 + (C.time i ((kt_cellPost r (some none) .pos
      (d.mapState fun _ => false)).mapState fun _ => entry) + 4) = _
    rw [kt_markerRowStart r entry d hd']
    omega

/-- The framed endpoint of a marker-adapted row: restore its marker, retreat that head,
and retain its exit value in the adapter's control. -/
private def kt_markerPost {K : ℕ} {S : Type} {x : List Bool}
    (r : Fin K) (e : Cfg K Bool S x) :
    Cfg K Bool (Bool ⊕ (Σ p, kt_payloadControl S p)) x :=
  let z := kt_closeMarker e r
  ⟨e.state.map (fun s => .inr ⟨some s, .inr true⟩), z.inputPos, z.workTapes,
    z.workTapePos, z.output⟩

/-- The restored payload endpoint has exactly the marker adapter's framed endpoint.

**Proof sketch.** `kt_closeContract_spec` identifies the restoration leaf's endpoint.
Read the state relabelings through their field equations; restoration changes the marker
and its head, and keeps every other field of the supplied row's endpoint. -/
private theorem kt_payloadPost_markerPost {K : ℕ} {S ι : Type} {x : List Bool}
    {M : MultiTapeTM K Bool S} {entry : S} {X : Set (Option S)}
    (r : Fin K) (C : Contract M entry X ι x) (i : ι) (d : Cfg K Bool S x) :
    (kt_payloadPost r C i d).mapState Sum.inr = kt_markerPost r (C.post i d) := by
  have hspec := (kt_closeContract_spec r
    ((C.post i d).mapState fun _ => .inl false)).2.2
  apply Cfg.ext
  · rw [Cfg.mapState_state]
    simp only [kt_payloadPost, kt_markerPost, Option.map_map]
    rfl
  · rw [Cfg.mapState_inputPos]
    change ((kt_closeContract r).post ()
      ((C.post i d).mapState fun _ => .inl false)).inputPos = (C.post i d).inputPos
    rw [hspec]
    simp only [kt_closeMarker, Cfg.mapState_inputPos]
  · funext j q
    rw [Cfg.mapState_workTapes]
    change ((kt_closeContract r).post ()
      ((C.post i d).mapState fun _ => .inl false)).workTapes j q =
        (kt_closeMarker (C.post i d) r).workTapes j q
    rw [hspec]
    by_cases hj : j = r
    · subst j
      simp only [kt_closeMarker, Function.update_self, Function.update_apply,
        Cfg.mapState_workTapes, Cfg.mapState_workTapePos]
    · simp only [kt_closeMarker, Function.update_of_ne hj, Cfg.mapState_workTapes]
  · funext j
    rw [Cfg.mapState_workTapePos]
    change ((kt_closeContract r).post ()
      ((C.post i d).mapState fun _ => .inl false)).workTapePos j =
        (kt_closeMarker (C.post i d) r).workTapePos j
    rw [hspec]
    simp only [kt_closeMarker, Function.update_apply, Cfg.mapState_workTapePos]
  · rw [Cfg.mapState_output]
    change ((kt_closeContract r).post ()
      ((C.post i d).mapState fun _ => .inl false)).output = (C.post i d).output
    rw [hspec]
    simp only [kt_closeMarker, Cfg.mapState_output]

/-- The shared contract's endpoint is the supplied row's endpoint with its marker restored.

**Proof sketch.** Read `Turing.Contract.seq_post` and collapse its state relabelings.
`kt_markerRowStart` identifies the row start, and `kt_payloadPost_markerPost` identifies
the complete restored endpoint. -/
private theorem kt_markerContract_post {K : ℕ} {S ι : Type} {x : List Bool}
    (r : Fin K) (M : MultiTapeTM K Bool S) (entry : S) (X : Set (Option S))
    [DecidablePred fun s => some s ∈ X] (C : Contract M entry X ι x) (hnone : none ∉ X)
    (i : ι) (d : Cfg K Bool (Bool ⊕ (Σ p, kt_payloadControl S p)) x)
    (hd : d.state = some (.inl false)) :
    (kt_markerContract r M entry X C hnone).post i d =
      kt_markerPost r (C.post i ((kt_openMarker d r).mapState fun _ => entry)) := by
  have hd' : d.state.isSome := by rw [hd]; rfl
  rw [kt_markerContract, Contract.seq_post]
  change (kt_payloadPost r C i (((kt_cellPost r (some none) .pos
    (d.mapState fun _ => false)).mapState
    fun _ => (⟨none, entry⟩ : Σ p, kt_payloadControl S p)).mapState fun _ => entry)).mapState
      Sum.inr = _
  rw [Cfg.mapState_mapState]
  change (kt_payloadPost r C i ((kt_cellPost r (some none) .pos
    (d.mapState fun _ => false)).mapState fun _ => entry)).mapState Sum.inr = _
  rw [kt_markerRowStart r entry d hd']
  exact kt_payloadPost_markerPost r C i _

/-- The adapter has finitely many controls whenever its supplied row does. -/
private instance kt_payloadControl_fintype {S : Type} [Fintype S] (p : Option S) :
    Fintype (kt_payloadControl S p) := by
  cases p <;> dsimp only [kt_payloadControl] <;> infer_instance

/-- Compare a marked field on `r` with the query word on `s` through the shared adapter. -/
private noncomputable def kt_compareTM {K : ℕ} (r s : Fin K) :
    MultiTapeTM K Bool (Bool ⊕ (Σ p, kt_payloadControl FlagPhase p)) := by
  classical
  exact kt_markerTM r (compareTM K r s) .run (Set.range fun b => some (FlagPhase.done b))

/-- The marked comparison contract is the catalog's framed comparison under the adapter. -/
private noncomputable def kt_compareContract {K : ℕ} {x : List Bool} (r s : Fin K)
    (hne : r ≠ s) :
    Contract (kt_compareTM r s) (.inl false)
      (Option.map Sum.inr '' kt_payloadExits FlagPhase) (List Bool × List Bool) x := by
  classical
  exact kt_markerContract r (compareTM K r s) .run _ (compareTM_contract r s hne x)
    (by rintro ⟨b, h⟩; cases h)

/-- Copy through the shared marker adapter. The marked field can be either source or
destination; the catalog copy contract reads only its source delimiter. -/
private noncomputable def kt_copyTM {K : ℕ} (r src dst : Fin K) :
    MultiTapeTM K Bool (Bool ⊕ (Σ p, kt_payloadControl SweepPhase p)) := by
  classical
  exact kt_markerTM r (copyTM K src dst) .sweep {some SweepPhase.done}

/-- The marked copy contract is the catalog's framed copy under the same adapter. -/
private noncomputable def kt_copyContract {K : ℕ} {x : List Bool} (r src dst : Fin K)
    (hne : src ≠ dst) :
    Contract (kt_copyTM r src dst) (.inl false)
      (Option.map Sum.inr '' kt_payloadExits SweepPhase) (List Bool) x := by
  classical
  exact kt_markerContract r (copyTM K src dst) .sweep {some SweepPhase.done}
    (copyTM_contract src dst hne x) (by intro h; cases h)

/-- State relabeling preserves a delimited word at any work head. -/
private theorem kt_wordAt_mapState {K : ℕ} {S U : Type} {x : List Bool}
    (d : Cfg K Bool S x) (f : S → U) (r : Fin K) (w : List Bool) (hw : WordAt d r w) :
    WordAt (d.mapState f) r w := by
  rw [wordAt_iff] at hw ⊢
  intro p hp hp'
  rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapes]
  exact hw p hp hp'

/-- Opening one field preserves a word delimited on a different tape. -/
private theorem kt_openMarker_word_other {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r s : Fin K) (hne : s ≠ r) (w : List Bool) (hw : WordAt d s w) :
    WordAt (kt_openMarker d r) s w := by
  rw [wordAt_iff] at hw ⊢
  intro p hp hp'
  simpa only [kt_openMarker, Function.update_of_ne hne] using hw p hp hp'

/-- Marked comparison is admissible for a marked key and an ordinary query, and takes
`2 * compareStop u v + 8` steps.

**Proof sketch.** `kt_openMarker_word` supplies the first delimiter and
`kt_openMarker_word_other` preserves the query. State relabeling preserves both words.
Apply `kt_markerContract_pre_time` to the catalog's comparison contract and read its time. -/
private theorem kt_compareContract_pre_time {K : ℕ} {x : List Bool} (r s : Fin K)
    (hne : r ≠ s) (u v : List Bool)
    (d : Cfg K Bool (Bool ⊕ (Σ p, kt_payloadControl FlagPhase p)) x)
    (hd : d.state = some (.inl false)) (hu : WordAt d r (true :: u)) (hv : WordAt d s v) :
    (kt_compareContract r s hne).pre (u, v) d ∧
      (kt_compareContract r s hne).time (u, v) d = 2 * compareStop u v + 8 := by
  classical
  have hbase := kt_markerContract_pre_time r (compareTM K r s) .run
    (Set.range fun b => some (FlagPhase.done b)) (compareTM_contract r s hne x)
    (by rintro ⟨b, h⟩; cases h) (u, v) d hd
  have hpre : (compareTM_contract r s hne x).pre (u, v)
      ((kt_openMarker d r).mapState fun _ => FlagPhase.run) := by
    rw [compareTM_contract_pre]
    exact ⟨(wordAt_iff _ _ _).mp (kt_wordAt_mapState _ _ r u (kt_openMarker_word d r u hu)),
      (wordAt_iff _ _ _).mp
        (kt_wordAt_mapState _ _ s v (kt_openMarker_word_other d r s hne.symm v hv))⟩
  refine ⟨hbase.1.mpr hpre, ?_⟩
  calc
    _ = (compareTM_contract r s hne x).time (u, v)
        ((kt_openMarker d r).mapState fun _ => FlagPhase.run) + 6 := hbase.2
    _ = 2 * compareStop u v + 8 := by rw [compareTM_contract_time]

/-- A row that changes only its state inside the marker adapter restores every tape cell,
head, input position and output of the original configuration.

**Proof sketch.** `kt_closeMarker_openMarker` restores the original physical configuration.
State relabeling and state replacement affect none of its physical fields. Read those fields
through the relabeling equations and retain the supplied exit as the adapter's exit tag. -/
private theorem kt_markerPost_openMarker {K : ℕ} {S U : Type} {x : List Bool}
    (r : Fin K) (d : Cfg K Bool U x) (entry q : S)
    (hm : d.workTapes r (d.workTapePos r) = some true) :
    kt_markerPost r { (kt_openMarker d r).mapState (fun _ => entry) with state := some q } =
      { d with state := some (.inr ⟨some q, .inr true⟩) } := by
  let e : Cfg K Bool S x :=
    { (kt_openMarker d r).mapState (fun _ => entry) with state := some q }
  have hrestore := kt_closeMarker_openMarker d r hm
  apply Cfg.ext
  · simp only [kt_markerPost, Option.map_some]
  · simp only [kt_markerPost, kt_closeMarker, kt_openMarker, Cfg.mapState_inputPos]
  · funext j z
    change (kt_closeMarker e r).workTapes j z = d.workTapes j z
    have h := congrArg (fun c : Cfg K Bool U x => c.workTapes j z) hrestore
    refine Eq.trans ?_ h
    by_cases hj : j = r
    · subst j
      simp only [e, kt_closeMarker, Cfg.mapState_workTapes, Cfg.mapState_workTapePos,
        Function.update_self, Function.update_apply]
    · simp only [e, kt_closeMarker, Cfg.mapState_workTapes, Cfg.mapState_workTapePos,
        Function.update_of_ne hj]
  · funext j
    change (kt_closeMarker e r).workTapePos j = d.workTapePos j
    have h := congrArg (fun c : Cfg K Bool U x => c.workTapePos j) hrestore
    refine Eq.trans ?_ h
    simp only [e, kt_closeMarker, Cfg.mapState_workTapePos, Function.update_apply]
  · simp only [kt_markerPost, kt_closeMarker, kt_openMarker, Cfg.mapState_output]

/-- Marked comparison returns its Boolean verdict and restores the original configuration's
entire physical frame. -/
private theorem kt_compareContract_post {K : ℕ} {x : List Bool} (r s : Fin K)
    (hne : r ≠ s) (u v : List Bool)
    (d : Cfg K Bool (Bool ⊕ (Σ p, kt_payloadControl FlagPhase p)) x)
    (hd : d.state = some (.inl false))
    (hm : d.workTapes r (d.workTapePos r) = some true) :
    (kt_compareContract r s hne).post (u, v) d =
      { d with state := some (.inr ⟨some (.done (decide (u = v))), .inr true⟩) } := by
  classical
  have h := kt_markerContract_post r (compareTM K r s) .run
    (Set.range fun b => some (FlagPhase.done b)) (compareTM_contract r s hne x)
    (by rintro ⟨b, h⟩; cases h) (u, v) d hd
  rw [compareTM_contract_post] at h
  exact h.trans (kt_markerPost_openMarker r d FlagPhase.run (.done (decide (u = v))) hm)

/-- Marked copying is admissible when the opened source is delimited, and takes
`2 * w.length + 8` steps. This covers copying out of and into a table field.

**Proof sketch.** State relabeling preserves the opened source word. Apply
`kt_markerContract_pre_time` to `Turing.copyTM_contract`, and read its source-word
precondition and its two-sweep time through the published contract equations. -/
private theorem kt_copyContract_pre_time {K : ℕ} {x : List Bool} (r src dst : Fin K)
    (hne : src ≠ dst) (w : List Bool)
    (d : Cfg K Bool (Bool ⊕ (Σ p, kt_payloadControl SweepPhase p)) x)
    (hd : d.state = some (.inl false)) (hw : WordAt (kt_openMarker d r) src w) :
    (kt_copyContract r src dst hne).pre w d ∧
      (kt_copyContract r src dst hne).time w d = 2 * w.length + 8 := by
  classical
  have hbase := kt_markerContract_pre_time r (copyTM K src dst) .sweep
    {some SweepPhase.done} (copyTM_contract src dst hne x) (by intro h; cases h) w d hd
  have hpre : (copyTM_contract src dst hne x).pre w
      ((kt_openMarker d r).mapState fun _ => SweepPhase.sweep) := by
    rw [copyTM_contract_pre]
    exact (wordAt_iff _ _ _).mp (kt_wordAt_mapState _ _ src w hw)
  refine ⟨hbase.1.mpr hpre, ?_⟩
  calc
    _ = (copyTM_contract src dst hne x).time w
        ((kt_openMarker d r).mapState fun _ => SweepPhase.sweep) + 6 := hbase.2
    _ = 2 * w.length + 8 := by rw [copyTM_contract_time]

/-! ## Private keyed-table layout facts -/

/-- The keyed table's flattened field list, with its header. -/
private def kt_fields (es : List (List Bool × List Bool)) : List (List Bool) :=
  tableFields [true] (keyFields es)

/-- Keyed tables have two nonempty fields per entry, including empty payloads. -/
private theorem kt_tableWF (es : List (List Bool × List Bool)) :
    TableWF 2 [true] (keyFields es) := by
  rw [tableWF_iff]
  refine ⟨by decide, ?_⟩
  intro e he
  rw [keyFields_def] at he
  obtain ⟨kv, _, rfl⟩ := List.mem_map.mp he
  refine ⟨rfl, ?_⟩
  intro u hu
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hu
  rcases hu with rfl | rfl <;> exact List.cons_ne_nil _ _

/-- An empty keyed table consists of its one-cell header. -/
private theorem kt_keyTableLength_nil : keyTableLength [] = 1 := by
  simp only [keyTableLength_def, keyFields_def, List.map_nil, tableFields_eq,
    List.flatten_nil, joinFields_singleton, List.length_map, List.length_cons, List.length_nil]

/-- Each entry adds its key and value payloads, two markers and two separators.

**Proof sketch.** Read the keyed layout through `Turing.keyTableLength_def`,
`Turing.keyFields_def` and `Turing.tableFields_eq`. `Turing.joinFields_length` counts field
cells and separators; adjoining the two marked fields gives the stated increment. -/
private theorem kt_keyTableLength_cons (e : List Bool × List Bool)
    (es : List (List Bool × List Bool)) :
    keyTableLength (e :: es) = e.1.length + e.2.length + 4 + keyTableLength es := by
  rw [keyTableLength_def, keyTableLength_def, tableFields_eq, tableFields_eq,
    keyFields_def, keyFields_def, List.map_cons, List.flatten_cons]
  simp only [List.cons_append, List.nil_append]
  rw [joinFields_length _ (List.cons_ne_nil _ _),
    joinFields_length _ (List.cons_ne_nil _ _)]
  simp only [List.map_cons, List.sum_cons, List.length_cons, List.length_nil]
  omega

/-- Every marked field of a keyed entry is a delimited word when the head is at its offset.

**Proof sketch.** Move only an auxiliary configuration's head to the entry offset, preserving
the table through `Turing.tableAt_iff`. `Turing.TableAt.recordAt_take` gives its two-field
record. Read that record with `Turing.recordAt_iff` and select the field using
`Turing.fieldsTape_field`; `Turing.fieldOffset_add_length_le` bounds the required cells. -/
private theorem kt_table_entry_word {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) (o : ℤ) (es : List (List Bool × List Bool))
    (ht : TableAt d r o [true] (keyFields es)) (j : ℕ) (hj : j < (keyFields es).length)
    (n : ℕ) (hn : n < ((keyFields es)[j]).length)
    (hpos : d.workTapePos r = o + tableOffset [true] (keyFields es) j +
      fieldOffset ((keyFields es)[j]) n) :
    WordAt d r ((keyFields es)[j][n]) := by
  let a : Cfg K Bool S x :=
    { d with workTapePos := Function.update d.workTapePos r (o + tableOffset [true] (keyFields es) j) }
  have hta : TableAt a r o [true] (keyFields es) := by
    rw [tableAt_iff] at ht ⊢
    exact ht
  have hlen : ((keyFields es)[j]).length = 2 :=
    ((tableWF_iff _ _ _).mp (kt_tableWF es)).2 _ (List.getElem_mem hj) |>.1
  have hrec := TableAt.recordAt_take hta (kt_tableWF es) j hj
    (by simp only [a, Function.update_self]) 2 (by decide) le_rfl
  rw [List.take_of_length_le (by omega)] at hrec
  have hspan := fieldOffset_add_length_le ((keyFields es)[j]) n hn
  have hspan' : (fieldOffset ((keyFields es)[j]) n : ℤ) +
      (((keyFields es)[j][n]).length : ℤ) ≤ (joinFields ((keyFields es)[j])).length := by
    exact_mod_cast hspan
  rw [wordAt_iff]
  intro p hp hp'
  rw [hpos, add_assoc]
  have hcell := (recordAt_iff _ _ _).mp hrec
    ((fieldOffset ((keyFields es)[j]) n : ℤ) + p) (by omega) (by omega)
  have hfield := fieldsTape_field ((keyFields es)[j]) n hn p hp hp'
  simpa only [a, Function.update_self, add_assoc] using hcell.trans hfield

/-- The fields of entry `j` are its marked key and marked value. -/
private theorem kt_keyFields_get (es : List (List Bool × List Bool)) (j : ℕ)
    (hj : j < es.length) :
    (keyFields es)[j]'(by rw [keyFields_def, List.length_map]; exact hj) =
      [true :: es[j].1, true :: es[j].2] := by
  simp only [keyFields_def, List.getElem_map]

/-- At an entry's offset, its marked key is a delimited word. -/
private theorem kt_table_key_word {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) (o : ℤ) (es : List (List Bool × List Bool))
    (ht : TableAt d r o [true] (keyFields es)) (j : ℕ) (hj : j < es.length)
    (hpos : d.workTapePos r = o + tableOffset [true] (keyFields es) j) :
    WordAt d r (true :: es[j].1) := by
  have hj' : j < (keyFields es).length := by rw [keyFields_def, List.length_map]; exact hj
  have hget := kt_keyFields_get es j hj
  have h := kt_table_entry_word d r o es ht j hj' 0 (by rw [hget]; exact Nat.zero_lt_succ 1)
    (by rw [fieldOffset_zero, Nat.cast_zero, add_zero]; exact hpos)
  simpa only [hget, List.getElem_cons_zero] using h

/-- After skipping an entry's marked key, its marked value is a delimited word. -/
private theorem kt_table_value_word {K : ℕ} {S : Type} {x : List Bool}
    (d : Cfg K Bool S x) (r : Fin K) (o : ℤ) (es : List (List Bool × List Bool))
    (ht : TableAt d r o [true] (keyFields es)) (j : ℕ) (hj : j < es.length)
    (hpos : d.workTapePos r = o + tableOffset [true] (keyFields es) j + es[j].1.length + 2) :
    WordAt d r (true :: es[j].2) := by
  have hj' : j < (keyFields es).length := by rw [keyFields_def, List.length_map]; exact hj
  have hget := kt_keyFields_get es j hj
  have hoff : fieldOffset ((keyFields es)[j]) 1 = es[j].1.length + 2 := by
    rw [hget, fieldOffset_cons_succ, fieldOffset_zero]
    simp only [List.length_cons]
  have h := kt_table_entry_word d r o es ht j hj' 1 (by rw [hget]; exact Nat.lt_succ_self 1)
    (by simpa only [hoff, Nat.cast_add, Nat.cast_ofNat, add_assoc] using hpos)
  simpa only [hget, List.getElem_cons_succ, List.getElem_cons_zero] using h

/-! ## The rows

Both rows are five-tape machines over `Bool`: tape `0` holds the table, with its head at the
origin; tape `1` the key; tape `2` the value register; tapes `3` and `4` are blank scratch tapes
(`Turing.ScratchBlank`), left blank. Every head ends where it started. -/

/-- **Keyed lookup.** From the entry, with a keyed table `es` at the head of tape `0`, a key `k`
on tape `1` and a register word `w` on tape `2`, every value of the table as long as `w`, and
blank scratch tapes: the row writes over `w` the value stored under `k`, or `|w|` zeros if `k` is
absent, and stops at its exit within `C·(L + |k| + |w| + 1)` steps and radius, where `L` is the
table's layout length. [AB09, Exercise 1.9]

**Proof sketch.** The field payloads follow their markers, so the catalog's word rows, which
need a blank at the word's offset `-1`, apply to a payload only through an adapter: blank the
marker cell (one step), run the row on the payload, now delimited, and write the marker back (one
step). An empty payload is then the empty word between two blanks. For each entry in turn:
compare its key payload with tape `1` in lockstep through the adapter (`Turing.compareTM`'s
method, returning both heads); on a match, copy the value payload to tape `2` through the adapter
(`Turing.copyTM`), return to the origin and exit; otherwise skip the entry's two fields
(`Turing.skipTM`). At the blank pair after the last field, clear tape `2` to
zeros over its own length and return to the origin. Each entry is crossed a constant number of
times. A comparison stops at the first differing cell, so it and the return of tape `1`'s head
cost at most a constant times the entry's key field plus one; summed over the entries this is
`O(L)`, and the final copy and return are `O(L + |k| + |w|)`. -/
theorem exists_keyLookupTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} (o : ℤ) (es : List (List Bool × List Bool)) (k w : List Bool)
        (d : Cfg 5 Bool S x),
        d.state = some entry → d.workTapePos 0 = o → KeyTableAt d 0 o es → WordAt d 1 k →
        WordAt d 2 w → (∀ e ∈ es, e.2.length = w.length) → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (keyTableLength es + k.length + w.length + 1))
          (C * (keyTableLength es + k.length + w.length + 1))
          { d with state := some exit,
                   workTapes :=
                     wordWrite d 2 ((keyLookup es k).getD (List.replicate w.length false)) } := by
  sorry

/-- **Keyed assignment.** From the entry, with a keyed table `es` at the head of tape `0`, a key
`k` on tape `1` and a value `v` on tape `2`, every value of the table as long as `v`, and blank
scratch tapes: the row lays out `keyAssign es k v` from the origin, overwriting the value under
`k` in place or appending `(k, v)`, and stops at its exit within `C·(L + |k| + |v| + 1)` steps
and radius, where `L` is the old table's layout length. [AB09, Exercise 1.9]

**Proof sketch.** Search as in `Turing.exists_keyLookupTM`, with its marker adapter. On a match,
copy tape `2` over the value payload through the adapter (same length, so the layout is unchanged elsewhere), and continue
the search through the rest of the table, overwriting every further match. If there was no match,
the head reaches the first blank of the pair after the table: write a separator, the field
`true :: k` from tape `1`, a separator and the field `true :: v` from tape `2`; the cells beyond
were blank (`KeyTableAt`), so the new layout's trailing blank pair is there. Return to the
origin. -/
theorem exists_keyAssignTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} (o : ℤ) (es : List (List Bool × List Bool)) (k v : List Bool)
        (d : Cfg 5 Bool S x),
        d.state = some entry → d.workTapePos 0 = o → KeyTableAt d 0 o es → WordAt d 1 k →
        WordAt d 2 v → (∀ e ∈ es, e.2.length = v.length) → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (keyTableLength es + k.length + v.length + 1))
          (C * (keyTableLength es + k.length + v.length + 1))
          { d with state := some exit, workTapes := keyTableWrite d 0 o (keyAssign es k v) } := by
  sorry

end Turing
