from pathlib import Path
import contextlib, hashlib, importlib.util, json, subprocess, sys, datetime

ROOT = Path(__file__).resolve().parents[3]
LOGS = ROOT / 'evidence/logs/r2'
BASE = '7342f98b58704d6c25faf668ed1a64ea0b27c4af'
OWNER = 'TCSlib.Complexity.TuringMachine.Build.KeyTable'
spec = importlib.util.spec_from_file_location('checks', ROOT / 'evidence/runtime/r2/checks.py')
checks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checks)
modules = {p.relative_to(ROOT).with_suffix('').as_posix().replace('/', '.'): p
    for p in (ROOT / 'TCSlib').rglob('*.lean')}
modules['TCSlib'] = ROOT / 'TCSlib.lean'
imports = {}
for module, path in modules.items():
    names = []
    for line in path.read_text().splitlines():
        if line.startswith('import '):
            names.extend(line.split('--', 1)[0].split()[1:])
    imports[module] = names
seen, order = set(), []
def visit(module):
    if module in seen or module not in modules:
        return
    seen.add(module)
    for name in imports[module]:
        visit(name)
    order.append(module)
for root in ['TCSlib.Complexity.RAMSimulation', 'TCSlib.Complexity.TuringMachine', 'TCSlib']:
    visit(root)
affected = {OWNER}
while True:
    more = affected | {m for m in order if any(n in affected for n in imports[m])}
    if more == affected:
        break
    affected = more
affected_order = [m for m in order if m in affected]
dirty = subprocess.check_output(['git', 'diff', BASE, '--name-only', '--', 'TCSlib', 'TCSlib.lean'], cwd=ROOT, text=True).splitlines()
assert dirty == [OWNER.replace('.', '/') + '.lean'], dirty
hashes = {m: hashlib.sha256(modules[m].read_bytes()).hexdigest() for m in order}
(LOGS / 'downstream-full-order.txt').write_text('\n'.join(order) + '\n')
(LOGS / 'downstream-all-importers.txt').write_text('\n'.join(affected_order) + '\n')
cached = [m for m in order if (checks.OLEANS / (m.replace('.', '/') + '.olean')).is_file()]
missing = [m for m in order if m not in cached]
(LOGS / 'downstream-missing-order.txt').write_text('\n'.join(missing) + '\n')
(LOGS / 'downstream-source-provenance.json').write_text(json.dumps(dict(base=BASE,
    only_library_diff=dirty, source_sha256=hashes, cached_from_own_bootstrap=cached), indent=2) + '\n')
owner_hash = hashes[OWNER]
compiled = []
started = checks.stamp()
print(f'Downstream replay: {len(affected_order)} affected modules; {len(order)} modules in full facade closure; {len(missing)} fresh prerequisites/checks.', flush=True)
def summary(passed, failed=None):
    value = dict(passed=passed, failed=failed, start=started, end=checks.stamp(),
        owner_sha256=owner_hash, affected_modules=affected_order, full_closure=len(order),
        compiled_count=len(compiled), compiled=compiled, own_bootstrap_count=len(cached))
    (LOGS / 'final-downstream-summary.json').write_text(json.dumps(value, indent=2) + '\n')
    return value
with (LOGS / 'downstream-driver.log').open('w') as driverlog:
    for index, module in enumerate(missing):
        assert hashlib.sha256(modules[module].read_bytes()).hexdigest() == hashes[module]
        for name in imports[module]:
            if name in modules:
                product = checks.OLEANS / (name.replace('.', '/') + '.olean')
                assert product.is_file() and product.stat().st_size > 0, (module, name)
        source = module.replace('.', '/') + '.lean'
        label = f'downstream-{index:04d}-' + module.removeprefix('TCSlib.').replace('.', '-')
        with contextlib.redirect_stdout(driverlog):
            passed = checks.check(label, source, True)
        driverlog.flush()
        if not passed:
            result = summary(False, module)
            print(json.dumps(result), flush=True)
            print((LOGS / (label + '.log')).read_text()[-14000:], flush=True)
            sys.exit(1)
        compiled.append(module)
        progress = dict(completed=len(compiled), total=len(missing), last=module, time=checks.stamp(),
            affected_done=[m for m in affected_order if m in cached or m in compiled])
        (LOGS / 'downstream-progress.json').write_text(json.dumps(progress, indent=2) + '\n')
        if module in affected or len(compiled) % 25 == 0:
            print(json.dumps(progress), flush=True)
assert all(hashlib.sha256(modules[m].read_bytes()).hexdigest() == hashes[m] for m in order)
assert owner_hash == json.loads((LOGS / 'seal-09-source.json').read_text())['source_sha256']
result = summary(True)
print(f"DOWNSTREAM PASS: {result['compiled_count']} fresh modules, {len(affected_order)} affected modules, entire {len(order)}-module facade closure.", flush=True)
