from pathlib import Path
import hashlib, json, shutil, subprocess

ROOT = Path(__file__).resolve().parents[3]
LOGS = ROOT / 'evidence/logs/r2'
EXCHANGE = Path((ROOT / 'evidence/runtime/r2/exchange-delivery-path.txt').read_text().strip())
BRANCH = 'exchange/pass-shelat-ch5-8'
NAME = 'fill-ram-key-table-r2.zip'
REL = 'arora-barak-ch3-4/inbox/fill-ram-key-table/' + NAME
SOURCE = ROOT / 'evidence/deliveries' / NAME
assert SOURCE.is_file()
pack = json.loads((LOGS / 'final-package.json').read_text())
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == pack['sha256']
with (LOGS / 'final-exchange-delivery.log').open('w') as log:
    def run(args, required=True):
        log.write('COMMAND ' + repr(args) + '\n')
        log.flush()
        r = subprocess.run(args, cwd=EXCHANGE, text=True, stdout=log, stderr=subprocess.STDOUT)
        log.write('EXIT ' + str(r.returncode) + '\n')
        log.flush()
        if required and r.returncode:
            raise SystemExit(r.returncode)
        return r.returncode
    def read(args):
        return subprocess.check_output(args, cwd=EXCHANGE, text=True).strip()
    assert read(['git', 'branch', '--show-current']) == BRANCH
    assert read(['git', 'status', '--porcelain']) == ''
    run(['git', 'pull', '--rebase', 'origin', BRANCH])
    target = EXCHANGE / REL
    assert not target.exists(), 'Do not replace a previously delivered archive'
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, target)
    run(['git', 'add', '--', REL])
    run(['git', 'commit', '--only', REL, '-m', 'Deliver completed keyed-table round-2 fill'])
    pushed = False
    for attempt in range(3):
        run(['git', 'pull', '--rebase', 'origin', BRANCH])
        commit = read(['git', 'rev-parse', 'HEAD'])
        assert read(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit]) == REL
        assert read(['git', 'diff', '--name-only', 'FETCH_HEAD', 'HEAD']) == REL
        if run(['git', 'push', 'origin', 'HEAD:' + BRANCH], required=False) == 0:
            pushed = True
            break
    assert pushed, 'Exchange push did not succeed; no force push attempted'
    run(['git', 'fetch', 'origin', BRANCH])
    remote = read(['git', 'rev-parse', 'FETCH_HEAD'])
    delivered = subprocess.check_output(['git', 'show', remote + ':' + REL], cwd=EXCHANGE)
    assert delivered == SOURCE.read_bytes()
    assert read(['git', 'status', '--porcelain']) == ''
    result = dict(commit=commit, observed_remote_commit=remote, path=REL,
        sha256=hashlib.sha256(delivered).hexdigest(), remote_blob_verified=True,
        changed_paths=[REL], source_commit=pack['source_commit'])
    (LOGS / 'final-exchange-delivery.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
