# Keyed-table fill, round 2 — checkpoint 1

This is a progress checkpoint. The goal remains active; assignment and final downstream checks
are still outstanding. It is not the final `fill-ram-key-table-r2.zip` delivery.

- Repository: Shilun-Allan-Li/tcslib.
- Read-only base: `7342f98b58704d6c25faf668ed1a64ea0b27c4af` (ram/readers-2, PR #375).
- Rules/brief: `e40383d88d79e23026c95e20608ee8827d45e59b`, COMMON.md including its tier 2 addendum.
- Local proof branch: `codex/fill-ram-key-table-r2`, never rebased or pushed.
- Source checkpoint: `1d65b34f0239e95af4876780b073d235b665d241`.
- Owned file SHA256: `4c58218f0fba855c720cef6269fd810efa23aff811134f1dcff4a51ace3c913a`.

## Targets and frontier

| Target | Status | Evidence |
|---|---|---|
| `Turing.exists_keyLookupTM` | Proved, frozen statement | Native116, full seal07, metadata02 |
| `Turing.exists_keyAssignTM` | Original sorry remains | Controller and shared entry scan are proved; whole assignment layout invariant and append run remain |

Lookup uses the finite shared phase host, one private marker contract transformer for comparison
and copying, catalog contracts placed with Contract.inPhase, and an induction on the unvisited
entry suffix. Entry costs telescope through the table offsets. The complete row has C = 64.
Its final anchor cannot be revisited, giving the first-exit cut; the model's head bound gives
radius at most the same time bound. The only remaining admission is assignment's original body.
No theorem statement, original definition, or unproved target sketch changed. The lookup sketch
was rewritten to describe the actual proof. The source-freeze check also compares the remaining
pre-existing source byte for byte after restoring only lookup's allowed body and sketch.

## Validation of this checkpoint

| Check | Exit | Result |
|---|---|---|
| `keytable-116-zero-footprint-split` | 0 | Fresh native owner olean; only assignment has a sorry warning |
| `lookup-metadata-02` | 0 | Lookup plus all private generated/explicit constants audited; 527 roots |
| `lookup-seal-07` | 0 | Entire new proof block and lookup re-elaborated with all 47 foreign heads irreducible |
| Source freeze and `git diff --check` | 0 | Both target statements byte-identical; no whitespace errors |

`#print axioms Turing.exists_keyLookupTM`:

```text
[propext, Classical.choice, Quot.sound]
```

There is no sorryAx and no admitted dependency, including no admitted RecordTable or WordArith
row. The required admitted-declaration walk is therefore empty. `LookupMetadata.lean` calls
collectAxioms on every root and fails for any axiom outside the three standard ones. The full
root list and axiom output are included. Downstream Sim/*, Simulation, Classes and facades have
not yet been replayed for this checkpoint; that replay is required for the final delivery.
Developmental failed checks remain in the logs for diagnosis. The success labels above identify
the evidence for this exact source; seal-07-source.json binds the sealed copy to the owner hash.

## Scope, readers and reuse

Only the owned library file is in the patch. The added existing import Build/InputRewind supplies
Cfg.mapState_mapState, used to compose state relabelings. No new public declaration, public
reader, axiom, simp attribute, or admitted dependency was added. Original private rt_* lemmas and
admitted RecordTable rows are never cited. Published PR #375 readers are used directly.

All 122 explicitly named private declarations and their actual roles are listed in
[INVENTORY.md](INVENTORY.md). Generated equations, matchers, recursors and derived instances are
included in [AUDITED-CONSTANTS.txt](AUDITED-CONSTANTS.txt) and the metadata log. Each of the
47 reached foreign definitions and its reading interface is in
[FOREIGN-READERS.md](FOREIGN-READERS.md). The file has 2409 lines; the tier 2
size exception explicitly permits continuing beyond 1,500 lines and leaving the split to landing.
The unused prepared raw-contract family is retained as assignment scaffolding at this checkpoint;
it can be removed before final delivery if assignment does not consume it.

Existing facts were searched in the bootstrapped import closure before adding helpers:

- Marker adaptation: Catalog's framed compare/copy rows, Contract.seq/inPhase, Seam's phaseHostTM
  run theorems, StateRenaming/CfgFacts field interfaces and InputRewind's map composition. Only a
  missing fixed one-cell delimiter eraser requires a raw leaf; the same leaf is reused to restore
  markers and write append markers. No replacement catalog machine was built.
- Layout: RecordTable's tableFields/tableWF/tableAt readers, TableAt.recordAt_take, tableOffset_eq
  and tableOffset_length; Catalog's fieldsTape_field, field offsets and public layout equations.
  Private rt_* facts were excluded. Keyed arithmetic and marker corollaries bridge these APIs.
- Zeroing: public mealyRun_nil/cons and scanResult_eq plus scanTM_contract; no word-arithmetic
  admission. WordAt and wordWrite helpers read only wordAt_iff and wordWrite_apply.
- Traversal: skipTM_contract, compareTM_contract, copyTM_contract and tableRewindTM_run_ofCfg,
  all placed through the shared phase helper. The Segment/SafeSegment/RoundContract interfaces
  were inspected; exact run concatenation and a non-revisited final anchor give the needed row
  without duplicating their envelope composition. Mathematical lookup uses List.find?_cons
  and List.drop_eq_getElem_cons, not another transition-table argument.

Patch statistics against the base:

```text
.../Complexity/TuringMachine/Build/KeyTable.lean   | 2244 +++++++++++++++++++-
 1 file changed, 2231 insertions(+), 13 deletions(-)
```

Thirty unrelated dirty blueprint files predated this work and were preserved, not staged or
included in this patch or archive. All code checkpoints so far are local only.

## Environment and process record

Native macOS, pinned Lean v4.25.0. Preflight recorded 12 CPUs, 18 GiB physical RAM, 59% available
memory by memory_pressure, and approximately 111 GiB free disk. Native sysctl/vm_stat/time -l
replace unavailable Linux diagnostics. Package URLs/revisions match lake-manifest.json; the
package directory is a pin-verified symlink to the existing cache. No lake build was run.
The base import closure was built fresh in our own `.lake/fill-ram-key-table-r2-oleans` tree:
38 original modules plus the added existing InputRewind module. Other fills' oleans are not used.
All checks run through the campaign leanelab wrappers with TCSLIB_LEAN_SLOTS=3, nice -n10 and -j4.
The driver records machine-wide executable counts and waits before launching when the count is
at least three. It now also holds an OS per-fill fcntl lock for each complete check and deletes
an old olean before recompiling. Process counts/waits and command exit codes are included.

An actual process-control deviation occurred: keytable-55 and -56 overlapped after a still-running
session was mistaken for a terminal result. Two own Lean processes ran concurrently for about
130 seconds; the recorded machine-wide count was two. Both checks failed, both products were
discarded, and no olean remained. They were never used as dependency evidence. The overlap and
resource recheck are logged; a per-fill lock was added, and the fresh serial check57 plus all
subsequent successful checks supersede them. This deviation did not end the fill.
Delivery uses a separate sparse exchange checkout backed by existing local Git objects; the
shared exchange checkout and its pending files from other fills remain untouched.

## Remaining work

Complete assignment's equal-width table rewrite invariant, all-match scan and absent-key append
through the existing shared adapter/controller; prove its frozen target; remove unused scaffolding;
re-run native, axioms, seals and the complete downstream closure; deliver the final round-2 zip.
The goal stays active while this work continues.

## Archive contents

REPORT.md, INVENTORY.md, FOREIGN-READERS.md, AUDITED-CONSTANTS.txt, the owned file at its normal
repository path, a patch against the base, all round-2 logs, all versioned round-2 Lean probes,
and the check/package driver scripts. MANIFEST.sha256 covers every archive file other than itself.
