# Named private declarations

All are in the owned file. Generated equations, recursors, matchers and derived instances are included in AUDITED-CONSTANTS.txt and the full metadata log.

| Name | Kind | Role |
|---|---|---|
| `kt_openMarker` | def | Erase the marker under head `r` and advance that head to the payload. |
| `kt_openMarker_word` | theorem | Clearing a marked field's marker gives a blank-delimited payload, including when the payload is empty. |
| `kt_closeMarker` | def | Return from a payload head to its marker and restore the marker. |
| `kt_closeMarker_openMarker` | theorem | Opening and immediately closing a marked field restores the complete configuration. |
| `kt_cellTM` | def | The catalog has no fixed one-cell delimiter eraser. This two-state leaf performs one `tapeAction`, then exposes its exit; the table traversal itself uses the phase host. |
| `kt_cellPost` | def | The complete endpoint of the delimiter leaf, including its unchanged outer frame. |
| `kt_cellTM_run` | theorem | The delimiter leaf has the stated one-step endpoint. |
| `kt_cellTM_park` | theorem | The cell leaf's true control parks forever without changing any physical field. |
| `kt_cellContract` | def | Package the one-cell leaf with any caller-supplied precondition. |
| `kt_closeTM` | def | The marker-restoration leaf: move left from the payload, then restore `true`. |
| `kt_closeContract` | def | The restoration leaf's contract is the seam composition of its two cell contracts. |
| `kt_closeContract_spec` | theorem | Marker restoration takes three steps, has no data precondition, and changes exactly the marker and its head. |
| `kt_payloadControl` | def | The payload phase uses the row's state type. Each restoration phase remembers the row's exit state and uses the two-cell restoration controller. |
| `kt_payloadParts` | def | Payload and restoration routines for the existing phase host. |
| `kt_payloadRedirect` | def | Redirect each live row exit into its own marker-restoration phase. |
| `kt_payloadTM` | def | Run a row at the payload and restore the marker at its exit, using `phaseHostTM`. |
| `kt_payloadExits` | def | Every restoration phase exposes the same local exit. Its index retains the row's verdict. |
| `kt_payloadTrace` | theorem | The adapter follows the row through its first exit, dispatches once, then follows the restoration leaf. The exit value remains the restoration phase's index. |
| `kt_payloadPost` | def | The row endpoint after restoring the marker, tagged by the row's retained exit state. |
| `kt_payload_run` | theorem | A payload row followed by marker restoration has four extra steps and cannot expose a restoration exit earlier. |
| `kt_payload_run_of_start` | theorem | The payload adapter's run and cut from a configuration already tagged at its entry. |
| `kt_payloadContract` | def | Turn a row contract into the payload-and-restoration contract. |
| `kt_markerTM` | def | The shared marker adapter: clear and advance once, dispatch into the payload adapter, run the row, then restore the marker. |
| `kt_markerContract` | def | The private marker contract transformer, shared by field comparison and value copying. Its precondition is the supplied row's precondition after the marker-clear step. |
| `kt_markerRowStart` | theorem | The marker-clear leaf prepares exactly `kt_openMarker`, independently of state tags. |
| `kt_markerContract_pre_time` | theorem | The marker adapter requires the original row's precondition on the opened payload and adds exactly six steps. |
| `kt_markerPost` | def | The framed endpoint of a marker-adapted row: restore its marker, retreat that head, and retain its exit value in the adapter's control. |
| `kt_payloadPost_markerPost` | theorem | The restored payload endpoint has exactly the marker adapter's framed endpoint. |
| `kt_markerContract_post` | theorem | The shared contract's endpoint is the supplied row's endpoint with its marker restored. |
| `kt_payloadControl_fintype` | instance | The adapter has finitely many controls whenever its supplied row does. |
| `kt_compareTM` | def | Compare a marked field on `r` with the query word on `s` through the shared adapter. |
| `kt_compareContract` | def | The marked comparison contract is the catalog's framed comparison under the adapter. |
| `kt_copyTM` | def | Copy through the shared marker adapter. The marked field can be either source or destination; the catalog copy contract reads only its source delimiter. |
| `kt_copyContract` | def | The marked copy contract is the catalog's framed copy under the same adapter. |
| `kt_wordAt_mapState` | theorem | State relabeling preserves a delimited word at any work head. |
| `kt_openMarker_word_other` | theorem | Opening one field preserves a word delimited on a different tape. |
| `kt_compareContract_pre_time` | theorem | Marked comparison is admissible for a marked key and an ordinary query, and takes `2 * compareStop u v + 8` steps. |
| `kt_markerPost_openMarker` | theorem | A row that changes only its state inside the marker adapter restores every tape cell, head, input position and output of the original configuration. |
| `kt_compareContract_post` | theorem | Marked comparison returns its Boolean verdict and restores the original configuration's entire physical frame. |
| `kt_copyContract_pre_time` | theorem | Marked copying is admissible when the opened source is delimited, and takes `2 * w.length + 8` steps. This covers copying out of and into a table field. |
| `kt_copy_row_post` | theorem | The catalog copy endpoint is exactly the word overwrite used by the keyed-table rows. |
| `kt_markerWrite` | def | The payload overwrite of an adapted copy. Only the marked tape's payload head is advanced, so this describes both copy directions and appending into the blank tail. |
| `kt_copyContract_post` | theorem | An adapted copy restores the marker and every head and overwrites exactly its payload or the ordinary destination word, according to the copy direction. |
| `kt_markerWrite_other` | theorem | If the destination is not marked, the adapted overwrite is the ordinary word overwrite. |
| `kt_markerWrite_word` | theorem | Overwriting a marked payload with an equally long word preserves both delimiters and yields the new marked word. |
| `kt_wordWrite_word` | theorem | An equally sized word overwrite preserves both delimiters of an ordinary word. |
| `kt_wordAt_marker` | theorem | A marked word exposes its leading true bit at the current head. |
| `kt_wordWrite_state` | theorem | Changing only the control does not change a word overwrite. |
| `kt_tableWF` | theorem | Keyed tables have two nonempty fields per entry, including empty payloads. |
| `kt_keyTableLength_nil` | theorem | An empty keyed table consists of its one-cell header. |
| `kt_keyTableLength_cons` | theorem | Each entry adds its key and value payloads, two markers and two separators. |
| `kt_table_entry_word` | theorem | Every marked field of a keyed entry is a delimited word when the head is at its offset. |
| `kt_keyFields_get` | theorem | The fields of entry `j` are its marked key and marked value. |
| `kt_table_key_word` | theorem | At an entry's offset, its marked key is a delimited word. |
| `kt_table_value_word` | theorem | After skipping an entry's marked key, its marked value is a delimited word. |
| `kt_entries_ne_nil` | theorem | Every keyed entry has a nonempty list of fields. |
| `kt_tableOffset_endpoints` | theorem | Entry zero starts after the header and its separator; the terminal entry offset is the second trailing blank, one cell after the layout's length. |
| `kt_tableOffset_succ` | theorem | Advancing past one key and value reaches the next entry's offset. |
| `kt_tableOffset_le_end` | theorem | Every entry offset, including a saturated index, is at most the terminal offset. |
| `kt_table_header_word` | theorem | At the table origin, its header is the delimited one-bit word `[true]`. |
| `kt_markerExit` | def | Read an adapter's retained exit, and return none at every internal control. |
| `kt_markerExit_none_iff` | theorem | An adapter control is internal exactly when it is outside the contract's exit set. |
| `kt_TablePhase` | inductive | The finite controller shared by lookup and assignment. The inspection flag records whether assignment has already found a matching key. |
| `kt_zeroStep` | def | A constant-zero transducer on the register word. |
| `kt_tableControl` | def | Each controller phase runs an existing catalog routine or the shared marker adapter. |
| `kt_tableParts` | def | The phase routines of the five-tape table machine. `assign = false` copies values out; `assign = true` copies the register into matched fields. The end test compares with the blank scratch word, so its stop is zero for both a marked field and the blank end. |
| `kt_tableRedirect` | def | The phase redirects implement first-match lookup or all-match assignment. Assignment remembers a match until the end, appending only when its flag is still false. |
| `kt_TableState` | abbrev | The table machine's complete finite control. |
| `kt_tableControl_fintype` | instance | Every phase has a finite local state type. |
| `kt_tableTM` | def | The five-tape keyed table controller, assembled with the existing phase host. Its Boolean parameter selects lookup or assignment; its state type is independent of every word width. |
| `kt_tableExits` | def | Local exits at which each catalog row dispatches to its next controller phase. |
| `kt_table_guards` | theorem | Every local exit dispatches to a different phase, and no internal state dispatches. |
| `kt_phaseContract` | def | Place a row contract in the shared table controller using the published phase-host adapter. Every redirect target must belong to a different phase. |
| `kt_phase_run` | theorem | Run any catalog contract in its controller phase, including the one dispatch step. The local endpoint is read through the public `Contract.inPhase` field equations. |
| `kt_rewindContract` | def | The published table-rewind row, packaged as a framed contract for the final phase. |
| `kt_phaseData` | def | Data supplied to each local catalog contract. |
| `kt_phaseEntry` | def | Entry control of each local catalog contract. |
| `kt_copyValue_ne` | theorem | Copying into the table and copying out of it always use different tapes. |
| `kt_rawContract` | def | The controller's local contracts are exactly the published catalog contracts, with the shared marker transformer at comparison and copying and the framed published rewind row. |
| `kt_zero_mealy` | theorem | The constant-zero transducer preserves length and replaces every bit by false. |
| `kt_zero_scanResult` | theorem | Both passes of the zero scan leave exactly the same-length zero word. |
| `kt_zero_contract_post` | theorem | The catalog zero scan writes only the register's original interval and returns all heads. |
| `kt_at` | def | A controller configuration with a chosen control and table head, all other physical fields supplied by one fixed configuration. |
| `kt_at_at` | theorem | Reframing twice keeps only the last chosen controller state and table head. |
| `kt_wordWrite_at_other` | theorem | Moving only the table head preserves a word overwrite on any other tape. |
| `kt_SkipKind` | inductive | The five uses of a field skip differ only in their controller continuation. |
| `kt_skipPhase` | def | The controller phase of a field skip. |
| `kt_afterSkip` | def | The continuation of each use of the same field skip. |
| `kt_skip_run` | theorem | Every field skip takes its word length plus two steps, dispatch included, and preserves all cells while advancing to the next field. |
| `kt_inspect_run` | theorem | Inspecting a field against the blank scratch word takes three steps, dispatch included, and changes only the controller state. |
| `kt_compare_run` | theorem | The comparison phase restores its complete physical frame and dispatches the verdict into the following key skip. |
| `kt_CopyKind` | inductive | The three uses of the shared adapted copy. |
| `kt_copyPhase` | def | Controller phase of an adapted copy. |
| `kt_copySrc` | def | Source tape of each adapted copy. |
| `kt_copyDst` | def | Destination tape of each adapted copy. |
| `kt_afterCopy` | def | Every adapted copy returns to a skip of the field just read or written. |
| `kt_copyKind_ne` | theorem | Every use of copying has distinct source and destination tapes. |
| `kt_mapState_workTapes` | theorem | Read the complete tape vector of a state relabeling through its pointwise public reader. |
| `kt_copy_run` | theorem | Each copy phase takes twice the payload length plus nine steps, including dispatch, returns every head, and overwrites exactly the adapted destination interval. |
| `kt_rewind_run` | theorem | The final rewind from the second blank after a keyed table returns to its origin, leaving every cell fixed, in the layout length plus nine steps. |
| `kt_zero_run` | theorem | The zero-register phase keeps its word width and dispatches to the final rewind. |
| `kt_match` | def | Whether this entry is copied: assignment tests every entry; lookup tests until its first match and then only skips the remaining fields. |
| `kt_searchKey_run` | theorem | Inspect and, when needed, compare one entry's key; the whole physical frame is restored. |
| `kt_valueWrite` | def | The overwrite at a matched value: into the marked payload for assignment, or into the ordinary register word for lookup. |
| `kt_valuePost` | def | The framed result of processing a value and advancing to the next entry. |
| `kt_value_run` | theorem | Process one value, copying it only when matched, and skip to the next entry. |
| `kt_entryPost` | def | The result of one entry scan, expressed through the common value-step frame. |
| `kt_entry_run` | theorem | One complete entry scan costs at most eight times that entry's layout contribution. |
| `kt_valueWrite_lookup` | theorem | Lookup's value copy is an ordinary register overwrite. |
| `kt_entryPost_lookup` | theorem | A lookup entry preserves the table and either keeps the register or copies the first matching value into it; the table head advances by precisely the entry's layout contribution. |
| `kt_keyLookup_cons` | theorem | Lookup reads the first matching entry and otherwise continues with the tail. |
| `kt_registerFrame` | def | A register overwrite combined with a new table head and controller control. |
| `kt_registerFrame_invariants` | theorem | The lookup register frame preserves the table, query and blank scratch word, and its new register is delimited with the original width. |
| `kt_lookupPost` | def | The lookup endpoint keeps an already found register, or writes the supplied result when searching was still active at this suffix. |
| `kt_lookupPost_frame` | theorem | A suffix endpoint composes with one conditional lookup copy. Once a value was found, no later entry writes, and an actual copy supplies the final result immediately. |
| `kt_lookupPost_cons` | theorem | The mathematical first-match lookup composes with a completed entry frame. |
| `kt_lookup_end_run` | theorem | At the blank pair after the table, lookup either keeps the found word or writes zeros, then returns to the origin within the layout length plus twice the register width plus fifteen. |
| `kt_lookup_suffix_run` | theorem | Lookup from any entry offset reaches its final result with a linear bound in the remaining layout, the complete rewind, and the register width. |
| `kt_scratch_word` | theorem | A globally blank scratch tape supplies the empty word used by the end inspection. |
| `kt_lookup_run_within` | theorem | The lookup controller's complete run has the required register result and a uniform linear time bound, before packaging its first-exit and radius clauses. |
| `kt_done_state` | theorem | After a positive number of steps from the final anchor, the controller is parked at its distinct true control, so the final false anchor is never revisited. |
| `kt_reaches_of_run` | theorem | Any bounded controller run to the final anchor has the required first-exit and radius clauses, since the anchor cannot be revisited and heads move at most one cell per step. |
