from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, zipfile

ROOT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-key-table/tcslib-exchange')
BASE = 'cb44316a22c258628bf571da8c84b72c347ee493'
OWNED = 'TCSlib/Complexity/TuringMachine/Build/KeyTable.lean'
LOGS = ROOT/'evidence/logs'
STAGE = Path('/private/tmp/fill-ram-key-table-delivery')
ARCHIVE = Path('/private/tmp/fill-ram-key-table.zip')

records = [json.loads(line) for line in (LOGS/'check-results.jsonl').read_text().splitlines()]
bootstrap = [r for r in records if r['label'].startswith('bootstrap-')]
downstream = [r for r in records if r['label'].startswith('downstream-')]
assert len(bootstrap) == 38 and len(downstream) == 91
assert all(r['passed'] for r in records if r['label'] != 'readers-sealed')
assert [r['exit'] for r in records if r['label'] == 'readers-sealed'] == [1]
assert (LOGS/'readers-sealed.log').read_text().count('error:') == 3
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == BASE
base_file = subprocess.check_output(['git','show',BASE+':'+OWNED],cwd=ROOT)
assert (ROOT/OWNED).read_bytes() == base_file
assert not subprocess.check_output(['git','diff',BASE,'--','TCSlib'],cwd=ROOT)
patch = subprocess.check_output(['git','diff',BASE,'--',OWNED],cwd=ROOT)
assert not patch
(LOGS/'owned-diff-stat.log').write_text('$ git diff '+BASE+' --stat -- '+OWNED+'\n'+subprocess.check_output(['git','diff',BASE,'--stat','--',OWNED],cwd=ROOT,text=True)+'EXIT 0\n(empty diff; owned file byte-identical to base)\n')
(LOGS/'worktree-unrelated-diff-stat.log').write_text(subprocess.check_output(['git','diff',BASE,'--stat'],cwd=ROOT,text=True))
owned_sha = hashlib.sha256(base_file).hexdigest()
correction_log = (LOGS/'process-counter-correction.log').read_text()
assert 'Controller completed; supervisor exits.' in correction_log
assert 'PROCESS DEVIATION observed' not in correction_log
waits = (LOGS/'lean-processes.log').read_text().count('WAIT:') + correction_log.count('WAIT:')
max_before = max(map(int,re.findall(r'count=(\d+)',(LOGS/'lean-processes.log').read_text())))
corrected_peak = max(map(int,re.findall(r'ACTIVE total=(\d+)',correction_log)))
rss = [int(x) for p in LOGS.glob('*.log') for x in re.findall(r'^\s*(\d+)\s+maximum resident set size',p.read_text(),re.M)]
summary = dict(outcome='E-READER',base=BASE,proved_targets=[],unchanged_admitted_targets=['Turing.exists_keyLookupTM','Turing.exists_keyAssignTM'],bootstrap_passed=len(bootstrap),downstream_passed=len(downstream),consumers_checked=(LOGS/'downstream-targets.txt').read_text().splitlines(),expected_negative_control_exit=1,unexpected_failures=0,lean_wait_events=waits,manual_scheduler_pauses=1,initial_counter_format_limitation=True,max_other_lean_processes_recognized_by_initial_counter=max_before,corrected_monitor_observed_machine_peak=corrected_peak,maximum_resident_set_size_bytes=max(rss),owned_sha256=owned_sha)
(LOGS/'FINAL-CHECK-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')

text = (ROOT/OWNED).read_text()
sketches=[]
for name in ['exists_keyLookupTM','exists_keyAssignTM']:
    before=text[:text.index('theorem '+name)]
    doc=before[before.rfind('/--')+3:]
    sketch=doc.split('**Proof sketch.**',1)[1].rsplit('-/',1)[0].strip()
    sketches.append('### `Turing.'+name+'`\n\n**Proof sketch.** '+sketch+'\n')

report=f'''# fill-ram-key-table: E-READER frontier

## Outcome and frozen base

This is the clean-frontier delivery authorized by `COMMON.md`, ground rules 2 and 6.
**0 of 2 target admissions proved.** Both targets remain exactly as dispatched. The stop is an
API reader gap, not a claim that either frozen statement is false.

- Repository: `Shilun-Allan-Li/tcslib`.
- Base: `{BASE}`, fetched read-only from `complexity/ram-simulation`.
- Local branch: `codex/fill-ram-key-table`, created directly at the base and never rebased.
- Owned file: `{OWNED}` (191 lines; unchanged).
- Owned-file SHA-256: `{owned_sha}`.
- Bundle SHA-256: `14de9a4a1ba6ca97c0508bacb0fbef22843cf29341c63a59fd34b5844abef26f`.
- Bundle and README both match `SHA256SUMS`; see `evidence/logs/input-integrity.log`.
- Read the README, the bundle's first two sections, `COMMON.md` and its tier 2 addendum,
  the owned brief, the contribution policy, environment addendum v2.6, maintainer Rule 10,
  tier 2 design, and gate 162's pack, findings and resolutions.

| Target | Status | Frontier |
|---|---|---|
| `Turing.exists_keyLookupTM` | Original `sorry` retained | Cannot obtain the table's tape-cell equations or establish keyed `TableWF` through a published reader. |
| `Turing.exists_keyAssignTM` | Original `sorry` retained | Same shared layout frontier; no assignment construction attempted past it. |

No checkpoint zip was produced because no target was proved. No statement, target body,
proof sketch, module docstring, import or library declaration was changed. The delivered patch
is deliberately empty.

## E-READER evidence and the API repair to request

The route needs to read `TableAt`'s field layout and construct
`TableWF 2 [true] (keyFields es)` before applying the seek and field adapters. `RecordTable`
defines `tableFields`, `TableWF` and `TableAt` at lines 311, 325 and 332, respectively, but does
not publish their equation/iff readers. They are ordinary `def`s, not reducible abbreviations.

The complete 38-module import closure was searched before introducing any helper. Its public
declaration inventory is `evidence/logs/reader-api-inventory.log`. A repository-wide source search
also found no alternative table readers outside `RecordTable` and `KeyTable`.

The nearby published facts do not bridge the gap:

- `keyTableAt_iff` exposes `TableAt` and the blank right tail, but does not expose the cells of
  the `TableAt` component.
- `TableAt.recordAt_take` reads an entry only after receiving `TableWF`; no published fact
  constructs that predicate for the keyed layout.
- `TableWF.field_ne_nil` eliminates an existing `TableWF` proof; it does not introduce one.
- `tableOffset_eq` and `tableOffset_length` expose offsets, not the missing layout and predicate
  equations. They were considered; no extra offset reader is requested here.
- Catalog already supplies `fieldsTape_field`, `fieldsTape_of_neg`,
  `fieldsTape_of_length_le`, `joinFields_nil`, `joinFields_singleton`,
  `joinFields_cons_cons`, `fieldOffset_zero` and `fieldOffset_succ`. Those are useful after the
  missing bridge, and were not re-proved.
- The admitted `exists_tableFindTM`, `exists_tableAppendTM`, and other `RecordTable`
  admissions were not cited. The private `rt_*` declarations were not cited.

Request the following three readers **beside their definitions in `Build/RecordTable`**, with
the usual implicit parameters. This delivery does not add them to the library:

```lean
tableFields_eq (h : List Γ) (es : List (List (List Γ))) :
  tableFields h es = h :: es.flatten

tableWF_iff (m : ℕ) (h : List Γ) (es : List (List (List Γ))) :
  TableWF m h es ↔
    h ≠ [] ∧ ∀ e ∈ es, e.length = m ∧ ∀ u ∈ e, u ≠ []

tableAt_iff (d : Cfg K Γ S x) (r : Fin K) (o : ℤ)
    (h : List Γ) (es : List (List (List Γ))) :
  TableAt d r o h es ↔
    ∀ p : ℤ, -2 ≤ p →
      p ≤ ((joinFields (tableFields h es)).length : ℤ) + 1 →
      d.workTapes r (o + p) = fieldsTape (tableFields h es) p
```

`evidence/probes/ReadersNative.lean.txt` contains fully quantified scratch versions: all three
elaborate, exit 0, and each `#print axioms` says it depends on no axioms. The identical proofs
with those three definitions marked `[local irreducible]` produce exactly three `rfl` errors,
exit 1 (`ReadersSealed.lean.txt`, `readers-sealed.log`). These are intentional diagnostic
controls, not candidate library proofs. The failed control declarations' `sorryAx` prints are
Lean's error recovery, not added admissions in the delivered file.

Using the native controls as local helpers would itself unfold a foreign definition and violate
Rule 10. Adding the readers to `RecordTable` would exceed this fill's file ownership and public
surface permissions. Therefore the marker contract transformer and both machine constructions
stop before this bridge. Once the maintainer publishes the readers and dispatches a suitable
base, resume with the shared marker adapter, the bounded compare/search loop, then the two
operations as described in the unchanged sketches below.

## Helpers, dependencies and axiom walk

New private library declarations: **none**. New public declarations/files/imports: **none**.
Other-file definitions read by new delivered proofs: **none**, because no target proof was
changed. The three scratch reader controls intentionally test definition reduction; their
role and separation from the library are described above.

No tier 2 admitted dependency was used. The baseline axiom prints, both exit 0, are:

```text
Turing.exists_keyLookupTM: [propext, sorryAx, Classical.choice, Quot.sound]
Turing.exists_keyAssignTM: [propext, sorryAx, Classical.choice, Quot.sound]
```

The scratch dependency walker follows both types and values of reachable constants, including
theorem values. Its complete lists of constants whose values directly use `sorryAx` are:

```text
Turing.exists_keyLookupTM: [Turing.exists_keyLookupTM] (1916 constants visited)
Turing.exists_keyAssignTM: [Turing.exists_keyAssignTM] (1917 constants visited)
```

These lists describe the **unchanged admissions**, not proved targets satisfying a
proved-modulo allowance. There are no newly proved targets for which that allowance is claimed.
The walker asserts each list is exactly its root; it exits 0. Source and output:
`evidence/probes/Axioms.lean.txt`, `evidence/logs/baseline-axioms-dependency-walk.log`.

## Verification

All results are against this fill's own scratch olean tree, bootstrapped from the pinned source.

| Check | Exit/result |
|---|---|
| Mathlib-root cache probe | 0, fresh nonempty olean |
| Owned import closure, including owned file | 38/38 exit 0, zero errors, fresh nonempty oleans |
| Owned file | 0; exactly the original two target admission warnings |
| Three native reader controls and their axiom prints | 0; no axioms |
| Three sealed reader controls | 1, exactly 3 expected reader failures |
| Baseline target axiom prints and dependency walks | 0 |
| Downstream sweep plus its additional prerequisites | 91/91 exit 0, zero errors, fresh nonempty oleans |
| Owned `git diff --stat` | 0, empty |
| All tracked `TCSlib` source against base | Empty diff |

The downstream sweep includes all seven direct/transitive consumers: `RAMSimulation/Sim/Encoding`,
`Sim/Startup`, `Sim/Phases`, `RAMSimulation/Simulation`, `RAMSimulation/Classes`, the
`RAMSimulation` facade and the `TuringMachine` facade. `Build/InputBit`, needed as a prerequisite,
was also checked. `downstream-targets.txt` and `downstream-order.txt` record the lists. The root
`TCSlib.lean` is excluded as required by the maintainer's replay convention.

Each check log records start, finish, exact command, exit and maximum memory. Individual exits
are also recorded in `check-results.jsonl`; `FINAL-CHECK-SUMMARY.json` is the compact summary.
`owned-diff-stat.log` records the required scoped diff. No successful proof is claimed on the
basis of the intentionally failing seal controls.

## Environment and waits

- Native host: macOS arm64; Linux `nproc`, cgroups and `/proc/meminfo` are unavailable. The
  native equivalents (`os.cpu_count`, `sysctl hw.memsize`, `vm_stat`, `memory_pressure`,
  `df -k`, `mount`) are recorded in `preflight.log`.
- 12 logical CPUs, 19,327,352,832 bytes RAM (18 GiB), system memory free percentage 67%.
  Initial disk availability: 125,709,448 KiB (about 119.9 GiB) on APFS, for both worktree and
  `/private/tmp`. Both resource floors pass. No memory-backed filesystem was used.
- Toolchain: the host's existing pinned Lean 4.25.0. No shim was needed.
- `.lake/packages` is a symlink to the populated main-checkout tree at
  `/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`,
  using the environment addendum's explicit pin-matched symlink exception. All present package
  URLs/revisions match the base manifest; absent documentation packages are listed as ABSENT.
  `packages.log` ends with `PASS: all present packages match manifest; documentation packages absent`.
- There are 29 direct Mathlib roots in the owned import closure. The linked dependency cache
  contains no zero-byte oleans and its Mathlib-root probe passes. No cache fetch, package update,
  toolchain install, object-store copy, snapshot reuse or combined TCSlib olean tree was used.
  The cache archive-store/fetch log requirement is inapplicable because no fetch was run.
- Bootstrap and all checks use the repository's `leanelab-o.sh`/`leanelab.sh`, `nice -n 10`,
  `lean -j4`, and `TCSLIB_LEAN_SLOTS=3`. A process-table check precedes every invocation;
  this fill starts one Lean process at a time. There is a process-counter limitation to disclose:
  the initial `ps` command parsed macOS's width-limited `comm` column, which recognizes bare
  `lean` but can omit a full-path executable. Its maximum recognized other count was
  {max_before}; those earlier counts cannot certify that full-path external processes were absent.
  The original logs are retained, not retroactively relabeled as complete counts.
- At downstream `CodeSimulator`, paused only the Python controller while its active Lean
  continued, corrected the reusable counter to parse `ps -axww -o pid=,args=`, and supervised
  all remaining launches with full-argument counts before resuming the controller each time.
  One controller pause was used for this correction. The corrected monitor's observed machine
  peak was {corrected_peak}; no over-limit overlap was observed. Resource-slot wait events:
  {waits}. See `lean-processes.log` and `process-counter-correction.log`. This is an environment
  checking deviation disclosed under the addendum's rule that a process deviation does not end
  a fill; it is not a proof or statement escalation.
- Peak recorded resident size: {max(rss):,} bytes ({max(rss)/2**30:.2f} GiB).
- No `lake build` or other Lake command was run. Logs were written directly to their final
  `evidence/logs/` locations. `MathlibRoot` is the separate scratch cache probe.
- When inspected, the managed worktree contained 30 unrelated blueprint metadata differences.
  Their modification times precede the first Lean invocation. They were left untouched and
  excluded from the payload and scoped patch; see `worktree-unrelated-diff-stat.log`.

## Delivery contents and continuation

The zip contains this report, the unchanged owned file at its repository-relative path, the
empty `fill-ram-key-table.patch` against the base, all check logs, scratch probes as `.lean.txt`,
verification driver sources, and an internal `SHA256SUMS`. It contains no oleans or dependency
build products. Delivery destination:
`arora-barak-ch3-4/inbox/fill-ram-key-table/fill-ram-key-table.zip` on
`exchange/pass-shelat-ch5-8`; only that exchange branch is to be pushed, after `git pull --rebase`,
without force or a PR. The proof branch remains at the frozen base.

The next required maintainer action is to publish the three readers (or an equivalent public
layout API), then redispatch the fill. The two original sketches below remain plans, not proofs.

## Unproved targets: unchanged proof sketches

'''+ '\n'.join(sketches)

STAGE.mkdir(parents=True, exist_ok=True)
(ROOT/'REPORT.md').write_text(report)
(STAGE/'REPORT.md').write_text(report)
(STAGE/OWNED).parent.mkdir(parents=True,exist_ok=True)
(STAGE/OWNED).write_bytes(base_file)
(STAGE/'fill-ram-key-table.patch').write_bytes(patch)
for src in sorted(LOGS.iterdir()):
    if src.is_file():
        dst=STAGE/'evidence/logs'/src.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
for src in sorted((ROOT/'evidence/probes').glob('*.lean')):
    dst=STAGE/'evidence/probes'/(src.name+'.txt');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
for src in [Path('/private/tmp/fill-ram-key-table-run-checks.py'),Path('/private/tmp/fill-ram-key-table-final-checks.py'),Path('/private/tmp/fill-ram-key-table-process-supervisor.py'),Path(__file__)]:
    dst=STAGE/'evidence/runtime'/src.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
hash_lines=[]
for p in sorted(STAGE.rglob('*')):
    if p.is_file() and p.name != 'SHA256SUMS':
        hash_lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(STAGE)))
(STAGE/'SHA256SUMS').write_text('\n'.join(hash_lines)+'\n')
with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file(): z.write(p,str(p.relative_to(STAGE)))
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert z.read(OWNED)==base_file
    assert z.read('fill-ram-key-table.patch') == b''
    for line in z.read('SHA256SUMS').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(dict(zip=str(ARCHIVE),bytes=ARCHIVE.stat().st_size,sha256=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),summary=summary),indent=2))
