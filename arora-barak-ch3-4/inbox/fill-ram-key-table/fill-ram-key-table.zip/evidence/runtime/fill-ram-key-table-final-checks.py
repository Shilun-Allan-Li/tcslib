from pathlib import Path
import importlib.util
import json

spec = importlib.util.spec_from_file_location('checks', '/private/tmp/fill-ram-key-table-run-checks.py')
checks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checks)

if not checks.check('readers-native', 'evidence/probes/ReadersNative.lean'):
    raise SystemExit(1)

sealed_passed = checks.check('readers-sealed', 'evidence/probes/ReadersSealed.lean')
sealed_log = (checks.LOGS/'readers-sealed.log').read_text()
if sealed_passed or sealed_log.count('error:') != 3 or sealed_log.count('rfl') < 3:
    raise SystemExit('The expected three sealed-reader failures were not observed.')
print('PASS: native reader controls elaborate; sealed reader controls produce the expected 3 failures.', flush=True)

if not checks.check('baseline-axioms-dependency-walk', 'evidence/probes/Axioms.lean'):
    raise SystemExit(1)

for index, module in enumerate((checks.LOGS/'downstream-order.txt').read_text().splitlines()):
    if not checks.check(f'downstream-{index:02d}-' + module.split('.')[-1], module.replace('.', '/')+'.lean', True):
        raise SystemExit(1)
print('FINAL CHECKS PASS (E-READER frontier; no targets proved)', flush=True)
