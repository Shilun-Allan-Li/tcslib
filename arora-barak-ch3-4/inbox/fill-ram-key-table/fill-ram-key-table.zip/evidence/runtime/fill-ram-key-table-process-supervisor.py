from pathlib import Path
import datetime, os, signal, subprocess, time

CONTROLLER = 10541
ROOT = Path('/Users/seyoonr/.codex/worktrees/fill-ram-key-table/tcslib-exchange')
MATCH = str(ROOT/'evidence/oleans')
LOG = ROOT/'evidence/logs/process-counter-correction.log'

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def snapshot():
    result = subprocess.check_output(['ps','-axww','-o','pid=,stat=,args='],text=True)
    active=[]; controller=None
    for line in result.splitlines():
        words=line.split(None,3)
        if len(words)<3: continue
        if int(words[0]) == CONTROLLER: controller=words[1]
        if Path(words[2]).name == 'lean' and not words[1].startswith('Z'): active.append(line)
    return controller,active

with LOG.open('a',buffering=1) as log:
    log.write(stamp()+' Starting corrected full-argument process supervisor.\n')
    phase='running-check'
    last=None
    while True:
        status,active=snapshot()
        if status is None or status.startswith('Z'):
            log.write(stamp()+' Controller completed; supervisor exits.\n')
            break
        own=[line for line in active if MATCH in line]
        if own:
            if 'T' not in status: os.kill(CONTROLLER,signal.SIGSTOP)
            phase='running-check'
            pids=tuple(line.split()[0] for line in active)
            if pids != last:
                log.write(stamp()+' ACTIVE total='+str(len(active))+' own='+str(len(own))+'\n'+'\n'.join(active)+'\n')
                last=pids
            if len(own)>1 or len(active)>3:
                log.write(stamp()+' PROCESS DEVIATION observed; report required.\n')
            time.sleep(0.25)
        elif phase=='running-check':
            if len(active)>=3:
                log.write(stamp()+' WAIT: corrected count='+str(len(active))+' before controller resume\n')
                time.sleep(2)
                continue
            log.write(stamp()+' CORRECTED BEFORE NEXT LAUNCH other_count='+str(len(active))+'\n'+'\n'.join(active)+'\n')
            os.kill(CONTROLLER,signal.SIGCONT)
            phase='launching'
            last=None
            time.sleep(0.01)
        else:
            time.sleep(0.01)
