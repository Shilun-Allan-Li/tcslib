# Fill u2s-g5 — `Turing.FinTM.two_work_tapes_run` (Hennie–Stearns on two work tapes)

**Status of this zip: checkpoint 3 of 9 (partial).** Checkpoints 1, 2 and 3 are reached; the
target is still open (its body reduces to the zone machine for `M.k ≥ 1` and ends in `sorry`).
Nothing outside the brief's regions (a)–(c) is changed; region (d) is not yet written (the target
is open, but its *Implementation status* paragraph is deferred to the final delivery of this
session, so that the frozen docstring changes once).

- Agent: Claude (Claude Code, cloud session). Brief `u2s-fill-g5.md`
  (SHA-256 `c5723901…85360`, verified) and addendum v2.6 (SHA-256 `9f5bd5e7…9bd28`, verified),
  both read at records commit `fe5cb6fb` and identical to the copies in
  `arora-barak-ch3-4/outbox/fills/u2s-fill-g5/` on `exchange/pass-shelat-ch5-8`.
- **Base:** `335d31d408f1b4b4164f5b1b3a37d246a42b25cc` (`git rev-parse HEAD` after
  `git checkout -b fill/u2s-g5 335d31d4…`). Ancestor check
  `git merge-base --is-ancestor 335d31d4… origin/complexity/arora-barak-ch3-4`: **passed**.
  Blob check `git rev-parse HEAD:…/Robustness/TwoTapes.lean` = `cc35767342620a3be6331c57239e5eafa5ea4c45`:
  **passed**. No rebase, merge or cherry-pick.
- **Commits on `fill/u2s-g5`** (the bundle and the patch series hold exactly these, over the base):
  1. `3232187a` region (a): the overlay (`import …Build.ZoneStep`), the first edit;
  2. `36fefeaa` checkpoint 1: the frame and the zero-tape case;
  3. `9a240ad3` checkpoint 2: the transition step (the leaf);
  4. `bdc01816` checkpoint 3: the controller and one round;
  5. `afff3c4a` `Fin.eq_one_of_ne_zero` replaces a private found by the `exact?` probe;
  6. `db11b8cf` a proof sketch for `tt_mapState_eq_cfg` (policy linter) and one long line;
  7. `c026c001`, 8. `e7d3ac90` (this zip's head): rewordings for two screen pairs (§7).

## 1. Environment (addendum v2.6, Part 1)

Quoted from `evidence/logs/preflight.log`:

- `nproc` = 4. cgroup v1. Memory: limit `14337302528` B (13.35 GiB; `hierarchical_memory_limit`
  the same); in use = `usage_in_bytes 803598336 − total_cache 747200512 + total_shmem 0` =
  `56397824` B; **headroom 13.30 GiB** (floor 4 GiB); `MemAvailable` 15.23 GiB; `oom_kill 0`.
- Disk: the clone `/home/user/tcslib` and the scratch directory are on `/dev/vda`, **ext4** (not
  tmpfs); free `31472963584` B = **29.31 GiB** (floor 12 GiB). Re-check after installing the
  toolchain: `28887388160` B free (floor 8 GiB; `evidence/logs/precache-df.log`).
- **Toolchain:** elan installed fresh with `leanprover/lean4:v4.25.0` (the archive extracted with
  `TAR_OPTIONS=--no-same-owner`). `lean --version`: `Lean (version 4.25.0, x86_64-unknown-linux-gnu,
  commit cdd38ac5…, Release)`. **Lean starts normally: Part 2's shim was not needed and not used.**
- **Archive store** (`evidence/logs/cache-store.log`, logged before the fetch): `/root/.cache/mathlib`
  **did not exist** (0 files, 0 bytes). Every archive was downloaded by this session.
- **Cache:** `TAR_OPTIONS=--no-same-owner lake exe cache get $(cat evidence/logs/mathlib-roots.txt)`
  with the **42 roots** of the order list (the brief's count): "Attempting to download 1022 file(s)",
  1022 downloaded, "Decompressing 1022 file(s)", "Completed successfully!", exit 0; no failed
  download, no retry. The unfiltered `lake exe cache get` and `lake build` were never run.
- **Manifest check** (`evidence/logs/manifest-check.log`): last line `manifest check: PASS (every
  present package matches)`; ABSENT: `doc-gen4`, `UnicodeBasic`, `BibtexQuery`, `MD4Lean` (the
  documentation toolchain; no module of the order list imports them). Empty oleans: 0.
- **Cache probe:** `import Mathlib.Algebra.BigOperators.Fin` (the first root) through
  `scripts/lean_check_tree.sh`: exit 0 (`evidence/logs/cache-probe.log`).
- `/usr/bin/time` is not installed; each module's start, end, elapsed time and maximum resident
  memory are logged by a 6-line Python wrapper (`resource.getrusage(RUSAGE_CHILDREN)`), one Lean
  process at a time.

## 2. Bootstrap (addendum item 5)

Done in the allowed order: **first the 25 modules of the order list in `TwoTapes`' import closure**
(`evidence/logs/bootstrap-closure.txt`, the list's order), ending with `TwoTapes` itself on the
overlay; all exit 0 (`evidence/logs/bootstrap-1-closure.log`, table in
`evidence/logs/bootstrap-1-table.md`). Total 575 s; the largest are `Build/ZoneRebalance` (372.3 s,
**4,629 MiB** maximum RSS — above the addendum's measured 2.8 GiB peak, recorded here; no
shortage: headroom stayed above 8 GiB) and `Build/Catalog` (107.4 s, 2,875 MiB). The overlay's
`TwoTapes` gives exactly one warning, `TwoTapes.lean:65:8: declaration uses 'sorry'` (the target).

The remaining **80 modules** of the order list (`evidence/logs/bootstrap-rest.txt`) are **not yet
built** at this checkpoint; they precede the final sweep. Sorry warnings in the 25 built modules:
Simulation 1, Composition 3, Wrappers 2, Loop 5, Encoding 1, TwoTapes 1 — the base set's entries for
these modules exactly (base: 22 entries in 9 modules; the other 9 entries are in unbuilt modules).

## 3. What is proved (checkpoints 1–3)

`TwoTapes.lean` grows from 86 to 840 lines: **2 public declarations (unchanged), 43 private**, all
under `tt_`, all in region (b) between `namespace Turing.FinTM` and the target's docstring.
`sorryAx` reaches `two_work_tapes_run` only through its own body (axiom prints, §6).

### Checkpoint 1 — the frame and `k = 0` (route steps 0–1)
Copied verbatim from the route probe `G5Route.lean.txt`, as the brief directs:
- `tt_zero_tapes` — `M.k = 0`: R1 (`embedEmitTM σ M.tm`, `σ = Fin.castLEEmb`) restarted at `M.tm.q₀`
  (`initCfg_with_q₀`, `runFrom_with_q₀`), `c = 1`, both directions.
- `tt_frame` — `alphabet_reduction_run (Function.Embedding.inl) HS`, `c := c₂ · c₁`; the forward
  property and the image converse of `HS`.
- `tt_route` — the case split on `M.k = 0`.
- The target's body is now `refine tt_route (fun M hk => ?_) M` followed by `sorry`: the open goal
  is exactly "a two-tape zone machine `HS` over `ZoneSym M.k` with the forward property and the
  image converse, for `1 ≤ M.k`".

### Checkpoint 2 — the leaf (the one authorized leaf)
- `tt_LeafSt M := M.State ⊕ (M.State × (Fin M.k → SignType))`; `tt_decodeIn` (input through
  `Sum.inl`), `tt_homeRead w t := (zoneCellOfCell w t).join` (a blank home reads all-blank),
  `tt_homeNew a v t := (a.workTapes t).1.getD (v t)`, `tt_moves a t := (a.workTapes t).2`.
- `tt_leafTr`, `tt_leafTM`: at `inl q` read the home tuple and the input symbol, apply `M.tm.tr q`,
  write `some (.inr fun t => some (v' t))` on tape `0`, nothing on tape `1`, move the input head by
  `a.inputTape`, emit `a.output.map Sum.inl`, keep both work heads, and go to `inr (q', m)` or
  halt with `M`. Its docstring says that no public row applies a finite-state transition to the
  home cell of the zoned tape and the input head in one step.
- `tt_leaf_step` (the one-step lemma, through `step_of_some`, `Action.apply_state`, `_inputPos`,
  `_workTapePos`, `_output`, `Action.apply_workTapes`), with `tt_leafTM_tr_moves`,
  `tt_leafTM_tr_workTapes_of_ne` (the table's own fields).

### Checkpoint 3 — the controller and one round (route steps 2–3)
- `tt_Fam k A` — **the track-step family** as a structure (state types with `Fintype`/`DecidableEq`,
  machines, entries, exits with `none ∉ X`, a contract per input with precondition `zoneRowPre`,
  and `exists_zoneTrackStepTM`'s five clauses). Every controller lemma is generic in it; it is
  instantiated (by `choose`) only in the target's body (pitfall 6).
- `tt_dir` (`pos ↦ true`), `tt_I M := Option (M.State × (Fin M.k → SignType) × Fin M.k)`,
  `tt_Ph`, `tt_Mf` — **the phases:** `none` is the leaf; `some (q', m, t)` is track `t`'s phase,
  whose machine is the track step of direction `tt_dir (m t)`. **Every track has a phase in every
  round; a stay is a zero-time phase** entered and left at its entry (recommended shape; no
  same-phase redirect).
- `tt_next`, `tt_red` (classical, `open Classical in`), `tt_red_track_pos/neg` — **the redirects:**
  leaf exit `inr (q', m)` → track `0`'s entry; track `t`'s live exit (a stay: its entry) →
  track `t + 1`'s entry, or the leaf at `inl q'` after the last track; nothing else.
- `tt_phFin`, `tt_phDec`, `tt_HS` — the zone machine: `phaseHostTM (tt_Mf M F) ⟨none, inl M.tm.q₀⟩
  (tt_red M F hk)` with `k = 2` and state type `Σ i, tt_Ph M F i` (finite: `Fintype` per case).
- `tt_cfg` (a phase-boundary configuration: tape `0` = `zonedTape D.2`, heads at `0`, tape `1`
  blank), `tt_cfg_mapState`, `tt_cfg_rowPre`, `tt_mapState_eq_cfg` (a row endpoint, renamed, is a
  boundary configuration; through `Cfg.mapState_eq_of_fields`, RN-1's canonical).
- `tt_trackData`, `tt_idx`, `tt_trackTime`; **`tt_track_seg`** — one track's phase as a
  `Turing.Segment` against `{none}` (`P := True`), time `trackTime + 1`, with
  `trackTime ≤ A · (2^{idx} + 1)` (`idx = 0`, time `0` for a stay): through `phaseHostTM_run`
  (a stay at time `0`; a move with the contract's run, cut, exit), liveness by `Contract.live`.
- `tt_Dtr`, `tt_stAt`, `tt_τ`, `tt_τ_of_lt`; **`tt_tracks_seg`** — the tracks of a round, by
  `Turing.Segment.iterate_seq` over the tracks (no hand-written induction).
- `tt_cfg0`, `tt_act`, `tt_homeData`; **`tt_round`** — one round from the leaf at `q` with data
  `D` (home cell `h0` read as `D`'s homes, so the first round, with a blank home, is an instance):
  if `M`'s transition halts, the host halts after one step with the emission appended (the halting
  round, through `phaseHostTM_run_le`); otherwise a segment of `2 + ∑_{j<k} τ j` steps to the
  leaf at `q'` with data `tt_Dtr m (tt_homeData a D) k` (through `tt_leaf_step`,
  `zonedTape_homeWrite`, `phaseHostTM_run`, `Segment.trans`). **`tt_τ_le`:**
  `τ j ≤ A · (2^{idx} + 1) + 1`, so a round costs at most `2 + A ∑_t (2^{idx t} + 1) + k`,
  `sum_cost_le_of_count`'s step hypothesis with `B = 2`.
- Positivity is read from the leaf's own step (time ≥ 2), never from `Contract.Positive`.

## 4. Open (checkpoints 4–9), with their proof sketches

The target's own body is the only admission. What remains, in mathematical terms:
- **4. The invariant except fullness.** For the data orbit `D_{r+1} = tt_Dtr m (tt_homeData a D_r) k`
  (`a` = `M`'s transition at `c_r`) show: `∀ t p, zoneTrackTape (D_r.2 t) p =
  c_r.workTapes t (c_r.workTapePos t + p)`, the input positions agree, the output is the image, and
  the state is the leaf's. *Proof sketch.* The home write by `zoneTrackTape_homeWrite` and
  `Action.apply_workTapes`; a move by `zoneTrackStepData_of_lt`/`_of_not_lt`,
  `zoneTrackTape_rebalance_right`/`_left` (hypotheses from fullness and the scan) and
  `zoneTrackTape_extend`; the other tracks by `Function.update_of_ne` after `zoneRebalanceData_eq`.
- **5. The iteration** by `Segment.iterate_seq` with starts `cs 0 = HS.initCfg (x.map inl)` and
  `cs (r+1) = tt_cfg (some ⟨none, inl q_{r+1}⟩) D_{r+1} ip_{r+1} out_{r+1}`; the first round is
  `tt_round` with `h0 = none` (`zonedTape_blank_outside`, `zoneStart_eq` give the initial tape as
  `tt_cfg0 … none …`).
- **6. Fullness, side totals, count and level bounds** over the data orbit (pure arithmetic):
  fullness by `zoneCascadeRight_lengths`/`Left_lengths`, `zoneRebalance_frame`, `extend_words_*`;
  the count `#{s < T | i < idx t s} ≤ T / 2^i + 1` from the side total of levels `≤ i`, which is
  `2^{i+1} − 1` after a step of index `> i` and changes by at most one per round; the level bound
  from the global displacement form.
- **7. The cost** through `sum_cost_le_of_count` (`B = 2`), `L := Nat.log 2 t₀ + 1`; **8. the
  converse**; **9. the target** (`choose` the family from `exists_zoneTrackStepTM`, `tt_HS`,
  `tt_frame` through `tt_route`).

## 5. Edge cases covered so far
- `k = 0`: `tt_zero_tapes` (R1). `k ≥ 1` required by `tt_HS` (`hk`; track `0` exists).
- A source that halts at its first transition: `tt_round`'s halting clause (one leaf step, no track step).
- Stays: zero-time phases, `idx = 0` (`tt_track_seg`, `tt_idx`).
- No write vs. a blank write: `tt_homeNew` (`getD`), matching `Action.apply_workTapes`.
- Emission at the halting transition: `tt_round`'s halting clause appends it.
- The first round with a blank home: `tt_round` takes `h0` with `tt_homeRead h0 = homes`.

## 6. Rule 10, rule 11 (this checkpoint's commit)
- **Elaborated-constant walk** (`evidence/logs/cp3/walk.out`, the `#tt_walk` command of
  `evidence/seal/walk.lean.txt`): 90 TCSlib constants from other modules; the non-theorems are
  structure types, constructors and projections, and 23 definitions, all in the seal.
- **Seal** (`evidence/seal/TwoTapesSealed.lean`, generated by `mkseal.py` from the module and
  `seal-list.txt`): **39 other-file definitions** `[local irreducible]` (the route probe's 15, the
  brief's list, and `FinTM.ComputesFunInTime`), `[-simp]` on `MultiTapeTM.initCfg`, `Cfg.init`,
  `Action.apply`. Command `bash scripts/lean_check_tree.sh Scratch/seal-cp3/TwoTapesSealed`:
  **exit 0**, one warning (the target's sorry). `ZoneSym`, `ZoneCell` and `ZoneData` are reducible
  `abbrev`s and stay out (as the route probe's README explains for the first two).
- **Controls** (`TwoTapesCtl_unsealed.lean`, `TwoTapesCtl_sealed.lean`; `#ctl_rfl` and `#ctl_eqn` per
  sealed definition, `#ctl_simp` for the three simp ones): **unsealed 81 CONTROL_PASS / 0 FAIL,
  sealed 0 PASS / 81 CONTROL_FAIL**, both exit 0. Raw outputs in `evidence/logs/cp3/`.
- **Inspection table** `evidence/logs/cp3/inspection.md`: 119 `rw`/`simp`/`show`/… arguments;
  other-file definitions passed to a rewriting tactic: **0**. Every `show`/`change` reduces only
  this file's definitions and structure projections (the seal confirms).
- **Import probe** re-run, extended (`evidence/seal/G5ImportProbeExt.lean`): **251 checks** (the
  pre-ship 217 + 34 further names cited: structure fields, core and Mathlib lemmas), 0 errors.
- **Axiom prints** (`TwoTapesAxioms.out`): every one of the 43 privates within
  `[propext, Classical.choice, Quot.sound]` (several on none); `two_work_tapes_run` and
  `two_work_tapes_binary` on `[propext, sorryAx, Classical.choice, Quot.sound]`.
  `universal_TlogT` is not printed at this checkpoint (its module is in the unbuilt 80).
- **Rule 11** (`evidence/logs/cp3/rule11.txt`): no R3 canonical row and no other file's private name in the diff.

## 7. Duplication
- **Before screen** (worktree of `3232187a`, the overlay; `nice -n 10 python3 -I
  scripts/copy-text-screen-v3.py . $(grep -v '^#' …/screen-population.txt)`): **byte-identical to
  the screen base** (1,210 declarations, 819 pairs, 281,024 characters).
- **After screen** (worktree of `e7d3ac90`): **1,233 declarations, 819 pairs, 281,024 characters** —
  the base's pairs exactly; no pair has a declaration of `TwoTapes` on either side.
  Two intermediate runs found pairs, both removed before this commit: `tt_round` reproducing
  `ZoneRebalance`'s private `zr_mir_lockstep` (60%, then 52%: the RO-1 idiom
  `rw [MultiTapeTM.runFrom_succ_eq_step', MultiTapeTM.runFrom_zero]` and `obtain rfl : u = 0`,
  shared text, not a copy; reworded through `Nat.lt_one_iff` and a local `runFrom_zero`), and
  `tt_tracks_seg`/`tt_τ_le` (55%, in-file; factored into `tt_τ_of_lt`).
- **Semantic search per private.** Every private but one states a fact about this file's own
  definitions (`tt_leafTM`, `tt_cfg`, `tt_red`, …), so no library declaration can state it; the
  tree and the open PRs have no `tt_` declarations outside this file (the prefix is unused, as the
  brief records). The two whose statements use only library notions were posed to `exact?`
  (`evidence/seal/G5FillExact.lean`, output `evidence/logs/cp3/G5FillExact.out`): `j : Fin 2,
  j ≠ 0 ⊢ j = 1` is closed by **`Fin.eq_one_of_ne_zero`** — the private was removed and the
  Mathlib lemma cited (commit 5); the row-endpoint renaming (`tt_mapState_eq_cfg`'s content) is not
  closed by any library lemma (it is an instance of `Cfg.mapState_eq_of_fields`, RN-1's canonical,
  which its proof cites).
- **Inline-step sweep** (`evidence/logs/cp3/inline-sweep.txt`): one `Cfg.ext` (in `tt_leaf_step`,
  the leaf's one-step lemma: a step against a structure literal, not a renaming, so not RN-1) and
  one RO-1 use (`MultiTapeTM.runFrom_succ_eq_step.trans MultiTapeTM.runFrom_zero` in `tt_round`,
  the leaf's one step).
  No `Nat.exists_eq_add_of_le`, `runFrom_add`, `runFrom_of_halt`, `lt_trichotomy` or `Nat.find`.
- **New copies: none.**

## 8. Promotion candidates and escalations
- **Promotion candidate (`[Q3]`):** the round over the zoned carrier (`tt_track_seg`,
  `tt_tracks_seg`, `tt_round` with `tt_Fam`) is "an interpreter or simulation step block"; a public
  form would take a track-step family and a finite-state leaf.
- **Escalations:** none.

## 9. Lint and size
`python3 -I scripts/campaign_style_lint.py TCSlib/Complexity/TuringMachine`: **0 FAIL, 71 WARN over 92
files** (the base's), INFO `TwoTapes.lean 840 lines; 2 public / 43 private`. Policy linter
`scripts/style_lint.py` on the file: **0 findings**. No line over 100 characters.

## 10. Checks of this zip
`TwoTapes` at this commit: `evidence/logs/cp3-check.log` — exit 0, one warning, the target's
`declaration uses 'sorry'`. The final sweep over the order list is not run at a checkpoint.
