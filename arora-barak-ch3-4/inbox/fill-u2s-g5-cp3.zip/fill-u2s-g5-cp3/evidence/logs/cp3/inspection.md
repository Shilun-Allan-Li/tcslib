| line | tactic | argument | classification |
|---|---|---|---|
| 84 | `rw` | `MultiTapeTM.initCfg_eq` | theorem (other file) |
| 86 | `simp only` | `Cfg.init_state` | theorem (a `simps` field equation, TCSlib) |
| 87 | `simp only` | `Cfg.init_inputPos` | theorem (a `simps` field equation, TCSlib) |
| 88 | `simp only` | `Cfg.init_output` | theorem (a `simps` field equation, TCSlib) |
| 88 | `simp only` | `List.append_nil` | core or Mathlib lemma |
| 92 | `simp only` | `Cfg.init_workTapes` | theorem (a `simps` field equation, TCSlib) |
| 93 | `simp only` | `Cfg.init_workTapePos` | theorem (a `simps` field equation, TCSlib) |
| 98 | `rw` | `hq` | local hypothesis |
| 98 | `rw` | `hinit` | local hypothesis |
| 98 | `rw` | `hr` | local hypothesis |
| 98 | `rw` | `embedEmitTM_runFrom` | theorem (other file) |
| 107 | `rw` | `computesInTime_iff` | theorem (other file) |
| 108 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 110 | `rw` | `hrun` | local hypothesis |
| 110 | `rw` | `embedEmitCfg_state` | theorem (other file) |
| 110 | `rw` | `hs` | local hypothesis |
| 111 | `rw` | `hrun` | local hypothesis |
| 111 | `rw` | `embedEmitCfg_output` | theorem (other file) |
| 111 | `rw` | `ho` | local hypothesis |
| 111 | `rw` | `List.nil_append` | core or Mathlib lemma |
| 116 | `rw` | `hrun` | local hypothesis |
| 116 | `rw` | `embedEmitCfg_state` | theorem (other file) |
| 117 | `rw` | `hrun` | local hypothesis |
| 117 | `rw` | `embedEmitCfg_output` | theorem (other file) |
| 117 | `rw` | `List.nil_append` | core or Mathlib lemma |
| 151 | `rw` | `hinl` | local hypothesis |
| 153 | `rw` | `Nat.mul_assoc` | core or Mathlib lemma |
| 251 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 291 | `rw` | `MultiTapeTM.step_of_some` | theorem (other file) |
| 293 | `rw` | `Action.apply_state` | theorem (other file) |
| 293 | `rw` | `hW` | local hypothesis |
| 295 | `rw` | `Action.apply_inputPos` | theorem (other file) |
| 295 | `rw` | `hW` | local hypothesis |
| 298 | `rw` | `Action.apply_workTapes` | theorem (other file) |
| 298 | `rw` | `Cfg.workTapeSymbols_eq` | theorem (other file) |
| 298 | `rw` | `hW` | local hypothesis |
| 302 | `rw` | `tt_leafTM_tr_workTapes_of_ne` | own definition/lemma |
| 302 | `rw` | `Option.getD_none` | core or Mathlib lemma |
| 302 | `rw` | `Function.update_eq_self` | core or Mathlib lemma |
| 303 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 304 | `rw` | `if_neg` | core or Mathlib lemma |
| 306 | `rw` | `Action.apply_workTapePos` | theorem (other file) |
| 306 | `rw` | `tt_leafTM_tr_moves` | own definition/lemma |
| 306 | `rw` | `SignType.coe_zero` | core or Mathlib lemma |
| 306 | `rw` | `add_zero` | core or Mathlib lemma |
| 307 | `rw` | `Action.apply_output` | theorem (other file) |
| 307 | `rw` | `hW` | local hypothesis |
| 464 | `rw` | `hs₀` | local hypothesis |
| 469 | `rw` | `h0` | local hypothesis |
| 472 | `rw` | `hb` | local hypothesis |
| 477 | `rw` | `hp0` | local hypothesis |
| 480 | `rw` | `h1` | local hypothesis |
| 529 | `rw` | `hb` | local hypothesis |
| 540 | `rw` | `hT` | local hypothesis |
| 540 | `rw` | `hD` | local hypothesis |
| 542 | `rw` | `H.2` | local hypothesis |
| 542 | `rw` | `hc` | local hypothesis |
| 542 | `rw` | `tt_cfg_mapState` | own definition/lemma |
| 550 | `rw` | `hR` | local hypothesis |
| 550 | `rw` | `F.pre` | local hypothesis |
| 557 | `rw` | `h` | local hypothesis |
| 575 | `rw` | `hT` | local hypothesis |
| 575 | `rw` | `hD` | local hypothesis |
| 575 | `rw` | `hI` | local hypothesis |
| 577 | `rw` | `H.2` | local hypothesis |
| 578 | `rw` | `hs'` | local hypothesis |
| 579 | `rw` | `H.1` | local hypothesis |
| 579 | `rw` | `Set.mem_singleton_iff` | core or Mathlib lemma |
| 579 | `rw` | `Cfg.mapState_state` | theorem (other file) |
| 584 | `rw` | `R.run` | local hypothesis |
| 584 | `rw` | `hs'` | local hypothesis |
| 655 | `rw` | `hend` | local hypothesis |
| 662 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 664 | `rw` | `hs` | local hypothesis |
| 664 | `rw` | `hD` | local hypothesis |
| 664 | `rw` | `hτ` | local hypothesis |
| 664 | `rw` | `hn` | local hypothesis |
| 708 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 712 | `rw` | `hr` | local hypothesis |
| 712 | `rw` | `hR` | local hypothesis |
| 712 | `rw` | `hinp` | local hypothesis |
| 713 | `change` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 728 | `rw` | `Nat.lt_one_iff.mp` | core or Mathlib lemma |
| 728 | `rw` | `h₀` | local hypothesis |
| 734 | `rw` | `H` | local hypothesis |
| 734 | `rw` | `h1` | local hypothesis |
| 734 | `rw` | `hstep` | local hypothesis |
| 736 | `rw` | `Cfg.mapState_state` | theorem (other file) |
| 737 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 738 | `rw` | `hn` | local hypothesis |
| 740 | `rw` | `Cfg.mapState_output` | theorem (other file) |
| 743 | `rw` | `hstep` | local hypothesis |
| 744 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 745 | `rw` | `hq'` | local hypothesis |
| 749 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 750 | `rw` | `show` | core or Mathlib lemma |
| 757 | `rw` | `hs₁` | local hypothesis |
| 759 | `rw` | `hstep` | local hypothesis |
| 761 | `rw` | `hstep` | local hypothesis |
| 765 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 766 | `rw` | `Function.update_idem` | core or Mathlib lemma |
| 766 | `rw` | `zonedTape_homeWrite` | theorem (other file) |
| 768 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 769 | `rw` | `if_neg` | core or Mathlib lemma |
| 769 | `rw` | `if_neg` | core or Mathlib lemma |
| 770 | `show` | (a `show`/`change` goal: reduces only this file's own definitions and structure projections; confirmed by the seal) | — |
| 771 | `rw` | `if_neg` | core or Mathlib lemma |
| 772 | `rw` | `hstep` | local hypothesis |
| 774 | `rw` | `hstep` | local hypothesis |
| 782 | `rw` | `H.1` | local hypothesis |
| 782 | `rw` | `Set.mem_singleton_iff` | core or Mathlib lemma |
| 782 | `rw` | `Cfg.mapState_state` | theorem (other file) |
| 784 | `rw` | `Nat.lt_one_iff.mp` | core or Mathlib lemma |
| 784 | `rw` | `h₀` | local hypothesis |
| 787 | `rw` | `h1` | local hypothesis |
| 787 | `rw` | `hs₁` | local hypothesis |
| 798 | `rw` | `tt_τ_of_lt` | own definition/lemma |
| 798 | `rw` | `Nat.add_le_add_iff_right` | core or Mathlib lemma |

Other-file definitions passed to a rewriting tactic: 0
