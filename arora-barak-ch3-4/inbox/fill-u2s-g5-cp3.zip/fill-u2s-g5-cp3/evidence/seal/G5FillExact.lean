import Mathlib.Data.Nat.Log
import TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction
import TCSlib.Complexity.TuringMachine.Build.ZoneRebalance
import TCSlib.Complexity.TuringMachine.Build.ZoneStep

/-! Semantic-duplication probe: the fill's privates whose statements mention no definition of
the fill's own file, posed to `exact?` (expected: no library lemma closes them, exit 1), and the
one that does (`tt_fin_two`, reported). -/

open Turing

example (j : Fin 2) (hj : j ≠ 0) : j = 1 := by exact?

example {k : ℕ} {S S' : Type} {x : List (ZoneSym k)} (D : ZoneData k) (d : Cfg 2 (ZoneSym k) S x)
    (hp : zoneRowPre D d) (s : S') (hs : d.state.isSome) (h1 : d.workTapePos 1 = 0)
    (d' : Cfg 2 (ZoneSym k) S' x) (hst : d'.state = some s)
    (hw : d'.workTapes = fun j => if j = 0 then zonedTape D.2 else fun _ => none)
    (hpos : d'.workTapePos = fun _ => 0) (hi : d.inputPos = d'.inputPos)
    (ho : d.output = d'.output) :
    d.mapState (fun _ => s) = d' := by exact?
