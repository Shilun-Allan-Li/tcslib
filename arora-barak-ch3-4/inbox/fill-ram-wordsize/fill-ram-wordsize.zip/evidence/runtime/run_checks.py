from pathlib import Path
import subprocess,os,sys,time,datetime,json
ROOT=Path('/private/tmp/fill-ram-wordsize-20261117')
WT=Path('/Users/seyoonr/.codex/worktrees/296c/tcslib-exchange')
OL=ROOT/'oleans'
LOG=ROOT/'evidence/logs'
env=os.environ.copy(); env['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+env['PATH']; env['TCSLIB_LEAN_SLOTS']='3'
def run(module,label=None,compile=True):
 path=module.replace('.','/')+'.lean' if not module.startswith('/') else module
 name=label or module.replace('.','__')
 waits=0
 while True:
  ps=subprocess.check_output(['ps','-Ao','comm,args'],text=True)
  live=[s for s in ps.splitlines() if s.split()[0].endswith('/lean') or s.split()[0]=='lean']
  if len(live)<3:break
  with (LOG/'lean-waits.log').open('a') as f:f.write(f'{datetime.datetime.now(datetime.timezone.utc).isoformat()} {name} waiting, active={len(live)}\n')
  time.sleep(5); waits+=1
 log=LOG/(name+'.log')
 with log.open('w') as f:
  f.write(f'START {datetime.datetime.now(datetime.timezone.utc).isoformat()} {path} lean_processes_before={len(live)} waits={waits}\n');f.flush()
  wrapper='leanelab-o.sh' if compile else 'leanelab.sh'
  args=['/usr/bin/time','-l','bash',str(WT/'devtools/seyoon'/wrapper),str(WT),str(OL),path]
  if compile:args.append(str(OL))
  start=time.time(); p=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  f.write(f'END {datetime.datetime.now(datetime.timezone.utc).isoformat()} EXIT {p.returncode} SECONDS {time.time()-start:.3f}\n')
 text=log.read_text(); ok=p.returncode==0 and 'error:' not in text
 print(f'{name}: exit={p.returncode}, errors={text.count("error:")}, sorry={text.count("declaration uses")}, seconds={time.time()-start:.1f}',flush=True)
 if not ok: print(text[-5000:],flush=True)
 return ok
if __name__=='__main__':
 if sys.argv[1]=='bootstrap':
  order=(LOG/'bootstrap-order.txt').read_text().splitlines()
  for m in order:
   if not run(m): sys.exit(1)
  (LOG/'bootstrap-result.log').write_text(f'base=81557aad15a7123fa7e006f53310b5f702e0b0cd\nmodules={len(order)} failed=0\n')
 else:
  sys.exit(0 if run(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else None,not sys.argv[1].startswith('/')) else 1)
