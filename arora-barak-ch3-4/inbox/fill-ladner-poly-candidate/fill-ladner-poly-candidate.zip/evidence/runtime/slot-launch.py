import sys,subprocess,time,datetime
from pathlib import Path
log=Path('/private/tmp/fill-ladner-poly-candidate/evidence/logs/concurrency.log')
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
while True:
    p=subprocess.run(['ps','-axo','comm='],text=True,capture_output=True,check=True)
    count=sum(c.strip().split('/')[-1]=='lean' for c in p.stdout.splitlines())
    with log.open('a') as out: out.write(f'{stamp()} SLOT-HELD COUNT {count} {sys.argv[1]}\n')
    if count<3: break
    with log.open('a') as out: out.write(f'{stamp()} WAIT count={count} {sys.argv[1]} after shared-slot acquisition; recount in 10s\n')
    time.sleep(10)
sys.exit(subprocess.run(sys.argv[2:]).returncode)
