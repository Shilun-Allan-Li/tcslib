from pathlib import Path
import sys,subprocess,zipfile,hashlib,datetime
root=Path('/private/tmp/fill-ladner-poly-candidate')
wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-poly-candidate/tcslib-exchange')
exchange=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-exchange')
out=exchange/'arora-barak-ch3-4/inbox/fill-ladner-poly-candidate'
out.mkdir(parents=True,exist_ok=True)
name=sys.argv[1]; report=Path(sys.argv[2]).read_text()
patch=subprocess.check_output(['git','-C',str(wt),'diff','fe8a8520f65a9feaa4c960c11874b68ebf8798db','--','TCSlib/Complexity/Diagonalization/Ladner.lean'])
source=(wt/'TCSlib/Complexity/Diagonalization/Ladner.lean').read_bytes()
manifest='UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n'+hashlib.sha256(source).hexdigest()+'  Ladner.lean\n'+hashlib.sha256(patch).hexdigest()+'  Ladner.patch\n'
zpath=out/name
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('REPORT.md',report)
    z.writestr('Ladner.lean',source)
    z.writestr('Ladner.patch',patch)
    z.writestr('SHA256SUMS',manifest)
    for n in ['run.py','slot-launch.py','lean-slot.sh','hold-slot.py','sync.py','prepare-probes.py','package.py']:
        if (root/n).exists(): z.write(root/n,'evidence/runtime/'+n)
    for p in sorted((root/'evidence/logs').glob('*')):
        if p.is_file(): z.write(p,'evidence/logs/'+p.name)
    for p in sorted((root/'probes').glob('*.lean')):
        z.write(p,'evidence/probes/'+p.name+'.txt')
print(zpath)
print('SHA256',hashlib.sha256(zpath.read_bytes()).hexdigest())
