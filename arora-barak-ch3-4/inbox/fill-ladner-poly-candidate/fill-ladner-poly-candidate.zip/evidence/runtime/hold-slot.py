import os,sys,time,datetime
from pathlib import Path
pid=int(sys.argv[1]); log=Path('/private/tmp/fill-ladner-poly-candidate/evidence/logs/coordination.log')
with log.open('a') as out: out.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+f' ACQUIRED ~/.lean-slots reservation for existing serialized bootstrap controller {pid}\n')
while True:
    try: os.kill(pid,0)
    except ProcessLookupError: break
    time.sleep(2)
with log.open('a') as out: out.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' RELEASE bootstrap slot reservation\n')
