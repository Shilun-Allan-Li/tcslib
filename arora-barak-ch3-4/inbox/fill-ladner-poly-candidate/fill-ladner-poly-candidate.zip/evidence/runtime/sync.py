from pathlib import Path
import subprocess
wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-poly-candidate/tcslib-exchange')
name='TCSlib/Complexity/Diagonalization/Ladner.lean'
base=subprocess.check_output(['git','-C',str(wt),'show','fe8a8520f65a9feaa4c960c11874b68ebf8798db:'+name],text=True)
assert base.endswith('end Complexity\n')
new=Path('/private/tmp/fill-ladner-poly-candidate/partA.lean.txt').read_text()
(wt/name).write_text(base[:-len('end Complexity\n')]+new+'\nend Complexity\n')
print('Rebuilt from exact base with one additive private section')
