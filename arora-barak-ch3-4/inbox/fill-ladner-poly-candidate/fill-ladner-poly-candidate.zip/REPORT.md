# Ladner polynomial-time candidate test

Complete through private `Complexity.ladner_candidate_FP`, with the exact required linear SAT verifier hypothesis and the route's exact candidate semantics. This fill proves no Ladner target. No escalation or open proof obligation remains in the delivered scope. Optional `memoInit`/`memoStep` were left for part B.

Base: `fe8a8520f65a9feaa4c960c11874b68ebf8798db` (#310). Local branch: `fill/ladner-poly-candidate`, never rebased. Work was done outside the exchange checkout in `/Users/seyoonr/.codex/worktrees/fill-ladner-poly-candidate/tcslib-exchange`. Records pin: `d6f7946706984db15349d482e9d04c529d0a38fc`; initial exchange pin: `88dcdab323199b73c475e0f62a9f7bddff9af6b2`. The exchange was pulled before reading and before each delivery push.

The bundle's SHA-256 was checked before reading: `bbb7206fa72e77f205d167a00e7a052ac3c62b2694a143062afcdc930a5e1876`, 16 sections. A delivery recheck is in `evidence/logs/bundle-verification.log`.

The only modified tracked source file is `TCSlib/Complexity/Diagonalization/Ladner.lean`: 1,054 insertions, 57 private declarations (19 definitions and 38 proofs). Every byte of the base file is preserved after removing the added section. The approved imports were already present, so no imports changed. No new public declarations, admissions, axioms, simp attributes, or library files were introduced. All six existing targets, their statements and bodies, and every existing private leaf remain byte-identical.

## Construction and statement fidelity

All prescribed part-A definitions and theorem types are retained in meaning, including the literal candidate handoff with only `linear` as its premise. No statement correction was necessary. Extra private helpers expose numeric memo normalization/lookup, context and padding guards, sentinel deletion, and bounded unary query-count initialization.

The simulator's clock is polynomial in the numeric deadline. `ladner_short_deadline` bounds that deadline by `n³`, `ladner_numeric_envelope` transfers it to the simulator's fixed degree, and `ladner_query_preparation` explicitly supplies an FP machine and setup clock. `ladner_composition_clock` includes the exact overhead `2*T₁ + T₂ + 2` of `FinTM.exists_comp_on_image`.

The short SAT machine consumes the linear-verifier hypothesis through `exists_proj_decider 1 1`; its short-image transfer pays both preparation and SAT search costs. Padding syntax uses saturated power even for arbitrary malformed table exponents. A public `mapW` normalizes every table entry before the public `getW` reading; entry count comes from `countW`, not serialized byte length. The guarded SAT image uses an empty default and masks its verdict, without any assumption about SAT of the empty word.

The query-count initialization doubles a unary accumulator for `log₂ n+1` rounds. Its private state transformation has an explicit length cap, and its entire initialized orbit is bounded by `8(|C|+1)`. It is an application of the existing public iterator, not a new machine or generic host. The candidate scan uses the same public iterator: `ladner_test_orbit` proves exact counters and the conjunction flag on every reached state; `ladner_test_size` proves `12(|C|+1)` for every iteration, including after termination. The final scan runs `2(|C|+1)` rounds and masks the readout by the context guard. Nested SAT and simulator work is included in the FP step proof. No monotonicity of `ladnerH` is assumed, and no Ladner target is cited.

## New declarations

| Declaration | Kind | Role |
|---|---|---|
| `ladner_values` | def | Read the numeric memo entries through `BinArith.decWords`. -/. |
| `ladner_shortWords` | def | Enumerate every short word by deleting the high sentinel bit of a positive rank. -/. |
| `ladner_stage` | def | Select the least successful index against the supplied memo values, or the cap. -/. |
| `ladner_candidate` | def | The candidate predicate checks context consistency and every short input. -/. |
| `ladner_validQuery` | def | A simulator query contains an index below the double logarithm and a short input. -/. |
| `ladner_queryCode` | def | Invalid queries use the empty code; valid ones use the canonical index bits. -/. |
| `ladner_queryInput` | def | Invalid queries use the empty simulator input. -/. |
| `ladner_queryDeadline` | def | Invalid queries use deadline zero; valid ones use the indexed deadline. -/. |
| `ladner_queryPrep` | def | Serialize the guarded query in the uniform simulator's input format. -/. |
| `ladner_ctxGuard` | def | Check the candidate context before using its numeric index. -/. |
| `ladner_wordVerdict` | def | A single rank's verdict includes every guard and the acceptance equivalence. -/. |
| `ladner_queryCount` | def | The number of words in the bounded short-input scan. -/. |
| `ladner_testInit` | def | Initialize the remaining count, completed rank, and conjunction flag. -/. |
| `ladner_testStep` | def | One transition of the candidate scan, intended for `BinArith.polyTimeComputable_iterate`. -/. |
| `ladner_testOut` | def | Read the conjunction flag of the candidate scan. -/. |
| `ladner_shortWords_complete` | theorem | The sentinel enumeration contains exactly the words of length at most its bound. |
| `ladner_shortWords_count` | theorem | The short-input scan has at most twice the stage length plus two queries. -/. |
| `ladner_square_le_power` | theorem | A uniform elementary bound used to charge the double logarithm. -/. |
| `ladner_short_deadline` | theorem | Short indexed simulations have a deadline bounded by the cube of the stage length. |
| `ladner_numeric_envelope` | theorem | The uniform simulator's numeric deadline cost has a polynomial stage envelope. |
| `ladner_composition_clock` | theorem | Polynomial preparation and an image budget absorb the exact composition overhead. -/. |
| `ladner_log_eq_bits_length` | theorem | The floor binary logarithm is the canonical binary length minus one. `Complexity.LogProg.length_bits_eq_log` supplies the nonzero case. -/. |
| `ladner_binary_log_FP` | theorem | The binary floor logarithm is polynomial-time, including noncanonical inputs. -/. |
| `ladner_short_SAT_machine` | theorem | A linear SAT verifier yields the exact exponential short-SAT search clock. |
| `ladner_short_SAT_envelope` | theorem | The short-SAT search clock is polynomial when the queried word is logarithmic. |
| `ladner_simulation_on_image` | theorem | Polynomial query preparation and a polynomial numeric budget suffice for simulation. |
| `ladner_short_SAT_on_image` | theorem | Short SAT evaluation on an FP-prepared image has polynomial total cost. |
| `ladner_validQuery_FP` | theorem | The query guard is an FP test of canonical binary lengths and indices. -/. |
| `ladner_query_preparation` | theorem | The guarded simulator query has a polynomial preparation machine and clock. |
| `ladner_query_budget` | theorem | The simulator's guarded numeric clock is polynomial in the serialized query length. |
| `ladner_table_FP` | theorem | Canonicalize all memo entries using the public encoded-list map. -/. |
| `ladner_values_length_FP` | theorem | The number of numeric memo entries is available in binary in polynomial time. -/. |
| `ladner_values_length_le` | theorem | Numeric memo entries are no more numerous than their serialized input bits. `Complexity.BinArith.length_decWords_le` supplies the bound. -/. |
| `ladner_get_value_FP` | theorem | Lookup of a memo exponent is FP after canonicalizing the table through `mapW`. -/. |
| `ladner_tableSyntax` | def | Check the padding syntax against an exponent read from the supplied table. -/. |
| `ladner_tableSyntax_FP` | theorem | Table-dependent padding syntax is FP, even for enormous malformed exponents. |
| `ladner_pad_guard_FP` | theorem | The short-word guard relative to the memo entry count is an FP predicate. -/. |
| `ladner_short_pad_FP` | theorem | Table-dependent padding membership of short words is polynomial-time. |
| `ladner_ctxGuard_FP` | theorem | The candidate context guard is an FP test of lengths and canonical indices. -/. |
| `ladner_dropLast_FP` | theorem | Deleting the high sentinel bit is FP through reversal and the public tail routine. -/. |
| `ladner_wordVerdict_FP` | theorem | The guarded single-word acceptance equivalence has a polynomial-time test. |
| `ladner_testStep_FP` | theorem | A candidate-scan transition is FP once its single-word verdict is FP. -/. |
| `ladner_queryFuel` | def | The short-word count needs one doubling per bit of the positive stage length. -/. |
| `ladner_queryFuel_length` | theorem | The count-generation counter has exactly `log₂ n + 1` symbols, including at zero. -/. |
| `ladner_queryFuel_power_le` | theorem | The doubling loop's final unary count is linearly bounded by the context length. -/. |
| `ladner_countInit` | def | Initialize the bounded query-count generation through the existing iterator. -/. |
| `ladner_countStep` | def | A bounded doubling transition for query-count initialization; malformed states cannot grow beyond the explicit guard. It is consumed by `BinArith.polyTimeComputable_iterate`. -/. |
| `ladner_countInit_FP` | theorem | Query-count initialization is an FP serialization. -/. |
| `ladner_countStep_FP` | theorem | One guarded query-count doubling transition is polynomial-time. -/. |
| `ladner_count_orbit` | theorem | Every round of bounded query-count generation has the exact doubling value. |
| `ladner_count_size` | theorem | All initialized query-count generation states have a linear serialized envelope. -/. |
| `ladner_testInit_FP` | theorem | The candidate scan's unary budget is constructed in polynomial time with a capped application of the public iterator. |
| `ladner_test_orbit` | theorem | Every initialized scan state has the exact remaining count, completed rank, and flag. |
| `ladner_queryCount_le` | theorem | The number of scan queries is bounded by twice the serialized context length plus two. -/. |
| `ladner_test_size` | theorem | Every state reached by an initialized candidate scan has linear serialized length. -/. |
| `ladner_candidate_readout` | theorem | After the bounded word scan, its masked flag is exactly the candidate predicate. |
| `ladner_candidate_FP` | theorem | The polynomial-time candidate test is the guarded readout of the existing bounded iterator; no Ladner target is used or proved here. |

## Other-file definitions and published readings

The production additions contain no explicit foreign-definition `simp`, `rw`, or `unfold` argument. Core/Mathlib function composition reduces only by `rfl` when needed; the explicit rewrite/simplifier inputs are equation lemmas.

| Foreign definition or interface | Reading/contract used |
|---|---|
| `PolyTimeComputable` | `polyTimeComputable_iff`; FP closure contracts `comp`, `pairEncode`, `append`, `polyTimeComputable_ite/and/not`, constant/id/unary/polynomial-unary and linear-machine bridge |
| `FinTM.ComputesFunInTime` | `FinTM.computesFunInTime_iff` |
| `FinTM.ComputesInTime` | `ComputesInTime.mono`, simulator contracts, and public composition contracts; no body read |
| `FinTM.DecidesInTime` | `FinTM.decidesInTime_iff` |
| `P` | `mem_P_iff` |
| `SAT` | The explicit `linear` verifier hypothesis; SAT is otherwise opaque. `SAT_exists_linear_verifier` is available at the pin, but keeping the hypothesis is authorized by the brief. |
| `LogProg.bitsVal` | `bitsVal_bits`, the explicit lambda result of `polyTimeComputable_normBits`, and `length_bits_eq_log`/`lt_two_pow_bits`/binary-length bounds |
| `pairFstD`, `pairSndD` | `pairFstD_pairEncode`, `pairSndD_pairEncode`, projection length bounds, `pairFstD_nil`, and `BinArith.iterate_pairSndD_nil 1` |
| `pairEncode` | `length_pairEncode` and projection equations; pairing closure contracts |
| `BinArith.decWords` | `length_decWords_le`; accessed as the list read by `mapW_pairEncode` and `countW_eq`; already irreducible at the pin |
| `BinArith.encWords` | `mapW_pairEncode` and `getW_pairEncode_bits`; never unfolded |
| `BinArith.mapW` | `mapW_pairEncode` on arbitrary table words, `polyTimeComputable_mapW` |
| `BinArith.countW` | `countW_eq`, `polyTimeComputable_countW` |
| `BinArith.getW` | `getW_pairEncode_bits`, `polyTimeComputable_getW` |
| `BinArith.add/sub/mul` | Canonical `add_pairEncode`, `sub_pairEncode`, `mul_pairEncode` equations and FP contracts; arbitrary index/table words are normalized first |
| `BinArith.lt/le/beq` | Canonical comparison equations and FP contracts |
| `BinArith.powCap` | `powCap_pairEncode` and `polyTimeComputable_powCap` |
| `expCode` | Its public `simulator_accepts` and `simulator_rejects` structure-field contracts and degree; no choice witness read |
| `CodeTM.toFinTM` | Appears opaquely in the simulator relation; no body read |
| `MultiTapeTM.indicator` | `indicator_of_mem`, `indicator_of_not_mem` |
| Public iterator | `BinArith.polyTimeComputable_iterate` with explicit FP init/step and all-orbit bounds for both initialization and candidate scans |
| Existing private Ladner parser | `ladner_parse_FP`, `ladner_parseWord`, `ladner_parsed_length`, `ladner_pad_membership`; all unchanged, in the owned file |

`isNilB` was sealed as a conservative extra. It is not read by the new production proofs: nil tests use the explicit predicate supplied by `polyTimeComputable_isNil`. No missing `isNilB` reader was invented or assumed.

Public-fact searches and candidate inspection are recorded in `proof-search.log`; they are not claimed exhaustive. In particular, the binary logarithm cites the existing `LogProg.length_bits_eq_log`, parser facts are reused, and arbitrary tables use the published map/count/lookup equations. The route explicitly asks for the sentinel-rank representation rather than private EXP enumeration facts. Its owner-local core-bit argument has structural similarity to existing inline sentinel arguments (including the owned file's padded-index proof and `NTimeDiag.stageCode_frequently`), but no standalone public lemma in the approved import closure states the needed bounded enumeration result. No existing proof text was copied; no known public fact was rederived. There is no new host or public API request.

## Verification

All final checks listed below passed. Earlier failed draft/setup logs are retained and do not count as successful verification: `ladner-draft-1/2` record routine proof syntax/equality corrections; `sealed-1` tried to reapply an existing irreducibility attribute to `decWords`; `axioms-1/2` used invalid scratch theorem-wrapper syntax/type inference. `axioms-3` uses valid public proof aliases and is the authoritative 38-proof axiom walk. The first unsealed delta-control attempt compared the recursive `bitsVal` as a whole function; that comparison was not a suitable baseline and was replaced by the applied constructor control. No failed probe output was accepted as evidence.

The production seal makes 26 foreign definitions opaque (25 explicit local attributes plus `decWords`, already opaque) for the entire added section. The source elaborates under that seal. Delta-control probes use Lean's default definitional equality on each constant versus its stored body, equivalent to testing an `rfl` delta goal. The recursive `bitsVal` control applies both sides to `[]`, so its unsealed constructor equation can reduce; its sealed version must fail. This avoids spelling inaccessible private body constants. The unsealed controls account for `decWords` already being irreducible at the base; the sealed controls must reject every delta comparison. Public reader/contract controls are checked separately under the same seal.

## Environment, waits, and exceptions

- Preflight: macOS 26.5.2 arm64, 12 CPUs, physical memory 19327352832 bytes (18 GiB). `memory_pressure` reported 47% system-wide memory free (about 8.46 GiB), used as the native macOS analogue of available-memory headroom, above the 4 GiB floor. Initial APFS filesystem free space for worktree and scratch was 229155246080 bytes, above 12 GiB. `vm_stat`, `memory_pressure`, `df -k`, `mount`, and `statvfs` replace Linux-only cgroup, `/proc`, `df -B1` and `df -T` checks. The native-memory interpretation is disclosed rather than presented as a Linux cgroup measurement.
- Existing pinned Lean 4.25.0 is used. No toolchain download, runtime shim, Lake command, cache fetch, or `lake build` was run. The approved exact-pin symlink alternative links this worktree's `.lake/packages` to the populated campaign package tree. All 11 present package URLs and commits match the manifest; four documentation packages are absent and not imported. All 46 direct Mathlib roots elaborate and no package olean is zero-sized. No other session's TCSlib olean tree was reused: all 138 prerequisite modules were compiled into this fill's own `/private/tmp/fill-ladner-poly-candidate/oleans` tree. Checkpoint 2's “137” prerequisite count was an inventory typo; `runs.tsv` records 138, all exit 0.
- The initial sandbox `git pull` and `ps` failed on host metadata/process access. Pull was rerun through authorized host access. The denied ps pipeline's printed zero was discarded before any Lean launch. All actual launches use checked host `ps -axo comm=` output, counting both bare `lean` and paths ending `/lean`; counts of three trigger timestamped waits and recounts. At most one own Lean process runs at a time. Checks use `-j4` under `nice -n 10`, with native `/usr/bin/time -l` time and peak-memory logs. No self-imposed timeout or process interruption was used.
- Initially the serialized bootstrap used the process-count gate and repository leanelab slots under `~/.tcslib-scratch/locks`. After the user explicitly authorized worker coordination, seq-zk, derand and sc-garble explained their separately issued `~/.lean-slots` protocol. The issued wrapper was copied unchanged (SHA-256 `ff64d8d5b6baf4e7b1c15172a7faeb70246f22c6acf76134bbdb70c017f41f1a`). To avoid interrupting an active module/controller or losing its exit status, one issued slot was reserved for the remainder of that bootstrap, about 09:07:05–09:12:40 UTC. This temporarily held a slot between modules. A waiting worker requested release at boundaries and was informed of the temporary bridge and its imminent completion. The reservation released automatically, and a gap over ten seconds preceded further checks. All subsequent checks acquire and release an issued slot individually and recount processes after acquisition. After observing that a count-before-slot poll could miss brief inter-module gaps, later final checks acquire the atomic slot first and then perform the mandatory process count immediately before Lean. Peers voluntarily offered a brief dispatch gap; no running Lean process was interrupted. Both the initial two-lock-domain interval and the temporary reservation are disclosed; no cap overrun was observed.
- Resource messages were sent only under direct human authorization. No proof work was delegated; no other worker's processes, package tree, source or deliverables were changed. Logs remain in their original `evidence/logs` locations throughout execution; zips contain snapshots, not moved live logs.

## Delivery

Cumulative checkpoints were pushed only to `arora-barak-ch3-4/inbox/fill-ladner-poly-candidate/` on `exchange/pass-shelat-ch5-8`: checkpoint 1 at `ea2ab4fd5` (preliminary), checkpoint 2 at `90f60c405` (full elaboration and seal passed). The final zip contains this report, the exact delivered `Ladner.lean`, the patch against the pinned base, checks, axiom outputs, probes as `.lean.txt`, launch scripts, and the concurrency log. Only the authorized inbox paths are staged/committed for exchange delivery, after `git pull --rebase`; pushes never use force. No other branch is pushed and no PR is opened.

## Final check results

Local source commit (not pushed): `8d5502cf1f520b800a151ba32fe5626a851a383f`.

| Check | Log | Exit | Result |
|---|---|---|---|
| Fresh bootstrap | `bootstrap-001.log through bootstrap-139.log (127 skipped)` | 0 | 138 prerequisite modules; all zero |
| Mathlib cache roots | `mathlib-roots.log` | 0 | 46 roots; no errors |
| Full source, plain | `ladner-draft-3.log` | 0 | zero errors; four inherited warnings |
| Foreign-definition seal | `sealed-2.log` | 0 | 26 opaque definitions; zero errors |
| Public scratch axiom aliases | `axioms-3.log` | 0 | 38 proofs; only standard axioms |
| Unsealed delta controls | `delta-unsealed-2.log` | 0 | 25 comparisons true; decWords already opaque |
| Sealed delta controls | `delta-sealed-1.log` | 0 | all 26 delta comparisons false |
| Sealed reader/contract controls | `reader-controls-1.log` | 0 | public readers usable |
| Final Ladner olean | `ladner-final.log` | 0 | fresh nonempty olean; four inherited warnings |
| Final facade olean | `facade-final.log` | 0 | fresh nonempty olean; no warnings |
| Toolchain | `toolchain-version.log` | 0 | Lean 4.25.0, commit cdd38ac5115bdeec5f609e9126cce00f51ae88b3 |

Final owned-file warnings (the only warnings in `ladner-final.log`):

```text
TCSlib/Complexity/Diagonalization/Ladner.lean:197:8: warning: declaration uses 'sorry'
TCSlib/Complexity/Diagonalization/Ladner.lean:205:8: warning: declaration uses 'sorry'
TCSlib/Complexity/Diagonalization/Ladner.lean:522:8: warning: declaration uses 'sorry'
TCSlib/Complexity/Diagonalization/Ladner.lean:533:8: warning: declaration uses 'sorry'
```

The facade check has zero errors and zero warnings. The final source and facade both emitted fresh, nonempty oleans into this fill's scratch tree. Freeze audit, `git diff --check`, and the proof-sketch audit pass. The source has 1,837 lines; size did not drive a split outside the owned-file scope.

Diff against the base:

```text
 TCSlib/Complexity/Diagonalization/Ladner.lean | 1054 +++++++++++++++++++++++++
 1 file changed, 1054 insertions(+)
```

Authoritative axiom prints from the successful public scratch aliases (the failed wrapper-setup logs are not evidence):

```text
'Complexity.fill3_axioms_ladner_shortWords_complete' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_shortWords_count' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_square_le_power' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_short_deadline' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_numeric_envelope' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_composition_clock' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_log_eq_bits_length' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_binary_log_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_short_SAT_machine' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_short_SAT_envelope' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_simulation_on_image' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_short_SAT_on_image' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_validQuery_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_query_preparation' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_query_budget' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_table_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_values_length_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_values_length_le' depends on axioms: [propext, Quot.sound]
'Complexity.fill3_axioms_ladner_get_value_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_tableSyntax_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_pad_guard_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_short_pad_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_ctxGuard_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_dropLast_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_wordVerdict_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_testStep_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_queryFuel_length' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_queryFuel_power_le' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_countInit_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_countStep_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_count_orbit' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_count_size' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_testInit_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_test_orbit' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_queryCount_le' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_test_size' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_candidate_readout' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill3_axioms_ladner_candidate_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
```

The concurrency log records 55 count-triggered wait events with timestamps and recounts. Maximum observed launch-gate count: 3; launches waited at three. Maximum logged resident set size was 3178774528 bytes in `bootstrap-084.log`. Shared wrapper acquisition/release events are retained separately.

Source SHA-256: `44db2e6e57f34d4a391d9e1d6b33af8cc895964eb3e13624cbd7d7245ec62986`. The zip's `SHA256SUMS` also records the exact patch hash.

The local source branch remains unpushed and clean at `8d5502cf1f520b800a151ba32fe5626a851a383f`. After the initial final-zip push, the app archive tool refused cleanup with “The task's primary checkout cannot be removed.” The managed worktree is therefore retained at the path above; no manual removal or protection bypass was attempted. This report and the final zip were updated in a new exchange commit to record the observed retention outcome. The verified Lean source and patch did not change.

Artifact validation passed: zip integrity and required contents, source/patch SHA-256 checks, no native/olean build products, and clean application of the patch to the exact base reproducing the delivered source byte-for-byte. See `evidence/logs/package-verification.log`.

Delivery workflow deviation: while correcting the post-delivery worktree-retention record, `git pull --rebase` refused because the already-tracked final zip had been regenerated and was unstaged. That metadata-only correction was committed and fast-forward pushed at `8b608325b` before rerunning the pull successfully. Before this final metadata delivery, the exchange was successfully pulled with the artifact clean, and only then was the final zip regenerated/staged. This departure from the requested pull-first ordering is disclosed; no source, target, patch, other folder or remote branch changed, and no force push was used.
