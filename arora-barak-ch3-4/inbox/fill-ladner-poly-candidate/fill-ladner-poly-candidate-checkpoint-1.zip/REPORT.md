# Ladner polynomial candidate — checkpoint 1

Base: `fe8a8520f65a9feaa4c960c11874b68ebf8798db`.
Local branch: `fill/ladner-poly-candidate`; never rebased.
Bundle SHA-256 verified: `bbb7206fa72e77f205d167a00e7a052ac3c62b2694a143062afcdc930a5e1876` (16 sections).

This is a cumulative preliminary checkpoint, not a verified fill. The separate worktree contains an additive private section with the requested semantic specifications and draft proofs for arithmetic/counting, guarded query preparation and budgeting, image simulation and short-SAT transfer, table normalization, short padding, single-word verdict, and scan-step FP. Existing declarations are preserved byte-for-byte. No Ladner target is proved and no new admissions were added.

Verification is waiting for the fresh pinned import-closure bootstrap. Through module 69, every completed bootstrap check has exited zero. The machine-wide count reached three repeatedly, so the serialized launcher waited and logged timestamps before continuing. The candidate scan initialization, orbit, size bound, readout, and `ladner_candidate_FP` are pending and are not represented by admitted declarations.

Environment: macOS APFS, 12 CPUs, 18 GiB physical memory; initial memory_pressure free percentage 47% (about 8.46 GiB), filesystem free 229155246080 bytes. Native macOS resource commands replace Linux-only /proc/cgroup/df flags. Packages are symlinked to the populated campaign package tree; every present package URL and revision matches the pinned manifest. All TCSlib oleans are freshly bootstrapped into this fill's own scratch tree. No lake build or cache fetch was run. The initial sandbox ps denial was detected before any Lean launch; all Lean-launch counts use checked host ps output, matching bare and full-path lean commands. One own Lean at a time, -j4, nice 10.

Included: current Ladner.lean, additive patch against the base, current check/resource/concurrency logs, and the serialized launcher. Later checkpoints and the final report supersede this preliminary status.
