from pathlib import Path
import os,sys,subprocess,time,datetime,fcntl
ROOT=Path('/private/tmp/fill-ladner-poly-candidate')
WT=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-poly-candidate/tcslib-exchange')
OL=ROOT/'oleans'
LOG=ROOT/'evidence/logs'
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(label,file,emit=False):
    with (ROOT/'own-lean.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        while True:
            ps=subprocess.run(['ps','-axo','comm='],text=True,capture_output=True,check=True)
            count=sum(c.strip().split('/')[-1]=='lean' for c in ps.stdout.splitlines())
            with (LOG/'concurrency.log').open('a') as out: out.write(f'{stamp()} COUNT {count} {label}\n')
            if count<3: break
            with (LOG/'concurrency.log').open('a') as out: out.write(f'{stamp()} WAIT count={count} {label}; recount in 10s\n')
            print(f'{stamp()} WAIT count={count} {label}',flush=True)
            time.sleep(10)
        env=dict(os.environ,TCSLIB_LEAN_SLOTS='3')
        script='leanelab-o.sh' if emit else 'leanelab.sh'
        args=['bash',str(WT/'devtools/seyoon'/script),str(WT),str(OL),file]
        if emit: args.append(str(OL))
        start=time.monotonic()
        with (LOG/(label+'.log')).open('w') as out:
            out.write(f'{stamp()} START {file}\n'); out.flush()
            p=subprocess.run(['/usr/bin/time','-l']+args,env=env,cwd=WT,stdout=out,stderr=subprocess.STDOUT)
            out.write(f'{stamp()} END EXIT {p.returncode} elapsed_seconds {time.monotonic()-start:.3f}\n')
        with (LOG/'runs.tsv').open('a') as out: out.write(f'{stamp()}\t{label}\t{p.returncode}\t{time.monotonic()-start:.3f}\t{file}\n')
        print(f'{stamp()} {label} EXIT {p.returncode} elapsed {time.monotonic()-start:.1f}s',flush=True)
        if p.returncode: print((LOG/(label+'.log')).read_text(),flush=True)
        return p.returncode
if sys.argv[1]=='bootstrap':
    modules=(LOG/'facade-order.txt').read_text().splitlines()
    for i,m in enumerate(modules,1):
        if m.endswith('/Ladner') or m=='TCSlib/Complexity/Diagonalization': continue
        code=run(f'bootstrap-{i:03d}',m+'.lean',True)
        if code: sys.exit(code)
elif sys.argv[1]=='check':
    sys.exit(run(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='emit'))
