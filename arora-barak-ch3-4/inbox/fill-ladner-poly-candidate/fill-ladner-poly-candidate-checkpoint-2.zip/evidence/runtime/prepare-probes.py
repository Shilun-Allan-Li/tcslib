from pathlib import Path
import re
r=Path('/private/tmp/fill-ladner-poly-candidate')
wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-poly-candidate/tcslib-exchange')
s=(wt/'TCSlib/Complexity/Diagonalization/Ladner.lean').read_text()
new=(r/'partA.lean.txt').read_text()
names=re.findall(r'^private theorem (ladner_\w+)',new,re.M)
wrappers='\n'.join('theorem fill3_axioms_'+n+' := '+n for n in names)
prints='\n'.join('#print axioms Complexity.fill3_axioms_'+n for n in names)
a=s.removesuffix('end Complexity\n')+wrappers+'\nend Complexity\n'+prints+'\n'
(r/'probes/AxiomWalk.lean').write_text(a)
foreign=['Complexity.PolyTimeComputable','Turing.FinTM.ComputesFunInTime',
'Turing.FinTM.ComputesInTime','Turing.FinTM.DecidesInTime','Complexity.P','Complexity.SAT',
'Complexity.BinArith.encWords','Complexity.BinArith.countW',
'Complexity.BinArith.mapW','Complexity.BinArith.getW','Complexity.BinArith.powCap',
'Complexity.BinArith.mul','Complexity.BinArith.add','Complexity.BinArith.sub',
'Complexity.BinArith.le','Complexity.BinArith.lt','Complexity.BinArith.beq',
'Complexity.LogProg.bitsVal','Complexity.pairFstD','Complexity.pairSndD',
'Turing.pairEncode','Complexity.expCode','Turing.CodeTM.toFinTM',
'Turing.MultiTapeTM.indicator','Complexity.isNilB']
foreign.append('Complexity.BinArith.decWords')
seal='section\nattribute [local irreducible] '+' '.join(n for n in foreign if n != 'Complexity.BinArith.decWords')+'\n'
sealed=s.replace(new,seal+new+'\nend\n')
(r/'probes/Sealed.lean').write_text(sealed)
(r/'evidence/logs/sealed-definitions.txt').write_text('\n'.join(foreign)+'\n')
print('Prepared',len(names),'axiom wrappers and a seal on',len(foreign),'foreign definitions')
