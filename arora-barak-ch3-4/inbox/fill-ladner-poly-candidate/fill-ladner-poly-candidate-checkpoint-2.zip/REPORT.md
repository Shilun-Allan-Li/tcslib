# Ladner polynomial candidate — checkpoint 2

Base: `fe8a8520f65a9feaa4c960c11874b68ebf8798db`. Local branch: `fill/ladner-poly-candidate`; never rebased.
Bundle SHA-256: `bbb7206fa72e77f205d167a00e7a052ac3c62b2694a143062afcdc930a5e1876`, verified before reading; 16 sections.

The implementation is complete through the prescribed private `ladner_candidate_FP`, with its exact linear-verifier hypothesis and the route's exact candidate semantics. This proves no Ladner target. All 57 additions are private, and every byte of the base file is preserved. No new imports, admissions, axioms, simp attributes, public declarations, or machine hosts were added. The extra initialization scan is an explicitly guarded application of the existing public iterator.

Completed checks:
- Fresh bootstrap of all 137 required non-owned/non-facade modules in the 140-module combined closure: every exit code 0. Ladner and the facade are checked separately.
- All 46 direct Mathlib import roots elaborate: exit 0. Every present package matches the manifest, no zero-sized package olean, packages linked via the permitted exact-pin alternative.
- Full Ladner.lean elaboration: exit 0 (`ladner-draft-3.log`), only the four inherited sorry warnings at lines 197, 205, 522, 533.
- Rule 10 seal: exit 0 (`sealed-2.log`), all 26 reached foreign definitions opaque; decWords was already irreducible at the base. The first seal attempt was a setup failure from trying to reapply its existing irreducibility; corrected without enabling unsafe reducibility. No explicit foreign-definition unfold/simp/rw arguments occur in the additions.
- Freeze audit and git diff --check: pass. Diff: only Ladner.lean, 1,054 insertions.

Pending final verification: 38 public scratch axiom wrappers (including candidate_FP), explicit delta controls for the seal, fresh final owned-file olean and the facade. The axiom walk is waiting for a shared Lean slot; the prepared scratch probes are included but are not yet claimed verified. The final report will give the complete declaration/reader inventory and axiom outputs.

Environment and fully disclosed resource decisions:
- Native macOS APFS, 12 CPUs, 18 GiB memory. Initial filesystem free: 229155246080 bytes. memory_pressure reported 47% system-wide memory free (about 8.46 GiB), above the 4 GiB floor. Native commands replace Linux /proc/cgroup and df flags. Existing pinned Lean 4.25.0 is used; no runtime shim, cache fetch or lake build.
- Initial sandbox git pull and ps were denied. git pull was rerun through authorized host access; the failed ps pipeline's printed zero was discarded before any Lean launch. All actual Lean launches use checked host ps output, counting bare lean and full paths ending /lean, with timestamped waits at count >=3. One own Lean at a time, -j4 under nice 10; per-module time and memory logs stay at their original paths.
- Initially the serialized bootstrap used verified process counts and the repository's leanelab slots under ~/.tcslib-scratch/locks. On the user's explicit authorization to coordinate resources, other workers explained their issued ~/.lean-slots protocol. A byte-identical issued lean-slot.sh was adopted (SHA-256 ff64d8d5b6baf4e7b1c15172a7faeb70246f22c6acf76134bbdb70c017f41f1a).
- To avoid interrupting the already-running bootstrap/controller or losing exit statuses, one ~/.lean-slots slot was reserved for its remaining run, 09:07:05–09:12:40 UTC approximately. This held the slot between modules; a waiting worker requested release at boundaries, and was informed that this was a temporary bridge. The reservation released automatically on bootstrap completion. After a >10-second gap, every check uses the issued wrapper per module, with another process count after slot acquisition. No cap overrun was observed; the earlier two lock domains and temporary reservation are disclosed rather than silently treated as a unified protocol.
- Resource-only messages were sent to seq-zk, derand and sc-garble under direct human authorization. No proof delegation, other-worker process changes, shared-package changes or other-worker source access for reuse occurred.

This cumulative checkpoint supersedes checkpoint 1's preliminary proof status. Final delivery remains pending the checks above.
