from pathlib import Path
import re
r=Path('/private/tmp/fill-ladner-final');wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange')
s=(wt/'TCSlib/Complexity/Diagonalization/Ladner.lean').read_text();new=(r/'final-section.lean.txt').read_text()
names=re.findall(r'^private theorem (ladner_\w+)',new,re.M)
wrappers='\n'.join('def fill7_axioms_'+n+' := @'+n for n in names)
prints='\n'.join('#print axioms Complexity.fill7_axioms_'+n for n in names)
assert s.endswith('end Complexity\n')
(r/'probes/AxiomWalk.lean').write_text(s.removesuffix('end Complexity\n')+wrappers+'\nend Complexity\n'+prints+'\n#print axioms Complexity.SAT_H_intermediate\n#print axioms Complexity.ladner\n')
foreign=['Complexity.PolyTimeComputable','Complexity.PolyTimeReducible','Complexity.NPComplete','Complexity.NPHard','Complexity.P','Complexity.NP','Complexity.SAT','Turing.pairEncode','Complexity.BinArith.mulU','Complexity.BinArith.beq']
seal='section\nattribute [local irreducible] '+' '.join(foreign)+'\n'
assert s.count(new)==1
sealed=s.replace(new,seal+new+'\nend\n',1)
a=sealed.index('/-- If P differs from NP, the explicit padded SAT language is in NP')
b=sealed.index('\n\n/-- If P differs from NP, an NP-intermediate language exists.',a)
sealed=sealed[:a]+seal+sealed[a:b]+'\nend\n'+sealed[b:]
(r/'probes/Sealed.lean').write_text(sealed)
(r/'evidence/logs/sealed-definitions.txt').write_text('\n'.join(foreign)+'\n')
header='import TCSlib.Complexity.ClassNP.Reductions\nimport TCSlib.Complexity.ClassNP.PClosure\nimport TCSlib.Complexity.ClassNP.SAT\nimport TCSlib.Complexity.ClassP.BinaryArith.Loops\n\n'
for sealedflag in [False,True]:
 pre=header+('attribute [local irreducible] '+' '.join(foreign)+'\n' if sealedflag else '')
 expr=',\n    '.join('``'+n for n in foreign); expected='false' if sealedflag else 'true'
 body=f'''open Lean Elab Command Meta in
run_cmd do
  liftTermElabM do
    for n in [{expr}] do
      let ci ← getConstInfo n
      let c := mkConst n (ci.levelParams.map Level.param)
      let v := ci.value!
      let ok ← withNewMCtxDepth <| withTransparency .default <| isDefEq c v
      let expected := {expected}
      unless ok == expected do
        throwError m!"delta control {{n}}: got {{ok}}, expected {{expected}}"
      logInfo m!"delta control {{n}}: {{ok}} (expected {{expected}})"
'''
 (r/('probes/DeltaSealed.lean' if sealedflag else 'probes/DeltaUnsealed.lean')).write_text(pre+body)
reader='''open Turing Complexity
open scoped Classical
attribute [local irreducible] '''+' '.join(foreign)+'''
example (f : List Bool → List Bool) : PolyTimeComputable f ↔ ∃ (M : FinTM Bool) (C d : ℕ),
    M.ComputesFunInTime f (fun n => C * (n + 1) ^ d) := polyTimeComputable_iff f
example (L L' : Language Bool) : PolyTimeReducible L L' ↔
    ∃ f : List Bool → List Bool, PolyTimeComputable f ∧ ∀ x, x ∈ L ↔ f x ∈ L' :=
  polyTimeReducible_iff L L'
example (L : Language Bool) : NPComplete L ↔ L ∈ NP ∧ NPHard L := NPComplete_iff L
example (L : Language Bool) : NPHard L ↔ ∀ L' : Language Bool, L' ∈ NP → PolyTimeReducible L' L :=
  NPHard_iff L
example (L : Language Bool) : L ∈ P ↔ ∃ (C d : ℕ) (M : FinTM Bool),
    M.DecidesInTime L (fun n => C * (n + 1) ^ d) := mem_P_iff
example : SAT ∈ NP := SAT_mem_NP
example (a b : List Bool) : pairEncode a b = (a.flatMap fun c => [c, c]) ++ [false, true] ++ b :=
  pairEncode_eq a b
example (a b : List Bool) : (BinArith.mulU (pairEncode a b)).length = a.length * b.length :=
  BinArith.length_mulU a b
example (a b : ℕ) : BinArith.beq (pairEncode (Nat.bits a) (Nat.bits b)) = decide (a = b) :=
  BinArith.beq_pairEncode a b
'''
(r/'probes/ReaderControls.lean').write_text(header+reader)
print('Prepared',len(names),'private-proof axiom aliases, 2 public axiom prints, 10 foreign seals and reader/delta controls')
