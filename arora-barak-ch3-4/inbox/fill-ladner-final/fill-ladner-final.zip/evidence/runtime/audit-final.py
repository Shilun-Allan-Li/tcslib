from pathlib import Path
import subprocess,re,hashlib,json,datetime,sys
r=Path('/private/tmp/fill-ladner-final');log=r/'evidence/logs';wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange');f='TCSlib/Complexity/Diagonalization/Ladner.lean';base='d811bdaaf5e923b2a57f0453135af5c7ee37713a'
a=subprocess.check_output(['git','-C',str(wt),'show',base+':'+f],text=True);s=(wt/f).read_text();new=(r/'final-section.lean.txt').read_text();anchor='/-! ### The theorem and its remaining targets -/'
assert s.count(new)==1 and new+anchor in s
restored=s.replace(new,'',1)
def body(t):
 i=t.index('theorem SAT_H_intermediate');i=t.index(' :=',i)+len(' :=');j=t.index('\n\n/-- If P differs from NP, an NP-intermediate language exists.',i);return i,j
b0,b1=body(a);s0,s1=body(restored);assert restored[s0:s1]==' by\n'+(r/'target-body.lean.txt').read_text().rstrip('\n')
restored=restored[:s0]+a[b0:b1]+restored[s1:];assert restored==a
assert not re.search(r'\b(sorry|admit|axiom)\b',new)
assert not re.search(r'^(@\[simp\]|import |(?:theorem|lemma|def|noncomputable def) )',new,re.M)
assert subprocess.check_output(['git','-C',str(wt),'diff','--name-only',base],text=True).strip()==f
subprocess.run(['git','-C',str(wt),'diff','--check'],check=True)
(log/'freeze-audit.log').write_text('UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\nPASS remove exact added private section and restore only target body reproduces every byte of base '+base+'\nPASS exact prescribed section placement, after NP-membership section\nPASS 8 private declarations (1 definition, 7 proofs), no new public declarations/imports/admissions/simp attributes\nPASS git diff --check; only owned file differs\n')
(log/'diff-stat.log').write_text(subprocess.check_output(['git','-C',str(wt),'diff','--stat',base,'--',f],text=True))
probe=(r/'bundle/campaign/fills/ladner-final/preship/Fill7Target6.lean.txt').read_text()
for name in ['ladner_bounded_pad_reduction','ladner_outside_P','ladner_not_complete']:
 def segment(t):
  i=t.index('private theorem '+name); ends=[m.start() for m in re.finditer(r'\n(?:private theorem |/--|/-!|```)',t[i+1:])];j=i+1+min(ends) if ends else len(t);return t[i:j].strip()
 assert segment(probe)==segment(new),name
(log/'preship-terms.log').write_text('PASS all three pre-shipped proved helper declarations/terms byte-identical apart from new preceding docstrings\nPASS target body equals pre-shipped assembly\n')
proofs=list(re.finditer(r'^private theorem (\w+)',new,re.M));inventory=[]
assert len(proofs)==7 and len(re.findall(r'^private def ',new,re.M))==1
for i,m in enumerate(proofs):
 stops=[v for v in [new.find('\n/--',m.start()),new.find('\n/-!',m.start())] if v>=0]
 end=min(stops) if stops else len(new)
 text=new[m.start():end];doc_start=new.rfind('/--',0,m.start());doc=new[doc_start:m.start()];lines=len(text.split(':=',1)[1].strip().splitlines());assert '[AB09,' in doc
 if lines>20:assert '**Proof sketch.**' in doc,m.group(1)
 inventory.append({'name':m.group(1),'proof_lines_upper_bound':lines,'has_sketch':'**Proof sketch.**' in doc})
(log/'proof-sketch-audit.log').write_text(json.dumps(inventory,indent=2)+'\n')
if '--scope' in sys.argv:
 print('PASS scope/freeze, pre-shipped terms and proof sketches')
 sys.exit(0)
rows=[line.split('\t') for line in (log/'runs.tsv').read_text().splitlines()]
required=['mathlib-roots','ladner-final','sealed-final','axioms-final','delta-unsealed-final','delta-sealed-final','reader-controls-final','facade-final','toolchain-version']
for label in required:
 found=[row for row in rows if row[1]==label];assert len(found)==1 and found[0][2]=='0',label
bootstrap=[row for row in rows if row[1].startswith('bootstrap-') or row[1].startswith('facade-prereq-')];assert len(bootstrap)==138 and all(row[2]=='0' for row in bootstrap)
digest=hashlib.sha256(s.encode()).hexdigest()
assert 'SOURCE_SHA256 '+digest in (log/'ladner-final.log').read_text()
assert 'SOURCE_SHA256_AFTER '+digest in (log/'ladner-final.log').read_text()
for label in ['ladner-final','sealed-final','axioms-final','facade-final']:
 t=(log/(label+'.log')).read_text();assert 'error:' not in t and "declaration uses 'sorry'" not in t,label
assert 'warning:' not in (log/'ladner-final.log').read_text()
for label in ['axioms-final','sealed-final']:
 assert 'SOURCE_SHA256 '+hashlib.sha256((r/'probes'/('AxiomWalk.lean' if label=='axioms-final' else 'Sealed.lean')).read_bytes()).hexdigest() in (log/(label+'.log')).read_text()
ax=(log/'axioms-final.log').read_text();names=['Complexity.fill7_axioms_'+m.group(1) for m in proofs]+['Complexity.SAT_H_intermediate','Complexity.ladner'];allowed={'propext','Classical.choice','Quot.sound'}
for name in names:
 pat="'"+re.escape(name)+"' (?:depends on axioms:\\s*\\[([^\\]]*)\\]|does not depend on any axioms)"
 mm=re.search(pat,ax);assert mm,name
 axs={v.strip() for v in (mm.group(1) or '').split(',') if v.strip()};assert axs<=allowed,(name,axs)
(log/'axiom-audit.log').write_text('PASS '+str(len(names))+' axiom prints: every new private proof, SAT_H_intermediate and ladner; all within propext/Classical.choice/Quot.sound; no sorryAx\n')
for label,truth in [('delta-unsealed-final','true'),('delta-sealed-final','false')]:
 t=(log/(label+'.log')).read_text();assert t.count(' (expected '+truth+')')==10
for label in ['ladner-final','facade-final']:
 t=(log/(label+'.log')).read_text();assert 'FRESH_OLEAN' in t
con=(log/'concurrency.log').read_text();counts=[int(v) for v in re.findall(r'SLOT-HELD COUNT (\d+)',con)];assert max(counts)<3
waits=con.count(' WAIT ')
rss=[]
for p in log.glob('*.log'):
 for n in re.findall(r'(\d+)\s+maximum resident set size',p.read_text(errors='replace')):rss.append((int(n),p.name))
summary={'base':base,'source_sha256':digest,'lines':len(s.splitlines()),'new_private_declarations':8,'new_private_proofs':7,'bootstrap_modules':138,'checks':required,'all_required_exit_zero':True,'new_admissions':0,'owned_errors':0,'owned_warnings':0,'axiom_prints':9,'foreign_sealed_definitions':10,'max_prelaunch_native_count':max(counts),'wait_events':waits,'max_rss_bytes_and_log':max(rss),'failed_draft_checks':[row[1] for row in rows if row[2]!='0']}
(log/'final-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
