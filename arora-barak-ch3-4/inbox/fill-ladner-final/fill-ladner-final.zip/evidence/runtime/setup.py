from pathlib import Path
import subprocess,json,re,hashlib,os
r=Path('/private/tmp/fill-ladner-final'); log=r/'evidence/logs'; wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange')
base='d811bdaaf5e923b2a57f0453135af5c7ee37713a'; f='TCSlib/Complexity/Diagonalization/Ladner.lean'
assert subprocess.check_output(['git','-C',str(wt),'rev-parse','HEAD'],text=True).strip()==base
assert subprocess.check_output(['git','-C',str(wt),'status','--porcelain'],text=True)==''
a=(r/'bundle'/f).read_text(); assert a.startswith('```\n') and a.endswith('```\n');a=a[4:-4]
assert a==(wt/f).read_text()
(log/'source-binding.log').write_text('Framed bundled source byte-identical to pinned base '+base+' after removing outer Markdown fences.\nInitial raw comparison found only those fences.\n')
manifest=json.loads((wt/'lake-manifest.json').read_text()); absent=[]; present=[]
with (log/'package-pins.log').open('w') as out:
 for p in manifest['packages']:
  d=wt/'.lake/packages'/p['name']
  if not d.exists(): absent.append(p['name']);out.write('ABSENT '+p['name']+'\n');continue
  url=subprocess.check_output(['git','-C',str(d),'remote','get-url','origin'],text=True).strip(); rev=subprocess.check_output(['git','-C',str(d),'rev-parse','HEAD'],text=True).strip()
  out.write(p['name']+' '+url+' '+rev+'\n');assert url==p['url'] and rev==p['rev'];present.append(p['name'])
 out.write('PASS all '+str(len(present))+' present package pins match; absent='+','.join(absent)+'\n')
def imports(m): return re.findall(r'^import\s+(\S+)',(wt/(m+'.lean')).read_text(),re.M)
def closure(root):
 seen=set();order=[]
 def visit(m):
  if m in seen:return
  seen.add(m)
  for dep in imports(m):
   if dep.startswith('TCSlib.'): visit(dep.replace('.','/'))
  order.append(m)
 visit(root); return order
owned=closure('TCSlib/Complexity/Diagonalization/Ladner');facade=closure('TCSlib/Complexity/Diagonalization')
(log/'ladner-order.txt').write_text('\n'.join(owned)+'\n');(log/'facade-order.txt').write_text('\n'.join(facade)+'\n')
roots=sorted({d for m in facade for d in imports(m) if d.startswith('Mathlib.')})
(log/'mathlib-roots.txt').write_text('\n'.join(roots)+'\n')
probes=r/'probes';probes.mkdir(exist_ok=True);(probes/'MathlibRoots.lean').write_text(''.join('import '+d+'\n' for d in roots))
assert not [(m,d) for m in facade for d in imports(m) if d.split('.')[0] in absent]
empty=[str(p) for p in (wt/'.lake/packages').rglob('*.olean') if p.stat().st_size==0];assert not empty,empty
(log/'cache-check.log').write_text('Exact-pin package symlink alternative. No Lake/cache fetch.\nZero-sized package oleans: 0\nDirect Mathlib roots: '+str(len(roots))+'\n')
(r/'oleans').mkdir(exist_ok=True)
src=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-exchange/outbox/fills/codex-host-2026-11-15/lean-slot.sh').read_bytes()
(r/'lean-slot.sh').write_bytes(src)
assert hashlib.sha256(src).hexdigest()=='ff64d8d5b6baf4e7b1c15172a7faeb70246f22c6acf76134bbdb70c017f41f1a'
for n in ['run.py','slot-launch.py']:
 s=(Path('/private/tmp/fill-ladner-shrink')/n).read_text().replace('fill-ladner-shrink','fill-ladner-final').replace("LEAN_SLOT_TAG='ladner-shrink'","LEAN_SLOT_TAG='ladner-final'")
 (r/n).write_text(s)
print('Source/pins/cache PASS; closure',len(owned),'facade',len(facade),'Mathlib roots',len(roots))
