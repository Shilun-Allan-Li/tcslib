from pathlib import Path
import subprocess
r=Path('/private/tmp/fill-ladner-final');wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange')
f='TCSlib/Complexity/Diagonalization/Ladner.lean';base='d811bdaaf5e923b2a57f0453135af5c7ee37713a'
s=subprocess.check_output(['git','-C',str(wt),'show',base+':'+f],text=True)
anchor='/-! ### The theorem and its remaining targets -/'
assert s.count(anchor)==1
s=s.replace(anchor,(r/'final-section.lean.txt').read_text()+anchor,1)
a=s.index('theorem SAT_H_intermediate');a=s.index(' :=',a)+len(' :=');b=s.index('\n\n/-- If P differs from NP, an NP-intermediate language exists.',a)
assert s[a:b].strip()=='sorry'
s=s[:a]+' by\n'+(r/'target-body.lean.txt').read_text().rstrip('\n')+s[b:]
current=(wt/f).read_text()
last=(r/'last-synced.lean.txt').read_text() if (r/'last-synced.lean.txt').exists() else subprocess.check_output(['git','-C',str(wt),'show',base+':'+f],text=True)
assert current==last, 'Unexpected independent source edits'
(wt/f).write_text(s);(r/'last-synced.lean.txt').write_text(s)
print('Synced',len(s.splitlines()),'lines')
