# Ladner final fill — target 6 complete

`Complexity.SAT_H_intermediate` is proved, removing the last admission from `TCSlib/Complexity/Diagonalization/Ladner.lean`. The unchanged packaging theorem `Complexity.ladner` now has only standard axioms. No proof frontier or escalation remains.

Base: `d811bdaaf5e923b2a57f0453135af5c7ee37713a`, campaign after #322. Local branch `fill/ladner-final` was created at that exact base and never rebased. Local-only source commit: `3e2e61d04a93ff30e8912ca5814d7d5a3edb3463`. Records pin: `91a58101a87fe27c757584dbfec2924a345432a1`. Dispatch exchange pin: `37ec3ab5885c8acefcaf1e34e037da9d446f1eff`.

The exchange was successfully pulled before the bundle was read. Its SHA-256 `bc582cf1fbbd8eae6f921b1394976f2f2a8ac763168fbaa10b7a6dfc7b967f09` was verified before reading/extraction; all 12 sections were extracted. The bundled source, after removing its Markdown fences, is byte-identical to the pinned base.

## Scope and prescribed terms

Only `Ladner.lean` changes. Its new private section is exactly before `/-! ### The theorem and its remaining targets -/`, after the NP-membership section. The only other change is the final target's body. Removing that section and restoring that body reproduces every byte of the base: all other declarations, imports, docstrings and proof sketches remain unchanged. The target statement/citation/sketch still describe the resulting proof. File size: 2738 lines. No public declaration, host, runtime recursion, import, simp attribute, admission or axiom was added.

All three pre-shipped proved helper declarations/terms (`ladner_bounded_pad_reduction`, `ladner_outside_P`, `ladner_not_complete`) are retained byte-for-byte apart from newly supplied preceding docstrings. The final assembly is exactly the pre-shipped body. The meaning of the binding FP and membership statements is unchanged. `preship-terms.log`, `freeze-audit.log`, `proof-sketch-audit.log` and the patch attest these claims. All new declarations cite AB09 Theorem 3.3 and its proof; the one new proof longer than 20 lines has its adjacent proof sketch.

```text
 TCSlib/Complexity/Diagonalization/Ladner.lean | 126 +++++++++++++++++++++++++-
 1 file changed, 124 insertions(+), 2 deletions(-)
```

## Construction and reuse inventory

| New private declaration | Role and facts searched/cited |
|---|---|
| `ladner_padWord` | Literal input prefix, false separator and `n^(h n)` true bits, as prescribed. |
| `ladner_bounded_pad_length` | List length equations and `Nat.pow_le_pow_left/right` give `n^(h n) ≤ (n+1)^C` and bound the prefix/separator and suffix by `(n+1)^(C+1)`. No exact bounded-pad length theorem was found in the import closure. |
| `ladner_power_cases_FP` | Constructs fixed unary powers by finite compositions of `polyTimeComputable_unary`, `BinArith.polyTimeComputable_mulU` and `length_mulU`; selects exponent values with `polyTimeComputable_beq`, `beq_pairEncode` and `polyTimeComputable_ite`. |
| `ladner_bounded_pad_FP` | Uses the selector's pointwise correctness under the value bound, then existing identity, constant and append FP closures. |
| `ladner_padWord_membership` | Specializes existing `ladner_pad_membership` and `ladner_parse_pad` with core option/product/existential equations; the final-separator uniqueness argument is not reconstructed. |
| `ladner_bounded_pad_reduction` | Pre-shipped `polyTimeReducible_iff` assembly from the two padding leaves. |
| `ladner_outside_P` | Pre-shipped contradiction via the bounded-index target, `SAT_H_eq`, reduction closure of P, `SAT_NPHard` and `P_eq_NP_of_NPHard_mem_P`. |
| `ladner_not_complete` | Pre-shipped contradiction via `NPComplete_iff`, divergence and the shrinking target, then SAT hardness/collapse. |

`proof-search.log` records candidate searches and inspection of the import closure, existing private parser/padding leaves, the binary arithmetic closures and related emitters. These are not claimed an exhaustive duplication certificate. The broader `FormulaKit.polyTimeComputable_unary_pow` was found outside the import closure and depends on an admitted multiplication theorem there; it is not a usable proved dependency under the import freeze. The implementation follows the brief's imported, proved unary rows without copying that implementation text or adding an import. `polyTimeComputable_polyUnary` emits `(n+1)^d`; the selected route uses the explicitly prescribed unary multiplication construction for `n^d`. No general public bounded-padding or arithmetic theorem was introduced.

The selector's two inductions construct a fixed finite composition for each chosen bound C. Its correctness is required only where the exponent value is at most C; the bounded-padding theorem supplies that fact on every input. Canonical binary equality compares exponent values. Unary multiplication and the unary length map emit the actual true-bit power, with an initial `[true]` for exponent zero, including `0^0 = 1`. The proof never substitutes a bit-length estimate for an emitter. Parsing the final false separator recovers the exact original prefix even when that prefix contains false bits. Both the polynomial bound and membership equivalence include empty inputs.

## Definition boundaries

| Other-file definition/interface | Published equation or contract used |
|---|---|
| `PolyTimeComputable` | Constant, identity, composition, append, pairing, unary and conditional FP closures; no extraction of its predicate body. `polyTimeComputable_iff` is also exercised as a reader control. |
| `PolyTimeReducible` | `polyTimeReducible_iff`, then `mem_P_of_polyTimeReducible`. |
| `NPComplete` | `NPComplete_iff`. |
| `NPHard` | Public `SAT_NPHard` and `P_eq_NP_of_NPHard_mem_P` contracts; the reader control also exercises `NPHard_iff`. |
| P | P closure under polynomial reductions and the public collapse theorem; `mem_P_iff` is exercised as a reader control. |
| NP, SAT | Existing targets and the public SAT-hardness/NP-completeness contracts; no SAT encoding/decoder or NP verifier body is inspected. The reader control also exercises `SAT_mem_NP`. |
| `Turing.pairEncode` | Public FP pairing; `pairEncode_eq` is exercised as a reader control. |
| `BinArith.mulU` | `length_mulU` and `polyTimeComputable_mulU`; no runner or multiplication implementation is inspected. |
| `BinArith.beq` | `beq_pairEncode` on canonical binary inputs and `polyTimeComputable_beq`. |
| Existing owner definitions/leaves | `SAT_H_eq`, `ladner_pad_membership`, `ladner_parse_pad`, and the already proved targets 1–5. No old proof is changed. |

Both the new private section and final target elaborate with all ten reached foreign definitions locally irreducible. All ten constant-versus-body delta comparisons succeed unsealed and fail sealed under default definitional equality; the public reader/contract goals still succeed under the same seal. No unsafe reducibility option is used. None of the sealed definitions has a definition-level simp attribute to remove; public equation theorems remain available. Every explicit `simp`/`rw` argument was inspected (`rewrite-audit.log`): only owner/local definitions, hypotheses and published theorem equations occur. No core/Mathlib definition or foreign TCSlib definition is explicitly unfolded.

## Checks

All final checks below have exit code zero. `runs.tsv` gives every invocation, including the failed first draft; logs retain starts, ends and native time/RSS measurements.

| Check | Evidence and result |
|---|---|
| Package pins/cache | All 11 present packages match URL/revision; four unused documentation packages are absent. Zero-sized package oleans: 0. All 46 direct Mathlib roots import successfully (`package-pins.log`, `cache-check.log`, `mathlib-roots.log`). |
| Fresh import closure | 126 owned-file prerequisites plus 12 facade prerequisites, all freshly compiled from the pinned sources into this fill's scratch olean tree, all exit 0. The owned file and facade themselves are checked separately. |
| Whole owned file | `ladner-final.log`: zero errors, zero warnings; fresh nonempty olean, 3565288 bytes. Input source hashes before and after are identical. |
| Foreign-definition seal | `sealed-final.log`: zero errors/warnings, both production additions checked under all ten seals. |
| Delta and reader controls | `delta-unsealed-final.log`, `delta-sealed-final.log`, `reader-controls-final.log`: all controls pass. |
| Axiom prints | `axioms-final.log`, `axiom-audit.log`: all seven new private proofs and both headline theorems use at most `propext`, `Classical.choice`, `Quot.sound`; no `sorryAx`. |
| Facade | `facade-final.log`: zero errors/warnings; fresh nonempty olean, 40192 bytes, stable input hash. |
| Toolchain | `toolchain-version.log`: Lean 4.25.0, arm64-apple-darwin24.6.0, commit `cdd38ac5115bdeec5f609e9126cce00f51ae88b3`. |
| Scope/freeze/formatting | `freeze-audit.log`, `preship-terms.log`, `diff-stat.log`, `proof-sketch-audit.log`: exact scope and placement, no other drift, `git diff --check` passes. |
| Artifact integrity | Zip CRC/member checks, source/patch hashes and checked source-commit binding; applying the patch to the exact base reproduces the delivered source byte for byte. |

The first owned-file check had one Boolean-coercion simplification gap (`if false = true`) and its associated unused-simp warning. Adding the theorem equation `Bool.false_eq_true` closes it; no statement, construction or hypothesis changed. That failed log (`ladner-check-1.log`) is preserved. The final owned-file check has zero warnings. The fresh prerequisite logs contain their inherited warnings, distinct from the zero-warning owned file/facade.

Authoritative axiom prints (private leaves use public aliases only in the scratch copy):

```text
'Complexity.fill7_axioms_ladner_bounded_pad_length' depends on axioms: [propext, Quot.sound]
'Complexity.fill7_axioms_ladner_power_cases_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill7_axioms_ladner_bounded_pad_FP' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill7_axioms_ladner_padWord_membership' depends on axioms: [propext, Quot.sound]
'Complexity.fill7_axioms_ladner_bounded_pad_reduction' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill7_axioms_ladner_outside_P' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.fill7_axioms_ladner_not_complete' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.SAT_H_intermediate' depends on axioms: [propext, Classical.choice, Quot.sound]
'Complexity.ladner' depends on axioms: [propext, Classical.choice, Quot.sound]
```

`AxiomWalk.lean` is the final production source with only public proof aliases and print commands appended in scratch. The library itself contains no audit wrappers or print commands. The seal and control probes are shipped as `.lean.txt`, and source/probe input hashes bind the recorded checks to their delivered contents.

## Environment, concurrency and exceptions

- Worktree: `/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange`, at the pinned base plus the local source commit. After checks, the app-managed archive attempt was refused: “The task's primary checkout cannot be removed.” The clean worktree is retained; no manual removal or protection bypass was attempted (`archive-attempt.log`).
- Native macOS 26.5.2 preflight substitutes `sysctl`, `vm_stat`, `memory_pressure`, `df -k`, `mount` and `statvfs` for Linux nproc/cgroup/procfs/df fields. CPU count 12; physical memory 19327352832 bytes (18 GiB); `memory_pressure` 55% system-wide free, approximately 9.90 GiB as the native available-memory analogue, above 4 GiB. This is explicitly a Mac interpretation, not a Linux cgroup measurement. APFS available space was 152085884928 bytes at exchange/scratch and the new worktree, above the initial 12 GiB floor.
- Initial restricted `sysctl` and a later read-only `ps` observation were denied. Authorized elevated native commands supplied the successful readings, and every actual Lean launch/count ran in that environment. Existing pinned Lean 4.25.0 needs no shim or download. No cache was fetched and no Lake command, `lake build`, dependency-tree copy or merge was run. The addendum's permitted exact-pin symlink links `.lake/packages` to the campaign package tree. No prior fill's TCSlib olean tree was reused, and no scratch `LEAN_PATH`s were combined.
- Every Lean-running command acquired one slot using the unchanged issued `lean-slot.sh`, SHA-256 `ff64d8d5b6baf4e7b1c15172a7faeb70246f22c6acf76134bbdb70c017f41f1a`, tag `ladner-final`, default `~/.lean-slots`, cap three. Inherited slot overrides were absent. The held slot encloses the repository leanelab helper, with `TCSLIB_LEAN_SLOTS=3`, `lean -j4`, `nice -n 10`. The native `ps -axo comm=` basename count includes bare `lean` and any executable path ending `/lean`; only a count below three launches. Own checks are serialized by one controller/lock at a time.
- Maximum immediate prelaunch native Lean count: 2; timestamped wait events: 0. No wait was required. Counts are in `concurrency.log`; only this fill's shared protocol events are in `shared-slot-events.log`. No subagents or other-worker resource messages were needed. No other worker's source, processes or package builds were modified.
- The task's explicit cap three and no-new-admissions rule supersede the generic five-slot/sorry-ladder text. Its prescribed command-line checks supersede the generic InfoView-only workflow. The five-second controller polls only observe live processes and never terminate a module. No self-imposed module deadline, resource kill, crash or interruption was used. Peak logged RSS was 3073425408 bytes in `bootstrap-084.log`. No resource-shortage condition occurred.
- Preparation guards caught Markdown framing, the target's original `:=` delimiter, and a facade-order index that would have reused a bootstrap log label. These were corrected before the affected operations: no unintended source write and no log overwrite occurred (`preparation-audit.log`). All logs stay at their original scratch paths; zips take snapshots rather than moving live logs. No mathematical exception, changed contract or E-READER/E-HOST/E-STATEMENT escalation was needed.

## Delivery

Checkpoint 1 (`b35fa7e37`) preserves the unverified draft/bootstrap snapshot. Checkpoint 2 (`f4a4a8846`, zip SHA-256 `d4d09ac77fe63ecb1469b311cb553595ebd7017bc0e38c35c8320e9922fd335b`) preserves the verified source/axioms and then-pending facade snapshot. This final zip includes all completed checks and the full report.

Zips are generated outside the exchange checkout. Each publication successfully pulls/rebases only the exchange branch before copying/staging only the designated `arora-barak-ch3-4/inbox/fill-ladner-final/` artifact. The source branch is never rebased or pushed. No force push or pull request is used. Unrelated exchange files/staging are preserved. The final zip is also linked in chat as a fallback.

Contents: this report, final `Ladner.lean`, `Ladner.patch` against `d811bdaa`, `SHA256SUMS`, check/concurrency/environment logs, reproducible runtime scripts and scratch probes as text. No olean or native build product is shipped. Artifact verification is recorded in `package-verification.log`; the final zip is revalidated after its evidence snapshot. Final source SHA-256: `0c85955b4860734b3bdd657b4960e086899163a742466c7f34f00b0bac91fda6`.
