from pathlib import Path
import os,sys,subprocess,time,datetime,fcntl
ROOT=Path('/private/tmp/fill-ladner-final')
WT=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange')
OL=ROOT/'oleans';LOG=ROOT/'evidence/logs'
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(label,file,emit=False):
    with (ROOT/'own-lean.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        marker=ROOT/('gate-'+label);marker.unlink(missing_ok=True)
        env=dict(os.environ,TCSLIB_LEAN_SLOTS='3',LEAN_SLOT_TAG='ladner-final')
        script='leanelab-o.sh' if emit else 'leanelab.sh'
        args=['bash',str(WT/'devtools/seyoon'/script),str(WT),str(OL),file]
        if emit:args.append(str(OL))
        start=time.monotonic()
        with (LOG/(label+'.log')).open('w') as out:
            out.write(f'{stamp()} START {file}\n');out.flush()
            cmd=['bash',str(ROOT/'lean-slot.sh'),'python3',str(ROOT/'slot-launch.py'),label,'/usr/bin/time','-l',*args]
            p=subprocess.Popen(cmd,env=env,cwd=WT,stdout=out,stderr=subprocess.STDOUT)
            while p.poll() is None:
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    if not marker.exists():
                        ps=subprocess.run(['ps','-axo','comm='],text=True,capture_output=True,check=True)
                        n=sum(c.strip().split('/')[-1]=='lean' for c in ps.stdout.splitlines())
                        with (LOG/'concurrency.log').open('a') as f:f.write(f'{stamp()} WAIT shared-slot count={n} {label}; poll again in 5s\n')
            code=p.returncode
            out.write(f'{stamp()} END EXIT {code} elapsed_seconds {time.monotonic()-start:.3f}\n')
        with (LOG/'runs.tsv').open('a') as out:out.write(f'{stamp()}\t{label}\t{code}\t{time.monotonic()-start:.3f}\t{file}\n')
        print(f'{stamp()} {label} EXIT {code} elapsed {time.monotonic()-start:.1f}s',flush=True)
        if code:print((LOG/(label+'.log')).read_text(),flush=True)
        return code
if sys.argv[1]=='bootstrap':
    code=run('mathlib-roots',str(ROOT/'probes/MathlibRoots.lean'))
    if code:sys.exit(code)
    for i,m in enumerate((LOG/'ladner-order.txt').read_text().splitlines(),1):
        if m.endswith('/Ladner'):continue
        code=run(f'bootstrap-{i:03d}',m+'.lean',True)
        if code:sys.exit(code)
elif sys.argv[1]=='facade-prereqs':
    old=set((LOG/'ladner-order.txt').read_text().splitlines())
    for i,m in enumerate((LOG/'facade-order.txt').read_text().splitlines(),1):
        if m in old or m=='TCSlib/Complexity/Diagonalization':continue
        code=run(f'bootstrap-{i:03d}',m+'.lean',True)
        if code:sys.exit(code)
elif sys.argv[1]=='check':
    sys.exit(run(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='emit'))

elif sys.argv[1]=='verification':
    for label,file,emit in [
        ('axioms-1',str(ROOT/'probes/AxiomWalk.lean'),False),
        ('delta-unsealed-1',str(ROOT/'probes/DeltaUnsealed.lean'),False),
        ('delta-sealed-1',str(ROOT/'probes/DeltaSealed.lean'),False),
        ('reader-controls-1',str(ROOT/'probes/ReaderControls.lean'),False)]:
        code=run(label,file,emit)
        if code:sys.exit(code)
    old=set((LOG/'ladner-order.txt').read_text().splitlines())
    for i,m in enumerate((LOG/'facade-order.txt').read_text().splitlines(),1):
        if m in old or m=='TCSlib/Complexity/Diagonalization':continue
        code=run(f'bootstrap-{i:03d}',m+'.lean',True)
        if code:sys.exit(code)
    for label,file,emit in [
        ('ladner-final','TCSlib/Complexity/Diagonalization/Ladner.lean',True),
        ('facade-final','TCSlib/Complexity/Diagonalization.lean',True),
        ('toolchain-version','--version',False)]:
        code=run(label,file,emit)
        if code:sys.exit(code)

elif sys.argv[1]=='seal-final':
    for label,file in [
        ('sealed-final','Sealed.lean'),
        ('delta-unsealed-final','DeltaUnsealed.lean'),
        ('delta-sealed-final','DeltaSealed.lean'),
        ('reader-controls-final','ReaderControls.lean')]:
        code=run(label,str(ROOT/'probes'/file))
        if code:sys.exit(code)
