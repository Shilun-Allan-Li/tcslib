from pathlib import Path,PurePosixPath
import hashlib,subprocess,sys,tempfile,zipfile,json
r=Path('/private/tmp/fill-ladner-final');wt=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange')
f='TCSlib/Complexity/Diagonalization/Ladner.lean';base='d811bdaaf5e923b2a57f0453135af5c7ee37713a';p=Path(sys.argv[1]);final=len(sys.argv)>2 and sys.argv[2]=='final'
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 for n in names:
  pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts
  assert pp.suffix not in {'.olean','.ilean','.o','.so','.dylib','.a'},n
 required=['REPORT.md','Ladner.lean','Ladner.patch','SHA256SUMS','evidence/logs/concurrency.log','evidence/logs/runs.tsv']
 if final: required+=['evidence/logs/'+n for n in ['final-verification.json','facade-final.log','axioms-final.log','sealed-final.log','delta-unsealed-final.log','delta-sealed-final.log','reader-controls-final.log','freeze-audit.log','package-pins.log']]
 assert set(required)<=set(names),set(required)-set(names)
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest
 source=z.read('Ladner.lean');patch=z.read('Ladner.patch')
 assert source==(wt/f).read_bytes()
 assert patch==subprocess.check_output(['git','-C',str(wt),'diff',base,'--',f])
 if final: assert json.loads(z.read('evidence/logs/final-verification.json'))['source_sha256']==hashlib.sha256(source).hexdigest()
 with tempfile.TemporaryDirectory(prefix='patch-check-',dir=r) as td:
  root=Path(td);target=root/f;target.parent.mkdir(parents=True)
  target.write_bytes(subprocess.check_output(['git','-C',str(wt),'show',base+':'+f]));pp=root/'change.patch';pp.write_bytes(patch)
  subprocess.run(['git','apply','--check',str(pp)],cwd=root,check=True)
  subprocess.run(['git','apply',str(pp)],cwd=root,check=True)
  assert target.read_bytes()==source
print('PASS zip integrity, safe unique members, required evidence, no build products')
print('PASS source/patch manifest hashes and worktree binding')
print('PASS patch applies to exact base '+base+' and reproduces source byte-for-byte')
print('Source SHA256 '+hashlib.sha256(source).hexdigest())
print('Archive SHA256 '+hashlib.sha256(p.read_bytes()).hexdigest())
