from pathlib import Path
import sys,subprocess,zipfile,hashlib,datetime
R=Path('/private/tmp/fill-ladner-final')
WT=Path('/Users/seyoonr/.codex/worktrees/fill-ladner-final/tcslib-exchange')
F='TCSlib/Complexity/Diagonalization/Ladner.lean';BASE='d811bdaaf5e923b2a57f0453135af5c7ee37713a'
name=sys.argv[1];report=Path(sys.argv[2]).read_text()
source=(WT/F).read_bytes() if (WT/F).exists() else (R/'final-Ladner.lean.txt').read_bytes()
patch=subprocess.check_output(['git','-C',str(WT),'diff',BASE,'--',F]) if (WT/F).exists() else (R/'final-Ladner.patch').read_bytes()
out=R/'delivery'/name;out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('REPORT.md',report);z.writestr('Ladner.lean',source);z.writestr('Ladner.patch',patch)
    z.writestr('SHA256SUMS',hashlib.sha256(source).hexdigest()+'  Ladner.lean\n'+hashlib.sha256(patch).hexdigest()+'  Ladner.patch\n')
    for n in ['run.py','slot-launch.py','lean-slot.sh','sync.py','package.py','prepare-probes.py','setup.py','verify-package.py','audit-final.py']:
        if (R/n).exists():z.write(R/n,'evidence/runtime/'+n)
    for p in sorted((R/'evidence/logs').glob('*')):
        if p.is_file():z.write(p,'evidence/logs/'+p.name)
    for p in sorted((R/'probes').glob('*.lean')):z.write(p,'evidence/probes/'+p.name+'.txt')
print(out);print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
