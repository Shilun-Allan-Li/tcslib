# E-PAD fill — `Complexity.mem_SPACE_padLang` (`SpaceComplexity/Padding.lean`)

**Status: checkpoint 1 reached** (design note and route probe). The target is still the base's
own `sorry`; this commit adds no admission. Checkpoints 2–4 follow in later zips.

## 1. Base, branch, commits

| item | value |
|---|---|
| campaign branch | `complexity/arora-barak-ch3-4` |
| ancestor check | `git merge-base --is-ancestor 72fcfbef3c1deb331aedc95d4a158a9ed4c56524 HEAD` → 0 |
| base (branched at exactly) | `72fcfbef3c1deb331aedc95d4a158a9ed4c56524` |
| `git rev-parse HEAD:TCSlib/Complexity/SpaceComplexity/Padding.lean` at base | `39a59037fb3b7582ef154cd8819640ac05c1b6ea` (as required) |
| fill branch | `fill/epad` (never rebased, merged or cherry-picked) |
| checkpoint 1 commit | `07b50af5` — route vocabulary and imports |

Delivery: by push of each zip to `exchange/pass-shelat-ch5-8` under
`arora-barak-ch3-4/inbox/fill-epad/` (the user's override of the brief's "zip in the reply";
one commit per zip, `git pull --rebase` before each push, never forced; nothing else touched).

## 2. Environment (addendum v2.6, Parts 1 and 2; Part 3's one-Lean rule)

This session earlier completed a different fill (Pass–shelat unit `rabin`) on the same host and
clone; E-PAD is a separate item with its own branch, bootstrap, checks and zip.

* **Preflight** (`evidence/logs/preflight.log`): `nproc` 4; cgroup v1, `memory.limit_in_bytes`
  unlimited, so headroom = `MemAvailable` = 15.41 GiB (floor 4 GiB): PASS; clone filesystem free
  23.73 GiB (floor 12 GiB): PASS.
* **Toolchain**: Lean 4.25.0 (`lean-toolchain` pin), installed under elan from the official
  GitHub release archive (`release.lean-lang.org` is unreachable from this host; disclosed, no
  shim needed: Lean starts normally, so Part 2's shim was **not** used).
* **Cache** for the roots only (`evidence/logs/mathlib-roots.txt`: 64 Mathlib roots of the
  227-module order list `evidence/logs/order.txt` = the TCSlib closure of `Padding`,
  `PreimageHost`, `InputDevice`, `VirtualInput`, `InputCall`, `PolyTimePairing` and the
  `SpaceComplexity` facade). Store logged before the fetch (`cache-store.log`: it existed, 2346
  files, from the earlier fill); `lake exe cache get <roots>`: "Attempting to download 20",
  "Decompressing 1061", exit 0 (`cache-get.log`). Package check PASS (`packages-check.log`);
  no zero-byte oleans (`zero-oleans.log`); cache probe exit 0 (`cache-probe.log`).
* **Bootstrap** of all 227 modules through `scripts/lean_check_tree.sh` into the scratch olean
  tree `/workspace/epad-oleans` (`bootstrap.log`): 01:58:56–02:26:22 UTC, every module exit 0,
  sum of module walls 1641 s, largest module 306 s, peak RSS 4565 MiB.
* **Import probe** (the brief's, at the base): exit 0, every host prints its type, the target's
  only admission is its own `sorry` (`evidence/logs/importprobe-base.out`, identical to the
  pre-ship output apart from the exit line).
* Every Lean run went through `scripts/lean_check_tree.sh` (wrapper `tools/chkE.py`, which logs
  start, end, wall time and peak RSS), one at a time.

## 3. Route and design note (checkpoint 1)

**Chosen route: (A), the preimage route, closed by the catalog's conditional.** Three machines
and one combinator, every host proved at the base:

1. **The validator** `D` decides the padded words
   `epadV C d = {y | ∃ a, y = pairEncode a 1^{C (|a|+1)^d}}`, malformed inputs included, in
   `O(log m) ⊆ O(m + 1)` cells (leaf `epad_V_mem : epadV C d ∈ LOGSPACE`, checkpoint 2).
2. **The run phase** `O`: the oracle-input simulator
   `LogProg.compileFinTM (LogProg.OIS.prog M) (LogProg.OIS.start M) (LogProg.bankTM Ms) (LogProg.bankStart Ms)`
   runs `L`'s decider `M` on the **virtual input** `v = epadVirt C d y`: the first component
   `pairFstD y` of a padded word, and `[]` on every other input. The virtual input is never
   written; its length and bit queries `⟨y, bits i⟩` are answered by a bank of two deciders for
   `epadQ C d false` / `epadQ C d true` (leaf `epad_Q_mem : epadQ C d mode ∈ LOGSPACE`,
   checkpoint 3), whose laws on genuine queries are `epad_query_mem_iff` (proved, this commit).
   Host: `Complexity.LogProg.OIS.compile_decides`.
3. **The constant** `[false]` machine: `Turing.FinTM.computesFunInTime_const_spaceUsed`.
4. **The combinator**: `Turing.FinTM.computesFunInTime_cond_spaceUsed` (`Build/Catalog`, proved):
   on `y`, run `D`; if it accepts, run `O`, else the constant. Its output is
   `if y ∈ epadV then [y.fst ∈ L] else [false] = [y ∈ padLang L pad]`. Its hypotheses
   (`ComputesFunInTime` and space at **every** time) come from
   `Turing.FinTM.ComputesInSpace.computesFunInTime_and_forall_spaceUsed_le` (`ConfigCount`).

**Why the conditional, and why `epadVirt y = []` off the padded words.** `compile_decides`
returns `M`'s answer on the virtual input, so invalid inputs must be rejected elsewhere; with the
conditional no word `w₀ ∉ L` is needed and `L = univ` needs no separate case. The conditional's
space hypotheses are uniform over inputs (`∀ x t, … ≤ s |x|`), so the run phase must be
space-safe on **invalid** inputs too: there its virtual input is `[]`, on which `M` uses the
constant `c · S 0` (never `S` of a long first component, which `hST` does not control).

**Why not route (B).** The machine-level hosts that would give a space-bounded validator are
not available: the catalog's length check `computesFunInTime_pairLenCheck_spaceUsed` writes the
unary bank `C (|a| + 1)^e` before comparing, so its space is polynomial in `m` on malformed
inputs (`c ((m+1)^e + m + 1)`); `polyUnaryTM_spaceUsed`, `branchTM_spaceUsed` and
`timedCondTM_spaceUsed` are `sorry` at the base (never cited). The register-machine layer
(`Machines/ARM*`, `Logspace/InputAccess`) has proved run lemmas for every loop the validator
needs and a proved space wrapper (`Complexity.LogProg.arm_decides_poly`), so (A) needs no new
machine semantics: only register programs and their runs.

**The validator and the bank (checkpoints 2–3), as abstract register machines.** Registers hold
naturals in binary; the input is read through the published deciders `inputBitLang`,
`inputLenLang` (`inputBitLang_mem`, `inputLenLang_mem`) by `whole`-mode calls on `⟨y, bits p⟩`.
* *Validator on `y`*: `inputLength_loop` (`|y|`); `alignedPair_loop` (stride 1) parses
  `y = ⟨a, b⟩` or rejects; `|a| + 1` = the pointer halved; a ones-scan of `b` counting `|b|`
  (rejects at a `0`); `P := C`, then `d` times `P := P · (|a| + 1)` by addition loops; accept
  iff `|b| = P`. Register values stay below `C (m + 1)^d + O(m)`, so `arm_decides_poly` gives
  `epadV C d ∈ LOGSPACE`. The pad is never written; malformed inputs are rejected by the parse
  or the scan within the same bound.
* *Bank on `z = ⟨y, w⟩`*: length of `z`; `alignedPair_loop` on `z` (reject unless a pair);
  `canonicalTail_loop` with cap `|y|` (reject a non-canonical or too-wide index: genuine queries
  have `i ≤ |v| ≤ |y|`); `boundedDecode_loop` (`i := bitsVal w`); the validator's block on `y`
  at stride 2 (`y`'s letters are `z`'s doubled first field); then mode `false`: `i < |a|`;
  mode `true`: if `i < |a|`, read `z` at `4i` (`= a_i`), else `0`.

**The space ledger** (proved in the route probe). Let `m = |y|`, `v = epadVirt C d y`
(`|v| ≤ m`), `M` decide `L` in `c · S`, the bank's deciders run in `c₀ · logSpace`,
`c₁ · logSpace`, `k_D = bankK Ms + bankK Ms`.
* `compile_decides`: the run phase uses at most
  `M.k (2 s_M + 1) + (|bits (|v| + 1)| + 2) + k_D (2B + 1)` cells, where `s_M ≤ c · S |v|` is
  `M`'s space on `v` and `B = (c₀ + c₁)(3m + 4) + 1` bounds the bank's radius on every query
  `⟨y, bits i⟩`, `i ≤ |v|` (its length is `2m + 2 + |bits i| ≤ 3m + 3`; `logSpace q ≤ q + 1`).
* Padded `y = ⟨a, 1^{C(|a|+1)^d}⟩`: `m = 2|a| + 2 + C (|a| + 1)^d` (`length_pairEncode`), so
  `S |v| = S |a| ≤ T m` by `hST`. Otherwise `v = []` and `S 0 ≤ S 0 · T m` (`T m ≥ 1`). Both:
  `S |v| ≤ (S 0 + 1) T m`.
* `|bits (|v| + 1)| + 2 ≤ |v| + 4 ≤ 4 T m`; `2B + 1 ≤ (8 (c₀ + c₁) + 3) T m` (as
  `3m + 4 ≤ 4 (m + 1) ≤ 4 T m`, from `hT`).
* Run phase: `≤ K T m`, `K = M.k (2c (S 0 + 1) + 1) + 4 + k_D (8 (c₀ + c₁) + 3)`.
* Validator: `c_V logSpace m ≤ c_V (m + 1) ≤ c_V T m`. Constant machine: `c_f ≤ c_f T m`.
* Conditional: `c_V logSpace m + max (K T m) c_f + c_c ≤ (c_V + K + c_f + c_c) T m`, so
  `padLang L pad ∈ SPACE T` with constant `c_V + K + c_f + c_c`.

**Initialization and the simulated input** (gate 110, note 4): `SPACE` counts visited work cells
(`SpaceComplexity/Basic`). `compile_decides` charges every work tape of the compiled machine:
`M`'s tapes as registers (`M.k (2 s_M + 1)`, origins included), the index register of the
virtual input (`|bits (|v|+1)| + 2`: the simulated input costs only its head position), and the
bank's `k_D` tapes (`2B + 1` each). The conditional's own overhead (capture tape, dispatch) is
its constant `c_c`. The input tape is read-only and uncounted.

**Route probe** (`evidence/probes/EPadRoute.lean`, output `evidence/logs/route-probe-cp1.out`):
a copy of `Padding.lean` in which `mem_SPACE_padLang` is proved from the two leaves; exit 0; the
only `sorry`s are `epad_V_mem` and `epad_Q_mem` (two "declaration uses 'sorry'" warnings, at
those two lines); the target prints `[propext, sorryAx, Classical.choice, Quot.sound]`.

## 4. New declarations (so far) and their roles

All private, prefix `epad`/`epad_`. Base: 77 lines, 3 public, 0 private.
At checkpoint 1: **143 lines, 3 public, 8 private** (no new public declaration).

| declaration | kind | role |
|---|---|---|
| `epadValid C d y` | def (Prop) | `y` is a padded word `⟨a, 1^{C(\|a\|+1)^d}⟩` |
| `epadV C d` | def (language) | the validator's language |
| `epadVirt C d y` | def | the virtual input: `pairFstD y` on padded words, `[]` otherwise |
| `epadQ C d mode` | def (language) | the bank's two query languages (exactly what the bank ARM decides) |
| `epadVirt_of_valid` | lemma | `epadVirt` on a padded word |
| `epadVirt_of_not_valid` | lemma | `epadVirt` off the padded words |
| `epadVirt_length_le` | lemma | `\|epadVirt y\| ≤ \|y\|` |
| `epad_query_mem_iff` | lemma | the bank's laws on genuine queries `⟨y, bits i⟩`, `i ≤ \|y\|` |

## 5. Added imports and why

| import | why |
|---|---|
| `TCSlib.Complexity.SpaceComplexity.Logspace.PreimageHost` | `LogProg.OIS.compile_decides` (the run phase); transitively `Logspace/InputAccess` (input access, ARM loops), `Machines/ARMKit` (`arm_decides_poly`, `indicator_eq_decide`), `SpaceComplexity/ConfigCount` (`computesFunInTime_and_forall_spaceUsed_le`) |
| `TCSlib.Complexity.TuringMachine.Build.Catalog` | `FinTM.computesFunInTime_cond_spaceUsed`, `FinTM.computesFunInTime_const_spaceUsed` |
| `TCSlib.Complexity.ClassNP.PolyTimePairing` | `pairFstD`, `pairFstD_pairEncode`, `length_pairFstD_le` |

None of them imports `SpaceComplexity/Padding` or `SpaceComplexity/Hierarchy` (checked on the
import closure); only the `SpaceComplexity` facade imports `Padding`, so no cycle.

## 6. Cited declarations outside the file

The citation walk `evidence/probes/EPadCites.lean` lists every constant of another TCSlib module
occurring in the module's declarations (`evidence/logs/cites-cp1.txt`); the extended import probe
`#check`s each at the base (`evidence/probes/EPadImportProbeExt.lean`,
`evidence/logs/importprobe-ext-cp1.out`).

## 7. Seal (rule 7) and inspection table

* Foreign definitions read by the module's declarations: `evidence/seal/foreign-defs-by-decl-cp1.txt`
  (generated, `Probe/EPadForeignDefs.lean`). Sealed (`attribute [local irreducible]`): all of
  them (`seal-list-cp1.txt`); none exempted at this checkpoint. `Action.apply`, `Cfg.init`,
  `MultiTapeTM.initCfg`, `NDTM.initCfg` are not reached at this checkpoint.
* Sealed copy `evidence/seal/EPadSealed-cp1.lean`: exit 0 (`logs/seal-main-cp1.log`).
* Controls, one per sealed definition (`#epad_seal_rfl f`: Lean's first defining equation
  `f.eq_1`, closed by `intros; rfl`): all close unsealed, all fail sealed
  (`logs/seal-control-cp1.log`).
* Inspection table: `evidence/logs/inspection-cp1.md` (every `rw`/`simp`/`simpa`/`dsimp`/`unfold`/
  `show`/`change` argument on an added line, kinds resolved by a Lean probe): no other-file
  definition is ever an argument; `epadVirt` is unfolded by `rw` in its own two equation lemmas.

## 8. Axiom print

`evidence/logs/axioms-cp1.log`: `Complexity.mem_SPACE_padLang` depends on
`[propext, sorryAx, Classical.choice, Quot.sound]` — the base's own `sorry`, unchanged at this
checkpoint. The walk over all the module's declarations shows `sorryAx` nowhere else.

## 9. Duplication search per private (so far)

* By name: `git grep -n "epad\|EPad"` over `TCSlib/` at the base: no hit (prefix unused).
* By statement: `git grep` for padded languages (`pairEncode … (List.replicate …)`): the time-side
  paddings `Nondeterminism.lean` (`C · 2^{(|x|+1)^c}` pad, a language and its NP/EXP transfer),
  `EXPCOM.lean`, `NP.lean`'s private `paddedVerifier`: none is a validity predicate of
  polynomially padded pairs, a virtual first component, or a query language; none is space-bounded.
  `pairFstD` is reused, not re-defined.
* `exact?` probes for the four lemmas: they state facts about this file's own private definitions,
  so no published statement can match; the probe is run for every private lemma at the final
  checkpoint (`evidence/probes/EPadDup*.lean`).

## 10. Screens

`scripts/copy-text-screen-v3.py` under `nice -n 10`, on frozen worktrees of the base and of the
checkpoint commit, population = `Padding.lean` + every TCSlib file in the citation walk
(`evidence/screens/population-cp1.txt`, 7 files): before 154 declarations / 21 pairs, after
157 / 21; **no new pair** (`screens/screen-diff-cp1.txt` empty).

## 11. Per-module time and memory

`evidence/logs/module-checks-cp1.log` (Padding, then the `SpaceComplexity` facade).

## 12. Checkpoints

| checkpoint | status |
|---|---|
| 1 design note and route probe | **reached** (this zip) |
| 2 validator | open (`epad_V_mem`) |
| 3 run phase | open (`epad_Q_mem`; the run-phase assembly is proved in the probe) |
| 4 assembly and ledger | open (proved in the probe from the two leaves) |

## 13. Escalations

None. No public lemma of another file is missing for this route.
