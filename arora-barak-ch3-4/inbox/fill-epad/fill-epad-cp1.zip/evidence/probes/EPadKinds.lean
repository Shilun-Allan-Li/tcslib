import TCSlib.Complexity.SpaceComplexity.Padding
open Lean Elab Command in
elab "#epad_kind " id:ident : command => do
  let env ← getEnv
  let n := id.getId
  let cands ← (do let r ← liftCoreM <| (Lean.resolveGlobalName n); pure (r.map (·.1)))
  let cands := cands ++ (if (env.find? n).isSome then [n] else [])
  let privN := mkPrivateName env n
  let cands := cands ++ (if (env.find? (mkPrivateName env (`Complexity ++ n))).isSome then [mkPrivateName env (`Complexity ++ n)] else [])
  let _ := privN
  match cands.head? with
  | none => logInfo m!"KIND\t{n}\tlocal (not a global constant)"
  | some c =>
    let kind := match env.find? c with
      | some (.thmInfo _) => "theorem"
      | some (.defnInfo _) => "definition"
      | some (.ctorInfo _) => "constructor"
      | some (.recInfo _) => "recursor"
      | some (.inductInfo _) => "inductive"
      | some (.axiomInfo _) => "axiom"
      | some (.opaqueInfo _) => "opaque"
      | some (.quotInfo _) => "quot"
      | none => "?"
    let mod := match env.getModuleIdxFor? c with
      | some i => toString env.header.moduleNames[i.toNat]!
      | none => "this file"
    logInfo m!"KIND\t{n}\t{kind}\t{c}\t{mod}"
namespace Complexity
open Turing
#epad_kind LogProg.bitsVal_bits
#epad_kind Option.some.injEq
#epad_kind Prod.mk.injEq
#epad_kind epadVirt
#epad_kind epadVirt_of_not_valid
#epad_kind epadVirt_of_valid
#epad_kind if_neg
#epad_kind if_pos
#epad_kind pairDecode_pairEncode
end Complexity
