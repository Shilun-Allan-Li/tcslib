from pathlib import Path
import subprocess,re,json,hashlib,zipfile,datetime
root=Path(__file__).resolve().parent.parent
ev=root/'evidence-r2';logs=ev/'logs'
order=(logs/'final-replay-order.txt').read_text().splitlines()
records=[]
for i,m in enumerate(order):
 p=logs/f'replay-{i:03d}-{Path(m).name}.log'
 s=p.read_text()
 assert re.search(r'^END .+ EXIT 0$',s,re.M),(m,'not completed successfully')
 assert not re.search(r': error:|^FAIL\(',s,re.M),(m,'error diagnostics')
 rss=re.search(r'(\d+)\s+maximum resident set size',s)
 records.append(dict(module=m,log=p.name,exit=0,rss_bytes=int(rss.group(1)) if rss else None))
assert len(records)==129
cons=(logs/'final-downstream.txt').read_text().splitlines();assert len(cons)==9
(logs/'replay-summary.json').write_text(json.dumps(dict(modules=records,downstream=cons,all_exit_zero=True),indent=2)+'\n')
all_records=[]
for p in logs.glob('*.log'):
 s=p.read_text();start=re.search(r'^START (.+)$',s,re.M);end=re.search(r'^END (.+) EXIT (\d+)$',s,re.M)
 if start and end:
  rss=re.search(r'(\d+)\s+maximum resident set size',s)
  all_records.append(dict(log=p.name,start=start.group(1),end=end.group(1),exit=int(end.group(2)),rss_bytes=int(rss.group(1)) if rss else None))
(logs/'verification-index.json').write_text(json.dumps(all_records,indent=2)+'\n')
for name in ['replay-000-FinalAxioms.log','replay-001-FinalDependencies.log','replay-002-FinalSealed.log']:
 assert re.search(r'^END .+ EXIT 0$',(logs/name).read_text(),re.M),name
slots=(logs/'process-slots.log').read_text();counts=[int(n) for n in re.findall(r': (\d+) other Lean processes',slots)]
waits=sum(n>=3 for n in counts);peak=max(r['rss_bytes'] or 0 for r in records)
report=(ev/'REPORT-final-draft.md').read_text()
report=report.replace('DOWNSTREAM_STATUS_PLACEHOLDER',f'Full current-source replay: all {len(records)} TCSlib modules in the import closure of the nine requested downstream consumers exit 0. This includes WordArith, the modified reader home, KeyTable, InputBit, every Sim module, Simulation, Classes, RAMSimulation, and TuringMachine. See final-replay-order.txt, final-downstream.txt, replay-summary.json, and the 129 individual logs. This is the requested closure, not a whole-project lake build.')
report=report.replace('RESOURCE_SUMMARY_PLACEHOLDER',f'The process log has {waits} threshold waits (five seconds per threshold wait); maximum observed other-Lean count is {max(counts)}. Peak RSS in the final replay is {peak} bytes ({peak/1024**3:.2f} GiB).')
report=report.replace('- final-diff-check.log: exit 0, no whitespace errors.','- final-diff-check.log: exit 0, no whitespace errors.\n- final-patch-roundtrip.log: exit 0; applying the patch to exported base files reproduces both delivered files byte-for-byte.')
assert '_PLACEHOLDER' not in report
(ev/'REPORT-final.md').write_text(report)
files=['TCSlib/Complexity/TuringMachine/Build/WordArith.lean','TCSlib/Complexity/TuringMachine/StateRenaming.lean']
assert subprocess.check_output(['git','diff','--name-only','HEAD','--',*files],cwd=root)==b''
source=(root/files[0]).read_text();assert not re.search(r'\b(sorry|admit|axiom)\b',source)
patch=subprocess.check_output(['git','diff','7342f98b58704d6c25faf668ed1a64ea0b27c4af','--',*files],cwd=root)
assert patch==(ev/'fill-ram-word-arith-r2.patch').read_bytes()
items={'REPORT.md':report.encode(),'fill-ram-word-arith-r2.patch':patch}
for f in files:items[f]=(root/f).read_bytes()
for directory in ['evidence','evidence-r2']:
 for p in (root/directory).rglob('*'):
  if not p.is_file() or p.suffix in ['.zip','.olean','.ilean','.pyc'] or p.name in ['REPORT-final-draft.md','delivery-metadata.json']:continue
  items[str(p.relative_to(root))]=p.read_bytes()
items['SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in sorted(items.items())).encode()
z=ev/'fill-ram-word-arith-r2.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
 for k,v in sorted(items.items()):f.writestr(k,v)
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 for line in f.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(f.read(name)).hexdigest()==digest,name
meta=dict(archive=str(z),sha256=hashlib.sha256(z.read_bytes()).hexdigest(),bytes=z.stat().st_size,entries=len(items),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),base='7342f98b58704d6c25faf668ed1a64ea0b27c4af',verified_targets=9,replay_modules=len(records),downstream_consumers=len(cons),threshold_waits=waits,peak_replay_rss_bytes=peak)
(ev/'delivery-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
