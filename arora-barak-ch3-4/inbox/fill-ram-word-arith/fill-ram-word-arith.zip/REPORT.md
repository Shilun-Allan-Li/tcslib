# fill-ram-word-arith final delivery

Clean frontier delivery: **3 of 9 targets proved**, with no admitted dependencies. The six
arithmetic targets remain `sorry`. This is a partial fill, permitted by COMMON.md's clean-frontier rule.

## Base and integrity

- Repository: Shilun-Allan-Li/tcslib.
- Base: `cb44316a22c258628bf571da8c84b72c347ee493` on `complexity/ram-simulation`, fetched read-only.
- Local branch: `codex/fill-ram-word-arith`; source commit `e13c083da`. Never rebased and not pushed.
- Exchange branch: `exchange/pass-shelat-ch5-8`; only the assigned inbox receives archives.
- Bundle SHA-256: `daa96cb0c44083eb9e61a911a4b80791a643f78718b006d9e762d02824366baf`.
  Both bundle and README passed SHA256SUMS (`evidence/logs/checksums.log`).
- Read the bundle's first two sections, the environment addendum v2.6, policy.md,
  TIER2-DESIGN.md, and gate 162's findings. The task's direct verification instructions
  override AGENTS.md's generic infoview-only advice; no `lake build` ran.

## Target status

| Target | Status | Axioms / frontier |
|---|---|---|
| `bvBits_injective` | Proved | `propext`, `Quot.sound` |
| `exists_wordAddTM` | Open (`sorry`) | First arithmetic frontier: E-READER for the shared sweep trace |
| `exists_wordSubTM` | Open (`sorry`) | Not pursued beyond that frontier; requires the same lockstep row |
| `exists_wordMulTM` | Open (`sorry`) | Not pursued beyond that frontier; requires the framed lockstep adder |
| `exists_wordHalfTM` | Open (`sorry`) | Not pursued beyond that frontier |
| `exists_wordSignExtendTM` | Open (`sorry`) | Not pursued beyond that frontier |
| `exists_wordIntTM` | Open (`sorry`) | Not pursued beyond that frontier |
| `exists_wordSignTM` | Proved | `propext`, `Classical.choice`, `Quot.sound` |
| `exists_wordNonzeroTM` | Proved | `propext`, `Classical.choice`, `Quot.sound` |

Checkpoint 1 was pushed in exchange commit `f8e3bcc50` (zip SHA-256
`4c19c674a2c9e51d279e8629ad3b49ef878f033c131602b128607102b51bbb90`).

Both tests use `ScanPhase Bool`, distinct exits `done true` and `done false`, and `C = 2`.
They preserve all tape cells, all heads, the input position and output, including width zero.
The private adapter is stronger than the requested scratch precondition: it needs no scratch
blankness. No transition table was added.

The scratch dependency walk traverses types and values and lists reachable constants whose
values directly reference `sorryAx`. Its list is **empty for each proved target**:
`bvBits_injective`, `exists_wordSignTM`, `exists_wordNonzeroTM`. No admitted dependency is used.
See `evidence/Dependencies.lean` and `evidence/logs/dependency-walk.log`.

## E-READER frontier and requested shared readers

The proposed lockstep proof must reuse the two-pass trace `Turing.catalog_trace_run` in
`Build/Catalog`. That theorem returns `Turing.catalogTrace F R D L t`. Its own proof and the
catalog's consumer proofs then unfold `catalogTrace` to recover the endpoint, earlier states,
and envelopes. No public equation or case readers for `catalogTrace` exist at the pinned base.
`catalog_trace_clauses` is private and is additionally specific to `SweepPhase`.
I stopped this construction before introducing unverified lockstep scaffolding. I did not
unfold `catalogTrace`, copy the private trace proof, or add public readers in an unowned file.
This is a missing reader on the chosen reuse route, not a claim that any frozen statement is false.

Requested reader in `Build/Catalog` (not added by this fill):

```lean
catalogTrace_eq (F R : ℕ → Cfg k Symbol S x) (D : Cfg k Symbol S x) (L t : ℕ) :
  catalogTrace F R D L t =
    if t ≤ L then F t else if t ≤ 2 * L + 1 then R (2 * L + 1 - t) else D
```

The general one-word scan route also lacks public readers of `scanResult` and `mealyRun`;
`mealyRun_append`, `mealyRun_induction`, `mealyRun_length`, `mealyRun_next` and
`scanResult_keep` are private. The published `scanResult_fold` suffices for the two completed
tests, but does not state the general finite-state writer equations. A continuation should
publish the recurrence equations for `mealyRun` and the defining equation of `scanResult`,
or publish the existing generic Mealy induction/identity-return result. Those additions would
need a separate authorization in the shared file. `evidence/logs/reader-search.log` records
the reader search. No E-STATEMENT or E-HOST finding is claimed.

## Private helpers and reuse searches

No public declarations, imports, files under TCSlib, simp attributes, axioms, or admissions
were added. Four private theorems were added in the owned file:

| Helper | Role | Existing facts searched / reused |
|---|---|---|
| `wordFold_run` | Framed read-only Boolean fold, both exits, linear bounds | `scanTM_run_ofCfg`, `scanResult_fold`, `wordPatch_self`, `wordPatch_apply`, `reachesWithin_iff`; the catalog contracts were also inspected |
| `bvBits_last_fold` | Last-bit fold equals `msb`, including width zero | `List.ofFn_succ_last`, `List.foldl_append`, `BitVec.msb_eq_getLsbD_last`, `BitVec.msb_zero_length`; searched list fold/last identities |
| `wordAny_fold` | Disjunction fold equals membership of true | Searched core/Mathlib for foldl/any/disjunction identities; reuses `List.foldl_cons`, `List.mem_cons`, `Bool.decide_or` |
| `bvBits_no_true` | No true bit iff the word is zero | Reuses the filled `bvBits_injective`, `List.ofFn_inj`, `List.mem_ofFn`, `BitVec.getLsbD_zero`; searched BitVec zero and bit extensionality facts |

Other-file TCSlib definitions are consumed only through published interfaces:

- `scanTM`: `scanTM_run_ofCfg`.
- `scanResult`, `scanFold`, `scanKeep`: the specialized `scanResult_fold` equation.
- `wordPatch`: `wordPatch_apply` and `wordPatch_self`.
- `ReachesWithin`: `reachesWithin_iff`.
- `FinTM.bufferTape` occurs opaquely in the word and patch specifications; no unfolding.

The existing same-file `WordAt` is read with `wordAt_iff`; `bvBits` and its readers remain local
to the owned file. Core/Mathlib results used for bit arithmetic are named lemmas.
No copied proved material or new hand-built machine is present. The owned file is 371 lines.

## Final verification

All invocations run through `scripts/lean_check_tree.sh`, wrapped by `evidence/run_check.py`.
The wrapper checks the machine-wide Lean count before each invocation, starts only one own
Lean process, logs starts/ends and `/usr/bin/time -l` maximum resident memory.

- Isolated upstream bootstrap: 20 modules, all exit 0.
- Mathlib cache probe: exit 0; no zero-length package oleans.
- Final owned file: `wordarith-final-02.log`, exit 0; exactly six warnings, at the still-open targets.
  No proved target has a sorry warning.
- Axiom prints: `axioms-final.log`, exit 0; only the axioms listed above.
- Dependency walk: `dependency-walk.log`, exit 0; empty admission lists.
- Seal: `sealed-wordarith.log`, exit 0; all 389 imported TCSlib ordinary definitions made
  locally irreducible, excluding abbreviations and projections; the entire delivered file
  re-elaborates. The six open targets remain admitted in this scratch check.
- Statement freeze: all 18 existing declaration statements byte-identical (exit 0).
- Full replay: **129/129 modules passed, exit 0**: the owned file, 20 upstream modules,
  and 108 remaining prerequisites/downstream modules. All nine downstream consumers passed:
  KeyTable, InputBit, Sim/Encoding, Sim/Startup, Sim/Phases, Simulation, Classes,
  RAMSimulation and TuringMachine. Per-module logs and all three order lists are included.
- Strict seal: `sealed-wordarith-strict.log`, exit 0; the same 389 definitions sealed,
  with their simp/unfold registrations removed as specified by the standing rule.
- Patch replay: `git apply --check` and application to a scratch base copy both exit 0;
  the result is byte-identical to the delivered source. The checker initially used an absolute
  scratch prefix, which Git rejected (exit 128); the relative-prefix check passed.
- `git diff --check` exits 0. `verification-summary.json` records all final results.
- Development checks `wordarith-01` through `wordarith-04` exited 1 while correcting head
  substitution, Boolean lemma names and zero-word normalization; `wordarith-05` and both
  final checks exited 0. These development logs are retained.

Owned-file diff against base:

```
.../Complexity/TuringMachine/Build/WordArith.lean  | 123 +++++++++++++++++++--
 1 file changed, 114 insertions(+), 9 deletions(-)
```

## Environment and waits

macOS host: 12 CPUs, 18 GiB physical RAM. Preflight recorded 125,711,896 KiB (119.888 GiB)
free on APFS and 67% system memory free (about 12.06 GiB). There is no Linux /proc/cgroup:
`sysctl`, `vm_stat`, `memory_pressure`, `df -k` and `mount` are the native equivalents, logged
in `preflight.log`. Existing user-managed Lean 4.25.0 is used; no toolchain was copied or installed.

The explicitly permitted symlink alternative is used for `.lake/packages`, pointing to
`/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-arora-barak-ch3-4/.lake/packages`.
Every present package's origin URL and revision matches lake-manifest.json: **MANIFEST PASS**.
The four documentation packages are ABSENT. No module in this fill's closure imports them.
No cache fetch ran, so no cache archive-store inspection or download is claimed.
All TCSlib oleans were built from the base sources into this fill's own
`.lake/fill-ram-word-arith-oleans`; no other session's scratch oleans were used.

`process-slots.log` records every check and wait. Checks wait while three other Lean processes
are active and proceed only below that count. No deliberate process-limit deviation occurred.
Total guard waits: 95.821 seconds across 2 checks
(`wordarith-01` and `wordarith-03`); all were waits at three occupied slots. Peak observed
maximum resident memory across this fill's checks: 3,892,346,880 bytes (replay-067-ZoneRebalance.log).
The managed worktree contained 30 unrelated modified blueprint files after creation; this fill
did not edit or revert them, and excludes them from its source commit, patch and archives.

## Literal proof sketches of the six open declarations


### `Turing.exists_wordAddTM`

**Proof sketch.** One lockstep sweep over the three words from their heads, carrying the carry bit
in the state and writing `uᵢ xor vᵢ xor carry`, ending at the blank after the words; then one
sweep back to the heads. The carry out of the top bit is dropped, which is reduction modulo `2^W`
(`BitVec.add` is `BitVec.ofNat` of the sum; the low `W` bits of a sum are the ripple-carry bits).

### `Turing.exists_wordSubTM`

**Proof sketch.** The lockstep sweep with a borrow bit in place of the carry, writing
`uᵢ xor vᵢ xor borrow` (equivalently, `u + ¬v + 1`: start the carry at `1` and complement `v`'s
bits as they are read); then the sweep back.

### `Turing.exists_wordMulTM`

**Proof sketch.** Shift and add. Copy `u` to scratch tape `3` and clear the destination to `0`.
For each bit of `v`, from the least significant: if it is `1`, add tape `3` into the destination
(the lockstep adder with the destination as an operand, using scratch tape `4` for the sum and
copying it back); then shift tape `3` up by one place in place, dropping its top bit. The
iteration walks `v`'s head one cell per round and stops at its delimiter, so it needs no counter.
Each round is `O(W)` and there are `W` rounds. Finally clear the scratch tapes and return the
heads. The invariant after `r` rounds: the destination holds `u * (v mod 2^r)` and tape `3` holds
`u <<< r`, both modulo `2^W`.

### `Turing.exists_wordHalfTM`

**Proof sketch.** Bit `i` of the result is bit `i + 1` of `u`, and the top bit is `u`'s top bit.
Start `u`'s head one cell to the right and sweep both heads together, writing the bit read and
remembering it in the state; at `u`'s right delimiter write the remembered bit once more. For
`W = 0` both words are empty and nothing is written. Then return the heads.

### `Turing.exists_wordSignExtendTM`

**Proof sketch.** Copy `u` into the first `W` cells, remembering its last bit read (`false` if
`W = 0`, where the extension is `0`); then write that bit `a` times, counted in the state; then
return the heads.

### `Turing.exists_wordIntTM`

**Proof sketch.** Let `b` be the bit length of `|c|` plus one. Bit `i` of `BitVec.ofInt n c` is
`c.testBit i` (two's complement), which for `i ≥ b` is the sign of `c`. Sweep the destination's
old word, writing `c.testBit i` from a table in the state for `i < b` and the sign beyond, and stop
at its right delimiter; then return the head.
