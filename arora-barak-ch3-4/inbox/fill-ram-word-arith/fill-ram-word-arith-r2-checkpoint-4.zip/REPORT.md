# fill-ram-word-arith round 2, checkpoint 4

Base: `7342f98b58704d6c25faf668ed1a64ea0b27c4af`, read-only ram/readers-2.
Instructions: `e40383d88d79e23026c95e20608ee8827d45e59b`.
Local source branch `codex/fill-ram-word-arith-r2`, commit `19b4bfcd6`; never rebased or pushed.
Round-1 archive and internal hashes were verified, and its patch was applied to this new base.

Eight of nine targets are proved: bvBits_injective, exists_wordAddTM, exists_wordSubTM,
exists_wordHalfTM, exists_wordSignExtendTM, exists_wordIntTM, exists_wordSignTM, exists_wordNonzeroTM.
Multiplication remains the sole original admission and is ongoing.
This checkpoint does not complete the objective. No proved target reaches an admission.

The arbitrary-frame alias-safe lockstep row is proved once, using catalog_trace_run and
catalogTrace_eq. Add/sub use C=2; half composes copy, sign fold and arithmetic shift with C=9.
Sign extension now composes seven rows in phaseHostTM: sign fold, copy, common walk, one fixed
backward move, writeConstTM, and two rewindTM rows. Segment.trans composes them. The destination
rewind reads only the copied prefix, and permits a sign bit at the current boundary. Total time
and physical displacement are bounded by (2*a+20)*(W+1). The exact endpoint preserves every
frame cell and restores all heads, including W=0 and a=0.

## Authorized reader and imports

The only added public declaration is `Cfg.mapState_eq` in StateRenaming.lean, a pure record
equation proved by rfl, beside its definition. The existing field readers were searched first.
All 18 original public statements are byte-identical. StateRenaming is otherwise byte-identical.

Added existing Build imports: Seam (phase host and transport); Scan (constant writer);
Rewind (prefix rewind allowing an arbitrary current cell); SeamLayout (published BufferWords
prefix readers, notably bufferTape_take). The no-scratch-precondition lockstep copy is reused
instead of requiring blank destination cells. The catalog has no standalone unconditional
common-head move row, so wordMoveTM is a one-step leaf built from the same action helper.
No private host or copied catalog proof is introduced. wordPhase_segment is generalized to a
dependent phase-state family, so half and sign extension share the public-host adapter.

## Private declaration inventory

- `wordLockAction`: Move the three selected heads together, optionally writing one destination bit. 
- `wordLockAction_apply`: The lockstep action changes only its destination cell and the selected heads. 
- `wordLockTM`: A two-source finite-state sweep, followed by a return guided by the first source. The catalog's one-tape scan cannot read both source bits with a carry. The selected tapes may alias: the forward pass reads each cell before writing it, and every written cell stays nonblank. The carry is discarded at the right delimiter, so every run has the same live exit. 
- `wordLockCfg`: A lockstep configuration with a written destination prefix and a common head offset. 
- `wordLockCfg_read_fwd`: At the forward boundary no source cell has yet been overwritten, even with aliases. 
- `wordLockCfg_read_full`: A full destination patch keeps its delimiters; an aliased source reads the output word. 
- `wordLockCfg_write`: One forward action extends the output prefix by exactly its next bit. 
- `wordLockCfg_move`: A non-writing lockstep action translates only the common head offset. 
- `wordLock_run`: The framed lockstep sweep computes any transducer whose successive states and bits satisfy the supplied cell equations. No scratch-blankness hypothesis is needed.
- `wordRippleStep`: One ripple-carry cell, optionally complementing the second operand for subtraction. 
- `wordRipple_run`: The framed ripple row adds the optionally complemented second word and an initial carry.
- `wordFold_run`: A Boolean fold scans one delimited word, returns the head, and preserves every cell.
- `bvBits_last_fold`: The overwrite fold of a word's bits is its most significant bit, with false for width zero. 
- `wordAny_fold`: The Boolean disjunction fold records exactly whether a true cell has occurred. 
- `bvBits_no_true`: A word has no true bit exactly when it is zero. 
- `wordAt_mapState`: State renaming does not affect a word held at a work head. 
- `wordAt_write`: A same-width word write keeps the destination delimited. 
- `wordPhase_segment`: A public phase-host run is a segment avoiding any designated exit in another phase.
- `wordPhase_guard`: A row's exit cut supplies the phase-host guard when only its exits redirect. 
- `wordHalf_bits`: Moving every bit down one position and repeating the sign bit is arithmetic halving.
- `wordWrite_twice`: Two writes of equal-width words on one tape retain only the last word. 
- `wordHalfRows`: The rows of arithmetic halving: copy, sign fold, and either sign-filled shift. 
- `wordHalfRed`: Halving dispatches the sign flag to the corresponding fixed-sign scan, then one exit. 
- `wordHalfTM`: Arithmetic halving composed from the framed copy and the catalog scans in a phase host. 
- `wordHalf_run`: The arithmetic-shift program preserves every frame and returns all heads.
- `wordMoveTM`: One fixed move of the selected heads. The catalog supplies its action primitives but no standalone fixed-distance work-head row; this one-step leaf is used between the existing scan rows. 
- `wordMove_run`: The fixed move takes one step and preserves every cell and every other head. 
- `wordSignExtend_bits`: Sign extension appends copies of the sign bit to the little-endian word.
- `wordWrite_append`: Writing at the end of a patched prefix joins the two words, for arbitrary other heads. 
- `WordExtStage`: The finite sequence of existing rows used for sign extension. 
- `wordExtPh`: A row's own state alphabet; the sign is carried by the phase index. 
- `wordExtPh_fintype`: The sign-extension rows are finite for every fixed extension length. 
- `wordExtPh_decidableEq`: Each sign-extension row has decidable state equality. 
- `wordExtRows`: Sign extension uses the catalog's copy, walk, constant writer, and rewind rows. 
- `wordExtRed`: The finite dispatch table threads the computed sign through the extension rows. 
- `wordExtTM`: The catalog-row program for sign extension; every loop belongs to an existing row. 
- `wordExtExit`: Only catalog exits trigger a sign-extension dispatch. 
- `wordExtRed_none`: A state outside a row's catalog exits cannot redirect the extension host. 
- `wordExtHeads`: The source and destination head offsets of the extension program. 
- `wordExtCfg`: A framed extension configuration after the source has been copied, in any phase type. 
- `wordExtCfg_mapState`: Tagging an extension configuration changes only its phase state. 
- `wordExtHeads_add`: Moving both selected heads by one common offset adds it to their frame coordinates. 
- `wordExtHeads_update`: Updating either selected head sets its coordinate and preserves the other. 
- `wordExtCfg_prefix`: A rewind may read the copied prefix even when sign bits occupy its right boundary.
- `wordExt_sign_copy`: The sign fold and framed copy enter the extension's walk row with the original word.
- `wordExt_walk_write`: Walking to the source boundary, stepping back, and writing the fixed sign suffix.
- `wordExt_rewind`: Two catalog rewinds return the source and destination heads without changing the word.

## Reuse and definition boundaries

Reuse searches inspected the catalog's copy/scan/walk/patch/trace rows, CfgFacts transport
facts, Segment composition, and core BitVec's carry, subtraction, complement, width and
arithmetic-shift equations. The lockstep action/run and the phase placement are factored once.
No catalog table or generic composition proof is copied. The private phase lemma is an adapter
for the existing public host, not a new host.

Other-file definitions are read through published equations and theorems: Action.apply_*;
Cfg.workTapeSymbols_eq; Cfg.mapState_eq and mapState_*; Cfg.mapState_sigma_state_ne;
MultiTapeTM.step_of_some and workTapePos_runFrom_mem_Icc; catalog_trace_run/catalogTrace_eq;
wordPatch_apply/frame/twice/self and catalog_write_take; scanTM_run_ofCfg,
scanResult_fold/shiftLeft; phaseHostTM_run; segment_iff/Segment.trans; reachesWithin_iff.
Only same-file definitions are explicitly unfolded. Core/Mathlib definitions are not supplied
as simp/rw/unfold arguments. New public surface is restricted to the authorized rfl reader;
no new admissions, simp attributes, or axioms were added.


Additional published readers used: walkTM_run_ofCfg, writeConstTM_run_ofCfg,
rewindTM_run_ofCfg, FinTM.bufferTape_take/left, wordPatch_append,
BitVec.getLsbD_signExtend, List.take_left. Search logs and failed-to-passing local elaborations
are retained. Function.update_apply is a theorem, not an unfolded Mathlib definition.

## Verification

- Native owned file constant-target-01: exit 0, only the original multiplication admission warns.
- Checkpoint4Axioms: exit 0, all eight targets use at most propext, Classical.choice, Quot.sound;
  the pure reader uses no axioms.
- Checkpoint4Dependencies: exit 0, all eight reachable direct-sorryAx-user lists are empty.
- Checkpoint4Sealed: exit 0. STRICT SEAL 428 imported TCSlib definitions; removed 3 simp/unfold registrations
- checkpoint-4-freeze.log: all 18 original statements and the reader-home-file scope PASS.
- The final full downstream replay remains pending. No round-1 replay is claimed for this base.
- New composition and row imports were bootstrapped in the own round-2 scratch tree, all exit 0.
  No old TCSlib oleans reused; no lake build, cache fetch, or global cache-history claim.
- Guarded runner starts at most one own Lean and checks the machine-wide three-process limit.
  All recorded process counts, waits, start/end/RSS/exit information remain in evidence-r2/logs.

macOS preflight and exact-pins package symlink match the prior reports; original evidence is
included. Thirty preexisting blueprint edits remain untouched and excluded. Checkpoints 1 and 2
were pushed as 963bbea12 and 8a7cc31f3. An unrelated untracked startup zip blocks the original
shared exchange checkout, so deliveries use an isolated managed checkout, with pull --rebase
before each non-force exchange-only push. No PR or campaign-branch push.

Owned file length: 1471 lines. Scoped diff:

```
 .../Complexity/TuringMachine/Build/WordArith.lean  | 1269 +++++++++++++++++++-
 TCSlib/Complexity/TuringMachine/StateRenaming.lean |    6 +
 2 files changed, 1243 insertions(+), 32 deletions(-)
```

## Constant writer added in this checkpoint

`wordConstIndex` is a finite saturated counter, `wordConstStep` emits the corresponding
natural-number bit or its complement, `wordConstStep_cell` proves the cell equations, and
`wordConst_run` instantiates the SAME framed lockstep sweep with all tapes aliased to tape 2.
No extra machine or host is needed. Searched core conversion/bit equations first and cite
BitVec.ofInt_natCast, BitVec.ofInt_negSucc_eq_not_ofNat, getLsbD_ofNat/getLsbD_not,
Nat.testBit_lt_two_pow, and Nat.lt_two_pow_self. The state table may be larger than a minimal
bit-length table; the theorem places no bound on the finite control's size. The explicit
running constant is 2*(a+1). All eight dependency lists are empty. The dependency probe now
uses a HashSet for visited names to avoid quadratic list membership; its traversal and
admission criterion are unchanged. Checkpoint 3 was delivered in exchange commit 369e30111.
