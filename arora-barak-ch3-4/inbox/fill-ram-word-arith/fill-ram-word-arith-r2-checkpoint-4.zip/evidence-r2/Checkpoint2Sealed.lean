/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.TuringMachine.Build.Contract.Reach
import TCSlib.Complexity.TuringMachine.Build.Catalog
import TCSlib.Complexity.TuringMachine.Build.Seam

open Lean Elab Command Meta in
run_cmd do
  let env ← getEnv
  let simp ← liftTermElabM getSimpTheorems
  let mut count := 0
  let mut removed := 0
  for (n, ci) in env.constants.toList do
    if let .defnInfo di := ci then
      if let some idx := env.getModuleIdxFor? n then
        let home := env.header.moduleNames[idx.toNat]!
        let isAbbrev := match di.hints with | .abbrev => true | _ => false
        if home.toString.startsWith "TCSlib." && !isAbbrev && !env.isProjectionFn n then
          if simp.toUnfold.contains n || simp.isLemma (.decl n) then
            elabCommand (← `(attribute [-simp] $(mkIdent n)))
            removed := removed + 1
          elabCommand (← `(attribute [local irreducible] $(mkIdent n)))
          count := count + 1
  logInfo m!"STRICT SEAL {count} imported TCSlib definitions; removed {removed} simp/unfold registrations"

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Fixed-width words on tapes: arithmetic rows

A word of `W` bits (`BitVec W`) is held on a work tape as its `W` bits, least significant first,
delimited by blanks at the head's offsets `-1` and `W`. This file states the rows that compute
on such words: addition, subtraction and multiplication modulo `2^W`, the arithmetic shift right,
sign extension, writing the word of an integer constant, and the sign and zero tests. They are the
arithmetic of a word RAM run on a Turing machine (`WordRAM.exists_simulation`).

Every row is a five-tape machine over `Bool`: tapes `0` and `1` hold the operands, tape `2` the
destination, and tapes `3` and `4` are blank scratch tapes, left blank. A row writes only the
destination's word interval, leaves every head where it was, and is stated with
`Turing.ReachesWithin`. A consumer places the five tapes among its own with `Turing.embedEmitTM`
and composes the rows with `Turing.Contract.ofReaches`. The words have one width throughout, so
the length of an operand delimits every scan and `W = 0` (empty words) needs no special case.

No row of the catalog reads two tapes with a carry, so addition and subtraction require
lockstep transducers. The sign and zero tests reuse the one-tape `Turing.scanTM` through its
read-only fold instance.

## Main definitions

* `Turing.bvBits`: the bits of a word, least significant first.
* `Turing.WordAt`: a word delimited at a head.
* `Turing.wordWrite`: the tapes after writing a word at a head.

## Main results

* `Turing.exists_wordAddTM`, `Turing.exists_wordSubTM`, `Turing.exists_wordMulTM`: addition,
  subtraction and multiplication modulo `2^W`, in `O(W)`, `O(W)` and `O(W²)` steps.
* `Turing.exists_wordHalfTM`: the arithmetic shift right by one place.
* `Turing.exists_wordSignExtendTM`: sign extension from `W` to `W + a` bits.
* `Turing.exists_wordIntTM`: the word of an integer constant, as wide as a guide word plus `a`.
* `Turing.exists_wordSignTM`, `Turing.exists_wordNonzeroTM`: the tests `u < 0` and `u ≠ 0`.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (§1.2: multitape machines; Exercise 1.9: a RAM simulated by a
  Turing machine, whose arithmetic these rows provide.)
-/

namespace Turing

/-! ## Words on tapes -/

/-- **The bits of a word**, least significant first: `bvBits v = [v₀, v₁, …, v_{W-1}]`. -/
def bvBits {W : ℕ} (v : BitVec W) : List Bool := List.ofFn fun i : Fin W => v.getLsbD i

/-- The bits of a word, as an equation. -/
theorem bvBits_def {W : ℕ} (v : BitVec W) :
    bvBits v = List.ofFn fun i : Fin W => v.getLsbD i := rfl

/-- A word of `W` bits has `W` bits. -/
theorem bvBits_length {W : ℕ} (v : BitVec W) : (bvBits v).length = W := by
  simp [bvBits]

/-- Distinct words have distinct bits.

**Proof sketch.** Equal bit lists give `getLsbD` equal at every `i < W` (`List.ofFn_inj`), and
`BitVec.eq_of_getLsbD_eq` concludes. -/
theorem bvBits_injective {W : ℕ} : Function.Injective (bvBits (W := W)) := by
  intro u v h
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  have he := List.ofFn_inj.mp h
  exact congrFun he ⟨i, hi⟩

/-- **A word delimited at a head**: tape `r` holds `w` from its head, with blanks at the head's
offsets `-1` and `|w|`. The cells beyond are arbitrary. -/
def WordAt {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K) (w : List Bool) :
    Prop :=
  ∀ p : ℤ, -1 ≤ p → p ≤ (w.length : ℤ) →
    d.workTapes r (d.workTapePos r + p) = FinTM.bufferTape w p

/-- `WordAt`, as an equivalence with its definition. -/
theorem wordAt_iff {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (w : List Bool) :
    WordAt d r w ↔ ∀ p : ℤ, -1 ≤ p → p ≤ (w.length : ℤ) →
      d.workTapes r (d.workTapePos r + p) = FinTM.bufferTape w p :=
  Iff.rfl

/-- **The tapes after writing a word at a head**: on tape `r`, the cells from its head on hold `w`
over `|w|` cells; every other cell, of every tape, is unchanged. -/
def wordWrite {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (w : List Bool) : Fin K → ℤ → Option Bool :=
  fun j q =>
    if j = r ∧ d.workTapePos j ≤ q ∧ q < d.workTapePos j + (w.length : ℤ)
      then FinTM.bufferTape w (q - d.workTapePos j)
    else d.workTapes j q

/-- `wordWrite`, as an equation. -/
theorem wordWrite_apply {K : ℕ} {S : Type} {x : List Bool} (d : Cfg K Bool S x) (r : Fin K)
    (w : List Bool) (j : Fin K) (q : ℤ) :
    wordWrite d r w j q =
      if j = r ∧ d.workTapePos j ≤ q ∧ q < d.workTapePos j + (w.length : ℤ)
        then FinTM.bufferTape w (q - d.workTapePos j)
      else d.workTapes j q :=
  rfl

/-- **The common precondition of the word rows**: tapes `3` and `4` are blank everywhere. -/
def ScratchBlank {S : Type} {x : List Bool} (d : Cfg 5 Bool S x) : Prop :=
  ∀ j : Fin 5, 3 ≤ j.val → ∀ p : ℤ, d.workTapes j p = none

/-- `ScratchBlank`, as an equivalence with its definition. -/
theorem scratchBlank_iff {S : Type} {x : List Bool} (d : Cfg 5 Bool S x) :
    ScratchBlank d ↔ ∀ j : Fin 5, 3 ≤ j.val → ∀ p : ℤ, d.workTapes j p = none :=
  Iff.rfl

/-! ## Framed lockstep transducers -/

/-- Move the three selected heads together, optionally writing one destination bit. -/
private def wordLockAction {k : ℕ} {A : Type} (src rhs dst : Fin k) (b : Option Bool)
    (m : SignType) (q : ScanPhase A) : Action k Bool (ScanPhase A) :=
  ⟨0, fun j => (if j = dst then b.map some else none,
    if j = src ∨ j = rhs ∨ j = dst then m else 0), none, some q⟩

/-- The lockstep action changes only its destination cell and the selected heads. -/
private theorem wordLockAction_apply {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst : Fin k) (b : Option Bool) (m : SignType) (q : ScanPhase A)
    (d : Cfg k Bool (ScanPhase A) x) :
    (wordLockAction src rhs dst b m q).apply d =
      { d with
        state := some q
        workTapes := fun j => if j = dst then
          match b with
          | none => d.workTapes j
          | some bit => Function.update (d.workTapes j) (d.workTapePos j) (some bit)
          else d.workTapes j
        workTapePos := fun j => d.workTapePos j +
          if j = src ∨ j = rhs ∨ j = dst then (m : ℤ) else 0} := by
  apply Cfg.ext
  · rw [Action.apply_state]; rfl
  · rw [Action.apply_inputPos]; exact moveInputPos_zero _
  · funext j
    rw [Action.apply_workTapes, Cfg.workTapeSymbols_eq]
    by_cases hj : j = dst <;> cases b <;>
      simp only [wordLockAction, hj, if_true, if_false, Option.map_none, Option.map_some,
        Option.getD_none, Option.getD_some, Function.update_eq_self]
  · funext j
    rw [Action.apply_workTapePos]
    by_cases hj : j = src ∨ j = rhs ∨ j = dst <;>
      simp only [wordLockAction, hj, if_true, if_false, SignType.coe_zero]
  · rw [Action.apply_output]; exact List.append_nil _

/-- A two-source finite-state sweep, followed by a return guided by the first source.
The catalog's one-tape scan cannot read both source bits with a carry. The selected tapes may
alias: the forward pass reads each cell before writing it, and every written cell stays nonblank.
The carry is discarded at the right delimiter, so every run has the same live exit. -/
private def wordLockTM {k : ℕ} {A : Type} (src rhs dst : Fin k)
    (δ : A → Bool → Bool → A × Bool) (a₀ : A) : MultiTapeTM k Bool (ScanPhase A) where
  q₀ := .fwd a₀
  tr := fun q _ w => match q with
    | .fwd a => match w src with
      | some bit =>
        let r := δ a bit ((w rhs).getD false)
        wordLockAction src rhs dst (some r.2) 1 (.fwd r.1)
      | none => wordLockAction src rhs dst none (-1) (.bwd a₀)
    | .bwd _ => match w src with
      | some _ => wordLockAction src rhs dst none (-1) (.bwd a₀)
      | none => wordLockAction src rhs dst none 1 (.done a₀)
    | .done a => wordLockAction src rhs dst none 0 (.done a)

/-- A lockstep configuration with a written destination prefix and a common head offset. -/
private def wordLockCfg {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst : Fin k) (d : Cfg k Bool (ScanPhase A) x)
    (out : List Bool) (q : ScanPhase A) (n : ℕ) (h : ℤ) : Cfg k Bool (ScanPhase A) x :=
  { d with
    state := some q
    workTapes := fun j p =>
      if j = dst ∧ d.workTapePos j ≤ p ∧ p < d.workTapePos j + (n : ℤ)
        then FinTM.bufferTape out (p - d.workTapePos j) else d.workTapes j p
    workTapePos := fun j => d.workTapePos j +
      if j = src ∨ j = rhs ∨ j = dst then h else 0}

/-- At the forward boundary no source cell has yet been overwritten, even with aliases. -/
private theorem wordLockCfg_read_fwd {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst j : Fin k) (d : Cfg k Bool (ScanPhase A) x) (out w : List Bool)
    (q : ScanPhase A) (n : ℕ) (hj : j = src ∨ j = rhs ∨ j = dst)
    (hn : n ≤ w.length) (hw : WordAt d j w) :
    (wordLockCfg src rhs dst d out q n n).workTapeSymbols j = FinTM.bufferTape w n := by
  rw [Cfg.workTapeSymbols_eq]
  simp only [wordLockCfg, if_pos hj, lt_self_iff_false, and_false, if_false]
  exact ((wordAt_iff d j w).mp hw) n (by omega) (by exact_mod_cast hn)

/-- A full destination patch keeps its delimiters; an aliased source reads the output word. -/
private theorem wordLockCfg_read_full {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst j : Fin k) (d : Cfg k Bool (ScanPhase A) x) (out w : List Bool)
    (q : ScanPhase A) (h : ℤ) (hj : j = src ∨ j = rhs ∨ j = dst)
    (hlen : out.length = w.length) (hlo : -1 ≤ h) (hhi : h ≤ (w.length : ℤ))
    (hw : WordAt d j w) :
    (wordLockCfg src rhs dst d out q w.length h).workTapeSymbols j =
      FinTM.bufferTape (if j = dst then out else w) h := by
  rw [Cfg.workTapeSymbols_eq]
  simp only [wordLockCfg, if_pos hj]
  by_cases hd : j = dst
  · have hp := wordPatch_frame (d.workTapes j) (d.workTapePos j) w out hlen
      ((wordAt_iff d j w).mp hw) h hlo (by simpa only [hlen] using hhi)
    simpa only [wordPatch_apply, hlen, hd, true_and, if_true] using hp
  · simp only [hd, false_and, if_false]
    exact ((wordAt_iff d j w).mp hw) h hlo hhi

/-- One forward action extends the output prefix by exactly its next bit. -/
private theorem wordLockCfg_write {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst : Fin k) (d : Cfg k Bool (ScanPhase A) x) (out : List Bool)
    (q q' : ScanPhase A) (r : ℕ) (hr : r < out.length) :
    (wordLockAction src rhs dst (some out[r]) 1 q').apply
        (wordLockCfg src rhs dst d out q r r) =
      wordLockCfg src rhs dst d out q' (r + 1) (r + 1) := by
  rw [wordLockAction_apply]
  apply Cfg.ext
  · rfl
  · rfl
  · funext j
    by_cases hj : j = dst
    · subst j
      simp only [wordLockCfg, if_true, true_and, or_true]
      exact catalog_write_take (d.workTapes dst) (d.workTapePos dst) out r hr
    · simp only [wordLockCfg, hj, if_false, false_and]
  · funext j
    by_cases hj : j = src ∨ j = rhs ∨ j = dst
    · simp only [wordLockCfg, hj, if_true, SignType.coe_one, Nat.cast_add, Nat.cast_one]
      omega
    · simp only [wordLockCfg, hj, if_false, add_zero]
  · rfl

/-- A non-writing lockstep action translates only the common head offset. -/
private theorem wordLockCfg_move {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst : Fin k) (d : Cfg k Bool (ScanPhase A) x) (out : List Bool)
    (q q' : ScanPhase A) (n : ℕ) (h : ℤ) (m : SignType) :
    (wordLockAction src rhs dst none m q').apply
        (wordLockCfg src rhs dst d out q n h) =
      wordLockCfg src rhs dst d out q' n (h + (m : ℤ)) := by
  rw [wordLockAction_apply]
  apply Cfg.ext
  · rfl
  · rfl
  · funext j
    simp only [ite_self]
    rfl
  · funext j
    by_cases hj : j = src ∨ j = rhs ∨ j = dst <;>
      simp only [wordLockCfg, hj, if_true, if_false, add_zero, add_assoc]
  · rfl

/-- The framed lockstep sweep computes any transducer whose successive states and bits
satisfy the supplied cell equations. No scratch-blankness hypothesis is needed.

**Proof sketch.** `catalog_trace_run` joins the forward prefix configurations and the
return configurations. `wordLockCfg_read_fwd` reads each input before its cell can be written;
`wordLockCfg_write` extends the prefix using `catalog_write_take`. The full-patch reader
uses `wordPatch_frame`, so an aliased guide remains a delimited nonblank word during the
return. `catalogTrace_eq` gives the endpoint and excludes earlier exits. The general
`MultiTapeTM.workTapePos_runFrom_mem_Icc` bounds displacement by the linear running time. -/
private theorem wordLock_run {k : ℕ} {A : Type} {x : List Bool}
    (src rhs dst : Fin k) (δ : A → Bool → Bool → A × Bool) (a₀ : A)
    (u v out : List Bool) (c : ℕ → A) (hv : v.length = u.length)
    (ho : out.length = u.length) (hc : c 0 = a₀)
    (hδ : ∀ r (hr : r < u.length),
      δ (c r) (u[r]) (v[r]'(by omega)) = (c (r + 1), (out[r]'(by omega))))
    (d : Cfg k Bool (ScanPhase A) x) (hd : d.state = some (.fwd a₀))
    (hu : WordAt d src u) (hw : WordAt d rhs v) :
    ReachesWithin (wordLockTM src rhs dst δ a₀) d {some (.done a₀)}
      (2 * (u.length + 1)) (2 * (u.length + 1))
      {d with state := some (.done a₀), workTapes := wordWrite d dst out} := by
  let M := wordLockTM src rhs dst δ a₀
  let F := fun r => wordLockCfg src rhs dst d out (.fwd (c r)) r r
  let R := fun r : ℕ => wordLockCfg src rhs dst d out (.bwd a₀) u.length ((r : ℤ) - 1)
  let D := wordLockCfg src rhs dst d out (.done a₀) u.length 0
  have hF0 : F 0 = d := by
    apply Cfg.ext
    · simpa only [F, wordLockCfg, hc] using hd.symm
    · rfl
    · funext j z
      simp only [F, wordLockCfg, Nat.cast_zero, add_zero]
      split_ifs with h
      · omega
      · rfl
    · funext j
      simp only [F, wordLockCfg, Nat.cast_zero, ite_self, add_zero]
    · rfl
  have hF : ∀ r < u.length, M.step (F r) = F (r + 1) := by
    intro r hr
    have hs : (F r).workTapeSymbols src = some u[r] := by
      simpa only [F, FinTM.bufferTape_nat, List.getElem?_eq_getElem hr] using
        wordLockCfg_read_fwd src rhs dst src d out u (.fwd (c r)) r
          (Or.inl rfl) hr.le hu
    have ht : (F r).workTapeSymbols rhs = some (v[r]'(by omega)) := by
      simpa only [F, FinTM.bufferTape_nat, List.getElem?_eq_getElem (by omega : r < v.length)] using
        wordLockCfg_read_fwd src rhs dst rhs d out v (.fwd (c r)) r
          (Or.inr (Or.inl rfl)) (by omega) hw
    rw [MultiTapeTM.step_of_some (show (F r).state = some (.fwd (c r)) from rfl)]
    simp only [M, wordLockTM, hs, ht, Option.getD_some, hδ r hr]
    exact wordLockCfg_write src rhs dst d out (.fwd (c r)) (.fwd (c (r + 1))) r (by omega)
  have hturn : M.step (F u.length) = R u.length := by
    have hs : (F u.length).workTapeSymbols src = none := by
      simpa only [F, FinTM.bufferTape_nat, List.getElem?_length] using
        wordLockCfg_read_fwd src rhs dst src d out u (.fwd (c u.length)) u.length
          (Or.inl rfl) le_rfl hu
    rw [MultiTapeTM.step_of_some (show (F u.length).state = some (.fwd (c u.length)) from rfl)]
    simp only [M, wordLockTM, hs]
    simpa only [F, R, SignType.coe_neg_one, sub_eq_add_neg] using
      wordLockCfg_move src rhs dst d out (.fwd (c u.length)) (.bwd a₀) u.length u.length (-1)
  have hR : ∀ r < u.length, M.step (R (r + 1)) = R r := by
    intro r hr
    let guide := if src = dst then out else u
    have hg : guide.length = u.length := by
      dsimp only [guide]
      split_ifs <;> first | exact ho | rfl
    have hpos : ((r + 1 : ℕ) : ℤ) - 1 = (r : ℤ) := by omega
    have hs : (R (r + 1)).workTapeSymbols src = some (guide[r]'(by omega)) := by
      have hp := wordLockCfg_read_full src rhs dst src d out u (.bwd a₀) r
        (Or.inl rfl) ho (by omega) (by omega) hu
      change (wordLockCfg src rhs dst d out (.bwd a₀) u.length r).workTapeSymbols src =
        FinTM.bufferTape guide r at hp
      rw [FinTM.bufferTape_nat, List.getElem?_eq_getElem (by omega : r < guide.length)] at hp
      simpa only [R, hpos] using hp
    rw [MultiTapeTM.step_of_some (show (R (r + 1)).state = some (.bwd a₀) from rfl)]
    simp only [M, wordLockTM, hs]
    rw [wordLockCfg_move]
    dsimp only [R]
    congr 1
    simp only [SignType.coe_neg_one]
    omega
  have hentry : M.step (R 0) = D := by
    have hs : (R 0).workTapeSymbols src = none := by
      simpa only [R, Nat.cast_zero, zero_sub, FinTM.bufferTape_left] using
        wordLockCfg_read_full src rhs dst src d out u (.bwd a₀) (-1)
          (Or.inl rfl) ho le_rfl (by omega) hu
    rw [MultiTapeTM.step_of_some (show (R 0).state = some (.bwd a₀) from rfl)]
    simp only [M, wordLockTM, hs]
    simpa only [R, D, Nat.cast_zero, zero_sub, SignType.coe_one, neg_add_cancel] using
      wordLockCfg_move src rhs dst d out (.bwd a₀) (.done a₀) u.length (-1) 1
  have hD : M.step D = D := by
    rw [MultiTapeTM.step_of_some (show D.state = some (.done a₀) from rfl)]
    simp only [M, wordLockTM]
    simpa only [D, SignType.coe_zero, add_zero] using
      wordLockCfg_move src rhs dst d out (.done a₀) (.done a₀) u.length 0 0
  have htrace (t : ℕ) : M.runFrom d t = catalogTrace F R D u.length t := by
    simpa only [hF0] using catalog_trace_run M F R D u.length hF hturn hR hentry hD t
  apply (reachesWithin_iff _ _ _ _ _ _).mpr
  refine ⟨2 * u.length + 2, by omega, ?_, ?_, ?_⟩
  · intro t ht
    rw [htrace, catalogTrace_eq]
    split_ifs with h₁ h₂
    · simp only [F, wordLockCfg, Set.mem_singleton_iff]
      intro h
      cases h
    · simp only [R, wordLockCfg, Set.mem_singleton_iff]
      intro h
      cases h
    · omega
  · intro t ht j
    have hp := M.workTapePos_runFrom_mem_Icc d t j
    rw [Finset.mem_Icc] at hp
    rw [abs_le]
    constructor <;> omega
  · rw [htrace, catalogTrace_eq, if_neg (by omega), if_neg (by omega)]
    apply Cfg.ext
    · rfl
    · rfl
    · funext j z
      simp only [D, wordLockCfg, wordWrite_apply, ho]
    · funext j
      simp only [D, wordLockCfg, ite_self, add_zero]
    · rfl

/-- One ripple-carry cell, optionally complementing the second operand for subtraction. -/
private def wordRippleStep (flip : Bool) (carry u v : Bool) : Bool × Bool :=
  let bit := if flip then !v else v
  (Bool.atLeastTwo u bit carry, u ^^ (bit ^^ carry))

/-- The framed ripple row adds the optionally complemented second word and an initial carry.

**Proof sketch.** Instantiate `wordLock_run` with `BitVec.carry` as its state sequence.
`BitVec.carry_zero` supplies the entry; `BitVec.carry_succ` is the state equation, and
`BitVec.getLsbD_add_add_bool` is the output equation. Complemented input bits are read by
`BitVec.getLsbD_not`, only below the fixed word width. -/
private theorem wordRipple_run {k W : ℕ} {x : List Bool} (src rhs dst : Fin k)
    (flip carry : Bool) (u v : BitVec W) (d : Cfg k Bool (ScanPhase Bool) x)
    (hd : d.state = some (.fwd carry)) (hu : WordAt d src (bvBits u))
    (hv : WordAt d rhs (bvBits v)) :
    ReachesWithin (wordLockTM src rhs dst (wordRippleStep flip) carry) d {some (.done carry)}
      (2 * (W + 1)) (2 * (W + 1))
      { d with
        state := some (.done carry)
        workTapes := wordWrite d dst (bvBits
          (u + (if flip then ~~~v else v) + BitVec.setWidth W (BitVec.ofBool carry)))} := by
  let z := if flip then ~~~v else v
  have hstep : ∀ r (hr : r < (bvBits u).length),
      wordRippleStep flip (BitVec.carry r u z carry) ((bvBits u)[r])
        ((bvBits v)[r]'(by simpa only [bvBits_length] using hr)) =
      (BitVec.carry (r + 1) u z carry,
        (bvBits (u + z + BitVec.setWidth W (BitVec.ofBool carry)))[r]'(by
          simpa only [bvBits_length] using hr)) := by
    intro r hr
    have hrW : r < W := by simpa only [bvBits_length] using hr
    have hz : z.getLsbD r = if flip then !(v.getLsbD r) else v.getLsbD r := by
      cases flip <;> simp only [z, Bool.false_eq_true, if_true, if_false, BitVec.getLsbD_not,
        hrW, decide_true, Bool.true_and]
    simp only [bvBits_def, List.getElem_ofFn, wordRippleStep]
    apply Prod.ext
    · rw [BitVec.carry_succ, hz]
    · rw [BitVec.getLsbD_add_add_bool hrW, hz]
  simpa only [bvBits_length] using
    wordLock_run src rhs dst (wordRippleStep flip) carry (bvBits u) (bvBits v)
      (bvBits (u + z + BitVec.setWidth W (BitVec.ofBool carry)))
      (fun r => BitVec.carry r u z carry) (by simp only [bvBits_length])
      (by simp only [bvBits_length]) BitVec.carry_zero hstep d hd hu hv

/-! ## Arithmetic modulo `2^W` -/

/-- **Addition modulo `2^W`.** From the entry, with `u` on tape `0`, `v` on tape `1`, a word of
`W` cells on tape `2` and blank scratch tapes, the row writes `u + v` on tape `2` and stops at its
exit within `C·(W + 1)` steps, every head within `C·(W + 1)` cells and back where it started.
[AB09, Exercise 1.9]

**Proof sketch.** Apply the framed `wordRipple_run` with an uncomplemented second operand
and initial carry false. Its `wordLock_run` sweep writes the low sum bits and returns all
three heads. The state and bit equations are `BitVec.carry_succ` and
`BitVec.getLsbD_add_add_bool`; the final carry is discarded. The bound uses `C = 2`.
-/
theorem exists_wordAddTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} {W : ℕ} (u v : BitVec W) (w : List Bool) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → WordAt d 1 (bvBits v) → WordAt d 2 w →
        w.length = W → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (W + 1)) (C * (W + 1))
          { d with state := some exit, workTapes := wordWrite d 2 (bvBits (u + v)) } := by
  refine ⟨ScanPhase Bool, inferInstance, inferInstance,
    wordLockTM 0 1 2 (wordRippleStep false) false, .fwd false, .done false, 2, ?_⟩
  intro x W u v w d hd hu hv _ _ _
  have h := wordRipple_run 0 1 2 false false u v d hd hu hv
  simpa [BitVec.ofBool_false] using h

/-- **Subtraction modulo `2^W`.** As `Turing.exists_wordAddTM`, writing `u - v`.
[AB09, Exercise 1.9]

**Proof sketch.** Apply the same framed `wordRipple_run` with complemented second-operand
bits and initial carry true. `BitVec.neg_eq_not_add` identifies the computed word with
`u - v`, including underflow modulo the width. The shared sweep returns every head and
uses the same constant `C = 2`. -/
theorem exists_wordSubTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} {W : ℕ} (u v : BitVec W) (w : List Bool) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → WordAt d 1 (bvBits v) → WordAt d 2 w →
        w.length = W → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (W + 1)) (C * (W + 1))
          { d with state := some exit, workTapes := wordWrite d 2 (bvBits (u - v)) } := by
  refine ⟨ScanPhase Bool, inferInstance, inferInstance,
    wordLockTM 0 1 2 (wordRippleStep true) true, .fwd true, .done true, 2, ?_⟩
  intro x W u v w d hd hu hv _ _ _
  have hone : BitVec.setWidth W (BitVec.ofBool true) = (1#W) := by
    rw [BitVec.ofBool_true]
    exact BitVec.setWidth_ofNat_one_eq_ofNat_one_of_lt (by decide : 0 < 1)
  have he : u + ~~~v + BitVec.setWidth W (BitVec.ofBool true) = u - v := by
    rw [hone, BitVec.add_assoc, ← BitVec.neg_eq_not_add, ← BitVec.sub_eq_add_neg]
  have h := wordRipple_run 0 1 2 true true u v d hd hu hv
  simpa only [if_true, he] using h

/-- **Multiplication modulo `2^W`.** As `Turing.exists_wordAddTM`, writing `u * v`, within
`C·(W + 1)²` steps and radius `C·(W + 1)`. [AB09, Exercise 1.9]

**Proof sketch.** Shift and add. Copy `u` to scratch tape `3` and clear the destination to `0`.
For each bit of `v`, from the least significant: if it is `1`, add tape `3` into the destination
(the lockstep adder with the destination as an operand, using scratch tape `4` for the sum and
copying it back); then shift tape `3` up by one place in place, dropping its top bit. The
iteration walks `v`'s head one cell per round and stops at its delimiter, so it needs no counter.
Each round is `O(W)` and there are `W` rounds. Finally clear the scratch tapes and return the
heads. The invariant after `r` rounds: the destination holds `u * (v mod 2^r)` and tape `3` holds
`u <<< r`, both modulo `2^W`. -/
theorem exists_wordMulTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} {W : ℕ} (u v : BitVec W) (w : List Bool) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → WordAt d 1 (bvBits v) → WordAt d 2 w →
        w.length = W → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (W + 1) ^ 2) (C * (W + 1))
          { d with state := some exit, workTapes := wordWrite d 2 (bvBits (u * v)) } := by
  sorry

/-! ## Framed read-only folds -/

/-- A Boolean fold scans one delimited word, returns the head, and preserves every cell.

**Proof sketch.** Apply `scanTM_run_ofCfg` and `scanResult_fold`. The `WordAt` interval
identifies every cell of the resulting word patch with its original value. The catalog's
first-exit clause excludes both Boolean exits, and its head envelope gives radius
`2 * (w.length + 1)`. -/
private theorem wordFold_run (δ : Bool → Bool → Bool) (a₀ : Bool) {x : List Bool}
    (w : List Bool) (d : Cfg 5 Bool (ScanPhase Bool) x)
    (hd : d.state = some (.fwd a₀)) (hw : WordAt d 0 w) :
    ReachesWithin (scanTM 5 0 (scanFold δ) scanKeep a₀) d
      {some (.done true), some (.done false)} (2 * (w.length + 1)) (2 * (w.length + 1))
      {d with state := some (.done (w.foldl δ a₀))} := by
  obtain ⟨hrun, hcut, henv⟩ :=
    scanTM_run_ofCfg 0 (scanFold δ) scanKeep a₀ w d hd ((wordAt_iff d 0 w).mp hw)
  rw [scanResult_fold] at hrun
  have hpatch : (fun j q =>
      if j = 0 ∧ d.workTapePos j ≤ q ∧ q < d.workTapePos j + (w.length : ℤ)
        then FinTM.bufferTape w (q - d.workTapePos j) else d.workTapes j q) =
      d.workTapes := by
    funext j q
    by_cases hj : j = 0
    · subst j
      simpa only [wordPatch_apply, true_and] using
        congrFun (wordPatch_self (d.workTapes 0) (d.workTapePos 0) w
          ((wordAt_iff d 0 w).mp hw)) q
    · simp only [hj, false_and, if_false]
  simp only [hpatch] at hrun
  apply (reachesWithin_iff _ _ _ _ _ _).mpr
  refine ⟨2 * w.length + 2, by omega, ?_, ?_, hrun⟩
  · intro t ht
    simpa only [Set.mem_insert_iff, Set.mem_singleton_iff, not_or] using
      And.intro (hcut t ht true) (hcut t ht false)
  · intro t ht j
    have hj := henv j t ht
    by_cases h : j = 0
    · subst j
      simp only [if_true, Finset.mem_Icc] at hj
      rw [abs_le]
      constructor <;> omega
    · simp only [h, if_false] at hj
      rw [hj, sub_self, abs_zero]
      positivity

/-- The overwrite fold of a word's bits is its most significant bit, with false for width zero. -/
private theorem bvBits_last_fold {W : ℕ} (u : BitVec W) :
    (bvBits u).foldl (fun _ b => b) false = u.msb := by
  cases W with
  | zero => simp [bvBits, BitVec.msb_zero_length]
  | succ W =>
    rw [bvBits_def, List.ofFn_succ_last, List.foldl_append]
    simp only [List.foldl_cons, List.foldl_nil]
    simpa only [Fin.val_last, Nat.add_sub_cancel] using (BitVec.msb_eq_getLsbD_last u).symm

/-- The Boolean disjunction fold records exactly whether a true cell has occurred. -/
private theorem wordAny_fold (w : List Bool) (b : Bool) :
    w.foldl (fun a c => a || c) b = (b || decide (true ∈ w)) := by
  induction w generalizing b with
  | nil => simp
  | cons a w ih =>
    simp only [List.foldl_cons, ih, List.mem_cons, Bool.decide_or]
    cases a <;> cases b <;> simp

/-- A word has no true bit exactly when it is zero. -/
private theorem bvBits_no_true {W : ℕ} (u : BitVec W) :
    true ∉ bvBits u ↔ u = 0 := by
  constructor
  · intro h
    apply bvBits_injective
    rw [bvBits_def, bvBits_def]
    apply List.ofFn_inj.mpr
    funext i
    change u.getLsbD i = (0#W).getLsbD i
    rw [BitVec.getLsbD_zero]
    apply Bool.eq_false_iff.mpr
    intro hi
    exact h (List.mem_ofFn.mpr ⟨i, hi⟩)
  · rintro rfl
    simp [bvBits]

/-! ## Word layouts under composition -/

/-- State renaming does not affect a word held at a work head. -/
private theorem wordAt_mapState {k : ℕ} {S T : Type} {x : List Bool}
    (d : Cfg k Bool S x) (f : S → T) (j : Fin k) (w : List Bool) :
    WordAt (d.mapState f) j w ↔ WordAt d j w := by
  simp only [wordAt_iff, Cfg.mapState_workTapes, Cfg.mapState_workTapePos]

/-- A same-width word write keeps the destination delimited. -/
private theorem wordAt_write {k : ℕ} {S : Type} {x : List Bool} (d : Cfg k Bool S x)
    (j : Fin k) (u v : List Bool) (hlen : v.length = u.length) (hw : WordAt d j u) :
    WordAt {d with workTapes := wordWrite d j v} j v := by
  rw [wordAt_iff]
  intro z hlo hhi
  have h := wordPatch_frame (d.workTapes j) (d.workTapePos j) u v hlen
    ((wordAt_iff d j u).mp hw) z hlo hhi
  simpa only [wordWrite_apply, wordPatch_apply, true_and] using h

/-- A public phase-host run is a segment avoiding any designated exit in another phase.

**Proof sketch.** `phaseHostTM_run` supplies the tagged prefix and the stationary dispatch.
`Cfg.mapState_sigma_state_ne` excludes the other phase's exit. State renaming preserves
every head, so the phase's head relation holds through the dispatch. These segments compose
with the library's `Segment.trans`. -/
private theorem wordPhase_segment {k : ℕ} {I S : Type} {x : List Bool}
    (Mf : I → MultiTapeTM k Bool S) (q₀ : Σ _ : I, S)
    (red : I → S → Option (Σ _ : I, S)) (p : I)
    (c c' : Cfg k Bool S x) (T : ℕ) (s' : S) (next exit : Σ _ : I, S)
    (P : (Fin k → ℤ) → Prop) (hrun : (Mf p).runFrom c T = c')
    (hs : c'.state = some s') (hr : red p s' = some next)
    (hg : ∀ u < T, ∀ s, ((Mf p).runFrom c u).state = some s → red p s = none)
    (hp : p ≠ exit.1) (he : ∀ u ≤ T, P ((Mf p).runFrom c u).workTapePos) :
    Segment (phaseHostTM Mf q₀ red) {some exit} P (c.mapState (fun s : S => (⟨p, s⟩ : Σ _ : I, S)))
      (c'.mapState fun _ => next) (T + 1) := by
  have h := phaseHostTM_run Mf q₀ red p c c' T hrun s' hs next hr hg
  apply (segment_iff _ _ _ _ _ _).mpr
  refine ⟨h.2, ?_, ?_⟩
  · intro u hu
    rw [h.1 u (by omega)]
    exact Cfg.mapState_sigma_state_ne (Ph := fun _ : I => S) p exit hp ((Mf p).runFrom c u)
  · intro u hu
    by_cases hle : u ≤ T
    · rw [h.1 u hle]
      have hpos : (((Mf p).runFrom c u).mapState (fun s : S => (⟨p, s⟩ : Σ _ : I, S))).workTapePos =
          ((Mf p).runFrom c u).workTapePos := by
        funext j
        exact Cfg.mapState_workTapePos _ _ j
      rw [hpos]
      exact he u hle
    · have hu' : u = T + 1 := by omega
      subst u
      rw [h.2]
      have hpos : (c'.mapState fun _ => next).workTapePos = c'.workTapePos := by
        funext j
        exact Cfg.mapState_workTapePos _ _ j
      rw [hpos, ← hrun]
      exact he T le_rfl

/-- Moving every bit down one position and repeating the sign bit is arithmetic halving.

**Proof sketch.** Compare list cells. Below the last cell, `List.getElem_tail` reads the next
source bit. The last cell reads the appended `msb`. `BitVec.getLsbD_sshiftRight` gives exactly
these two cases, with an empty result at width zero. -/
private theorem wordHalf_bits {W : ℕ} (u : BitVec W) :
    List.zipWith (fun (_ b : Bool) => b) (bvBits u) ((bvBits u).tail ++ [u.msb]) =
      bvBits (u.sshiftRight 1) := by
  apply List.ext_getElem
  · simp only [List.length_zipWith, bvBits_length, List.length_append, List.length_tail,
      List.length_singleton]
    omega
  · intro i hi hi'
    have hiW : i < W := by simpa only [bvBits_length] using hi'
    simp only [List.getElem_zipWith]
    by_cases hn : i + 1 < W
    · rw [List.getElem_append_left (by simp only [List.length_tail, bvBits_length]; omega),
        List.getElem_tail]
      simp only [bvBits_def, List.getElem_ofFn]
      rw [BitVec.getLsbD_sshiftRight]
      simp [hiW, hn, Nat.add_comm]
    · rw [List.getElem_append_right (by simp only [List.length_tail, bvBits_length]; omega)]
      simp only [List.getElem_singleton, bvBits_def, List.getElem_ofFn]
      rw [BitVec.getLsbD_sshiftRight]
      simp [hiW, hn, Nat.add_comm]

/-- Two writes of equal-width words on one tape retain only the last word. -/
private theorem wordWrite_twice {k : ℕ} {S : Type} {x : List Bool} (d : Cfg k Bool S x)
    (j : Fin k) (u v : List Bool) (hlen : v.length = u.length) :
    wordWrite {d with workTapes := wordWrite d j u} j v = wordWrite d j v := by
  funext r z
  by_cases hr : r = j
  · subst r
    simpa only [wordWrite_apply, wordPatch_apply, true_and] using
      congrFun (wordPatch_twice (d.workTapes j) (d.workTapePos j) u v hlen) z
  · simp only [wordWrite_apply, hr, false_and, if_false]

/-- The rows of arithmetic halving: copy, sign fold, and either sign-filled shift. -/
private def wordHalfRows (i : Fin 5) : MultiTapeTM 5 Bool (ScanPhase Bool) :=
  if i = 0 then wordLockTM 0 0 2 (fun (_ : Bool) b _ => (false, b)) false
  else if i = 1 then scanTM 5 0 (scanFold (fun _ b => b)) scanKeep false
  else scanTM 5 2 scanKeep (scanShift id (fun (_ b : Bool) => b)) (decide (i = 3))

/-- Halving dispatches the sign flag to the corresponding fixed-sign scan, then one exit. -/
private def wordHalfRed (i : Fin 5) : ScanPhase Bool → Option (Σ _ : Fin 5, ScanPhase Bool)
  | .done b =>
    if i = 0 then if b then none else some ⟨1, .fwd false⟩
    else if i = 1 then some ⟨if b then 3 else 2, .fwd b⟩
    else if i = 2 ∨ i = 3 then some ⟨4, .done false⟩ else none
  | _ => none

/-- Arithmetic halving composed from the framed copy and the catalog scans in a phase host. -/
private def wordHalfTM : MultiTapeTM 5 Bool (Σ _ : Fin 5, ScanPhase Bool) :=
  phaseHostTM wordHalfRows ⟨0, .fwd false⟩ wordHalfRed

/-- The arithmetic-shift program preserves every frame and returns all heads.

**Proof sketch.** Copy the source with `wordLock_run`, compute its sign with `wordFold_run`,
and dispatch to `scanResult_shiftLeft` with that fixed sign. `wordHalf_bits` identifies the
rewritten list. `wordPhase_segment` places the three rows in `phaseHostTM`; `Segment.trans`
composes their verified runs. Their heads return at each seam, and `wordWrite_twice` removes
the intermediate copy. The total time, including three dispatches, is at most `9 * (W + 1)`;
the general displacement-from-time bound supplies the same radius. -/
private theorem wordHalf_run {W : ℕ} {x : List Bool} (u : BitVec W) (w : List Bool)
    (d : Cfg 5 Bool (Σ _ : Fin 5, ScanPhase Bool) x)
    (hd : d.state = some ⟨0, .fwd false⟩) (hu : WordAt d 0 (bvBits u))
    (hw : WordAt d 2 w) (hlen : w.length = W) :
    ReachesWithin wordHalfTM d {some ⟨4, .done false⟩} (9 * (W + 1)) (9 * (W + 1))
      {d with state := some ⟨4, .done false⟩, workTapes := wordWrite d 2 (bvBits (u.sshiftRight 1))} := by
  let exit : Σ _ : Fin 5, ScanPhase Bool := ⟨4, .done false⟩
  let d₀ := d.mapState fun _ => (ScanPhase.fwd false)
  have hcopy := wordLock_run 0 0 2 (fun (_ : Bool) bit _ => (false, bit)) false
    (bvBits u) (bvBits u) (bvBits u) (fun _ => false) rfl rfl rfl (fun _ _ => rfl)
    d₀ (by simp only [d₀, Cfg.mapState_state, hd, Option.map_some])
    ((wordAt_mapState d _ 0 _).mpr hu) ((wordAt_mapState d _ 0 _).mpr hu)
  simp only [bvBits_length] at hcopy
  obtain ⟨t₀, ht₀, cut₀, _, run₀⟩ := (reachesWithin_iff _ _ _ _ _ _).mp hcopy
  let e₀ : Cfg 5 Bool (ScanPhase Bool) x := {d₀ with state := some (.done false), workTapes := wordWrite d₀ 2 (bvBits u)}
  let d₁ := { d with
    state := some (⟨1, .fwd false⟩ : Σ _ : Fin 5, ScanPhase Bool)
    workTapes := wordWrite d 2 (bvBits u)}
  have guard₀ : ∀ t < t₀, ∀ q,
      ((wordHalfRows 0).runFrom d₀ t).state = some q → wordHalfRed 0 q = none := by
    intro t ht q hq
    cases q with
    | fwd a => rfl
    | bwd a => rfl
    | done a =>
      cases a with
      | true => rfl
      | false =>
        apply False.elim
        apply cut₀ t ht
        simpa only [wordHalfRows, if_pos rfl, Set.mem_singleton_iff] using hq
  have seg₀ : Segment wordHalfTM {some exit} (fun _ => True) d d₁ (t₀ + 1) := by
    have hs := wordPhase_segment wordHalfRows ⟨0, .fwd false⟩ wordHalfRed 0 d₀ e₀ t₀
      (.done false) ⟨1, .fwd false⟩ exit (fun _ => True)
      (by simpa only [wordHalfRows, if_pos rfl] using run₀) rfl rfl guard₀
      (by decide) (fun _ _ => True.intro)
    have hstart : {d with state := some (⟨0, .fwd false⟩ : Σ _ : Fin 5, ScanPhase Bool)} = d := by
      rw [← hd]
    simpa only [wordHalfTM, d₀, e₀, d₁, Cfg.mapState_eq, hd, Option.map_some,
      wordWrite, hstart] using hs
  have hu₁ : WordAt d₁ 0 (bvBits u) := by
    simpa [d₁, wordAt_iff, wordWrite_apply] using hu
  have hw₁ : WordAt d₁ 2 (bvBits u) :=
    wordAt_write d 2 w (bvBits u) (by simp only [bvBits_length, hlen]) hw
  let c₁ := d₁.mapState fun _ => (ScanPhase.fwd false)
  let b := u.msb
  let p : Fin 5 := if b then 3 else 2
  have hsign := wordFold_run (fun _ bit => bit) false (bvBits u) c₁
    (by simp only [c₁, d₁, Cfg.mapState_state, Option.map_some])
    ((wordAt_mapState d₁ _ 0 _).mpr hu₁)
  simp only [bvBits_length, bvBits_last_fold] at hsign
  obtain ⟨t₁, ht₁, cut₁, _, run₁⟩ := (reachesWithin_iff _ _ _ _ _ _).mp hsign
  let e₁ : Cfg 5 Bool (ScanPhase Bool) x := {c₁ with state := some (.done b)}
  let d₂ := {d₁ with state := some (⟨p, .fwd b⟩ : Σ _ : Fin 5, ScanPhase Bool)}
  have guard₁ : ∀ t < t₁, ∀ q,
      ((wordHalfRows 1).runFrom c₁ t).state = some q → wordHalfRed 1 q = none := by
    intro t ht q hq
    cases q with
    | fwd a => rfl
    | bwd a => rfl
    | done a =>
      apply False.elim
      apply cut₁ t ht
      have hq' : ((scanTM 5 0 (scanFold (fun _ bit => bit)) scanKeep false).runFrom c₁ t).state =
          some (.done a) := by simpa [wordHalfRows] using hq
      rw [hq']
      cases a <;> simp
  have seg₁ : Segment wordHalfTM {some exit} (fun _ => True) d₁ d₂ (t₁ + 1) := by
    have hs := wordPhase_segment wordHalfRows ⟨0, .fwd false⟩ wordHalfRed 1 c₁ e₁ t₁
      (.done b) ⟨p, .fwd b⟩ exit (fun _ => True)
      (by simpa [wordHalfRows] using run₁) rfl (by simp [wordHalfRed, p]) guard₁
      (by decide) (fun _ _ => True.intro)
    simpa only [wordHalfTM, c₁, e₁, d₂, d₁, Cfg.mapState_eq, Option.map_some] using hs
  let c₂ := d₂.mapState fun _ => (ScanPhase.fwd b)
  have hw₂ : WordAt c₂ 2 (bvBits u) := by
    rw [wordAt_mapState]
    exact hw₁
  have hm₂ : wordHalfRows p =
      scanTM 5 2 scanKeep (scanShift id (fun (_ bit : Bool) => bit)) b := by
    cases hb : b <;> simp [wordHalfRows, p, hb]
  have hscan := scanTM_run_ofCfg 2 scanKeep (scanShift id (fun (_ bit : Bool) => bit)) b
    (bvBits u) c₂ (by simp only [c₂, d₂, Cfg.mapState_state, Option.map_some])
    ((wordAt_iff c₂ 2 _).mp hw₂)
  let flag := (bvBits u).head?.getD b
  let e₂ : Cfg 5 Bool (ScanPhase Bool) x := { c₂ with
    state := some (.done flag)
    workTapes := wordWrite c₂ 2 (bvBits (u.sshiftRight 1)) }
  have run₂ : (wordHalfRows p).runFrom c₂ (2 * W + 2) = e₂ := by
    rw [hm₂]
    have hs := hscan.1
    simp only [scanResult_shiftLeft, List.map_id, b, wordHalf_bits, bvBits_length] at hs
    apply hs.trans
    apply Cfg.ext
    · rfl
    · rfl
    · funext j z
      simp only [e₂, wordWrite_apply, bvBits_length]
    · rfl
    · rfl
  have guard₂ : ∀ t < 2 * W + 2, ∀ q,
      ((wordHalfRows p).runFrom c₂ t).state = some q → wordHalfRed p q = none := by
    intro t ht q hq
    cases q with
    | fwd a => rfl
    | bwd a => rfl
    | done a =>
      apply False.elim
      have ht' : t < 2 * (bvBits u).length + 2 := by simpa only [bvBits_length] using ht
      apply hscan.2.1 t ht' a
      simpa only [hm₂] using hq
  have seg₂ : Segment wordHalfTM {some exit} (fun _ => True) d₂
      {d with state := some exit, workTapes := wordWrite d 2 (bvBits (u.sshiftRight 1))}
      (2 * W + 2 + 1) := by
    have hs := wordPhase_segment wordHalfRows ⟨0, .fwd false⟩ wordHalfRed p c₂ e₂
      (2 * W + 2) (.done flag) exit exit (fun _ => True) run₂ rfl
      (by cases hb : b <;> simp [wordHalfRed, p, hb, exit]) guard₂
      (by cases hb : b <;> simp [p, hb, exit]) (fun _ _ => True.intro)
    have hwrites : wordWrite d₂ 2 (bvBits (u.sshiftRight 1)) =
        wordWrite d 2 (bvBits (u.sshiftRight 1)) :=
      wordWrite_twice d 2 (bvBits u) (bvBits (u.sshiftRight 1)) (by simp only [bvBits_length])
    have hs' : Segment wordHalfTM {some exit} (fun _ => True) d₂
        {d₂ with state := some exit, workTapes := wordWrite d₂ 2 (bvBits (u.sshiftRight 1))}
        (2 * W + 2 + 1) := by
      simpa only [wordHalfTM, c₂, e₂, d₂, Cfg.mapState_eq, Option.map_some] using hs
    rw [hwrites] at hs'
    exact hs'
  have hs := (segment_iff _ _ _ _ _ _).mp ((seg₀.trans seg₁).trans seg₂)
  apply (reachesWithin_iff _ _ _ _ _ _).mpr
  refine ⟨(t₀ + 1 + (t₁ + 1)) + (2 * W + 2 + 1), by omega, hs.2.1, ?_, hs.1⟩
  intro t ht j
  have hp := wordHalfTM.workTapePos_runFrom_mem_Icc d t j
  rw [Finset.mem_Icc] at hp
  rw [abs_le]
  constructor <;> omega

/-- **The arithmetic shift right by one place.** From the entry, with `u` on tape `0`, a word of
`W` cells on tape `2` and blank scratch tapes, the row writes `u.sshiftRight 1` (that is,
`⌊u / 2⌋` read signed) on tape `2`, within `C·(W + 1)` steps and radius `C·(W + 1)`, tape `1`
untouched. [AB09, Exercise 1.9]

**Proof sketch.** `wordHalf_run` composes a framed copy, the catalog's sign fold, and its
left shift with the computed sign as fill. `wordHalf_bits` reads
`BitVec.getLsbD_sshiftRight` to identify the shifted word. Each catalog row returns its heads;
three stationary phase dispatches give time and radius at most `9 * (W + 1)`, also at width zero. -/
theorem exists_wordHalfTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} {W : ℕ} (u : BitVec W) (w : List Bool) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → WordAt d 2 w → w.length = W →
        ScratchBlank d →
        ReachesWithin R d {some exit} (C * (W + 1)) (C * (W + 1))
          { d with state := some exit, workTapes := wordWrite d 2 (bvBits (u.sshiftRight 1)) } := by
  refine ⟨(Σ _ : Fin 5, ScanPhase Bool), inferInstance, inferInstance,
    wordHalfTM, ⟨0, .fwd false⟩, ⟨4, .done false⟩, 9, ?_⟩
  intro x W u w d hd hu hw hlen _
  exact wordHalf_run u w d hd hu hw hlen

/-- **Sign extension by `a` places.** From the entry, with `u` on tape `0`, a word of `W + a`
cells on tape `2` and blank scratch tapes, the row writes `u.signExtend (W + a)` on tape `2`,
within `C·(W + 1)` steps and radius `C·(W + 1)`, tape `1` untouched. The constant `C` depends on
`a`. [AB09, Exercise 1.9]

**Proof sketch.** Copy `u` into the first `W` cells, remembering its last bit read (`false` if
`W = 0`, where the extension is `0`); then write that bit `a` times, counted in the state; then
return the heads. -/
theorem exists_wordSignExtendTM (a : ℕ) :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} {W : ℕ} (u : BitVec W) (w : List Bool) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → WordAt d 2 w → w.length = W + a →
        ScratchBlank d →
        ReachesWithin R d {some exit} (C * (W + 1)) (C * (W + 1))
          { d with state := some exit,
                   workTapes := wordWrite d 2 (bvBits (u.signExtend (W + a))) } := by
  sorry

/-- **The word of an integer constant.** For an integer `c` and `a ≥ 0`: from the entry, with a
word of `W + a` cells on tape `2` and blank scratch tapes, the row writes `BitVec.ofInt (W + a) c`
over it, within `C·(W + 1)` steps and radius `C·(W + 1)`, tapes `0` and `1` untouched. The
constant `C` depends on `c` and `a`. With `a = 0` and `c = 1` this writes the word `1`.
[AB09, Exercise 1.9]

**Proof sketch.** Let `b` be the bit length of `|c|` plus one. Bit `i` of `BitVec.ofInt n c` is
`c.testBit i` (two's complement), which for `i ≥ b` is the sign of `c`. Sweep the destination's
old word, writing `c.testBit i` from a table in the state for `i < b` and the sign beyond, and stop
at its right delimiter; then return the head. -/
theorem exists_wordIntTM (c : ℤ) (a : ℕ) :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S) (entry exit : S)
      (C : ℕ),
      ∀ {x : List Bool} {W : ℕ} (w : List Bool) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 2 w → w.length = W + a → ScratchBlank d →
        ReachesWithin R d {some exit} (C * (W + 1)) (C * (W + 1))
          { d with state := some exit,
                   workTapes := wordWrite d 2 (bvBits (BitVec.ofInt (W + a) c)) } := by
  sorry

/-! ## Tests -/

/-- **The sign test.** From the entry, with `u` on tape `0` and blank scratch tapes, the row stops
at `yes` if `u` is negative read signed (`u.toInt < 0`) and at `no` otherwise, within `C·(W + 1)`
steps and radius `C·(W + 1)`, writing nothing. [AB09, Exercise 1.9]

**Proof sketch.** `wordFold_run` instantiates `scanTM_run_ofCfg` and `scanResult_fold` with
the overwrite fold, preserving the word and returning the head. `bvBits_last_fold` identifies
the verdict with `u.msb`, and `BitVec.msb_eq_toInt` identifies it with the signed comparison.
The initial false flag covers width zero; the catalog's bounds give the constant `2`. -/
theorem exists_wordSignTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S)
      (entry yes no : S) (C : ℕ), yes ≠ no ∧
      ∀ {x : List Bool} {W : ℕ} (u : BitVec W) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → ScratchBlank d →
        ReachesWithin R d {some yes, some no} (C * (W + 1)) (C * (W + 1))
          { d with state := some (if u.toInt < 0 then yes else no) } := by
  refine ⟨ScanPhase Bool, inferInstance, inferInstance,
    scanTM 5 0 (scanFold (fun _ b => b)) scanKeep false,
    .fwd false, .done true, .done false, 2, (by intro h; cases h), ?_⟩
  intro x W u d hd hw _
  have h := wordFold_run (fun _ b => b) false (bvBits u) d hd hw
  by_cases hneg : u.toInt < 0 <;>
    simpa only [bvBits_length, bvBits_last_fold, BitVec.msb_eq_toInt, hneg,
      decide_true, decide_false, if_true, if_false] using h

/-- **The zero test.** From the entry, with `u` on tape `0` and blank scratch tapes, the row stops
at `yes` if `u ≠ 0` and at `no` otherwise, within `C·(W + 1)` steps and radius `C·(W + 1)`,
writing nothing. [AB09, Exercise 1.9]

**Proof sketch.** `wordFold_run` applies the read-only `scanTM` fold to Boolean disjunction.
`wordAny_fold` identifies the flag with membership of true, and `bvBits_no_true`, using
`bvBits_injective`, identifies its false case with the zero word. The empty fold is false,
and the same catalog bounds give the constant `2`. -/
theorem exists_wordNonzeroTM :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM 5 Bool S)
      (entry yes no : S) (C : ℕ), yes ≠ no ∧
      ∀ {x : List Bool} {W : ℕ} (u : BitVec W) (d : Cfg 5 Bool S x),
        d.state = some entry → WordAt d 0 (bvBits u) → ScratchBlank d →
        ReachesWithin R d {some yes, some no} (C * (W + 1)) (C * (W + 1))
          { d with state := some (if u ≠ 0 then yes else no) } := by
  refine ⟨ScanPhase Bool, inferInstance, inferInstance,
    scanTM 5 0 (scanFold (fun a b => a || b)) scanKeep false,
    .fwd false, .done true, .done false, 2, (by intro h; cases h), ?_⟩
  intro x W u d hd hw _
  have hmem : true ∈ bvBits u ↔ u ≠ 0 := by
    simpa only [not_not] using not_congr (bvBits_no_true u)
  have h := wordFold_run (fun a b => a || b) false (bvBits u) d hd hw
  simp only [bvBits_length, wordAny_fold, Bool.false_or, hmem] at h
  by_cases hz : u = (0#W) <;> simpa [hz] using h

end Turing
