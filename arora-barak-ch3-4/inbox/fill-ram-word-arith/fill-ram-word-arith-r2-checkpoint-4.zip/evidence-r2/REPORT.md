# fill-ram-word-arith round 2, checkpoint 1

Base: `7342f98b58704d6c25faf668ed1a64ea0b27c4af` (`ram/readers-2`, fetched read-only). Local branch:
`codex/fill-ram-word-arith-r2`. Instructions read with `git show` at
`e40383d88d79e23026c95e20608ee8827d45e59b`. The round-1 zip and every internal checksum were
verified before its patch was applied to the new base.

Proved targets: `bvBits_injective`, `exists_wordAddTM`, `exists_wordSubTM`,
`exists_wordSignTM`, `exists_wordNonzeroTM`. The remaining four targets—multiplication,
arithmetic shift, sign extension, and integer constants—remain `sorry` and are ongoing work.
This checkpoint does not close the round-2 objective.

The new `wordLockTM` is a generic finite-state transducer over three selected tape indices.
The catalog lacks a two-source carry row. `wordLock_run` proves its run once using
`catalog_trace_run` and the newly published `catalogTrace_eq`. It requires no blank scratch,
preserves arbitrary frames, and supports aliased source/destination indices. `wordRipple_run`
instantiates it with core `BitVec.carry_zero`, `BitVec.carry_succ`, and
`BitVec.getLsbD_add_add_bool`. Both exported rows use constant 2; subtraction complements the
second operand and starts the carry at true, using `BitVec.neg_eq_not_add`.

New private declarations and roles:

- `wordLockAction`, `wordLockAction_apply`: a destination write and three-head move, read through
  the published `Action.apply_*` equations and `Cfg.workTapeSymbols_eq`.
- `wordLockTM`: finite-state two-source leaf transducer; no matching catalog row exists.
- `wordLockCfg`: a written prefix with a common head offset and arbitrary frame.
- `wordLockCfg_read_fwd`: current inputs have not yet been overwritten, even with aliasing.
- `wordLockCfg_read_full`: the patched guide remains delimited, using `wordPatch_frame`.
- `wordLockCfg_write`: extends the prefix with `catalog_write_take`.
- `wordLockCfg_move`: all non-writing phase steps, factored once.
- `wordLock_run`: the complete trace, first-exit cut, exact endpoint, and linear bounds.
- `wordRippleStep`, `wordRipple_run`: one shared carry/complement instance for add/sub.

The four round-1 private helpers remain: `wordFold_run`, `bvBits_last_fold`,
`wordAny_fold`, and `bvBits_no_true`. Their roles and searches are unchanged from the round-1
report. Reuse searches covered Catalog's copy/scan/trace/patch APIs and core BitVec's carry,
addition, negation, complement, and width-extension facts. No copied machine table or duplicate
add/sub proof family is introduced.

Other-file definitions are consumed through published interfaces:
`MultiTapeTM.step_of_some`, `catalog_trace_run`, `catalogTrace_eq`,
`MultiTapeTM.workTapePos_runFrom_mem_Icc`, `Action.apply_state/inputPos/workTapes/workTapePos/output`,
`Cfg.workTapeSymbols_eq`, `wordPatch_apply`, `wordPatch_frame`, `catalog_write_take`,
`scanTM_run_ofCfg`, `scanResult_fold`, `wordPatch_self`, and `reachesWithin_iff`.
No imports or home-file readers were added at this checkpoint. No public declarations or
new admissions were added. All 18 existing statements are byte-identical.

Checks: 20 upstream modules bootstrapped from the new base into the fresh
`.lake/fill-ram-word-arith-r2-oleans`; all exit 0. The owned file, axiom probe, strict seal,
and dependency walk each exit 0 (`checkpoint-1-*.log`). The strict seal makes 389 imported
TCSlib ordinary definitions irreducible and removes their simp/unfold registrations. Only the
four still-open targets warn about sorry. All five proved targets have empty admission lists;
axioms are restricted to propext, Classical.choice, and Quot.sound. Downstream replay is deferred
until the next checkpoint or final delivery; no downstream result from round 1 is claimed for
this base.

Environment: macOS native preflight (12 CPUs, 18 GiB RAM, 62% free memory, 115712288 KiB free
on APFS). Existing user Lean 4.25.0 and the permitted package symlink are used. All present
package URLs/revisions match the manifest; four documentation packages are absent. No cache
fetch or `lake build` ran. Checks run serially under `nice -n 10`, checking the machine-wide
Lean count before every invocation and waiting at three occupied slots. Any waits are in
`process-slots.log`. The 30 unrelated blueprint edits carried from round 1 remain untouched
and are excluded. Development failures and corrected checks are retained in the logs.

Owned-file diff against the new base:

```
.../Complexity/TuringMachine/Build/WordArith.lean  | 456 ++++++++++++++++++++-
 1 file changed, 438 insertions(+), 18 deletions(-)
```
