import TCSlib.Complexity.TuringMachine.Build.WordArith

set_option maxHeartbeats 0

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for root in [`Turing.bvBits_injective, `Turing.exists_wordAddTM, `Turing.exists_wordSubTM, `Turing.exists_wordHalfTM, `Turing.exists_wordSignExtendTM, `Turing.exists_wordIntTM, `Turing.exists_wordSignTM, `Turing.exists_wordNonzeroTM] do
    let mut todo := [root]
    let mut seen : Std.HashSet Name := {}
    let mut admitted : List Name := []
    while !todo.isEmpty do
      let n := todo.head!
      todo := todo.tail!
      if seen.contains n then continue
      seen := seen.insert n
      let some ci := env.find? n | continue
      let refs := ci.type.getUsedConstants.toList ++
        ((ci.value?.map Expr.getUsedConstants).getD #[]).toList
      if ((ci.value?.map Expr.getUsedConstants).getD #[]).contains `sorryAx then
        admitted := n :: admitted
      todo := refs ++ todo
    logInfo m!"DEPENDENCY WALK {root}: direct sorryAx users = {admitted.reverse}; visited {seen.size} constants"
    unless admitted.isEmpty do
      throwError "proved target reaches an admission"
