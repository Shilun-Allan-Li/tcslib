# fill-ram-word-arith round 2, checkpoint 2

Base: `7342f98b58704d6c25faf668ed1a64ea0b27c4af`, fetched read-only from ram/readers-2.
Instructions were read at `e40383d88d79e23026c95e20608ee8827d45e59b` as requested.
Source branch: `codex/fill-ram-word-arith-r2`; never rebased or pushed.

**6/9 targets proved:** bvBits_injective, exists_wordAddTM, exists_wordSubTM,
exists_wordHalfTM, exists_wordSignTM, exists_wordNonzeroTM. Sign extension, integer constants,
and multiplication remain `sorry` and are ongoing work, in that order. This checkpoint does
not close the round-2 objective.

Round-1 archive/internal checksums were verified before applying its patch to the new base.
The arbitrary-frame and alias-safe lockstep transducer is proved once with catalog_trace_run
and catalogTrace_eq; the ripple instance uses core carry_succ/getLsbD_add_add_bool. Addition
and subtraction use C=2. The new half program uses the public phaseHostTM to compose a copy,
a sign fold, and the sign-filled scanResult_shiftLeft. wordHalf_bits identifies the result with
BitVec.sshiftRight 1, and Segment.trans composes the verified segments. All frames and heads
are preserved/restored, including W=0, with C=9. No admitted dependency is used.

## Added pure reader and import

- `Turing.Cfg.mapState_eq`, beside Cfg.mapState in StateRenaming.lean, is exactly the defining
  record equation, proved by rfl with a mathematical docstring. It is the only new public
  declaration. The updated missing-readers rule authorizes it. Existing projection readers
  were searched; there was no full record equation. The reader avoids private copies of
  the library's configuration-transport proofs.
- Added import Build.Seam for phaseHostTM and its run theorems. It also imports the existing
  CfgFacts transport API. All other existing statements remain byte-identical; the home file
  is unchanged apart from its six-line reader addition.

## Private declaration inventory

- `wordLockAction`: Move the three selected heads together, optionally writing one destination bit.
- `wordLockAction_apply`: The lockstep action changes only its destination cell and the selected heads.
- `wordLockTM`: A two-source finite-state sweep, followed by a return guided by the first source. The catalog's one-tape scan cannot read both source bits with a carry. The selected tapes may alias: the forward pass reads each cell before writing it, and every written cell stays nonblank. The carry is discarded at the right delimiter, so every run has the same live exit.
- `wordLockCfg`: A lockstep configuration with a written destination prefix and a common head offset.
- `wordLockCfg_read_fwd`: At the forward boundary no source cell has yet been overwritten, even with aliases.
- `wordLockCfg_read_full`: A full destination patch keeps its delimiters; an aliased source reads the output word.
- `wordLockCfg_write`: One forward action extends the output prefix by exactly its next bit.
- `wordLockCfg_move`: A non-writing lockstep action translates only the common head offset.
- `wordLock_run`: The framed lockstep sweep computes any transducer whose successive states and bits satisfy the supplied cell equations. No scratch-blankness hypothesis is needed.
- `wordRippleStep`: One ripple-carry cell, optionally complementing the second operand for subtraction.
- `wordRipple_run`: The framed ripple row adds the optionally complemented second word and an initial carry.
- `wordFold_run`: A Boolean fold scans one delimited word, returns the head, and preserves every cell.
- `bvBits_last_fold`: The overwrite fold of a word's bits is its most significant bit, with false for width zero.
- `wordAny_fold`: The Boolean disjunction fold records exactly whether a true cell has occurred.
- `bvBits_no_true`: A word has no true bit exactly when it is zero.
- `wordAt_mapState`: State renaming does not affect a word held at a work head.
- `wordAt_write`: A same-width word write keeps the destination delimited.
- `wordPhase_segment`: A public phase-host run is a segment avoiding any designated exit in another phase.
- `wordHalf_bits`: Moving every bit down one position and repeating the sign bit is arithmetic halving.
- `wordWrite_twice`: Two writes of equal-width words on one tape retain only the last word.
- `wordHalfRows`: The rows of arithmetic halving: copy, sign fold, and either sign-filled shift.
- `wordHalfRed`: Halving dispatches the sign flag to the corresponding fixed-sign scan, then one exit.
- `wordHalfTM`: Arithmetic halving composed from the framed copy and the catalog scans in a phase host.
- `wordHalf_run`: The arithmetic-shift program preserves every frame and returns all heads.

## Reuse and definition boundaries

Reuse searches inspected the catalog's copy/scan/walk/patch/trace rows, CfgFacts transport
facts, Segment composition, and core BitVec's carry, subtraction, complement, width and
arithmetic-shift equations. The lockstep action/run and the phase placement are factored once.
No catalog table or generic composition proof is copied. The private phase lemma is an adapter
for the existing public host, not a new host.

Other-file definitions are read through published equations and theorems: Action.apply_*;
Cfg.workTapeSymbols_eq; Cfg.mapState_eq and mapState_*; Cfg.mapState_sigma_state_ne;
MultiTapeTM.step_of_some and workTapePos_runFrom_mem_Icc; catalog_trace_run/catalogTrace_eq;
wordPatch_apply/frame/twice/self and catalog_write_take; scanTM_run_ofCfg,
scanResult_fold/shiftLeft; phaseHostTM_run; segment_iff/Segment.trans; reachesWithin_iff.
Only same-file definitions are explicitly unfolded. Core/Mathlib definitions are not supplied
as simp/rw/unfold arguments. New public surface is restricted to the authorized rfl reader;
no new admissions, simp attributes, or axioms were added.

## Verification

- 22 upstream modules (including new composition imports) rebuilt in the round-2 scratch tree,
  all exit 0; no round-1 TCSlib oleans reused.
- Owned file (`half-target-02.log`): exit 0, exactly three remaining-admission warnings.
- Axioms (`checkpoint-2-axioms.log`): exit 0. All six targets use only propext,
  Classical.choice and Quot.sound; Cfg.mapState_eq uses no axioms.
- Strict seal (`checkpoint-2-seal.log`): exit 0. All 393 imported ordinary TCSlib definitions
  made irreducible; three simp/unfold registrations removed. All six proofs re-elaborate.
- Dependency walks (`checkpoint-2-dependencies.log`): exit 0. Every proved target's reachable
  list of direct sorryAx users is empty.
- Freeze (`checkpoint-2-freeze.log`): all 18 existing statements byte-identical; the reader's
  home file otherwise byte-identical.
- Downstream facade replay remains pending until the final delivery; no old-base replay is
  claimed as evidence for this checkpoint.

The macOS preflight, exact-pins package symlink, manifest PASS, and serial guarded Lean runner
are recorded under evidence/logs. Existing Lean 4.25.0 is used. No lake build or cache fetch.
The guard checks all machine-wide Lean processes before each invocation and waits at 3;
all waits and per-check start/end/RSS/exit data are retained. The unrelated 30 blueprint edits
are untouched and excluded. An unrelated untracked startup zip blocked the shared exchange
pull at checkpoint 1; an isolated delivery checkout was used instead. Checkpoint 1 was pushed
as 963bbea12. No force push or campaign-branch push occurred.

Owned file length: 946 lines. Diff against the new base (owned file plus authorized reader):

```
.../Complexity/TuringMachine/Build/WordArith.lean  | 726 ++++++++++++++++++++-
 TCSlib/Complexity/TuringMachine/StateRenaming.lean |   6 +
 2 files changed, 709 insertions(+), 23 deletions(-)
```
