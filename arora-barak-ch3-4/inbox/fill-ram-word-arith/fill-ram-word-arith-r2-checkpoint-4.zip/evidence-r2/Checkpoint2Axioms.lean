import TCSlib.Complexity.TuringMachine.Build.WordArith
#print axioms Turing.bvBits_injective
#print axioms Turing.exists_wordAddTM
#print axioms Turing.exists_wordSubTM
#print axioms Turing.exists_wordHalfTM
#print axioms Turing.exists_wordSignTM
#print axioms Turing.exists_wordNonzeroTM
#print axioms Turing.Cfg.mapState_eq
