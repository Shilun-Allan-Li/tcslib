from pathlib import Path
import subprocess, tempfile, hashlib, os
root=Path(__file__).resolve().parent.parent
os.chdir(root)
base='cb44316a22c258628bf571da8c84b72c347ee493'
owned='TCSlib/Complexity/TuringMachine/Build/WordArith.lean'
lines=[]
with tempfile.TemporaryDirectory(prefix='wordarith-patch-',dir='.lake') as scratch:
 p=Path(scratch)/owned;p.parent.mkdir(parents=True)
 p.write_bytes(subprocess.check_output(['git','show',base+':'+owned]))
 for check in [True,False]:
  args=['git','apply']+(['--check'] if check else [])+['--directory='+str(Path(scratch).relative_to(root)),'fill-ram-word-arith.patch']
  cp=subprocess.run(args,capture_output=True,text=True)
  lines+=['$ '+' '.join(args),cp.stdout,cp.stderr,f'EXIT {cp.returncode}']
  if cp.returncode:
   Path('evidence/logs/patch-replay-attempt.log').write_text('\n'.join(lines)+'\n')
   print('\n'.join(lines),flush=True)
   raise SystemExit(cp.returncode)
 assert p.read_bytes()==Path(owned).read_bytes()
 lines+=['PATCH REPLAY BYTE-IDENTICAL TO DELIVERED SOURCE', 'SOURCE SHA256 '+hashlib.sha256(p.read_bytes()).hexdigest()]
Path('evidence/logs/patch-replay.log').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
