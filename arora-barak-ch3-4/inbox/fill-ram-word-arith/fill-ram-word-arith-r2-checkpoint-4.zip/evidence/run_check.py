from pathlib import Path
import subprocess,os,sys,time,datetime
root=Path(__file__).resolve().parent.parent
os.chdir(root)
logs=root/'evidence/logs'
os.environ['PATH']='/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:'+os.environ['PATH']
os.environ['TCSLIB_OLEANS']=str(root/'.lake/fill-ram-word-arith-oleans')
def check(module,label):
 with (logs/'process-slots.log').open('a') as sl:
  while True:
   ps=subprocess.check_output(['ps','-ww','-axo','pid=,comm='],text=True)
   active=[line.strip() for line in ps.splitlines() if line.split() and Path(line.split()[-1]).name=='lean']
   sl.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+f' {label}: {len(active)} other Lean processes '+repr(active)+'\n');sl.flush()
   if len(active)<3:break
   time.sleep(5)
 log=logs/(label+'.log')
 with log.open('w') as f:
  f.write('START '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n');f.flush()
  p=subprocess.run(['/usr/bin/time','-l','bash','scripts/lean_check_tree.sh',module],stdout=f,stderr=subprocess.STDOUT)
  f.write('END '+datetime.datetime.now(datetime.timezone.utc).isoformat()+f' EXIT {p.returncode}\n')
 print(f'{label}: EXIT {p.returncode}',flush=True)
 if p.returncode: print(log.read_text(),flush=True)
 return p.returncode
if sys.argv[1] in ('order','order-final'):
 for n,m in enumerate(Path(sys.argv[2]).read_text().splitlines()):
  if check(m,('bootstrap-' if sys.argv[1]=='order' else 'replay-')+str(n).zfill(3)+'-'+Path(m).name):sys.exit(1)
else:sys.exit(check(sys.argv[1],sys.argv[2]))
