from pathlib import Path
import re,json,datetime,hashlib,subprocess
root=Path(__file__).resolve().parent.parent
logs=root/'evidence/logs';own='TCSlib/Complexity/TuringMachine/Build/WordArith.lean'
up=(logs/'upstream-order.txt').read_text().splitlines()
replay=(logs/'replay-order.txt').read_text().splitlines()
required=[(f'bootstrap-{i:03}-{Path(m).name}',m) for i,m in enumerate(up)]
required += [(f'replay-{i:03}-{Path(m).name}',m) for i,m in enumerate(replay)]
required += [('wordarith-final-02',own[:-5]),('cache-probe','evidence/CacheProbe'),('axioms-final','evidence/Axioms'),('dependency-walk','evidence/Dependencies'),('sealed-wordarith','evidence/SealedWordArith'),('sealed-wordarith-strict','evidence/SealedWordArithStrict')]
for label,module in required:
 data=(logs/(label+'.log')).read_text()
 assert re.search(r'END .* EXIT 0\n',data),label+' did not pass'
 assert not re.search(r'(?:^|\n).*error:',data),label+' error diagnostic'
 assert (root/'.lake/fill-ram-word-arith-oleans'/(module+'.olean')).stat().st_size>0,module
source=(root/own).read_text()
starts=[(source[:m.start()].count('\n')+1,m.group(1)) for m in re.finditer(r'(?m)^theorem (\w+)',source)]
warning_lines=[int(x) for x in re.findall(r'WordArith\.lean:(\d+):\d+: warning: declaration uses \'sorry\'',(logs/'wordarith-final-02.log').read_text())]
warning_names=[max((i,n) for i,n in starts if i<=line)[1] for line in warning_lines]
open_names=['exists_wordAddTM','exists_wordSubTM','exists_wordMulTM','exists_wordHalfTM','exists_wordSignExtendTM','exists_wordIntTM']
assert sorted(warning_names)==sorted(open_names),warning_names
assert 'sorryAx' not in (logs/'axioms-final.log').read_text()
walk=(logs/'dependency-walk.log').read_text();assert walk.count('direct sorryAx users = []')==3
assert 'PASS 18 existing declaration statements' in (logs/'statement-freeze.log').read_text()
assert 'PATCH REPLAY BYTE-IDENTICAL TO DELIVERED SOURCE' in (logs/'patch-replay.log').read_text()
polls={}
for line in (logs/'process-slots.log').read_text().splitlines():
 m=re.match(r'^(\S+) (.+): (\d+) other Lean processes',line)
 if m:
  t,label,count=m.groups();polls.setdefault(label,[]).append((datetime.datetime.fromisoformat(t),int(count)))
waits=[{'check':label,'seconds':round((points[-1][0]-points[0][0]).total_seconds(),3),'polls_at_limit':sum(c>=3 for _,c in points)} for label,points in polls.items() if any(c>=3 for _,c in points)]
peaks=[]
for p in logs.glob('*.log'):
 for n in re.findall(r'(\d+)\s+maximum resident set size',p.read_text()):peaks.append((int(n),p.name))
peak=max(peaks)
summary={'base':'cb44316a22c258628bf571da8c84b72c347ee493','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream_passed':len(up),'replay_passed':len(replay),'total_modules_passed':len(up)+1+len(replay),'proved':['bvBits_injective','exists_wordSignTM','exists_wordNonzeroTM'],'still_admitted':open_names,'proved_targets_admitted_dependencies':[],'waits':waits,'total_wait_seconds':round(sum(x['seconds'] for x in waits),3),'peak_rss_bytes':peak[0],'peak_rss_log':peak[1],'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'all_required_checks_exit':0}
(logs/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
p=root/'REPORT.md';s=p.read_text().replace('# fill-ram-word-arith checkpoint 1','# fill-ram-word-arith final delivery').replace('## Verification at checkpoint','## Final verification')
s=s.replace('''- Downstream replay: RUNNING at this checkpoint. The full list has 129 modules: the owned
  file, 20 already-built upstream modules, and 108 remaining prerequisites/downstream modules.
  Its nine downstream consumers include KeyTable, InputBit, all three Sim modules,
  Simulation, Classes and both facades.''','''- Full replay: **129/129 modules passed, exit 0**: the owned file, 20 upstream modules,
  and 108 remaining prerequisites/downstream modules. All nine downstream consumers passed:
  KeyTable, InputBit, Sim/Encoding, Sim/Startup, Sim/Phases, Simulation, Classes,
  RAMSimulation and TuringMachine. Per-module logs and all three order lists are included.
- Strict seal: `sealed-wordarith-strict.log`, exit 0; the same 389 definitions sealed,
  with their simp/unfold registrations removed as specified by the standing rule.
- Patch replay: `git apply --check` and application to a scratch base copy both exit 0;
  the result is byte-identical to the delivered source. The checker initially used an absolute
  scratch prefix, which Git rejected (exit 128); the relative-prefix check passed.
- `git diff --check` exits 0. `verification-summary.json` records all final results.''')
s=s.replace('''The managed worktree contained 30 unrelated modified blueprint files after creation; this fill''','''Total guard waits: '''+str(summary['total_wait_seconds'])+''' seconds across '''+str(len(waits))+''' checks
(`wordarith-01` and `wordarith-03`); all were waits at three occupied slots. Peak observed
maximum resident memory across this fill's checks: '''+f'{peak[0]:,}'+''' bytes ('''+peak[1]+''').
The managed worktree contained 30 unrelated modified blueprint files after creation; this fill''')
s=s.replace('No copied proved material or new hand-built machine is present.','No copied proved material or new hand-built machine is present. The owned file is 371 lines.')
p.write_text(s)
print(json.dumps(summary,indent=2))
