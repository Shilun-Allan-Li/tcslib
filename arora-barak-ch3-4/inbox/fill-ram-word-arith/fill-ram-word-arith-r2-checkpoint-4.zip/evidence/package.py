from pathlib import Path
import sys,zipfile,hashlib
root=Path(__file__).resolve().parent.parent
out=Path(sys.argv[1]);checkpoint='checkpoint' in out.name
owned=Path('TCSlib/Complexity/TuringMachine/Build/WordArith.lean')
files=[Path('REPORT.md'),owned,Path('fill-ram-word-arith.patch')]
files += sorted(p.relative_to(root) for p in (root/'evidence').rglob('*') if p.is_file() and p.suffix not in ('.olean','.ilean','.zip','.pyc') and '__pycache__' not in p.parts and not (checkpoint and p.name.startswith('replay-') and p.suffix=='.log'))
contents={str(p):(root/p).read_bytes() for p in files}
contents['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in contents.items()).encode()
out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in contents.items():z.writestr(name,data)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  sha,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==sha
print(str(out)+'\nSHA256 '+hashlib.sha256(out.read_bytes()).hexdigest()+f'\n{len(contents)} entries; {out.stat().st_size} bytes')
