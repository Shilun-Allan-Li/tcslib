# Fill u2s-g5 — checkpoint 4 zip (`fill-u2s-g5-cp4.zip`)

**Checkpoint 4 of 9**, at commit `84bca80daa31f27013194ca23b5c8b972a01549c` of `fill/u2s-g5` (base
`335d31d408f1b4b4164f5b1b3a37d246a42b25cc`); 1325 lines. Contents at this commit: the invariant along the orbit — represented tapes and fullness (`tt_full` and its preservation, `tt_tape_rebalance`, `tt_trackStep_inv`, `tt_Dtr_inv`, `tt_homeData_inv`, `tt_round_inv`, the data orbit `tt_D`, `tt_D_inv`).
The target's body ends in its own `sorry`, the open time bound (checkpoints 6–7).

**This zip was assembled after the fill was complete** (the final delivery, `fill-u2s-g5.zip`,
proves `two_work_tapes_run` with no admission; its `REPORT.md` is the full report). Run on this
commit's file (`evidence/logs/cp4/`):
- module check: exit 0, one warning, the target's `declaration uses 'sorry'`;
- seal (43 definitions, `evidence/seal/`): exit 0, the target's sorry only;
- controls: 89 CONTROL_PASS unsealed, 89 CONTROL_FAIL sealed;
- axiom prints: `sorryAx` only in `two_work_tapes_run` and `two_work_tapes_binary`.

Environment, cache and bootstrap logs are the session's; the before screen is in `screens/`; the
after screens were run at checkpoint 3 and at the final commit (see those zips). Escalations: none.
