import Mathlib.Data.Nat.Log
import TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction
import TCSlib.Complexity.TuringMachine.Build.ZoneRebalance
import TCSlib.Complexity.TuringMachine.Build.ZoneStep

/-! Rule-10 controls for TwoTapes (sealed): 43 definitions, 3 of them `@[simp]`. -/

open Lean Elab Command Meta in
elab "#ctl_rfl " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ci ← getConstInfo n
  let some value := ci.value? | throwError "not a definition: {n}"
  let ok ← liftTermElabM do
    try
      Term.withoutErrToSorry do
        let goal ← mkEq (mkConst n (ci.levelParams.map Level.param)) value
        let proof ← Term.elabTermEnsuringType (← `(by rfl)) goal
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} rfl {n}"

open Lean Elab Command Meta in
elab "#ctl_eqn " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ok ← liftTermElabM do
    try
      let some eqs ← getEqnsFor? n | return false
      let ty := (← getConstInfo eqs[0]!).type
      let ty ← instantiateForall ty #[]
      Term.withoutErrToSorry do
        let proof ← Term.elabTermEnsuringType (← `(by intros; rfl)) ty
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} eqn {n}"

open Lean Elab Command Meta in
elab "#ctl_simp " id:ident : command => do
  let n ← liftCoreM (realizeGlobalConstNoOverload id)
  let ci ← getConstInfo n
  let some value := ci.value? | throwError "not a definition: {n}"
  let ok ← liftTermElabM do
    try
      Term.withoutErrToSorry do
        let c := mkConst n (ci.levelParams.map Level.param)
        let goal ← forallTelescopeReducing ci.type fun xs _ => do
          mkForallFVars xs (← mkEq (mkAppN c xs) (mkAppN value xs).headBeta)
        let proof ← Term.elabTermEnsuringType (← `(by intros; simp)) goal
        Term.synthesizeSyntheticMVarsNoPostponing
        return !(← instantiateMVars proof).hasSorry
    catch _ => return false
  logInfo m!"{if ok then "CONTROL_PASS" else "CONTROL_FAIL"} simp {n}"



section Controls

attribute [local irreducible]
  Turing.FinTM.ComputesInTime
  Turing.FinTM.ComputesFunInTime
  Turing.MultiTapeTM.ComputesInTimeAndSpace
  Turing.MultiTapeTM.spaceUsed
  Turing.MultiTapeTM.spaceUsedByTape
  Turing.MultiTapeTM.visitedByTapeHead
  Turing.MultiTapeTM.runFrom
  Turing.MultiTapeTM.initCfg
  Turing.Cfg.init
  Turing.MultiTapeTM.step
  Turing.Action.apply
  Turing.Cfg.inputSymbol
  Turing.Cfg.workTapeSymbols
  Turing.moveInputPos
  Turing.embedEmitTM
  Turing.embedEmitCfg
  Turing.zoneRowPre
  Turing.zoneRebalanceIndex
  Turing.zoneRebalanceData
  Turing.zoneExtendData
  Turing.zoneTrackStepData
  Turing.zonedTape
  Turing.zoneHomeWrite
  Turing.zoneTrackTape
  Turing.zoneShiftIndex
  Turing.zoneRebalance
  Turing.zoneCascade
  Turing.ZoneContents.extend
  Turing.ZoneContents.words
  Turing.zoneCapacity
  Turing.zoneCellOfCell
  Turing.Contract.inPhase
  Turing.Contract.zero
  Turing.Contract.Positive
  Turing.Segment
  Turing.HeadBox
  Turing.Cfg.bindState
  Turing.Cfg.mapState
  Turing.phaseHostTM
  Turing.ZoneContents.empty
  Turing.zoneCascadeLeft
  Turing.zoneCascadeRight
  Turing.zoneStart
attribute [-simp] Turing.MultiTapeTM.initCfg Turing.Cfg.init Turing.Action.apply

#ctl_rfl Turing.FinTM.ComputesInTime
#ctl_rfl Turing.FinTM.ComputesFunInTime
#ctl_rfl Turing.MultiTapeTM.ComputesInTimeAndSpace
#ctl_rfl Turing.MultiTapeTM.spaceUsed
#ctl_rfl Turing.MultiTapeTM.spaceUsedByTape
#ctl_rfl Turing.MultiTapeTM.visitedByTapeHead
#ctl_rfl Turing.MultiTapeTM.runFrom
#ctl_rfl Turing.MultiTapeTM.initCfg
#ctl_rfl Turing.Cfg.init
#ctl_rfl Turing.MultiTapeTM.step
#ctl_rfl Turing.Action.apply
#ctl_rfl Turing.Cfg.inputSymbol
#ctl_rfl Turing.Cfg.workTapeSymbols
#ctl_rfl Turing.moveInputPos
#ctl_rfl Turing.embedEmitTM
#ctl_rfl Turing.embedEmitCfg
#ctl_rfl Turing.zoneRowPre
#ctl_rfl Turing.zoneRebalanceIndex
#ctl_rfl Turing.zoneRebalanceData
#ctl_rfl Turing.zoneExtendData
#ctl_rfl Turing.zoneTrackStepData
#ctl_rfl Turing.zonedTape
#ctl_rfl Turing.zoneHomeWrite
#ctl_rfl Turing.zoneTrackTape
#ctl_rfl Turing.zoneShiftIndex
#ctl_rfl Turing.zoneRebalance
#ctl_rfl Turing.zoneCascade
#ctl_rfl Turing.ZoneContents.extend
#ctl_rfl Turing.ZoneContents.words
#ctl_rfl Turing.zoneCapacity
#ctl_rfl Turing.zoneCellOfCell
#ctl_rfl Turing.Contract.inPhase
#ctl_rfl Turing.Contract.zero
#ctl_rfl Turing.Contract.Positive
#ctl_rfl Turing.Segment
#ctl_rfl Turing.HeadBox
#ctl_rfl Turing.Cfg.bindState
#ctl_rfl Turing.Cfg.mapState
#ctl_rfl Turing.phaseHostTM
#ctl_rfl Turing.ZoneContents.empty
#ctl_rfl Turing.zoneCascadeLeft
#ctl_rfl Turing.zoneCascadeRight
#ctl_rfl Turing.zoneStart
#ctl_eqn Turing.FinTM.ComputesInTime
#ctl_eqn Turing.FinTM.ComputesFunInTime
#ctl_eqn Turing.MultiTapeTM.ComputesInTimeAndSpace
#ctl_eqn Turing.MultiTapeTM.spaceUsed
#ctl_eqn Turing.MultiTapeTM.spaceUsedByTape
#ctl_eqn Turing.MultiTapeTM.visitedByTapeHead
#ctl_eqn Turing.MultiTapeTM.runFrom
#ctl_eqn Turing.MultiTapeTM.initCfg
#ctl_eqn Turing.Cfg.init
#ctl_eqn Turing.MultiTapeTM.step
#ctl_eqn Turing.Action.apply
#ctl_eqn Turing.Cfg.inputSymbol
#ctl_eqn Turing.Cfg.workTapeSymbols
#ctl_eqn Turing.moveInputPos
#ctl_eqn Turing.embedEmitTM
#ctl_eqn Turing.embedEmitCfg
#ctl_eqn Turing.zoneRowPre
#ctl_eqn Turing.zoneRebalanceIndex
#ctl_eqn Turing.zoneRebalanceData
#ctl_eqn Turing.zoneExtendData
#ctl_eqn Turing.zoneTrackStepData
#ctl_eqn Turing.zonedTape
#ctl_eqn Turing.zoneHomeWrite
#ctl_eqn Turing.zoneTrackTape
#ctl_eqn Turing.zoneShiftIndex
#ctl_eqn Turing.zoneRebalance
#ctl_eqn Turing.zoneCascade
#ctl_eqn Turing.ZoneContents.extend
#ctl_eqn Turing.ZoneContents.words
#ctl_eqn Turing.zoneCapacity
#ctl_eqn Turing.zoneCellOfCell
#ctl_eqn Turing.Contract.inPhase
#ctl_eqn Turing.Contract.zero
#ctl_eqn Turing.Contract.Positive
#ctl_eqn Turing.Segment
#ctl_eqn Turing.HeadBox
#ctl_eqn Turing.Cfg.bindState
#ctl_eqn Turing.Cfg.mapState
#ctl_eqn Turing.phaseHostTM
#ctl_eqn Turing.ZoneContents.empty
#ctl_eqn Turing.zoneCascadeLeft
#ctl_eqn Turing.zoneCascadeRight
#ctl_eqn Turing.zoneStart
#ctl_simp Turing.MultiTapeTM.initCfg
#ctl_simp Turing.Cfg.init
#ctl_simp Turing.Action.apply

end Controls
