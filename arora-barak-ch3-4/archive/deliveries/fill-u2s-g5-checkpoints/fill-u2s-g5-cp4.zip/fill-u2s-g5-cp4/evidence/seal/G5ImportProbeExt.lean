import Mathlib.Data.Nat.Log
import TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction
import TCSlib.Complexity.TuringMachine.Build.ZoneRebalance
import TCSlib.Complexity.TuringMachine.Build.ZoneStep

/-! G5's import probe (maintainer pre-ship, 2026-11-06): `TwoTapes`'s three imports and region
(a)'s `Build.ZoneStep` resolve every name the brief cites, with `Turing.Segment.iterate_seq`
(#202). A probe, not library code. -/

#check @Turing.exists_zoneTrackStepTM
#check @Turing.zoneTrackStepData
#check @Turing.zoneTrackStepData_of_lt
#check @Turing.zoneTrackStepData_of_not_lt
#check @Turing.sum_two_pow_le_of_count
#check @Turing.sum_cost_le_of_count
#check @Turing.ZoneData
#check @Turing.zoneRowPre
#check @Turing.zoneRowPre_iff
#check @Turing.zoneRowPre_congr
#check @Turing.zoneRowPre_mapState_iff
#check @Turing.zoneRebalanceIndex
#check @Turing.zoneRebalanceIndex_eq
#check @Turing.zoneRebalanceIndex_le
#check @Turing.zoneRebalanceData
#check @Turing.zoneExtendData
#check @Turing.zoneRebalancePost
#check @Turing.zoneExtendPost
#check @Turing.zoneRebalanceData_of_short
#check @Turing.zoneRebalanceIndex_extend_of_short
#check @Turing.exists_zoneRebalanceTM
#check @Turing.exists_zoneExtendTM
#check @Turing.ZoneCell
#check @Turing.ZoneSym
#check @Turing.zoneCellOfCell
#check @Turing.zoneCellOfCell_inr
#check @Turing.zoneCellOfCell_inl
#check @Turing.zoneCellOfCell_none
#check @Turing.zoneStart_eq
#check @Turing.zonedTape
#check @Turing.zonedTape_zero
#check @Turing.zonedTape_blank_outside
#check @Turing.zonedTape_homeWrite
#check @Turing.zoneCapacity_eq
#check @Turing.ZoneContents
#check @Turing.ZoneContents.empty
#check @Turing.ZoneContents.empty_home
#check @Turing.ZoneContents.empty_left
#check @Turing.ZoneContents.empty_right
#check @Turing.ZoneContents.words_true
#check @Turing.ZoneContents.words_false
#check @Turing.ZoneContents.extend
#check @Turing.ZoneContents.extend_words_castSucc
#check @Turing.ZoneContents.extend_words_last
#check @Turing.zoneHomeWrite
#check @Turing.zoneHomeWrite_home
#check @Turing.zoneHomeWrite_left
#check @Turing.zoneHomeWrite_right
#check @Turing.zoneShiftIndex_le
#check @Turing.zoneShiftIndex_empty
#check @Turing.zoneShiftIndex_nonempty
#check @Turing.zoneShiftIndex_eq
#check @Turing.zoneShiftIndex_eq_length_iff
#check @Turing.zoneShiftIndex_extend
#check @Turing.zoneShiftIndex_extend_of_lt
#check @Turing.zoneRebalance_of_lt
#check @Turing.zoneRebalance_of_le
#check @Turing.zoneRebalance_frame
#check @Turing.zoneCascade_true
#check @Turing.zoneCascade_false
#check @Turing.zoneCascadeRight_lengths
#check @Turing.zoneCascadeLeft_lengths
#check @Turing.zoneTrackTape_zero
#check @Turing.zoneTrackTape_empty
#check @Turing.zoneTrackTape_homeWrite
#check @Turing.zoneTrackTape_extend
#check @Turing.zoneTrackTape_rebalance_right
#check @Turing.zoneTrackTape_rebalance_left
#check @Turing.ZoneContents.words
#check @Turing.zoneCapacity
#check @Turing.zoneCascade
#check @Turing.zoneRebalance
#check @Turing.zoneShiftIndex
#check @Turing.zoneTrackTape
#check @Turing.Contract
#check @Turing.Contract.live
#check @Turing.Contract.segment
#check @Turing.Contract.ofSegment
#check @Turing.Contract.ofSegment_pre
#check @Turing.Contract.ofSegment_time
#check @Turing.Contract.ofSegment_post
#check @Turing.Contract.ofSegment_lo
#check @Turing.Contract.ofSegment_hi
#check @Turing.Contract.zero
#check @Turing.Contract.zero_pre
#check @Turing.Contract.zero_time
#check @Turing.Contract.zero_post
#check @Turing.Contract.zero_lo
#check @Turing.Contract.zero_hi
#check @Turing.Contract.time_envelope
#check @Turing.Contract.trans
#check @Turing.Contract.trans_pre
#check @Turing.Contract.trans_time
#check @Turing.Contract.trans_post
#check @Turing.Contract.trans_lo
#check @Turing.Contract.trans_hi
#check @Turing.Segment
#check @Turing.segment_iff
#check @Turing.Segment.one
#check @Turing.Segment.trans
#check @Turing.Segment.mono
#check @Turing.Segment.cons
#check @Turing.Segment.live
#check @Turing.Round
#check @Turing.Round.iterate_seq
#check @Turing.RoundContract
#check @Turing.Lockstep
#check @Turing.Lockstep.runFrom
#check @Turing.Contract.seq
#check @Turing.Contract.inPhase
#check @Turing.Contract.branch
#check @Turing.Contract.seq_pre
#check @Turing.Contract.seq_time
#check @Turing.Contract.seq_post
#check @Turing.Contract.seq_lo
#check @Turing.Contract.seq_hi
#check @Turing.Contract.inPhase_pre
#check @Turing.Contract.inPhase_time
#check @Turing.Contract.inPhase_post
#check @Turing.Contract.inPhase_lo
#check @Turing.Contract.inPhase_hi
#check @Turing.Contract.branch_pre
#check @Turing.Contract.branch_time
#check @Turing.Contract.branch_post
#check @Turing.Contract.branch_lo
#check @Turing.Contract.branch_hi
#check @Turing.Contract.seq_positive
#check @Turing.Contract.inPhase_positive
#check @Turing.Contract.branch_positive
#check @Turing.Cfg.bindState
#check @Turing.Cfg.bindState_state
#check @Turing.Cfg.bindState_inputPos
#check @Turing.Cfg.bindState_workTapes
#check @Turing.Cfg.bindState_workTapePos
#check @Turing.Cfg.bindState_output
#check @Turing.phaseHostTM
#check @Turing.phaseHostTM_tr_of_red_none
#check @Turing.phaseHostTM_q₀
#check @Turing.phaseHostTM_tr_of_red_some
#check @Turing.phaseHostTM_run_le
#check @Turing.phaseHostTM_run
#check @Turing.Cfg.mapState_eq_of_fields
#check @Turing.Cfg.mapState_const_eq_mapState_sigma
#check @Turing.Cfg.mapState_sigma_state_ne
#check @Turing.embedEmitTM
#check @Turing.embedEmitTM_tr
#check @Turing.embedEmitTM_runFrom
#check @Turing.embedEmitTM_frame
#check @Turing.embedEmitCfg_eq
#check @Turing.Action.apply
#check @Turing.Action.apply_state
#check @Turing.Action.apply_inputPos
#check @Turing.Action.apply_workTapePos
#check @Turing.Action.apply_output
#check @Turing.Cfg.inputSymbol_of_zero
#check @Turing.Cfg.inputSymbol_of_end
#check @Turing.inputSymbolInner
#check @Turing.Cfg.workTapeSymbols_eq
#check @Turing.Cfg.init_state
#check @Turing.Cfg.init_inputPos
#check @Turing.Cfg.init_workTapes
#check @Turing.Cfg.init_workTapePos
#check @Turing.Cfg.init_output
#check @Turing.moveInputPos
#check @Turing.Cfg.ext
#check @Turing.Cfg.init
#check @Turing.Cfg.inputSymbol
#check @Turing.Action.apply_workTapes
#check @Turing.Cfg.mapState
#check @Turing.Cfg.mapState_state
#check @Turing.Cfg.mapState_inputPos
#check @Turing.Cfg.mapState_workTapes
#check @Turing.Cfg.mapState_workTapePos
#check @Turing.Cfg.mapState_output
#check @Turing.MultiTapeTM.step_of_halt
#check @Turing.MultiTapeTM.step_of_some
#check @Turing.MultiTapeTM.runFrom_zero
#check @Turing.MultiTapeTM.runFrom_succ_eq_step'
#check @Turing.MultiTapeTM.runFrom_add
#check @Turing.MultiTapeTM.runFrom_of_halt
#check @Turing.MultiTapeTM.initCfg
#check @Turing.MultiTapeTM.initCfg_eq
#check @Turing.MultiTapeTM.step
#check @Turing.MultiTapeTM.runFrom
#check @Turing.MultiTapeTM.runFrom_state_ne_none_of_le
#check @Turing.MultiTapeTM.exists_first_halt
#check @Turing.MultiTapeTM.runFrom_with_q₀
#check @Turing.MultiTapeTM.initCfg_with_q₀
#check @Turing.FinTM
#check @Turing.FinTM.ComputesInTime
#check @Turing.FinTM.computesFunInTime_iff
#check @Turing.FinTM.ComputesInTime.mono
#check @Turing.FinTM.not_computesInTime_zero
#check @Turing.FinTM.ComputesInTime.output_unique
#check @Turing.FinTM.computesInTime_iff
#check @Turing.FinTM.ComputesFunInTime
#check @Turing.FinTM.alphabet_reduction_run
#check @Function.Embedding.inl
#check @Function.Embedding.inl_apply
#check @Nat.log
#check @Nat.pow_log_le_self
#check @Nat.lt_pow_succ_log_self
#check @Nat.log_mono_right
#check @Nat.log2_eq_log_two
#check @Fin.castLEEmb
#check @SignType
#check @lt_trichotomy
#check @Nat.find
#check @List.length_map
#check @List.getElem_map
#check @Nat.exists_eq_add_of_le
#check @Nat.log2
#check @Turing.Segment.iterate_seq
#check @Turing.zoneRebalanceData_eq
#check @Turing.zoneExtendData_eq
#check @Turing.embedEmitCfg_state
#check @Turing.embedEmitCfg_output

/-! Extension: every further name the fill's diff cites (resolved under `open Turing Turing.FinTM`). -/
open Turing Turing.FinTM in
section
end
open Turing Turing.FinTM in #check @Eq.symm
open Turing Turing.FinTM in #check @Fin.coe_castSucc
open Turing Turing.FinTM in #check @Fin.eq_one_of_ne_zero
open Turing Turing.FinTM in #check @Fin.ext
open Turing Turing.FinTM in #check @Fin.ext_iff.mpr
open Turing Turing.FinTM in #check @Fin.last
open Turing Turing.FinTM in #check @Fin.lastCases
open Turing Turing.FinTM in #check @Fin.val_last
open Turing Turing.FinTM in #check @Finset.Icc
open Turing Turing.FinTM in #check @Finset.card_image_of_injOn
open Turing Turing.FinTM in #check @Finset.card_le_card
open Turing Turing.FinTM in #check @Finset.card_range
open Turing Turing.FinTM in #check @Finset.card_univ
open Turing Turing.FinTM in #check @Finset.mem_Icc
open Turing Turing.FinTM in #check @Finset.mem_filter.mp
open Turing Turing.FinTM in #check @Finset.mem_image.mp
open Turing Turing.FinTM in #check @Finset.mem_range
open Turing Turing.FinTM in #check @Finset.mem_range.mp
open Turing Turing.FinTM in #check @Finset.mem_range.mpr
open Turing Turing.FinTM in #check @Finset.mem_univ
open Turing Turing.FinTM in #check @Finset.mul_sum
open Turing Turing.FinTM in #check @Finset.range
open Turing Turing.FinTM in #check @Finset.sum_add_distrib
open Turing Turing.FinTM in #check @Finset.sum_bij
open Turing Turing.FinTM in #check @Finset.sum_congr
open Turing Turing.FinTM in #check @Finset.sum_const
open Turing Turing.FinTM in #check @Finset.sum_le_sum
open Turing Turing.FinTM in #check @Finset.sum_range_succ
open Turing Turing.FinTM in #check @Finset.univ
open Turing Turing.FinTM in #check @Fintype.card_fin
open Turing Turing.FinTM in #check @Function.update
open Turing Turing.FinTM in #check @Function.update_eq_self
open Turing Turing.FinTM in #check @Function.update_idem
open Turing Turing.FinTM in #check @Function.update_of_ne
open Turing Turing.FinTM in #check @Function.update_self
open Turing Turing.FinTM in #check @Int.one_le_abs
open Turing Turing.FinTM in #check @List.append_nil
open Turing Turing.FinTM in #check @List.length
open Turing Turing.FinTM in #check @List.length_nil
open Turing Turing.FinTM in #check @List.length_pos_iff.mpr
open Turing Turing.FinTM in #check @List.length_replicate
open Turing Turing.FinTM in #check @List.map_append
open Turing Turing.FinTM in #check @List.map_nil
open Turing Turing.FinTM in #check @List.nil_append
open Turing Turing.FinTM in #check @MultiTapeTM.runFrom_succ_eq_step.trans
open Turing Turing.FinTM in #check @MultiTapeTM.workTapePos_runFrom_mem_Icc
open Turing Turing.FinTM in #check @Nat.add_div_right
open Turing Turing.FinTM in #check @Nat.add_le_add_iff_right
open Turing Turing.FinTM in #check @Nat.add_le_add_left
open Turing Turing.FinTM in #check @Nat.add_le_add_right
open Turing Turing.FinTM in #check @Nat.add_sub_cancel
open Turing Turing.FinTM in #check @Nat.cast_id
open Turing Turing.FinTM in #check @Nat.cast_sub
open Turing Turing.FinTM in #check @Nat.div_le_div_right
open Turing Turing.FinTM in #check @Nat.le_add_left
open Turing Turing.FinTM in #check @Nat.le_add_right
open Turing Turing.FinTM in #check @Nat.le_induction
open Turing Turing.FinTM in #check @Nat.le_self_pow
open Turing Turing.FinTM in #check @Nat.le_succ
open Turing Turing.FinTM in #check @Nat.lt_one_iff.mp
open Turing Turing.FinTM in #check @Nat.lt_or_ge
open Turing Turing.FinTM in #check @Nat.lt_succ_of_le
open Turing Turing.FinTM in #check @Nat.lt_succ_self
open Turing Turing.FinTM in #check @Nat.mul_assoc
open Turing Turing.FinTM in #check @Nat.mul_comm
open Turing Turing.FinTM in #check @Nat.mul_le_mul
open Turing Turing.FinTM in #check @Nat.mul_le_mul_left
open Turing Turing.FinTM in #check @Nat.mul_one
open Turing Turing.FinTM in #check @Nat.not_lt_zero
open Turing Turing.FinTM in #check @Nat.one_le_two_pow
open Turing Turing.FinTM in #check @Nat.one_mul
open Turing Turing.FinTM in #check @Nat.pow_le_pow_right
open Turing Turing.FinTM in #check @Nat.two_pow_pos
open Turing Turing.FinTM in #check @Nat.zero_le
open Turing Turing.FinTM in #check @Option.getD_none
open Turing Turing.FinTM in #check @Option.isSome_iff_exists.mp
open Turing Turing.FinTM in #check @Option.map
open Turing Turing.FinTM in #check @Option.map_eq_none_iff.mp
open Turing Turing.FinTM in #check @Option.ne_none_iff_exists'.mp
open Turing Turing.FinTM in #check @Option.some.inj
open Turing Turing.FinTM in #check @Or.inl
open Turing Turing.FinTM in #check @Or.inr
open Turing Turing.FinTM in #check @Set.InjOn
open Turing Turing.FinTM in #check @Set.mem_singleton_iff
open Turing Turing.FinTM in #check @Set.mem_singleton_iff.mpr
open Turing Turing.FinTM in #check @Sigma.mk
open Turing Turing.FinTM in #check @SignType.coe_zero
open Turing Turing.FinTM in #check @Sum.inl
open Turing Turing.FinTM in #check @Sum.inr
open Turing Turing.FinTM in #check @Turing.MultiTapeTM.workTapePos_runFrom_mem_Icc
