# Fill u2s-g5 — checkpoint 1 zip (`fill-u2s-g5-cp1.zip`)

**Checkpoint 1 of 9 (partial)**, at commit `36fefeaa` of `fill/u2s-g5` (base
`335d31d408f1b4b4164f5b1b3a37d246a42b25cc`). Contents at this commit: the frame and the zero-tape case (`tt_zero_tapes`, `tt_frame`, `tt_route`, copied from the route probe); the target's body is `refine tt_route (fun M hk => ?_) M` then `sorry`. 227 lines; 2 public, 3 private.

This zip was assembled after checkpoint 3 had also been reached in the same session (the
session builds checkpoint zips once its delivery tooling exists). For this commit's file it
carries its own module check (`evidence/logs/cp1/cp1-check.log`: exit 0, the target's sorry
warning only), the seal with its controls and the axiom prints, run on this commit's file
(`evidence/logs/cp1/`: sealed copy exit 0; controls 81 PASS unsealed / 81 FAIL sealed; `sorryAx`
only in `two_work_tapes_run` and `two_work_tapes_binary`). The environment, cache and bootstrap
logs are the session's (`evidence/logs/`); the before screen is in `screens/` (byte-identical to
the screen base); the after screen was run at checkpoint 3 (a superset of this commit's code),
see `fill-u2s-g5-cp3.zip`. The full report, with the environment numbers, every declaration's
role, rule 10 and duplication, is checkpoint 3's `REPORT.md` (and the final one).

Escalations: none. Open: everything after checkpoint 1; see checkpoint 3's report, §4.
