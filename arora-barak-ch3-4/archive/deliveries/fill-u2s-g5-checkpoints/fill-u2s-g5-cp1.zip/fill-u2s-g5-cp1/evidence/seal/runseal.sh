#!/usr/bin/env bash
# usage: runseal.sh <tag>   (runs the sealed copy, both controls and the axiom prints, one at a time)
export PATH=$HOME/.elan/bin:$PATH
cd /home/user/tcslib
L=evidence/logs/$1; mkdir -p $L
for f in TwoTapesSealed TwoTapesCtl_unsealed TwoTapesCtl_sealed TwoTapesAxioms; do
  { echo "\$ bash scripts/lean_check_tree.sh Scratch/seal-$1/$f"; bash scripts/lean_check_tree.sh Scratch/seal-$1/$f; echo "exit status: $?"; } > $L/$f.out 2>&1
done
