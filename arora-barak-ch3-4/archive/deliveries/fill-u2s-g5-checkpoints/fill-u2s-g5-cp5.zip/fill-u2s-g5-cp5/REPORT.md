# Fill u2s-g5 — checkpoint 5 zip (`fill-u2s-g5-cp5.zip`)

**Checkpoint 5 of 9**, at commit `ec0b621c397d7e37a6ea46aa4557107f632cf4a4` of `fill/u2s-g5` (base
`335d31d408f1b4b4164f5b1b3a37d246a42b25cc`); 1622 lines. Contents at this commit: checkpoint 4 plus the iteration to the source's first halt and the output there (`tt_cs`, `tt_T`, `tt_cs_start`, `tt_cs_round`, `tt_cs_run` by `Segment.iterate_seq`, `tt_cs_halt`, `tt_forward_run`).
The target's body ends in its own `sorry`, the open time bound (checkpoints 6–7).

**This zip was assembled after the fill was complete** (the final delivery, `fill-u2s-g5.zip`,
proves `two_work_tapes_run` with no admission; its `REPORT.md` is the full report). Run on this
commit's file (`evidence/logs/cp5/`):
- module check: exit 0, one warning, the target's `declaration uses 'sorry'`;
- seal (43 definitions, `evidence/seal/`): **exit 1** — one rule-10 violation: a `show` in `tt_cs_start` (`[] = List.map Sum.inl (tt_c M x 0).output`, the equation the wrong way round) closed only by unfolding `runFrom`/`Cfg.init`. Found by the final seal and **fixed in `71046be0`** (it now rewrites with `Cfg.init_output`); the delivered final file passes the seal with no diagnostic;
- controls: 89 CONTROL_PASS unsealed, 89 CONTROL_FAIL sealed;
- axiom prints: `sorryAx` only in `two_work_tapes_run` and `two_work_tapes_binary`.

Environment, cache and bootstrap logs are the session's; the before screen is in `screens/`; the
after screens were run at checkpoint 3 and at the final commit (see those zips). Escalations: none.
