#!/usr/bin/env python3
"""E-PAD duplication probe: for every private lemma/theorem of Padding.lean, an `exact?` probe
on its exact statement, placed immediately before the declaration in a scratch copy of the
module (so the declaration itself is not yet available), under a heartbeat cap. Output: one
line per private with the probe's verdict. Usage: epad_dup.py <tag>
"""
import re, subprocess, sys, os
tag = sys.argv[1]
F = '/workspace/tcslib-fill'
E = '/workspace/epad-evidence'
src = open(f'{F}/TCSlib/Complexity/SpaceComplexity/Padding.lean').read()
DECL = re.compile(r'^(?:open Classical in\n)?private (?:lemma|theorem) (\S+)', re.M)
out = []
pos = 0
names = []
for m in DECL.finditer(src):
    name = m.group(1)
    start = m.start()
    # statement: from after the name to the first ':=' at bracket depth 0
    i = m.end(); d = 0
    while i < len(src):
        ch = src[i]
        if ch in '([{⟨': d += 1
        elif ch in ')]}⟩': d -= 1
        elif src.startswith(':=', i) and d == 0: break
        i += 1
    stmt = src[m.end():i].rstrip()
    # place before any docstring of the declaration
    k = src.rfind('/--', 0, start)
    kend = src.find('-/', k) + 2 if k >= 0 else -1
    ins = k if k >= 0 and src[kend:start].strip() in ('', 'open Classical in') else start
    pre = src[:ins]
    if pre.endswith('open Classical in\n'):
        ins -= len('open Classical in\n')
    names.append((name, ins, stmt))
pieces = []
last = 0
for name, ins, stmt in names:
    pieces.append(src[last:ins])
    pieces.append(f'-- EPAD-DUP-PROBE {name}\nset_option maxHeartbeats 400000 in\nopen Classical in\nexample{stmt} := by\n  exact?\n\n')
    last = ins
pieces.append(src[last:])
probe = ''.join(pieces)
open(f'{F}/Probe/EPadDupProbe.lean', 'w').write(probe)
r = subprocess.run(['python3', '/workspace/bin/chkE.py', 'Probe/EPadDupProbe'], cwd=F,
                   capture_output=True, text=True)
log = r.stdout + r.stderr
open(f'{E}/logs/dup-exact-{tag}.log', 'w').write(log)
# map probe line numbers to names
lines = probe.splitlines()
marks = []
for i, l in enumerate(lines):
    if l.startswith('-- EPAD-DUP-PROBE '):
        j = i
        while lines[j].strip() != 'exact?': j += 1
        marks.append((j + 1, l.split()[-1]))
def owner(ln):
    o = None
    for mln, nm in marks:
        if mln <= ln: o = nm
    return o
res = {nm: [] for _, nm in marks}
# a `Try this` suggestion is printed without a position: attribute it to the probe whose
# `exact?` produced no error (an `exact?` that closes its goal reports only the suggestion)
for mm in re.finditer(r'EPadDupProbe\.lean:(\d+):\d+: (error|warning|info)[^:]*: (.*)', log):
    ln = int(mm.group(1)); nm = owner(ln)
    if nm and ln == [m for m, n in marks if n == nm][0]:
        res[nm].append(f'{mm.group(2)}: {mm.group(3)[:160]}')
rows = []
tries = re.findall(r'Try this:\n\s*\[apply\] (.*)', log)
for _, nm in marks:
    msgs = res[nm]
    txt = ' | '.join(msgs) if msgs else '(no message)'
    if not msgs: verdict = 'CLOSED by `exact?` (a suggestion was printed; suggestions in order: ' + '; '.join(f'`{t}`' for t in tries) + ')'
    elif any('could not close' in x or 'exact?' in x and 'error' in x for x in msgs): verdict = 'no closing term found'
    elif any('heartbeats' in x or 'timeout' in x for x in msgs): verdict = 'search exhausted its heartbeat cap'
    else: verdict = txt
    rows.append(f'| `{nm}` | {verdict} |')
open(f'{E}/logs/dup-exact-{tag}.md', 'w').write('| private lemma | `exact?` probe on its statement (before it) |\n|---|---|\n' + '\n'.join(rows) + '\n')
print('\n'.join(rows))
