import TCSlib.Complexity.SpaceComplexity.Padding
import TCSlib.Complexity.SpaceComplexity.Logspace.PreimageHost
import TCSlib.Complexity.TuringMachine.Build.InputDevice
import TCSlib.Complexity.TuringMachine.Build.VirtualInput
import TCSlib.Complexity.TuringMachine.Build.InputCall
import TCSlib.Complexity.ClassNP.PolyTimePairing
import TCSlib.Complexity.SpaceComplexity.Basic
import TCSlib.Complexity.TuringMachine.Build.Catalog
import TCSlib.Complexity.SpaceComplexity.Codec.Word

/-! E-PAD import probe, extended (cp3): the brief's probe, plus every declaration of
another TCSlib module occurring in `Padding.lean`'s declarations (the citation walk
`Probe/EPadCites.lean`), each `#check`ed at the base. Private names cannot occur. -/


/-! E-PAD's import probe: every host the brief names, at the base. Each `#check` must print a
type; the final line prints the target's axioms (`sorryAx` expected: the target is the fill). -/

open Complexity Turing in
section
#check @Complexity.padLang
#check @Complexity.mem_padLang_iff
#check @Complexity.mem_SPACE_padLang
#check @Complexity.mem_SPACE_iff
#check @Complexity.SPACE.mono
#check @Complexity.SPACE.mono_const
#check @Turing.FinTM.decidesInSpace_iff
#check @Turing.length_pairEncode
#check @Complexity.pairFstD_pairEncode
#check @Complexity.LogProg.OIS.compile_decides
#check @Complexity.mem_LOGSPACE_preimage
#check @Turing.exists_rulerHostTM
#check @Turing.vhostEmitTM
#check @Turing.FinTM.exists_inputCallTM
end


section EPadExtension
#check @Complexity.Codec.bitsVal_lt_two_pow
#check @Complexity.LOGSPACE
#check @Complexity.LOGSPACE_eq
#check @Complexity.LogProg.AConf
#check @Complexity.LogProg.AHalt
#check @Complexity.LogProg.AHalt.ret
#check @Complexity.LogProg.AHalt.step
#check @Complexity.LogProg.ARM
#check @Complexity.LogProg.AReach
#check @Complexity.LogProg.AReach.halt
#check @Complexity.LogProg.AReach.refl
#check @Complexity.LogProg.AReach.single
#check @Complexity.LogProg.AReach.step
#check @Complexity.LogProg.AReach.trans
#check @Complexity.LogProg.BankS
#check @Complexity.LogProg.CallSpec.mk
#check @Complexity.LogProg.Canon
#check @Complexity.LogProg.CleanSt
#check @Complexity.LogProg.Ins
#check @Complexity.LogProg.Ins.call
#check @Complexity.LogProg.Ins.casesOn
#check @Complexity.LogProg.Ins.clr
#check @Complexity.LogProg.Ins.dec
#check @Complexity.LogProg.Ins.half
#check @Complexity.LogProg.Ins.inc
#check @Complexity.LogProg.Ins.jeq
#check @Complexity.LogProg.Ins.jeqFst
#check @Complexity.LogProg.Ins.jeqIn
#check @Complexity.LogProg.Ins.jeqSnd
#check @Complexity.LogProg.Ins.jodd
#check @Complexity.LogProg.Ins.jz
#check @Complexity.LogProg.Ins.ret
#check @Complexity.LogProg.Ins.valP
#check @Complexity.LogProg.Ins.valQ
#check @Complexity.LogProg.Mode
#check @Complexity.LogProg.Mode.whole
#check @Complexity.LogProg.OIS.Ph
#check @Complexity.LogProg.OIS.compile_decides
#check @Complexity.LogProg.OIS.instDecidableEqPh
#check @Complexity.LogProg.OIS.instFintypePh
#check @Complexity.LogProg.OIS.prog
#check @Complexity.LogProg.OIS.start
#check @Complexity.LogProg.PreS
#check @Complexity.LogProg.ValidPair
#check @Complexity.LogProg.ValidPlain
#check @Complexity.LogProg.alignedPair_loop
#check @Complexity.LogProg.arm_chain
#check @Complexity.LogProg.arm_decides_poly
#check @Complexity.LogProg.astep
#check @Complexity.LogProg.astep_call
#check @Complexity.LogProg.astep_clr
#check @Complexity.LogProg.astep_dec
#check @Complexity.LogProg.astep_half
#check @Complexity.LogProg.astep_inc
#check @Complexity.LogProg.astep_jeq
#check @Complexity.LogProg.astep_jz
#check @Complexity.LogProg.bankK
#check @Complexity.LogProg.bankStart
#check @Complexity.LogProg.bankTM
#check @Complexity.LogProg.bitsVal
#check @Complexity.LogProg.bitsVal_bits
#check @Complexity.LogProg.boundedDecode_loop
#check @Complexity.LogProg.callSegs
#check @Complexity.LogProg.canon_bits
#check @Complexity.LogProg.canonicalTail_loop
#check @Complexity.LogProg.compileFinTM
#check @Complexity.LogProg.drop_canon
#check @Complexity.LogProg.indexedSeek_loop
#check @Complexity.LogProg.indicator_eq_decide
#check @Complexity.LogProg.inputLength_loop
#check @Complexity.LogProg.instDecidableEqCleanSt
#check @Complexity.LogProg.instFintypeCleanSt
#check @Complexity.LogProg.length_bits_le_log
#check @Complexity.LogProg.length_bits_mono
#check @Complexity.LogProg.preS_of_ins
#check @Complexity.LogProg.registerCopy_loop
#check @Complexity.LogProg.registerScale_loop
#check @Complexity.LogProg.register_update_le
#check @Complexity.LogProg.vword
#check @Complexity.LogProg.vword_whole₁
#check @Complexity.SPACE
#check @Complexity.indicator_inputBitLang
#check @Complexity.indicator_inputLenLang
#check @Complexity.inputBitLang
#check @Complexity.inputBitLang_mem
#check @Complexity.inputLenLang
#check @Complexity.inputLenLang_mem
#check @Complexity.length_pairFstD_le
#check @Complexity.logSpace
#check @Complexity.logSpace_le_succ
#check @Complexity.mem_SPACE_iff
#check @Complexity.pairEncode_getD
#check @Complexity.pairEncode_getD_snd
#check @Complexity.pairFstD
#check @Complexity.pairFstD_pairEncode
#check @Turing.FinTM
#check @Turing.FinTM.ComputesInSpace
#check @Turing.FinTM.ComputesInTime
#check @Turing.FinTM.DecidesInSpace
#check @Turing.FinTM.State
#check @Turing.FinTM.computesInSpace_iff
#check @Turing.FinTM.decEqState
#check @Turing.FinTM.decidesInSpace_iff
#check @Turing.FinTM.fintypeState
#check @Turing.FinTM.k
#check @Turing.FinTM.tm
#check @Turing.MultiTapeTM.indicator
#check @Turing.MultiTapeTM.initCfg
#check @Turing.MultiTapeTM.spaceUsed
#check @Turing.eq_pairEncode_of_pairDecode
#check @Turing.length_pairEncode
#check @Turing.pairDecode
#check @Turing.pairDecode_pairEncode
#check @Turing.pairEncode
end EPadExtension

#print axioms Complexity.mem_SPACE_padLang
