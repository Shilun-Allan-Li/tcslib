import TCSlib.Complexity.SpaceComplexity.Savitch

/-! Rule 10's inspection: the kind (theorem or definition) of every global constant passed to
`rw`/`simp`/`unfold` in the owned regions (`args.tsv`), other than this fill's own. -/

open Lean Elab Command in
elab "#kinds " ids:ident* : command => do
  for i in ids do
    let n ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo i
    let ci ← getConstInfo n
    let k := match ci with
      | .thmInfo _ => "theorem" | .defnInfo _ => "definition" | .axiomInfo _ => "axiom"
      | _ => "other"
    logInfo m!"{n} : {k}"

open Complexity Complexity.LogProg Complexity.LogProg.SavitchARM Complexity.Codec Turing

#kinds Function.update_of_ne Function.update_self Function.update_idem Function.update_apply
  Function.comp_apply zero_add one_mul dif_pos dif_neg if_pos if_neg Fin.ext_iff Fin.val_mk
  logSpace_eq indicator_eq_decide astep_inc astep_clr Nat.sub_add_cancel stepRel_iff_mem
  setSt_toV outerSt_toV rel_iff_orc initO_iff_orc accO_iff_orc noEdge_iff pow_add mul_comm
  mul_assoc decide_eq_false_iff_not decide_eq_decide Nat.size_eq_bits_len
