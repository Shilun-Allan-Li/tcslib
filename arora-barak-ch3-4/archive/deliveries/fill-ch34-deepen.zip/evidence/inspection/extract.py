#!/usr/bin/env python3
"""Rule 10's inspection table: every argument of `rw`/`rwa`/`simp`/`simp only`/`simp_all`/`simpa`/
`dsimp`/`unfold` and every `show` in the given files, with its line.
Usage: python3 -I extract.py <file.lean>... > args.tsv  (columns: file, line, tactic, argument)"""
import re, sys
TAC = re.compile(r"\b(rwa|rw|simp_all|simpa|simp only|simp|dsimp only|dsimp|unfold)\b(?:\s*\[([^\]]*)\])?")
def split_args(s):
    out, d, cur = [], 0, ""
    for ch in s:
        if ch in "([{⟨": d += 1
        if ch in ")]}⟩": d -= 1
        if ch == "," and d == 0: out.append(cur.strip()); cur = ""
        else: cur += ch
    if cur.strip(): out.append(cur.strip())
    return out
for f in sys.argv[1:]:
    text = open(f, encoding="utf-8").read()
    # join bracket continuations: scan the whole text for tactic[...] spans
    for m in TAC.finditer(text):
        line = text.count("\n", 0, m.start()) + 1
        lstart = text.rfind("\n", 0, m.start()) + 1
        prefix = text[lstart:m.start()]
        if "--" in prefix or prefix.lstrip().startswith("*") : continue
        tac = m.group(1)
        if m.group(2) is None:
            print(f"{f}\t{line}\t{tac}\t(no list)"); continue
        for a in split_args(m.group(2)):
            print(f"{f}\t{line}\t{tac}\t{' '.join(a.split())}")
    for m in re.finditer(r"\bshow\b([^\n]*)", text):
        line = text.count("\n", 0, m.start()) + 1
        lstart = text.rfind("\n", 0, m.start()) + 1
        if "--" in text[lstart:m.start()]: continue
        print(f"{f}\t{line}\tshow\t{m.group(1).strip()}")
