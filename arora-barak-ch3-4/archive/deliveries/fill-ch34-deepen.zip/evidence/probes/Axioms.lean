import TCSlib.Complexity.SpaceComplexity.Savitch
#print axioms Complexity.savitch
#print axioms Complexity.savitch_of_logSpace_le
#print axioms Complexity.LogProg.SavitchARM.deepen_contract
