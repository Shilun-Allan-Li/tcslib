#!/usr/bin/env python3
"""Assemble the delivery: fill the report's measured fields, then build fill-ch34-deepen.zip and
the checkpoint zips cp1 … cp8 in <out>. Usage: python3 -I package.py <repo> <out>"""
import os, re, shutil, subprocess, sys, hashlib, zipfile
repo, out = sys.argv[1], sys.argv[2]
run = lambda *a: subprocess.run(a, cwd=repo, capture_output=True, text=True, check=True).stdout
head = run("git", "rev-parse", "HEAD").strip()
log = run("git", "log", "--format=%h %s", "fd97df61..HEAD").strip()
sweep = open(f"{repo}/evidence/logs/final-sweep.log").read()
n_ok = sweep.count("exit=0 maxrss"); n_all = sweep.count("=== [")
tot = sum(float(x) for x in re.findall(r"wall_s=([\d.]+)", sweep))
rss = max((int(x), m) for x, m in re.findall(r"maxrss_kib=(\d+) cmd=bash scripts/lean_check_tree.sh (\S+)", sweep))
errs = len(re.findall(r"error:", sweep))
tail = sweep.strip().splitlines()[-1]
sw = (f"{n_all} modules, {n_ok} with exit 0, {errs} `error:` lines; total wall time {tot:,.0f} s; "
      f"peak {rss[0]:,} KiB (`{rss[1]}`). Last line: `{tail}`.")
sor = re.findall(r"^(TCSlib/\S+?\.lean):\d+:\d+: warning: declaration uses 'sorry'", sweep, re.M)
from collections import Counter
cnt = Counter(sor)
base = {"TuringMachine/Simulation": 1, "TuringMachine/Encoding": 1, "TuringMachine/Composition": 3,
        "ClassP/TimeConstructible": 2, "TuringMachine/Build/Wrappers": 2, "TuringMachine/Build/Loop": 5,
        "TuringMachine/Build/Primitives": 3, "TuringMachine/Build/RecordTable": 4,
        "SpaceComplexity/Savitch": 1, "SpaceComplexity/Hierarchy": 4}
got = {k.replace("TCSlib/Complexity/", "").replace(".lean", ""): v for k, v in cnt.items()}
exp = dict(base); exp.pop("SpaceComplexity/Savitch")
ok = got == exp
srs = (f"{sum(got.values())} warnings in {len(got)} modules: "
       + ", ".join(f"{k} {v}" for k, v in sorted(got.items()))
       + f". The base set less `savitch`'s is 25 entries in 9 modules: "
       + ("**equal, module by module**." if ok else "**DIFFERS**."))
kinds = open(f"{repo}/evidence/inspection/kinds.out").read()
krows = re.findall(r"^(\S+) : (\w+)$", kinds, re.M)
args = [l.rstrip("\n").split("\t") for l in open(f"{repo}/evidence/inspection/args.tsv")]
def uses(name):
    short = name.split(".")[-1] if not name.startswith(("Function.", "Fin.", "Nat.")) else name
    ls = sorted({int(a[1]) for a in args if re.sub(r"\.(mpr|mp)$", "", re.sub(r"^← ?|^@|^\(+@?", "", a[3]).split(" ")[0].split(")")[0]) in (name, short, name.replace("Complexity.LogProg.SavitchARM.", "").replace("Complexity.LogProg.", "").replace("Complexity.Codec.", "").replace("Complexity.", ""))})
    return len(ls)
tbl = "| constant | kind | uses |\n|---|---|---|\n" + "\n".join(
    f"| `{n}` | {k} | {uses(n)} |" for n, k in krows)
r = open(f"{repo}/evidence/REPORT.md").read()
for k, v in {"@@HEAD@@": head, "@@LOG@@": log, "@@HEAD8@@": head[:8], "@@SWEEP@@": sw,
             "@@SORRIES@@": srs, "@@INSPECTION@@": tbl}.items():
    r = r.replace(k, v)
assert "@@" not in r
os.makedirs(out, exist_ok=True)
stage = os.path.join(out, "stage"); shutil.rmtree(stage, ignore_errors=True); os.makedirs(stage)
open(f"{stage}/REPORT.md", "w").write(r)
for f in ["TCSlib/Complexity/SpaceComplexity/SavitchARM/Deepen.lean",
          "TCSlib/Complexity/SpaceComplexity/Savitch.lean", "TCSlib/Complexity/SpaceComplexity.lean"]:
    os.makedirs(os.path.dirname(f"{stage}/source/{f}"), exist_ok=True)
    shutil.copy(f"{repo}/{f}", f"{stage}/source/{f}")
os.makedirs(f"{stage}/patches")
run("git", "format-patch", "-q", "-o", f"{stage}/patches", "fd97df61..HEAD")
run("git", "bundle", "create", f"{stage}/fill-ch34-deepen.bundle", "fd97df61..fill/ch34-deepen")
shutil.copytree(f"{repo}/evidence", f"{stage}/evidence", ignore=shutil.ignore_patterns("REPORT.md", "*.olean"))
def sums(d):
    lines = []
    for root, _, fs in os.walk(d):
        for f in sorted(fs):
            p = os.path.join(root, f); rel = os.path.relpath(p, d)
            if rel == "SHA256SUMS": continue
            lines.append(f"{hashlib.sha256(open(p,'rb').read()).hexdigest()}  {rel}")
    open(f"{d}/SHA256SUMS", "w").write("\n".join(sorted(lines, key=lambda l: l[66:])) + "\n")
def mkzip(name, extra=None):
    if extra: open(f"{stage}/CHECKPOINT.txt", "w").write(extra)
    elif os.path.exists(f"{stage}/CHECKPOINT.txt"): os.remove(f"{stage}/CHECKPOINT.txt")
    sums(stage)
    z = os.path.join(out, name)
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, fs in os.walk(stage):
            for f in sorted(fs):
                p = os.path.join(root, f); zf.write(p, os.path.relpath(p, stage))
    return hashlib.sha256(open(z, "rb").read()).hexdigest()
CP = {1: "labels, table, deciders, oracle bridges, table equations, PreS",
      2: "setup loops n, ℓ, s := 1", 3: "w, 2^w, register reset and its RegExt",
      4: "the edge and accept blocks' runs", 5: "the loop (dp_body)", 6: "register bound, guard",
      7: "deepen_contract", 8: "Savitch.lean: savitch_of_logSpace_le, savitch, public text, facade"}
res = {}
for n, d in CP.items():
    res[f"fill-ch34-deepen-cp{n}.zip"] = mkzip(f"fill-ch34-deepen-cp{n}.zip",
        f"Checkpoint {n}: {d}.\nReached at {head} (checkpoints 1-7 were reached together in commit "
        "6c8e70fa, the first elaboration of the full Deepen.lean; 8 with it). This zip holds the "
        "end-of-session state; see REPORT.md section 2.\n")
res["fill-ch34-deepen.zip"] = mkzip("fill-ch34-deepen.zip")
for k, v in res.items(): print(v, k)
