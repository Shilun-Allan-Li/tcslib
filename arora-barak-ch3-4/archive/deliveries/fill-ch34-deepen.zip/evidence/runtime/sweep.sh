#!/usr/bin/env bash
# Check every module of an order list, in order, one Lean process at a time, each through
# scripts/lean_check_tree.sh under the timing wrapper. Stops at the first failing module.
set -u
ORDER="$1"
export PATH=$HOME/.elan/bin:$PATH
n=0
while read -r m; do
  n=$((n+1)); echo "=== [$n] $m"
  python3 -I evidence/runtime/timed.py bash scripts/lean_check_tree.sh "$m" || { echo "SWEEP STOPPED at [$n] $m"; exit 1; }
done < "$ORDER"
echo "SWEEP COMPLETE: $n modules"
