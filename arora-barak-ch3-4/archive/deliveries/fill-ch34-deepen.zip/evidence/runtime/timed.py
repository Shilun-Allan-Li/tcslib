#!/usr/bin/env python3
"""Run one command, then print its start/end time (UTC), wall seconds, exit status and the
maximum resident set size of its process tree (getrusage RUSAGE_CHILDREN, KiB) -- the
fields /usr/bin/time -v would give, on a host without it."""
import resource, subprocess, sys, time, datetime
def now(): return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
t0 = time.time(); s = now()
rc = subprocess.call(sys.argv[1:])
ru = resource.getrusage(resource.RUSAGE_CHILDREN)
print(f"TIMED start={s} end={now()} wall_s={time.time()-t0:.1f} exit={rc} maxrss_kib={ru.ru_maxrss} cmd={' '.join(sys.argv[1:])}", flush=True)
sys.exit(rc)
