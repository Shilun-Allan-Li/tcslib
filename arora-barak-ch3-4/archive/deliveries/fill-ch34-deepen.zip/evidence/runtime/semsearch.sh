#!/usr/bin/env bash
# The semantic search by name and statement: each pattern over the tree at HEAD and over every
# PR head not contained in the campaign branch or main (16 heads; the API that would mark them
# open is not available on this host). Deepen.lean itself is excluded.
set -u
declare -A P=(
 [names]='\b(dp_[a-zA-Z_]+|dpSt[a-zA-Z_]*|dpHl[a-zA-Z_]*|dpρ[a-zA-Z_]*|DpLb|dpD)\b'
 [update_bound]='(update_le|le_of_update|bd_update|upd_bd|update_bd)|∀ [a-z]+, Function\.update [a-zA-Z]+ [a-zA-Z]+ [a-zA-Z0-9]+ [a-z]+ ≤'
 [halve_to_zero]='half[A-Za-z_]*_run|halveZ|halving loop|halv[a-z]* until|lg_run|hl_run'
 [log_vs_halving]='Nat\.log 2 \(?[a-z]+ / 2\)?|log_div_base|log_of_one_lt_of_le'
 [reg_split]='dif_pos .*isLt|r\.val < 18|Fin\.append .*→ ℕ|castAdd .*→ ℕ'
 [clear_chain]='clr_run|clear_run|clrs_run|cb_run'
 [const_copies]='cT_run|mulc_run|copies_run|mul_run'
 [single_step]='inc_step|clr_step|step_inc|step_clr|dp_inc|one_step|step_of'
 [copy_wrapper]='\bcopy_run\b|\bshl_run\b'
 [embed_fit]='embed_guardLe'
 [oracle_bridge]='rel_iff_orc|initO_iff_orc|accO_iff_orc'
)
search() {  # $1 = label, $2 = git tree-ish or "HEAD"
  for k in "${!P[@]}"; do
    git grep -n -E "${P[$k]}" "$2" -- '*.lean' ':!TCSlib/Complexity/SpaceComplexity/SavitchARM/Deepen.lean' 2>/dev/null \
      | sed "s|^|$1 [$k] |"
  done
}
search HEAD HEAD
while read -r r sha; do search "$r" "$sha"; done < "$1"
