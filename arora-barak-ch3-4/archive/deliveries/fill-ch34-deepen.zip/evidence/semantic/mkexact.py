#!/usr/bin/env python3
"""Pose every private lemma of Deepen.lean to `exact?`: a copy of the file in which, just before
each `private theorem` (and before its docstring and any `open ... in` line), its statement is
restated as `example … := by exact?` under a heartbeat cap. The lemma itself is not yet
declared there, so `exact?` can only find it elsewhere (the library, or an earlier lemma).
Usage: python3 -I mkexact.py <Deepen.lean> <out.lean>"""
import sys, re
src, out = sys.argv[1], sys.argv[2]
lines = open(src, encoding="utf-8").read().split("\n")
res = []; i = 0; names = []
def header_end(text):
    d = 0
    for k, ch in enumerate(text):
        if ch in "([{⟨": d += 1
        elif ch in ")]}⟩": d -= 1
        elif text.startswith(":=", k) and d == 0: return k
    return -1
out_lines = list(lines)
inserts = []
for idx, ln in enumerate(lines):
    m = re.match(r"^private theorem (\S+)(.*)$", ln)
    if not m: continue
    rest = "\n".join(lines[idx:])
    hdr = rest[len("private theorem " + m.group(1)):]
    hdr = hdr[:header_end(hdr)]
    j = idx
    if lines[j-1].rstrip().endswith("-/"):
        while not lines[j-1].lstrip().startswith("/--"):
            j -= 1
        j -= 1
    opn = ""
    if j > 0 and lines[j-1].startswith("open ") and lines[j-1].endswith(" in"):
        j -= 1; opn = lines[j] + "\n"
    ex = f"-- exact? probe: {m.group(1)}\nset_option maxHeartbeats 400000 in\n{opn}example{hdr}:= by exact?\n"
    inserts.append((j, ex)); names.append(m.group(1))
for j, ex in sorted(inserts, reverse=True):
    out_lines.insert(j, ex)
open(out, "w", encoding="utf-8").write("\n".join(out_lines))
print(len(names), " ".join(names))
