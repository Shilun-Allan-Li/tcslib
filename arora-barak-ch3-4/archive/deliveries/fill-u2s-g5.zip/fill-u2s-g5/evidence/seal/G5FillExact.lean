import Mathlib.Data.Nat.Log
import TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction
import TCSlib.Complexity.TuringMachine.Build.ZoneRebalance
import TCSlib.Complexity.TuringMachine.Build.ZoneStep

/-! Semantic-duplication probe: the fill's privates whose statements mention no definition of
the fill's own file, posed to `exact?` (expected: no library lemma closes them, exit 1), and the
one that does (`tt_fin_two`, reported). -/

open Turing

example (j : Fin 2) (hj : j ≠ 0) : j = 1 := by exact?

example {k : ℕ} {S S' : Type} {x : List (ZoneSym k)} (D : ZoneData k) (d : Cfg 2 (ZoneSym k) S x)
    (hp : zoneRowPre D d) (s : S') (hs : d.state.isSome) (h1 : d.workTapePos 1 = 0)
    (d' : Cfg 2 (ZoneSym k) S' x) (hst : d'.state = some s)
    (hw : d'.workTapes = fun j => if j = 0 then zonedTape D.2 else fun _ => none)
    (hpos : d'.workTapePos = fun _ => 0) (hi : d.inputPos = d'.inputPos)
    (ho : d.output = d'.output) :
    d.mapState (fun _ => s) = d' := by exact?

-- tt_card_le_of_gap
example (T g : ℕ) (hg : 0 < g) (S : Finset ℕ) (hS : ∀ a ∈ S, a < T)
    (hgap : ∀ a ∈ S, ∀ b ∈ S, a < b → a + g ≤ b) : S.card ≤ T / g + 1 := by exact?

-- tt_sum_range_fin
example (k : ℕ) (f : ℕ → ℕ) : ∑ j ∈ Finset.range k, f j = ∑ t : Fin k, f t.val := by exact?

-- tt_moveInputPos_val
example {n n' : ℕ} (hn : n = n') (p : Fin (n + 2)) (p' : Fin (n' + 2)) (h : p.val = p'.val)
    (s : SignType) : (moveInputPos p s).val = (moveInputPos p' s).val := by exact?

-- tt_inputSymbol
example {k k' : ℕ} {S S' : Type} {x : List Bool} (d : Cfg k (ZoneSym k') S (x.map Sum.inl))
    (c : Cfg k' Bool S' x) (h : d.inputPos.val = c.inputPos.val) :
    d.inputSymbol = c.inputSymbol.map Sum.inl := by exact?
