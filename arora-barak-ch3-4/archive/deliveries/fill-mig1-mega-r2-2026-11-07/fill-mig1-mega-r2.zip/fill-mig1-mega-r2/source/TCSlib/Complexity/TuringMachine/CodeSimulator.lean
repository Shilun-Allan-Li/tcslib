/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.TuringMachine.CodeFormat
import TCSlib.Complexity.TuringMachine.Build.CounterLoop
import TCSlib.Complexity.TuringMachine.Build.Seam
import TCSlib.Complexity.TuringMachine.Build.VirtualInput
import TCSlib.Complexity.TuringMachine.Build.StepBlock
import TCSlib.Complexity.TuringMachine.Build.StepBlockLoop
-- B5a continuation: sanctioned imports for the physical binary-header loader.
import TCSlib.Complexity.TuringMachine.Build.Primitives
import TCSlib.Complexity.TuringMachine.Build.InputCall
import TCSlib.Complexity.TuringMachine.Build.InputRewind
import TCSlib.Complexity.TuringMachine.Nondeterministic
import TCSlib.Complexity.TuringMachine.Build.InterpreterStartup

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The uniform code simulator

One format-parameterized simulator for deterministic machine codes: on
`⟨⟨bits t, α⟩, x⟩` it decides whether the machine that `α` denotes halts on `x`
with output exactly `[true]` within `t` steps, in time **one polynomial in
`|α| + |x| + t + 1` jointly**. The parameter is a `Turing.MachineFormat`: a
`Turing.CodeFormat` (12.2c item 8's parse layer) whose codes denote `k`-work-tape
binary machines in the fixed `k`-record serialization. The one-work-tape codes
(`Turing.oneTapeMachineFormat`) and the two-work-tape codes of `Codes2Tape` are
instances; they supply `Turing.exists_uniformMachineCode` (`Diagonalization/EXPCOM`)
and `Turing.exists_uniformMachineCode2` (`Codes2Tape`). [AB09, §1.4.1, Theorem 1.9;
the uniform form required by Example 3.6(3), audited at phase P3.2 round 2]

## Design

* **One interpreter, parameterized by the record grammar.** The table of a
  `k`-tape code is `3^(k+1)` `Turing.actionBitsK` records per state
  (`Turing.tableBitsK`); a single finite machine per format interprets it.
* **Canonize first, then interpret.** The decoded machine's serialization is
  computed in polynomial time (`Turing.MachineFormat.exists_polyCanonizer`):
  the binary state count and the minimum-length guard are checked before any
  state-indexed work, so a huge declared count is never expanded in unary.
* **The clock is §12.7's counter loop** (`Turing.counterLoopTM`) over the
  deadline's binary word; a simulated halt is a live body exit.
* **Status.** The canonizer `Turing.MachineFormat.exists_polyCanonizer` is proved, with
  no admission. A validator (`exists_canonDecider`) runs the two-port parse front end
  (`exists_canonParseFront`: header validity, canonicality and the binary length guard) and
  the grammar stage (`exists_canonGrammarStage`) on one bank and emits one verdict bit; the
  strip machine (`exists_canonStripTM`) or the constant fallback follows. The grammar stage
  checks the unary initial state against the header (the bounded unary reader
  `exists_canonUnaryTM`), runs two nested public counter loops, over `n + 1` states and
  `3^(k+1)` records each, on the fresh-anchor record round (`canonReturnAdapter` around the
  record validator `exists_canonRecordTM`), and tests the all-`true` suffix; its time is
  quadratic in the input length and independent of the header's value.
  The uniform simulator `Turing.MachineFormat.exists_uniformSimulator` is proved, with no
  admission: the interpreter startup (`Turing.exists_interpreterStartup`, with the canonizer
  installed) seamed to the binary deadline clock around the complete generic step block
  `Turing.StepBlock.roundTM` of `Build/StepBlock`, hosted on the virtual input, with its one-bit
  verdict (`h1HostedVerdict_accepts`), the clock being the public loop
  `Turing.StepBlock.hostedLoopTM_run` of `Build/StepBlockLoop`.

## Main definitions

* `Turing.serializeK`, `Turing.codeSkipTableK` — the fixed `k`-record serialization
  and grammar, over the table layout `Turing.workReadsK`, `Turing.tableBitsK` of
  `Build/StepBlock`.
* `Turing.serializeK_eq` — the serialization as an equation, the specification API (user,
  2026-10-16).
* `Turing.MachineFormat`, `Turing.MachineFormat.toFinTM` — the format parameter.
* `Turing.oneTapeMachineFormat` — the one-work-tape instance.

## Main results

* `Turing.tableBitsK_two`, `Turing.codeSkipTable2_eq_codeSkipTableK` — the
  two-work-tape bridges to `CodeFormat`'s frozen table writer and skipper.
* `Turing.MachineFormat.exists_polyCanonizer` — a polynomial-time canonizer.
* `Turing.MachineFormat.exists_uniformSimulator` — the uniform simulator.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (§1.4, §1.4.1, Theorem 1.9; Example 3.6(3).)
-/

namespace Turing

/-! ## The `k`-record layout -/

/-- The canonical serialization of a `k`-work-tape binary machine with `n + 1`
states: the binary state count, the unary initial state, the table. [AB09, §1.4] -/
def serializeK {k n : ℕ} (M : MultiTapeTM k Bool (Fin (n + 1))) : List Bool :=
  pairEncode n.bits (unaryFin M.q₀ ++ tableBitsK M.tr)

/-- **The serialization as an equation** (the specification API, user 2026-10-16): the doubled
binary state count, the separator, the unary initial state, then the table. Consumers read the
captured serialization through this equation (with `Turing.pairEncode_eq` and
`Turing.unaryFin_eq`), not by unfolding `Turing.serializeK`. -/
theorem serializeK_eq {k n : ℕ} (M : MultiTapeTM k Bool (Fin (n + 1))) :
    serializeK M = pairEncode n.bits (unaryFin M.q₀ ++ tableBitsK M.tr) :=
  rfl

/-- The table skipper of the `k`-record grammar: `n + 1` states of `3^(k+1)`
records each. [AB09, §1.4] -/
def codeSkipTableK (k n : ℕ) : List Bool → Option (List Bool) :=
  codeSkipRepeat ((fun r => codeSkipRepeat r 3)^[k + 1] (codeSkipActionK k n)) (n + 1)

/-- A one-tape read vector built by `Fin.cons` is the constant function. -/
private lemma fin_cons_one (w : Option Bool) :
    (Fin.cons w Fin.elim0 : Fin 1 → Option Bool) = fun _ => w := by
  funext i; fin_cases i; rfl

/-- A two-tape read vector built by `Fin.cons` is the `Turing.workPair` of its entries. -/
private lemma fin_cons_two (w₀ w₁ : Option Bool) :
    (Fin.cons w₀ (fun _ : Fin 1 => w₁) : Fin 2 → Option Bool) = workPair w₀ w₁ := by
  funext i; fin_cases i <;> rfl

/-- The one-work-tape reads are the constant functions, in table order. -/
lemma workReadsK_one : workReadsK 1 =
    ([none, some false, some true] : List (Option Bool)).map fun w => fun _ => w := by
  simp [workReadsK, fin_cons_one]

/-- The two-work-tape reads are the `Turing.workPair`s, in table order. -/
lemma workReadsK_two : workReadsK 2 =
    ([none, some false, some true] : List (Option Bool)).flatMap fun w₀ =>
      ([none, some false, some true] : List (Option Bool)).map fun w₁ => workPair w₀ w₁ := by
  simp [workReadsK, fin_cons_one, fin_cons_two]

/-- At two work tapes the generic table writer is `Turing.codeTable2Bits`. -/
lemma tableBitsK_two {n : ℕ}
    (tr : Fin (n + 1) → Option Bool → (Fin 2 → Option Bool) → Action 2 Bool (Fin (n + 1))) :
    tableBitsK tr = codeTable2Bits (fun q inp w₀ w₁ => tr q inp (workPair w₀ w₁)) := by
  unfold tableBitsK codeTable2Bits
  rw [workReadsK_two]
  simp only [List.flatMap_assoc, List.flatMap_map]

/-- At two work tapes the generic table skipper is `Turing.codeSkipTable2`. -/
lemma codeSkipTable2_eq_codeSkipTableK (n : ℕ) (xs : List Bool) :
    codeSkipTable2 n xs = codeSkipTableK 2 n xs := rfl

/-! ## Machine formats -/

/-- A **deterministic machine format**: a `Turing.CodeFormat` whose codes denote
`k`-work-tape binary machines, serialized in the fixed `k`-record layout and
parsed by the fixed `k`-record grammar. [AB09, §1.4] -/
structure MachineFormat extends CodeFormat where
  /-- the work-tape count of the coded machines -/
  k : ℕ
  /-- the machine a code denotes -/
  machine : (M : Code) → MultiTapeTM k Bool (Fin (numStates M + 1))
  /-- the format's serialization is the fixed `k`-record serialization -/
  serialize_eq : ∀ M, serialize M = serializeK (machine M)
  /-- the format's table skipper is the fixed `k`-record skipper -/
  skipTable_eq : ∀ n xs, skipTable n xs = codeSkipTableK k n xs

/-- The bundled machine a code of a machine format denotes. -/
def MachineFormat.toFinTM (F : MachineFormat) (M : F.Code) : FinTM Bool where
  k := F.k
  State := Fin (F.numStates M + 1)
  tm := F.machine M

/-- The one-tape format's table skipper is the generic skipper at one work tape: the
framed one-tape action skipper is `Turing.codeSkipActionK 1`. -/
private lemma oneTape_skipTable_eq (n : ℕ) (xs : List Bool) :
    oneTapeFormat.skipTable n xs = codeSkipTableK 1 n xs := by
  have h : codeSkipAction n = codeSkipActionK 1 n :=
    funext (codeSkipAction_eq_codeSkipActionK n)
  show codeSkipRepeat (codeSkipRepeat (codeSkipRepeat (codeSkipAction n) 3) 3) (n + 1) xs = _
  rw [h]; rfl

/-- The frozen one-tape serialization is the generic one at one work tape, record for
record (`Turing.workReadsK_one`, `Turing.actionBits_eq_actionBitsK`). -/
private lemma oneTape_serialize_eq (M : CodeTM) : M.serialize = serializeK M.tm := by
  unfold CodeTM.serialize serializeK tableBitsK
  rw [workReadsK_one]
  simp only [List.flatMap_map, actionBits_eq_actionBitsK]

/-- The one-work-tape code format `Turing.oneTapeFormat` as a machine format.
Its decoder is `Turing.codeDecode` and its bundled machines are
`Turing.CodeTM.toFinTM`, both definitionally. [AB09, §1.4] -/
def oneTapeMachineFormat : MachineFormat :=
  { oneTapeFormat with
    k := 1
    machine := fun M => M.tm
    serialize_eq := oneTape_serialize_eq
    skipTable_eq := oneTape_skipTable_eq }

namespace MachineFormat

variable (F : MachineFormat)

/-! ### Positive grammar bound (B5a fill preparation)

These lemmas justify the extra fail-fast guard even when `F.guard = 0`.
They concern the specified parser; the finite binary implementation and its
polynomial time ledger remain the canonizer's continuation obligation.
-/

/-- Iterated skipping consumes the sum of the per-record lower bounds.

**Proof sketch.** Split off the first successful skip, apply the induction
hypothesis to its suffix, and add the two length inequalities. -/
private lemma skipRepeat_consumes (r : List Bool → Option (List Bool)) (b : ℕ)
    (hr : ∀ xs ys, r xs = some ys → b + ys.length ≤ xs.length)
    (m : ℕ) (xs ys : List Bool) (h : codeSkipRepeat r m xs = some ys) :
    b * m + ys.length ≤ xs.length := by
  induction m generalizing xs with
  | zero =>
    have heq : xs = ys := Option.some.inj h
    simp [heq]
  | succ m ih =>
    obtain ⟨zs, hz, hy⟩ := Option.bind_eq_some_iff.mp h
    have hfirst := hr xs zs hz
    have hrest := ih zs hy
    rw [Nat.mul_succ]
    omega

/-- Nesting a three-symbol reader multiplies its consumption bound by three. -/
private lemma skipSymbols_consumes (r : List Bool → Option (List Bool)) (b : ℕ)
    (hr : ∀ xs ys, r xs = some ys → b + ys.length ≤ xs.length)
    (j : ℕ) (xs ys : List Bool)
    (h : ((fun f => codeSkipRepeat f 3)^[j] r) xs = some ys) :
    b * 3 ^ j + ys.length ≤ xs.length := by
  induction j generalizing xs ys with
  | zero => simpa using hr xs ys h
  | succ j ih =>
    rw [Function.iterate_succ_apply'] at h
    have hb := skipRepeat_consumes _ (b * 3 ^ j) (fun u v huv => ih u v huv)
      3 xs ys h
    simpa only [Nat.pow_succ, Nat.mul_assoc] using hb

/-- A successful table skip consumes a positive number of bits per state,
independently of the format's optional guard. -/
private lemma skipTable_consumes (k n : ℕ) (xs ys : List Bool)
    (h : codeSkipTableK k n xs = some ys) :
    (4 * k + 5) * 3 ^ (k + 1) * (n + 1) + ys.length ≤ xs.length := by
  have ha (u v : List Bool) (hu : codeSkipActionK k n u = some v) :
      4 * k + 5 + v.length ≤ u.length := by
    rw [← codeEraseActionK] at hu
    obtain ⟨⟨a, rest⟩, hread, rfl⟩ := Option.map_eq_some_iff.mp hu
    rw [codeReadActionK_sound u a rest hread, List.length_append]
    exact Nat.add_le_add_right (codeActionK_length a) _
  exact skipRepeat_consumes _ _ (fun u v huv =>
    skipSymbols_consumes _ _ ha (k + 1) u v huv) (n + 1) xs ys h

/-- A successful scanner satisfies the positive grammar guard already on the
suffix following the binary header. This holds also for a zero format guard.

**Proof sketch.** Decompose the successful scanner into its header, initial-state
and table checks. Erasure and initial-state reader soundness show that the table
input is a suffix of the header remainder. Apply the generic table-skip bound
and discard the nonnegative final-suffix length. -/
private lemma scan_grammar_guard (α bits rest tail : List Bool)
    (hp : pairDecode α = some (bits, rest)) (hs : F.scan α = some tail) :
    (4 * F.k + 5) * 3 ^ (F.k + 1) * (codeBitsNat bits + 1) ≤ rest.length := by
  unfold CodeFormat.scan at hs
  rw [hp] at hs
  dsimp only [bind, Option.bind] at hs
  split at hs
  · contradiction
  split at hs
  · contradiction
  obtain ⟨table, hq, ht⟩ := Option.bind_eq_some_iff.mp hs
  obtain ⟨suffix, htable, _⟩ := Option.bind_eq_some_iff.mp ht
  rw [F.skipTable_eq] at htable
  have hlen := skipTable_consumes F.k (codeBitsNat bits) table suffix htable
  rw [← codeEraseFin] at hq
  obtain ⟨⟨q, r⟩, hread, rfl⟩ := Option.map_eq_some_iff.mp hq
  have hword := codeReadFin_sound rest q r hread
  have hrest : r.length ≤ rest.length := by
    rw [hword, List.length_append]
    omega
  dsimp only at hlen
  omega

/-- Reject a binary header whose declared table cannot fit in the remaining
input, before evaluating the format scanner. This is a specification function,
not yet a certified finite-machine implementation. -/
private def guardedScan (α : List Bool) : Option (List Bool) := do
  let (bits, rest) ← pairDecode α
  if rest.length < (4 * F.k + 5) * 3 ^ (F.k + 1) * (codeBitsNat bits + 1)
    then none else F.scan α

/-- The additional positive guard preserves the scanner exactly.

**Proof sketch.** Header failure already fails the scanner. If the new guard
fails, any hypothetical successful scan contradicts `scan_grammar_guard`;
otherwise the guarded scanner calls the original scanner. -/
private lemma guardedScan_eq (α : List Bool) : guardedScan F α = F.scan α := by
  unfold guardedScan
  cases hp : pairDecode α with
  | none => simp [CodeFormat.scan, hp]
  | some p =>
    rcases p with ⟨bits, rest⟩
    dsimp only [bind, Option.bind]
    split
    next hg =>
      cases hs : F.scan α with
      | none => rfl
      | some tail =>
        have := scan_grammar_guard F α bits rest tail hp hs
        omega
    · rfl

/-- Early failure of the positive grammar guard selects exactly the prescribed
fallback, including for a zero guard and a potentially accepting fallback. -/
private lemma decode_of_grammar_guard (α bits rest : List Bool)
    (hp : pairDecode α = some (bits, rest))
    (hg : rest.length < (4 * F.k + 5) * 3 ^ (F.k + 1) * (codeBitsNat bits + 1)) :
    F.decode α = F.fallback := by
  have hs : F.scan α = none := by
    rw [← guardedScan_eq]
    simp [guardedScan, hp, hg]
  have hparse : F.parseFull α = none := by
    rw [F.scan_full] at hs
    exact Option.map_eq_none_iff.mp hs
  exact F.decode_of_parseFull_none α hparse

/-- Passing the positive guard bounds state-count work by the available input. -/
private lemma grammar_guard_states (n s : ℕ)
    (h : (4 * F.k + 5) * 3 ^ (F.k + 1) * (n + 1) ≤ s) : n + 1 ≤ s := by
  have hc : 1 ≤ (4 * F.k + 5) * 3 ^ (F.k + 1) :=
    Nat.mul_pos (by omega) (Nat.pow_pos (by omega))
  have hs : n + 1 ≤ (4 * F.k + 5) * 3 ^ (F.k + 1) * (n + 1) := by
    simpa using Nat.mul_le_mul_right (n + 1) hc
  exact hs.trans h

/-! ### Physical binary-header loading (B5a continuation) -/

/-- The undoubled header, or the empty word when the pair grammar fails.
The later validation phase must distinguish failure from a valid zero header. -/
private def canonHeader (α : List Bool) : List Bool :=
  ((pairDecode α).map Prod.fst).getD []

/-- Loading a doubled header never produces more bits than the source input. -/
private lemma canonHeader_length (α : List Bool) : (canonHeader α).length ≤ α.length := by
  cases hp : pairDecode α with
  | none => simp [canonHeader, hp]
  | some p =>
    rcases p with ⟨bits, rest⟩
    have he := congrArg List.length (eq_pairEncode_of_pairDecode α bits rest hp)
    rw [length_pairEncode] at he
    simp only [canonHeader, hp, Option.map_some, Option.getD_some]
    omega

/-- A physical linear-time header loader installs the binary header on tape
zero and restores a clean seam with the original native input available.

**Proof sketch.** Install the public pair-first extractor through the public
native-input call row. The header length is at most the original input length,
so the call row's ledger is linear as well. No parsing or host trace is copied. -/
private lemma exists_canonHeaderCall :
    ∃ (C : FinTM Bool) (entry exit : C.State) (a : ℕ), 0 < C.k ∧
      ∀ α : List Bool, ∃ t ≤ a * (α.length + 1), 0 < t ∧
        (∀ u, 0 < u → u < t →
          (C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) u).state ≠
            some exit) ∧
        C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) t =
          Cfg.ofWords exit (stateWord C.k (canonHeader α)) := by
  obtain ⟨M, a, hM⟩ := FinTM.computesFunInTime_pairFst
  obtain ⟨C, entry, exit, c, hk, hC⟩ :=
    FinTM.exists_inputCallTM M canonHeader (fun n => a * (n + 1)) hM
  refine ⟨C, entry, exit, c * (a + 2), hk, ?_⟩
  intro α
  obtain ⟨t, ht, hpos, hcut, hrun⟩ := hC α
  refine ⟨t, ht.trans ?_, hpos, hcut, hrun⟩
  have hlen := canonHeader_length α
  calc
    c * (a * (α.length + 1) + α.length + (canonHeader α).length + 1) ≤
        c * (a * (α.length + 1) + 2 * (α.length + 1)) :=
      Nat.mul_le_mul_left c (by omega)
    _ = _ := by ring

/-! ### Physical fail-fast length guard (B5a continuation)

The catalog has whole-input scans but no fixed-block input scan with a short-input
exit. The following body supplies that missing finite controller; the binary
countdown itself is the public `counterLoopTM`, not a new loop implementation.
The body has no work tapes and never emits. Its block length is `b + 1`, so
even the zero-format-guard case can use the positive grammar minimum.
-/

/-- Progress through a fixed positive block; `none` is the short-input exit. -/
private def guardPhase (b u : ℕ) : Option (Fin (b + 1)) :=
  some ⟨u % (b + 1), Nat.mod_lt _ (Nat.succ_pos _)⟩

/-- Read at most `b + 1` actual input symbols, returning to the anchor after
one whole block and taking a distinct live exit on a boundary blank. -/
private def guardBlockTM (b : ℕ) : MultiTapeTM 0 Bool (Option (Fin (b + 1))) where
  q₀ := guardPhase b 0
  tr := fun q inp _ => match q with
    | none => inputMoveAction 0 none
    | some i => if inp.isSome then
        inputMoveAction 1 (guardPhase b (i.val + 1))
      else inputMoveAction 0 none

/-- A block-scan configuration after `j` input cells have been consumed. -/
private def guardCfg (b : ℕ) (x : List Bool) (q : Option (Fin (b + 1)))
    (j : ℕ) (hj : j ≤ x.length) (out : List Bool) :
    Cfg 0 Bool (Option (Fin (b + 1))) x :=
  ⟨some q, ⟨j + 1, by omega⟩, Fin.elim0, Fin.elim0, out⟩

/-- The finite block controller advances one cell without writing or emitting.
The input-only action law supplies all unchanged configuration fields. -/
private lemma guardBlock_step (b : ℕ) (x : List Bool) (u j : ℕ)
    (hu : u < b + 1) (hj : j < x.length) (out : List Bool) :
    (guardBlockTM b).step (guardCfg b x (guardPhase b u) j (by omega) out) =
      guardCfg b x (guardPhase b (u + 1)) (j + 1) (by omega) out := by
  have hr := inputSymbolInner
    (cfg := guardCfg b x (guardPhase b u) j (by omega) out) j (by dsimp [guardCfg]; omega) hj
  rw [step_of_inputMoveAction (guardBlockTM b) _ (q' := guardPhase b (u + 1)) 1 rfl (by
    change (if (guardCfg b x (guardPhase b u) j (by omega) out).inputSymbol.isSome then
      inputMoveAction 1 (guardPhase b (u % (b + 1) + 1)) else inputMoveAction 0 none) = _
    rw [hr]
    simp only [Option.isSome_some, if_true, Nat.mod_eq_of_lt hu])]
  apply Cfg.ext_zero_tapes
  · rfl
  · apply Fin.ext
    change (moveInputPos (guardCfg b x (guardPhase b u) j (by omega) out).inputPos
      SignType.pos).val = j + 1 + 1
    rw [moveInputPos_pos_of_ne_right _ (by dsimp [guardCfg]; omega)]
    rfl
  · rfl

/-- Every available prefix of one block is traversed in exactly its length.

**Proof sketch.** Induct on the traversed prefix and apply the input-only
one-step contract. The upper bound prevents an intermediate anchor return. -/
private lemma guardBlock_run (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out : List Bool) (u : ℕ)
    (hu : u ≤ b + 1) (hlen : j + u ≤ x.length) :
    (guardBlockTM b).runFrom (guardCfg b x (guardPhase b 0) j hj out) u =
      guardCfg b x (guardPhase b u) (j + u) hlen out := by
  induction u with
  | zero => rfl
  | succ u ih =>
    rw [MultiTapeTM.runFrom_succ_eq_step', ih (by omega) (by omega)]
    simpa only [Nat.add_assoc] using
      guardBlock_step b x u (j + u) (by omega) (by omega) out

/-- At the right input blank, the next transition takes the short-input exit. -/
private lemma guardBlock_blank (b : ℕ) (x : List Bool) (u : ℕ) (out : List Bool) :
    (guardBlockTM b).step
        (guardCfg b x (guardPhase b u) x.length le_rfl out) =
      guardCfg b x none x.length le_rfl out := by
  rw [step_of_inputMoveAction (guardBlockTM b) _ (q' := none) 0 rfl (by
    simp [guardBlockTM, guardPhase, Cfg.inputSymbol, guardCfg])]
  simp only [moveInputPos_zero]
  rfl

/-- A short block exits immediately after reading its remaining symbols.
In particular the running time does not depend on the declared state count. -/
private lemma guardBlock_short (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (hshort : x.length - j < b + 1) (out : List Bool) :
    (guardBlockTM b).runFrom (guardCfg b x (guardPhase b 0) j hj out)
        (x.length - j + 1) = guardCfg b x none x.length le_rfl out := by
  rw [MultiTapeTM.runFrom_succ_eq_step',
    guardBlock_run b x j hj out (x.length - j) (by omega) (by omega)]
  have hpos : j + (x.length - j) = x.length := by omega
  simpa only [hpos] using guardBlock_blank b x (x.length - j) out

/-- Exact duration of a block: its fixed size, or the available suffix plus
one transition detecting the blank, whichever is smaller. -/
private def guardTime (b : ℕ) {x : List Bool}
    (c : Cfg 0 Bool (Option (Fin (b + 1))) x) : ℕ :=
  min (b + 1) (x.length + 2 - c.inputPos.val)

/-- Before the end of a block, neither live exit has been reached.

**Proof sketch.** Every strict-interior time is smaller than the block size
and traverses only existing input cells. Its progress index is strictly
positive and below the modulus, so it is neither the anchor nor the failure. -/
private lemma guardBlock_interior (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out : List Bool) (u : ℕ) (hu : 0 < u)
    (ht : u < guardTime b (guardCfg b x (guardPhase b 0) j hj out)) :
    ∃ s, ((guardBlockTM b).runFrom
        (guardCfg b x (guardPhase b 0) j hj out) u).state = some s ∧
      s ≠ guardPhase b 0 ∧ s ≠ none := by
  have hb : u < b + 1 := lt_of_lt_of_le ht (Nat.min_le_left _ _)
  have hl : j + u ≤ x.length := by
    have := lt_of_lt_of_le ht (Nat.min_le_right _ _)
    dsimp [guardCfg] at this
    omega
  rw [guardBlock_run b x j hj out u (by omega) hl]
  refine ⟨guardPhase b u, rfl, ?_, Option.some_ne_none _⟩
  intro he
  have hv := congrArg (fun q => q.map Fin.val) he
  simp [guardPhase, Nat.mod_eq_of_lt hb] at hv
  omega

/-- The physical binary guard is the shared counter loop with the block
controller as body. It has exactly one work tape, holding the binary count. -/
private def binaryGuardTM (b : ℕ) :
    MultiTapeTM 1 Bool (CounterLoopState (Option (Fin (b + 1)))) :=
  counterLoopTM (guardBlockTM b) (guardPhase b 0) (some none)

/-- Guard entry with the binary counter delimited at the origin. The original
input remains native, so the caller can rewind and parse it after the guard. -/
private def binaryGuardStart (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out w : List Bool) :
    Cfg 1 Bool (CounterLoopState (Option (Fin (b + 1)))) x :=
  counterLoopCfg (some (.dec .run))
    (guardCfg b x (guardPhase b 0) j hj out) (FinTM.bufferTape w) 0

/-- While whole blocks fit, the body orbit advances by their combined length.

**Proof sketch.** Induct on the number of blocks. The next full block takes
`b + 1` transitions by `guardBlock_run`, returns its finite progress index to
zero, and preserves the output. This is a body-orbit calculation; the physical
counter is handled solely by the public counter-loop contracts. -/
private lemma guardBlock_orbit (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out : List Bool) (r : ℕ)
    (hr : j + (b + 1) * r ≤ x.length) :
    counterLoopOrbit (guardBlockTM b) (guardTime b)
        (guardCfg b x (guardPhase b 0) j hj out) r =
      guardCfg b x (guardPhase b 0) (j + (b + 1) * r) hr out := by
  induction r with
  | zero => rfl
  | succ r ih =>
    have hprev : j + (b + 1) * r ≤ x.length := by
      rw [Nat.mul_succ] at hr
      omega
    change (fun c => (guardBlockTM b).runFrom c (guardTime b c))^[r + 1] _ = _
    rw [Function.iterate_succ_apply']
    change (guardBlockTM b).runFrom
      (counterLoopOrbit (guardBlockTM b) (guardTime b)
        (guardCfg b x (guardPhase b 0) j hj out) r)
      (guardTime b (counterLoopOrbit (guardBlockTM b) (guardTime b)
        (guardCfg b x (guardPhase b 0) j hj out) r)) = _
    rw [ih hprev]
    have ht : guardTime b
        (guardCfg b x (guardPhase b 0) (j + (b + 1) * r) hprev out) = b + 1 := by
      dsimp [guardTime, guardCfg]
      rw [Nat.min_eq_left]
      rw [Nat.mul_succ] at hr
      omega
    rw [ht, guardBlock_run b x _ hprev out (b + 1) le_rfl (by
      rw [Nat.mul_succ] at hr
      omega)]
    simp only [guardPhase, Nat.mod_self, Nat.zero_mod, Nat.mul_succ, Nat.add_assoc]

/-- Each block is a positive first-return-or-exit segment, including an empty
suffix. This is the hypothesis shared by the returning and escaping host rows. -/
private lemma guardBlock_segment (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out : List Bool) :
    let c := guardCfg b x (guardPhase b 0) j hj out
    c.state = some (guardPhase b 0) ∧ 0 < guardTime b c ∧
      (∀ u, 0 < u → u < guardTime b c →
        ∃ s, ((guardBlockTM b).runFrom c u).state = some s ∧
          s ≠ guardPhase b 0 ∧ s ≠ none) := by
  refine ⟨rfl, ?_, guardBlock_interior b x j hj out⟩
  dsimp [guardTime, guardCfg]
  omega

/-- If the requested whole blocks fit, the physical guard reaches `done`,
silently, in linear time in the input length and the binary counter width.

**Proof sketch.** The body orbit supplies the counter host's first-return
hypotheses. Its exact run is the existing `counterLoopTM_run_done`; its
ledger is `counterLoop_time_le`. Both the number of rounds and their total
input consumption are bounded by the actual input length. -/
private lemma binaryGuard_done (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out w : List Bool)
    (hfit : j + (b + 1) * Nat.ofDigits 2 (w.map Bool.toNat) ≤ x.length) :
    ∃ T ≤ 5 * x.length + 2 * w.length + 2,
      let c := (binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) T
      c.state = some .done ∧ c.output = out ∧
        c.inputPos.val = j + (b + 1) * Nat.ofDigits 2 (w.map Bool.toNat) + 1 ∧
        (∀ u < T,
          ((binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) u).state ≠
            some .done ∧
          ((binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) u).state ≠
            some .escape) := by
  let d := Nat.ofDigits 2 (w.map Bool.toNat)
  let c := guardCfg b x (guardPhase b 0) j hj out
  have hpos (r : ℕ) (hr : r ≤ d) : j + (b + 1) * r ≤ x.length :=
    (Nat.add_le_add_left (Nat.mul_le_mul_left (b + 1) hr) j).trans hfit
  have horbit (r : ℕ) (hr : r ≤ d) :
      counterLoopOrbit (guardBlockTM b) (guardTime b) c r =
        guardCfg b x (guardPhase b 0) (j + (b + 1) * r) (hpos r hr) out :=
    guardBlock_orbit b x j hj out r (hpos r hr)
  let T := (∑ r ∈ Finset.range d,
    guardTime b (counterLoopOrbit (guardBlockTM b) (guardTime b) c r)) +
      counterOverhead w (d + 1)
  have hrun := counterLoopTM_run_done (guardBlockTM b) (guardPhase b 0) (some none)
    (guardTime b) c w (FinTM.bufferTape w) 0 (by intro p _ _; simp) d rfl
    (by
      intro r hr
      rw [horbit r (by omega), horbit (r + 1) (by omega)]
      obtain ⟨hs, ht, hi⟩ := guardBlock_segment b x _ (hpos r (by omega)) out
      refine ⟨hs, ht, ?_, rfl⟩
      intro u hu hut
      obtain ⟨s, hsu, hsa, hse⟩ := hi u hu hut
      exact ⟨s, hsu, hsa, fun he => hse (Option.some.inj he).symm⟩) T rfl
  have ht := counterLoop_time_le (guardBlockTM b) (guardTime b) c w d rfl (b + 1)
    (fun _ _ => Nat.min_le_left _ _)
  have hd : d ≤ (b + 1) * d := by
    simpa using Nat.mul_le_mul_right d (show 1 ≤ b + 1 by omega)
  refine ⟨T, ?_, ?_⟩
  · dsimp [T]
    rw [Nat.mul_comm d (b + 1)] at ht
    dsimp [d] at ht hd ⊢
    omega
  · dsimp only
    have he : (binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) T = _ := hrun.1
    rw [he, horbit d le_rfl]
    exact ⟨rfl, rfl, rfl, hrun.2.1⟩

/-- If the requested blocks do not fit, the physical guard reaches `escape`
in time independent of the value represented by the binary counter.

**Proof sketch.** Divide the available input length by the positive block
size. Exactly that many full body rounds fit, and the next round detects the
right blank. Apply the public escaping counter-host contract and its prefix
amortization bound; there are at most `|x| + 1` attempted rounds. -/
private lemma binaryGuard_escape (b : ℕ) (x : List Bool) (j : ℕ)
    (hj : j ≤ x.length) (out w : List Bool)
    (hshort : x.length < j + (b + 1) * Nat.ofDigits 2 (w.map Bool.toNat)) :
    ∃ T ≤ (b + 5) * (x.length + 1) + 2 * w.length,
      let c := (binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) T
      c.state = some .escape ∧ c.output = out ∧ c.inputPos.val = x.length + 1 ∧
        (∀ u < T,
          ((binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) u).state ≠
            some .done ∧
          ((binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) u).state ≠
            some .escape) := by
  let r₀ := (x.length - j) / (b + 1)
  let c := guardCfg b x (guardPhase b 0) j hj out
  have hdiv := Nat.mod_add_div (x.length - j) (b + 1)
  have hmod := Nat.mod_lt (x.length - j) (Nat.succ_pos b)
  have hstart : j + (b + 1) * r₀ ≤ x.length := by dsimp [r₀]; omega
  have hlast : x.length - (j + (b + 1) * r₀) < b + 1 := by
    rw [← Nat.sub_sub]
    change (x.length - j) - (b + 1) * ((x.length - j) / (b + 1)) < b + 1
    rw [← Nat.mod_eq_sub_mul_div]
    exact hmod
  have hr₀ : r₀ < Nat.ofDigits 2 (w.map Bool.toNat) := by
    by_contra hn
    have hm := Nat.mul_le_mul_left (b + 1) (Nat.le_of_not_gt hn)
    omega
  have hpos (r : ℕ) (hr : r ≤ r₀) : j + (b + 1) * r ≤ x.length :=
    (Nat.add_le_add_left (Nat.mul_le_mul_left (b + 1) hr) j).trans hstart
  have horbit (r : ℕ) (hr : r ≤ r₀) :
      counterLoopOrbit (guardBlockTM b) (guardTime b) c r =
        guardCfg b x (guardPhase b 0) (j + (b + 1) * r) (hpos r hr) out :=
    guardBlock_orbit b x j hj out r (hpos r hr)
  have hexit : counterLoopOrbit (guardBlockTM b) (guardTime b) c (r₀ + 1) =
      guardCfg b x none x.length le_rfl out := by
    change (fun z => (guardBlockTM b).runFrom z (guardTime b z))^[r₀ + 1] c = _
    rw [Function.iterate_succ_apply']
    change (guardBlockTM b).runFrom
      (counterLoopOrbit (guardBlockTM b) (guardTime b) c r₀)
      (guardTime b (counterLoopOrbit (guardBlockTM b) (guardTime b) c r₀)) = _
    rw [horbit r₀ le_rfl]
    have ht : guardTime b
        (guardCfg b x (guardPhase b 0) (j + (b + 1) * r₀) hstart out) =
        x.length - (j + (b + 1) * r₀) + 1 := by
      dsimp [guardTime, guardCfg]
      omega
    rw [ht]
    exact guardBlock_short b x _ hstart hlast out
  let T := (∑ r ∈ Finset.range (r₀ + 1),
    guardTime b (counterLoopOrbit (guardBlockTM b) (guardTime b) c r)) +
      counterOverhead w (r₀ + 1)
  have hrun := counterLoopTM_run_escape (guardBlockTM b) (guardPhase b 0) none
    (by simp [guardPhase]) (guardTime b) c w (FinTM.bufferTape w) 0
    (by intro p _ _; simp) r₀ hr₀ (by
      intro r hr
      rw [horbit r hr]
      exact guardBlock_segment b x _ (hpos r hr) out)
    (by rw [hexit]; rfl) T rfl
  have hs : (∑ r ∈ Finset.range (r₀ + 1),
      guardTime b (counterLoopOrbit (guardBlockTM b) (guardTime b) c r)) ≤
        (r₀ + 1) * (b + 1) := by
    calc
      _ ≤ ∑ _r ∈ Finset.range (r₀ + 1), (b + 1) :=
        Finset.sum_le_sum (fun _ _ => Nat.min_le_left _ _)
      _ = _ := by simp
  have hc := counterOverhead_le_of_le w (r₀ + 1) (by omega)
  have hn : r₀ + 1 ≤ x.length + 1 := by
    have := Nat.mul_le_mul_right r₀ (show 1 ≤ b + 1 by omega)
    simp only [one_mul] at this
    omega
  refine ⟨T, ?_, ?_⟩
  · calc
      T ≤ (r₀ + 1) * (b + 1) + (4 * (r₀ + 1) + 2 * w.length) :=
        Nat.add_le_add hs hc
      _ = (b + 5) * (r₀ + 1) + 2 * w.length := by ring
      _ ≤ _ := Nat.add_le_add_right (Nat.mul_le_mul_left (b + 5) hn) _
  · dsimp only
    have he : (binaryGuardTM b).runFrom (binaryGuardStart b x j hj out w) T = _ := hrun.1
    rw [he, hexit]
    exact ⟨rfl, rfl, rfl, hrun.2.1⟩



/-- The last bit, with the empty word accepted as canonical zero. -/
private def canonBitsOK (w : List Bool) : Bool := w.getLast?.getD true

/-- A last-symbol fold has exactly the finite scan's canonicality verdict. -/
private lemma canonBits_fold (w : List Bool) (a : Bool) :
    w.foldl (fun _ b => b) a = w.getLast?.getD a := by
  induction w generalizing a with
  | nil => rfl
  | cons b w ih =>
    simp only [List.foldl_cons, ih, List.getLast?_cons, Option.getD_some]

/-- A finite last-bit check suffices to recover the canonical binary word.

**Proof sketch.** Remove the low bit. A nonempty canonical tail has positive
value, so adjoining either low bit is exactly the binary constructor law;
the singleton case admits only the bit one. -/
private lemma canonBits_of_last (w : List Bool) :
    canonBitsOK w = true → (w.foldr Nat.bit 0).bits = w := by
  induction w with
  | nil => intro _; simp
  | cons b w ih =>
    intro h
    cases w with
    | nil => cases b <;> simp_all [canonBitsOK, Nat.bit]
    | cons c w =>
      have htail : canonBitsOK (c :: w) = true := by
        simpa only [canonBitsOK, List.getLast?_cons_cons] using h
      have he := ih htail
      have hne : (c :: w).foldr Nat.bit 0 ≠ 0 := by
        intro hz
        simp only [hz, Nat.zero_bits] at he
        contradiction
      rw [List.foldr_cons, Nat.bits_append_bit _ b (fun hz => (hne hz).elim), he]

/-- Canonical natural-number digits pass the finite last-bit check.

**Proof sketch.** Use the public binary recursion from zero and one, so every
extension has a nonzero tail. The public decoding identity shows that such
a tail has nonempty digits; its last bit is unchanged by the extension. -/
private lemma canonBits_bits (n : ℕ) : canonBitsOK n.bits = true := by
  refine Nat.binaryRecFromOne (motive := fun m => canonBitsOK m.bits = true)
    (by simp [canonBitsOK]) (by simp [canonBitsOK]) ?_ n
  intro low tail nonzero canonical
  have nonempty : tail.bits ≠ [] := by
    intro hempty
    have decoded := codeBitsNat_bits tail
    rw [hempty] at decoded
    exact nonzero decoded.symm
  rw [Nat.bits_append_bit tail low (fun hz => (nonzero hz).elim)]
  cases htail : tail.bits with
  | nil => exact (nonempty htail).elim
  | cons first rest =>
    simpa only [canonBitsOK, htail, List.getLast?_cons_cons] using canonical

/-- The finite check recognizes exactly the canonical little-endian words. -/
private lemma canonBitsOK_iff (w : List Bool) :
    canonBitsOK w = true ↔ w = (w.foldr Nat.bit 0).bits := by
  constructor
  · intro h
    exact (canonBits_of_last w h).symm
  · intro h
    calc
      canonBitsOK w = canonBitsOK (w.foldr Nat.bit 0).bits := congrArg canonBitsOK h
      _ = true := canonBits_bits _

/-- A spare high zero makes the state-count successor nonoverflowing. -/
private def canonCount (w : List Bool) : List Bool :=
  (incFixed (w ++ [false])).getD []

/-- Incrementing with a spare high zero preserves the enlarged width and
represents one more than the original header, including the empty header.

**Proof sketch.** Follow the carry through the low one bits. At the first
zero the increment stops; the appended zero guarantees that this happens.
Each recursive carry doubles the value equation. -/
private lemma canonCount_spec (w : List Bool) :
    incFixed (w ++ [false]) = some (canonCount w) ∧
      (canonCount w).length = w.length + 1 ∧
      (canonCount w).foldr Nat.bit 0 = w.foldr Nat.bit 0 + 1 := by
  induction w with
  | nil => simp [canonCount, incFixed, Nat.bit]
  | cons b w ih =>
    cases b with
    | false =>
      simp [canonCount, incFixed, List.foldr_append, Nat.bit]
    | true =>
      have he : canonCount (true :: w) = false :: canonCount w := by
        change ((incFixed (w ++ [false])).map (false :: ·)).getD [] = _
        rw [ih.1]
        rfl
      rw [he]
      simp only [List.cons_append, incFixed, ih.1, Option.map_some,
        List.length_cons, ih.2.1, List.foldr_cons, ih.2.2, Nat.bit]
      simp [Nat.mul_add, Nat.add_assoc]

/-- The canonical-bit checker is the public two-pass scan, with the last
symbol as accumulator and an identity return pass. -/
private def canonBitsTM (k : ℕ) (i : Fin k) : MultiTapeTM k Bool (ScanPhase Bool) :=
  scanTM k i (scanFold (fun _ b => b)) scanKeep true

/-- The canonicality scan preserves every seam word, the native input
position and the empty output, and avoids both verdict anchors until its
exact linear-time return.

**Proof sketch.** Specialize the public scan contract to the last-bit fold.
Its pure result preserves the scanned word, so the interval rewrite is the
original buffer at every cell. The shared contract supplies both exit cuts. -/
private lemma canonBitsTM_run (k : ℕ) (i : Fin k) (α : List Bool)
    (w : Fin k → List Bool) :
    (canonBitsTM k i).runFrom (Cfg.ofWords (input := α) (.fwd true) w)
        (2 * (w i).length + 2) = Cfg.ofWords (.done (canonBitsOK (w i))) w ∧
      (∀ t < 2 * (w i).length + 2, ∀ b,
        ((canonBitsTM k i).runFrom (Cfg.ofWords (input := α) (.fwd true) w) t).state ≠
          some (.done b)) := by
  let d := Cfg.ofWords (input := α) (ScanPhase.fwd true) w
  have h := scanTM_run_ofCfg i (scanFold (fun (_ : Bool) b => b)) scanKeep true
    (w i) d rfl (by intro p _ _; simp [d, Cfg.ofWords])
  rw [scanResult_fold, canonBits_fold] at h
  refine ⟨h.1.trans ?_, h.2.1⟩
  apply Cfg.ext <;> try rfl
  funext j z
  dsimp only [d, Cfg.ofWords]
  split_ifs with hz
  · rcases hz with ⟨rfl, _, _⟩
    simp
  · rfl

/-- A strict first-return form of the inherited physical header call, ready
for the public seam combinator even when the original anchors coincide.

**Proof sketch.** If the original anchors differ, time zero is excluded by
that inequality. If they coincide, apply the public release adapter, whose
fresh entry executes the call before any return can be dispatched. The
machine and all tape/output data are otherwise those of the inherited call. -/
private lemma exists_canonHeaderSeam :
    ∃ (C : FinTM Bool) (entry exit : C.State) (a : ℕ), 0 < C.k ∧
      ∀ α : List Bool, ∃ t ≤ a * (α.length + 1), 0 < t ∧
        (∀ u < t,
          (C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) u).state ≠
            some exit) ∧
        C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) t =
          Cfg.ofWords exit (stateWord C.k (canonHeader α)) := by
  classical
  obtain ⟨C, entry, exit, a, hk, hC⟩ := exists_canonHeaderCall
  by_cases he : entry = exit
  · subst exit
    let R : FinTM Bool := {
      k := C.k
      State := Unit ⊕ C.State
      tm := seamReleaseTM C.tm entry }
    refine ⟨R, Sum.inl (), Sum.inr entry, a, hk, ?_⟩
    intro α
    obtain ⟨t, ht, hpos, hcut, hrun⟩ := hC α
    have hr := seamReleaseTM_firstReturn C.tm entry rfl hpos hrun rfl hcut
    refine ⟨t, ht, hpos, ?_, ?_⟩
    · simpa only [R, Cfg.ofWords, Cfg.mapState, Option.map_some] using hr.2
    · simpa only [R, Cfg.ofWords, Cfg.mapState, Option.map_some] using hr.1
  · refine ⟨C, entry, exit, a, hk, ?_⟩
    intro α
    obtain ⟨t, ht, hpos, hcut, hrun⟩ := hC α
    refine ⟨t, ht, hpos, ?_, hrun⟩
    intro u hu
    by_cases hz : u = 0
    · subst u
      change some entry ≠ some exit
      exact fun h => he (Option.some.inj h)
    · exact hcut u (by omega) hu

/-- The nonoverflowing count word is computed in linear time by two public
primitives: append a zero, then increment at that fixed width.

**Proof sketch.** Compose the append-bit and fixed-width increment machines.
Their linear budgets compose to a linear budget; the added constant is
absorbed using the positive input-length offset. -/
private lemma exists_canonCountTM :
    ∃ (M : FinTM Bool) (a : ℕ),
      M.ComputesFunInTime canonCount (fun n => a * (n + 1)) := by
  obtain ⟨A, a, hA⟩ := FinTM.computesFunInTime_appendBit false
  obtain ⟨B, b, hB⟩ := FinTM.computesFunInTime_incFixed
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_comp hA hB
    (fun _ _ h => Nat.mul_le_mul_left b (by omega))
  refine ⟨M, c * (a + b * (a + 1) + 1), ?_⟩
  intro w
  apply (hM w).mono
  calc
    c * (a * (w.length + 1) + b * (a * (w.length + 1) + 1) + 1) ≤
        c * ((a * (w.length + 1) + b * (a * (w.length + 1) + 1) + 1) +
          (b + 1) * w.length) := Nat.mul_le_mul_left c (Nat.le_add_right _ _)
    _ = _ := by ring

/-- Emit the scan's verdict on its final transition. All scanning transitions
are the existing public scan; only its live exits receive a halting action. -/
private def canonVerdictTM (k : ℕ) (i : Fin k) : MultiTapeTM k Bool (ScanPhase Bool) where
  q₀ := .fwd true
  tr := fun q inp work => match q with
    | .done b => ⟨0, fun _ => (none, 0), some b, none⟩
    | _ => (canonBitsTM k i).tr q inp work

/-- From a loaded word, the verdict wrapper halts with exactly its canonicality
bit after the public scan and one emitting transition.

**Proof sketch.** The scan avoids both verdict states until its return. Apply
the public guarded-agreement transfer on those states, then execute the one
new halting action. No scan trace is re-proved. -/
private lemma canonVerdictTM_run (k : ℕ) (i : Fin k) (α : List Bool)
    (w : Fin k → List Bool) :
    let c := (canonVerdictTM k i).runFrom
      (Cfg.ofWords (input := α) (.fwd true) w) (2 * (w i).length + 3)
    c.state = none ∧ c.output = [canonBitsOK (w i)] := by
  obtain ⟨hscan, hcut⟩ := canonBitsTM_run k i α w
  have hid : ⇑(Function.Embedding.refl (ScanPhase Bool)) = id := rfl
  have hpre := MultiTapeTM.runFrom_mapState_of_agreeOn
    (canonBitsTM k i) (canonVerdictTM k i) (Function.Embedding.refl _)
    (fun q => ∀ b, q ≠ ScanPhase.done b)
    (by
      intro q hq inp work
      simp only [hid, id_eq]
      cases q with
      | fwd a => simp [canonVerdictTM, Action.mapState]
      | bwd a => simp [canonVerdictTM, Action.mapState]
      | done b => exact (hq b rfl).elim)
    (Cfg.ofWords (input := α) (.fwd true) w) (2 * (w i).length + 2)
    (by
      intro u hu q hq b he
      exact hcut u hu b (hq.trans (congrArg some he)))
  simp only [hid, Cfg.mapState, Option.map_id, id_eq] at hpre
  change ((canonVerdictTM k i).runFrom _ ((2 * (w i).length + 2) + 1)).state = none ∧ _
  rw [MultiTapeTM.runFrom_succ_eq_step', hpre, hscan]
  simp [MultiTapeTM.step, Cfg.ofWords, canonVerdictTM, Action.apply]


/-- The loaded-header scan, reached through the inherited native-input call,
computes the canonicality bit in linear time.

**Proof sketch.** Use the strict loader seam, then the public scan with its
single emitting exit. The loader restores the native input and clean work
heads. Its returned header has length at most the input length, so the two
linear ledgers and the one dispatch step have a common linear bound. -/
private lemma exists_canonHeaderBitsTM :
    ∃ (M : FinTM Bool) (a : ℕ),
      M.ComputesFunInTime (fun α => [canonBitsOK (canonHeader α)])
        (fun n => a * (n + 1)) := by
  classical
  obtain ⟨C, entry, exit, a, hk, hC⟩ := exists_canonHeaderSeam
  let i : Fin C.k := ⟨0, hk⟩
  let V := canonVerdictTM C.k i
  let L := seamCompTM C.tm exit V (ScanPhase.fwd true)
  let M : FinTM Bool := {
    k := C.k
    State := C.State ⊕ ScanPhase Bool
    tm := { L with q₀ := Sum.inl entry } }
  refine ⟨M, a + 4, ?_⟩
  intro α
  obtain ⟨t, ht, _, hcut, hload⟩ := hC α
  let w := stateWord C.k (canonHeader α)
  have hw : w i = canonHeader α := by simp [w, stateWord, i]
  let v := V.runFrom (Cfg.ofWords (input := α) (.fwd true) w)
    (2 * (w i).length + 3)
  have hv : v.state = none ∧ v.output = [canonBitsOK (w i)] :=
    canonVerdictTM_run C.k i α w
  have hrun := seamCompTM_run_ofCfg C.tm exit V (.fwd true)
    (c₃ := v) hload rfl hcut (by
      simp only [Cfg.ofWords, Cfg.mapState, Option.map_some]
      rfl)
  have hinit : M.tm.initCfg α =
      (Cfg.ofWords (input := α) entry (fun _ => [])).mapState Sum.inl := by
    simp [M, MultiTapeTM.initCfg, Cfg.init, Cfg.ofWords, Cfg.mapState,
      FinTM.bufferTape_nil]
  have hbase : M.ComputesInTime α [canonBitsOK (canonHeader α)]
      (t + 1 + (2 * (w i).length + 3)) := by
    apply (FinTM.computesInTime_iff M _ _ _).mpr
    rw [hinit]
    change (L.runFrom _ _).state = none ∧ (L.runFrom _ _).output = _
    rw [hrun]
    simpa only [Cfg.mapState, hv.1, Option.map_none, hw] using hv
  apply hbase.mono
  have hlen := canonHeader_length α
  rw [hw]
  calc
    t + 1 + (2 * (canonHeader α).length + 3) ≤
        a * (α.length + 1) + 2 * α.length + 4 := by omega
    _ ≤ (a + 4) * (α.length + 1) := by
      rw [Nat.add_mul]
      omega

/-- Header validity keeps pair-grammar failure separate from the loader's
empty-word fallback; a successfully decoded empty header is canonical zero. -/
private def canonHeaderOK (α : List Bool) : Bool :=
  (pairDecode α).isSome && canonBitsOK (canonHeader α)

/-- The physical header predicate tests precisely successful pair decoding
and canonical binary state-count digits. -/
private lemma canonHeaderOK_iff (α : List Bool) :
    canonHeaderOK α = true ↔
      ∃ bits rest, pairDecode α = some (bits, rest) ∧ bits = (codeBitsNat bits).bits := by
  cases hp : pairDecode α with
  | none => simp [canonHeaderOK, hp]
  | some p =>
    rcases p with ⟨bits, rest⟩
    simp [canonHeaderOK, canonHeader, hp, canonBitsOK_iff, codeBitsNat]

/-- Header rejection is a genuine scanner failure, never an accidental
acceptance of the loader's default empty word.

**Proof sketch.** Pair failure is the scanner's first failure. For a decoded
pair, failure of the last-bit test is equivalent to failure of the scanner's
canonical-binary equality. -/
private lemma scan_eq_none_of_canonHeaderOK (F : MachineFormat) (α : List Bool)
    (h : canonHeaderOK α = false) : F.scan α = none := by
  cases hp : pairDecode α with
  | none => simp [CodeFormat.scan, hp]
  | some p =>
    rcases p with ⟨bits, rest⟩
    have hb : bits ≠ (codeBitsNat bits).bits := by
      intro he
      have ht : canonHeaderOK α = true :=
        (canonHeaderOK_iff α).mpr ⟨bits, rest, hp, he⟩
      simp [h] at ht
    simp [CodeFormat.scan, hp, hb]

/-- A total linear-time validator checks pair success separately and runs the
loaded-header checker only on successful pairs.

**Proof sketch.** Branch on the public pair-validity primitive. The positive
branch is the loader-plus-scan machine; the negative branch emits false. The
public conditional wrapper combines these computations, and the maximum of
the two branch budgets is bounded by their sum. -/
private lemma exists_canonHeaderOKTM :
    ∃ (M : FinTM Bool) (a : ℕ),
      M.ComputesFunInTime (fun α => [canonHeaderOK α]) (fun n => a * (n + 1)) := by
  obtain ⟨D, a, hD⟩ := FinTM.computesFunInTime_pairValid
  obtain ⟨B, b, hB⟩ := exists_canonHeaderBitsTM
  obtain ⟨E, e, hE⟩ := FinTM.computesFunInTime_const [false]
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_cond hD hB hE
  refine ⟨M, c * (a + b + e + 1), ?_⟩
  intro α
  have hout : (if (pairDecode α).isSome then [canonBitsOK (canonHeader α)] else [false]) =
      [canonHeaderOK α] := by
    cases hb : (pairDecode α).isSome <;> simp [canonHeaderOK, hb]
  change M.ComputesInTime α [canonHeaderOK α] _
  rw [← hout]
  apply (hM α).mono
  change c * (a * (α.length + 1) + max (b * (α.length + 1)) (e * (α.length + 1)) + 1) ≤
    (c * (a + b + e + 1)) * (α.length + 1)
  rw [Nat.mul_assoc]
  apply Nat.mul_le_mul_left c
  calc
    a * (α.length + 1) + max (b * (α.length + 1)) (e * (α.length + 1)) + 1 ≤
        a * (α.length + 1) + (b + e) * (α.length + 1) + 1 := by
      rw [Nat.add_mul]
      omega
    _ ≤ (a + b + e + 1) * (α.length + 1) := by
      simp only [Nat.add_mul, Nat.one_mul]
      omega

/-- One positive block size enforces both necessary length guards. Taking
its maximum combines the format guard and the grammar guard, including
formats whose own guard is zero. -/
private def canonGuardBlock (F : MachineFormat) : ℕ :=
  max F.guard ((4 * F.k + 5) * 3 ^ (F.k + 1))

/-- The grammar component makes the combined guard strictly positive. -/
private lemma canonGuardBlock_pos (F : MachineFormat) : 0 < canonGuardBlock F := by
  have h : 0 < (4 * F.k + 5) * 3 ^ (F.k + 1) := by positivity
  exact h.trans_le (Nat.le_max_right _ _)

/-- Failure of the combined guard selects the specified fallback.

**Proof sketch.** The maximum is one of the two block sizes. In the format
case cite its public early-rejection law; in the grammar case cite the
inherited positive-grammar rejection law. -/
private lemma decode_of_canonGuard (F : MachineFormat) (α bits rest : List Bool)
    (hp : pairDecode α = some (bits, rest))
    (hg : rest.length < canonGuardBlock F * (codeBitsNat bits + 1)) :
    F.decode α = F.fallback := by
  rcases le_total F.guard ((4 * F.k + 5) * 3 ^ (F.k + 1)) with h | h
  · rw [canonGuardBlock, max_eq_right h] at hg
    exact decode_of_grammar_guard F α bits rest hp hg
  · rw [canonGuardBlock, max_eq_left h] at hg
    exact F.toCodeFormat.decode_of_guard_lt α bits rest hp hg

/-- At the real post-header offset, a preloaded successor counter checks
both guards with a bound independent of the header's numerical value.
The result retains the inherited strict cuts at both live exits.

**Proof sketch.** Pair-reader soundness identifies the native remainder
position. The spare-bit increment supplies exactly `n + 1` in the binary
value convention of the inherited guard. Select its proved success or
escape contract by the remainder-length comparison, then enlarge both
budgets to the same linear bound. Loading, bank preservation and native
seeking are separate composition obligations, not hypotheses hidden here. -/
private lemma canonGuard_run (F : MachineFormat) (α bits rest : List Bool)
    (hp : pairDecode α = some (bits, rest)) :
    let B := canonGuardBlock F
    let j := 2 * bits.length + 2
    ∃ hj : j ≤ α.length, ∃ T ≤ (B + 4) * (α.length + 1) + 2 * (bits.length + 1),
      let c := (binaryGuardTM (B - 1)).runFrom
        (binaryGuardStart (B - 1) α j hj [] (canonCount bits)) T
      c.state = some (if B * (codeBitsNat bits + 1) ≤ rest.length then .done else .escape) ∧
        c.output = [] ∧
        c.inputPos.val = (if B * (codeBitsNat bits + 1) ≤ rest.length
          then j + B * (codeBitsNat bits + 1) + 1 else α.length + 1) ∧
        (∀ u < T,
          ((binaryGuardTM (B - 1)).runFrom
            (binaryGuardStart (B - 1) α j hj [] (canonCount bits)) u).state ≠ some .done ∧
          ((binaryGuardTM (B - 1)).runFrom
            (binaryGuardStart (B - 1) α j hj [] (canonCount bits)) u).state ≠ some .escape) := by
  dsimp only
  set B := canonGuardBlock F
  set j := 2 * bits.length + 2
  have hpos : 0 < B := canonGuardBlock_pos F
  have hblock : B - 1 + 1 = B := by omega
  have hlen : α.length = j + rest.length := by
    rw [eq_pairEncode_of_pairDecode α bits rest hp, length_pairEncode]
  have hj : j ≤ α.length := by omega
  have hcount : Nat.ofDigits 2 ((canonCount bits).map Bool.toNat) = codeBitsNat bits + 1 := by
    rw [← foldr_bit_eq_ofDigits]
    exact (canonCount_spec bits).2.2
  have hwidth := (canonCount_spec bits).2.1
  refine ⟨hj, ?_⟩
  by_cases hg : B * (codeBitsNat bits + 1) ≤ rest.length
  · have hfit : j + (B - 1 + 1) * Nat.ofDigits 2 ((canonCount bits).map Bool.toNat) ≤
        α.length := by rw [hblock, hcount]; omega
    obtain ⟨T, hT, hs, ho, hi, hcut⟩ :=
      binaryGuard_done (B - 1) α j hj [] (canonCount bits) hfit
    refine ⟨T, hT.trans ?_, ?_⟩
    · rw [hwidth]
      have hm := Nat.mul_le_mul_right (α.length + 1) (show 5 ≤ B + 4 by omega)
      omega
    · simp only [if_pos hg]
      refine ⟨hs, ho, ?_, hcut⟩
      simpa only [hblock, hcount] using hi
  · have hshort : α.length < j + (B - 1 + 1) * Nat.ofDigits 2 ((canonCount bits).map Bool.toNat) := by
      rw [hblock, hcount]
      omega
    obtain ⟨T, hT, hs, ho, hi, hcut⟩ :=
      binaryGuard_escape (B - 1) α j hj [] (canonCount bits) hshort
    refine ⟨T, ?_, ?_⟩
    · simpa only [show B - 1 + 5 = B + 4 by omega, hwidth] using hT
    · simp only [if_neg hg]
      exact ⟨hs, ho, hi, hcut⟩


/-- A clean install call with a cut that includes time zero. The public
release adapter handles coincident entry and exit anchors; otherwise their
inequality supplies the only missing case.

**Proof sketch.** Apply the install row, preserving its exact ledger. If
its anchors coincide, use the public positive-return adapter. Otherwise
separate zero from the positive times already covered by the row. -/
private lemma canonStrictInstall (M : FinTM Bool) (f : List Bool → List Bool)
    (T : ℕ → ℕ) (hM : M.ComputesFunInTime f T) :
    ∃ (C : FinTM Bool) (entry exit : C.State) (a : ℕ), 0 < C.k ∧
      ∀ x arg : List Bool,
        ∃ t ≤ a * (T arg.length + arg.length + (f arg).length + 1),
          0 < t ∧
          (∀ u < t, (C.tm.runFrom
            (Cfg.ofWords (input := x) entry (stateWord C.k arg)) u).state ≠ some exit) ∧
          C.tm.runFrom (Cfg.ofWords (input := x) entry (stateWord C.k arg)) t =
            Cfg.ofWords exit (stateWord C.k (f arg)) := by
  classical
  obtain ⟨C, entry, exit, a, hk, hC⟩ := FinTM.exists_installCallTM M f T hM
  by_cases he : entry = exit
  · subst exit
    let R : FinTM Bool := {
      k := C.k
      State := Unit ⊕ C.State
      tm := seamReleaseTM C.tm entry }
    refine ⟨R, Sum.inl (), Sum.inr entry, a, hk, ?_⟩
    intro x arg
    obtain ⟨t, bound, pos, cut, run⟩ := hC x arg
    obtain ⟨released, first⟩ := seamReleaseTM_firstReturn C.tm entry rfl pos run rfl cut
    exact ⟨t, bound, pos, by
      simpa only [Cfg.ofWords, Cfg.mapState, Option.map_some] using first, by
      simpa only [Cfg.ofWords, Cfg.mapState, Option.map_some] using released⟩
  · refine ⟨C, entry, exit, a, hk, ?_⟩
    intro x arg
    obtain ⟨t, bound, pos, cut, run⟩ := hC x arg
    refine ⟨t, bound, pos, ?_, run⟩
    intro u hu
    cases u with
    | zero => exact fun h => he (Option.some.inj h)
    | succ u => exact cut (u + 1) (Nat.succ_pos _) hu

/-- Configuration assembly from the public selected-tape and frame laws.
This is the common extensionality step for word banks and native seeks.

**Proof sketch.** Split each host tape by membership in the embedded bank;
use the public selected projections there and the public frame at time zero
elsewhere. The other three fields are supplied by the caller. -/
private lemma canonEmbedEq {m k : ℕ} {S : Type} {x : List Bool}
    (M : MultiTapeTM m Bool S) (ι : Fin m ↪ Fin k)
    (c : Cfg m Bool S x) (d : Cfg k Bool S x)
    (tapes : Fin k → ℤ → Option Bool) (heads : Fin k → ℤ)
    (hs : c.state = d.state) (hp : c.inputPos = d.inputPos) (ho : c.output = d.output)
    (selected : ∀ i, c.workTapes i = d.workTapes (ι i) ∧
      c.workTapePos i = d.workTapePos (ι i))
    (outside : ∀ j, j ∉ Set.range ι →
      tapes j = d.workTapes j ∧ heads j = d.workTapePos j) :
    embedEmitCfg ι tapes heads [] c = d := by
  apply Cfg.ext hs hp ?_ ?_ (by simpa only [embedEmitCfg, List.nil_append] using ho)
  all_goals
    funext j
    by_cases located : j ∈ Set.range ι
    · obtain ⟨i, rfl⟩ := located
      first
      | exact (embedEmitCfg_selected_tape ι tapes heads [] c i).trans (selected i).1
      | exact (embedEmitCfg_selected_pos ι tapes heads [] c i).trans (selected i).2
    · have fixed := (embedEmitTM_frame ι M tapes heads [] c 0).1 j located
      first
      | exact fixed.1.trans (outside j located).1
      | exact fixed.2.trans (outside j located).2


/-- The public selected-tape and frame laws identify an embedded clean bank
with the requested whole-bank word layout. No private slot inverse is used.

**Proof sketch.** On the image of the tape embedding use its selected-tape
laws; off that image use its frame law at time zero. Configuration
extensionality then identifies the words and heads simultaneously. -/
private lemma canonEmbedWords {m k : ℕ} {S : Type} {x : List Bool}
    (M : MultiTapeTM m Bool S) (ι : Fin m ↪ Fin k) (q : S)
    (v : Fin m → List Bool) (ambient wanted : Fin k → List Bool)
    (selected : ∀ i, wanted (ι i) = v i)
    (outside : ∀ j, j ∉ Set.range ι → ambient j = wanted j) :
    embedEmitCfg ι (fun j => FinTM.bufferTape (ambient j)) (fun _ => 0) []
        (Cfg.ofWords (input := x) q v) = Cfg.ofWords q wanted := by
  apply canonEmbedEq M ι _ _ _ _ rfl rfl rfl
  · intro i
    exact ⟨congrArg FinTM.bufferTape (selected i).symm, rfl⟩
  · intro j hj
    exact ⟨congrArg FinTM.bufferTape (outside j hj), rfl⟩

/-- A clean tape-resident argument can be preserved on tape zero while a
public install call puts its transformed value on tape one. Every other
tape is blank again on return. This is a composition of the public copy,
embedding and seam rows, not an additional call host.

**Proof sketch.** Reserve tape zero, copy its word to the first tape of a
fresh install bank, and run the strict install there by public embedding.
The bank frame preserves the original word. The copy and dispatch costs
are absorbed into four times the argument-length part of the call ledger. -/
private lemma canonPreserveInstall (M : FinTM Bool) (f : List Bool → List Bool)
    (T : ℕ → ℕ) (hM : M.ComputesFunInTime f T) :
    ∃ (C : FinTM Bool) (dst : Fin C.k) (entry exit : C.State) (a : ℕ),
      dst.val = 1 ∧ ∀ x arg : List Bool,
        ∃ t ≤ a * (T arg.length + arg.length + (f arg).length + 1),
          (∀ u < t, (C.tm.runFrom
            (Cfg.ofWords (input := x) entry (stateWord C.k arg)) u).state ≠ some exit) ∧
          C.tm.runFrom (Cfg.ofWords (input := x) entry (stateWord C.k arg)) t =
            Cfg.ofWords exit (Function.update (stateWord C.k arg) dst (f arg)) := by
  classical
  obtain ⟨I, enter, leave, a, positive, installed⟩ := canonStrictInstall M f T hM
  let zero : Fin I.k := ⟨0, positive⟩
  let dst : Fin (I.k + 1) := zero.succ
  let bank : Fin I.k ↪ Fin (I.k + 1) := Fin.succEmb I.k
  let P := copyTM (Symbol := Bool) (I.k + 1) 0 dst
  let E := embedEmitTM bank I.tm
  let C : FinTM Bool := {
    k := I.k + 1
    State := SweepPhase ⊕ I.State
    tm := { seamCompTM P .done E enter with q₀ := Sum.inl .sweep } }
  refine ⟨C, dst, Sum.inl .sweep, Sum.inr leave, a + 4, rfl, ?_⟩
  intro x arg
  let w := stateWord (I.k + 1) arg
  let copied := Function.update w dst arg
  let result := Function.update w dst (f arg)
  have source : w 0 = arg := by simp [w, stateWord]
  have fresh : w dst = [] := by simp [w, stateWord, dst]
  have distinct : (0 : Fin (I.k + 1)) ≠ dst := by
    intro h
    have := congrArg Fin.val h
    simp [dst] at this
  have onBank (v : List Bool) (i : Fin I.k) :
      (Function.update w dst v) (bank i) = stateWord I.k v i := by
    simp [w, stateWord, dst, bank, zero, Function.update_apply, Fin.ext_iff]
  have offBank (j : Fin (I.k + 1)) (hj : j ∉ Set.range bank) : copied j = result j := by
    have ne : j ≠ dst := fun eq => hj ⟨zero, eq.symm⟩
    simp only [copied, result, Function.update_of_ne ne]
  -- The copy, read from the framed contract at the canonical seam.
  have framed₀ := copyTM_run_ofCfg (x := x) 0 dst distinct (w 0) (Cfg.ofWords .sweep w) (Cfg.ofWords_state _ _)
    (fun p _ _ => by rw [Cfg.ofWords_workTapes, Cfg.ofWords_workTapePos, zero_add])
  have run₀ := framed₀.1.trans (Cfg.ofWords_copy_endpoint _ _ w 0 dst fresh)
  have cut₀ := framed₀.2.1
  rw [source] at run₀ cut₀
  set t₀ := 2 * arg.length + 2 with t₀def
  have budget₀ : t₀ ≤ 3 * arg.length + 3 := by omega
  obtain ⟨t₁, budget₁, _, cut₁, run₁⟩ := installed x arg
  have lift (u : ℕ) : E.runFrom (Cfg.ofWords (input := x) enter copied) u =
      embedEmitCfg bank (fun j => FinTM.bufferTape (copied j)) (fun _ => 0) []
        (I.tm.runFrom (Cfg.ofWords (input := x) enter (stateWord I.k arg)) u) := by
    rw [← canonEmbedWords I.tm bank enter (stateWord I.k arg) copied copied
      (onBank arg) (fun _ _ => rfl)]
    exact embedEmitTM_runFrom bank I.tm _ _ _ _ u
  have second : E.runFrom (Cfg.ofWords (input := x) enter copied) t₁ =
      Cfg.ofWords leave result := by
    rw [lift, run₁]
    exact canonEmbedWords I.tm bank leave (stateWord I.k (f arg)) copied result
      (onBank (f arg)) offBank
  have secondCut (u : ℕ) (hu : u < t₁) :
      (E.runFrom (Cfg.ofWords (input := x) enter copied) u).state ≠ some leave := by
    rw [lift]
    exact cut₁ u hu
  have second' : E.runFrom
      ((Cfg.ofWords (input := x) SweepPhase.done copied).mapState fun _ => enter) t₁ =
      Cfg.ofWords leave result := second
  have cut' (u : ℕ) (hu : u < t₁) :
      (E.runFrom ((Cfg.ofWords (input := x) SweepPhase.done copied).mapState
        fun _ => enter) u).state ≠ some leave := secondCut u hu
  have whole := seamCompTM_run_ofCfg P .done E enter run₀ (Cfg.ofWords_state _ _) cut₀ second'
  have first := seamCompTM_firstReturn_ofCfg P .done E enter leave
    run₀ (Cfg.ofWords_state _ _) cut₀ second' rfl cut'
  refine ⟨t₀ + 1 + t₁, ?_, ?_, ?_⟩
  · calc
      t₀ + 1 + t₁ ≤ 3 * arg.length + 4 +
          a * (T arg.length + arg.length + (f arg).length + 1) := by omega
      _ ≤ (a + 4) * (T arg.length + arg.length + (f arg).length + 1) := by
        rw [Nat.add_mul]
        omega
  · simpa only [C, Cfg.ofWords, Cfg.mapState, Option.map_some] using first
  · simpa only [C, result, w, Cfg.ofWords, Cfg.mapState, Option.map_some] using whole


/-- Load the undoubled header and install its nonoverflowing successor on
a separate tape. The original header remains on tape zero, tape one holds
`canonCount`, all other tapes are blank, and the native head is restored.
The contract retains a strict first-exit cut for subsequent seam composition.

**Proof sketch.** Extract the count-computing machine before applying the
preserving install construction. Embed that construction and the inherited
header loader into one bank of the larger tape count, then join them with
the public seam. The successor width is the header width plus one, so the
complete loading, copying and installation ledger is linear in the input. -/
private lemma exists_canonHeaderCountSeam :
    ∃ (C : FinTM Bool) (dst : Fin C.k) (entry exit : C.State) (a : ℕ),
      dst.val = 1 ∧ ∀ α : List Bool, ∃ t ≤ a * (α.length + 1),
        (∀ u < t, (C.tm.runFrom
          (Cfg.ofWords (input := α) entry (fun _ => [])) u).state ≠ some exit) ∧
        C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) t =
          Cfg.ofWords exit (Function.update (stateWord C.k (canonHeader α)) dst
            (canonCount (canonHeader α))) := by
  classical
  obtain ⟨L, lentry, lexit, a, hl, load⟩ := exists_canonHeaderSeam
  obtain ⟨N, b, count⟩ := exists_canonCountTM
  obtain ⟨P, pdst, pentry, pexit, c, hdst, install⟩ :=
    canonPreserveInstall N canonCount (fun n => b * (n + 1)) count
  let K := max L.k P.k
  let lb : Fin L.k ↪ Fin K := Fin.castLEEmb (Nat.le_max_left _ _)
  let pb : Fin P.k ↪ Fin K := Fin.castLEEmb (Nat.le_max_right _ _)
  let A := embedEmitTM lb L.tm
  let B := embedEmitTM pb P.tm
  let C : FinTM Bool := {
    k := K
    State := L.State ⊕ P.State
    tm := { seamCompTM A lexit B pentry with q₀ := Sum.inl lentry } }
  refine ⟨C, pb pdst, Sum.inl lentry, Sum.inr pexit, a + c * (b + 2) + 1, hdst, ?_⟩
  intro α
  let header := canonHeader α
  let w := stateWord K header
  let result := Function.update w (pb pdst) (canonCount header)
  obtain ⟨t₀, bound₀, _, cut₀, run₀⟩ := load α
  obtain ⟨t₁, bound₁, cut₁, run₁⟩ := install α header
  have loadLift (u : ℕ) :
      A.runFrom (Cfg.ofWords (input := α) lentry (fun _ => [])) u =
        embedEmitCfg lb (fun _ => FinTM.bufferTape []) (fun _ => 0) []
          (L.tm.runFrom (Cfg.ofWords (input := α) lentry (fun _ => [])) u) := by
    rw [← canonEmbedWords L.tm lb lentry (fun _ => []) (fun _ => []) (fun _ => [])
      (fun _ => rfl) (fun _ _ => rfl)]
    exact embedEmitTM_runFrom lb L.tm _ _ _ _ u
  have loaded : A.runFrom (Cfg.ofWords (input := α) lentry (fun _ => [])) t₀ =
      Cfg.ofWords lexit w := by
    rw [loadLift, run₀]
    apply canonEmbedWords L.tm lb lexit (stateWord L.k header) (fun _ => []) w
    · intro i
      rfl
    · intro j hj
      have nonzero : j.val ≠ 0 := by
        intro hz
        apply hj
        exact ⟨⟨0, hl⟩, Fin.ext hz.symm⟩
      simp [w, stateWord, nonzero]
  have first₀ (u : ℕ) (hu : u < t₀) :
      (A.runFrom (Cfg.ofWords (input := α) lentry (fun _ => [])) u).state ≠ some lexit := by
    rw [loadLift]
    exact cut₀ u hu
  have installLift (u : ℕ) : B.runFrom (Cfg.ofWords (input := α) pentry w) u =
      embedEmitCfg pb (fun j => FinTM.bufferTape (w j)) (fun _ => 0) []
        (P.tm.runFrom (Cfg.ofWords (input := α) pentry (stateWord P.k header)) u) := by
    rw [← canonEmbedWords P.tm pb pentry (stateWord P.k header) w w
      (fun _ => rfl) (fun _ _ => rfl)]
    exact embedEmitTM_runFrom pb P.tm _ _ _ _ u
  have installed : B.runFrom (Cfg.ofWords (input := α) pentry w) t₁ =
      Cfg.ofWords pexit result := by
    rw [installLift, run₁]
    apply canonEmbedWords P.tm pb pexit
      (Function.update (stateWord P.k header) pdst (canonCount header)) w result
    · intro i
      exact congrFun (Function.update_comp_eq_of_injective w pb.injective pdst
        (canonCount header)) i
    · intro j hj
      have ne : j ≠ pb pdst := fun h => hj ⟨pdst, h.symm⟩
      exact (Function.update_of_ne ne _ _).symm
  have first₁ (u : ℕ) (hu : u < t₁) :
      (B.runFrom (Cfg.ofWords (input := α) pentry w) u).state ≠ some pexit := by
    rw [installLift]
    exact cut₁ u hu
  have installed' : B.runFrom
      ((Cfg.ofWords (input := α) lexit w).mapState fun _ => pentry) t₁ =
      Cfg.ofWords pexit result := installed
  have first₁' (u : ℕ) (hu : u < t₁) :
      (B.runFrom ((Cfg.ofWords (input := α) lexit w).mapState fun _ => pentry) u).state ≠
        some pexit := first₁ u hu
  have run := seamCompTM_run_ofCfg A lexit B pentry loaded rfl first₀ installed'
  have cut := seamCompTM_firstReturn_ofCfg A lexit B pentry pexit
    loaded rfl first₀ installed' rfl first₁'
  have boundCount : t₁ ≤ c * (b + 2) * (α.length + 1) := by
    have width := (canonCount_spec header).2.1
    rw [width] at bound₁
    calc
      t₁ ≤ c * (b * (header.length + 1) + header.length + (header.length + 1) + 1) := bound₁
      _ = c * (b + 2) * (header.length + 1) := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.add_le_add_right (canonHeader_length α) 1)
  refine ⟨t₀ + 1 + t₁, ?_, ?_, ?_⟩
  · rw [Nat.add_mul, Nat.add_mul, Nat.one_mul]
    omega
  · simpa only [C, Cfg.ofWords, Cfg.mapState, Option.map_some] using cut
  · simpa only [C, result, w, header, Cfg.ofWords, Cfg.mapState, Option.map_some] using run


/-- Binary address of the first bit after the doubled header and its separator.
A low one below the successor of the header's length represents `2|w|+3`.
The seek contract accepts the harmless spare high zero. -/
private def canonOffset (w : List Bool) : List Bool :=
  true :: canonCount w.length.bits

/-- The offset word represents the actual native-input address and has
length at most the original header length plus two.

**Proof sketch.** The existing successor-word law gives the length plus
one. Prepending a low one doubles that value and adds one. The public
binary-size inequality bounds the length of the length counter. -/
private lemma canonOffset_spec (w : List Bool) :
    Nat.ofDigits 2 ((canonOffset w).map Bool.toNat) = 2 * w.length + 3 ∧
      (canonOffset w).length ≤ w.length + 2 := by
  constructor
  · rw [← foldr_bit_eq_ofDigits]
    change Nat.bit true ((canonCount w.length.bits).foldr Nat.bit 0) = _
    rw [(canonCount_spec w.length.bits).2.2]
    change Nat.bit true (codeBitsNat w.length.bits + 1) = _
    rw [codeBitsNat_bits]
    simp [Nat.bit]
    omega
  · have small : w.length.bits.length ≤ w.length := length_bits_le_self _
    simp only [canonOffset, List.length_cons, (canonCount_spec w.length.bits).2.1]
    omega

/-- The native remainder address is computed in linear time, using only
public length/prepend primitives and the inherited successor machine.

**Proof sketch.** Compose binary length with the successor, then prepend
one. Each application of the public composition theorem gives a linear
ledger; distribute the products to absorb its fixed dispatch cost. -/
private lemma exists_canonOffsetTM :
    ∃ (M : FinTM Bool) (a : ℕ),
      M.ComputesFunInTime canonOffset (fun n => a * (n + 1)) := by
  obtain ⟨L, a, length⟩ := FinTM.computesFunInTime_lengthBits
  obtain ⟨N, b, count⟩ := exists_canonCountTM
  obtain ⟨A, c, comp⟩ := FinTM.computesFunInTime_comp length count
    (fun _ _ h => Nat.mul_le_mul_left b (Nat.add_le_add_right h 1))
  have first : A.ComputesFunInTime (fun w => canonCount w.length.bits)
      (fun n => c * (a + 1) * (b + 1) * (n + 1)) := by
    intro w
    apply (comp w).mono
    have room : 0 ≤ (b + 1) * w.length := Nat.zero_le _
    calc
      c * (a * (w.length + 1) + b * (a * (w.length + 1) + 1) + 1) ≤
          c * (a * (w.length + 1) + b * (a * (w.length + 1) + 1) + 1 +
            (b + 1) * w.length) := Nat.mul_le_mul_left c (by omega)
      _ = _ := by ring
  obtain ⟨P, e, prepend⟩ := FinTM.computesFunInTime_prepend [true]
  obtain ⟨M, d, combined⟩ := FinTM.computesFunInTime_comp first prepend
    (fun _ _ h => Nat.mul_le_mul_left e (Nat.add_le_add_right h 1))
  let z := c * (a + 1) * (b + 1)
  refine ⟨M, d * (z + 1) * (e + 1), ?_⟩
  intro w
  apply (combined w).mono
  change d * (z * (w.length + 1) + e * (z * (w.length + 1) + 1) + 1) ≤ _
  calc
    d * (z * (w.length + 1) + e * (z * (w.length + 1) + 1) + 1) ≤
        d * (z * (w.length + 1) + e * (z * (w.length + 1) + 1) + 1 +
          (e + 1) * w.length) := Nat.mul_le_mul_left d (Nat.le_add_right _ _)
    _ = _ := by ring


/-- The canonizer's prepared bank: original header, successor count and
native remainder address on tapes zero, one and two, with blank scratch. -/
private def canonReadyWords (k : ℕ) (header : List Bool) : Fin k → List Bool :=
  fun j => if j.val = 0 then header else if j.val = 1 then canonCount header
    else if j.val = 2 then canonOffset header else []

/-- A physical front end prepares both binary words without changing the
original header. At least one additional blank tape is reserved for the
public native-input seek. The native head and every work head are at home.

**Proof sketch.** Run the proved header/count seam in a larger bank. Copy
and install the offset through a second preserving call whose embedding
skips the live count tape. The embedding frame protects that count; the
call protects the header. Compose their strict seams and add the two
linear ledgers, charging the offset's width by `canonOffset_spec`. -/
private lemma exists_canonReadySeam :
    ∃ (C : FinTM Bool) (entry exit : C.State) (a : ℕ), 4 ≤ C.k ∧
      ∀ α : List Bool, ∃ t ≤ a * (α.length + 1),
        (∀ u < t, (C.tm.runFrom
          (Cfg.ofWords (input := α) entry (fun _ => [])) u).state ≠ some exit) ∧
        C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) t =
          Cfg.ofWords exit (canonReadyWords C.k (canonHeader α)) := by
  classical
  obtain ⟨H, hdst, hentry, hexit, a, hv, headerRun⟩ := exists_canonHeaderCountSeam
  obtain ⟨O, b, offsetRun⟩ := exists_canonOffsetTM
  obtain ⟨P, pdst, pentry, pexit, c, pv, prepare⟩ :=
    canonPreserveInstall O canonOffset (fun n => b * (n + 1)) offsetRun
  have hp : 2 ≤ P.k := by have := pdst.isLt; omega
  let K := max H.k (P.k + 1) + 1
  have hK : 4 ≤ K := by dsimp [K]; omega
  let hb : Fin H.k ↪ Fin K := Fin.castLEEmb (by dsimp [K]; omega)
  let pb : Fin P.k ↪ Fin K :=
    (Fin.succAboveEmb (⟨1, by omega⟩ : Fin (P.k + 1))).trans (Fin.castLEEmb (by dsimp [K]; omega))
  have pval (i : Fin P.k) : (pb i).val = if i.val = 0 then 0 else i.val + 1 := by
    change ((⟨1, by omega⟩ : Fin (P.k + 1)).succAbove i).val = _
    dsimp only [Fin.succAbove]
    split_ifs <;> simp_all [Fin.lt_def]
  let A := embedEmitTM hb H.tm
  let B := embedEmitTM pb P.tm
  let C : FinTM Bool := {
    k := K
    State := H.State ⊕ P.State
    tm := { seamCompTM A hexit B pentry with q₀ := Sum.inl hentry } }
  refine ⟨C, Sum.inl hentry, Sum.inr pexit, a + c * (b + 3) + 1, hK, ?_⟩
  intro α
  let head := canonHeader α
  let mid := Function.update (stateWord K head) (hb hdst) (canonCount head)
  let out := canonReadyWords K head
  have hv' : (hb hdst).val = 1 := hv
  have imageCount (j : Fin K) (hj : j ∉ Set.range hb) : j.val ≠ 0 ∧ j ≠ hb hdst := by
    refine ⟨?_, fun h => hj ⟨hdst, h.symm⟩⟩
    intro hz
    apply hj
    exact ⟨⟨0, by have := hdst.isLt; omega⟩, Fin.ext hz.symm⟩
  have sourceP (i : Fin P.k) : mid (pb i) = stateWord P.k head i := by
    have neq : pb i ≠ hb hdst := by
      intro eq
      have := congrArg Fin.val eq
      rw [pval, hv'] at this
      split at this <;> omega
    dsimp only [mid]
    rw [Function.update_of_ne neq]
    dsimp only [stateWord]
    rw [pval]
    split <;> simp_all
  have finalP (i : Fin P.k) :
      out (pb i) = Function.update (stateWord P.k head) pdst (canonOffset head) i := by
    have eqv : i = pdst ↔ i.val = 1 := by
      constructor
      · rintro rfl; exact pv
      · intro hi; exact Fin.ext (hi.trans pv.symm)
    simp only [out, canonReadyWords, pval, Function.update_apply, eqv, stateWord]
    by_cases hi : i.val = 0
    · simp [hi]
    · simp [hi]
  have outsideP (j : Fin K) (hj : j ∉ Set.range pb) : mid j = out j := by
    have notzero : j.val ≠ 0 := by
      intro hz
      apply hj
      refine ⟨⟨0, by omega⟩, Fin.ext ?_⟩
      rw [pval]
      simp [hz]
    have nottwo : j.val ≠ 2 := by
      intro hz
      apply hj
      refine ⟨pdst, Fin.ext ?_⟩
      rw [pval, pv, hz]
      rfl
    by_cases h1 : j = hb hdst
    · subst j
      simp [mid, out, canonReadyWords, hv']
    · have valne : j.val ≠ 1 := fun h => h1 (Fin.ext (h.trans hv'.symm))
      simp [mid, out, Function.update_of_ne h1, canonReadyWords, stateWord,
        notzero, valne, nottwo]
  obtain ⟨t₀, time₀, cut₀, run₀⟩ := headerRun α
  obtain ⟨t₁, time₁, cut₁, run₁⟩ := prepare α head
  have hlift (u : ℕ) :
      A.runFrom (Cfg.ofWords (input := α) hentry (fun _ => [])) u =
        embedEmitCfg hb (fun _ => FinTM.bufferTape []) (fun _ => 0) []
          (H.tm.runFrom (Cfg.ofWords (input := α) hentry (fun _ => [])) u) := by
    rw [← canonEmbedWords H.tm hb hentry (fun _ => []) (fun _ => []) (fun _ => [])
      (fun _ => rfl) (fun _ _ => rfl)]
    exact embedEmitTM_runFrom hb H.tm _ _ _ _ u
  have first : A.runFrom (Cfg.ofWords (input := α) hentry (fun _ => [])) t₀ =
      Cfg.ofWords hexit mid := by
    rw [hlift, run₀]
    apply canonEmbedWords H.tm hb hexit
      (Function.update (stateWord H.k head) hdst (canonCount head)) (fun _ => []) mid
    · intro i
      exact Function.update_apply_of_injective (stateWord K head) hb.injective
        hdst (canonCount head) i
    · intro j hj
      obtain ⟨nz, ne⟩ := imageCount j hj
      simp [mid, Function.update_of_ne ne, stateWord, nz]
  have firstCut (u : ℕ) (hu : u < t₀) :
      (A.runFrom (Cfg.ofWords (input := α) hentry (fun _ => [])) u).state ≠ some hexit := by
    rw [hlift]; exact cut₀ u hu
  have plift (u : ℕ) : B.runFrom (Cfg.ofWords (input := α) pentry mid) u =
      embedEmitCfg pb (fun j => FinTM.bufferTape (mid j)) (fun _ => 0) []
        (P.tm.runFrom (Cfg.ofWords (input := α) pentry (stateWord P.k head)) u) := by
    rw [← canonEmbedWords P.tm pb pentry (stateWord P.k head) mid mid
      sourceP (fun _ _ => rfl)]
    exact embedEmitTM_runFrom pb P.tm _ _ _ _ u
  have second : B.runFrom ((Cfg.ofWords (input := α) hexit mid).mapState
      fun _ => pentry) t₁ = Cfg.ofWords pexit out := by
    change B.runFrom (Cfg.ofWords pentry mid) t₁ = _
    rw [plift, run₁]
    exact canonEmbedWords P.tm pb pexit
      (Function.update (stateWord P.k head) pdst (canonOffset head)) mid out finalP outsideP
  have secondCut (u : ℕ) (hu : u < t₁) :
      (B.runFrom ((Cfg.ofWords (input := α) hexit mid).mapState
        fun _ => pentry) u).state ≠ some pexit := by
    change (B.runFrom (Cfg.ofWords pentry mid) u).state ≠ _
    rw [plift]; exact cut₁ u hu
  have whole := seamCompTM_run_ofCfg A hexit B pentry first rfl firstCut second
  have firstExit := seamCompTM_firstReturn_ofCfg A hexit B pentry pexit
    first rfl firstCut second rfl secondCut
  have budget : t₁ ≤ c * (b + 3) * (α.length + 1) := by
    calc
      t₁ ≤ c * (b * (head.length + 1) + head.length + (canonOffset head).length + 1) := time₁
      _ ≤ c * (b * (head.length + 1) + head.length + (head.length + 2) + 1) :=
        Nat.mul_le_mul_left c (by have := (canonOffset_spec head).2; omega)
      _ ≤ c * (b + 3) * (head.length + 1) := by
        rw [Nat.mul_assoc]
        apply Nat.mul_le_mul_left c
        rw [Nat.add_mul]
        omega
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.add_le_add_right (canonHeader_length α) 1)
  refine ⟨t₀ + 1 + t₁, ?_, ?_, ?_⟩
  · simp only [Nat.add_mul, Nat.one_mul]
    omega
  · simpa only [C, Cfg.ofWords, Cfg.mapState, Option.map_some] using firstExit
  · simpa only [C, out, head, Cfg.ofWords, Cfg.mapState, Option.map_some] using whole


/-- The public native-input seek, embedded in a caller-selected bank. All
host tapes, all heads and the output are restored, including the frame.
This contract can therefore be used again after a destructive guard.

**Proof sketch.** Project the two selected tapes to the public seek row,
then transport its run and strict cut by forwarding embedding. Assemble
the returned host configuration by `canonEmbedEq`; the selected projections
come from the seek and the remaining tapes come from the public frame. -/
private lemma exists_canonSeekOnBank {k : ℕ} (ι : Fin 2 ↪ Fin k) :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S)
      (R : MultiTapeTM k Bool S) (entry exit : S) (a : ℕ),
      ∀ {x : List Bool} (p : ℕ) (w : List Bool),
        Nat.ofDigits 2 (w.map Bool.toNat) = p → ∀ hp : p ≤ x.length + 1,
        ∀ d : Cfg k Bool S x, d.state = some entry →
        (∀ q : ℤ, -1 ≤ q → q ≤ (w.length : ℤ) →
          d.workTapes (ι 0) (d.workTapePos (ι 0) + q) = FinTM.bufferTape w q) →
        (∀ q, d.workTapes (ι 1) q = none) →
        ∃ t ≤ a * (w.length + d.inputPos.val + p + 1),
          (∀ u < t, (R.runFrom d u).state ≠ some exit) ∧
          R.runFrom d t = { d with state := some exit, inputPos := ⟨p, by omega⟩ } := by
  classical
  obtain ⟨S, finite, equal, M, entry, exit, a, seek⟩ := exists_inputSeekTM
  letI : Fintype S := finite
  letI : DecidableEq S := equal
  refine ⟨S, finite, equal, embedEmitTM ι M, entry, exit, a, ?_⟩
  intro x p w hw hp d hd word blank
  let src : Cfg 2 Bool S x :=
    ⟨d.state, d.inputPos, fun i => d.workTapes (ι i), fun i => d.workTapePos (ι i), d.output⟩
  have start : embedEmitCfg ι d.workTapes d.workTapePos [] src = d := by
    exact canonEmbedEq M ι src d _ _ rfl rfl rfl (fun _ => ⟨rfl, rfl⟩)
      (fun _ _ => ⟨rfl, rfl⟩)
  have lift (u : ℕ) : (embedEmitTM ι M).runFrom d u =
      embedEmitCfg ι d.workTapes d.workTapePos [] (M.runFrom src u) := by
    conv_lhs => rw [← start]
    exact embedEmitTM_runFrom ι M _ _ [] src u
  obtain ⟨t, time, cut, _, state, pos, tapes, heads, out⟩ := seek p w hw hp src hd word blank
  refine ⟨t, time, ?_, ?_⟩
  · intro u hu
    rw [lift]
    exact cut u hu
  · rw [lift]
    refine canonEmbedEq M ι (M.runFrom src t)
      ({ d with state := some exit, inputPos := ⟨p, by omega⟩ })
      d.workTapes d.workTapePos state (Fin.ext pos) out ?_ ?_
    · intro i
      exact ⟨congrFun tapes i, congrFun heads i⟩
    · exact fun _ _ => ⟨rfl, rfl⟩


/-- From blank work tapes, prepare the header bank, seek to the native
remainder, run the positive guard, and seek back on success. All tapes
except the guard counter are preserved from the prepared bank. Rejection
is at the right input blank. This is a guard front end, not a grammar verdict.

**Proof sketch.** The preparation seam feeds an embedded public seek. The
inherited guard runs only on tape one, leaving the saved offset and its
scratch tape intact. A public seam dispatches its successful exit to the
same seek again; a failed guard is observed before that dispatch. Two more
public seams join the first seek and preparation. Every copy, installation,
seek and dispatch is included in the displayed linear coefficient. -/
private lemma exists_canonGuardFront (F : MachineFormat) :
    ∃ (C : FinTM Bool) (entry yes no : C.State) (a : ℕ), 4 ≤ C.k ∧ yes ≠ no ∧
      ∀ α bits rest : List Bool, pairDecode α = some (bits, rest) →
        ∃ t ≤ a * (α.length + 1),
          let d := C.tm.runFrom (Cfg.ofWords (input := α) entry (fun _ => [])) t
          d.state = some (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
            then yes else no) ∧ d.output = [] ∧
          d.inputPos.val = (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
            then 2 * bits.length + 3 else α.length + 1) ∧
          ∀ i : Fin C.k, i.val ≠ 1 →
            d.workTapes i = FinTM.bufferTape (canonReadyWords C.k bits i) ∧
              d.workTapePos i = 0 := by
  classical
  obtain ⟨P, pentry, pexit, a, hk, prep⟩ := exists_canonReadySeam
  let sb : Fin 2 ↪ Fin P.k := ⟨fun i => ⟨i.val + 2, by have := i.isLt; omega⟩,
    fun i j h => Fin.ext (by have := congrArg Fin.val h; dsimp at this; omega)⟩
  let gb : Fin 1 ↪ Fin P.k := ⟨fun _ => ⟨1, by omega⟩, fun _ _ _ => Subsingleton.elim _ _⟩
  obtain ⟨S, finite, equal, R, enter, leave, b, seek⟩ := exists_canonSeekOnBank sb
  letI : Fintype S := finite
  letI : DecidableEq S := equal
  let B := canonGuardBlock F
  let G := embedEmitTM gb (binaryGuardTM (B - 1))
  let U := seamCompTM G .done R enter
  let V := seamCompTM R leave U (Sum.inl (.dec .run))
  let C : FinTM Bool := {
    k := P.k
    State := P.State ⊕ (S ⊕ ((CounterLoopState (Option (Fin (B - 1 + 1))))) ⊕ S)
    tm := { seamCompTM P.tm pexit V (Sum.inl enter) with q₀ := Sum.inl pentry } }
  -- The parentheses below record the actual three seam summands.
  let yes : C.State := Sum.inr (Sum.inr (Sum.inr leave))
  let no : C.State := Sum.inr (Sum.inr (Sum.inl .escape))
  have distinct : yes ≠ no := by
    intro h
    cases Sum.inr.inj (Sum.inr.inj h)
  refine ⟨C, Sum.inl pentry, yes, no, a + 10 * b + B + 9, hk, distinct, ?_⟩
  intro α bits rest pair
  have header : canonHeader α = bits := by simp [canonHeader, pair]
  have size : bits.length ≤ α.length := header ▸ canonHeader_length α
  let p := 2 * bits.length + 3
  have inRange : p ≤ α.length + 1 := by
    rw [eq_pairEncode_of_pairDecode α bits rest pair, length_pairEncode]
    dsimp [p]
    omega
  let w := canonReadyWords P.k bits
  have address : w (sb 0) = canonOffset bits := by simp [w, canonReadyWords, sb]
  have scratch : w (sb 1) = [] := by simp [w, canonReadyWords, sb]
  let s₀ := Cfg.ofWords (input := α) enter w
  obtain ⟨ts, timeS, cutS, runS⟩ := seek p (canonOffset bits) (canonOffset_spec bits).1
    inRange s₀ rfl (by intro q _ _; simp [s₀, Cfg.ofWords, address])
    (by intro q; simp [s₀, Cfg.ofWords, scratch, FinTM.bufferTape])
  let s₁ : Cfg P.k Bool S α := { s₀ with state := some leave, inputPos := ⟨p, by omega⟩ }
  change R.runFrom s₀ ts = s₁ at runS
  obtain ⟨hj, tg, timeG, stateG, outG, posG, cutG⟩ := canonGuard_run F α bits rest pair
  let g₀ := binaryGuardStart (B - 1) α (2 * bits.length + 2) hj [] (canonCount bits)
  let g₁ := (binaryGuardTM (B - 1)).runFrom g₀ tg
  let d₀ : Cfg P.k Bool (CounterLoopState (Option (Fin (B - 1 + 1)))) α :=
    s₁.mapState (fun _ => CounterLoopState.dec FlagPhase.run)
  have startG : embedEmitCfg gb s₁.workTapes s₁.workTapePos [] g₀ = d₀ := by
    apply canonEmbedEq (binaryGuardTM (B - 1)) gb g₀ d₀ _ _ rfl
      (Fin.ext (by simp [g₀, binaryGuardStart, counter_cfg_eq, guardCfg,
        d₀, s₁, p, Cfg.mapState])) rfl
    · intro i
      have hi : i = Fin.last 0 := Subsingleton.elim _ _
      subst i
      simp only [g₀, binaryGuardStart, counter_cfg_eq, Fin.lastCases_last]
      exact ⟨rfl, rfl⟩
    · exact fun _ _ => ⟨rfl, rfl⟩
  have liftG (u : ℕ) : G.runFrom d₀ u =
      embedEmitCfg gb s₁.workTapes s₁.workTapePos []
        ((binaryGuardTM (B - 1)).runFrom g₀ u) := by
    conv_lhs => rw [← startG]
    exact embedEmitTM_runFrom gb (binaryGuardTM (B - 1)) _ _ [] g₀ u
  let d₁ := embedEmitCfg gb s₁.workTapes s₁.workTapePos [] g₁
  have runG : G.runFrom d₀ tg = d₁ := liftG tg
  have cutDone (u : ℕ) (hu : u < tg) : (G.runFrom d₀ u).state ≠ some .done := by
    rw [liftG]
    exact (cutG u hu).1
  have framed (i : Fin P.k) (hi : i.val ≠ 1) :
      d₁.workTapes i = FinTM.bufferTape (w i) ∧ d₁.workTapePos i = 0 := by
    have outside : i ∉ Set.range gb := by
      rintro ⟨j, hj⟩
      exact hi (congrArg Fin.val hj.symm)
    have frame := (embedEmitTM_frame gb (binaryGuardTM (B - 1))
      s₁.workTapes s₁.workTapePos [] g₀ tg).1 i outside
    rw [embedEmitTM_runFrom] at frame
    exact frame
  have stateD : d₁.state = some (if B * (codeBitsNat bits + 1) ≤ rest.length
      then .done else .escape) := stateG
  have outputD : d₁.output = [] := by simpa only [d₁, embedEmitCfg, List.nil_append] using outG
  have posD : d₁.inputPos.val = (if B * (codeBitsNat bits + 1) ≤ rest.length
      then 2 * bits.length + 2 + B * (codeBitsNat bits + 1) + 1 else α.length + 1) := posG
  have seekBudget (pos : ℕ) (hpos : pos ≤ α.length + 1) :
      b * ((canonOffset bits).length + pos + p + 1) ≤ 5 * b * (α.length + 1) := by
    have width := (canonOffset_spec bits).2
    calc
      _ ≤ b * (5 * (α.length + 1)) := Nat.mul_le_mul_left b (by omega)
      _ = _ := by ring
  have boundS : ts ≤ 5 * b * (α.length + 1) :=
    timeS.trans (seekBudget 1 (by omega))
  have boundG : tg ≤ (B + 6) * (α.length + 1) := by
    calc
      _ ≤ (B + 4) * (α.length + 1) + 2 * (bits.length + 1) := timeG
      _ ≤ _ := by simp only [Nat.add_mul]; omega
  obtain ⟨tp, timeP, cutP, runP⟩ := prep α
  rw [header] at runP
  -- Package the conditional return segment before joining its two callers.
  have tail : ∃ tu ≤ (5 * b + B + 7) * (α.length + 1),
      let z := U.runFrom (d₀.mapState Sum.inl) tu
      z.state = some (if B * (codeBitsNat bits + 1) ≤ rest.length
        then Sum.inr leave else Sum.inl .escape) ∧ z.output = [] ∧
      z.inputPos.val = (if B * (codeBitsNat bits + 1) ≤ rest.length then p else α.length + 1) ∧
      ∀ i, i.val ≠ 1 → z.workTapes i = FinTM.bufferTape (w i) ∧ z.workTapePos i = 0 := by
    by_cases good : B * (codeBitsNat bits + 1) ≤ rest.length
    · have done : d₁.state = some .done := by simpa [good] using stateD
      let r₀ := d₁.mapState (fun _ => enter)
      obtain ⟨tr, timeR, _, runR⟩ := seek p (canonOffset bits) (canonOffset_spec bits).1
        inRange r₀ (by simp [r₀, Cfg.mapState, done])
        (by intro q _ _; simp [r₀, Cfg.mapState, (framed (sb 0) (by simp [sb])).1,
          (framed (sb 0) (by simp [sb])).2, address])
        (by intro q; simp [r₀, Cfg.mapState, (framed (sb 1) (by simp [sb])).1,
          scratch, FinTM.bufferTape])
      have whole := seamCompTM_run_ofCfg G .done R enter runG done cutDone runR
      have boundR : tr ≤ 5 * b * (α.length + 1) :=
        timeR.trans (seekBudget r₀.inputPos.val (by have := r₀.inputPos.isLt; omega))
      refine ⟨tg + 1 + tr, ?_, ?_⟩
      · rw [show 5 * b + B + 7 = (B + 6) + 5 * b + 1 by omega, Nat.add_mul,
          Nat.add_mul, Nat.one_mul]
        omega
      · dsimp only [U]
        rw [whole]
        simp only [good, if_true, Cfg.mapState, Option.map_some]
        exact ⟨True.intro, outputD, True.intro, framed⟩
    · have whole := seamCompTM_runFrom_left G .done R enter cutDone tg le_rfl
      rw [runG] at whole
      refine ⟨tg, boundG.trans (Nat.mul_le_mul_right _ (by omega)), ?_⟩
      dsimp only [U]
      rw [whole]
      simp only [good, if_false, Cfg.mapState, stateD, Option.map_some]
      exact ⟨True.intro, outputD, by simpa [good] using posD, framed⟩
  obtain ⟨tu, timeU, stateU, outU, posU, frameU⟩ := tail
  have firstSeek := seamCompTM_run_ofCfg R leave U (Sum.inl (.dec .run)) runS rfl cutS
    (rfl : U.runFrom (d₀.mapState Sum.inl) tu = _)
  have loaded := seamCompTM_run_ofCfg P.tm pexit V (Sum.inl enter) runP rfl cutP firstSeek
  have loadedC : C.tm.runFrom (Cfg.ofWords (input := α) (Sum.inl pentry) (fun _ => []))
      (tp + 1 + (ts + 1 + tu)) =
      (U.runFrom (d₀.mapState Sum.inl) tu).mapState (fun s => (Sum.inr (Sum.inr s) : C.State)) := by
    simpa only [C, Cfg.ofWords, Cfg.mapState, Option.map_some, Option.map_map,
      Function.comp_def] using loaded
  refine ⟨tp + 1 + (ts + 1 + tu), ?_, ?_⟩
  · have budget := Nat.add_le_add (Nat.add_le_add timeP boundS) timeU
    ring_nf at budget ⊢
    omega
  · dsimp only
    rw [loadedC]
    refine ⟨?_, outU, posU, frameU⟩
    change (U.runFrom (d₀.mapState Sum.inl) tu).state.map
      (fun s => (Sum.inr (Sum.inr s) : C.State)) = _
    rw [stateU]
    split <;> rfl

/-- Read and erase a singleton Boolean result at the selected work head.
The two live exits retain the bit. This one-cell leaf is not supplied by
the catalog's whole-word scans; composition uses the public seam host. -/
private def canonBoolPopTM (k : ℕ) (i : Fin k) : MultiTapeTM k Bool (Option Bool) where
  q₀ := none
  tr := fun q _ w => match q with
    | none => tapeAction i 0 (some none) 0 (some ((w i).getD false))
    | some b => inputMoveAction 0 (some b)

/-- The singleton result is consumed in one silent stationary transition.
Every work tape is blank afterwards, and the native head remains home. -/
private lemma canonBoolPop_run (k : ℕ) (positive : 0 < k) (b : Bool) (x : List Bool) :
    (canonBoolPopTM k ⟨0, positive⟩).runFrom
        (Cfg.ofWords (input := x) none (stateWord k [b])) 1 =
      Cfg.ofWords (some b) (fun _ => []) := by
  have singleton : FinTM.bufferTape [b] =
      Function.update (fun _ : ℤ => (none : Option Bool)) 0 (some b) := by
    simpa using FinTM.bufferTape_append ([] : List Bool) b
  rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  all_goals
    simp [MultiTapeTM.step, canonBoolPopTM, Cfg.ofWords, Cfg.workTapeSymbols,
      stateWord, tapeAction, Action.apply, FinTM.bufferTape]
  · funext j z
    by_cases hj : j.val = 0
    · have he : j = ⟨0, positive⟩ := Fin.ext hj
      subst j
      simp [singleton, Function.update_idem]
    · simp [hj, show j ≠ ⟨0, positive⟩ from fun h => hj (congrArg Fin.val h)]
  · funext j
    split <;> rfl

/-- Any linear-time native-input Boolean computation has a silent clean
branch seam, with distinct exits and cuts at both exits including time zero.
All work tapes are blank on return, and the native head is at one.

**Promotion candidate.** This is a Boolean-result adapter built from the
public input copier, the inherited strict install adapter and the one-cell
result leaf. It is independent of machine formats.

**Proof sketch.** Copy the native input to tape zero and install the singleton
result using the strict call. The final leaf reads and erases it. Until the
call finishes, both result exits lie in an unentered seam summand; the sole
remaining strict-prefix instant is the leaf's entry. All three costs and
the two dispatches are included in the linear bound. -/
private lemma exists_canonBoolBranch (M : FinTM Bool) (p : List Bool → Bool)
    (c : ℕ) (computes : M.ComputesFunInTime (fun x => [p x]) (fun n => c * (n + 1))) :
    ∃ (C : FinTM Bool) (entry : C.State) (exit : Bool → C.State) (a : ℕ),
      0 < C.k ∧ Function.Injective exit ∧
      ∀ x : List Bool, ∃ t ≤ a * (x.length + 1),
        (∀ u < t, ∀ b, (C.tm.runFrom
          (Cfg.ofWords (input := x) entry (fun _ => [])) u).state ≠ some (exit b)) ∧
        C.tm.runFrom (Cfg.ofWords (input := x) entry (fun _ => [])) t =
          Cfg.ofWords (exit (p x)) (fun _ => []) := by
  classical
  obtain ⟨I, enter, leave, a, positive, install⟩ :=
    canonStrictInstall M (fun x => [p x]) (fun n => c * (n + 1)) computes
  let i : Fin I.k := ⟨0, positive⟩
  let P := seamCompTM (inputCopyTM I.k i) .done I.tm enter
  let V := canonBoolPopTM I.k i
  let C : FinTM Bool := {
    k := I.k
    State := (SweepPhase ⊕ I.State) ⊕ Option Bool
    tm := { seamCompTM P (Sum.inr leave) V none with
      q₀ := Sum.inl (Sum.inl .sweep) } }
  refine ⟨C, Sum.inl (Sum.inl .sweep), fun b => Sum.inr (some b),
    a * (c + 2) + 5, positive, ?_, ?_⟩
  · intro b d eq
    exact Option.some.inj (Sum.inr.inj eq)
  · intro x
    let initial : Cfg I.k Bool SweepPhase x :=
      Cfg.ofWords (input := x) SweepPhase.sweep (fun _ => [])
    have copy := inputCopyTM_run_ofCfg i initial rfl rfl
    have copied : (inputCopyTM I.k i).runFrom initial (2 * x.length + 2) =
        Cfg.ofWords .done (stateWord I.k x) := by
      rw [copy.1]
      apply Cfg.ext <;> try rfl
      funext j z
      by_cases hj : j = i
      · subst j
        simp only [initial, Cfg.ofWords, stateWord, i, ↓reduceIte, zero_add, sub_zero]
        split_ifs with hz
        · rfl
        · by_cases hn : 0 ≤ z
          · have outside : ¬(0 ≤ z ∧ z < (x.length : ℤ)) := by simpa using hz
            simp [FinTM.bufferTape, hn,
              List.getElem?_eq_none (by omega : x.length ≤ z.toNat)]
          · simp [FinTM.bufferTape, hn]
      · have nz : j.val ≠ 0 := fun h => hj (Fin.ext h)
        simp [initial, Cfg.ofWords, stateWord, hj, nz]
    obtain ⟨t, time, _, cut, run⟩ := install x x
    have first := seamCompTM_run_ofCfg (inputCopyTM I.k i) .done I.tm enter
      copied rfl copy.2.1 run
    have firstCut := seamCompTM_firstReturn_ofCfg (inputCopyTM I.k i) .done I.tm enter leave
      copied rfl copy.2.1 run rfl cut
    let duration := 2 * x.length + 2 + 1 + t
    let middle := (Cfg.ofWords (input := x) leave (stateWord I.k [p x])).mapState
      (Sum.inr : I.State → SweepPhase ⊕ I.State)
    have pop : V.runFrom (middle.mapState (fun _ => none)) 1 =
        Cfg.ofWords (some (p x)) (fun _ => []) := canonBoolPop_run I.k positive (p x) x
    have whole := seamCompTM_run_ofCfg P (Sum.inr leave) V none
      first rfl firstCut pop
    refine ⟨duration + 1 + 1, ?_, ?_, ?_⟩
    · simp only [List.length_cons, List.length_nil, Nat.zero_add] at time
      have bound : t ≤ a * (c + 2) * (x.length + 1) := by
        apply time.trans
        rw [Nat.mul_assoc]
        apply Nat.mul_le_mul_left a
        rw [Nat.add_mul]
        omega
      dsimp only [duration]
      rw [Nat.add_mul]
      omega
    · intro u hu b
      change ((seamCompTM P (Sum.inr leave) V none).runFrom
        ((initial.mapState Sum.inl).mapState Sum.inl) u).state ≠ some (Sum.inr (some b))
      by_cases early : u ≤ duration
      · rw [seamCompTM_runFrom_left P (Sum.inr leave) V none firstCut u early]
        simp [Cfg.mapState]
      · have atLeaf : u = duration + 1 := by omega
        rw [atLeaf]
        have dispatch := seamCompTM_run_ofCfg P (Sum.inr leave) V none
          first rfl firstCut (rfl : V.runFrom (middle.mapState (fun _ => none)) 0 = _)
        simp only [Nat.add_zero] at dispatch
        rw [dispatch]
        simp [middle, Cfg.mapState, Cfg.ofWords]
    · simpa only [C, initial, duration, Cfg.ofWords, Cfg.mapState, Option.map_some] using whole

/-- The total header check returns a clean live verdict, so its successful
branch may start the existing blank-tape preparation without any cleanup. -/
private lemma exists_canonHeaderBranch :
    ∃ (C : FinTM Bool) (entry : C.State) (exit : Bool → C.State) (a : ℕ),
      0 < C.k ∧ Function.Injective exit ∧
      ∀ x : List Bool, ∃ t ≤ a * (x.length + 1),
        (∀ u < t, ∀ b, (C.tm.runFrom
          (Cfg.ofWords (input := x) entry (fun _ => [])) u).state ≠ some (exit b)) ∧
        C.tm.runFrom (Cfg.ofWords (input := x) entry (fun _ => [])) t =
          Cfg.ofWords (exit (canonHeaderOK x)) (fun _ => []) := by
  obtain ⟨M, c, computes⟩ := exists_canonHeaderOKTM
  exact exists_canonBoolBranch M canonHeaderOK c computes

/-- A negative total header verdict has exactly the prescribed fallback
semantics, including malformed pairs whose extracted header is empty. -/
private lemma decode_of_canonHeader (F : MachineFormat) (x : List Bool)
    (invalid : canonHeaderOK x = false) : F.decode x = F.fallback := by
  apply F.decode_of_parseFull_none
  have scan := scan_eq_none_of_canonHeaderOK F x invalid
  rw [F.scan_full] at scan
  exact Option.map_eq_none_iff.mp scan

/-- Prefix avoidance in a public seam composition, for an arbitrary
composite control state. Both the chosen and the unchosen branch exits can
therefore be protected, without asserting that either is the final state.

**Promotion candidate.** This is a two-segment consequence of the public
seam run equations, not a new host or a second machine trace.

**Proof sketch.** Before dispatch use the public left-prefix identity;
after dispatch use its public run identity at the remaining time. Apply
the corresponding supplied avoidance predicate in the two intervals. -/
private lemma canonSeam_avoids {k : ℕ} {S R : Type} [DecidableEq S]
    {x : List Bool} (A : MultiTapeTM k Bool S) (leave : S)
    (B : MultiTapeTM k Bool R) (enter : R) (target : S ⊕ R)
    {d e : Cfg k Bool S x} {t v : ℕ}
    (run : A.runFrom d t = e) (atExit : e.state = some leave)
    (first : ∀ u < t, (A.runFrom d u).state ≠ some leave)
    (before : ∀ u ≤ t, ((A.runFrom d u).mapState (Sum.inl : S → S ⊕ R)).state ≠
      some target)
    (after : ∀ u < v,
      ((B.runFrom (e.mapState (fun _ => enter)) u).mapState (Sum.inr : R → S ⊕ R)).state ≠
        some target) :
    ∀ u < t + 1 + v,
      ((seamCompTM A leave B enter).runFrom (d.mapState Sum.inl) u).state ≠
        some target := by
  intro u hu
  by_cases left : u ≤ t
  · rw [seamCompTM_runFrom_left A leave B enter first u left]
    exact before u left
  · obtain ⟨r, hr⟩ : ∃ r, u = t + 1 + r := ⟨u - (t + 1), by omega⟩
    rw [hr, seamCompTM_run_ofCfg A leave B enter run atExit first rfl]
    exact after r (by omega)

/-- Select the guard counter alone; all other live words lie in the frame. -/
private def canonCounterBank {k : ℕ} (i : Fin k) : Fin 1 ↪ Fin k :=
  ⟨fun _ => i, fun _ _ _ => Subsingleton.elim _ _⟩

/-- The inherited physical guard on one selected counter tape, with an
arbitrary ambient bank. No post-guard property of that counter is assumed.
Both exit cuts and the exact frame survive the public embedding.

**Proof sketch.** Identify the selected tape and native head with the
inherited guard's preloaded start using the existing configuration assembly
lemma. Transport its run by the public embedding equation, and project the
public frame. The predecessor's guard proof supplies all branch semantics,
positions, cuts and the numerical-value-independent time bound. -/
private lemma canonGuard_onBank {k : ℕ} (i : Fin k) (F : MachineFormat)
    (x bits rest : List Bool) (pair : pairDecode x = some (bits, rest))
    (d : Cfg k Bool (CounterLoopState (Option (Fin (canonGuardBlock F - 1 + 1)))) x)
    (control : d.state = some (.dec .run))
    (position : d.inputPos.val = 2 * bits.length + 3)
    (counter : d.workTapes i = FinTM.bufferTape (canonCount bits))
    (home : d.workTapePos i = 0) (silent : d.output = []) :
    let G := embedEmitTM (canonCounterBank i) (binaryGuardTM (canonGuardBlock F - 1))
    ∃ t ≤ (canonGuardBlock F + 6) * (x.length + 1),
      let e := G.runFrom d t
      e.state = some (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
        then .done else .escape) ∧ e.output = [] ∧
      e.inputPos.val = (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
        then 2 * bits.length + 3 + canonGuardBlock F * (codeBitsNat bits + 1)
        else x.length + 1) ∧
      (∀ u < t, (G.runFrom d u).state ≠ some .done ∧
        (G.runFrom d u).state ≠ some .escape) ∧
      ∀ j, j ≠ i → e.workTapes j = d.workTapes j ∧ e.workTapePos j = d.workTapePos j := by
  obtain ⟨hpos, elapsed, budget, finish, output, native, cuts⟩ := canonGuard_run F x bits rest pair
  let src := binaryGuardStart (canonGuardBlock F - 1) x (2 * bits.length + 2) hpos []
    (canonCount bits)
  have identified : embedEmitCfg (canonCounterBank i) d.workTapes d.workTapePos [] src = d := by
    apply canonEmbedEq (binaryGuardTM (canonGuardBlock F - 1)) (canonCounterBank i)
      src d _ _ control.symm (Fin.ext (by simpa [src, binaryGuardStart,
        counter_cfg_eq, guardCfg, Nat.add_assoc] using position.symm)) silent.symm
    · intro j
      have last : j = Fin.last 0 := Subsingleton.elim _ _
      subst j
      simp only [src, binaryGuardStart, counter_cfg_eq, Fin.lastCases_last]
      exact ⟨counter.symm, home.symm⟩
    · exact fun _ _ => ⟨rfl, rfl⟩
  have transported (u : ℕ) :
      (embedEmitTM (canonCounterBank i) (binaryGuardTM (canonGuardBlock F - 1))).runFrom d u =
        embedEmitCfg (canonCounterBank i) d.workTapes d.workTapePos []
          ((binaryGuardTM (canonGuardBlock F - 1)).runFrom src u) := by
    conv_lhs => rw [← identified]
    exact embedEmitTM_runFrom _ _ _ _ _ _ u
  have length : bits.length ≤ x.length := by
    have loaded := canonHeader_length x
    simpa [canonHeader, pair] using loaded
  refine ⟨elapsed, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [Nat.add_mul] at budget ⊢
    omega
  · rw [transported]
    exact finish
  · rw [transported]
    exact output
  · rw [transported]
    change ((binaryGuardTM (canonGuardBlock F - 1)).runFrom src elapsed).inputPos.val = _
    change ((binaryGuardTM (canonGuardBlock F - 1)).runFrom src elapsed).inputPos.val = _ at native
    split_ifs at native ⊢ <;> omega
  · intro u hu
    rw [transported]
    exact cuts u hu
  · intro j hj
    have notSelected : j ∉ Set.range (canonCounterBank i) := by
      rintro ⟨q, eq⟩
      exact hj eq.symm
    have frame := (embedEmitTM_frame (canonCounterBank i)
      (binaryGuardTM (canonGuardBlock F - 1)) d.workTapes d.workTapePos [] src elapsed).1
        j notSelected
    rw [identified] at frame
    exact frame

/-- From the prepared bank, seek to the remainder, run the inherited guard
on tape one, and seek back on success. Both final ports have strict cuts;
the header, saved address and every non-counter tape are preserved.

**Proof sketch.** Use the public seek contract twice, with the framed guard
between them. The success branch dispatches to the second seek; the failure
branch stops before that dispatch. The arbitrary-target seam cut protects
both ports in either case. A second public seam attaches the first seek.
All seeks, guard work and dispatches are charged to a linear bound. -/
private lemma exists_canonGuardReady (F : MachineFormat) (k : ℕ) (hk : 4 ≤ k) :
    ∃ (S : Type) (_ : Fintype S) (_ : DecidableEq S)
      (C : MultiTapeTM k Bool S) (entry : S) (exit : Bool → S) (a : ℕ),
      Function.Injective exit ∧ ∀ x bits rest : List Bool,
        pairDecode x = some (bits, rest) → ∃ t ≤ a * (x.length + 1),
          let start := Cfg.ofWords (input := x) entry (canonReadyWords k bits)
          let e := C.runFrom start t
          e.state = some (exit (decide
            (canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length))) ∧
          e.output = [] ∧ e.inputPos.val =
            (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
              then 2 * bits.length + 3 else x.length + 1) ∧
          (∀ u < t, ∀ b, (C.runFrom start u).state ≠ some (exit b)) ∧
          ∀ j, j.val ≠ 1 →
            e.workTapes j = FinTM.bufferTape (canonReadyWords k bits j) ∧
              e.workTapePos j = 0 := by
  classical
  let addressBank : Fin 2 ↪ Fin k :=
    ⟨fun j => ⟨j.val + 2, by have := j.isLt; omega⟩,
      fun j l eq => Fin.ext (by have := congrArg Fin.val eq; dsimp at this; omega)⟩
  let counter : Fin k := ⟨1, by omega⟩
  obtain ⟨S, finite, equal, R, enter, leave, c, seek⟩ := exists_canonSeekOnBank addressBank
  letI : Fintype S := finite
  letI : DecidableEq S := equal
  let G := embedEmitTM (canonCounterBank counter) (binaryGuardTM (canonGuardBlock F - 1))
  let U := seamCompTM G .done R enter
  let C := seamCompTM R leave U (Sum.inl (.dec .run))
  let port (b : Bool) : CounterLoopState (Option (Fin (canonGuardBlock F - 1 + 1))) ⊕ S :=
    if b then Sum.inr leave else Sum.inl .escape
  refine ⟨_, inferInstance, inferInstance, C, Sum.inl enter,
    fun b => Sum.inr (port b), 10 * c + canonGuardBlock F + 8, ?_, ?_⟩
  · intro b d eq
    cases b <;> cases d <;> simp_all [port]
  · intro x bits rest pair
    let p := 2 * bits.length + 3
    let words := canonReadyWords k bits
    let beginning := Cfg.ofWords (input := x) enter words
    have size : bits.length ≤ x.length := by
      simpa [canonHeader, pair] using canonHeader_length x
    have range : p ≤ x.length + 1 := by
      rw [eq_pairEncode_of_pairDecode x bits rest pair, length_pairEncode]
      dsimp [p]
      omega
    have charge (pos : ℕ) (small : pos ≤ x.length + 1) :
        c * ((canonOffset bits).length + pos + p + 1) ≤ 5 * c * (x.length + 1) := by
      calc
        _ ≤ c * (5 * (x.length + 1)) :=
          Nat.mul_le_mul_left c (by have := (canonOffset_spec bits).2; omega)
        _ = _ := by ring
    obtain ⟨s, costS, firstS, ranS⟩ := seek p (canonOffset bits) (canonOffset_spec bits).1
      range beginning rfl
      (by intro z _ _; simp [beginning, Cfg.ofWords, words, canonReadyWords, addressBank])
      (by intro z; simp [beginning, Cfg.ofWords, words, canonReadyWords, addressBank])
    let afterSeek : Cfg k Bool S x :=
      { beginning with state := some leave, inputPos := ⟨p, by omega⟩ }
    change R.runFrom beginning s = afterSeek at ranS
    let guardStart : Cfg k Bool
        (CounterLoopState (Option (Fin (canonGuardBlock F - 1 + 1)))) x :=
      afterSeek.mapState (fun _ => CounterLoopState.dec FlagPhase.run)
    obtain ⟨g, costG, guardState, guardOutput, guardPos, guardCut, guardFrame⟩ :=
      canonGuard_onBank counter F x bits rest pair guardStart rfl rfl rfl rfl rfl
    let guarded := G.runFrom guardStart g
    have frame (j : Fin k) (hj : j.val ≠ 1) :
        guarded.workTapes j = FinTM.bufferTape (words j) ∧ guarded.workTapePos j = 0 :=
      guardFrame j (fun eq => hj (congrArg Fin.val eq))
    have cutDone : ∀ u < g, (G.runFrom guardStart u).state ≠ some .done :=
      fun u hu => (guardCut u hu).1
    have tail : ∃ v ≤ (5 * c + canonGuardBlock F + 7) * (x.length + 1),
        let e := U.runFrom (guardStart.mapState Sum.inl) v
        e.state = some (port (decide
          (canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length))) ∧
        e.output = [] ∧ e.inputPos.val =
          (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
            then p else x.length + 1) ∧
        (∀ u < v, ∀ b, (U.runFrom (guardStart.mapState Sum.inl) u).state ≠ some (port b)) ∧
        ∀ j, j.val ≠ 1 → e.workTapes j = FinTM.bufferTape (words j) ∧ e.workTapePos j = 0 := by
      by_cases fits : canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
      · have done : guarded.state = some .done := by simpa [fits] using guardState
        let rewind := guarded.mapState (fun _ => enter)
        obtain ⟨r, costR, firstR, ranR⟩ := seek p (canonOffset bits) (canonOffset_spec bits).1
          range rewind (by simp [rewind, Cfg.mapState, done])
          (by
            intro z _ _
            change guarded.workTapes (addressBank 0)
              (guarded.workTapePos (addressBank 0) + z) = _
            rw [(frame (addressBank 0) (by simp [addressBank])).1,
              (frame (addressBank 0) (by simp [addressBank])).2]
            simp [words, canonReadyWords, addressBank])
          (by
            intro z
            change guarded.workTapes (addressBank 1) z = _
            rw [(frame (addressBank 1) (by simp [addressBank])).1]
            simp [words, canonReadyWords, addressBank])
        have whole := seamCompTM_run_ofCfg G .done R enter rfl done cutDone ranR
        have budgetR := costR.trans (charge rewind.inputPos.val
          (by have := rewind.inputPos.isLt; omega))
        refine ⟨g + 1 + r, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · simp only [Nat.add_mul] at costG ⊢
          omega
        · rw [whole]
          simp [fits, port, Cfg.mapState]
        · rw [whole]
          exact guardOutput
        · rw [whole]
          simp [fits, Cfg.mapState]
        · intro u hu b
          apply canonSeam_avoids G .done R enter (port b) rfl done cutDone
            (v := r) ?_ ?_ u hu
          · intro z hz
            cases b with
            | true => simp [port, Cfg.mapState]
            | false =>
              have avoids : (G.runFrom guardStart z).state ≠ some .escape := by
                by_cases strict : z < g
                · exact (guardCut z strict).2
                · have eq : z = g := by omega
                  rw [eq]
                  simp only [show G.runFrom guardStart g = guarded from rfl, done]
                  simp
              simpa [port, Cfg.mapState] using avoids
          · intro z hz
            cases b with
            | true => simpa [port, Cfg.mapState] using firstR z hz
            | false => simp [port, Cfg.mapState]
        · rw [whole]
          exact frame
      · have leftRun (u : ℕ) (hu : u ≤ g) :=
          seamCompTM_runFrom_left G .done R enter cutDone u hu
        refine ⟨g, costG.trans (Nat.mul_le_mul_right _ (by omega)), ?_, ?_, ?_, ?_, ?_⟩
        · rw [leftRun g le_rfl]
          simpa [fits, port, Cfg.mapState] using guardState
        · rw [leftRun g le_rfl]
          exact guardOutput
        · rw [leftRun g le_rfl]
          simpa [fits] using guardPos
        · intro u hu b
          rw [leftRun u hu.le]
          cases b with
          | true => simp [port, Cfg.mapState]
          | false => simpa [port, Cfg.mapState] using (guardCut u hu).2
        · rw [leftRun g le_rfl]
          exact frame
    obtain ⟨v, costV, stateV, outputV, posV, cutV, frameV⟩ := tail
    have all := seamCompTM_run_ofCfg R leave U (Sum.inl (.dec .run))
      ranS rfl firstS (rfl : U.runFrom (guardStart.mapState Sum.inl) v = _)
    change C.runFrom (Cfg.ofWords (input := x) (Sum.inl enter) words) (s + 1 + v) = _ at all
    have budgetS := costS.trans (charge 1 (by omega))
    refine ⟨s + 1 + v, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · have budget := Nat.add_le_add budgetS costV
      ring_nf at budget ⊢
      omega
    · rw [all]
      change ((U.runFrom (guardStart.mapState Sum.inl) v).state.map Sum.inr) = _
      rw [stateV]
      rfl
    · rw [all]
      exact outputV
    · rw [all]
      exact posV
    · intro u hu b
      apply canonSeam_avoids R leave U (Sum.inl (.dec .run)) (Sum.inr (port b))
        ranS rfl firstS (v := v) ?_ ?_ u hu
      · intro z _
        simp [Cfg.mapState]
      · intro z hz
        simpa [Cfg.mapState] using cutV z hz b
    · rw [all]
      exact frameV

/-- A separate strengthening of the frozen guard front end: both Boolean
ports are distinct and have cuts including time zero. Preparation starts
from blank tapes and the non-counter bank is retained on either verdict.

**Proof sketch.** Compose the inherited preparation seam with the prepared
bank guard. The public seam supplies the run; arbitrary-target avoidance
transports both cuts. The two component bounds and the dispatch are linear. -/
private lemma exists_canonGuardFrontStrict (F : MachineFormat) :
    ∃ (C : FinTM Bool) (entry : C.State) (exit : Bool → C.State) (a : ℕ),
      4 ≤ C.k ∧ Function.Injective exit ∧ ∀ x bits rest : List Bool,
        pairDecode x = some (bits, rest) → ∃ t ≤ a * (x.length + 1),
          let start := Cfg.ofWords (input := x) entry (fun _ => [])
          let e := C.tm.runFrom start t
          e.state = some (exit (decide
            (canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length))) ∧
          e.output = [] ∧ e.inputPos.val =
            (if canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length
              then 2 * bits.length + 3 else x.length + 1) ∧
          (∀ u < t, ∀ b, (C.tm.runFrom start u).state ≠ some (exit b)) ∧
          ∀ j, j.val ≠ 1 →
            e.workTapes j = FinTM.bufferTape (canonReadyWords C.k bits j) ∧
              e.workTapePos j = 0 := by
  classical
  obtain ⟨P, pentry, pexit, a, hk, prep⟩ := exists_canonReadySeam
  obtain ⟨S, finite, equal, G, enter, leave, b, distinct, guard⟩ :=
    exists_canonGuardReady F P.k hk
  letI : Fintype S := finite
  letI : DecidableEq S := equal
  let C : FinTM Bool := {
    k := P.k
    State := P.State ⊕ S
    tm := { seamCompTM P.tm pexit G enter with q₀ := Sum.inl pentry } }
  refine ⟨C, Sum.inl pentry, fun d => Sum.inr (leave d), a + b + 1, hk,
    fun _ _ eq => distinct (Sum.inr.inj eq), ?_⟩
  intro x bits rest pair
  obtain ⟨s, budgetS, firstS, ranS⟩ := prep x
  have header : canonHeader x = bits := by simp [canonHeader, pair]
  rw [header] at ranS
  obtain ⟨t, budgetT, stateT, outputT, posT, cutT, frameT⟩ := guard x bits rest pair
  have whole := seamCompTM_run_ofCfg P.tm pexit G enter ranS rfl firstS
    (rfl : G.runFrom (Cfg.ofWords (input := x) enter (canonReadyWords P.k bits)) t = _)
  change C.tm.runFrom (Cfg.ofWords (input := x) (Sum.inl pentry) (fun _ => []))
    (s + 1 + t) = _ at whole
  refine ⟨s + 1 + t, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [Nat.add_mul, Nat.add_mul]
    omega
  · rw [whole]
    simp only [Cfg.mapState, stateT, Option.map_some]
  · rw [whole]
    exact outputT
  · rw [whole]
    exact posT
  · intro u hu d
    apply canonSeam_avoids P.tm pexit G enter (Sum.inr (leave d))
      ranS rfl firstS (v := t) ?_ ?_ u hu
    · intro z _
      simp [Cfg.mapState]
    · intro z hz
      simpa [Cfg.mapState] using cutT z hz d
  · rw [whole]
    exact frameT

/-- Transport a blank-tape start along any public bank embedding.
This is only a specialization of the existing word-configuration assembly
and public run transport, and adds no configuration reconstruction. -/
private lemma canonBlankLift {m k : ℕ} {S : Type} (M : MultiTapeTM m Bool S)
    (bank : Fin m ↪ Fin k) (q : S) (x : List Bool) (t : ℕ) :
    (embedEmitTM bank M).runFrom (Cfg.ofWords (input := x) q (fun _ => [])) t =
      embedEmitCfg bank (fun _ => FinTM.bufferTape []) (fun _ => 0) []
        (M.runFrom (Cfg.ofWords (input := x) q (fun _ => [])) t) := by
  rw [← canonEmbedWords M bank q (fun _ => []) (fun _ => []) (fun _ => [])
    (fun _ => rfl) (fun _ _ => rfl)]
  exact embedEmitTM_runFrom bank M _ _ _ _ t

/-- Total header checking followed by the strong guard. Three distinct live
ports retain the cause of rejection: `none` is a malformed or noncanonical
header, `some false` is a failed positive guard, and `some true` is ready
for parsing. Every rejection decodes to the fixed fallback. Both guard
ports and the header-failure port have strict cuts including time zero.

**Proof sketch.** Embed the clean header branch and the strong guard into
the larger bank. A public seam dispatches only the valid-header exit.
Invalid headers stop before dispatch; valid headers use the guard contract.
The public selected-tape and frame projections retain the ready bank, and
the inherited scanner rejection laws identify both failures with fallback. -/
private lemma exists_canonCheckedFront (F : MachineFormat) :
    ∃ (C : FinTM Bool) (entry : C.State) (exit : Option Bool → C.State) (a : ℕ),
      4 ≤ C.k ∧ Function.Injective exit ∧ ∀ x : List Bool,
        ∃ t ≤ a * (x.length + 1), ∃ verdict : Option Bool,
          let start := Cfg.ofWords (input := x) entry (fun _ => [])
          let e := C.tm.runFrom start t
          e.state = some (exit verdict) ∧ e.output = [] ∧
          (∀ u < t, ∀ q, (C.tm.runFrom start u).state ≠ some (exit q)) ∧
          (verdict ≠ some true → F.decode x = F.fallback) ∧
          (verdict = some true → ∃ bits rest,
            pairDecode x = some (bits, rest) ∧ bits = (codeBitsNat bits).bits ∧
            canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length ∧
            e.inputPos.val = 2 * bits.length + 3 ∧
            ∀ j, j.val ≠ 1 →
              e.workTapes j = FinTM.bufferTape (canonReadyWords C.k bits j) ∧
                e.workTapePos j = 0) := by
  classical
  obtain ⟨H, hentry, hexit, a, _, hdistinct, header⟩ := exists_canonHeaderBranch
  obtain ⟨G, gentry, gexit, b, gsize, gdistinct, guard⟩ := exists_canonGuardFrontStrict F
  let K := max H.k G.k
  let hb : Fin H.k ↪ Fin K := Fin.castLEEmb (Nat.le_max_left _ _)
  let gb : Fin G.k ↪ Fin K := Fin.castLEEmb (Nat.le_max_right _ _)
  let A := embedEmitTM hb H.tm
  let B := embedEmitTM gb G.tm
  let C : FinTM Bool := {
    k := K
    State := H.State ⊕ G.State
    tm := { seamCompTM A (hexit true) B gentry with q₀ := Sum.inl hentry } }
  let exit : Option Bool → C.State
    | none => Sum.inl (hexit false)
    | some d => Sum.inr (gexit d)
  refine ⟨C, Sum.inl hentry, exit, a + b + 1,
    gsize.trans (Nat.le_max_right _ _), ?_, ?_⟩
  · intro p q eq
    cases p <;> cases q
    · rfl
    · cases eq
    · cases eq
    · exact congrArg some (gdistinct (Sum.inr.inj eq))
  · intro x
    obtain ⟨s, budgetH, cutH, ranH⟩ := header x
    let startH := Cfg.ofWords (input := x) hentry (fun _ : Fin K => [])
    have headerRun : A.runFrom startH s =
        Cfg.ofWords (hexit (canonHeaderOK x)) (fun _ => []) := by
      rw [canonBlankLift H.tm hb, ranH]
      exact canonEmbedWords H.tm hb _ (fun _ => []) (fun _ => []) (fun _ => [])
        (fun _ => rfl) (fun _ _ => rfl)
    have headerCut (u : ℕ) (hu : u < s) (d : Bool) :
        (A.runFrom startH u).state ≠ some (hexit d) := by
      rw [canonBlankLift H.tm hb]
      exact cutH u hu d
    cases valid : canonHeaderOK x with
    | false =>
      have leftRun := seamCompTM_runFrom_left A (hexit true) B gentry
        (fun u hu => headerCut u hu true) s le_rfl
      rw [headerRun, valid] at leftRun
      change C.tm.runFrom (Cfg.ofWords (input := x) (Sum.inl hentry) (fun _ => [])) s =
        Cfg.ofWords (exit none) (fun _ => []) at leftRun
      refine ⟨s, budgetH.trans (Nat.mul_le_mul_right _ (by omega)), none,
        ?_, ?_, ?_, ?_, ?_⟩
      · rw [leftRun]
        rfl
      · rw [leftRun]
        rfl
      · intro u hu q
        change ((seamCompTM A (hexit true) B gentry).runFrom (startH.mapState Sum.inl) u).state ≠ _
        rw [seamCompTM_runFrom_left A (hexit true) B gentry
          (fun z hz => headerCut z hz true) u hu.le]
        cases q with
        | none => simpa [exit, Cfg.mapState] using headerCut u hu false
        | some q => simp [exit, Cfg.mapState]
      · exact fun _ => decode_of_canonHeader F x valid
      · simp
    | true =>
      obtain ⟨bits, rest, pair, canonical⟩ := (canonHeaderOK_iff x).mp valid
      obtain ⟨t, budgetG, stateG, outputG, posG, cutG, frameG⟩ := guard x bits rest pair
      let result := decide (canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length)
      let startG := Cfg.ofWords (input := x) gentry (fun _ : Fin K => [])
      let endG := B.runFrom startG t
      have state : endG.state = some (gexit result) := by
        dsimp only [endG]
        rw [canonBlankLift G.tm gb]
        exact stateG
      have silent : endG.output = [] := by
        dsimp only [endG]
        rw [canonBlankLift G.tm gb]
        exact outputG
      have cut (u : ℕ) (hu : u < t) (d : Bool) :
          (B.runFrom startG u).state ≠ some (gexit d) := by
        rw [canonBlankLift G.tm gb]
        exact cutG u hu d
      rw [valid] at headerRun
      have whole := seamCompTM_run_ofCfg A (hexit true) B gentry headerRun rfl
        (fun u hu => headerCut u hu true) (rfl : B.runFrom startG t = endG)
      change C.tm.runFrom (Cfg.ofWords (input := x) (Sum.inl hentry) (fun _ => []))
        (s + 1 + t) = endG.mapState Sum.inr at whole
      refine ⟨s + 1 + t, ?_, some result, ?_, ?_, ?_, ?_, ?_⟩
      · rw [Nat.add_mul, Nat.add_mul]
        omega
      · rw [whole]
        change endG.state.map Sum.inr = _
        rw [state]
        rfl
      · rw [whole]
        exact silent
      · intro u hu q
        apply canonSeam_avoids A (hexit true) B gentry (exit q) headerRun rfl
          (fun z hz => headerCut z hz true) (v := t) ?_ ?_ u hu
        · intro z hz
          cases q with
          | some d => simp [exit, Cfg.mapState]
          | none =>
            have avoids : (A.runFrom startH z).state ≠ some (hexit false) := by
              by_cases early : z < s
              · exact headerCut z early false
              · have eq : z = s := by omega
                rw [eq, headerRun]
                exact fun h => Bool.noConfusion (hdistinct (Option.some.inj h))
            simpa [exit, Cfg.mapState] using avoids
        · intro z hz
          cases q with
          | none => simp [exit, Cfg.mapState]
          | some d => simpa [exit, Cfg.mapState] using cut z hz d
      · intro rejected
        apply decode_of_canonGuard F x bits rest pair
        have denied : result ≠ true := fun eq => rejected (congrArg some eq)
        exact Nat.lt_of_not_ge (of_decide_eq_false (Bool.eq_false_iff.mpr denied))
      · intro accepted
        have fits : canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length :=
          of_decide_eq_true (Option.some.inj accepted)
        refine ⟨bits, rest, pair, canonical, fits, ?_, ?_⟩
        · rw [whole]
          change endG.inputPos.val = _
          dsimp only [endG]
          rw [canonBlankLift G.tm gb]
          simpa only [if_pos fits] using posG
        · intro j hj
          rw [whole]
          change endG.workTapes j = _ ∧ endG.workTapePos j = 0
          by_cases selected : j ∈ Set.range gb
          · obtain ⟨i, rfl⟩ := selected
            dsimp only [endG]
            rw [canonBlankLift G.tm gb, embedEmitCfg_selected_tape, embedEmitCfg_selected_pos]
            exact frameG i hj
          · have fixed := (embedEmitTM_frame gb G.tm (fun _ => FinTM.bufferTape [])
              (fun _ => 0) [] (Cfg.ofWords (input := x) gentry (fun _ => [])) t).1 j selected
            rw [canonEmbedWords G.tm gb gentry (fun _ => []) (fun _ => []) (fun _ => [])
              (fun _ => rfl) (fun _ _ => rfl)] at fixed
            have large : G.k ≤ j.val := by
              by_contra small
              exact selected ⟨⟨j.val, by omega⟩, rfl⟩
            simpa [canonReadyWords, show j.val ≠ 0 by omega,
              show j.val ≠ 1 by omega, show j.val ≠ 2 by omega] using fixed

/-- Merge the three checked-front ports into two ports with one public
phase-host dispatch. `some true` succeeds and the other two ports reject.
The dispatch preserves all data fields and gives strict cuts at both ports.

**Promotion candidate.** This finite verdict adapter is independent of
machine formats; it uses the public phase host, with no private host trace.

**Proof sketch.** Before the source exit, its three cuts disable every
redirect. The public phase contract therefore gives the whole prefix and
one stationary dispatch into the terminal phase. Distinct phase tags prove
both strict cuts. The terminal phase reuses the existing stationary Boolean
ports; no terminal transition is executed by this contract. -/
private lemma canonExitDispatch {k : ℕ} {S : Type} [Fintype S] [DecidableEq S]
    (positive : 0 < k) (M : MultiTapeTM k Bool S) (start : S)
    (exit : Option Bool → S) (distinct : Function.Injective exit) :
    ∃ (R : Type) (_ : Fintype R) (_ : DecidableEq R) (N : MultiTapeTM k Bool R)
      (entry : R) (leave : Bool → R), Function.Injective leave ∧
      ∀ (x : List Bool) (t : ℕ) (v : Option Bool),
        let d := Cfg.ofWords (input := x) start (fun _ => [])
        (M.runFrom d t).state = some (exit v) →
        (∀ u < t, ∀ q, (M.runFrom d u).state ≠ some (exit q)) →
        N.runFrom (Cfg.ofWords entry (fun _ => [])) (t + 1) =
          (M.runFrom d t).mapState (fun _ => leave (decide (v = some true))) ∧
        ∀ u < t + 1, ∀ b, (N.runFrom
          (Cfg.ofWords (input := x) entry (fun _ => [])) u).state ≠ some (leave b) := by
  classical
  let Ph : Bool → Type
    | false => S
    | true => Option Bool
  let family (b : Bool) : MultiTapeTM k Bool (Ph b) := match b with
    | false => M
    | true => canonBoolPopTM k ⟨0, positive⟩
  letI : ∀ b, Fintype (Ph b) := fun b => by cases b <;> exact inferInstance
  letI : ∀ b, DecidableEq (Ph b) := fun b => by cases b <;> exact inferInstance
  let base : (b : Bool) × Ph b := ⟨false, start⟩
  let leave (b : Bool) : (p : Bool) × Ph p := ⟨true, some b⟩
  let red (b : Bool) : Ph b → Option ((p : Bool) × Ph p) := match b with
    | false => fun q =>
      if q = exit none then some (leave false)
      else if q = exit (some false) then some (leave false)
      else if q = exit (some true) then some (leave true) else none
    | true => fun _ => none
  let N := phaseHostTM family base red
  refine ⟨_, inferInstance, inferInstance, N, base, leave, ?_, ?_⟩
  · intro b c eq
    exact Option.some.inj (eq_of_heq (Sigma.mk.inj_iff.mp eq).2)
  · intro x t v d control cuts
    have redirect : red false (exit v) = some (leave (decide (v = some true))) := by
      cases v with
      | none => simp [red]
      | some b => cases b <;> simp [red, distinct.eq_iff]
    have disabled (u : ℕ) (hu : u < t) (s : S) (hs : (M.runFrom d u).state = some s) :
        red false s = none := by
      have avoids (q : Option Bool) : s ≠ exit q :=
        fun eq => cuts u hu q (hs.trans (congrArg some eq))
      simp only [red, if_neg (avoids none), if_neg (avoids (some false)),
        if_neg (avoids (some true))]
    have phase := phaseHostTM_run family base red false d (M.runFrom d t) t rfl
      (exit v) control (leave (decide (v = some true))) redirect disabled
    refine ⟨phase.2, ?_⟩
    intro u hu b
    change ((phaseHostTM family base red).runFrom (d.mapState (Sigma.mk false)) u).state ≠ _
    rw [phase.1 u (by omega)]
    change ((M.runFrom d u).state.map (Sigma.mk false)) ≠ some (leave b)
    intro eq
    obtain ⟨q, _, hq⟩ := Option.map_eq_some_iff.mp eq
    have impossible := congrArg Sigma.fst hq
    cases impossible

/-- A total composable parser front end. The two strict live ports mean
rejection or ready-for-grammar; every rejection denotes the fixed fallback.
Success retains a canonical header and saved address, has passed the positive
guard, and positions the native head at the remainder. The destroyed guard
counter is deliberately absent from the preserved-bank contract.

**Proof sketch.** Use the total checked front and merge its three cause ports
through the public phase-host adapter. The dispatch is stationary and silent,
so every data invariant transfers unchanged; increase the coefficient by one. -/
private lemma exists_canonParseFront (F : MachineFormat) :
    ∃ (C : FinTM Bool) (entry : C.State) (exit : Bool → C.State) (a : ℕ),
      4 ≤ C.k ∧ Function.Injective exit ∧ ∀ x : List Bool,
        ∃ t ≤ a * (x.length + 1), ∃ verdict : Bool,
          let start := Cfg.ofWords (input := x) entry (fun _ => [])
          let e := C.tm.runFrom start t
          e.state = some (exit verdict) ∧ e.output = [] ∧
          (∀ u < t, ∀ q, (C.tm.runFrom start u).state ≠ some (exit q)) ∧
          (verdict = false → F.decode x = F.fallback) ∧
          (verdict = true → ∃ bits rest,
            pairDecode x = some (bits, rest) ∧ bits = (codeBitsNat bits).bits ∧
            canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length ∧
            e.inputPos.val = 2 * bits.length + 3 ∧
            ∀ j, j.val ≠ 1 →
              e.workTapes j = FinTM.bufferTape (canonReadyWords C.k bits j) ∧
                e.workTapePos j = 0) := by
  obtain ⟨H, hentry, hexit, a, enough, distinct, front⟩ := exists_canonCheckedFront F
  obtain ⟨S, finite, equal, N, entry, leave, separate, dispatch⟩ :=
    canonExitDispatch (by omega) H.tm hentry hexit distinct
  letI : Fintype S := finite
  letI : DecidableEq S := equal
  let C : FinTM Bool := { k := H.k, State := S, tm := N }
  refine ⟨C, entry, leave, a + 1, enough, separate, ?_⟩
  intro x
  obtain ⟨t, budget, v, control, silent, cuts, reject, ready⟩ := front x
  obtain ⟨ran, strict⟩ := dispatch x t v control cuts
  refine ⟨t + 1, ?_, decide (v = some true), ?_, ?_, strict, ?_, ?_⟩
  · rw [Nat.add_mul]
    omega
  · rw [ran]
    simp only [Cfg.mapState, control, Option.map_some]
  · rw [ran]
    exact silent
  · intro no
    exact reject (of_decide_eq_false no)
  · intro yes
    rw [ran]
    exact ready (of_decide_eq_true yes)

/-- The grammar the physical parser decides once the parse front end is ready: the unary
initial state below `n + 1` (`Turing.codeSkipFin`), the fixed `k`-record table
(`Turing.codeSkipTableK`), and the all-`true` suffix. It is the format scanner's residue
after the header, canonicality and guard checks (`scan_eq_canonGrammar`).
-/
private def canonGrammar (k n : ℕ) (rest : List Bool) : Option (List Bool) :=
  ((codeSkipFin (n + 1) rest).bind (codeSkipTableK k n)).bind
    fun tail => if tail.all id then some tail else none

/-- At the parse front end's ready port the format scanner is exactly the fixed grammar on
the header's remainder: the canonicality test and the format's own guard both pass, since
the combined block size dominates `F.guard`.

**Proof sketch.** Unfold the scanner at the decoded pair. Canonicality removes the first
branch; `F.guard ≤ canonGuardBlock F` removes the second; `F.skipTable_eq` turns the
format's table skipper into the fixed one. -/
private lemma scan_eq_canonGrammar (F : MachineFormat) (α bits rest : List Bool)
    (hp : pairDecode α = some (bits, rest)) (hb : bits = (codeBitsNat bits).bits)
    (hg : canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length) :
    F.scan α = canonGrammar F.k (codeBitsNat bits) rest := by
  have hguard : F.guard * (codeBitsNat bits + 1) ≤ rest.length :=
    (Nat.mul_le_mul_right _ (Nat.le_max_left _ _)).trans hg
  unfold CodeFormat.scan canonGrammar
  rw [hp]
  dsimp only [bind, Option.bind]
  rw [if_neg (not_not.mpr hb), if_neg (not_lt.mpr hguard)]
  cases codeSkipFin (codeBitsNat bits + 1) rest with
  | none => rfl
  | some r =>
    dsimp only
    rw [F.skipTable_eq]
    rfl

/-- The verdict law of the physical validator at the ready port: deciding the fixed grammar
gives a bit whose rejection decodes to the fallback and whose acceptance is a successful
format scan.

**Proof sketch.** Rewrite the scanner by `scan_eq_canonGrammar`. A failed grammar is a
failed scan, hence a failed full parse (`Turing.CodeFormat.scan_full`), hence the fallback
(`Turing.CodeFormat.decode_of_parseFull_none`). -/
private lemma canonGrammar_verdict (F : MachineFormat) (α bits rest : List Bool)
    (hp : pairDecode α = some (bits, rest)) (hb : bits = (codeBitsNat bits).bits)
    (hg : canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length) :
    ((canonGrammar F.k (codeBitsNat bits) rest).isSome = false → F.decode α = F.fallback) ∧
      ((canonGrammar F.k (codeBitsNat bits) rest).isSome = true →
        ∃ tail, F.scan α = some tail) := by
  rw [← scan_eq_canonGrammar F α bits rest hp hb hg]
  constructor
  · intro h
    have hs : F.scan α = none := Option.not_isSome_iff_eq_none.mp (by simp [h])
    rw [F.scan_full] at hs
    exact F.decode_of_parseFull_none α (Option.map_eq_none_iff.mp hs)
  · intro h
    exact Option.isSome_iff_exists.mp h

/-- The input with its maximal all-`true` suffix removed. On every input the format scanner
accepts it is the canonical serialization of the decoded machine (`canonStrip_of_scan`).
Format independent. -/
private def canonStrip (α : List Bool) : List Bool :=
  (α.reverse.dropWhile id).reverse

/-- A word ending in `false`, followed by an all-`true` suffix, is recovered by
`canonStrip`. -/
private lemma canonStrip_append (u tail : List Bool) (h : tail.all id = true) :
    canonStrip (u ++ [false] ++ tail) = u ++ [false] := by
  have hall : ∀ b ∈ tail.reverse, id b = true := by
    intro b hb
    exact List.all_eq_true.mp h b (List.mem_reverse.mp hb)
  unfold canonStrip
  rw [List.reverse_append, List.dropWhile_append_of_pos hall]
  simp

/-- A nonempty concatenation of words that each end in `false` ends in `false`.
-/
private lemma canonFlatMap_last {A : Type} (L : List A) (f : A → List Bool) (hL : L ≠ [])
    (hf : ∀ a ∈ L, ∃ u, f a = u ++ [false]) : ∃ u, L.flatMap f = u ++ [false] := by
  obtain ⟨L', a, rfl⟩ := (List.eq_nil_or_concat L).resolve_left hL
  obtain ⟨u, hu⟩ := hf a (by simp)
  exact ⟨L'.flatMap f ++ u, by simp [List.flatMap_append, hu]⟩

/-- Every serialized record ends with its successor field's terminating `false`.
-/
private lemma actionBitsK_last {k n : ℕ} (a : Action k Bool (Fin (n + 1))) :
    ∃ u, actionBitsK a = u ++ [false] := by
  obtain ⟨v, hv⟩ : ∃ v, optStateBits a.state = v ++ [false] := by
    cases a.state with
    | none => exact ⟨[], rfl⟩
    | some s => exact ⟨true :: List.replicate s.val true, by simp [optStateBits, unaryFin]⟩
  refine ⟨signBits a.inputTape ++
    (List.finRange k).flatMap
      (fun i => optOptBoolBits (a.workTapes i).1 ++ signBits (a.workTapes i).2) ++
    optBoolBits a.output ++ v, ?_⟩
  simp only [actionBitsK, hv, List.append_assoc]

/-- The fixed `k`-record serialization ends with `false`: its table is nonempty and its last
record ends with a successor field. -/
private lemma serializeK_last {k n : ℕ} (M : MultiTapeTM k Bool (Fin (n + 1))) :
    ∃ u, serializeK M = u ++ [false] := by
  have hw : workReadsK k ≠ [] := by
    apply List.ne_nil_of_length_pos
    rw [StepBlock.length_workReadsK]
    exact Nat.pow_pos (by omega)
  have hq : List.finRange (n + 1) ≠ [] := List.ne_nil_of_length_pos (by simp)
  obtain ⟨u, hu⟩ := canonFlatMap_last (List.finRange (n + 1))
    (fun q => ([none, some false, some true] : List (Option Bool)).flatMap fun inp =>
      (workReadsK k).flatMap fun w => actionBitsK (M.tr q inp w)) hq fun q _ =>
    canonFlatMap_last ([none, some false, some true] : List (Option Bool))
      (fun inp => (workReadsK k).flatMap fun w => actionBitsK (M.tr q inp w)) (by simp)
      fun inp _ => canonFlatMap_last (workReadsK k) (fun w => actionBitsK (M.tr q inp w)) hw
        fun w _ => actionBitsK_last (M.tr q inp w)
  refine ⟨(n.bits.flatMap fun b => [b, b]) ++ [false, true] ++ unaryFin M.q₀ ++ u, ?_⟩
  have ht : tableBitsK M.tr = u ++ [false] := hu
  simp only [serializeK, pairEncode, ht, List.append_assoc]

/-- The suffix retained by a successful format scan is all `true`. -/
private lemma canonScan_all (F : MachineFormat) (α tail : List Bool)
    (hs : F.scan α = some tail) : tail.all id = true := by
  unfold CodeFormat.scan at hs
  obtain ⟨⟨bits, rest⟩, _, hs⟩ := Option.bind_eq_some_iff.mp hs
  dsimp only at hs
  split at hs
  · contradiction
  split at hs
  · contradiction
  obtain ⟨r, _, hs⟩ := Option.bind_eq_some_iff.mp hs
  obtain ⟨r', _, hs⟩ := Option.bind_eq_some_iff.mp hs
  split at hs
  next hall =>
    cases hs
    exact hall
  · contradiction

/-- On every input the format scanner accepts, stripping the all-`true` suffix yields the
canonical serialization of the decoded machine.

**Proof sketch.** The scanner is the projected full parse (`Turing.CodeFormat.scan_full`),
so the input is the decoded machine's serialization followed by the retained suffix
(`Turing.CodeFormat.parseFull_sound`). That serialization ends in `false`
(`serializeK_last`) and the suffix is all `true` (`canonScan_all`). -/
private lemma canonStrip_of_scan (F : MachineFormat) (α tail : List Bool)
    (hs : F.scan α = some tail) : canonStrip α = F.serialize (F.decode α) := by
  have hall := canonScan_all F α tail hs
  rw [F.scan_full] at hs
  obtain ⟨⟨M, tail'⟩, hp, rfl⟩ := Option.map_eq_some_iff.mp hs
  have hdec : F.decode α = M := by
    simp [CodeFormat.decode, hp]
  have hα := F.parseFull_sound α M tail' hp
  obtain ⟨u, hu⟩ := serializeK_last (F.machine M)
  rw [hdec, F.serialize_eq M, hu]
  rw [hα, F.serialize_eq M, hu]
  exact canonStrip_append u tail' hall

/-- Removing the trailing `true` bits leaves an empty word or a word ending in `false`.

**Proof sketch.** Append the last bit. A `true` extends the removed suffix; a `false`
ends that suffix and keeps the whole word. -/
private lemma canonStrip_split (w : List Bool) :
    ∃ r, w = canonStrip w ++ List.replicate r true ∧
      (canonStrip w = [] ∨ ∃ u, canonStrip w = u ++ [false]) := by
  induction w using List.reverseRecOn with
  | nil => exact ⟨0, rfl, Or.inl rfl⟩
  | append_singleton w b ih =>
    obtain ⟨r, hr, last⟩ := ih
    cases b with
    | false =>
      have strip : canonStrip (w ++ [false]) = w ++ [false] := by
        simp [canonStrip]
      exact ⟨0, by simp [strip], Or.inr ⟨w, strip⟩⟩
    | true =>
      have strip : canonStrip (w ++ [true]) = canonStrip w := by
        simp [canonStrip]
      refine ⟨r + 1, ?_, by simpa only [strip] using last⟩
      rw [strip, List.replicate_succ', ← List.append_assoc]
      exact congrArg (fun v => v ++ [true]) hr

/-- The strip boundary is a prefix boundary, followed only by `true` cells; its final
retained cell, if present, is `false`.

**Proof sketch.** Decompose the word at its stripped prefix, then read either side of the
append boundary. The last retained cell is the terminating `false` of that prefix. -/
private lemma canonStrip_boundary (w : List Bool) :
    (canonStrip w).length ≤ w.length ∧
      w.take (canonStrip w).length = canonStrip w ∧
      (∀ (r : ℕ) (hr : r < w.length), (canonStrip w).length ≤ r → w[r] = true) ∧
      (∀ (r : ℕ) (hr : r < w.length), (canonStrip w).length = r + 1 → w[r] = false) := by
  obtain ⟨t, word, last⟩ := canonStrip_split w
  generalize hu : canonStrip w = u at *
  subst w
  refine ⟨by simp, List.take_left, ?_, ?_⟩
  · intro r hr past
    rw [List.getElem_append_right past]
    simp
  · intro r hr boundary
    rcases last with rfl | ⟨v, rfl⟩
    · simp at boundary
    · have index : r = v.length := by simp at boundary; omega
      subst r
      simp

/-- A trailing-`true` eraser on one selected work tape. No catalog row erases only a suffix:
the two-pass scan rewrites each symbol to a symbol, so it cannot replace a bit by blank.
The forward pass finds the right blank. The return pass erases until the first `false`,
then preserves the remaining prefix, reaching the origin at its live exit. -/
private def canonTrimTM (k : ℕ) (i : Fin k) : MultiTapeTM k Bool (ScanPhase Bool) where
  q₀ := .fwd false
  tr := fun q _ w =>
    let (write, move, next) : Option (Option Bool) × SignType × ScanPhase Bool :=
      match q, w i with
      | .fwd _, some _ => (none, .pos, .fwd false)
      | .fwd _, none => (none, .neg, .bwd true)
      | .bwd clean, some b =>
        (if clean && b then some none else none, .neg, .bwd (clean && b))
      | .bwd _, none => (none, .pos, .done false)
      | .done _, _ => (none, 0, .done false)
    tapeAction i 0 write move next

/-- Erasing the last cell of a finite buffer removes precisely its final symbol.

**Proof sketch.** The append law installs the last cell with a point update. A second
update to blank restores the original buffer, which is blank at its own length. -/
private lemma canonEraseLast (w : List Bool) (b : Bool) :
    Function.update (FinTM.bufferTape (w ++ [b])) (w.length : ℤ) none =
      FinTM.bufferTape w := by
  rw [FinTM.bufferTape_append, Function.update_idem]
  apply Function.update_eq_self_iff.mpr
  simp

/-- The eraser returns at the origin with exactly the stripped word and has no earlier
visit to its exit. All other tape words, the native head and the output are unchanged.

**Proof sketch.** Apply the public two-pass trace theorem. On the backward pass at position
`r - 1`, the retained buffer is the original prefix of length `max r |canonStrip w|`.
The finite flag records whether the strip boundary has been crossed. The boundary facts
identify the cell that switches the flag, and the one-cell erase law shortens only the suffix.
This also covers an empty input and a word consisting entirely of `true` bits. -/
private lemma canonTrim_run (k : ℕ) (i : Fin k) (x : List Bool)
    (words : Fin k → List Bool) :
    (canonTrimTM k i).runFrom (Cfg.ofWords (input := x) (.fwd false) words)
        (2 * (words i).length + 2) =
      Cfg.ofWords (.done false) (Function.update words i (canonStrip (words i))) ∧
      ∀ t < 2 * (words i).length + 2,
        ((canonTrimTM k i).runFrom (Cfg.ofWords (input := x) (.fwd false) words) t).state ≠
          some (.done false) := by
  let w := words i
  let m := (canonStrip w).length
  obtain ⟨small, pref, past, boundary⟩ := canonStrip_boundary w
  let base := Cfg.ofWords (input := x) (ScanPhase.fwd false) words
  let fwd (r : ℕ) : Cfg k Bool (ScanPhase Bool) x :=
    { base with workTapePos := Function.update base.workTapePos i r }
  let back (r : ℕ) : Cfg k Bool (ScanPhase Bool) x :=
    { base with state := some (.bwd (decide (m ≤ r)))
                workTapes := Function.update base.workTapes i
                  (FinTM.bufferTape (w.take (max r m)))
                workTapePos := Function.update base.workTapePos i ((r : ℤ) - 1) }
  let done : Cfg k Bool (ScanPhase Bool) x :=
    Cfg.ofWords (.done false) (Function.update words i (canonStrip w))
  have start : fwd 0 = base := by simp [fwd, base, Cfg.ofWords]
  have forward (r : ℕ) (hr : r < w.length) :
      (canonTrimTM k i).step (fwd r) = fwd (r + 1) := by
    have read : (fwd r).workTapeSymbols i = some w[r] := by
      simp [fwd, base, Cfg.ofWords, Cfg.workTapeSymbols, w, hr]
    rw [step_of_tapeAction_move _ _ i 0 .pos rfl
      (q' := ScanPhase.fwd false) (by simp [canonTrimTM, read])]
    apply Cfg.ext <;> try rfl
    · simp [fwd, moveInputPos_zero]
    · simp [fwd, Function.update_idem, Nat.cast_add]
  have turn : (canonTrimTM k i).step (fwd w.length) = back w.length := by
    have read : (fwd w.length).workTapeSymbols i = none := by
      simp [fwd, base, Cfg.ofWords, Cfg.workTapeSymbols, w]
    rw [step_of_tapeAction_move _ _ i 0 .neg rfl
      (q' := ScanPhase.bwd true) (by simp [canonTrimTM, read])]
    apply Cfg.ext <;>
      simp [fwd, back, m, small, Function.update_idem, base, Cfg.ofWords, w,
        sub_eq_add_neg]
  have backward (r : ℕ) (hr : r < w.length) :
      (canonTrimTM k i).step (back (r + 1)) = back r := by
    have read : (back (r + 1)).workTapeSymbols i = some w[r] := by
      simp only [back, Cfg.workTapeSymbols, Function.update_self, Nat.cast_add,
        Nat.cast_one, add_sub_cancel_right, FinTM.bufferTape_nat]
      rw [List.getElem?_take_of_lt (by omega), List.getElem?_eq_getElem hr]
    by_cases erase : m ≤ r
    · have bit : w[r] = true := past r hr erase
      have flag : decide (m ≤ r + 1) = true := by simp; omega
      have cells : Function.update (FinTM.bufferTape (w.take (max (r + 1) m)))
          (r : ℤ) none = FinTM.bufferTape (w.take (max r m)) := by
        rw [max_eq_left (by omega), max_eq_left erase,
          List.take_succ_eq_append_getElem hr]
        have len : (w.take r).length = r := List.length_take_of_le (by omega)
        simpa only [len] using canonEraseLast (w.take r) w[r]
      rw [step_of_tapeAction_write _ _ i 0 none .neg rfl
        (q' := ScanPhase.bwd true) (by simp only [canonTrimTM, read, flag, bit]; rfl)]
      apply Cfg.ext <;>
        simp only [back, Function.update_self, Nat.cast_add, Nat.cast_one,
          add_sub_cancel_right, cells, Function.update_idem, moveInputPos_zero,
          decide_eq_true erase]
      simp [sub_eq_add_neg]
    · have notzero : r + 1 ≤ m := by omega
      have value : (decide (m ≤ r + 1) && w[r]) = false := by
        by_cases edge : m = r + 1
        · simp [edge, boundary r hr edge]
        · rw [decide_eq_false (by omega : ¬m ≤ r + 1)]
          rfl
      have same : max (r + 1) m = max r m := by omega
      rw [step_of_tapeAction_move _ _ i 0 .neg rfl
        (q' := ScanPhase.bwd false) (by simp only [canonTrimTM, read, value]; rfl)]
      apply Cfg.ext <;>
        simp [back, same, erase, Function.update_idem, Nat.cast_add, sub_eq_add_neg]
  have enter : (canonTrimTM k i).step (back 0) = done := by
    have read : (back 0).workTapeSymbols i = none := by
      simp [back, Cfg.workTapeSymbols]
    rw [step_of_tapeAction_move _ _ i 0 .pos rfl
      (q' := ScanPhase.done false) (by simp [canonTrimTM, read])]
    apply Cfg.ext
    all_goals simp [back, done, base, Cfg.ofWords, m, pref, Function.update_idem]
    funext j
    by_cases eq : j = i
    · subst j; simp
    · simp only [Function.update_of_ne eq]
  have stationary : (canonTrimTM k i).step done = done := by
    rw [step_of_tapeAction_move _ _ i 0 0 rfl (q' := ScanPhase.done false) rfl]
    simp [done, Cfg.ofWords]
  have trace (t : ℕ) :=
    catalog_trace_run (canonTrimTM k i) fwd back done w.length forward turn backward
      enter stationary t
  rw [start] at trace
  refine ⟨?_, ?_⟩
  · rw [trace]
    rw [catalogTrace, if_neg (by dsimp [w]; omega), if_neg (by dsimp [w]; omega)]
  · intro t ht
    rw [trace]
    simp only [catalogTrace]
    split_ifs with front rear
    · simp [fwd, base, Cfg.ofWords]
    · simp [back]
    · change t < 2 * w.length + 2 at ht
      omega

/-- Patching a buffered word by a word at least as long, over the longer word's interval, gives
the longer word's buffer.

**Proof sketch.** Split at zero and the patch's length. Inside the interval use the patch
branch; outside it both buffers are blank by the public list lookup bound. -/
private lemma canonPatchWord_le (w v : List Bool) (le : w.length ≤ v.length) :
    (fun z : ℤ => if 0 ≤ z ∧ z < (v.length : ℤ) then FinTM.bufferTape v z
      else FinTM.bufferTape w z) = FinTM.bufferTape v := by
  funext z
  by_cases nonneg : 0 ≤ z
  · by_cases inside : z < (v.length : ℤ)
    · simp [nonneg, inside]
    · simp [nonneg, inside, FinTM.bufferTape,
        List.getElem?_eq_none (show w.length ≤ z.toNat by omega)]
  · simp [nonneg, FinTM.bufferTape]

/-- **The polynomial-time strip machine.** One finite binary machine computes `canonStrip`
in polynomial time. Format independent; a promotion candidate.

**Proof sketch.** Copy the native input to a work tape (`Turing.inputCopyTM`). A one-tape
leaf walks to the word's right end, erases the trailing `true` cells moving left until a
`false` or the left delimiter, and returns to the origin. Forward the remaining word to the
output by the public emit call `Turing.FinTM.exists_emitCallTM` with the identity machine,
and halt. Every phase is linear. -/
private lemma exists_canonStripTM :
    ∃ (M : FinTM Bool) (a : ℕ),
      M.ComputesFunInTime canonStrip (fun n => a * (n + 1) ^ a) := by
  classical
  obtain ⟨I, a, identity⟩ := FinTM.computesFunInTime_id
  obtain ⟨E, entry, exit, c, positive, emit⟩ :=
    FinTM.exists_emitCallTM I id (fun n => a * (n + 1)) identity
  let i : Fin E.k := ⟨0, positive⟩
  let trim := canonTrimTM E.k i
  let prepare := seamCompTM (inputCopyTM E.k i) .done trim (.fwd false)
  let release := seamReleaseTM E.tm entry
  let halt : MultiTapeTM E.k Bool Unit :=
    ⟨(), fun _ _ _ => ⟨0, fun _ => (none, 0), none, none⟩⟩
  let finish := seamCompTM release (Sum.inr exit) halt ()
  let machine : FinTM Bool := {
    k := E.k
    State := (SweepPhase ⊕ ScanPhase Bool) ⊕ ((Unit ⊕ E.State) ⊕ Unit)
    tm := { seamCompTM prepare (Sum.inr (.done false)) finish (Sum.inl (Sum.inl ())) with
      q₀ := Sum.inl (Sum.inl .sweep) } }
  let d := c * (a + 2) + 8
  refine ⟨machine, d, ?_⟩
  intro x
  let source := Cfg.ofWords (input := x) SweepPhase.sweep (fun _ : Fin E.k => [])
  have copied := inputCopyTM_run_ofCfg i source rfl rfl
  have copy : (inputCopyTM E.k i).runFrom source (2 * x.length + 2) =
      Cfg.ofWords .done (stateWord E.k x) := by
    rw [copied.1]
    apply Cfg.ext <;> try rfl
    funext j z
    have index : j = i ↔ j.val = 0 := Fin.ext_iff
    simp only [source, Cfg.ofWords, stateWord, index, zero_add, sub_zero,
      FinTM.bufferTape_nil]
    by_cases zero : j.val = 0
    · simp only [zero, if_true, true_and]
      simpa using congrFun (canonPatchWord_le [] x (Nat.zero_le _)) z
    · simp [zero]
  have word : stateWord E.k x i = x := by simp [stateWord, i]
  have restored : Function.update (stateWord E.k x) i (canonStrip x) =
      stateWord E.k (canonStrip x) := by
    funext j
    by_cases selected : j = i
    · subst j; simp [stateWord, i]
    · have other : j.val ≠ 0 := fun h => selected (Fin.ext h)
      simp [Function.update_of_ne selected, stateWord, other]
  obtain ⟨trimmed, trimCut⟩ := canonTrim_run E.k i x (stateWord E.k x)
  rw [word, restored] at trimmed
  rw [word] at trimCut
  have prepared := seamCompTM_run_ofCfg (inputCopyTM E.k i) .done trim (.fwd false)
    copy rfl copied.2.1 trimmed
  have prepareCut := seamCompTM_firstReturn_ofCfg (inputCopyTM E.k i) .done trim
    (.fwd false) (.done false) copy rfl copied.2.1 trimmed rfl trimCut
  let argument := canonStrip x
  let callStart := Cfg.ofWords (input := x) entry (stateWord E.k argument)
  obtain ⟨t, budget, nonzero, first, ran⟩ := emit x argument
  have released : release.runFrom (callStart.mapState (fun _ => Sum.inl ())) t =
      ({ Cfg.ofWords (input := x) exit (stateWord E.k argument)
          with output := argument } : Cfg E.k Bool E.State x).mapState Sum.inr := by
    rw [seamReleaseTM_runFrom_pos E.tm entry callStart rfl t nonzero]
    exact congrArg (Cfg.mapState Sum.inr) ran
  have releaseCut : ∀ u < t,
      (release.runFrom (callStart.mapState (fun _ => Sum.inl ())) u).state ≠
        some (Sum.inr exit) := by
    intro u hu
    cases u with
    | zero => simp [callStart, Cfg.ofWords, Cfg.mapState]
    | succ u =>
      rw [seamReleaseTM_runFrom_pos E.tm entry callStart rfl _ (Nat.succ_pos _)]
      intro h
      obtain ⟨q, hq, eq⟩ := Option.map_eq_some_iff.mp h
      exact first (u + 1) (Nat.succ_pos _) hu
        (hq.trans (congrArg some (Sum.inr.inj eq)))
  let emitted : Cfg E.k Bool (Unit ⊕ E.State) x :=
    ({ Cfg.ofWords (input := x) exit (stateWord E.k argument)
        with output := argument } : Cfg E.k Bool E.State x).mapState Sum.inr
  let stopped := halt.runFrom (emitted.mapState (fun _ => ())) 1
  have stopped_eq : stopped =
      { emitted.mapState (fun _ => ()) with state := none } := by
    simp [stopped, halt, MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.step,
      emitted, Cfg.mapState, Cfg.ofWords, Action.apply]
  have finished := seamCompTM_run_ofCfg release (Sum.inr exit) halt ()
    released rfl releaseCut (rfl : halt.runFrom (emitted.mapState (fun _ => ())) 1 = stopped)
  have complete := seamCompTM_run_ofCfg prepare (Sum.inr (.done false)) finish
    (Sum.inl (Sum.inl ())) prepared rfl prepareCut finished
  let duration := (2 * x.length + 2 + 1 + (2 * x.length + 2)) + 1 + (t + 1 + 1)
  have computation : machine.ComputesInTime x argument duration := by
    apply (FinTM.computesInTime_iff machine _ _ _).mpr
    rw [initCfg_ofWords]
    change ((seamCompTM prepare (Sum.inr (.done false)) finish _).runFrom
      ((source.mapState Sum.inl).mapState Sum.inl) duration).state = none ∧
      ((seamCompTM prepare (Sum.inr (.done false)) finish _).runFrom
        ((source.mapState Sum.inl).mapState Sum.inl) duration).output = argument
    rw [complete]
    change (stopped.mapState Sum.inr |>.mapState Sum.inr).state = none ∧
      (stopped.mapState Sum.inr |>.mapState Sum.inr).output = argument
    rw [stopped_eq]
    exact ⟨rfl, rfl⟩
  apply computation.mono
  have length : argument.length ≤ x.length := (canonStrip_boundary x).1
  have cost : t ≤ c * (a + 2) * (x.length + 1) := by
    apply budget.trans
    dsimp only [id_eq]
    calc
      c * (a * (argument.length + 1) + argument.length + argument.length + 1)
          ≤ c * ((a + 2) * (argument.length + 1)) := by
        apply Nat.mul_le_mul_left c
        ring_nf
        omega
      _ ≤ c * ((a + 2) * (x.length + 1)) :=
        Nat.mul_le_mul_left c (Nat.mul_le_mul_left _ (by omega))
      _ = _ := by ring
  have linear : duration ≤ d * (x.length + 1) := by
    dsimp [duration, d]
    nlinarith
  exact linear.trans (Nat.mul_le_mul_left d (by
    simpa using Nat.pow_le_pow_right (show 1 ≤ x.length + 1 by omega)
      (show 1 ≤ d by dsimp [d]; omega)))

/-- The bounded unary field: `codeSkipFin (n + 1)` accepts exactly `1^i 0` with `i ≤ n`.
 -/
private lemma canonSkipFin_iff (n : ℕ) (ys rest : List Bool) :
    codeSkipFin (n + 1) ys = some rest ↔
      ∃ i, i ≤ n ∧ ys = List.replicate i true ++ false :: rest := by
  constructor
  · intro h
    obtain ⟨⟨i, tail⟩, hu, h⟩ := Option.bind_eq_some_iff.mp h
    dsimp only at h
    split at h
    next hi =>
      have e := Option.some.inj h
      exact ⟨i, by omega, by rw [← e]; exact codeReadUnary_sound ys i tail hu⟩
    · contradiction
  · rintro ⟨i, hi, rfl⟩
    simp [codeSkipFin, codeReadUnary_append, show i < n + 1 by omega]

/-- The fixed fields of one record: the input move, the `k` work-tape writes and moves, and
the output, each a two-bit field; the successor field follows.  -/
private def canonSkipFields (k : ℕ) : List Bool → Option (List Bool) :=
  let move : Bool → Bool → Bool := fun a b => a || !b
  fun xs => ((codeSkipPair move xs).bind (codeSkipRepeat codeSkipWork k)).bind (codeSkipPair move)

/-- A record is its fixed fields followed by its successor field.  -/
private lemma canonSkipAction_eq (k n : ℕ) (xs : List Bool) :
    codeSkipActionK k n xs = (canonSkipFields k xs).bind (codeSkipState (n + 1)) := by
  unfold codeSkipActionK canonSkipFields
  simp only [bind, Option.bind_assoc]

/-- A successful pair skip consumes exactly two cells.  -/
private lemma canonSkipPair_cells (v : Bool → Bool → Bool) (xs ys : List Bool)
    (h : codeSkipPair v xs = some ys) : ∃ a b, xs = a :: b :: ys := by
  match xs, h with
  | a :: b :: rest, h =>
    unfold codeSkipPair at h
    dsimp only at h
    split at h
    · cases h
      exact ⟨a, b, rfl⟩
    · contradiction

/-- Successful fixed fields consume exactly `4k + 4` cells.  -/
private lemma canonSkipFields_cells (k : ℕ) (xs ys : List Bool)
    (h : canonSkipFields k xs = some ys) : ∃ u, xs = u ++ ys ∧ u.length = 4 * k + 4 := by
  have work (j : ℕ) (us vs : List Bool) (hw : codeSkipRepeat codeSkipWork j us = some vs) :
      ∃ u, us = u ++ vs ∧ u.length = 4 * j := by
    induction j generalizing us with
    | zero =>
      cases hw
      exact ⟨[], rfl, rfl⟩
    | succ j ih =>
      obtain ⟨ws, hws, hrest⟩ := Option.bind_eq_some_iff.mp hw
      obtain ⟨zs, hz, hz'⟩ := Option.bind_eq_some_iff.mp hws
      obtain ⟨a, b, rfl⟩ := canonSkipPair_cells _ _ _ hz
      obtain ⟨c, d, rfl⟩ := canonSkipPair_cells _ _ _ hz'
      obtain ⟨u, rfl, hu⟩ := ih ws hrest
      exact ⟨a :: b :: c :: d :: u, rfl, by simp only [List.length_cons, hu]; omega⟩
  obtain ⟨zs, hz, hout⟩ := Option.bind_eq_some_iff.mp h
  obtain ⟨ws, hws, hrep⟩ := Option.bind_eq_some_iff.mp hz
  obtain ⟨a, b, rfl⟩ := canonSkipPair_cells _ _ _ hws
  obtain ⟨u, rfl, hu⟩ := work k ws zs hrep
  obtain ⟨c, d, rfl⟩ := canonSkipPair_cells _ _ _ hout
  exact ⟨a :: b :: (u ++ [c, d]), by simp,
    by simp only [List.length_cons, List.length_append, List.length_nil, hu]⟩

/-- Repetition counts add.  -/
private lemma canonSkipRepeat_add (r : List Bool → Option (List Bool)) (m n : ℕ)
    (xs : List Bool) :
    codeSkipRepeat r (m + n) xs = (codeSkipRepeat r m xs).bind (codeSkipRepeat r n) := by
  induction m generalizing xs with
  | zero =>
    rw [Nat.zero_add]
    rfl
  | succ m ih =>
    rw [Nat.succ_add]
    show (r xs).bind (codeSkipRepeat r (m + n)) =
      ((r xs).bind (codeSkipRepeat r m)).bind (codeSkipRepeat r n)
    cases r xs with
    | none => rfl
    | some ys => exact ih ys

/-- A repetition of repetitions is one repetition of the product length.
 -/
private lemma canonSkipRepeat_mul (r : List Bool → Option (List Bool)) (a b : ℕ)
    (xs : List Bool) :
    codeSkipRepeat (codeSkipRepeat r a) b xs = codeSkipRepeat r (a * b) xs := by
  induction b generalizing xs with
  | zero => rfl
  | succ b ih =>
    have e : a * (b + 1) = a + a * b := by ring
    rw [e, canonSkipRepeat_add r a (a * b)]
    show (codeSkipRepeat r a xs).bind (codeSkipRepeat (codeSkipRepeat r a) b) = _
    congr 1
    funext ys
    exact ih ys

/-- The fixed table grammar is `n + 1` states of `3^(k+1)` records each.
 -/
private lemma canonSkipTable_eq (k n : ℕ) (xs : List Bool) :
    codeSkipTableK k n xs =
      codeSkipRepeat (codeSkipRepeat (codeSkipActionK k n) (3 ^ (k + 1))) (n + 1) xs := by
  have iter (j : ℕ) (r : List Bool → Option (List Bool)) :
      (fun f => codeSkipRepeat f 3)^[j] r = codeSkipRepeat r (3 ^ j) := by
    induction j with
    | zero =>
      funext ys
      show r ys = (r ys).bind some
      cases r ys <;> rfl
    | succ j ih =>
      rw [Function.iterate_succ_apply', ih]
      funext ys
      rw [canonSkipRepeat_mul, Nat.pow_succ]
  unfold codeSkipTableK
  rw [iter]

/-- Read one native cell, advancing exactly when it is the requested bit. The catalog's
native readers traverse the whole input, so this single-cell leaf supplies the local test.
No work tape is touched and no symbol is emitted. -/
private def canonCellTM (k : ℕ) (bit : Bool) : MultiTapeTM k Bool (Option Bool) where
  q₀ := none
  tr := fun _ inp _ =>
    inputMoveAction (if inp = some bit then 1 else 0) (some (decide (inp = some bit)))

/-- The native-cell leaf has exactly the public input-only action's effect. -/
private lemma canonCell_step {k : ℕ} {x : List Bool} (bit : Bool)
    (d : Cfg k Bool (Option Bool) x) (q : Option Bool) (hq : d.state = some q) :
    (canonCellTM k bit).step d =
      { d with
        state := some (some (decide (d.inputSymbol = some bit)))
        inputPos := moveInputPos d.inputPos (if d.inputSymbol = some bit then 1 else 0) } :=
  step_of_inputMoveAction _ _ _ hq rfl

/-- Every word has a maximal initial run of `true` cells, followed by either a
`false` or the right blank. Only existence is used by the physical reader.

**Proof sketch.** Specialize the public list decomposition into an initial constant
run and its first different cell. A leading false cell gives a zero-length true run. -/
private lemma canonTruePrefix (xs : List Bool) :
    ∃ r rest, xs = List.replicate r true ++ rest ∧
      (rest = [] ∨ ∃ ys, rest = false :: ys) := by
  rcases List.eq_replicate_or_eq_replicate_append_cons xs with
    rfl | ⟨n, b, rfl, positive⟩ | ⟨n, a, b, ys, rfl, positive, different⟩
  · exact ⟨0, [], rfl, Or.inl rfl⟩
  · cases b with
    | false =>
      obtain ⟨n, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : n ≠ 0)
      exact ⟨0, _, rfl, Or.inr ⟨List.replicate n false, rfl⟩⟩
    | true => exact ⟨n, [], by simp, Or.inl rfl⟩
  · cases a with
    | false =>
      obtain ⟨n, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : n ≠ 0)
      exact ⟨0, _, rfl, Or.inr ⟨List.replicate n false ++ b :: ys, rfl⟩⟩
    | true =>
      cases b
      · exact ⟨n, false :: ys, rfl, Or.inr ⟨ys, rfl⟩⟩
      · exact (different rfl).elim

/-- A true prefix gives the exact body orbit of the unary reader. This is only a
calculation of the one-cell body's orbit; the physical countdown uses the public host.

**Proof sketch.** At round `r` the native head is at the original position plus `r`.
The supplied prefix lookup makes the next one-cell action a right move and a return to
the same anchor. The shared round-orbit successor law gives the induction step. -/
private lemma canonTrueOrbit {k : ℕ} {x : List Bool}
    (d : Cfg k Bool (Option Bool) x) (hs : d.state = some (some true))
    (p r : ℕ) (hp : d.inputPos.val = p + 1) (hr : p + r ≤ x.length)
    (hprefix : ∀ i < r, x[p + i]? = some true) :
    counterLoopOrbit (canonCellTM k true) (fun _ => 1) d r =
      { d with state := some (some true), inputPos := ⟨p + r + 1, by omega⟩ } := by
  simp only [counterLoopOrbit]
  induction r with
  | zero =>
    change d = _
    refine Cfg.ext hs ?_ rfl rfl rfl
    exact Fin.ext hp
  | succ r ih =>
    rw [roundOrbit_succ, ih (by omega) (fun i hi => hprefix i (by omega))]
    rw [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.runFrom_zero,
      canonCell_step true _ (some true) rfl]
    have read :
        ({ d with
          state := some (some true)
          inputPos := ⟨p + r + 1, by omega⟩ } : Cfg k Bool (Option Bool) x).inputSymbol =
          some true := (FinTM.inputSymbol_at _ (p + r) (by omega) rfl).trans (hprefix r (by omega))
    simp only [read, decide_true, if_true]
    refine Cfg.ext rfl ?_ rfl rfl rfl
    apply Fin.ext
    change (moveInputPos (⟨p + r + 1, by omega⟩ : Fin (x.length + 2)) SignType.pos).val = _
    rw [moveInputPos_pos_of_ne_right _ (by
      change p + r + 1 ≠ x.length + 1
      omega)]
    rfl

/-- Replacing a buffered word by another word of the same width changes only its interval.
The two buffers are both blank outside that interval.

**Proof sketch.** `canonPatchWord_le` at equal widths. -/
private lemma canonPatchWord (w v : List Bool) (width : v.length = w.length) :
    (fun z : ℤ => if 0 ≤ z ∧ z < (w.length : ℤ) then FinTM.bufferTape v z
      else FinTM.bufferTape w z) = FinTM.bufferTape v := by
  have patched := canonPatchWord_le w v width.ge
  rwa [width] at patched

/-- The countdown reads at most the initial true hprefix. Its result keeps the body tapes,
returns the counter head to zero, and retains a buffered counter word of the original width.

**Proof sketch.** If the bound is no larger than the true hprefix, every one-cell round
returns and the public done contract applies. Otherwise the first non-true cell is the
escaping round. Apply the public escape contract and its hprefix amortization bound.
Both cases use the same body-orbit calculation; no host transition is re-proved. -/
private lemma canonUnaryLoop {x : List Bool} (d : Cfg 1 Bool (Option Bool) x)
    (hs : d.state = some (some true)) (p r : ℕ) (hp : d.inputPos.val = p + 1)
    (hr : p + r ≤ x.length) (hprefix : ∀ i < r, x[p + i]? = some true)
    (stopped : x[p + r]? ≠ some true) (w : List Bool) :
    ∃ t ≤ 5 * x.length + 2 * w.length + 7, ∃ v q,
      v.length = w.length ∧ (q = CounterLoopState.done ∨ q = .escape) ∧
      (counterLoopTM (canonCellTM 1 true) (some true) (some (some false))).runFrom
          (counterLoopCfg (some (.dec .run)) d (FinTM.bufferTape w) 0) t =
        counterLoopCfg (some q)
          { d with inputPos := ⟨p + min (counterValue w) r + 1, by
              have := Nat.min_le_right (counterValue w) r; omega⟩ }
          (FinTM.bufferTape v) 0 ∧
      ∀ u < t,
        ((counterLoopTM (canonCellTM 1 true) (some true) (some (some false))).runFrom
          (counterLoopCfg (some (.dec .run)) d (FinTM.bufferTape w) 0) u).state ≠ some .done ∧
        ((counterLoopTM (canonCellTM 1 true) (some true) (some (some false))).runFrom
          (counterLoopCfg (some (.dec .run)) d (FinTM.bufferTape w) 0) u).state ≠ some .escape := by
  let M := canonCellTM 1 true
  let n := counterValue w
  have orbit (j : ℕ) (hj : j ≤ r) :
      counterLoopOrbit M (fun _ => 1) d j =
        { d with state := some (some true), inputPos := ⟨p + j + 1, by omega⟩ } :=
    canonTrueOrbit d hs p j hp (by omega) (fun i hi => hprefix i (by omega))
  by_cases fits : n ≤ r
  · let t := n + counterOverhead w (n + 1)
    have run := counterLoopTM_run_done M (some true) (some (some false)) (fun _ => 1)
      d w (FinTM.bufferTape w) 0 (by intro z _ _; simp) n rfl
      (by
        intro j hj
        rw [orbit j (by omega), orbit (j + 1) (by omega)]
        exact ⟨rfl, Nat.zero_lt_one, by intro u hu hut; change u < 1 at hut; omega,
          rfl⟩) t (by simp [t])
    have charge := counterLoop_time_le M (fun _ => 1) d w n rfl 1
      (by intros; exact le_rfl)
    simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one] at charge
    have patch : (fun z : ℤ => if 0 ≤ z ∧ z < 0 + (w.length : ℤ) then some true
        else FinTM.bufferTape w z) = FinTM.bufferTape (List.replicate w.length true) := by
      rw [← canonPatchWord w (List.replicate w.length true) (by simp)]
      funext z
      simp only [zero_add]
      split_ifs with inside
      · simp [FinTM.bufferTape, inside.1,
          show z.toNat < w.length by omega]
      · rfl
    refine ⟨t, by dsimp [t] at *; omega, List.replicate w.length true, .done,
      by simp, Or.inl rfl, ?_, run.2.1⟩
    rw [run.1, patch, orbit n fits]
    refine Cfg.ext rfl ?_ rfl rfl rfl
    apply Fin.ext
    change p + n + 1 = p + min (counterValue w) r + 1
    rw [Nat.min_eq_left fits]
  · have before : r < n := by omega
    have escape : counterLoopOrbit M (fun _ => 1) d (r + 1) =
        { d with state := some (some false), inputPos := ⟨p + r + 1, by omega⟩ } := by
      change roundOrbit M (fun _ => 1) d (r + 1) = _
      rw [roundOrbit_succ]
      change M.runFrom (counterLoopOrbit M (fun _ => 1) d r) 1 = _
      rw [orbit r le_rfl, MultiTapeTM.runFrom_succ_eq_step,
        MultiTapeTM.runFrom_zero, canonCell_step true _ (some true) rfl]
      have read := FinTM.inputSymbol_at
        ({ d with state := some (some true), inputPos := ⟨p + r + 1, by omega⟩ })
        (p + r) hr rfl
      simp only [read, if_neg stopped, decide_eq_false stopped, moveInputPos_zero]
    let t := r + 1 + counterOverhead w (r + 1)
    have run := counterLoopTM_run_escape M (some true) (some false) (by decide)
      (fun _ => 1) d w (FinTM.bufferTape w) 0 (by intro z _ _; simp) r before
      (by
        intro j hj
        rw [orbit j hj]
        exact ⟨rfl, Nat.zero_lt_one, by intro u hu hut; change u < 1 at hut; omega⟩)
      (by rw [escape]) t (by simp [t])
    have width := counterWord_length w (r + 1)
    have charge := counterOverhead_le_of_le w (r + 1) (by exact Nat.succ_le_of_lt before)
    refine ⟨t, by dsimp [t]; omega, counterWord w (r + 1), .escape, width,
      Or.inr rfl, ?_, run.2.1⟩
    rw [run.1, escape]
    simp only [zero_add, sub_zero]
    rw [canonPatchWord w _ width]
    refine Cfg.ext rfl ?_ rfl rfl rfl
    apply Fin.ext
    change p + r + 1 = p + min (counterValue w) r + 1
    rw [Nat.min_eq_right (by omega : r ≤ n)]

/-- The unary component has public-host phases for the countdown, terminating-cell test,
and scratch clearing with either verdict retained in the phase tag. -/
private abbrev canonUnaryPhase : Option (Option Bool) → Type
  | none => CounterLoopState (Option Bool)
  | some none => Option Bool
  | some (some _) => SweepPhase

/-- The unary phase family uses the public countdown and clearing machines. -/
private def canonUnaryFamily (p : Option (Option Bool)) :
    MultiTapeTM 2 Bool (canonUnaryPhase p) :=
  match p with
  | none => counterLoopTM (canonCellTM 1 true) (some true) (some (some false))
  | some none => canonCellTM 2 false
  | some (some _) => clearTM 2 1

/-- Both countdown exits share the terminating-cell test, which dispatches to the
cleanup phase with its Boolean verdict retained. The final ports are clearing's done ports. -/
private def canonUnaryNext (p : Option (Option Bool)) :
    canonUnaryPhase p → Option (Sigma canonUnaryPhase) := match p with
  | none => fun q =>
      if q = .done ∨ q = .escape then some ⟨some none, none⟩ else none
  | some none => fun q => q.map (fun b => ⟨some (some b), .sweep⟩)
  | some (some b) => fun q => if q = .done then some ⟨some (some b), .done⟩ else none

/-- The unary core starts with the copied bound on its last tape. It is a public phase
host, with no private controller for the transitions between the three phases. -/
private def canonUnaryCore : MultiTapeTM 2 Bool (Sigma canonUnaryPhase) :=
  phaseHostTM canonUnaryFamily ⟨none, .dec .run⟩ canonUnaryNext

/-- In a maximal true prefix, the bounded skipper returns the suffix after the first
false cell exactly when that cell is at or below the bound.

**Proof sketch.** A false-terminated field is the public unary-reader append law. A word
consisting only of true cells cannot satisfy `canonSkipFin_iff`, since that characterization
would place a false cell in the word. -/
private lemma canonUnaryField (n r : ℕ) (rest : List Bool)
    (stop : rest = [] ∨ ∃ ys, rest = false :: ys) :
    codeSkipFin (n + 1) (List.replicate r true ++ rest) =
      if r ≤ n then rest.tail? else none := by
  rcases stop with rfl | ⟨ys, rfl⟩
  · have absent : codeSkipFin (n + 1) (List.replicate r true) = none := by
      cases h : codeSkipFin (n + 1) (List.replicate r true) with
      | none => rfl
      | some ys =>
        obtain ⟨i, _, eq⟩ := (canonSkipFin_iff n _ ys).mp h
        have impossible : false ∈ List.replicate r true := by rw [eq]; simp
        simp at impossible
    simp [absent]
  · simp [codeSkipFin, codeReadUnary_append, show (r < n + 1) ↔ r ≤ n by omega]

/-- The unary core consumes a bounded unary field and then clears its scratch counter.
It preserves the other tape, every head, and the output, with a linear time bound.

**Proof sketch.** Split the suffix at its first false cell or right blank. Apply the
public countdown contract to the one-cell orbit, test the stopping cell, and clear the
residual word at its unchanged width. Public phase-host hprefix equations give the strict
exit cuts. No countdown or phase-host transition is re-proved. -/
private lemma canonUnaryCore_run {x : List Bool} (w : List Bool)
    (d : Cfg 2 Bool (Sigma canonUnaryPhase) x)
    (hs : d.state = some ⟨none, .dec .run⟩) (positive : 1 ≤ d.inputPos.val)
    (counter : d.workTapes 1 = FinTM.bufferTape w) (home : d.workTapePos 1 = 0) :
    ∃ t ≤ 12 * (x.length + w.length + 1),
      (canonUnaryCore.runFrom d t).state = some
        ⟨some (some (codeSkipFin (counterValue w + 1)
          (x.drop (d.inputPos.val - 1))).isSome), .done⟩ ∧
      (canonUnaryCore.runFrom d t).output = d.output ∧
      (∀ u < t, ∀ b,
        (canonUnaryCore.runFrom d u).state ≠ some ⟨some (some b), .done⟩) ∧
      (canonUnaryCore.runFrom d t).workTapes =
        Function.update d.workTapes 1 (FinTM.bufferTape []) ∧
      (canonUnaryCore.runFrom d t).workTapePos = d.workTapePos ∧
      ∀ ys, codeSkipFin (counterValue w + 1) (x.drop (d.inputPos.val - 1)) = some ys →
        (canonUnaryCore.runFrom d t).inputPos.val = x.length + 1 - ys.length := by
  let p := d.inputPos.val - 1
  have pos : d.inputPos.val = p + 1 := by dsimp [p]; omega
  have range : p ≤ x.length := by have := d.inputPos.isLt; omega
  obtain ⟨r, rest, parts, stop⟩ := canonTruePrefix (x.drop p)
  have size : x.length = p + r + rest.length := by
    have lengths := congrArg List.length parts
    simp only [List.length_drop, List.length_append, List.length_replicate] at lengths
    omega
  have fits : p + r ≤ x.length := by omega
  have lookup (i : ℕ) : x[p + i]? = (List.replicate r true ++ rest)[i]? := by
    rw [← parts]
    simp only [List.getElem?_drop]
  have hprefix (i : ℕ) (hi : i < r) : x[p + i]? = some true := by
    rw [lookup]
    simp [List.getElem?_append, hi]
  have last : x[p + r]? = rest.head? := by
    rw [lookup]
    simp [List.getElem?_append]
    cases rest <;> rfl
  have stopped : x[p + r]? ≠ some true := by
    rw [last]
    rcases stop with rfl | ⟨ys, rfl⟩ <;> simp
  let start : Cfg 2 Bool (CounterLoopState (Option Bool)) x :=
    d.mapState (fun _ => .dec .run)
  let body := counterLoopBody (some true) start
  have startState : start.state = some (.dec .run) := by simp [start, Cfg.mapState, hs]
  have layout : counterLoopCfg (some (.dec .run)) body (FinTM.bufferTape w) 0 = start := by
    rw [← startState]
    rw [← counter, ← home]
    exact counterLoopCfg_body (some true) start
  obtain ⟨l, boundL, v, q, width, which, runL, cutL⟩ :=
    canonUnaryLoop body rfl p r pos fits hprefix stopped w
  rw [layout] at runL cutL
  let afterLoop := (canonUnaryFamily none).runFrom start l
  have loopEq : afterLoop = _ := runL
  have stateL : afterLoop.state = some q := by rw [loopEq]; rfl
  have first := phaseHostTM_run canonUnaryFamily ⟨none, .dec .run⟩ canonUnaryNext
    none start afterLoop l rfl q stateL ⟨some none, none⟩
    (by simp [canonUnaryNext, which]) (by
      intro u hu s state
      have noDone : s ≠ .done := fun eq => (cutL u hu).1 (state.trans (congrArg some eq))
      have noEscape : s ≠ .escape := fun eq => (cutL u hu).2
        (state.trans (congrArg some eq))
      simp [canonUnaryNext, noDone, noEscape])
  have startEq : start.mapState (Sigma.mk none) = d := by
    apply Cfg.ext <;> simp [start, Cfg.mapState, hs]
  rw [startEq] at first
  let cellStart : Cfg 2 Bool (Option Bool) x := afterLoop.mapState (fun _ => none)
  have cellState : cellStart.state = some none := by simp [cellStart, Cfg.mapState, stateL]
  let bit := decide (cellStart.inputSymbol = some false)
  let afterCell := (canonCellTM 2 false).step cellStart
  have cellEq : afterCell = _ := canonCell_step false cellStart none cellState
  have stateT : afterCell.state = some (some bit) := by rw [cellEq]
  have second := phaseHostTM_run canonUnaryFamily ⟨none, .dec .run⟩ canonUnaryNext
    (some none) cellStart afterCell 1 rfl (some bit) stateT
    ⟨some (some bit), .sweep⟩ rfl (by
      intro u hu s state
      have zero : u = 0 := by omega
      subst u
      have eq : s = none := (Option.some.inj (cellState.symm.trans state)).symm
      subst s
      rfl)
  have cellJoin : afterLoop.mapState (fun _ => (⟨some none, none⟩ : Sigma canonUnaryPhase)) =
      cellStart.mapState (Sigma.mk (some none)) := by
    simp [cellStart, Cfg.mapState, Option.map_map, Function.comp_def]
  rw [← cellJoin] at second
  let clearStart : Cfg 2 Bool SweepPhase x := afterCell.mapState (fun _ => .sweep)
  have clearState : clearStart.state = some .sweep := by simp [clearStart, Cfg.mapState, stateT]
  have clearWord : clearStart.workTapes 1 = FinTM.bufferTape v ∧
      clearStart.workTapePos 1 = 0 := by
    change afterCell.workTapes 1 = _ ∧ afterCell.workTapePos 1 = _
    rw [cellEq]
    change afterLoop.workTapes 1 = _ ∧ afterLoop.workTapePos 1 = _
    rw [loopEq]
    simp only [counter_cfg_eq]
    change Fin.lastCases (motive := fun _ : Fin 2 => ℤ → Option Bool)
      (FinTM.bufferTape v) body.workTapes (Fin.last 1) = _ ∧
      Fin.lastCases (motive := fun _ : Fin 2 => ℤ) 0 body.workTapePos (Fin.last 1) = _
    simp only [Fin.lastCases_last, and_self]
  have clearing := clearTM_run_ofCfg (1 : Fin 2) v clearStart clearState
    (by intro z _ _; rw [clearWord.1, clearWord.2]; simp)
  let c := 2 * v.length + 2
  let afterClear := (clearTM 2 (1 : Fin 2)).runFrom clearStart c
  have clearEq : afterClear = _ := clearing.1
  have stateC : afterClear.state = some .done := by rw [clearEq]
  have third := phaseHostTM_run canonUnaryFamily ⟨none, .dec .run⟩ canonUnaryNext
    (some (some bit)) clearStart afterClear c rfl .done stateC
    ⟨some (some bit), .done⟩ (by rfl) (by
      intro u hu s state
      have notDone : s ≠ .done := fun eq =>
        clearing.2.1 u hu (state.trans (congrArg some eq))
      simp [canonUnaryNext, notDone])
  have clearJoin : afterCell.mapState
      (fun _ => (⟨some (some bit), .sweep⟩ : Sigma canonUnaryPhase)) =
      clearStart.mapState (Sigma.mk (some (some bit))) := by
    simp [clearStart, Cfg.mapState, Option.map_map, Function.comp_def]
  let duration := (l + 1) + 2 + c
  have whole : canonUnaryCore.runFrom d duration =
      afterClear.mapState (Sigma.mk (some (some bit))) := by
    change (phaseHostTM canonUnaryFamily ⟨none, .dec .run⟩ canonUnaryNext).runFrom d _ = _
    rw [MultiTapeTM.runFrom_add d (l + 1 + 2) c,
      MultiTapeTM.runFrom_add d (l + 1) 2, first.2, second.2, clearJoin,
      third.1 c le_rfl]
  have position : cellStart.inputPos.val = p + min (counterValue w) r + 1 := by
    change afterLoop.inputPos.val = _
    rw [loopEq]
    rfl
  have read : cellStart.inputSymbol = x[p + min (counterValue w) r]? :=
    FinTM.inputSymbol_at cellStart _
      (by have := Nat.min_le_right (counterValue w) r; omega) position
  have field := canonUnaryField (counterValue w) r rest stop
  rw [← parts] at field
  have verdict : (codeSkipFin (counterValue w + 1) (x.drop p)).isSome = bit := by
    rw [field]
    dsimp only [bit]
    rw [read]
    by_cases enough : r ≤ counterValue w
    · rw [if_pos enough, Nat.min_eq_right enough, last]
      rcases stop with rfl | ⟨ys, rfl⟩ <;> rfl
    · rw [if_neg enough, Nat.min_eq_left (by omega), hprefix _ (by omega)]
      rfl
  have tapes : afterClear.workTapes = Function.update d.workTapes 1 (FinTM.bufferTape []) := by
    rw [clearEq]
    funext j z
    fin_cases j
    · change clearStart.workTapes 0 z = d.workTapes 0 z
      change afterCell.workTapes 0 z = _
      rw [cellEq]
      change afterLoop.workTapes 0 z = _
      rw [loopEq]
      change Fin.lastCases (motive := fun _ : Fin 2 => ℤ → Option Bool)
        (FinTM.bufferTape v) body.workTapes (0 : Fin 1).castSucc z = _
      rw [Fin.lastCases_castSucc]
      rfl
    · simp only [FinTM.bufferTape_nil]
      change (if (1 : Fin 2) = 1 ∧ clearStart.workTapePos 1 ≤ z ∧
        z < clearStart.workTapePos 1 + (v.length : ℤ) then none
        else clearStart.workTapes 1 z) = none
      rw [clearWord.1, clearWord.2]
      simp only [true_and, zero_add]
      split_ifs with inside
      · rfl
      · by_cases nonneg : 0 ≤ z
        · simp [FinTM.bufferTape, nonneg,
            List.getElem?_eq_none (show v.length ≤ z.toNat by omega)]
        · simp [FinTM.bufferTape, nonneg]
  have heads : afterClear.workTapePos = d.workTapePos := by
    rw [clearEq]
    change afterCell.workTapePos = _
    rw [cellEq]
    change afterLoop.workTapePos = _
    rw [loopEq]
    funext j
    fin_cases j
    · change Fin.lastCases (motive := fun _ : Fin 2 => ℤ)
        0 body.workTapePos (0 : Fin 1).castSucc = _
      rw [Fin.lastCases_castSucc]
      rfl
    · change Fin.lastCases (motive := fun _ : Fin 2 => ℤ) 0 body.workTapePos (Fin.last 1) = _
      rw [Fin.lastCases_last]
      exact home.symm
  have output : afterClear.output = d.output := by
    rw [clearEq]
    change afterCell.output = _
    rw [cellEq]
    change afterLoop.output = _
    rw [loopEq]
    rfl
  refine ⟨duration, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · dsimp [duration, c]
    rw [width]
    omega
  · rw [whole]
    change Option.map (fun s : SweepPhase =>
      (⟨some (some bit), s⟩ : Sigma canonUnaryPhase)) afterClear.state = _
    rw [stateC]
    change some (⟨some (some bit), SweepPhase.done⟩ : Sigma canonUnaryPhase) =
      some ⟨some (some (codeSkipFin (counterValue w + 1) (x.drop p)).isSome), .done⟩
    rw [verdict]
  · rw [whole]
    exact output
  · intro u hu b
    by_cases early : u ≤ l
    · rw [first.1 u early]
      intro eq
      obtain ⟨s, _, bad⟩ := Option.map_eq_some_iff.mp eq
      have impossible := congrArg Sigma.fst bad
      cases impossible
    · have index : u = l + 1 + (u - (l + 1)) := by omega
      rw [index, MultiTapeTM.runFrom_add, first.2]
      by_cases middle : u - (l + 1) ≤ 1
      · rw [second.1 _ middle]
        intro eq
        obtain ⟨s, _, bad⟩ := Option.map_eq_some_iff.mp eq
        have impossible := congrArg Sigma.fst bad
        cases impossible
      · have tailIndex : u - (l + 1) = 2 + (u - (l + 1) - 2) := by omega
        rw [tailIndex, MultiTapeTM.runFrom_add, second.2, clearJoin,
          third.1 _ (by dsimp [duration] at hu; omega)]
        intro eq
        obtain ⟨s, state, tag⟩ := Option.map_eq_some_iff.mp eq
        have equalBits : bit = b := by
          have e := congrArg Sigma.fst tag
          exact Option.some.inj (Option.some.inj e)
        subst b
        have same : s = .done := eq_of_heq (Sigma.mk.inj_iff.mp tag).2
        exact clearing.2.1 _ (by dsimp [duration, c] at *; omega)
          (state.trans (congrArg some same))
  · rw [whole]
    exact tapes
  · rw [whole]
    exact heads
  · intro ys accepted
    change codeSkipFin (counterValue w + 1) (x.drop p) = some ys at accepted
    rw [field] at accepted
    have enough : r ≤ counterValue w := by
      by_contra small
      simp [small] at accepted
    rw [if_pos enough] at accepted
    rcases stop with rfl | ⟨tail, rfl⟩
    · cases accepted
    · have same : tail = ys := Option.some.inj accepted
      subst ys
      have value : cellStart.inputSymbol = some false := by
        rw [read, Nat.min_eq_right enough, last]
        rfl
      rw [whole, clearEq]
      change afterCell.inputPos.val = _
      rw [cellEq]
      simp only [value, if_true]
      have beforeEnd : cellStart.inputPos.val ≠ x.length + 1 := by
        intro eq
        simp only [List.length_cons, Nat.min_eq_right enough] at size position
        omega
      change (moveInputPos cellStart.inputPos SignType.pos).val = _
      rw [moveInputPos_pos_of_ne_right _ beforeEnd]
      change cellStart.inputPos.val + 1 = x.length + 1 - tail.length
      simp only [List.length_cons, Nat.min_eq_right enough] at size position
      omega

/-- The bounded unary reader uses two tapes: the preserved bound and one restored scratch
counter. It consumes the field on acceptance and preserves every work tape and head.

**Proof sketch.** Copy the bound by the framed catalog row, then dispatch through the
public seam to the unary core. That core tests its stopping cell and clears its residual
counter. The untouched bound and blank scratch give exact restoration, and the
copy, seam, and core ledgers fit one linear bound. -/
private lemma exists_canonUnaryTM :
    ∃ (m : ℕ) (S : Type) (_ : Fintype S) (_ : DecidableEq S) (U : MultiTapeTM m Bool S)
      (entry : S) (exit : Bool → S) (bound : Fin m) (a : ℕ), Function.Injective exit ∧
      ∀ (x w : List Bool) (d : Cfg m Bool S x), d.state = some entry →
        1 ≤ d.inputPos.val →
        d.workTapes bound = FinTM.bufferTape w → d.workTapePos bound = 0 →
        (∀ j, j ≠ bound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0) →
        ∃ t ≤ a * (x.length + w.length + 1),
          (U.runFrom d t).state =
            some (exit (codeSkipFin (counterValue w + 1) (x.drop (d.inputPos.val - 1))).isSome) ∧
          (U.runFrom d t).output = d.output ∧
          (∀ u < t, ∀ v, (U.runFrom d u).state ≠ some (exit v)) ∧
          (U.runFrom d t).workTapes = d.workTapes ∧
          (U.runFrom d t).workTapePos = d.workTapePos ∧
          ∀ ys, codeSkipFin (counterValue w + 1) (x.drop (d.inputPos.val - 1)) = some ys →
            (U.runFrom d t).inputPos.val = x.length + 1 - ys.length := by
  letI : ∀ p, Fintype (canonUnaryPhase p) := fun p => by
    cases p with
    | none => exact inferInstance
    | some b => cases b <;> exact inferInstance
  letI : ∀ p, DecidableEq (canonUnaryPhase p) := fun p => by
    cases p with
    | none => exact inferInstance
    | some b => cases b <;> exact inferInstance
  let C := copyTM (Symbol := Bool) 2 0 1
  let U := seamCompTM C .done canonUnaryCore ⟨none, .dec .run⟩
  let exit (b : Bool) : SweepPhase ⊕ Sigma canonUnaryPhase := Sum.inr ⟨some (some b), .done⟩
  refine ⟨2, _, inferInstance, inferInstance, U, Sum.inl .sweep, exit, 0, 16, ?_, ?_⟩
  · intro a b eq
    have tagged := congrArg Sigma.fst (Sum.inr.inj eq)
    exact Option.some.inj (Option.some.inj tagged)
  · intro x w d state positive bound home blank
    let cp : Cfg 2 Bool SweepPhase x :=
      ⟨some .sweep, d.inputPos, d.workTapes, d.workTapePos, d.output⟩
    have start : cp.mapState Sum.inl = d := by
      exact Cfg.ext state.symm rfl rfl rfl rfl
    have scratch := blank 1 (by decide)
    have copied := copyTM_run_ofCfg (0 : Fin 2) 1 (by decide) w cp rfl
      (by intro z _ _; change d.workTapes 0 (d.workTapePos 0 + z) = _; rw [bound, home]; simp)
    let e := C.runFrom cp (2 * w.length + 2)
    have copyEq : e = _ := copied.1
    have atExit : e.state = some .done := by rw [copyEq]
    let next := e.mapState (fun _ => (⟨none, .dec .run⟩ : Sigma canonUnaryPhase))
    have counter : next.workTapes 1 = FinTM.bufferTape w := by
      change e.workTapes 1 = _
      rw [copyEq]
      funext z
      change (if (1 : Fin 2) = 1 ∧ d.workTapePos 1 ≤ z ∧
        z < d.workTapePos 1 + (w.length : ℤ) then FinTM.bufferTape w (z - d.workTapePos 1)
        else d.workTapes 1 z) = FinTM.bufferTape w z
      rw [scratch.1, scratch.2]
      simp only [true_and, zero_add, sub_zero, FinTM.bufferTape_nil]
      split_ifs with inside
      · rfl
      · by_cases nonneg : 0 ≤ z
        · simp [FinTM.bufferTape, nonneg,
            List.getElem?_eq_none (show w.length ≤ z.toNat by omega)]
        · simp [FinTM.bufferTape, nonneg]
    have nextPos : next.inputPos = d.inputPos := by change e.inputPos = _; rw [copyEq]
    have nextHeads : next.workTapePos = d.workTapePos := by
      change e.workTapePos = _
      rw [copyEq]
    have nextOutput : next.output = d.output := by change e.output = _; rw [copyEq]
    obtain ⟨t, budget, finish, silent, cuts, tapes, heads, suffix⟩ :=
      canonUnaryCore_run w next (by simp [next, Cfg.mapState, atExit])
        (by rw [nextPos]; exact positive) counter (by rw [nextHeads]; exact scratch.2)
    have whole := seamCompTM_run_ofCfg C .done canonUnaryCore ⟨none, .dec .run⟩
      (rfl : C.runFrom cp (2 * w.length + 2) = e) atExit copied.2.1
      (rfl : canonUnaryCore.runFrom next t = _)
    rw [start] at whole
    refine ⟨2 * w.length + 2 + 1 + t, by omega, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · rw [whole]
      change Option.map Sum.inr (canonUnaryCore.runFrom next t).state = _
      rw [finish, nextPos]
      rfl
    · rw [whole]
      exact silent.trans nextOutput
    · intro u hu b
      change ((seamCompTM C .done canonUnaryCore ⟨none, .dec .run⟩).runFrom d u).state ≠ _
      rw [← start]
      apply canonSeam_avoids C .done canonUnaryCore ⟨none, .dec .run⟩ (exit b)
        (rfl : C.runFrom cp (2 * w.length + 2) = e) atExit copied.2.1 (v := t)
        (by intro z _; simp [exit, Cfg.mapState])
        (by intro z hz; simpa [exit, Cfg.mapState] using cuts z hz b) u hu
    · rw [whole]
      change (canonUnaryCore.runFrom next t).workTapes = _
      rw [tapes]
      funext j z
      fin_cases j
      · change next.workTapes 0 z = _
        change e.workTapes 0 z = _
        rw [copyEq]
        rfl
      · simpa only [Function.update_self] using congrFun scratch.1.symm z
    · rw [whole]
      exact heads.trans nextHeads
    · intro ys skipped
      rw [whole]
      exact suffix ys (by simpa only [nextPos] using skipped)

/-- A finite list of two-cell validators, in native reading order. -/
private def canonPairs : List (Bool → Bool → Bool) → List Bool → Option (List Bool)
  | [], xs => some xs
  | v :: vs, xs => (codeSkipPair v xs).bind (canonPairs vs)

/-- The native fixed-field leaf remembers the first cell of a pair and its finite pair
index. It rejects a blank immediately and validates each pair before proceeding.
The catalog's input folds require a whole-input traversal from position one; this local
fixed-width validator is the missing leaf. -/
private def canonPairsTM (m : ℕ) (vs : List (Bool → Bool → Bool)) :
    MultiTapeTM m Bool (Bool ⊕ (Fin (vs.length + 1) × Option Bool)) where
  q₀ := Sum.inr (0, none)
  tr := fun q inp _ => match q with
    | Sum.inl b => inputMoveAction 0 (Sum.inl b)
    | Sum.inr (j, a) =>
      if h : j.val < vs.length then
        match a, inp with
        | none, some b => inputMoveAction 1 (Sum.inr (j, some b))
        | some a, some b =>
          if vs[j.val] a b then
            inputMoveAction 1 (Sum.inr (⟨j.val + 1, by omega⟩, none))
          else inputMoveAction 0 (Sum.inl false)
        | _, none => inputMoveAction 0 (Sum.inl false)
      else inputMoveAction 0 (Sum.inl true)

/-- Native reads are lookups at the head of the current suffix. Advancing over a present
cell leaves precisely its tail. This is a use of the public input lookup and move laws. -/
private lemma canonNativeSuffix {m : ℕ} {S : Type} {x : List Bool}
    (d : Cfg m Bool S x) (p : ℕ) (pos : d.inputPos.val = p + 1)
    (range : p ≤ x.length) :
    d.inputSymbol = (x.drop p).head? ∧
      ∀ b ys, x.drop p = b :: ys →
        (moveInputPos d.inputPos 1).val = p + 2 ∧ x.drop (p + 1) = ys := by
  refine ⟨?_, ?_⟩
  · rw [FinTM.inputSymbol_at d p range pos, List.head?_drop]
  · intro b ys split
    have size := congrArg List.length split
    simp only [List.length_drop, List.length_cons] at size
    have beforeEnd : d.inputPos.val ≠ x.length + 1 := by omega
    constructor
    · change (moveInputPos d.inputPos SignType.pos).val = _
      rw [moveInputPos_pos_of_ne_right d.inputPos beforeEnd]
      simp only [pos]
    · have tail := congrArg (List.drop 1) split
      simpa only [List.drop_drop, Nat.add_comm 1 p, List.drop_succ_cons, List.drop_zero] using tail

/-- A native fixed-field scan is linear in the finite list of pair tests. The head never
returns to the left blank, and every work tape and head is unchanged.

**Proof sketch.** Induct on the number of remaining pairs. A missing first or second
cell rejects immediately. A failed predicate rejects after two tests; a successful pair
advances two cells and invokes the induction hypothesis at the next finite index.
Only the permitted native leaf is traced; there is no private phase or loop host. -/
private lemma canonPairs_run {m : ℕ} {x : List Bool} (vs : List (Bool → Bool → Bool))
    (j : Fin (vs.length + 1))
    (d : Cfg m Bool (Bool ⊕ (Fin (vs.length + 1) × Option Bool)) x)
    (p : ℕ) (pos : d.inputPos.val = p + 1) (range : p ≤ x.length)
    (state : d.state = some (Sum.inr (j, none))) :
    ∃ t ≤ 2 * (vs.length - j.val) + 1,
      ((canonPairsTM m vs).runFrom d t).state =
        some (Sum.inl (canonPairs (vs.drop j.val) (x.drop p)).isSome) ∧
      ((canonPairsTM m vs).runFrom d t).output = d.output ∧
      (∀ u < t, ∀ b, ((canonPairsTM m vs).runFrom d u).state ≠ some (Sum.inl b)) ∧
      ((canonPairsTM m vs).runFrom d t).workTapes = d.workTapes ∧
      ((canonPairsTM m vs).runFrom d t).workTapePos = d.workTapePos ∧
      1 ≤ ((canonPairsTM m vs).runFrom d t).inputPos.val ∧
      ∀ ys, canonPairs (vs.drop j.val) (x.drop p) = some ys →
        ((canonPairsTM m vs).runFrom d t).inputPos.val = x.length + 1 - ys.length := by
  generalize hn : vs.length - j.val = n
  induction n using Nat.strong_induction_on generalizing j d p with
  | h n ih =>
    let M := canonPairsTM m vs
    have native := canonNativeSuffix d p pos range
    have firstCut (b : Bool) : (M.runFrom d 0).state ≠ some (Sum.inl b) := by
      simpa only [MultiTapeTM.runFrom_zero, state] using
        (by simp : some (Sum.inr (j, none)) ≠
          (some (Sum.inl b) : Option (Bool ⊕ (Fin (vs.length + 1) × Option Bool))))
    by_cases more : j.val < vs.length
    · have parse : canonPairs (vs.drop j.val) (x.drop p) =
          (codeSkipPair vs[j.val] (x.drop p)).bind (canonPairs (vs.drop (j.val + 1))) := by
        rw [List.drop_eq_getElem_cons more]
        rfl
      cases suffix : x.drop p with
      | nil =>
        rw [← suffix]
        have read : d.inputSymbol = none := by rw [native.1, suffix]; rfl
        have step := step_of_inputMoveAction M d (q' := Sum.inl false) 0 state
          (by simp [M, canonPairsTM, more, read])
        have run : M.runFrom d 1 = { d with state := some (Sum.inl false) } := by
          simpa only [moveInputPos_zero] using step
        have verdict : canonPairs (vs.drop j.val) (x.drop p) = none := by
          rw [parse, suffix]
          rfl
        refine ⟨1, by omega, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · rw [run, verdict]; rfl
        · rw [run]
        · intro u hu b
          have zero : u = 0 := by omega
          subst u
          exact firstCut b
        · rw [run]
        · rw [run]
        · rw [run]; change 1 ≤ d.inputPos.val; omega
        · intro ys accepted; rw [verdict] at accepted; cases accepted
      | cons a tail =>
        rw [← suffix]
        have read : d.inputSymbol = some a := by rw [native.1, suffix]; rfl
        have advance := native.2 a tail suffix
        let d1 : Cfg m Bool (Bool ⊕ (Fin (vs.length + 1) × Option Bool)) x :=
          { d with
            state := some (Sum.inr (j, some a))
            inputPos := moveInputPos d.inputPos 1 }
        have run1 : M.runFrom d 1 = d1 :=
          step_of_inputMoveAction M d _ state
            (by simp [M, canonPairsTM, more, read])
        have pos1 : d1.inputPos.val = (p + 1) + 1 := by
          exact advance.1
        have range1 : p + 1 ≤ x.length := by have := d1.inputPos.isLt; omega
        have native1 := canonNativeSuffix d1 (p + 1) pos1 range1
        have d1state : d1.state = some (Sum.inr (j, some a)) := rfl
        have cut1 (b : Bool) : (M.runFrom d 1).state ≠ some (Sum.inl b) := by
          rw [run1, d1state]
          simp
        have fail (invalid : codeSkipPair vs[j.val] (x.drop p) = none)
            (tr : M.tr (Sum.inr (j, some a)) d1.inputSymbol d1.workTapeSymbols =
              inputMoveAction 0 (Sum.inl false)) :
            ∃ t ≤ 2 * n + 1,
              (M.runFrom d t).state =
                some (Sum.inl (canonPairs (vs.drop j.val) (x.drop p)).isSome) ∧
              (M.runFrom d t).output = d.output ∧
              (∀ u < t, ∀ b, (M.runFrom d u).state ≠ some (Sum.inl b)) ∧
              (M.runFrom d t).workTapes = d.workTapes ∧
              (M.runFrom d t).workTapePos = d.workTapePos ∧
              1 ≤ (M.runFrom d t).inputPos.val ∧
              ∀ ys, canonPairs (vs.drop j.val) (x.drop p) = some ys →
                (M.runFrom d t).inputPos.val = x.length + 1 - ys.length := by
          have step := step_of_inputMoveAction M d1 _ d1state tr
          have run2 : M.runFrom d 2 = { d1 with state := some (Sum.inl false) } := by
            rw [show 2 = 1 + 1 from rfl, MultiTapeTM.runFrom_add (tm := M) d 1 1, run1]
            simpa only [moveInputPos_zero] using step
          have verdict : canonPairs (vs.drop j.val) (x.drop p) = none := by
            rw [parse, invalid]
            rfl
          refine ⟨2, by omega, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
          · rw [run2, verdict]; rfl
          · rw [run2]
          · intro u hu b
            have choices : u = 0 ∨ u = 1 := by omega
            rcases choices with rfl | rfl
            · exact firstCut b
            · exact cut1 b
          · rw [run2]
          · rw [run2]
          · rw [run2]; change 1 ≤ d1.inputPos.val; omega
          · intro ys accepted; rw [verdict] at accepted; cases accepted
        cases tail with
        | nil =>
          apply fail (by rw [suffix]; rfl)
          have read1 : d1.inputSymbol = none := by rw [native1.1, advance.2]; rfl
          simp [M, canonPairsTM, more, read1]
        | cons b ys =>
          have read1 : d1.inputSymbol = some b := by rw [native1.1, advance.2]; rfl
          by_cases valid : vs[j.val] a b = true
          · let j' : Fin (vs.length + 1) := ⟨j.val + 1, by omega⟩
            let d2 : Cfg m Bool (Bool ⊕ (Fin (vs.length + 1) × Option Bool)) x :=
              { d1 with
                state := some (Sum.inr (j', none))
                inputPos := moveInputPos d1.inputPos 1 }
            have run2 : M.runFrom d 2 = d2 := by
              rw [show 2 = 1 + 1 from rfl, MultiTapeTM.runFrom_add (tm := M) d 1 1, run1]
              exact step_of_inputMoveAction M d1 _ d1state
                (by simp [M, canonPairsTM, more, read1, valid, j'])
            have advance1 := native1.2 b ys advance.2
            have pos2 : d2.inputPos.val = (p + 2) + 1 := advance1.1
            have range2 : p + 2 ≤ x.length := by have := d2.inputPos.isLt; omega
            have parser : canonPairs (vs.drop j.val) (x.drop p) =
                canonPairs (vs.drop j'.val) (x.drop (p + 2)) := by
              rw [parse, suffix]
              simp only [codeSkipPair, valid, if_true, Option.bind_some]
              exact congrArg (canonPairs (vs.drop j'.val)) advance1.2.symm
            obtain ⟨t, budget, finish, silent, cuts, tapes, heads, positive, consumed⟩ :=
              ih (vs.length - j'.val) (by dsimp [j']; omega) j' d2 (p + 2)
                pos2 range2 rfl rfl
            have whole : M.runFrom d (2 + t) = M.runFrom d2 t := by
              rw [MultiTapeTM.runFrom_add (tm := M), run2]
            refine ⟨2 + t, by dsimp [j'] at budget; omega, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
            · rw [whole, parser]; exact finish
            · rw [whole]; exact silent
            · intro u hu bit
              by_cases early : u < 2
              · have choices : u = 0 ∨ u = 1 := by omega
                rcases choices with rfl | rfl
                · exact firstCut bit
                · exact cut1 bit
              · have index : u = 2 + (u - 2) := by omega
                rw [index, MultiTapeTM.runFrom_add (tm := M), run2]
                exact cuts _ (by omega) bit
            · rw [whole]; exact tapes
            · rw [whole]; exact heads
            · rw [whole]; exact positive
            · intro zs accepted
              rw [whole]
              exact consumed zs (parser.symm.trans accepted)
          · apply fail (by simp [suffix, codeSkipPair, valid])
            simp [M, canonPairsTM, more, read1, valid]
    · have done : vs.drop j.val = [] := List.drop_eq_nil_of_le (by omega)
      have step := step_of_inputMoveAction M d (q' := Sum.inl true) 0 state
        (by simp [M, canonPairsTM, more])
      have run : M.runFrom d 1 = { d with state := some (Sum.inl true) } := by
        simpa only [moveInputPos_zero] using step
      refine ⟨1, by omega, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [run, done]; rfl
      · rw [run]
      · intro u hu b
        have zero : u = 0 := by omega
        subst u
        exact firstCut b
      · rw [run]
      · rw [run]
      · rw [run]; change 1 ≤ d.inputPos.val; omega
      · intro ys accepted
        have same : x.drop p = ys := Option.some.inj (by simpa [done, canonPairs] using accepted)
        have lengths := congrArg List.length same
        simp only [List.length_drop] at lengths
        rw [run]
        change d.inputPos.val = _
        omega

/-- Work-tape write/move pairs followed by the output pair. Every write pair is valid;
move and output pairs exclude precisely `false, true`. -/
private def canonWorkPairs : ℕ → List (Bool → Bool → Bool)
  | 0 => [fun a b => a || !b]
  | k + 1 => (fun _ _ => true) :: (fun a b => a || !b) :: canonWorkPairs k

/-- The finite pair list has exactly the grammar's fixed-field semantics.

**Proof sketch.** Induct on the number of work-tape pairs, using `codeSkipWork` for
each write/move pair and associativity of `Option.bind` for the output and input fields. -/
private lemma canonPairs_fields (k : ℕ) (xs : List Bool) :
    canonPairs ((fun a b => a || !b) :: canonWorkPairs k) xs = canonSkipFields k xs := by
  have work (j : ℕ) (ys : List Bool) : canonPairs (canonWorkPairs j) ys =
      (codeSkipRepeat codeSkipWork j ys).bind (codeSkipPair (fun a b => a || !b)) := by
    induction j generalizing ys with
    | zero => simp [canonWorkPairs, canonPairs, codeSkipRepeat]
    | succ j ih =>
      simp only [canonWorkPairs, canonPairs, ih, codeSkipRepeat, codeSkipWork, Option.bind_assoc]
  simp only [canonPairs, work, canonSkipFields, Option.bind_assoc]

/-- There are `2k + 2` fixed pairs in one action record. -/
private lemma canonWorkPairs_length (k : ℕ) : (canonWorkPairs k).length = 2 * k + 1 := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [canonWorkPairs, List.length_cons, ih]; omega

/-- One native tag test records blank, false, or true and advances exactly for a present
cell. It supplies the local successor tag check, absent from the whole-input catalog. -/
private def canonTagTM (m : ℕ) : MultiTapeTM m Bool (Option (Option Bool)) where
  q₀ := none
  tr := fun _ inp _ => inputMoveAction (if inp.isSome then 1 else 0) (some inp)

/-- The tag leaf's single step follows the public input-only action contract. -/
private lemma canonTag_step {m : ℕ} {x : List Bool}
    (d : Cfg m Bool (Option (Option Bool)) x) (hs : d.state = some none) :
    (canonTagTM m).runFrom d 1 =
      { d with
        state := some (some d.inputSymbol)
        inputPos := moveInputPos d.inputPos (if d.inputSymbol.isSome then 1 else 0) } :=
  step_of_inputMoveAction _ _ _ hs rfl

/-- The record's native finite pair list. -/
private abbrev canonRecordPairs (k : ℕ) : List (Bool → Bool → Bool) :=
  (fun a b => a || !b) :: canonWorkPairs k

/-- Fixed pairs, the successor tag, and the bounded unary component are the three
phases. The two final ports are in the tag phase. -/
private abbrev canonRecordPhase (k : ℕ) (S : Type) : Option Bool → Type
  | none => Bool ⊕ (Fin ((canonRecordPairs k).length + 1) × Option Bool)
  | some false => Option (Option Bool)
  | some true => S

/-- Each record phase is an existing component or one permitted native leaf. -/
private def canonRecordFamily {m : ℕ} {S : Type} (k : ℕ) (U : MultiTapeTM m Bool S)
    (p : Option Bool) : MultiTapeTM m Bool (canonRecordPhase k S p) := match p with
  | none => canonPairsTM m (canonRecordPairs k)
  | some false => canonTagTM m
  | some true => U

/-- The public phase host dispatches failures to the false port, a false successor tag
to the true port, and a true successor tag to the bounded unary reader. -/
private def canonRecordNext {S : Type} [DecidableEq S] (k : ℕ) (entry : S) (exit : Bool → S) :
    (p : Option Bool) → canonRecordPhase k S p → Option (Sigma (canonRecordPhase k S))
  | none, Sum.inl true => some ⟨some false, none⟩
  | none, Sum.inl false => some ⟨some false, some none⟩
  | none, Sum.inr _ => none
  | some false, none => none
  | some false, some none => some ⟨some false, some none⟩
  | some false, some (some false) => some ⟨some false, some (some false)⟩
  | some false, some (some true) => some ⟨some true, entry⟩
  | some true, q =>
    if q = exit true then some ⟨some false, some (some false)⟩
    else if q = exit false then some ⟨some false, some none⟩ else none

/-- The generic action-record validator preserves its binary bound and scratch bank.
It decides the fixed fields and successor field with strict Boolean exits and a linear
bound in the input length and binary width.

**Proof sketch.** The native pair leaf decides the prescribed fixed fields. A public
phase host then reads the successor tag: blank rejects, false accepts, and true dispatches
to the proved bounded unary reader on the same bank. The reader's framed contract restores
the bank. The fixed finite cost plus its linear ledger gives one linear bound. -/
private lemma exists_canonRecordTM (k : ℕ) :
    ∃ (m : ℕ) (S : Type) (_ : Fintype S) (_ : DecidableEq S) (R : MultiTapeTM m Bool S)
      (entry : S) (exit : Bool → S) (bound : Fin m) (a : ℕ), Function.Injective exit ∧
      ∀ (x w : List Bool) (d : Cfg m Bool S x), d.state = some entry →
        1 ≤ d.inputPos.val →
        d.workTapes bound = FinTM.bufferTape w → d.workTapePos bound = 0 →
        (∀ j, j ≠ bound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0) →
        ∃ t ≤ a * (x.length + w.length + 1),
          (R.runFrom d t).state =
            some (exit (codeSkipActionK k (counterValue w) (x.drop (d.inputPos.val - 1))).isSome) ∧
          (R.runFrom d t).output = d.output ∧
          (∀ u < t, ∀ v, (R.runFrom d u).state ≠ some (exit v)) ∧
          (R.runFrom d t).workTapes = d.workTapes ∧
          (R.runFrom d t).workTapePos = d.workTapePos ∧
          ∀ ys, codeSkipActionK k (counterValue w) (x.drop (d.inputPos.val - 1)) = some ys →
            (R.runFrom d t).inputPos.val = x.length + 1 - ys.length := by
  obtain ⟨m, S, fS, dS, U, ue, ux, bound, a, injective, unary⟩ := exists_canonUnaryTM
  letI : Fintype S := fS
  letI : DecidableEq S := dS
  letI : ∀ p, Fintype (canonRecordPhase k S p) := fun p => by
    cases p with
    | none => exact inferInstance
    | some b => cases b <;> exact inferInstance
  letI : ∀ p, DecidableEq (canonRecordPhase k S p) := fun p => by
    cases p with
    | none => exact inferInstance
    | some b => cases b <;> exact inferInstance
  let family := canonRecordFamily k U
  let red := canonRecordNext k ue ux
  let entry : Sigma (canonRecordPhase k S) := ⟨none, Sum.inr (0, none)⟩
  let R := phaseHostTM family entry red
  let exit (b : Bool) : Sigma (canonRecordPhase k S) :=
    ⟨some false, some (if b then some false else none)⟩
  refine ⟨m, _, inferInstance, inferInstance, R, entry, exit, bound, a + 4 * k + 9, ?_, ?_⟩
  · intro b c eq
    cases b <;> cases c <;> simp_all [exit]
  · intro x w d state positive word origin blank
    let p := d.inputPos.val - 1
    have pos : d.inputPos.val = p + 1 := by dsimp [p]; omega
    have range : p ≤ x.length := by have := d.inputPos.isLt; omega
    let f : Cfg m Bool (canonRecordPhase k S none) x :=
      d.mapState (fun _ => Sum.inr (0, none))
    have fState : f.state = some (Sum.inr (0, none)) := by simp [f, Cfg.mapState, state]
    obtain ⟨ft, fixedBudget, fixedExit, fixedOutput, fixedCuts, fixedTapes, fixedHeads,
      fixedPositive, fixedConsumed⟩ :=
      canonPairs_run (canonRecordPairs k) 0 f p pos range fState
    simp only [Fin.val_zero, Nat.sub_zero, canonRecordPairs, List.length_cons,
      canonWorkPairs_length] at fixedBudget
    simp only [Fin.val_zero, List.drop_zero, canonRecordPairs, canonPairs_fields]
      at fixedExit fixedConsumed
    let fEnd := (family none).runFrom f ft
    have fExit : fEnd.state = some (Sum.inl (canonSkipFields k (x.drop p)).isSome) := fixedExit
    have fOutput : fEnd.output = d.output := fixedOutput
    have fTapes : fEnd.workTapes = d.workTapes := fixedTapes
    have fHeads : fEnd.workTapePos = d.workTapePos := fixedHeads
    let target : Sigma (canonRecordPhase k S) :=
      if (canonSkipFields k (x.drop p)).isSome then ⟨some false, none⟩ else exit false
    have first := phaseHostTM_run family entry red none f fEnd ft rfl _ fExit target
      (by cases h : (canonSkipFields k (x.drop p)).isSome <;>
          simp [red, canonRecordNext, target, h, exit]) (by
        intro u hu s hs
        cases s with
        | inr pair => rfl
        | inl b => exact (fixedCuts u hu b hs).elim)
    have start : f.mapState (Sigma.mk none) = d := by
      apply Cfg.ext <;> simp [f, Cfg.mapState, state, entry]
    rw [start] at first
    have safeFirst (u : ℕ) (hu : u ≤ ft) (b : Bool) :
        (R.runFrom d u).state ≠ some (exit b) := by
      rw [first.1 u hu]
      intro eq
      obtain ⟨s, _, tagged⟩ := Option.map_eq_some_iff.mp eq
      have impossible := congrArg Sigma.fst tagged
      cases impossible
    cases fields : canonSkipFields k (x.drop p) with
    | none =>
      have record : codeSkipActionK k (counterValue w) (x.drop p) = none := by
        rw [canonSkipAction_eq, fields]
        rfl
      have run : R.runFrom d (ft + 1) = fEnd.mapState (fun _ => exit false) := by
        simpa only [target, fields, Option.isSome_none, Bool.false_eq_true, if_false] using first.2
      refine ⟨ft + 1, by nlinarith, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [run]
        change Option.map (fun _ => exit false) fEnd.state = _
        rw [fExit]
        change some (exit false) =
          some (exit (codeSkipActionK k (counterValue w) (x.drop p)).isSome)
        rw [record]
        rfl
      · rw [run]; exact fOutput
      · intro u hu b; exact safeFirst u (by omega) b
      · rw [run]; exact fTapes
      · rw [run]; exact fHeads
      · intro ys accepted
        change codeSkipActionK k (counterValue w) (x.drop p) = some ys at accepted
        rw [record] at accepted
        cases accepted
    | some ys =>
      have record : codeSkipActionK k (counterValue w) (x.drop p) =
          codeSkipState (counterValue w + 1) ys := by
        rw [canonSkipAction_eq, fields]
        rfl
      obtain ⟨pre, split, width⟩ := canonSkipFields_cells k (x.drop p) ys fields
      have size : x.length = p + pre.length + ys.length := by
        have lengths := congrArg List.length split
        simp only [List.length_drop, List.length_append] at lengths
        omega
      have tail : x.drop (p + pre.length) = ys := by
        have e := congrArg (List.drop pre.length) split
        simpa only [List.drop_drop, List.drop_left] using e
      let tagStart : Cfg m Bool (Option (Option Bool)) x := fEnd.mapState (fun _ => none)
      have tagState : tagStart.state = some none := by simp [tagStart, Cfg.mapState, fExit]
      have tagPos : tagStart.inputPos.val = p + pre.length + 1 := by
        have h := fixedConsumed ys fields
        change fEnd.inputPos.val = _ at h ⊢
        omega
      have native := canonNativeSuffix tagStart (p + pre.length) tagPos (by omega)
      have tagRead : tagStart.inputSymbol = ys.head? := by rw [native.1, tail]
      let tagEnd := (canonTagTM m).runFrom tagStart 1
      have tagEq : tagEnd = _ := canonTag_step tagStart tagState
      have tagExit : tagEnd.state = some (some ys.head?) := by rw [tagEq, tagRead]
      let tagNext : Sigma (canonRecordPhase k S) := match ys.head? with
        | some true => ⟨some true, ue⟩
        | some false => exit true
        | none => exit false
      have second := phaseHostTM_run family entry red (some false) tagStart tagEnd 1 rfl
        (some ys.head?) tagExit tagNext (by
          cases h : ys.head? with
          | none => simp [red, canonRecordNext, tagNext, h, exit]
          | some b => cases b <;> simp [red, canonRecordNext, tagNext, h, exit]) (by
          intro u hu s hs
          have zero : u = 0 := by omega
          subst u
          have eq : s = none := (Option.some.inj (tagState.symm.trans hs)).symm
          subst s
          rfl)
      have join : fEnd.mapState (fun _ => target) =
          tagStart.mapState (Sigma.mk (some false)) := by
        simp [tagStart, target, fields, Cfg.mapState, Option.map_map, Function.comp_def]
      have firstRun : R.runFrom d (ft + 1) = tagStart.mapState (Sigma.mk (some false)) := by
        rw [first.2, join]
      have tagRun : R.runFrom d (ft + 2) = tagEnd.mapState (Sigma.mk (some false)) := by
        rw [show ft + 2 = ft + 1 + 1 by omega,
          MultiTapeTM.runFrom_add d (ft + 1) 1, firstRun, second.1 1 le_rfl]
      have tagDispatch : R.runFrom d (ft + 3) = tagEnd.mapState (fun _ => tagNext) := by
        rw [show ft + 3 = ft + 1 + (1 + 1) by omega,
          MultiTapeTM.runFrom_add d (ft + 1) (1 + 1), firstRun, second.2]
      have tagOutput : tagEnd.output = d.output := by rw [tagEq]; exact fOutput
      have tagTapes : tagEnd.workTapes = d.workTapes := by rw [tagEq]; exact fTapes
      have tagHeads : tagEnd.workTapePos = d.workTapePos := by rw [tagEq]; exact fHeads
      have safeTag (u : ℕ) (hu : u ≤ ft + 1) (b : Bool) :
          (R.runFrom d u).state ≠ some (exit b) := by
        by_cases early : u ≤ ft
        · exact safeFirst u early b
        · have eq : u = ft + 1 := by omega
          rw [eq, firstRun]
          simp [Cfg.mapState, tagState, exit]
      cases ys with
      | nil =>
        refine ⟨ft + 2, by nlinarith, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · rw [tagRun]
          change Option.map (fun s : Option (Option Bool) =>
            (⟨some false, s⟩ : Sigma (canonRecordPhase k S))) tagEnd.state = _
          rw [tagExit]
          change some (exit false) =
            some (exit (codeSkipActionK k (counterValue w) (x.drop p)).isSome)
          rw [record]
          rfl
        · rw [tagRun]; exact tagOutput
        · intro u hu b; exact safeTag u (by omega) b
        · rw [tagRun]; exact tagTapes
        · rw [tagRun]; exact tagHeads
        · intro zs accepted
          change codeSkipActionK k (counterValue w) (x.drop p) = some zs at accepted
          rw [record] at accepted
          cases accepted
      | cons b ys =>
        cases b with
        | false =>
          refine ⟨ft + 2, by nlinarith, ?_, ?_, ?_, ?_, ?_, ?_⟩
          · rw [tagRun]
            change Option.map (fun s : Option (Option Bool) =>
              (⟨some false, s⟩ : Sigma (canonRecordPhase k S))) tagEnd.state = _
            rw [tagExit]
            change some (exit true) =
              some (exit (codeSkipActionK k (counterValue w) (x.drop p)).isSome)
            rw [record]
            rfl
          · rw [tagRun]; exact tagOutput
          · intro u hu bit; exact safeTag u (by omega) bit
          · rw [tagRun]; exact tagTapes
          · rw [tagRun]; exact tagHeads
          · intro zs accepted
            change codeSkipActionK k (counterValue w) (x.drop p) = some zs at accepted
            rw [record] at accepted
            have same : ys = zs := Option.some.inj accepted
            subst zs
            rw [tagRun, tagEq]
            change (moveInputPos tagStart.inputPos
              (if tagStart.inputSymbol.isSome then 1 else 0)).val = _
            rw [tagRead]
            have advance := (native.2 false ys tail).1
            simp only [List.head?_cons, Option.isSome_some, if_true]
            simp only [List.length_cons] at size
            omega
        | true =>
          let uStart : Cfg m Bool S x := tagEnd.mapState (fun _ => ue)
          have uState : uStart.state = some ue := by simp [uStart, Cfg.mapState, tagExit]
          have advance := native.2 true ys tail
          have uPos : uStart.inputPos.val = p + pre.length + 2 := by
            change tagEnd.inputPos.val = _
            rw [tagEq, tagRead]
            exact advance.1
          have uTail : x.drop (uStart.inputPos.val - 1) = ys := by
            rw [uPos]
            simpa only [Nat.add_sub_cancel] using advance.2
          obtain ⟨ut, unaryBudget, uExit, uOutput, uCuts, uTapes, uHeads, uConsumed⟩ :=
            unary x w uStart uState (by omega)
              (by change tagEnd.workTapes bound = _; rw [tagTapes]; exact word)
              (by change tagEnd.workTapePos bound = _; rw [tagHeads]; exact origin)
              (by intro j hj; change tagEnd.workTapes j = _ ∧ tagEnd.workTapePos j = _
                  rw [tagTapes, tagHeads]; exact blank j hj)
          let uEnd := U.runFrom uStart ut
          let verdict := (codeSkipFin (counterValue w + 1) ys).isSome
          have uFinal : uEnd.state = some (ux verdict) := by simpa only [uTail] using uExit
          have third := phaseHostTM_run family entry red (some true) uStart uEnd ut rfl
            (ux verdict) uFinal (exit verdict) (by
              have different : ux false ≠ ux true := fun eq => Bool.false_ne_true (injective eq)
              cases verdict <;> simp [red, canonRecordNext, exit, different]) (by
              intro u hu s hs
              have noTrue : s ≠ ux true := fun eq => uCuts u hu true (hs.trans (congrArg some eq))
              have noFalse : s ≠ ux false := fun eq =>
                uCuts u hu false (hs.trans (congrArg some eq))
              simp [red, canonRecordNext, noTrue, noFalse])
          have uJoin : tagEnd.mapState (fun _ => tagNext) =
              uStart.mapState (Sigma.mk (some true)) := by
            simp [uStart, tagNext, Cfg.mapState, Option.map_map, Function.comp_def]
          have whole : R.runFrom d (ft + 3 + (ut + 1)) =
              uEnd.mapState (fun _ => exit verdict) := by
            rw [MultiTapeTM.runFrom_add d (ft + 3) (ut + 1), tagDispatch, uJoin, third.2]
          have semantics : (codeSkipActionK k (counterValue w) (x.drop p)).isSome = verdict := by
            rw [record]
            rfl
          refine ⟨ft + 3 + (ut + 1), by nlinarith, ?_, ?_, ?_, ?_, ?_, ?_⟩
          · rw [whole]
            change Option.map (fun _ => exit verdict) uEnd.state = _
            rw [uFinal]
            change some (exit verdict) =
              some (exit (codeSkipActionK k (counterValue w) (x.drop p)).isSome)
            rw [semantics]
          · rw [whole]
            exact uOutput.trans tagOutput
          · intro u hu b
            by_cases early : u ≤ ft + 1
            · exact safeTag u early b
            · by_cases onTag : u = ft + 2
              · rw [onTag, tagRun]
                simp [Cfg.mapState, tagExit, exit]
              · have index : u = ft + 3 + (u - (ft + 3)) := by omega
                rw [index, MultiTapeTM.runFrom_add d (ft + 3) (u - (ft + 3)), tagDispatch,
                  uJoin, third.1 _ (by omega)]
                intro eq
                obtain ⟨s, _, tagged⟩ := Option.map_eq_some_iff.mp eq
                have impossible := congrArg Sigma.fst tagged
                cases impossible
          · rw [whole]
            exact uTapes.trans tagTapes
          · rw [whole]
            exact uHeads.trans tagHeads
          · intro zs accepted
            rw [whole]
            apply uConsumed zs
            rw [uTail]
            change codeSkipActionK k (counterValue w) (x.drop p) = some zs at accepted
            rw [record] at accepted
            exact accepted

/-- Starting at the current native head, accept a suffix of true cells and reject its
first false cell. The catalog's whole-input scans do not supply this local suffix test. -/
private def canonSuffixTM (m : ℕ) : MultiTapeTM m Bool (Option Bool) where
  q₀ := none
  tr := fun q inp _ => match q with
    | some bit => inputMoveAction 0 (some bit)
    | none => match inp with
      | some true => inputMoveAction 1 none
      | some false => inputMoveAction 0 (some false)
      | none => inputMoveAction 0 (some true)

/-- The native suffix test decides `List.all id`, silently and without changing any work
tape or work head. It reaches its first Boolean exit in at most the remaining length plus one.

**Proof sketch.** Induct on the remaining suffix length. Blank accepts and false rejects
in one step. A true cell advances by the public input-only action law, after which the
induction hypothesis applies to the tail. The inherited native-suffix lemma supplies both
the lookup and the new suffix. -/
private lemma canonSuffix_run {m : ℕ} {x : List Bool} (d : Cfg m Bool (Option Bool) x)
    (state : d.state = some none) (positive : 1 ≤ d.inputPos.val) :
    ∃ t ≤ (x.drop (d.inputPos.val - 1)).length + 1,
      ((canonSuffixTM m).runFrom d t).state =
        some (some ((x.drop (d.inputPos.val - 1)).all id)) ∧
      ((canonSuffixTM m).runFrom d t).output = d.output ∧
      ((canonSuffixTM m).runFrom d t).workTapes = d.workTapes ∧
      ((canonSuffixTM m).runFrom d t).workTapePos = d.workTapePos ∧
      ∀ u < t, ∀ bit, ((canonSuffixTM m).runFrom d u).state ≠ some (some bit) := by
  generalize hn : (x.drop (d.inputPos.val - 1)).length = n
  induction n using Nat.strong_induction_on generalizing d with
  | h n ih =>
    let p := d.inputPos.val - 1
    have pos : d.inputPos.val = p + 1 := by dsimp [p]; omega
    have range : p ≤ x.length := by have := d.inputPos.isLt; omega
    obtain ⟨read, advance⟩ := canonNativeSuffix d p pos range
    have stop (bit : Bool) (v : Option Bool)
        (hv : d.inputSymbol = v)
        (htr : (canonSuffixTM m).tr none v d.workTapeSymbols =
          inputMoveAction 0 (some bit))
        (value : (x.drop p).all id = bit) :
        ∃ t ≤ n + 1,
          ((canonSuffixTM m).runFrom d t).state = some (some ((x.drop p).all id)) ∧
          ((canonSuffixTM m).runFrom d t).output = d.output ∧
          ((canonSuffixTM m).runFrom d t).workTapes = d.workTapes ∧
          ((canonSuffixTM m).runFrom d t).workTapePos = d.workTapePos ∧
          ∀ u < t, ∀ b, ((canonSuffixTM m).runFrom d u).state ≠ some (some b) := by
      have step : (canonSuffixTM m).runFrom d 1 =
          { d with state := some (some bit), inputPos := moveInputPos d.inputPos 0 } :=
        step_of_inputMoveAction (canonSuffixTM m) d 0 state (by rw [hv]; exact htr)
      refine ⟨1, by omega, ?_, ?_, ?_, ?_, ?_⟩
      · rw [step, value]
      · rw [step]
      · rw [step]
      · rw [step]
      · intro u hu b
        have zero : u = 0 := by omega
        subst u
        simp [state]
    cases tail : x.drop p with
    | nil =>
      rw [← tail]
      apply stop true none (by rw [read, tail]; rfl) rfl
      simp [tail]
    | cons bit ys =>
      rw [← tail]
      cases bit with
      | false =>
        apply stop false (some false) (by rw [read, tail]; rfl) rfl
        simp [tail]
      | true =>
        let e : Cfg m Bool (Option Bool) x :=
          { d with state := some none, inputPos := moveInputPos d.inputPos 1 }
        have step : (canonSuffixTM m).runFrom d 1 = e :=
          step_of_inputMoveAction _ _ _ state (by simp [canonSuffixTM, read, tail])
        obtain ⟨moved, rest⟩ := advance true ys tail
        have newPos : e.inputPos.val = p + 2 := moved
        have newTail : x.drop (e.inputPos.val - 1) = ys := by
          rw [newPos]
          simpa using rest
        have smaller : ys.length < n := by
          change (x.drop p).length = n at hn
          rw [tail] at hn
          simp only [List.length_cons] at hn
          omega
        obtain ⟨t, budget, done, silent, tapes, heads, cuts⟩ :=
          ih ys.length smaller e rfl (by omega) (by rw [newTail])
        refine ⟨1 + t, by omega, ?_, ?_, ?_, ?_, ?_⟩
        · rw [MultiTapeTM.runFrom_add, step, done, newTail]
          simp [tail]
        · rw [MultiTapeTM.runFrom_add, step]; exact silent
        · rw [MultiTapeTM.runFrom_add, step]; exact tapes
        · rw [MultiTapeTM.runFrom_add, step]; exact heads
        · intro u hu bit
          cases u with
          | zero => simp [state]
          | succ u =>
            rw [show u + 1 = 1 + u by omega, MultiTapeTM.runFrom_add, step]
            exact cuts u (by omega) bit

/-- A live Boolean control emits its bit and halts in one step. No catalog row supplies
this final emitting action; all surrounding dispatches use the public phase host. -/
private def canonHaltTM (k : ℕ) : MultiTapeTM k Bool Bool where
  q₀ := false
  tr := fun bit _ _ => ⟨0, fun _ => (none, 0), some bit, none⟩

/-- The emitting leaf appends exactly its live control bit and halts. -/
private lemma canonHalt_run {k : ℕ} {x : List Bool} (d : Cfg k Bool Bool x)
    (bit : Bool) (hs : d.state = some bit) :
    ((canonHaltTM k).runFrom d 1).state = none ∧
      ((canonHaltTM k).runFrom d 1).output = d.output ++ [bit] := by
  simp [MultiTapeTM.runFrom_succ_eq_step, MultiTapeTM.step, hs,
    canonHaltTM, Action.apply]

/-- A three-port silent computation becomes a one-bit halting computation. The absent
port and the false port reject; the true port accepts. One public phase dispatch reaches
one emitting halt, so the cost is exactly two additional steps.

**Proof sketch.** The supplied strict cuts disable all redirects during the source run.
Apply the public phase contract at its final port, then the emitting leaf. -/
private lemma canonEmitVerdict {k : ℕ} {S : Type} [Fintype S] [DecidableEq S]
    (M : MultiTapeTM k Bool S) (entry : S) (exit : Option Bool → S)
    (injective : Function.Injective exit) :
    ∃ D : FinTM Bool, ∀ (x : List Bool) (t : ℕ) (v : Option Bool),
      let d := Cfg.ofWords (input := x) entry (fun _ => [])
      (M.runFrom d t).state = some (exit v) → (M.runFrom d t).output = [] →
      (∀ u < t, ∀ q, (M.runFrom d u).state ≠ some (exit q)) →
      D.ComputesInTime x [decide (v = some true)] (t + 2) := by
  classical
  let Ph : Bool → Type
    | false => S
    | true => Bool
  let family (b : Bool) : MultiTapeTM k Bool (Ph b) := match b with
    | false => M
    | true => canonHaltTM k
  letI : ∀ b, Fintype (Ph b) := fun b => by cases b <;> exact inferInstance
  letI : ∀ b, DecidableEq (Ph b) := fun b => by cases b <;> exact inferInstance
  let start : Sigma Ph := ⟨false, entry⟩
  let red (b : Bool) : Ph b → Option (Sigma Ph) := match b with
    | true => fun _ => none
    | false => fun q =>
      if q = exit (some true) then some ⟨true, true⟩
      else if q = exit none ∨ q = exit (some false) then some ⟨true, false⟩ else none
  let N := phaseHostTM family start red
  let D : FinTM Bool := { k := k, State := Sigma Ph, tm := N }
  refine ⟨D, ?_⟩
  intro x t v d state silent cuts
  let e := M.runFrom d t
  let bit := decide (v = some true)
  have dispatch := phaseHostTM_run family start red false d e t rfl (exit v) state
    ⟨true, bit⟩ (by cases v with
      | none => simp [red, bit, injective.eq_iff]
      | some b => cases b <;> simp [red, bit, injective.eq_iff]) (by
        intro u hu q hq
        have avoids (w : Option Bool) : q ≠ exit w :=
          fun h => cuts u hu w (hq.trans (congrArg some h))
        simp [red, avoids])
  let z : Cfg k Bool Bool x := e.mapState (fun _ => bit)
  have live : z.state = some bit := by simp [z, Cfg.mapState, state, e]
  have joined : e.mapState (fun _ => (⟨true, bit⟩ : Sigma Ph)) =
      z.mapState (Sigma.mk true) := by
    simp [z, Cfg.mapState, Option.map_map, Function.comp_def]
  have leaf : N.runFrom (z.mapState (Sigma.mk true)) 1 =
      ((canonHaltTM k).runFrom z 1).mapState (Sigma.mk true) :=
    phaseHostTM_run_le family start red true z 1 (fun _ _ _ _ => rfl) 1 le_rfl
  have halted := canonHalt_run z bit live
  apply (FinTM.computesInTime_iff D _ _ _).mpr
  rw [initCfg_ofWords, show D.tm.q₀ = start from phaseHostTM_q₀ family start red]
  change (N.runFrom (d.mapState (Sigma.mk false)) (t + 2)).state = none ∧
    (N.runFrom (d.mapState (Sigma.mk false)) (t + 2)).output = [bit]
  rw [show t + 2 = (t + 1) + 1 by omega, MultiTapeTM.runFrom_add,
    dispatch.2, joined, leaf]
  constructor
  · simp only [Cfg.mapState, halted.1, Option.map_none]
  · have blank : z.output = [] := silent
    simpa only [Cfg.mapState, blank, List.nil_append] using halted.2

/-- A Boolean-exit computation becomes a first-return-or-escape round. A fresh anchor
enters the source in one phase dispatch; its successful exit returns to that anchor and
its failed exit reaches a separate port in one more dispatch. All data fields are those
of the source endpoint, and the exact additional cost is two steps.

**Proof sketch.** Apply the public phase-host contract once at time zero in the fresh
phase, and once at the source's first verdict. During the intervening source run, the
phase tag excludes both fresh ports. Liveness follows from the source's live endpoint.
The source table is reused in the two fresh phases, where this contract executes no
source transition. This generic adapter is a promotion candidate. -/
private lemma canonReturnAdapter {m : ℕ} {S : Type} [Fintype S] [DecidableEq S]
    (M : MultiTapeTM m Bool S) (entry : S) (exit : Bool → S)
    (distinct : Function.Injective exit) :
    ∃ (H : Type) (_ : Fintype H) (_ : DecidableEq H) (N : MultiTapeTM m Bool H)
      (anchor escape : H), escape ≠ anchor ∧
      ∀ (x : List Bool) (d : Cfg m Bool S x), d.state = some entry →
        ∀ (t : ℕ) (v : Bool), (M.runFrom d t).state = some (exit v) →
          (∀ u < t, ∀ b, (M.runFrom d u).state ≠ some (exit b)) →
          0 < t + 2 ∧
          N.runFrom (d.mapState (fun _ => anchor)) (t + 2) =
            (M.runFrom d t).mapState (fun _ => if v then anchor else escape) ∧
          ∀ u, 0 < u → u < t + 2 →
            ∃ q, (N.runFrom (d.mapState (fun _ => anchor)) u).state = some q ∧
              q ≠ anchor ∧ q ≠ escape := by
  classical
  let P : Option Bool → Type := fun _ => S
  let phases (_ : Option Bool) : MultiTapeTM m Bool S := M
  let port (b : Bool) : Sigma P := if b then ⟨some true, entry⟩ else ⟨none, entry⟩
  let initial : Sigma P := ⟨some false, entry⟩
  let redirect (b : Option Bool) : S → Option (Sigma P) := match b with
    | some false => fun q => if q = exit true then some (port true)
        else if q = exit false then some (port false) else none
    | some true => fun _ => some initial
    | none => fun _ => none
  let host := phaseHostTM phases (port true) redirect
  refine ⟨Sigma P, inferInstance, inferInstance, host, port true, port false, ?_, ?_⟩
  · intro h
    have impossible := congrArg Sigma.fst h
    cases impossible
  · intro x d hd t v ht hcut
    have launch := phaseHostTM_run phases (port true) redirect (some true) d d 0
      MultiTapeTM.runFrom_zero entry hd initial rfl (by intro u hu; omega)
    have source := phaseHostTM_run phases (port true) redirect (some false) d (M.runFrom d t) t
      rfl (exit v) ht (port v) (by cases v <;> simp [redirect, distinct.eq_iff]) (by
        intro u hu q hq
        have avoid (b : Bool) : q ≠ exit b :=
          fun h => hcut u hu b (hq.trans (congrArg some h))
        simp only [redirect, if_neg (avoid true), if_neg (avoid false)])
    have begin : d.mapState (Sigma.mk (some true)) = d.mapState (fun _ => port true) := by
      apply Cfg.ext
      · simp only [Cfg.mapState_state, hd, Option.map_some, port, if_true]
      · simp only [Cfg.mapState_inputPos]
      · funext j z; simp only [Cfg.mapState_workTapes]
      · funext j; simp only [Cfg.mapState_workTapePos]
      · simp only [Cfg.mapState_output]
    have enter : d.mapState (fun _ => initial) = d.mapState (Sigma.mk (some false)) := by
      apply Cfg.ext
      · simp only [Cfg.mapState_state, hd, Option.map_some, initial]
      · simp only [Cfg.mapState_inputPos]
      · funext j z; simp only [Cfg.mapState_workTapes]
      · funext j; simp only [Cfg.mapState_workTapePos]
      · simp only [Cfg.mapState_output]
    rw [begin, enter] at launch
    have middleRun (u : ℕ) (hu : u ≤ t) :
        host.runFrom (d.mapState (fun _ => port true)) (1 + u) =
          (M.runFrom d u).mapState (Sigma.mk (some false)) := by
      rw [MultiTapeTM.runFrom_add, launch.2, source.1 u hu]
    refine ⟨by omega, ?_, ?_⟩
    · rw [show t + 2 = 1 + (t + 1) by omega, MultiTapeTM.runFrom_add,
        launch.2, source.2]
      cases v <;> rfl
    · intro u positive before
      have offset : u = 1 + (u - 1) := by omega
      rw [offset, middleRun (u - 1) (by omega), Cfg.mapState_state]
      have live := M.runFrom_state_ne_none_of_le d t (by rw [ht]; exact Option.some_ne_none _)
        (u - 1) (by omega)
      obtain ⟨q, hq⟩ := Option.ne_none_iff_exists'.mp live
      refine ⟨⟨some false, q⟩, by rw [hq]; rfl, ?_, ?_⟩
      all_goals
        intro h
        have impossible := congrArg Sigma.fst h
        cases impossible

/-- The record validator, wrapped as a positive round with one fresh returning anchor.
It restores the whole work bank, preserves output, and retains C2's accepted suffix.
Its linear coefficient is C2's coefficient plus two, for the two phase dispatches.

**Proof sketch.** Instantiate the generic return adapter with C2. Relabel an arbitrary
anchor configuration to C2's entry, invoke C2's published private contract, and relabel
its endpoint back to the selected fresh port. The adapter supplies the entire interior
cut, including times at which C2 revisits its own entry. -/
private lemma exists_canonRecordRound (k : ℕ) :
    ∃ (m : ℕ) (H : Type) (_ : Fintype H) (_ : DecidableEq H) (N : MultiTapeTM m Bool H)
      (anchor escape : H) (bound : Fin m) (a : ℕ), escape ≠ anchor ∧
      ∀ (x w : List Bool) (d : Cfg m Bool H x), d.state = some anchor →
        1 ≤ d.inputPos.val →
        d.workTapes bound = FinTM.bufferTape w → d.workTapePos bound = 0 →
        (∀ j, j ≠ bound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0) →
        ∃ t ≤ a * (x.length + w.length + 1), 0 < t ∧
          (N.runFrom d t).state = some
            (if (codeSkipActionK k (counterValue w) (x.drop (d.inputPos.val - 1))).isSome
              then anchor else escape) ∧
          (N.runFrom d t).output = d.output ∧
          (∀ u, 0 < u → u < t →
            ∃ q, (N.runFrom d u).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
          (N.runFrom d t).workTapes = d.workTapes ∧
          (N.runFrom d t).workTapePos = d.workTapePos ∧
          ∀ ys, codeSkipActionK k (counterValue w) (x.drop (d.inputPos.val - 1)) = some ys →
            (N.runFrom d t).inputPos.val = x.length + 1 - ys.length := by
  obtain ⟨m, S, finiteS, eqS, R, entry, exit, bound, a, separate, record⟩ :=
    exists_canonRecordTM k
  letI : Fintype S := finiteS
  letI : DecidableEq S := eqS
  obtain ⟨H, finiteH, eqH, N, anchor, escape, different, adapt⟩ :=
    canonReturnAdapter R entry exit separate
  refine ⟨m, H, finiteH, eqH, N, anchor, escape, bound, a + 2, different, ?_⟩
  intro x w d state positive word home blank
  let c := d.mapState (fun _ => entry)
  have live : c.state = some entry := by
    rw [Cfg.mapState_state, state, Option.map_some]
  obtain ⟨t, cost, verdict, output, cut, tapes, heads, suffix⟩ := record x w c live
    (by simpa only [c, Cfg.mapState_inputPos] using positive)
    (by funext z; simpa only [c, Cfg.mapState_workTapes] using congrFun word z)
    (by simpa only [c, Cfg.mapState_workTapePos] using home)
    (fun j hj => by
      refine ⟨?_, by simpa only [c, Cfg.mapState_workTapePos] using (blank j hj).2⟩
      funext z
      simpa only [c, Cfg.mapState_workTapes] using congrFun (blank j hj).1 z)
  obtain ⟨elapsed, run, interior⟩ := adapt x c live t _ verdict cut
  have restored : c.mapState (fun _ => anchor) = d := by
    apply Cfg.ext
    · simp only [c, Cfg.mapState_state, state, Option.map_some]
    · simp only [c, Cfg.mapState_inputPos]
    · funext j z; simp only [c, Cfg.mapState_workTapes]
    · funext j; simp only [c, Cfg.mapState_workTapePos]
    · simp only [c, Cfg.mapState_output]
  rw [restored] at run interior
  refine ⟨t + 2, by nlinarith, elapsed, ?_, ?_, interior, ?_, ?_, ?_⟩
  · rw [run, Cfg.mapState_state, verdict, Option.map_some, Cfg.mapState_inputPos]
  · rw [run, Cfg.mapState_output, output, Cfg.mapState_output]
  · rw [run]
    funext j z
    simp only [Cfg.mapState_workTapes, tapes, c]
  · rw [run]
    funext j
    simp only [Cfg.mapState_workTapePos, heads, c]
  · intro ys hy
    rw [run, Cfg.mapState_inputPos]
    exact suffix ys (by simpa only [c, Cfg.mapState_inputPos] using hy)

/-- Appending one skipper call is the right-hand successor form of the inherited
repetition-addition law. Both repetition cases are read through the public API. -/
private lemma canonRepeat_last (r : List Bool → Option (List Bool)) (n : ℕ)
    (xs : List Bool) :
    codeSkipRepeat r (n + 1) xs = (codeSkipRepeat r n xs).bind r := by
  rw [canonSkipRepeat_add r n 1]
  congr 1
  funext ys
  rw [codeSkipRepeat_succ]
  cases r ys with
  | none => rw [Option.bind_none]
  | some zs => rw [Option.bind_some, codeSkipRepeat_zero]

/-- The semantic orbit of a returning skipper either completes all requested calls or
stops at its first failure. Every attempted call starts with the supplied invariant and
at the returning anchor. This is a parser induction over the public round orbit, not a
second physical loop.

**Proof sketch.** Append one call using `canonRepeat_last`. An earlier failed prefix
remains failed. Otherwise apply the single-round specification at the last successful
prefix; its two verdicts either extend that prefix or establish the first failure. -/
private lemma canonRepeat_orbit {m : ℕ} {S : Type} {x : List Bool}
    (M : MultiTapeTM m Bool S) (anchor escape : S) (τ : Cfg m Bool S x → ℕ)
    (valid : Cfg m Bool S x → Prop) (tail : Cfg m Bool S x → List Bool)
    (r : List Bool → Option (List Bool))
    (step : ∀ c, valid c → c.state = some anchor →
      (M.runFrom c (τ c)).state = some (if (r (tail c)).isSome then anchor else escape) ∧
      ∀ ys, r (tail c) = some ys → valid (M.runFrom c (τ c)) ∧
        tail (M.runFrom c (τ c)) = ys)
    (c : Cfg m Bool S x) (hc : valid c) (ha : c.state = some anchor) (n : ℕ) :
    ∃ j ≤ n,
      (∀ i < j, valid (roundOrbit M τ c i) ∧ (roundOrbit M τ c i).state = some anchor) ∧
      ((j = n ∧ valid (roundOrbit M τ c j) ∧
          (roundOrbit M τ c j).state = some anchor ∧
          codeSkipRepeat r n (tail c) = some (tail (roundOrbit M τ c j))) ∨
        (0 < j ∧ (roundOrbit M τ c j).state = some escape ∧
          codeSkipRepeat r n (tail c) = none)) := by
  induction n with
  | zero =>
    refine ⟨0, le_rfl, by intro i hi; omega, Or.inl ?_⟩
    simp only [roundOrbit_zero, codeSkipRepeat_zero]
    exact ⟨True.intro, hc, ha, True.intro⟩
  | succ n ih =>
    obtain ⟨j, bound, earlier, success | failure⟩ := ih
    · obtain ⟨same, good, state, parsed⟩ := success
      subst j
      obtain ⟨nextState, nextTail⟩ := step _ good state
      have starts : ∀ i < n + 1,
          valid (roundOrbit M τ c i) ∧ (roundOrbit M τ c i).state = some anchor := by
        intro i hi
        by_cases lt : i < n
        · exact earlier i lt
        · have eq : i = n := by omega
          subst i
          exact ⟨good, state⟩
      refine ⟨n + 1, le_rfl, starts, ?_⟩
      rw [canonRepeat_last, parsed, Option.bind_some]
      cases result : r (tail (roundOrbit M τ c n)) with
      | none =>
        apply Or.inr
        refine ⟨by omega, ?_, rfl⟩
        rw [roundOrbit_succ]
        simpa only [result, Option.isSome_none, Bool.false_eq_true, if_false] using nextState
      | some ys =>
        obtain ⟨preserved, suffix⟩ := nextTail ys result
        apply Or.inl
        refine ⟨rfl, ?_, ?_, ?_⟩
        · rw [roundOrbit_succ]; exact preserved
        · rw [roundOrbit_succ]
          simpa only [result, Option.isSome_some, if_true] using nextState
        · rw [roundOrbit_succ, suffix]
    · refine ⟨j, by omega, earlier, Or.inr ⟨failure.1, failure.2.1, ?_⟩⟩
      rw [canonRepeat_last, failure.2.2, Option.bind_none]

/-- A public counter loop whose positive rounds decide a skipper decides its repetition,
failing at the first unsuccessful round. The exact time counts only attempted rounds;
the displayed upper bound uses the binary counter value and its width. The residual
counter is the public host's all-true word on completion or its decremented word on escape.

**Proof sketch.** The semantic orbit lemma supplies either all successful rounds or the
first failing round. Apply the public done or escape contract once. Bound the round sum
by the per-round budget and cite the corresponding public amortized counter bound.
No counter transition, host trace, or decrement arithmetic is repeated. -/
private lemma canonCounterRepeat {m : ℕ} {S : Type} [DecidableEq S] {x : List Bool}
    (M : MultiTapeTM m Bool S) (anchor escape : S) (different : escape ≠ anchor)
    (τ : Cfg m Bool S x → ℕ) (valid : Cfg m Bool S x → Prop)
    (tail : Cfg m Bool S x → List Bool) (r : List Bool → Option (List Bool)) (B : ℕ)
    (spec : ∀ d, valid d → d.state = some anchor →
      0 < τ d ∧ τ d ≤ B ∧
      (∀ u, 0 < u → u < τ d →
        ∃ q, (M.runFrom d u).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
      (M.runFrom d (τ d)).state = some (if (r (tail d)).isSome then anchor else escape) ∧
      ∀ ys, r (tail d) = some ys → valid (M.runFrom d (τ d)) ∧
        tail (M.runFrom d (τ d)) = ys)
    (c : Cfg m Bool S x) (hc : valid c) (ha : c.state = some anchor)
    (w : List Bool) (ct : ℤ → Option Bool) (cp : ℤ)
    (word : ∀ z : ℤ, -1 ≤ z → z ≤ (w.length : ℤ) →
      ct (cp + z) = FinTM.bufferTape w z)
    (n : ℕ) (value : Nat.ofDigits 2 (w.map Bool.toNat) = n) :
    ∃ T ≤ n * (B + 4) + 2 * w.length + 2, ∃ j ≤ n,
      T = (∑ i ∈ Finset.range j, τ (roundOrbit M τ c i)) +
        counterOverhead w (j + if (codeSkipRepeat r n (tail c)).isSome then 1 else 0) ∧
      (counterLoopTM M anchor (some escape)).runFrom
          (counterLoopCfg (some (.dec .run)) c ct cp) T =
        counterLoopCfg (some (if (codeSkipRepeat r n (tail c)).isSome then .done else .escape))
          (roundOrbit M τ c j)
          (fun z => if cp ≤ z ∧ z < cp + (w.length : ℤ) then
            if (codeSkipRepeat r n (tail c)).isSome then some true
            else FinTM.bufferTape (counterWord w j) (z - cp) else ct z) cp ∧
      (∀ u < T,
        ((counterLoopTM M anchor (some escape)).runFrom
          (counterLoopCfg (some (.dec .run)) c ct cp) u).state ≠ some .done ∧
        ((counterLoopTM M anchor (some escape)).runFrom
          (counterLoopCfg (some (.dec .run)) c ct cp) u).state ≠ some .escape) ∧
      (∀ ys, codeSkipRepeat r n (tail c) = some ys →
        j = n ∧ valid (roundOrbit M τ c j) ∧ tail (roundOrbit M τ c j) = ys) ∧
      (codeSkipRepeat r n (tail c) = none →
        0 < j ∧ (roundOrbit M τ c j).state = some escape) := by
  obtain ⟨j, hj, starts, finished | failed⟩ := canonRepeat_orbit M anchor escape τ valid tail r
    (fun d hd hs => (spec d hd hs).2.2.2) c hc ha n
  · obtain ⟨same, good, state, parsed⟩ := finished
    subst j
    let T := (∑ i ∈ Finset.range n, τ (roundOrbit M τ c i)) + counterOverhead w (n + 1)
    have result := counterLoopTM_run_done M anchor (some escape) τ c w ct cp word n value
      (by
        intro i hi
        obtain ⟨hd, hs⟩ := starts i hi
        obtain ⟨positive, _, interior, _, _⟩ := spec _ hd hs
        refine ⟨hs, positive, ?_, ?_⟩
        · intro u hu ht
          obtain ⟨q, hq, hqa, hqe⟩ := interior u hu ht
          exact ⟨q, hq, hqa, fun eq => hqe (Option.some.inj eq).symm⟩
        · by_cases earlier : i + 1 < n
          · exact (starts (i + 1) earlier).2
          · have last : i + 1 = n := by omega
            simpa only [last] using state) T rfl
    have budget := counterLoop_time_le M τ c w n value B
      (fun i hi => (spec _ (starts i hi).1 (starts i hi).2).2.1)
    refine ⟨T, by dsimp only [T]; nlinarith [budget], n, le_rfl, ?_, ?_, result.2.1, ?_, ?_⟩
    · simp only [parsed, Option.isSome_some, if_true]
      rfl
    · simpa only [parsed, Option.isSome_some, if_true] using result.1
    · intro ys hy
      exact ⟨rfl, good, Option.some.inj (parsed.symm.trans hy)⟩
    · intro impossible
      rw [parsed] at impossible
      cases impossible
  · obtain ⟨positive, state, parsed⟩ := failed
    have rounds : j - 1 + 1 = j := by omega
    let T := (∑ i ∈ Finset.range j, τ (roundOrbit M τ c i)) + counterOverhead w j
    have result := counterLoopTM_run_escape M anchor escape different τ c w ct cp word
      (j - 1) (by omega) (by
        intro i hi
        obtain ⟨hd, hs⟩ := starts i (by omega)
        obtain ⟨pos, _, interior, _, _⟩ := spec _ hd hs
        exact ⟨hs, pos, interior⟩) (by simpa only [rounds] using state)
      T (by rw [rounds])
    rw [rounds] at result
    have sumBound : (∑ i ∈ Finset.range j, τ (roundOrbit M τ c i)) ≤ j * B := by
      calc
        _ ≤ ∑ _i ∈ Finset.range j, B := Finset.sum_le_sum (fun i hi =>
          (spec _ (starts i (Finset.mem_range.mp hi)).1
            (starts i (Finset.mem_range.mp hi)).2).2.1)
        _ = j * B := by simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_id]
    have counterBound := counterOverhead_le_of_le w j (by omega)
    have cost : T ≤ n * (B + 4) + 2 * w.length + 2 := by
      dsimp only [T]
      nlinarith [Nat.mul_le_mul_right B hj]
    refine ⟨T, cost, j, hj, ?_, ?_, result.2.1, ?_, fun _ => ⟨positive, state⟩⟩
    · simp only [parsed, Option.isSome_none, Bool.false_eq_true, if_false, Nat.add_zero]
      rfl
    · simpa only [parsed, Option.isSome_none, Bool.false_eq_true, if_false] using result.1
    · intro ys impossible
      rw [parsed] at impossible
      cases impossible

/-- A successful record skip returns a suffix of its input. -/
private lemma canonStageSkip_suffix (k n : ℕ) (xs ys : List Bool)
    (h : codeSkipActionK k n xs = some ys) : ys.IsSuffix xs := by
  have he := codeEraseActionK k n xs
  rw [h] at he
  cases hr : codeReadActionK k n xs with
  | none => rw [hr, Option.map_none] at he; cases he
  | some p =>
    rw [hr, Option.map_some] at he
    obtain ⟨a', rest⟩ := p
    have hs := codeReadActionK_sound xs a' rest hr
    have : rest = ys := by simpa using he
    subst this
    exact ⟨actionBitsK a', hs.symm⟩

/-- Dropping to a suffix's start recovers it. -/
private lemma canonStageSuffix_drop (x ys : List Bool) (h : ys.IsSuffix x) :
    x.drop (x.length - ys.length) = ys := by
  obtain ⟨pre, rfl⟩ := h
  rw [List.length_append, Nat.add_sub_cancel, List.drop_left]

/-- **The record round's loop specification.** The adapter-wrapped record
validator, read as one round of the public counter loop: from any configuration carrying C2's
bank (the binary bound on the bound tape, every other work tape blank, all work heads at the
origin, empty output, the native head inside the input), one round costs a positive time at
most linear in `|x| + |w| + 1`, avoids both ports strictly inside, exits at the anchor exactly
when one more record skips (`codeSkipActionK` at the counter value of the bound word), and on
success preserves the bank and moves the native head to the skipped suffix. The inner
counter loop of the grammar stage iterates this round.

**Proof sketch.** The adapter-wrapped validator `exists_canonRecordRound` gives, for each such
configuration, a time with all but the suffix clause; choose it per configuration (zero off the
domain). On success the skipped word is a suffix of the input (`canonStageSkip_suffix`), so the
reported head position gives it by dropping (`canonStageSuffix_drop`). -/
private lemma canonStageRoundSpec (k : ℕ) :
    ∃ (m : ℕ) (H : Type) (_ : Fintype H) (_ : DecidableEq H) (N : MultiTapeTM m Bool H)
      (anchor escape : H) (bound : Fin m) (B : ℕ), escape ≠ anchor ∧
      ∀ (x w : List Bool), ∃ τ : Cfg m Bool H x → ℕ,
        ∀ d : Cfg m Bool H x,
          (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
            d.workTapes bound = FinTM.bufferTape w ∧ d.workTapePos bound = 0 ∧
            (∀ j, j ≠ bound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0)) →
          d.state = some anchor →
          0 < τ d ∧ τ d ≤ B * (x.length + w.length + 1) ∧
          (∀ u, 0 < u → u < τ d →
            ∃ q, (N.runFrom d u).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
          (N.runFrom d (τ d)).state = some
            (if (codeSkipActionK k (counterValue w) (x.drop (d.inputPos.val - 1))).isSome
              then anchor else escape) ∧
          (N.runFrom d (τ d)).output = [] ∧
          ∀ ys, codeSkipActionK k (counterValue w) (x.drop (d.inputPos.val - 1)) = some ys →
            (((N.runFrom d (τ d)).output = [] ∧ 1 ≤ (N.runFrom d (τ d)).inputPos.val ∧
              (N.runFrom d (τ d)).workTapes bound = FinTM.bufferTape w ∧
              (N.runFrom d (τ d)).workTapePos bound = 0 ∧
              (∀ j, j ≠ bound → (N.runFrom d (τ d)).workTapes j = FinTM.bufferTape [] ∧
                (N.runFrom d (τ d)).workTapePos j = 0)) ∧
            x.drop ((N.runFrom d (τ d)).inputPos.val - 1) = ys) := by
  classical
  obtain ⟨m, H, finiteH, eqH, N, anchor, escape, bound, a, different, record⟩ :=
    exists_canonRecordRound k
  refine ⟨m, H, finiteH, eqH, N, anchor, escape, bound, a, different, ?_⟩
  intro x w
  letI : Fintype H := finiteH
  letI : DecidableEq H := eqH
  refine ⟨fun d =>
    if h : (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
        d.workTapes bound = FinTM.bufferTape w ∧ d.workTapePos bound = 0 ∧
        (∀ j, j ≠ bound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0)) ∧
        d.state = some anchor then
      (record x w d h.2 h.1.2.1 h.1.2.2.1 h.1.2.2.2.1 h.1.2.2.2.2).choose
    else 0, ?_⟩
  intro d hv hs
  have hcond : (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
      d.workTapes bound = FinTM.bufferTape w ∧ d.workTapePos bound = 0 ∧
      (∀ j, j ≠ bound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0)) ∧
      d.state = some anchor := ⟨hv, hs⟩
  simp only [dif_pos hcond]
  obtain ⟨cost, positive, verdict, output, interior, tapes, heads, suffix⟩ :=
    (record x w d hcond.2 hcond.1.2.1 hcond.1.2.2.1 hcond.1.2.2.2.1
      hcond.1.2.2.2.2).choose_spec
  set t := (record x w d hcond.2 hcond.1.2.1 hcond.1.2.2.1 hcond.1.2.2.2.1
      hcond.1.2.2.2.2).choose with ht
  refine ⟨positive, cost, interior, verdict, output.trans hv.1, ?_⟩
  intro ys hy
  have hsfx : ys.IsSuffix (x.drop (d.inputPos.val - 1)) :=
    canonStageSkip_suffix k (counterValue w) _ ys hy
  have hsfx' : ys.IsSuffix x := hsfx.trans (List.drop_suffix _ x)
  have hylen : ys.length ≤ x.length := hsfx'.length_le
  have hpos := suffix ys hy
  constructor
  · refine ⟨?_, ?_, ?_, ?_, ?_⟩
    · rw [output, hv.1]
    · rw [hpos]
      omega
    · rw [tapes, hv.2.2.1]
    · rw [heads, hv.2.2.2.1]
    · intro j hj
      rw [tapes, heads]
      exact hv.2.2.2.2 j hj
  · rw [hpos]
    have : x.length + 1 - ys.length - 1 = x.length - ys.length := by omega
    rw [this]
    exact canonStageSuffix_drop x ys hsfx'

/-- A buffered word is blank at and beyond its length. -/
private lemma canonStageBuffer_none (w : List Bool) (q : ℤ) (h : (w.length : ℤ) ≤ q) :
    FinTM.bufferTape w q = none := by
  rw [FinTM.bufferTape_eq, if_pos (by omega : (0 : ℤ) ≤ q)]
  exact List.getElem?_eq_none (by omega)

/-- **The inner block's loop specification.** The write-then-loop seam —
`writeConstTM` writing the inner counter word for `3 ^ (k + 1)` rounds, then the record
round's counter loop — wrapped by the fresh-anchor adapter, read as one round of the outer counter
loop: from any configuration carrying C2's bank on the embedded coordinates, a counter tape
blank outside the fixed inner window with its head at the origin, and empty output, one outer
round costs a positive time at most linear in `|x| + |w| + 1` (the coefficient depending only
on `k`), avoids both fresh ports strictly inside, exits at the anchor exactly when one inner
block of records skips (`codeSkipRepeat` of the record skipper, `3 ^ (k + 1)` times), and on
success re-establishes the bank and the closed counter window and moves the native head to the
surviving suffix.

**Proof sketch.** Write the inner counter word `(3 ^ (k + 1)).bits` on the last tape
(`writeConstTM_run_ofCfg`); its value is `3 ^ (k + 1)`. Then run the record round's counter loop
(`counterLoopTM` over `canonStageRoundSpec`) through the seam. `canonRepeat_orbit` reads the loop's
orbit off the round's specification: each round either skips one record and returns to the anchor
or escapes, and the counter stops the loop after `3 ^ (k + 1)` returns, so the block succeeds
exactly when `codeSkipRepeat` does. The fresh-anchor adapter (`canonReturnAdapter`) turns the seam
into one outer round; its time, the write row's plus the rounds', is linear in `|x| + |w| + 1`. -/
private lemma canonStageInnerSpec (k : ℕ) :
    ∃ (m : ℕ) (H : Type) (_ : Fintype H) (_ : DecidableEq H) (N : MultiTapeTM (m + 1) Bool H)
      (anchor escape : H) (bound : Fin m) (B : ℕ), escape ≠ anchor ∧
      ∀ (x w : List Bool), ∃ τ : Cfg (m + 1) Bool H x → ℕ,
        ∀ d : Cfg (m + 1) Bool H x,
          (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
            d.workTapes bound.castSucc = FinTM.bufferTape w ∧
            d.workTapePos bound.castSucc = 0 ∧
            (∀ j : Fin m, j ≠ bound → d.workTapes j.castSucc = FinTM.bufferTape [] ∧
              d.workTapePos j.castSucc = 0) ∧
            (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
              d.workTapes (Fin.last m) q = none) ∧
            d.workTapePos (Fin.last m) = 0) →
          d.state = some anchor →
          0 < τ d ∧ τ d ≤ B * (x.length + w.length + 1) ∧
          (∀ u, 0 < u → u < τ d →
            ∃ q, (N.runFrom d u).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
          (N.runFrom d (τ d)).state = some
            (if (codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
                (x.drop (d.inputPos.val - 1))).isSome
              then anchor else escape) ∧
          (N.runFrom d (τ d)).output = [] ∧
          ∀ ys, codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
              (x.drop (d.inputPos.val - 1)) = some ys →
            (((N.runFrom d (τ d)).output = [] ∧ 1 ≤ (N.runFrom d (τ d)).inputPos.val ∧
              (N.runFrom d (τ d)).workTapes bound.castSucc = FinTM.bufferTape w ∧
              (N.runFrom d (τ d)).workTapePos bound.castSucc = 0 ∧
              (∀ j : Fin m, j ≠ bound →
                (N.runFrom d (τ d)).workTapes j.castSucc = FinTM.bufferTape [] ∧
                (N.runFrom d (τ d)).workTapePos j.castSucc = 0) ∧
              (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
                (N.runFrom d (τ d)).workTapes (Fin.last m) q = none) ∧
              (N.runFrom d (τ d)).workTapePos (Fin.last m) = 0) ∧
            x.drop ((N.runFrom d (τ d)).inputPos.val - 1) = ys) := by
  classical
  obtain ⟨m, H₀, finiteH₀, eqH₀, N₀, anchor₀, escape₀, bound, B₀, different₀, spec₀⟩ :=
    canonStageRoundSpec k
  letI : Fintype H₀ := finiteH₀
  letI : DecidableEq H₀ := eqH₀
  set w₀ : List Bool := (3 ^ (k + 1) : ℕ).bits with hw₀
  let W : MultiTapeTM (m + 1) Bool (WritePhase w₀.length) :=
    writeConstTM (m + 1) (Fin.last m) w₀
  let L : MultiTapeTM (m + 1) Bool (CounterLoopState H₀) :=
    counterLoopTM N₀ anchor₀ (some escape₀)
  let Rin : MultiTapeTM (m + 1) Bool (WritePhase w₀.length ⊕ CounterLoopState H₀) :=
    seamCompTM W WritePhase.done L (CounterLoopState.dec FlagPhase.run)
  let exitF : Bool → WritePhase w₀.length ⊕ CounterLoopState H₀ := fun b =>
    Sum.inr (if b then CounterLoopState.done else CounterLoopState.escape)
  have hinj : Function.Injective exitF := by
    intro a b h
    cases a <;> cases b <;> simp [exitF] at h ⊢
  obtain ⟨H, finiteH, eqH, N, anchor, escape, different, adapt⟩ :=
    canonReturnAdapter Rin (Sum.inl (WritePhase.wr 0)) exitF hinj
  have hval : Nat.ofDigits 2 (w₀.map Bool.toNat) = 3 ^ (k + 1) :=
    (counterValue_eq w₀).symm.trans (counterValue_bits (3 ^ (k + 1)))
  refine ⟨m, H, finiteH, eqH, N, anchor, escape, bound,
    3 ^ (k + 1) * (B₀ + 4) + 6 * w₀.length + 12, different, ?_⟩
  intro x w
  obtain ⟨τ₀, hτ₀⟩ := spec₀ x w
  -- the inner block's run, from the seam's entry, at the seam's own state type
  have hblock : ∀ d : Cfg (m + 1) Bool (WritePhase w₀.length ⊕ CounterLoopState H₀) x,
      (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
        d.workTapes bound.castSucc = FinTM.bufferTape w ∧
        d.workTapePos bound.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound → d.workTapes j.castSucc = FinTM.bufferTape [] ∧
          d.workTapePos j.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q → d.workTapes (Fin.last m) q = none) ∧
        d.workTapePos (Fin.last m) = 0) →
      d.state = some (Sum.inl (WritePhase.wr 0)) →
      ∃ t ≤ 3 ^ (k + 1) * (B₀ * (x.length + w.length + 1) + 4) + 4 * w₀.length + 7,
        (Rin.runFrom d t).state = some (exitF
          (codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop (d.inputPos.val - 1))).isSome) ∧
        (Rin.runFrom d t).output = [] ∧
        (∀ u < t, ∀ b, (Rin.runFrom d u).state ≠ some (exitF b)) ∧
        (∀ ys, codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop (d.inputPos.val - 1)) = some ys →
          ((Rin.runFrom d t).output = [] ∧ 1 ≤ (Rin.runFrom d t).inputPos.val ∧
            (Rin.runFrom d t).workTapes bound.castSucc = FinTM.bufferTape w ∧
            (Rin.runFrom d t).workTapePos bound.castSucc = 0 ∧
            (∀ j : Fin m, j ≠ bound →
              (Rin.runFrom d t).workTapes j.castSucc = FinTM.bufferTape [] ∧
              (Rin.runFrom d t).workTapePos j.castSucc = 0) ∧
            (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q →
              (Rin.runFrom d t).workTapes (Fin.last m) q = none) ∧
            (Rin.runFrom d t).workTapePos (Fin.last m) = 0) ∧
          x.drop ((Rin.runFrom d t).inputPos.val - 1) = ys) := by
    intro d hv hs
    obtain ⟨hout, hpos, hbank, hbhead, hblank, hctr, hctrh⟩ := hv
    have hcs_last : ∀ j : Fin m, j.castSucc ≠ Fin.last m := by
      intro j h
      have hvj := congrArg Fin.val h
      rw [Fin.coe_castSucc, Fin.val_last] at hvj
      have := j.isLt
      omega
    -- phase 1: the write row, at the write machine's own state type
    obtain ⟨hwrun, hwcut, -⟩ := writeConstTM_run_ofCfg (Fin.last m) w₀
      (d.mapState fun _ => WritePhase.wr 0)
      (by rw [Cfg.mapState_state, hs, Option.map_some])
    have hc₀d : (d.mapState fun _ => WritePhase.wr 0).mapState Sum.inl = d := by
      refine Cfg.ext ?_ ((Cfg.mapState_inputPos _ _).trans (Cfg.mapState_inputPos _ _)) ?_ ?_ ?_
      · rw [Cfg.mapState_state, Cfg.mapState_state, hs, Option.map_some, Option.map_some]
      · funext j q
        rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
      · funext j
        rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
      · rw [Cfg.mapState_output, Cfg.mapState_output]
    have hctrpos : (d.mapState fun _ =>
        (WritePhase.wr 0 : WritePhase w₀.length)).workTapePos (Fin.last m) = 0 := by
      rw [Cfg.mapState_workTapePos]
      exact hctrh
    set Ew : Cfg (m + 1) Bool (WritePhase w₀.length) x :=
      { (d.mapState fun _ => WritePhase.wr 0) with
        state := some WritePhase.done
        workTapes := fun j q =>
          if j = Fin.last m ∧ (d.mapState fun _ => WritePhase.wr 0).workTapePos j ≤ q ∧
              q < (d.mapState fun _ => WritePhase.wr 0).workTapePos j + (w₀.length : ℤ)
            then FinTM.bufferTape w₀ (q - (d.mapState fun _ => WritePhase.wr 0).workTapePos j)
          else (d.mapState fun _ => WritePhase.wr 0).workTapes j q } with hEw
    have hEwstate : Ew.state = some WritePhase.done := rfl
    have hct : ∀ z : ℤ, -1 ≤ z → z ≤ (w₀.length : ℤ) →
        Ew.workTapes (Fin.last m) (0 + z) = FinTM.bufferTape w₀ z := by
      intro z hz1 hz2
      show (if Fin.last m = Fin.last m ∧
          (d.mapState fun _ => WritePhase.wr 0).workTapePos (Fin.last m) ≤ 0 + z ∧
          0 + z < (d.mapState fun _ => WritePhase.wr 0).workTapePos (Fin.last m) +
            (w₀.length : ℤ)
        then FinTM.bufferTape w₀
          (0 + z - (d.mapState fun _ => WritePhase.wr 0).workTapePos (Fin.last m))
        else (d.mapState fun _ => WritePhase.wr 0).workTapes (Fin.last m) (0 + z)) =
        FinTM.bufferTape w₀ z
      rw [hctrpos]
      by_cases hzin : (0 : ℤ) ≤ z ∧ z < (w₀.length : ℤ)
      · rw [if_pos ⟨rfl, by omega, by omega⟩]
        congr 1
        omega
      · rw [if_neg (fun hcon => hzin ⟨by omega, by omega⟩), Cfg.mapState_workTapes,
          hctr (0 + z) (by omega), eq_comm]
        rcases lt_or_ge z 0 with h0 | h0
        · exact FinTM.bufferTape_of_neg _ h0
        · exact canonStageBuffer_none _ _ (by omega)
    have hEwtape : ∀ j : Fin m, Ew.workTapes j.castSucc = d.workTapes j.castSucc := by
      intro j
      funext q
      show (if j.castSucc = Fin.last m ∧ _ ∧ _ then _ else
        (d.mapState fun _ => WritePhase.wr 0).workTapes j.castSucc q) = _
      rw [if_neg (fun hcon => hcs_last j hcon.1), Cfg.mapState_workTapes]
    have hEwctr : ∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q →
        Ew.workTapes (Fin.last m) q = none := by
      intro q hq
      show (if Fin.last m = Fin.last m ∧
          (d.mapState fun _ => WritePhase.wr 0).workTapePos (Fin.last m) ≤ q ∧ _
        then _ else (d.mapState fun _ => WritePhase.wr 0).workTapes (Fin.last m) q) = none
      rw [hctrpos, if_neg (fun hcon => by omega), Cfg.mapState_workTapes]
      exact hctr q hq
    have hEwpos : ∀ j : Fin (m + 1), Ew.workTapePos j = d.workTapePos j := by
      intro j
      show (d.mapState fun _ =>
        (WritePhase.wr 0 : WritePhase w₀.length)).workTapePos j = d.workTapePos j
      rw [Cfg.mapState_workTapePos]
    have hEwip : Ew.inputPos = d.inputPos :=
      Cfg.mapState_inputPos (fun _ => (WritePhase.wr 0 : WritePhase w₀.length)) d
    have hEwout : Ew.output = d.output :=
      Cfg.mapState_output (fun _ => (WritePhase.wr 0 : WritePhase w₀.length)) d
    -- phase 2: the loop, through the counter host's layout
    have hJ : (Ew.mapState fun _ => CounterLoopState.dec FlagPhase.run) =
        counterLoopCfg (some (CounterLoopState.dec FlagPhase.run))
          (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x)
          (Ew.workTapes (Fin.last m)) 0 := by
      rw [counter_cfg_eq]
      refine Cfg.ext ?_ ?_ ?_ ?_ ?_
      · rw [Cfg.mapState_state]
        rfl
      · exact (Cfg.mapState_inputPos _ _).trans hEwip
      · funext j
        dsimp only
        refine Fin.lastCases ?_ (fun j' => ?_) j
        · rw [Fin.lastCases_last]
          funext q
          rw [Cfg.mapState_workTapes]
        · rw [Fin.lastCases_castSucc]
          funext q
          rw [Cfg.mapState_workTapes]
      · funext j
        dsimp only
        refine Fin.lastCases ?_ (fun j' => ?_) j
        · rw [Fin.lastCases_last, Cfg.mapState_workTapePos, hEwpos, hctrh]
        · rw [Fin.lastCases_castSucc, Cfg.mapState_workTapePos]
      · exact (Cfg.mapState_output _ _).trans hEwout
    have hbody : (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
        fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).output = [] ∧
        1 ≤ (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).inputPos.val ∧
        (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).workTapes bound =
          FinTM.bufferTape w ∧
        (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).workTapePos bound =
          0 ∧
        ∀ j, j ≠ bound →
          (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).workTapes j =
            FinTM.bufferTape [] ∧
          (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).workTapePos j =
            0 := by
      refine ⟨hout, hpos, ?_, ?_, ?_⟩
      · show Ew.workTapes bound.castSucc = FinTM.bufferTape w
        rw [hEwtape, hbank]
      · show Ew.workTapePos bound.castSucc = 0
        rw [hEwpos, hbhead]
      · intro j hj
        exact ⟨by rw [show (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).workTapes j =
            Ew.workTapes j.castSucc from rfl, hEwtape]; exact (hblank j hj).1,
          by rw [show (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x).workTapePos j =
            Ew.workTapePos j.castSucc from rfl, hEwpos]; exact (hblank j hj).2⟩
    obtain ⟨jr, hjn, chain, hdich⟩ := canonRepeat_orbit N₀ anchor₀ escape₀ τ₀
      (fun c => c.output = [] ∧ 1 ≤ c.inputPos.val ∧
        c.workTapes bound = FinTM.bufferTape w ∧ c.workTapePos bound = 0 ∧
        ∀ j, j ≠ bound → c.workTapes j = FinTM.bufferTape [] ∧ c.workTapePos j = 0)
      (fun c => x.drop (c.inputPos.val - 1))
      (codeSkipActionK k (counterValue w))
      (fun c hc ha => ⟨(hτ₀ c hc ha).2.2.2.1, fun ys hy =>
        ⟨((hτ₀ c hc ha).2.2.2.2.2 ys hy).1, ((hτ₀ c hc ha).2.2.2.2.2 ys hy).2⟩⟩)
      (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x)
      hbody rfl (3 ^ (k + 1))
    have hipb : ((⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ :
            Cfg m Bool H₀ x)).inputPos = d.inputPos := rfl
    have houtchain : ∀ i, i ≤ jr →
        (roundOrbit N₀ τ₀ (⟨some anchor₀, d.inputPos,
          fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i).output = [] := by
      intro i hi
      cases i with
      | zero =>
        rw [roundOrbit_zero]
        exact hbody.1
      | succ i =>
        obtain ⟨hvi, hsi⟩ := chain i (by omega)
        rw [roundOrbit_succ]
        exact (hτ₀ _ hvi hsi).2.2.2.2.1
    rcases hdich with ⟨hjN, hgood, hanch, hparsed⟩ | ⟨hjpos, hesc, hparsed⟩
    · -- every round returns: the loop runs to the done port
      subst hjN
      rw [hipb] at hparsed
      set TS : ℕ := (∑ i ∈ Finset.range (3 ^ (k + 1)), τ₀ (roundOrbit N₀ τ₀
        (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i)) +
        counterOverhead w₀ (3 ^ (k + 1) + 1) with hTS
      obtain ⟨hrun, hcutT, -, -⟩ := counterLoopTM_run_done N₀ anchor₀ (some escape₀) τ₀
        (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x)
        w₀ (Ew.workTapes (Fin.last m)) 0 hct (3 ^ (k + 1)) hval
        (by
          intro r hr
          obtain ⟨hvr, hsr⟩ := chain r hr
          obtain ⟨hpos', -, hint, -, -, -⟩ := hτ₀ _ hvr hsr
          refine ⟨hsr, hpos', ?_, ?_⟩
          · intro uu huu htu
            obtain ⟨q, hq, hqa, hqe⟩ := hint uu huu htu
            exact ⟨q, hq, hqa, fun eq => hqe (Option.some.inj eq).symm⟩
          · by_cases hlt : r + 1 < 3 ^ (k + 1)
            · exact (chain (r + 1) hlt).2
            · have hre : r + 1 = 3 ^ (k + 1) := by omega
              rw [hre]
              exact hanch)
        TS hTS
      have hseam : Rin.runFrom d (2 * w₀.length + 2 + 1 + TS) =
          (counterLoopCfg (some CounterLoopState.done)
            (roundOrbit N₀ τ₀ (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) (3 ^ (k + 1)))
            (fun q => if 0 ≤ q ∧ q < 0 + (w₀.length : ℤ) then some true
              else Ew.workTapes (Fin.last m) q) 0).mapState Sum.inr := by
        conv_lhs => rw [← hc₀d]
        rw [seamCompTM_runFrom_right W WritePhase.done L (CounterLoopState.dec FlagPhase.run)
          hwrun hEwstate hwcut TS, hJ, hrun]
      rw [counter_cfg_eq] at hseam
      have hsum : (∑ i ∈ Finset.range (3 ^ (k + 1)), τ₀ (roundOrbit N₀ τ₀
          (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i)) ≤
          3 ^ (k + 1) * (B₀ * (x.length + w.length + 1)) := by
        calc (∑ i ∈ Finset.range (3 ^ (k + 1)), τ₀ (roundOrbit N₀ τ₀
            (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
              fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i))
            ≤ ∑ _i ∈ Finset.range (3 ^ (k + 1)), B₀ * (x.length + w.length + 1) :=
              Finset.sum_le_sum fun r hr =>
                (hτ₀ _ (chain r (Finset.mem_range.mp hr)).1
                  (chain r (Finset.mem_range.mp hr)).2).2.1
          _ = 3 ^ (k + 1) * (B₀ * (x.length + w.length + 1)) := by
              rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_id]
      have hov : counterOverhead w₀ (3 ^ (k + 1) + 1) ≤
          4 * 3 ^ (k + 1) + 2 * w₀.length + 2 := by
        have hle := counterOverhead_le w₀
        rw [hval] at hle
        exact hle
      refine ⟨2 * w₀.length + 2 + 1 + TS, ?_, ?_, ?_, ?_, ?_⟩
      · have hprod : 3 ^ (k + 1) * (B₀ * (x.length + w.length + 1) + 4) =
            3 ^ (k + 1) * (B₀ * (x.length + w.length + 1)) + 4 * 3 ^ (k + 1) := by ring
        omega
      · rw [hseam, Cfg.mapState_state, hparsed]
        rfl
      · rw [hseam, Cfg.mapState_output]
        exact houtchain (3 ^ (k + 1)) le_rfl
      · intro u hu b
        by_cases hu1 : u ≤ 2 * w₀.length + 2
        · conv_lhs => rw [← hc₀d]
          rw [seamCompTM_runFrom_left W WritePhase.done L
            (CounterLoopState.dec FlagPhase.run) hwcut u hu1, Cfg.mapState_state]
          cases hws : ((writeConstTM (m + 1) (Fin.last m) w₀).runFrom
              (d.mapState fun _ => WritePhase.wr 0) u).state <;> simp [exitF]
        · intro hcon
          conv_lhs at hcon => rw [← hc₀d]
          rw [show u = 2 * w₀.length + 2 + 1 + (u - (2 * w₀.length + 2 + 1)) by omega,
            seamCompTM_runFrom_right W WritePhase.done L
              (CounterLoopState.dec FlagPhase.run)
              hwrun hEwstate hwcut (u - (2 * w₀.length + 2 + 1)), hJ,
            Cfg.mapState_state] at hcon
          obtain ⟨y, hy, hyz⟩ := Option.map_eq_some_iff.mp hcon
          have hcl := hcutT (u - (2 * w₀.length + 2 + 1)) (by omega)
          cases b
          · have hy' : y = CounterLoopState.escape := by simpa [exitF] using hyz
            exact hcl.2 (by rw [hy, hy'])
          · have hy' : y = CounterLoopState.done := by simpa [exitF] using hyz
            exact hcl.1 (by rw [hy, hy'])
      · intro ys hy
        have htail : x.drop ((roundOrbit N₀ τ₀
            (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
              fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x)
            (3 ^ (k + 1))).inputPos.val - 1) = ys :=
          Option.some.inj (hparsed.symm.trans hy)
        obtain ⟨horb_out, horb_pos, horb_bank, horb_bh, horb_blank⟩ := hgood
        constructor
        · refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
          · rw [hseam, Cfg.mapState_output]
            exact horb_out
          · rw [hseam, Cfg.mapState_inputPos]
            exact horb_pos
          · rw [hseam]
            funext q
            rw [Cfg.mapState_workTapes]
            dsimp only
            rw [Fin.lastCases_castSucc]
            exact congrFun horb_bank q
          · rw [hseam, Cfg.mapState_workTapePos]
            show Fin.lastCases _ _ bound.castSucc = (0 : ℤ)
            rw [Fin.lastCases_castSucc]
            exact horb_bh
          · intro j hj
            constructor
            · rw [hseam]
              funext q
              rw [Cfg.mapState_workTapes]
              dsimp only
              rw [Fin.lastCases_castSucc]
              exact congrFun (horb_blank j hj).1 q
            · rw [hseam, Cfg.mapState_workTapePos]
              show Fin.lastCases _ _ j.castSucc = (0 : ℤ)
              rw [Fin.lastCases_castSucc]
              exact (horb_blank j hj).2
          · intro q hq
            rw [hseam]
            rw [Cfg.mapState_workTapes]
            show Fin.lastCases _ _ (Fin.last m) q = none
            rw [Fin.lastCases_last]
            rw [if_neg (by omega)]
            exact hEwctr q hq
          · rw [hseam, Cfg.mapState_workTapePos]
            show Fin.lastCases _ _ (Fin.last m) = (0 : ℤ)
            rw [Fin.lastCases_last]
        · rw [hseam, Cfg.mapState_inputPos]
          exact htail
    · -- some round fails: the loop escapes early
      rw [hipb] at hparsed
      have hj1 : jr - 1 + 1 = jr := by omega
      set TF : ℕ := (∑ i ∈ Finset.range jr, τ₀ (roundOrbit N₀ τ₀
        (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i)) +
        counterOverhead w₀ jr with hTF
      obtain ⟨hrun, hcutT, -, -⟩ := counterLoopTM_run_escape N₀ anchor₀ escape₀ different₀
        τ₀
        (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x)
        w₀ (Ew.workTapes (Fin.last m)) 0 hct (jr - 1)
        (by rw [hval]; omega)
        (by
          intro r hr
          obtain ⟨hvr, hsr⟩ := chain r (by omega)
          obtain ⟨hpos', -, hint, -, -, -⟩ := hτ₀ _ hvr hsr
          exact ⟨hsr, hpos', hint⟩)
        (by rw [hj1]; exact hesc)
        TF (by rw [hTF, hj1])
      rw [hj1] at hrun
      have hseam : Rin.runFrom d (2 * w₀.length + 2 + 1 + TF) =
          (counterLoopCfg (some CounterLoopState.escape)
            (roundOrbit N₀ τ₀ (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
          fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) jr)
            (fun q => if 0 ≤ q ∧ q < 0 + (w₀.length : ℤ)
              then FinTM.bufferTape (counterWord w₀ jr) (q - 0)
              else Ew.workTapes (Fin.last m) q) 0).mapState Sum.inr := by
        conv_lhs => rw [← hc₀d]
        rw [seamCompTM_runFrom_right W WritePhase.done L (CounterLoopState.dec FlagPhase.run)
          hwrun hEwstate hwcut TF, hJ, hrun]
      rw [counter_cfg_eq] at hseam
      have hsum : (∑ i ∈ Finset.range jr, τ₀ (roundOrbit N₀ τ₀
          (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
            fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i)) ≤
          jr * (B₀ * (x.length + w.length + 1)) := by
        calc (∑ i ∈ Finset.range jr, τ₀ (roundOrbit N₀ τ₀
            (⟨some anchor₀, d.inputPos, fun j => Ew.workTapes j.castSucc,
              fun j => Ew.workTapePos j.castSucc, d.output⟩ : Cfg m Bool H₀ x) i))
            ≤ ∑ _i ∈ Finset.range jr, B₀ * (x.length + w.length + 1) :=
              Finset.sum_le_sum fun r hr =>
                (hτ₀ _ (chain r (Finset.mem_range.mp hr)).1
                  (chain r (Finset.mem_range.mp hr)).2).2.1
          _ = jr * (B₀ * (x.length + w.length + 1)) := by
              rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_id]
      have hov : counterOverhead w₀ jr ≤ 4 * jr + 2 * w₀.length :=
        counterOverhead_le_of_le w₀ jr (by rw [hval]; exact hjn)
      refine ⟨2 * w₀.length + 2 + 1 + TF, ?_, ?_, ?_, ?_, ?_⟩
      · have hprod : jr * (B₀ * (x.length + w.length + 1)) ≤
            3 ^ (k + 1) * (B₀ * (x.length + w.length + 1)) :=
          Nat.mul_le_mul_right _ hjn
        have hprod2 : 3 ^ (k + 1) * (B₀ * (x.length + w.length + 1) + 4) =
            3 ^ (k + 1) * (B₀ * (x.length + w.length + 1)) + 4 * 3 ^ (k + 1) := by ring
        omega
      · rw [hseam, Cfg.mapState_state, hparsed]
        rfl
      · rw [hseam, Cfg.mapState_output]
        exact houtchain jr le_rfl
      · intro u hu b
        by_cases hu1 : u ≤ 2 * w₀.length + 2
        · conv_lhs => rw [← hc₀d]
          rw [seamCompTM_runFrom_left W WritePhase.done L
            (CounterLoopState.dec FlagPhase.run) hwcut u hu1, Cfg.mapState_state]
          cases hws : ((writeConstTM (m + 1) (Fin.last m) w₀).runFrom
              (d.mapState fun _ => WritePhase.wr 0) u).state <;> simp [exitF]
        · intro hcon
          conv_lhs at hcon => rw [← hc₀d]
          rw [show u = 2 * w₀.length + 2 + 1 + (u - (2 * w₀.length + 2 + 1)) by omega,
            seamCompTM_runFrom_right W WritePhase.done L
              (CounterLoopState.dec FlagPhase.run)
              hwrun hEwstate hwcut (u - (2 * w₀.length + 2 + 1)), hJ,
            Cfg.mapState_state] at hcon
          obtain ⟨y, hy, hyz⟩ := Option.map_eq_some_iff.mp hcon
          have hcl := hcutT (u - (2 * w₀.length + 2 + 1)) (by omega)
          cases b
          · have hy' : y = CounterLoopState.escape := by simpa [exitF] using hyz
            exact hcl.2 (by rw [hy, hy'])
          · have hy' : y = CounterLoopState.done := by simpa [exitF] using hyz
            exact hcl.1 (by rw [hy, hy'])
      · intro ys hy
        rw [hparsed] at hy
        exact Option.noConfusion hy
  -- the adapter turns the block into the outer round, with the time chosen
  have hmain : ∀ d : Cfg (m + 1) Bool H x,
      (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
        d.workTapes bound.castSucc = FinTM.bufferTape w ∧
        d.workTapePos bound.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound → d.workTapes j.castSucc = FinTM.bufferTape [] ∧
          d.workTapePos j.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q → d.workTapes (Fin.last m) q = none) ∧
        d.workTapePos (Fin.last m) = 0) →
      d.state = some anchor →
      ∃ s, 0 < s ∧
        s ≤ (3 ^ (k + 1) * (B₀ + 4) + 6 * w₀.length + 12) * (x.length + w.length + 1) ∧
        (∀ u, 0 < u → u < s →
          ∃ q, (N.runFrom d u).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
        (N.runFrom d s).state = some
          (if (codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
              (x.drop (d.inputPos.val - 1))).isSome
            then anchor else escape) ∧
        (N.runFrom d s).output = [] ∧
        ∀ ys, codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop (d.inputPos.val - 1)) = some ys →
          (((N.runFrom d s).output = [] ∧ 1 ≤ (N.runFrom d s).inputPos.val ∧
            (N.runFrom d s).workTapes bound.castSucc = FinTM.bufferTape w ∧
            (N.runFrom d s).workTapePos bound.castSucc = 0 ∧
            (∀ j : Fin m, j ≠ bound →
              (N.runFrom d s).workTapes j.castSucc = FinTM.bufferTape [] ∧
              (N.runFrom d s).workTapePos j.castSucc = 0) ∧
            (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q →
              (N.runFrom d s).workTapes (Fin.last m) q = none) ∧
            (N.runFrom d s).workTapePos (Fin.last m) = 0) ∧
          x.drop ((N.runFrom d s).inputPos.val - 1) = ys) := by
    intro d hv hs
    have hcs : (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
        WritePhase w₀.length ⊕ CounterLoopState H₀)).state =
        some (Sum.inl (WritePhase.wr 0)) := by
      rw [Cfg.mapState_state, hs, Option.map_some]
    have hrestored : (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
        WritePhase w₀.length ⊕ CounterLoopState H₀)).mapState (fun _ => anchor) = d := by
      refine Cfg.ext ?_ ((Cfg.mapState_inputPos _ _).trans (Cfg.mapState_inputPos _ _)) ?_ ?_ ?_
      · rw [Cfg.mapState_state, Cfg.mapState_state, hs, Option.map_some, Option.map_some]
      · funext j q
        rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
      · funext j
        rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
      · rw [Cfg.mapState_output, Cfg.mapState_output]
    have hip : (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
        WritePhase w₀.length ⊕ CounterLoopState H₀)).inputPos = d.inputPos :=
      Cfg.mapState_inputPos _ _
    have hcv : ((d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
        WritePhase w₀.length ⊕ CounterLoopState H₀)).output = [] ∧
        1 ≤ (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
          WritePhase w₀.length ⊕ CounterLoopState H₀)).inputPos.val ∧
        (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
          WritePhase w₀.length ⊕ CounterLoopState H₀)).workTapes bound.castSucc =
          FinTM.bufferTape w ∧
        (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
          WritePhase w₀.length ⊕ CounterLoopState H₀)).workTapePos bound.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound →
          (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
            WritePhase w₀.length ⊕ CounterLoopState H₀)).workTapes j.castSucc =
            FinTM.bufferTape [] ∧
          (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
            WritePhase w₀.length ⊕ CounterLoopState H₀)).workTapePos j.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q →
          (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
            WritePhase w₀.length ⊕ CounterLoopState H₀)).workTapes (Fin.last m) q = none) ∧
        (d.mapState fun _ => (Sum.inl (WritePhase.wr 0) :
          WritePhase w₀.length ⊕ CounterLoopState H₀)).workTapePos (Fin.last m) = 0) := by
      obtain ⟨h1, h2, h3, h4, h5, h6, h7⟩ := hv
      refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [Cfg.mapState_output]; exact h1
      · rw [hip]; exact h2
      · funext q
        rw [Cfg.mapState_workTapes]
        exact congrFun h3 q
      · rw [Cfg.mapState_workTapePos]; exact h4
      · intro j hj
        refine ⟨?_, ?_⟩
        · funext q
          rw [Cfg.mapState_workTapes]
          exact congrFun (h5 j hj).1 q
        · rw [Cfg.mapState_workTapePos]; exact (h5 j hj).2
      · intro q hq
        rw [Cfg.mapState_workTapes]
        exact h6 q hq
      · rw [Cfg.mapState_workTapePos]; exact h7
    obtain ⟨t, ht, hstate, houtB, hcut, hysb⟩ := hblock _ hcv hcs
    rw [hip] at hstate hysb
    obtain ⟨hpos2, hrunN, hint⟩ := adapt x _ hcs t _ hstate hcut
    rw [hrestored] at hrunN hint
    refine ⟨t + 2, hpos2, ?_, hint, ?_, ?_, ?_⟩
    · have hX : 1 ≤ x.length + w.length + 1 := by omega
      have h1 := Nat.mul_le_mul_left (4 * 3 ^ (k + 1)) hX
      have h2 := Nat.mul_le_mul_left (6 * w₀.length) hX
      have h3 := Nat.mul_le_mul_left 12 hX
      nlinarith
    · rw [hrunN, Cfg.mapState_state, hstate, Option.map_some]
    · rw [hrunN, Cfg.mapState_output]
      exact houtB
    · intro ys hy
      obtain ⟨⟨g1, g2, g3, g4, g5, g6, g7⟩, gtail⟩ := hysb ys hy
      constructor
      · refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · rw [hrunN, Cfg.mapState_output]; exact g1
        · rw [hrunN, Cfg.mapState_inputPos]; exact g2
        · rw [hrunN]
          funext q
          rw [Cfg.mapState_workTapes]
          exact congrFun g3 q
        · rw [hrunN, Cfg.mapState_workTapePos]; exact g4
        · intro j hj
          refine ⟨?_, ?_⟩
          · rw [hrunN]
            funext q
            rw [Cfg.mapState_workTapes]
            exact congrFun (g5 j hj).1 q
          · rw [hrunN, Cfg.mapState_workTapePos]; exact (g5 j hj).2
        · intro q hq
          rw [hrunN, Cfg.mapState_workTapes]
          exact g6 q hq
        · rw [hrunN, Cfg.mapState_workTapePos]; exact g7
      · rw [hrunN, Cfg.mapState_inputPos]
        exact gtail
  -- package the chosen time
  refine ⟨fun d =>
    if h : (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
        d.workTapes bound.castSucc = FinTM.bufferTape w ∧
        d.workTapePos bound.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound → d.workTapes j.castSucc = FinTM.bufferTape [] ∧
          d.workTapePos j.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q → d.workTapes (Fin.last m) q = none) ∧
        d.workTapePos (Fin.last m) = 0) ∧ d.state = some anchor then
      (hmain d h.1 h.2).choose
    else 0, ?_⟩
  intro d hv hs
  have hcond : (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
      d.workTapes bound.castSucc = FinTM.bufferTape w ∧
      d.workTapePos bound.castSucc = 0 ∧
      (∀ j : Fin m, j ≠ bound → d.workTapes j.castSucc = FinTM.bufferTape [] ∧
        d.workTapePos j.castSucc = 0) ∧
      (∀ q : ℤ, q < 0 ∨ (w₀.length : ℤ) ≤ q → d.workTapes (Fin.last m) q = none) ∧
      d.workTapePos (Fin.last m) = 0) ∧ d.state = some anchor := ⟨hv, hs⟩
  simp only [dif_pos hcond]
  exact (hmain d hcond.1 hcond.2).choose_spec

/-- One successful inner block consumes at least one input cell: every record it skips has at
least `4k + 5` bits (`codeActionK_length`) and the block skips `3^(k+1)` of them.

**Proof sketch.** Every successful record skip consumes at least `4k + 5` cells (its read action's
bits), so `skipRepeat_consumes` bounds the consumed length below by `(4k + 5) · 3 ^ (k + 1) ≥ 1`. -/
private lemma canonStageBlock_consumes (k n : ℕ) (xs ys : List Bool)
    (h : codeSkipRepeat (codeSkipActionK k n) (3 ^ (k + 1)) xs = some ys) :
    1 + ys.length ≤ xs.length := by
  have ha : ∀ u v : List Bool, codeSkipActionK k n u = some v →
      4 * k + 5 + v.length ≤ u.length := by
    intro u v hu
    rw [← codeEraseActionK] at hu
    obtain ⟨⟨a, rest⟩, hread, rfl⟩ := Option.map_eq_some_iff.mp hu
    rw [codeReadActionK_sound u a rest hread, List.length_append]
    exact Nat.add_le_add_right (codeActionK_length a) _
  have hb := skipRepeat_consumes _ (4 * k + 5) ha (3 ^ (k + 1)) xs ys h
  have hp : 1 ≤ 3 ^ (k + 1) := Nat.one_le_pow _ _ (by omega)
  have h1 : 1 * 1 ≤ (4 * k + 5) * 3 ^ (k + 1) := Nat.mul_le_mul (by omega) hp
  omega

/-- **The table block**: the outer counter loop over the inner
block, wrapped once more by the fresh-anchor adapter. From a configuration carrying C2's bank,
the closed inner-counter window, and an outer counter holding any word `u` of value
`counterValue w + 1` (the incremented header copy), one block decides the whole fixed table
grammar `codeSkipTableK` (`canonSkipTable_eq`), in a time **independent of the counter value**:
each round that returns consumes at least one input cell (`canonStageBlock_consumes`), so at
most `|x| + 1` rounds ever run, each charged the inner block's linear budget, and the counter
overhead is settled by `counterOverhead_le` and `counterOverhead_le_of_le`. The block avoids
both fresh ports strictly inside, exits by the table verdict on the native suffix, and on
success has empty output and the native head at the surviving suffix.

**Proof sketch.** Run the outer counter loop (`counterLoopTM`) over the inner block
(`canonStageInnerSpec`) from the incremented copy. `canonRepeat_orbit` reads its orbit off the
inner block's specification. Each returning round consumes an input cell
(`canonStageBlock_consumes`), so at most `|x| + 1` rounds run, whatever the counter's value; each is
charged the inner block's linear budget, and the counter's own steps are bounded by
`counterOverhead_le` and `counterOverhead_le_of_le`. The verdict is the table grammar's
(`canonSkipTable_eq`). The fresh-anchor adapter (`canonReturnAdapter`) wraps the loop as one
block. -/
private lemma canonStageOuterSpec (k : ℕ) :
    ∃ (m : ℕ) (H : Type) (_ : Fintype H) (_ : DecidableEq H) (P : MultiTapeTM (m + 2) Bool H)
      (anchor escape : H) (bound : Fin m) (A : ℕ), escape ≠ anchor ∧
      ∀ (x w u : List Bool), Nat.ofDigits 2 (u.map Bool.toNat) = counterValue w + 1 →
        ∃ τ : Cfg (m + 2) Bool H x → ℕ,
          ∀ d : Cfg (m + 2) Bool H x,
            (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
              d.workTapes bound.castSucc.castSucc = FinTM.bufferTape w ∧
              d.workTapePos bound.castSucc.castSucc = 0 ∧
              (∀ j : Fin m, j ≠ bound →
                d.workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
                d.workTapePos j.castSucc.castSucc = 0) ∧
              (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
                d.workTapes (Fin.last m).castSucc q = none) ∧
              d.workTapePos (Fin.last m).castSucc = 0 ∧
              d.workTapes (Fin.last (m + 1)) = FinTM.bufferTape u ∧
              d.workTapePos (Fin.last (m + 1)) = 0) →
            d.state = some anchor →
            0 < τ d ∧ τ d ≤ A * (x.length + w.length + u.length + 1) ^ 2 ∧
            (∀ v, 0 < v → v < τ d →
              ∃ q, (P.runFrom d v).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
            (P.runFrom d (τ d)).state = some
              (if (codeSkipTableK k (counterValue w) (x.drop (d.inputPos.val - 1))).isSome
                then anchor else escape) ∧
            (P.runFrom d (τ d)).output = [] ∧
            ∀ ys, codeSkipTableK k (counterValue w) (x.drop (d.inputPos.val - 1)) = some ys →
              (P.runFrom d (τ d)).output = [] ∧ 1 ≤ (P.runFrom d (τ d)).inputPos.val ∧
              x.drop ((P.runFrom d (τ d)).inputPos.val - 1) = ys := by
  classical
  obtain ⟨m, H₂, finiteH₂, eqH₂, N₂, anchor₂, escape₂, bound, B₂, different₂, spec₂⟩ :=
    canonStageInnerSpec k
  letI : Fintype H₂ := finiteH₂
  letI : DecidableEq H₂ := eqH₂
  let L : MultiTapeTM (m + 2) Bool (CounterLoopState H₂) :=
    counterLoopTM N₂ anchor₂ (some escape₂)
  let exitF : Bool → CounterLoopState H₂ := fun b =>
    if b then CounterLoopState.done else CounterLoopState.escape
  have hinj : Function.Injective exitF := by
    intro a b h
    cases a <;> cases b <;> simp [exitF] at h ⊢
  obtain ⟨H, finiteH, eqH, N, anchor, escape, different, adapt⟩ :=
    canonReturnAdapter L (CounterLoopState.dec FlagPhase.run) exitF hinj
  refine ⟨m, H, finiteH, eqH, N, anchor, escape, bound, B₂ + 20, different, ?_⟩
  intro x w u hu
  obtain ⟨τ₂, hτ₂⟩ := spec₂ x w
  -- the loop's run, from its own entry, at the loop's state type
  have hloopblock : ∀ e : Cfg (m + 2) Bool (CounterLoopState H₂) x,
      (e.output = [] ∧ 1 ≤ e.inputPos.val ∧
        e.workTapes bound.castSucc.castSucc = FinTM.bufferTape w ∧
        e.workTapePos bound.castSucc.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound →
          e.workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
          e.workTapePos j.castSucc.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
          e.workTapes (Fin.last m).castSucc q = none) ∧
        e.workTapePos (Fin.last m).castSucc = 0 ∧
        e.workTapes (Fin.last (m + 1)) = FinTM.bufferTape u ∧
        e.workTapePos (Fin.last (m + 1)) = 0) →
      e.state = some (CounterLoopState.dec FlagPhase.run) →
      ∃ t, t ≤ (x.length + 1) * (B₂ * (x.length + w.length + 1)) +
          4 * x.length + 2 * u.length + 10 ∧
        (L.runFrom e t).state = some (exitF
          (codeSkipTableK k (counterValue w) (x.drop (e.inputPos.val - 1))).isSome) ∧
        (L.runFrom e t).output = [] ∧
        (∀ v < t, ∀ b : Bool, (L.runFrom e v).state ≠ some (exitF b)) ∧
        ∀ ys, codeSkipTableK k (counterValue w) (x.drop (e.inputPos.val - 1)) = some ys →
          (L.runFrom e t).output = [] ∧ 1 ≤ (L.runFrom e t).inputPos.val ∧
          x.drop ((L.runFrom e t).inputPos.val - 1) = ys := by
    intro e hv hes
    obtain ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9⟩ := hv
    set c₂ : Cfg (m + 1) Bool H₂ x :=
      ⟨some anchor₂, e.inputPos, fun j => e.workTapes j.castSucc,
        fun j => e.workTapePos j.castSucc, e.output⟩ with hc₂
    have hc₂ip : c₂.inputPos = e.inputPos := rfl
    have hc₂v : c₂.output = [] ∧ 1 ≤ c₂.inputPos.val ∧
        c₂.workTapes bound.castSucc = FinTM.bufferTape w ∧
        c₂.workTapePos bound.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound → c₂.workTapes j.castSucc = FinTM.bufferTape [] ∧
          c₂.workTapePos j.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
          c₂.workTapes (Fin.last m) q = none) ∧
        c₂.workTapePos (Fin.last m) = 0 :=
      ⟨h1, h2, h3, h4, h5, h6, h7⟩
    -- the junction into the loop's layout
    have hJ : e = counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) c₂
        (e.workTapes (Fin.last (m + 1))) 0 := by
      rw [counter_cfg_eq]
      refine Cfg.ext ?_ ?_ ?_ ?_ ?_
      · exact hes
      · exact hc₂ip.symm
      · funext jj
        dsimp only
        refine Fin.lastCases ?_ (fun j' => ?_) jj
        · rw [Fin.lastCases_last]
        · rw [Fin.lastCases_castSucc]
      · funext jj
        dsimp only
        refine Fin.lastCases ?_ (fun j' => ?_) jj
        · rw [Fin.lastCases_last]
          exact h9
        · rw [Fin.lastCases_castSucc]
      · rfl
    have he' : ∀ v : ℕ, L.runFrom e v =
        L.runFrom (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) c₂
          (e.workTapes (Fin.last (m + 1))) 0) v :=
      fun v => congrArg (fun z => L.runFrom z v) hJ
    have hword : ∀ p : ℤ, -1 ≤ p → p ≤ (u.length : ℤ) →
        (e.workTapes (Fin.last (m + 1))) (0 + p) = FinTM.bufferTape u p := by
      intro p _ _
      rw [h8, zero_add]
    -- the orbit's dichotomy
    obtain ⟨j, hj, chain, hdich⟩ := canonRepeat_orbit N₂ anchor₂ escape₂ τ₂
      (fun c => c.output = [] ∧ 1 ≤ c.inputPos.val ∧
        c.workTapes bound.castSucc = FinTM.bufferTape w ∧
        c.workTapePos bound.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound → c.workTapes j.castSucc = FinTM.bufferTape [] ∧
          c.workTapePos j.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
          c.workTapes (Fin.last m) q = none) ∧
        c.workTapePos (Fin.last m) = 0)
      (fun c => x.drop (c.inputPos.val - 1))
      (codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1)))
      (fun c hvc hsc => ⟨(hτ₂ c hvc hsc).2.2.2.1, fun ys hy =>
        ⟨((hτ₂ c hvc hsc).2.2.2.2.2 ys hy).1, ((hτ₂ c hvc hsc).2.2.2.2.2 ys hy).2⟩⟩)
      c₂ hc₂v rfl (counterValue w + 1)
    have hbase : (x.drop (e.inputPos.val - 1)).length ≤ x.length := by
      rw [List.length_drop]
      omega
    rcases hdich with ⟨hjN, hgood, hanch, hparsed⟩ | ⟨hjpos, hesc, hparsed⟩
    · -- every round returns: the loop runs to the done port
      subst hjN
      rw [hc₂ip, ← canonSkipTable_eq] at hparsed
      have hcons : ∀ i < counterValue w + 1,
          codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop ((roundOrbit N₂ τ₂ c₂ i).inputPos.val - 1)) =
          some (x.drop ((roundOrbit N₂ τ₂ c₂ (i + 1)).inputPos.val - 1)) := by
        intro i hi
        obtain ⟨hvi, hsi⟩ := chain i hi
        have hver := (hτ₂ _ hvi hsi).2.2.2.1
        have hnext : (roundOrbit N₂ τ₂ c₂ (i + 1)).state = some anchor₂ := by
          by_cases hlt : i + 1 < counterValue w + 1
          · exact (chain (i + 1) hlt).2
          · have hieq : i + 1 = counterValue w + 1 := by omega
            rw [hieq]
            exact hanch
        rw [roundOrbit_succ] at hnext
        have hifeq := Option.some.inj (hver.symm.trans hnext)
        by_cases hC : (codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop ((roundOrbit N₂ τ₂ c₂ i).inputPos.val - 1))).isSome = true
        · obtain ⟨ys, hys⟩ := Option.isSome_iff_exists.mp hC
          have htl := ((hτ₂ _ hvi hsi).2.2.2.2.2 ys hys).2
          rw [hys, roundOrbit_succ]
          exact congrArg some htl.symm
        · rw [if_neg hC] at hifeq
          exact absurd hifeq different₂
      have htele : ∀ i, i ≤ counterValue w + 1 →
          i + (x.drop ((roundOrbit N₂ τ₂ c₂ i).inputPos.val - 1)).length ≤
            (x.drop (e.inputPos.val - 1)).length := by
        intro i
        induction i with
        | zero =>
          intro _
          rw [roundOrbit_zero, hc₂ip]
          omega
        | succ i ih =>
          intro hi
          have hstep := hcons i (by omega)
          have hcl := canonStageBlock_consumes k (counterValue w) _ _ hstep
          have hprev := ih (by omega)
          omega
      have hNNx : counterValue w + 1 ≤ x.length := by
        have := htele (counterValue w + 1) le_rfl
        omega
      have hsum : (∑ r ∈ Finset.range (counterValue w + 1), τ₂ (roundOrbit N₂ τ₂ c₂ r)) ≤
          (counterValue w + 1) * (B₂ * (x.length + w.length + 1)) := by
        calc (∑ r ∈ Finset.range (counterValue w + 1), τ₂ (roundOrbit N₂ τ₂ c₂ r))
            ≤ ∑ _r ∈ Finset.range (counterValue w + 1), B₂ * (x.length + w.length + 1) :=
              Finset.sum_le_sum fun r hr =>
                (hτ₂ _ (chain r (Finset.mem_range.mp hr)).1
                  (chain r (Finset.mem_range.mp hr)).2).2.1
          _ = (counterValue w + 1) * (B₂ * (x.length + w.length + 1)) := by
              rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_id]
      have hov : counterOverhead u (counterValue w + 1 + 1) ≤
          4 * (counterValue w + 1) + 2 * u.length + 2 := by
        have hle := counterOverhead_le u
        rw [hu] at hle
        exact hle
      set T : ℕ := (∑ r ∈ Finset.range (counterValue w + 1), τ₂ (roundOrbit N₂ τ₂ c₂ r)) +
        counterOverhead u (counterValue w + 1 + 1) with hT
      obtain ⟨hrun, hcutT, -, -⟩ := counterLoopTM_run_done N₂ anchor₂ (some escape₂) τ₂ c₂
        u (e.workTapes (Fin.last (m + 1))) 0 hword (counterValue w + 1) hu
        (by
          intro r hr
          obtain ⟨hvr, hsr⟩ := chain r hr
          obtain ⟨hpos, -, hint, -, -, -⟩ := hτ₂ _ hvr hsr
          refine ⟨hsr, hpos, ?_, ?_⟩
          · intro uu huu htu
            obtain ⟨q, hq, hqa, hqe⟩ := hint uu huu htu
            exact ⟨q, hq, hqa, fun eq => hqe (Option.some.inj eq).symm⟩
          · by_cases hlt : r + 1 < counterValue w + 1
            · exact (chain (r + 1) hlt).2
            · have hre : r + 1 = counterValue w + 1 := by omega
              rw [hre]
              exact hanch)
        T hT
      refine ⟨T, ?_, ?_, ?_, ?_, ?_⟩
      · have h5 : (counterValue w + 1) * (B₂ * (x.length + w.length + 1)) ≤
            (x.length + 1) * (B₂ * (x.length + w.length + 1)) :=
          Nat.mul_le_mul_right _ (by omega)
        omega
      · rw [he', hrun, counter_cfg_eq, hparsed]
        rfl
      · rw [he', hrun, counter_cfg_eq]
        exact hgood.1
      · intro v hvt b
        rw [he']
        have hc := hcutT v hvt
        cases b
        · exact hc.2
        · exact hc.1
      · intro ys hy
        rw [hparsed] at hy
        have hyse := Option.some.inj hy
        refine ⟨?_, ?_, ?_⟩
        · rw [he', hrun, counter_cfg_eq]
          exact hgood.1
        · rw [he', hrun, counter_cfg_eq]
          exact hgood.2.1
        · rw [he', hrun, counter_cfg_eq]
          exact hyse
    · -- some round fails: the loop escapes early
      rw [hc₂ip, ← canonSkipTable_eq] at hparsed
      have hcons : ∀ i, i + 1 < j →
          codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop ((roundOrbit N₂ τ₂ c₂ i).inputPos.val - 1)) =
          some (x.drop ((roundOrbit N₂ τ₂ c₂ (i + 1)).inputPos.val - 1)) := by
        intro i hi
        obtain ⟨hvi, hsi⟩ := chain i (by omega)
        have hver := (hτ₂ _ hvi hsi).2.2.2.1
        have hnext : (roundOrbit N₂ τ₂ c₂ (i + 1)).state = some anchor₂ :=
          (chain (i + 1) hi).2
        rw [roundOrbit_succ] at hnext
        have hifeq := Option.some.inj (hver.symm.trans hnext)
        by_cases hC : (codeSkipRepeat (codeSkipActionK k (counterValue w)) (3 ^ (k + 1))
            (x.drop ((roundOrbit N₂ τ₂ c₂ i).inputPos.val - 1))).isSome = true
        · obtain ⟨ys, hys⟩ := Option.isSome_iff_exists.mp hC
          have htl := ((hτ₂ _ hvi hsi).2.2.2.2.2 ys hys).2
          rw [hys, roundOrbit_succ]
          exact congrArg some htl.symm
        · rw [if_neg hC] at hifeq
          exact absurd hifeq different₂
      have htele : ∀ i, i < j →
          i + (x.drop ((roundOrbit N₂ τ₂ c₂ i).inputPos.val - 1)).length ≤
            (x.drop (e.inputPos.val - 1)).length := by
        intro i
        induction i with
        | zero =>
          intro _
          rw [roundOrbit_zero, hc₂ip]
          omega
        | succ i ih =>
          intro hi
          have hstep := hcons i (by omega)
          have hcl := canonStageBlock_consumes k (counterValue w) _ _ hstep
          have hprev := ih (by omega)
          omega
      have hjx : j ≤ x.length + 1 := by
        have := htele (j - 1) (by omega)
        omega
      have hsum : (∑ r ∈ Finset.range j, τ₂ (roundOrbit N₂ τ₂ c₂ r)) ≤
          j * (B₂ * (x.length + w.length + 1)) := by
        calc (∑ r ∈ Finset.range j, τ₂ (roundOrbit N₂ τ₂ c₂ r))
            ≤ ∑ _r ∈ Finset.range j, B₂ * (x.length + w.length + 1) :=
              Finset.sum_le_sum fun r hr =>
                (hτ₂ _ (chain r (Finset.mem_range.mp hr)).1
                  (chain r (Finset.mem_range.mp hr)).2).2.1
          _ = j * (B₂ * (x.length + w.length + 1)) := by
              rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_id]
      have hov : counterOverhead u j ≤ 4 * j + 2 * u.length :=
        counterOverhead_le_of_le u j (by rw [hu]; omega)
      have hj1 : j - 1 + 1 = j := by omega
      set T : ℕ := (∑ r ∈ Finset.range j, τ₂ (roundOrbit N₂ τ₂ c₂ r)) +
        counterOverhead u j with hT
      obtain ⟨hrun, hcutT, -, -⟩ := counterLoopTM_run_escape N₂ anchor₂ escape₂ different₂
        τ₂ c₂ u (e.workTapes (Fin.last (m + 1))) 0 hword (j - 1)
        (by rw [hu]; omega)
        (by
          intro r hr
          obtain ⟨hvr, hsr⟩ := chain r (by omega)
          obtain ⟨hpos, -, hint, -, -, -⟩ := hτ₂ _ hvr hsr
          exact ⟨hsr, hpos, hint⟩)
        (by rw [hj1]; exact hesc)
        T (by rw [hT, hj1])
      rw [hj1] at hrun
      have houtchain : ∀ i, i ≤ j → (roundOrbit N₂ τ₂ c₂ i).output = [] := by
        intro i hi
        cases i with
        | zero =>
          rw [roundOrbit_zero]
          exact hc₂v.1
        | succ i =>
          obtain ⟨hvi, hsi⟩ := chain i (by omega)
          rw [roundOrbit_succ]
          exact (hτ₂ _ hvi hsi).2.2.2.2.1
      refine ⟨T, ?_, ?_, ?_, ?_, ?_⟩
      · have h5 : j * (B₂ * (x.length + w.length + 1)) ≤
            (x.length + 1) * (B₂ * (x.length + w.length + 1)) :=
          Nat.mul_le_mul_right _ (by omega)
        omega
      · rw [he', hrun, counter_cfg_eq, hparsed]
        rfl
      · rw [he', hrun, counter_cfg_eq]
        exact houtchain j le_rfl
      · intro v hvt b
        rw [he']
        have hc := hcutT v hvt
        cases b
        · exact hc.2
        · exact hc.1
      · intro ys hy
        rw [hparsed] at hy
        exact Option.noConfusion hy
  -- the adapter wrap and the chosen time
  have hmain : ∀ d : Cfg (m + 2) Bool H x,
      (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
        d.workTapes bound.castSucc.castSucc = FinTM.bufferTape w ∧
        d.workTapePos bound.castSucc.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound →
          d.workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
          d.workTapePos j.castSucc.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
          d.workTapes (Fin.last m).castSucc q = none) ∧
        d.workTapePos (Fin.last m).castSucc = 0 ∧
        d.workTapes (Fin.last (m + 1)) = FinTM.bufferTape u ∧
        d.workTapePos (Fin.last (m + 1)) = 0) →
      d.state = some anchor →
      ∃ s, 0 < s ∧ s ≤ (B₂ + 20) * (x.length + w.length + u.length + 1) ^ 2 ∧
        (∀ v, 0 < v → v < s →
          ∃ q, (N.runFrom d v).state = some q ∧ q ≠ anchor ∧ q ≠ escape) ∧
        (N.runFrom d s).state = some
          (if (codeSkipTableK k (counterValue w) (x.drop (d.inputPos.val - 1))).isSome
            then anchor else escape) ∧
        (N.runFrom d s).output = [] ∧
        ∀ ys, codeSkipTableK k (counterValue w) (x.drop (d.inputPos.val - 1)) = some ys →
          (N.runFrom d s).output = [] ∧ 1 ≤ (N.runFrom d s).inputPos.val ∧
          x.drop ((N.runFrom d s).inputPos.val - 1) = ys := by
    intro d hv hs
    have hcs : (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
        CounterLoopState H₂)).state = some (CounterLoopState.dec FlagPhase.run) := by
      rw [Cfg.mapState_state, hs, Option.map_some]
    have hrestored : (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
        CounterLoopState H₂)).mapState (fun _ => anchor) = d := by
      refine Cfg.ext ?_ ((Cfg.mapState_inputPos _ _).trans (Cfg.mapState_inputPos _ _)) ?_ ?_ ?_
      · rw [Cfg.mapState_state, Cfg.mapState_state, hs, Option.map_some, Option.map_some]
      · funext j q
        rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
      · funext j
        rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
      · rw [Cfg.mapState_output, Cfg.mapState_output]
    have hip : (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
        CounterLoopState H₂)).inputPos = d.inputPos :=
      Cfg.mapState_inputPos _ _
    have hcv : ((d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
        CounterLoopState H₂)).output = [] ∧
        1 ≤ (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
          CounterLoopState H₂)).inputPos.val ∧
        (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
          CounterLoopState H₂)).workTapes bound.castSucc.castSucc = FinTM.bufferTape w ∧
        (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
          CounterLoopState H₂)).workTapePos bound.castSucc.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound →
          (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
            CounterLoopState H₂)).workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
          (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
            CounterLoopState H₂)).workTapePos j.castSucc.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
          (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
            CounterLoopState H₂)).workTapes (Fin.last m).castSucc q = none) ∧
        (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
          CounterLoopState H₂)).workTapePos (Fin.last m).castSucc = 0 ∧
        (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
          CounterLoopState H₂)).workTapes (Fin.last (m + 1)) = FinTM.bufferTape u ∧
        (d.mapState fun _ => (CounterLoopState.dec FlagPhase.run :
          CounterLoopState H₂)).workTapePos (Fin.last (m + 1)) = 0) := by
      obtain ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9⟩ := hv
      refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [Cfg.mapState_output]; exact h1
      · rw [hip]; exact h2
      · funext q
        rw [Cfg.mapState_workTapes]
        exact congrFun h3 q
      · rw [Cfg.mapState_workTapePos]; exact h4
      · intro j hj
        refine ⟨?_, ?_⟩
        · funext q
          rw [Cfg.mapState_workTapes]
          exact congrFun (h5 j hj).1 q
        · rw [Cfg.mapState_workTapePos]; exact (h5 j hj).2
      · intro q hq
        rw [Cfg.mapState_workTapes]
        exact h6 q hq
      · rw [Cfg.mapState_workTapePos]; exact h7
      · funext q
        rw [Cfg.mapState_workTapes]
        exact congrFun h8 q
      · rw [Cfg.mapState_workTapePos]; exact h9
    obtain ⟨t, ht, hstate, houtB, hcut, hysb⟩ := hloopblock _ hcv hcs
    rw [hip] at hstate hysb
    obtain ⟨hpos2, hrunN, hint⟩ := adapt x _ hcs t _ hstate hcut
    rw [hrestored] at hrunN hint
    refine ⟨t + 2, hpos2, ?_, hint, ?_, ?_, ?_⟩
    · have hX1 : x.length + 1 ≤ x.length + w.length + u.length + 1 := by omega
      have hX2 : x.length + w.length + 1 ≤ x.length + w.length + u.length + 1 := by omega
      have h2 : (x.length + 1) * (B₂ * (x.length + w.length + 1)) ≤
          (x.length + w.length + u.length + 1) *
            (B₂ * (x.length + w.length + u.length + 1)) :=
        Nat.mul_le_mul hX1 (Nat.mul_le_mul_left _ hX2)
      have h3 : x.length + w.length + u.length + 1 ≤
          (x.length + w.length + u.length + 1) * (x.length + w.length + u.length + 1) :=
        Nat.le_mul_of_pos_left _ (by omega)
      have h4 : x.length ≤ x.length + w.length + u.length + 1 := by omega
      have h6 : u.length ≤ x.length + w.length + u.length + 1 := by omega
      have h7 : 1 ≤ x.length + w.length + u.length + 1 := by omega
      rw [pow_two]
      nlinarith
    · rw [hrunN, Cfg.mapState_state, hstate, Option.map_some]
    · rw [hrunN, Cfg.mapState_output]
      exact houtB
    · intro ys hy
      obtain ⟨g1, g2, g3⟩ := hysb ys hy
      refine ⟨?_, ?_, ?_⟩
      · rw [hrunN, Cfg.mapState_output]; exact g1
      · rw [hrunN, Cfg.mapState_inputPos]; exact g2
      · rw [hrunN, Cfg.mapState_inputPos]; exact g3
  -- package the chosen time
  refine ⟨fun d =>
    if h : (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
        d.workTapes bound.castSucc.castSucc = FinTM.bufferTape w ∧
        d.workTapePos bound.castSucc.castSucc = 0 ∧
        (∀ j : Fin m, j ≠ bound →
          d.workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
          d.workTapePos j.castSucc.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
          d.workTapes (Fin.last m).castSucc q = none) ∧
        d.workTapePos (Fin.last m).castSucc = 0 ∧
        d.workTapes (Fin.last (m + 1)) = FinTM.bufferTape u ∧
        d.workTapePos (Fin.last (m + 1)) = 0) ∧ d.state = some anchor then
      (hmain d h.1 h.2).choose
    else 0, ?_⟩
  intro d hv hs
  have hcond : (d.output = [] ∧ 1 ≤ d.inputPos.val ∧
      d.workTapes bound.castSucc.castSucc = FinTM.bufferTape w ∧
      d.workTapePos bound.castSucc.castSucc = 0 ∧
      (∀ j : Fin m, j ≠ bound →
        d.workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
        d.workTapePos j.castSucc.castSucc = 0) ∧
      (∀ q : ℤ, q < 0 ∨ ((3 ^ (k + 1) : ℕ).bits.length : ℤ) ≤ q →
        d.workTapes (Fin.last m).castSucc q = none) ∧
      d.workTapePos (Fin.last m).castSucc = 0 ∧
      d.workTapes (Fin.last (m + 1)) = FinTM.bufferTape u ∧
      d.workTapePos (Fin.last (m + 1)) = 0) ∧ d.state = some anchor := ⟨hv, hs⟩
  simp only [dif_pos hcond]
  exact (hmain d hcond.1 hcond.2).choose_spec

/-- The parking phase: a machine that halts at once, holding the verdict it was
dispatched into. The stage's contract reads its state only at the dispatch instant. -/
private def canonStageHaltTM (M : ℕ) : MultiTapeTM M Bool Bool where
  q₀ := true
  tr := fun _ _ _ => ⟨0, fun _ => (none, 0), none, none⟩

/-- The fixed-width increment adds one to the binary value. -/
private lemma canonStageInc_value : ∀ (w v : List Bool), incFixed w = some v →
    Nat.ofDigits 2 (v.map Bool.toNat) = Nat.ofDigits 2 (w.map Bool.toNat) + 1
  | [], v, h => Option.noConfusion (incFixed_nil.symm.trans h)
  | false :: w, v, h => by
    obtain rfl : true :: w = v := Option.some.inj ((incFixed_false_cons w).symm.trans h)
    simp only [List.map_cons, Nat.ofDigits_cons]
    simp only [Bool.toNat_true, Bool.toNat_false]
    omega
  | true :: w, v, h => by
    obtain ⟨z, hz, rfl⟩ :=
      Option.map_eq_some_iff.mp ((incFixed_true_cons w).symm.trans h)
    simp only [List.map_cons, Nat.ofDigits_cons, canonStageInc_value w z hz]
    simp only [Bool.toNat_true, Bool.toNat_false]
    ring

/-- A trailing `false` pad keeps the binary value. -/
private lemma canonStagePad_value (w : List Bool) :
    Nat.ofDigits 2 ((w ++ [false]).map Bool.toNat) = Nat.ofDigits 2 (w.map Bool.toNat) := by
  rw [List.map_append, Nat.ofDigits_append]
  simp

/-- The stage front's nine phases: seven counter-preparation rows, the embedded
bounded unary reader, and the parking phase. -/
private def canonStagePh (SU : Type) : Fin 9 → Type := fun i =>
  match i with
  | ⟨0, _⟩ => SweepPhase
  | ⟨1, _⟩ => SeekPhase
  | ⟨2, _⟩ => SeekPhase
  | ⟨3, _⟩ => WritePhase 1
  | ⟨4, _⟩ => SeekPhase
  | ⟨5, _⟩ => SeekPhase
  | ⟨6, _⟩ => FlagPhase
  | ⟨7, _⟩ => SU
  | ⟨8, _⟩ => Bool
  | ⟨_ + 9, h⟩ => absurd h (by omega)

private def canonStagePh_fintype (SU : Type) [Fintype SU] :
    ∀ i, Fintype (canonStagePh SU i) := fun i =>
  match i with
  | ⟨0, _⟩ => inferInstanceAs (Fintype SweepPhase)
  | ⟨1, _⟩ => inferInstanceAs (Fintype SeekPhase)
  | ⟨2, _⟩ => inferInstanceAs (Fintype SeekPhase)
  | ⟨3, _⟩ => inferInstanceAs (Fintype (WritePhase 1))
  | ⟨4, _⟩ => inferInstanceAs (Fintype SeekPhase)
  | ⟨5, _⟩ => inferInstanceAs (Fintype SeekPhase)
  | ⟨6, _⟩ => inferInstanceAs (Fintype FlagPhase)
  | ⟨7, _⟩ => inferInstanceAs (Fintype SU)
  | ⟨8, _⟩ => inferInstanceAs (Fintype Bool)
  | ⟨_ + 9, h⟩ => absurd h (by omega)

private def canonStagePh_deceq (SU : Type) [DecidableEq SU] :
    ∀ i, DecidableEq (canonStagePh SU i) := fun i =>
  match i with
  | ⟨0, _⟩ => inferInstanceAs (DecidableEq SweepPhase)
  | ⟨1, _⟩ => inferInstanceAs (DecidableEq SeekPhase)
  | ⟨2, _⟩ => inferInstanceAs (DecidableEq SeekPhase)
  | ⟨3, _⟩ => inferInstanceAs (DecidableEq (WritePhase 1))
  | ⟨4, _⟩ => inferInstanceAs (DecidableEq SeekPhase)
  | ⟨5, _⟩ => inferInstanceAs (DecidableEq SeekPhase)
  | ⟨6, _⟩ => inferInstanceAs (DecidableEq FlagPhase)
  | ⟨7, _⟩ => inferInstanceAs (DecidableEq SU)
  | ⟨8, _⟩ => inferInstanceAs (DecidableEq Bool)
  | ⟨_ + 9, h⟩ => absurd h (by omega)

/-- The stage front's phase machines: the copy, the three seeks and the step back, the pad
write, the increment, the embedded bounded unary reader, and the parking machine. -/
private def canonStageFamily (M mU : ℕ) (SU : Type) (U : MultiTapeTM mU Bool SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) :
    (i : Fin 9) → MultiTapeTM M Bool (canonStagePh SU i) := fun i =>
  match i with
  | ⟨0, _⟩ => copyTM M header ctrOuter
  | ⟨1, _⟩ => skipTM M ctrOuter
  | ⟨2, _⟩ => walkTM M ctrOuter (· = ctrOuter) .neg
  | ⟨3, _⟩ => writeConstTM M ctrOuter [false]
  | ⟨4, _⟩ => skipTM M ctrOuter
  | ⟨5, _⟩ => skipBackTM M ctrOuter
  | ⟨6, _⟩ => incrementTM M ctrOuter
  | ⟨7, _⟩ => embedEmitTM σ U
  | ⟨8, _⟩ => canonStageHaltTM M
  | ⟨_ + 9, h⟩ => absurd h (by omega)

/-- The stage front's dispatch table: each row's exit to the next row, the increment's
phantom overflow port and both reader ports to the parking phase. -/
private def canonStageRed (SU : Type) [DecidableEq SU] (ue : SU) (ux : Bool → SU) :
    (i : Fin 9) → canonStagePh SU i → Option (Σ j, canonStagePh SU j) :=
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  fun i =>
  match i with
  | ⟨0, _⟩ => fun s => if s = SweepPhase.done
      then some ⟨⟨1, by omega⟩, SeekPhase.run⟩ else none
  | ⟨1, _⟩ => fun s => if s = SeekPhase.done
      then some ⟨⟨2, by omega⟩, SeekPhase.run⟩ else none
  | ⟨2, _⟩ => fun s => if s = SeekPhase.done
      then some ⟨⟨3, by omega⟩, WritePhase.wr 0⟩ else none
  | ⟨3, _⟩ => fun s => if s = WritePhase.done
      then some ⟨⟨4, by omega⟩, SeekPhase.run⟩ else none
  | ⟨4, _⟩ => fun s => if s = SeekPhase.done
      then some ⟨⟨5, by omega⟩, SeekPhase.run⟩ else none
  | ⟨5, _⟩ => fun s => if s = SeekPhase.done
      then some ⟨⟨6, by omega⟩, FlagPhase.run⟩ else none
  | ⟨6, _⟩ => fun s => if s = FlagPhase.done true then some ⟨⟨7, by omega⟩, ue⟩
      else if s = FlagPhase.done false then some ⟨⟨8, by omega⟩, false⟩ else none
  | ⟨7, _⟩ => fun s => if s = ux true then some ⟨⟨8, by omega⟩, true⟩
      else if s = ux false then some ⟨⟨8, by omega⟩, false⟩ else none
  | ⟨8, _⟩ => fun _ => none
  | ⟨_ + 9, h⟩ => absurd h (by omega)

/-- The stage front's host. -/
private def canonStageFr (M mU : ℕ) (SU : Type) [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) :
    MultiTapeTM M Bool (Σ j, canonStagePh SU j) :=
  phaseHostTM (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)

/-- The stage front's bank shape: the header word, the outer-counter tape, every other
tape blank, every head at the origin but the outer counter's, and empty output. -/
private def canonStageBank {x : List Bool} (M : ℕ) (header ctrOuter : Fin M) {S' : Type}
    (q : Option S') (ip : Fin (x.length + 2)) (ct : ℤ → Option Bool) (cp : ℤ)
    (w : List Bool) : Cfg M Bool S' x :=
  ⟨q, ip,
    fun j => if j = header then FinTM.bufferTape w
      else if j = ctrOuter then ct else FinTM.bufferTape [],
    fun j => if j = ctrOuter then cp else 0, []⟩

/-- The bank shape's fields. -/
private lemma canonStageBank_fields {x : List Bool} (M : ℕ) (header ctrOuter : Fin M)
    (hhc : header ≠ ctrOuter) {S' : Type} (q : Option S') (ip : Fin (x.length + 2))
    (ct : ℤ → Option Bool) (cp : ℤ) (w : List Bool) :
    (canonStageBank M header ctrOuter q ip ct cp w).workTapes header = FinTM.bufferTape w ∧
    (canonStageBank M header ctrOuter q ip ct cp w).workTapePos header = 0 ∧
    (canonStageBank M header ctrOuter q ip ct cp w).workTapes ctrOuter = ct ∧
    (canonStageBank M header ctrOuter q ip ct cp w).workTapePos ctrOuter = cp ∧
    ∀ j, j ≠ header → j ≠ ctrOuter →
      (canonStageBank M header ctrOuter q ip ct cp w).workTapes j = FinTM.bufferTape [] ∧
      (canonStageBank M header ctrOuter q ip ct cp w).workTapePos j = 0 := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · show (if header = header then _ else _) = _
    rw [if_pos rfl]
  · show (if header = ctrOuter then cp else 0) = 0
    rw [if_neg hhc]
  · show (if ctrOuter = header then _ else _) = _
    rw [if_neg (fun h => hhc h.symm), if_pos rfl]
  · show (if ctrOuter = ctrOuter then cp else 0) = cp
    rw [if_pos rfl]
  · intro j hj1 hj2
    constructor
    · show (if j = header then _ else _) = _
      rw [if_neg hj1, if_neg hj2]
    · show (if j = ctrOuter then cp else 0) = 0
      rw [if_neg hj2]


/-- One leg of the stage front's strict cut: while the host replays phase `i`, its control
carries phase `i`'s tag, which is not the parking tag. -/
private lemma canonStageCut_leg {M : ℕ} {SU : Type} {x : List Bool}
    (Fr : MultiTapeTM M Bool (Σ j, canonStagePh SU j))
    (d : Cfg M Bool (Σ j, canonStagePh SU j) x) (A B : ℕ) (i : Fin 9) (hi : i.val ≠ 8)
    (c : Cfg M Bool (canonStagePh SU i) x) (Mach : MultiTapeTM M Bool (canonStagePh SU i))
    (hhost : Fr.runFrom d A = c.mapState (Sigma.mk i))
    (hpre : ∀ u ≤ B, Fr.runFrom (c.mapState (Sigma.mk i)) u =
      (Mach.runFrom c u).mapState (Sigma.mk i))
    (vt : ℕ) (h1 : A ≤ vt) (h2 : vt ≤ A + B) (b : Bool) :
    (Fr.runFrom d vt).state ≠ some ⟨⟨8, by omega⟩, b⟩ := by
  rw [show vt = A + (vt - A) by omega, MultiTapeTM.runFrom_add, hhost,
    hpre (vt - A) (by omega), Cfg.mapState_state]
  cases hst : (Mach.runFrom c (vt - A)).state with
  | none =>
    rw [Option.map_none]
    exact fun hcon => Option.noConfusion hcon
  | some s =>
    rw [Option.map_some]
    intro hcon
    exact hi (congrArg (fun z : Σ j, canonStagePh SU j => z.1.val) (Option.some.inj hcon))

/-- Leg 0 of the stage front: copy the header onto the outer counter (`Turing.copyTM`).

**Proof sketch.** The bank configuration meets the row's framed premise (its fields read by
`canonStageBank_fields`). Then `phaseHostTM_run`, with its guard from the row's first-visit cut,
gives the lockstep window and the dispatch, and the dispatched configuration is the next
phase's bank configuration, field by field. -/
private lemma canonStageLeg0 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2)) :
    (∀ u ≤ 2 * w.length + 2,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some SweepPhase.sweep) ip
      (FinTM.bufferTape []) 0 w)).mapState (Sigma.mk (⟨0, by omega⟩ : Fin 9))) u =
      ((copyTM M header ctrOuter).runFrom
        (canonStageBank M header ctrOuter (some SweepPhase.sweep) ip
      (FinTM.bufferTape []) 0 w) u).mapState (Sigma.mk (⟨0, by omega⟩ : Fin 9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some SweepPhase.sweep) ip
      (FinTM.bufferTape []) 0 w)).mapState (Sigma.mk (⟨0, by omega⟩ : Fin 9))) (2 * w.length + 2 +
          1) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w)).mapState (Sigma.mk (⟨1, by omega⟩ : Fin 9)) := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SweepPhase.sweep) ip (FinTM.bufferTape []) 0 w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape w) 0 w
  obtain ⟨hrun, hcut, -⟩ := copyTM_run_ofCfg header ctrOuter hhc w
    (canonStageBank M header ctrOuter (some SweepPhase.sweep) ip
      (FinTM.bufferTape []) 0 w)
    rfl
    (by
      intro p _ _
      rw [hA_h, hA_hp, zero_add])
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨0, by omega⟩ _ _ (2 * w.length + 2) hrun (SweepPhase.done) rfl
    ⟨⟨1, by omega⟩, SeekPhase.run⟩
    (by
      show (if SweepPhase.done = SweepPhase.done
        then some (⟨⟨1, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨1, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd : s = SweepPhase.done
      · rw [hd] at hsu
        exact absurd hsu (hcut u hu)
      · show (if s = SweepPhase.done then _ else none) = none
        rw [if_neg hd])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (if j = ctrOuter ∧ _ ∧ _ then _ else _) = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      by_cases hq : (0 : ℤ) ≤ q ∧ q < 0 + (w.length : ℤ)
      · rw [if_pos ⟨rfl, (by rw [hA_cp]; exact hq.1), (by rw [hA_cp]; exact hq.2)⟩,
          hB_c, hA_cp, sub_zero]
      · rw [if_neg (fun hcon => hq ⟨(by rw [← hA_cp]; exact hcon.2.1),
          (by rw [← hA_cp]; exact hcon.2.2)⟩), hA_c, hB_c, FinTM.bufferTape_nil]
        rcases (by omega : q < 0 ∨ (w.length : ℤ) ≤ q) with hq' | hq'
        · rw [FinTM.bufferTape_of_neg _ hq']
        · rw [canonStageBuffer_none w q hq']
    · rw [if_neg (fun hcon => hj2 hcon.1)]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_h, hB_h]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show (canonStageBank M header ctrOuter (some SweepPhase.sweep) ip
      (FinTM.bufferTape []) 0 w).workTapePos j = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [hA_cp, hB_cp]
    · by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl

/-- Leg 1 of the stage front: skip past the copy on the outer counter (`Turing.skipTM`).

**Proof sketch.** The bank configuration meets the row's framed premise (its fields read by
`canonStageBank_fields`). Then `phaseHostTM_run`, with its guard from the row's first-visit cut,
gives the lockstep window and the dispatch, and the dispatched configuration is the next
phase's bank configuration, field by field. -/
private lemma canonStageLeg1 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2)) :
    (∀ u ≤ w.length + 1,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w)).mapState (Sigma.mk (⟨1, by omega⟩ : Fin 9))) u =
      ((skipTM M ctrOuter).runFrom
        (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w) u).mapState (Sigma.mk (⟨1, by omega⟩ : Fin 9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w)).mapState (Sigma.mk (⟨1, by omega⟩ : Fin 9))) (w.length + 1 + 1) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) (w.length + 1) w)).mapState (Sigma.mk (⟨2, by omega⟩ : Fin 9)) := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape w) 0 w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape w) (w.length + 1) w
  obtain ⟨hrun, hcut, -⟩ := skipTM_run_ofCfg ctrOuter w
    (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w)
    rfl
    (by
      intro p _ _
      rw [hA_c, hA_cp, zero_add])
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨1, by omega⟩ _ _ (w.length + 1) hrun (SeekPhase.done) rfl
    ⟨⟨2, by omega⟩, SeekPhase.run⟩
    (by
      show (if SeekPhase.done = SeekPhase.done
        then some (⟨⟨2, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨2, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd : s = SeekPhase.done
      · rw [hd] at hsu
        exact absurd hsu (hcut u hu)
      · show (if s = SeekPhase.done then _ else none) = none
        rw [if_neg hd])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w).workTapes j q = _
    by_cases hj1 : j = header
    · subst hj1
      rw [hA_h, hB_h]
    · by_cases hj2 : j = ctrOuter
      · subst hj2
        rw [hA_c, hB_c]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show Function.update (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) 0 w).workTapePos ctrOuter
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
        (FinTM.bufferTape w) 0 w).workTapePos ctrOuter + w.length + 1) j = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [Function.update_self, hA_cp, hB_cp]
      ring
    · rw [Function.update_of_ne hj2]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl

/-- Leg 2 of the stage front: one step back on the outer counter (`Turing.walkTM`).

**Proof sketch.** The bank configuration meets the row's framed premise (its fields read by
`canonStageBank_fields`). Then `phaseHostTM_run`, with its guard from the row's first-visit cut,
gives the lockstep window and the dispatch, and the dispatched configuration is the next
phase's bank configuration, field by field. -/
private lemma canonStageLeg2 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2)) :
    (∀ u ≤ ([] : List Bool).length + 1,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) (w.length + 1) w)).mapState (Sigma.mk (⟨2, by omega⟩ : Fin 9))) u =
      ((walkTM M ctrOuter (· = ctrOuter) .neg).runFrom
        (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) (w.length + 1) w) u).mapState (Sigma.mk (⟨2, by omega⟩ : Fin 9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) (w.length + 1) w)).mapState (Sigma.mk (⟨2, by omega⟩ : Fin 9))) (([] :
          List Bool).length + 1 + 1) =
      ((canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) ip
      (FinTM.bufferTape w) (w.length) w)).mapState (Sigma.mk (⟨3, by omega⟩ : Fin 9)) := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape w) (w.length + 1) w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some (WritePhase.wr 0) : Option (WritePhase 1)) ip (FinTM.bufferTape w) (w.length) w
  obtain ⟨hrun, hcut, -⟩ := walkTM_run_ofCfg ctrOuter (· = ctrOuter) rfl .neg []
    (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) (w.length + 1) w)
    rfl
    (by
      intro p hp
      obtain rfl : p = 0 := Nat.le_zero.mp (by simpa using hp)
      rw [hA_c, hA_cp]
      simp only [Nat.cast_zero, mul_zero, add_zero, FinTM.bufferTape_nil]
      exact canonStageBuffer_none w _ (by omega))
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨2, by omega⟩ _ _ (([] : List Bool).length + 1) hrun (SeekPhase.done) rfl
    ⟨⟨3, by omega⟩, WritePhase.wr 0⟩
    (by
      show (if SeekPhase.done = SeekPhase.done
        then some (⟨⟨3, by omega⟩, WritePhase.wr 0⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨3, by omega⟩, WritePhase.wr 0⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd : s = SeekPhase.done
      · rw [hd] at hsu
        exact absurd hsu (hcut u hu)
      · show (if s = SeekPhase.done then _ else none) = none
        rw [if_neg hd])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape w) (w.length + 1) w).workTapes j q = _
    by_cases hj1 : j = header
    · subst hj1
      rw [hA_h, hB_h]
    · by_cases hj2 : j = ctrOuter
      · subst hj2
        rw [hA_c, hB_c]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show (canonStageBank M header ctrOuter (some SeekPhase.run) ip
        (FinTM.bufferTape w) (w.length + 1) w).workTapePos j +
        (if j = ctrOuter then _ else 0) = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [if_pos rfl, hA_cp, hB_cp]
      show (w.length : ℤ) + 1 +
        (SignType.neg : ℤ) * ((([] : List Bool).length + 1 : ℕ) : ℤ) = (w.length : ℤ)
      simp
    · rw [if_neg hj2, add_zero]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl

/-- Leg 3 of the stage front: write the spare `false` pad (`Turing.writeConstTM`).

**Proof sketch.** The bank configuration meets the row's framed premise (its fields read by
`canonStageBank_fields`). Then `phaseHostTM_run`, with its guard from the row's first-visit cut,
gives the lockstep window and the dispatch, and the dispatched configuration is the next
phase's bank configuration, field by field. -/
private lemma canonStageLeg3 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2)) :
    (∀ u ≤ 2 * ([false] : List Bool).length + 2,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) ip
      (FinTM.bufferTape w) (w.length) w)).mapState (Sigma.mk (⟨3, by omega⟩ : Fin 9))) u =
      ((writeConstTM M ctrOuter [false]).runFrom
        (canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) ip
      (FinTM.bufferTape w) (w.length) w) u).mapState (Sigma.mk (⟨3, by omega⟩ : Fin 9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) ip
      (FinTM.bufferTape w) (w.length) w)).mapState (Sigma.mk (⟨3, by omega⟩ : Fin 9))) (2 * ([false]
          : List Bool).length + 2 + 1) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w)).mapState (Sigma.mk (⟨4, by omega⟩ : Fin 9))
          := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  have hlapp : (w ++ [false]).length = w.length + 1 := by
    rw [List.length_append]
    rfl
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some (WritePhase.wr 0) : Option (WritePhase 1)) ip (FinTM.bufferTape w) (w.length) w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape (w ++ [false])) (w.length) w
  obtain ⟨hrun, hcut, -⟩ := writeConstTM_run_ofCfg ctrOuter [false]
    (canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) ip
      (FinTM.bufferTape w) (w.length) w)
    rfl
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨3, by omega⟩ _ _ (2 * ([false] : List Bool).length + 2) hrun
    (WritePhase.done : WritePhase 1) rfl
    ⟨⟨4, by omega⟩, SeekPhase.run⟩
    (by
      show (if (WritePhase.done : WritePhase 1) = WritePhase.done
        then some (⟨⟨4, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨4, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd : s = WritePhase.done
      · rw [hd] at hsu
        exact absurd hsu (hcut u hu)
      · show (if s = WritePhase.done then _ else none) = none
        rw [if_neg hd])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (if j = ctrOuter ∧ _ ∧ _ then _ else _) = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      by_cases hq : (w.length : ℤ) ≤ q ∧ q < (w.length : ℤ) + 1
      · rw [if_pos ⟨rfl, (by rw [hA_cp]; exact hq.1),
          (by rw [hA_cp]; simpa using hq.2)⟩, hB_c]
        obtain rfl : q = (w.length : ℤ) := by omega
        rw [hA_cp, sub_self]
        rw [show FinTM.bufferTape [false] 0 = some false by rw [FinTM.bufferTape_eq]; rfl,
          FinTM.bufferTape_nat, List.getElem?_append_right (le_refl w.length),
          Nat.sub_self]
        rfl
      · rw [if_neg (fun hcon => hq ⟨(by
            have h1 := hcon.2.1
            rw [hA_cp] at h1
            exact h1), (by
            have h2 := hcon.2.2
            rw [hA_cp] at h2
            simpa using h2)⟩), hA_c, hB_c, FinTM.bufferTape_eq, FinTM.bufferTape_eq]
        by_cases hq0 : (0 : ℤ) ≤ q
        · rw [if_pos hq0, if_pos hq0]
          push_cast at hq
          rcases (by omega : q < (w.length : ℤ) ∨ (w.length : ℤ) + 1 ≤ q) with hq' | hq'
          · rw [List.getElem?_append_left (by omega)]
          · rw [List.getElem?_eq_none (show w.length ≤ q.toNat by omega),
              List.getElem?_eq_none
                (show (w ++ [false]).length ≤ q.toNat by rw [hlapp]; omega)]
        · rw [if_neg hq0, if_neg hq0]
    · rw [if_neg (fun hcon => hj2 hcon.1)]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_h, hB_h]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show (canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) ip
      (FinTM.bufferTape w) (w.length) w).workTapePos j = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [hA_cp, hB_cp]
    · by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl

/-- Leg 4 of the stage front: skip past the pad (`Turing.skipTM`).

**Proof sketch.** The bank configuration meets the row's framed premise (its fields read by
`canonStageBank_fields`). Then `phaseHostTM_run`, with its guard from the row's first-visit cut,
gives the lockstep window and the dispatch, and the dispatched configuration is the next
phase's bank configuration, field by field. -/
private lemma canonStageLeg4 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2)) :
    (∀ u ≤ ([false] : List Bool).length + 1,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w)).mapState (Sigma.mk (⟨4, by omega⟩ : Fin 9)))
          u =
      ((skipTM M ctrOuter).runFrom
        (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w) u).mapState (Sigma.mk (⟨4, by omega⟩ : Fin
          9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w)).mapState (Sigma.mk (⟨4, by omega⟩ : Fin 9)))
          (([false] : List Bool).length + 1 + 1) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w)).mapState (Sigma.mk (⟨5, by omega⟩ : Fin
          9)) := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  have hlapp : (w ++ [false]).length = w.length + 1 := by
    rw [List.length_append]
    rfl
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape (w ++ [false])) (w.length) w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape (w ++ [false])) (w.length + 2) w
  obtain ⟨hrun, hcut, -⟩ := skipTM_run_ofCfg ctrOuter [false]
    (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w)
    rfl
    (by
      intro p hp0 hp1
      have hp1' : p ≤ 1 := by simpa using hp1
      rw [hA_c, hA_cp]
      rcases (by omega : p = 0 ∨ p = 1) with rfl | rfl
      · rw [add_zero, show FinTM.bufferTape [false] 0 = some false by rw [FinTM.bufferTape_eq]; rfl,
          FinTM.bufferTape_nat, List.getElem?_append_right (le_refl w.length),
          Nat.sub_self]
        rfl
      · rw [canonStageBuffer_none _ _ (by rw [hlapp]; omega),
          show FinTM.bufferTape [false] 1 = none by rw [FinTM.bufferTape_eq]; rfl])
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨4, by omega⟩ _ _ (([false] : List Bool).length + 1) hrun (SeekPhase.done) rfl
    ⟨⟨5, by omega⟩, SeekPhase.run⟩
    (by
      show (if SeekPhase.done = SeekPhase.done
        then some (⟨⟨5, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨5, by omega⟩, SeekPhase.run⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd : s = SeekPhase.done
      · rw [hd] at hsu
        exact absurd hsu (hcut u hu)
      · show (if s = SeekPhase.done then _ else none) = none
        rw [if_neg hd])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w).workTapes j q = _
    by_cases hj1 : j = header
    · subst hj1
      rw [hA_h, hB_h]
    · by_cases hj2 : j = ctrOuter
      · subst hj2
        rw [hA_c, hB_c]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show Function.update (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length) w).workTapePos ctrOuter
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
        (FinTM.bufferTape (w ++ [false])) (w.length) w).workTapePos ctrOuter +
        ([false] : List Bool).length + 1) j = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [Function.update_self, hA_cp, hB_cp]
      show (w.length : ℤ) + ((([false] : List Bool).length : ℕ) : ℤ) + 1 =
        (w.length : ℤ) + 2
      simp only [List.length_singleton]
      push_cast
      ring
    · rw [Function.update_of_ne hj2]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl

/-- Leg 5 of the stage front: skip back over the padded word (`Turing.skipBackTM`).

**Proof sketch.** The bank configuration meets the row's framed premise (its fields read by
`canonStageBank_fields`). Then `phaseHostTM_run`, with its guard from the row's first-visit cut,
gives the lockstep window and the dispatch, and the dispatched configuration is the next
phase's bank configuration, field by field. -/
private lemma canonStageLeg5 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2)) :
    (∀ u ≤ (w ++ [false]).length + 3,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w)).mapState (Sigma.mk (⟨5, by omega⟩ : Fin
          9))) u =
      ((skipBackTM M ctrOuter).runFrom
        (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w) u).mapState (Sigma.mk (⟨5, by omega⟩ : Fin
          9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w)).mapState (Sigma.mk (⟨5, by omega⟩ : Fin
          9))) ((w ++ [false]).length + 3 + 1) =
      ((canonStageBank M header ctrOuter (some FlagPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) 0 w)).mapState (Sigma.mk (⟨6, by omega⟩ : Fin 9)) := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  have hlapp : (w ++ [false]).length = w.length + 1 := by
    rw [List.length_append]
    rfl
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some SeekPhase.run) ip (FinTM.bufferTape (w ++ [false])) (w.length + 2) w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some FlagPhase.run) ip (FinTM.bufferTape (w ++ [false])) 0 w
  obtain ⟨hrun, hcut, -⟩ := skipBackTM_run_ofCfg ctrOuter (w ++ [false])
    (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w)
    rfl
    (by
      intro p _ _
      rw [hA_c, hA_cp]
      congr 1
      rw [hlapp]
      push_cast
      ring)
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨5, by omega⟩ _ _ ((w ++ [false]).length + 3) hrun (SeekPhase.done) rfl
    ⟨⟨6, by omega⟩, FlagPhase.run⟩
    (by
      show (if SeekPhase.done = SeekPhase.done
        then some (⟨⟨6, by omega⟩, FlagPhase.run⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨6, by omega⟩, FlagPhase.run⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd : s = SeekPhase.done
      · rw [hd] at hsu
        exact absurd hsu (hcut u hu)
      · show (if s = SeekPhase.done then _ else none) = none
        rw [if_neg hd])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w).workTapes j q = _
    by_cases hj1 : j = header
    · subst hj1
      rw [hA_h, hB_h]
    · by_cases hj2 : j = ctrOuter
      · subst hj2
        rw [hA_c, hB_c]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show Function.update (canonStageBank M header ctrOuter (some SeekPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) (w.length + 2) w).workTapePos ctrOuter
      ((canonStageBank M header ctrOuter (some SeekPhase.run) ip
        (FinTM.bufferTape (w ++ [false])) (w.length + 2) w).workTapePos ctrOuter -
        (w ++ [false]).length - 1) j = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [Function.update_self, hA_cp, hB_cp, hlapp]
      push_cast
      ring
    · rw [Function.update_of_ne hj2]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl

/-- Leg 6 of the stage front: increment the padded copy (`Turing.incrementTM`).

**Proof sketch.** As for the other legs, with the increment row's success case
(`incrementTM_run_succ_ofCfg`): the padded copy does not overflow, and its incremented word has
the same length (`incFixed_length`). Then `phaseHostTM_run` and the field-by-field
identification of the next phase's bank configuration. -/
private lemma canonStageLeg6 {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hhc : header ≠ ctrOuter)
    (x w : List Bool) (ip : Fin (x.length + 2))
    (v : List Bool) (hv : incFixed (w ++ [false]) = some v) :
    (∀ u ≤ 2 * ((w ++ [false]).takeWhile id).length + 2,
      (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
        (((canonStageBank M header ctrOuter (some FlagPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) 0 w)).mapState (Sigma.mk (⟨6, by omega⟩ : Fin 9))) u =
      ((incrementTM M ctrOuter).runFrom
        (canonStageBank M header ctrOuter (some FlagPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) 0 w) u).mapState (Sigma.mk (⟨6, by omega⟩ : Fin 9))) ∧
    (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom
      (((canonStageBank M header ctrOuter (some FlagPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) 0 w)).mapState (Sigma.mk (⟨6, by omega⟩ : Fin 9))) (2 * ((w
          ++ [false]).takeWhile id).length + 2 + 1) =
      ((canonStageBank M header ctrOuter (some ue) ip
      (FinTM.bufferTape v) 0 w)).mapState (Sigma.mk (⟨7, by omega⟩ : Fin 9)) := by
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  have hlapp : (w ++ [false]).length = w.length + 1 := by
    rw [List.length_append]
    rfl
  have hvlen : v.length = w.length + 1 := by
    have h1 := incFixed_length hv
    rw [hlapp] at h1
    exact h1
  obtain ⟨hA_h, hA_hp, hA_c, hA_cp, hA_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some FlagPhase.run) ip (FinTM.bufferTape (w ++ [false])) 0 w
  obtain ⟨hB_h, hB_hp, hB_c, hB_cp, hB_o⟩ := canonStageBank_fields M header ctrOuter hhc
    (x := x) (some ue) ip (FinTM.bufferTape v) 0 w
  obtain ⟨hrun, hcut, -⟩ := incrementTM_run_succ_ofCfg ctrOuter (w ++ [false]) v hv
    (canonStageBank M header ctrOuter (some FlagPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) 0 w)
    rfl
    (by
      intro p _ _
      rw [hA_c, hA_cp, zero_add])
  obtain ⟨hpre, hdisp⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨6, by omega⟩ _ _ (2 * ((w ++ [false]).takeWhile id).length + 2) hrun (FlagPhase.done true) rfl
    ⟨⟨7, by omega⟩, ue⟩
    (by
      show (if FlagPhase.done true = FlagPhase.done true
        then some (⟨⟨7, by omega⟩, ue⟩ : Σ j, canonStagePh SU j) else if FlagPhase.done true =
            FlagPhase.done false
        then some (⟨⟨8, by omega⟩, false⟩ : Σ j, canonStagePh SU j) else none) =
        some (⟨⟨7, by omega⟩, ue⟩ : Σ j, canonStagePh SU j)
      rw [if_pos rfl])
    (by
      intro u hu s hsu
      by_cases hd1 : s = FlagPhase.done true
      · rw [hd1] at hsu
        exact absurd hsu (hcut u hu true)
      · by_cases hd0 : s = FlagPhase.done false
        · rw [hd0] at hsu
          exact absurd hsu (hcut u hu false)
        · show (if s = FlagPhase.done true then _
            else if s = FlagPhase.done false then _ else none) = none
          rw [if_neg hd1, if_neg hd0])
  rw [← hrun] at hdisp
  refine ⟨hpre, hdisp.trans ?_⟩
  rw [hrun]
  refine Cfg.ext ?_ ?_ ?_ ?_ ?_
  · rw [Cfg.mapState_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.mapState_inputPos, Cfg.mapState_inputPos]
    rfl
  · funext j q
    rw [Cfg.mapState_workTapes, Cfg.mapState_workTapes]
    show (if j = ctrOuter ∧ _ ∧ _ then _ else _) = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      by_cases hq : (0 : ℤ) ≤ q ∧ q < 0 + ((w ++ [false]).length : ℤ)
      · rw [if_pos ⟨rfl, (by rw [hA_cp]; exact hq.1), (by rw [hA_cp]; exact hq.2)⟩,
          hB_c, hA_cp, sub_zero]
      · rw [if_neg (fun hcon => hq ⟨(by rw [← hA_cp]; exact hcon.2.1),
          (by rw [← hA_cp]; exact hcon.2.2)⟩), hA_c, hB_c]
        rcases (by omega : q < 0 ∨ ((w ++ [false]).length : ℤ) ≤ q) with hq' | hq'
        · rw [FinTM.bufferTape_of_neg _ hq', FinTM.bufferTape_of_neg _ hq']
        · rw [canonStageBuffer_none _ q hq', canonStageBuffer_none v q (by
            rw [hvlen]
            rw [hlapp] at hq'
            exact hq')]
    · rw [if_neg (fun hcon => hj2 hcon.1)]
      by_cases hj1 : j = header
      · subst hj1
        rw [hA_h, hB_h]
      · rw [(hA_o j hj1 hj2).1, (hB_o j hj1 hj2).1]
  · funext j
    rw [Cfg.mapState_workTapePos, Cfg.mapState_workTapePos]
    show (canonStageBank M header ctrOuter (some FlagPhase.run) ip
      (FinTM.bufferTape (w ++ [false])) 0 w).workTapePos j = _
    by_cases hj2 : j = ctrOuter
    · subst hj2
      rw [hA_cp, hB_cp]
    · by_cases hj1 : j = header
      · subst hj1
        rw [hA_hp, hB_hp]
      · rw [(hA_o j hj1 hj2).2, (hB_o j hj1 hj2).2]
  · rw [Cfg.mapState_output, Cfg.mapState_output]
    rfl


/-- **The stage front**: the counter preparation and the initial-state range
check, as one block over the stage's bank. The host runs seven framed catalog rows — copy
the header to the outer counter, skip past the copy, one step back, write the spare `false`
pad, skip past the pad, skip back over the padded word, increment (`incFixed` on the padded
copy never overflows) — and then the bounded unary reader C1, embedded by the forwarding
transformer, with both its ports dispatched to the parking phase. The block is silent,
preserves the header, leaves every tape but the outer counter as it found it, puts the
incremented header copy (of value `counterValue w + 1`) on the outer counter with its head
at the origin, exits by C1's verdict with a strict cut, and on success lands the native head
at the surviving suffix. C1's contract is a hypothesis, so the stage assembly can discharge
it at `exists_canonUnaryTM` within its own tape budget.

**Proof sketch.** The padded header copy increments without overflow (`incFixed` on it is `some v`,
of length `|w| + 1` and value `counterValue w + 1`). The seven legs (`canonStageLeg0`–`Leg6`) carry
the bank configuration from phase to phase, each with its lockstep window and dispatch. The
eighth phase is C1 embedded by the forwarding transformer (`embedEmitCfg_eq` for its start, its
contract for the run), and `phaseHostTM_run` dispatches both its ports to the parking phase. The
strict cut is `canonStageCut_leg` on each phase's window; the endpoint is the last leg's. -/
private lemma canonStageFrontSpec {M mU : ℕ} {SU : Type} [Fintype SU] [DecidableEq SU]
    (U : MultiTapeTM mU Bool SU) (ue : SU) (ux : Bool → SU) (uBound : Fin mU) (ua : ℕ)
    (uinj : Function.Injective ux)
    (unary : ∀ (x w : List Bool) (d : Cfg mU Bool SU x), d.state = some ue →
      1 ≤ d.inputPos.val →
      d.workTapes uBound = FinTM.bufferTape w → d.workTapePos uBound = 0 →
      (∀ j, j ≠ uBound → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0) →
      ∃ t ≤ ua * (x.length + w.length + 1),
        (U.runFrom d t).state =
          some (ux (codeSkipFin (counterValue w + 1)
            (x.drop (d.inputPos.val - 1))).isSome) ∧
        (U.runFrom d t).output = d.output ∧
        (∀ u < t, ∀ v, (U.runFrom d u).state ≠ some (ux v)) ∧
        (U.runFrom d t).workTapes = d.workTapes ∧
        (U.runFrom d t).workTapePos = d.workTapePos ∧
        ∀ ys, codeSkipFin (counterValue w + 1) (x.drop (d.inputPos.val - 1)) = some ys →
          (U.runFrom d t).inputPos.val = x.length + 1 - ys.length)
    (header ctrOuter : Fin M) (σ : Fin mU ↪ Fin M) (hσb : σ uBound = header)
    (hσc : ∀ i, σ i ≠ ctrOuter) (hhc : header ≠ ctrOuter) :
    ∃ (H : Type) (_ : Fintype H) (_ : DecidableEq H) (Fr : MultiTapeTM M Bool H)
      (entry : H) (exit : Bool → H) (A : ℕ), Function.Injective exit ∧
      ∀ (x w : List Bool) (d : Cfg M Bool H x), d.state = some entry → d.output = [] →
        1 ≤ d.inputPos.val →
        d.workTapes header = FinTM.bufferTape w → d.workTapePos header = 0 →
        (∀ j, j ≠ header → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0) →
        ∃ t ≤ A * (x.length + w.length + 1), ∃ u : List Bool,
          Nat.ofDigits 2 (u.map Bool.toNat) = counterValue w + 1 ∧
          u.length = w.length + 1 ∧
          (Fr.runFrom d t).state = some (exit (codeSkipFin (counterValue w + 1)
            (x.drop (d.inputPos.val - 1))).isSome) ∧
          (Fr.runFrom d t).output = [] ∧
          (∀ v < t, ∀ b, (Fr.runFrom d v).state ≠ some (exit b)) ∧
          (Fr.runFrom d t).workTapes header = FinTM.bufferTape w ∧
          (Fr.runFrom d t).workTapePos header = 0 ∧
          (Fr.runFrom d t).workTapes ctrOuter = FinTM.bufferTape u ∧
          (Fr.runFrom d t).workTapePos ctrOuter = 0 ∧
          (∀ j, j ≠ header → j ≠ ctrOuter →
            (Fr.runFrom d t).workTapes j = FinTM.bufferTape [] ∧
            (Fr.runFrom d t).workTapePos j = 0) ∧
          ∀ ys, codeSkipFin (counterValue w + 1) (x.drop (d.inputPos.val - 1)) = some ys →
            (Fr.runFrom d t).inputPos.val = x.length + 1 - ys.length := by
  classical
  letI : ∀ i, Fintype (canonStagePh SU i) := canonStagePh_fintype SU
  letI : ∀ i, DecidableEq (canonStagePh SU i) := canonStagePh_deceq SU
  refine ⟨Σ j, canonStagePh SU j, inferInstance, inferInstance,
    canonStageFr M mU SU U ue ux header ctrOuter σ,
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩, fun b => ⟨⟨8, by omega⟩, b⟩, ua + 33, ?_, ?_⟩
  · intro a b h
    exact eq_of_heq (Sigma.mk.inj_iff.mp h).2
  intro x w d hs hout hpos hht hhp hblank
  have hvsome : (incFixed (w ++ [false])).isSome = true := by
    rw [Option.isSome_iff_ne_none]
    intro hnone
    have hrep := (incFixed_eq_none_iff_replicate _).mp hnone
    have hmem : false ∈ w ++ [false] := List.mem_append_right _ (List.mem_singleton.mpr rfl)
    rw [hrep] at hmem
    exact Bool.noConfusion (List.eq_of_mem_replicate hmem)
  obtain ⟨v, hv⟩ := Option.isSome_iff_exists.mp hvsome
  have hlapp : (w ++ [false]).length = w.length + 1 := by
    rw [List.length_append]
    rfl
  have hvlen : v.length = w.length + 1 := by
    have h1 := incFixed_length hv
    rw [hlapp] at h1
    exact h1
  have hvval : Nat.ofDigits 2 (v.map Bool.toNat) = counterValue w + 1 := by
    rw [canonStageInc_value _ v hv, canonStagePad_value, ← counterValue_eq]
  obtain ⟨hB0h, hB0hp, hB0c, hB0cp, hB0o⟩ :=
    canonStageBank_fields M header ctrOuter hhc (x := x)
      (some SweepPhase.sweep) d.inputPos (FinTM.bufferTape []) 0 w
  obtain ⟨hB7h, hB7hp, hB7c, hB7cp, hB7o⟩ :=
    canonStageBank_fields M header ctrOuter hhc (x := x)
      (some ue) d.inputPos (FinTM.bufferTape v) 0 w
  have hstart : ((canonStageBank M header ctrOuter (some SweepPhase.sweep) d.inputPos
      (FinTM.bufferTape []) 0 w)).mapState
      (Sigma.mk (⟨0, by omega⟩ : Fin 9)) = d := by
    refine Cfg.ext ?_ ?_ ?_ ?_ ?_
    · rw [Cfg.mapState_state, hs]
      rfl
    · rw [Cfg.mapState_inputPos]
      rfl
    · funext j q
      rw [Cfg.mapState_workTapes]
      by_cases hj1 : j = header
      · subst hj1
        rw [hB0h, hht]
      · by_cases hj2 : j = ctrOuter
        · rw [hj2, hB0c, (hblank ctrOuter (fun h => hhc h.symm)).1]
        · rw [(hB0o j hj1 hj2).1, (hblank j hj1).1]
    · funext j
      rw [Cfg.mapState_workTapePos]
      by_cases hj1 : j = header
      · subst hj1
        rw [hB0hp, hhp]
      · by_cases hj2 : j = ctrOuter
        · rw [hj2, hB0cp, (hblank ctrOuter (fun h => hhc h.symm)).2]
        · rw [(hB0o j hj1 hj2).2, (hblank j hj1).2]
    · rw [Cfg.mapState_output, hout]
      rfl
  obtain ⟨hpre0, hop0⟩ := canonStageLeg0 U ue ux header ctrOuter σ hhc x w d.inputPos
  obtain ⟨hpre1, hop1⟩ := canonStageLeg1 U ue ux header ctrOuter σ hhc x w d.inputPos
  obtain ⟨hpre2, hop2⟩ := canonStageLeg2 U ue ux header ctrOuter σ hhc x w d.inputPos
  obtain ⟨hpre3, hop3⟩ := canonStageLeg3 U ue ux header ctrOuter σ hhc x w d.inputPos
  obtain ⟨hpre4, hop4⟩ := canonStageLeg4 U ue ux header ctrOuter σ hhc x w d.inputPos
  obtain ⟨hpre5, hop5⟩ := canonStageLeg5 U ue ux header ctrOuter σ hhc x w d.inputPos
  obtain ⟨hpre6, hop6⟩ := canonStageLeg6 U ue ux header ctrOuter σ hhc x w d.inputPos v hv
  have hhost1 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1)) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) d.inputPos
        (FinTM.bufferTape w) 0 w)).mapState (Sigma.mk (⟨1, by omega⟩ : Fin 9)) := by
    conv_lhs => rw [← hstart]
    exact hop0
  have hhost2 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1)) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) d.inputPos
        (FinTM.bufferTape w) (w.length + 1) w)).mapState (Sigma.mk (⟨2, by omega⟩ : Fin 9)) := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1))
      ((w.length + 1) + 1), hhost1]
    exact hop1
  have hhost3 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1)) =
      ((canonStageBank M header ctrOuter (some (WritePhase.wr 0) : Option (WritePhase 1)) d.inputPos
        (FinTM.bufferTape w) (w.length) w)).mapState (Sigma.mk (⟨3, by omega⟩ : Fin 9)) := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1))
      ((([] : List Bool).length + 1) + 1), hhost2]
    exact hop2
  have hhost4 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1)) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) d.inputPos
        (FinTM.bufferTape (w ++ [false])) (w.length) w)).mapState (Sigma.mk (⟨4, by omega⟩ : Fin 9))
            := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1))
      ((2 * ([false] : List Bool).length + 2) + 1), hhost3]
    exact hop3
  have hhost5 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1)) =
      ((canonStageBank M header ctrOuter (some SeekPhase.run) d.inputPos
        (FinTM.bufferTape (w ++ [false])) (w.length + 2) w)).mapState (Sigma.mk (⟨5, by omega⟩ : Fin
            9)) := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1))
      ((([false] : List Bool).length + 1) + 1), hhost4]
    exact hop4
  have hhost6 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1) + ((w ++
          [false]).length + 3 + 1)) =
      ((canonStageBank M header ctrOuter (some FlagPhase.run) d.inputPos
        (FinTM.bufferTape (w ++ [false])) 0 w)).mapState (Sigma.mk (⟨6, by omega⟩ : Fin 9)) := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1))
      (((w ++ [false]).length + 3) + 1), hhost5]
    exact hop5
  have hhost7 : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1) + ((w ++
          [false]).length + 3 + 1) + (2 * ((w ++ [false]).takeWhile id).length + 2 + 1)) =
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
        (FinTM.bufferTape v) 0 w)).mapState (Sigma.mk (⟨7, by omega⟩ : Fin 9)) := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1) + ((w ++
          [false]).length + 3 + 1))
      ((2 * ((w ++ [false]).takeWhile id).length + 2) + 1), hhost6]
    exact hop6
  -- leg 7: the embedded bounded unary reader
  set selU : Cfg mU Bool SU x := ⟨some ue, d.inputPos,
    fun i => (canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w).workTapes (σ i),
    fun i => (canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w).workTapePos (σ i), []⟩ with hselU
  have hsel : embedEmitCfg σ
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).output
      (selU) =
      (canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w) :=
    embedEmitCfg_eq σ _ _ _ _ _ rfl rfl (List.append_nil _)
      (fun _ => ⟨rfl, rfl⟩) (fun _ _ => ⟨rfl, rfl⟩)
  have hrun7 : ∀ tt : ℕ, (embedEmitTM σ U).runFrom
      (canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w) tt =
      embedEmitCfg σ
        ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes
        ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos
        ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).output
        (U.runFrom (selU) tt) := by
    intro tt
    conv_lhs => rw [← hsel]
    exact embedEmitTM_runFrom σ U _ _ _ _ tt
  have hσh : ∀ i, i ≠ uBound → σ i ≠ header := by
    intro i hi hcon
    exact hi (σ.injective (hcon.trans hσb.symm))
  obtain ⟨tU, htU, hUst, hUout, hUcut, hUtapes, hUheads, hUsfx⟩ := unary x w
    (selU)
    rfl hpos
    (by
      show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes (σ uBound) = _
      rw [hσb, hB7h])
    (by
      show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos (σ uBound) = _
      rw [hσb, hB7hp])
    (by
      intro j hj
      constructor
      · show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes (σ j) = _
        rw [(hB7o (σ j) (hσh j hj) (hσc j)).1]
      · show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos (σ j) = _
        rw [(hB7o (σ j) (hσh j hj) (hσc j)).2])
  obtain ⟨hpre7, hdisp7⟩ := phaseHostTM_run (canonStageFamily M mU SU U header ctrOuter σ)
    ⟨⟨0, by omega⟩, SweepPhase.sweep⟩ (canonStageRed SU ue ux)
    ⟨7, by omega⟩ _ _ tU (hrun7 tU)
    (ux (codeSkipFin (counterValue w + 1)
      (x.drop ((selU).inputPos.val - 1))).isSome)
    (by rw [embedEmitCfg_state]; exact hUst)
    ⟨⟨8, by omega⟩, (codeSkipFin (counterValue w + 1)
      (x.drop ((selU).inputPos.val - 1))).isSome⟩
    (by
      cases (codeSkipFin (counterValue w + 1)
        (x.drop ((selU).inputPos.val - 1))).isSome
      · show (if ux false = ux true
          then some (⟨⟨8, by omega⟩, true⟩ : Σ j, canonStagePh SU j)
          else if ux false = ux false
            then some (⟨⟨8, by omega⟩, false⟩ : Σ j, canonStagePh SU j) else none) =
          some (⟨⟨8, by omega⟩, false⟩ : Σ j, canonStagePh SU j)
        rw [if_neg (fun hcon => Bool.noConfusion (uinj hcon)), if_pos rfl]
      · show (if ux true = ux true
          then some (⟨⟨8, by omega⟩, true⟩ : Σ j, canonStagePh SU j)
          else if ux true = ux false
            then some (⟨⟨8, by omega⟩, false⟩ : Σ j, canonStagePh SU j) else none) =
          some (⟨⟨8, by omega⟩, true⟩ : Σ j, canonStagePh SU j)
        rw [if_pos rfl])
    (by
      intro u hu s hsu
      rw [hrun7 u, embedEmitCfg_state] at hsu
      have hsu' : (U.runFrom (selU) u).state = some s := hsu
      by_cases hd1 : s = ux true
      · rw [hd1] at hsu'
        exact absurd hsu' (hUcut u hu true)
      · by_cases hd0 : s = ux false
        · rw [hd0] at hsu'
          exact absurd hsu' (hUcut u hu false)
        · show (if s = ux true then _ else if s = ux false then _ else none) = none
          rw [if_neg hd1, if_neg hd0])
  rw [← hrun7 tU] at hdisp7
  have hfin : (canonStageFr M mU SU U ue ux header ctrOuter σ).runFrom d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1) + ((w ++
          [false]).length + 3 + 1) + (2 * ((w ++ [false]).takeWhile id).length + 2 + 1) + (tU + 1))
          =
      ((embedEmitTM σ U).runFrom (canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w) tU).mapState
        (fun _ => (⟨⟨8, by omega⟩, (codeSkipFin (counterValue w + 1)
          (x.drop ((selU).inputPos.val - 1))).isSome⟩ :
          Σ j, canonStagePh SU j)) := by
    rw [MultiTapeTM.runFrom_add d
      ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
          ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1) + ((w ++
          [false]).length + 3 + 1) + (2 * ((w ++ [false]).takeWhile id).length + 2 + 1))
      (tU + 1), hhost7]
    exact hdisp7
  refine ⟨(2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) + (2 *
      ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1 + 1) + ((w ++
      [false]).length + 3 + 1) + (2 * ((w ++ [false]).takeWhile id).length + 2 + 1) + (tU + 1), ?_,
      v, hvval, hvlen, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · -- the ledger
    have hTW : ((w ++ [false]).takeWhile id).length ≤ w.length + 1 := by
      have h1 := (List.takeWhile_sublist (l := w ++ [false]) id).length_le
      rw [hlapp] at h1
      exact h1
    have hn0 : ([] : List Bool).length = 0 := rfl
    have hn1 : ([false] : List Bool).length = 1 := rfl
    have hsplit : (ua + 33) * (x.length + w.length + 1) =
        ua * (x.length + w.length + 1) + 33 * (x.length + w.length + 1) := by ring
    have hexp : 33 * (x.length + w.length + 1) =
        33 * x.length + 33 * w.length + 33 := by ring
    omega
  · -- the exit state
    rw [hfin, Cfg.mapState_state, hrun7 tU, embedEmitCfg_state, hUst, Option.map_some]
  · -- the output
    rw [hfin, Cfg.mapState_output, hrun7 tU, embedEmitCfg_output, hUout]
    rfl
  · -- the cut
    intro vt hvt b
    by_cases h1 : vt ≤ 2 * w.length + 2
    · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
        (0) (2 * w.length + 2) ⟨0, by omega⟩ (by decide : (0 : ℕ) ≠ 8) _ _
        (by rw [MultiTapeTM.runFrom_zero]; exact hstart.symm) hpre0 vt (by omega)
        (by omega) b
    ·
      by_cases h2 : vt ≤ (2 * w.length + 2 + 1) + (w.length + 1)
      · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
          ((2 * w.length + 2 + 1)) (w.length + 1) ⟨1, by omega⟩ (by decide : (1 : ℕ) ≠ 8) _ _
          hhost1 hpre1 vt (by omega) (by omega) b
      ·
        by_cases h3 : vt ≤ (2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length +
            1)
        · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
            ((2 * w.length + 2 + 1) + (w.length + 1 + 1)) (([] : List Bool).length + 1) ⟨2, by
                omega⟩ (by decide : (2 : ℕ) ≠ 8) _ _
            hhost2 hpre2 vt (by omega) (by omega) b
        ·
          by_cases h4 : vt ≤ (2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length
              + 1 + 1) + (2 * ([false] : List Bool).length + 2)
          · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
              ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1)) (2 *
                  ([false] : List Bool).length + 2) ⟨3, by omega⟩ (by decide : (3 : ℕ) ≠ 8) _ _
              hhost3 hpre3 vt (by omega) (by omega) b
          ·
            by_cases h5 : vt ≤ (2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List
                Bool).length + 1 + 1) + (2 * ([false] : List Bool).length + 2 + 1) + (([false] :
                List Bool).length + 1)
            · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
                ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) +
                    (2 * ([false] : List Bool).length + 2 + 1)) (([false] : List Bool).length + 1)
                    ⟨4, by omega⟩ (by decide : (4 : ℕ) ≠ 8) _ _
                hhost4 hpre4 vt (by omega) (by omega) b
            ·
              by_cases h6 : vt ≤ (2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List
                  Bool).length + 1 + 1) + (2 * ([false] : List Bool).length + 2 + 1) + (([false] :
                  List Bool).length + 1 + 1) + ((w ++ [false]).length + 3)
              · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
                  ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1) +
                      (2 * ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length + 1
                      + 1)) ((w ++ [false]).length + 3) ⟨5, by omega⟩ (by decide : (5 : ℕ) ≠ 8) _ _
                  hhost5 hpre5 vt (by omega) (by omega) b
              ·
                by_cases h7 : vt ≤ (2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List
                    Bool).length + 1 + 1) + (2 * ([false] : List Bool).length + 2 + 1) + (([false] :
                    List Bool).length + 1 + 1) + ((w ++ [false]).length + 3 + 1) + (2 * ((w ++
                    [false]).takeWhile id).length + 2)
                · exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
                    ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1)
                        + (2 * ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length
                        + 1 + 1) + ((w ++ [false]).length + 3 + 1)) (2 * ((w ++ [false]).takeWhile
                        id).length + 2) ⟨6, by omega⟩ (by decide : (6 : ℕ) ≠ 8) _ _
                    hhost6 hpre6 vt (by omega) (by omega) b
                ·
                  exact canonStageCut_leg (canonStageFr M mU SU U ue ux header ctrOuter σ) d
                    ((2 * w.length + 2 + 1) + (w.length + 1 + 1) + (([] : List Bool).length + 1 + 1)
                        + (2 * ([false] : List Bool).length + 2 + 1) + (([false] : List Bool).length
                        + 1 + 1) + ((w ++ [false]).length + 3 + 1) + (2 * ((w ++ [false]).takeWhile
                        id).length + 2 + 1)) tU ⟨7, by omega⟩ (by decide : (7 : ℕ) ≠ 8) _ _
                    hhost7 hpre7 vt (by omega) (by omega) b
  · -- the header tape
    rw [hfin, hrun7 tU]
    have h1 := embedEmitCfg_selected_tape σ
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).output
      (U.runFrom (selU) tU) uBound
    rw [hσb] at h1
    funext q
    rw [Cfg.mapState_workTapes, congrFun h1 q, congrFun hUtapes uBound]
    show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes (σ uBound) q = _
    rw [hσb, hB7h]
  · -- the header head
    rw [hfin, hrun7 tU, Cfg.mapState_workTapePos]
    have h1 := embedEmitCfg_selected_pos σ
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos
      ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).output
      (U.runFrom (selU) tU) uBound
    rw [hσb] at h1
    rw [h1, congrFun hUheads uBound]
    show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos (σ uBound) = _
    rw [hσb, hB7hp]
  · -- the outer counter tape
    rw [hfin, hrun7 tU]
    funext q
    rw [Cfg.mapState_workTapes]
    rw [congrFun (embedEmitCfg_unselected σ _ _ _ _ ctrOuter
      (fun ⟨i, hi⟩ => hσc i hi)).1 q, hB7c]
  · -- the outer counter head
    rw [hfin, hrun7 tU, Cfg.mapState_workTapePos]
    rw [(embedEmitCfg_unselected σ _ _ _ _ ctrOuter (fun ⟨i, hi⟩ => hσc i hi)).2, hB7cp]
  · -- every other tape
    intro j hj1 hj2
    constructor
    · rw [hfin, hrun7 tU]
      funext q
      rw [Cfg.mapState_workTapes]
      by_cases hjr : j ∈ Set.range σ
      · obtain ⟨i, rfl⟩ := hjr
        rw [embedEmitCfg_selected_tape, congrFun hUtapes i]
        show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapes (σ i) q = _
        rw [(hB7o (σ i) hj1 hj2).1]
      · rw [congrFun (embedEmitCfg_unselected σ _ _ _ _ j hjr).1 q,
          (hB7o j hj1 hj2).1]
    · rw [hfin, hrun7 tU, Cfg.mapState_workTapePos]
      by_cases hjr : j ∈ Set.range σ
      · obtain ⟨i, rfl⟩ := hjr
        rw [embedEmitCfg_selected_pos, congrFun hUheads i]
        show ((canonStageBank M header ctrOuter (some ue) d.inputPos
      (FinTM.bufferTape v) 0 w)).workTapePos (σ i) = _
        rw [(hB7o (σ i) hj1 hj2).2]
      · rw [(embedEmitCfg_unselected σ _ _ _ _ j hjr).2, (hB7o j hj1 hj2).2]
  · -- the suffix clause
    intro ys hy
    rw [hfin, hrun7 tU, Cfg.mapState_inputPos, embedEmitCfg_inputPos]
    exact hUsfx ys hy

/-- The grammar stage's phase types: the stage front's host, the release-adapter-wrapped
embedded table block, the native suffix test, and the parking phase. -/
private def canonGramPh (HF H₃ : Type) : Fin 4 → Type := fun i =>
  match i with
  | ⟨0, _⟩ => HF
  | ⟨1, _⟩ => Unit ⊕ H₃
  | ⟨2, _⟩ => Option Bool
  | ⟨3, _⟩ => Bool
  | ⟨_ + 4, h⟩ => absurd h (by omega)

private def canonGramPh_fintype (HF H₃ : Type) [Fintype HF] [Fintype H₃] :
    ∀ i, Fintype (canonGramPh HF H₃ i) := fun i =>
  match i with
  | ⟨0, _⟩ => inferInstanceAs (Fintype HF)
  | ⟨1, _⟩ => inferInstanceAs (Fintype (Unit ⊕ H₃))
  | ⟨2, _⟩ => inferInstanceAs (Fintype (Option Bool))
  | ⟨3, _⟩ => inferInstanceAs (Fintype Bool)
  | ⟨_ + 4, h⟩ => absurd h (by omega)

private def canonGramPh_deceq (HF H₃ : Type) [DecidableEq HF] [DecidableEq H₃] :
    ∀ i, DecidableEq (canonGramPh HF H₃ i) := fun i =>
  match i with
  | ⟨0, _⟩ => inferInstanceAs (DecidableEq HF)
  | ⟨1, _⟩ => inferInstanceAs (DecidableEq (Unit ⊕ H₃))
  | ⟨2, _⟩ => inferInstanceAs (DecidableEq (Option Bool))
  | ⟨3, _⟩ => inferInstanceAs (DecidableEq Bool)
  | ⟨_ + 4, h⟩ => absurd h (by omega)

/-- The grammar stage's phase machines: the stage front, the release-adapter-wrapped
embedded table block, the native suffix test, and the parking machine. -/
private def canonGramFamily (M m₃ : ℕ) (HF H₃ : Type) (FrM : MultiTapeTM M Bool HF)
    (P : MultiTapeTM (m₃ + 2) Bool H₃) (anchor₃ : H₃) (ι₃ : Fin (m₃ + 2) ↪ Fin M) :
    (i : Fin 4) → MultiTapeTM M Bool (canonGramPh HF H₃ i) := fun i =>
  match i with
  | ⟨0, _⟩ => FrM
  | ⟨1, _⟩ => seamReleaseTM (embedEmitTM ι₃ P) anchor₃
  | ⟨2, _⟩ => canonSuffixTM M
  | ⟨3, _⟩ => canonStageHaltTM M
  | ⟨_ + 4, h⟩ => absurd h (by omega)

/-- The grammar stage's dispatch table: the front's two ports to the table and the park,
the table's return and escape ports, and the suffix test's verdict to the park. -/
private def canonGramRed (HF H₃ : Type) [DecidableEq HF] [DecidableEq H₃]
    (fexit : Bool → HF) (anchor₃ escape₃ : H₃) :
    (i : Fin 4) → canonGramPh HF H₃ i → Option (Σ j, canonGramPh HF H₃ j) :=
  letI : ∀ i, DecidableEq (canonGramPh HF H₃ i) := canonGramPh_deceq HF H₃
  fun i =>
  match i with
  | ⟨0, _⟩ => fun s => if s = fexit true
      then some ⟨⟨1, by omega⟩, Sum.inl ()⟩
      else if s = fexit false then some ⟨⟨3, by omega⟩, false⟩ else none
  | ⟨1, _⟩ => fun s => if s = Sum.inr anchor₃
      then some ⟨⟨2, by omega⟩, (none : Option Bool)⟩
      else if s = Sum.inr escape₃ then some ⟨⟨3, by omega⟩, false⟩ else none
  | ⟨2, _⟩ => fun s => match s with
      | some b => some ⟨⟨3, by omega⟩, b⟩
      | none => none
  | ⟨3, _⟩ => fun _ => none
  | ⟨_ + 4, h⟩ => absurd h (by omega)

/-- The grammar stage's host. -/
private def canonGramG (M m₃ : ℕ) (HF H₃ : Type) [DecidableEq HF] [DecidableEq H₃]
    (FrM : MultiTapeTM M Bool HF) (P : MultiTapeTM (m₃ + 2) Bool H₃)
    (anchor₃ escape₃ : H₃) (ι₃ : Fin (m₃ + 2) ↪ Fin M) (fentry : HF)
    (fexit : Bool → HF) : MultiTapeTM M Bool (Σ j, canonGramPh HF H₃ j) :=
  phaseHostTM (canonGramFamily M m₃ HF H₃ FrM P anchor₃ ι₃)
    ⟨⟨0, by omega⟩, fentry⟩ (canonGramRed HF H₃ fexit anchor₃ escape₃)

/-- One leg of the grammar stage's strict cut: while the host replays phase `i`, its
control carries phase `i`'s tag, which is not the parking tag. -/
private lemma canonGramCut_leg {M : ℕ} {HF H₃ : Type} {x : List Bool}
    (G : MultiTapeTM M Bool (Σ j, canonGramPh HF H₃ j))
    (d : Cfg M Bool (Σ j, canonGramPh HF H₃ j) x) (A B : ℕ) (i : Fin 4) (hi : i.val ≠ 3)
    (c : Cfg M Bool (canonGramPh HF H₃ i) x)
    (Mach : MultiTapeTM M Bool (canonGramPh HF H₃ i))
    (hhost : G.runFrom d A = c.mapState (Sigma.mk i))
    (hpre : ∀ u ≤ B, G.runFrom (c.mapState (Sigma.mk i)) u =
      (Mach.runFrom c u).mapState (Sigma.mk i))
    (vt : ℕ) (h1 : A ≤ vt) (h2 : vt ≤ A + B) (b : Bool) :
    (G.runFrom d vt).state ≠ some ⟨⟨3, by omega⟩, b⟩ := by
  rw [show vt = A + (vt - A) by omega, MultiTapeTM.runFrom_add, hhost,
    hpre (vt - A) (by omega), Cfg.mapState_state]
  cases hst : (Mach.runFrom c (vt - A)).state with
  | none =>
    rw [Option.map_none]
    exact fun hcon => Option.noConfusion hcon
  | some s =>
    rw [Option.map_some]
    intro hcon
    exact hi (congrArg (fun z : Σ j, canonGramPh HF H₃ j => z.1.val) (Option.some.inj hcon))

/-- A successful bounded unary skip returns a suffix of its input. -/
private lemma canonGramFin_suffix (n : ℕ) (xs ys : List Bool)
    (h : codeSkipFin n xs = some ys) : ys.IsSuffix xs := by
  rw [← codeEraseFin] at h
  obtain ⟨⟨q, r⟩, hread, hr⟩ := Option.map_eq_some_iff.mp h
  have hword := codeReadFin_sound xs q r hread
  exact ⟨unaryFin q, by rw [← (show r = ys from hr), hword]⟩

/-- The grammar stage's ledger: a front leg, a table leg and a suffix leg, each with its
dispatch step, fit under one polynomial exponent.

**Proof sketch.** Bound the three legs with their dispatch steps by `(2·AF + 9·A₃ + 8)·(X + 1)²`,
then raise the square to the common exponent (`pow_le_pow_right`, since `X + 1 ≥ 1`). -/
private lemma canonGramLedger (AF A₃ X t₁ t₂ t₃ : ℕ)
    (h₁ : t₁ ≤ AF * (2 * (X + 1))) (h₂ : t₂ ≤ A₃ * (3 * (X + 1)) ^ 2)
    (h₃ : t₃ ≤ X + 2) :
    t₁ + 1 + (t₂ + 1) + (t₃ + 1) ≤
      (2 * AF + 9 * A₃ + 8) * (X + 1) ^ (2 * AF + 9 * A₃ + 8) := by
  have hX : 1 ≤ X + 1 := by omega
  have hpow : (X + 1) ^ 2 ≤ (X + 1) ^ (2 * AF + 9 * A₃ + 8) :=
    Nat.pow_le_pow_right hX (by omega)
  have hstep : t₁ + 1 + (t₂ + 1) + (t₃ + 1) ≤ (2 * AF + 9 * A₃ + 8) * (X + 1) ^ 2 := by
    have e1 : AF * (2 * (X + 1)) ≤ 2 * AF * (X + 1) ^ 2 := by nlinarith
    have e2 : A₃ * (3 * (X + 1)) ^ 2 = 9 * A₃ * (X + 1) ^ 2 := by ring
    have e3 : X + 5 ≤ 8 * (X + 1) ^ 2 := by nlinarith
    have e4 : (2 * AF + 9 * A₃ + 8) * (X + 1) ^ 2 =
        2 * AF * (X + 1) ^ 2 + 9 * A₃ * (X + 1) ^ 2 + 8 * (X + 1) ^ 2 := by ring
    omega
  exact hstep.trans (Nat.mul_le_mul_left _ hpow)


/-- **The physical grammar stage.** Started on one bank whose tape `header` holds the
canonical binary header `bits` (head at the origin), every other tape blank, the native head
at the remainder's first cell and the output empty, it decides the fixed grammar on the
remainder with two distinct live exits, silently, within a polynomial bound that does not
depend on the header's numerical value.

**Proof sketch.** Copy the header to scratch counters as needed (framed copy rows; its value
`n` serves as the binary bound of every unary range check). Check the unary initial state
below `n + 1`; run one public counter loop over the `n + 1` states, each of `3^(k+1)`
records, with the generic record validator as its body; check the all-`true` suffix to the
right input blank. Every record consumes at least `4k + 5` cells and every round fails fast
on input exhaustion, so at most `|x| + 1` rounds run, each charged `O(|x| + |bits|)`.

**Implementation.** A four-phase host joins the stage front, the table block (embedded by the
forwarding transformer and wrapped by the release adapter), the suffix test and a parking
phase. The front copies the header to the outer counter, pads the copy with a spare `false`
and increments it, so that the outer counter holds `n + 1` without overflow, and then runs the
bounded unary reader on the header.
The table block is an outer public counter loop over `n + 1` inner blocks; an inner block
writes a fresh inner counter of `3^(k+1)` and runs an inner public counter loop of record
rounds. Each loop's body is a first-return round (the fresh-anchor adapter), and the loop
contracts are composed from the repetition orbit (`canonRepeat_orbit`) and the public done and
escape contracts. Every completed inner block consumes input, so at most `|x| + 1` outer rounds
run whatever the value of `n`. -/
private lemma exists_canonGrammarStage (F : MachineFormat) :
    ∃ (m : ℕ) (S : Type) (_ : Fintype S) (_ : DecidableEq S) (G : MultiTapeTM m Bool S)
      (entry : S) (exit : Bool → S) (a : ℕ) (header : Fin m), Function.Injective exit ∧
      ∀ (x bits rest : List Bool), pairDecode x = some (bits, rest) →
        bits = (codeBitsNat bits).bits →
        canonGuardBlock F * (codeBitsNat bits + 1) ≤ rest.length →
        ∀ d : Cfg m Bool S x, d.state = some entry → d.output = [] →
          d.inputPos.val = 2 * bits.length + 3 →
          d.workTapes header = FinTM.bufferTape bits → d.workTapePos header = 0 →
          (∀ j, j ≠ header → d.workTapes j = FinTM.bufferTape [] ∧ d.workTapePos j = 0) →
          ∃ t ≤ a * (x.length + 1) ^ a,
            (G.runFrom d t).state =
              some (exit (canonGrammar F.k (codeBitsNat bits) rest).isSome) ∧
            (G.runFrom d t).output = [] ∧
            ∀ u < t, ∀ v, (G.runFrom d u).state ≠ some (exit v) := by
  classical
  obtain ⟨mU, SU, fSU, dSU, Uu, ue, ux, uBound, ua, uinj, unary⟩ := exists_canonUnaryTM
  letI : Fintype SU := fSU
  letI : DecidableEq SU := dSU
  obtain ⟨m₃, H₃, fH₃, dH₃, P, anchor₃, escape₃, bound₃, A₃, diff₃, spec₃⟩ :=
    canonStageOuterSpec F.k
  letI : Fintype H₃ := fH₃
  letI : DecidableEq H₃ := dH₃
  set ι₃ : Fin (m₃ + 2) ↪ Fin ((m₃ + 2) + mU) := Fin.castLEEmb (by omega) with hι₃
  have hhc : ι₃ (bound₃.castSucc.castSucc) ≠ ι₃ (Fin.last (m₃ + 1)) := by
    intro hcon
    have v := congrArg Fin.val hcon
    have h1 : (ι₃ (bound₃.castSucc.castSucc)).val = bound₃.val := rfl
    have h2 : (ι₃ (Fin.last (m₃ + 1))).val = m₃ + 1 := rfl
    have hb := bound₃.isLt
    omega
  set σU : Fin mU ↪ Fin ((m₃ + 2) + mU) := ⟨fun i =>
    if i = uBound then ⟨bound₃.val, by have := bound₃.isLt; omega⟩
    else ⟨(m₃ + 2) + i.val, by have := i.isLt; omega⟩, by
    intro i j h
    by_cases hi : i = uBound <;> by_cases hj : j = uBound
    · exact hi.trans hj.symm
    · have v := congrArg Fin.val h
      simp only [if_pos hi, if_neg hj] at v
      have hb := bound₃.isLt
      omega
    · have v := congrArg Fin.val h
      simp only [if_neg hi, if_pos hj] at v
      have hb := bound₃.isLt
      omega
    · have v := congrArg Fin.val h
      simp only [if_neg hi, if_neg hj] at v
      exact Fin.ext (by omega)⟩ with hσU
  have hσb : σU uBound = ι₃ (bound₃.castSucc.castSucc) := by
    show (if uBound = uBound then _ else _) = _
    rw [if_pos rfl]
    exact Fin.ext rfl
  have hσc : ∀ i, σU i ≠ ι₃ (Fin.last (m₃ + 1)) := by
    intro i hcon
    have v := congrArg Fin.val hcon
    have hlast : (ι₃ (Fin.last (m₃ + 1))).val = m₃ + 1 := rfl
    have hb := bound₃.isLt
    have hiu := i.isLt
    by_cases hi : i = uBound
    · simp only [σU, Function.Embedding.coeFn_mk, if_pos hi] at v
      omega
    · simp only [σU, Function.Embedding.coeFn_mk, if_neg hi] at v
      omega
  obtain ⟨HF, fHF, dHF, FrM, fentry, fexit, AF, finj, front⟩ :=
    canonStageFrontSpec Uu ue ux uBound ua uinj unary
      (ι₃ (bound₃.castSucc.castSucc)) (ι₃ (Fin.last (m₃ + 1))) σU hσb hσc hhc
  letI : Fintype HF := fHF
  letI : DecidableEq HF := dHF
  letI : ∀ i, Fintype (canonGramPh HF H₃ i) := canonGramPh_fintype HF H₃
  letI : ∀ i, DecidableEq (canonGramPh HF H₃ i) := canonGramPh_deceq HF H₃
  refine ⟨(m₃ + 2) + mU, Σ j, canonGramPh HF H₃ j, inferInstance, inferInstance,
    canonGramG ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ escape₃ ι₃ fentry fexit,
    ⟨⟨0, by omega⟩, fentry⟩, fun b => ⟨⟨3, by omega⟩, b⟩, 2 * AF + 9 * A₃ + 8,
    ι₃ (bound₃.castSucc.castSucc), ?_, ?_⟩
  · intro a b h
    exact eq_of_heq (Sigma.mk.inj_iff.mp h).2
  intro x bits rest hp hcanon hguard d hs hout hpos hht hhp hblank
  set G := canonGramG ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ escape₃ ι₃ fentry fexit
    with hG
  -- the decoded geometry and the value bridge
  have hn : counterValue bits = codeBitsNat bits := by
    rw [counterValue_eq, codeBitsNat_eq, ← foldr_bit_eq_ofDigits]
  have hx : x = pairEncode bits rest := eq_pairEncode_of_pairDecode x bits rest hp
  have hxlen : x.length = 2 * bits.length + 2 + rest.length := by
    rw [hx, length_pairEncode]
  have hsfx : rest.IsSuffix x := ⟨dbl bits ++ [false, true], by
    rw [hx, pairEncode_eq_dbl]⟩
  -- the front's leg, from the stub's entry bank
  set c₀ : Cfg ((m₃ + 2) + mU) Bool HF x :=
    ⟨some fentry, d.inputPos, d.workTapes, d.workTapePos, d.output⟩ with hc₀def
  have hc₀ : c₀.mapState (Sigma.mk (⟨0, by omega⟩ : Fin 4)) = d := by
    refine Cfg.ext ?_ (Cfg.mapState_inputPos _ _) ?_ ?_ (Cfg.mapState_output _ _)
    · rw [Cfg.mapState_state, hs]
      rfl
    · funext j z
      rw [Cfg.mapState_workTapes]
    · funext j
      rw [Cfg.mapState_workTapePos]
  have hc₀pos : c₀.inputPos.val = 2 * bits.length + 3 := hpos
  have hdrop0 : x.drop (c₀.inputPos.val - 1) = rest := by
    have h2 : x.length - rest.length = 2 * bits.length + 2 := by omega
    have h3 := canonStageSuffix_drop x rest hsfx
    rw [h2] at h3
    rw [show c₀.inputPos.val - 1 = 2 * bits.length + 2 by omega]
    exact h3
  obtain ⟨tF, htF, u, huval, hulen, hFst, hFout, hFcut, hFht, hFhp, hFct, hFcp, hFblank,
    hFsfx⟩ := front x bits c₀ rfl hout (by omega) hht hhp hblank
  set cF : Cfg ((m₃ + 2) + mU) Bool HF x := FrM.runFrom c₀ tF with hcF
  rw [hdrop0, hn] at hFst hFsfx
  -- the front's verdict dichotomy
  cases hskf : codeSkipFin (codeBitsNat bits + 1) rest with
  | none =>
    -- the unary range check fails: dispatch to the park with the reject verdict
    rw [hskf] at hFst
    simp only [Option.isSome_none] at hFst
    obtain ⟨hpre0, hdisp0⟩ := phaseHostTM_run
      (canonGramFamily ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ ι₃)
      ⟨⟨0, by omega⟩, fentry⟩ (canonGramRed HF H₃ fexit anchor₃ escape₃)
      ⟨0, by omega⟩ c₀ cF tF hcF.symm (fexit false) hFst
      ⟨⟨3, by omega⟩, false⟩
      (by
        show (if fexit false = fexit true
            then some (⟨⟨1, by omega⟩, Sum.inl ()⟩ : Σ j, canonGramPh HF H₃ j)
            else if fexit false = fexit false
              then some (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j) else none) =
          some (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j)
        rw [if_neg (fun hcon => Bool.noConfusion (finj hcon)), if_pos rfl])
      (by
        intro uu huu s hsu
        show (if s = fexit true then _ else if s = fexit false then _ else none) = none
        by_cases h1 : s = fexit true
        · subst h1
          exact absurd hsu (hFcut uu huu true)
        · by_cases h0 : s = fexit false
          · subst h0
            exact absurd hsu (hFcut uu huu false)
          · rw [if_neg h1, if_neg h0])
    have hfin : G.runFrom d (tF + 1) =
        cF.mapState (fun _ => (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j)) := by
      conv_lhs => rw [← hc₀]
      exact hdisp0
    refine ⟨tF + 1, ?_, ?_, ?_, ?_⟩
    · have hb1 : tF ≤ AF * (2 * (x.length + 1)) :=
        htF.trans (Nat.mul_le_mul le_rfl (by omega))
      have hled := canonGramLedger AF A₃ x.length tF 0 0 hb1 (Nat.zero_le _) (by omega)
      exact le_trans (by omega) hled
    · rw [hfin, Cfg.mapState_state, hFst, Option.map_some]
      have hcg : canonGrammar F.k (codeBitsNat bits) rest = none := by
        show ((codeSkipFin (codeBitsNat bits + 1) rest).bind
          (codeSkipTableK F.k (codeBitsNat bits))).bind
          (fun tail => if tail.all id then some tail else none) = none
        rw [hskf]
        rfl
      rw [hcg]
      rfl
    · rw [hfin, Cfg.mapState_output]
      exact hFout
    · intro vt hvt b
      exact canonGramCut_leg G d 0 tF ⟨0, by omega⟩ (by decide : (0 : ℕ) ≠ 3) _ _
        (by rw [MultiTapeTM.runFrom_zero]; exact hc₀.symm) hpre0 vt (by omega) (by omega) b
  | some ys₁ =>
    -- the unary check passes: the front hands its bank to the embedded table
    rw [hskf] at hFst
    simp only [Option.isSome_some] at hFst
    have hsfx1 : ys₁.IsSuffix x := (canonGramFin_suffix _ rest ys₁ hskf).trans hsfx
    have hys1len : ys₁.length ≤ x.length := hsfx1.length_le
    have hposF : cF.inputPos.val = x.length + 1 - ys₁.length := hFsfx ys₁ hskf
    have hdropF : x.drop (cF.inputPos.val - 1) = ys₁ := by
      have h1 : cF.inputPos.val - 1 = x.length - ys₁.length := by omega
      rw [h1]
      exact canonStageSuffix_drop x ys₁ hsfx1
    obtain ⟨hpre0, hdisp0⟩ := phaseHostTM_run
      (canonGramFamily ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ ι₃)
      ⟨⟨0, by omega⟩, fentry⟩ (canonGramRed HF H₃ fexit anchor₃ escape₃)
      ⟨0, by omega⟩ c₀ cF tF hcF.symm (fexit true) hFst
      ⟨⟨1, by omega⟩, Sum.inl ()⟩
      (by
        show (if fexit true = fexit true
            then some (⟨⟨1, by omega⟩, Sum.inl ()⟩ : Σ j, canonGramPh HF H₃ j)
            else if fexit true = fexit false
              then some (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j) else none) =
          some (⟨⟨1, by omega⟩, Sum.inl ()⟩ : Σ j, canonGramPh HF H₃ j)
        rw [if_pos rfl])
      (by
        intro uu huu s hsu
        show (if s = fexit true then _ else if s = fexit false then _ else none) = none
        by_cases h1 : s = fexit true
        · subst h1
          exact absurd hsu (hFcut uu huu true)
        · by_cases h0 : s = fexit false
          · subst h0
            exact absurd hsu (hFcut uu huu false)
          · rw [if_neg h1, if_neg h0])
    have hhost1 : G.runFrom d (tF + 1) =
        cF.mapState (fun _ => (⟨⟨1, by omega⟩, Sum.inl ()⟩ : Σ j, canonGramPh HF H₃ j)) := by
      conv_lhs => rw [← hc₀]
      exact hdisp0
    -- the table's bank, selected through the embedding
    set cA : Cfg ((m₃ + 2) + mU) Bool H₃ x := cF.mapState (fun _ => anchor₃) with hcA
    have hcAst : cA.state = some anchor₃ := by
      rw [hcA, Cfg.mapState_state, hFst, Option.map_some]
    set sel : Cfg (m₃ + 2) Bool H₃ x := ⟨some anchor₃, cF.inputPos,
      fun i => cF.workTapes (ι₃ i), fun i => cF.workTapePos (ι₃ i), []⟩ with hsel
    have hselst : sel.state = some anchor₃ := rfl
    have hselpos : sel.inputPos.val = cF.inputPos.val := rfl
    obtain ⟨τ₃, hτ₃⟩ := spec₃ x bits u huval
    have hbank : sel.output = [] ∧ 1 ≤ sel.inputPos.val ∧
        sel.workTapes bound₃.castSucc.castSucc = FinTM.bufferTape bits ∧
        sel.workTapePos bound₃.castSucc.castSucc = 0 ∧
        (∀ j : Fin m₃, j ≠ bound₃ →
          sel.workTapes j.castSucc.castSucc = FinTM.bufferTape [] ∧
          sel.workTapePos j.castSucc.castSucc = 0) ∧
        (∀ q : ℤ, q < 0 ∨ ((3 ^ (F.k + 1) : ℕ).bits.length : ℤ) ≤ q →
          sel.workTapes (Fin.last m₃).castSucc q = none) ∧
        sel.workTapePos (Fin.last m₃).castSucc = 0 ∧
        sel.workTapes (Fin.last (m₃ + 1)) = FinTM.bufferTape u ∧
        sel.workTapePos (Fin.last (m₃ + 1)) = 0 := by
      have hne3 : ι₃ ((Fin.last m₃).castSucc) ≠ ι₃ (bound₃.castSucc.castSucc) := by
        intro hcon
        have hv := congrArg Fin.val (ι₃.injective hcon)
        simp only [Fin.coe_castSucc, Fin.val_last] at hv
        have := bound₃.isLt
        omega
      have hne4 : ι₃ ((Fin.last m₃).castSucc) ≠ ι₃ (Fin.last (m₃ + 1)) := by
        intro hcon
        have hv := congrArg Fin.val (ι₃.injective hcon)
        simp only [Fin.coe_castSucc, Fin.val_last] at hv
        omega
      refine ⟨rfl, by omega, hFht, hFhp, ?_, ?_, ?_, hFct, hFcp⟩
      · intro j hj
        have hne1 : ι₃ (j.castSucc.castSucc) ≠ ι₃ (bound₃.castSucc.castSucc) := by
          intro hcon
          have hv := congrArg Fin.val (ι₃.injective hcon)
          simp only [Fin.coe_castSucc] at hv
          exact hj (Fin.ext hv)
        have hne2 : ι₃ (j.castSucc.castSucc) ≠ ι₃ (Fin.last (m₃ + 1)) := by
          intro hcon
          have hv := congrArg Fin.val (ι₃.injective hcon)
          simp only [Fin.coe_castSucc, Fin.val_last] at hv
          have := j.isLt
          omega
        exact ⟨(hFblank _ hne1 hne2).1, (hFblank _ hne1 hne2).2⟩
      · intro q hq
        show cF.workTapes (ι₃ ((Fin.last m₃).castSucc)) q = none
        rw [(hFblank _ hne3 hne4).1]
        simp
      · exact (hFblank _ hne3 hne4).2
    obtain ⟨hpos₃, hbound₃, hint₃, hst₃, hout₃, hys₃⟩ := hτ₃ sel hbank hselst
    have hdropsel : x.drop (sel.inputPos.val - 1) = ys₁ := hdropF
    rw [hdropsel, hn] at hst₃ hys₃
    -- the embedded table's run and the release adapter's transport
    have hembA : embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output sel = cA := by
      refine embedEmitCfg_eq ι₃ cA.workTapes cA.workTapePos cA.output sel cA
        hcAst.symm ?_ ?_ ?_ (fun _ _ => ⟨rfl, rfl⟩)
      · rw [hcA, Cfg.mapState_inputPos]
      · rw [hcA, Cfg.mapState_output, hFout, List.nil_append]
      · intro i
        constructor
        · funext z
          rw [hcA, Cfg.mapState_workTapes]
        · rw [hcA, Cfg.mapState_workTapePos]
    have hErun : ∀ tt : ℕ, (embedEmitTM ι₃ P).runFrom cA tt =
        embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output (P.runFrom sel tt) := by
      intro tt
      conv_lhs => rw [← hembA]
      exact embedEmitTM_runFrom ι₃ P _ _ _ _ tt
    have hc1 : cF.mapState (fun _ => (⟨⟨1, by omega⟩, Sum.inl ()⟩ :
        Σ j, canonGramPh HF H₃ j)) =
        (cA.mapState (fun _ => (Sum.inl () : Unit ⊕ H₃))).mapState
          (Sigma.mk (⟨1, by omega⟩ : Fin 4)) := by
      rw [hcA, Cfg.mapState_mapState, Cfg.mapState_mapState]; rfl
    -- the table's verdict dichotomy
    cases htab : codeSkipTableK F.k (codeBitsNat bits) ys₁ with
    | some ys₂ =>
      -- every record skips: the release returns and the suffix test decides
      have hstA : (P.runFrom sel (τ₃ sel)).state = some anchor₃ := by
        rw [hst₃, htab]
        rfl
      obtain ⟨g1, g2, g3⟩ := hys₃ ys₂ htab
      obtain ⟨hrel, hrelcut⟩ := seamReleaseTM_firstReturn (embedEmitTM ι₃ P) anchor₃
        hcAst hpos₃ (hErun (τ₃ sel))
        (by rw [embedEmitCfg_state]; exact hstA)
        (by
          intro t ht1 ht2
          rw [hErun t, embedEmitCfg_state]
          obtain ⟨q, hq, hqa, hqe⟩ := hint₃ t ht1 ht2
          rw [hq]
          intro hcon
          exact hqa (Option.some.inj hcon))
      obtain ⟨hpre1, hdisp1⟩ := phaseHostTM_run
        (canonGramFamily ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ ι₃)
        ⟨⟨0, by omega⟩, fentry⟩ (canonGramRed HF H₃ fexit anchor₃ escape₃)
        ⟨1, by omega⟩ (cA.mapState (fun _ => (Sum.inl () : Unit ⊕ H₃)))
        ((embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
          (P.runFrom sel (τ₃ sel))).mapState (Sum.inr : H₃ → Unit ⊕ H₃)) (τ₃ sel) hrel
        (Sum.inr anchor₃)
        (by rw [Cfg.mapState_state, embedEmitCfg_state, hstA, Option.map_some])
        ⟨⟨2, by omega⟩, (none : Option Bool)⟩
        (by
          show (if (Sum.inr anchor₃ : Unit ⊕ H₃) = Sum.inr anchor₃
              then some (⟨⟨2, by omega⟩, (none : Option Bool)⟩ : Σ j, canonGramPh HF H₃ j)
              else if (Sum.inr anchor₃ : Unit ⊕ H₃) = Sum.inr escape₃
                then some (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j) else none) =
            some (⟨⟨2, by omega⟩, (none : Option Bool)⟩ : Σ j, canonGramPh HF H₃ j)
          rw [if_pos rfl])
        (by
          intro uu huu s hsu
          show (if s = Sum.inr anchor₃ then _
            else if s = Sum.inr escape₃ then _ else none) = none
          rcases Nat.eq_zero_or_pos uu with huz | hupos
          · subst huz
            rw [MultiTapeTM.runFrom_zero, Cfg.mapState_state, hcAst,
              Option.map_some] at hsu
            obtain rfl : s = Sum.inl () := (Option.some.inj hsu).symm
            rw [if_neg (fun hcon => Sum.noConfusion hcon),
              if_neg (fun hcon => Sum.noConfusion hcon)]
          · rw [seamReleaseTM_runFrom_pos (embedEmitTM ι₃ P) anchor₃ cA hcAst uu hupos,
              Cfg.mapState_state, hErun uu, embedEmitCfg_state] at hsu
            obtain ⟨q, hq, hqa, hqe⟩ := hint₃ uu hupos huu
            rw [hq, Option.map_some] at hsu
            obtain rfl : s = Sum.inr q := (Option.some.inj hsu).symm
            rw [if_neg (fun hcon => hqa (Sum.inr.inj hcon)),
              if_neg (fun hcon => hqe (Sum.inr.inj hcon))])
      have hhost2 : G.runFrom d ((tF + 1) + (τ₃ sel + 1)) =
          ((embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
            (P.runFrom sel (τ₃ sel))).mapState (Sum.inr : H₃ → Unit ⊕ H₃)).mapState
            (fun _ => (⟨⟨2, by omega⟩, (none : Option Bool)⟩ : Σ j, canonGramPh HF H₃ j)) := by
        rw [MultiTapeTM.runFrom_add d (tF + 1) (τ₃ sel + 1), hhost1, hc1]
        exact hdisp1
      -- the suffix test's leg
      set cT : Cfg ((m₃ + 2) + mU) Bool (Option Bool) x :=
        (embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
          (P.runFrom sel (τ₃ sel))).mapState (fun _ => (none : Option Bool)) with hcT
      have hc2 : ((embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
          (P.runFrom sel (τ₃ sel))).mapState (Sum.inr : H₃ → Unit ⊕ H₃)).mapState
          (fun _ => (⟨⟨2, by omega⟩, (none : Option Bool)⟩ : Σ j, canonGramPh HF H₃ j)) =
          cT.mapState (Sigma.mk (⟨2, by omega⟩ : Fin 4)) := by
        rw [hcT, Cfg.mapState_mapState, Cfg.mapState_mapState]; rfl
      have hcTst : cT.state = some none := by
        rw [hcT, Cfg.mapState_state, embedEmitCfg_state, hstA, Option.map_some]
      have hcTpos : cT.inputPos.val = (P.runFrom sel (τ₃ sel)).inputPos.val := by
        rw [hcT, Cfg.mapState_inputPos, embedEmitCfg_inputPos]
      obtain ⟨tS, htS, hSst, hSout, hStapes, hSheads, hScut⟩ := canonSuffix_run cT hcTst
        (by omega)
      have hdropT : x.drop (cT.inputPos.val - 1) = ys₂ := by
        rw [hcTpos]
        exact g3
      rw [hdropT] at hSst htS
      obtain ⟨hpre2, hdisp2⟩ := phaseHostTM_run
        (canonGramFamily ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ ι₃)
        ⟨⟨0, by omega⟩, fentry⟩ (canonGramRed HF H₃ fexit anchor₃ escape₃)
        ⟨2, by omega⟩ cT ((canonSuffixTM ((m₃ + 2) + mU)).runFrom cT tS) tS rfl
        (some (ys₂.all id)) hSst ⟨⟨3, by omega⟩, ys₂.all id⟩ rfl
        (by
          intro uu huu s hsu
          cases s with
          | none => rfl
          | some bit => exact absurd hsu (hScut uu huu bit))
      have hhost3 : G.runFrom d ((tF + 1) + (τ₃ sel + 1) + (tS + 1)) =
          ((canonSuffixTM ((m₃ + 2) + mU)).runFrom cT tS).mapState
            (fun _ => (⟨⟨3, by omega⟩, ys₂.all id⟩ : Σ j, canonGramPh HF H₃ j)) := by
        rw [MultiTapeTM.runFrom_add d ((tF + 1) + (τ₃ sel + 1)) (tS + 1), hhost2, hc2]
        exact hdisp2
      have hys2len : ys₂.length ≤ x.length := by
        have h := congrArg List.length g3
        rw [List.length_drop] at h
        omega
      refine ⟨(tF + 1) + (τ₃ sel + 1) + (tS + 1), ?_, ?_, ?_, ?_⟩
      · have hb1 : tF ≤ AF * (2 * (x.length + 1)) :=
          htF.trans (Nat.mul_le_mul le_rfl (by omega))
        have hb2 : τ₃ sel ≤ A₃ * (3 * (x.length + 1)) ^ 2 :=
          hbound₃.trans (Nat.mul_le_mul le_rfl (Nat.pow_le_pow_left (by omega) 2))
        have hb3 : tS ≤ x.length + 2 := by omega
        exact canonGramLedger AF A₃ x.length tF (τ₃ sel) tS hb1 hb2 hb3
      · rw [hhost3, Cfg.mapState_state, hSst, Option.map_some]
        have hcg : canonGrammar F.k (codeBitsNat bits) rest =
            if ys₂.all id then some ys₂ else none := by
          show ((codeSkipFin (codeBitsNat bits + 1) rest).bind
            (codeSkipTableK F.k (codeBitsNat bits))).bind
            (fun tail => if tail.all id then some tail else none) =
            if ys₂.all id then some ys₂ else none
          rw [hskf]
          show (codeSkipTableK F.k (codeBitsNat bits) ys₁).bind
            (fun tail => if tail.all id then some tail else none) =
            if ys₂.all id then some ys₂ else none
          rw [htab]
          rfl
        rw [hcg]
        cases hall : ys₂.all id <;> rfl
      · rw [hhost3, Cfg.mapState_output, hSout, hcT, Cfg.mapState_output,
          embedEmitCfg_output, g1, List.append_nil, hcA, Cfg.mapState_output]
        exact hFout
      · intro vt hvt b
        by_cases h1 : vt ≤ tF
        · exact canonGramCut_leg G d 0 tF ⟨0, by omega⟩ (by decide : (0 : ℕ) ≠ 3) _ _
            (by rw [MultiTapeTM.runFrom_zero]; exact hc₀.symm) hpre0 vt (by omega)
            (by omega) b
        · by_cases h2 : vt ≤ (tF + 1) + τ₃ sel
          · exact canonGramCut_leg G d (tF + 1) (τ₃ sel) ⟨1, by omega⟩
              (by decide : (1 : ℕ) ≠ 3) _ _ (by rw [hhost1, hc1]) hpre1 vt (by omega)
              (by omega) b
          · exact canonGramCut_leg G d ((tF + 1) + (τ₃ sel + 1)) tS ⟨2, by omega⟩
              (by decide : (2 : ℕ) ≠ 3) _ _ (by rw [hhost2, hc2]) hpre2 vt (by omega)
              (by omega) b
    | none =>
      -- some record fails: the release escapes and the park holds the reject verdict
      have hstE : (P.runFrom sel (τ₃ sel)).state = some escape₃ := by
        rw [hst₃, htab]
        rfl
      have hrelE : (seamReleaseTM (embedEmitTM ι₃ P) anchor₃).runFrom
          (cA.mapState (fun _ => (Sum.inl () : Unit ⊕ H₃))) (τ₃ sel) =
          (embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
            (P.runFrom sel (τ₃ sel))).mapState (Sum.inr : H₃ → Unit ⊕ H₃) := by
        rw [seamReleaseTM_runFrom_pos (embedEmitTM ι₃ P) anchor₃ cA hcAst (τ₃ sel) hpos₃,
          hErun (τ₃ sel)]
      obtain ⟨hpre1, hdisp1⟩ := phaseHostTM_run
        (canonGramFamily ((m₃ + 2) + mU) m₃ HF H₃ FrM P anchor₃ ι₃)
        ⟨⟨0, by omega⟩, fentry⟩ (canonGramRed HF H₃ fexit anchor₃ escape₃)
        ⟨1, by omega⟩ (cA.mapState (fun _ => (Sum.inl () : Unit ⊕ H₃)))
        ((embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
          (P.runFrom sel (τ₃ sel))).mapState (Sum.inr : H₃ → Unit ⊕ H₃)) (τ₃ sel) hrelE
        (Sum.inr escape₃)
        (by rw [Cfg.mapState_state, embedEmitCfg_state, hstE, Option.map_some])
        ⟨⟨3, by omega⟩, false⟩
        (by
          show (if (Sum.inr escape₃ : Unit ⊕ H₃) = Sum.inr anchor₃
              then some (⟨⟨2, by omega⟩, (none : Option Bool)⟩ : Σ j, canonGramPh HF H₃ j)
              else if (Sum.inr escape₃ : Unit ⊕ H₃) = Sum.inr escape₃
                then some (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j) else none) =
            some (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j)
          rw [if_neg (fun hcon => diff₃ (Sum.inr.inj hcon)), if_pos rfl])
        (by
          intro uu huu s hsu
          show (if s = Sum.inr anchor₃ then _
            else if s = Sum.inr escape₃ then _ else none) = none
          rcases Nat.eq_zero_or_pos uu with huz | hupos
          · subst huz
            rw [MultiTapeTM.runFrom_zero, Cfg.mapState_state, hcAst,
              Option.map_some] at hsu
            obtain rfl : s = Sum.inl () := (Option.some.inj hsu).symm
            rw [if_neg (fun hcon => Sum.noConfusion hcon),
              if_neg (fun hcon => Sum.noConfusion hcon)]
          · rw [seamReleaseTM_runFrom_pos (embedEmitTM ι₃ P) anchor₃ cA hcAst uu hupos,
              Cfg.mapState_state, hErun uu, embedEmitCfg_state] at hsu
            obtain ⟨q, hq, hqa, hqe⟩ := hint₃ uu hupos huu
            rw [hq, Option.map_some] at hsu
            obtain rfl : s = Sum.inr q := (Option.some.inj hsu).symm
            rw [if_neg (fun hcon => hqa (Sum.inr.inj hcon)),
              if_neg (fun hcon => hqe (Sum.inr.inj hcon))])
      have hhost2 : G.runFrom d ((tF + 1) + (τ₃ sel + 1)) =
          ((embedEmitCfg ι₃ cA.workTapes cA.workTapePos cA.output
            (P.runFrom sel (τ₃ sel))).mapState (Sum.inr : H₃ → Unit ⊕ H₃)).mapState
            (fun _ => (⟨⟨3, by omega⟩, false⟩ : Σ j, canonGramPh HF H₃ j)) := by
        rw [MultiTapeTM.runFrom_add d (tF + 1) (τ₃ sel + 1), hhost1, hc1]
        exact hdisp1
      refine ⟨(tF + 1) + (τ₃ sel + 1), ?_, ?_, ?_, ?_⟩
      · have hb1 : tF ≤ AF * (2 * (x.length + 1)) :=
          htF.trans (Nat.mul_le_mul le_rfl (by omega))
        have hb2 : τ₃ sel ≤ A₃ * (3 * (x.length + 1)) ^ 2 :=
          hbound₃.trans (Nat.mul_le_mul le_rfl (Nat.pow_le_pow_left (by omega) 2))
        have hled := canonGramLedger AF A₃ x.length tF (τ₃ sel) 0 hb1 hb2 (by omega)
        exact le_trans (by omega) hled
      · rw [hhost2, Cfg.mapState_state, Cfg.mapState_state, embedEmitCfg_state, hstE,
          Option.map_some, Option.map_some]
        have hcg : canonGrammar F.k (codeBitsNat bits) rest = none := by
          show ((codeSkipFin (codeBitsNat bits + 1) rest).bind
            (codeSkipTableK F.k (codeBitsNat bits))).bind
            (fun tail => if tail.all id then some tail else none) = none
          rw [hskf]
          show (codeSkipTableK F.k (codeBitsNat bits) ys₁).bind
            (fun tail => if tail.all id then some tail else none) = none
          rw [htab]
          rfl
        rw [hcg]
        rfl
      · rw [hhost2, Cfg.mapState_output, Cfg.mapState_output, embedEmitCfg_output, hout₃,
          List.append_nil, hcA, Cfg.mapState_output]
        exact hFout
      · intro vt hvt b
        by_cases h1 : vt ≤ tF
        · exact canonGramCut_leg G d 0 tF ⟨0, by omega⟩ (by decide : (0 : ℕ) ≠ 3) _ _
            (by rw [MultiTapeTM.runFrom_zero]; exact hc₀.symm) hpre0 vt (by omega)
            (by omega) b
        · exact canonGramCut_leg G d (tF + 1) (τ₃ sel) ⟨1, by omega⟩
            (by decide : (1 : ℕ) ≠ 3) _ _ (by rw [hhost1, hc1]) hpre1 vt (by omega)
            (by omega) b

/-- **The physical validator.** One finite binary machine halts on every input within a
polynomial bound with a single verdict bit; a rejection decodes to the fallback, and an
acceptance is a successful format scan.

**Proof sketch.** Run the total parse front end `exists_canonParseFront`. Its reject port
emits `false` and halts. At its ready port tape `0` holds the canonical header `bits`, the
native head is at the remainder, and the positive guard has passed; run the physical grammar
on a fresh bank around tape `0`, deciding `(canonGrammar F.k n rest).isSome`, then emit the
bit and halt. `canonGrammar_verdict` is the verdict law; the front end's linear ledger and
the grammar's quadratic ledger add.

**Fill appendix (canonizer continuation 5).** The composition is now proved modulo the
unchanged grammar-stage stub. A shared header and fresh grammar scratch bank preserve the
front end's actual ready configuration, including its arbitrary guard residue. One public
seam joins successful parsing to grammar; one public phase dispatch and one emitting halt
handle each final verdict. No new admission is introduced. -/
private lemma exists_canonDecider (F : MachineFormat) :
    ∃ (D : FinTM Bool) (a : ℕ), ∀ α : List Bool, ∃ b : Bool,
      D.ComputesInTime α [b] (a * (α.length + 1) ^ a) ∧
        (b = false → F.decode α = F.fallback) ∧
        (b = true → ∃ tail, F.scan α = some tail) := by
  classical
  obtain ⟨C, ce, cx, a, wide, cinj, front⟩ := exists_canonParseFront F
  obtain ⟨m, S, finite, equal, G, ge, gx, b, header, ginj, grammar⟩ :=
    exists_canonGrammarStage F
  letI : Fintype S := finite
  letI : DecidableEq S := equal
  let K := C.k + m
  let cb : Fin C.k ↪ Fin K := Fin.castLEEmb (by dsimp [K]; omega)
  let gb : Fin m ↪ Fin K := ⟨fun j =>
    if j = header then ⟨0, by dsimp [K]; omega⟩
    else ⟨C.k + j.val, by have := j.isLt; dsimp [K]; omega⟩, by
      intro i j h
      by_cases hi : i = header <;> by_cases hj : j = header
      · exact hi.trans hj.symm
      · have v := congrArg Fin.val h
        simp only [if_pos hi, if_neg hj] at v
        omega
      · have v := congrArg Fin.val h
        simp only [if_neg hi, if_pos hj] at v
        omega
      · have v := congrArg Fin.val h
        simp only [if_neg hi, if_neg hj] at v
        exact Fin.ext (by omega)⟩
  let A := embedEmitTM cb C.tm
  let B := embedEmitTM gb G
  let P := seamCompTM A (cx true) B ge
  let ports : Option Bool → C.State ⊕ S
    | none => Sum.inl (cx false)
    | some bit => Sum.inr (gx bit)
  have distinct : Function.Injective ports := by
    intro v w h
    cases v <;> cases w
    · rfl
    · cases h
    · cases h
    · exact congrArg some (ginj (Sum.inr.inj h))
  obtain ⟨D, emit⟩ := canonEmitVerdict P (Sum.inl ce) ports distinct
  let degree := a + b + 4
  refine ⟨D, degree, ?_⟩
  intro x
  obtain ⟨t, bound, v, state, silent, cuts, rejected, ready⟩ := front x
  let start := Cfg.ofWords (input := x) ce (fun _ : Fin K => [])
  let e := A.runFrom start t
  have es : e.state = some (cx v) := by
    dsimp only [e]
    rw [canonBlankLift C.tm cb]
    exact state
  have eo : e.output = [] := by
    dsimp only [e]
    rw [canonBlankLift C.tm cb]
    exact silent
  have ec (u : ℕ) (hu : u < t) (bit : Bool) :
      (A.runFrom start u).state ≠ some (cx bit) := by
    rw [canonBlankLift C.tm cb]
    exact cuts u hu bit
  have budget (s : ℕ) (hs : s ≤ b * (x.length + 1) ^ b) :
      t + 1 + s + 2 ≤ degree * (x.length + 1) ^ degree := by
    have power : (x.length + 1) ^ b ≤ (x.length + 1) ^ degree :=
      Nat.pow_le_pow_right (by omega) (by dsimp [degree]; omega)
    have linear : x.length + 1 ≤ (x.length + 1) ^ degree := by
      simpa using Nat.pow_le_pow_right (show 1 ≤ x.length + 1 by omega)
        (show 1 ≤ degree by dsimp [degree]; omega)
    have positive : 1 ≤ (x.length + 1) ^ degree := Nat.one_le_pow _ _ (by omega)
    have bt := bound.trans (Nat.mul_le_mul_left a linear)
    have bs := hs.trans (Nat.mul_le_mul_left b power)
    dsimp [degree] at *
    nlinarith
  cases v with
  | false =>
    have run : P.runFrom (start.mapState Sum.inl) t = e.mapState Sum.inl :=
      seamCompTM_runFrom_left A (cx true) B ge (fun u hu => ec u hu true) t le_rfl
    have ps : (P.runFrom (start.mapState Sum.inl) t).state = some (ports none) := by
      rw [run]
      simp [Cfg.mapState, es, ports]
    have po : (P.runFrom (start.mapState Sum.inl) t).output = [] := by rw [run]; exact eo
    have pc (u : ℕ) (hu : u < t) (q : Option Bool) :
        (P.runFrom (start.mapState Sum.inl) u).state ≠ some (ports q) := by
      rw [seamCompTM_runFrom_left A (cx true) B ge (fun z hz => ec z hz true) u hu.le]
      cases q with
      | none => simpa [ports, Cfg.mapState] using ec u hu false
      | some bit => simp [ports, Cfg.mapState]
    have computed := emit x t none ps po pc
    refine ⟨false, computed.mono ?_, fun _ => rejected rfl, by simp⟩
    exact (by omega : t + 2 ≤ t + 1 + 0 + 2).trans (budget 0 (Nat.zero_le _))
  | true =>
    obtain ⟨bits, rest, pair, canonical, guard, position, frame⟩ := ready rfl
    let g : Cfg m Bool S x :=
      ⟨some ge, e.inputPos, fun j => e.workTapes (gb j),
        fun j => e.workTapePos (gb j), []⟩
    have native : g.inputPos.val = 2 * bits.length + 3 := by
      change e.inputPos.val = _
      dsimp only [e]
      rw [canonBlankLift C.tm cb]
      exact position
    have headerBank : gb header = cb ⟨0, by omega⟩ := by
      apply Fin.ext
      simp [gb, cb]
    have headerWord : g.workTapes header = FinTM.bufferTape bits ∧
        g.workTapePos header = 0 := by
      change e.workTapes (gb header) = _ ∧ e.workTapePos (gb header) = 0
      dsimp only [e]
      rw [headerBank, canonBlankLift C.tm cb,
        embedEmitCfg_selected_tape, embedEmitCfg_selected_pos]
      simpa [canonReadyWords] using frame ⟨0, by omega⟩ (by simp)
    have fresh (j : Fin m) (hj : j ≠ header) :
        g.workTapes j = FinTM.bufferTape [] ∧ g.workTapePos j = 0 := by
      have outside : gb j ∉ Set.range cb := by
        rintro ⟨i, hi⟩
        have values := congrArg Fin.val hi
        have ilt := i.isLt
        have gv : (gb j).val = C.k + j.val := by simp [gb, hj]
        rw [gv] at values
        change i.val = C.k + j.val at values
        omega
      have fixed := (embedEmitTM_frame cb C.tm (fun _ => FinTM.bufferTape [])
        (fun _ => 0) [] (Cfg.ofWords (input := x) ce (fun _ => [])) t).1 (gb j) outside
      rw [canonEmbedWords C.tm cb ce (fun _ => []) (fun _ => []) (fun _ => [])
        (fun _ => rfl) (fun _ _ => rfl)] at fixed
      exact fixed
    have startG : embedEmitCfg gb e.workTapes e.workTapePos [] g =
        e.mapState (fun _ => ge) := by
      apply canonEmbedEq G gb g (e.mapState (fun _ => ge)) _ _
        (by simp [g, Cfg.mapState, es]) rfl eo.symm
      · exact fun _ => ⟨rfl, rfl⟩
      · exact fun _ _ => ⟨rfl, rfl⟩
    have lift (u : ℕ) : B.runFrom (e.mapState (fun _ => ge)) u =
        embedEmitCfg gb e.workTapes e.workTapePos [] (G.runFrom g u) := by
      rw [← startG]
      exact embedEmitTM_runFrom gb G _ _ _ _ u
    obtain ⟨s, sb, gs, go, gc⟩ := grammar x bits rest pair canonical guard g rfl rfl
      native headerWord.1 headerWord.2 fresh
    let bit := (canonGrammar F.k (codeBitsNat bits) rest).isSome
    let h := B.runFrom (e.mapState (fun _ => ge)) s
    have hs : h.state = some (gx bit) := by dsimp only [h]; rw [lift]; exact gs
    have ho : h.output = [] := by dsimp only [h]; rw [lift]; exact go
    have hc (u : ℕ) (hu : u < s) (bit : Bool) :
        (B.runFrom (e.mapState (fun _ => ge)) u).state ≠ some (gx bit) := by
      rw [lift]
      exact gc u hu bit
    have whole := seamCompTM_run_ofCfg A (cx true) B ge (rfl : A.runFrom start t = e)
      es (fun u hu => ec u hu true) (rfl : B.runFrom (e.mapState (fun _ => ge)) s = h)
    have ps : (P.runFrom (start.mapState Sum.inl) (t + 1 + s)).state =
        some (ports (some bit)) := by
      rw [whole]
      change (h.mapState Sum.inr).state = _
      simp [Cfg.mapState, hs, ports]
    have po : (P.runFrom (start.mapState Sum.inl) (t + 1 + s)).output = [] := by
      rw [whole]; exact ho
    have pc (u : ℕ) (hu : u < t + 1 + s) (q : Option Bool) :
        (P.runFrom (start.mapState Sum.inl) u).state ≠ some (ports q) := by
      apply canonSeam_avoids A (cx true) B ge (ports q) rfl es
        (fun z hz => ec z hz true) (v := s) ?_ ?_ u hu
      · intro z hz
        cases q with
        | some bit => simp [ports, Cfg.mapState]
        | none =>
          have avoid : (A.runFrom start z).state ≠ some (cx false) := by
            by_cases early : z < t
            · exact ec z early false
            · have eq : z = t := by omega
              rw [eq]
              change e.state ≠ _
              rw [es]
              exact fun eq => by cases cinj (Option.some.inj eq)
          simpa [ports, Cfg.mapState] using avoid
      · intro z hz
        cases q with
        | none => simp [ports, Cfg.mapState]
        | some bit => simpa [ports, Cfg.mapState] using hc z hz bit
    have computed := emit x (t + 1 + s) (some bit) ps po pc
    have law := canonGrammar_verdict F x bits rest pair canonical guard
    refine ⟨bit, ?_, law.1, law.2⟩
    have output : decide (some bit = some true) = bit := by cases bit <;> rfl
    rw [output] at computed
    exact computed.mono (budget s sb)

/-- **A polynomial-time canonizer**: one finite
binary machine computes the fixed serialization of the decoded machine within
`d · (|α| + 1)^d` steps. [AB09, §1.4; the P3.2 round-2 construction]

**Proof sketch.** Implement `F.scan` and emit `F.canonical`
(`Turing.CodeFormat.canonical_eq`). Copy `α` to a work tape. Parse the doubled
state count (`pairDecode`) and check that it is canonical. Check the guard
`F.guard · (n + 1) ≤ |rest|` in binary **before** any state-indexed work: count
`rest` in blocks of `F.guard` cells against a decrementing copy of `bits n`
(`Turing.decrementTM`, `Turing.counterLoopTM`), never expanding `n` in unary.
Then skip the unary initial state with its range check, and the table by the
fixed grammar (`F.skipTable_eq`, `Turing.codeSkipTableK`): `n + 1` rounds of
`3^(k+1)` records, each field by a finite-state check and each successor field
by a binary range check. After the guard every round consumes at least
`4k + 5` cells (`Turing.codeActionK_length`), so there are at most `|α|` rounds.
**The guard may be `0`** (wave-1 statement gate, round 1, finding 5). `F.guard` is
unconstrained, and a zero guard bounds nothing, so the guard check alone does not bound
`n`. Add the grammar-derived necessary check: a successful parse consumes at least
`(4k + 5) · 3^(k+1) · (n + 1)` table bits, a positive multiple of `n + 1`. Run it in binary
against a decrementing copy of `bits n`, failing fast once the suffix is exhausted. Early
rejection by this check or by the guard yields exactly the prescribed fallback, because
`F.scan` fails on the same inputs (`Turing.CodeFormat.canonical_eq`). No stronger
`MachineFormat` hypothesis is needed.
Check the all-`true` suffix. On success copy the consumed prefix to the output;
on failure emit the constant `F.serialize F.fallback`. Every phase is polynomial
in `|α|`; take `d` at least the coefficient and the exponent.

**Implementation.** Validation and emission are separate phases. A validator
(`exists_canonDecider`) decides whether `F.scan` succeeds, in polynomial time and with a
single verdict bit, by the two-port parse front end (header validity and canonicality, and the
positive guard `max F.guard ((4k + 5) · 3^(k+1))` checked in binary against the successor of
the header) followed by the grammar stage (`exists_canonGrammarStage`). On acceptance the strip
machine (`exists_canonStripTM`) erases the input's maximal trailing `true` suffix, which leaves
the decoded machine's serialization (`canonStrip_of_scan`); on rejection the constant
`F.serialize F.fallback` is emitted; `Turing.FinTM.computesFunInTime_cond` composes the three.
The record validator has an entry and two distinct verdict ports, while a public counter loop's
body must return to its own anchor on success; so every record round is wrapped by a fresh-anchor
return adapter (`canonReturnAdapter`), which makes it a positive first-return-or-escape round,
before it becomes the loop's body. -/
theorem exists_polyCanonizer :
    ∃ (C : FinTM Bool) (d : ℕ),
      C.ComputesFunInTime (fun α => F.serialize (F.decode α)) fun n => d * (n + 1) ^ d := by
  obtain ⟨D, a, decider⟩ := exists_canonDecider F
  choose verdict spec using decider
  obtain ⟨M, b, strip⟩ := exists_canonStripTM
  obtain ⟨E, e, fallback⟩ := FinTM.computesFunInTime_const (F.serialize F.fallback)
  have decides : D.ComputesFunInTime (fun α => [verdict α]) fun n => a * (n + 1) ^ a :=
    fun α => (spec α).1
  obtain ⟨C, c, branch⟩ := FinTM.computesFunInTime_cond decides strip fallback
  refine ⟨C, c * (a + b + e + 1) + a + b + 1, ?_⟩
  intro α
  have output : (if verdict α then canonStrip α else F.serialize F.fallback) =
      F.serialize (F.decode α) := by
    cases hv : verdict α with
    | false =>
      rw [(spec α).2.1 hv]
      rfl
    | true =>
      obtain ⟨tail, hs⟩ := (spec α).2.2 hv
      exact canonStrip_of_scan F α tail hs
  have run := branch α
  dsimp only at run ⊢
  rw [output] at run
  apply run.mono
  set d := c * (a + b + e + 1) + a + b + 1
  set P := (α.length + 1) ^ d
  have base : 1 ≤ α.length + 1 := by omega
  have pa : (α.length + 1) ^ a ≤ P := Nat.pow_le_pow_right base (by omega)
  have pb : (α.length + 1) ^ b ≤ P := Nat.pow_le_pow_right base (by omega)
  have p1 : α.length + 1 ≤ P := by
    simpa using Nat.pow_le_pow_right base (show 1 ≤ d by omega)
  have p0 : 1 ≤ P := Nat.one_le_pow _ _ (by omega)
  have inner : a * (α.length + 1) ^ a +
      max (b * (α.length + 1) ^ b) (e * (α.length + 1)) + 1 ≤ (a + b + e + 1) * P := by
    have ha := Nat.mul_le_mul_left a pa
    have hb := Nat.mul_le_mul_left b pb
    have he := Nat.mul_le_mul_left e p1
    have hm : max (b * (α.length + 1) ^ b) (e * (α.length + 1)) ≤ b * P + e * P :=
      max_le (by omega) (by omega)
    nlinarith
  calc
    c * (a * (α.length + 1) ^ a + max (b * (α.length + 1) ^ b) (e * (α.length + 1)) + 1)
        ≤ c * ((a + b + e + 1) * P) := Nat.mul_le_mul_left c inner
    _ = (c * (a + b + e + 1)) * P := by ring
    _ ≤ d * P := Nat.mul_le_mul_right P (by omega)

/-! ### Finite output summary (D4 move, generalized from Codes2Tape)

The four clock declarations below, with the five output-summary declarations now
in `Build/StepBlock` (`Turing.StepBlock.outputSummary` and its lemmas, H2-M),
replace their specialized ZF-B3 counterparts. This is the semantic specification
of the step block, not a finite-machine interpreter or a claim about its running
time.
-/

section StepBlockClients

open StepBlock

/-- Semantic clock for any finite-tape binary machine. It performs exactly the
permitted number of source steps, maintaining only the finite output summary,
and then inspects halting and exact output. This is a specification function,
not a finite-machine construction or a claim about machine time. -/
private def summaryClock {k : ℕ} {Q : Type} (M : MultiTapeTM k Bool Q)
    {x : List Bool} : ℕ → Cfg k Bool Q x → Option Bool → Bool
  | 0, c, s => c.state.isNone && (s == some true)
  | t + 1, c, s =>
    summaryClock M t (M.step c) (summaryEmit s (M.outputSymbol c))

/-- The clock's final inspection includes the last permitted transition.
Halted configurations are allowed, so the equation also covers padding an
early halt to the deadline.

**Proof sketch.** Induct on the deadline. The output-summary update is
exactly append by the step's optional emission; cite the public run and
output-step equations to identify the residual run. -/
private lemma summaryClock_correct {k : ℕ} {Q : Type} (M : MultiTapeTM k Bool Q)
    {x : List Bool} (c : Cfg k Bool Q x) (t : ℕ) :
    summaryClock M t c (outputSummary c.output) =
      ((M.runFrom c t).state.isNone &&
        (outputSummary (M.runFrom c t).output == some true)) := by
  induction t generalizing c <;>
    simp only [summaryClock, ← outputSummary_append, ← MultiTapeTM.step_output,
      MultiTapeTM.runFrom_zero, MultiTapeTM.runFrom_succ_eq_step, *]

/-- Inspecting the semantic clock at the deadline is exactly bounded acceptance,
including a halt on the last permitted transition. -/
private lemma summaryClock_accepts (M : FinTM Bool) (x : List Bool) (t : ℕ) :
    summaryClock M.tm t (M.tm.initCfg x) none = true ↔ M.ComputesInTime x [true] t := by
  change summaryClock M.tm t (M.tm.initCfg x)
    (outputSummary (M.tm.initCfg x).output) = true ↔ _
  rw [summaryClock_correct, FinTM.computesInTime_iff]
  simp only [Bool.and_eq_true, Option.isNone_iff_eq_none, beq_iff_eq, outputSummary_true]

/-- The zero-deadline clock rejects every initialized machine. -/
private lemma summaryClock_zero (M : FinTM Bool) (x : List Bool) :
    summaryClock M.tm 0 (M.tm.initCfg x) none = false := rfl

/-- The hosted clock `StepBlock.hostedLoopTM` with its two live exits replaced by the
one-step verdict. Timeout emits false; simulated halt tests the restored summary
cell. Every other transition is the existing hosted clock transition. -/
private def h1HostedVerdictTM (k : ℕ) :
    MultiTapeTM (1 + (k + 2 + 1)) Bool (CounterLoopState (Σ key, Ph k key) × Bool) :=
  { hostedLoopTM k with tr := fun q inp work =>
      if q.1 = .done ∨ q.1 = .escape then
        ⟨0, fun _ => (none, 0),
          some (if q.1 = .escape then
            work (vhostBank (summaryTape k).castSucc) == some true else false), none⟩
      else (hostedLoopTM k).tr q inp work }

/-- The physical hosted clock and its verdict, from the prepared round
seam. The endpoint is halted and emits precisely the inherited semantic
clock's answer, after the arbitrary prior physical output prefix.

**Proof sketch.** The public agreement theorem transports the hosted clock
run because its strict prefixes avoid both verdict exits. At the endpoint,
the representation places the output summary under its head. One stationary
halting step reads it. The frozen semantic clock equation identifies this
bit; neither the physical run nor the acceptance argument is re-proved. -/
private theorem h1HostedVerdict_effect {k n : ℕ} {x z : List Bool}
    (M : MultiTapeTM k Bool (Fin (n + 1)))
    (d : Cfg (k + 2) Bool (Σ key, Ph k key) x)
    (entry : d.state = some (exit k true))
    (rel : Rep M.tr (M.initCfg x) d) (t : ℕ)
    (p : Fin (z.length + 2)) :
    ∃ T ≤ t * (50 * ((tableBitsK M.tr).length + 1)) + 4 * t + 2 * t.bits.length + 3,
      let e := (h1HostedVerdictTM k).runFrom
        (vhostCfg (counterLoopCfg (some (.dec .run)) d
          (FinTM.bufferTape t.bits) 0) true p []) T
      e.state = none ∧ e.inputPos = p ∧
        e.output = d.output ++ [summaryClock M t (M.initCfg x) none] := by
  obtain ⟨T, e, ct, b, bound, -, related, output, -, _, run, cut⟩ :=
    hostedLoopTM_run M (M.initCfg x) (by simp [MultiTapeTM.initCfg, Cfg.init]) d entry rel
      t.bits (FinTM.bufferTape t.bits) 0 (by intro p _ _; simp) t (counterValue_bits t) true
      (by simp [FinTM.VirtualTag, MultiTapeTM.initCfg, Cfg.init]) p []
  let start := vhostCfg (counterLoopCfg (some (.dec .run)) d
    (FinTM.bufferTape t.bits) 0) true p []
  have agree : (hostedLoopTM k).AgreeOn (h1HostedVerdictTM k)
      {q | q.1 ≠ .done ∧ q.1 ≠ .escape} := by
    intro q hq inp work
    simp only [h1HostedVerdictTM, hq.1, hq.2, or_self, ↓reduceIte]
  have transfer := MultiTapeTM.runFrom_eq_of_agreeOn agree start T (by
    intro u hu q hq
    constructor
    · intro bad
      exact (cut u hu q.2).1 (hq.trans (congrArg some (Prod.ext bad rfl)))
    · intro bad
      exact (cut u hu q.2).2 (hq.trans (congrArg some (Prod.ext bad rfl))))
  have semantic : summaryClock M t (M.initCfg x) none =
      ((M.runFrom (M.initCfg x) t).state.isNone &&
        (outputSummary (M.runFrom (M.initCfg x) t).output == some true)) :=
    summaryClock_correct M (M.initCfg x) t
  obtain ⟨hs, -, -, cell⟩ := hostedLoop_read M.tr (M.runFrom (M.initCfg x) t) e related
    (if (M.runFrom (M.initCfg x) t).state.isSome then .done else .escape) ct 0 b p []
  refine ⟨T + 1, by omega, ?_⟩
  change ((h1HostedVerdictTM k).runFrom start (T + 1)).state = none ∧ _
  rw [MultiTapeTM.runFrom_succ_eq_step', transfer, run, semantic]
  unfold MultiTapeTM.step
  rw [hs]
  simp only [h1HostedVerdictTM, cell]
  cases state : (M.runFrom (M.initCfg x) t).state <;>
    simp [Action.apply, vhostCfg, counter_cfg_eq, output, moveInputPos_zero]

/-- The hosted verdict's bit is bounded acceptance, by the inherited
semantic bridge. This specializes only the prepared-seam contract: parsing
and canonizer installation are separate startup obligations. -/
private theorem h1HostedVerdict_accepts (F : MachineFormat) (α x z : List Bool)
    (d : Cfg (F.k + 2) Bool (Σ key, Ph F.k key) x)
    (entry : d.state = some (exit F.k true))
    (rel : Rep (F.machine (F.decode α)).tr
      ((F.machine (F.decode α)).initCfg x) d) (t : ℕ)
    (p : Fin (z.length + 2)) :
    ∃ T ≤ t * (50 * ((tableBitsK (F.machine (F.decode α)).tr).length + 1)) +
        4 * t + 2 * t.bits.length + 3, ∃ answer : Bool,
      ((h1HostedVerdictTM F.k).runFrom
        (vhostCfg (counterLoopCfg (some (.dec .run)) d
          (FinTM.bufferTape t.bits) 0) true p []) T).state = none ∧
      ((h1HostedVerdictTM F.k).runFrom
        (vhostCfg (counterLoopCfg (some (.dec .run)) d
          (FinTM.bufferTape t.bits) 0) true p []) T).output = d.output ++ [answer] ∧
      (answer = true ↔ (F.toFinTM (F.decode α)).ComputesInTime x [true] t) := by
  obtain ⟨T, bound, halted, _, output⟩ :=
    h1HostedVerdict_effect (F.machine (F.decode α)) d entry rel t p
  exact ⟨T, bound, _, halted, output, summaryClock_accepts (F.toFinTM (F.decode α)) x t⟩

/-- **The installation is uniform and polynomial.** One install module, uniform in the code,
which from the code `α` returns with the serialization of the decoded machine installed, at a
first positive return within `a · ((|α| + 1)^d + |α| + max |α| |F.serialize F.fallback| + 1)`.

**Proof sketch.** The format's polynomial canonizer through the public install call; the
canonical word's length is at most `max |α| |F.serialize F.fallback|`, and `F.serialize_eq`
names the installed word. -/
private theorem us_install :
    ∃ (C : FinTM Bool) (entry exit : C.State) (a d : ℕ), 0 < C.k ∧
      ∀ x α : List Bool, ∃ t ≤ a * ((α.length + 1) ^ d + α.length +
          max α.length (F.serialize F.fallback).length + 1), 0 < t ∧
        (∀ t', 0 < t' → t' < t →
          (C.tm.runFrom (Cfg.ofWords (input := x) entry (stateWord C.k α)) t').state ≠
            some exit) ∧
        C.tm.runFrom (Cfg.ofWords (input := x) entry (stateWord C.k α)) t =
          Cfg.ofWords exit (stateWord C.k (serializeK (F.machine (F.decode α)))) := by
  obtain ⟨P, d, hP⟩ := F.exists_polyCanonizer
  obtain ⟨C, entry, exit, c, hk, inst⟩ := FinTM.exists_installCallTM P _ _ hP
  refine ⟨C, entry, exit, c * (d + 1), d, hk, fun x α => ?_⟩
  obtain ⟨t, ht, hpos, hcut, hrun⟩ := inst x α
  have hlen := F.serialize_decode_length_le α
  refine ⟨t, ht.trans ?_, hpos, hcut, ?_⟩
  · have hm : d * (α.length + 1) ^ d ≤ (d + 1) * (α.length + 1) ^ d :=
      Nat.mul_le_mul_right _ (Nat.le_succ d)
    calc c * (d * (α.length + 1) ^ d + α.length + (F.serialize (F.decode α)).length + 1)
        ≤ c * ((d + 1) * (α.length + 1) ^ d + α.length +
            max α.length (F.serialize F.fallback).length + 1) := by
          apply Nat.mul_le_mul_left; omega
      _ ≤ c * ((d + 1) * ((α.length + 1) ^ d + α.length +
            max α.length (F.serialize F.fallback).length + 1)) := by
          apply Nat.mul_le_mul_left
          nlinarith [Nat.zero_le ((α.length + 1) ^ d)]
      _ = c * (d + 1) * ((α.length + 1) ^ d + α.length +
            max α.length (F.serialize F.fallback).length + 1) := by ring
  · rw [hrun, F.serialize_eq]

/-- **Deterministic input locality.** In `t` steps a machine reads at most the first `t` input
symbols, so its runs on `x.take t` and on `x` agree in state and output at time `t`. -/
private theorem us_locality {k : ℕ} {Q : Type} (M : MultiTapeTM k Bool Q) (x : List Bool)
    (t : ℕ) :
    (M.runFrom (M.initCfg (x.take t)) t).state = (M.runFrom (M.initCfg x) t).state ∧
      (M.runFrom (M.initCfg (x.take t)) t).output = (M.runFrom (M.initCfg x) t).output := by
  have h := NDTM.runWith_initCfg_take M.toNDTM x t (List.replicate t false)
    (by rw [List.length_replicate])
  simp only [MultiTapeTM.toNDTM_runWith, MultiTapeTM.toNDTM_initCfg,
    List.length_replicate] at h
  exact ⟨h.1, h.2.2.2.2⟩

/-- **A halt with a one-bit output gives both clauses.** If a machine halts at `T ≤ B` with
output `[answer]`, and `answer` decides `P`, it computes `[true]` within `B` when `P` holds and
`[false]` within `B` otherwise. -/
private theorem us_verdict (S : FinTM Bool) (z : List Bool) (T B : ℕ) (answer : Bool) (P : Prop)
    (hT : T ≤ B) (halt : (S.tm.runFrom (S.tm.initCfg z) T).state = none)
    (out : (S.tm.runFrom (S.tm.initCfg z) T).output = [answer]) (hans : answer = true ↔ P) :
    (P → S.ComputesInTime z [true] B) ∧ (¬P → S.ComputesInTime z [false] B) := by
  have hc : S.ComputesInTime z [answer] T := (FinTM.computesInTime_iff _ _ _ _).mpr ⟨halt, out⟩
  constructor
  · intro hp
    rw [hans.mpr hp] at hc
    exact hc.mono hT
  · intro hp
    cases answer with
    | false => exact hc.mono hT
    | true => exact absurd (hans.mp rfl) hp

/-- The installed table is no longer than the code or the format's fallback serialization. -/
private theorem us_table_le (α : List Bool) :
    (tableBitsK (F.machine (F.decode α)).tr).length ≤
      max α.length (F.serialize F.fallback).length := by
  have h := F.serialize_decode_length_le α
  rw [F.serialize_eq, serializeK_eq, length_pairEncode, List.length_append] at h
  omega

/-- **The verdict on the window decides acceptance on the input.** The hosted verdict, run from
a represented start on the window `x.take t`, halts within its bound with one output bit, which
is `true` exactly when the decoded machine accepts `x` itself within `t` steps. -/
private theorem us_window_verdict (α x z : List Bool) (t : ℕ)
    (d : Cfg (F.k + 2) Bool (Σ key, StepBlock.Ph F.k key) (x.take t))
    (entry : d.state = some (StepBlock.exit F.k true))
    (rel : StepBlock.Rep (F.machine (F.decode α)).tr
      ((F.machine (F.decode α)).initCfg (x.take t)) d)
    (p : Fin (z.length + 2)) (silent : d.output = []) :
    ∃ T ≤ t * (50 * ((tableBitsK (F.machine (F.decode α)).tr).length + 1)) +
        4 * t + 2 * t.bits.length + 3, ∃ answer : Bool,
      ((h1HostedVerdictTM F.k).runFrom
        (vhostCfg (counterLoopCfg (some (.dec .run)) d
          (FinTM.bufferTape t.bits) 0) true p []) T).state = none ∧
      ((h1HostedVerdictTM F.k).runFrom
        (vhostCfg (counterLoopCfg (some (.dec .run)) d
          (FinTM.bufferTape t.bits) 0) true p []) T).output = [answer] ∧
      (answer = true ↔ (F.toFinTM (F.decode α)).ComputesInTime x [true] t) := by
  obtain ⟨T, bound, answer, halted, out, iff⟩ :=
    h1HostedVerdict_accepts F α (x.take t) z d entry rel t p
  refine ⟨T, bound, answer, halted, by rw [out, silent, List.nil_append], iff.trans ?_⟩
  rw [FinTM.computesInTime_iff, FinTM.computesInTime_iff]
  obtain ⟨hs, ho⟩ := us_locality (F.toFinTM (F.decode α)).tm x t
  rw [hs, ho]

/-- **The joint ledger.** With `N = |α| + |x| + t + 1`, a startup within the polynomial
installer's cost plus its linear terms, one dispatch step and the hosted verdict's quadratic
bound together stay within `D · N^D`, for `D` built from the constants alone.

**Proof sketch.** Every term is at most a constant times `P = N^(d₀ + 2)`: the installer's
power because `|α| + 1 ≤ N`, the linear terms because `N ≤ P`, the verdict's `t · |table|`
because `N · N ≤ P`, and the constants because `1 ≤ P`. Collect the coefficients, then use
`P ≤ N^D` for `d₀ + 2 ≤ D`. -/
private theorem us_ledger (a d₀ A B L αl xl t T₁ T₂ s m tb bl : ℕ)
    (hm : m ≤ αl + L) (hs : s ≤ m) (htb : tb ≤ m) (hbl : bl ≤ t)
    (hT₁ : T₁ ≤ a * ((αl + 1) ^ d₀ + αl + m + 1) + A * (αl + s + 1) +
      B * (bl + min t xl + 1))
    (hT₂ : T₂ ≤ t * (50 * (tb + 1)) + 4 * t + 2 * bl + 3) :
    T₁ + 1 + T₂ ≤ (a * (L + 4) + A * (L + 3) + 3 * B + 50 * L + 110 + d₀ + 2) *
      (αl + xl + t + 1) ^ (a * (L + 4) + A * (L + 3) + 3 * B + 50 * L + 110 + d₀ + 2) := by
  have hN : 1 ≤ αl + xl + t + 1 := by omega
  have hP1 : 1 ≤ (αl + xl + t + 1) ^ (d₀ + 2) := Nat.one_le_pow _ _ hN
  have hNP : αl + xl + t + 1 ≤ (αl + xl + t + 1) ^ (d₀ + 2) := by
    calc αl + xl + t + 1 = (αl + xl + t + 1) ^ 1 := (pow_one _).symm
      _ ≤ _ := Nat.pow_le_pow_right hN (by omega)
  have hNNP : (αl + xl + t + 1) * (αl + xl + t + 1) ≤ (αl + xl + t + 1) ^ (d₀ + 2) := by
    rw [← pow_two]
    exact Nat.pow_le_pow_right hN (by omega)
  have hαP : (αl + 1) ^ d₀ ≤ (αl + xl + t + 1) ^ (d₀ + 2) :=
    (Nat.pow_le_pow_left (by omega) d₀).trans (Nat.pow_le_pow_right hN (by omega))
  have hLP : L ≤ L * (αl + xl + t + 1) ^ (d₀ + 2) := Nat.le_mul_of_pos_right _ hP1
  have hLN : L * (αl + xl + t + 1) ≤ L * (αl + xl + t + 1) ^ (d₀ + 2) :=
    Nat.mul_le_mul_left L hNP
  have hX : (αl + 1) ^ d₀ + αl + m + 1 ≤ (L + 4) * (αl + xl + t + 1) ^ (d₀ + 2) := by
    rw [add_mul]; omega
  have hY : αl + s + 1 ≤ (L + 3) * (αl + xl + t + 1) ^ (d₀ + 2) := by
    rw [add_mul]; omega
  have hZ : bl + min t xl + 1 ≤ 3 * (αl + xl + t + 1) ^ (d₀ + 2) := by omega
  have hW : t * (50 * (tb + 1)) ≤
      (αl + xl + t + 1) * (50 * ((αl + xl + t + 1) + L + 1)) :=
    Nat.mul_le_mul (by omega) (by omega)
  have hW' : (αl + xl + t + 1) * (50 * ((αl + xl + t + 1) + L + 1)) =
      50 * ((αl + xl + t + 1) * (αl + xl + t + 1)) + 50 * (L * (αl + xl + t + 1)) +
        50 * (αl + xl + t + 1) := by ring
  have hc : T₁ + 1 + T₂ ≤ (a * (L + 4) + A * (L + 3) + 3 * B + 50 * L + 110) *
      (αl + xl + t + 1) ^ (d₀ + 2) := by
    have h1 := Nat.mul_le_mul_left a hX
    have h2 := Nat.mul_le_mul_left A hY
    have h3 := Nat.mul_le_mul_left B hZ
    have e : (a * (L + 4) + A * (L + 3) + 3 * B + 50 * L + 110) *
        (αl + xl + t + 1) ^ (d₀ + 2) =
        a * ((L + 4) * (αl + xl + t + 1) ^ (d₀ + 2)) +
          A * ((L + 3) * (αl + xl + t + 1) ^ (d₀ + 2)) +
          B * (3 * (αl + xl + t + 1) ^ (d₀ + 2)) +
          50 * (L * (αl + xl + t + 1) ^ (d₀ + 2)) + 110 * (αl + xl + t + 1) ^ (d₀ + 2) := by
      ring
    rw [e]
    omega
  refine hc.trans (Nat.mul_le_mul (by omega) (Nat.pow_le_pow_right hN (by omega)))

/-- **The hosted verdict's tape map into the startup's tapes.** The virtual window first, then
the `k` mirrored work tapes on the reserved passive tapes, the table, the summary, and last the
counter. The map is injective by the startup's ten separation facts.

**Proof sketch.** Define the map by `Fin.addCases` and `Fin.lastCases`, which gives the five
value equations. Every index of `Fin (1 + (k + 2 + 1))` is one of the five forms, by its value.
For injectivity, compare two indices form by form. Two reserved tapes are equal only at the same
index, since `ιP` is injective. Any other two distinct forms land on tapes that the separation
facts keep apart. -/
private theorem us_bank {k K : ℕ} (ιP : Fin k ↪ Fin K) (jctr jwin jtbl jsm : Fin K)
    (hcw : jctr ≠ jwin) (hct : jctr ≠ jtbl) (hcs : jctr ≠ jsm) (hwt : jwin ≠ jtbl)
    (hws : jwin ≠ jsm) (hts : jtbl ≠ jsm) (hcP : jctr ∉ Set.range ιP)
    (hwP : jwin ∉ Set.range ιP) (htP : jtbl ∉ Set.range ιP) (hsP : jsm ∉ Set.range ιP) :
    ∃ g : Fin (1 + (k + 2 + 1)) ↪ Fin K,
      g (Fin.castAdd (k + 2 + 1) 0) = jwin ∧
      (∀ i, g (Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) = ιP i) ∧
      g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd k 0))) = jtbl ∧
      g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd k 1))) = jsm ∧
      g (Fin.natAdd 1 (Fin.last (k + 2))) = jctr := by
  obtain ⟨f, fw, fP, ft, fs, fc⟩ : ∃ f : Fin (1 + (k + 2 + 1)) → Fin K,
      f (Fin.castAdd (k + 2 + 1) 0) = jwin ∧
      (∀ i, f (Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) = ιP i) ∧
      f (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd k 0))) = jtbl ∧
      f (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd k 1))) = jsm ∧
      f (Fin.natAdd 1 (Fin.last (k + 2))) = jctr :=
    ⟨Fin.addCases (motive := fun _ => Fin K) (fun _ => jwin)
        (Fin.lastCases (motive := fun _ => Fin K) jctr
          (Fin.addCases (motive := fun _ => Fin K) (fun i => ιP i)
            (fun j => if j = 0 then jtbl else jsm))),
      by rw [Fin.addCases_left],
      fun i => by rw [Fin.addCases_right, Fin.lastCases_castSucc, Fin.addCases_left],
      by
        rw [Fin.addCases_right, Fin.lastCases_castSucc, Fin.addCases_right]
        try exact if_pos rfl,
      by
        rw [Fin.addCases_right, Fin.lastCases_castSucc, Fin.addCases_right]
        try exact if_neg (by decide),
      by rw [Fin.addCases_right, Fin.lastCases_last]⟩
  have cover : ∀ a : Fin (1 + (k + 2 + 1)), a = Fin.castAdd (k + 2 + 1) 0 ∨
      (∃ i, a = Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) ∨
      a = Fin.natAdd 1 (Fin.castSucc (Fin.natAdd k 0)) ∨
      a = Fin.natAdd 1 (Fin.castSucc (Fin.natAdd k 1)) ∨
      a = Fin.natAdd 1 (Fin.last (k + 2)) := by
    intro a
    have ha := a.isLt
    by_cases h0 : a.val = 0
    · left
      exact Fin.ext (by rw [Fin.coe_castAdd, Fin.val_zero]; omega)
    by_cases h1 : a.val ≤ k
    · right; left
      refine ⟨⟨a.val - 1, by omega⟩, Fin.ext ?_⟩
      rw [Fin.coe_natAdd, Fin.coe_castSucc, Fin.coe_castAdd]
      show (a : ℕ) = 1 + (a.val - 1)
      omega
    by_cases h2 : a.val = k + 1
    · right; right; left
      exact Fin.ext (by rw [Fin.coe_natAdd, Fin.coe_castSucc, Fin.coe_natAdd, Fin.val_zero]; omega)
    by_cases h3 : a.val = k + 2
    · right; right; right; left
      exact Fin.ext (by rw [Fin.coe_natAdd, Fin.coe_castSucc, Fin.coe_natAdd, Fin.val_one]; omega)
    · right; right; right; right
      exact Fin.ext (by rw [Fin.coe_natAdd, Fin.val_last]; omega)
  refine ⟨⟨f, fun a b h => ?_⟩, fw, fP, ft, fs, fc⟩
  rcases cover a with rfl | ⟨i, rfl⟩ | rfl | rfl | rfl <;>
    rcases cover b with rfl | ⟨i', rfl⟩ | rfl | rfl | rfl <;>
    simp only [fw, fP, ft, fs, fc] at h <;>
    first
    | rfl
    | exact congrArg (fun i => Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) (ιP.injective h)
    | exact absurd h hcw | exact absurd h.symm hcw
    | exact absurd h hct | exact absurd h.symm hct
    | exact absurd h hcs | exact absurd h.symm hcs
    | exact absurd h hwt | exact absurd h.symm hwt
    | exact absurd h hws | exact absurd h.symm hws
    | exact absurd h hts | exact absurd h.symm hts
    | exact (hcP ⟨_, h⟩).elim | exact (hcP ⟨_, h.symm⟩).elim
    | exact (hwP ⟨_, h⟩).elim | exact (hwP ⟨_, h.symm⟩).elim
    | exact (htP ⟨_, h⟩).elim | exact (htP ⟨_, h.symm⟩).elim
    | exact (hsP ⟨_, h⟩).elim | exact (hsP ⟨_, h.symm⟩).elim

/-- **The loop junction.** A configuration with the interpreter startup's threshold fields, at
`p = F.k`, is the hosted verdict's start embedded along the tape map. The startup's threshold has
the counter `bits t`, the window `x.take t`, the decoded machine's table and its summary on the
four role tapes, the `F.k` reserved tapes blank, every role and reserved head at `0`, and the
empty output. Relabelled to the hosted clock's first state, it is the forwarding embedding of
`vhostCfg (counterLoopCfg (some (.dec .run)) d (bufferTape t.bits) 0)` at the configuration's own
input head. Here `d` is a represented start of the decoded machine on the window, at the step
block's live exit, with empty output.

**Proof sketch.** Take for `d` the step block's live exit, input head `1`, the mirrored tapes
blank, the table and the summary from the startup, every head at `0`, empty output. It
represents the initial configuration on the window (`StepBlock.Rep_iff`, the `Cfg.init`
fields). For the embedding, apply `embedEmitCfg_eq`. The state, input head and output come from
the field equations of `vhostCfg`, `counter_cfg_eq` and `Cfg.mapState`. For a selected tape,
split its index by `Fin.addCases` and `Fin.lastCases` into the window, the mirrored bank, the
table, the summary and the counter; each contents and head is the corresponding threshold field.
The tapes off the map are the configuration's own. -/
private theorem us_junction {K : ℕ} {Q : Type} {z : List Bool} (α x : List Bool) (t : ℕ)
    (g : Fin (1 + (F.k + 2 + 1)) ↪ Fin K) (ιP : Fin F.k ↪ Fin K) (jctr jwin jtbl jsm : Fin K)
    (gw : g (Fin.castAdd (F.k + 2 + 1) 0) = jwin)
    (gP : ∀ i, g (Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) = ιP i)
    (gt : g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd F.k 0))) = jtbl)
    (gs : g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd F.k 1))) = jsm)
    (gc : g (Fin.natAdd 1 (Fin.last (F.k + 2))) = jctr)
    (c : Cfg K Bool Q z) (done : Q) (hst : c.state = some done) (hout : c.output = [])
    (hctr : c.workTapes jctr = FinTM.bufferTape (Nat.bits t)) (hctrp : c.workTapePos jctr = 0)
    (hwin : c.workTapes jwin = FinTM.bufferTape (x.take t)) (hwinp : c.workTapePos jwin = 0)
    (htbl : c.workTapes jtbl = FinTM.bufferTape (tableBitsK (F.machine (F.decode α)).tr))
    (htblp : c.workTapePos jtbl = 0)
    (hsm : c.workTapes jsm =
      StepBlock.summaryCells none (unaryFin (F.machine (F.decode α)).q₀))
    (hsmp : c.workTapePos jsm = 0)
    (hpas : ∀ i, c.workTapes (ιP i) = (fun _ => none) ∧ c.workTapePos (ιP i) = 0) :
    ∃ d : Cfg (F.k + 2) Bool (Σ key, StepBlock.Ph F.k key) (x.take t),
      d.state = some (StepBlock.exit F.k true) ∧
      StepBlock.Rep (F.machine (F.decode α)).tr
        ((F.machine (F.decode α)).initCfg (x.take t)) d ∧
      d.output = [] ∧
      c.mapState (fun _ => ((CounterLoopState.dec FlagPhase.run, true) :
          CounterLoopState (Σ key, StepBlock.Ph F.k key) × Bool)) =
        embedEmitCfg g c.workTapes c.workTapePos []
          (vhostCfg (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) d
            (FinTM.bufferTape t.bits) 0) true c.inputPos []) := by
  obtain ⟨wt, wtP, wtT, wtS⟩ : ∃ wt : Fin (F.k + 2) → ℤ → Option Bool,
      (∀ i, wt (Fin.castAdd 2 i) = fun _ => none) ∧
      wt (Fin.natAdd F.k 0) = FinTM.bufferTape (tableBitsK (F.machine (F.decode α)).tr) ∧
      wt (Fin.natAdd F.k 1) =
        StepBlock.summaryCells none (unaryFin (F.machine (F.decode α)).q₀) :=
    ⟨Fin.addCases (motive := fun _ => ℤ → Option Bool) (fun _ => fun _ => none)
        (fun j => if j = 0 then FinTM.bufferTape (tableBitsK (F.machine (F.decode α)).tr)
          else StepBlock.summaryCells none (unaryFin (F.machine (F.decode α)).q₀)),
      fun i => by rw [Fin.addCases_left],
      by
        rw [Fin.addCases_right]
        try exact if_pos rfl,
      by
        rw [Fin.addCases_right]
        try exact if_neg (by decide)⟩
  obtain ⟨d, hds, hdi, hdw, hdp, hdo⟩ :
      ∃ d : Cfg (F.k + 2) Bool (Σ key, StepBlock.Ph F.k key) (x.take t),
        d.state = some (StepBlock.exit F.k true) ∧ d.inputPos = 1 ∧ d.workTapes = wt ∧
          d.workTapePos = (fun _ => 0) ∧ d.output = [] :=
    ⟨⟨some (StepBlock.exit F.k true), 1, wt, fun _ => 0, []⟩, rfl, rfl, rfl, rfl, rfl⟩
  have hrep : StepBlock.Rep (F.machine (F.decode α)).tr
      ((F.machine (F.decode α)).initCfg (x.take t)) d := by
    rw [StepBlock.Rep_iff, MultiTapeTM.initCfg_eq, Cfg.init_inputPos, Cfg.init_output,
      Cfg.init_state, StepBlock.outputSummary_nil, Option.map_some, Option.getD_some,
      StepBlock.tableTape_eq, StepBlock.summaryTape_eq, hdi, hdw, hdp]
    refine ⟨rfl, fun i => ⟨?_, ?_⟩, wtT, wtS, rfl, rfl⟩
    · rw [wtP i]
      funext q
      rw [Cfg.init_workTapes]
    · rw [Cfg.init_workTapePos]
  have hcl_tapes : ∀ i : Fin (F.k + 2 + 1),
      (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) d
        (FinTM.bufferTape (Nat.bits t)) 0).workTapes i =
      Fin.lastCases (FinTM.bufferTape (Nat.bits t)) d.workTapes i := by
    intro i
    rw [counter_cfg_eq]
  have hcl_pos : ∀ i : Fin (F.k + 2 + 1),
      (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) d
        (FinTM.bufferTape (Nat.bits t)) 0).workTapePos i =
      Fin.lastCases 0 d.workTapePos i := by
    intro i
    rw [counter_cfg_eq]
  have hcl_in : (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) d
      (FinTM.bufferTape (Nat.bits t)) 0).inputPos = d.inputPos := by
    rw [counter_cfg_eq]
  have hcl_out : (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) d
      (FinTM.bufferTape (Nat.bits t)) 0).output = d.output := by
    rw [counter_cfg_eq]
  have hcl_state : (counterLoopCfg (some (CounterLoopState.dec FlagPhase.run)) d
      (FinTM.bufferTape (Nat.bits t)) 0).state =
      some (CounterLoopState.dec FlagPhase.run) := by
    rw [counter_cfg_eq]
  refine ⟨d, hds, hrep, hdo, ?_⟩
  refine (embedEmitCfg_eq g c.workTapes c.workTapePos [] _ _ ?_ ?_ ?_ ?_ ?_).symm
  · rw [vhostCfg_state, hcl_state, Cfg.mapState_state, hst, Option.map_some, Option.map_some]
  · rw [vhostCfg_inputPos, Cfg.mapState_inputPos]
  · rw [vhostCfg_output, hcl_out, hdo, Cfg.mapState_output, hout, List.nil_append,
      List.nil_append]
  · intro i
    induction i using Fin.addCases with
    | left i0 =>
      obtain rfl : i0 = 0 := Subsingleton.elim _ _
      refine ⟨funext fun q => ?_, ?_⟩
      · rw [vhostCfg_workTapes, Fin.addCases_left, Cfg.mapState_workTapes, gw, hwin]
      · rw [vhostCfg_workTapePos, Fin.addCases_left, Cfg.mapState_workTapePos, gw, hwinp, hcl_in,
          hdi, Fin.val_one]
        norm_num
    | right j =>
      induction j using Fin.lastCases with
      | last =>
        refine ⟨funext fun q => ?_, ?_⟩
        · rw [vhostCfg_workTapes, Fin.addCases_right, hcl_tapes, Fin.lastCases_last,
            Cfg.mapState_workTapes, gc, hctr]
        · rw [vhostCfg_workTapePos, Fin.addCases_right, hcl_pos, Fin.lastCases_last,
            Cfg.mapState_workTapePos, gc, hctrp]
      | cast j =>
        induction j using Fin.addCases with
        | left i =>
          refine ⟨funext fun q => ?_, ?_⟩
          · rw [vhostCfg_workTapes, Fin.addCases_right, hcl_tapes, Fin.lastCases_castSucc, hdw,
              wtP, Cfg.mapState_workTapes, gP, (hpas i).1]
          · rw [vhostCfg_workTapePos, Fin.addCases_right, hcl_pos, Fin.lastCases_castSucc, hdp,
              Cfg.mapState_workTapePos, gP, (hpas i).2]
        | right j =>
          rcases (Fin.exists_fin_two (p := fun i => i = j)).mp ⟨j, rfl⟩ with rfl | rfl
          · refine ⟨funext fun q => ?_, ?_⟩
            · rw [vhostCfg_workTapes, Fin.addCases_right, hcl_tapes, Fin.lastCases_castSucc, hdw,
                wtT, Cfg.mapState_workTapes, gt, htbl]
            · rw [vhostCfg_workTapePos, Fin.addCases_right, hcl_pos, Fin.lastCases_castSucc, hdp,
                Cfg.mapState_workTapePos, gt, htblp]
          · refine ⟨funext fun q => ?_, ?_⟩
            · rw [vhostCfg_workTapes, Fin.addCases_right, hcl_tapes, Fin.lastCases_castSucc, hdw,
                wtS, Cfg.mapState_workTapes, gs, hsm]
            · rw [vhostCfg_workTapePos, Fin.addCases_right, hcl_pos, Fin.lastCases_castSucc, hdp,
                Cfg.mapState_workTapePos, gs, hsmp]
  · intro j _
    refine ⟨funext fun q => ?_, ?_⟩
    · rw [Cfg.mapState_workTapes]
    · rw [Cfg.mapState_workTapePos]

/-- **The startup's threshold into the verdict.** From a run of a machine `U` that first
reaches `done` at a configuration with the startup's threshold fields, the seam into the hosted
verdict embedded along the tape map halts, within the hosted verdict's bound after the threshold
and one dispatch step, with output exactly `[answer]`, where `answer` decides bounded acceptance
of the decoded machine on `x` itself.

**Proof sketch.** The junction gives the relabelled threshold as the embedded hosted start, with
a represented start `d` on the window. The window verdict runs from it and decides acceptance on
`x`. The seam's right run (`seamCompTM_runFrom_right`) and the forwarding transport
(`embedEmitTM_runFrom`) carry that run into the composite. Its state and output are read through
the relabelling's and the transport's field equations, after the threshold's empty output. -/
private theorem us_tail {K : ℕ} {Q : Type} [DecidableEq Q] (α x : List Bool) (t : ℕ)
    (U : MultiTapeTM K Bool Q) (done : Q) (g : Fin (1 + (F.k + 2 + 1)) ↪ Fin K)
    (ιP : Fin F.k ↪ Fin K) (jctr jwin jtbl jsm : Fin K)
    (gw : g (Fin.castAdd (F.k + 2 + 1) 0) = jwin)
    (gP : ∀ i, g (Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) = ιP i)
    (gt : g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd F.k 0))) = jtbl)
    (gs : g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd F.k 1))) = jsm)
    (gc : g (Fin.natAdd 1 (Fin.last (F.k + 2))) = jctr)
    (c₀ c : Cfg K Bool Q (pairEncode (pairEncode (Nat.bits t) α) x)) (T₁ : ℕ)
    (run : U.runFrom c₀ T₁ = c) (hst : c.state = some done)
    (cut : ∀ u < T₁, (U.runFrom c₀ u).state ≠ some done) (hout : c.output = [])
    (hctr : c.workTapes jctr = FinTM.bufferTape (Nat.bits t)) (hctrp : c.workTapePos jctr = 0)
    (hwin : c.workTapes jwin = FinTM.bufferTape (x.take t)) (hwinp : c.workTapePos jwin = 0)
    (htbl : c.workTapes jtbl = FinTM.bufferTape (tableBitsK (F.machine (F.decode α)).tr))
    (htblp : c.workTapePos jtbl = 0)
    (hsm : c.workTapes jsm =
      StepBlock.summaryCells none (unaryFin (F.machine (F.decode α)).q₀))
    (hsmp : c.workTapePos jsm = 0)
    (hpas : ∀ i, c.workTapes (ιP i) = (fun _ => none) ∧ c.workTapePos (ιP i) = 0) :
    ∃ T₂ ≤ t * (50 * ((tableBitsK (F.machine (F.decode α)).tr).length + 1)) +
        4 * t + 2 * t.bits.length + 3, ∃ answer : Bool,
      ((seamCompTM U done (embedEmitTM g (h1HostedVerdictTM F.k))
          (CounterLoopState.dec FlagPhase.run, true)).runFrom (c₀.mapState Sum.inl)
          (T₁ + 1 + T₂)).state = none ∧
      ((seamCompTM U done (embedEmitTM g (h1HostedVerdictTM F.k))
          (CounterLoopState.dec FlagPhase.run, true)).runFrom (c₀.mapState Sum.inl)
          (T₁ + 1 + T₂)).output = [answer] ∧
      (answer = true ↔ (F.toFinTM (F.decode α)).ComputesInTime x [true] t) := by
  obtain ⟨d, hds, hrel, hdo, junc⟩ :=
    us_junction F α x t g ιP jctr jwin jtbl jsm gw gP gt gs gc c done hst hout hctr hctrp hwin
      hwinp htbl htblp hsm hsmp hpas
  obtain ⟨T₂, bound, answer, halted, out, iff⟩ :=
    us_window_verdict F α x _ t d hds hrel c.inputPos hdo
  refine ⟨T₂, bound, answer, ?_⟩
  rw [seamCompTM_runFrom_right U done _ _ run hst cut T₂, junc, embedEmitTM_runFrom]
  refine ⟨?_, ?_, iff⟩
  · rw [Cfg.mapState_state, embedEmitCfg_state, halted]
    rfl
  · rw [Cfg.mapState_output, embedEmitCfg_output, out, List.nil_append]

/-- **The start.** A composite over a sum of states, restarted at the left tag of a state
`entry`, starts at the blank configuration at `entry`, relabelled by the left tag: input head `1`,
every tape blank, every head at `0`, empty output.

**Proof sketch.** The restarted machine's initial configuration is `Cfg.init` at the tagged state
(`initCfg_with_q₀`); compare it with the relabelled blank start field by field, through the
`Cfg.init` and `Cfg.mapState` field equations. -/
private theorem us_start {K : ℕ} {Q R : Type} (W : MultiTapeTM K Bool (Q ⊕ R)) (entry : Q)
    (z : List Bool) :
    ({ W with q₀ := Sum.inl entry } : MultiTapeTM K Bool (Q ⊕ R)).initCfg z =
      (⟨some entry, 1, fun _ _ => none, fun _ => 0, []⟩ : Cfg K Bool Q z).mapState Sum.inl := by
  rw [MultiTapeTM.initCfg_with_q₀]
  apply Cfg.ext
  · rw [Cfg.init_state, Cfg.mapState_state]
    rfl
  · rw [Cfg.init_inputPos, Cfg.mapState_inputPos]
  · funext j q
    rw [Cfg.init_workTapes, Cfg.mapState_workTapes]
  · funext j
    rw [Cfg.init_workTapePos, Cfg.mapState_workTapePos]
  · rw [Cfg.init_output, Cfg.mapState_output]

/-- **The simulator's run.** For a machine `U` that, from the blank start at `entry` on
`⟨⟨bits t, α⟩, x⟩`, first reaches `done` at a configuration with the startup's threshold fields,
the binary machine `S` (the seam of `U` into the hosted verdict embedded along the tape map,
restarted at `entry`) halts from its initial configuration within `T₁ + 1 + T₂` steps with
output `[answer]`, deciding bounded acceptance on `x`. This is the shape `us_verdict` takes.

**Proof sketch.** `us_start` turns `S`'s initial configuration into the relabelled blank start,
and the restart changes no run (`runFrom_with_q₀`); then `us_tail`. -/
private theorem us_run {K : ℕ} {Q : Type} [Fintype Q] [DecidableEq Q] (α x : List Bool)
    (t : ℕ) (U : MultiTapeTM K Bool Q) (entry done : Q) (g : Fin (1 + (F.k + 2 + 1)) ↪ Fin K)
    (ιP : Fin F.k ↪ Fin K) (jctr jwin jtbl jsm : Fin K)
    (gw : g (Fin.castAdd (F.k + 2 + 1) 0) = jwin)
    (gP : ∀ i, g (Fin.natAdd 1 (Fin.castSucc (Fin.castAdd 2 i))) = ιP i)
    (gt : g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd F.k 0))) = jtbl)
    (gs : g (Fin.natAdd 1 (Fin.castSucc (Fin.natAdd F.k 1))) = jsm)
    (gc : g (Fin.natAdd 1 (Fin.last (F.k + 2))) = jctr)
    (c : Cfg K Bool Q (pairEncode (pairEncode (Nat.bits t) α) x)) (T₁ : ℕ)
    (run : U.runFrom ⟨some entry, 1, fun _ _ => none, fun _ => 0, []⟩ T₁ = c)
    (hst : c.state = some done)
    (cut : ∀ u < T₁, (U.runFrom (⟨some entry, 1, fun _ _ => none, fun _ => 0, []⟩ :
      Cfg K Bool Q (pairEncode (pairEncode (Nat.bits t) α) x)) u).state ≠ some done)
    (hout : c.output = [])
    (hctr : c.workTapes jctr = FinTM.bufferTape (Nat.bits t)) (hctrp : c.workTapePos jctr = 0)
    (hwin : c.workTapes jwin = FinTM.bufferTape (x.take t)) (hwinp : c.workTapePos jwin = 0)
    (htbl : c.workTapes jtbl = FinTM.bufferTape (tableBitsK (F.machine (F.decode α)).tr))
    (htblp : c.workTapePos jtbl = 0)
    (hsm : c.workTapes jsm =
      StepBlock.summaryCells none (unaryFin (F.machine (F.decode α)).q₀))
    (hsmp : c.workTapePos jsm = 0)
    (hpas : ∀ i, c.workTapes (ιP i) = (fun _ => none) ∧ c.workTapePos (ιP i) = 0) :
    let S : FinTM Bool :=
      { k := K, State := Q ⊕ (CounterLoopState (Σ key, StepBlock.Ph F.k key) × Bool),
        tm := { seamCompTM U done (embedEmitTM g (h1HostedVerdictTM F.k))
          (CounterLoopState.dec FlagPhase.run, true) with q₀ := Sum.inl entry } }
    ∃ T₂ ≤ t * (50 * ((tableBitsK (F.machine (F.decode α)).tr).length + 1)) +
        4 * t + 2 * t.bits.length + 3, ∃ answer : Bool,
      (S.tm.runFrom (S.tm.initCfg (pairEncode (pairEncode (Nat.bits t) α) x))
          (T₁ + 1 + T₂)).state = none ∧
      (S.tm.runFrom (S.tm.initCfg (pairEncode (pairEncode (Nat.bits t) α) x))
          (T₁ + 1 + T₂)).output = [answer] ∧
      (answer = true ↔ (F.toFinTM (F.decode α)).ComputesInTime x [true] t) := by
  intro S
  obtain ⟨T₂, bound, answer, halted, out, iff⟩ :=
    us_tail F α x t U done g ιP jctr jwin jtbl jsm gw gP gt gs gc _ c T₁ run hst cut hout hctr
      hctrp hwin hwinp htbl htblp hsm hsmp hpas
  have hS : S.tm = ({ seamCompTM U done (embedEmitTM g (h1HostedVerdictTM F.k))
      (CounterLoopState.dec FlagPhase.run, true) with q₀ := Sum.inl entry } :
        MultiTapeTM K Bool (Q ⊕ (CounterLoopState (Σ key, StepBlock.Ph F.k key) × Bool))) := rfl
  refine ⟨T₂, bound, answer, ?_, ?_, iff⟩
  · rw [hS, MultiTapeTM.runFrom_with_q₀, us_start]
    exact halted
  · rw [hS, MultiTapeTM.runFrom_with_q₀, us_start]
    exact out

end StepBlockClients

/-- **The uniform bounded-acceptance simulator**: one finite binary machine and one degree such
that, on `⟨⟨bits t, α⟩, x⟩`, the machine answers `[true]` if the machine `α` denotes halts on `x`
with output exactly `[true]` within `t` steps, and `[false]` otherwise, within
`d · (|α| + |x| + t + 1)^d` steps. [AB09, §1.4.1, Theorem 1.9, time-bounded form; Example 3.6(3)'s
uniformity]

**Proof sketch.** Install the decoded machine's serialization by the polynomial canonizer
`Turing.MachineFormat.exists_polyCanonizer` through `Turing.FinTM.exists_installCallTM`; by
`F.serialize_eq` it is `serializeK (F.machine (F.decode α))`, of length at most
`max |α| |F.serialize F.fallback|` (`Turing.CodeFormat.serialize_decode_length_le`). The
interpreter startup `Turing.exists_interpreterStartup`, with `F.k` passive tapes reserved for the
simulated work tapes, reads the nested input and leaves the deadline word `bits t` on a counter,
the window `x.take t` on a buffer, and the table and the initial-state summary on two more tapes.
From there the step block's hosted clock and verdict run the decoded machine on the window for
`t` steps and emit one bit, `true` exactly when it halts with output `[true]` within `t`
(`h1HostedVerdict_accepts`); deterministic input locality makes acceptance on the window
acceptance on `x`. The ledger: the installer's polynomial, the startup's terms linear in `|α|`,
the serialization, `|bits t|` and `min t |x|`, and `t` rounds of at most `50 · (|table| + 1)`
steps with the counter's `4t + 2|bits t| + 3`, all at most `d · (|α| + |x| + t + 1)^d` for one
`d` depending only on the format.

**Implementation.** `S` is the startup seamed (`Turing.seamCompTM`) to the hosted verdict,
which runs embedded (`Turing.embedEmitTM`) along a tape map from the startup's roles: the window,
the reserved tapes as the mirrored work tapes, the table, the summary and the counter. `S` is
restarted at the startup's entry state, so its initial configuration is the startup's blank
start. The startup's threshold, relabelled to the clock's first state, is the hosted verdict's
start, with a represented initial configuration on the window; it is read through the field
equations of the virtual-input host, the counter loop and the forwarding embedding. The startup
is silent, so the verdict's bit is the only output.
-/
theorem exists_uniformSimulator :
    ∃ (S : FinTM Bool) (d : ℕ), ∀ (α x : List Bool) (t : ℕ),
      ((F.toFinTM (F.decode α)).ComputesInTime x [true] t →
        S.ComputesInTime (pairEncode (pairEncode (Nat.bits t) α) x) [true]
          (d * (α.length + x.length + t + 1) ^ d)) ∧
      (¬(F.toFinTM (F.decode α)).ComputesInTime x [true] t →
        S.ComputesInTime (pairEncode (pairEncode (Nat.bits t) α) x) [false]
          (d * (α.length + x.length + t + 1) ^ d)) := by
  obtain ⟨C, entryI, exitI, a, d₀, hk, inst⟩ := us_install F
  obtain ⟨K, Q, hF, hD, U, entry, done, ιP, jctr, jwin, jtbl, jsm, A, B, h1, h2, h3, h4, h5, h6,
      h7, h8, h9, h10, run⟩ :=
    exists_interpreterStartup (fun α => F.numStates (F.decode α))
      (fun α => F.machine (F.decode α)) C entryI exitI
      (fun α => a * ((α.length + 1) ^ d₀ + α.length +
        max α.length (F.serialize F.fallback).length + 1)) hk
      (fun x α => by rw [← serializeK_eq]; exact inst x α) F.k
  obtain ⟨g, gw, gP, gt, gs, gc⟩ := us_bank ιP jctr jwin jtbl jsm h1 h2 h3 h4 h5 h6 h7 h8 h9 h10
  let S : FinTM Bool :=
    { k := K, State := Q ⊕ (CounterLoopState (Σ key, StepBlock.Ph F.k key) × Bool),
      tm := { seamCompTM U done (embedEmitTM g (h1HostedVerdictTM F.k))
        (CounterLoopState.dec FlagPhase.run, true) with q₀ := Sum.inl entry } }
  refine ⟨S, a * ((F.serialize F.fallback).length + 4) +
      A * ((F.serialize F.fallback).length + 3) + 3 * B +
      50 * (F.serialize F.fallback).length + 110 + d₀ + 2, fun α x t => ?_⟩
  obtain ⟨T₁, hT₁, hdone, hcut, hin, hout, hctr, hctrp, hwin, hwinp, htbl, htblp, hsm, hsmp,
      hpas⟩ := run α x t (fun _ _ => none) (fun _ _ => rfl)
  obtain ⟨T₂, hT₂, answer, halt, out, hans⟩ :=
    us_run F α x t U entry done g ιP jctr jwin jtbl jsm gw gP gt gs gc _ T₁ rfl hdone hcut hout
      hctr hctrp hwin hwinp htbl htblp hsm hsmp hpas
  have hs : (pairEncode (F.numStates (F.decode α)).bits
      (unaryFin (F.machine (F.decode α)).q₀ ++ tableBitsK (F.machine (F.decode α)).tr)).length ≤
      max α.length (F.serialize F.fallback).length := by
    have h := F.serialize_decode_length_le α
    rw [F.serialize_eq, serializeK_eq] at h
    exact h
  exact us_verdict S _ (T₁ + 1 + T₂) _ answer _
    (us_ledger a d₀ A B (F.serialize F.fallback).length α.length x.length t T₁ T₂ _ _ _ _
      (by omega) hs (us_table_le F α) (length_bits_le_self t) hT₁ hT₂) halt out hans

end MachineFormat

end Turing
