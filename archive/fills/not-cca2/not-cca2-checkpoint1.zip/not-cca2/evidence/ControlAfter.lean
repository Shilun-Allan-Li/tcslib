import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity
import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF
import Mathlib.Tactic.Simps.Basic

run_cmd do
  let names : Array String := #[
    "Complexity.NUPPT.advInput",
    "Complexity.NUPPT.coinLen",
    "Complexity.NUPPT.inArg",
    "Complexity.NUPPT.inParam",
    "Complexity.NUPPT.ofPolyTimeUniform",
    "Complexity.NUPPT.runAt",
    "Complexity.NUPPT.runAtL",
    "Complexity.PolyTimeComputable",
    "Complexity.pairFstD",
    "Complexity.pairSndD",
    "TCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure",
    "TCSlib.Cryptography.Composability.FixedLengthScheme.indGame",
    "TCSlib.Cryptography.Games.advantage",
    "TCSlib.Cryptography.Negligible",
    "TCSlib.Cryptography.padFin",
    "Turing.pairEncode"]
  for spelling in names do
    let name := spelling.toName
    let some ci := (← Lean.getEnv).find? name | throwError "Missing seal candidate {name}"
    unless ci.isDefinition do throwError "Nondefinition seal candidate {name}"
    Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $(Lean.mkIdent name):ident))
    let status ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus name
    unless status == .irreducible do throwError "Seal not installed for {name}"
    Lean.logInfo m!"SEALED|{name}|{repr status}"

example (z : List Bool) : Complexity.NUPPT.inArg z =
    Complexity.pairSndD (Complexity.pairFstD (Complexity.pairFstD z)) := by
  rfl
