"""Build a replay seal from the elaborated type-and-value reference census."""
import json
from pathlib import Path
import sys

log = Path(sys.argv[1]).read_text()
rows = {}
for line in log.splitlines():
    if 'CANDIDATE|' not in line:
        continue
    name, home, status, instance = line.split('CANDIDATE|', 1)[1].split('|')
    reason = 'abbreviation' if status.endswith('.reducible') else None
    if name == 'Complexity.PolyExpr.eval':
        reason = 'notation explicitly exempted by issued brief'
    rows[name] = dict(name=name, home=home, status=status,
                      instance=instance == 'instance=true', skipped=reason)
rows = [rows[name] for name in sorted(rows)]
Path('../not-cca2/evidence/seal-candidates.json').write_text(json.dumps(rows, indent=2) + '\n')
active = [row for row in rows if not row['skipped']]
header = 'import Lean\nimport TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nimport TCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nimport Mathlib.Tactic.Simps.Basic\n\n'
names = ',\n    '.join(json.dumps(row['name']) for row in active)
seal = '''run_cmd do
  let names : Array String := #[
    %s]
  for spelling in names do
    let name := spelling.toName
    let some ci := (← Lean.getEnv).find? name | throwError "Missing seal candidate {name}"
    unless ci.isDefinition do throwError "Nondefinition seal candidate {name}"
    Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $(Lean.mkIdent name):ident))
    let status ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus name
    unless status == .irreducible do throwError "Seal not installed for {name}"
    Lean.logInfo m!"SEALED|{name}|{repr status}"
''' % names
source = Path('TCSlib/Cryptography/Encryption/PrivateKey/OracleFromPRF.lean').read_text()
body = source[source.index('set_option maxHeartbeats'):]
control = '''example (z : List Bool) : Complexity.NUPPT.inArg z =
    Complexity.pairSndD (Complexity.pairFstD (Complexity.pairFstD z)) := by
  rfl
'''
out = Path('../not-cca2/evidence')
(out / 'Seal.lean').write_text(header + seal + '\n' + body)
(out / 'ControlBefore.lean').write_text(header + control)
(out / 'ControlAfter.lean').write_text(header + seal + '\n' + control)
print('Candidates:', len(rows), 'active:', len(active), 'instances:', sum(r['instance'] for r in active))
for row in rows:
    print(row['name'], row['skipped'] or 'SEALED')
