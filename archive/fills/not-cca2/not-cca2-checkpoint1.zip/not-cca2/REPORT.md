# not-cca2 — checkpoint 1: adversary

This is a partial fill, not a completed proof. The target
`TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2` remains admitted.
The CPA and CCA1 admissions are unchanged. The final query-budget/simulation and
advantage proofs, full downstream sweep, and final target axiom check remain pending.

## Pins and scope

- Repository: `Shilun-Allan-Li/tcslib`.
- Exchange: `20ca57c15da54342358b27ae2fee359acf06560d`.
- Issue base: `4a09f3993eb9344fc5714610e41ab141a0144db8`.
- Fresh separate checkout; local branch `fill/not-cca2`. No push was performed.
- Lean 4.25.0; Mathlib `029db123ddaa7f8fd0d18cea3b1b33bf84dacd1e`.
- Only two tracked files changed: `FromPRF.lean` and `OracleFromPRF.lean` under
  `TCSlib/Cryptography/Encryption/PrivateKey/`.
- `FromPRF.lean` adds exactly the authorized `prfScheme_dec` reader with its formula
  and proof `rfl`. No other content there changed.
- `OracleFromPRF.lean` adds private helpers. All original declaration statements,
  statement prose, proof sketches and global simp attributes are unchanged at this checkpoint.

## Checked frontier

The machine is `NUPPT.ofPolyTimeUniform cca2Next_poly (.const 0)`. Its first activation
encodes the Challenge query on the all-false/all-true messages. Its second activation
encodes the Dec query on the last-bit-flipped challenge answer. Its third activation
encodes the negation of the final bit of the second answer. The polynomial-time proof
and the raw one-entry/two-entry activation equations are checked. The intended budget
is `.const 2`; its complete `toComp`/simulation proof is still pending.

Also checked are the list/vector last-bit identities: a nonempty suffix contains the
flipped bit; the pair prefix and nonce are preserved; length is preserved; the flipped
word is distinct; and unmasking the modified XOR string gives the flipped message.
Their use with the actual challenge and decryption machines is not yet proved.

The supplied 129-module prerequisite closure was checked serially in supplied order.
The initial target-file check exposed local proof errors, repaired in `owned-01.log`.
All first 128 modules passed in `bootstrap.tsv`; the repaired target file passed
`owned-01.log`. The reader addition passed in bootstrap module 122.
Every Lean invocation used `scripts/lean_check_tree.sh`, one module at a time.

## Reader discipline and axioms

No additional reader request or mathematical escalation at this checkpoint.
The elaborated type-and-value census includes generated helper declarations and
foreign references (`Refs.lean`, `logs/refs-checkpoint1-fixed.log`).
There are 18 distinct foreign definition candidates: 16 sealed, plus the explicitly
exempted `NUPPT.Coins` abbreviation and `PolyExpr.eval` notation. No foreign instance
definition occurs in this checkpoint's candidate set. `Seal.lean` replays the complete
owned file successfully with every active candidate irreducible. The control passes
before sealing and fails after sealing at the intended `inArg` definitional equality.
See `seal-candidates.json` and the three control/seal logs.

All new proved helpers and the adversary use only `propext`, `Classical.choice`,
and `Quot.sound` (subsets allowed). The target and its corollary still include
`sorryAx`, as expected at this partial checkpoint. No new source admission was added.
The full 232-module admission comparison and final style lint are pending.

## Environment and cache

Initial preflight: `nproc = 9`; overlay disk free **59,564,011,520 bytes**;
memory headroom **9,525,805,056 bytes**, using `/proc/meminfo`'s `MemAvailable`
fallback because `/sys` and cgroup files are not exposed. Both issued floors pass.
The clone, toolchain, cache, temporary files and oleans are on the disk-backed overlay.
`/tmp` is tmpfs and was not used as `TMPDIR`.

A fresh official Lean archive was downloaded and extracted for this task; its URL,
SHA-256 and extraction command are in `logs/toolchain-provenance.log`.
No other session's toolchain, dependency tree, package build or olean store was used.
The new task-local cache archive store initially did not exist (0 files, 0 bytes).
Only the 98 supplied direct Mathlib roots were requested. The first fetch encountered
603 HTTP 429 failures; the allowed retry fetched those 603 and successfully unpacked
all 2,381 files. No cleaned retry was needed. All present package URLs and revisions
match the manifest; the four unneeded documentation packages are ABSENT. Last pin
check: **PASS (all present packages match; order imports no absent package)**.
Zero-size package oleans: 0. A probe importing the first Mathlib root passed.

`/usr/bin/time` is absent. The wrapper `time_check.py` records each module's UTC
start/end, elapsed/user/system times, exit status and maximum child RSS through
Python's `resource.getrusage`; all Python runs used `python3 -I`.
No `lake build` or unfiltered cache fetch was run. The cache tool's own prescribed
internal bootstrap was left to Lake.

## Payload and continuation

`patches/` contains the complete local format-patch series from the issue base;
`src/` contains the exact committed owned files. `evidence/` contains issued inputs,
verification, cache/bootstrap logs, reference census, seal source and controls.
The delivery provenance and patch replay check are in `evidence/delivery.json`.

Next: connect the checked attack to the IND codec and actual challenge, prove the
CCA2 decryption answer, then compute the advantage and run the final checks.
