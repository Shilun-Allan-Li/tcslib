"""relatives.py <repo> <rev>: for each listed relative of headD_drop_ofFn (pre-existing statements and inline proof
chains found by dupscan.py and read by hand), print the declaration line at <rev> and whether Foundations/BitLists is
already in the file's import closure (git objects only)."""
import re, subprocess, sys
repo, rev = sys.argv[1:3]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True, text=True).stdout
BL = 'TCSlib/Cryptography/Foundations/BitLists.lean'
REL = [
    ('index-0 headD form', 'TCSlib/Cryptography/Foundations/BitLists.lean', 'headD_ofFn_one'),
    ('index-0 headD form', 'TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphismZK/Closeness.lean', 'headD_ofFn_block'),
    ('index-0 headD form', 'TCSlib/Cryptography/Encryption/PublicKey/NonMalleability/Simulation/SimIND.lean', 'eq_const_headD'),
    ('getD form', 'TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/SoundnessRep.lean', "getD_ofFn_lt'"),
    ('getD form', 'TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/Proofs.lean', 'getD_ofFn_lt'),
    ('getD form', 'TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphismZK/Closeness.lean', 'getD_ofFn_lt'),
    ('getD form', 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/ProtocolProofs.lean', 'ofFn_getD_lt'),
    ('getD form', 'TCSlib/Cryptography/SecureComputation/Yao.lean', "getD_ofFn'"),
    ('inline headD chain', 'TCSlib/Cryptography/Pseudorandom/NextBit.lean', 'headD_drop, List.getD_eq_getElem?_getD, List.getElem?_ofFn'),
    ('inline getD chain', 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/Simulator.lean', 'List.getD_eq_getElem?_getD, List.getElem?_ofFn, dif_pos'),
    ('inline getD chain', 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/Language.lean', 'List.getD_eq_getElem?_getD, List.getElem?_ofFn, dif_pos'),
    ('inline getD chain', 'TCSlib/Cryptography/ZeroKnowledge/Encoding.lean', 'List.getD_eq_getElem?_getD, List.getElem?_ofFn, dif_pos'),
]
g, cache = {}, {}
def imports(p):
    if p not in g:
        try: t = git('show', f'{rev}:{p}')
        except subprocess.CalledProcessError: t = ''
        g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(TCSlib\S*)', t)]
    return g[p]
def clo(p):
    seen, st = set(), [p]
    while st:
        x = st.pop()
        if x in seen: continue
        seen.add(x); st.extend(imports(x))
    return seen
for kind, f, key in REL:
    L = git('show', f'{rev}:{f}').split('\n')
    if ',' in key:
        hits = [i for i, l in enumerate(L) if key in l]
    else:
        pat = re.compile(r'^(?:(?:private|protected)\s+)?theorem\s+' + re.escape(key) + r'(?=[\s({:\[])')
        hits = [i for i, l in enumerate(L) if pat.match(l)]
    for i in hits:
        txt = ' '.join(x.strip() for x in L[i:i + 2]) if ',' not in key else L[i].strip()
        print(f'{kind}\t{f}:{i + 1}\tBitLists in closure: {BL in clo(f) or f == BL}\t{txt[:200]}')
