"""srcequality.py <repo> <evidence.zip> <rev>...: every built module's source_sha256 in the evidence ZIP's
build/results.jsonl against the blob of <module>.lean at each rev (git objects; a tree id also works)."""
import hashlib, json, subprocess, sys, zipfile
repo, zp = sys.argv[1:3]
rows = [json.loads(l) for l in zipfile.ZipFile(zp).read('build/results.jsonl').decode().splitlines() if l.strip()]
mods = [r for r in rows if 'module' in r]
print(f'{zp.split("/")[-1]}:build/results.jsonl: {len(mods)} module records, last record {sorted(rows[-1])}')
for rev in sys.argv[3:]:
    diff = []
    for r in mods:
        b = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{r["module"]}.lean'], capture_output=True).stdout
        if hashlib.sha256(b).hexdigest() != r['source_sha256']: diff.append(r['module'])
    print(f'{rev}: {len(mods) - len(diff)} equal, {len(diff)} differ {diff}')
print(f'rc 0: {sum(r["rc"] == 0 for r in mods)}; errors {sum(r["errors"] for r in mods)}; errors_diag '
      f'{sum(r["errors_diag"] for r in mods)}; sorry {sum(r["sorry"] for r in mods)}')
