"""pack32.py <repo> <out-dir>: Gate 32 (#316, headD_drop_ofFn promotion) re-checks from git objects only (no Lean).
Writes mergetrees.txt, imports.txt, downstream314.txt, headers.txt and namecheck.txt."""
import os, re, subprocess, sys
repo, out = sys.argv[1:3]
def git(*a, check=True):
    return subprocess.run(['git', '-C', repo, *a], check=check, capture_output=True, text=True)
rp = lambda r: git('rev-parse', r).stdout.strip()
HEAD = rp('c18afbe66101381eed1617801d942dcf691506ea'); PARENT = rp(HEAD + '^')
TIP = rp('origin/cryptography/pass-shelat-ch2-4'); PRE = rp('0e5e725dc80c94575ea27b863399ff1119926c96')
M314 = rp('59c2c1fbf8c1bb08f9d191012b7cdd7e15248531')
L313 = rp('94b31964ee94b97bf3ed3b4b4338cacae8183194'); L315 = rp('fbd37f447596d4207c8d08b7ef7602f57fe95198')
BL = 'TCSlib/Cryptography/Foundations/BitLists.lean'
MS = 'TCSlib/Cryptography/Authentication/Signatures/Lamport/MachineSpec.lean'
F314 = ['TCSlib/Cryptography/Pseudorandom/Functions/Defs.lean',
        'TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Reduction.lean']
PR = [MS, BL]
show = lambda rev, p: git('show', f'{rev}:{p}').stdout
def lean_paths(rev, base=None):
    return [p for p in git('diff', '--name-only', '--no-renames', base, rev).stdout.split() if p.endswith('.lean')] \
        if base else [p for p in git('ls-tree', '-r', '--name-only', rev).stdout.split() if p.endswith('.lean')]
def graph(rev):
    g = {}
    for p in lean_paths(rev):
        if p.startswith('TCSlib') or p.startswith('audits'):
            g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', show(rev, p))
                    if m.startswith('TCSlib') or m.startswith('audits')]
    return g
def closure(g, roots):
    seen, st = set(), list(roots)
    while st:
        x = st.pop()
        if x in seen or x not in g: continue
        seen.add(x); st.extend(g[x])
    return seen
def chain(g, src, dst):
    prev, st = {src: None}, [src]
    while st:
        x = st.pop(0)
        if x == dst:
            c = []
            while x: c.append(x); x = prev[x]
            return ' <- '.join(reversed([q[:-5].replace('/', '.') for q in c]))
        for y in g.get(x, []):
            if y not in prev: prev[y] = x; st.append(y)
    return None
def down(g, targets):
    return {p for p in g if p not in targets and set(targets) & closure(g, [p])}

# 1. trial merges
L = [f'PR #316 head {HEAD}, parent {PARENT} (= merge base with the tip: {rp(git("merge-base", HEAD, TIP).stdout.strip())})',
     f'records tip {TIP}; #314 merged at {M314} (second parent {rp(M314 + "^2")}); pre-merge tip {PRE}', '']
trees = {}
for name, rev in [('tip (#314 merged)', TIP), ('pre-#314-merge tip', PRE), ('#313 LE-gate29a head', L313),
                  ('#315 head', L315)]:
    r = git('merge-tree', '--write-tree', '--name-only', HEAD, rev, check=False)
    t = r.stdout.split('\n')[0]; trees[rev] = t
    L.append(f'git merge-tree --write-tree {HEAD} {rev} ({name}): {t} rc {r.returncode}')
    if r.returncode: L.append(r.stdout)
for rev, other in [(TIP, 'the tip'), (L313, '#313'), (L315, '#315')]:
    t = trees[rev]
    dh = [p for p in git('diff', '--name-only', HEAD, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    do = [p for p in git('diff', '--name-only', rev, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    L.append(f'merged tree {t} with {other}: Lean paths differing from the #316 head ({len(dh)}): {dh}')
    L.append(f'  and from {other} ({len(do)}): {do}')
L.append('')
L.append(f'#314 changed .lean paths {PRE[:8]}..{M314[:8]}: {lean_paths(M314, PRE)}')
L.append(f'#313 changed .lean paths (merge base with #316): {lean_paths(L313, rp(git("merge-base", L313, HEAD).stdout.strip()))}')
L.append(f'#315 changed .lean paths (merge base with #316): {lean_paths(L315, rp(git("merge-base", L315, HEAD).stdout.strip()))}')
L.append(f'#316 changed .lean paths: {lean_paths(HEAD, PARENT)}')
mb13 = rp(git('merge-base', L313, HEAD).stdout.strip())
L.append(f'#313 merge base with #316 {mb13}; its delta to the #316 parent ({mb13[:8]}..{PARENT[:8]}, the merged #311 and '
         f'#312): {lean_paths(PARENT, mb13)}; so the #313 merged tree differs from #313 by these and the 2 PR files')
open(os.path.join(out, 'mergetrees.txt'), 'w').write('\n'.join(L) + '\n')

# 2. imports
gh, gp = graph(HEAD), graph(PARENT)
L = [f'# import graph from git objects (TCSlib and audits modules), #316 head {HEAD[:8]}, parent {PARENT[:8]}']
for p in PR:
    a = re.findall(r'(?m)^import\s+\S+', show(PARENT, p)); b = re.findall(r'(?m)^import\s+\S+', show(HEAD, p))
    L.append(f'{p}: import lines identical at parent and head: {a == b}')
    L += [f'    {x}' for x in b]
L.append(f'TCSlib/audits imports of BitLists at the head: {gh[BL]}; closure of BitLists: {sorted(closure(gh, [BL]) - {BL})}')
L.append(f'cycle: BitLists in the closure of anything it imports: False (it imports no project module)')
L.append(f'MachineSpec imports BitLists directly: {BL in gh[MS]}')
for name, rev, p in [('#313 head', L313, 'TCSlib/Cryptography/Randomness/Learning/Random.lean'),
                     ('#316 head', HEAD, MS)]:
    g = graph(rev) if rev != HEAD else gh
    L.append(f'{name} {rev[:8]}: BitLists in the closure of {p}: {BL in closure(g, [p])}; chain: {chain(g, p, BL)}')
g15 = graph(L315)
for p in lean_paths(L315, rp(git('merge-base', L315, HEAD).stdout.strip())):
    L.append(f'#315 head {L315[:8]}: BitLists in the closure of {p}: {BL in closure(g15, [p])}')
dh = down(gh, [BL]); dm = down(gh, [MS])
L.append(f'modules downstream of BitLists at the head (TCSlib and audits, facades included): {len(dh)}; of MachineSpec: {len(dm)}')
L.append(f'  (each excluding the module itself; at the parent {len(down(gp, [BL]))} and {len(down(gp, [MS]))}; the maintainer '
         f'record, downcount.py at the parent, counts 245 and 6 with the module itself)')
open(os.path.join(out, 'imports.txt'), 'w').write('\n'.join(L) + '\n')

# 3. downstream of #314
gt = graph(TIP)
L = [f'# Is a #316 module downstream of #314\'s files? Graph at the tip {TIP[:8]} (#314 merged; #316 files at their base content)']
for p in PR:
    for f in F314:
        L.append(f'{p} downstream of {f}: {f in closure(gt, [p])}; chain: {chain(gt, p, f)}')
for f in F314:
    L.append(f'{f} downstream of a #316 module: {[p for p in PR if p in closure(gt, [f])]}')
both = sorted(p for p in gt if (set(F314) & closure(gt, [p])) and (set(PR) & closure(gt, [p])))
L.append(f'TCSlib/audits tip modules downstream of a #314 module and of a #316 module (a module counts as downstream of '
         f'itself): {len(both)}. (deltacheck-tip.txt lists {len(both)} plus the briefs/ evidence .lean files, which its graph '
         f'also reads.)')
L += [f'  {p}' for p in both]
open(os.path.join(out, 'downstream314.txt'), 'w').write('\n'.join(L) + '\n')

# 4. headers and docstrings of every base declaration of the two files
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)')
def decls(text):
    Ls = text.split('\n'); out = {}
    for i, l in enumerate(Ls):
        m = KW.match(l)
        if not m: continue
        kind, name = m.groups()
        j = i
        while j < len(Ls) and Ls[j].strip() != '': j += 1
        block = '\n'.join(Ls[i:j])
        if kind in ('theorem', 'lemma'):
            d, cut = 0, None
            for k, ch in enumerate(block):
                if ch in '([{⟨': d += 1
                elif ch in ')]}⟩': d -= 1
                elif d == 0 and block.startswith(':=', k): cut = k; break
            block = block[:cut] if cut is not None else block
        k = i - 1; doc = ''
        if k >= 0 and Ls[k].rstrip().endswith('-/'):
            s = k
            while s >= 0 and '/--' not in Ls[s]: s -= 1
            doc = '\n'.join(Ls[s:k + 1])
        out[name] = (kind, i + 1, block, doc)
    return out
L = [f'# headers (keyword line to the top-level := for theorems; the whole block for definitions) and docstrings,'
     f' parent {PARENT[:8]} -> head {HEAD[:8]}']
tot = same = 0
for p in PR:
    a, b = decls(show(PARENT, p)), decls(show(HEAD, p))
    for n in a:
        tot += 1
        ka, la, ha, da = a[n]; kb, lb, hb, db = b.get(n, (None, None, None, None))
        ok = hb == ha; same += ok
        L.append(f'{"IDENTICAL" if ok else "DIFF"}\theader\t{ka} {n}\t{p.split("/")[-1]}:{la}->{lb}\tdocstring '
                 f'{"identical" if da == db else "changed"}')
        if da != db:
            L.append(f'    docstring at parent: {da!r}\n    docstring at head:   {db!r}')
    for n in b:
        if n not in a:
            L.append(f'ADDED\t{b[n][0]} {n}\t{p.split("/")[-1]}:{b[n][1]}\theader {b[n][2]!r}')
    L.append(f'{p}: base declarations {len(a)}, head {len(b)}; order kept: '
             f'{[n for n in b if n in a] == list(a)}')
L.append(f'TOTAL {tot} base declarations, {same} headers identical')
open(os.path.join(out, 'headers.txt'), 'w').write('\n'.join(L) + '\n')

# 5. name check
L = ['# every occurrence of the name headD_drop_ofFn in TCSlib/ and audits/ (git grep on objects), with the file\'s'
     ' namespaces and opens']
for name, rev in [('#316 head', HEAD), ('tip', TIP), ('#313', L313), ('#315', L315)]:
    r = git('grep', '-n', '-w', 'headD_drop_ofFn', rev, '--', 'TCSlib', 'audits', check=False).stdout.splitlines()
    L.append(f'## {name} {rev[:8]}: {len(r)} lines')
    files = sorted({x.split(':')[1] for x in r})
    for f in files:
        t = show(rev, f)
        ns = re.findall(r'(?m)^namespace\s+(\S+)', t); op = re.findall(r'(?m)^\s*open\s+([^\n]+)', t)
        L.append(f'  {f}: namespaces {ns}; opens {op}')
        L += [f'    {x.split(":", 2)[2].strip()[:150]}  (line {x.split(":")[2]})' for x in r if x.split(':')[1] == f]
open(os.path.join(out, 'namecheck.txt'), 'w').write('\n'.join(L) + '\n')
print('OK', HEAD[:8], PARENT[:8], TIP[:8], {k[:8]: v[:8] for k, v in trees.items()})
