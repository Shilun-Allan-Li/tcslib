"""dupscan.py <repo> <rev>[@<base>]...: candidate copies of headD_drop_ofFn, from git objects (no Lean). For each rev and each
TCSlib/audits .lean file: (S) declarations whose statement (keyword to the top-level ':=') mentions ofFn together with
headD, getD, head?, getElem?, get? or drop; (P) proof lines that use the reading lemmas of the promoted proof
(headD_drop, getD_eq_getElem?_getD, getElem?_ofFn, headD_ofFn*, head?_drop, getD_ofFn*, ofFn_succ with headD).
With @<base>, only the .lean files changed from <base> to <rev>."""
import re, subprocess, sys
repo = sys.argv[1]
def git(*a): return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True, text=True).stdout
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*(theorem|lemma|def|abbrev|instance)\s+(\S+)')
TIGHT = re.compile(r'(ofFn\s+\(?[^=]*?\)\s*\)?(\.drop\s+[^)=]*\))?\.(headD|getD|head\?|get\?|get!|getI|head!)\b)|ofFn\s+[^=]*?\)\[[^\]]+\]\?|getElem\?\s+\(List\.ofFn')
READ = re.compile(r'headD_drop\b|getD_eq_getElem\?_getD|getElem\?_ofFn|headD_ofFn|head\?_drop|getD_ofFn|ofFn_succ.*headD|headD.*ofFn_succ')
for arg in sys.argv[2:]:
    rev, _, base = arg.partition('@')
    full = git('rev-parse', rev).strip()
    files = [p for p in (git('diff', '--name-only', '--no-renames', base, full) if base else
                         git('ls-tree', '-r', '--name-only', full)).split()
             if p.endswith('.lean') and (p.startswith('TCSlib/') or p.startswith('audits/'))]
    S, P = [], []
    for f in files:
        L = git('show', f'{full}:{f}').split('\n')
        i = 0
        while i < len(L):
            m = KW.match(L[i])
            if m:
                j, buf = i, []
                while j < len(L) and j < i + 12:
                    buf.append(L[j])
                    if ':=' in L[j] or re.search(r'\bby\s*$', L[j]): break
                    j += 1
                st = ' '.join(buf)
                st = st[:st.index(':=')] if ':=' in st else st
                if TIGHT.search(st) or (re.search(r'ofFn', m.group(2)) and re.search(r'headD|getD|get|drop|head', m.group(2))):
                    S.append(f'{f}:{i+1}\t{m.group(1)} {m.group(2)}\t{re.sub(chr(32)+"+", " ", st.strip())[:220]}')
            if READ.search(L[i]) and not KW.match(L[i]):
                P.append(f'{f}:{i+1}\t{L[i].strip()[:160]}')
            i += 1
    print(f'## rev {arg} = {full}: {len(files)} files; S {len(S)} statements; P {len(P)} proof lines')
    print('### S'); print('\n'.join(S))
    print('### P'); print('\n'.join(P))
    print()
