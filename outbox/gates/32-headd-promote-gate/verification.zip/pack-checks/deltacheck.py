"""deltacheck.py <repo> <tip> <head>: the base delta (merge-base..tip) against the PR (merge-base..head), from git
objects: paths touched by each, their intersection, whether any delta .lean module is in the import closure (at the
head) of a PR-changed module, and which tip modules import a delta module and a PR-changed module transitively."""
import re, subprocess, sys
repo, tip, head = sys.argv[1:4]
def git(*a): return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True, text=True).stdout
mb = git('merge-base', tip, head).strip()
delta = git('diff', '--name-only', '--no-renames', mb, tip).split()
pr = git('diff', '--name-only', '--no-renames', mb, head).split()
print('merge-base', mb)
print('delta commits', len(git('rev-list', f'{mb}..{tip}').split()), 'paths', len(delta))
print('delta non-record paths', [p for p in delta if not (p.startswith('briefs/') or p == 'PassShelatChapter5-8Plan.md')])
print('PR paths', pr)
print('intersection', sorted(set(delta) & set(pr)))
def graph(rev):
    tree = [p for p in git('ls-tree', '-r', '--name-only', rev).split() if p.endswith('.lean')]
    g = {}
    for p in tree:
        src = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{p}'], capture_output=True, text=True).stdout
        g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', src)]
        g[p] = [q for q in g[p] if q in set(tree) or q.startswith('TCSlib') or q.startswith('audits')]
    return g
def closure(g, roots):
    seen, st = set(), list(roots)
    while st:
        p = st.pop()
        if p in seen or p not in g: continue
        seen.add(p); st.extend(g[p])
    return seen
gh = graph(head)
dl = [p for p in delta if p.endswith('.lean')]
prl = [p for p in pr if p.endswith('.lean')]
cl = closure(gh, prl)
print('PR closure at head', len(cl), 'contains delta modules', sorted(set(dl) & cl))
gt = graph(tip)
up = {p: closure(gt, [p]) for p in gt}
both = sorted(p for p in gt if any(d in up[p] for d in dl) and any(q in up[p] for q in prl if q in gt))
print('tip modules downstream of a delta module and of an existing PR module', both)
