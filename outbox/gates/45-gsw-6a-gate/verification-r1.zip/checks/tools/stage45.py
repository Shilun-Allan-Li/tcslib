"""stage45.py <repo> <g45-dir> (Gate 45, the GSW 6a gate, maintainer staging; no Lean, no lake): builds from git objects,
the exchange delivery commit and the three recorded 6a evidence ZIPs (read in place, never re-run):
  out/pr358.diff.txt, out/pr359.diff.txt, out/pr35{8,9}-description.md, out/source-head-r1.json, out/sources-r1.zip,
  vstage/ (the verification tree), which mkverif45.py zips.
Every check here is a git-object read or a hash of a recorded file (diffs, hashes, merge-tree, import graphs, line counts)."""
import sys, os, json, hashlib, subprocess, zipfile, shutil, re
from collections import Counter, defaultdict

repo, g = sys.argv[1:3]
TIP = 'e1d39836ed4a69a34914c35f4c73c71de853dcc6'   # #358's merge base (records tip at the re-cut)
PIN = '8c5875fa268a622e4e166da5f7a992715097c2c7'   # records pin (origin/cryptography/pass-shelat-ch2-4 at staging)
O1 = 'a616adcac0760ab56b1b0a2a4869f4763843f9ab'    # #358 head, land/gsw-6a-o1
ST = '73aedcdaaaffef7e69ab012d9b9195f150bae68d'    # #359 head, land/gsw-6a-statements
M346 = '3f540c22360c869069a0fba684e23ce6f3cb20db'  # #346 merge, olean snapshot #5's tree
EXCH = 'd7a9adb5b70c70c1b6fb8dc3d0aa5a60d720c1ef'  # exchange delivery commit ("stmt gsw-6a: final")
W_O1, W_ST = '413e9aa42f6b96b4d65673c37c83819b2fb77579', 'ec36703b56513d575036fa75ddb0b2b9d3f893b6'
OTHERS = [('#357 land/pairings-bb1-sim', '7a98ba0140ce6334bef1f2a8d39c6dfceb6ccaff'),
          ('#347 cleanup/dw5-derand-readers', 'daa6e173cdd94cad1475b9a96eca613bce53ba61'),
          ('#355 land/cleanup-stage1', 'd3c7cb00092ad5913904654d922f30fc7d5fce4a')]
CODE = ['TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean', 'lake-manifest.json', 'lean-toolchain']
DP = 'inbox/fills/gsw-6a-statements/'
EV = os.path.join(repo, 'briefs/lattice-gsw/phase6/final-6a-r1')
Z1, Z2, Z5 = (os.path.join(EV, f'gsw-6a-final-r1-{k}-evidence.zip') for k in ('phase1', 'phase2', 'rereplay5'))
OUT, VS = os.path.join(g, 'out'), os.path.join(g, 'vstage')
for d in (OUT, VS):
    if os.path.exists(d): shutil.rmtree(d)
    os.makedirs(d)

def git(*a, text=True):
    return subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True, text=text).stdout
def gitrc(*a):
    r = subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True); return r.returncode, r.stdout
def show(rev, p): return git('show', f'{rev}:{p}', text=False)
def exists(rev, p): return subprocess.run(['git', '-C', repo, 'cat-file', '-e', f'{rev}:{p}'], capture_output=True).returncode == 0
def sha(b): return hashlib.sha256(b).hexdigest()
def put(rel, data):
    p = os.path.join(VS, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb').write(data if isinstance(data, bytes) else data.encode())
def lines_of(b):
    ls = b.decode().split('\n')
    return ls[:-1] if ls and ls[-1] == '' else ls

# 0. pins
assert git('rev-parse', 'origin/cryptography/pass-shelat-ch2-4').strip() == PIN
assert git('rev-parse', 'origin/land/gsw-6a-o1').strip() == O1 and git('rev-parse', 'origin/land/gsw-6a-statements').strip() == ST
assert git('merge-base', TIP, O1).strip() == TIP and git('rev-parse', f'{ST}~6').strip() == O1

files358 = git('diff', '--name-only', TIP, O1).split()
files359 = git('diff', '--name-only', O1, ST).split()
series = git('diff', '--name-only', TIP, ST).split()
assert len(files358) == 4 and len(files359) == 17 and len(series) == 18, (files358, files359, series)

# 1. PR diffs (two-dot from the PR base = merge base; equal to the three-dot view) and descriptions
diffs = {}
for n, a, b in ((358, TIP, O1), (359, O1, ST)):
    d2 = git('diff', a, b, text=False); d3 = git('diff', f'{a}...{b}', text=False)
    assert d2 == d3; diffs[n] = d2
    open(os.path.join(OUT, f'pr{n}.diff.txt'), 'wb').write(d2)
    shutil.copy(os.path.join(g, 'pr', f'body{n}.md'), os.path.join(OUT, f'pr{n}-description.md'))

# 2. source-head-r1.json
def finfo(f, base, head):
    b = show(head, f); ls = lines_of(b); w = [len(l) for l in ls]
    st = 'M' if exists(base, f) else 'A'
    return {'status': st, 'blob': git('rev-parse', f'{head}:{f}').strip(), 'sha256': sha(b), 'lines': len(ls),
            'lines_at_base': len(lines_of(show(base, f))) if st == 'M' else None,
            'sha256_at_base': sha(show(base, f)) if st == 'M' else None,
            'max_width': max(w) if w else 0, 'over_100': sum(x > 100 for x in w),
            'tabs': sum('\t' in l for l in ls), 'trailing_space': sum(l != l.rstrip(' ') for l in ls)}
def commits(a, b):
    out = []
    for c in git('rev-list', '--reverse', f'{a}..{b}').split():
        raw = git('cat-file', '-p', c)
        out.append({'commit': c, 'parent': git('rev-parse', f'{c}^').strip(), 'tree': git('rev-parse', f'{c}^{{tree}}').strip(),
                    'subject': git('log', '-1', '--format=%s', c).strip(),
                    'author': git('log', '-1', '--format=%an <%ae> %aI', c).strip(),
                    'committer': git('log', '-1', '--format=%cn <%ce> %cI', c).strip(),
                    'gpgsig': raw.count('\ngpgsig ') + raw.startswith('gpgsig '),
                    'files': git('diff', '--name-only', f'{c}^', c).split()})
    return out
c358, c359 = commits(TIP, O1), commits(O1, ST)
sh = {'records_pin': PIN, 'snapshot5_tree_commit': M346, 'exchange_delivery': EXCH,
      'worker_heads': {'o1': W_O1, 'stmt': W_ST},
      'pr358': {'head': O1, 'head_branch': 'land/gsw-6a-o1', 'base_branch': 'cryptography/pass-shelat-ch2-4', 'merge_base': TIP,
                'tree': git('rev-parse', f'{O1}^{{tree}}').strip(), 'diff_stat': git('diff', '--shortstat', TIP, O1).strip(),
                'diff_sha256': sha(diffs[358]), 'commits': c358, 'files': {f: finfo(f, TIP, O1) for f in files358}},
      'pr359': {'head': ST, 'head_branch': 'land/gsw-6a-statements', 'base_branch': 'land/gsw-6a-o1', 'base': O1,
                'tree': git('rev-parse', f'{ST}^{{tree}}').strip(), 'diff_stat': git('diff', '--shortstat', O1, ST).strip(),
                'diff_sha256': sha(diffs[359]), 'commits': c359, 'files': {f: finfo(f, O1, ST) for f in files359}},
      'series_vs_tip': {'paths': series, 'diff_stat': git('diff', '--shortstat', TIP, ST).strip(),
                        'pin_x_head_tree': git('merge-tree', '--write-tree', PIN, ST).strip()}}
open(os.path.join(OUT, 'source-head-r1.json'), 'w').write(json.dumps(sh, indent=1, sort_keys=True, ensure_ascii=False) + '\n')

# 3a. checks/series.txt
L = ['# series and pins (git objects; no Lean)\n',
     f'records pin {PIN}: {git("log", "-1", "--format=%s", PIN).strip()}',
     f'#358 merge base / re-cut tip {TIP}: {git("log", "-1", "--format=%s", TIP).strip()}',
     f'pin descends from {TIP[:8]}: {gitrc("merge-base", "--is-ancestor", TIP, PIN)[0] == 0}',
     'records commits tip..pin: ' + ' '.join(git('rev-list', '--reverse', f'{TIP}..{PIN}').split()),
     f'code paths changed tip..pin ({" ".join(CODE)}, machine-library-design.md): '
     f'{len(git("diff", "--name-only", TIP, PIN, "--", *CODE, "machine-library-design.md").split())}',
     f'code paths changed {M346[:8]} (snapshot #5 T)..tip: {len(git("diff", "--name-only", M346, TIP, "--", *CODE).split())}',
     f'#358 REST base.sha at staging is 3ef91b408b2a9303fa36c8ac696da532e4170ed0 (records-only descendant of the merge base): '
     f'ancestor of pin {gitrc("merge-base", "--is-ancestor", "3ef91b408b2a9303fa36c8ac696da532e4170ed0", PIN)[0] == 0}; '
     f'code paths {TIP[:8]}..3ef91b40: {len(git("diff", "--name-only", TIP, "3ef91b408b2a9303fa36c8ac696da532e4170ed0", "--", *CODE, "machine-library-design.md").split())}',
     f'pin x #359 head merge-tree: {sh["series_vs_tip"]["pin_x_head_tree"]}; paths differing from the pin: '
     + str(len(git('diff', '--name-only', PIN, sh['series_vs_tip']['pin_x_head_tree']).split())),
     f'tree of #358 head {sh["pr358"]["tree"]}; merge-tree tip x worker {W_O1[:8]}: {git("merge-tree", "--write-tree", TIP, W_O1).strip()}',
     f'tree of #359 head {sh["pr359"]["tree"]}; #359~1 tree {git("rev-parse", ST + "~1^{tree}").strip()}; merge-tree tip x worker {W_ST[:8]}: {git("merge-tree", "--write-tree", TIP, W_ST).strip()}', '']
for n, a, b, cs in ((358, TIP, O1, c358), (359, O1, ST, c359)):
    L.append(f'PR #{n}: git diff {a[:8]} {b[:8]} == three-dot: True; sha256 {sha(diffs[n])}; {git("diff", "--shortstat", a, b).strip()}')
    L.append(git('diff', '--numstat', a, b))
    for c in cs:
        L.append(f'  {c["commit"]} parent {c["parent"][:8]} tree {c["tree"][:8]} gpgsig={c["gpgsig"]}')
        L.append(f'    author {c["author"]}; committer {c["committer"]}')
        L.append(f'    {c["subject"]}; files {len(c["files"])}')
    L.append('')
for name, a, b in (('O1', W_O1 + '^', W_O1), ('statements', W_O1, W_ST)):
    L.append(f'patch-id of the worker series {name} vs the PR series:')
    for c in git('rev-list', '--reverse', f'{a}..{b}').split():
        L.append(f'  worker {c[:8]} {git("log", "-1", "--format=%s", c).strip()}')
L.append('\nSignatures are checked for presence of a gpgsig header only (no allowed-signers file on this host); the')
L.append('re-replay records the key identity per commit in rereplay5/landing/signatures.txt.')
put('checks/series.txt', '\n'.join(L) + '\n')

# 3b. checks/le-ren.txt: LE-ren as applied (#359 head commit) vs the phase-1 proposed diff, by hunk body; rename scan
z1 = zipfile.ZipFile(Z1)
prop = z1.read('gsw-6a-final-r1-phase1/landing/LE-ren-proposed.diff').decode()
appl = git('diff', f'{ST}~1', ST)
def hunks(t):
    out = {}; f = None; cur = None
    for l in t.split('\n'):
        if l.startswith('+++ '): f = l[6:].split('\t')[0].strip(); cur = None; continue
        if l.startswith(('--- ', 'diff ', 'index ')): continue
        if l.startswith('@@'):
            m = re.match(r'@@ (-\d+(?:,\d+)? \+\d+(?:,\d+)?) @@', l); cur = [m.group(1)]; out.setdefault(f, []).append(cur); continue
        if cur is not None and l != '': cur.append(l)
    return out
hp, ha = hunks(prop), hunks(appl)
R = ['# LE-ren: #359 head commit vs phase 1 landing/LE-ren-proposed.diff (hunk ranges and bodies; context text ignored)\n',
     f'files proposed {sorted(hp)}', f'files applied  {sorted(ha)}']
allok = sorted(hp) == sorted(ha)
for f in sorted(ha):
    for x, y in zip(ha[f], hp.get(f, [])):
        ok = x == y; allok &= ok
        R.append(f'  {f}: {x[0]} vs {y[0]}: {"IDENTICAL" if ok else "DIFFER"} ({len(x) - 1} lines)')
    allok &= len(ha[f]) == len(hp.get(f, []))
R.append(f'RESULT {"IDENTICAL" if allok else "DIFFER"}')
R.append(f'\ngit diff --stat {ST[:8]}~1 {ST[:8]}:\n' + git('diff', '--stat', f'{ST}~1', ST))
rc, out = gitrc('grep', '-n', '-E', r'TreeCircuit\.rename|rename_eval|depth_rename|rename_eq|\.rename\b', ST, '--', 'TCSlib', 'TCSlib.lean')
R.append(f'git grep rename family over TCSlib at the head: {"no match" if rc == 1 else out}')
rc, out = gitrc('grep', '-n', '-w', 'rename', ST, '--', 'machine-library-design.md')
R.append('machine-library-design.md word hits for rename at the head:\n' + out)
put('checks/le-ren.txt', '\n'.join(R) + '\n')

# 3c. checks/targets.txt: the 98 targets (delivered rowmap minus rename_eval, depth_rename) with file:line at the head
rowmap = show(EXCH, DP + 'evidence/stmt/rowmap.txt').decode().split('\n')
tg = [l.split('\t') for l in rowmap if l.count('\t') >= 4 and l.split('\t')[3] == 'sorry']
tg = [t for t in tg if t[1] not in ('TreeCircuit.rename_eval', 'TreeCircuit.depth_rename')]
T = ['# the 98 admitted targets at the #359 head (rowmap.txt of exchange d7a9adb5 minus the 2 LE-ren targets);',
     '# columns: row, declaration, file:line of its `theorem` line at the head, the line ending the declaration body is `sorry`\n']
src = {}
per = Counter(); missing = 0
for row, name, kind, st, f in [t[:5] for t in tg]:
    if f not in src: src[f] = lines_of(show(ST, f))
    short = name.split('.')[-1]; hit = None
    for i, l in enumerate(src[f]):
        if re.match(rf'\s*(private\s+)?theorem\s+(\S+\.)?{re.escape(short)}(\s|$)', l) and (name in l or short in l):
            cand = re.match(r'\s*(?:private\s+)?theorem\s+(\S+)', l).group(1)
            if cand == name or cand.endswith('.' + short) or cand == short:
                hit = i + 1
                if cand == name or name.endswith(cand): break
    if hit is None: missing += 1
    per[f] += 1
    T.append(f'{row}\t{name}\t{f.replace("TCSlib/Complexity/", "")}:{hit}')
T.append(f'\ntotal {len(tg)}; not located {missing}')
for f, n in sorted(per.items()): T.append(f'  {n:3d} {f}')
# sorry-token lines per file (comments and strings not stripped; a line whose code is `sorry`)
T.append('\nlines whose code is the token `sorry` (`^\\s*sorry\\s*$` or `:= by sorry`), per file at the head:')
tot = 0
for f in series:
    if not f.endswith('.lean'): continue
    n = sum(1 for l in lines_of(show(ST, f)) if re.match(r'^\s*sorry\s*$', l) or re.search(r':=\s*by\s+sorry\s*$', l))
    tot += n
    if n: T.append(f'  {n:3d} {f}')
T.append(f'  total {tot}')
put('checks/targets.txt', '\n'.join(T) + '\n')

# 3d. checks/sorryax-dependents.txt: the five non-target constants the axiom probe reports with sorryAx
D = ['# constants with sorryAx that are not targets (phase 2 R2-4 / re-replay S5-4): kind and declaration at the head\n']
for f, pats in (('TCSlib/Complexity/CircuitComplexity/NANDForm.lean', [r'def DAGCircuit\.toNANDForm\b', r'theorem DAGCircuit\.toNANDForm_eq\b']),
                ('TCSlib/Complexity/CircuitComplexity/NANDLayering.lean', [r'@\[simps', r'def DAGCircuit\.layerNAND\b'])):
    ls = lines_of(show(ST, f))
    for p in pats:
        for i, l in enumerate(ls):
            if re.search(p, l): D.append(f'{f}:{i+1}: {l.strip()}')
D += ['', 'Reading: `toNANDForm` and `layerNAND` are definitions whose bodies pass the admitted proofs N2 (`nandGadget_correct`)',
      'and N12/N13 (`layerGates_acyclic`, `layerOutput_lt`) as Prop arguments; `toNANDForm_eq` is an `rfl` theorem whose',
      'statement names `nandGadget_correct`; `layerNAND_gates` and `layerNAND_output` are the `simps` field equations of',
      '`layerNAND`. No definition body contains the `sorry` token. Plan r3 and brief check 5 foresee exactly this.']
put('checks/sorryax-dependents.txt', '\n'.join(D) + '\n')

# 3e. checks/tags.txt: citation anchors at the head (phase 1 citecheck.py's regex), per file
tagre = re.compile(r'\[(Bar89|BV14|BV11|AP14|Gen09|AB09)([^\]]*)\]', re.S)
A = ['# citation tags and pNNN-bNNN anchors at the #359 head (the regex of phase 1 tools/citecheck.py; existence of each',
     '# anchor in its ingest is phase 1 citations/citecheck.out, not re-checked here)\n']
tot = Counter(); anchors_total = 0
for f in series:
    if not f.endswith('.lean'): continue
    s = show(ST, f).decode(); c = Counter(); na = 0
    for m in tagre.finditer(s):
        segs = [(m.group(1), m.group(2).split(';')[0])]
        for seg in m.group(2).split(';')[1:]:
            mm = re.match(r'\s*(Bar89|BV14|BV11|AP14|Gen09|AB09)\b(.*)', seg, re.S)
            segs.append((mm.group(1), mm.group(2)) if mm else (segs[-1][0], seg))
        for t, body in segs:
            c[t] += 1; k = len(re.findall(r'p\d{3}-b\d{3}', body)); na += k
    anchors_total += na; tot.update(c)
    if c: A.append(f'{f}: tags {dict(sorted(c.items()))}; anchors {na}')
A.append(f'\nall series files: tags {dict(sorted(tot.items()))}; anchors {anchors_total}')
A.append(f'[Gen09] occurrences in the series files at the head: {tot.get("Gen09", 0)}')
put('checks/tags.txt', '\n'.join(A) + '\n')

# 3f. checks/sizes.txt
S = ['# line counts and widths at the heads (git objects)\n', 'path\tstatus\tlines (base -> head)\tmax width\tover 100']
for n in ('pr358', 'pr359'):
    S.append(f'## {n}')
    for f, i in sh[n]['files'].items():
        S.append(f'{f}\t{i["status"]}\t{i["lines_at_base"]} -> {i["lines"]}\t{i["max_width"]}\t{i["over_100"]}')
put('checks/sizes.txt', '\n'.join(S) + '\n')

# 3g. checks/mergetrees.txt and the import-overlap analysis
def tree_graph(rev):
    ls = git('ls-tree', '-r', '--name-only', rev, '--', 'TCSlib', 'TCSlib.lean').split()
    mods = {p[:-5].replace('/', '.'): p for p in ls if p.endswith('.lean')}
    imp = {}
    for m, p in mods.items():
        imp[m] = [l.split()[1] for l in show(rev, p).decode().split('\n') if l.startswith('import TCSlib')]
    return mods, imp
def downstream(imp, seeds):
    rev = defaultdict(set)
    for m, xs in imp.items():
        for x in xs: rev[x].add(m)
    seen, st = set(seeds), list(seeds)
    while st:
        x = st.pop()
        for y in rev[x]:
            if y not in seen: seen.add(y); st.append(y)
    return seen
def leanmods(paths): return {p[:-5].replace('/', '.') for p in paths if p.endswith('.lean') and (p.startswith('TCSlib/') or p == 'TCSlib.lean')}
MT = [f'# merge-tree of the #359 head {ST} (stacked on #358 {O1}) with other open PRs (git {git("--version").split()[2]})',
      f'# the series changes {len(series)} paths against {TIP[:8]}; import overlap from `import TCSlib.*` lines of the merged trees\n']
for name, h in [('records pin', PIN)] + OTHERS:
    got = git('rev-parse', h).strip(); mb = git('merge-base', ST, h).strip()
    rc, out = gitrc('merge-tree', '--write-tree', '--name-only', ST, h)
    tree = out.split('\n')[0]
    other = set(git('diff', '--name-only', mb, h).split()); mine = set(git('diff', '--name-only', mb, ST).split())
    MT.append(f'== {name} {h}: merge-base {mb}; rc={rc}; tree {tree}')
    if rc: MT.append('   ' + out.replace('\n', '\n   '))
    MT.append(f'   paths changed by the other side since the merge base: {len(other)}; shared with the #359 side since the merge base: {sorted(mine & other)}')
    MT.append(f'   shared with the 18 series paths: {sorted(set(series) & other)}')
    for lbl, hd in (('#358 head', O1),):
        rc2, out2 = gitrc('merge-tree', '--write-tree', '--name-only', hd, h)
        MT.append(f'   x {lbl}: rc={rc2}; tree {out2.split(chr(10))[0]}')
    if name == 'records pin': continue
    mods, imp = tree_graph(tree)
    own = other
    pm = leanmods(own) & set(mods); sm = leanmods(series) & set(mods)
    dpr, dst = downstream(imp, pm), downstream(imp, sm)
    MT.append(f'   in the merged tree: the PR\'s own Lean modules {len(pm)}, downstream {len(dpr)}; the series\' modules {len(sm)}, downstream {len(dst)}')
    MT.append(f'   modules downstream of both: {sorted(dpr & dst)}')
    AGG = {'TCSlib', 'TCSlib.Complexity.CircuitComplexity', 'TCSlib.ComputationalModels'}
    up, stk = set(), [m for m in sm - AGG]
    while stk:
        x = stk.pop()
        for y in imp.get(x, []):
            if y not in up: up.add(y); stk.append(y)
    MT.append(f'   the PR\'s modules in the import closure of a non-aggregate series module (all but TCSlib, CircuitComplexity, ComputationalModels): {sorted(pm & up)}')
    MT.append(f'   series modules downstream of the PR\'s modules: {sorted(sm & dpr)}')
MT += ['', 'Snapshot adoption (merge conditions): the 6a replays are adoptable only if the merge commit\'s Lean paths equal tree',
       'a461632b (O1) / 2c243bb1 (statements). Any other PR merging first changes Lean paths, so the literal condition fails and',
       'the 6a PR re-replays (P2-8.3); the module sets above show whether that re-replay rebuilds anything beyond the 6a set.']
put('checks/mergetrees.txt', '\n'.join(MT) + '\n')

# 3h. checks/tools-carry.txt: re-replay TOOLS.txt entries without a p2zip-match annotation, hashed in the phase-2 zip
z2, z5 = zipfile.ZipFile(Z2), zipfile.ZipFile(Z5)
tools = z5.read('gsw-6a-final-r1-rereplay5/tools/TOOLS.txt').decode().split('\n')
C = ['# re-replay tools/TOOLS.txt rows and their copies in the phase-1 and phase-2 zips (SHA-256 of zip members; nothing executed)\n']
p2 = {n: sha(zz.read(n)) for zz in (z1, z2) for n in zz.namelist() if (('/tools/' in n) or ('/probes/src/' in n)) and not n.endswith('/')}
for l in tools:
    if not l or l.startswith('#'): continue
    h, path = l.split()[0], l.split()[1]
    base = os.path.basename(path)
    hits = [n for n, s in p2.items() if os.path.basename(n) == base and s == h]
    C.append(f'{"MATCH" if hits else "NO-COPY"}\t{h[:16]}\t{path}\t{hits[0] if hits else ""}')
put('checks/tools-carry.txt', '\n'.join(C) + '\n')

# 3i. checks/blobs.txt: the PR files against the worker's commits and the bases against the issue base
ISSUE = 'f6f295a6502b72bbf498bb8c64b63f847e910866'
def same(a, b, f):
    try: return git('rev-parse', f'{a}:{f}') == git('rev-parse', f'{b}:{f}')
    except subprocess.CalledProcessError: return False
Bl = ['# blob identities (git objects)\n', f'#358 head {O1[:8]} vs worker O1 {W_O1[:8]}:']
Bl += [f'  {"SAME" if same(O1, W_O1, f) else "DIFF"} {f}' for f in files358]
Bl.append(f'#358 base {TIP[:8]} vs issue base {ISSUE[:8]} (the base of checkpoint 1\'s decls2 7/0/0 and frozen check):')
Bl += [f'  {"SAME" if same(TIP, ISSUE, f) else "DIFF"} {f}' for f in files358 if exists(TIP, f)]
Bl.append(f'#359 head~1 {ST[:8]}~1 (before LE-ren) vs worker statements head {W_ST[:8]}:')
Bl += [f'  {"SAME" if same(ST + "~1", W_ST, f) else "DIFF"} {f}' for f in series]
Bl.append(f'#359 head vs head~1 (LE-ren): ' + ' '.join(git('diff', '--name-only', f'{ST}~1', ST).split()))
Bl.append(f'TCSlib.lean: tip {TIP[:8]} vs issue base: {"SAME" if same(TIP, ISSUE, "TCSlib.lean") else "DIFF"}; '
          f'head vs tip: ' + git('diff', '-U0', TIP, ST, '--', 'TCSlib.lean').split('@@')[-1].strip().replace('\n', ' | '))
put('checks/blobs.txt', '\n'.join(Bl) + '\n')

# 4. records/ at the pin
recs = ['briefs/lattice-gsw/phase6/plan-section.md', 'briefs/lattice-gsw/phase6/rulings.md', 'briefs/lattice-gsw/phase6/questions.md',
        'briefs/lattice-gsw/phase6/checkpoint1-6a-review.md', 'briefs/lattice-gsw/phase6/final-6a-r1/review.md',
        'briefs/lattice-gsw/phase6/final-6a-r1/phase2.md', 'briefs/lattice-gsw/phase6/final-6a-r1/evidence-SHA256SUMS',
        'briefs/lattice-gsw/phase6/issued-6a-r1/README.md', 'briefs/lattice-gsw/phase6/issued-6a-r1/brief.md',
        'briefs/lattice-gsw/phase6/issued-6a-r1/dispatch.md', 'briefs/lattice-gsw/phase6/issued-6a-r1/fill-environment-addendum.md',
        'briefs/lattice-gsw/phase6/issued-6a-r1/SHA256SUMS', 'briefs/lattice-gsw/phase6/issued-6a-r1/base-sorries.txt',
        'briefs/pairings/gates/44-pairing-fills/findings-r1.md', 'briefs/pairings/gates/44-pairing-fills/findings-r2.md',
        'policy.md', 'workflow.md']
for p in recs: put('records/' + p, show(PIN, p))
plan = lines_of(show(PIN, 'LatticeCryptographyPlan.md'))
hdr = [i for i, l in enumerate(plan) if l.startswith('| Date | Decision/evidence |')][-1]
rows = [i for i, l in enumerate(plan) if re.match(r'\| 2026-11-1[6-9] ', l)]
put('records/decision-log-lattice.md',
    f'# Decision-log extract: LatticeCryptographyPlan.md at {PIN}, the table header (lines {hdr+1}-{hdr+2}) and every row dated '
    f'2026-11-16 or later (lines {rows[0]+1}-{rows[-1]+1})\n\n' + '\n'.join(plan[hdr:hdr+2] + plan[rows[0]:rows[-1]+1]) + '\n')
led = lines_of(show(PIN, 'briefs/pass-shelat-ch5-8/duplication-ledger.md'))
r54 = [i for i, l in enumerate(led) if l.startswith('| DL-54 ')][0]
th = [i for i in range(r54, -1, -1) if led[i].startswith('|---')][0] - 1
put('records/duplication-ledger-DL54.md',
    f'# Extract: briefs/pass-shelat-ch5-8/duplication-ledger.md at {PIN}, table header (lines {th+1}-{th+2}) and row DL-54 '
    f'(line {r54+1})\n\n' + '\n'.join(led[th:th+2] + [led[r54]]) + '\n')

# 5. delivery/ (exchange d7a9adb5, the small files)
dl = ['REPORT.md', 'patches/o1/COMMITS.tsv', 'patches/stmt/COMMITS.tsv',
      'evidence/git/diffstat.txt', 'evidence/git/heads.txt', 'evidence/git/reproduce.txt',
      'evidence/headers/frozen-check-final.txt', 'evidence/headers/control-alter-final.txt', 'evidence/headers/control-delete-final.txt',
      'evidence/stmt/rowmap.txt', 'evidence/stmt/targets-per-module.tsv', 'evidence/stmt/definitions-readers.txt',
      'evidence/stmt/quotes-check.txt', 'evidence/stmt/controls-spec.json', 'evidence/stmt/files.txt', 'evidence/stmt/modules.txt',
      'evidence/stmt/AxiomProbe.lean', 'evidence/stmt/AxiomProbe.log', 'evidence/stmt/AxiomProbe.log.summary',
      'evidence/probes-final/summary.txt']
ctl = [p[len(DP):] for p in git('ls-tree', '-r', '--name-only', EXCH, DP + 'evidence/rule10/controls/').split()
       if p.endswith(('.lean', '.log.summary'))]
for p in dl + ctl: put('delivery/' + p, show(EXCH, DP + p))
nctl = sum(p.endswith('.lean') for p in ctl)

# 6. phase1/ (whole), phase2/ and rereplay5/ (summary files; each zip's own SHA256SUMS kept as SHA256SUMS.original)
def copy_zip(z, root, dest, keep):
    kept, left = 0, 0
    for n in z.namelist():
        if n.endswith('/'): continue
        rel = n[len(root):]
        if rel == 'SHA256SUMS': put(f'{dest}/SHA256SUMS.original', z.read(n)); continue
        if keep(rel, z.getinfo(n).file_size): put(f'{dest}/{rel}', z.read(n)); kept += 1
        else: left += 1
    return kept, left
k1 = copy_zip(z1, 'gsw-6a-final-r1-phase1/', 'phase1', lambda r, s: True)
def keep2(r, s):
    if r.startswith(('clash/names-', 'r1/state', 'r2/state', 'r1/plan/', 'r2/plan/', 'r1/check', 'r2/check', 'r1/order/', 'r2/order/',
                     'r1/full-order', 'r2/full-order', 'lint/campaign-', 'tools/used/', 'scan/', 'snapshot/v', 'snapshot/after', 'snapshot/start', 'snapshot/end')):
        return (r.startswith('scan/') and s <= 131072 and not r.endswith(('items-head.json', '.pid')))
    if r.startswith('rule10/'):
        parts = r.split('/')
        if parts[1] in ('o1', 'stmt', 'root', 'base', 'drivers'):
            return len(parts) == 3 and s <= 65536 or r.endswith('root-chunks.txt')
        if parts[1] == 'delivered-controls': return r.endswith(('.out', '.txt', '.tsv')) and s <= 65536
        return s <= 65536
    if r.startswith(('probes/', 'r1/build', 'r2/build')): return s <= 32768 and not r.endswith('.pid')
    return s <= 65536
k2 = copy_zip(z2, 'gsw-6a-final-r1-phase2/', 'phase2', keep2)
k5 = copy_zip(z5, 'gsw-6a-final-r1-rereplay5/', 'rereplay5', keep2)

# 7. pr/ REST fields
for n in (358, 359):
    rest = json.load(open(os.path.join(g, 'pr', f'pr{n}-rest.json')))
    keep = {k: rest[k] for k in ('number', 'title', 'state', 'draft', 'created_at', 'updated_at', 'additions', 'deletions',
                                  'changed_files', 'commits', 'merged', 'mergeable_state')}
    keep['head'] = {'ref': rest['head']['ref'], 'sha': rest['head']['sha']}
    keep['base'] = {'ref': rest['base']['ref'], 'sha': rest['base']['sha']}
    keep['body_sha256'] = sha(rest['body'].encode())
    put(f'pr/pr{n}-rest-fields.json', json.dumps(keep, indent=1, sort_keys=True, ensure_ascii=False) + '\n')

# 8. sources-r1.zip
ents = []
for f in series:
    if f == 'machine-library-design.md': continue
    ents.append((f'head-73aedcda/{f}', show(ST, f), f'{ST}:{f}'))
for f in files358: ents.append((f'o1-a616adca/{f}', show(O1, f), f'{O1}:{f}'))
for f in series:
    if exists(TIP, f) and f != 'machine-library-design.md': ents.append((f'base-e1d39836/{f}', show(TIP, f), f'{TIP}:{f}'))
ctx = ['TCSlib/Complexity/CircuitComplexity/' + x + '.lean' for x in
       ('Basic', 'TreeDAG', 'DAGCircuit', 'DAGTransform', 'DAGFanin', 'Adder', 'NCAC', 'Hierarchy', 'Parity', 'LayeredDAG')] + \
      ['TCSlib/BooleanAnalysis/LMN/CircuitReindex.lean']
for f in ctx:
    assert git('rev-parse', f'{ST}:{f}') == git('rev-parse', f'{TIP}:{f}'), f
    ents.append((f'context-73aedcda/{f}', show(ST, f), f'{ST}:{f} (blob-equal at the tip)'))
refs = ['barrington-1989-bounded-width-bp', 'brakerski-vaikuntanathan-2014-fhe', 'brakerski-vaikuntanathan-2011-fhe']
for r in refs:
    for ext in ('.md', '.raw.md'):
        p = f'blueprint/src/references/{r}{ext}'; ents.append((f'references/{r}{ext}', show(PIN, p), f'{PIN}:{p}'))
readme = ['# Gate 45 source bundle', '', 'Every entry is read from git objects; SHA-256 of the bytes and the origin `rev:path`.', '',
          f'- `head-73aedcda/`: the 17 Lean paths of the 18-path series (#358 + #359) at the #359 head `{ST}`',
          '  (`machine-library-design.md` is not copied; its changed lines are in `pr359.diff.txt`).',
          f'- `o1-a616adca/`: #358\'s 4 files at its head `{O1}`.',
          f'- `base-e1d39836/`: the series Lean files that exist at the merge base `{TIP}` (Lean-equal to `{M346}`, snapshot #5).',
          '- `context-73aedcda/`: unchanged modules the new files import or cite (`Basic`, `TreeDAG`, `DAGCircuit`, `DAGTransform`,',
          '  `DAGFanin`, `Adder`, `NCAC`), the duplication-relevant `Hierarchy` (`widenCircuit`), `Parity` (dual-rail XOR, P6-Q6),',
          '  `LayeredDAG` (`toLayered`) and `BooleanAnalysis/LMN/CircuitReindex` (the `reidx` family of LE-ren); blob-equal at tip and head.',
          '- `references/`: the Bar89, BV14 and BV11 ingests (`.md`, `.raw.md`) that the 112 anchors cite. [AB09, p. 118] is a',
          '  pre-existing library tag with no ingest; [AP14] and [Gen09] are not cited by the series.', '',
          '| Entry | SHA-256 | Origin |', '|---|---|---|']
readme += [f'| `{n}` | `{sha(b)}` | `{o}` |' for n, b, o in ents]
with zipfile.ZipFile(os.path.join(OUT, 'sources-r1.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in [('README.md', ('\n'.join(readme) + '\n').encode())] + [(n, b) for n, b, _ in ents]:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16; z.writestr(zi, b)
print('series', len(series), 'sources entries', len(ents) + 1, 'targets', len(tg), 'controls', nctl,
      'phase1', k1, 'phase2 kept/left', k2, 'rereplay5 kept/left', k5)
