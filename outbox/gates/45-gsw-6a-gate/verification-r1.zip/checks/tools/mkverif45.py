"""mkverif45.py <repo> <stage-dir> <out.zip> (Gate 45, maintainer; no Lean): write POINTERS.md and MANIFEST.md into
<stage-dir>, copy the staging tools into checks/tools/, write <stage-dir>/SHA256SUMS over every other file, then zip
<stage-dir> deterministically (sorted paths, fixed timestamps, mode 0644). Gate 48's mkverif48 layout."""
import sys, os, zipfile, hashlib, subprocess, shutil
repo, st, outz = sys.argv[1:4]
PIN = '8c5875fa268a622e4e166da5f7a992715097c2c7'
EXCH = 'd7a9adb5b70c70c1b6fb8dc3d0aa5a60d720c1ef'
sha = lambda b: hashlib.sha256(b).hexdigest()
show = lambda p: subprocess.run(['git', '-C', repo, 'show', f'{PIN}:{p}'], capture_output=True, check=True).stdout
xshow = lambda p: subprocess.run(['git', '-C', repo, 'show', f'{EXCH}:{p}'], capture_output=True, check=True).stdout
here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(st, 'checks/tools'), exist_ok=True)
for t in ('stage45.py', 'mkverif45.py', 'mkbundle45.py'):
    if os.path.exists(os.path.join(here, t)): shutil.copy(os.path.join(here, t), os.path.join(st, 'checks/tools', t))

ev = 'briefs/lattice-gsw/phase6/final-6a-r1/'
zips = [ev + 'gsw-6a-final-r1-phase1-evidence.zip', ev + 'gsw-6a-final-r1-phase2-evidence.zip',
        ev + 'gsw-6a-final-r1-rereplay5-evidence.zip']
note = {zips[0]: 'whole, extracted under `phase1/`',
        zips[1]: 'summary files under `phase2/` (manifest `phase2/SHA256SUMS.original`)',
        zips[2]: 'summary files under `rereplay5/` (manifest `rereplay5/SHA256SUMS.original`)'}
P = ['# Pointers: evidence not copied whole into this ZIP', '',
     f'Records ZIPs at the records pin `{PIN}` (size in bytes and SHA-256 of the git blob; the same values are in',
     f'`records/{ev}evidence-SHA256SUMS`):', '', '| Path | Bytes | SHA-256 | Here |', '|---|---:|---|---|']
for z in zips:
    b = show(z); P.append(f'| `{z}` | {len(b)} | `{sha(b)}` | {note[z]} |')
P += ['', 'Left out of `phase2/` and `rereplay5/`: the raw seal records, seal and control sources, probe and seal run logs',
      '(`rule10/{o1,stmt,root,base}/**` below the first level, `delivered-controls/*.lean.txt`), the stateplan state, plan',
      'and order files, the full state-check outputs (`r1/check*.txt`, `r2/check*.txt`; `accept.txt` and `linkcheck*.txt` are here),',
      'the clash name lists, the `campaign_style_lint` full outputs (their FAIL/WARN diffs are here), the scan item lists',
      '(`scan/*/items-head.json`) and `tools/used/` (whose SHA-256 are in `rereplay5/tools/TOOLS.txt` and checked in',
      '`checks/tools-carry.txt`). Each omitted file is listed with its SHA-256 in the ZIP\'s `SHA256SUMS.original`; verify the',
      'copies with `cd phase2 && sha256sum -c --ignore-missing SHA256SUMS.original` (likewise `rereplay5`).', '',
      f'The worker delivery is on the exchange at `{EXCH}` ("stmt gsw-6a: final"), `inbox/fills/gsw-6a-statements/`:',
      f'`SHA256SUMS` `{sha(xshow("inbox/fills/gsw-6a-statements/SHA256SUMS"))}`, `evidence/SHA256SUMS`',
      f'`{sha(xshow("inbox/fills/gsw-6a-statements/evidence/SHA256SUMS"))}`, `REPORT.md`',
      f'`{sha(xshow("inbox/fills/gsw-6a-statements/REPORT.md"))}` (the two manifests and `evidence/stmt/decls2.tsv`, equal to',
      '`phase1/statements/decls2.tsv`, are not copied). Its patches (`patches/o1/`, `patches/stmt/`), `src/`,',
      '`src-o1/`, build logs, seal records and probes are there; `delivery/` here copies the small files and the 30 paired',
      'controls. Checkpoint 1 is exchange `c0e11b31fd0146de79b3af48fede99714376d682`.']
open(os.path.join(st, 'POINTERS.md'), 'w').write('\n'.join(P) + '\n')

M = ['# verification-r1.zip · Gate 45 (GSW 6a: #358 O1 and #359 statements) round 1', '',
     'Every entry except `SHA256SUMS` is listed in `SHA256SUMS`. Nothing here was produced by a new Lean run: `phase1/`,',
     '`phase2/` and `rereplay5/` are the maintainer review\'s recorded evidence, copied byte for byte; `delivery/` is copied',
     'from the exchange delivery commit; `checks/` are git-object reads and hashes made at staging; `records/` are byte',
     'copies or marked extracts of records at the pin.', '',
     '| Path | What | Origin |', '|---|---|---|',
     '| `POINTERS.md` | evidence not copied whole, with sizes and SHA-256 | this staging |',
     '| `checks/series.txt` | pins, the records-only pin delta, Lean-equality of the base with `3f540c22`, both PR diffs, commits, trees | `git` at staging |',
     '| `checks/blobs.txt` | #358 vs the worker\'s O1, #359~1 vs the worker\'s head, bases vs the issue base | `git` at staging |',
     '| `checks/le-ren.txt` | LE-ren as applied vs phase 1\'s proposed diff, hunk by hunk; the `rename` scan | `git` + phase-1 ZIP |',
     '| `checks/targets.txt` | the 98 targets with file:line at the head; `sorry` lines per file | `git` + delivered `rowmap.txt` |',
     '| `checks/sorryax-dependents.txt` | the 5 non-target `sorryAx` constants: kind and declaration | `git` at staging |',
     '| `checks/tags.txt` | citation tags and anchors per file at the head (phase 1\'s regex) | `git` at staging |',
     '| `checks/sizes.txt` | line counts and widths of every changed file | `git` at staging |',
     '| `checks/mergetrees.txt` | `git merge-tree --write-tree` of #359 (and #358) with the pin, #357, #347, #355; import overlap | `git` at staging |',
     '| `checks/tools-carry.txt` | the re-replay\'s TOOLS.txt rows matched by SHA-256 to the phase-1/phase-2 ZIP copies | ZIP members at staging |',
     '| `checks/tools/` | the staging scripts | this staging |',
     '| `phase1/` | the phase-1 (static) review evidence, whole; its manifest is `phase1/SHA256SUMS.original` | `gsw-6a-final-r1-phase1-evidence.zip` |',
     '| `phase2/` | the phase-2 (snapshot #4) evidence\'s summary files: landing, statements (decls2), admissions, probes, rule10 summaries and controls, scans, lint diffs, clash result, cross-merge | `gsw-6a-final-r1-phase2-evidence.zip` |',
     '| `rereplay5/` | the snapshot-#5 re-replay\'s summary files: landing (range-diff, trees, signatures), recut map, admissions, probes, coe-A seal tables, `carry/` (closure keys, seal comparisons, root requests), lint, clash, tools, drafts | `gsw-6a-final-r1-rereplay5-evidence.zip` |',
     '| `delivery/` | REPORT, COMMITS.tsv, rowmap, targets per module, definitions and readers, quotes check, axiom probe and log, frozen-file check, probe summary, the 30 paired controls | exchange `d7a9adb5` |',
     '| `records/briefs/lattice-gsw/phase6/…` | plan r3, rulings, questions, checkpoint-1 review, `review.md`, `phase2.md`, evidence sums, the issued package | records at the pin |',
     '| `records/briefs/pairings/gates/44-pairing-fills/findings-r{1,2}.md` | Gate 44\'s findings (precedent G44-01..03) | records at the pin |',
     '| `records/policy.md`, `records/workflow.md` | the repository standards and the campaign workflow | records at the pin |',
     '| `records/decision-log-lattice.md` | `LatticeCryptographyPlan.md` decision-log rows dated 2026-11-16 or later | extract at the pin |',
     '| `records/duplication-ledger-DL54.md` | ledger row DL-54 (LE-ren\'s `reidx` move) | extract at the pin |',
     '| `pr/pr358-rest-fields.json`, `pr/pr359-rest-fields.json` | the PRs\' REST fields at staging (head, base, counts, body SHA-256) | GitHub REST |']
open(os.path.join(st, 'MANIFEST.md'), 'w').write('\n'.join(M) + '\n')

files = sorted(os.path.relpath(os.path.join(r, f), st) for r, _, fs in os.walk(st) for f in fs)
files = [f for f in files if f != 'SHA256SUMS' and '__pycache__' not in f]
with open(os.path.join(st, 'SHA256SUMS'), 'w') as o:
    for f in files: o.write(f'{sha(open(os.path.join(st, f), "rb").read())}  {f}\n')
with zipfile.ZipFile(outz, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in files + ['SHA256SUMS']:
        zi = zipfile.ZipInfo(f, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16; z.writestr(zi, open(os.path.join(st, f), 'rb').read())
print(f'{len(files) + 1} entries; SHA256SUMS {sha(open(os.path.join(st, "SHA256SUMS"), "rb").read())}')
