# Pointers: evidence not copied whole into this ZIP

Records ZIPs at the records pin `8c5875fa268a622e4e166da5f7a992715097c2c7` (size in bytes and SHA-256 of the git blob; the same values are in
`records/briefs/lattice-gsw/phase6/final-6a-r1/evidence-SHA256SUMS`):

| Path | Bytes | SHA-256 | Here |
|---|---:|---|---|
| `briefs/lattice-gsw/phase6/final-6a-r1/gsw-6a-final-r1-phase1-evidence.zip` | 30408 | `ef2b38ecfb1bdbcdea8832d7707c4ce070eb9eacf101c8ffed9afaa61531aa90` | whole, extracted under `phase1/` |
| `briefs/lattice-gsw/phase6/final-6a-r1/gsw-6a-final-r1-phase2-evidence.zip` | 13300493 | `efbca5677d482134152752fc959e50805a6ec05387e4b3fbf097ed6c984e7b33` | summary files under `phase2/` (manifest `phase2/SHA256SUMS.original`) |
| `briefs/lattice-gsw/phase6/final-6a-r1/gsw-6a-final-r1-rereplay5-evidence.zip` | 5675338 | `985cdc5cf3c30dffc779b05ee716519142b94bac45de4e653c0d3c11a4040f1b` | summary files under `rereplay5/` (manifest `rereplay5/SHA256SUMS.original`) |

Left out of `phase2/` and `rereplay5/`: the raw seal records, seal and control sources, probe and seal run logs
(`rule10/{o1,stmt,root,base}/**` below the first level, `delivered-controls/*.lean.txt`), the stateplan state, plan
and order files, the full state-check outputs (`r1/check*.txt`, `r2/check*.txt`; `accept.txt` and `linkcheck*.txt` are here),
the clash name lists, the `campaign_style_lint` full outputs (their FAIL/WARN diffs are here), the scan item lists
(`scan/*/items-head.json`) and `tools/used/` (whose SHA-256 are in `rereplay5/tools/TOOLS.txt` and checked in
`checks/tools-carry.txt`). Each omitted file is listed with its SHA-256 in the ZIP's `SHA256SUMS.original`; verify the
copies with `cd phase2 && sha256sum -c --ignore-missing SHA256SUMS.original` (likewise `rereplay5`).

The worker delivery is on the exchange at `d7a9adb5b70c70c1b6fb8dc3d0aa5a60d720c1ef` ("stmt gsw-6a: final"), `inbox/fills/gsw-6a-statements/`:
`SHA256SUMS` `e3aebb339b6f877ac75c384e5b9f4c39f33e18fd391a0d29a4fbb00e9206033f`, `evidence/SHA256SUMS`
`c7ba47b07cd88f6151d0f35d518bca8775d3abb5704a4130ff22c6eaf793b720`, `REPORT.md`
`01aba5c56498f9ea192e2929a474a665ee08d61593dd1dcf83b31fa11f96413a` (the two manifests and `evidence/stmt/decls2.tsv`, equal to
`phase1/statements/decls2.tsv`, are not copied). Its patches (`patches/o1/`, `patches/stmt/`), `src/`,
`src-o1/`, build logs, seal records and probes are there; `delivery/` here copies the small files and the 30 paired
controls. Checkpoint 1 is exchange `c0e11b31fd0146de79b3af48fede99714376d682`.
