# verification-r1.zip · Gate 45 (GSW 6a: #358 O1 and #359 statements) round 1

Every entry except `SHA256SUMS` is listed in `SHA256SUMS`. Nothing here was produced by a new Lean run: `phase1/`,
`phase2/` and `rereplay5/` are the maintainer review's recorded evidence, copied byte for byte; `delivery/` is copied
from the exchange delivery commit; `checks/` are git-object reads and hashes made at staging; `records/` are byte
copies or marked extracts of records at the pin.

| Path | What | Origin |
|---|---|---|
| `POINTERS.md` | evidence not copied whole, with sizes and SHA-256 | this staging |
| `checks/series.txt` | pins, the records-only pin delta, Lean-equality of the base with `3f540c22`, both PR diffs, commits, trees | `git` at staging |
| `checks/blobs.txt` | #358 vs the worker's O1, #359~1 vs the worker's head, bases vs the issue base | `git` at staging |
| `checks/le-ren.txt` | LE-ren as applied vs phase 1's proposed diff, hunk by hunk; the `rename` scan | `git` + phase-1 ZIP |
| `checks/targets.txt` | the 98 targets with file:line at the head; `sorry` lines per file | `git` + delivered `rowmap.txt` |
| `checks/sorryax-dependents.txt` | the 5 non-target `sorryAx` constants: kind and declaration | `git` at staging |
| `checks/tags.txt` | citation tags and anchors per file at the head (phase 1's regex) | `git` at staging |
| `checks/sizes.txt` | line counts and widths of every changed file | `git` at staging |
| `checks/mergetrees.txt` | `git merge-tree --write-tree` of #359 (and #358) with the pin, #357, #347, #355; import overlap | `git` at staging |
| `checks/tools-carry.txt` | the re-replay's TOOLS.txt rows matched by SHA-256 to the phase-1/phase-2 ZIP copies | ZIP members at staging |
| `checks/tools/` | the staging scripts | this staging |
| `phase1/` | the phase-1 (static) review evidence, whole; its manifest is `phase1/SHA256SUMS.original` | `gsw-6a-final-r1-phase1-evidence.zip` |
| `phase2/` | the phase-2 (snapshot #4) evidence's summary files: landing, statements (decls2), admissions, probes, rule10 summaries and controls, scans, lint diffs, clash result, cross-merge | `gsw-6a-final-r1-phase2-evidence.zip` |
| `rereplay5/` | the snapshot-#5 re-replay's summary files: landing (range-diff, trees, signatures), recut map, admissions, probes, coe-A seal tables, `carry/` (closure keys, seal comparisons, root requests), lint, clash, tools, drafts | `gsw-6a-final-r1-rereplay5-evidence.zip` |
| `delivery/` | REPORT, COMMITS.tsv, rowmap, targets per module, definitions and readers, quotes check, axiom probe and log, frozen-file check, probe summary, the 30 paired controls | exchange `d7a9adb5` |
| `records/briefs/lattice-gsw/phase6/…` | plan r3, rulings, questions, checkpoint-1 review, `review.md`, `phase2.md`, evidence sums, the issued package | records at the pin |
| `records/briefs/pairings/gates/44-pairing-fills/findings-r{1,2}.md` | Gate 44's findings (precedent G44-01..03) | records at the pin |
| `records/policy.md`, `records/workflow.md` | the repository standards and the campaign workflow | records at the pin |
| `records/decision-log-lattice.md` | `LatticeCryptographyPlan.md` decision-log rows dated 2026-11-16 or later | extract at the pin |
| `records/duplication-ledger-DL54.md` | ledger row DL-54 (LE-ren's `reidx` move) | extract at the pin |
| `pr/pr358-rest-fields.json`, `pr/pr359-rest-fields.json` | the PRs' REST fields at staging (head, base, counts, body SHA-256) | GitHub REST |
