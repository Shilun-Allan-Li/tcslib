# Extract: briefs/pass-shelat-ch5-8/duplication-ledger.md at 8c5875fa268a622e4e166da5f7a992715097c2c7, table header (lines 60-61) and row DL-54 (line 86)

| Id | New declaration (where) | Existing copy (where) | Status | Resolution |
|---|---|---|---|---|
| DL-54 | (none landed: LE-ren drops the delivered `TreeCircuit.rename`, `rename_eval`, `depth_rename` from the GSW phase 6a statements, G6A-F01) | `TreeCircuit.reidx`, `reidx_eval`, `reidx_depth` (`BooleanAnalysis/LMN/CircuitReindex.lean:24/29/46`), which the 6a formula layer uses instead | Accepted (Seyoon, 2026-11-17, 6a ruling Q1) | Move the `reidx` family into the `Complexity/` formula combinators (`Combinators`) later, so the core formula layer need not import a `BooleanAnalysis/LMN` file (deferred, out of the Pass–shelat cleanup). |
