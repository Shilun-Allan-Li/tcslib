#!/bin/bash
# Gate 46 staging: git-object checks of #376/#377 (no Lean). Usage: series.sh <repo>
set -u
R=$1; cd "$R"
TIP=38123ccbebef878cd25dd2d2761de1b40ba7e421     # records tip the PRs were cut on
REC=$(git rev-parse 9ae6b909)                      # records tip at staging (pin parent)
O2=04ba2446f541c39dd02aefaa97a9eb31dbbda748; ST=7563734a8badba842223e0687c719b3b4692e9d2
S10=cf6a2266; W_O2=5bd5ada5f42c5e1228ea84ad70f4d8c52a3644fd; W_ST=8f92fe7d53967bc488a4075fb38210e7d40b9031
LEAN='TCSlib TCSlib.lean lean-toolchain lake-manifest.json lakefile.lean scripts audits'
echo "# series.txt"; echo "tip $TIP; staging records $REC; #376 $O2; #377 $ST"
echo; echo "## commits (hash tree parents | author | committer | gpgsig lines | subject)"
for c in $(git rev-list --reverse $TIP..$ST); do
  echo "$(git log -1 --format='%H %T %P | %an <%ae> | %cn <%ce> %cI' $c) | gpgsig $(git cat-file -p $c | grep -c '^gpgsig') | $(git log -1 --format=%s $c)"
  git diff-tree --no-commit-id -r --numstat $c | sed 's/^/    /'
done
echo; echo "## trailers of the landing-edit commit"; git log -1 --format=%B $ST | tail -3
echo; echo "## the PR diffs"
echo "#376 $TIP..$O2:"; git diff --stat $TIP $O2 | tail -1
echo "#377 $O2..$ST:"; git diff --stat $O2 $ST | tail -1
echo "paths changed $TIP..$ST:"; git diff --name-status $TIP $ST
echo; echo "## range identity with the worker series (tree equality per file)"
for f in $(git diff --name-only $TIP $O2); do echo "$f O2-head $(git rev-parse $O2:$f) worker $(git rev-parse $W_O2:$f)"; done
for f in $(git diff --name-only $O2 $ST); do echo "$f picks(~1) $(git rev-parse $ST~1:$f) worker $(git rev-parse $W_ST:$f) head $(git rev-parse $ST:$f)"; done
