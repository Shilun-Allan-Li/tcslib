# Gate 46 staging: pins, commits and per-file facts (git objects only). Usage: sourcehead.py <repo> <out.json> <sizes.tsv>
import sys, subprocess, json, hashlib
repo, out, sizes = sys.argv[1:4]
def g(*a): return subprocess.run(['git','-C',repo,*a],capture_output=True,text=True).stdout
def gb(*a): return subprocess.run(['git','-C',repo,*a],capture_output=True).stdout
TIP='38123ccbebef878cd25dd2d2761de1b40ba7e421'; O2='04ba2446f541c39dd02aefaa97a9eb31dbbda748'
ST='7563734a8badba842223e0687c719b3b4692e9d2'; REC=g('rev-parse','9ae6b909').strip()
pins={'pr376':{'number':376,'branch':'land/gsw-6b-o2','head':O2,'tree':g('rev-parse',O2+'^{tree}').strip(),
               'parent':TIP,'rest_base_sha':'1a9a32959cc58d7a882d0f6a7e2b0003b52f82ae','worker':'5bd5ada5f42c5e1228ea84ad70f4d8c52a3644fd'},
      'pr377':{'number':377,'branch':'land/gsw-6b-statements','head':ST,'tree':g('rev-parse',ST+'^{tree}').strip(),
               'base':O2,'worker':'8f92fe7d53967bc488a4075fb38210e7d40b9031'},
      'records_pin':'<RECORDS>','records_tip_at_staging':REC,'pr_cut_tip':TIP,
      'snapshot10_T':g('rev-parse','cf6a2266').strip(),'delivery_exchange':'3b340824dde77433b2135a3c8d20c7ed194cf18c',
      'issued_base':'3e51b5f28900db6190f1eb2e6d207d27ee15d541','mathlib':'029db123ddaa7f8fd0d18cea3b1b33bf84dacd1e'}
commits=[]
for c in g('rev-list','--reverse',f'{TIP}..{ST}').split():
    raw=g('cat-file','-p',c)
    commits.append({'hash':c,'tree':g('rev-parse',c+'^{tree}').strip(),'parents':g('log','-1','--format=%P',c).split(),
        'author':g('log','-1','--format=%an <%ae> %aI',c).strip(),'committer':g('log','-1','--format=%cn <%ce> %cI',c).strip(),
        'gpgsig':'gpgsig' in raw,'subject':g('log','-1','--format=%s',c).strip(),
        'files':[l.split('\t') for l in g('diff-tree','--no-commit-id','-r','--numstat',c).splitlines()]})
files=[]; rows=['path\tbase_lines\thead_lines\thead_max_width\tover100\ttabs\ttrailing\thead_sha256']
for p in g('diff','--name-only',TIP,ST).split():
    def facts(rev):
        b=gb('show',f'{rev}:{p}')
        if not b and rev==TIP: return None
        t=b.decode('utf-8'); L=t.split('\n')
        if L and L[-1]=='': L=L[:-1]
        return {'blob':g('rev-parse',f'{rev}:{p}').strip(),'sha256':hashlib.sha256(b).hexdigest(),'lines':len(L),
                'max_width':max((len(l) for l in L),default=0),'over100':sum(len(l)>100 for l in L),
                'tabs':sum('\t' in l for l in L),'trailing':sum(l!=l.rstrip() for l in L)}
    base=facts(TIP) if p in g('ls-tree','-r','--name-only',TIP,p) else None
    head=facts(ST)
    files.append({'path':p,'status':'M' if base else 'A','base':base,'head':head})
    rows.append(f"{p}\t{base['lines'] if base else '-'}\t{head['lines']}\t{head['max_width']}\t{head['over100']}\t{head['tabs']}\t{head['trailing']}\t{head['sha256']}")
json.dump({'pins':pins,'commits':commits,'files':files},open(out,'w'),indent=1,ensure_ascii=False)
open(sizes,'w').write('\n'.join(rows)+'\n')
