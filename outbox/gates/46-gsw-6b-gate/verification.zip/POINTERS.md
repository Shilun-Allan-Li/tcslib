# POINTERS (not copied, or copied whole)

- Phase-1 evidence: `evidence/gsw-6b-final-r1-phase1-evidence.zip`, SHA-256
  `eed236aeedb3efa32b7dbdfc084686d0f881ba565145ee7984d707a3a364d7cf` (records `final-6b-r1/evidence-SHA256SUMS`);
  inner manifest 25/25 at staging.
- Phase-2 evidence: `evidence/gsw-6b-final-r1-phase2-evidence.zip`, SHA-256
  `60cfe32649c5692e50b12c86713498810aab10e9cabaa4e11545542ff3aa22af`; inner manifest 598/598 at staging.
- The worker's delivery is not copied: `inbox/fills/gsw-6b-statements/` on `exchange/pass-shelat-ch5-8` at
  `3b340824dde77433b2135a3c8d20c7ed194cf18c` (2,688 files; phase 1 verified its manifests 2,687/2,687 and 2,664/2,664).
- #368's evidence (Gate 50, merged): `briefs/lattice-gsw/phase6/owner-prereqs-6b/` (3/3 at staging).
- The replay trees `olean-replay-6b-o2` (map `e1d210bf…`, #376) and `olean-replay-6b-stmt-g46` (map `65ca0263…`, #377 at
  `7563734a`, a `cp -al` of `olean-replay-6b-stmt`, map `52ed7825…`, which it supersedes for #377) are on the maintainer
  host, kept for adoption.
