"""repoint_nmsim.py <worktree>: landing edit LE-repoint-nmsim. Re-points the nm-sim files to the consolidation's
names (code: every occurrence; docstrings/comments: only qualified stale spellings), removes the selective
`open AdaptiveCPA (...)` lines whose names moved, and deletes nm-sim's private padFin_replicate_false (DL-37)
in favour of Games.padFin_replicate_false. Prints counts per file and pattern."""
import sys, re, collections
W = sys.argv[1] + '/TCSlib/Cryptography/Encryption/PublicKey/NonMalleability/'
files = ['Simulation.lean'] + [f'Simulation/{m}.lean' for m in
         ['Challenge', 'Generic', 'Hybrid', 'IndSim', 'Recover', 'Reduction', 'Rounds', 'SimIND', 'SimINDGap', 'Simulator']]
def split(s):
    res = []; j = 0; L = len(s)
    while j < L:
        if s.startswith('/-', j):
            d = 1; e = j + 2
            while d and e < L:
                if s.startswith('/-', e): d += 1; e += 2
                elif s.startswith('-/', e): d -= 1; e += 2
                else: e += 1
            res.append(['c', s[j:e]]); j = e
        elif s.startswith('--', j):
            e = s.find('\n', j); e = L if e < 0 else e
            res.append(['c', s[j:e]]); j = e
        else:
            e1 = s.find('/-', j); e2 = s.find('--', j)
            e = min([x for x in (e1, e2) if x >= 0] or [L])
            res.append(['x', s[j:e]]); j = e
    return res
B = lambda n: r"(?<![\w.'])" + n + r"(?![\w'])"
QUAL = [  # qualified stale spellings: code and docs
    (r"(?<![\w.'])GGMRed\.ofFn_padFin_of_length(?![\w'])", 'ofFn_padFin_of_length'),
    (r"(?<![\w.'])ChallengeSim\.(expect_sample_equiv|expect_sample_comm|expect_sample_unique|expect_sub)(?![\w'])", r'ProbComp.\1'),
    (r"(?<![\w.'])AdaptiveCPA\.(castImpl|castImpl_eq|castImpl_self|expect_simulate_castImpl_toCompOn|simulate_castImpl_toCompOn|padFin_ofFn_zeroBits|simulate_eq_of_abs)(?![\w'])", r'Games.\1'),
    (r"(?<![\w.'])AdaptiveCPA\.ofFn_cast(?![\w'])", 'ofFn_cast'),
    (r"(?<![\w.'])AdaptiveCPA\.(ofFn_splitHalf_fst|ofFn_splitHalf_snd)(?![\w'])", r'FixedLengthScheme.\1'),
]
# unqualified names that resolved through `open AdaptiveCPA (...)` / `open ... ChallengeSim`, per file (code only)
UNQ_AC = {'Simulation.lean': ['castImpl', 'castImpl_eq', 'expect_simulate_castImpl_toCompOn', 'padFin_ofFn_zeroBits'],
          'Simulation/SimIND.lean': ['castImpl', 'castImpl_eq', 'ofFn_splitHalf_fst', 'ofFn_splitHalf_snd',
                                     'padFin_ofFn_zeroBits', 'expect_simulate_castImpl_toCompOn', 'simulate_eq_of_abs'],
          'Simulation/IndSim.lean': ['simulate_eq_of_abs'], 'Simulation/Simulator.lean': ['simulate_eq_of_abs']}
TARGET = {'castImpl': 'Games.castImpl', 'castImpl_eq': 'Games.castImpl_eq',
          'expect_simulate_castImpl_toCompOn': 'Games.expect_simulate_castImpl_toCompOn',
          'padFin_ofFn_zeroBits': 'Games.padFin_ofFn_zeroBits', 'simulate_eq_of_abs': 'Games.simulate_eq_of_abs',
          'ofFn_splitHalf_fst': 'FixedLengthScheme.ofFn_splitHalf_fst',
          'ofFn_splitHalf_snd': 'FixedLengthScheme.ofFn_splitHalf_snd'}
UNQ_PC = {'Simulation/SimIND.lean', 'Simulation/SimINDGap.lean'}  # `open ... ProbComp ChallengeSim`
OPENS = {'Simulation.lean': ['open AdaptiveCPA (castImpl castImpl_eq expect_simulate_castImpl_toCompOn padFin_ofFn_zeroBits)\n'],
         'Simulation/SimIND.lean': ['open AdaptiveCPA (castImpl castImpl_eq ofFn_cast ofFn_splitHalf_fst ofFn_splitHalf_snd\n  padFin_ofFn_zeroBits expect_simulate_castImpl_toCompOn simulate_eq_of_abs)\n'],
         'Simulation/IndSim.lean': ['open AdaptiveCPA (simulate_eq_of_abs)\n'],
         'Simulation/Simulator.lean': ['open AdaptiveCPA (simulate_eq_of_abs)\n']}
cnt = collections.Counter()
for f in files:
    p = W + f; s = open(p, encoding='utf-8').read()
    for o in OPENS.get(f, []):
        assert s.count(o) == 1, (f, o); s = s.replace(o, ''); cnt[(f, 'open AdaptiveCPA (...) removed')] += 1
    if f == 'Simulation/Challenge.lean':
        blk = s[s.index('/-- A padded run of `false`s is all `false`'):s.index('section Calls')]
        assert blk.count('private theorem padFin_replicate_false') == 1
        s = s.replace(blk, ''); cnt[(f, 'private padFin_replicate_false deleted')] += 1
    parts = split(s)
    for part in parts:
        for pat, rep in QUAL:
            part[1], c = re.subn(pat, rep, part[1])
            if c: cnt[(f, f"{'code' if part[0] == 'x' else 'doc'}: {pat.split(')')[1] if False else rep}")] += c
        if part[0] != 'x': continue
        for n in UNQ_AC.get(f, []):
            part[1], c = re.subn(B(n), TARGET[n], part[1])
            if c: cnt[(f, f'code: {n} -> {TARGET[n]}')] += c
        if f in UNQ_PC:
            for n in ['expect_sample_equiv', 'expect_sample_comm', 'expect_sample_unique', 'expect_sub']:
                part[1], c = re.subn(B(n), 'ProbComp.' + n, part[1])
                if c: cnt[(f, f'code: {n} -> ProbComp.{n}')] += c
        if f == 'Simulation/Challenge.lean':
            part[1], c = re.subn(B('padFin_replicate_false'), 'Games.padFin_replicate_false', part[1])
            if c: cnt[(f, 'code: padFin_replicate_false -> Games.padFin_replicate_false')] += c
    open(p, 'w', encoding='utf-8').write(''.join(x[1] for x in parts))
for (f, k), v in sorted(cnt.items()): print(f'{f}\t{k}\t{v}')
