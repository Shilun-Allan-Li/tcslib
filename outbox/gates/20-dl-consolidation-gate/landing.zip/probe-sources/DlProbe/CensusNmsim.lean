import Lean
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Challenge
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Generic
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Hybrid
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.IndSim
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Recover
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Reduction
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Rounds
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimIND
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimINDGap
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Simulator
import TCSlib.Cryptography.Implications.PublicKey
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

/-! dl-consolidation review census probe (nm-sim files at the rebased head). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_of_simNMSecure
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_of_nmSecure_cpa
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure.adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.bitwise_padded_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.exists_adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.padded_cpa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_rsa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_factoring
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_cca2_of_indSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_of_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2

def owners : List Name := [`TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Challenge,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Generic,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Hybrid,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.IndSim,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Recover,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Reduction,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Rounds,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimIND,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimINDGap,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Simulator]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

