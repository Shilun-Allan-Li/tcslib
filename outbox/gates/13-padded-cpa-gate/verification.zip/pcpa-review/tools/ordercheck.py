"""ordercheck.py <worktree> <order> <target-module-path> <issued-order>
Checks: every TCSlib import of each module in the order appears earlier; the order covers the
upstream TCSlib closure of target and every TCSlib module (whole tree) that transitively imports it;
diffs against the issued order; reports Mathlib roots."""
import sys, os, re
wt, order, target, issued = sys.argv[1:5]
mods = [l.strip() for l in open(order) if l.strip()]
def imports(m):
    p = os.path.join(wt, m + '.lean'); out = []
    for l in open(p, encoding='utf-8'):
        mm = re.match(r'^import\s+(\S+)', l)
        if mm: out.append(mm.group(1))
        elif l.strip() and not l.startswith(('import', '--', '/-')) and not l.startswith(' '): pass
    return out
all_mods = []
for root, _, fs in os.walk(os.path.join(wt, 'TCSlib')):
    for f in fs:
        if f.endswith('.lean'): all_mods.append(os.path.relpath(os.path.join(root, f), wt)[:-5])
all_mods.append('TCSlib') if os.path.exists(os.path.join(wt, 'TCSlib.lean')) else None
imp = {m: [i.replace('.', '/') for i in imports(m) if i.startswith('TCSlib')] for m in all_mods}
pos = {m: i for i, m in enumerate(mods)}
bad = [(m, i) for m in mods for i in imp.get(m, ['<missing file>']) if i not in pos or pos[i] > pos[m]]
print('order modules', len(mods), 'dups', len(mods) - len(set(mods)))
print('topology violations', len(bad)); [print('  VIOL', b) for b in bad[:20]]
up, st = set(), [target]
while st:
    x = st.pop()
    for i in imp[x]:
        if i not in up: up.add(i); st.append(i)
down = set(); ch = True
while ch:
    ch = False
    for m in all_mods:
        if m not in down and m != target and any(i == target or i in down for i in imp[m]): down.add(m); ch = True
print('upstream closure', len(up), 'missing', sorted(up - set(mods)))
print('downstream (whole tree)', len(down), 'missing', sorted(down - set(mods)))
iss = [l.strip() for l in open(issued) if l.strip()]
print('issued', len(iss), 'removed from issued', sorted(set(iss) - set(mods)))
print('added vs issued', [m for m in mods if m not in set(iss)])
print('relative order of issued preserved', [m for m in mods if m in set(iss)] == iss)
roots = set()
for m in mods:
    for i in imports(m):
        if i.startswith('Mathlib'): roots.add(i)
print('mathlib roots', len(roots))
open(os.path.join(os.path.dirname(order), 'roots-computed.txt'), 'w').write('\n'.join(sorted(roots)) + '\n')
open(os.path.join(os.path.dirname(order), 'downstream.txt'), 'w').write('\n'.join(sorted(down)) + '\n')
open(os.path.join(os.path.dirname(order), 'upstream.txt'), 'w').write('\n'.join(sorted(up)) + '\n')
