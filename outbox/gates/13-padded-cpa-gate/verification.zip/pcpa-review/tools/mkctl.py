"""mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
Sensitivity controls for the padded-cpa review, built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (pairEncode, padFin, zeroBits, seedIn, chRun, recAdvIn, firstQ)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
B = {
 'Turing.pairEncode': [
  ("ctlPair", True, "theorem ctlPair (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n"),
  ("ctlPairReader", False, "theorem ctlPairReader (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b\n"),
  ("anonymous example", True, "example (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n")],
 'TCSlib.Cryptography.padFin': [
  ("ctlPadFin", True, "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n"),
  ("ctlPadFinReader", False, "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n")],
 'TCSlib.Cryptography.Games.zeroBits': [
  ("ctlZeroBits", True, "theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl\n"),
  ("ctlZeroBitsReader", False, "theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=\n  TCSlib.Cryptography.Games.zeroBits_apply d j\n")],
 'TCSlib.Cryptography.Games.seedIn': [
  ("ctlSeedIn", True, "theorem ctlSeedIn (n : ℕ) (z w : List Bool) : TCSlib.Cryptography.Games.seedIn n z w =\n    Turing.pairEncode (List.replicate n true) (Turing.pairEncode z w) := rfl\n"),
  ("ctlSeedInReader", False, "theorem ctlSeedInReader (n : ℕ) (z w : List Bool) : TCSlib.Cryptography.Games.seedIn n z w =\n    Turing.pairEncode (List.replicate n true) (Turing.pairEncode z w) := TCSlib.Cryptography.Games.seedIn_eq n z w\n")],
 CS + '.chRun': [
  ("ctlChRun", True, f"theorem ctlChRun {{ins outs : Fin 2 → ℕ}} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)\n    (s : Option (Fin (outs 1) → Bool)) : {CS}.chRun g (.pure a) s = (a, s) := rfl\n"),
  ("ctlChRunReader", False, f"theorem ctlChRunReader {{ins outs : Fin 2 → ℕ}} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)\n    (s : Option (Fin (outs 1) → Bool)) : {CS}.chRun g (.pure a) s = (a, s) := {CS}.chRun_pure g a s\n")],
 CS + '.recAdvIn': [
  ("ctlRecAdvIn", True, f"theorem ctlRecAdvIn (c : List Bool) : {CS}.recAdvIn c =\n    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl\n"),
  ("ctlRecAdvInReader", False, f"theorem ctlRecAdvInReader (c : List Bool) : {CS}.recAdvIn c =\n    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := {CS}.recAdvIn_eq c\n")],
}
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace PcpaControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end PcpaControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
for rec_path in sorted(Path(sealdir).glob('Seal_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][5:]
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
