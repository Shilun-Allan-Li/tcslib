"""lint42r2.py <repo> <work-dir> <out.txt>: scripts/campaign_style_lint.py (as at the records pin) over the 70 PR files
only, at the round-1 head and at the round-2 head, each in a mini tree written from git objects under <work-dir>
(the 70 files and the script; no full export). Every lint check on these files is per file, except the facade checks of
Yao.lean and Yao/HybridProof.lean, whose child directories hold PR files only; so the lines printed for these files
equal those of a whole-tree run. Compares the FAIL and WARN lines of the two runs."""
import hashlib, os, shutil, subprocess, sys

repo, WORK, OUTF = sys.argv[1:4]
PIN = '2da7e0f3cd65ec93ed71813b7828c3b66ba18942'
BASE = 'f9fda8fe8d11fc68c233df2979a86d356ddfe1ab'
REVS = {'round 1': 'e9b03c437aca251846430ff23b40ee5ff3d3347a', 'round 2': '355a0288d56290e8c984228cbc1824187029e456'}
LINT = 'scripts/campaign_style_lint.py'


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


paths = git('diff', '--name-only', BASE, REVS['round 2']).decode().split()
script = git('show', f'{PIN}:{LINT}')
L = [f'{LINT} at the records pin {PIN[:8]} (sha256 {hashlib.sha256(script).hexdigest()}; the same blob at both heads: '
     f'{all(git("show", f"{r}:{LINT}") == script for r in REVS.values())}), run as `python3 -I scripts/campaign_style_lint.py '
     f'TCSlib --check8b` in a mini tree holding only the {len(paths)} PR files']
res = {}
for name, rev in REVS.items():
    d = os.path.join(WORK, name.replace(' ', ''))
    if os.path.exists(d):
        shutil.rmtree(d)
    os.makedirs(os.path.join(d, 'scripts'))
    open(os.path.join(d, LINT), 'wb').write(script)
    for p in paths:
        os.makedirs(os.path.dirname(os.path.join(d, p)), exist_ok=True)
        open(os.path.join(d, p), 'wb').write(git('show', f'{rev}:{p}'))
    r = subprocess.run([sys.executable, '-I', os.path.join(d, LINT), 'TCSlib', '--check8b'], cwd=d, capture_output=True,
                       text=True)
    lines = [x for x in r.stdout.splitlines() if x.startswith(('FAIL', 'WARN'))]
    res[name] = lines
    L.append(f'{name} {rev[:8]}: exit {r.returncode}; {r.stdout.strip().splitlines()[-1]}')
    L.extend('  ' + ' '.join(x.split()) for x in lines)
    shutil.rmtree(d)
norm = lambda xs: sorted(' '.join(x.split()) for x in xs)
import re
L.append(f'FAIL and WARN lines identical in the two runs: {norm(res["round 1"]) == norm(res["round 2"])}; added '
         f'{sorted(set(norm(res["round 2"])) - set(norm(res["round 1"])))}; removed '
         f'{sorted(set(norm(res["round 1"])) - set(norm(res["round 2"])))}')
L.append(f'identical once the line count in the size WARN is masked: '
         f'{[re.sub(r" [0-9]+ lines > ", " N lines > ", x) for x in norm(res["round 1"])] == [re.sub(r" [0-9]+ lines > ", " N lines > ", x) for x in norm(res["round 2"])]} '
         f'(Yao.lean 1179 -> 1195 lines, SY-2 cap 1200); no FAIL in either run')
open(OUTF, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
print('\n'.join(L))
