"""chk42r2.py <repo> <out-dir> <pr-json> <r1-sources.zip>: the Gate 42 round-2 pack re-checks (sc-yao, draft PR #341 at
355a0288), from git objects and the committed integration evidence only (no Lean, no lake, no checkout). Python as
`python3 -I`. Writes into <out-dir>:

  series-r2.txt       the records pin and its relation to round 1's pins; PR #341 (GitHub REST, the body equal to the
                      MCP read); the three new commits on e9b03c43 with their SSH signatures verified (ed25519, python
                      `cryptography`, one-byte tamper control); pr-r2.diff.txt and pr.diff-r2.txt and their identities
  le-r2.txt           LE-reuse-2 (proof-only: statement, imports and every other declaration byte-identical; the new
                      body's names), LE-refs and LE-steps (comment-only: comment-stripped equality, pure insertions,
                      byte removal restores the parent, every inserted line a comment), with controls; widths; sorry
  decls-r2.txt        all 70 PR files, e9b03c43 -> 355a0288: declarations, headers, definition blocks, docstrings and
                      comment-stripped code
  frozen-r2.txt       Yao.lean, tip f9fda8fe -> 355a0288, masking the six approved regions and LE-title's title line
                      (round 1's check), with its six controls; e9b03c43 -> 355a0288 inside the polyTime body only;
                      Uniform.lean and DAGCircuit.lean unchanged since round 1
  steps-r2.txt        the six proofs of G42-03: their sketches and the inserted step comments side by side; every
                      backticked name in a step comment located in the proof's code
  sources-r2.txt      citation tags against each file's `## References` (all 70 files, round 1 and round 2); the two
                      new entries and the library's other AB09 and BMR90 entries
  integration-r2.txt  the integration evidence at the records pin: the ZIP against its SHA256SUMS; M and M' rebuilt
                      with git merge-tree; the raw diffs; the M' build records bound to the blobs; the M' state check,
                      admissions and axioms; the four RunWithHost seals bound to the source and recounted from the raw
                      logs; the Yao.lean seals (run at M)
  closure-r2.txt      the source closure of the changed modules at 355a0288 against round 1's sources.zip
  mergetrees-r2.txt   git merge-tree of the head with the records pin and with the open PRs on the records branch
"""
import base64, collections, difflib, hashlib, io, json, os, re, subprocess, sys, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls  # noqa: E402

repo, OUT, PRJ, R1SRC = sys.argv[1:5]
R = Repo(repo)
sha = lambda b: hashlib.sha256(b).hexdigest()
PIN = '2da7e0f3cd65ec93ed71813b7828c3b66ba18942'      # records pin, round 2
PIN1 = 'f22e0f6798815b9263893e61928b4f16452f74ee'     # records pin, round 1 (= T of the integration)
RULS = {'67423db6c9d6448ae531b04f42c315585d00d502': 'SY-F01..F03 rulings', 'd6fe1ddd4f38b9bd29d2c707dcb4b60129b4586e':
        'DL-49 wording correction', 'bf08dbfa3a057a3b41d20f6dbede3066bc5e6660': 'SY-F05 ruling (DL-52)',
        '9fa48035cf5c99dd0997606aa9cd55a9d12916e4': 'round-1 findings and resolutions',
        'ed0d2acc055c52c016fbaef84209e8880149058c': 'integration evidence'}
H1 = 'e9b03c437aca251846430ff23b40ee5ff3d3347a'       # round-1 head
H2 = '355a0288d56290e8c984228cbc1824187029e456'       # round-2 head
BASE = 'f9fda8fe8d11fc68c233df2979a86d356ddfe1ab'
CUR = '201bf57a941131d1737295089ffd7477e1d7f7b9'
LE = [('LE-reuse-2', '26f0b77bd22a3e3366778eb40ce7ddc68b6263ea', 'G42-01'),
      ('LE-refs', '3e99eb80109a7d5310acd890612e32385d3f1abc', 'G42-02'),
      ('LE-steps', H2, 'G42-03')]
M_ = ('e327a5f284c043493e1b405b282e9abc5e002b61', '741bafe2ce706adbf697ab893bf4bc28e7eb1d7d')
MP = ('061ad60cdc485e6248eeadfc2de165a227f7cd99', '84c5381ba7188069f296f899efff9104f9b9bbe0')
OPEN = {331: '9e7a96481785d6cac4dea3b2e990c49ac278b060', 338: 'd45d3682089cb6fd04f4d075f48a464fefaa143c',
        339: '839f36cca9b4af0570c014f03f19858d0a03cbfb'}
SC = 'TCSlib/Cryptography/SecureComputation/'
YAO = SC + 'Yao.lean'
UNI = 'TCSlib/Complexity/CircuitComplexity/Uniform.lean'
DAG = 'TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean'
HP = SC + 'Yao/HybridProof/'
RWH = HP + 'RunWithHost.lean'
SL = 'TCSlib/Complexity/Randomized/Build/StringLoops.lean'
EVD = 'briefs/pass-shelat-ch5-8/fills/sc-yao/final-r1/integration-tip/'
CODE = ('TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean', 'lake-manifest.json', 'lean-toolchain')
files = {}


def out(name, lines):
    text = '\n'.join(lines) + '\n'
    files[name] = text
    open(os.path.join(OUT, name), 'w', encoding='utf-8').write(text)


# ---------------------------------------------------------------- Lean text helpers (chk42.py, round 1)
def strip_comments(t):
    o, i, n, depth = [], 0, len(t), 0
    while i < n:
        if depth:
            if t.startswith('/-', i):
                depth += 1; i += 2
            elif t.startswith('-/', i):
                depth -= 1; i += 2
            else:
                if t[i] == '\n':
                    o.append('\n')
                i += 1
            continue
        c = t[i]
        if c == '"':
            j = i + 1
            while j < n and t[j] != '"':
                j += 2 if t[j] == '\\' else 1
            o.append(t[i:j + 1]); i = j + 1
        elif t.startswith('/-', i):
            depth = 1; i += 2
        elif t.startswith('--', i):
            j = t.find('\n', i)
            i = n if j < 0 else j
        else:
            o.append(c); i += 1
    return ''.join(o)


def code_lines(t):
    return [l.rstrip() for l in strip_comments(t).split('\n') if l.strip()]


def decl_spans(text):
    L = text.split('\n'); d = decls(text); res = {}
    for k, v in d.items():
        i = v[1] - 1; j = i
        while j < len(L) and L[j].strip() != '':
            j += 1
        s = i
        if v[3]:
            s = i - 1
            while s >= 0 and '/--' not in L[s]:
                s -= 1
        res[k] = (s, i, j)
    return res


def enclosing(text, idx):
    """the declaration whose span [docstring or keyword, first blank line) contains line index idx."""
    for k, (s, i, j) in decl_spans(text).items():
        if s <= idx < j:
            return k
    return None


def ssh_sig(commit, tamper=False):
    raw = R.gitb('cat-file', 'commit', commit)
    if tamper:
        raw = raw.replace(b'\ncommitter ', b'\ncommitter  ', 1)
    lines = raw.split(b'\n')
    sig, rest, i = [], [], 0
    while i < len(lines):
        l = lines[i]
        if l == b'':
            rest.extend(lines[i:]); break
        if l.startswith(b'gpgsig '):
            sig.append(l[7:]); i += 1
            while i < len(lines) and lines[i].startswith(b' '):
                sig.append(lines[i][1:]); i += 1
            continue
        rest.append(l); i += 1
    if not sig:
        return dict(n=0)
    payload = b'\n'.join(rest)
    blob = base64.b64decode(''.join(x for x in b'\n'.join(sig).decode().splitlines() if not x.startswith('-----')))

    def rd(b, k):
        n = int.from_bytes(b[k:k + 4], 'big'); return b[k + 4:k + 4 + n], k + 4 + n
    assert blob[:6] == b'SSHSIG'
    k = 10
    pub, k = rd(blob, k); ns, k = rd(blob, k); _, k = rd(blob, k); halg, k = rd(blob, k); sigblob, k = rd(blob, k)
    fp = 'SHA256:' + base64.b64encode(hashlib.sha256(pub).digest()).decode().rstrip('=')
    ktype, kk = rd(pub, 0)
    st, kk2 = rd(sigblob, 0)
    sigraw, _ = rd(sigblob, kk2)
    h = hashlib.sha512(payload).digest() if halg == b'sha512' else hashlib.sha256(payload).digest()
    s = lambda x: len(x).to_bytes(4, 'big') + x
    signed = b'SSHSIG' + s(ns) + s(b'') + s(halg) + s(h)
    ok = None
    if ktype == b'ssh-ed25519':
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            keyraw, _ = rd(pub, kk)
            Ed25519PublicKey.from_public_bytes(keyraw).verify(sigraw, signed)
            ok = True
        except ImportError:
            ok = None
        except Exception:
            ok = False
    return dict(n=sum(1 for l in lines if l.startswith(b'gpgsig ')), fp=fp, ns=ns.decode(), ktype=ktype.decode(), ok=ok)


def cinfo(c):
    f = R.git('show', '-s', '--format=%H%x00%P%x00%an <%ae>%x00%aI%x00%cn <%ce>%x00%cI%x00%s', c).stdout
    return dict(zip(['hash', 'parents', 'author', 'adate', 'committer', 'cdate', 'subject'],
                    f.rstrip('\n').split('\x00')))


def body_without_trailers(c):
    return [x for x in R.git('show', '-s', '--format=%b', c).stdout.rstrip('\n').split('\n')
            if not x.startswith(('Co-Authored-By: ', 'Claude-Session: '))]


def hunks(a, b):
    return [op for op in difflib.SequenceMatcher(None, a.split('\n'), b.split('\n'), autojunk=False).get_opcodes()
            if op[0] != 'equal']


def inserted_lines(a, b):
    ops = hunks(a, b)
    ins = set()
    for _, i1, i2, j1, j2 in ops:
        ins |= set(range(j1, j2))
    return ops, ins


def remove_lines(b, idxs):
    return '\n'.join(l for i, l in enumerate(b.split('\n')) if i not in idxs)


def doc_block_span(text):
    """line-index span [s, e] of the module docstring `/-! ... -/`."""
    L = text.split('\n')
    s = [i for i, l in enumerate(L) if l.startswith('/-!')][0]
    e = s
    while not L[e].rstrip().endswith('-/'):
        e += 1
    return s, e


PATHS1 = R.git('diff', '--name-status', '--no-renames', BASE, H1).stdout.splitlines()
STATUS = {l.split('\t')[1]: l.split('\t')[0] for l in R.git('diff', '--name-status', '--no-renames', BASE, H2)
          .stdout.splitlines()}
PATHS = sorted(STATUS)
CH = R.git('diff', '--name-only', H1, H2).stdout.split()

# ---------------------------------------------------------------- series-r2.txt
L = [f'records pin (round 2) {PIN}: {cinfo(PIN)["subject"]}']
L.append(f'  descends from round 1\'s records pin {PIN1[:8]}: {R.anc(PIN1, PIN)}; and from ' +
         '; '.join(f'{c[:8]} ({w}): {R.anc(c, PIN)}' for c, w in RULS.items()))
cp = R.git('diff', '--name-only', PIN1, PIN, '--', *CODE).stdout.split()
L.append(f'  code paths (TCSlib, TCSlib.lean, audits, scripts, lake files) changed {PIN1[:8]}..{PIN[:8]}: {len(cp)} {cp}; '
         f'so the integration tip T = {PIN1[:8]} has the pin\'s code')
cp2 = R.git('diff', '--name-only', CUR, PIN, '--', *CODE).stdout.split()
L.append(f'  code paths changed 201bf57a (#327, #324 merged)..{PIN[:8]}: {len(cp2)}')
nrec = R.git('rev-list', '--count', f'{PIN1}..{PIN}').stdout.strip()
L.append(f'  commits {PIN1[:8]}..{PIN[:8]}: {nrec}')
psig = ssh_sig(PIN)
L.append(f'  pin commit signature: gpgsig {psig["n"]}, {psig.get("ktype")} key {psig.get("fp")}, namespace '
         f'{psig.get("ns")}, verified {psig.get("ok")}')
pj = json.load(open(PRJ))
body = pj['body'].encode()
L.append('')
L.append(f'PR #341 (GitHub REST GET /repos/Shilun-Allan-Li/tcslib/pulls/341, 2026-11-16; the MCP pull_request_read of the '
         f'same time gives the same body): state {pj["state"]}, draft {pj["draft"]}, head {pj["head"]["ref"]} '
         f'{pj["head"]["sha"]}, base {pj["base"]["ref"]} (REST base.sha {pj["base"]["sha"]}), changed_files '
         f'{pj["changed_files"]}, +{pj["additions"]}/-{pj["deletions"]}, commits {pj["commits"]}, updated_at '
         f'{pj["updated_at"]}')
L.append(f'  REST head = {H2}: {pj["head"]["sha"] == H2}; body sha256 {sha(body)} ({len(body)} bytes); '
         f'= pr-description-r2.md: {open(os.path.join(OUT, "..", "out", "pr-description-r2.md"), "rb").read() == body}')
L.append(f'  origin/land/pass-shelat-sc-yao = {R.rp("origin/land/pass-shelat-sc-yao")} (= head: '
         f'{R.rp("origin/land/pass-shelat-sc-yao") == H2}); head tree {R.rp(H2 + "^{tree}")}')
L.append('')
new = R.git('rev-list', '--reverse', f'{H1}..{H2}').stdout.split()
L.append(f'round-1 head {H1[:8]} is an ancestor of the head (no rebase): {R.anc(H1, H2)}; commits {H1[:8]}..{H2[:8]}: '
         f'{len(new)} = the three landing edits {[c for _, c, _ in LE] == new}; first-parent chain, no merges: '
         f'{all(len(cinfo(c)["parents"].split()) == 1 for c in new)}')
for (name, c, fid), _ in zip(LE, new):
    ci, sg = cinfo(c), ssh_sig(c)
    msg = R.git('show', '-s', '--format=%B', c).stdout.splitlines()
    L.append(f'  {name} ({fid}) {c}: parent {ci["parents"]}; author {ci["author"]} {ci["adate"]}; committer '
             f'{ci["committer"]}; gpgsig {sg["n"]} {sg.get("ktype")} {sg.get("fp")} ns={sg.get("ns")} verified='
             f'{sg.get("ok")}; same key as the records pin: {sg.get("fp") == psig.get("fp")}; Co-Authored-By and '
             f'Claude-Session trailers present: {any(x.startswith("Co-Authored-By: ") for x in msg)}, '
             f'{any(x.startswith("Claude-Session: ") for x in msg)}')
    L.append(f'    subject: {ci["subject"]}')
    L.append(f'    {R.git("diff", "--shortstat", c + "^", c).stdout.strip()}')
L.append(f'  signature control: the head with one byte added to its committer line verifies: '
         f'{ssh_sig(H2, tamper=True).get("ok")} (expected False)')
L.append('')
mb = R.git('merge-base', PIN, H2).stdout.strip()
L.append(f'merge base of the head with the records pin: {mb} (= the PR base {BASE[:8]}, as in round 1: {mb == BASE})')
d2 = R.gitb('diff', f'{BASE}..{H2}')
three = R.gitb('diff', f'{PIN}...{H2}')
open(os.path.join(OUT, '..', 'out', 'pr.diff-r2.txt'), 'wb').write(d2)
L.append(f'pr.diff-r2.txt = git diff {BASE[:8]}..{H2[:8]}: {len(d2)} bytes, sha256 {sha(d2)}; '
         f'{R.git("diff", "--shortstat", BASE, H2).stdout.strip()}')
L.append(f'  = git diff {PIN[:8]}...{H2[:8]} (three-dot, GitHub\'s view) byte for byte: {d2 == three}')
st1 = {l.split('\t')[1]: l.split('\t')[0] for l in PATHS1}
L.append(f'  paths {len(STATUS)} ({dict(collections.Counter(STATUS.values()))}); the same paths and statuses as round 1\'s '
         f'pr.diff.txt ({BASE[:8]}..{H1[:8]}): {STATUS == st1}')
r1d = open(os.path.join(repo, 'briefs/pass-shelat-ch5-8/gates/42-sc-yao/pr.diff.txt'), 'rb').read()
L.append(f'  round 1\'s records pr.diff.txt = git diff {BASE[:8]}..{H1[:8]}: {r1d == R.gitb("diff", f"{BASE}..{H1}")}')
d12 = R.gitb('diff', f'{H1}..{H2}')
open(os.path.join(OUT, '..', 'out', 'pr-r2.diff.txt'), 'wb').write(d12)
L.append(f'pr-r2.diff.txt = git diff {H1[:8]}..{H2[:8]} (round 1 -> round 2): {len(d12)} bytes, sha256 {sha(d12)}; '
         f'{R.git("diff", "--shortstat", H1, H2).stdout.strip()}; paths {len(CH)}, all among the PR\'s 70: '
         f'{set(CH) <= set(PATHS)}')
L.append(f'  = the concatenation of the three commits\' diffs, path by path: '
         f'{sorted(set(sum((R.git("diff", "--name-only", c + "^", c).stdout.split() for _, c, _ in LE), []))) == sorted(CH)}')
for p in CH:
    L.append(f'  {p}: {R.git("diff", "--numstat", H1, H2, "--", p).stdout.split()[:2]} (added, deleted)')
out('series-r2.txt', L)

# ---------------------------------------------------------------- le-r2.txt
L = []
CTL = []
for name, c, fid in LE:
    par = R.rp(c + '^')
    ps = R.git('diff', '--name-only', par, c).stdout.split()
    L.append(f'=== {name} {c} ({fid}; parent {par[:8]}): {len(ps)} file(s); '
             f'{R.git("diff", "--shortstat", par, c).stdout.strip()}')
    for p in ps:
        a, b = R.show(par, p), R.show(c, p)
        ops, ins = inserted_lines(a, b)
        imp_same = re.findall(r'(?m)^import .*', a) == re.findall(r'(?m)^import .*', b)
        cs = code_lines(a) == code_lines(b)
        L.append(f'  {p.replace(SC, "")}: hunks {len(ops)} ({dict(collections.Counter(o[0] for o in ops))}); imports '
                 f'byte-identical {imp_same}; identical after stripping comments {cs}')
        if name == 'LE-reuse-2':
            da, db = decls(a), decls(b)
            spa, spb = decl_spans(a), decl_spans(b)
            diff_decls = [k for k in da if k in db and a.split('\n')[spa[k][0]:spa[k][2]] != b.split('\n')[spb[k][0]:spb[k][2]]]
            L.append(f'    declarations {len(da)} -> {len(db)}, same names in the same order {list(da) == list(db)}; '
                     f'headers (keyword to the top-level `:=`) byte-identical for all {all(da[k][2] == db[k][2] for k in da)}; '
                     f'declarations whose docstring-to-end span differs: {diff_decls}')
            s_a, s_b = spa['acc_poly'], spb['acc_poly']
            La, Lb = a.split('\n'), b.split('\n')
            outside = La[:s_a[0]] + La[s_a[2]:] == Lb[:s_b[0]] + Lb[s_b[2]:]
            L.append(f'    the file outside acc_poly\'s span (docstring to the next blank line) byte-identical: {outside}')
            L.append(f'    acc_poly header at parent and head: {da["acc_poly"][2]!r} | {db["acc_poly"][2]!r}; equal '
                     f'{da["acc_poly"][2] == db["acc_poly"][2]}')
            doa, dob = da['acc_poly'][3].split('\n'), db['acc_poly'][3].split('\n')
            dops, dins = inserted_lines(da['acc_poly'][3], db['acc_poly'][3])
            L.append(f'    acc_poly docstring: {len(doa)} -> {len(dob)} lines; pure insertion '
                     f'{all(o[0] == "insert" for o in dops)}; inserted {[dob[i] for i in sorted(dins)]}; formula line '
                     f'kept: {doa[-1] == dob[-1]} ({dob[-1]!r})')
            old_body = '\n'.join(La[s_a[1]:s_a[2]]); new_body = '\n'.join(Lb[s_b[1]:s_b[2]])
            L.append('    old declaration (parent):'); L.extend('      | ' + x for x in old_body.split('\n'))
            L.append('    new declaration (head):'); L.extend('      | ' + x for x in new_body.split('\n'))
            pf = new_body.split(':= by', 1)[1]
            names_ = sorted(set(re.findall(r'[A-Za-z_][A-Za-z_0-9.\']*', pf)))
            L.append(f'    identifiers in the new proof: {names_}')
            tact = [t for t in ('unfold', 'delta', 'simp', 'dsimp', 'show', 'rfl', 'decide', 'change', 'native_decide',
                                'Eq.mpr', 'cast') if re.search(rf'(?<![\w.]){re.escape(t)}(?![\w])', pf)]
            L.append(f'    definition-reading tactics or terms in the new proof (unfold, delta, simp, dsimp, show, rfl, '
                     f'decide, change, native_decide, Eq.mpr, cast): {tact}; the only rewrite is `rw [hfun]` with the '
                     f'local equation hfun')
            L.append(f'    the readers used: acc_eq (this file) and Complexity.StateLoop.MajLoop.acc_eq: '
                     f'{"acc_eq w" in pf and "Complexity.StateLoop.MajLoop.acc_eq w" in pf}; MajLoop.acc_poly applied: '
                     f'{"exact Complexity.StateLoop.MajLoop.acc_poly" in pf}')
            cand = ('simpa only [acc_eq, Complexity.StateLoop.MajLoop.acc_eq] using\n    '
                    'Complexity.StateLoop.MajLoop.acc_poly')
            L.append(f'    Codex\'s candidate body (`simpa only [acc_eq, Complexity.StateLoop.MajLoop.acc_eq] using '
                     f'Complexity.StateLoop.MajLoop.acc_poly`) is the committed body: {cand in new_body}; it is '
                     f'"Fallback 1" in the commit message, which keeps it and a second fallback untried:')
            L.extend('      > ' + x for x in body_without_trailers(c))
    if name in ('LE-refs', 'LE-steps'):
        allpure = restore = commentonly = True
        indent_ok = True
        for p in ps:
            a, b = R.show(par, p), R.show(c, p)
            ops, ins = inserted_lines(a, b)
            allpure &= all(o[0] == 'insert' for o in ops)
            restore &= remove_lines(b, ins) == a
            Lb = b.split('\n')
            if name == 'LE-steps':
                commentonly &= all(re.match(r'^\s*-- ', Lb[i]) for i in ins)
                for i in sorted(ins):
                    if i + 1 not in ins:
                        nxt = next(j for j in range(i + 1, len(Lb)) if Lb[j].strip())
                        ind = lambda s: len(s) - len(s.lstrip(' '))
                        k = i
                        while k - 1 in ins:
                            k -= 1
                        for kk in range(k, i + 1):
                            indent_ok &= ind(Lb[kk]) == ind(Lb[nxt])
            else:
                s, e = doc_block_span(b)
                commentonly &= all(s < i < e for i in ins)
        L.append(f'  all hunks pure insertions: {allpure}; removing the inserted lines restores the parent byte for byte: '
                 f'{restore}')
        if name == 'LE-steps':
            L.append(f'  every inserted line is a `-- ` line comment: {commentonly}; each comment at the indentation of the '
                     f'next code line: {indent_ok}')
            per = collections.OrderedDict()
            for p in ps:
                a, b = R.show(par, p), R.show(c, p)
                ops, ins = inserted_lines(a, b)
                Lb = b.split('\n')
                for i in sorted(ins):
                    m = re.match(r'^\s*-- Step (\d+):', Lb[i])
                    if m:
                        per.setdefault((p, enclosing(b, i)), []).append((int(m.group(1)), i + 1))
            for (p, d), ks in per.items():
                seq = [k for k, _ in ks]
                L.append(f'  {p.replace(SC, "")} `{d}`: {len(ks)} step comments, numbered {seq} (consecutive from 1: '
                         f'{seq == list(range(1, len(seq) + 1))}), head lines {[ln for _, ln in ks]}')
        else:
            L.append(f'  every inserted line inside the module docstring `/-! ... -/`: {commentonly}')
            for p in ps:
                a, b = R.show(par, p), R.show(c, p)
                ops, ins = inserted_lines(a, b)
                L.append(f'  {p.replace(SC, "")} inserted:')
                L.extend('    + ' + b.split('\n')[i] for i in sorted(ins))
        L.append(f'  {name} message, without the trailer lines:')
        L.extend('    > ' + x for x in body_without_trailers(c))
    # controls on the first touched file of each commit
    p0 = ps[0]; a0, b0 = R.show(par, p0), R.show(c, p0)
    Lb0 = b0.split('\n')
    k0 = [i for i, l in enumerate(Lb0) if re.search(r':= by\s*$', l)][0]
    c1 = Lb0[:]; c1[k0 + 1] = c1[k0 + 1] + ' <;> rfl'
    c2 = Lb0[:]; c2[k0] = c2[k0].replace(':= by', ':=  by')
    c3 = Lb0[:k0 + 1] + ['  skip'] + Lb0[k0 + 1:]
    ca = code_lines(a0)
    CTL.append(f'  {name} on {p0.split("/")[-1]}: one added tactic caught by the comment-strip check '
               f'{ca != code_lines(chr(10).join(c1))}; one doubled space caught {ca != code_lines(chr(10).join(c2))}; one '
               f'inserted code line `skip` caught by the comment-strip check {ca != code_lines(chr(10).join(c3))} and by '
               f'the comment-line rule {not re.match(r"^\s*-- ", "  skip")} (expected True each)')
L.append('controls (each a copy of the commit\'s first touched file):')
L.extend(CTL)
L.append('')
widths = {p: max(len(x) for x in R.show(H2, p).splitlines()) for p in PATHS}
lines = {p: len(R.show(H2, p).splitlines()) for p in PATHS}
L.append(f'widths at the head over the 70 files: max {max(widths.values())} (at most 100: '
         f'{all(w <= 100 for w in widths.values())}); Yao.lean {lines[YAO]} lines (SY-2 cap 1200: {lines[YAO] <= 1200}); '
         f'largest other file {max((v, k.split("/")[-1]) for k, v in lines.items() if k != YAO)}')
for p in CH:
    L.append(f'  {p.replace(SC, "")}: {len(R.show(H1, p).splitlines())} -> {lines[p]} lines, max width {widths[p]}')
srx = re.compile(r'\bsorry\b')
s1 = sum(len(srx.findall(strip_comments(R.show(H1, p)))) for p in PATHS)
s2 = sum(len(srx.findall(strip_comments(R.show(H2, p)))) for p in PATHS)
L.append(f'`sorry` tokens outside comments in the 70 files: round 1 {s1}, round 2 {s2}')
out('le-r2.txt', L)

# ---------------------------------------------------------------- decls-r2.txt
L = [f'all {len(PATHS)} PR files, round 1 {H1[:8]} -> round 2 {H2[:8]}']
tot1 = tot2 = 0
hdr_diff, def_diff, doc_diff, order_bad, code_diff = [], [], [], [], []
for p in PATHS:
    a, b = R.show(H1, p), R.show(H2, p)
    da, db = decls(a), decls(b)
    tot1 += len(da); tot2 += len(db)
    if list(da) != list(db):
        order_bad.append(p)
    hdr_diff += [f'{p.split("/")[-1]}:{k}' for k in da if k in db and da[k][2] != db[k][2]]
    def_diff += [f'{p.split("/")[-1]}:{k}' for k in da if k in db and da[k][0] not in ('theorem', 'lemma')
                 and da[k][2] != db[k][2]]
    doc_diff += [f'{p.split("/")[-1]}:{k}' for k in da if k in db and da[k][3] != db[k][3]]
    if code_lines(a) != code_lines(b):
        code_diff.append(p)
L.append(f'declarations: {tot1} -> {tot2}; files whose declaration list (names, order) changed: {order_bad}')
L.append(f'headers differing: {hdr_diff}; definition blocks differing: {def_diff}; declaration docstrings differing: '
         f'{doc_diff}')
L.append(f'files whose code differs after stripping comments: {[p.replace(SC, "") for p in code_diff]}')
a, b = R.show(H1, RWH), R.show(H2, RWH)
ca, cb = strip_comments(a).split('\n'), strip_comments(b).split('\n')
sa, sb = decl_spans(a)['acc_poly'], decl_spans(b)['acc_poly']
L.append(f'  RunWithHost.lean, comment-stripped, outside acc_poly\'s span: identical '
         f'{[x for x in ca[:sa[0]] + ca[sa[2]:] if x.strip()] == [x for x in cb[:sb[0]] + cb[sb[2]:] if x.strip()]}')
L.append(f'module docstrings changed: ' + str([p.replace(SC, '') for p in PATHS if '/-!' in R.show(H1, p) and
          (lambda t: '\n'.join(t.split('\n')[doc_block_span(t)[0]:doc_block_span(t)[1] + 1]))(R.show(H1, p)) !=
          (lambda t: '\n'.join(t.split('\n')[doc_block_span(t)[0]:doc_block_span(t)[1] + 1]))(R.show(H2, p))]))
L.append(f'new declaration names in round 2: {sorted(set(k for p in PATHS for k in decls(R.show(H2, p))) - set(k for p in PATHS for k in decls(R.show(H1, p))))}')
out('decls-r2.txt', L)

# ---------------------------------------------------------------- frozen-r2.txt
TARGETS = ('yaoHybrid_polyTime', 'yaoHybrid_simulators')


def yao_regions(text):
    Ls = text.split('\n'); reg = []
    imp = [i for i, l in enumerate(Ls) if l == 'import TCSlib.Cryptography.Foundations.BitLists'][0]
    hub = [i for i, l in enumerate(Ls) if l.startswith('import TCSlib.Cryptography.SecureComputation.Yao.')]
    reg.append(('hub import', imp + 1, imp + 1 + len(hub)))
    t = [i for i, l in enumerate(Ls) if l.startswith('# Yao')][0]
    reg.append(('title line (LE-title)', t, t + 1))
    b0 = [i for i, l in enumerate(Ls) if l.startswith('* `SecureComputation.yaoHybrid_polyTime`')][0]
    b1 = [i for i, l in enumerate(Ls) if l.startswith('* `SecureComputation.yaoHybrid_hbcSecure`')][0]
    reg.append(('Main results bullet', b0, b1))
    for tg in TARGETS:
        k = [i for i, l in enumerate(Ls) if re.match(rf'^theorem {tg}\b', l)][0]
        e = k - 1
        while not Ls[e].rstrip().endswith('-/'):
            e -= 1
        s = e
        while '**Proof sketch.**' not in Ls[s]:
            s -= 1
        reg.append((f'{tg} sketch', s, e + 1))
        h = k
        while not re.search(r':= by\s*$', Ls[h]):
            h += 1
        j = h + 1
        while j < len(Ls) and Ls[j].strip() != '':
            j += 1
        reg.append((f'{tg} body', h + 1, j))
    return reg


def mask(text, regs):
    Ls = text.split('\n'); o = []; i = 0
    for name, s, e in sorted(regs, key=lambda r: r[1]):
        o.extend(Ls[i:s]); o.append(f'<<{name}>>'); i = e
    o.extend(Ls[i:])
    return o


def yao_check(bt, ht):
    rb, rh = yao_regions(bt), yao_regions(ht)
    mb, mh = mask(bt, rb), mask(ht, rh)
    ops = [op for op in difflib.SequenceMatcher(None, mb, mh, autojunk=False).get_opcodes() if op[0] != 'equal']
    Lh = ht.split('\n')
    rules = []
    for name, s, e in rh:
        if name.endswith('body'):
            body = Lh[s:e]
            if any(x and not x.startswith(' ') for x in body):
                rules.append(f'{name}: a column-0 line')
            if any(re.search(r'\bsorry\b', x) for x in body):
                rules.append(f'{name}: sorry')
        if name.endswith('sketch') and 'not yet stated' in '\n'.join(Lh[s:e]):
            rules.append(f'{name}: "not yet stated"')
        if name == 'hub import' and e - s != 1:
            rules.append(f'hub import: {e - s} lines')
    return rb, rh, ops, rules, mb, mh


L = []
bt, h1t, ht = R.show(BASE, YAO), R.show(H1, YAO), R.show(H2, YAO)
rb, rh, ops, rules, mb, mh = yao_check(bt, ht)
L.append(f'=== {YAO}: tip {BASE[:8]} ({len(bt.splitlines())} lines) -> head {H2[:8]} ({len(ht.splitlines())} lines; '
         f'SY-2 cap 1200: {len(ht.splitlines()) <= 1200}; max width {max(len(x) for x in ht.splitlines())})')
L.append('approved regions (1-based line ranges, tip | head):')
for (n1, s1, e1), (n2, s2, e2) in zip(rb, rh):
    L.append(f'  {n1:32s} tip {s1 + 1}-{e1} ({e1 - s1} lines) | head {s2 + 1}-{e2} ({e2 - s2} lines)')
L.append(f'masked tip = masked head (everything outside the regions byte-identical): {mb == mh}; violations {len(ops)}')
L.append(f'rule breaks (column-0 line or sorry in a body, "not yet stated" in a sketch, hub import not one line): '
         f'{len(rules)} {rules}')
raw = hunks(bt, ht)
L.append(f'unmasked diff hunks: {len(raw)}; each inside one region on both sides:')
for tag, i1, i2, j1, j2 in raw:
    hit = [n for (n, s, e), (_, s2, e2) in zip(rb, rh) if s <= i1 and i2 <= e and s2 <= j1 and j2 <= e2]
    L.append(f'  {tag:7s} tip {i1 + 1}-{i2} head {j1 + 1}-{j2}: {hit}')
db_, dh = decls(bt), decls(ht)
L.append(f'declarations: tip {len(db_)} ({sum(v[4] for v in db_.values())} private), head {len(dh)}; same names in the '
         f'same order: {list(db_) == list(dh)}')
L.append(f'  headers differing: {[k for k in db_ if k in dh and db_[k][2] != dh[k][2]]}; definition blocks differing: '
         f'{[k for k in db_ if k in dh and db_[k][0] not in ("theorem", "lemma") and db_[k][2] != dh[k][2]]}; docstrings '
         f'differing: {[k for k in db_ if k in dh and db_[k][3] != dh[k][3]]}')
for tg in TARGETS:
    pb, ph = db_[tg][3].split('**Proof sketch.**')[0], dh[tg][3].split('**Proof sketch.**')[0]
    L.append(f'  {tg}: statement prose before **Proof sketch.** byte-identical: {pb == ph} ({len(pb.splitlines())} '
             f'lines); header byte-identical: {db_[tg][2] == dh[tg][2]}')
yb = decl_spans(bt)['yaoSeed_good_whp']; yh = decl_spans(ht)['yaoSeed_good_whp']
L.append(f'  yaoSeed_good_whp: docstring, header and body byte-identical: '
         f'{bt.split(chr(10))[yb[0]:yb[2]] == ht.split(chr(10))[yh[0]:yh[2]]}')
ib = [l for l in bt.splitlines() if l.startswith('import ')]; ih = [l for l in ht.splitlines() if l.startswith('import ')]
L.append(f'  imports: tip {len(ib)}, head {len(ih)}; added {[x for x in ih if x not in ib]}; removed '
         f'{[x for x in ib if x not in ih]}')
Lh = ht.split('\n')
C = []
k = [i for i, l in enumerate(Lh) if l.startswith('theorem yaoHybrid_hbcSecure')][0]
c1 = Lh[:]; c1[k] = c1[k].replace('yaoHybrid_hbcSecure', 'yaoHybrid_hbcSecurf', 1)
C.append(('one character in a frozen header (yaoHybrid_hbcSecure)', '\n'.join(c1), 1, 0))
p_ = [i for i, l in enumerate(Lh) if 'yaoSeed_good_whp' in l and l.startswith('theorem')][0] - 2
C.append(('one extra line in a frozen region (above yaoSeed_good_whp)', '\n'.join(Lh[:p_] + ['frozen-region extra line']
                                                                                   + Lh[p_:]), 1, 0))
C.append(('a second new import line', '\n'.join(Lh[:rh[0][2]] + ['import TCSlib.Cryptography.Foundations.Negligible'] +
                                                 Lh[rh[0][2]:]), 1, 0))
bs = [r for r in rh if r[0] == 'yaoHybrid_polyTime body'][0]
C.append(('a declaration smuggled into the polyTime body', '\n'.join(Lh[:bs[1] + 1] + ['theorem smuggled : True := trivial']
                                                                     + Lh[bs[1] + 1:]), 0, 1))
ss = [r for r in rh if r[0] == 'yaoHybrid_polyTime sketch'][0]
c5 = Lh[:]; c5[ss[1] + 1] = c5[ss[1] + 1] + ' (edited)'
C.append(('an edit inside a sketch (allowed)', '\n'.join(c5), 0, 0))
ks = [i for i, l in enumerate(Lh) if l.startswith('theorem yaoHybrid_simulators')][0]
pr_ = ks
while not Lh[pr_].startswith('/--'):
    pr_ -= 1
pr_ += 1
c6 = Lh[:]; c6[pr_] = c6[pr_].replace(' ', '  ', 1)
C.append((f'one doubled space in yaoHybrid_simulators\' statement prose (head line {pr_ + 1})', '\n'.join(c6), 1, 0))
L.append('controls (each a copy of the head; expected violations, rule breaks):')
for name, txt, ev, er in C:
    _, _, o2, r2, _, _ = yao_check(bt, txt)
    L.append(f'  {name}: violations {len(o2)}, rule breaks {len(r2)} (expected {ev}, {er}): '
             f'{"OK" if (len(o2), len(r2)) == (ev, er) else "UNEXPECTED"}')
L.append('')
r1reg = yao_regions(h1t)
raw12 = hunks(h1t, ht)
L.append(f'=== {YAO}: round 1 {H1[:8]} ({len(h1t.splitlines())} lines) -> round 2 {H2[:8]} ({len(ht.splitlines())} lines): '
         f'{len(raw12)} hunks')
for tag, i1, i2, j1, j2 in raw12:
    hit = [n for (n, s, e), (_, s2, e2) in zip(r1reg, rh) if s <= i1 and i2 <= e + 1 and s2 <= j1 and j2 <= e2]
    L.append(f'  {tag:7s} round 1 {i1 + 1}-{i2} round 2 {j1 + 1}-{j2}: {hit}; lines '
             f'{[x.strip()[:60] for x in ht.split(chr(10))[j1:j2]]}')
pb1 = [r for r in r1reg if r[0] == 'yaoHybrid_polyTime body'][0]
L.append(f'  polyTime body region: round 1 {pb1[1] + 1}-{pb1[2]} ({pb1[2] - pb1[1]} lines) -> round 2 {bs[1] + 1}-{bs[2]} '
         f'({bs[2] - bs[1]} lines); identical after stripping comments: '
         f'{code_lines(chr(10).join(h1t.split(chr(10))[pb1[1]:pb1[2]])) == code_lines(chr(10).join(Lh[bs[1]:bs[2]]))}')
sk1 = [r for r in r1reg if r[0] == 'yaoHybrid_polyTime sketch'][0]
L.append(f'  the polyTime sketch is unchanged since round 1: '
         f'{h1t.split(chr(10))[sk1[1]:sk1[2]] == Lh[ss[1]:ss[2]]}')
L.append(f'  masked round 1 = masked round 2 (all seven regions): {mask(h1t, r1reg) == mask(ht, rh)}')
L.append(f'{UNI}: blob at round 1 = round 2: {R.blob(H1, UNI) == R.blob(H2, UNI)}; {DAG}: blob at the tip = round 2: '
         f'{R.blob(BASE, DAG) == R.blob(H2, DAG)}')
out('frozen-r2.txt', L)

# ---------------------------------------------------------------- steps-r2.txt
SIX = [(YAO, 'yaoHybrid_polyTime'), (HP + 'SelectedLaw.lean', 'acceptProb_fill'),
       (HP + 'FakeSimulatorFactory.lean', 'exists_data'), (HP + 'SeedCoordinates.lean', 'pick_iff_place'),
       (HP + 'FakeProgram.lean', 'tables_poly'), (HP + 'BobIO.lean', 'outputBit_poly')]
L = ['the six proofs of G42-03 at the head: the **Proof sketch.** (the docstring from the marker) and the step comments '
     '(line numbers at the head); for each backticked name in a step comment, where it occurs in the proof\'s code']
for p, d in SIX:
    t = R.show(H2, p); t1 = R.show(H1, p)
    dd = decls(t)[d]
    s, i, j = decl_spans(t)[d]
    Lt = t.split('\n')
    s1_, i1_, j1_ = decl_spans(t1)[d]
    L.append('')
    L.append(f'=== {p.replace(SC, "")} `{d}` (head lines {i + 1}-{j}; proof lines at round 1 {j1_ - i1_}, at round 2 '
             f'{j - i}); docstring unchanged since round 1: {decls(t1)[d][3] == dd[3]}')
    sk = dd[3].split('**Proof sketch.**', 1)
    L.append('  sketch:' if len(sk) == 2 else '  NO **Proof sketch.** marker')
    if len(sk) == 2:
        L.extend('    | ' + x for x in ('**Proof sketch.**' + sk[1]).split('\n'))
    code = strip_comments('\n'.join(Lt[i:j]))
    L.append('  step comments:')
    for k in range(i, j):
        if re.match(r'^\s*-- ', Lt[k]):
            L.append(f'    {k + 1}: {Lt[k].strip()}')
    names_ = []
    for k in range(i, j):
        if re.match(r'^\s*-- ', Lt[k]):
            names_ += re.findall(r'`([^`]+)`', Lt[k])
    for nm in names_:
        base_ = nm.split()[0].split('.')[-1] if re.match(r'^[\w.\'₀-₉]+$', nm.split()[0]) else None
        if base_ is None:
            L.append(f'    `{nm}`: an expression, not a name')
            continue
        L.append(f'    `{nm}`: in the proof code {bool(re.search(rf"(?<![\w]){re.escape(nm)}(?![\w])", code))}'
                 f'{"" if re.search(rf"(?<![\w]){re.escape(nm)}(?![\w])", code) else f"; last component `{base_}` in the proof code {bool(re.search(rf'(?<![\w]){re.escape(base_)}(?![\w])', code))}"}')
out('steps-r2.txt', L)

# ---------------------------------------------------------------- sources-r2.txt
TAGRX = re.compile(r'\[((?:PS10|LP09|BMR90|Gol04|Gol01|AB09|Gar26|LP07|Yao86|KL\d\d|BHR12|Lin17)[^\]]*)\]')


def missing(rev):
    res = []
    for p in PATHS:
        t = R.show(rev, p)
        groups = TAGRX.findall(t)
        refsec = t.split('## References', 1)[1].split('-/', 1)[0] if '## References' in t else ''
        tags = {m.group(1) for g in groups for x in g.split(';') for m in [re.match(r'^\s*([A-Z][A-Za-z]*\d{2})\b', x)] if m}
        declared = set(re.findall(r'^\s*\*\s*\[([A-Za-z]+\d+)\]', refsec, re.M))
        res += [f'{p.split("/")[-1]}: [{tg}]' for tg in sorted(tags) if tg not in declared]
    return res


L = ['citation tags against the file\'s `## References` entries (an entry is a line `* [TAG] ...` in that section), over '
     'the 70 PR files']
for nm, rev in (('round 1', H1), ('round 2', H2)):
    m_ = missing(rev)
    L.append(f'  {nm} {rev[:8]}: tags without an entry: {len(m_)} {m_}')
L.append('the library\'s reference entries for AB09 and BMR90 in the PR files at the head (each entry with its '
         'continuation line):')
for p in PATHS:
    t = R.show(H2, p).split('\n')
    for i, l in enumerate(t):
        if re.match(r'^\* \[(AB09|BMR90)\]', l):
            cont = t[i + 1] if i + 1 < len(t) and t[i + 1].startswith('  ') else ''
            new_ = p in CH and i in inserted_lines(R.show(H1, p), R.show(H2, p))[1]
            L.append(f'  {"NEW " if new_ else "    "}{p.replace(SC, "")}:{i + 1}: {l.strip()} {cont.strip()}')
reg = json.loads(R.show(PIN, 'blueprint/src/references/sources.json'))['tags']
L.append(f'registry blueprint/src/references/sources.json at the pin: AB09 registered {"AB09" in reg}; BMR90 registered '
         f'{"BMR90" in reg}; the registry file is the same blob at round 1\'s pin {PIN1[:8]}: '
         f'{R.blob(PIN, "blueprint/src/references/sources.json") == R.blob(PIN1, "blueprint/src/references/sources.json")}')
out('sources-r2.txt', L)

# ---------------------------------------------------------------- integration-r2.txt
L = []
zb = R.blob(PIN, EVD + 'integration-tip-evidence.zip')
sums = R.show(PIN, EVD + 'SHA256SUMS')
readme = R.blob(PIN, EVD + 'README.md')
L.append(f'{EVD} at the records pin {PIN[:8]}: README.md {len(readme)} bytes (sha256 {sha(readme)}); SHA256SUMS '
         f'{len(sums.encode())} bytes (sha256 {sha(sums.encode())}); integration-tip-evidence.zip {len(zb)} bytes, sha256 '
         f'{sha(zb)}')
L.append(f'  the working tree copies equal the pin\'s blobs: '
         f'{all(open(os.path.join(repo, EVD + f), "rb").read() == R.blob(PIN, EVD + f) for f in ("README.md", "SHA256SUMS", "integration-tip-evidence.zip"))}')
rows = [x.split('  ', 1) for x in sums.splitlines() if x.strip()]
man = {p: h for h, p in rows}
z = zipfile.ZipFile(io.BytesIO(zb))
names = [i.filename for i in z.infolist()]
zip_row = man.pop('integration-tip-evidence.zip', None)
L.append(f'  SHA256SUMS rows {len(rows)}: {len(man)} entries plus the ZIP itself ({zip_row == sha(zb)}); ZIP entries '
         f'{len(names)}, path set = the manifest\'s: {set(names) == set(man)}; directories {sum(n.endswith("/") for n in names)}')
bad = [n for n in names if sha(z.read(n)) != man.get(n)]
L.append(f'  every entry hashes to its manifest row: {not bad} (mismatches {bad[:5]})')
zr = lambda n: z.read('int-tip/' + n)
L.append('')
L.append('M and M\' (the README, merge/merge-facts.txt, mprime/merge/merge-facts.txt) rebuilt from git objects:')
for lab, (cm, tr), rhs in (('M', M_, H1), ("M'", MP, H2)):
    t, rc_, _ = R.mergetree(PIN1, rhs)
    loc = R.git('cat-file', '-t', cm, check=False).stdout.strip() == 'commit'
    L.append(f'  {lab}: git merge-tree --write-tree {PIN1[:8]} {rhs[:8]} -> {t} (rc {rc_}); = the recorded tree {tr}: '
             f'{t == tr}; the recorded commit {cm[:8]} is local only (not pushed); present here: {loc}'
             + (f', tree {R.rp(cm + "^{tree}")}, parents {cinfo(cm)["parents"]}' if loc else ''))
mf = zr('mprime/merge/merge-facts.txt').decode()
L.append(f'  M\' is the merge of {H2[:8]} into T = {PIN1[:8]} (parents T and {H2[:8]}), not a merge of M: '
         f'{f"parents {PIN1} {H2}" in mf}; its tree differs from M\'s exactly by the round-1 -> round-2 diff:')
mm = R.git('diff', '--raw', '--no-abbrev', M_[1], MP[1]).stdout
hh = R.git('diff', '--raw', '--no-abbrev', H1, H2).stdout
L.append(f'    git diff --raw {M_[1][:8]} {MP[1][:8]} (trees M, M\') = git diff --raw {H1[:8]} {H2[:8]}: {mm == hh} '
         f'({len(hh.splitlines())} paths)')
L.append(f'    = the ZIP\'s mprime/merge/diff-M-Mprime.raw and diff-e9b03c43-355a0288.raw: '
         f'{zr("mprime/merge/diff-M-Mprime.raw").decode() == hh} {zr("mprime/merge/diff-e9b03c43-355a0288.raw").decode() == hh}')
fd = R.git('diff', '--raw', '--no-abbrev', BASE, H2).stdout
cd = R.git('diff', '--raw', '--no-abbrev', CUR, MP[1], '--', 'TCSlib', 'TCSlib.lean', 'audits').stdout
L.append(f'    git diff --raw 201bf57a M\' over TCSlib, TCSlib.lean, audits = git diff --raw {BASE[:8]} {H2[:8]}: {cd == fd} '
         f'({len(fd.splitlines())} paths); = the ZIP\'s diff-f9fda8fe-355a0288.raw {zr("mprime/merge/diff-f9fda8fe-355a0288.raw").decode() == fd}')
L.append('')
# M build (int-tip/build-m/)
mrecs = [r for r in (json.loads(x) for x in zr('build-m/results.jsonl').decode().splitlines() if x.strip()) if 'module' in r]
mg = R.graph(M_[1])
mds = downstream(mg, [p for p in R.git('diff', '--name-only', 'eff2dcd0', M_[1], '--', 'TCSlib', 'TCSlib.lean', 'audits').stdout.split() if p.endswith('.lean')])
L.append(f'M build (build-m/results.jsonl): {len(mrecs)} module records; rc 0 and 0 errors in all: '
         f'{all(r["rc"] == 0 and r["errors"] == 0 and r["error_substr"] == 0 for r in mrecs)}; sorry warnings '
         f'{sum(r["sorry"] for r in mrecs)}; every record\'s source_sha256 = its file in the tree of M: '
         f'{all(r["source_sha256"] == sha(R.blob(M_[1], r["module"] + ".lean")) for r in mrecs)}; root TCSlib and both '
         f'audits Checks among them: {all(x in {r["module"] for r in mrecs} for x in ("TCSlib", "audits/pass-shelat/Checks", "audits/garg-ch1-3/Checks"))}')
L.append(f'  the built set = the downstream (in M\'s tree) of every module changed since the olean snapshot base eff2dcd0: '
         f'{ {r["module"] + ".lean" for r in mrecs} == mds} ({len(mds)} modules)')
L.append(f'  build-m/statecheck.txt last lines: {zr("build-m/statecheck.txt").decode().splitlines()[-2:]}; '
         f'build-m/refunion.txt: {zr("build-m/refunion.txt").decode().strip().splitlines()[-1]}')
L.append(f'  admissions/census-tip-vs-M-summary.txt: ' + ' | '.join(zr('admissions/census-tip-vs-M-summary.txt').decode().strip().splitlines()))
# M' build
allrecs = [json.loads(x) for x in zr('mprime/build/results.jsonl').decode().splitlines() if x.strip()]
recs = [r for r in allrecs if 'module' in r]
g = R.graph(MP[1])
ds = downstream(g, [p for p in CH if p.endswith('.lean')])
built = {r['module'] + '.lean' for r in recs}
L.append(f'M\' build (mprime/build/results.jsonl): {len(recs)} module records and {len(allrecs) - len(recs)} "done" record; rc 0 and 0 errors in all: '
         f'{all(r["rc"] == 0 and r["errors"] == 0 and r["error_substr"] == 0 for r in recs)}; sorry {sum(r["sorry"] for r in recs)}; '
         f'warnings {sum(r["warnings"] for r in recs)} ({[r["module"].split("/")[-1] for r in recs if r["warnings"]]})')
L.append(f'  the 20 built modules = the modules of the tree of M\' whose import closure meets the 9 changed files '
         f'(computed from git objects, {len(g)} modules of TCSlib and audits): {built == ds}; '
         f'extra {sorted(built - ds)}, missing {sorted(ds - built)}')
srcok = all(r['source_sha256'] == sha(R.blob(MP[1], r['module'] + '.lean')) for r in recs)
L.append(f'  every record\'s source_sha256 = the sha256 of its file in the tree of M\': {srcok}; and the 9 changed files '
         f'there = their blobs at {H2[:8]}: {all(R.blob(MP[1], p) == R.blob(H2, p) for p in CH)}')
logs = {n: z.read(n).decode() for n in names if n.startswith('int-tip/mprime/build/mods/')}
ER = re.compile(r'^\S+:\d+:\d+: error[:(]', re.M)
L.append(f'  raw logs mprime/build/mods/: {len(logs)}; each log\'s sha256 = its record\'s log_sha256: '
         f'{all(sha(z.read("int-tip/mprime/build/mods/" + r["module"].replace("/", "_") + ".log")) == r["log_sha256"] for r in recs)}; '
         f'error lines (both forms) {sum(len(ER.findall(t)) for t in logs.values())}; substring "error" '
         f'{sum(t.count("error") for t in logs.values())}; non-empty logs {[n.split("/")[-1] for n, t in logs.items() if t]}')
bl = [t for n, t in logs.items() if n.endswith('BobIO.log')][0]
ln = int(re.search(r'BobIO\.lean:(\d+):', bl).group(1))
L.append(f'  the BobIO warning: {bl.splitlines()[0]!r}; line {ln} of BobIO.lean at the head: '
         f'{R.show(H2, HP + "BobIO.lean").split(chr(10))[ln - 1].strip()!r} (round 1 line 211: '
         f'{R.show(H1, HP + "BobIO.lean").split(chr(10))[210].strip()!r})')
for n in ('mprime/build/buildsum.txt', 'mprime/build/permod.out', 'mprime/plan/plan.out', 'mprime/build/stateupdate.out'):
    L.append(f'  {n}: {zr(n).decode().strip().splitlines()[0]}')
scl = zr('mprime/build/statecheck.txt').decode().splitlines()
L.append(f'  mprime/build/statecheck.txt: {sum(x.startswith("OK ") for x in scl)} OK lines, other module lines '
         f'{sum(not x.startswith("OK ") for x in scl[:-2])}; last lines {scl[-2:]}')
cM = zr('admissions/census-M-e327a5f2.txt').decode(); cMP = zr('mprime/census-Mprime-061ad60c.txt').decode()
pm = lambda t: {m.group(2): int(m.group(1)) for m in re.finditer(r'(?m)^\s*(\d+) (\S+)  \[', t)}
L.append(f'  admissions: census M {cM.strip().splitlines()[-1][:62]!r}; census M\' {cMP.strip().splitlines()[-1][:62]!r}; '
         f'modules {len(pm(cM))} and {len(pm(cMP))}; per-module counts equal: {pm(cM) == pm(cMP)}; nonzero at M\' in the '
         f'PR\'s modules: {[k for k, v in pm(cMP).items() if v and k + ".lean" in PATHS]}')
L.append('')
L.append('axioms at M\' (mprime/axioms-summary-AxiomsLand.txt, mprime/axioms-summary-AxiomsLE.txt):')
for n in ('mprime/axioms-summary-AxiomsLand.txt', 'mprime/axioms-summary-AxiomsLE.txt'):
    t = zr(n).decode().splitlines()
    nonstd = [x for x in t if '::' in x and x.split('::')[1].strip() not in ('propext, Classical.choice, Quot.sound', 'none')]
    L.append(f'  {n}: {sum("::" in x for x in t)} constants, nonstandard {nonstd}; '
             + '; '.join(x for x in t if x.startswith(('ADMITTED', 'CENSUS')) or 'yaoProtocol_hbcSecure ::' in x or 'acc_poly ::' in x))
L.append(f'  mprime/axioms-vs-M.diff: {zr("mprime/axioms-vs-M.diff").decode().count(chr(10))} lines, only closure sizes: '
         f'{all(("closure" in x) or x[:1] not in "<>" for x in zr("mprime/axioms-vs-M.diff").decode().splitlines())}')
L.append(f'  the probe AxiomsLE.lean (mprime/probe-src/), its commands: '
         f'{[x.strip() for x in zr("mprime/probe-src/AxiomsLE.lean").decode().splitlines() if re.match(r"^(#check|#print|#admitted|#axioms)", x.strip())]}')
L.append('  its raw log (mprime/probe-runs/mods/ScYaoLEProbe_AxiomsLE.log), the #check output included:')
L.extend('    | ' + x for x in zr('mprime/probe-runs/mods/ScYaoLEProbe_AxiomsLE.log').decode().rstrip('\n').split('\n'))
L.append(f'  M (axioms-summary-AxiomsLand.txt, the integration before the landing edits): yaoProtocol_hbcSecure line '
         f'{[x for x in zr("axioms-summary-AxiomsLand.txt").decode().splitlines() if "yaoProtocol_hbcSecure" in x]}')
L.append('')
L.append('RunWithHost seals at M\' (mprime/seals-{coe,strict}/{A,B}/, mprime/seal-runs/):')
srec = {j['module']: j for j in (json.loads(x) for x in zr('mprime/seal-runs/results.jsonl').decode().splitlines() if x.strip()) if 'module' in j}
src_h2 = R.blob(H2, RWH)
probes = {}
for var in ('coe', 'strict'):
    for ab in ('A', 'B'):
        lab = f'Seal{ab}_Cryptography_SecureComputation_Yao_HybridProof_RunWithHost'
        js = json.loads(zr(f'mprime/seals-{var}/{ab}/{lab}.json'))
        mfj = json.loads(zr(f'mprime/seals-{var}/{ab}/manifest.json'))
        pr = zr(f'mprime/seals-{var}/{ab}/{lab}.lean.txt')
        probes[(var, ab)] = pr
        rb_ = bytearray(pr); okins = True
        for ins in sorted(js['insertions'], key=lambda x: -x['probe_byte_offset']):
            seg = bytes(rb_[ins['probe_byte_offset']:ins['probe_byte_offset'] + ins['byte_count']])
            okins &= sha(seg) == ins['sha256']
            del rb_[ins['probe_byte_offset']:ins['probe_byte_offset'] + ins['byte_count']]
        rec = srec[f'ScYaoLESeal_{var}/{lab}']
        log = zr(f'mprime/seal-runs/mods/ScYaoLESeal_{var}_{lab}.log').decode()
        e1 = len(re.findall(r'^\S+\.lean:\d+:\d+: error:', log, re.M)); e2 = len(re.findall(r'^\S+\.lean:\d+:\d+: error\(', log, re.M))
        ends = re.findall(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', log)
        sealed = {r_['spelling'] for r_ in js['rows']}
        L.append(f'  {var} {ab}: probe sha256 = manifest probe_sha256 = run record source_sha256: '
                 f'{sha(pr) == mfj["probes"][0]["probe_sha256"] == rec["source_sha256"]}; manifest rev {mfj["rev"][:8]} '
                 f'(= M\' {mfj["rev"] == MP[0]}); removing the {len(js["insertions"])} recorded insertions (each hash '
                 f'checked: {okins}) gives RunWithHost.lean at {H2[:8]} byte for byte: {bytes(rb_) == src_h2}; requests '
                 f'{js["requested"]} = rows {len(js["rows"])}; raw log: error: {e1}, error( {e2}, install '
                 f'{"phase=install" in log}, eof {"phase=eof" in log}, SEAL-END requested = verified '
                 f'{bool(ends) and all(a_ == b_ for a_, b_ in ends)}; record rc {rec["rc"]}, log sha256 = record '
                 f'{sha(log.encode()) == rec["log_sha256"]}; Complexity.StateLoop.MajLoop.acc sealed '
                 f'{"Complexity.StateLoop.MajLoop.acc" in sealed}, its term readers {js["term_readers"].get("Complexity.StateLoop.MajLoop.acc")}; '
                 f'notation exclusions {mfj["notation_exclusions"]}')
L.append(f'  coe and strict probes byte-identical: A {probes[("coe", "A")] == probes[("strict", "A")]}, B '
         f'{probes[("coe", "B")] == probes[("strict", "B")]} (no projection-coercion instance in this file\'s closure)')
L.append('')
L.append('Yao.lean seals (int-tip/seal-*): run at M, not at M\':')
for ab in ('A', 'B'):
    mfj = json.loads(zr(f'seals-coe/{ab}/manifest.json'))
    L.append(f'  coe {ab}: manifest rev {mfj["rev"][:8]} (= M {mfj["rev"] == M_[0]}); seal-sum-coe-{ab}.tsv: '
             f'{zr(f"seal-sum-coe-{ab}.tsv").decode().split(chr(9))[1:4]} (requests, rc, errors)')
L.append(f'  seal-compare-phase2.txt: ' + ' | '.join(zr('seal-compare-phase2.txt').decode().strip().splitlines()))
L.append(f'  Yao.lean at M = at {H1[:8]}: {R.blob(M_[1], YAO) == R.blob(H1, YAO)}; Yao.lean at M\' = at {H2[:8]}: '
         f'{R.blob(MP[1], YAO) == R.blob(H2, YAO)}; the two differ by comment lines only (le-r2.txt, frozen-r2.txt): '
         f'{code_lines(R.show(H1, YAO)) == code_lines(R.show(H2, YAO))}')
untouched = [p for p in CH if p != RWH]
L.append(f'  files of the landing edits with no seal at M\' (comment-only, le-r2.txt): {[p.replace(SC, "") for p in untouched]}')
out('integration-r2.txt', L)

# ---------------------------------------------------------------- closure-r2.txt
L = []
g2 = R.graph(H2)
g1 = R.graph(H1)
cl2 = closure(g2, [p for p in PATHS if p.endswith('.lean')])
cl1 = closure(g1, [p for p in PATHS if p.endswith('.lean')])
r1 = zipfile.ZipFile(R1SRC)
r1n = {n for n in r1.namelist() if n.startswith('TCSlib/') and not n.endswith('/')}
L.append(f'the import closure of the 70 changed modules: at round 1 {len(cl1)} files, at round 2 {len(cl2)}; same path '
         f'set {cl1 == cl2}; import lines of the 70 files unchanged: '
         f'{all(re.findall(r"(?m)^import .*", R.show(H1, p)) == re.findall(r"(?m)^import .*", R.show(H2, p)) for p in PATHS)}')
L.append(f'round 1\'s sources.zip: {len(r1n)} TCSlib files; = the closure path set: {r1n == cl2}')
same = [p for p in sorted(cl2) if R.blob(H2, p) == r1.read(p)]
diff_ = [p for p in sorted(cl2) if R.blob(H2, p) != r1.read(p)]
L.append(f'  files whose blob at {H2[:8]} equals round 1\'s sources.zip member: {len(same)}; differing: {len(diff_)} = the 9 '
         f'files of the round-2 diff: {sorted(diff_) == sorted(CH)}')
L.append(f'  {SL} at {H2[:8]} = at the records pin = at {BASE[:8]} = round 1\'s member: '
         f'{R.blob(H2, SL) == R.blob(PIN, SL) == R.blob(BASE, SL) == r1.read(SL)}')
chain = None
from collections import deque
q = deque([[RWH]]); seen = {RWH}
while q:
    path = q.popleft()
    if path[-1] == SL:
        chain = path; break
    for nx in g2.get(path[-1], []):
        if nx not in seen:
            seen.add(nx); q.append(path + [nx])
L.append(f'  shortest import chain RunWithHost -> StringLoops at {H2[:8]}: {[x.replace("TCSlib/", "").replace(".lean", "") for x in chain]}')
sl = R.show(H2, SL)
dsl = decls(sl)
for k in ('acc', 'acc_eq', 'acc_poly'):
    if k in dsl:
        L.append(f'  StringLoops `{k}` (line {dsl[k][1]}): {dsl[k][2].split(chr(10))[0].strip()} ...')
rw_ = decls(R.show(H2, RWH))
norm = lambda s: re.sub(r'\b[vw]\b', 'x', s.split(':=', 1)[1].strip())
L.append(f'  the two acceptance predicates, bound variable renamed: RunWithHost.acc `{norm(rw_["acc"][2])}` | '
         f'MajLoop.acc `{norm(dsl["acc"][2])}`; equal {norm(rw_["acc"][2]) == norm(dsl["acc"][2])}')
out('closure-r2.txt', L)

# ---------------------------------------------------------------- mergetrees-r2.txt
L = []
t, rc_, o = R.mergetree(PIN, H2)
dd = R.git('diff', '--name-only', PIN, t).stdout.split()
L.append(f'git merge-tree --write-tree {PIN[:8]} (records pin) {H2[:8]}: rc {rc_}, tree {t}; the merged tree differs from '
         f'the pin in exactly the PR\'s 70 paths: {sorted(dd) == PATHS}')
L.append(f'  its TCSlib, TCSlib.lean, audits subtrees = those of M\' ({MP[1][:8]}): '
         f'{all(R.rp(f"{t}:{x}") == R.rp(f"{MP[1]}:{x}") for x in ("TCSlib", "TCSlib.lean", "audits"))}')
for n, h in OPEN.items():
    t, rc_, o = R.mergetree(H2, h)
    mbx = R.git('merge-base', PIN, h).stdout.strip()
    their = set(R.git('diff', '--name-only', mbx, h).stdout.split())
    L.append(f'#{n} head {h[:8]}: merge-tree with {H2[:8]} rc {rc_} (clean {rc_ == 0}); its own paths since its merge base '
             f'with the pin {len(their)}; shared with #341\'s 70: {sorted(their & set(PATHS))}')
L.append('open PRs on the records branch (GitHub, 2026-11-16): #341, #339, #338, #331; #340 is no longer open and not '
         'merged into the pin')
out('mergetrees-r2.txt', L)

print('\n'.join(f'{k}: {len(v.splitlines())} lines' for k, v in files.items()))
