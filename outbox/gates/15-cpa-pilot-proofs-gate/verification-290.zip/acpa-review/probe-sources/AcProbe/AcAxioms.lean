import Lean
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA

/-! adaptive-cpa review: axioms of the target and its two downstream corollaries (explicit
`#print axioms`), and of every stored constant of the five touched modules (collectAxioms). -/

set_option maxHeartbeats 0

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure.adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.bitwise_padded_adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.exists_adaptive_cpa

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let owners : List Name := [`TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Hybrid,
    `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Handler,
    `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Games,
    `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Reduction,
    `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA]
  let mut n := 0
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"AX {home} {c} {axs.toList}"
    n := n + 1
  IO.println s!"AX-COUNT {n}"
