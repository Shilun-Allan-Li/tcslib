import Lean
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA

def kindStr : Option Lean.ConstantInfo → String
  | some (.thmInfo _) => "theorem"
  | some (.defnInfo _) => "def"
  | some _ => "other"
  | none => "absent"

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for s in ["TCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure_iff", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.adaptiveINDSecure_iff", "zero_mul", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.adaptiveIndGame_eq", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.adaptiveIndImpl_challenge_encrypt", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.adaptiveIndImpl_challenge_full", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.adaptiveIndImpl_challenge_zero", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.adaptiveIndImpl_dec_other", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.inLens_one", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.inLens_zero", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_challenge_repeat_onSpec", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_dec_onSpec", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.outLens_one", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.outLens_zero", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indGame_eq", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_challenge_none_onSpec"] do
    IO.println s!"KIND {s} {kindStr (env.find? s.toName)}"
  for (n, c) in env.constants.toList do
    let t := n.toString
    if (t.endsWith ".expect_bind" || t.endsWith ".prob_bind" || t.endsWith ".expect_pure" ||
        t.endsWith ".prob_pure") && !n.isInternal then
      IO.println s!"FOUND {t} {kindStr (some c)}"
