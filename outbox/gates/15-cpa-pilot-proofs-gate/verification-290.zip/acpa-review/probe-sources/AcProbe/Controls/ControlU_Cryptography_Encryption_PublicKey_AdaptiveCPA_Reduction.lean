import Lean
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Reduction

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace AcControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

theorem ctlChRun {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := rfl

theorem ctlChRunReader {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := TCSlib.Cryptography.Composability.ChallengeSim.chRun_pure g a s

theorem ctlRecAdvIn (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl

theorem ctlRecAdvInReader (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn_eq c

open TCSlib.Cryptography.Games in
theorem ctlSimulate {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl

open TCSlib.Cryptography.Games in
theorem ctlSimulateReader {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := TCSlib.Cryptography.Games.simulate_pure impl a s

theorem ctlPkInLens (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl

theorem ctlPkInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=
  S.inLens_zero n

open TCSlib.Cryptography.Games in
theorem ctlCastImpl {k : ℕ} {σ : Type} {ins ins' outs outs' : Fin k → ℕ}
    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.castImpl (ins := ins) (outs := outs) O i x s =
      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>
        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) := rfl

open TCSlib.Cryptography.Games in
theorem ctlCastImplReader {k : ℕ} {σ : Type} {ins ins' outs outs' : Fin k → ℕ}
    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.castImpl (ins := ins) (outs := outs) O i x s =
      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>
        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) :=
  TCSlib.Cryptography.Composability.AdaptiveCPA.castImpl_eq O i x s

open TCSlib.Cryptography.Games in
theorem ctlHybImpl {ins outs : Fin 2 → ℕ} {L : ℕ} {C : Type} [Fintype C] [Nonempty C] (κ : ℕ)
    (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)
    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) := rfl

open TCSlib.Cryptography.Games in
theorem ctlHybImplReader {ins outs : Fin 2 → ℕ} {L : ℕ} {C : Type} [Fintype C] [Nonempty C]
    (κ : ℕ) (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)
    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) :=
  TCSlib.Cryptography.Composability.AdaptiveCPA.hybImpl_zero κ E sel x h

theorem ctlMsgOf (m : ℕ) (β : Bool) (l : List Bool) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf m β l = if β then l.drop m else l.take m := rfl

theorem ctlMsgOfReader (m : ℕ) (β : Bool) (l : List Bool) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf m β l = if β then l.drop m else l.take m := TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf_eq m β l

theorem ctlAcDin (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) : TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 0 = S.ctLen := rfl

theorem ctlAcDinReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) : TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 0 = S.ctLen := TCSlib.Cryptography.Composability.AdaptiveCPA.acDin_zero S

theorem ctlAcHandler (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :
    (TCSlib.Cryptography.Composability.AdaptiveCPA.acHandler S cap ist).perCall = .const 1 := rfl

theorem ctlAcHandlerReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :
    (TCSlib.Cryptography.Composability.AdaptiveCPA.acHandler S cap ist).perCall = .const 1 := TCSlib.Cryptography.Composability.AdaptiveCPA.acHandler_perCall S cap ist

theorem ctlAcEnc (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) (pk : List Bool) (β : Bool)
    (mm : Fin ((TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n
      (Turing.pairEncode pk (TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) := rfl

theorem ctlAcEncReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) (pk : List Bool) (β : Bool)
    (mm : Fin ((TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n
      (Turing.pairEncode pk (TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) :=
  TCSlib.Cryptography.Composability.AdaptiveCPA.acEnc_eq S n pk β mm r

end AcControls

