import Lean
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Asymptotic.EnsemblesLemmas
import TCSlib.Cryptography.Asymptotic.HardCoreGLColl
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Collision
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Games
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Handler
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Lazy
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Reduction
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Transfer
import TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Games
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Handler
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Hybrid
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Reduction
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA.Planted
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA.QueryHandler
import TCSlib.Cryptography.Encryption.PublicKey.ElGamal
import TCSlib.Cryptography.Encryption.PublicKey.HybridMachine
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Decrypt
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Encrypt
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.ChallengeSim
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.PaddedCPA
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.RecordHandler
import TCSlib.Cryptography.Encryption.PublicKey.TrapdoorCPA
import TCSlib.Cryptography.Foundations
import TCSlib.Cryptography.Foundations.BitLists
import TCSlib.Cryptography.Games.BitCodec
import TCSlib.Cryptography.Games.Efficiency
import TCSlib.Cryptography.Games.Hopping
import TCSlib.Cryptography.Games.Probability
import TCSlib.Cryptography.Games.Simulate
import TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM.Run
import TCSlib.Cryptography.Pseudorandom.NextBit
import TCSlib.Cryptography.SecureComputation.Yao
import TCSlib.Cryptography.ZeroKnowledge.CommitmentLemmas
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRep
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRepGI
import TCSlib.Cryptography.Implications.PublicKey

/-! dl-consolidation review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure.adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.bitwise_padded_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.exists_adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.padded_cpa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_rsa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_factoring
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_cca2_of_indSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_of_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2

def owners : List Name := [`TCSlib.Cryptography.Asymptotic.Adversary,
  `TCSlib.Cryptography.Asymptotic.EnsemblesLemmas,
  `TCSlib.Cryptography.Asymptotic.HardCoreGLColl,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Collision,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Games,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Handler,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Lazy,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Reduction,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Transfer,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity,
  `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Games,
  `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Handler,
  `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Hybrid,
  `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Reduction,
  `TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA,
  `TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA.Planted,
  `TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA.QueryHandler,
  `TCSlib.Cryptography.Encryption.PublicKey.ElGamal,
  `TCSlib.Cryptography.Encryption.PublicKey.HybridMachine,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Decrypt,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Encrypt,
  `TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity,
  `TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.ChallengeSim,
  `TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.PaddedCPA,
  `TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.RecordHandler,
  `TCSlib.Cryptography.Encryption.PublicKey.TrapdoorCPA,
  `TCSlib.Cryptography.Foundations,
  `TCSlib.Cryptography.Foundations.BitLists,
  `TCSlib.Cryptography.Games.BitCodec,
  `TCSlib.Cryptography.Games.Efficiency,
  `TCSlib.Cryptography.Games.Hopping,
  `TCSlib.Cryptography.Games.Probability,
  `TCSlib.Cryptography.Games.Simulate,
  `TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM.Run,
  `TCSlib.Cryptography.Pseudorandom.NextBit,
  `TCSlib.Cryptography.SecureComputation.Yao,
  `TCSlib.Cryptography.ZeroKnowledge.CommitmentLemmas,
  `TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRep,
  `TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRepGI]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

