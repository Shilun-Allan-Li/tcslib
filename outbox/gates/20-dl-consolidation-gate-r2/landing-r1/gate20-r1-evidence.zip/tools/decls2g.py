"""decls2g.py <root> <base-rev> <file>...: decls2.py (maintainer tool, verbatim decls()) aggregated over
all files by full name, so moves between files show as MOVED; deleted/new files handled.
Rows: REMOVED/ADDED/CHANGED/MOVED(same normalized statement, different file)."""

import sys, re, subprocess
root, base = sys.argv[1], sys.argv[2]
files = sys.argv[3:]
KW = r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)'
def strip(src):
    src = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), src, flags=re.S)
    return re.sub(r'--[^\n]*', '', src)
def decls(src):
    lines = strip(src).split('\n')
    out, ns, i = {}, [], 0
    while i < len(lines):
        l = lines[i]
        m = re.match(r'^namespace\s+(\S+)', l)
        if m: ns.append(m.group(1)); i += 1; continue
        m = re.match(r'^end\s+(\S+)\s*$', l)
        if m and ns and ns[-1] == m.group(1): ns.pop(); i += 1; continue
        m = re.match(r'^(@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec)\s+)*' + KW +
                     r'\s+([^\s(:{\[]+)', l)
        if m and not re.search(r'\bprivate\b', l.split(m.group(3))[0]):
            name = m.group(4)
            full = name[len('_root_.'):] if name.startswith('_root_.') else '.'.join(ns + [name])
            def cut(t):
                d = 0
                for k, ch in enumerate(t):
                    if ch in '([{⟨': d += 1
                    elif ch in ')]}⟩': d -= 1
                    elif d == 0 and t.startswith(':=', k): return t[:k]
                    elif d == 0 and re.match(r'\bwhere\b', t[k:]) and (k == 0 or not t[k-1].isalnum()):
                        return t[:k]
                return None
            j, buf = i, []
            while j < len(lines):
                buf.append(lines[j])
                c = cut(' '.join(buf))
                if c is not None or (j > i and lines[j+1:j+2] and re.match(r'^\s*\|[^|\n]*=>', lines[j+1])
                                     and not re.search(r'\bmatch\b', ' '.join(buf))):
                    break
                j += 1
            t = ' '.join(buf)
            c = cut(t)
            t = c if c is not None else t
            t = re.sub(r'^@\[[^\]]*\]\s*', '', t.strip())
            out[full] = (m.group(3), i + 1, re.sub(r'\s+', ' ', t).strip())
            i = j + 1; continue
        i += 1
    return out

A, B = {}, {}
for f in files:
    old = subprocess.run(['git', 'show', f'{base}:{f}'], cwd=root, capture_output=True, text=True).stdout
    try: new = open(f'{root}/{f}', encoding='utf-8').read()
    except FileNotFoundError: new = ''
    for n, v in (decls(old) if old else {}).items(): A[n] = (f,) + v
    for n, v in (decls(new) if new else {}).items(): B[n] = (f,) + v
for n in sorted(set(A) | set(B)):
    if n in A and n not in B: print(f"REMOVED\t{A[n][0]}:{A[n][2]}\t{n}\t{A[n][1]}\t{A[n][3]}")
    elif n in B and n not in A: print(f"ADDED\t{B[n][0]}:{B[n][2]}\t{n}\t{B[n][1]}\t{B[n][3]}")
    elif A[n][3] != B[n][3]: print(f"CHANGED\t{A[n][0]}:{A[n][2]}->{B[n][0]}:{B[n][2]}\t{n}\t{B[n][1]}\t{A[n][3]}\t=>\t{B[n][3]}")
    elif A[n][0] != B[n][0]: print(f"MOVED\t{A[n][0]}:{A[n][2]}->{B[n][0]}:{B[n][2]}\t{n}\t{B[n][1]}")

