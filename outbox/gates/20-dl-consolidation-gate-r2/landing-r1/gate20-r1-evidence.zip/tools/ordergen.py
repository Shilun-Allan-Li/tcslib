"""ordergen.py <repo> <rev> <root module path>... : topological (imports-first, DFS) order of the
TCSlib/audits source closure of the roots at <rev>, read with git show. Prints module paths.
Also writes Mathlib direct roots to stderr as 'ROOT <name>'."""
import sys, re, subprocess
repo, rev, roots = sys.argv[1], sys.argv[2], sys.argv[3:]
cache = {}
def src(mp):
    if mp not in cache:
        r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{mp}.lean'], capture_output=True)
        if r.returncode: raise SystemExit(f'missing {mp}')
        cache[mp] = r.stdout.decode('utf-8')
    return cache[mp]
def imps(mp):
    return re.findall(r'^import\s+(\S+)', src(mp), re.M)
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
order, seen, mroots = [], set(), set()
sys.setrecursionlimit(100000)
def visit(mp):
    if mp in seen: return
    seen.add(mp)
    for i in imps(mp):
        if local(i): visit(i.replace('.', '/'))
        elif i.startswith('Mathlib'): mroots.add(i)
    order.append(mp)
for r in roots: visit(r)
print('\n'.join(order))
for m in sorted(mroots): sys.stderr.write('ROOT ' + m + '\n')
