"""censuscmp.py <base census log> <head census log> <namemap> <out-prefix>: compares the stored constants of the
changed files (landing parent vs landing head) by normalized name (private prefix stripped). Base types are
renamed through the worker's name map (verified separately), so a type that mentions a moved constant compares
equal to its re-pointed head type. Writes <out>.tsv rows and prints a summary; checks the name map."""
import sys, re, collections
bl, hl, nm, out = sys.argv[1:5]
def load(p):
    d = {}
    for l in open(p, encoding='utf-8'):
        if not l.startswith('C\t'): continue
        f = l.rstrip('\n').split('\t')
        _, n, internal, priv, home, kind, h, red, abbr, simp, inst, prot, axs = f
        d.setdefault(n, []).append(dict(name=n, internal=internal == 'true', private=priv == 'true', home=home, kind=kind,
                                        hash=h, red=red, abbr=abbr, simp=simp, inst=inst, prot=prot, axs=axs))
    return d
B, H = load(bl), load(hl)
dups = [n for n, v in list(B.items()) + list(H.items()) if len(v) > 1]
B = {n: v[0] for n, v in B.items()}; H = {n: v[0] for n, v in H.items()}
pairs = []
for l in open(nm):
    l = l.strip()
    if not l or l.startswith('#'): continue
    a, b = [x.strip() for x in l.split('->')]
    pairs.append((re.sub(r'^_private\.[^ ]*?\.0\.', '', a) if a != '-' else a, b))
aux = lambda n: bool(re.search(r'(\.match_\d+|\._proof_\d+|\.eq_\d+|\.eq_def|\._unary|\.proof_\d+|\._sunfold|\.congr_simp|\.eq_unfold|_aux_|\._simp_|\.induct|\._closed)', n)) or n.split('.')[-1].startswith('_')
rows = []
removed = sorted(set(B) - set(H)); added = sorted(set(H) - set(B)); common = sorted(set(B) & set(H))
moved = [n for n in common if B[n]['home'] != H[n]['home']]
changed = [n for n in common if B[n]['hash'] != H[n]['hash']]
attr = [n for n in common if (B[n]['red'], B[n]['abbr'], B[n]['simp'], B[n]['inst'], B[n]['prot'], B[n]['private']) != (H[n]['red'], H[n]['abbr'], H[n]['simp'], H[n]['inst'], H[n]['prot'], H[n]['private'])]
ax = [n for n in common if B[n]['axs'] != H[n]['axs']]
with open(out + '.tsv', 'w') as f:
    for n in removed: f.write(f"REMOVED\t{'aux' if aux(n) else 'named'}\t{n}\t{B[n]['home']}\t{B[n]['kind']}\t{'private' if B[n]['private'] else 'public'}\n")
    for n in added: f.write(f"ADDED\t{'aux' if aux(n) else 'named'}\t{n}\t{H[n]['home']}\t{H[n]['kind']}\t{'private' if H[n]['private'] else 'public'}\tsimp={H[n]['simp']}\tinst={H[n]['inst']}\tred={H[n]['red']}\tabbr={H[n]['abbr']}\n")
    for n in moved: f.write(f"MOVED\t{n}\t{B[n]['home']} -> {H[n]['home']}\ttype-equal={B[n]['hash'] == H[n]['hash']}\n")
    for n in changed: f.write(f"TYPE-CHANGED\t{'aux' if aux(n) else 'named'}\t{n}\t{H[n]['home']}\t{H[n]['kind']}\n")
    for n in attr: f.write(f"ATTR-CHANGED\t{n}\t{[B[n][k] for k in ('red','abbr','simp','inst','prot','private')]} -> {[H[n][k] for k in ('red','abbr','simp','inst','prot','private')]}\n")
    for n in ax: f.write(f"AXIOMS-CHANGED\t{n}\t{B[n]['axs']} -> {H[n]['axs']}\n")
# name map check
nmr = []
for a, b in pairs:
    gone = a == '-' or a not in H or a == b
    exists = b in H or not b.startswith('TCSlib')
    eq = (a in B and b in H and B[a]['hash'] == H[b]['hash'])
    nmr.append((a, b, gone, exists, eq))
rem_named = [n for n in removed if not aux(n)]
mapped = {a for a, b in pairs}
unmapped = [n for n in rem_named if n not in mapped]
with open(out + '-namemap.tsv', 'w') as f:
    for r in nmr: f.write('\t'.join(map(str, r)) + '\n')
s = collections.Counter()
print(f"base {len(B)} head {len(H)} common {len(common)} dup-normalized-names {dups}")
print(f"removed {len(removed)} (named {len(rem_named)}, public named {sum(1 for n in rem_named if not B[n]['private'])}); added {len(added)} (named {sum(1 for n in added if not aux(n))}); moved {len(moved)}; type-changed {len(changed)} (named {sum(1 for n in changed if not aux(n))}); attr-changed {len(attr)}; axioms-changed {len(ax)}")
print(f"namemap rows {len(nmr)}: old gone {sum(r[2] for r in nmr)}, new exists {sum(r[3] for r in nmr)}, same type {sum(r[4] for r in nmr)}; removed named not in map: {unmapped}")
print('added simp/inst:', [n for n in added if H[n]['simp'] == 'true' or H[n]['inst'] == 'true'], 'added abbrev:', [n for n in added if H[n]['abbr'] == 'abbrev'])
