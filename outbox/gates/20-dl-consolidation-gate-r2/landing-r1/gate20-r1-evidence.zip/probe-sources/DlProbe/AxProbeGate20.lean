import Lean
import TCSlib.Cryptography.Asymptotic.OneWayLemmas
import TCSlib.Cryptography.Asymptotic.UniversalPadding
import TCSlib.Cryptography.Implications.PublicKey
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation

/-! dl-consolidation review census and axioms probe (LE-gate20: OneWayLemmas, UniversalPadding; 16 endpoints). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_of_simNMSecure
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_of_nmSecure_cpa
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa
#print axioms TCSlib.Cryptography.OneWay.ofFn_block_eq_take_drop
#print axioms TCSlib.Cryptography.OneWay.length_take_drop_block
#print axioms TCSlib.Cryptography.PadQuad.exists_pow_dominates
#print axioms TCSlib.Cryptography.PadQuad.length_gStr
#print axioms TCSlib.Cryptography.PadQuad.lengthRegular_gStr
#print axioms TCSlib.Cryptography.PadQuad.family_inLen
#print axioms TCSlib.Cryptography.PadQuad.ofFn_family_f
#print axioms TCSlib.Cryptography.PadQuad.exists_linearTime_gStr
#print axioms TCSlib.Cryptography.PadQuad.easy_of_linear
#print axioms TCSlib.Cryptography.PadQuad.quadraticCode_of_linear
#print axioms TCSlib.Cryptography.PadQuad.raw_eq
#print axioms TCSlib.Cryptography.PadQuad.gStr_eq
#print axioms TCSlib.Cryptography.PadQuad.padStr_eq_gStr
#print axioms TCSlib.Cryptography.PadQuad.f_eq_of_gStr_eq
#print axioms TCSlib.Cryptography.PadQuad.invProbAt_family_le
#print axioms TCSlib.Cryptography.PadQuad.strongOneWay
#print axioms TCSlib.Cryptography.PadQuad.exists_family
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure.adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.bitwise_padded_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.exists_adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.padded_cpa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_rsa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_factoring
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_cca2_of_indSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_of_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2

def owners : List Name := [`TCSlib.Cryptography.Asymptotic.OneWayLemmas,
  `TCSlib.Cryptography.Asymptotic.UniversalPadding]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

