"""blockcmp.py <repo> <old> <new> <file> <name>...: for each named declaration, the text from its keyword line to the
end of its header (first top-level ':=' / ' where' / a line starting with '|'), or for a def-like declaration the whole
block up to the next blank line, at both revisions; prints SAME or DIFF."""
import re, subprocess, sys
repo, old, new, f = sys.argv[1:5]
def show(r): return subprocess.run(['git', '-C', repo, 'show', f'{r}:{f}'], capture_output=True, text=True).stdout
def block(t, name):
    L = t.split('\n')
    pat = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(theorem|def|abbrev|inductive|structure|instance)\s+' + re.escape(name) + r'(?=[\s({:\[]|$)')
    hits = [i for i, l in enumerate(L) if pat.match(l)]
    assert len(hits) == 1, (name, hits)
    i = hits[0]; kind = pat.match(L[i]).group(1)
    j = i
    while j < len(L) and L[j].strip() != '': j += 1
    text = '\n'.join(L[i:j])
    if kind == 'theorem':
        m = re.search(r':=|\n\s*\|', text)
        text = text[:m.start()] if m else text
    return kind, i + 1, text
for n in sys.argv[5:]:
    k, a, x = block(show(old), n); _, b, y = block(show(new), n)
    print('SAME' if x == y else 'DIFF', k, n, f'{f.split("/")[-1]}:{a}->{b}', f'{len(x)} chars')
