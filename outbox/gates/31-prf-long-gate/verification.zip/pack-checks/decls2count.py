"""decls2count.py <repo> <rev> <file>...: number of declarations decls2.py's parser keys per file, and the raw count of
top-level declaration keywords (a cross-check of the frozen-check counts)."""
import re, subprocess, sys
repo, rev = sys.argv[1:3]
src = open(f'{repo}/briefs/pass-shelat-ch5-8/maintainer/tools/decls2.py', encoding='utf-8').read()
src = src[:src.index('for f in files:')]
g = {'__name__': 'decls2', 'sys': sys}
argv = sys.argv; sys.argv = ['decls2', repo, rev]; exec(compile(src, 'decls2.py', 'exec'), g); sys.argv = argv
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*'
                r'(theorem|lemma|def|abbrev|instance|structure|inductive|class)\b(\s+\S+)?', re.M)
for f in sys.argv[3:]:
    t = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, text=True).stdout
    d = g['decls'](t)
    raw = [(m.group(1), (m.group(2) or '').strip()) for m in KW.finditer(t)]
    names = [n for _, n in raw]
    print(f, 'decls2', len(d), 'raw', len(raw), 'missing', [n for n in names if n not in d and n.split('.')[-1] not in {k.split('.')[-1] for k in d}])
