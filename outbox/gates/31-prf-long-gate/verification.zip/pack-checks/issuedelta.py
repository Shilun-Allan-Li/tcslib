"""issuedelta.py <repo> <issue-base> <pr-base> <head>: the Lean delta between the issue base and the PR base, against the
PR's changed modules at the head: shared paths, delta modules in the PR closure, and head modules downstream of both."""
import re, subprocess, sys
repo, ib, pb, head = sys.argv[1:5]
def git(*a): return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True, text=True).stdout
delta = [p for p in git('diff', '--name-only', '--no-renames', ib, pb).split() if p.endswith('.lean')]
pr = [p for p in git('diff', '--name-only', '--no-renames', pb, head).split() if p.endswith('.lean')]
tree = [p for p in git('ls-tree', '-r', '--name-only', head).split() if p.endswith('.lean')]
g = {}
for p in tree:
    s = subprocess.run(['git', '-C', repo, 'show', f'{head}:{p}'], capture_output=True, text=True).stdout
    g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', s)]
def clo(roots):
    seen, st = set(), list(roots)
    while st:
        x = st.pop()
        if x in seen or x not in g: continue
        seen.add(x); st.extend(g[x])
    return seen
print('delta .lean', delta)
print('shared with PR', sorted(set(delta) & set(pr)))
print('delta modules in the PR closure at head', sorted(set(delta) & clo(pr)))
both = sorted(p for p in tree if (set(delta) & clo([p])) and (set(pr) & clo([p])))
print('head modules downstream of a delta module and a PR module', len(both), both)
