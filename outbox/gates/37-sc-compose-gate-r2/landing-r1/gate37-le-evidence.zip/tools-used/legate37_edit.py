"""legate37_edit.py <worktree> <plan-out.tsv>: sc-compose LE-gate37 (Gate 37 G37-01/02/03; Seyoon: "re-point via import").
G37-01  ComposeSecurity/Machines.lean: `import TCSlib.Cryptography.ZeroKnowledge.CommitmentLemmas` added after the last import;
        the proof of ComposeMachines.encodeMsgs_append becomes the public CommitmentLemmas.encodeMsgs_append (fully qualified);
        header (text before `:=`) byte-identical; one sentence naming the source inserted at the end of the docstring.
G37-02  ComposeSecurity/Bounds.lean (imports Machines, so no new import): the proof of ComposeBound.length_encodeMsgs_le becomes
        the public CommitmentLemmas.length_encodeMsgs_le; same header rule and docstring sentence.
G37-03  docstrings only: every LE-doc formula that the sc-compose LE-doc (f61ce08f, ledoc_sc.py) cut at 240 characters with
        " …" -- the eleven readers named by the coordinator and the nine other declarations cut by the same rule (the defs
        GoodRuns, sampleA, sampleB, whose formula is their reader's, and exists_main_msgs_le, exists_main_outV_le,
        exists_main_outP_le, runMsg_composeCoins, exists_tmplA_bound, exists_tmplB_bound) -- is replaced by the complete
        conclusion, extracted exactly as ledoc_sc.py does (the declaration's own conclusion; for a def, its _eq/_iff
        reader's), wrapped at 100 characters (the last line leaving room for a following ` -/`). The cut text is located by
        its whitespace-insensitive token sequence inside the declaration's own docstring and must occur there exactly once.
Every replacement is asserted to apply exactly once."""
import sys, os, re
TOOLS = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, TOOLS)
import frozencheck_lib as F
wt, planf = sys.argv[1:3]
D = os.path.join(wt, 'TCSlib/Cryptography/SecureComputation/ComposeSecurity')
plan = []
def sub1(path, old, new, tag):
    s = open(path, encoding='utf-8').read()
    assert s.count(old) == 1, (tag, s.count(old))
    open(path, 'w', encoding='utf-8').write(s.replace(old, new)); plan.append((os.path.relpath(path, wt), tag, 'REPLACE'))
# G37-01
M = os.path.join(D, 'Machines.lean')
sub1(M, 'import TCSlib.Cryptography.SecureComputation.Compose\n',
     'import TCSlib.Cryptography.SecureComputation.Compose\nimport TCSlib.Cryptography.ZeroKnowledge.CommitmentLemmas\n',
     'G37-01 import')
sub1(M, """    Strategy.encodeMsgs (a ++ b) = Strategy.encodeMsgs a ++ Strategy.encodeMsgs b := by
  induction a with
  | nil => rw [List.nil_append, Strategy.encodeMsgs_nil, List.nil_append]
  | cons m a ih =>
    rw [List.cons_append, Strategy.encodeMsgs_cons, Strategy.encodeMsgs_cons, ih,
      ← BinArith.pairEncode_nil_append,
      ← BinArith.pairEncode_nil_append (b := Strategy.encodeMsgs a), List.append_assoc]
""", """    Strategy.encodeMsgs (a ++ b) = Strategy.encodeMsgs a ++ Strategy.encodeMsgs b :=
  TCSlib.Cryptography.CommitmentLemmas.encodeMsgs_append a b
""", 'G37-01 proof')
sub1(M, """`encodeMsgs (a ++ b) = encodeMsgs a ++ encodeMsgs b` (`pairEncode_nil_append`). -/
theorem encodeMsgs_append""", """`encodeMsgs (a ++ b) = encodeMsgs a ++ encodeMsgs b` (`pairEncode_nil_append`).
It is the public `CommitmentLemmas.encodeMsgs_append` (`ZeroKnowledge/CommitmentLemmas.lean`). -/
theorem encodeMsgs_append""", 'G37-01 docstring sentence')
# G37-02
B = os.path.join(D, 'Bounds.lean')
sub1(B, """    (Strategy.encodeMsgs l).length ≤ l.length * (2 * c + 2) := by
  rw [ComposeMachines.encodeMsgs_eq_flatMap, ← BinArith.encWords_def]
  exact BinArith.length_encWords_le l c h
""", """    (Strategy.encodeMsgs l).length ≤ l.length * (2 * c + 2) :=
  TCSlib.Cryptography.CommitmentLemmas.length_encodeMsgs_le l c h
""", 'G37-02 proof')
sub1(B, """`|encodeMsgs l| ≤ |l| (2c + 2)` (`encodeMsgs_eq_flatMap`, `BinArith.length_encWords_le`). -/
theorem length_encodeMsgs_le""", """`|encodeMsgs l| ≤ |l| (2c + 2)` (`encodeMsgs_eq_flatMap`, `BinArith.length_encWords_le`).
It is the public `CommitmentLemmas.length_encodeMsgs_le` (`ZeroKnowledge/CommitmentLemmas.lean`). -/
theorem length_encodeMsgs_le""", 'G37-02 docstring sentence')
# G37-03
NS = 'TCSlib.Cryptography.SecureComputation.'
TARGETS = [('Assembly.lean', 'ComposeSim.asmView_eq'), ('Assembly.lean', 'ComposeSim.asmW_eq'),
           ('Efficiency.lean', 'ComposeMachines.runW_eq'), ('Efficiency.lean', 'ComposeMachines.ansW_eq'),
           ('Efficiency.lean', 'HybridProtocol.composePW_eq'), ('Efficiency.lean', 'HybridProtocol.composeVW_eq'),
           ('Runs.lean', 'HybridProtocol.goodRuns_iff'), ('SideA.lean', 'HybridProtocol.sampleA_eq'),
           ('SideB.lean', 'HybridProtocol.sampleB_eq'), ('Sim.lean', 'ComposeSim.phiV_eq'),
           ('Template.lean', 'ComposeSim.hybW_eq'),
           # the nine other LE-doc cuts
           ('Runs.lean', 'HybridProtocol.GoodRuns'), ('SideA.lean', 'HybridProtocol.sampleA'),
           ('SideB.lean', 'HybridProtocol.sampleB'), ('Lengths.lean', 'HybridProtocol.exists_main_msgs_le'),
           ('Lengths.lean', 'HybridProtocol.exists_main_outV_le'), ('Lengths.lean', 'HybridProtocol.exists_main_outP_le'),
           ('Runs.lean', 'HybridProtocol.runMsg_composeCoins'), ('SideA.lean', 'HybridProtocol.exists_tmplA_bound'),
           ('SideB.lean', 'HybridProtocol.exists_tmplB_bound')]
REL = re.compile(r'(=|≤|<|≥|>|↔|≃|∈|≠|→)')
def concl(s, m, d):  # ledoc_sc.py's extraction, verbatim logic
    a, he = d['hdr_span']; h = s[a:he]; mk = m[a:he]
    kw = re.match(r'((?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*\w+\s+\S+)', h, re.S)
    i = kw.end(); depth = 0
    while i < len(h):
        c = h[i]
        if mk[i]:
            if c in '([{⟨⦃': depth += 1
            elif c in ')]}⟩⦄': depth -= 1
            elif c == ':' and depth == 0 and not h.startswith(':=', i): return ' '.join(h[i + 1:].split())
        i += 1
    return ''
def wrap(text, tail):
    lines = ['']
    for w in text.split(' '):
        if len(lines[-1]) + len(w) + (1 if lines[-1] else 0) > 100: lines.append(w)
        else: lines[-1] = (lines[-1] + ' ' + w) if lines[-1] else w
    if tail and len(lines[-1]) + tail > 100:
        h, l = lines[-1].rsplit(' ', 1); lines[-1:] = [h, l]
    return '\n'.join(lines)
for fn, short in TARGETS:
    p = os.path.join(D, fn); s = open(p, encoding='utf-8').read(); m = F.code_mask(s); ds = F.decls(s)
    by = {d['name']: d for d in ds}; n = NS + short; d = by[n]
    c = concl(s, m, d); src = 'conclusion'
    if d['kind'] in F.DEFKINDS and not REL.search(c):
        for suf in ('_eq', '_iff'):
            if n + suf in by: c = concl(s, m, by[n + suf]); src = 'reader ' + short.rsplit('.', 1)[-1] + suf; break
            base, last = n.rsplit('.', 1); alt = base + '.' + last[0].lower() + last[1:] + suf
            if alt in by: c = concl(s, m, by[alt]); src = 'reader ' + alt.rsplit('.', 1)[-1]; break
    assert len(c) > 240, (n, len(c))
    cut = c[:240].rsplit(' ', 1)[0] + ' …'
    a = d['hdr_span'][0]; ds_ = s.rfind('/--', 0, a); de = s.rfind('-/', 0, a)
    doc = s[ds_:de]
    pat = r'`' + r'\s+'.join(re.escape(t) for t in cut.split(' ')) + r'`\.'
    hits = list(re.finditer(pat, doc))
    assert len(hits) == 1, (n, len(hits))
    h0 = hits[0]; st, en = ds_ + h0.start(), ds_ + h0.end()
    assert s[st - 1] == '\n', n
    nl = s.find('\n', en); tail = len(s[en:nl])
    s = s[:st] + wrap('`' + c + '`.', tail) + s[en:]
    open(p, 'w', encoding='utf-8').write(s)
    plan.append((os.path.relpath(p, wt), n, f'COMPLETE {src}: {len(c)} chars (was cut at {len(cut)})'))
with open(planf, 'w', encoding='utf-8') as f:
    for x in plan: f.write('\t'.join(x) + '\n')
print(len(plan), 'edits')
