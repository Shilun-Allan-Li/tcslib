"""legate37_runs_fix.py <worktree>: the follow-up needed by G37-01's import. Machines.lean's new import brings
Asymptotic/CollectionsHelpers.lean (TCSlib.Cryptography.splitCoins (a b : ℕ)) into Runs.lean's closure; inside
`namespace TCSlib.Cryptography.SecureComputation.HybridProtocol` the bare `splitCoins` then resolves through the enclosing
namespace TCSlib.Cryptography (an explicit `open ComposeSim (splitCoins)` does not take precedence; probe in
checks/name-resolution-probe.txt), and composeCoins, composeCoins_fst, composeCoins_snd fail (5 errors). The three bare
uses outside `namespace ComposeSim` are written `ComposeSim.splitCoins`: the same constant as before the import."""
import sys
p = sys.argv[1] + '/TCSlib/Cryptography/SecureComputation/ComposeSecurity/Runs.lean'
s = open(p, encoding='utf-8').read()
for old, new in [("      ((splitCoins (H.composeP_coinLen_eq ρ n)).prodCongr\n        (splitCoins (H.composeV_coinLen_eq ρ n))))",
                  "      ((ComposeSim.splitCoins (H.composeP_coinLen_eq ρ n)).prodCongr\n        (ComposeSim.splitCoins (H.composeV_coinLen_eq ρ n))))"),
                 ("      splitCoins (H.composeP_coinLen_eq ρ n) (m.1, fun j => (t j).1) :=",
                  "      ComposeSim.splitCoins (H.composeP_coinLen_eq ρ n) (m.1, fun j => (t j).1) :="),
                 ("      splitCoins (H.composeV_coinLen_eq ρ n) (m.2, fun j => (t j).2) :=",
                  "      ComposeSim.splitCoins (H.composeV_coinLen_eq ρ n) (m.2, fun j => (t j).2) :=")]:
    assert s.count(old) == 1, old
    s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
print('3 replacements')
