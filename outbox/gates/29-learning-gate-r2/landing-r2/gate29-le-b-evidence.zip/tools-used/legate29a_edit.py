"""legate29a_edit.py <worktree>: #313 resolution edit LE-gate29a (Gate 29 G29-01), proof only, exact replacements.
Random.lean, abs_gameProb_random_sub_half_le: the local `hj` computes the constant average with the public
OneWay.uexp_const instead of re-proving it (uexp_def, sum of a constant, positive cardinality, field_simp); the sketch's
lemma list for Pr[s_j = x] = 2^{-n} gains `OneWay.uexp_const`."""
import sys, os
wt = sys.argv[1]
def edit(rel, R):
    f = os.path.join(wt, rel); s = open(f, encoding='utf-8').read()
    for a, b in R:
        c = s.count(a); assert c == 1, (rel, c, a[:70]); s = s.replace(a, b)
    open(f, 'w', encoding='utf-8').write(s); print(rel, len(R), 'replacements')
edit('TCSlib/Cryptography/Randomness/Learning/Random.lean', [
('''`Σ_j Pr[s_j = x] = m · 2^{-n}` (`uprob_prod`, `uprob_eq_point`). -/''',
 '''`Σ_j Pr[s_j = x] = m · 2^{-n}` (`uprob_prod`, `uprob_eq_point`, `OneWay.uexp_const`). -/'''),
('''    intro j
    rw [uprob_prod]
    simp only [uprob_eq_point, uexp_def, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
    have : (0 : ℝ) < Fintype.card ((Fin m → Fin n → Bool) × ρ) := by
      exact_mod_cast Fintype.card_pos
    field_simp
''', '''    intro j
    rw [uprob_prod]
    simp only [uprob_eq_point, OneWay.uexp_const]
'''),
])
