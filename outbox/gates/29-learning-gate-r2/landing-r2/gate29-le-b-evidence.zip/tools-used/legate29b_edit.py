"""legate29b_edit.py <worktree>: LE-gate29b (G29-02), 2 exact replacements in Learning/Random.lean:
the proof of firstBit_of_pos from the published TCSlib.Cryptography.headD_drop_ofFn (#316), and one docstring sentence
inserted before the closing `-/` (pure insertion). The header is untouched."""
import sys
p = sys.argv[1] + '/TCSlib/Cryptography/Randomness/Learning/Random.lean'
E = [("`firstBit y = y ⟨0, hn⟩`. -/\ntheorem firstBit_of_pos",
      "`firstBit y = y ⟨0, hn⟩`.\nThis is the published `TCSlib.Cryptography.headD_drop_ofFn` at index `0`. -/\ntheorem firstBit_of_pos"),
     ("  obtain ⟨k, rfl⟩ : ∃ k, n = k + 1 := ⟨n - 1, by omega⟩\n  rw [firstBit_eq, List.ofFn_succ, List.headD_cons]\n  rfl\n",
      "  rw [firstBit_eq]\n  simpa only [List.drop_zero] using TCSlib.Cryptography.headD_drop_ofFn y ⟨0, hn⟩ false\n")]
s = open(p, encoding='utf-8').read()
for old, new in E:
    assert s.count(old) == 1, old
    s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
print('edited', p)
