# Verification attempt dispositions

The successful native source replay is in native/results.jsonl, with the first
Strings check in native/Strings-r1.log. It checks nine affected source modules
and the campaign Checks file. The retained imported objects come from the
verified #282 tree and their 1,146 source files match the current inputs.

The first telemetry wrapper returned one after its restricted sysctl failed.
Its Lean output and produced object were retained, and the module was checked
again through the ordinary checker with a successful exit. The numeric start
argument to the older ladder selected no module. Its empty replay log supplies
no successful checks. The maintained replay uses the explicit module order.

The first explicit-name classification probe used a reserved local name and
failed before classification. The corrected probe passes. Its final inventory
contains 1,031 explicit list items and all five List.cons_ne_nil argument uses.
All explicit definition heads resolve to definitions owned by the same file.
The remaining unresolved heads are tactic locals and a theorem projection.

The six failures in controls-sealed.log are the intended sensitivity outcomes.
The same six controls all pass in controls-unsealed.log.
