import Lean
import TCSlib.Cryptography.Games.Efficiency

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def inScope (owner : Name) (_name : Name) : Bool :=
  owner.toString == "TCSlib.Cryptography.Games.Efficiency" || owner.toString.startsWith "TCSlib.Cryptography.Games.Efficiency."

def home? (env : Environment) (n : Name) : Option Name := do
  let i ← env.getModuleIdxFor? n
  env.header.moduleNames[i.toNat]?

run_cmd do
  let env ← getEnv
  let mut count := 0
  let standard : List Name := [`propext, `Classical.choice, `Quot.sound]
  for (name, _) in env.constants.toList do
    let some owner := home? env name | continue
    unless inScope owner name do continue
    let axioms ← Lean.collectAxioms name
    unless axioms.all standard.contains do
      throwError "Unexpected axiom set for {name}: {axioms}"
    count := count + 1
    liftIO <| IO.println s!"AXIOMS {name}: {axioms}"
  liftIO <| IO.println s!"CENSUS {count} selected declarations use standard axioms only"
