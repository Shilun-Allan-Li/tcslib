/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Games.Efficiency.Strings
import TCSlib.Cryptography.Games.Simulate
/- G06-HARNESS INSTALL EfficiencySealHandler -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "EfficiencySealHandler"
  let payload : String := "Complexity.NUPPT.coinLen\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.inAdvice\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.inArg\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.inCoins\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.inParam\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.layout\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.output\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.runAt\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.runAtL\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.toCompOn\tTCSlib.Cryptography.Games.Machines\nComplexity.PolyTimeComputable\tTCSlib.Complexity.ClassNP.PolyTime\nComplexity.pairFstD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nComplexity.pairSndD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nTCSlib.Cryptography.Games.EffFill.RunsTo\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.actLoop\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.canonFun\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.canonWord\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.entryPoly\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.fixLen\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.selLen\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.MachineCodec.encodeLog\tTCSlib.Cryptography.Games.Machines\nTCSlib.Cryptography.Games.OracleComp.bind\tTCSlib.Cryptography.Games.OracleComp\nTCSlib.Cryptography.Games.bitCodec\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Games.buildComp\tTCSlib.Cryptography.Games.Machines\nTCSlib.Cryptography.Games.decodeBitMove\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Games.encodeBitMove\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Games.simulate\tTCSlib.Cryptography.Games.Simulate\nTCSlib.Cryptography.Games.zeroBits\tTCSlib.Cryptography.Games.BitCodec\nTuring.pairEncode\tTCSlib.Complexity.TuringMachine.Encoding"
  let expectedRequests : Nat := 29
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "Complexity.NUPPT.coinLen\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"coinLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inAdvice\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inAdvice\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inArg\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inArg\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inCoins\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inCoins\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inParam\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inParam\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.layout\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"layout\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.output\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"output\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.runAt\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"runAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.runAtL\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"runAtL\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.toCompOn\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"toCompOn\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nComplexity.PolyTimeComputable\t[[\"str\",\"Complexity\"],[\"str\",\"PolyTimeComputable\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTime\"]]\tfalse\tfalse\tfalse\nComplexity.pairFstD\t[[\"str\",\"Complexity\"],[\"str\",\"pairFstD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nComplexity.pairSndD\t[[\"str\",\"Complexity\"],[\"str\",\"pairSndD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.RunsTo\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"RunsTo\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.actLoop\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"actLoop\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.canonFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"canonFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.canonWord\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"canonWord\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.entryPoly\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"entryPoly\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.fixLen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"fixLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.selLen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"selLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.MachineCodec.encodeLog\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"MachineCodec\"],[\"str\",\"encodeLog\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.OracleComp.bind\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"],[\"str\",\"bind\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.bitCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"bitCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.buildComp\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"buildComp\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.decodeBitMove\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"decodeBitMove\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.encodeBitMove\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"encodeBitMove\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.simulate\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"simulate\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Simulate\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.zeroBits\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"zeroBits\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTuring.pairEncode\t[[\"str\",\"Turing\"],[\"str\",\"pairEncode\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"TuringMachine\"],[\"str\",\"Encoding\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The machine of a non-interactive handler (efficiency fill, T1)

The raw function behind `Games.exists_handlerMachine` (route note
`briefs/pass-shelat-ch5-8/design/S2b-efficiency.md`, §"T1"), stated over the raw ingredients of a
handler (its lengths and its three string functions) so that it does not depend on the handler
structure of `TCSlib.Cryptography.Games.Efficiency`.

On the raw layout `X = ⟨⟨⟨1^n, ⟨z, ω⟩⟩, ⟨α_A, s₀⟩⟩, r⟩` (`α_A` the adversary's advice, `s₀` the
initial state) the function is an activation loop (`EffFill.actLoop`) on the state
`⟨L, ⟨s, 1^t⟩⟩`: the adversary's encoded log, the handler's state and the number of answered
queries. One round runs the adversary on `⟨advIn ⟨1^n, ⟨z, ω⟩⟩, L⟩`, reads its move through the
canonical decoder, and either stops (an output, or a query when the budget `q(n)` is spent) with
`out ⟨⟨1^n, ⟨z, ω⟩⟩, ⟨s, a⟩⟩`, or answers the query with `run`, decoded componentwise with the
all-`false` default (`fixLen`), and appends the entry to the log.

## Main definitions

* `EffFill.hAct`, `EffFill.hStart`, `EffFill.hRaw`: the round, the initial state and the raw
  function; `EffFill.hRounds`, `EffFill.hBound`: the round and state bounds; `EffFill.hState`: the
  state.
* `EffFill.advNext`: the next-move function of a machine adversary on an input.

## Main results

* `EffFill.hRaw_poly`: the raw function is polynomial-time.
* `EffFill.hRaw_spec`: on the layout, it returns the finalized output of the simulation.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §2.1 (closure of p.p.t. machines under efficient operations; for example the reductions of the
  proofs of Theorems 135.4 and 168.2).
-/

namespace TCSlib.Cryptography.Games.EffFill

open Complexity Turing

variable {k : ℕ}

/-- The next-move function of the machine `A` on the input `x` with coins `r`: `A`'s output on
`⟨x, encoded log⟩`, decoded by the codec. -/
def advNext {ι α : Type} {spec : OracleSpec ι} (A : NUPPT) (codec : MachineCodec spec α) (n : ℕ)
    (x : List Bool) (r : A.Coins n) (hist : QueryLog spec) : Move spec α :=
  codec.decodeMove (A.runAt n (pairEncode x (codec.encodeLog hist)) r)

/-- `advNext A codec n x r hist = codec.decodeMove (A.runAt n ⟨x, codec.encodeLog hist⟩ r)`. -/
theorem advNext_eq {ι α : Type} {spec : OracleSpec ι} (A : NUPPT) (codec : MachineCodec spec α)
    (n : ℕ) (x : List Bool) (r : A.Coins n) (hist : QueryLog spec) :
    advNext A codec n x r hist = codec.decodeMove (A.runAt n (pairEncode x (codec.encodeLog hist))
        r) :=
  rfl

/-- `A`'s computation on the input `x` is `buildComp` of `advNext` (`NUPPT.toCompOn_eq`). -/
theorem toCompOn_eq_advNext {ι α : Type} {spec : OracleSpec ι} (A : NUPPT)
    (codec : MachineCodec spec α) (n q : ℕ) (x : List Bool) (r : A.Coins n) :
    A.toCompOn codec n q x r = buildComp (advNext A codec n x r) codec.timeout q [] := by
  rw [NUPPT.toCompOn_eq]
  rfl

section Raw

variable (A : NUPPT) (q dα : PolyExpr) (din dout : Fin k → PolyExpr) (stateLen : PolyExpr)
  (run advIn out : List Bool → List Bool)

/-- The context `⟨1^n, ⟨z, ω⟩⟩` read off the raw layout `X` (its parameter and argument). -/
def hCtx (X : List Bool) : List Bool := pairEncode (NUPPT.inParam X) (NUPPT.inArg X)

/-- `hCtx X = ⟨inParam X, inArg X⟩`. -/
theorem hCtx_eq (X : List Bool) : hCtx X = pairEncode (NUPPT.inParam X) (NUPPT.inArg X) := rfl

/-- The adversary's canonical move word in the round on `w = ⟨X, ⟨L, ⟨s, c⟩⟩⟩`. -/
def hMove (w : List Bool) : List Bool :=
  canonFun din (pairEncode (NUPPT.inParam (pairFstD w))
    (pairEncode (List.replicate (dα.eval (NUPPT.inParam (pairFstD w)).length) true)
      (A.output (NUPPT.layout (NUPPT.inParam (pairFstD w))
        (pairEncode (advIn (hCtx (pairFstD w))) (pairFstD (pairSndD w)))
        (pairFstD (NUPPT.inAdvice (pairFstD w))) (NUPPT.inCoins (pairFstD w))))))

/-- The defining equation of `hMove` (the canonical decoder of `A`'s output on
`⟨advIn ctx, L⟩`). -/
theorem hMove_eq (w : List Bool) :
    hMove A dα din advIn w =
      canonFun din (pairEncode (NUPPT.inParam (pairFstD w))
        (pairEncode (List.replicate (dα.eval (NUPPT.inParam (pairFstD w)).length) true)
          (A.output (NUPPT.layout (NUPPT.inParam (pairFstD w))
            (pairEncode (advIn (hCtx (pairFstD w))) (pairFstD (pairSndD w)))
            (pairFstD (NUPPT.inAdvice (pairFstD w))) (NUPPT.inCoins (pairFstD w)))))) :=
  rfl

/-- The handler's output `run ⟨ctx, ⟨s, ⟨1^i, x⟩⟩⟩` on the pending query of the round. -/
def hRes (w : List Bool) : List Bool :=
  run (pairEncode (hCtx (pairFstD w))
    (pairEncode (pairFstD (pairSndD (pairSndD w))) (pairSndD (hMove A dα din advIn w))))

/-- The defining equation of `hRes`. -/
theorem hRes_eq (w : List Bool) :
    hRes A dα din run advIn w =
      run (pairEncode (hCtx (pairFstD w))
        (pairEncode (pairFstD (pairSndD (pairSndD w))) (pairSndD (hMove A dα din advIn w)))) :=
  rfl

/-- The new state of a continuing round: the log with the answered entry appended, the new state
and the incremented counter. -/
def hNext (w : List Bool) : List Bool :=
  pairEncode
    (pairFstD (pairSndD w) ++ pairEncode (pairEncode (pairFstD (pairSndD (hMove A dα din advIn w)))
      (pairEncode (pairSndD (pairSndD (hMove A dα din advIn w)))
        (fixLen (selLen dout (NUPPT.inParam (pairFstD w)).length
          (pairFstD (pairSndD (hMove A dα din advIn w))).length)
          (pairFstD (hRes A dα din run advIn w))))) [])
    (pairEncode (fixLen (stateLen.eval (NUPPT.inParam (pairFstD w)).length)
      (pairSndD (hRes A dα din run advIn w))) (true :: pairSndD (pairSndD (pairSndD w))))

/-- The defining equation of `hNext`. -/
theorem hNext_eq (w : List Bool) :
    hNext A dα din dout stateLen run advIn w =
      pairEncode
        (pairFstD (pairSndD w) ++ pairEncode (pairEncode (pairFstD (pairSndD (hMove A dα din advIn
            w)))
          (pairEncode (pairSndD (pairSndD (hMove A dα din advIn w)))
            (fixLen (selLen dout (NUPPT.inParam (pairFstD w)).length
              (pairFstD (pairSndD (hMove A dα din advIn w))).length)
              (pairFstD (hRes A dα din run advIn w))))) [])
        (pairEncode (fixLen (stateLen.eval (NUPPT.inParam (pairFstD w)).length)
          (pairSndD (hRes A dα din run advIn w))) (true :: pairSndD (pairSndD (pairSndD w)))) :=
  rfl

/-- **One round of the handler machine** on `w = ⟨X, ⟨L, ⟨s, c⟩⟩⟩`: stop with
`out ⟨ctx, ⟨s, a⟩⟩` on an output `a`; stop with `out ⟨ctx, ⟨s, 0^{dα(n)}⟩⟩` on a query when
`q(n) ≤ |c|`; otherwise continue with `hNext`. -/
def hAct (w : List Bool) : List Bool :=
  if pairFstD (hMove A dα din advIn w) = [true] then
    pairEncode [true] (out (pairEncode (hCtx (pairFstD w))
      (pairEncode (pairFstD (pairSndD (pairSndD w))) (pairSndD (hMove A dα din advIn w)))))
  else if q.eval (NUPPT.inParam (pairFstD w)).length ≤ (pairSndD (pairSndD (pairSndD w))).length
      then
    pairEncode [true] (out (pairEncode (hCtx (pairFstD w))
      (pairEncode (pairFstD (pairSndD (pairSndD w)))
        (List.replicate (dα.eval (NUPPT.inParam (pairFstD w)).length) false))))
  else pairEncode [false] (hNext A dα din dout stateLen run advIn w)

/-- The defining equation of `hAct`. -/
theorem hAct_eq (w : List Bool) :
    hAct A q dα din dout stateLen run advIn out w =
      if pairFstD (hMove A dα din advIn w) = [true] then
        pairEncode [true] (out (pairEncode (hCtx (pairFstD w))
          (pairEncode (pairFstD (pairSndD (pairSndD w))) (pairSndD (hMove A dα din advIn w)))))
      else if q.eval (NUPPT.inParam (pairFstD w)).length ≤
          (pairSndD (pairSndD (pairSndD w))).length then
        pairEncode [true] (out (pairEncode (hCtx (pairFstD w))
          (pairEncode (pairFstD (pairSndD (pairSndD w)))
            (List.replicate (dα.eval (NUPPT.inParam (pairFstD w)).length) false))))
      else pairEncode [false] (hNext A dα din dout stateLen run advIn w) :=
  rfl

/-- The initial state `⟨[], ⟨s₀, []⟩⟩`, with the initial state `s₀` read off the advice. -/
def hStart (X : List Bool) : List Bool :=
  pairEncode [] (pairEncode (pairSndD (NUPPT.inAdvice X)) [])

/-- `hStart X = ⟨[], ⟨snd (inAdvice X), []⟩⟩`. -/
theorem hStart_eq (X : List Bool) :
    hStart X = pairEncode [] (pairEncode (pairSndD (NUPPT.inAdvice X)) []) := rfl

/-- The round bound `q + 1`: at most `q(n)` answered queries and one stopping round. -/
def hRounds : PolyExpr := .add q (.const 1)

/-- `hRounds q = q + 1`. -/
theorem hRounds_eq : hRounds q = .add q (.const 1) := rfl

/-- The state bound `2 q E + 2 stateLen + q + 4` (`E` the entry bound `entryPoly`). -/
def hBound : PolyExpr :=
  .add (.mul (.const 2) (.mul q (entryPoly din dout))) (.add (.mul (.const 2) stateLen) (.add q
      (.const 4)))

/-- The defining equation of `hBound`. -/
theorem hBound_eq : hBound q din dout stateLen =
    .add (.mul (.const 2) (.mul q (entryPoly din dout))) (.add (.mul (.const 2) stateLen) (.add q
        (.const 4))) :=
  rfl

/-- **The raw function of the handler machine:** the activation loop of `hAct` from `hStart`, with
`q + 1` rounds and the state bound `hBound`. -/
def hRaw : List Bool → List Bool :=
  actLoop hStart (hAct A q dα din dout stateLen run advIn out) (hRounds q) (hBound q din dout
      stateLen)

/-- `hRaw = actLoop hStart hAct (q + 1) hBound`. -/
theorem hRaw_eq : hRaw A q dα din dout stateLen run advIn out =
    actLoop hStart (hAct A q dα din dout stateLen run advIn out) (hRounds q)
      (hBound q din dout stateLen) :=
  rfl

/-! ### Polynomial time -/

variable {run advIn out}

/-- The context is polynomial-time. -/
theorem hCtx_poly : PolyTimeComputable hCtx :=
  NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inArg

/-- The round's move is polynomial-time. -/
theorem hMove_poly (hadvIn : PolyTimeComputable advIn) : PolyTimeComputable (hMove A dα din advIn)
    := by
  have hX := polyTimeComputable_pairFstD
  have hu := NUPPT.polyTimeComputable_inParam.comp' hX
  have hout := A.polyTimeComputable_output.comp' (NUPPT.polyTimeComputable_layout hu
    ((hadvIn.comp' (hCtx_poly.comp' hX)).pairEncode
      (polyTimeComputable_pairFstD.comp' polyTimeComputable_pairSndD))
    (polyTimeComputable_pairFstD.comp' (NUPPT.polyTimeComputable_inAdvice.comp' hX))
    (NUPPT.polyTimeComputable_inCoins.comp' hX))
  exact (canonFun_poly din).comp' (hu.pairEncode ((StateLoop.unaryPoly_comp dα hu).pairEncode hout))

/-- The handler's output on the pending query is polynomial-time. -/
theorem hRes_poly (hrun : PolyTimeComputable run) (hadvIn : PolyTimeComputable advIn) :
    PolyTimeComputable (hRes A dα din run advIn) :=
  hrun.comp' ((hCtx_poly.comp' polyTimeComputable_pairFstD).pairEncode
    ((polyTimeComputable_pairFstD.comp' (polyTimeComputable_pairSndD.comp'
      polyTimeComputable_pairSndD)).pairEncode
      (polyTimeComputable_pairSndD.comp' (hMove_poly A dα din hadvIn))))

/-- The continuing state is polynomial-time. -/
theorem hNext_poly (hrun : PolyTimeComputable run) (hadvIn : PolyTimeComputable advIn) :
    PolyTimeComputable (hNext A dα din dout stateLen run advIn) := by
  have hX := polyTimeComputable_pairFstD
  have hu := NUPPT.polyTimeComputable_inParam.comp' hX
  have hm := hMove_poly A dα din hadvIn
  have hq := polyTimeComputable_pairSndD.comp' hm
  have hres := hRes_poly A dα din hrun hadvIn
  have hy := fixLen_poly ((selLen_poly dout).comp' (hu.pairEncode (polyTimeComputable_pairFstD.comp'
      hq)))
    (polyTimeComputable_pairFstD.comp' hres)
  have hs := fixLen_poly (StateLoop.unaryPoly_comp stateLen hu) (polyTimeComputable_pairSndD.comp'
      hres)
  have h := ((polyTimeComputable_pairFstD.comp' polyTimeComputable_pairSndD).append
    (((polyTimeComputable_pairFstD.comp' hq).pairEncode
      ((polyTimeComputable_pairSndD.comp' hq).pairEncode hy)).pairEncode
        (polyTimeComputable_const []))).pairEncode
    (hs.pairEncode ((StateLoop.cons_poly true).comp' (polyTimeComputable_pairSndD.comp'
      (polyTimeComputable_pairSndD.comp' polyTimeComputable_pairSndD))))
  refine h.congr fun w => ?_
  rw [hNext_eq]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode, List.length_replicate]

/-- **One round of the handler machine is polynomial-time.** -/
theorem hAct_poly (hrun : PolyTimeComputable run) (hadvIn : PolyTimeComputable advIn)
    (hout : PolyTimeComputable out) : PolyTimeComputable (hAct A q dα din dout stateLen run advIn
        out) := by
  have hX := polyTimeComputable_pairFstD
  have hu := NUPPT.polyTimeComputable_inParam.comp' hX
  have hm := hMove_poly A dα din hadvIn
  have hctx := hCtx_poly.comp' hX
  have hst := polyTimeComputable_pairFstD.comp' (polyTimeComputable_pairSndD.comp'
    polyTimeComputable_pairSndD)
  have hc := polyTimeComputable_pairSndD.comp' (polyTimeComputable_pairSndD.comp'
    polyTimeComputable_pairSndD)
  have h1 := eq_poly (polyTimeComputable_pairFstD.comp' hm) (polyTimeComputable_const [true])
  have h2 := StateLoop.lenLe_comp hc (StateLoop.unaryPoly_comp q hu)
  have hz : PolyTimeComputable fun w =>
      List.replicate (dα.eval (NUPPT.inParam (pairFstD w)).length) false :=
    (zeros_poly (StateLoop.unaryPoly_comp dα hu)).congr fun w => by rw [List.length_replicate]
  have h := polyTimeComputable_ite h1
    ((polyTimeComputable_const [true]).pairEncode (hout.comp' (hctx.pairEncode
      (hst.pairEncode (polyTimeComputable_pairSndD.comp' hm)))))
    (polyTimeComputable_ite h2
      ((polyTimeComputable_const [true]).pairEncode (hout.comp' (hctx.pairEncode (hst.pairEncode
          hz))))
      ((polyTimeComputable_const [false]).pairEncode (hNext_poly A dα din dout stateLen hrun
          hadvIn)))
  refine h.congr fun w => ?_
  rw [hAct_eq]
  simp only [List.length_replicate, decide_eq_true_eq]

/-- **The raw function of the handler machine is polynomial-time** (`actLoop_poly`). -/
theorem hRaw_poly (hrun : PolyTimeComputable run) (hadvIn : PolyTimeComputable advIn)
    (hout : PolyTimeComputable out) : PolyTimeComputable (hRaw A q dα din dout stateLen run advIn
        out) :=
  actLoop_poly ((polyTimeComputable_const []).pairEncode
      ((polyTimeComputable_pairSndD.comp' NUPPT.polyTimeComputable_inAdvice).pairEncode
        (polyTimeComputable_const [])))
    (hAct_poly A q dα din dout stateLen hrun hadvIn hout) _ _

end Raw

/-! ### The functional equation -/

section Spec

variable (A : NUPPT) (q dα : PolyExpr) (din dout : Fin k → PolyExpr) (stateLen : PolyExpr)
  (run advIn out : List Bool → List Bool)

/-- The state `⟨L, ⟨s, 1^t⟩⟩` of the handler machine: the encoded log, the handler's state and
the number `t` of answered queries. -/
def hState (L s : List Bool) (t : ℕ) : List Bool :=
  pairEncode L (pairEncode s (List.replicate t true))

/-- `hState L s t = ⟨L, ⟨s, 1^t⟩⟩`. -/
theorem hState_eq (L s : List Bool) (t : ℕ) :
    hState L s t = pairEncode L (pairEncode s (List.replicate t true)) :=
  rfl

/-- The move word of a round on the state `⟨L, ⟨s, 1^t⟩⟩` at parameter `n`: the canonical decoder
of `A`'s output on `⟨advIn ctx, L⟩` with the advice and coins of the layout. -/
theorem hMove_state {X : List Bool} {n : ℕ} (hXu : NUPPT.inParam X = List.replicate n true)
    (L s : List Bool) (t : ℕ) :
    hMove A dα din advIn (pairEncode X (hState L s t)) =
      canonWord din n (dα.eval n) (A.output (NUPPT.layout (List.replicate n true)
        (pairEncode (advIn (hCtx X)) L) (pairFstD (NUPPT.inAdvice X)) (NUPPT.inCoins X))) := by
  rw [hMove_eq, hState_eq]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode, hXu, List.length_replicate]
  exact canonFun_eq din n (dα.eval n) _

/-- **A round on an output stops:** if the move word is `⟨[true], a⟩`, the round stops with
`out ⟨ctx, ⟨s, a⟩⟩`. -/
theorem hAct_of_ret {X : List Bool} {L s a : List Bool} {t : ℕ}
    (hm : hMove A dα din advIn (pairEncode X (hState L s t)) = pairEncode [true] a) :
    hAct A q dα din dout stateLen run advIn out (pairEncode X (hState L s t)) =
      pairEncode [true] (out (pairEncode (hCtx X) (pairEncode s a))) := by
  rw [hAct_eq, hm, if_pos (pairFstD_pairEncode _ _)]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode, hState_eq]

/-- **A query with the budget spent stops:** if the move word is a query `⟨[false], m⟩` and
`q(n) ≤ t`, the round stops with `out ⟨ctx, ⟨s, 0^{dα(n)}⟩⟩`. -/
theorem hAct_of_timeout {X : List Bool} {n : ℕ} (hXu : NUPPT.inParam X = List.replicate n true)
    {L s m : List Bool} {t : ℕ}
    (hm : hMove A dα din advIn (pairEncode X (hState L s t)) = pairEncode [false] m)
    (ht : q.eval n ≤ t) :
    hAct A q dα din dout stateLen run advIn out (pairEncode X (hState L s t)) =
      pairEncode [true] (out (pairEncode (hCtx X) (pairEncode s
        (List.replicate (dα.eval n) false)))) := by
  have hne : pairFstD (pairEncode [false] m) ≠ [true] := by
    rw [pairFstD_pairEncode]
    decide
  rw [hAct_eq, hm, if_neg hne]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode, hState_eq, hXu, List.length_replicate]
  rw [if_pos ht]

/-- **A query within budget continues:** if the move word is the query `⟨[false], ⟨iw, xw⟩⟩` and
`t < q(n)`, the round continues with the entry `⟨iw, ⟨xw, y⟩⟩` appended to the log, the new state
`s'` and `t + 1`, where `y` and `s'` are `run ⟨ctx, ⟨s, ⟨iw, xw⟩⟩⟩` decoded componentwise. -/
theorem hAct_of_query {X : List Bool} {n : ℕ} (hXu : NUPPT.inParam X = List.replicate n true)
    {L s iw xw : List Bool} {t : ℕ}
    (hm : hMove A dα din advIn (pairEncode X (hState L s t)) =
      pairEncode [false] (pairEncode iw xw))
    (ht : t < q.eval n) :
    hAct A q dα din dout stateLen run advIn out (pairEncode X (hState L s t)) =
      pairEncode [false] (hState
        (L ++ pairEncode (pairEncode iw (pairEncode xw (fixLen (selLen dout n iw.length)
          (pairFstD (run (pairEncode (hCtx X) (pairEncode s (pairEncode iw xw)))))))) [])
        (fixLen (stateLen.eval n) (pairSndD (run (pairEncode (hCtx X) (pairEncode s
          (pairEncode iw xw)))))) (t + 1)) := by
  have hne : pairFstD (pairEncode [false] (pairEncode iw xw)) ≠ [true] := by
    rw [pairFstD_pairEncode]
    decide
  rw [hAct_eq, hm, if_neg hne, hNext_eq, hRes_eq, hm]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode, hState_eq, hXu, List.length_replicate]
  rw [if_neg (Nat.not_le.2 ht), List.replicate_succ]

/-- **The functional equation of the handler machine.** At parameter `n`, on the layout
`X = ⟨⟨⟨1^n, ⟨z, ω⟩⟩, ⟨α_A, s₀⟩⟩, r⟩` with `α_A = A.advice n`, for any answer function `ans`
that agrees with `run` decoded componentwise (`fixLen`), the simulation of `A` on
`advIn ⟨1^n, ⟨z, ω⟩⟩` with the stateless answers `ans` from `s₀` returns some `(a, s)`, and the
raw function returns `out ⟨⟨1^n, ⟨z, ω⟩⟩, ⟨s, a⟩⟩`.

**Proof sketch.** By induction on the remaining budget `b`, from the round `t = q(n) − b` whose
state is `⟨encodeLog hist, ⟨s, 1^t⟩⟩` (`RunsTo`). The round's move word is the canonical word of
`A`'s next move (`hMove_state`, `canonWord_eq`, `NUPPT.runAtL_eq_output_layout`). On an output `a`
the round stops with `out ⟨ctx, ⟨s, a⟩⟩` (`hAct_of_ret`) and `buildComp` returns `a`
(`buildComp_zero_of_ret`, `buildComp_succ_of_ret`, `simulate_pure`). On a query with `b = 0` it
stops with the all-`false` output (`hAct_of_timeout`), as `buildComp_zero_of_query` does. On a
query with `b > 0` the round continues (`hAct_of_query`) with the answered entry appended
(`encodeLog_append_single`, `bitCodec_encodeEntry`) and the new state, which is the state of
`simulate` after `buildComp_succ_of_query`, `simulate_query` and `pure_bind`. The states stay
within `hBound` (`length_encodeLog_le`, `entry_le_entryPoly`, `PolyExpr.eval_mono`), and the
stopping
round is at most `q(n) ≤ (q + 1)(|X|)`; `runsTo_stop` evaluates the loop. -/
theorem hRaw_spec {ι' : Type} {spec' : OracleSpec ι'} (n : ℕ) (z ω : List Bool) (r : A.Coins n)
    (init : Fin (stateLen.eval n) → Bool)
    (ans : ∀ i : Fin k, (Fin ((din i).eval n) → Bool) → (Fin (stateLen.eval n) → Bool) →
      (Fin ((dout i).eval n) → Bool) × (Fin (stateLen.eval n) → Bool))
    (hans : ∀ i x s,
      List.ofFn (ans i x s).1 = fixLen ((dout i).eval n) (pairFstD (run (pairEncode
        (pairEncode (List.replicate n true) (pairEncode z ω))
        (pairEncode (List.ofFn s) (pairEncode (List.replicate i true) (List.ofFn x)))))) ∧
      List.ofFn (ans i x s).2 = fixLen (stateLen.eval n) (pairSndD (run (pairEncode
        (pairEncode (List.replicate n true) (pairEncode z ω))
        (pairEncode (List.ofFn s) (pairEncode (List.replicate i true) (List.ofFn x))))))) :
    ∃ (a : Fin (dα.eval n) → Bool) (s : Fin (stateLen.eval n) → Bool),
      simulate (spec' := spec') (fun i x s => OracleComp.pure (ans i x s))
          (A.toCompOn (bitCodec (fun i => (din i).eval n) (fun i => (dout i).eval n) (dα.eval n))
            n (q.eval n) (advIn (pairEncode (List.replicate n true) (pairEncode z ω))) r) init =
        .pure (a, s) ∧
      hRaw A q dα din dout stateLen run advIn out
          (NUPPT.layout (List.replicate n true) (pairEncode z ω)
            (pairEncode (A.advice n) (List.ofFn init)) (List.ofFn r)) =
        out (pairEncode (pairEncode (List.replicate n true) (pairEncode z ω))
          (pairEncode (List.ofFn s) (List.ofFn a))) := by
  -- The fixed data of the run.
  set X := NUPPT.layout (List.replicate n true) (pairEncode z ω)
    (pairEncode (A.advice n) (List.ofFn init)) (List.ofFn r) with hX
  set ctx := pairEncode (List.replicate n true) (pairEncode z ω) with hctx
  set codec := bitCodec (fun i => (din i).eval n) (fun i => (dout i).eval n) (dα.eval n)
    with hcodec
  have hnX : n ≤ X.length := le_length_layout n _ _ _
  have hXu : NUPPT.inParam X = List.replicate n true := NUPPT.inParam_layout _ _ _ _
  have hXctx : hCtx X = ctx := by rw [hCtx_eq, hXu, hX, NUPPT.inArg_layout]
  -- The move word of a round is the canonical word of `A`'s next move.
  have hmove : ∀ (hist : QueryLog (bitSpec (fun i => (din i).eval n) (fun i => (dout i).eval n)))
      (s : Fin (stateLen.eval n) → Bool) (t : ℕ), hMove A dα din advIn
      (pairEncode X (hState (codec.encodeLog hist) (List.ofFn s) t)) =
      encodeBitMove (fun i => (din i).eval n) (fun i => (dout i).eval n) (dα.eval n)
        (advNext A codec n (advIn ctx) r hist) := by
    intro hist s t
    rw [hMove_state A dα din advIn hXu, hXctx, hX, NUPPT.inAdvice_layout, NUPPT.inCoins_layout,
      pairFstD_pairEncode, ← NUPPT.runAtL_eq_output_layout, ← NUPPT.runAt_eq,
      canonWord_eq din (fun i => (dout i).eval n), advNext_eq, hcodec, bitCodec_decodeMove]
  -- The state bound.
  have hbound : ∀ (hist : QueryLog (bitSpec (fun i => (din i).eval n) (fun i => (dout i).eval n)))
      (s : Fin (stateLen.eval n) → Bool) (t : ℕ), hist.length = t → t ≤ q.eval n →
      (hState (codec.encodeLog hist) (List.ofFn s) t).length ≤
        (hBound q din dout stateLen).eval X.length := by
    intro hist s t hlen ht
    have hlog := length_encodeLog_le codec ((entryPoly din dout).eval n) hist
      (fun e _ => entry_le_entryPoly din dout n e (dα.eval n))
    refine le_trans ?_ ((hBound q din dout stateLen).eval_mono hnX)
    rw [hState_eq, length_pairEncode, length_pairEncode, List.length_ofFn, List.length_replicate,
      hBound_eq]
    simp only [PolyExpr.eval_add, PolyExpr.eval_mul, PolyExpr.eval_const]
    rw [hlen] at hlog
    have : t * (entryPoly din dout).eval n ≤ q.eval n * (entryPoly din dout).eval n :=
      Nat.mul_le_mul_right _ ht
    omega
  have hR : ∀ t, t ≤ q.eval n → t ≤ (hRounds q).eval X.length := by
    intro t ht
    rw [hRounds_eq, PolyExpr.eval_add, PolyExpr.eval_const]
    have := q.eval_mono hnX
    omega
  -- The induction on the remaining budget.
  have key : ∀ b hist (s : Fin (stateLen.eval n) → Bool) t, t + b = q.eval n →
      hist.length = t →
      RunsTo hStart (hAct A q dα din dout stateLen run advIn out) (hBound q din dout stateLen) X t
        (hState (codec.encodeLog hist) (List.ofFn s) t) →
      ∃ (a : Fin (dα.eval n) → Bool) (s' : Fin (stateLen.eval n) → Bool),
        simulate (spec' := spec') (fun i x s => OracleComp.pure (ans i x s))
            (buildComp (advNext A codec n (advIn ctx) r) codec.timeout b hist) s = .pure (a, s') ∧
        hRaw A q dα din dout stateLen run advIn out X =
          out (pairEncode ctx (pairEncode (List.ofFn s') (List.ofFn a))) := by
    intro b
    induction b with
    | zero =>
      intro hist s t ht hlen hrun
      cases hm : advNext A codec n (advIn ctx) r hist with
      | ret a =>
        refine ⟨a, s, by rw [buildComp_zero_of_ret hm, simulate_pure], ?_⟩
        refine runsTo_stop hrun ?_ (hR t (by omega))
        rw [hAct_of_ret A q dα din dout stateLen run advIn out
          (by rw [hmove, hm, encodeBitMove_ret]), hXctx]
      | query i x =>
        refine ⟨zeroBits _, s, ?_, ?_⟩
        · rw [buildComp_zero_of_query hm, simulate_pure, hcodec, bitCodec_timeout]
        · refine runsTo_stop hrun ?_ (hR t (by omega))
          rw [hAct_of_timeout A q dα din dout stateLen run advIn out hXu
            (by rw [hmove, hm, encodeBitMove_query]) (by omega), hXctx, ofFn_zeroBits]
    | succ b ih =>
      intro hist s t ht hlen hrun
      cases hm : advNext A codec n (advIn ctx) r hist with
      | ret a =>
        refine ⟨a, s, by rw [buildComp_succ_of_ret hm, simulate_pure], ?_⟩
        refine runsTo_stop hrun ?_ (hR t (by omega))
        rw [hAct_of_ret A q dα din dout stateLen run advIn out
          (by rw [hmove, hm, encodeBitMove_ret]), hXctx]
      | query i x =>
        have hlen' : (hist ++ [(⟨i, x, (ans i x s).1⟩ : Σ i, (bitSpec (fun i => (din i).eval n)
            (fun i => (dout i).eval n)).dom i × (bitSpec (fun i => (din i).eval n)
            (fun i => (dout i).eval n)).rng i)]).length = t + 1 := by
          rw [List.length_append, hlen, List.length_singleton]
        have hnext : hAct A q dα din dout stateLen run advIn out
            (pairEncode X (hState (codec.encodeLog hist) (List.ofFn s) t)) =
            pairEncode [false] (hState (codec.encodeLog (hist ++ [⟨i, x, (ans i x s).1⟩]))
              (List.ofFn (ans i x s).2) (t + 1)) := by
          rw [hAct_of_query A q dα din dout stateLen run advIn out hXu
            (by rw [hmove, hm, encodeBitMove_query]) (by omega), hXctx, List.length_replicate,
            selLen_eq, ← (hans i x s).1, ← (hans i x s).2, encodeLog_append_single, hcodec,
            bitCodec_encodeEntry]
        obtain ⟨a, s', hsim, hraw⟩ := ih (hist ++ [⟨i, x, (ans i x s).1⟩]) (ans i x s).2 (t + 1)
          (by omega) hlen' (runsTo_succ hrun hnext (hbound _ _ _ hlen' (by omega)))
        refine ⟨a, s', ?_, hraw⟩
        rw [buildComp_succ_of_query hm, simulate_query, OracleComp.pure_bind]
        exact hsim
  have hstart : hStart X = hState (codec.encodeLog []) (List.ofFn init) 0 := by
    rw [hStart_eq, hX, NUPPT.inAdvice_layout, pairSndD_pairEncode, hState_eq,
      MachineCodec.encodeLog_nil, List.replicate_zero]
  have h0 : RunsTo hStart (hAct A q dα din dout stateLen run advIn out) (hBound q din dout stateLen)
      X 0 (hState (codec.encodeLog []) (List.ofFn init) 0) := by
    rw [← hstart]
    exact runsTo_zero (by rw [hstart]; exact hbound [] init 0 rfl (Nat.zero_le _))
  obtain ⟨a, s, hsim, hraw⟩ := key (q.eval n) [] init 0 (Nat.zero_add _) rfl h0
  refine ⟨a, s, ?_, hraw⟩
  rw [toCompOn_eq_advNext]
  exact hsim

end Spec

end TCSlib.Cryptography.Games.EffFill
/- G06-HARNESS EOF-VERIFY EfficiencySealHandler -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "EfficiencySealHandler"
  let payload : String := "Complexity.NUPPT.coinLen\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.inAdvice\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.inArg\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.inCoins\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.inParam\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.layout\tTCSlib.Complexity.Randomized.Closure\nComplexity.NUPPT.output\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.runAt\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.runAtL\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.toCompOn\tTCSlib.Cryptography.Games.Machines\nComplexity.PolyTimeComputable\tTCSlib.Complexity.ClassNP.PolyTime\nComplexity.pairFstD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nComplexity.pairSndD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nTCSlib.Cryptography.Games.EffFill.RunsTo\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.actLoop\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.canonFun\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.canonWord\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.entryPoly\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.fixLen\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.EffFill.selLen\tTCSlib.Cryptography.Games.Efficiency.Strings\nTCSlib.Cryptography.Games.MachineCodec.encodeLog\tTCSlib.Cryptography.Games.Machines\nTCSlib.Cryptography.Games.OracleComp.bind\tTCSlib.Cryptography.Games.OracleComp\nTCSlib.Cryptography.Games.bitCodec\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Games.buildComp\tTCSlib.Cryptography.Games.Machines\nTCSlib.Cryptography.Games.decodeBitMove\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Games.encodeBitMove\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Games.simulate\tTCSlib.Cryptography.Games.Simulate\nTCSlib.Cryptography.Games.zeroBits\tTCSlib.Cryptography.Games.BitCodec\nTuring.pairEncode\tTCSlib.Complexity.TuringMachine.Encoding"
  let expectedRequests : Nat := 29
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "Complexity.NUPPT.coinLen\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"coinLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inAdvice\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inAdvice\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inArg\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inArg\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inCoins\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inCoins\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.inParam\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"inParam\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.layout\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"layout\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"Closure\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.output\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"output\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.runAt\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"runAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.runAtL\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"runAtL\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.toCompOn\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"toCompOn\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nComplexity.PolyTimeComputable\t[[\"str\",\"Complexity\"],[\"str\",\"PolyTimeComputable\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTime\"]]\tfalse\tfalse\tfalse\nComplexity.pairFstD\t[[\"str\",\"Complexity\"],[\"str\",\"pairFstD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nComplexity.pairSndD\t[[\"str\",\"Complexity\"],[\"str\",\"pairSndD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.RunsTo\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"RunsTo\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.actLoop\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"actLoop\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.canonFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"canonFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.canonWord\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"canonWord\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.entryPoly\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"entryPoly\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.fixLen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"fixLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.EffFill.selLen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"EffFill\"],[\"str\",\"selLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Efficiency\"],[\"str\",\"Strings\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.MachineCodec.encodeLog\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"MachineCodec\"],[\"str\",\"encodeLog\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.OracleComp.bind\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"],[\"str\",\"bind\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.bitCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"bitCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.buildComp\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"buildComp\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.decodeBitMove\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"decodeBitMove\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.encodeBitMove\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"encodeBitMove\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.simulate\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"simulate\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Simulate\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.zeroBits\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"zeroBits\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTuring.pairEncode\t[[\"str\",\"Turing\"],[\"str\",\"pairEncode\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"TuringMachine\"],[\"str\",\"Encoding\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

