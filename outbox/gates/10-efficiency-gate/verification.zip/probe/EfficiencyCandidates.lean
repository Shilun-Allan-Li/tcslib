import Lean
import TCSlib.Cryptography.Games.Efficiency

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def inScope (owner : Name) (_name : Name) : Bool :=
  owner.toString == "TCSlib.Cryptography.Games.Efficiency" || owner.toString.startsWith "TCSlib.Cryptography.Games.Efficiency."

def home? (env : Environment) (n : Name) : Option Name := do
  let i ← env.getModuleIdxFor? n
  env.header.moduleNames[i.toNat]?

def nameParts : Name → List (String × String)
  | .anonymous => []
  | .str p s => nameParts p ++ [("str", s)]
  | .num p n => nameParts p ++ [("num", toString n)]

run_cmd do
  let env ← getEnv
  let mut refs : Std.HashMap (Name × Name) Json := {}
  let mut count := 0
  for (name, c) in env.constants.toList do
    let some owner := home? env name | continue
    unless inScope owner name do continue
    count := count + 1
    for d in c.getUsedConstantsAsSet do
      let some other := home? env d | continue
      unless other != owner && other.toString.startsWith "TCSlib." do continue
      let some ci := env.find? d | continue
      unless ci.isDefinition do continue
      let status := Lean.getReducibilityStatusCore env d
      let isInst := Lean.Meta.isInstanceCore env d
      let matcher := Lean.Meta.isMatcherCore env d
      let abbrevFlag := match ci with
        | .defnInfo d => match d.hints with | .abbrev => true | _ => false
        | _ => false
      refs := refs.insert (owner, d) <| Json.mkObj [
        ("owner", toJson owner.toString), ("name", toJson d.toString), ("home", toJson other.toString),
        ("name_components", toJson (nameParts d)), ("home_components", toJson (nameParts other)),
        ("status", toJson status.toAttrString), ("instance", toJson isInst), ("matcher", toJson matcher),
        ("abbrev", toJson abbrevFlag)]
  for (_, row) in refs.toArray do liftIO <| IO.println ("SEAL_CAND " ++ row.compress)
  liftIO <| IO.println s!"CENSUS {count} selected declarations, {refs.size} external definitions"
