from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys
import time

area=Path(__file__).resolve().parent
plan=json.loads((area/"native/PLAN.json").read_text())
repo=Path(plan["worktree"])
tree=area/"oleans"
logdir=area/"native/logs"
logdir.mkdir(exist_ok=True)
env=os.environ.copy()
for name in ("LEAN_SYSROOT","LEAN_SRC_PATH","LEAN_OPTS"):
    env.pop(name,None)
env["PATH"]="/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:"+env["PATH"]
env["TCSLIB_OLEANS"]=str(tree)
modules=(area/"native/order.txt").read_text().splitlines()[1:]
modules.append("audits/pass-shelat/Checks")
for module in modules:
    source=repo/(module+".lean")
    expected=plan["source_digests"].get(module)
    if expected:
        assert sha256(source.read_bytes()).hexdigest()==expected,module
    log=logdir/(module.replace("/","_")+".log")
    start=time.monotonic()
    with log.open("w") as f:
        proc=subprocess.run(["/bin/bash","scripts/lean_check_tree.sh",module],
                            cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=log.read_text()
    obj=tree/(module+".olean")
    row={"module":module,"rc":proc.returncode,"seconds":round(time.monotonic()-start,3),
         "source_sha256":sha256(source.read_bytes()).hexdigest(),"log":str(log),
         "log_sha256":sha256(log.read_bytes()).hexdigest(),
         "olean_sha256":sha256(obj.read_bytes()).hexdigest() if obj.is_file() else None,
         "sorry_warnings":raw.count("declaration uses 'sorry'")}
    with (area/"native/results.jsonl").open("a") as f:
        f.write(json.dumps(row)+"\n")
    print(module,proc.returncode,row["seconds"],flush=True)
    if proc.returncode or "error:" in raw or not obj.is_file():
        print(raw,flush=True)
        sys.exit(1)
