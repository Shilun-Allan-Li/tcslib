"""pack3435.py <repo> <34|35> <out-dir>: Gate 34 (#318, sc-ot) and Gate 35 (#319, canonizer) re-checks from git
objects only (no Lean). The Gate 33 method (g33/checks/pack33.py) for these units. Writes mergetrees.txt,
downstream.txt, headers.txt, lecheck.txt, rebase.txt, srcequality.txt and namecheck.txt; for Gate 35 also
readers.txt, whitespace.txt and deptrace.txt."""
import hashlib, io, json, os, re, subprocess, sys, zipfile
repo, gate, out = sys.argv[1], sys.argv[2], sys.argv[3]


def git(*a, check=True):
    return subprocess.run(['git', '-C', repo, *a], check=check, capture_output=True, text=True)


def gitb(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


rp = lambda r: git('rev-parse', r).stdout.strip()
B = 'briefs/pass-shelat-ch5-8'
TIPREF = 'origin/cryptography/pass-shelat-ch2-4'
TIP = rp(TIPREF)
ISSUE = rp('107f1e8c218733eac12d6b9bee6fece441271317')
SCOT, CANON = rp('f62a25b3eda099c9cf9371900664752e7b89007d'), rp('6421ac1631ef08feed297c810f0839b178d2a2bb')
OT = 'TCSlib/Cryptography/SecureComputation/ObliviousTransfer'
UV = 'TCSlib/Cryptography/Asymptotic/Universal'
TM = 'TCSlib/Complexity/TuringMachine'
CFG = {
    '34': dict(name='sc-ot', pr=318, head=SCOT, wk=rp('b2e817cae4737dbcbeaf4171c9598b3e2b21fd57'),
               ledoc=rp('7a1fa29bae093192e21344fb9110d8a087d0a123'), lereuse=SCOT,
               r1=(rp('0e5e725dc80c94575ea27b863399ff1119926c96'), rp('fb6075d8a2be07e4adedb2efc245fbec899adce0')),
               exch=rp('a8972fa063a58ad2ffbfd221d625653d34a53ee8'), other=('#319', CANON),
               owned=[f'{OT}.lean'],
               unit=[f'{OT}.lean'] + [f'{OT}/{x}.lean' for x in
                                      ('Shape', 'Efficiency', 'Simulators', 'ViewA', 'Predictor', 'ViewB')],
               frozen_defs={f'{OT}.lean': ['EnhancedHardCore']}),
    '35': dict(name='canonizer', pr=319, head=CANON, wk=rp('11b24a7ec53d0a3fe0960c177da8bffcd17eb69b'),
               ledoc=CANON, lereuse=None,
               r1=(rp('59c2c1fbf8c1bb08f9d191012b7cdd7e15248531'), rp('da08374d4e5d1d00bf15aba9716407729e549f82')),
               exch=rp('27ae588db3952fb508f02184f9ea2adbb726cf6c'), other=('#318', SCOT),
               owned=[f'{UV}.lean', f'{TM}/CodeFormat.lean', f'{TM}/CodeSimulator.lean'],
               unit=[f'{UV}.lean', f'{UV}/Canonizer.lean', f'{TM}/CodeFormat.lean', f'{TM}/CodeSimulator.lean'],
               frozen_defs={f'{UV}.lean': ['CanonizerExp'], f'{TM}/CodeFormat.lean': ['oneTapeFormat', 'codeDecode'],
                            f'{TM}/CodeSimulator.lean': ['oneTapeMachineFormat']}),
}[gate]
HEAD, WK, LEDOC = CFG['head'], CFG['wk'], CFG['ledoc']
BASE = rp(git('merge-base', HEAD, TIP).stdout.strip())
UNIT, OWNED = CFG['unit'], CFG['owned']
OPEN = {'#313': rp('94b31964ee94b97bf3ed3b4b4338cacae8183194'), '#316': rp('c18afbe66101381eed1617801d942dcf691506ea'),
        '#317': rp('590d1a56a350d9e8e75ee33d31e0501182169f67'), CFG['other'][0]: CFG['other'][1]}
CMP = [('tip', TIP)] + list(OPEN.items())
show = lambda rev, p: git('show', f'{rev}:{p}', check=False).stdout
lean = lambda a, b: [p for p in git('diff', '--name-only', '--no-renames', a, b).stdout.split() if p.endswith('.lean')]
anc = lambda a, b: git('merge-base', '--is-ancestor', a, b, check=False).returncode == 0
W = lambda name, L: open(os.path.join(out, name), 'w', encoding='utf-8').write('\n'.join(L) + '\n')


def graph(rev):
    g = {}
    for p in git('ls-tree', '-r', '--name-only', rev).stdout.split():
        if p.endswith('.lean') and p.startswith(('TCSlib', 'audits')):
            g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', show(rev, p))
                    if m.startswith(('TCSlib', 'audits'))]
    return g


def closure(g, roots):
    seen, st = set(), list(roots)
    while st:
        x = st.pop()
        if x in seen or x not in g: continue
        seen.add(x); st.extend(g[x])
    return seen


# 1. merge trees -----------------------------------------------------------------------------------------------
L = [f'PR #{CFG["pr"]} ({CFG["name"]}) head {HEAD}; merge base with the tip {TIP}: {BASE}',
     f'#{CFG["pr"]} changed .lean paths ({BASE[:8]}..head): {lean(BASE, HEAD)}',
     f'tip {TIP[:8]} contains #316 {OPEN["#316"][:8]}: {anc(OPEN["#316"], TIP)}; contains #317 {OPEN["#317"][:8]}: '
     f'{anc(OPEN["#317"], TIP)}; contains #313 {OPEN["#313"][:8]}: {anc(OPEN["#313"], TIP)}',
     f'tip .lean delta since the merge base ({BASE[:8]}..{TIP[:8]}): {lean(BASE, TIP)}', '']
trees, changed, mb = {}, {}, {}
for k, v in CMP:
    mb[k] = rp(git('merge-base', HEAD, v).stdout.strip())
    changed[k] = lean(mb[k], v)
    r = git('merge-tree', '--write-tree', '--name-only', HEAD, v, check=False)
    t = r.stdout.split('\n')[0]; trees[k] = t
    L.append(f'git merge-tree --write-tree {HEAD} {v} ({k}): {t} rc {r.returncode}')
    if r.returncode: L.append(r.stdout)
    dh = [p for p in git('diff', '--name-only', HEAD, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    do = [p for p in git('diff', '--name-only', v, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    L.append(f'  Lean paths of the merged tree differing from the #{CFG["pr"]} head ({len(dh)}): {dh}')
    L.append(f'  and from {k} ({len(do)}): {do}')
    L.append(f'  merge base {mb[k]}; {k} changed .lean paths from it ({len(changed[k])}); shared with '
             f'#{CFG["pr"]}: {sorted(set(changed[k]) & set(lean(BASE, HEAD)))}')
L.append('')
ok, ov = CFG['other']
s1, s2, s3 = set(lean(BASE, HEAD)), set(lean(BASE, ov)), set(lean(BASE, TIP)) | set(lean(mb['#313'], OPEN['#313']))
L.append(f'three-way disjointness (tip delta + #313, #{CFG["pr"]}, {ok}): #{CFG["pr"]} & {ok} {sorted(s1 & s2)}; '
         f'#{CFG["pr"]} & (tip, #313) {sorted(s1 & s3)}; {ok} & (tip, #313) {sorted(s2 & s3)}')
W('mergetrees.txt', L)

# 2. downstream ------------------------------------------------------------------------------------------------
gh = graph(HEAD)
clo = {p: closure(gh, [p]) for p in UNIT}
L = [f'# graph at the #{CFG["pr"]} head {HEAD[:8]} (TCSlib and audits modules); a module counts as downstream of itself',
     f'unit modules: {len(UNIT)}; union of their closures: {len(set().union(*clo.values()))} modules']
for k, v in CMP:
    ch = set(changed[k])
    hit = {p: sorted(ch & clo[p]) for p in UNIT}
    L.append(f'{k} ({v[:8]}): changed modules (from the merge base {mb[k][:8]}) in the closure of a unit module: '
             f'{sorted(set().union(*hit.values()))}')
    for p in UNIT:
        L.append(f'    {p.split("/")[-1]}: {len(hit[p])}')
    gm = graph(trees[k])
    both = sorted(p for p in gm if (set(UNIT) & closure(gm, [p])) and (ch & closure(gm, [p])))
    L.append(f'  in the merged tree {trees[k][:8]}: {len(both)} modules downstream of both a #{CFG["pr"]} module and a '
             f'{k} module: {both}')
W('downstream.txt', L)

# 3. headers and docstrings of the pre-existing declarations ---------------------------------------------------
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)')


def decls(text):
    Ls = text.split('\n'); res = {}
    for i, l in enumerate(Ls):
        m = KW.match(l)
        if not m: continue
        kind, name = m.groups(); j = i
        while j < len(Ls) and Ls[j].strip() != '': j += 1
        block = '\n'.join(Ls[i:j])
        if kind in ('theorem', 'lemma'):
            d, cut = 0, None
            for k, ch in enumerate(block):
                if ch in '([{⟨': d += 1
                elif ch in ')]}⟩': d -= 1
                elif d == 0 and block.startswith(':=', k): cut = k; break
            block = block[:cut] if cut is not None else block
        k = i - 1; doc = ''
        if k >= 0 and Ls[k].rstrip().endswith('-/'):
            s = k
            while s >= 0 and '/--' not in Ls[s]: s -= 1
            doc = '\n'.join(Ls[s:k + 1])
        res[name] = (kind, i + 1, block, doc)
    return res


ws = lambda t: re.sub(r'\s+', ' ', t).strip()
L = [f'# pre-existing files: every declaration at the issue base {ISSUE[:8]} and the merge base {BASE[:8]} against the '
     f'head {HEAD[:8]} (header = keyword line to the top-level := for theorems, the whole block for definitions)']
for own in OWNED:
    L.append(f'## {own}')
    L.append(f'blob at {ISSUE[:8]} = at {BASE[:8]}: {show(ISSUE, own) == show(BASE, own)}')
    a, b = decls(show(BASE, own)), decls(show(HEAD, own))
    nd = 0
    for n in a:
        ka, la, ha, da = a[n]; kb, lb, hb, db = b.get(n, (None,) * 4)
        if ha != hb or da != db or len(a) < 60:
            L.append(f'{"IDENTICAL" if ha == hb else ("WHITESPACE-ONLY" if hb is not None and ws(ha) == ws(hb) else "DIFF")}'
                     f'\theader\t{ka} {n}\t{la}->{lb}\tdocstring {"identical" if da == db else "changed"}')
        nd += ha != hb
    L.append(f'base {len(a)} declarations, head {len(b)}; headers differing in bytes: {nd}; order kept: '
             f'{[n for n in b if n in a] == list(a)}; new: {[n for n in b if n not in a]}; gone: {[n for n in a if n not in b]}')
    for d in CFG['frozen_defs'].get(own, []):
        L.append(f'frozen definition {d}: block byte-identical base -> head: {a[d][2] == b[d][2]}; docstring identical: '
                 f'{a[d][3] == b[d][3]}')
for p in UNIT:
    if p not in OWNED:
        L.append(f'{p}: new file (absent at {BASE[:8]}: {show(BASE, p) == ""}), {len(decls(show(HEAD, p)))} named '
                 f'declarations')
W('headers.txt', L)

# 4. landing edits ---------------------------------------------------------------------------------------------
def blank_docs(t): return re.sub(r'/-[-!].*?-/', '', t, flags=re.S)


docs = lambda t: re.findall(r'/--.*?-/', t, flags=re.S)
L = ['# landing edits from git objects']
fs = lean(WK, LEDOC)
L.append(f'LE-doc {WK[:8]}..{LEDOC[:8]}: {len(fs)} files; numstat {git("diff", "--numstat", WK, LEDOC).stdout.split()}')
tot = 0
for p in fs:
    a, b = show(WK, p), show(LEDOC, p)
    da, db = docs(a), docs(b)
    nch = sum(x != y for x, y in zip(da, db)) if len(da) == len(db) else None
    tot += nch or 0
    L.append(f'  {p.split("/")[-1]}: identical with doc comments deleted: {blank_docs(a) == blank_docs(b)}; '
             f'docstrings {len(da)} -> {len(db)}, changed {nch}; max width {max(len(x) for x in b.splitlines())}')
L.append(f'  docstrings changed in total: {tot}')
if CFG['lereuse']:
    R = CFG['lereuse']; fs = lean(LEDOC, R)
    L.append(f'LE-reuse {LEDOC[:8]}..{R[:8]}: {len(fs)} files {fs}; numstat {git("diff", "--numstat", LEDOC, R).stdout.split()}')
    d = git('diff', '-U0', LEDOC, R).stdout
    L.append('  hunks: ' + ' | '.join(h.strip() for h in re.findall(r'(?m)^@@ .*? @@(.*)$', d)))
    L += ['  ' + x for x in d.splitlines() if x[:1] in '+-' and not x.startswith(('+++', '---'))]
    for p in fs:
        a, b = decls(show(LEDOC, p)), decls(show(R, p))
        dh = [n for n in a if a[n][2] != b.get(n, (0, 0, None))[2]]
        dd = [n for n in a if a[n][3] != b.get(n, (0, 0, 0, None))[3]]
        L.append(f'  {p.split("/")[-1]}: {len(a)} declarations; headers differing: {dh}; docstrings changed: {dd}; '
                 f'imports identical: {re.findall(r"(?m)^import .*", show(LEDOC, p)) == re.findall(r"(?m)^import .*", show(R, p))}')
        L.append(f'  BinArith.iterate_pairSndD_nil at the head: '
                 f'{[f"{q}:{i + 1}" for q in [p, "TCSlib/Complexity/ClassP/BinaryArith/Words.lean"] for i, l in enumerate(show(R, q).splitlines()) if "iterate_pairSndD_nil" in l and ("theorem" in l or ":=" in l or "BinArith." in l)]}')
W('lecheck.txt', L)

# 5. rebase identity, worker sources, signatures ---------------------------------------------------------------
L = ['# rebase identity, the worker src/ and the signatures']
r1b, r1h = CFG['r1']
r = git('range-diff', f'{r1b}..{r1h}', f'{BASE}..{HEAD}').stdout
L.append(f'git range-diff {r1b[:8]}..{r1h[:8]} (the review r1 head, where the probes, seals and controls ran) '
         f'{BASE[:8]}..{HEAD[:8]}:'); L += ['  ' + x for x in r.splitlines()]
cl = sorted(set().union(*[closure(gh, [p]) for p in UNIT]))
dif = [p for p in cl if show(r1h, p) != show(HEAD, p)]
L.append(f'unit closure at the head ({len(cl)} modules, the {len(UNIT)} unit modules included): byte-identical at '
         f'r1 {r1h[:8]}: {len(cl) - len(dif)}, differing {dif}')
for p in UNIT:
    w = gitb('show', f'{CFG["exch"]}:inbox/fills/{CFG["name"]}/src/{p}')
    L.append(f'{p.split("/")[-1]}: worker src/ (exchange {CFG["exch"][:8]}) = landing worker head {WK[:8]}: '
             f'{w == gitb("show", f"{WK}:{p}")}')
src = git('ls-tree', '-r', '--name-only', CFG['exch'], f'inbox/fills/{CFG["name"]}/src').stdout.split()
L.append(f'src/ holds {len(src)} files; landing worker head changes {len(lean(BASE, WK))} .lean paths from {BASE[:8]}')
L.append(f'commits {BASE[:8]}..{HEAD[:8]}:')
for c in git('rev-list', '--reverse', f'{BASE}..{HEAD}').stdout.split():
    o = git('cat-file', '-p', c).stdout
    L.append(f'  {c} gpgsig {len(re.findall(r"(?m)^gpgsig", o))} | '
             f'{git("log", "-1", "--format=%an <%ae> | %cn <%ce> | %s", c).stdout.strip()}')
W('rebase.txt', L)

# 6. built sources against the head and the merged trees -------------------------------------------------------
zp = os.path.join(repo, f'{B}/fills/{CFG["name"]}/final-r1/review-evidence.zip')
z = zipfile.ZipFile(zp)
pre = f'{CFG["name"]}-r1/'
rows = [json.loads(l) for l in z.read(pre + 'build-r3/results.jsonl').decode().splitlines() if l.strip()]
mods = [x for x in rows if 'module' in x]
L = [f'review-evidence.zip:{pre}build-r3/results.jsonl (the final build, head {HEAD[:8]}): {len(mods)} module records; '
     f'last record keys {sorted(rows[-1])}; rc 0 {sum(x["rc"] == 0 for x in mods)}, errors {sum(x["errors"] for x in mods)}',
     f'unit modules built: {sorted(set(m["module"] + ".lean" for m in mods) & set(UNIT)) == sorted(UNIT)}']
for k, rev in [('head', HEAD)] + [(f'merged with {k}', trees[k]) for k, _ in CMP]:
    diff = [x['module'] for x in mods
            if hashlib.sha256(gitb('show', f'{rev}:{x["module"]}.lean')).hexdigest() != x['source_sha256']]
    L.append(f'{k} {rev[:8]}: {len(mods) - len(diff)} equal, {len(diff)} differ {diff}')
W('srcequality.txt', L)

# 7. new names against the comparators' changed files ----------------------------------------------------------
NM = re.compile(r'(?m)^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                r'(?:theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)')
new = sorted({n for p in UNIT for n in NM.findall(show(HEAD, p))} - {n for p in UNIT for n in NM.findall(show(BASE, p))})
L = [f'# the {len(new)} declaration names new at the head (short names as written) against the declarations of the '
     f'.lean files each comparator changed since its merge base with the head']
for k, v in CMP:
    hits = []
    for p in changed[k]:
        if p in UNIT: continue
        for i, l in enumerate(show(v, p).splitlines()):
            m = NM.match(l)
            if m and m.group(1) in new: hits.append(f'{p}:{i + 1}: {l.strip()[:120]}')
    L.append(f'{k} ({len(changed[k])} changed files): {len(hits)} declarations with a new name')
    L += ['    ' + h for h in hits]
W('namecheck.txt', L)

# 8. Gate 35: the readers, the C-F01 re-wrap, the dependency trace ----------------------------------------------
if gate == '35':
    RUL = {f'{TM}/CodeFormat.lean': ('oneTapeFormat_serialize_decode', '(xs : List Bool)',
                                     'oneTapeFormat.serialize (oneTapeFormat.decode xs) = (codeDecode xs).serialize',
                                     'codeDecode_serialize_pad'),
           f'{TM}/CodeSimulator.lean': ('oneTapeMachineFormat_serialize_decode', '(α : List Bool)',
                                        'oneTapeMachineFormat.serialize (oneTapeMachineFormat.decode α) = '
                                        'oneTapeFormat.serialize (oneTapeFormat.decode α)', 'oneTapeMachineFormat')}
    rul = show(TIP, f'{B}/fills/canonizer/rulings/2026-11-14-readers.md')
    L = ['# the frozen machine-library files: the diffs from the merge base, against the ruling of 2026-11-14 '
         f'(fills/canonizer/rulings/2026-11-14-readers.md at the tip {TIP[:8]})']
    for p, (name, binder, stmt, after) in RUL.items():
        d = git('diff', '-U0', BASE, HEAD, '--', p).stdout
        plus = [x[1:] for x in d.splitlines() if x.startswith('+') and not x.startswith('+++')]
        minus = [x for x in d.splitlines() if x.startswith('-') and not x.startswith('---')]
        hunks = re.findall(r'(?m)^@@ .*? @@', d)
        L.append(f'## {p}: {len(hunks)} hunk(s) {hunks}, {len(plus)} added lines, {len(minus)} removed lines')
        L += ['  + ' + x for x in plus]
        text = '\n'.join(plus)
        m = re.search(r'/--(.*?)-/\s*(.*)', text, flags=re.S)
        doc, decl = m.group(1), ws(m.group(2))
        want = f'theorem {name} {binder} : {stmt} := rfl'
        L.append(f'  declaration (whitespace-collapsed) = `theorem {name} {binder} : <ruling statement> := rfl`: '
                 f'{decl == want}')
        L.append(f'  ruling statement verbatim in the ruling file: {("`" + stmt + "`") in ws(rul)}')
        L.append(f'  docstring states the formula (contains the statement, whitespace-collapsed): {ws(stmt) in ws(doc)}')
        L.append(f'  attribute: {"@[" in text}; `List Bool` binder: {"List Bool" in binder}; proved by `rfl`: '
                 f'{decl.endswith(":= rfl")}')
        hb = show(HEAD, p).splitlines(); i = next(k for k, l in enumerate(hb) if f'theorem {name}' in l)
        prev = [l for l in hb[:i] if KW.match(l)][-1]
        L.append(f'  placed after: `{prev.strip()[:90]}` (expected `{after}`): {after in prev}')
        hs = show(HEAD, p).splitlines(keepends=True)
        k0 = int(re.match(r'@@ -\S+ \+(\d+)', hunks[0]).group(1)) - 1
        L.append(f'  head file with the {len(plus)} added lines (head lines {k0 + 1}-{k0 + len(plus)}) cut out = the '
                 f'merge-base file byte for byte: {"".join(hs[:k0] + hs[k0 + len(plus):]) == show(BASE, p)}')
        a, b = decls(show(BASE, p)), decls(show(HEAD, p))
        L.append(f'  base declarations {len(a)}: header and docstring byte-identical at the head: '
                 f'{sum(a[n][2:] == b.get(n, (0, 0, 0, 0))[2:] for n in a)}; new: {[n for n in b if n not in a]}')
    W('readers.txt', L)

    own = f'{UV}.lean'
    a, b = show(BASE, own), show(HEAD, own)
    da, db = decls(a), decls(b)
    L = [f'# C-F01: the owned file {own}, merge base {BASE[:8]} -> head {HEAD[:8]}']
    hd = [n for n in da if da[n][2] != db[n][2]]
    L.append(f'declarations whose header bytes differ: {hd}')
    for n in hd:
        L.append(f'  {n}: whitespace-collapsed equal: {ws(da[n][2]) == ws(db[n][2])}; base line widths '
                 f'{[len(x) for x in da[n][2].splitlines()]}; head {[len(x) for x in db[n][2].splitlines()]}')
        L += ['    - ' + x for x in da[n][2].splitlines()] + ['    + ' + x for x in db[n][2].splitlines()]

    def body(t, n):
        Ls = t.split('\n'); i = da[n][1] - 1 if t is a else db[n][1] - 1
        j = i + 1
        while j < len(Ls) and not KW.match(Ls[j]) and not Ls[j].startswith(('/--', 'end ', 'section', '/-!')): j += 1
        return '\n'.join(Ls[i:j])
    tgt = 'exists_canonizerExp'
    L.append('declarations whose full text (keyword line to the next declaration) differs, other than the target:')
    for n in da:
        if n == tgt: continue
        x, y = body(a, n), body(b, n)
        if x != y:
            L.append(f'  {n}: whitespace-collapsed equal {ws(x) == ws(y)}; base lines over 100 '
                     f'{sum(len(l) > 100 for l in x.splitlines())}, head {sum(len(l) > 100 for l in y.splitlines())}')
    L.append(f'target {tgt}: header byte-identical {da[tgt][2] == db[tgt][2]}; docstring changed {da[tgt][3] != db[tgt][3]}')
    L.append(f'owned file lines over 100: base {sum(len(l) > 100 for l in a.splitlines())}, head '
             f'{sum(len(l) > 100 for l in b.splitlines())}; lines {len(a.splitlines())} -> {len(b.splitlines())}')
    W('whitespace.txt', L)

    e = z.read(pre + 'probe-runs/mods/PlProbe_DepTrace.log').decode()
    L = [f'# review-evidence.zip:{pre}probe-runs/mods/PlProbe_DepTrace.log (the review\'s Lean run at r1 {r1h[:8]}; '
         f'quoted, not re-run), sha256 {hashlib.sha256(e.encode()).hexdigest()}'] + ['  ' + x for x in e.splitlines()]
    src = z.read(pre + 'probe-sources/head/DepTrace.lean').decode()
    L.append(f'probe source {pre}probe-sources/head/DepTrace.lean: walks getUsedConstantsAsSet from '
             f'TCSlib.Cryptography.exists_canonizerExp: {"getUsedConstantsAsSet" in src and "exists_canonizerExp" in src}')
    W('deptrace.txt', L)
print('OK', gate, {k: v[:8] for k, v in trees.items()})
