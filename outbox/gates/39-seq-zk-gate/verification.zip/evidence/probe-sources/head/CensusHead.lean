import Lean
import TCSlib.Cryptography.Composability.SequentialZK
import TCSlib.Cryptography.Composability.SequentialZK.Advice
import TCSlib.Cryptography.Composability.SequentialZK.BoundedMetadata
import TCSlib.Cryptography.Composability.SequentialZK.ComputationalAdvice
import TCSlib.Cryptography.Composability.SequentialZK.ComputationalHybrid
import TCSlib.Cryptography.Composability.SequentialZK.ComputationalPhaseBound
import TCSlib.Cryptography.Composability.SequentialZK.ComputationalReduction
import TCSlib.Cryptography.Composability.SequentialZK.ComputationalTransfer
import TCSlib.Cryptography.Composability.SequentialZK.Congruence
import TCSlib.Cryptography.Composability.SequentialZK.ContinuationProbability
import TCSlib.Cryptography.Composability.SequentialZK.Efficiency
import TCSlib.Cryptography.Composability.SequentialZK.EndpointSampling
import TCSlib.Cryptography.Composability.SequentialZK.ErrSoundness
import TCSlib.Cryptography.Composability.SequentialZK.ExecutionBounds
import TCSlib.Cryptography.Composability.SequentialZK.HybridRecursion
import TCSlib.Cryptography.Composability.SequentialZK.Normalization
import TCSlib.Cryptography.Composability.SequentialZK.NormalizationMachine
import TCSlib.Cryptography.Composability.SequentialZK.NormalizedStep
import TCSlib.Cryptography.Composability.SequentialZK.PaddedProverSpec
import TCSlib.Cryptography.Composability.SequentialZK.PhaseView
import TCSlib.Cryptography.Composability.SequentialZK.Phases
import TCSlib.Cryptography.Composability.SequentialZK.PrefixFolds
import TCSlib.Cryptography.Composability.SequentialZK.PrefixLaws
import TCSlib.Cryptography.Composability.SequentialZK.ProofTransfers
import TCSlib.Cryptography.Composability.SequentialZK.RealPhases
import TCSlib.Cryptography.Composability.SequentialZK.RealPrefixBounds
import TCSlib.Cryptography.Composability.SequentialZK.ReductionAdvantage
import TCSlib.Cryptography.Composability.SequentialZK.RepeatedSoundness
import TCSlib.Cryptography.Composability.SequentialZK.RepeatedVerifier
import TCSlib.Cryptography.Composability.SequentialZK.SimulatorMachine
import TCSlib.Cryptography.Composability.SequentialZK.Soundness
import TCSlib.Cryptography.Composability.SequentialZK.Statistical
import TCSlib.Cryptography.Composability.SequentialZK.StatisticalPostprocess
import TCSlib.Cryptography.Composability.SequentialZK.StatisticalPrefix
import TCSlib.Cryptography.Composability.SequentialZK.StatisticalRecursion
import TCSlib.Cryptography.Composability.SequentialZK.StatisticalTransfer
import TCSlib.Cryptography.Composability.SequentialZK.SuffixLaws
import TCSlib.Cryptography.Composability.SequentialZK.SuffixMachine
import TCSlib.Cryptography.Composability.SequentialZK.VerifierPrefix
import TCSlib.Cryptography.Composability.SequentialZK.WrappedVerifier
import TCSlib.Cryptography.ZeroKnowledge.Defs
import TCSlib.Cryptography.Composability.ThreeColoring

/-! seq-zk review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.ZK.seqRep
#print axioms TCSlib.Cryptography.StatZK.seqRep
#print axioms TCSlib.Cryptography.InteractiveProof.seqRep
#print axioms TCSlib.Cryptography.InteractiveProofErr.seqRep
#print axioms TCSlib.Cryptography.EfficientProverProofErr.seqRep
#print axioms TCSlib.Cryptography.PerfectZK.seqRep
#print axioms TCSlib.Cryptography.PerfectZKAbort.seqRep
#print axioms TCSlib.Cryptography.Composability.colSeq_efficientProverProof_zk
#print axioms TCSlib.Cryptography.Composability.negligible_colSeqSound
#print axioms TCSlib.Cryptography.StatZK_iff
#print axioms TCSlib.Cryptography.SequentialZK.zk_of_padded_spec

def owners : List Name := [`TCSlib.Cryptography.Composability.SequentialZK,
  `TCSlib.Cryptography.Composability.SequentialZK.Advice,
  `TCSlib.Cryptography.Composability.SequentialZK.BoundedMetadata,
  `TCSlib.Cryptography.Composability.SequentialZK.ComputationalAdvice,
  `TCSlib.Cryptography.Composability.SequentialZK.ComputationalHybrid,
  `TCSlib.Cryptography.Composability.SequentialZK.ComputationalPhaseBound,
  `TCSlib.Cryptography.Composability.SequentialZK.ComputationalReduction,
  `TCSlib.Cryptography.Composability.SequentialZK.ComputationalTransfer,
  `TCSlib.Cryptography.Composability.SequentialZK.Congruence,
  `TCSlib.Cryptography.Composability.SequentialZK.ContinuationProbability,
  `TCSlib.Cryptography.Composability.SequentialZK.Efficiency,
  `TCSlib.Cryptography.Composability.SequentialZK.EndpointSampling,
  `TCSlib.Cryptography.Composability.SequentialZK.ErrSoundness,
  `TCSlib.Cryptography.Composability.SequentialZK.ExecutionBounds,
  `TCSlib.Cryptography.Composability.SequentialZK.HybridRecursion,
  `TCSlib.Cryptography.Composability.SequentialZK.Normalization,
  `TCSlib.Cryptography.Composability.SequentialZK.NormalizationMachine,
  `TCSlib.Cryptography.Composability.SequentialZK.NormalizedStep,
  `TCSlib.Cryptography.Composability.SequentialZK.PaddedProverSpec,
  `TCSlib.Cryptography.Composability.SequentialZK.PhaseView,
  `TCSlib.Cryptography.Composability.SequentialZK.Phases,
  `TCSlib.Cryptography.Composability.SequentialZK.PrefixFolds,
  `TCSlib.Cryptography.Composability.SequentialZK.PrefixLaws,
  `TCSlib.Cryptography.Composability.SequentialZK.ProofTransfers,
  `TCSlib.Cryptography.Composability.SequentialZK.RealPhases,
  `TCSlib.Cryptography.Composability.SequentialZK.RealPrefixBounds,
  `TCSlib.Cryptography.Composability.SequentialZK.ReductionAdvantage,
  `TCSlib.Cryptography.Composability.SequentialZK.RepeatedSoundness,
  `TCSlib.Cryptography.Composability.SequentialZK.RepeatedVerifier,
  `TCSlib.Cryptography.Composability.SequentialZK.SimulatorMachine,
  `TCSlib.Cryptography.Composability.SequentialZK.Soundness,
  `TCSlib.Cryptography.Composability.SequentialZK.Statistical,
  `TCSlib.Cryptography.Composability.SequentialZK.StatisticalPostprocess,
  `TCSlib.Cryptography.Composability.SequentialZK.StatisticalPrefix,
  `TCSlib.Cryptography.Composability.SequentialZK.StatisticalRecursion,
  `TCSlib.Cryptography.Composability.SequentialZK.StatisticalTransfer,
  `TCSlib.Cryptography.Composability.SequentialZK.SuffixLaws,
  `TCSlib.Cryptography.Composability.SequentialZK.SuffixMachine,
  `TCSlib.Cryptography.Composability.SequentialZK.VerifierPrefix,
  `TCSlib.Cryptography.Composability.SequentialZK.WrappedVerifier,
  `TCSlib.Cryptography.ZeroKnowledge.Defs]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

