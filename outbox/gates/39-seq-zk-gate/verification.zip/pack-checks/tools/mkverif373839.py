"""mkverif373839.py <repo> <rec-rev> <37|38|39> <checks-dir> <tools-dir> <out.zip>: the verification ZIP of Gate 37
round 2 (verification-r2.zip, the Gate 34/36 round-2 method of g3436r2/tools/mkverif_r2.py) or of Gate 38 / 39
(verification.zip, the Gate 36/37 method of g3637/tools/mkverif3637.py).

Members are byte-identical originals: records at the records commit REC (each checked equal to the working tree),
for 38 and 39 the review evidence ZIP with its manifest and the review's landing PROVENANCE, byte copies of the review
ZIP's entries the pack cites, and the worker's files from the delivery commit on the exchange; then checks/ (37) or
pack-checks/ (38, 39): the pack's re-checks from git objects, with their scripts. Writes PROVENANCE.txt and SHA256SUMS
(every other entry). For 38 and 39 also writes the gate's landing/ extracts (byte copies of evidence entries) into the
records gate directory."""
import collections, hashlib, io, os, subprocess, sys, zipfile

repo, REC, gate, chk, tools, out = sys.argv[1:7]
B = 'briefs/pass-shelat-ch5-8'
TOOLS = ['packchk373839.py', 'gitlib.py', 'decls2rev.py', 'mksources.py', 'mkverif373839.py']


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


show = lambda rev, path: git('show', f'{rev}:{path}')
sha = lambda b: hashlib.sha256(b).hexdigest()
members = []


def from_rec(src, dst):
    b = show(REC, src)
    assert open(os.path.join(repo, src), 'rb').read() == b, f'working tree differs from {REC[:8]} for {src}'
    members.append((dst, b, f'records {REC[:8]}:{src}'))


def write(prefix_checks, prov_head, prov_tail, date):
    for c in sorted(os.listdir(chk)):
        members.append((f'{prefix_checks}/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
    for t in TOOLS:
        members.append((f'{prefix_checks}/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
    prov = prov_head + prov_tail + '\nSources:\n' + ''.join(f'  {p}  <-  {d}\n' for p, _, d in sorted(members))
    members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
    members.sort(key=lambda m: m[0])
    assert len({p for p, _, _ in members}) == len(members), 'duplicate member'
    sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
    members.append(('SHA256SUMS', sums.encode(), 'generated'))
    with zipfile.ZipFile(out, 'w') as z:
        for p, b, _ in members:
            zi = zipfile.ZipInfo(p, date_time=date)
            zi.external_attr = 0o100644 << 16
            zi.compress_type = zipfile.ZIP_STORED if p.endswith('.zip') else zipfile.ZIP_DEFLATED
            z.writestr(zi, b)
    with zipfile.ZipFile(out) as z:
        listed = z.namelist()
        inner = {l.split('  ', 1)[1] for l in z.read('SHA256SUMS').decode().splitlines()}
        assert set(listed) == inner | {'SHA256SUMS'} and len(listed) == len(inner) + 1
        for l in z.read('SHA256SUMS').decode().splitlines():
            h, p = l.split('  ', 1)
            assert sha(z.read(p)) == h, p
    print(f'OK gate {gate}: {len(listed)} entries {dict(collections.Counter(n.split("/")[0] for n in listed))}; '
          f'sha256 {sha(open(out, "rb").read())}')


if gate == '37':
    recs = [('PassShelatChapter5-8Plan.md', 'the decision log, with the rows of 2026-11-16 (Gate 37 HOLD and the ruling "re-point\n'
             '    via import"; the combined integration of all open PRs, LE-gate37 pushed; #318, #319 and #323 merged)'),
            (f'{B}/duplication-ledger.md', 'DL-49 (the sc-compose restatements, ruled ledger debt, SC-F01), the disposition\n'
             '    round 1 checked G37-01/02 against'),
            (f'{B}/deferred-work.md', 'the deferred-work register (DW-4: the duplication cleanup, DL-49 included)'),
            (f'{B}/fills/sc-compose/final-r1/review.md', 'the sc-compose maintainer review (as it now stands)')]
    for src, _ in recs:
        from_rec(src, f'records/{src}')
    head = f"""Gate 37 round 2 (sc-compose, draft PR #324, Lean head 4bd2d80bfb58fab5243c66c9f1a697a30b533756) verification-r2.zip

The round-2 records the pack cites that the outbox does not already carry as files, and the pack's re-checks.
- records/: byte-identical originals from records commit {REC} (each also equal to the working tree):
""" + ''.join(f'  - {p.replace(B + "/", "")}: {d};\n' for p, d in recs)
    tail = """- checks/: generated from git objects alone (nothing was built or run): mergetrees.txt, downstream.txt and
  namecheck.txt (the head against the tip, the other open PRs #326 and #327, and the merged heads of #318, #319 and
  #323), integration.txt (the combined build of all open PRs against the current tip: the three open heads merged onto
  it in all six orders, its built sources), srcequality.txt (the LE-gate37 rebuild), rebase.txt (the series and
  signatures), lecheck.txt (LE-gate37: the edit, the headers since round 1, the import and closures, the two public
  lemmas), splitcoins.txt (the Runs.lean qualification), formulas.txt (G37-03), dupscan.txt (the lines changed since
  round 1, reading-lemma lines, statement scans against the pools and the whole tree), the decls2 comparisons, and
  tools/ (packchk373839.py with gitlib.py; decls2rev.py = maintainer/tools/decls2.py's parser on two revisions;
  mksources.py, which wrote sources-r2.zip, pr.diff-r2.txt and source-head-r2.json; this script).
SHA256SUMS lists every entry except itself.
"""
    write('checks', head, tail, (2026, 11, 16, 0, 0, 0))
    sys.exit(0)

CFG = {
    '38': dict(unit='derand', pr=326, head='c27005d67298f79c785a4e8ac1648da0a67d3614', issued='issued-r2',
               exch={'final': '186ffb99ae6e1034185ee2cdffc318db2c955a58'},
               rev='ef0776d5b100fdb1b183d4f47a34e54fba70a8b099bd2998e759be4982f4cfcb', gd='38-derand',
               recs=[f'{B}/duplication-ledger.md', 'PassShelatChapter5-8Plan.md', f'{B}/deferred-work.md',
                     f'{B}/fills/codex-host-2026-11-15/host-addendum.md', f'{B}/fills/codex-host-2026-11-15/dispatch-codex.md',
                     f'{B}/gates/28-derand-host/resolutions-r1.md', f'{B}/gates/28-derand-host/resolutions-r2.md'],
               worker=['patches/COMMITS.tsv'] + [f'evidence/worker/scope-request/{x}' for x in (
                   'EX-01.md', 'EX-02.md', 'standing-discretion.txt', 'SR-01/answer.txt', 'SR-01/inbpp-reader-search.txt',
                   'SR-01/scope-inbpp-reader.md', 'SR-01/scope-inbpp-reader.patch', 'SR-02/request.md',
                   'SR-02/automatic-review-rejection.txt', 'SR-02/typed-views.patch')],
               dx={'patches/COMMITS.tsv': 'patches/COMMITS.tsv',
                   **{f'evidence/worker/scope-request/{x}': f'scope-request/{x}' for x in (
                       'EX-01.md', 'EX-02.md', 'standing-discretion.txt', 'SR-01/answer.txt',
                       'SR-01/inbpp-reader-search.txt', 'SR-01/scope-inbpp-reader.md', 'SR-01/scope-inbpp-reader.patch',
                       'SR-02/request.md', 'SR-02/automatic-review-rejection.txt', 'SR-02/typed-views.patch')}},
               frozen='statements/frozen/frozen-check.txt',
               landing_extra=[('build-retry-results.jsonl', 'build-retry/results.jsonl')]),
    '39': dict(unit='seq-zk', pr=327, head='bd19c433a4cf3d4027ffc891d7d3c06e927e9dfa', issued='issued-r1',
               exch={'final': 'a6be22fa168fcd0a40971383d8ffb3f1adb9731d'},
               rev='f9c394794fd7637237a274163a396eaa78452250c5e31abc5d2878b9e353392f', gd='39-seq-zk',
               recs=[f'{B}/duplication-ledger.md', 'PassShelatChapter5-8Plan.md', f'{B}/deferred-work.md',
                     f'{B}/fills/codex-host-2026-11-15/host-addendum.md', f'{B}/fills/codex-host-2026-11-15/dispatch-codex.md',
                     f'{B}/audits/uniformity-2026-11-16/findings/uniformity-audit-findings.md'],
               worker=['patches/COMMITS.tsv', 'evidence/scope-request/StatZK-iff.patch',
                       'evidence/scope-request/request-and-answer.md', 'evidence/CHECKPOINT1-REPORT.md',
                       'evidence/CHECKPOINT2-REPORT.md', 'evidence/CHECKPOINT3-REPORT.md',
                       'evidence/CHECKPOINT3-doc-REPORT.md', 'evidence/CHECKPOINTfinal-repair-REPORT.md'],
               dx={'patches/COMMITS.tsv': 'patches/COMMITS.tsv',
                   'evidence/scope-request/StatZK-iff.patch': 'scope-request/StatZK-iff.patch',
                   'evidence/scope-request/request-and-answer.md': 'scope-request/request-and-answer.md'},
               frozen='statements/frozen-check.txt', landing_extra=[]),
}[gate]
unit, HEAD, REV = CFG['unit'], CFG['head'], CFG['rev']
FR, IR = f'{B}/fills/{unit}/final-r1', f'{B}/fills/{unit}/{CFG["issued"]}'
GD = f'{B}/gates/{CFG["gd"]}'
EX = {k: git('rev-parse', v).decode().strip() for k, v in CFG['exch'].items()}
from_rec(f'{FR}/review-evidence.zip', 'review-evidence.zip')
from_rec(f'{FR}/evidence-SHA256SUMS', 'review-evidence-SHA256SUMS')
for name in sorted(os.listdir(os.path.join(repo, FR, 'landing'))):
    from_rec(f'{FR}/landing/{name}', f'landing/{name}')
for name in sorted(os.listdir(os.path.join(repo, IR))):
    from_rec(f'{IR}/{name}', f'records/{IR}/{name}')
for src in CFG['recs']:
    from_rec(src, f'records/{src}')
for w in CFG['worker']:
    members.append((f'worker/{w}', show(EX['final'], f'inbox/fills/{unit}/{w}'),
                    f'exchange {EX["final"][:8]}:inbox/fills/{unit}/{w}'))
by = {p: b for p, b, _ in members}
assert sha(by['review-evidence.zip']) == REV, 'review-evidence.zip hash'
man = {}
for l in by['review-evidence-SHA256SUMS'].decode().splitlines():
    if l.strip():
        h, p = l.split('  ', 1); man[p] = h
zf = zipfile.ZipFile(io.BytesIO(by['review-evidence.zip']))
allnames = zf.namelist(); names = [n for n in allnames if not n.endswith('/')]
assert set(names) == set(man) | {'SHA256SUMS'}, sorted(set(names) ^ (set(man) | {'SHA256SUMS'}))[:5]
for p, h in man.items():
    assert sha(zf.read(p)) == h, p
assert zf.read('SHA256SUMS') == by['review-evidence-SHA256SUMS'], 'inner SHA256SUMS differs from the manifest'
cnt = (len(allnames), len(allnames) - len(names), len(names), len(man))
assert by['landing/PROVENANCE.txt'] == zf.read('PROVENANCE.txt')
dx = []
for w, e in CFG['dx'].items():
    assert by[f'worker/{w}'] == zf.read(f'logs/delivery-extracts/{e}'), w
    dx.append(f'worker/{w} = logs/delivery-extracts/{e}')
# the cited review entries: every file under logs/ (except the delivery extracts, already in worker/ or the ZIP),
# statements/, landing/, lint/, restore/ and scan/ up to 2 MB, and named tree/, probe, control and order files
PRE = ('logs/', 'statements/', 'landing/', 'lint/', 'restore/', 'scan/')
NAMED = ['tree/tree-check-head.txt', 'tree/tree-check-post.txt', 'tree/snapshot-pre.txt', 'tree/snapshot-post-final.txt',
         'probe-sources/head/CensusHead.lean', 'probe-runs/mods/PlProbe_CensusHead.log',
         'probe-sources/base/CensusBase.lean', 'base-probe-runs/mods/PlProbe_CensusBase.log',
         'controls/controls-plan.json', 'controls-strict/controls-plan.json', 'order/build-queue.txt', 'order/changed.txt',
         'order/down.txt', 'order/control-probes.txt', 'order/seal-probes-head.txt', 'build/summary.txt']
ext = [n for n in names if n.startswith(PRE) and not n.startswith('logs/delivery-extracts/')
       and zf.getinfo(n).file_size <= 2_000_000] + [n for n in NAMED if n in names]
skipped = [n for n in names if n.startswith(PRE) and not n.startswith('logs/delivery-extracts/')
           and zf.getinfo(n).file_size > 2_000_000]
for e in sorted(set(ext)):
    members.append((f'evidence/{e}', zf.read(e), f'review-evidence.zip:{e}'))
LANDING = [('root-checks.jsonl', 'build/results.jsonl'), ('build-summary.txt', 'logs/build-summary.txt'),
           ('census-head.log', 'probe-runs/mods/PlProbe_CensusHead.log'), ('frozen-check.txt', CFG['frozen']),
           ('tree-check-head.txt', 'tree/tree-check-head.txt')] + CFG['landing_extra']
os.makedirs(os.path.join(repo, GD, 'landing'), exist_ok=True)
for dst, e in LANDING:
    open(os.path.join(repo, GD, 'landing', dst), 'wb').write(zf.read(e))
nrec = sum(p.startswith('records/') for p, _, _ in members)
nw = sum(p.startswith('worker/') for p, _, _ in members)
head = f"""Gate {gate} ({unit}, draft PR #{CFG['pr']}, Lean head {HEAD}) verification.zip

Every file that the maintainer review (final-r1/review.md) cites and the pack uses, as byte-identical originals. Nothing
was re-run to build this ZIP; pack-checks/ holds the pack's own re-checks from git objects (no Lean), with their scripts.
- review-evidence.zip: the delivery review's raw evidence (final-r1/review-evidence.zip, SHA-256 {REV}), with its
  manifest review-evidence-SHA256SUMS (= final-r1/evidence-SHA256SUMS). The ZIP has {cnt[0]} entries, no top folder:
  {cnt[1]} directory entries and {cnt[2]} file entries. The file entries are exactly the {cnt[3]} manifest paths plus
  SHA256SUMS, which is byte-identical to the manifest; every manifest hash verifies.
- landing/PROVENANCE.txt: the review's PROVENANCE (final-r1/landing/), byte-identical to the ZIP's PROVENANCE.txt.
- records/ ({nrec}): git objects at records commit {REC} (each equal to the working tree): the issue package
  {IR.replace(B + '/', '')}/ and the records the pack cites.
- evidence/ ({len(set(ext))}): byte copies of review-evidence.zip entries (path = the entry's path): every file under logs/
  (except logs/delivery-extracts/), statements/, landing/, lint/, restore/ and scan/ of at most 2 MB, and named tree,
  probe, control and order files. Over 2 MB and only inside review-evidence.zip: {skipped}.
- worker/ ({nw}): byte copies from exchange/pass-shelat-ch5-8 (inbox/fills/{unit}/) at the final delivery commit
  {EX['final']}. Byte-identical to the review's copies under logs/delivery-extracts/ ({len(dx)}):
""" + ''.join(f'    {x}\n' for x in dx)
tail = """  The worker's final REPORT.md is worker-report.md in the gate pack.
- pack-checks/: the maintainer's re-checks for this pack, from git objects only: mergetrees.txt, downstream.txt and
  namecheck.txt (the head against the tip, the other open PRs and the merged heads of #318, #319 and #323),
  integration.txt (the combined build of all open PRs against the current tip), srcequality.txt (the review build),
  rebase.txt (range-diff, the worker src/, signatures), headers.txt (the pre-existing files), lecheck.txt (LE-doc),
  shared.txt (the shared-file additions), rule10.txt (the seal failures attributed), dupscan.txt (statement scans), the
  decls2 comparisons; and tools/ (packchk373839.py with gitlib.py; decls2rev.py = maintainer/tools/decls2.py's parser
  applied to two revisions; mksources.py, which wrote sources.zip, pr.diff.txt and source-head.json; this script).
SHA256SUMS lists every entry except itself.
"""
write('pack-checks', head, tail, (2026, 11, 16, 0, 0, 0))
