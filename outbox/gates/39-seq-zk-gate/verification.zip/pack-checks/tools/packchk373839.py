"""packchk373839.py <repo> <37|38|39> <out-dir>: pack re-checks from git objects only (no Lean) for Gate 37 round 2
(#324, sc-compose), Gate 38 (#326, derand) and Gate 39 (#327, seq-zk).

The Gate 34/36 round-2 method (g3436r2/tools/packchk_r2.py) for 37, and the Gate 36/37 fill-gate method
(g3637/tools/packchk.py) for 38 and 39, after #318, #319 and #323 merged (2026-11-16). Each head is trial-merged with
the tip, with the other open PRs (#324, #326, #327) and with the merged heads of #318, #319 and #323. The combined
build of all open PRs (maintainer/int-all-open-2026-11-16/) is related to the current tip: the three open heads merged
onto it, in every order, against the combined build's TCSlib and audits trees, and its built sources against them.

Writes mergetrees.txt, downstream.txt, namecheck.txt, integration.txt, srcequality.txt, rebase.txt, lecheck.txt,
dupscan.txt, and the gate's own checks: 37 splitcoins.txt, formulas.txt; 38 and 39 headers.txt, shared.txt,
rule10.txt."""
import hashlib, io, itertools, json, os, re, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls, ws, blank_docs, docs, NM

repo_path, gate, out = sys.argv[1], sys.argv[2], sys.argv[3]
R = Repo(repo_path); rp = R.rp
B = 'briefs/pass-shelat-ch5-8'
TIPREF = 'origin/cryptography/pass-shelat-ch2-4'
TIP = rp(TIPREF)
OPEN = {'#324': rp('origin/land/pass-shelat-sc-compose'), '#326': rp('origin/land/pass-shelat-derand'),
        '#327': rp('origin/land/pass-shelat-seq-zk')}
assert OPEN == {'#324': '4bd2d80bfb58fab5243c66c9f1a697a30b533756', '#326': 'c27005d67298f79c785a4e8ac1648da0a67d3614',
                '#327': 'bd19c433a4cf3d4027ffc891d7d3c06e927e9dfa'}, OPEN
MERGED = {'#318': rp('b0bad23ae611983e3323460bb8c564da90ad6e8c'), '#319': rp('47daa90792e96b93510384adbab9f6e492ccef3a'),
          '#323': rp('8c3f3e3fe2912784f680c10f8c478d2eeeeb7f6a')}
MCOMMIT = {'#318': rp('51a25911e0b715b20151940feb172fb4aba78554'), '#319': rp('0053d7c1810b8fc3309de3cac55bb9ede4c9450c'),
           '#323': rp('4ba8f126e39cf86b0ae149a7cf46b0c91a02d644')}
INT = dict(zip=f'{B}/maintainer/int-all-open-2026-11-16/int-all-open-evidence.zip', part='build/results-final.jsonl',
           tree=rp('3fb05ea062395caf069c09643a8caf751d3ad6da'), commit=rp('639d16d943d4bb4777c77ae8614cd8c2ed91f1bd'),
           rtip=rp('b0ebd475eb0b4131449bce58462f168f27eee17b'))
SC = 'TCSlib/Cryptography/SecureComputation'
CSD = f'{SC}/ComposeSecurity'
RND = 'TCSlib/Complexity/Randomized'
DER = 'TCSlib/Cryptography/Randomness/Derandomization'
SQZ = 'TCSlib/Cryptography/Composability/SequentialZK'
CFG = {
    '37': dict(pr='#324', name='sc-compose', head='4bd2d80bfb58fab5243c66c9f1a697a30b533756',
               unit=[f'{SC}/ComposeSecurity.lean'] + [f'{CSD}/{x}.lean' for x in (
                   'Accept', 'Assembly', 'Bounds', 'Chain', 'Correct', 'Efficiency', 'Lengths', 'Machines',
                   'Probability', 'Reductions', 'Runs', 'SideA', 'SideB', 'Sim', 'Template')],
               r1head=rp('a6eaebd78c48e7fdfd06263edb84b70bc00ec593'), r1base=rp('6ce4658db08a1dc2a03a149987197660db078011'),
               zips=[(f'{B}/gates/37-sc-compose/landing-r1/gate37-le-evidence.zip', ['build/results.jsonl'],
                      'LE-gate37 rebuild (21 modules, on the combined tree)')]),
    '38': dict(pr='#326', name='derand', head='c27005d67298f79c785a4e8ac1648da0a67d3614',
               unit=['TCSlib/Complexity/ClassP/DTIME.lean', f'{RND}/Build/IterateFind.lean', f'{RND}/Classes.lean',
                     f'{RND}/SeedMajority.lean'] + [f'{RND}/SeedMajority/{x}.lean' for x in
                                                    ('Enumeration', 'Envelope', 'State', 'Words')]
                    + [f'{DER}.lean'] + [f'{DER}/{x}.lean' for x in
                                         ('AdviceGap', 'CoinGap', 'Expanded', 'Majority', 'RootSchedule', 'TimeBound')],
               frozen=['TCSlib/Complexity/ClassP/DTIME.lean', f'{RND}/Build/IterateFind.lean', f'{RND}/Classes.lean',
                       f'{RND}/SeedMajority.lean', f'{DER}.lean'],
               issue=rp('01de2d8baed9113e4a099e13c5d50c81e6dbc66f'), wk=rp('941b5a1e5116b1ecf3afa56188abd88159389600'),
               wkhead=rp('5e12a169e671dc16b6766e21067b79c16835af67'), exch=rp('186ffb99ae6e1034185ee2cdffc318db2c955a58'),
               zips=[(f'{B}/fills/derand/final-r1/review-evidence.zip', ['build/results.jsonl', 'build-retry/results.jsonl'],
                      'the derand review build (565 modules, at 941b5a1e)')]),
    '39': dict(pr='#327', name='seq-zk', head='bd19c433a4cf3d4027ffc891d7d3c06e927e9dfa',
               unit=None, frozen=[f'{SQZ}.lean', 'TCSlib/Cryptography/ZeroKnowledge/Defs.lean'],
               issue=rp('107f1e8c218733eac12d6b9bee6fece441271317'), wk=rp('e9b5ea47a1c3dcd664caf2dbf308f89c1beffbb8'),
               wkhead=rp('d842dc8f681f6b89499129f5b64a50d0e4587935'), exch=rp('a6be22fa168fcd0a40971383d8ffb3f1adb9731d'),
               zips=[(f'{B}/fills/seq-zk/final-r1/review-evidence.zip', ['build/results.jsonl'],
                      'the seq-zk review build (303 modules, at e9b5ea47)')]),
}[gate]
HEAD, PR = rp(CFG['head']), CFG['pr']
assert OPEN[PR] == HEAD, (PR, OPEN[PR], HEAD)
for k, v in MERGED.items():
    assert R.anc(v, TIP), (k, 'not in the tip')
    assert R.anc(MCOMMIT[k], TIP) and rp(MCOMMIT[k] + '^2') == v, (k, 'merge commit')
BASE = rp(R.git('merge-base', HEAD, TIP).stdout.strip())
lean = R.lean_changed
if CFG['unit'] is None:
    CFG['unit'] = sorted(lean(BASE, HEAD))
UNIT = CFG['unit']
assert sorted(lean(BASE, HEAD)) == sorted(UNIT), sorted(set(lean(BASE, HEAD)) ^ set(UNIT))
CMP = [('tip', TIP)] + [(k, v) for k, v in OPEN.items() if k != PR] + [(f'{k} (merged)', v) for k, v in MERGED.items()]
os.makedirs(out, exist_ok=True)
W = lambda name, L: open(os.path.join(out, name), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
short = lambda p: p.replace('TCSlib/Cryptography/', '').replace('TCSlib/Complexity/', 'Complexity/')


def series(a, b):
    L = []
    for c in R.git('rev-list', '--reverse', f'{a}..{b}').stdout.split():
        o = R.git('cat-file', '-p', c).stdout
        L.append(f'  {c} gpgsig {len(re.findall(r"(?m)^gpgsig", o))} | '
                 f'{R.git("log", "-1", "--format=author %an <%ae> | committer %cn <%ce> | %s", c).stdout.strip()}')
    return L


def hdrcmp(old, new_, files, label):
    L = [f'# {label}: every declaration (private included) at {old[:8]} against {new_[:8]}; header = keyword line to '
         f'the top-level := for theorems, the whole block for definitions, with any open/include/omit ... in prefix']
    tot = {}
    for f in files:
        a, b = decls(R.show(old, f)), decls(R.show(new_, f))
        if not a:
            L.append(f'## {short(f)}: new file, {len(b)} declarations'); continue
        same = [n for n in a if n in b and a[n][2] == b[n][2]]
        ch = [n for n in a if n in b and a[n][2] != b[n][2]]
        gone = [n for n in a if n not in b]
        dch = [n for n in a if n in b and a[n][3] != b[n][3]]
        defs = [n for n in a if a[n][0] not in ('theorem', 'lemma') and n in b]
        L.append(f'## {short(f)}: {len(a)} -> {len(b)}; headers identical {len(same)}, differing {ch}, removed {gone}, '
                 f'new {[n for n in b if n not in a]}; order kept {[n for n in b if n in a] == [n for n in a if n in b]}; '
                 f'docstrings changed {dch}; definition blocks {sum(a[n][2] == b[n][2] for n in defs)}/{len(defs)} '
                 f'identical')
        tot[f] = (a, b, ch, gone, dch)
    return L, tot


def doc_only(a, b, label):
    fs = lean(a, b)
    L = [f'{label} {a[:8]}..{b[:8]}: {len(fs)} files; numstat {R.git("diff", "--numstat", a, b).stdout.split()}']
    tot = 0
    for p in fs:
        x, y = R.show(a, p), R.show(b, p)
        dx, dy = docs(x), docs(y)
        n = sum(u != v for u, v in zip(dx, dy)) if len(dx) == len(dy) else None
        tot += n or 0
        L.append(f'  {short(p)}: identical with doc comments deleted: {blank_docs(x) == blank_docs(y)}; docstrings '
                 f'{len(dx)} -> {len(dy)}, changed {n}; lines {len(x.splitlines())} -> {len(y.splitlines())}; max width '
                 f'{max(len(l) for l in y.splitlines())}')
    L.append(f'  docstrings changed in total: {tot}')
    return L


def edit_report(a, b, label):
    fs = lean(a, b)
    d = R.git('diff', '-U0', a, b).stdout
    L = [f'{label} {a[:8]}..{b[:8]}: files {[short(f) for f in fs]}; numstat '
         f'{R.git("diff", "--numstat", a, b).stdout.split()}']
    for p in fs:
        x, y = decls(R.show(a, p)), decls(R.show(b, p))
        L.append(f'  {p.split("/")[-1]}: declarations {len(x)} -> {len(y)}; removed {[n for n in x if n not in y]}; '
                 f'added {[n for n in y if n not in x]}; headers differing '
                 f'{[n for n in x if n in y and x[n][2] != y[n][2]]}; docstrings changed '
                 f'{[n for n in x if n in y and x[n][3] != y[n][3]]}; order kept '
                 f'{[n for n in y if n in x] == [n for n in x if n in y]}; code identical with doc comments deleted '
                 f'{blank_docs(R.show(a, p)) == blank_docs(R.show(b, p))}')
        ia, ib = re.findall(r'(?m)^import .*', R.show(a, p)), re.findall(r'(?m)^import .*', R.show(b, p))
        L.append(f'    imports identical {ia == ib}; added {[i for i in ib if i not in ia]}; removed '
                 f'{[i for i in ia if i not in ib]}')
    return L, d


def code_hunks(a, b, files):
    """the -/+ lines of git diff a b on files after deleting doc and module comments from both sides."""
    import difflib
    L = []
    for p in files:
        x, y = blank_docs(R.show(a, p)).splitlines(), blank_docs(R.show(b, p)).splitlines()
        dl = [l for l in difflib.unified_diff(x, y, lineterm='', n=0) if l[:1] in '+-' and not l.startswith(('+++', '---'))]
        L.append(f'  {short(p)}: {len(dl)} code lines differ after deleting doc and module comments')
        L += ['    ' + l for l in dl]
    return L


# 1. merge trees ---------------------------------------------------------------------------------------------------
L = [f'PR {PR} ({CFG["name"]}) head {HEAD}; merge base with the tip {TIP} ({TIPREF}): {BASE}',
     f'{PR} changed .lean paths ({BASE[:8]}..head, {len(UNIT)}): {[short(p) for p in sorted(lean(BASE, HEAD))]}',
     f'tip .lean delta since the merge base ({BASE[:8]}..{TIP[:8]}, {len(lean(BASE, TIP))} files)',
     'open PR heads (origin branch refs at the time of this check): ' + ', '.join(f'{k} {v}' for k, v in OPEN.items()),
     'merged PR heads (each an ancestor of the tip, second parent of its merge commit): '
     + ', '.join(f'{k} {v} (merge {MCOMMIT[k][:8]})' for k, v in MERGED.items()), '']
trees, changed, mb = {}, {}, {}
for k, v in CMP:
    mb[k] = rp(R.git('merge-base', HEAD, v).stdout.strip())
    changed[k] = lean(mb[k], v)
    t, rc, raw = R.mergetree(HEAD, v); trees[k] = t
    L.append(f'git merge-tree --write-tree {HEAD} {v} ({k}): tree {t} rc {rc} ({"clean" if rc == 0 else "CONFLICT"})')
    if rc:
        L.append(raw)
    dh = [p for p in R.git('diff', '--name-only', HEAD, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    do = [p for p in R.git('diff', '--name-only', v, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    L.append(f'  Lean paths of the merged tree differing from the {PR} head: {len(dh)}; from {k}: {len(do)}, of them '
             f'{PR} unit files {len(set(do) & set(UNIT))}/{len(UNIT)}')
    shared = sorted(set(changed[k]) & set(UNIT))
    L.append(f'  merge base {mb[k]}; {k} changed .lean paths from it: {len(changed[k])}; shared with {PR}: {shared}')
W('mergetrees.txt', L)

# 2. downstream ----------------------------------------------------------------------------------------------------
gh = R.graph(HEAD)
uclo = set().union(*[closure(gh, [p]) for p in UNIT])
L = [f'# import graph at the {PR} head {HEAD[:8]} (TCSlib and audits modules); a module counts as downstream of itself',
     f'unit modules: {len(UNIT)}; union of their import closures: {len(uclo)} modules']
shared_down = {}
for k, v in CMP:
    ch = set(changed[k])
    L.append(f'{k} ({v[:8]}): its changed modules (from the merge base {mb[k][:8]}) inside the unit closure: '
             f'{[short(p) for p in sorted(ch & uclo)]}')
    gm = R.graph(trees[k])
    both = sorted(downstream(gm, set(UNIT)) & downstream(gm, ch - set(UNIT)))
    shared_down[k] = both
    L.append(f'  merged tree {trees[k][:8]}: {len(both)} modules downstream of both a {PR} module and a {k} module'
             + (f': {[short(p[:-5]) for p in both]}' if len(both) <= 40 else f' (first 40: '
                f'{[short(p[:-5]) for p in both[:40]]})'))
W('downstream.txt', L)

# 3. names ---------------------------------------------------------------------------------------------------------
new = sorted({n for p in UNIT for n in NM.findall(R.show(HEAD, p))} - {n for p in UNIT for n in NM.findall(R.show(BASE, p))})
L = [f'# the {len(new)} declaration names new at the head (short names as written) against the declarations of the '
     f'.lean files each comparator changed since its merge base with the head (unit files excluded)']
for k, v in CMP:
    hits = []
    for p in changed[k]:
        if p in UNIT:
            continue
        for i, l in enumerate(R.show(v, p).splitlines()):
            m = NM.match(l)
            if m and m.group(1) in new:
                hits.append(f'{p}:{i + 1}: {l.strip()[:120]}')
    L.append(f'{k} ({len(changed[k])} changed files): {len(hits)} declarations with a new name')
    L += ['    ' + h for h in hits]
W('namecheck.txt', L)

# 4. the combined build and the current tip --------------------------------------------------------------------------
zp = INT['zip']
zb = open(os.path.join(repo_path, zp), 'rb').read()
z = zipfile.ZipFile(io.BytesIO(zb))
rows = [json.loads(l) for l in z.read(INT['part']).decode().splitlines() if l.strip()]
mods = [x for x in rows if 'module' in x]
final = {}
for x in mods:
    final[x['module']] = x
L = [f'# the combined integration build of all open PRs ({zp}, SHA-256 {hashlib.sha256(zb).hexdigest()})',
     f'{INT["part"]}: {len(mods)} module records (the main build 694 + the 21-module #324 rebuild after LE-gate37; later '
     f'records override earlier), {len(final)} modules; rc 0 {sum(x["rc"] == 0 for x in final.values())}; errors '
     f'{sum(x["errors"] for x in final.values())}; substring "error" {sum(x.get("error_substr", 0) for x in final.values())}',
     f'built tree {INT["tree"]} (scratch commit {INT["commit"][:8]} = records tip {INT["rtip"][:8]} + #318, #319, #323, '
     f'#324 at 4bd2d80b, #326, #327); its parents: {R.git("log", "-1", "--format=%P", INT["commit"]).stdout.strip()}',
     f'records tip of that build {INT["rtip"]} -> current tip {TIP}: first-parent merges in between: '
     + '; '.join(R.git('log', '--first-parent', '--merges', '--format=%h %s', f'{INT["rtip"]}..{TIP}').stdout.splitlines())]
d0 = [p for p in R.git('diff', '--name-only', INT['rtip'], TIP).stdout.split()]
lp = [p for p in d0 if p.startswith(('TCSlib/', 'audits/'))]
mu = set().union(*[set(lean(rp(R.git('merge-base', v, INT['rtip']).stdout.strip()), v)) for v in MERGED.values()])
L.append(f'  paths changed {INT["rtip"][:8]}..{TIP[:8]}: {len(d0)}; under TCSlib/ or audits/: {len(lp)}, all changed by '
         f'#318, #319 or #323 (from their merge bases with {INT["rtip"][:8]}): {set(lp) <= mu} ({len(mu)} such paths); '
         f'every other path is a record (under briefs/ or a *Plan.md): '
         f'{all(p.startswith("briefs/") or p.endswith("Plan.md") for p in d0 if p not in lp)}')
orders = {}
for perm in itertools.permutations(OPEN):
    cur = TIP; chain = []
    for k in perm:
        t, rc, _ = R.mergetree(cur, OPEN[k])
        assert rc == 0, (perm, k)
        cur = R.git('commit-tree', '--no-gpg-sign', '-p', cur, '-p', OPEN[k], '-m', f'scratch {k}', t).stdout.strip()
        chain.append(t)
    orders[perm] = chain
    same = all(rp(f'{chain[-1]}:{s}') == rp(f'{INT["tree"]}:{s}') for s in ('TCSlib', 'audits'))
    L.append(f'tip {TIP[:8]} + {" + ".join(perm)} (git merge-tree chain, unsigned scratch commits on no ref): trees '
             f'{[t[:8] for t in chain]}, every step clean; final TCSlib and audits subtrees = the built tree '
             f'{INT["tree"][:8]}\'s: {same}')
fin = orders[('#324', '#326', '#327')][-1]
dd = R.git('diff', '--name-only', INT['tree'], fin).stdout.split()
L.append(f'  the final merged tree {fin[:8]} differs from the built tree {INT["tree"][:8]} in {len(dd)} paths, all records '
         f'(briefs/ or a *Plan.md): {all(p.startswith("briefs/") or p.endswith("Plan.md") for p in dd)}')
for lab, rev in [('built tree', INT['tree']), ('final merged tree on the current tip', fin), (f'{PR} head', HEAD),
                 (f'{PR} merged with the tip', trees['tip'])]:
    diff = [m for m, x in final.items()
            if hashlib.sha256(R.blob(rev, m + '.lean') or b'').hexdigest() != x['source_sha256']]
    L.append(f'{lab} {rev[:8]}: {len(final) - len(diff)} of the {len(final)} built sources equal, {len(diff)} differ'
             + (f' {[short(m) for m in diff]}' if len(diff) <= 30 else f' (not shown; {len(diff)})'))
um = sorted(set(m + '.lean' for m in final) & set(UNIT))
L.append(f'unit modules built in the combined build: {len(um)}/{len(UNIT)}; unit sources equal to the head: '
         f'{all(hashlib.sha256(R.blob(HEAD, p)).hexdigest() == final[p[:-5]]["source_sha256"] for p in um)}')
L.append('intermediate states not built as such: tip + #326, tip + #327, tip + #326 + #327 and every state with #324 '
         'before the last merge; the combined build covers the state after the last merge, in every order (above).')
W('integration.txt', L)

# 5. source equality of the unit's own build -----------------------------------------------------------------------
L = []
for zp, parts, lab in CFG['zips']:
    zb = open(os.path.join(repo_path, zp), 'rb').read()
    z = zipfile.ZipFile(io.BytesIO(zb))
    fin_ = {}
    L.append(f'{zp} (SHA-256 {hashlib.sha256(zb).hexdigest()}), {lab}:')
    for part in parts:
        rr = [json.loads(l) for l in z.read(part).decode().splitlines() if l.strip()]
        mm = [x for x in rr if 'module' in x]
        L.append(f'  {part}: {len(mm)} module records, rc 0 {sum(x["rc"] == 0 for x in mm)}, errors '
                 f'{sum(x["errors"] for x in mm)}, substring "error" {sum(x.get("error_substr", 0) for x in mm)}, last '
                 f'record "done": {"done" in rr[-1]}')
        for x in mm:
            fin_[x['module']] = x
    L.append(f'  modules (later records override earlier): {len(fin_)}; unit modules built: '
             f'{len(set(m + ".lean" for m in fin_) & set(UNIT))}/{len(UNIT)}')
    revs = [('head', HEAD), ('merged with the tip', trees['tip']), ('the final merged tree on the current tip', fin)]
    if gate in ('38', '39'):
        revs = [(f'landing head before LE-doc {CFG["wk"][:8]}', CFG['wk'])] + revs
    for k, rev in revs:
        diff = [m for m, x in fin_.items()
                if hashlib.sha256(R.blob(rev, m + '.lean') or b'').hexdigest() != x['source_sha256']]
        L.append(f'  {k} {rev[:8]}: {len(fin_) - len(diff)} built sources equal, {len(diff)} differ'
                 + (f' {[short(m) for m in diff]}' if len(diff) <= 30 else f' ({len(diff)}; first 30 '
                    f'{[short(m) for m in diff[:30]]})'))
W('srcequality.txt', L)

# 6. duplication scan ------------------------------------------------------------------------------------------------
PAT = re.compile(r'headD_drop\b|getD_eq_getElem\?_getD|getElem\?_ofFn|getD_eq_getElem\b|getElem_ofFn|headD_ofFn|'
                 r'head\?_drop|getD_ofFn|ofFn_succ.*headD|headD.*ofFn_succ|List\.headD_cons|length_le_length_encodeList|'
                 r'length_ofFn_coins|encodeList_cons|encodeList_nil|encodeMsgs_append|length_encodeMsgs_le')


def sig(hdr, name):
    h = [x for x in hdr.split('\n') if not re.match(r'^(open|include|omit)\b', x)]
    s = ws('\n'.join(h))
    i = s.find(name)
    return s[i + len(name):].strip() if i >= 0 else s


L = []
since = R1H = CFG.get('r1head')
if gate == '37':
    L.append(f'# A. every line added or removed since round 1 ({R1H[:8]}..{HEAD[:8]}) in the unit files, doc comments '
             f'deleted on both sides (the docstring changes are G37-03: formulas.txt)')
    L += code_hunks(R1H, HEAD, UNIT)
    nr1 = {n for p in UNIT for n in decls(R.show(R1H, p))}
    nh = {n for p in UNIT for n in decls(R.show(HEAD, p))}
    L.append(f'declarations in the unit files: round 1 {len(nr1)}, head {len(nh)}; new since round 1 {sorted(nh - nr1)}; '
             f'removed since round 1 {sorted(nr1 - nh)}')
L.append(f'# B. lines added {BASE[:8]}..{HEAD[:8]} that use a reading lemma of the DL-47 class, a coin-length or '
         f'encodeList lemma, or the G37-01/02 lemmas')
for p in UNIT:
    d = R.git('diff', '-U0', BASE, HEAD, '--', p).stdout
    ln = 0
    for x in d.splitlines():
        m = re.match(r'@@ -\S+ \+(\d+)', x)
        if m:
            ln = int(m.group(1)); continue
        if x.startswith('+') and not x.startswith('+++'):
            if PAT.search(x):
                L.append(f'  {short(p)}:{ln}: {x[1:].strip()[:140]}')
            ln += 1
newdecl = {}
for p in UNIT:
    a, b = decls(R.show(BASE, p)), decls(R.show(HEAD, p))
    for n, v in b.items():
        if n not in a and v[0] in ('theorem', 'lemma'):
            newdecl[(p, n)] = sig(v[2], n.split('#')[0])
# pools: the tip's .lean files changed since the unit's base (that is #313's and #318/#319/#323's files), the files
# each other open PR changes, and, for every unit, the public statement pools named in the pack
pools = [(f'tip since the base {BASE[:8]}', TIP, [p for p in lean(BASE, TIP) if p not in UNIT])] + \
        [(k, v, [p for p in changed[k] if p not in UNIT]) for k, v in CMP if k in OPEN]
L.append(f'# C. statement scan: each of the {len(newdecl)} theorems new at the head (against the base) compared with '
         f'every theorem of the pools below; a hit = identical binders and type after whitespace normalisation, '
         f'name excluded')
for lab, rev, files in pools:
    hits, n = [], 0
    for p in files:
        for nm, v in decls(R.show(rev, p)).items():
            if v[0] not in ('theorem', 'lemma'):
                continue
            n += 1
            s = sig(v[2], nm.split('#')[0])
            for (up, un), us in newdecl.items():
                if us == s:
                    hits.append(f'    {un} ({short(up)}) = {nm} ({p}:{v[1]})')
    L.append(f'  {lab} ({rev[:8]}): {len(files)} files, {n} theorems scanned; hits {len(hits)}')
    L += hits
# D. whole-tree statement scan at the head: every theorem of every TCSlib file outside the unit
allf = [p for p in R.git('ls-tree', '-r', '--name-only', HEAD, 'TCSlib').stdout.split() if p.endswith('.lean')
        and p not in UNIT]
hits, n = [], 0
idx = {}
for (up, un), us in newdecl.items():
    idx.setdefault(us, []).append((up, un))
for p in allf:
    for nm, v in decls(R.show(HEAD, p)).items():
        if v[0] not in ('theorem', 'lemma'):
            continue
        n += 1
        s = sig(v[2], nm.split('#')[0])
        for up, un in idx.get(s, []):
            hits.append(f'    {un} ({short(up)}) = {nm} ({p}:{v[1]})')
L.append(f'# D. the same scan against every theorem of the {len(allf)} other TCSlib files at the head ({n} theorems): '
         f'hits {len(hits)}')
L += hits
W('dupscan.txt', L)

# ===================================================================================================================
if gate == '37':
    R1B = CFG['r1base']
    L = [f'# the PR series: round-1 head {R1H[:8]} plus LE-gate37, no rebase (base {BASE[:8]} = round-1 base '
         f'{R1B[:8]}: {BASE == R1B})', f'{HEAD[:8]}^ = {rp(HEAD + "^")} (= round-1 head: {rp(HEAD + "^") == R1H}); tree '
         f'{rp(HEAD + "^{tree}")}', f'commits {BASE[:8]}..{HEAD[:8]}:'] + series(BASE, HEAD)
    L.append(f'unit files changed {R1H[:8]}..{HEAD[:8]}: {[short(p) for p in lean(R1H, HEAD)]}')
    L.append(f'the superseded first attempt b49005592be4703d97affc844d88bb28a22a377e on any ref: '
             f'{R.git("branch", "-a", "--contains", "b49005592be4703d97affc844d88bb28a22a377e", check=False).stdout.strip() or "none"}'
             f' (object present locally: {R.git("cat-file", "-t", "b49005592be4703d97affc844d88bb28a22a377e", check=False).returncode == 0})')
    W('rebase.txt', L)
    MA, BO, RU = f'{CSD}/Machines.lean', f'{CSD}/Bounds.lean', f'{CSD}/Runs.lean'
    CL = 'TCSlib/Cryptography/ZeroKnowledge/CommitmentLemmas.lean'
    er, d = edit_report(R1H, HEAD, 'LE-gate37')
    L = ['# LE-gate37 (G37-01/02/03) from git objects'] + er
    L.append('  code lines changed after deleting doc and module comments:')
    L += code_hunks(R1H, HEAD, lean(R1H, HEAD))
    hl, _ = hdrcmp(R1H, HEAD, UNIT, f'round-1 head {R1H[:8]} -> round-2 head')
    L += [''] + hl
    c0, c1 = closure(R.graph(R1H), [MA]), closure(gh, [MA])
    L += ['', f'Machines import closure: round-1 head {len(c0)}, head {len(c1)}; added {len(c1 - c0)}; removed '
              f'{sorted(c0 - c1)}; any added module under ComposeSecurity: {[p for p in c1 - c0 if "ComposeSecurity" in p]}']
    L.append(f'  added: {[short(p[:-5]) for p in sorted(c1 - c0)]}')
    L.append(f'acyclic: any unit module in the import closure of CommitmentLemmas at the head: '
             f'{sorted(set(UNIT) & closure(gh, [CL]))}')
    uc0 = set().union(*[closure(R.graph(R1H), [p]) for p in UNIT])
    L.append(f'unit closure: round-1 head {len(uc0)}, head {len(uclo)}; added {len(uclo - uc0)}; = the Machines additions: '
             f'{uclo - uc0 == c1 - c0}')
    for nm in ('encodeMsgs_append', 'length_encodeMsgs_le'):
        dl = decls(R.show(HEAD, CL)).get(nm)
        L.append(f'TCSlib.Cryptography.CommitmentLemmas.{nm}: {short(CL)}:{dl[1] if dl else None}: '
                 f'{ws(dl[2])[:220] if dl else None}; CommitmentLemmas blob head = tip: '
                 f'{R.blob(HEAD, CL) == R.blob(TIP, CL)}; = round-1 base: {R.blob(HEAD, CL) == R.blob(R1B, CL)}')
    for f, nm in ((MA, 'encodeMsgs_append'), (BO, 'length_encodeMsgs_le')):
        x, y = decls(R.show(R1H, f))[nm], decls(R.show(HEAD, f))[nm]
        L.append(f'{short(f)} {nm}: header identical {x[2] == y[2]}; header {ws(y[2])[:200]}')
    W('lecheck.txt', L)
    # splitCoins
    CH = 'TCSlib/Cryptography/Asymptotic/CollectionsHelpers.lean'
    L = ['# the splitCoins qualification in Runs.lean (the LE-gate37 side effect)',
         f'CollectionsHelpers in the import closure of Runs: at the round-1 head {CH in closure(R.graph(R1H), [RU])}; at '
         f'the head {CH in closure(gh, [RU])}']
    for rev, lab in [(R1H, 'round-1 head'), (HEAD, 'head')]:
        cl = closure(R.graph(rev), [RU])
        hs = []
        for p in sorted(cl):
            for i, l in enumerate(R.show(rev, p).splitlines()):
                m = NM.match(l)
                if m and m.group(1).split('.')[-1] == 'splitCoins':
                    hs.append(f'{short(p)}:{i + 1}: {l.strip()[:110]}')
        L.append(f'declarations named splitCoins in the import closure of Runs (itself included) at the {lab} '
                 f'({len(cl)} modules): {hs}')
    nsl = []
    for p in R.git('ls-tree', '-r', '--name-only', HEAD, 'TCSlib').stdout.split():
        if p.endswith('.lean'):
            for i, l in enumerate(R.show(HEAD, p).splitlines()):
                if re.match(r'\s*namespace\s+\S*ComposeSim\b', l):
                    nsl.append(f'{short(p)}:{i + 1}: {l.strip()}')
    L.append(f'namespace lines naming ComposeSim anywhere in TCSlib at the head: {nsl}')
    rt0, rt1 = R.show(R1H, RU), R.show(HEAD, RU)
    L.append(f'Runs.lean: the namespace around line 52 at the head: '
             f'{[l for l in rt1.splitlines()[:60] if l.startswith(("namespace", "end ", "open"))]}')
    occ = [(i + 1, l.strip()) for i, l in enumerate(rt1.splitlines()) if 'ComposeSim.splitCoins' in l]
    L.append(f'occurrences of ComposeSim.splitCoins in Runs.lean at the head: {len(occ)}')
    dh = decls(rt1)
    for i, l in occ:
        owner = max([(v[1], n) for n, v in dh.items() if v[1] <= i] or [(0, 'the module docstring')])
        L.append(f'  line {i} (in {owner[1]}, line {owner[0]}): {l[:110]}')
    replaced = rt1.replace('ComposeSim.splitCoins', 'splitCoins')
    L.append(f'Runs.lean at the head with each "ComposeSim.splitCoins" written back as "splitCoins" = the round-1 file '
             f'with doc comments deleted on both sides: {blank_docs(replaced) == blank_docs(rt0)}')
    d0, d1 = decls(rt0), decls(rt1)
    for n in ('composeCoins', 'composeCoins_fst', 'composeCoins_snd'):
        L.append(f'  {n}: header identical {d0[n][2] == d1[n][2]}; identical after the write-back '
                 f'{d0[n][2] == d1[n][2].replace("ComposeSim.splitCoins", "splitCoins")}; docstring identical '
                 f'{d0[n][3] == d1[n][3]}; docstring mentions: {re.findall(r"[A-Za-z.]*splitCoins", d1[n][3])}')
    users = R.git('grep', '-n', '-w', '-E', 'composeCoins_fst|composeCoins_snd', HEAD, '--', 'TCSlib', check=False).stdout
    L.append('uses of composeCoins_fst / composeCoins_snd at the head (outside docstrings not distinguished): '
             + '; '.join(sorted({x.split(':')[1].split('/')[-1] + ':' + x.split(':')[2] for x in users.splitlines()})))
    W('splitcoins.txt', L)
    # G37-03 formulas
    L = ['# G37-03: the docstrings LE-gate37 changes (doc comments only outside Machines, Bounds and Runs code above)']
    tot = 0
    eleven = ['asmView_eq', 'asmW_eq', 'runW_eq', 'ansW_eq', 'composePW_eq', 'composeVW_eq', 'goodRuns_iff', 'sampleA_eq',
              'sampleB_eq', 'phiV_eq', 'hybW_eq']
    seen = {}
    for p in lean(R1H, HEAD):
        x, y = decls(R.show(R1H, p)), decls(R.show(HEAD, p))
        ch = [n for n in x if n in y and x[n][3] != y[n][3]]
        tot += len(ch)
        for n in ch:
            cut = ' …`' in x[n][3] or '…`' in x[n][3]
            seen[n] = (p, cut, '…`' in y[n][3])
        L.append(f'  {short(p)}: docstrings changed {ch}')
    L.append(f'docstrings changed in total: {tot}; of them truncated ("…`") at round 1: '
             f'{sum(v[1] for v in seen.values())}; still truncated at the head: {[n for n, v in seen.items() if v[2]]}')
    L.append(f'the eleven G37-03 readers all changed: {all(n in seen for n in eleven)}; the other changed docstrings: '
             f'{[n for n in seen if n not in eleven]}')
    alltr = []
    for p in UNIT:
        for n, v in decls(R.show(R1H, p)).items():
            if '…`' in v[3]:
                alltr.append(n)
    L.append(f'round-1 docstrings in the unit with a formula ending in "…`" (the LE-doc cut): {len(alltr)}: {alltr}')
    rem = []
    for p in UNIT:
        for i, l in enumerate(R.show(HEAD, p).splitlines()):
            if '…' in l:
                rem.append(f'{p.split("/")[-1]}:{i + 1}: {l.strip()[:100]}')
    L.append(f'lines with "…" left in the unit at the head: {len(rem)}; with "…`": {sum("…`" in r for r in rem)}')
    L += ['    ' + r for r in rem]
    W('formulas.txt', L)

if gate in ('38', '39'):
    ISS, WK, WKH, EX = CFG['issue'], CFG['wk'], CFG['wkhead'], CFG['exch']
    L = ['# the landing: rebase identity, the worker src/, the signatures']
    r = R.git('range-diff', f'{ISS}..{WKH}', f'{BASE}..{WK}').stdout
    L.append(f'git range-diff {ISS[:8]}..{WKH[:8]} (the worker series at the issue base) {BASE[:8]}..{WK[:8]} '
             f'(the landing before LE-doc):')
    L += ['  ' + x for x in r.splitlines()]
    eq = [R.blob(EX, f'inbox/fills/{CFG["name"]}/src/{p}') == R.blob(WK, p) for p in UNIT]
    eqw = [R.blob(EX, f'inbox/fills/{CFG["name"]}/src/{p}') == R.blob(WKH, p) for p in UNIT]
    src = R.git('ls-tree', '-r', '--name-only', EX, f'inbox/fills/{CFG["name"]}/src').stdout.split()
    L.append(f'worker src/ (exchange {EX[:8]}, {len(src)} files) = the landing before LE-doc {WK[:8]}: {sum(eq)}/{len(UNIT)}; '
             f'= the worker head {WKH[:8]}: {sum(eqw)}/{len(UNIT)}; src/ paths = the unit: '
             f'{sorted(p.split("/src/", 1)[1] for p in src) == sorted(UNIT)}')
    L.append(f'the {len(UNIT)} paths at the issue base = at the landing base {BASE[:8]}: '
             f'{all(R.blob(ISS, p) == R.blob(BASE, p) for p in UNIT)}')
    L.append(f'.lean delta issue base {ISS[:8]} -> landing base {BASE[:8]}: {len(lean(ISS, BASE))} files')
    L.append(f'commits {BASE[:8]}..{HEAD[:8]}:')
    L += series(BASE, HEAD)
    W('rebase.txt', L)
    hl, tot = hdrcmp(ISS, HEAD, CFG['frozen'], f'issue base {ISS[:8]} -> head (the pre-existing files)')
    W('headers.txt', hl)
    L = ['# LE-doc from git objects'] + doc_only(WK, HEAD, 'LE-doc')
    hl2, _ = hdrcmp(WK, HEAD, lean(WK, HEAD), f'LE-doc: {WK[:8]} -> {HEAD[:8]}')
    L += [''] + hl2
    W('lecheck.txt', L)


def text_of(rev, path, name):
    """the declaration's text from its keyword line up to the next declaration, docstring, module comment or
    namespace/section line, trailing blank lines dropped."""
    t = R.show(rev, path).split('\n'); d = decls('\n'.join(t))
    i = d[name][1] - 1
    starts = sorted(v[1] - 1 for v in d.values() if v[1] - 1 > i)
    blk = t[i:starts[0] if starts else len(t)]
    for k in range(1, len(blk)):
        if re.match(r'^(end\b|namespace\b|section\b|/-!|/--)', blk[k]):
            blk = blk[:k]; break
    return '\n'.join(blk).rstrip()


if gate == '38':
    DT, IF, CLS = 'TCSlib/Complexity/ClassP/DTIME.lean', f'{RND}/Build/IterateFind.lean', f'{RND}/Classes.lean'
    L = ['# the shared (frozen, non-owned) files: exactly E1-E3 and SR-01']
    exp = {DT: ['mem_DTIME_iff', 'decidesInTime_iff'], IF: ['computesFunInTime_find'], CLS: ['inBPP_iff']}
    for f in (DT, IF, CLS):
        a, b = decls(R.show(ISS, f)), decls(R.show(HEAD, f))
        added = [n for n in b if n not in a]
        ns = R.git('diff', '--numstat', ISS, HEAD, '--', f).stdout.split()
        L.append(f'{short(f)}: declarations {len(a)} -> {len(b)}; added {added} (= {exp[f]}: {sorted(added) == sorted(exp[f])}); '
                 f'removed {[n for n in a if n not in b]}; numstat +{ns[0]}/-{ns[1]}; lines '
                 f'{len(R.show(ISS, f).splitlines())} -> {len(R.show(HEAD, f).splitlines())}; max width '
                 f'{max(len(l) for l in R.show(HEAD, f).splitlines())}')
        hs = R.git('diff', '-U0', ISS, HEAD, '--', f).stdout
        L.append(f'  hunks {re.findall(r"(?m)^@@ .*? @@", hs)}')
        bl = R.show(ISS, f).splitlines(keepends=True)
        hl_ = R.show(HEAD, f).splitlines(keepends=True)
        import difflib
        sm = difflib.SequenceMatcher(a=bl, b=hl_, autojunk=False)
        ops = [o for o in sm.get_opcodes() if o[0] != 'equal']
        L.append(f'  the base file is the head file with lines inserted only (no base line deleted or replaced): '
                 f'{all(o[0] == "insert" for o in ops)}; insertions {[(o[3] + 1, o[4] - o[3]) for o in ops]}')
        for n in exp[f]:
            v = b[n]
            L.append(f'  {n}: line {v[1]}; header {ws(v[2])[:300]}')
            L.append(f'    docstring {ws(v[3])[:300]}')
    for n in ('polyTimeComputable_find', 'final_bound'):
        t0, t1 = text_of(ISS, IF, n), text_of(HEAD, IF, n)
        L.append(f'{short(IF)} {n}: whole text (keyword to the next declaration) byte-identical at the issue base and the '
                 f'head: {t0 == t1} ({len(t1.splitlines())} lines; header line {decls(R.show(HEAD, IF))[n][1]})')
    br = R.show(TIP, f'{B}/fills/derand/issued-r2/brief.md')
    blk = re.search(r'Draft signatures for E2 and E3.*?```lean\n(.*?)```', br, flags=re.S).group(1)
    dr = {m.group(1): ws(m.group(0)) for m in re.finditer(r'theorem (\w+).*?Iff\.rfl', blk, flags=re.S)}
    for n in ('decidesInTime_iff', 'mem_DTIME_iff'):
        hd = R.show(HEAD, DT)
        m = re.search(r'theorem ' + n + r'\b.*?Iff\.rfl', hd, flags=re.S)
        L.append(f'E2/E3 {n}: the head text (theorem ... Iff.rfl) = the brief\'s draft (issued-r2/brief.md), whitespace-'
                 f'normalised: {ws(m.group(0)) == dr[n]}')
    pat = R.show(EX, 'inbox/fills/derand/evidence/worker/scope-request/SR-01/scope-inbpp-reader.patch')
    pplus = [x[1:] for x in pat.splitlines() if x.startswith('+') and not x.startswith('+++')]
    d = R.git('diff', '-U0', ISS, WK, '--', CLS).stdout
    plus = [x[1:] for x in d.splitlines() if x.startswith('+') and not x.startswith('+++')]
    L.append(f'SR-01: Classes.lean lines added issue base -> {WK[:8]} (before LE-doc) = the scope-request patch\'s added lines '
             f'(exchange {EX[:8]}, evidence/worker/scope-request/SR-01/scope-inbpp-reader.patch): {plus == pplus} '
             f'({len(plus)} lines); code of the patch = code at the head (doc comments deleted): '
             f'{[l for l in blank_docs(chr(10).join(plus)).splitlines() if l.strip()] == [l for l in blank_docs(chr(10).join([x[1:] for x in R.git("diff", "-U0", ISS, HEAD, "--", CLS).stdout.splitlines() if x.startswith("+") and not x.startswith("+++")])).splitlines() if l.strip()]}')
    own = [f'{RND}/SeedMajority.lean', f'{DER}.lean']
    for f in own:
        a, b = decls(R.show(ISS, f)), decls(R.show(HEAD, f))
        L.append(f'owned {short(f)}: declarations {len(a)} -> {len(b)}; added {[n for n in b if n not in a]}; imports added '
                 f'{[i for i in re.findall(r"(?m)^import .*", R.show(HEAD, f)) if i not in re.findall(r"(?m)^import .*", R.show(ISS, f))]}')
    newf = [p for p in UNIT if R.blob(ISS, p) is None]
    L.append(f'new files ({len(newf)}): {[short(p) for p in newf]}; all under Randomized/SeedMajority/ or '
             f'Randomness/Derandomization/: {all(p.startswith((RND + "/SeedMajority/", DER + "/")) for p in newf)}')
    W('shared.txt', L)
    # Rule 10 attribution of F-01
    zb = open(os.path.join(repo_path, CFG['zips'][0][0]), 'rb').read()
    z = zipfile.ZipFile(io.BytesIO(zb))
    L = ['# Rule 10 (F-01, ruled debt, DW-5): the failing seal lines mapped to declarations from git objects']
    sl = z.read('logs/seal-iteratefind-lines.txt').decode()
    dh = decls(R.show(HEAD, IF))
    L.append(f'IterateFind.lean blob: head = {WK[:8]} (the sealed tree, = d34fbf09): {R.blob(HEAD, IF) == R.blob(WK, IF)}; '
             f'= d34fbf09: {R.blob(HEAD, IF) == R.blob(rp("d34fbf097067ea94086295ec8b8ee1f5fe7495b7"), IF)}')
    for var in ('A', 'B'):
        m = re.search(rf'(?m)^{var} errors (\d+) polyTimeComputable_find src lines \[([^\]]*)\] E1 src lines \[([^\]]*)\]', sl)
        tot_, l1, l2 = int(m.group(1)), [int(x) for x in m.group(2).split(',')], [int(x) for x in m.group(3).split(',')]
        own_ = lambda ln: max((v[1], n) for n, v in dh.items() if v[1] <= ln)[1]
        L.append(f'seal {var}: {tot_} errors; lines {l1} -> declarations {sorted(set(own_(x) for x in l1))} ({len(l1)}); '
                 f'lines {l2} -> {sorted(set(own_(x) for x in l2))} ({len(l2)}); total {len(l1) + len(l2)} = {tot_}: '
                 f'{len(l1) + len(l2) == tot_}')
    bl = decls(R.show(ISS, IF))
    m = re.search(r'(?m)^A errors \d+ polyTimeComputable_find src lines \[([^\]]*)\]', sl)
    L.append(f'polyTimeComputable_find at the issue base starts at line {bl["polyTimeComputable_find"][1]} and at the head '
             f'at {dh["polyTimeComputable_find"][1]} (the base failures are at the same lines: E1 is inserted after it)')
    for t in ('logs/seal-head-seals-coe-A.tsv', 'logs/seal-head-seals-coe-B.tsv', 'logs/seal-head-seals-A.tsv',
              'logs/seal-head-seals-B.tsv', 'logs/seal-base-seals-coe-A.tsv', 'logs/seal-base-seals-A.tsv'):
        rr = [l.split('\t') for l in z.read(t).decode().splitlines() if l.strip()]
        bad = [(r[0], r[3], r[6] if len(r) > 6 else '') for r in rr if r[3] != '0']
        L.append(f'{t} (columns: probe, requests, rc, errors, install, EOF, failing declarations): {len(rr)} probe '
                 f'rows; requests {sum(int(r[1]) for r in rr)}; rows with errors: {bad}; install and EOF records in '
                 f'every row: {all(r[4:6] == ["1", "1"] for r in rr)}')
    L.append('the seal table (logs/seal-table.txt), as delivered:')
    L += ['  ' + x for x in z.read('logs/seal-table.txt').decode().splitlines()[11:31]]
    W('rule10.txt', L)

if gate == '39':
    DF, SZ = 'TCSlib/Cryptography/ZeroKnowledge/Defs.lean', f'{SQZ}.lean'
    L = ['# the shared frozen file ZeroKnowledge/Defs.lean: exactly StatZK_iff (S-01)']
    a, b = decls(R.show(ISS, DF)), decls(R.show(HEAD, DF))
    ns = R.git('diff', '--numstat', ISS, HEAD, '--', DF).stdout.split()
    L.append(f'{short(DF)}: declarations {len(a)} -> {len(b)}; added {[n for n in b if n not in a]}; removed '
             f'{[n for n in a if n not in b]}; numstat +{ns[0]}/-{ns[1]}; lines {len(R.show(ISS, DF).splitlines())} -> '
             f'{len(R.show(HEAD, DF).splitlines())}')
    import difflib
    sm = difflib.SequenceMatcher(a=R.show(ISS, DF).splitlines(), b=R.show(HEAD, DF).splitlines(), autojunk=False)
    ops = [o for o in sm.get_opcodes() if o[0] != 'equal']
    L.append(f'  lines inserted only: {all(o[0] == "insert" for o in ops)}; insertions {[(o[3] + 1, o[4] - o[3]) for o in ops]}')
    v = b['StatZK_iff']
    L.append(f'  StatZK_iff: line {v[1]}; header {ws(v[2])}')
    L.append(f'  docstring at the head: {ws(v[3])}')
    pat = R.show(EX, 'inbox/fills/seq-zk/evidence/scope-request/StatZK-iff.patch')
    pplus = [x[1:] for x in pat.splitlines() if x.startswith('+') and not x.startswith('+++')]
    d = R.git('diff', '-U0', ISS, WK, '--', DF).stdout
    plus = [x[1:] for x in d.splitlines() if x.startswith('+') and not x.startswith('+++')]
    L.append(f'S-01: Defs.lean lines added issue base -> {WK[:8]} (before LE-doc) = the scope-request patch\'s added lines '
             f'(exchange {EX[:8]}): {plus == pplus}; equal after dropping blank lines: '
             f'{[x for x in plus if x.strip()] == [x for x in pplus if x.strip()]}; the patch\'s non-blank code lines = the '
             f'head\'s (doc comments deleted): '
             f'{[l for l in blank_docs(chr(10).join(pplus)).splitlines() if l.strip()] == [l for l in blank_docs(chr(10).join([x[1:] for x in R.git("diff", "-U0", ISS, HEAD, "--", DF).stdout.splitlines() if x.startswith("+") and not x.startswith("+++")])).splitlines() if l.strip()]}')
    sa, sb = decls(R.show(ISS, SZ)), decls(R.show(HEAD, SZ))
    T5 = ['ZK.seqRep', 'StatZK.seqRep', 'InteractiveProof.seqRep', 'InteractiveProofErr.seqRep',
          'EfficientProverProofErr.seqRep']
    L.append(f'owned {short(SZ)}: declarations {len(sa)} -> {len(sb)}; added {[n for n in sb if n not in sa]}')
    for n in T5:
        x, y = sa[n], sb[n]
        L.append(f'  target {n}: line {y[1]}; header byte-identical {x[2] == y[2]}; body at the head has no sorry: '
                 f'{"sorry" not in text_of(HEAD, SZ, n).split(":=", 1)[-1]}; docstring changed {x[3] != y[3]}; '
                 f'docstring unchanged by LE-doc: {decls(R.show(WK, SZ))[n][3] == y[3]}')
    newf = [p for p in UNIT if R.blob(ISS, p) is None]
    L.append(f'new files ({len(newf)}), all under Composability/SequentialZK/: {all(p.startswith(SQZ + "/") for p in newf)}; '
             f'largest {max((len(R.show(HEAD, p).splitlines()), short(p)) for p in UNIT)}; max width '
             f'{max(max(len(l) for l in R.show(HEAD, p).splitlines()) for p in UNIT)}')
    md = R.show(HEAD, SZ)
    i = md.find('**Deviations**')
    L.append('the owned file\'s module docstring, Deviations (at the head):')
    L += ['  ' + x for x in md[i:i + 2400].splitlines()[:22]]
    W('shared.txt', L)
    zb = open(os.path.join(repo_path, CFG['zips'][0][0]), 'rb').read()
    z = zipfile.ZipFile(io.BytesIO(zb))
    L = ['# Rule 10: only the pre-existing ZeroKnowledge/Defs failures']
    for t in ('logs/seal-head-seals-coe-A.tsv', 'logs/seal-head-seals-coe-B.tsv', 'logs/seal-head-seals-A.tsv',
              'logs/seal-head-seals-B.tsv', 'logs/seal-base-seals-coe-A.tsv', 'logs/seal-base-seals-A.tsv'):
        rr = [l.split('\t') for l in z.read(t).decode().splitlines() if l.strip()]
        bad = [(r[0], r[3], r[6] if len(r) > 6 else '') for r in rr if r[3] != '0']
        L.append(f'{t} (columns: probe, requests, rc, errors, install, EOF, failing declarations): {len(rr)} probe '
                 f'rows; requests {sum(int(r[1]) for r in rr)}; rows with errors: {bad}; install and EOF records in '
                 f'every row: {all(r[4:6] == ["1", "1"] for r in rr)}')
    L += ['logs/seal-defs-base-vs-head.txt, as delivered:'] + ['  ' + x for x in
                                                              z.read('logs/seal-defs-base-vs-head.txt').decode().splitlines()]
    dh, db = decls(R.show(HEAD, DF)), decls(R.show(ISS, DF))
    six = re.findall(r"'TCSlib\.Cryptography\.([^']+)'", z.read('logs/seal-defs-base-vs-head.txt').decode())
    six = sorted(set(six))
    key = lambda n, d: n if n in d else n.split('.')[-1]
    L.append(f'the {len(six)} failing declarations at the issue base and the head (header identical, docstring identical, '
             f'line at the head): {[(n, db[key(n, db)][2] == dh[key(n, dh)][2], db[key(n, db)][3] == dh[key(n, dh)][3], dh[key(n, dh)][1]) for n in six]}; '
             f'StatZK_iff among them: {"StatZK_iff" in six}')
    W('rule10.txt', L)

print('OK', gate, BASE[:8], {k: (v[:8], len(shared_down[k])) for k, v in trees.items()})
