"""mksources.py <repo> <base> <head> <out-dir> [<suffix>]: sources<suffix>.zip, pr.diff<suffix>.txt and
source-head<suffix>.json (suffix "-r2" for a round-2 pack, "" for a first-round pack, dated 2026-11-16), from git objects only. The ZIP = the import closure (TCSlib modules) at <head> of every .lean file changed
<base>..<head>, directory entries first, then files, each sorted; files deflated (the layout of the earlier packs' sources.zip; with the
selftest date 2026-11-14 this script reproduces gates/29-learning/sources-r2.zip byte for byte from 2b6c2981, checked with --selftest)."""
import hashlib, json, os, re, subprocess, sys, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure


def sources_zip(R, base, head, out, date=(2026, 11, 14, 0, 0, 0)):
    g = R.graph(head)
    changed = [p for p in R.lean_changed(base, head) if R.blob(head, p) is not None]
    clo = sorted(p for p in set().union(*[closure(g, [p]) for p in changed]) if p.startswith('TCSlib'))
    dirs = sorted({'/'.join(p.split('/')[:k]) + '/' for p in clo for k in range(1, p.count('/') + 1)})
    with zipfile.ZipFile(out, 'w') as z:
        for name in dirs + clo:
            zi = zipfile.ZipInfo(name, date_time=date)
            zi.create_system = 3
            if name.endswith('/'):
                zi.external_attr = 0o40755 << 16
                z.writestr(zi, b'')
            else:
                zi.external_attr = 0o100644 << 16
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, R.blob(head, name))
    return clo


def main():
    repo, base, head, out = sys.argv[1:5]
    sfx = sys.argv[5] if len(sys.argv) > 5 else '-r2'
    R = Repo(repo)
    base, head = R.rp(base), R.rp(head)
    os.makedirs(out, exist_ok=True)
    clo = sources_zip(R, base, head, os.path.join(out, f'sources{sfx}.zip'), (2026, 11, 16, 0, 0, 0))
    diff = R.gitb('diff', f'{base}..{head}')
    open(os.path.join(out, f'pr.diff{sfx}.txt'), 'wb').write(diff)
    st = {}
    for l in R.git('diff', '--name-status', '--no-renames', base, head).stdout.splitlines():
        s, p = l.split('\t')
        st[p] = s
    files, deleted = {}, []
    for p in sorted(st):
        if st[p] == 'D':
            deleted.append(p); continue
        b = R.blob(head, p)
        t = b.decode('utf-8')
        files[p] = dict(status=st[p], sha256=hashlib.sha256(b).hexdigest(), lines=len(t.splitlines()),
                        lines_over_100=sum(len(x) > 100 for x in t.splitlines()))
    js = json.dumps(dict(rev=head, files=files, deleted=deleted), indent=1, ensure_ascii=False)
    open(os.path.join(out, f'source-head{sfx}.json'), 'w', encoding='utf-8').write(js)
    print(f'sources{sfx}.zip {len(clo)} files; pr.diff{sfx}.txt {len(diff)} bytes, '
          f'{R.git("diff", "--shortstat", base, head).stdout.strip()}; source-head{sfx}.json {len(files)} files')


if __name__ == '__main__':
    if sys.argv[1] == '--selftest':
        repo, ref, out = sys.argv[2:5]
        R = Repo(repo)
        sources_zip(R, R.rp('6ce4658db08a1dc2a03a149987197660db078011'), R.rp('2b6c29816de4cb1cd0e6b74fa3ae848c9f0f1be9'), out)
        print('selftest sources-r2.zip identical:', open(out, 'rb').read() == open(ref, 'rb').read())
    else:
        main()
