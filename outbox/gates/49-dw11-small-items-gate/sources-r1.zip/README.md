# sources-r1.zip · Gate 49 (DW-11: #351, #352, #365) round 1

Every file is a byte copy of a git blob, written with `git show <rev>:<path>` at staging. The table gives each entry's
SHA-256, its path in this ZIP, and its origin (commit and blob). `TCSlib/Cryptography/` is spelled out.

- `pr351/base-176cfd4a/`: #351's two existing files at its merge base `176cfd4a` (`Relational.lean` is new).
- `pr351/head-dfacac35/`: the three files at #351's head; the merge `cf7d28f7` carries the same blobs.
- `pr352/base-176cfd4a/`, `pr352/head-92dea4f8/`: `Pairing/Group.lean` at #352's merge base and head; the merge
  `463f2244` carries the head blob.
- `pr365/base-5aed9907/`, `pr365/head-5eaddd17/`: `Pairing/Group.lean` at #365's base (equal to #352's head blob) and
  head.
- `context-b31b77f7/`: at the records tip before this pack: `Relational.lean` with #357's bodies (out of scope), the
  `Games` facade, the relatives of the `Relational` lemmas (`Simulate`, `Hopping`, `Tapes`, ETT `Tools`), the ETT file
  holding the private averaging copy (`Forgery.lean:515`, DL-40), and the consumers of the group helpers
  (`BonehBoyenSecurity`, `BonehBoyenSecurity/Coupling`, `BonehBoyenSecurity/Chain`, `KeyExchange/Joux`).
- `mathlib-029db123/`: the two Mathlib files holding the nearest relatives (`orderOf_eq_prime`, `pow_card_eq_one`,
  `pow_injOn_Iio_orderOf`, `pow_mod_card`, `finEquivPowers`, `IsCyclic.unique_zpow_zmod`, `zmodCyclicMulEquiv`), at the
  pinned Mathlib revision (`lake-manifest.json` `029db123ddaa`).
- `references/`: the [BGZ09], [Sho04] and [BB04] transcriptions (`blueprint/src/references/`).

| SHA-256 | Path | Origin |
|---|---|---|
| `dd67d6952d872a95cc03e34f477dace41bcfb96d50a79daa383064a7d64f2693` | `pr351/base-176cfd4a/TCSlib/Cryptography/Games.lean` | git 176cfd4a42ac:TCSlib/Cryptography/Games.lean (blob fb3115e911b5) |
| `a7d79d12d14ae90d88b7eec368afa8f311eb30864ee8c9b9b72f9f75548dee32` | `pr351/base-176cfd4a/TCSlib/Cryptography/Games/Probability.lean` | git 176cfd4a42ac:TCSlib/Cryptography/Games/Probability.lean (blob c27939a1624e) |
| `1ee49c04e9e6d9374e4cc01106dfdb3b3e7429748b149b15c0f6b0e081dbf6b5` | `pr351/head-dfacac35/TCSlib/Cryptography/Games.lean` | git dfacac356ff1:TCSlib/Cryptography/Games.lean (blob ce4a9f308673) |
| `ddbe55e93b89be218836a068686736e35055eb0bb86c301dbd4912db8643a9d7` | `pr351/head-dfacac35/TCSlib/Cryptography/Games/Probability.lean` | git dfacac356ff1:TCSlib/Cryptography/Games/Probability.lean (blob b7e8d3d107e8) |
| `804a4c875318f9173da80d3e3275f309258c50ed72e0aaf9928b65849fa05ae8` | `pr351/head-dfacac35/TCSlib/Cryptography/Games/Relational.lean` | git dfacac356ff1:TCSlib/Cryptography/Games/Relational.lean (blob eee8e19f19a4) |
| `ae72aa9cdda09be12eca8a7512b0cecb00074ce69cef6e1ce0bef1e3dfc8ce9d` | `pr352/base-176cfd4a/TCSlib/Cryptography/Pairing/Group.lean` | git 176cfd4a42ac:TCSlib/Cryptography/Pairing/Group.lean (blob b6464ece3c0e) |
| `59c605e139e467e50631494f692460e73beede743e06f9add501644361af6213` | `pr352/head-92dea4f8/TCSlib/Cryptography/Pairing/Group.lean` | git 92dea4f81267:TCSlib/Cryptography/Pairing/Group.lean (blob 54e63b26349f) |
| `59c605e139e467e50631494f692460e73beede743e06f9add501644361af6213` | `pr365/base-5aed9907/TCSlib/Cryptography/Pairing/Group.lean` | git 5aed99076d2b:TCSlib/Cryptography/Pairing/Group.lean (blob 54e63b26349f) |
| `78a82161d788ca81c88431e9a161dd7c95f6ba250c7d8afcc3e6ddd8b34d6ea2` | `pr365/head-5eaddd17/TCSlib/Cryptography/Pairing/Group.lean` | git 5eaddd171bce:TCSlib/Cryptography/Pairing/Group.lean (blob f9eb3af4ff6b) |
| `aec82c1ce5c060482f43ac056ed5041c521ed7d3866a29c01346551a13ec22da` | `context-b31b77f7/TCSlib/Cryptography/Games/Relational.lean` | git b31b77f7f412:TCSlib/Cryptography/Games/Relational.lean (blob 15015555b353) |
| `d3fec8c9d47effe7097a67e2ad36b15af70ec70e7a47029b02d11f1fd8f85d42` | `context-b31b77f7/TCSlib/Cryptography/Games.lean` | git b31b77f7f412:TCSlib/Cryptography/Games.lean (blob 7cccb7675728) |
| `784ce55a196d5e2664ac6bd1b6967cb68dc7a84697f582fccc2e9f843b72686f` | `context-b31b77f7/TCSlib/Cryptography/Games/Simulate.lean` | git b31b77f7f412:TCSlib/Cryptography/Games/Simulate.lean (blob 93da9a335606) |
| `656d738928553101f6c79a7d1a824f5ece2ebc2857b4c286599abaa46ecc74a4` | `context-b31b77f7/TCSlib/Cryptography/Games/Hopping.lean` | git b31b77f7f412:TCSlib/Cryptography/Games/Hopping.lean (blob 42306c1abc66) |
| `95e3a8a9b32bbb1ef0d28a563b41fde8042da9d539e72b0827438bf0aff896e2` | `context-b31b77f7/TCSlib/Cryptography/Games/Tapes.lean` | git b31b77f7f412:TCSlib/Cryptography/Games/Tapes.lean (blob 895f59a882e6) |
| `df401817642ad35b320b44ce906b20f9105706079a0790b7dc7aaaab102fdf65` | `context-b31b77f7/TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Tools.lean` | git b31b77f7f412:TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Tools.lean (blob e1d041898350) |
| `bbd2c2ef984b5bb7dd572cf80d6e9fd3d83a5fa7e45069a62c2862e0786e8ef7` | `context-b31b77f7/TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Forgery.lean` | git b31b77f7f412:TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Forgery.lean (blob 22595430e18c) |
| `f990a770f605f60a76cd8f49b31b1e51c1734693e934a14167fb6e1a276059a2` | `context-b31b77f7/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity.lean` | git b31b77f7f412:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity.lean (blob 6cc5b644f5e3) |
| `9516779ff19961745aea656a1be89b70b9f762fe41331d63999112624f0bb06c` | `context-b31b77f7/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity/Coupling.lean` | git b31b77f7f412:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity/Coupling.lean (blob da37cf2c998b) |
| `3bc99236758a31d602425123cb5fd730bca4e3c400276a5c43948876513e238e` | `context-b31b77f7/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity/Chain.lean` | git b31b77f7f412:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity/Chain.lean (blob 2b9c5d6aa89c) |
| `61612d85a1c7fd1dcd66f6fabcca23ee25d4a4063e9b93ec738caefc60a49498` | `context-b31b77f7/TCSlib/Cryptography/KeyExchange/Joux.lean` | git b31b77f7f412:TCSlib/Cryptography/KeyExchange/Joux.lean (blob 46d343d26ec5) |
| `09b38bddb6be56b3e44ec39a791dd6d074576e906aea3d3604043a3f38f3b5a7` | `mathlib-029db123/Mathlib/GroupTheory/OrderOfElement.lean` | git 029db123ddaa:Mathlib/GroupTheory/OrderOfElement.lean (blob a38205ebd3a3) |
| `84f86460395d0f462e5407a9377dbb8c7d5ac8fba41397c57cc59e5ac9c06889` | `mathlib-029db123/Mathlib/GroupTheory/SpecificGroups/Cyclic.lean` | git 029db123ddaa:Mathlib/GroupTheory/SpecificGroups/Cyclic.lean (blob 3ce6dd76227d) |
| `1ef9a1c40f5474068bcd602368dfc95cae7d092b8cf7221e9a19be7680d5e68d` | `references/barthe-gregoire-zanella-2009-certified-proofs.md` | git b31b77f7f412:blueprint/src/references/barthe-gregoire-zanella-2009-certified-proofs.md (blob 1fdb4119a452) |
| `3dfc581404fcadc57a5cf62e72040817b9ee278c3bd0cbc43de8bdf0e5bc983f` | `references/shoup-2004-sequences-of-games.md` | git b31b77f7f412:blueprint/src/references/shoup-2004-sequences-of-games.md (blob 31cb114ca128) |
| `46f8f7b187a46a5f8ff3778c4bded10d7504e89c187653e7e4412d211ef244a2` | `references/boneh-boyen-2004-selective-id-ibe.md` | git b31b77f7f412:blueprint/src/references/boneh-boyen-2004-selective-id-ibe.md (blob 5ecaeb7be8d8) |
