# The two maintainer reviews' evidence ZIPs (not copied; committed at the records tip 1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821)

| PR | Review step | Path at the records tip | Bytes | SHA-256 | Entries |
|---|---|---|---:|---|---:|
| #346 | phase 1 (static; review.md) | `briefs/pairings/fills/bb1-machine/final-r1/bb1-machine-r1-phase1-evidence.zip` | 86649 | `8157bdfca262ed37cf9721b2d1ea35e3ca382c6e28a8b8eac6b2f5787b8b1502` | 44 |
| #346 | phase 2 (Lean; phase2/README.md) | `briefs/pairings/fills/bb1-machine/final-r1/phase2/phase2-evidence.zip` | 28234406 | `53a476759936531327ab9c1f2b96a9f66768b32d683a40809355793b1e530169` | 963 |
| #346 | in-house checkpoint (inhouse-r1/REPORT.md) | `briefs/pairings/fills/bb1-machine/inhouse-r1/fill-bb1-machine-evidence.zip` | 9383747 | `eeaa5c787187c977adb91617c577bb6d98987714138f282453590659b50a2580` | 457 |
| #340 | in-house fill (pair-bdh REPORT.md) | `briefs/pairings/fills/pair-bdh/inhouse-r1/fill-pair-bdh-evidence.zip` | 1618511 | `f3be40f83cacecce173e42ad08bda45d6cdda8fbed98ac6eca36cff204331152` | 256 |
| #340 | integration cross-build tip x #341 x #340 (int-x-341-340 README.md) | `briefs/pass-shelat-ch5-8/maintainer/int-x-341-340-2026-11-16/int-x-341-340-evidence.zip` | 4014228 | `b65ded6582c597e13c54ddd6bd2c3398c4dbe20a2e9f0881b71d6e6d6f2e6209` | 1247 |

Integrity at staging: checks/reviews-integrity.txt (each ZIP's own manifest verifies with an exact path set; the phase-2 and int-x directory SHA256SUMS verify).
Also kept on disk (not committed): $SP/olean-replay-346c, the #346-alone replay on snapshot #4, map (no Mathlib) 5e63b3cc1a0efd40c3b5875d701b99a7457cc5f2a3b2831d4a7ab8cc7cf35404, rechecked at staging (replay/output-map/346c-recheck.out).
