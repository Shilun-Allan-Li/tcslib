#!/usr/bin/env bash
# run-build-g44.sh: Gate 44 joint replay, T44 = tip 1d1a9bb3 x #340 916afc25 x #346 89a18a82 (tree 33681cb8, Lean-equal to
# c7be1301) on $SP/olean-replay-g44 (cp -al of snapshot #4 at 463f2244), plan/queue.txt (16 modules), one Lean process at a
# time, through scripts/lean_check_tree.sh (runner.py, unmodified from the snapshot recipe).
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/wt
export PATH=$HOME/.elan/bin:$PATH TMPDIR=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/tmp
echo "start $(date -u +%FT%TZ)" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/build/runner.start
df -m / | tail -1 > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/build/df-launch.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/tools/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/wt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-g44 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/build
echo "runner exit $? $(date -u +%FT%TZ)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/build/runner.exit
df -m / | tail -1 >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44/run/build/runner.exit
