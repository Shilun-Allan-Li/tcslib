#!/usr/bin/env bash
# rule10_g44.sh <phase...> (Gate 44 joint replay, maintainer): Lean checks on T44 = tip 1d1a9bb3 x #340 x #346 (tree 33681cb8,
# Lean-equal to c7be1301) after its replay on $SP/olean-replay-g44. Composed from bb1-machine phase 2's rule10_346.sh and
# rule10_x.sh and pair-bdh's rule10_pbdh.sh; the seal harness (tools/seal) is bb1-machine phase 2's tools-used/seal, unmodified,
# plus pair-bdh's mkctl_pbdh.py (unmodified). Phases:
#   statements  touched.py, tip vs T44, over the 9 changed files
#   axioms      probe-src/Axioms44.lean (Axioms346.lean + Pairing.Assumptions in the census)
#   asm         #340's owner Pairing/Assumptions: collector over that owner alone (as pair-bdh and int-x-341-340), then
#               rule10_b.sh unmodified with mkctl_pbdh.py: strict and coe seals A and B, paired controls strict and coe
#   own         #346's 8 owners: collector over the 8 (as bb1-machine phase 2), seal records for all 8 (request-set
#               comparison), seal runs strict and coe, A and B, for the 5 owners downstream of Pairing/Assumptions
#   scan        explicit-unfold scan over the 9 changed files (scan1_g40.py, scan2.py)
#   g40         supplement (coordinator's ruling, 2026-11-17): the unchanged Gate 40 owners downstream of the changed files,
#               KeyExchange/Joux, IdentityBased/BonehBoyenSecurity and the facades IdentityBased and AdvancedEncryption:
#               collector over the four, then rule10_b.sh unmodified with LE-gate40's mkctl_g40.py (strict and coe, A and B,
#               paired controls), as in Gate 40's canonical suite
# Every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing is written to the olean tree). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/g44; W=$G/wt; E=$G/run; TREE=$SP/olean-replay-g44; T=$G/tools/seal; A=$T/review/archived-gate10-tools
H=33681cb8ed893a897ca2028d5ada70ca29237978; TIP=1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821
export GIT_DIR=/home/user/tcslib/.git GIT_OBJECT_DIRECTORY=$G/objs GIT_ALTERNATE_OBJECT_DIRECTORIES=/home/user/tcslib/.git/objects
export TCSLIB_OLEANS_TREE=$TREE TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH
PX=TCSlib.Cryptography.AdvancedEncryption.IdentityBased; ASM=TCSlib.Cryptography.Pairing.Assumptions
OWN8="$PX.Defs $PX.BonehBoyen $PX.BonehBoyenMachine.Draws $PX.BonehBoyenMachine.Words $PX.BonehBoyenMachine.Handler $PX.BonehBoyenMachine.Reduction $PX.BonehBoyenMachine.Oracles $PX.BonehBoyenMachine"
OWN5="$PX.BonehBoyenMachine.Words $PX.BonehBoyenMachine.Handler $PX.BonehBoyenMachine.Reduction $PX.BonehBoyenMachine.Oracles $PX.BonehBoyenMachine"
G40="TCSlib.Cryptography.KeyExchange.Joux $PX.BonehBoyenSecurity TCSlib.Cryptography.AdvancedEncryption.IdentityBased TCSlib.Cryptography.AdvancedEncryption"
FILES=$(git diff --name-only $TIP $H -- 'TCSlib/*.lean')
mkdir -p $E/tmp $E/statements $E/axioms $E/scan
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) tree $H"
case $ph in
statements)
  echo $FILES > $E/statements/files.txt
  python3 -I $T/review/touched.py /home/user/tcslib $TIP $H $E/statements/touched-after.json $FILES > $E/statements/touched-after.tsv 2>&1; echo "touched rc=$?";;
axioms)
  mkdir -p $W/G44X; cp $G/probe-src/Axioms44.lean $W/G44X/Axioms44.lean
  echo G44X/Axioms44 > $E/axioms/order.txt
  python3 -I $T/runner_full.py $W $E/axioms/order.txt $TREE $E/axioms/runs > $E/axioms/runner.out 2>&1; echo "axioms rc=$?";;
asm)
  EA=$E/asm; R=$EA/rule10; P=G44A; mkdir -p $R/order $R/probe-sources $EA/statements $W/$P
  cp $E/statements/touched-after.json $EA/statements/touched-after.json
  printf '%s\n' $ASM > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "fill-pair-bdh collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?"
  bash $T/rule10_b.sh $T $W $EA $P $H $T/review/mkctl_pbdh.py $ASM > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
own)
  EO=$E/own; R=$EO/rule10; P=G44O; mkdir -p $R/order $R/probe-sources $R/rel $W/$P
  printf '%s\n' $OWN8 > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-machine phase 2 collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?"
  LOG=$R/probe-runs/mods/${P}_CollectHead.log
  # records of all 8 owners (request-set comparison only; written under $P/R*, never run)
  (cd $T && python3 -I $T/review/mkseals_ab.py $A $LOG $W $H $R/rel/seals/A $P/RS SealA_ $OWN8 > $R/rel/mkseals-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $A $LOG $W $H $R/rel/seals/B $P/RS SealB_ $OWN8 > $R/rel/mkseals-B.log
   python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/rel/seals-coe/A $P/RC SealA_ $OWN8 > $R/rel/mkseals-coe-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/rel/seals-coe/B $P/RC SealB_ $OWN8 > $R/rel/mkseals-coe-B.log)
  # the seals that run: the 5 owners downstream of Pairing/Assumptions
  (cd $T && python3 -I $T/review/mkseals_ab.py $A $LOG $W $H $R/seals/A $P/S SealA_ $OWN5 > $R/mkseals-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $A $LOG $W $H $R/seals/B $P/S SealB_ $OWN5 > $R/mkseals-B.log
   python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/seals-coe/A $P/C SealA_ $OWN5 > $R/mkseals-coe-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/seals-coe/B $P/C SealB_ $OWN5 > $R/mkseals-coe-B.log)
  (cd $W && ls $P/C/*.lean $P/S/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
  python3 -I $T/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1 || true
  for v in seals/A seals/B seals-coe/A seals-coe/B; do
    python3 -I $T/review/sealsum.py $R/$v $R/seal-runs $E/statements/touched-after.json $R/$(echo $v | tr / -).tsv; done
  cat $R/mkseals-*.log $R/seals*.tsv;;
scan)
  echo $FILES > $E/scan/files.txt
  SCAN_IMPORTS="$ASM $OWN8" python3 -I $T/scan1_g40.py $A/scan_explicit.py $W \
    $E/statements/touched-after.json $E/scan/items-head.json $W/G44X/ScanKindsHead.lean $FILES > $E/scan/scan1.out 2>&1
  cp $W/G44X/ScanKindsHead.lean $E/scan/ScanKindsHead.lean.txt
  echo G44X/ScanKindsHead > $E/scan/order.txt
  python3 -I $T/runner_full.py $W $E/scan/order.txt $TREE $E/scan/runs > $E/scan/scan-runner.out 2>&1
  python3 -I $T/scan2.py $E/scan/items-head.json $E/scan/runs/mods/G44X_ScanKindsHead.log \
    $E/scan/explicit-head.json > $E/scan/scan2-head.log 2>&1; echo "scan2 rc=$?";;
g40)
  E4=$E/g40; R=$E4/rule10; P=G44G; mkdir -p $R/order $R/probe-sources $E4/statements $W/$P
  cp $E/statements/touched-after.json $E4/statements/touched-after.json
  printf '%s\n' $G40 > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "Gate 44 supplement collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?"
  bash $T/rule10_b.sh $T $W $E4 $P $H $T/review/mkctl_g40.py $G40 > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
