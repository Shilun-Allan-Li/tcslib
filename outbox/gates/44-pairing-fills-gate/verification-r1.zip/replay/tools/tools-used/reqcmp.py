"""reqcmp.py <new-records-dir> <ref-records-dir> <label> (Gate 44, maintainer; no Lean): for every seal record Seal*.json in
<new>, compare its request rows with the same-named record in <ref>, row by row (spelling, home, instance, matcher, abbrev,
collector_reducibility), and the owner source hash. Prints one line per record: counts, added and removed rows, source equal,
probe equal (probe_sha256). A record with no counterpart is reported as MISSING-REF."""
import sys, json, glob, os
new, ref, label = sys.argv[1:4]
key = lambda r: (r['spelling'], r['home'], r['instance'], r['matcher'], r['abbrev'], r.get('collector_reducibility'))
tot = 0
for f in sorted(glob.glob(os.path.join(new, 'Seal*.json'))):
    n = json.load(open(f)); g = os.path.join(ref, os.path.basename(f))
    if not os.path.exists(g): print(f'{label}\t{os.path.basename(f)[:-5]}\tMISSING-REF'); continue
    r = json.load(open(g)); a = set(map(key, n['rows'])); b = set(map(key, r['rows']))
    add = sorted(x[:2] for x in a - b); rem = sorted(x[:2] for x in b - a); tot += len(add) + len(rem)
    print(f'{label}\t{os.path.basename(f)[:-5]}\tnew {n["requested"]}\tref {r["requested"]}\tadded {add}\tremoved {rem}\t'
          f'src-equal {n["source_sha256"] == r["source_sha256"]}\tprobe-equal {n["probe_sha256"] == r["probe_sha256"]}')
print(f'{label}\tTOTAL row differences {tot}')
