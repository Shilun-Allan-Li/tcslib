"""chk44.py <repo> <outdir> (Gate 44 pack re-checks, maintainer; no Lean): pins, commit series and SSH signatures, merge
trees, PR diffs, frozen headers of T1-T4 and bb1_sidSecure, unchanged-file checks, and source tags, from git objects only.
The T44 tree lives in a scratch object directory: run with GIT_OBJECT_DIRECTORY=<objs> and
GIT_ALTERNATE_OBJECT_DIRECTORIES=<repo>/.git/objects. ssh_sig is Gate 42 r2's (chk42r2.py), unmodified in substance."""
import sys, os, re, base64, hashlib, subprocess, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo
repo, out = sys.argv[1:3]; os.makedirs(out, exist_ok=True)
R = Repo(repo)
TIP = '1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821'; T4S = '463f224414ab7615e54104be353bfcda9dfceda7'
H340 = '916afc25c21f5e52b4b01958186ad55d2f615fd1'; H346 = '89a18a8225be1b76166af12a15179da291747783'
T44 = '33681cb8ed893a897ca2028d5ada70ca29237978'; C7 = 'c7be1301f59ec0f208f2645544abac8ac5cc6626'
B331 = '9e7a96481785d6cac4dea3b2e990c49ac278b060'; ISS = '7c0a55e0239c14786612d0cd4462e64238543ca1'
CODE = ['TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean', 'lake-manifest.json', 'lean-toolchain']
IB = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/'; ASM = 'TCSlib/Cryptography/Pairing/Assumptions.lean'
sha = lambda b: hashlib.sha256(b).hexdigest()

def ssh_sig(commit, tamper=False):
    raw = R.gitb('cat-file', 'commit', commit)
    if tamper: raw = raw.replace(b'\ncommitter ', b'\ncommitter  ', 1)
    lines = raw.split(b'\n'); sig, rest, i = [], [], 0
    while i < len(lines):
        l = lines[i]
        if l == b'': rest.extend(lines[i:]); break
        if l.startswith(b'gpgsig '):
            sig.append(l[7:]); i += 1
            while i < len(lines) and lines[i].startswith(b' '): sig.append(lines[i][1:]); i += 1
            continue
        rest.append(l); i += 1
    if not sig: return dict(n=0)
    payload = b'\n'.join(rest)
    blob = base64.b64decode(''.join(x for x in b'\n'.join(sig).decode().splitlines() if not x.startswith('-----')))
    def rd(b, k):
        n = int.from_bytes(b[k:k + 4], 'big'); return b[k + 4:k + 4 + n], k + 4 + n
    assert blob[:6] == b'SSHSIG'
    k = 10
    pub, k = rd(blob, k); ns, k = rd(blob, k); _, k = rd(blob, k); halg, k = rd(blob, k); sigblob, k = rd(blob, k)
    fp = 'SHA256:' + base64.b64encode(hashlib.sha256(pub).digest()).decode().rstrip('=')
    ktype, kk = rd(pub, 0); st, kk2 = rd(sigblob, 0); sigraw, _ = rd(sigblob, kk2)
    h = hashlib.sha512(payload).digest() if halg == b'sha512' else hashlib.sha256(payload).digest()
    s = lambda x: len(x).to_bytes(4, 'big') + x
    signed = b'SSHSIG' + s(ns) + s(b'') + s(halg) + s(h); ok = None
    if ktype == b'ssh-ed25519':
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            keyraw, _ = rd(pub, kk); Ed25519PublicKey.from_public_bytes(keyraw).verify(sigraw, signed); ok = True
        except ImportError: ok = None
        except Exception: ok = False
    return dict(n=sum(1 for l in lines if l.startswith(b'gpgsig ')), fp=fp, ns=ns.decode(), ktype=ktype.decode(), ok=ok)

def cinfo(c):
    f = R.git('show', '-s', '--format=%H%x00%P%x00%an <%ae>%x00%aI%x00%cn <%ce>%x00%cI%x00%s', c).stdout
    return dict(zip(['hash', 'parents', 'author', 'adate', 'committer', 'cdate', 'subject'], f.rstrip('\n').split('\x00')))

def W(name, lines):
    open(os.path.join(out, name), 'w').write('\n'.join(lines) + '\n')

# ---- series ----
L = []
tipsig = ssh_sig(TIP)
L.append(f'records tip {TIP}: {cinfo(TIP)["subject"]}')
L.append(f'  signature: gpgsig {tipsig.get("n")}, {tipsig.get("ktype")} {tipsig.get("fp")}, ns={tipsig.get("ns")}, verified {tipsig.get("ok")}')
L.append(f'  code paths (TCSlib, TCSlib.lean, audits, scripts, lake files, lean-toolchain) changed {T4S[:8]} (snapshot #4 T, merge of #352)..tip: '
         f'{len(R.git("diff", "--name-only", T4S, TIP, "--", *CODE).stdout.split())}')
for n, h, base_note in ((340, H340, 'issued on #331 head 9e7a9648'), (346, H346, 'landing branch from the records tip 7291f6b2')):
    mb = R.rp(f'$(true)') if False else R.git('merge-base', TIP, h).stdout.strip()
    cs = R.git('rev-list', '--reverse', f'{mb}..{h}').stdout.split()
    L.append(''); L.append(f'PR #{n} head {h} ({base_note}); merge base with the tip {mb}; commits {len(cs)}; merges in the range: '
             f'{sum(1 for c in cs if len(cinfo(c)["parents"].split()) > 1)}')
    for c in cs:
        i = cinfo(c); s = ssh_sig(c)
        files = R.git('show', '--format=', '--numstat', c).stdout.strip().split('\n')
        L.append(f'  {c}: author {i["author"]} {i["adate"]}; committer {i["committer"]}; gpgsig {s.get("n")} {s.get("ktype","")} '
                 f'{s.get("fp","")} ns={s.get("ns","")} verified={s.get("ok")}; same key as the records tip: {s.get("fp") == tipsig.get("fp")}')
        L.append(f'    subject: {i["subject"]}')
        for f in files: L.append(f'    {f}')
    L.append(f'  signature control: the head with one byte added to its committer line verifies: {ssh_sig(h, tamper=True).get("ok")} (expected False)')
    d3 = R.git('diff', f'{TIP}...{h}').stdout; d2 = R.git('diff', f'{mb}..{h}').stdout
    L.append(f'  git diff {mb[:8]}..{h[:8]} = git diff tip...head (three-dot, GitHub view) byte for byte: {d2 == d3}; '
             f'{len(d2.encode())} bytes, sha256 {sha(d2.encode())}')
    L.append('  ' + R.git('diff', '--shortstat', f'{mb}..{h}').stdout.strip())
    open(os.path.join(out, f'pr{n}.diff.txt'), 'w').write(d2)
W('series.txt', L)

# ---- merge trees ----
L = []
def mt(a, b):
    r = R.git('merge-tree', '--write-tree', a, b, check=False); return r.stdout.split('\n')[0], r.returncode
t1, r1 = mt(TIP, H340); t2, r2 = mt(TIP, H346)
L.append(f'tip x #340: tree {t1} rc {r1}; tip x #346: tree {t2} rc {r2}')
L.append(f'T44 = (tip x #340) x #346 = (tip x #346) x #340 = (tip x #340) x (tip x #346): {T44} (scratch commits; all three orders give this tree, see landing/mergetrees.txt)')
L.append(f'T44 vs c7be1301 (bb1-machine phase 2: snapshot-#4 T 463f2244 x #346 x #340) over code paths: '
         f'{len(R.git("diff", "--name-only", C7, T44, "--", *CODE).stdout.split())} files')
dl = R.git('diff', '--name-status', TIP, T44).stdout.strip().split('\n')
L.append(f'T44 vs tip, all paths: {len(dl)}')
for x in dl:
    st, p = x.split('\t'); hp = H340 if p == ASM else H346
    L.append(f'  {st} {p}: T44 blob {R.rp(f"{T44}:{p}")[:12]} = {hp[:8]} blob: {R.rp(f"{T44}:{p}") == R.rp(f"{hp}:{p}")}')
p340 = set(R.git('diff', '--name-only', f'{TIP}...{H340}').stdout.split()); p346 = set(R.git('diff', '--name-only', f'{TIP}...{H346}').stdout.split())
L.append(f'#340 paths {sorted(p340)}; #346 paths {len(p346)}; shared {sorted(p340 & p346)}; union = T44 vs tip: {p340 | p346 == set(x.split(chr(9))[1] for x in dl)}')
dT = R.git('diff', TIP, T44, '--', *CODE).stdout
open(os.path.join(out, 'T44.diff.txt'), 'w').write(dT)
L.append(f'T44.diff.txt = git diff tip T44 over code paths: {len(dT.encode())} bytes, sha256 {sha(dT.encode())}')
W('mergetrees.txt', L)

# ---- frozen headers of the targets and of the consumers ----
def decl_block(text, name):
    """from the docstring opener before `theorem <name>` to the line ending `:= by` or `:=` (the header end)."""
    ls = text.split('\n'); i = next(k for k, l in enumerate(ls) if re.match(rf'^(private\s+)?theorem {re.escape(name)}\b', l))
    s = i
    while s > 0 and not ls[s].startswith('/--'): s -= 1
    j = i
    while not re.search(r':=( by)?\s*$', ls[j]): j += 1
    doc = '\n'.join(ls[s:i]); hdr = '\n'.join(ls[i:j + 1])
    prose = doc.split('**Proof sketch.**')[0]
    return prose, hdr
L = []
for name, path, revs in (('bdhAssumption_of_dbdhAssumption', ASM, [B331, TIP, H340, T44]),
                         ('exists_bb1_distinguisher', IB + 'BonehBoyenMachine.lean', [B331, ISS, TIP, H346, T44]),
                         ('bb1_sim_real', IB + 'BonehBoyenSecurity.lean', [B331, TIP, H346, T44]),
                         ('bb1_sim_random', IB + 'BonehBoyenSecurity.lean', [B331, TIP, H346, T44]),
                         ('bb1_sidSecure', IB + 'BonehBoyenSecurity.lean', [B331, TIP, H346, T44])):
    got = {r: decl_block(R.show(r, path), name) for r in revs}
    h0 = got[revs[0]]
    L.append(f'{name} ({path}): header sha256 {sha(h0[1].encode())[:16]}, statement prose (docstring before **Proof sketch.**) sha256 {sha(h0[0].encode())[:16]}')
    for r in revs[1:]:
        L.append(f'  at {r[:8]}: header equal {got[r][1] == h0[1]}; prose equal {got[r][0] == h0[0]}')
    L.append('  header at T44:'); L += ['    ' + x for x in got[T44][1].split('\n')]
sec = IB + 'BonehBoyenSecurity.lean'
L.append(f'BonehBoyenSecurity.lean blob: 9e7a9648 {R.rp(f"{B331}:{sec}")[:12]}, tip {R.rp(f"{TIP}:{sec}")[:12]}, T44 {R.rp(f"{T44}:{sec}")[:12]}; unchanged: '
         f'{R.rp(f"{B331}:{sec}") == R.rp(f"{TIP}:{sec}") == R.rp(f"{T44}:{sec}")}')
for p in ('TCSlib/Cryptography/Pairing/Group.lean', 'TCSlib/Cryptography/Pairing/Operations.lean', 'TCSlib/Cryptography/KeyExchange/Joux.lean',
          'TCSlib/Cryptography/AdvancedEncryption/IdentityBased.lean', 'TCSlib/Cryptography/AdvancedEncryption.lean', 'TCSlib.lean'):
    L.append(f'{p}: tip = T44 blob {R.rp(f"{TIP}:{p}") == R.rp(f"{T44}:{p}")}')
W('headers.txt', L)

# ---- source tags ----
TAG = re.compile(r'\[((?:[A-Z][A-Za-z]*\d\d[a-z]?)(?:, [A-Z][A-Za-z]*\d\d[a-z]?)*)(?:, ([^\]]*))?\]')
L = ['source tags [KEY..., locator] per changed file, at the tip (or absent) and at T44; NEW = a (key, locator) pair absent from that file at the tip']
files = sorted(p340 | p346)
for p in files:
    def tags(rev):
        t = R.show(rev, p); return [(m.group(1), (m.group(2) or '').strip()) for m in TAG.finditer(t)]
    a, b = tags(TIP), tags(T44); sa = set(a)
    refs = re.search(r'## References\n(.*?)(?:\n-/|\n## )', R.show(T44, p), re.S)
    keys = sorted(set(re.findall(r'^\* \[([A-Za-z]+\d\d[a-z]?)\]', refs.group(1), re.M))) if refs else []
    used = sorted(set(k for kk, _ in b for k in kk.split(', ')))
    L.append(f'{p}: tags tip {len(a)}, T44 {len(b)}; keys used {used}; ## References entries {keys}; used keys without an entry: {sorted(set(used) - set(keys))}')
    for k, loc in sorted(set(b) - sa): L.append(f'  NEW [{k}{", " + loc if loc else ""}]')
W('sources.txt', L)
print('ok')
