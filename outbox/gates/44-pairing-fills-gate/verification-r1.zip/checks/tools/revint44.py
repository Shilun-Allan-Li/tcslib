"""revint44.py (Gate 44, maintainer; no Lean): integrity of the two maintainer reviews' committed evidence at the records tip
(run from the repository root, working tree = HEAD): each directory SHA256SUMS, and each evidence ZIP against its own manifest
(the internal SHA256SUMS, paths with a leading `./` normalized, or the phase-1 ZIP's evidence-SHA256SUMS beside it), with the path set compared exactly."""
import zipfile, hashlib, os
for d in ('briefs/pairings/fills/bb1-machine/final-r1/phase2', 'briefs/pairings/fills/bb1-machine/inhouse-r1', 'briefs/pass-shelat-ch5-8/maintainer/int-x-341-340-2026-11-16'):
    rows = [l.split(None, 1) for l in open(os.path.join(d, 'SHA256SUMS')) if l.strip()]
    res = [(p.strip(), hashlib.sha256(open(os.path.join(d, p.strip()), 'rb').read()).hexdigest() == h) for h, p in rows]
    print(f'{d}/SHA256SUMS: {res}')
Z = [('briefs/pairings/fills/bb1-machine/final-r1/bb1-machine-r1-phase1-evidence.zip', 'bb1-machine-r1/', 'briefs/pairings/fills/bb1-machine/final-r1/evidence-SHA256SUMS'),
     ('briefs/pairings/fills/bb1-machine/final-r1/phase2/phase2-evidence.zip', 'bb1-machine-r1-phase2/', None),
     ('briefs/pairings/fills/bb1-machine/inhouse-r1/fill-bb1-machine-evidence.zip', None, None),
     ('briefs/pairings/fills/pair-bdh/inhouse-r1/fill-pair-bdh-evidence.zip', 'fill-pair-bdh/', None),
     ('briefs/pass-shelat-ch5-8/maintainer/int-x-341-340-2026-11-16/int-x-341-340-evidence.zip', 'int-x-341-340/', None)]
for z, pre, ext in Z:
    zf = zipfile.ZipFile(z); names = set(n for n in zf.namelist() if not n.endswith('/'))
    if pre is None:
        tops = sorted(set(n.split('/')[0] + '/' for n in names if '/' in n)); pre = tops[0] if len(tops) == 1 else ''
    man = open(ext).read() if ext else zf.read(pre + 'SHA256SUMS').decode()
    rows = [(h, p.strip().removeprefix('./')) for h, p in (l.split(None, 1) for l in man.splitlines() if l.strip())]
    ok = sum(1 for h, p in rows if pre + p.strip() in names and hashlib.sha256(zf.read(pre + p.strip())).hexdigest() == h)
    listed = set(pre + p.strip() for _, p in rows)
    print(f'{z}: sha256 {hashlib.sha256(open(z, "rb").read()).hexdigest()}; files {len(names)}; manifest rows {len(rows)}; '
          f'verified {ok}; path set = manifest + its SHA256SUMS: {names == listed | {pre + "SHA256SUMS"} or names == listed}')
