"""Reviewer's frozen check of BonehBoyenMachine.lean (bb1-machine, phase 1, no Lean).

Usage: python3 -I frozen_t4.py <repo> <base-rev> <head-rev> [--controls]

Masks the permitted regions and requires the rest to be byte-identical:
  R1 one new import line `import ...IdentityBased.BonehBoyenMachine.Oracles` (only addition
     among the imports; the other imports byte-identical and in order);
  R2 one new `## Contents` bullet `* `BonehBoyenMachine.Oracles`: ...` (with its continuation
     lines), inserted directly after the base's last Contents bullet;
  R3 T4's `**Proof sketch.**` paragraph: from the line starting `**Proof sketch.**` in T4's
     docstring up to and including the docstring's closing `-/`;
  R4 T4's body: the lines after the header line ending `:= by`, up to the next blank line
     before `end`.
Also: T4's docstring before `**Proof sketch.**` and its header (from `theorem` to `:= by`)
are byte-identical; the body has no `sorry`, `admit`, `native_decide`; no column-0 body line.
"""
import subprocess
import sys

PATH = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine.lean'
IMPORT = 'import TCSlib.Cryptography.AdvancedEncryption.IdentityBased.BonehBoyenMachine.Oracles\n'


def show(repo, rev):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{PATH}'], capture_output=True,
                          check=True).stdout.decode()


def split(text):
    """Return dict of parts: pre (before T4 docstring), prose, sketch, header, body, post."""
    lines = text.splitlines(keepends=True)
    th = next(i for i, l in enumerate(lines) if l.startswith('theorem exists_bb1_distinguisher'))
    ds = max(i for i in range(th) if lines[i].startswith('/--'))
    sk = next(i for i in range(ds, th) if lines[i].startswith('**Proof sketch.**'))
    he = next(i for i in range(th, len(lines)) if lines[i].rstrip().endswith(':= by'))
    be = next(i for i in range(he + 1, len(lines)) if lines[i].strip() == '')
    return {
        'pre': ''.join(lines[:ds]),
        'prose': ''.join(lines[ds:sk]),
        'sketch': ''.join(lines[sk:th]),
        'header': ''.join(lines[th:he + 1]),
        'body': ''.join(lines[he + 1:be]),
        'post': ''.join(lines[be:]),
    }


def strip_permitted_pre(base_pre, head_pre):
    """Remove the permitted import and Contents bullet from head_pre; return (text, notes)."""
    notes = []
    hp = head_pre
    if hp.count(IMPORT) == 1:
        hp = hp.replace(IMPORT, '', 1)
        notes.append('import: Oracles line present once')
        # placement: imports sorted as at the base
        imps = [l for l in head_pre.splitlines() if l.startswith('import ')]
        notes.append(f'imports sorted: {imps == sorted(imps)}')
    else:
        notes.append(f'import: Oracles line count {hp.count(IMPORT)}')
    lines = hp.splitlines(keepends=True)
    idx = [i for i, l in enumerate(lines) if l.startswith('* `BonehBoyenMachine.Oracles`')]
    if len(idx) == 1:
        i = idx[0]
        j = i + 1
        while j < len(lines) and lines[j].startswith('  ') and lines[j].strip():
            j += 1
        bullet = ''.join(lines[i:j])
        notes.append(f'contents bullet: {j - i} line(s): {bullet!r}')
        prev = lines[i - 1]
        notes.append(f'bullet follows a bullet or its continuation: '
                     f'{prev.startswith("* ") or prev.startswith("  ")}')
        hp = ''.join(lines[:i] + lines[j:])
    else:
        notes.append(f'contents bullet count {len(idx)}')
    return hp, notes


def check(base, head, verbose=True):
    b, h = split(base), split(head)
    res = {}
    hp, notes = strip_permitted_pre(b['pre'], h['pre'])
    res['pre_eq_after_masking'] = hp == b['pre']
    res['t4_prose_eq'] = h['prose'] == b['prose']
    res['t4_header_eq'] = h['header'] == b['header']
    res['post_eq'] = h['post'] == b['post']
    body = h['body']
    res['body_no_admission'] = not any(w in body for w in ('sorry', 'admit', 'native_decide'))
    res['body_indented'] = all(l.startswith('  ') for l in body.splitlines() if l.strip())
    res['sketch_starts_marker'] = h['sketch'].startswith('**Proof sketch.**')
    res['sketch_ends_docstring'] = h['sketch'].rstrip().endswith('-/')
    res['sketch_changed'] = h['sketch'] != b['sketch']
    ok = all(res.values())
    if verbose:
        for n in notes:
            print('  ' + n)
        for k, v in res.items():
            print(f'  {k}: {v}')
        print(f'  base body: {b["body"]!r}')
        print(f'  head body lines: {len(body.splitlines())}; sketch lines base '
              f'{len(b["sketch"].splitlines())} head {len(h["sketch"].splitlines())}')
        print(f'RESULT {"PASS" if ok else "FAIL"}')
    return ok, res


def main():
    repo, base_rev, head_rev = sys.argv[1:4]
    base, head = show(repo, base_rev), show(repo, head_rev)
    print(f'{PATH} {base_rev[:12]} -> {head_rev[:12]}')
    check(base, head)
    if '--controls' in sys.argv:
        print('== controls (each must FAIL)')
        cs = {
            'header-char': head.replace('(q : PolyExpr) :', '(q : PolyExpr)  :', 1),
            'prose-char': head.replace('negligible `σ` with', 'negligible `σ`  with', 1),
            'sketch-spills-into-prose': head.replace(
                'both tuple distributions.\n', 'both tuple distributions, by T1.\n', 1),
            'title-edit': head.replace('\n# ', '\n#  ', 1),
            'second-contents-bullet': head.replace(
                '* `BonehBoyenMachine.Oracles`', '* `BonehBoyenMachine.Extra`: x.\n'
                '* `BonehBoyenMachine.Oracles`', 1),
            'contents-bullet-edited-existing': head.replace(
                '* `BonehBoyenMachine.Handler`: the handler and its run.',
                '* `BonehBoyenMachine.Handler`: the handler, its run.', 1),
            'extra-import': head.replace(IMPORT, IMPORT + 'import Mathlib.Tactic\n', 1),
            'sorry-in-body': head.replace('  obtain ⟨A\', -, hA\'⟩', '  sorry\n  obtain ⟨A\', -, hA\'⟩',
                                          1),
            'post-edit': head.replace('end TCSlib.Cryptography', 'end  TCSlib.Cryptography', 1),
            'variable-deleted': '\n'.join(l for l in head.split('\n')
                                         if not l.startswith('variable')),
        }
        allfail = True
        for name, mut in cs.items():
            if mut == head:
                print(f'  {name}: MUTATION NOT APPLIED')
                allfail = False
                continue
            ok, res = check(base, mut, verbose=False)
            allfail &= not ok
            print(f'  {name}: {"FAIL (as required)" if not ok else "PASS (CONTROL BROKEN)"} '
                  f'{[k for k, v in res.items() if not v]}')
        print(f'ALL_CONTROLS_OK {allfail}')


if __name__ == '__main__':
    main()
