"""mkverif44.py <stage-dir> <out.zip> (Gate 44, maintainer): zip <stage-dir> deterministically (sorted paths, fixed timestamps,
mode 0644) after writing <stage-dir>/SHA256SUMS over every other file. Prints the entry count and the manifest's SHA-256."""
import sys, os, zipfile, hashlib
st, outz = sys.argv[1:3]
files = sorted(os.path.relpath(os.path.join(r, f), st) for r, _, fs in os.walk(st) for f in fs)
files = [f for f in files if f != 'SHA256SUMS']
with open(os.path.join(st, 'SHA256SUMS'), 'w') as o:
    for f in files: o.write(f'{hashlib.sha256(open(os.path.join(st, f), "rb").read()).hexdigest()}  {f}\n')
with zipfile.ZipFile(outz, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in files + ['SHA256SUMS']:
        zi = zipfile.ZipInfo(f, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
        z.writestr(zi, open(os.path.join(st, f), 'rb').read())
print(f'{len(files) + 1} entries; SHA256SUMS {hashlib.sha256(open(os.path.join(st, "SHA256SUMS"), "rb").read()).hexdigest()}')
