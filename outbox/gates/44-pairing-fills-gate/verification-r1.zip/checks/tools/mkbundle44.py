"""mkbundle44.py <repo> <pack-dir> <verification-stage-dir> <bundle-files.txt> <out-bundle.md> (Gate 44, maintainer; no Lean):
bundle.md = every item of <bundle-files.txt> under a `## ===== <path> (<origin>) =====` header. Items: `pack <file>` (this
pack's directory), `zip:verification-r1.zip <entry>` (the verification stage directory), `<rev> <path>` (git object).
Prints the section count."""
import sys, os, subprocess
repo, pk, st, lst, out = sys.argv[1:6]
secs = []
for line in open(lst):
    line = line.rstrip('\n')
    if not line: continue
    src, path = line.split(' ', 1)
    if src == 'pack':
        body = open(os.path.join(pk, path), encoding='utf-8').read(); hdr = f'{path} (this pack)'
    elif src.startswith('zip:'):
        body = open(os.path.join(st, path), encoding='utf-8').read(); hdr = f'{src[4:]}:{path} (this pack)'
    else:
        body = subprocess.run(['git', '-C', repo, 'show', f'{src}:{path}'], capture_output=True, check=True).stdout.decode('utf-8')
        kind = 'Lean' if path.endswith('.lean') else 'records'
        hdr = f'{path} ({kind}, at {src})'
    secs.append(f'## ===== {hdr} =====\n\n' + body.rstrip('\n') + '\n')
open(out, 'w', encoding='utf-8').write('\n'.join(secs))
print(len(secs), 'sections')
