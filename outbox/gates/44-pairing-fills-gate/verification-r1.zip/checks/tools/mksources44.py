"""mksources44.py <repo> <closure.txt> <out.zip> (Gate 44, maintainer; no Lean): the source bundle, from git objects only.
Layout: T44-33681cb8/ the source closure at T44 (168 modules: the import closure of the IdentityBased, KeyExchange and
Pairing facades, which contains every changed file and BonehBoyenSecurity); pr340-head-916afc25/ and pr346-head-89a18a82/
the changed files at each PR head; tip-1d1a9bb3/ the four changed files that exist at the records tip; references/ the source
texts the targets cite (records tip). Fixed timestamps; README.md lists each entry's origin and SHA-256."""
import sys, zipfile, hashlib, subprocess
repo, clos, outz = sys.argv[1:4]
TIP = '1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821'; H340 = '916afc25c21f5e52b4b01958186ad55d2f615fd1'
H346 = '89a18a8225be1b76166af12a15179da291747783'; T44 = '33681cb8ed893a897ca2028d5ada70ca29237978'
show = lambda r, p: subprocess.run(['git', '-C', repo, 'show', f'{r}:{p}'], capture_output=True, check=True).stdout
names = lambda a, b: subprocess.run(['git', '-C', repo, 'diff', '--name-only', f'{a}...{b}'], capture_output=True, text=True, check=True).stdout.split()
ents = []
for m in [l.strip() for l in open(clos) if l.strip()]:
    ents.append((f'T44-33681cb8/{m}.lean', show(T44, m + '.lean'), f'{T44}:{m}.lean'))
for h, tag in ((H340, 'pr340-head-916afc25'), (H346, 'pr346-head-89a18a82')):
    for p in names(TIP, h): ents.append((f'{tag}/{p}', show(h, p), f'{h}:{p}'))
for p in sorted(set(names(TIP, H340)) | set(names(TIP, H346))):
    r = subprocess.run(['git', '-C', repo, 'cat-file', '-e', f'{TIP}:{p}'])
    if r.returncode == 0: ents.append((f'tip-1d1a9bb3/{p}', show(TIP, p), f'{TIP}:{p}'))
refs = [('blueprint/src/references/boneh-boyen-2004-selective-id-ibe.md', None),
        ('blueprint/src/references/joux-2000-tripartite-dh.md', None),
        ('briefs/pairings/gates/40-pairings-statements/source-excerpts/BB04-excerpts.md', None),
        ('briefs/pairings/gates/40-pairings-statements/source-excerpts/Jou00-excerpts.md', None),
        ('blueprint/src/references/pass-shelat-2010-ch2.raw.md', (1338, 1420))]
for p, rng in refs:
    b = show(TIP, p)
    if rng:
        ls = b.decode().split('\n'); b = ('\n'.join(ls[rng[0] - 1:rng[1]]) + '\n').encode()
        ents.append((f'references/pass-shelat-2010-ch2.raw.lines{rng[0]}-{rng[1]}.md', b, f'{TIP}:{p} lines {rng[0]}-{rng[1]} (Assumption 52.2, Theorem 52.3)'))
    else: ents.append((f'references/{p.split("/")[-1]}', b, f'{TIP}:{p}'))
readme = ['# Gate 44 source bundle', '', 'Every entry is read from git objects; SHA-256 of the bytes and the origin `rev:path`.', '',
          f'- `T44-33681cb8/`: the source closure at T44 (tree `{T44}` = records tip `{TIP}` x #340 x #346), 168 modules.',
          f'- `pr340-head-916afc25/`, `pr346-head-89a18a82/`: the changed files at each PR head (blob-equal to T44\'s).',
          f'- `tip-1d1a9bb3/`: the four changed files that exist at the records tip (the bases).',
          '- `references/`: the BB04 and Jou00 transcriptions (DW-7) and Gate 40\'s excerpts; [PS10] §2.8 lines around Theorem 52.3 (cited by `Draws.draw`).', '',
          '| Entry | SHA-256 | Origin |', '|---|---|---|']
readme += [f'| `{n}` | `{hashlib.sha256(b).hexdigest()}` | `{o}` |' for n, b, o in ents]
with zipfile.ZipFile(outz, 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in [('README.md', ('\n'.join(readme) + '\n').encode())] + [(n, b) for n, b, _ in ents]:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
        z.writestr(zi, b)
print(len(ents) + 1, 'entries')
