"""Reviewer's independent reader-insertion check for bb1-machine (phase 1, no Lean).

Usage: python3 -I readers_check.py <repo> <base-rev> <head-rev> <approved-text-file> [--controls]

Builds the expected post-insertion Defs.lean and BonehBoyen.lean from the base blobs and the
approved text (BB1ReadersMin.lean.txt lines 27-68, 74-97, 99-109) at the brief's positions
(each block preceded by one blank line, inserted after base line 387 of Defs.lean, and after
base lines 387 and 551 of BonehBoyen.lean), and compares them byte for byte with the head
blobs. Independently it removes the blocks from the head and compares with the base.
With --controls it runs mutation controls on the head bytes.
"""
import hashlib
import subprocess
import sys

DEFS = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/Defs.lean'
BB = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyen.lean'
PIN = {
    DEFS: ('9af4b7738f041d2b7f166df6b6ef7c35cf1fcf41c891e04317b50bdff06cf4a8',
           '4e220eadd4bf71ea62372bc371a3e2062b9f213acc696dbb66994c1f64069dfd'),
    BB: ('22caae4f61102c6c31b242fbc37f486939442960049b5e6e4c54790fca96ecd6',
         'da875140806706f26c4cdbb5cf765f522144f3a5a885c5156a58b8c611cd25f4'),
}
APPROVED_SHA = '8644e7228ee7acd4d00c10adb004dca4fe0f94429a18a426e361406d5783420d'
ANCHORS = {
    DEFS: [(387, '    S.oracleImpl κ init key chal 2 x s = chal x s := rfl\n')],
    BB: [(387, '  setup keyGen enc dec MsgSpace encPP encSK encCT] bb1Scheme\n'), (551, None)],
}


def show(repo, rev, path):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True,
                          check=True).stdout


def sha(b):
    return hashlib.sha256(b).hexdigest()


def blocks_from(approved):
    lines = approved.decode().splitlines(keepends=True)
    return {DEFS: [lines[26:68]], BB: [lines[73:97], lines[98:109]]}


def expected(base, blocks, anchors):
    lines = base.decode().splitlines(keepends=True)
    out = []
    cuts = {a for a, _ in anchors}
    queue = list(blocks)
    for i, line in enumerate(lines, 1):
        out.append(line)
        if i in cuts:
            out.append('\n')
            out.extend(queue.pop(0))
    return ''.join(out).encode()


def remove(head, blocks):
    """Remove each block (preceded by one blank line), in order; report how many found."""
    text = head.decode()
    found = 0
    for blk in blocks:
        needle = '\n' + ''.join(blk)
        k = text.count(needle)
        if k == 1:
            text = text.replace(needle, '', 1)
            found += 1
    return text.encode(), found


def linediff(a, b):
    import difflib
    al = a.decode().splitlines()
    bl = b.decode().splitlines()
    sm = difflib.SequenceMatcher(None, al, bl, autojunk=False)
    added = removed = changed = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'insert':
            added += j2 - j1
        elif tag == 'delete':
            removed += i2 - i1
        elif tag == 'replace':
            changed += max(i2 - i1, j2 - j1)
    return added, removed, changed


def check(base, head, path, blocks, verbose=True):
    exp = expected(base, blocks[path], ANCHORS[path])
    rem, found = remove(head, blocks[path])
    res = {
        'base_sha_pinned': sha(base) == PIN[path][0],
        'head_sha_pinned': sha(head) == PIN[path][1],
        'head_eq_expected': head == exp,
        'blocks_found_once': found == len(blocks[path]),
        'removal_restores_base': rem == base,
    }
    a, r, c = linediff(base, head)
    res['diff_vs_base'] = f'+{a} -{r} ~{c}'
    ok = all(v for k, v in res.items() if k != 'diff_vs_base')
    if verbose:
        nb, nh = base.count(b'\n'), head.count(b'\n')
        print(f'{path}: base {sha(base)} head {sha(head)} lines {nb}->{nh}')
        for k, v in res.items():
            print(f'  {k}: {v}')
        print(f'  RESULT {"PASS" if ok else "FAIL"}')
    return ok, res


def main():
    repo, base_rev, head_rev, approved_path = sys.argv[1:5]
    approved = open(approved_path, 'rb').read()
    print(f'approved text sha256 {sha(approved)} pinned {sha(approved) == APPROVED_SHA}')
    blocks = blocks_from(approved)
    # anchors at base
    allok = sha(approved) == APPROVED_SHA
    bases, heads = {}, {}
    for path in (DEFS, BB):
        bases[path] = show(repo, base_rev, path)
        heads[path] = show(repo, head_rev, path)
        bl = bases[path].decode().splitlines(keepends=True)
        for ln, txt in ANCHORS[path]:
            shown = bl[ln - 1].rstrip('\n')
            good = txt is None or bl[ln - 1] == txt
            print(f'anchor {path}:{ln}: {"OK" if good else "MISMATCH"}: {shown}')
            allok &= good
    for i, blk in enumerate(blocks[DEFS] + blocks[BB]):
        print(f'block {i}: first {blk[0].rstrip()[:70]!r} ... last {blk[-1].rstrip()[:50]!r}'
              f' ({len(blk)} lines)')
    for path in (DEFS, BB):
        ok, _ = check(bases[path], heads[path], path, blocks)
        allok &= ok
    print('ALL_PASS' if allok else 'SOME_FAIL')
    if '--controls' in sys.argv:
        controls(bases, heads, blocks)


def controls(bases, heads, blocks):
    print('== controls (each must FAIL)')
    results = []

    def run(name, path, mutated):
        ok, res = check(bases[path], mutated, path, blocks, verbose=False)
        results.append(not ok)
        fails = [k for k, v in res.items() if v is False]
        print(f'  {name}: {"FAIL (as required)" if not ok else "PASS (CONTROL BROKEN)"}; '
              f'failed {fails}; diff {res["diff_vs_base"]}')

    h = heads[DEFS].decode()
    run('defs-char-in-reader', DEFS, h.replace('(OracleComp.bind_pure _).symm',
                                               '(OracleComp.bind_pure _ ).symm', 1).encode())
    i = h.index('/-- **Oracle `1` of `oracleImpl` on the game')
    j = h.index('(OracleComp.bind_pure _).symm\n\n', i) + len('(OracleComp.bind_pure _).symm\n\n')
    run('defs-delete-reader-one', DEFS, (h[:i] + h[j:]).encode())
    run('defs-extra-line-elsewhere', DEFS, h.replace('\n', '\n\n', 1).encode())
    run('defs-docstring-edit', DEFS, h.replace('on the game\'s query type**', 'on the query type**',
                                               1).encode())
    b = heads[BB].decode()
    blk3 = '\n' + ''.join(blocks[BB][1])
    run('bb-move-ofFn_bb1SimCt', BB, b.replace(blk3, '', 1).replace(
        'theorem bb1_correct', blk3.lstrip('\n') + '\ntheorem bb1_correct', 1).encode())
    run('bb-char-in-reader', BB, b.replace('List.ofFn_inj.symm', 'List.ofFn_inj .symm', 1).encode())
    run('bb-extra-line-elsewhere', BB, (b + '\n').encode())
    run('bb-docstring-edit', BB, b.replace('**The key encoding as a word**',
                                           '**The key encoding**', 1).encode())
    run('bb-delete-reader', BB, b.replace(blk3, '', 1).encode())
    print(f'ALL_CONTROLS_OK {all(results)} ({sum(results)}/{len(results)})')


if __name__ == '__main__':
    main()
