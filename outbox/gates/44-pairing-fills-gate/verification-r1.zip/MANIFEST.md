# Gate 44 verification ZIP · manifest and provenance

Maintainer job, 2026-11-17 UTC (03:47–04:30; supplement 04:35–05:01). `$SP` is `/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad`;
the job's working directory was `$SP/g44`. `SHA256SUMS` lists every other entry of this ZIP.

**Pins.** Records tip `1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821` (Lean-equal to snapshot #4's T
`463f224414ab7615e54104be353bfcda9dfceda7`); #340 `916afc25c21f5e52b4b01958186ad55d2f615fd1`; #346
`89a18a8225be1b76166af12a15179da291747783`; T44 = `33681cb8ed893a897ca2028d5ada70ca29237978` (Lean-equal to
`c7be1301f59ec0f208f2645544abac8ac5cc6626`). Both PR heads equal `refs/pull/N/head` (fetched at the start) and the REST
`head.sha` (read at staging).

**Git objects.** T44 and the scratch merge commits used to compute it (dated 2026-11-17T00:00:00Z, unsigned, unreferenced)
live in a scratch object directory `$SP/g44/objs` with the repository's objects as alternate; no merge tree or scratch
commit was written to the repository, and it keeps no new ref. Every check that reads T44 runs with `GIT_OBJECT_DIRECTORY` set accordingly. The export `$SP/g44/wt` is
`git archive T44` of `TCSlib`, `TCSlib.lean`, `audits`, `scripts`, `lakefile.lean`, `lake-manifest.json` and
`lean-toolchain`, with `.lake/packages` symlinked to the repository's.

**Lean.** Only through `scripts/lean_check_tree.sh` (the build, `runner.py`) and phase 2's `runner_full.py`
(`lean -DmaxErrors=0 <probe>`, no `-o`: axioms, collectors, seals, controls, scan kinds), one process at a time; no `lake`, no
cache get. Olean tree: `$SP/olean-replay-g44` only (a `cp -al` copy of `$SP/olean-snapshot`); the snapshot itself was
only read and rehashed. Other agents' directories (`$SP/olean-stage-t23` and others) were not touched; no process was
killed.

## Layout

- `replay/` — the joint replay of T44 on olean snapshot #4.
  - `landing/mergetrees.txt`: the trees of every merge order and the comparison with `c7be1301` (including the correction
    that `c7be1301` is computed from `463f2244`, not from the records tip `ca129d64`).
  - `tree/` (export and copy records), `order/` (`downorder.py`, `fullorder.py`, closure check), `state/` (`stateplan` init
    at `463f2244`, the state after the update), `plan/` (queue of 16, keys), `build/` (`results.jsonl`, every module log
    under `mods/`, `per-module.tsv` and `permod.out`, `statecheck.txt` after the update and `statecheck-final.txt` at the
    end, runner start/exit and disk), `build-mathlib-extra/` (overlay count; NthRootLemmas log, `c0a9cff0…`).
  - `checks/`: snapshot #4 rehash before (`base4-before`), after the build (`base4-after-replay`) and at the end
    (`base4-final`), each 0/0/0; link counts of the 16 rebuilt oleans (after the build and at the end, all 1);
    `olean-vs-refs.txt` (each rebuilt olean against earlier committed build records of the same source).
  - `output-map/`: the output's map without `Mathlib/` (`ded2f64d…`, 1458 entries; comparison with snapshot #4), and the
    recheck of `$SP/olean-replay-346c` against its committed map (`5e63b3cc…`, equal).
  - `admissions/`: `tipcensus.py` at the tip and at T44, the diff, the record sets used (`record-sets-paths.txt`; the sets
    were extracted from the committed evidence ZIPs named there and in `reviews/POINTERS.md`).
  - `axioms/`: the probe run (`runs/`, log `G44X_Axioms44.log`), `axsum.txt`; `probe-src/Axioms44.lean`.
  - `statements/`: `touched.py` (tip vs T44) over the 9 files.
  - `lint/`: `campaign_style_lint.py TCSlib/Cryptography --check8b` at the tip and at T44 (exports), the INFO and non-INFO
    diffs, `style_lint.py` and `sk15.py` on the 9 files, widths.
  - `rule10-g44.out`: the Rule 10 driver's phase log.
  - `tools/`: `run-build-g44.sh` and `rule10_g44.sh` (new drivers); `tools-used/` = #346 phase 2's `tools-used/`
    unmodified (the snapshot recipe tools and `seal/`), plus `seal/review/mkctl_pbdh.py` (pair-bdh's, unmodified) and three
    new scripts: `reqcmp.py` (request-set comparison), `mapnoml.py` (map without `Mathlib/`).
- `rule10/`
  - `asm/`: `Pairing/Assumptions` — the collector (`probe-runs/`, `probe-sources/`), the seal records (`seals/`,
    `seals-coe/`, each probe source as `.lean.txt`), the controls (`controls-strict/`, `controls-coe/`, plans and probe
    sources), every run log (`seal-runs/`), `sealsum` tables, `ctlcheck` results, `error-forms-seal-runs.txt`.
  - `own/`: #346's owners — the collector over all eight; `seals/`, `seals-coe/` for the five owners that were sealed, with
    their run logs and tables; `rel/` the records of the three owners not sealed (`Defs`, `BonehBoyen`, `Draws`), from the
    same collector run (the `rel/` records of the five sealed owners were dropped from this ZIP: their rows are those of
    `own/seals*/`; `rel/*/manifest.json` still lists all eight).
  - `scan/`: the explicit-unfold scan (items, kinds probe and its log, the classification).
  - `compare/`: `reqcmp.py` outputs — `assumptions.txt` (vs pair-bdh's in-house records and phase 2's X) and `owners.txt`
    (the eight owners vs phase 2's snapshot-#4 records; the five sealed owners vs phase 2's X; the summary line).
- `checks/` — re-checks from git objects only (no Lean): `series.txt` (pins, commits, SSH signatures, PR diffs),
  `mergetrees.txt`, `headers.txt` (T1–T4 and `bb1_sidSecure` headers and prose across revisions; unchanged files),
  `frozen-assumptions.txt` (pair-bdh's `frozen_check.py` and `frozen_controls.py`), `readers.txt` and `frozen-t4.txt` (the
  #346 phase-1 review's `readers_check.py` and `frozen_t4.py`), `decls2-tip-vs-T44.tsv`, `sources.txt`,
  `nameclash-T44.txt`, `reviews-integrity.txt`; `tools/` holds every script (`chk44.py`, `gitlib.py` from Gate 42 r2,
  `mksources44.py`, `mkbundle44.py`, `mkverif44.py`, `revint44.py`, and the copied checkers).
- `reviews/` — #346: `review.md`, phase 2 `README.md` and `SHA256SUMS`, the phase-1 `evidence-SHA256SUMS`; #340: the
  in-house `REPORT.md`, the int-x-341-340 `README.md` and `SHA256SUMS`; `POINTERS.md` (path, size, SHA-256 and entry count
  of each evidence ZIP at the records tip).
- `records/` — at the records tip: `PairingCryptographyPlan.md`, `decision-log-pairings.md` (its header and rows 395–436),
  `gate40/` (round-1 and round-2 findings, their `SHA256SUMS`, round-2 resolutions, the BB04 excerpts),
  `bb1-machine/` (the approved reader text `BB1ReadersMin.lean.txt`, the issue brief, the in-house checkpoint REPORT),
  `policy.md`.
- `pr/pr-rest-fields.json` — the REST fields of #340 and #346 read after Seyoon's description updates of 2026-11-17 (`gh api`;
  the GitHub MCP read gives the same title, head, base, `updated_at` and body), with the bodies' SHA-256.
- `supplement/` — the seals and paired controls of the unchanged Gate 40 owners downstream of the changed files (`Joux`,
  `BonehBoyenSecurity`, the two facades), run 04:35–05:01 UTC by the coordinator's ruling; `README.md` there has the figures.
  `replay/tools/rule10_g44.sh` is the driver with the added phase `g40` (the other phases are unchanged).

## Slips during the job (none affects a result)

- The first computation of T44's comparison tree started from `ca129d64` (giving `02b2d44a`, which differs from `c7be1301`
  only in records paths); phase 2's trees were computed from `463f2244`, and recomputing from it reproduces `2ec72515` and
  `c7be1301` exactly (`landing/mergetrees.txt`).
- One state recheck at the end was first started without the scratch-object environment, so T44 could not be read and it
  printed FAIL; it was rerun correctly (`build/statecheck-final.txt`, RESULT OK over 1427).
- Two local refs `refs/scratch/g44/pr340` and `pr346` were created by a fetch of `refs/pull/N/head` and deleted at once;
  their objects were already present.
- `current.pid` files of the runners are not included.
