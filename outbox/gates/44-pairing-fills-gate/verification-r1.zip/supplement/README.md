# Supplement: seals of the unchanged Gate 40 owners downstream of the changed files

Coordinator's ruling of 2026-11-17 (question 2 of the staging report, option b): re-seal before dispatch, so that skipped
re-seals are not an audit question. Run 2026-11-17 04:35–05:01 UTC on `$SP/olean-replay-g44` (T44 =
`33681cb8ed893a897ca2028d5ada70ca29237978`), driver `tools/rule10_g44.sh g40` (the phase added to `replay/tools/rule10_g44.sh`;
the earlier phases are unchanged).

## Which owners

Gate 40's canonical suite covered ten owners: `Pairing/Group`, `Pairing/Assumptions`, `Pairing/Operations`,
`KeyExchange/Joux`, `IB/Defs`, `IB/BonehBoyen`, `IB/BonehBoyenMachine`, `IB/BonehBoyenSecurity` and the facades
`AdvancedEncryption/IdentityBased` and `AdvancedEncryption`.
- Changed by #340 or #346 and covered by the main run: `Assumptions`, `Defs`, `BonehBoyen`, `BonehBoyenMachine`.
- **Unchanged, downstream of the changed files** (rebuilt in the replay's queue of 16): `KeyExchange/Joux`,
  `IB/BonehBoyenSecurity`, `AdvancedEncryption/IdentityBased`, `AdvancedEncryption`. Their request sets cannot be shown
  identical by records: against Gate 40's merged-tree seals (`gates/40-pairings-statements/seals-merged/`, head `9e7a9648`)
  every one of the 16 records gains rows (Joux +253; `BonehBoyenSecurity` and the `IdentityBased` facade +1208; the
  `AdvancedEncryption` facade +1161) and loses none, the owner sources being byte-identical
  (`compare-vs-gate40-seals-merged.txt`). The gains come from #340's new imports of `Assumptions` and #346's helper modules.
  **These four were sealed here.**
- **Not downstream** of the changed files: `Pairing/Group` and `Pairing/Operations` (not in the replay's queue; their import
  closures at T44 equal the tip's). Out of this gate's scope.

## Method

The collector over the four owners (`NmCollect.template.lean`, `mkcollect.py`), then `rule10_b.sh` unmodified with LE-gate40's
`mkctl_g40.py` (Gate 40's canonical rows: `PolyExpr.eval` (B only), `padFin`, `OracleComp.AllOutputs`, `BilinearGen.desc`,
`BilinearGen.DBDHAssumption`, `IBEScheme.Correct`, `IBEScheme.sidImpl`, `BB1.F`, `KeyExchange.jouxMsg`; each a negative
`rfl`/`Iff.rfl` unfolding and a positive through the published reader, in the covering subset of owners whose request sets
contain the name). Every probe through `runner_full.py` (`lean -DmaxErrors=0`, no `-o`), one at a time.

## Results

| Owner | strict A | strict B | coe A | coe B |
|---|---|---|---|---|
| `KeyExchange/Joux` | 904 | 905 | 903 | 904 |
| `IB/BonehBoyenSecurity` | 2312 | 2313 | 2311 | 2312 |
| `AdvancedEncryption/IdentityBased` | 2312 | 2313 | 2311 | 2312 |
| `AdvancedEncryption` | 2409 | 2410 | 2408 | 2409 |

- **Seals: 16/16 rc 0, 0 `error:`, 0 `error(`**, install and EOF records present, no failing declaration
  (`rule10/seals*.tsv`, `rule10/error-forms-seal-runs.txt`).
- **Paired controls:** the covering subset is the `IdentityBased` facade and `Joux` (A and B), 4 sealed and 4 unsealed probes
  per variant. The 24 sealed negatives per variant (facade A 7, facade B 8 with `PolyExpr.eval`, Joux A 4, Joux B 5) each fail
  exactly once (48 `error:` lines over both variants, 0 `error(`); every reader passes; every unsealed probe has 0 errors.
  **ALL_OK True** in strict and in coe (`rule10/ctlcheck-*.log`). The `jouxMsg` row is not exercised: `Joux` owns it, and no
  other sealed owner's closure contains `Joux`.
- `BonehBoyenSecurity` declares no definition (only the theorems `bb1_sim_real`, `bb1_sim_random`, `bb1_sidSecure` and their
  helpers), so it owns nothing to control; its request sets equal the `IdentityBased` facade's row for row (strict A checked),
  and the facade's controls cover those rows.
- **No write-through:** snapshot #4 rehashed 0/0/0 before and after (`base4-before.out`, `base4-after.out`); the output
  `$SP/olean-replay-g44` still matches its map `ded2f64d…` exactly (`g44-map-after.out`). The Mathlib overlay stays in the
  output until adoption (recipe step 6).
