"""rawheaders.py <repo> <base> <head> <file>: the raw source bytes of every declaration header (from
the declaration keyword at line start, after attributes/modifiers, to the first ` := ` / `:= by` that
ends it), compared byte for byte between <base> and <head>, with each header's SHA-256."""
import sys, subprocess, re, hashlib
repo, base, head, f = sys.argv[1:5]
show = lambda r: subprocess.run(['git', '-C', repo, 'show', f'{r}:{f}'], capture_output=True,
                                check=True).stdout
KW = rb'(?:theorem|lemma|def|abbrev|structure|class|instance|inductive|axiom|opaque|example)'
def hs(b):
    out = []
    for m in re.finditer(rb'^(?:(?:private|protected|noncomputable|@\[[^\]]*\])\s+)*' + KW + rb'\b', b, re.M):
        e = re.search(rb':=', b[m.start():])
        out.append(b[m.start():m.start() + e.start()])
    return out
hb, hh = hs(show(base)), hs(show(head))
ok = hb == hh
for x, y in zip(hb, hh):
    print('same' if x == y else 'DIFF', hashlib.sha256(x).hexdigest(), x.split()[1].decode())
print('raw headers', len(hb), len(hh), 'byte-identical:', ok)
