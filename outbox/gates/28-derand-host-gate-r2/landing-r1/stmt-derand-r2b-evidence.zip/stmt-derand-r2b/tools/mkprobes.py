"""mkprobes.py <head-source> <outdir>: the round-2b probes from SeedMajority.lean at head.
The whole-file seal makes `Randomized.randProb`, `Complexity.DTIME`, `Complexity.P`,
`Complexity.PolyTimeComputable`, `Turing.pairEncode`, `Turing.FinTM.DecidesInTime` and
`Turing.FinTM.DecidesInTimeVia` locally irreducible. SeedMajority no longer imports
`ClassP.ModelInvariance`, where `DecidesInTimeVia` lives, so the sealed probes add that one import
line after the file's own imports, only so the seal can name the constant (nothing in the file
uses it). `SealSeedMajorityOwnImports` seals the six names in scope under the file's own imports,
without the added import. Controls (each must fail sealed and pass unsealed): 1 `randProb` by `rfl`;
2 `DTIME` by anonymous constructor; 3 `DecidesInTime` applied as its body; 4 `DecidesInTimeVia`
applied as its body."""
import sys, os
src, out = sys.argv[1:3]
L = open(src, encoding='utf-8').read().split('\n')
last_imp = max(i for i, l in enumerate(L) if l.startswith('import '))
anchor = L.index('set_option autoImplicit false')
assert L[anchor + 1] == '' and anchor > last_imp
IMP = ['import TCSlib.Complexity.ClassP.ModelInvariance  -- PROBE ONLY: names DecidesInTimeVia']
SEAL7 = ['-- SEAL (whole-file): foreign definitions read only through published lemmas',
         'attribute [local irreducible] Randomized.randProb Complexity.DTIME Complexity.P',
         '  Complexity.PolyTimeComputable Turing.pairEncode Turing.FinTM.DecidesInTime',
         '  Turing.FinTM.DecidesInTimeVia', '']
SEAL6 = ['-- SEAL (whole-file, own imports): the six of the seven names in scope',
         'attribute [local irreducible] Randomized.randProb Complexity.DTIME Complexity.P',
         '  Complexity.PolyTimeComputable Turing.pairEncode Turing.FinTM.DecidesInTime', '']
CTRL = '''
-- CONTROL 1 (must fail sealed): reads `randProb` through its body.
example (m : ℕ) (A : List Bool → Prop) [DecidablePred A] :
    Randomized.randProb m A =
      ((Finset.univ.filter fun r : Fin m → Bool => A (List.ofFn r)).card : ℚ) / 2 ^ m := rfl

-- CONTROL 2 (must fail sealed): builds `DTIME` membership through its body.
example (L : Language Bool) (M : Turing.FinTM Bool) (T : ℕ → ℕ)
    (h : M.DecidesInTime L fun n => 1 * T n) : L ∈ Complexity.DTIME T := ⟨1, M, h⟩

-- CONTROL 3 (must fail sealed): reads `FinTM.DecidesInTime` through its body.
example (L : Language Bool) (M : Turing.FinTM Bool) (T : ℕ → ℕ)
    (h : M.DecidesInTime L T) (x : List Bool) :
    M.ComputesInTime x [Turing.MultiTapeTM.indicator (L : Set (List Bool)) x] (T x.length) :=
  h x

-- CONTROL 4 (must fail sealed): reads `FinTM.DecidesInTimeVia` through its body.
example (L : Language Bool) (M : Turing.FinTM Bool) (T : ℕ → ℕ)
    (h : M.DecidesInTimeVia (Function.Embedding.refl Bool) L T) (x : List Bool) :
    M.ComputesInTime (x.map (Function.Embedding.refl Bool))
      [(Function.Embedding.refl Bool) (Turing.MultiTapeTM.indicator (L : Set (List Bool)) x)]
      (T x.length) :=
  h x

#print axioms Complexity.exists_seedMajorityTM
#print axioms Complexity.seedMajority_mem_DTIME
#print axioms Randomized.half_lt_randProb_iff
'''.split('\n')
def build(imp, seal, ctrl):
    body = L[:last_imp + 1] + imp + L[last_imp + 1:anchor + 2] + seal + L[anchor + 2:]
    if ctrl:
        while body and body[-1] == '': body.pop()
        body += CTRL
    return '\n'.join(body) + ('' if body[-1] == '' else '\n')
files = {'SealSeedMajority': build(IMP, SEAL7, False),
         'SealSeedMajorityOwnImports': build([], SEAL6, False),
         'SealSeedMajorityControl': build(IMP, SEAL7, True),
         'UnsealedSeedMajorityControl': build(IMP, [], True)}
for k, v in files.items():
    open(os.path.join(out, k + '.lean'), 'w', encoding='utf-8').write(v)
    print(k, len(v.split('\n')))
