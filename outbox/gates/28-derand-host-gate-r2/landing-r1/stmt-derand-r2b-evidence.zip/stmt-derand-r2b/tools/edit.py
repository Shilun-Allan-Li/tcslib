import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
R = [
("import TCSlib.Complexity.ClassP.ModelInvariance\n", ""),
("import TCSlib.Complexity.Randomized.QuasiPolyHierarchy\n", ""),
("""G28-02). **Proof owner:** the `derand` fill proves both the host
contract `Complexity.exists_seedMajorityTM` and Theorem 180.1
(`TCSlib.Cryptography.Randomness.bpp_subset_dtime_subexp`).""",
"""G28-02). **Proof owner:** the `derand` fill proves the host contract
`Complexity.exists_seedMajorityTM`, its corollary `Complexity.seedMajority_mem_DTIME`, and
Theorem 180.1 (`TCSlib.Cryptography.Randomness.bpp_subset_dtime_subexp`)."""),
("""- **The class** `DTIME (n ↦ 2^{w(n)} · (n+1)^e)` is a corollary (`seedMajority_mem_DTIME`),
  proved from the contract through `DTIME`'s published lemmas only: the introduction lemma
  `Complexity.mem_DTIME_of_decidesInTimeVia`, `DTIME.mono` and
  `Randomized.DTIME_const_mul_subset`.""",
"""- **The class** `DTIME (n ↦ 2^{w(n)} · (n+1)^e)` is a corollary (`seedMajority_mem_DTIME`),
  which follows from the contract through the reader `Complexity.mem_DTIME_iff`. The `derand`
  fill adds that reader beside `DTIME` (`ClassP/DTIME.lean`) under its pre-approval (Seyoon,
  2026-11-15). Until then the corollary is admitted: without the reader its proof would read
  `Turing.FinTM.DecidesInTime`, `Turing.FinTM.DecidesInTimeVia` and `DTIME` by their
  definitions (Rule 10)."""),
("""  `∃ e, {x | 2^{w(|x|)} < 2 · count} ∈ DTIME (n ↦ 2^{w(n)} · (n+1)^e)` (proved from the contract).""",
"""  `∃ e, {x | 2^{w(|x|)} < 2 · count} ∈ DTIME (n ↦ 2^{w(n)} · (n+1)^e)` (stated; a `sorry`
  until the `derand` fill adds `mem_DTIME_iff`, then read off the contract)."""),
("""∈ DTIME (fun n => 2^{w(n)} · (n+1)^e)`. Ties (`2 · count = 2^w`) reject. It is the corollary
of the machine contract `exists_seedMajorityTM` that the consumers of the class read.

**Proof sketch.** Take the machine `M` and constants `c, e` of `exists_seedMajorityTM` (the
envelope is not needed here). With the identity embedding `Bool ↪ Bool` (`x.map id = x`), `M`
decides the language in `DTIME (n ↦ c · (2^{w(n)} · (n+1)^e) + 1)`
(`mem_DTIME_of_decidesInTimeVia`, the published introduction lemma of `DTIME`). That
bound is at most `(c + 1) · (2^{w(n)} · (n+1)^e)`, since `2^{w(n)} · (n+1)^e ≥ 1`
(`DTIME.mono`), and the constant `c + 1` is absorbed (`Randomized.DTIME_const_mul_subset`). -/""",
"""∈ DTIME (fun n => 2^{w(n)} · (n+1)^e)`. Ties (`2 · count = 2^w`) reject. It is the corollary
of the machine contract `exists_seedMajorityTM` that the consumers of the class read.

**Status.** Admitted (a `sorry`). It follows from `exists_seedMajorityTM` through the reader
`Complexity.mem_DTIME_iff`, which the `derand` fill adds beside `DTIME` (`ClassP/DTIME.lean`)
under its pre-approval (Seyoon, 2026-11-15). The `derand` fill proves both the contract and
this corollary. Until the reader exists, a proof would read `Turing.FinTM.DecidesInTime`,
`Turing.FinTM.DecidesInTimeVia` and `DTIME` by their definitions, which Rule 10 forbids.

**Proof sketch.** Take the machine `M` and constants `c, e` of `exists_seedMajorityTM` (the
envelope is not needed here). `M` decides the language within
`n ↦ c · (2^{w(n)} · (n+1)^e)`, which is `c · T n` for `T n = 2^{w(n)} · (n+1)^e`. By
`mem_DTIME_iff` (membership in `DTIME T` is a constant `c` together with a machine deciding
within `c · T`), the language is in `DTIME T`, with the witness `e`. -/"""),
("""        DTIME fun n => 2 ^ w n * (n + 1) ^ e := by
  obtain ⟨M, c, e, hM, -⟩ := exists_seedMajorityTM hV w hw
  refine ⟨e, Randomized.DTIME_const_mul_subset (c + 1) _ (DTIME.mono (fun n => ?_)
    (mem_DTIME_of_decidesInTimeVia (Function.Embedding.refl Bool) (M := M)
      (T := fun n => c * (2 ^ w n * (n + 1) ^ e)) fun x => by
        rw [Function.Embedding.coe_refl, List.map_id]
        exact hM x))⟩
  have h1 : 1 ≤ 2 ^ w n * (n + 1) ^ e := Nat.one_le_iff_ne_zero.2 (by positivity)
  calc c * (2 ^ w n * (n + 1) ^ e) + 1
      ≤ c * (2 ^ w n * (n + 1) ^ e) + 2 ^ w n * (n + 1) ^ e := Nat.add_le_add_left h1 _
    _ = (c + 1) * (2 ^ w n * (n + 1) ^ e) := by ring
""",
"""        DTIME fun n => 2 ^ w n * (n + 1) ^ e := by
  sorry
"""),
]
for a, b in R:
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s)
print('ok')
