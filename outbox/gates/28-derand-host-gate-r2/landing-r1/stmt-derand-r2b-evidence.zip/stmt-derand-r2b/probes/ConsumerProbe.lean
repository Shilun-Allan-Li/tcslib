import TCSlib.Complexity.Randomized.SeedMajority
import TCSlib.Complexity.Randomized.QuasiPolyHierarchy
import TCSlib.Cryptography.Randomness.Derandomization

/-! Consumer probe (round 2, Gate 28): the final transport of `bpp_subset_dtime_subexp`
([PS10, Theorem 180.1]) from the corollary `seedMajority_mem_DTIME`, through published lemmas
only. Given a test `V ∈ P`, a width `w` with a polynomial-time unary word, a language `L` equal
to the probabilistic-majority language (steps 1-4 of the paper proof) and the pointwise bound
`2^{w n} (n+1)^e ≤ c · subexpBound ε n` (step 6), `L ∈ DTIME (subexpBound ε)`. Also the same
for a general bound `T`. `DTIME`, `randProb`, `P`, `PolyTimeComputable`, `pairEncode` and
`subexpBound` are sealed; the control reads `DTIME` through its body and must fail exactly
once. -/

set_option autoImplicit false

attribute [local irreducible] Complexity.DTIME Randomized.randProb Complexity.P
  Complexity.PolyTimeComputable Turing.pairEncode
  TCSlib.Cryptography.Randomness.subexpBound

open Complexity

open Classical in
/-- The general transport: majority language in `DTIME T` from a pointwise bound. -/
theorem transport_general {V : Language Bool} (hV : V ∈ P) (w : ℕ → ℕ)
    (hw : PolyTimeComputable fun x => List.replicate (w x.length) true) (T : ℕ → ℕ)
    (hT : ∀ e : ℕ, ∃ c : ℕ, ∀ n, 2 ^ w n * (n + 1) ^ e ≤ c * T n) :
    {x : List Bool | 1 / 2 < Randomized.randProb (w x.length)
        fun r => Turing.pairEncode x r ∈ V} ∈ DTIME T := by
  obtain ⟨e, he⟩ := seedMajority_mem_DTIME hV w hw
  obtain ⟨c, hc⟩ := hT e
  have hset : {x : List Bool | 1 / 2 < Randomized.randProb (w x.length)
        fun r => Turing.pairEncode x r ∈ V} =
      {x : List Bool | 2 ^ w x.length <
        2 * (Finset.univ.filter fun u : Fin (w x.length) → Bool =>
          Turing.pairEncode x (List.ofFn u) ∈ V).card} := by
    ext x
    exact Randomized.half_lt_randProb_iff _ _
  rw [hset]
  exact Randomized.DTIME_const_mul_subset c T (DTIME.mono hc he)

open Classical in
/-- Thm 180.1's last step, at `T = subexpBound ε`, for a language `L` identified with the
majority language of `(V'', w)` by steps 1-4 of the paper proof. -/
example (ε : ℝ) (L : Language Bool) {V : Language Bool} (hV : V ∈ P) (w : ℕ → ℕ)
    (hw : PolyTimeComputable fun x => List.replicate (w x.length) true)
    (hL : L = {x : List Bool | 1 / 2 < Randomized.randProb (w x.length)
        fun r => Turing.pairEncode x r ∈ V})
    (hT : ∀ e : ℕ, ∃ c : ℕ, ∀ n,
      2 ^ w n * (n + 1) ^ e ≤ c * TCSlib.Cryptography.Randomness.subexpBound ε n) :
    L ∈ DTIME (TCSlib.Cryptography.Randomness.subexpBound ε) := by
  rw [hL]
  exact transport_general hV w hw _ hT

-- CONTROL (must fail sealed, exactly once): builds `DTIME` membership through its body.
example (L : Language Bool) (M : Turing.FinTM Bool) (T : ℕ → ℕ)
    (h : M.DecidesInTime L fun n => 1 * T n) : L ∈ DTIME T := ⟨1, M, h⟩

#print axioms transport_general
#print axioms Complexity.seedMajority_mem_DTIME
#print axioms Complexity.exists_seedMajorityTM
