r"""replayverify.py <tree> <ref-map-noMathlib.tsv> <expected-ref-map-sha256> <nthroot-sha256> <expected-symlinks> (LE-g48, new):
rehash a replay tree (snapshot + Mathlib/ symlink overlay + NthRootLemmas olean) against a reference map made by mapnoml.py.
Outside Mathlib/: every file must be a regular .olean listed in the map with that hash (extra/changed/missing), no symlinks.
Inside Mathlib/: symlinks are counted (must equal <expected-symlinks>); the only regular file must be
Analysis/SpecialFunctions/Pow/NthRootLemmas.olean with <nthroot-sha256>. Prints counts and RESULT OK/FAIL. Read-only."""
import sys, os, hashlib
d, ref, refsha, nth, nlinks = sys.argv[1:6]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
ok = sha(ref) == refsha
M = dict(l.rstrip('\n').split('\t') for l in open(ref))
files, links_out, other, mlinks, mfiles = {}, [], [], 0, {}
for r, ds, fs in os.walk(d):
    rel = os.path.relpath(r, d); inml = rel == 'Mathlib' or rel.startswith('Mathlib/')
    for f in fs + [x for x in ds if os.path.islink(os.path.join(r, x))]:
        p = os.path.join(r, f); q = os.path.relpath(p, d)
        if inml:
            if os.path.islink(p): mlinks += 1
            else: mfiles[q] = sha(p)
            continue
        if os.path.islink(p): links_out.append(q)
        elif q.endswith('.olean'): files[q[:-6]] = sha(p)
        else: other.append(q)
extra = sorted(set(files) - set(M)); missing = sorted(set(M) - set(files)); changed = sorted(m for m in files if m in M and M[m] != files[m])
mlok = mfiles == {'Mathlib/Analysis/SpecialFunctions/Pow/NthRootLemmas.olean': nth} and mlinks == int(nlinks)
res = ok and not (extra or missing or changed or links_out or other) and mlok
print(f'{d}: ref {ref} sha256 {"OK" if ok else "MISMATCH"}; files {len(files)}; extra {len(extra)}; changed {len(changed)}; '
      f'missing {len(missing)}; symlinks outside Mathlib {len(links_out)}; other {len(other)}; Mathlib symlinks {mlinks}; '
      f'Mathlib files {sorted(mfiles.items())}; RESULT {"OK" if res else "FAIL"}')
for n, xs in (('extra', extra), ('changed', changed), ('missing', missing)):
    for x in xs: print(f'  {n} {x}')
