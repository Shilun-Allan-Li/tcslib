#!/usr/bin/env bash
# rule10_g48.sh <phase...> (LE-g48): bsp2/rule10_bsf2.sh with this job's paths (head dfdc56f2 = 7a98ba01 + LE-g48, tree
# $SP/olean-replay-bb1sim-g48, export $SP/le-g48-work/wtx), a 30 s host slot poll before each runner call, and the seal phase
# reduced to the canonical coe-A seal on BonehBoyenSecurity (rule10_b_gated.sh's mkseals_coe.py line, then
# runner_full_gated.py and sealsum.py exactly as there; no B/strict seals and no paired controls). Tools: phase 2's
# tools/seal (unmodified). Probe prefix BSF2 kept so the generated probe sources compare with phase 2's byte for byte.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/le-g48-work; W=$G/wtx; E=$G/run; TREE=$SP/olean-replay-bb1sim-g48; T=$SP/bsp2/tools/seal; A=$T/review/archived-gate10-tools
H=dfdc56f21898abe2d9d6cef83b0cfe57da87d28d; TIP=e1d39836ed4a69a34914c35f4c73c71de853dcc6
export GIT_DIR=/home/user/tcslib/.git
export TCSLIB_OLEANS_TREE=$TREE TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH
GM=TCSlib.Cryptography.Games; IM=TCSlib.Cryptography.AdvancedEncryption.IdentityBased
OWN9="$GM.Relational $IM.Defs $IM.BonehBoyen $IM.BonehBoyenSecurity $IM.BonehBoyenSecurity.Lazy $IM.BonehBoyenSecurity.Real $IM.BonehBoyenSecurity.Coupling $IM.BonehBoyenSecurity.Random $IM.BonehBoyenSecurity.Chain"
FILES=$(git -C /home/user/tcslib diff --name-only $TIP $H -- 'TCSlib/*.lean')
P=BSF2; R=$E/rule10
gate() { while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean $1" >> $E/slot-waits.txt; sleep 30; done
         echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $1" >> $E/slot-log.txt; }
mkdir -p $E/tmp $E/statements $E/axioms $R/order $R/probe-sources $W/$P
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) head $H"
case $ph in
statements)
  echo $FILES > $E/statements/files.txt
  python3 -I $T/review/touched.py /home/user/tcslib $TIP $H $E/statements/touched-after.json $FILES > $E/statements/touched-after.tsv 2>&1; echo "touched rc=$?";;
collect)
  printf '%s\n' $OWN9 > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-sim phase 2 collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  gate collect; python3 -I $T/runner_full_gated.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
axioms)
  cp $SP/bsp2/probe-src/AxiomsBsf.lean $W/$P/AxiomsBsf.lean
  echo $P/AxiomsBsf > $E/axioms/order.txt
  gate axioms; python3 -I $T/runner_full_gated.py $W $E/axioms/order.txt $TREE $E/axioms/runs > $E/axioms/runner.out 2>&1; echo "axioms rc=$?";;
sealcoeA)
  LOG=$R/probe-runs/mods/${P}_CollectHead.log
  ( cd $T && python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/seals-coe/A $P/C SealA_ $IM.BonehBoyenSecurity > $R/mkseals-coe-A.log ); echo "mkseals_coe rc=$?"
  (cd $W && ls $P/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
  gate seal; python3 -I $T/runner_full_gated.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1; echo "seal runner rc=$?"
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $E/statements/touched-after.json $R/seals-coe-A.tsv; echo "sealsum rc=$?"
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
