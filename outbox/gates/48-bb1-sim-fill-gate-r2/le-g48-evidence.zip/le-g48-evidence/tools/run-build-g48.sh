#!/usr/bin/env bash
# run-build-g48.sh (LE-g48): bsp2/run-build-bsf.sh with the paths of this job and a 30 s slot poll. New head
# dfdc56f21898abe2d9d6cef83b0cfe57da87d28d (7a98ba01 + LE-g48) on $SP/olean-replay-bb1sim-g48 (cp -al of #357's replay
# tree), plan/queue.txt (4 modules), through the recipe's runner.py (unmodified), one module per call; before each module
# the host's Lean slot count is checked (wait while 3 or more lean processes run).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
B=$SP/le-g48-work; OUT=$SP/olean-replay-bb1sim-g48; RUNNER=$SP/bsp2/tools/runner.py
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$B/run/tmp
echo "start $(date -u +%FT%TZ)" > $B/run/build/runner.start; df -m / | tail -1 > $B/run/build/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $B/run/build/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $B/run/build/slot-log.txt
  echo "$m" > $B/run/build/one/order.txt
  python3 -I $RUNNER $B/wtx $B/run/build/one/order.txt $OUT $B/run/build < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $B/run/build/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $B/run/build/runner.exit; exit 2; }
done < $B/run/plan/queue.txt
echo "runner exit 0 $(date -u +%FT%TZ)" >> $B/run/build/runner.exit; df -m / | tail -1 >> $B/run/build/runner.exit
