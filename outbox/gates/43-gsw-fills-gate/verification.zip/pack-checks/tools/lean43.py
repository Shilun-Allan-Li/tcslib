"""lean43.py: text-level Lean helpers for the Gate 43 pack re-checks (no Lean is run).

split_items(text) splits a Lean file into top-level items. A command starts at column 0, outside a block
comment, with a command keyword (or attribute/modifier); a docstring (`/-- … -/`) and `open/include/omit … in`
prefix lines attach to the next command. Lines at column 0 that do not start a command (match arms, closing
brackets) continue the current item. Each item is a dict:
  kind   'decl' | 'moddoc' | 'comment' | 'cmd'
  key    ('decl', keyword, name) for declarations (anonymous ones are keyed by their normalised header),
         ('cmd', normalised text) for other commands, ('moddoc'|'comment', normalised text)
  name, keyword, private, line (1-based line of the keyword), doc (attached docstring text, '' if none),
  prefix (the attached `… in` lines), header (keyword line up to the top-level `:=`, ` where` or first `|` arm,
  excluding docstring and prefix), body (the rest), text (the whole item, docstring included).

compare(base_text, head_text, targets) applies the frozen-statement rule of the GSW briefs:
  * every base item reappears at head, in the same relative order;
  * a target keeps its prefix and header byte-identical, and its docstring byte-identical up to and including
    `**Proof sketch.**` (the marker must still be there); its body may change;
  * every other base item is byte-identical as a whole;
  * head-only items are ADDED; only `import` commands and declarations may be added.
It returns a list of (code, message) with codes DIFF, REMOVED, ORDER, ADDED, BADADD.
"""
import re

MODS = ('private', 'protected', 'noncomputable', 'partial', 'unsafe', 'nonrec')
DECL_KW = ('theorem', 'lemma', 'def', 'abbrev', 'structure', 'class', 'instance', 'inductive', 'example', 'opaque',
           'axiom', 'irreducible_def')
CMD_RE = re.compile(r'^(@\[|(?:' + '|'.join(MODS + DECL_KW) + r')\b|import\b|open\b|namespace\b|section\b|end\b|'
                    r'variable\b|universe\b|set_option\b|attribute\b|noncomputable\s+section\b|local\b|scoped\b|'
                    r'notation\b|macro\b|syntax\b|mutual\b|alias\b|export\b|include\b|omit\b|#)')
IN_PREFIX = re.compile(r'^(open|include|omit)\b.*\bin\s*$')
DECL_RE = re.compile(r'^(?:@\[[^\]]*\]\s*)*((?:(?:' + '|'.join(MODS) + r')\s+)*)(' + '|'.join(DECL_KW) +
                     r')\b\s*([^\s(:{\[]*)')
SKETCH = '**Proof sketch.**'
norm = lambda t: re.sub(r'\s+', ' ', t).strip()


def _comment_depth(line, depth):
    i = 0
    while i < len(line):
        if line.startswith('/-', i):
            depth += 1; i += 2
        elif line.startswith('-/', i) and depth > 0:
            depth -= 1; i += 2
        elif depth == 0 and line.startswith('--', i):
            break
        elif depth == 0 and line[i] == '"':
            j = i + 1
            while j < len(line) and line[j] != '"':
                j += 2 if line[j] == '\\' else 1
            i = j + 1
        else:
            i += 1
    return depth


def _header_split(lines):
    """split a declaration's lines (keyword line first) into header and body at the first depth-0 `:=`,
    ` where` or `|` match arm."""
    text = '\n'.join(lines)
    d, k, n = 0, 0, len(text)
    tick = False
    while k < n:
        ch = text[k]
        if ch == '`':
            tick = not tick
        elif not tick:
            if ch in '([{⟨':
                d += 1
            elif ch in ')]}⟩':
                d -= 1
            elif d == 0:
                if text.startswith(':=', k):
                    return text[:k], text[k:]
                if re.match(r'\swhere\b', text[k:k + 7]):
                    return text[:k], text[k:]
                if ch == '\n' and re.match(r'\n\s*\|', text[k:]):
                    return text[:k], text[k:]
        k += 1
    return text, ''


def split_items(text):
    lines = text.split('\n')
    items, cur, pending, depth = [], None, [], 0

    def close():
        nonlocal cur
        if cur is not None:
            while cur['lines'] and cur['lines'][-1].strip() == '':
                cur['lines'].pop()
            items.append(cur)
            cur = None

    for no, ln in enumerate(lines, 1):
        start = depth
        depth = _comment_depth(ln, depth)
        if start > 0:  # inside a block comment opened earlier
            (cur['lines'] if cur is not None and not pending else pending).append(ln)
            if depth == 0 and pending and cur is None:
                head = pending[0]
                if head.startswith('/-!') or (head.startswith('/-') and not head.startswith('/--')):
                    items.append(dict(kind='moddoc' if head.startswith('/-!') else 'comment', lines=pending,
                                      line=no - len(pending) + 1))
                    pending = []
            continue
        if ln.startswith('/-') and not ln.startswith('/--'):
            close()
            pending = [ln]
            if depth == 0:
                items.append(dict(kind='moddoc' if ln.startswith('/-!') else 'comment', lines=pending, line=no))
                pending = []
            continue
        if ln.startswith('/--'):
            close()
            pending.append(ln)
            continue
        if IN_PREFIX.match(ln) and not ln.startswith('@['):
            close()
            pending.append(ln)
            continue
        if CMD_RE.match(ln):
            close()
            cur = dict(kind='cmd', lines=[ln], line=no, attached=pending)
            pending = []
            continue
        if cur is not None:
            cur['lines'].append(ln)
        elif ln.strip():
            cur = dict(kind='cmd', lines=[ln], line=no, attached=pending)
            pending = []
    close()
    out = []
    for it in items:
        if it['kind'] in ('moddoc', 'comment'):
            t = '\n'.join(it['lines'])
            out.append(dict(kind=it['kind'], key=(it['kind'], norm(t)), text=t, line=it['line'], name=None))
            continue
        att = it.get('attached', [])
        doc_lines = [x for x in att if not IN_PREFIX.match(x)]
        pre_lines = [x for x in att if IN_PREFIX.match(x)]
        doc = '\n'.join(doc_lines)
        prefix = '\n'.join(pre_lines)
        first = '\n'.join(it['lines'])
        m = DECL_RE.match(first.replace('\n', ' '))
        whole = '\n'.join(att + it['lines'])
        if m:
            mods, kw, name = m.groups()
            header, body = _header_split(it['lines'])
            if not name or name in (':', ':=', 'where'):
                name = ''
            key = ('decl', kw, name or norm(header))
            out.append(dict(kind='decl', key=key, keyword=kw, name=name, private='private' in mods.split(),
                            line=it['line'], doc=doc, prefix=prefix, header=header, body=body, text=whole))
        else:
            out.append(dict(kind='cmd', key=('cmd', norm(first)), text=whole, line=it['line'], name=None,
                            doc=doc, prefix=prefix))
    return out


def body_is_sorry(it):
    b = re.sub(r'--[^\n]*', '', it['body'])
    return norm(b) in (':= by sorry', ':= sorry')


def has_sorry(t):
    t = re.sub(r'/-.*?-/', '', t, flags=re.S)
    t = re.sub(r'--[^\n]*', '', t)
    return re.search(r'\bsorry\b', t) is not None


def sorry_count(t):
    t = re.sub(r'/-.*?-/', '', t, flags=re.S)
    t = re.sub(r'--[^\n]*', '', t)
    return len(re.findall(r'\bsorry\b', t))


def doc_prose(doc):
    i = doc.find(SKETCH)
    return doc if i < 0 else doc[:i + len(SKETCH)]


def doc_sketch(doc):
    i = doc.find(SKETCH)
    return '' if i < 0 else doc[i:]


def short(name):
    return name.split('.')[-1]


def compare(base_text, head_text, targets):
    B, H = split_items(base_text), split_items(head_text)
    hk = {}
    for i, it in enumerate(H):
        hk.setdefault(it['key'], []).append(i)
    res, pos, used = [], [], set()
    for it in B:
        cand = [i for i in hk.get(it['key'], []) if i not in used]
        if not cand:
            res.append(('REMOVED', f"{it['kind']} {it.get('name') or it['key'][-1][:70]!r} (base line {it['line']})"))
            continue
        j = cand[0]; used.add(j); pos.append(j)
        h = H[j]
        if it['kind'] == 'decl' and it['name'] in targets:
            if it['prefix'] != h['prefix'] or it['header'] != h['header']:
                res.append(('DIFF', f"target {it['name']}: header or prefix differs (base {it['line']}, head {h['line']})"))
            if doc_prose(it['doc']) != doc_prose(h['doc']) or SKETCH not in h['doc']:
                res.append(('DIFF', f"target {it['name']}: docstring prose before the sketch differs or marker lost"))
        elif it['text'] != h['text']:
            res.append(('DIFF', f"{it['kind']} {it.get('name') or it['key'][-1][:70]!r}: item differs "
                                f"(base {it['line']}, head {h['line']})"))
    if pos != sorted(pos):
        bad = sum(1 for a, b in zip(pos, pos[1:]) if b < a)
        res.append(('ORDER', f'{bad} order inversion(s) among the base items'))
    for i, it in enumerate(H):
        if i in used:
            continue
        if it['kind'] == 'decl':
            res.append(('ADDED', f"{'private ' if it['private'] else ''}{it['keyword']} {it['name']} (head line "
                                 f"{it['line']})"))
        elif it['kind'] == 'cmd' and it['text'].startswith('import '):
            res.append(('ADDED', f"import: {it['text']}"))
        else:
            res.append(('BADADD', f"{it['kind']} at head line {it['line']}: {it['text'][:80]!r}"))
    return res, B, H


TAGKEY = re.compile(r'\[([A-Z][A-Za-z]+\d{2}[a-z]?)(?=[,;\]\s])')


def citations(text):
    """every bracketed citation group `[KEY …; KEY …]` in comments/docstrings, as (line, group text), the group
    read to its matching `]` (nesting counted outside backtick spans)."""
    out = []
    for m in TAGKEY.finditer(text):
        k, d, tick = m.start(), 0, False
        j = k
        while j < len(text):
            ch = text[j]
            if ch == '`':
                tick = not tick
            elif not tick and ch == '[':
                d += 1
            elif not tick and ch == ']':
                d -= 1
                if d == 0:
                    break
            j += 1
        out.append((text.count('\n', 0, k) + 1, norm(text[k:j + 1])))
    return out


LOC = re.compile(r'\b(Sections?|Lemmas?|Definitions?|Claims?|Corollar(?:y|ies)|Theorems?|Remarks?|Equations?|'
                 r'Figures?|Constructions?|Facts?|Propositions?)\s+((?:\d+(?:\.\d+)*)(?:\s*[–-]\s*\d+(?:\.\d+)*)?)')
EQN = re.compile(r'\((\d+\.\d+(?:\.\d+)*)\)')


def locators(group):
    """(key, kind, number) for every key-led part of a citation group."""
    out = []
    for part in group.strip('[]').split(';'):
        part = part.strip()
        m = re.match(r'([A-Z][A-Za-z]+\d{2}[a-z]?)\b', part)
        if not m:
            continue
        key = m.group(1)
        locs = [(a, b) for a, b in LOC.findall(part)] + [('Equation', e) for e in EQN.findall(part)]
        out.append((key, locs))
    return out
