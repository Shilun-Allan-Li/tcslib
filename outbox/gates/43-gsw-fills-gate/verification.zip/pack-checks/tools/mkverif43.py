"""mkverif43.py <repo> <checks-dir> <tools-dir> <pr-desc-dir> <out.zip>: the verification ZIP of Gate 43 (the GSW fill
gate: #339 gsw-core at 839f36cca9b4af0570c014f03f19858d0a03cbfb, #338 gsw-security at
d45d3682089cb6fd04f4d075f48a464fefaa143c). No Lean or lake is run.

Members are byte-identical originals:
- review-evidence/: the two maintainer delivery-review evidence ZIPs as filed in the records, with their manifests:
  gsw-security's records copy `evidence-SHA256SUMS` (equal to the ZIP's inner manifest), and for gsw-core the ZIP's
  inner `gsw-core-r1/SHA256SUMS` (the records copy `fills/gsw-core/final-r1/evidence-SHA256SUMS` is empty: a filing
  defect, recorded in pack-checks/manifests.txt);
- review-extracts/<unit>-r1/: byte copies of the review-evidence entries the pack cites (read from the ZIPs);
- worker/<unit>/: byte copies from the final delivery commits on the exchange: REPORT.md, the top-level SHA256SUMS,
  patches/COMMITS.tsv and the patch files;
- records/: the campaign records the pack cites, at the records commit REC (HEAD when this ZIP is built), each
  checked equal to the working tree, except the duplication ledger, taken from the working tree (the pin commit
  adds exactly these bytes: the DL-47 extension of GC-01; checked after the commit by stage43.py's pincheck);
- source-references/: the DW-7 scoped transcriptions (`.md`, `.raw.md`) of [GSW13], [AP14], [BV14] and [Pei16] and
  the tag registry sources.json, at REC;
- context/: library files at the records tip that the duplication questions compare against and that are not in
  sources.zip;
- pr/: the two PR descriptions as fetched from the GitHub REST API on 2026-11-16 (`.body`, raw);
- pack-checks/: the pack's re-checks from git objects, with their scripts (pack-checks/tools/).
Writes PROVENANCE.txt and SHA256SUMS (every other entry)."""
import collections, hashlib, os, subprocess, sys, zipfile

repo, chk, tools, prd, out = sys.argv[1:6]


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


REC = git('rev-parse', 'HEAD').decode().strip()
TIP = git('rev-parse', 'origin/cryptography/pass-shelat-ch2-4').decode().strip()
assert REC == TIP, 'build the ZIP on the records tip, before the pin commit'
sha = lambda b: hashlib.sha256(b).hexdigest()
members = []
FINAL = {'gsw-core': '9e52a5019258c51d67b1f28d3675c66cf787209b', 'gsw-security': '5857e850e7f7daf264d2860caf27341e3052f8c5'}


def rec(path, dst=None):
    b = git('show', f'{REC}:{path}')
    assert open(os.path.join(repo, path), 'rb').read() == b, f'working tree differs from {REC[:8]}: {path}'
    members.append((dst or f'records/{path}', b, f'records {REC[:8]}:{path}'))


def wtfile(path, dst):
    members.append((dst, open(os.path.join(repo, path), 'rb').read(), f'filed by the pin commit: {path}'))


# review evidence
for u in ('gsw-core', 'gsw-security'):
    rec(f'briefs/lattice-gsw/fills/{u}/final-r1/{u}-r1-evidence.zip', f'review-evidence/{u}-r1-evidence.zip')
rec('briefs/lattice-gsw/fills/gsw-security/final-r1/evidence-SHA256SUMS',
    'review-evidence/gsw-security-r1-evidence-SHA256SUMS')
zc = zipfile.ZipFile(os.path.join(repo, 'briefs/lattice-gsw/fills/gsw-core/final-r1/gsw-core-r1-evidence.zip'))
members.append(('review-evidence/gsw-core-r1-evidence-SHA256SUMS', zc.read('gsw-core-r1/SHA256SUMS'),
                'gsw-core-r1-evidence.zip entry gsw-core-r1/SHA256SUMS (the records copy is empty)'))
CITE = {
    'gsw-core': ['PROVENANCE.txt', 'statements/frozen-final.txt', 'statements/frozen-controls.txt',
                 'statements/decls2-note.txt', 'p2/merge-tree-current-tip.txt', 'p2/export-check.txt',
                 'p2/finish-post-build.out', 'p2/admissions/census-tip-vs-merged.diff', 'p2/summary/axioms-summary.txt',
                 'p2/summary/sealsum-seals-A.tsv', 'p2/summary/sealsum-seals-B.tsv', 'p2/summary/sealsum-seals-coe-A.tsv',
                 'p2/summary/sealsum-seals-coe-B.tsv', 'p2/summary/ctlcheck.log', 'p2/summary/error-counts.tsv',
                 'p2/probe-sources/GcMatcher.lean', 'p2/probe-sources/GcMatcherU.lean',
                 'p2/probe-runs/mods/GcProbe_GcMatcher.log', 'p2/probe-runs/mods/GcProbe_GcMatcherU.log',
                 'p2/statements/touched.tsv', 'rule10/unfold-scan-final.txt', 'rule10/unfold-scan-dispositions.txt',
                 'clash/clash-scan.txt', 'style/sketch-rule.txt', 'style/width-size.txt', 'sources/tags.txt',
                 'lint/lint-diff.txt', 'lint/lint-vs-delivered.txt', 'integrity/git-am-replay.log',
                 'integrity/files-vs-src.log', 'delivered-evidence-check/error-counts.txt',
                 'delivered-evidence-check/sorry-recount.txt', 'delivered-evidence-check/axioms-reparse.txt',
                 'delivered-evidence-check/seal-probes-vs-source.txt'],
    'gsw-security': ['PROVENANCE.txt', 'seal-summary.txt', 'controls-coe-A.out', 'controls-coe-B.out',
                     'controls-strict-A.out', 'controls-strict-B.out', 'build/buildsum.txt',
                     'admissions/census-tip-vs-M2.diff', 'probe-runs-1/mods/GsProbe_GsAxioms.log',
                     'out/headers/check_Columns.txt', 'out/headers/check_Security.txt',
                     'out/headers/controls_Columns.txt', 'out/headers/controls_Security.txt', 'out/unfold-scan.txt',
                     'out/merge-tree.txt', 'out/manifest-top.txt', 'out/manifest-evidence.txt',
                     'out/reconstructed/CacheProbe.lean', 'out/reconstructed/README.txt', 'out/patch-reproduction.txt',
                     'out/dup-searches-tip.txt', 'out/sources-tags.txt', 'out/widths.txt', 'out/lint/lint-compare.txt',
                     'out/sealprobe-check-delivered.txt', 'out/error-counts-delivered.txt', 'out/decls2-summary.txt'],
}
for u, lst in CITE.items():
    z = zipfile.ZipFile(os.path.join(repo, f'briefs/lattice-gsw/fills/{u}/final-r1/{u}-r1-evidence.zip'))
    top = f'{u}-r1'
    man = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in z.read(f'{top}/SHA256SUMS').decode().splitlines()}
    for c in lst:
        b = z.read(f'{top}/{c}')
        assert sha(b) == man[c], c
        members.append((f'review-extracts/{top}/{c}', b, f'{u}-r1-evidence.zip entry {top}/{c} (manifest {man[c][:12]}…)'))
# worker files from the exchange
for u, F in FINAL.items():
    root = f'inbox/fills/{u}/'
    paths = ['REPORT.md', 'SHA256SUMS', 'patches/COMMITS.tsv'] + sorted(
        p[len(root):] for p in git('ls-tree', '-r', '--name-only', F, root + 'patches/').decode().split()
        if p.endswith('.patch'))
    for p in paths:
        members.append((f'worker/{u}/{p}', git('show', f'{F}:{root}{p}'), f'exchange {F[:9]}:{root}{p}'))
# records
for u in ('gsw-core', 'gsw-security'):
    for f in ('README.md', 'brief.md', 'SHA256SUMS', 'base-sorries.txt', 'dispatch.md'):
        rec(f'briefs/lattice-gsw/fills/{u}/issued-r1/{f}')
    rec(f'briefs/lattice-gsw/fills/{u}/final-r1/review.md')
for p in ('briefs/lattice-gsw/rulings.md', 'briefs/lattice-gsw/questions.md', 'briefs/lattice-gsw/plan-section.md',
          'briefs/lattice-gsw/gates/41-gsw-statements/resolutions-r1.md',
          'briefs/lattice-gsw/gates/41-gsw-statements/findings/gate41-gsw-statements-findings.md',
          'LatticeCryptographyPlan.md', 'policy.md', 'briefs/pass-shelat-ch5-8/deferred-work.md',
          'briefs/pass-shelat-ch5-8/maintainer/tooling-followups.md'):
    rec(p)
wtfile('briefs/pass-shelat-ch5-8/duplication-ledger.md', 'records/briefs/pass-shelat-ch5-8/duplication-ledger.md')
# source references
for d in ('gentry-sahai-waters-2013-fhe', 'alperin-sheriff-peikert-2014-bootstrapping', 'brakerski-vaikuntanathan-2014-fhe',
          'peikert2016-lattice-survey'):
    for ext in ('.md', '.raw.md'):
        rec(f'blueprint/src/references/{d}{ext}', f'source-references/{d}{ext}')
rec('blueprint/src/references/sources.json', 'source-references/sources.json')
# context
for c in ('TCSlib/Cryptography/ZeroKnowledge/Commitment.lean', 'TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean',
          'TCSlib/Cryptography/Encryption/PublicKey/Hybrid.lean',
          'TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/SoundnessRep.lean',
          'TCSlib/Cryptography/SecureComputation/Garbling.lean', 'TCSlib/Cryptography/Encryption/Symmetric/Regev/Experiments.lean',
          'TCSlib/Cryptography/TrapdoorFunctions/Lossy/Experiments.lean', 'TCSlib/Cryptography/TrapdoorFunctions/Lossy/Matrix.lean',
          'TCSlib/Cryptography/Foundations/BitLists.lean'):
    members.append((f'context/{c}', git('show', f'{TIP}:{c}'), f'records tip {TIP[:8]}:{c}'))
for n in (338, 339):
    members.append((f'pr/pr-{n}-description.md', open(os.path.join(prd, f'pr-{n}-description.md'), 'rb').read(),
                    f'GitHub REST GET /repos/Shilun-Allan-Li/tcslib/pulls/{n}, .body, fetched 2026-11-16'))
for c in sorted(os.listdir(chk)):
    members.append((f'pack-checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
for t in ('chk43.py', 'lean43.py', 'gitlib.py', 'mksources43.py', 'mkverif43.py', 'stage43.py'):
    members.append((f'pack-checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
title = ('Gate 43 (GSW fills: draft PR #339 gsw-core, Lean head 839f36cca9b4af0570c014f03f19858d0a03cbfb; draft PR #338 '
         'gsw-security, Lean head d45d3682089cb6fd04f4d075f48a464fefaa143c)')
prov = (f'{title}: verification.zip\n\nBuilt from git objects and the records working tree, records commit REC = {REC} '
        f'(the records tip, before the pin). No Lean or lake was run.\n\n' + __doc__.split('\n\n', 1)[1] +
        '\nSources:\n' + ''.join(f'  {p}  <-  {d}\n' for p, _, d in sorted(members)))
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
assert len({p for p, _, _ in members}) == len(members), 'duplicate member'
sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
members.append(('SHA256SUMS', sums.encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as zz:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=(2026, 11, 16, 0, 0, 0))
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_STORED if p.endswith('.zip') else zipfile.ZIP_DEFLATED
        zz.writestr(zi, b)
with zipfile.ZipFile(out) as zz:
    listed = zz.namelist()
    inn = {l.split('  ', 1)[1] for l in zz.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == inn | {'SHA256SUMS'} and len(listed) == len(inn) + 1
    for l in zz.read('SHA256SUMS').decode().splitlines():
        h, p = l.split('  ', 1)
        assert sha(zz.read(p)) == h, p
print(f'OK: {len(listed)} entries {dict(collections.Counter(n.split("/")[0] for n in listed))}; '
      f'sha256 {sha(open(out, "rb").read())}; REC {REC}')
