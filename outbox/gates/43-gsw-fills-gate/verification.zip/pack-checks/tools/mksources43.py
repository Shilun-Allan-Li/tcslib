"""mksources43.py <repo> <out-dir>: the Gate 43 source files, from git objects only (the layout of
mksources4041.py, for two PRs with disjoint files on different bases):
- pr-339.diff.txt = git diff 347665bd..839f36cc (#339, gsw-core) and pr-338.diff.txt = git diff 15d8f01a..d45d3682
  (#338, gsw-security), each from the PR's merge base with the records tip to its head;
- source-head.json: per PR, the head, base, and for each changed file its status, SHA-256, line count and lines over
  100 characters;
- sources.zip: for each PR, the import closure (TCSlib modules) at its head of its changed files, under the prefix
  pr-<n>-<unit>/ (the two heads differ in the shared closure files: #338's head has gsw-core's files sorried); directory
  entries first, then files, each sorted; files deflated; dated 2026-11-16."""
import hashlib, json, os, sys, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure  # noqa: E402

repo, out = sys.argv[1:3]
R = Repo(repo)
TIP = R.rp('origin/cryptography/pass-shelat-ch2-4')
PRS = [(339, 'gsw-core', '839f36cca9b4af0570c014f03f19858d0a03cbfb'),
       (338, 'gsw-security', 'd45d3682089cb6fd04f4d075f48a464fefaa143c')]
DATE = (2026, 11, 16, 0, 0, 0)
os.makedirs(out, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
entries, meta, report = [], {}, []
for n, unit, head in PRS:
    base = R.git('merge-base', TIP, head).stdout.strip()
    diff = R.gitb('diff', f'{base}..{head}')
    open(os.path.join(out, f'pr-{n}.diff.txt'), 'wb').write(diff)
    st = {}
    for l in R.git('diff', '--name-status', '--no-renames', base, head).stdout.splitlines():
        s, p = l.split('\t')
        st[p] = s
    files = {}
    for p in sorted(st):
        b = R.blob(head, p)
        t = b.decode('utf-8')
        files[p] = dict(status=st[p], sha256=sha(b), lines=len(t.splitlines()),
                        lines_over_100=sum(len(x) > 100 for x in t.splitlines()))
    meta[f'#{n}'] = dict(unit=unit, head=head, base=base, files=files)
    g = R.graph(head)
    clo = sorted(p for p in set().union(*[closure(g, [p]) for p in st if p.endswith('.lean')])
                 if p.startswith('TCSlib'))
    pre = f'pr-{n}-{unit}/'
    entries += [(pre + p, R.blob(head, p)) for p in clo]
    report.append(f'#{n}: pr-{n}.diff.txt {len(diff)} bytes sha256 {sha(diff)} '
                  f'({R.git("diff", "--shortstat", base, head).stdout.strip()}); closure {len(clo)} files')
names = [e[0] for e in entries]
dirs = sorted({'/'.join(p.split('/')[:k]) + '/' for p in names for k in range(1, p.count('/') + 1)})
with zipfile.ZipFile(os.path.join(out, 'sources.zip'), 'w') as z:
    for name in dirs:
        zi = zipfile.ZipInfo(name, date_time=DATE); zi.create_system = 3
        zi.external_attr = 0o40755 << 16
        z.writestr(zi, b'')
    for name, b in sorted(entries):
        zi = zipfile.ZipInfo(name, date_time=DATE); zi.create_system = 3
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
js = json.dumps(dict(records_tip=TIP, prs=meta), indent=1, ensure_ascii=False)
open(os.path.join(out, 'source-head.json'), 'w', encoding='utf-8').write(js + '\n')
print('\n'.join(report))
print(f'sources.zip {len(entries)} files ({len(dirs)} directories), sha256 '
      f'{sha(open(os.path.join(out, "sources.zip"), "rb").read())}')
