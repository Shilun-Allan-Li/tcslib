"""stage43.py <records-repo> <records-pin> <exchange-wt> <mkbundle2.py>: write the outbox of Gate 43 (the GSW fill
gate, #339 gsw-core and #338 gsw-security) in the layout of the Gate 39/41 packs: README.md, pack.md, bundle.md,
BUNDLE-FILES.txt, LEAN-HEAD.txt, RECORDS.txt, SHA256SUMS, and byte copies (git show at the records pin, checked equal to
the working tree) of the gate directory's pr-338.diff.txt, pr-339.diff.txt, source-head.json, sources.zip and
verification.zip. bundle.md is built by the maintainer tool mkbundle2.py from BUNDLE-FILES.txt (`<rev> <path>` per
section, each section verified against `git show`): the pack and the records it needs at the pin, the two worker
REPORTs at their final exchange commits, the DW-7 transcriptions at the pin, and the 7 changed Lean files at the heads.

pincheck: before writing, every verification.zip member that the ZIP's PROVENANCE marks "filed by the pin commit" is
compared with that path's blob at the pin (byte-identical, or the stage stops); the gate directory's SHA256SUMS is
verified at the pin."""
import hashlib, os, re, subprocess, sys, tempfile, zipfile

repo, pin, wt, mkb = sys.argv[1:5]


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


show = lambda rev, path: git('show', f'{rev}:{path}')
sha = lambda b: hashlib.sha256(b).hexdigest()
pin = git('rev-parse', pin).decode().strip()
G = 'briefs/lattice-gsw/gates/43-gsw-fills'
OUT = 'outbox/gates/43-gsw-fills-gate'
H9, H8 = '839f36cca9b4af0570c014f03f19858d0a03cbfb', 'd45d3682089cb6fd04f4d075f48a464fefaa143c'
F9, F8 = '9e52a5019258c51d67b1f28d3675c66cf787209b', '5857e850e7f7daf264d2860caf27341e3052f8c5'
GS = 'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/'
stem = 'gate43-gsw-fills'

# pincheck
vz = zipfile.ZipFile(os.path.join(repo, G, 'verification.zip'))
prov = vz.read('PROVENANCE.txt').decode()
filed = re.findall(r'^  (\S+)  <-  filed by the pin commit: (\S+)$', prov, re.M)
assert filed
for member, path in filed:
    assert vz.read(member) == show(pin, path), f'pincheck: {member} != {pin[:8]}:{path}'
print(f'pincheck: {len(filed)} member(s) equal to their blobs at the pin')
rows = [l.split('  ', 1) for l in show(pin, f'{G}/SHA256SUMS').decode().splitlines() if l.strip()]
assert all(sha(show(pin, f'{G}/{p}')) == h for h, p in rows), 'records SHA256SUMS'
print(f'records {G}/SHA256SUMS: {len(rows)}/{len(rows)} verify at the pin')

files = {}
for f in ('pack.md', 'pr-338.diff.txt', 'pr-339.diff.txt', 'source-head.json', 'sources.zip', 'verification.zip'):
    b = show(pin, f'{G}/{f}')
    assert open(os.path.join(repo, G, f), 'rb').read() == b, f'working tree differs from {pin[:8]}: {f}'
    files[f] = b
listing = [(pin, f'{G}/pack.md'), (pin, 'policy.md'),
           (pin, 'briefs/lattice-gsw/fills/gsw-core/final-r1/review.md'),
           (pin, 'briefs/lattice-gsw/fills/gsw-security/final-r1/review.md'),
           (F9, 'inbox/fills/gsw-core/REPORT.md'), (F8, 'inbox/fills/gsw-security/REPORT.md'),
           (pin, 'briefs/lattice-gsw/fills/gsw-core/issued-r1/brief.md'),
           (pin, 'briefs/lattice-gsw/fills/gsw-security/issued-r1/brief.md'),
           (pin, 'briefs/lattice-gsw/rulings.md'),
           (pin, 'briefs/lattice-gsw/gates/41-gsw-statements/resolutions-r1.md'),
           (pin, 'briefs/lattice-gsw/gates/41-gsw-statements/findings/gate41-gsw-statements-findings.md'),
           (pin, 'briefs/pass-shelat-ch5-8/duplication-ledger.md')]
listing += [(pin, f'blueprint/src/references/{d}.md') for d in
            ('gentry-sahai-waters-2013-fhe', 'alperin-sheriff-peikert-2014-bootstrapping',
             'brakerski-vaikuntanathan-2014-fhe', 'peikert2016-lattice-survey')]
listing += [(H9, GS + f + '.lean') for f in ('Gadget', 'Noise', 'Scheme', 'Symmetric', 'Eval')]
listing += [(H8, GS + 'Security.lean'), (H8, 'TCSlib/Cryptography/Hashing/SIS/Columns.lean')]
files['BUNDLE-FILES.txt'] = ''.join(f'{r} {p}\n' for r, p in listing).encode()
with tempfile.TemporaryDirectory() as td:
    lp, bp = os.path.join(td, 'list.txt'), os.path.join(td, 'bundle.md')
    open(lp, 'wb').write(files['BUNDLE-FILES.txt'])
    r = subprocess.run([sys.executable, '-I', mkb, repo, bp, lp], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    print('mkbundle2:', r.stdout.strip())
    files['bundle.md'] = open(bp, 'rb').read()
files['LEAN-HEAD.txt'] = f'#339 {H9}\n#338 {H8}\n'.encode()
files['RECORDS.txt'] = f'{pin}\n'.encode()
files['README.md'] = f"""# Codex audit · Gate 43 GSW fills (#339 gsw-core and #338 gsw-security, audited together)

Audit draft PR #339 (gsw-core: gadget, noise algebra, public- and secret-key GSW, circuit evaluation; 29 targets) at
{H9} and draft PR #338 (gsw-security: the column leftover-hash hybrid and IND-CPA of
public-key GSW; 6 targets) at {H8}, using the scope in pack.md: a **proof audit** of the
35 frozen GSW targets of phase 5 of the lattice campaign, whose statements Gate 41 accepted. Campaign records are
pinned at {pin}.

**Gate number.** Gate 42 is reserved for sc-yao (Pass-shelat campaign). The phase-6 plan
(`briefs/lattice-gsw/phase6/plan-section.md`) uses 42 and 43 as provisional numbers for its two statement gates; those
will be renumbered later. This gate, 43, is the phase-5 fill gate.

The bundle contains the pack, policy, the two delivery reviews, the two worker REPORTs (from their final exchange
commits), the two issued briefs, the GSW rulings, Gate 41's resolutions and findings, the duplication ledger, the DW-7
scoped transcriptions of [GSW13], [AP14], [BV14] and [Pei16], and the 7 changed Lean files at their heads.

Also:
- pr-339.diff.txt and pr-338.diff.txt: the full diff of each PR from its merge base with the records tip to its head;
- source-head.json: the heads, bases, hashes, line counts and over-width counts of the 7 changed files;
- sources.zip: for each PR, the import closure at its head of its changed files (25 + 25 files), under the prefixes
  pr-339-gsw-core/ and pr-338-gsw-security/ (the heads differ in the shared closure: at #338's head gsw-core's files
  are still sorried);
- verification.zip: the two review evidence ZIPs with their manifests, byte copies of the entries the pack cites, the
  worker REPORTs, manifests and patches, the cited records, the DW-7 transcriptions, context files for the duplication
  questions, the PR descriptions and the pack's git-object re-checks with their scripts (pack-checks/); its entries
  are exactly its SHA256SUMS plus SHA256SUMS.

The workers' own evidence is on this branch under inbox/fills/gsw-core/ (final commit {F9}) and
inbox/fills/gsw-security/ (final commit {F8}).

Check SHA256SUMS before using the pack.

Return {stem}-findings.md as Markdown in the chat, with findings marked by PR. If you have several evidence files,
return a ZIP containing that Markdown and the evidence. The user dispatches and merges.
""".encode()
out = os.path.join(wt, OUT)
assert not os.path.exists(out), out
os.makedirs(out)
for p, b in files.items():
    open(os.path.join(out, p), 'wb').write(b)
files['SHA256SUMS'] = ''.join(f'{sha(files[p])}  {p}\n' for p in sorted(files)).encode()
open(os.path.join(out, 'SHA256SUMS'), 'wb').write(files['SHA256SUMS'])
print(OUT, len(files) - 1, 'listed; SHA256SUMS', sha(files['SHA256SUMS']), '; bundle', sha(files['bundle.md']),
      f'({len(listing)} sections); verification.zip', sha(files['verification.zip']), '; sources.zip',
      sha(files['sources.zip']))
