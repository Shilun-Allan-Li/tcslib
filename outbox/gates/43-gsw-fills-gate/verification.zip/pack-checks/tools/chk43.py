"""chk43.py <repo> <out-dir> <pr-json-dir>: the Gate 43 pack re-checks (gsw-core #339, gsw-security #338), from git
objects only (no Lean, no lake, no checkout). Writes into <out-dir>:

  series.txt     PR metadata (REST, fetched 2026-11-16), merge bases, the landed commits with their signature
                 headers verified (SSH ed25519, with the python `cryptography` package) and the delivered commits;
                 per-commit patch-id, author and author-date equality; git range-diff; the changed paths' blobs at
                 the issue base and the PR base; `git diff base..head` = `git diff issue..delivered` byte for byte
  delivery.txt   diff-equals-delivery: each PR head's changed files = the delivery's src/ at the final exchange
                 commit = the delivered head; the delivered patches' patch-ids = the landed commits'; COMMITS.tsv
                 = the delivered commits; the delivery commits touch only inbox/fills/<unit>/
  manifests.txt  the deliveries' SHA256SUMS (top level and evidence/) verified from git objects; the review
                 evidence ZIPs' inner manifests; the records' evidence-SHA256SUMS copies; the issue packages
  frozen.txt     the frozen-statement re-check (lean43.compare) of the 7 files, PR base vs PR head, with controls;
                 and a re-run of the two reviews' own frozen-check tools on the same blobs, when given (--revtools)
  sorries.txt    the 35 targets: base body `sorry`, head body sorry-free; sorry tokens per file base -> head
  docs.txt       widths and lengths; micro sign, tabs, trailing spaces, @[simp], attribute commands; the sketch rule
                 (proofs of >= 15 lines carry `**Proof sketch.**`); target sketches rewritten or kept; new
                 declarations and their docstrings
  sources.txt    citation groups base vs head (multiset), the keys' registry entries and DW-7 transcriptions, and a
                 locator lookup (kind + number) in each transcription (an aid, not a verdict)
  names.txt      new declaration names against every declaration name in TCSlib/ and audits/ at the tip
  mergetrees.txt git merge-tree of each head with the tip, with each other and with the other open PRs on the base;
                 the combined #338+#339 tree against the tip; shared paths
  downstream.txt modules downstream of both PRs (import graph of the combined tree)
  dupscan.txt    mechanical aids for the duplication questions: occurrences of the reviewed patterns in the added
                 lines and of the named relatives at the tip
"""
import base64, collections, hashlib, json, os, re, subprocess, sys, tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream  # noqa: E402
import lean43  # noqa: E402

repo, OUT, PRJ = sys.argv[1:4]
REVTOOLS = sys.argv[sys.argv.index('--revtools') + 1] if '--revtools' in sys.argv else None
R = Repo(repo)
sha = lambda b: hashlib.sha256(b).hexdigest()
TIP = R.rp('origin/cryptography/pass-shelat-ch2-4')
EXCH = R.rp('origin/exchange/pass-shelat-ch5-8')
ISSUE = '486f44f8414c20a2d21e452c44de8b8c8d8513a0'
G = 'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/'
PRS = {
    339: dict(unit='gsw-core', branch='land/lattice-gsw-core', head='839f36cca9b4af0570c014f03f19858d0a03cbfb',
              delivered='d4ebb0be088e5985337ccb4e0a61cb3a662e8b73',
              final='9e52a5019258c51d67b1f28d3675c66cf787209b', ckpt='5b72e346bd5484fb059cbaadd836de88f4adf0a2',
              files=[G + f + '.lean' for f in ('Gadget', 'Noise', 'Scheme', 'Symmetric', 'Eval')]),
    338: dict(unit='gsw-security', branch='land/lattice-gsw-security', head='d45d3682089cb6fd04f4d075f48a464fefaa143c',
              delivered='a9f97eddb42c7dfc0422fa8c9ce998c658bfa4f8',
              final='5857e850e7f7daf264d2860caf27341e3052f8c5', ckpt='b08456186ebfa194f8445f1f78ba7c0743e4991b',
              files=[G + 'Security.lean', 'TCSlib/Cryptography/Hashing/SIS/Columns.lean']),
}
OTHER_OPEN = {331: 'stmt/pairings', 327: 'land/pass-shelat-seq-zk', 324: 'land/pass-shelat-sc-compose'}
TARGETS = {}
for l in R.show(TIP, 'briefs/lattice-gsw/fills/gsw-core/issued-r1/base-sorries.txt').splitlines():
    if l.startswith('TOTAL') or ':' not in l:
        continue
    m, n, names = l.split(':', 2)
    TARGETS[m + '.lean'] = [x.strip() for x in names.split(',')]
assert sum(len(v) for v in TARGETS.values()) == 35
for n, d in PRS.items():
    d['base'] = R.git('merge-base', TIP, d['head']).stdout.strip()
    d['targets'] = {f: TARGETS[f] for f in d['files']}
files = {}


def out(name, text):
    files[name] = text
    open(os.path.join(OUT, name), 'w', encoding='utf-8').write(text)


# ---------------------------------------------------------------- signatures
def ssh_sig(commit, tamper=False):
    raw = R.gitb('cat-file', 'commit', commit)
    if tamper:  # negative control: one changed byte in the signed payload must fail verification
        raw = raw.replace(b'\ncommitter ', b'\ncommitter  ', 1)
    lines = raw.split(b'\n')
    sig, rest, i = [], [], 0
    while i < len(lines):
        l = lines[i]
        if l == b'':
            rest.extend(lines[i:]); break
        if l.startswith(b'gpgsig '):
            sig.append(l[7:]); i += 1
            while i < len(lines) and lines[i].startswith(b' '):
                sig.append(lines[i][1:]); i += 1
            continue
        rest.append(l); i += 1
    if not sig:
        return dict(n=0)
    payload = b'\n'.join(rest)
    armor = b'\n'.join(sig).decode()
    blob = base64.b64decode(''.join(x for x in armor.splitlines() if not x.startswith('-----')))

    def rd(b, k):
        n = int.from_bytes(b[k:k + 4], 'big'); return b[k + 4:k + 4 + n], k + 4 + n
    assert blob[:6] == b'SSHSIG'
    k = 10
    pub, k = rd(blob, k); ns, k = rd(blob, k); _, k = rd(blob, k); halg, k = rd(blob, k); sigblob, k = rd(blob, k)
    fp = 'SHA256:' + base64.b64encode(hashlib.sha256(pub).digest()).decode().rstrip('=')
    ktype, kk = rd(pub, 0)
    st, kk2 = rd(sigblob, 0)
    sigraw, _ = rd(sigblob, kk2)
    h = hashlib.sha512(payload).digest() if halg == b'sha512' else hashlib.sha256(payload).digest()

    def s(x):
        return len(x).to_bytes(4, 'big') + x
    signed = b'SSHSIG' + s(ns) + s(b'') + s(halg) + s(h)
    ok = None
    if ktype == b'ssh-ed25519':
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            keyraw, _ = rd(pub, kk)
            Ed25519PublicKey.from_public_bytes(keyraw).verify(sigraw, signed)
            ok = True
        except ImportError:
            ok = None
        except Exception:
            ok = False
    return dict(n=sum(1 for l in lines if l.startswith(b'gpgsig ')), fp=fp, ns=ns.decode(), alg=halg.decode(),
                ktype=ktype.decode(), ok=ok)


def cinfo(c):
    f = R.git('show', '-s', '--format=%H%x00%an <%ae>%x00%ad%x00%cn <%ce>%x00%cd%x00%s', '--date=raw', c).stdout
    return dict(zip(['hash', 'author', 'adate', 'committer', 'cdate', 'subject'], f.rstrip('\n').split('\x00')))


def patch_id(c):
    p = subprocess.run(['git', '-C', repo, 'show', '--format=', '--no-color', c], capture_output=True, check=True).stdout
    r = subprocess.run(['git', '-C', repo, 'patch-id', '--stable'], input=p, capture_output=True, check=True).stdout
    return r.split()[0].decode() if r.strip() else ''


def patch_id_text(b):
    r = subprocess.run(['git', '-C', repo, 'patch-id', '--stable'], input=b, capture_output=True, check=True).stdout
    return r.split()[0].decode() if r.strip() else ''


# ---------------------------------------------------------------- series.txt
L = [f'records tip (origin/cryptography/pass-shelat-ch2-4) {TIP}', f'exchange tip (origin/exchange/pass-shelat-ch5-8) {EXCH}',
     f'issue base of both fills {ISSUE} (#333 head; ancestor of the tip: {R.anc(ISSUE, TIP)})', '']
tipsig = ssh_sig(TIP)
L.append(f'records tip commit signature: headers {tipsig.get("n")}, key {tipsig.get("fp")}, namespace {tipsig.get("ns")}, '
         f'verified {tipsig.get("ok")}')
neg = ssh_sig(TIP, tamper=True)
L.append(f'signature control: the same commit with one byte added to its committer line verifies: {neg.get("ok")} '
         f'(expected False)')
L.append('')
for n, d in sorted(PRS.items()):
    pj = json.load(open(os.path.join(PRJ, f'pr-{n}.json')))
    L.append(f'=== PR #{n} ({d["unit"]}) ===')
    L.append(f'REST (fetched 2026-11-16): state {pj["state"]}, draft {pj["draft"]}, base ref {pj["base"]["ref"]}, '
             f'base sha {pj["base"]["sha"]}, head ref {pj["head"]["ref"]}, head sha {pj["head"]["sha"]}; '
             f'changed_files {pj["changed_files"]}, +{pj["additions"]}/-{pj["deletions"]}')
    L.append(f'origin/{d["branch"]} = {R.rp("origin/" + d["branch"])} (= head {d["head"]}: '
             f'{R.rp("origin/" + d["branch"]) == d["head"]}); REST head sha equal: {pj["head"]["sha"] == d["head"]}')
    L.append(f'head tree {R.rp(d["head"] + "^{tree}")}')
    L.append(f'merge base with the tip = PR base {d["base"]} (REST base sha equal: {pj["base"]["sha"] == d["base"]}); '
             f'issue base an ancestor of the PR base: {R.anc(ISSUE, d["base"])}')
    lean_delta = R.git('diff', '--name-only', d['base'], TIP, '--', '*.lean', 'lakefile.lean', 'lake-manifest.json',
                       'lean-toolchain').stdout.split()
    L.append(f'Lean/lake paths changed between the PR base and the tip: {len(lean_delta)} (the tip adds records only)')
    landed = R.git('rev-list', '--reverse', f'{d["base"]}..{d["head"]}').stdout.split()
    deliv = R.git('rev-list', '--reverse', f'{ISSUE}..{d["delivered"]}').stdout.split()
    d['landed'], d['deliv'] = landed, deliv
    L.append(f'landed commits {d["base"][:8]}..{d["head"][:8]}: {len(landed)}; delivered commits '
             f'{ISSUE[:8]}..{d["delivered"][:8]}: {len(deliv)}')
    for a, b in zip(landed, deliv):
        ia, ib = cinfo(a), cinfo(b)
        sa, sb = ssh_sig(a), ssh_sig(b)
        pa, pb = patch_id(a), patch_id(b)
        L.append(f'  landed    {a} | gpgsig {sa["n"]} {sa.get("ktype","")} {sa.get("fp","")} ns={sa.get("ns","")} '
                 f'verified={sa.get("ok")} | author {ia["author"]} {ia["adate"]} | committer {ia["committer"]} | '
                 f'{ia["subject"]}')
        L.append(f'  delivered {b} | gpgsig {sb["n"]} | author {ib["author"]} {ib["adate"]} | committer '
                 f'{ib["committer"]} {ib["cdate"]} | {ib["subject"]}')
        L.append(f'    patch-id landed {pa} delivered {pb} equal {pa == pb}; author equal {ia["author"] == ib["author"]}; '
                 f'author date equal {ia["adate"] == ib["adate"]}; subject equal {ia["subject"] == ib["subject"]}; '
                 f'same key as the records tip {sa.get("fp") == tipsig.get("fp")}')
    rd = R.git('range-diff', '--no-color', f'{ISSUE}..{d["delivered"]}', f'{d["base"]}..{d["head"]}').stdout
    L.append('git range-diff issue..delivered base..head:')
    L.extend('  ' + x for x in rd.rstrip('\n').split('\n'))
    L.append(f'  all "=": {all(" = " in x for x in rd.strip().splitlines())}')
    for p in d['files']:
        bi, bb = R.blob(ISSUE, p), R.blob(d['base'], p)
        L.append(f'  {p}: blob at issue base = blob at PR base: {bi == bb} (sha256 {sha(bb)[:16]}…)')
    pr_diff = R.gitb('diff', f'{d["base"]}..{d["head"]}')
    dl_diff = R.gitb('diff', f'{ISSUE}..{d["delivered"]}')
    three = R.gitb('diff', f'{TIP}...{d["head"]}')
    d['diff'] = pr_diff
    L.append(f'git diff base..head (pr-{n}.diff.txt): {len(pr_diff)} bytes, sha256 {sha(pr_diff)}; '
             f'{R.git("diff", "--shortstat", d["base"], d["head"]).stdout.strip()}')
    L.append(f'  = git diff {ISSUE[:8]}..{d["delivered"][:8]} (the delivered series) byte for byte: {pr_diff == dl_diff}')
    L.append(f'  = git diff tip...head (three-dot, GitHub\'s view) byte for byte: {pr_diff == three}')
    paths = R.git('diff', '--name-only', d['base'], d['head']).stdout.split()
    L.append(f'  changed paths ({len(paths)}) = the owned files: {sorted(paths) == sorted(d["files"])}')
    L.append('')
out('series.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- delivery.txt
L = []
for n, d in sorted(PRS.items()):
    u, F = d['unit'], d['final']
    root = f'inbox/fills/{u}/'
    L.append(f'=== PR #{n} ({u}): delivery {F} (final), {d["ckpt"]} (checkpoint 1) ===')
    L.append(f'final and checkpoint on the exchange tip {EXCH[:8]}: {R.anc(F, EXCH)}, {R.anc(d["ckpt"], EXCH)}')
    for c in (d['ckpt'], F):
        ch = R.git('diff-tree', '--no-commit-id', '--name-only', '-r', f'{c}^', c).stdout.split()
        L.append(f'  {c[:9]} ({cinfo(c)["subject"]}): {len(ch)} paths changed, all under {root}: '
                 f'{all(x.startswith(root) for x in ch)}')
    later = R.git('log', '--format=%H', f'{F}..{EXCH}', '--', root).stdout.split()
    L.append(f'  commits after the final touching {root}: {len(later)}')
    srcs = [p[len(root) + 4:] for p in R.git('ls-tree', '-r', '--name-only', F, root + 'src/').stdout.split()]
    L.append(f'  src/ paths = the PR\'s changed paths: {sorted(srcs) == sorted(d["files"])} ({len(srcs)})')
    for p in d['files']:
        s, h, dv = R.blob(F, root + 'src/' + p), R.blob(d['head'], p), R.blob(d['delivered'], p)
        L.append(f'  {p}: src/ = PR head {s == h}; delivered head = PR head {dv == h}; sha256 {sha(h)}')
    pats = sorted(p for p in R.git('ls-tree', '--name-only', F, root + 'patches/').stdout.split() if p.endswith('.patch'))
    L.append(f'  patches: {len(pats)} (landed commits {len(d["landed"])})')
    for p, c in zip(pats, d['landed']):
        b = R.blob(F, p)
        pi, pc = patch_id_text(b), patch_id(c)
        m = re.match(rb'From ([0-9a-f]{40})', b)
        L.append(f'    {p.split("/")[-1]}: From {m.group(1).decode() if m else "?"}; patch-id {pi} = landed '
                 f'{c[:12]} {pc}: {pi == pc}')
    tsv = R.show(F, root + 'patches/COMMITS.tsv').splitlines()
    rows = [r.split('\t') for r in tsv[1:] if r.strip()]
    L.append(f'  COMMITS.tsv: {len(rows)} rows; hashes = the delivered series {[r[0] for r in rows] == d["deliv"]}; '
             f'signing column {sorted({r[-1] for r in rows})}')
    for r, c in zip(rows, d['deliv']):
        ci = R.git('show', '-s', '--format=%an|%ae|%aI|%cn|%ce|%cI', c).stdout.strip().split('|')
        L.append(f'    {r[0][:12]}: author/committer identities and ISO dates in the row: '
                 f'{all(x in r for x in ci)}')
    L.append('')
out('delivery.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- manifests.txt
L = []


def tree_blobs(rev, root):
    res = {}
    for l in R.git('ls-tree', '-r', rev, root).stdout.splitlines():
        meta, p = l.split('\t', 1)
        res[p[len(root):]] = meta.split()[2]
    return res


for n, d in sorted(PRS.items()):
    u, F = d['unit'], d['final']
    root = f'inbox/fills/{u}/'
    tb = tree_blobs(F, root)
    L.append(f'=== {u} delivery at {F} ({len(tb)} files under {root}) ===')
    for man, pre in (('SHA256SUMS', ''), ('evidence/SHA256SUMS', 'evidence/')):
        rows = [x.split('  ', 1) for x in R.show(F, root + man).splitlines() if x.strip()]
        listed = {pre + p for _, p in rows}
        have = {p for p in tb if p.startswith(pre) and p != man}
        bad = [p for h, p in rows if pre + p in tb and sha(R.blob(F, root + pre + p)) != h]
        miss = sorted(listed - set(tb))
        extra = sorted(have - listed) if pre == 'evidence/' else sorted(set(tb) - listed - {man})
        L.append(f'  {man}: {len(rows)} rows; present {len(listed & set(tb))}; hash mismatches {len(bad)}; '
                 f'missing {len(miss)} {miss}; unlisted {len(extra)} {extra[:5]}; "./" prefixes '
                 f'{sum(p.startswith("./") for _, p in rows)}')
    pyc = [p for p in tb if p.endswith('.pyc')]
    L.append(f'  compiled artifacts delivered: {pyc}')
    L.append('')
import zipfile  # noqa: E402
for u, top in (('gsw-core', 'gsw-core-r1'), ('gsw-security', 'gsw-security-r1')):
    zp = os.path.join(repo, f'briefs/lattice-gsw/fills/{u}/final-r1/{u}-r1-evidence.zip')
    zb = open(zp, 'rb').read()
    assert zb == R.blob(TIP, f'briefs/lattice-gsw/fills/{u}/final-r1/{u}-r1-evidence.zip')
    z = zipfile.ZipFile(zp)
    names = [x for x in z.namelist() if not x.endswith('/')]
    man = z.read(f'{top}/SHA256SUMS')
    rows = [x.split('  ', 1) for x in man.decode().splitlines()]
    ok = sum(sha(z.read(f'{top}/{p}')) == h for h, p in rows)
    rec = R.blob(TIP, f'briefs/lattice-gsw/fills/{u}/final-r1/evidence-SHA256SUMS')
    L.append(f'=== review evidence {u}-r1-evidence.zip (records tip, sha256 {sha(zb)}) ===')
    L.append(f'  {len(names)} entries; inner {top}/SHA256SUMS {len(rows)} rows, {ok} verify; entries = rows + the manifest: '
             f'{set(names) == {f"{top}/{p}" for _, p in rows} | {f"{top}/SHA256SUMS"}}; inner manifest sha256 {sha(man)}')
    L.append(f'  records copy fills/{u}/final-r1/evidence-SHA256SUMS: {len(rec)} bytes; equal to the inner manifest: '
             f'{rec == man}' + ('  <- EMPTY: a records filing defect; the inner manifest is authoritative'
                                if len(rec) == 0 else ''))
    L.append('')
for u in ('gsw-core', 'gsw-security'):
    root = f'briefs/lattice-gsw/fills/{u}/issued-r1/'
    rows = [x.split('  ', 1) for x in R.show(TIP, root + 'SHA256SUMS').splitlines() if x.strip()]
    ok = sum(sha(R.blob(TIP, root + p)) == h for h, p in rows)
    L.append(f'issue package {root}: SHA256SUMS {ok}/{len(rows)} verify at the records tip')
    ex = R.git('ls-tree', '-r', '--name-only', EXCH, f'outbox/fills/{u}/').stdout.split()
    same = sum(R.blob(EXCH, p) == R.blob(TIP, root + p.split('/', 3)[3]) for p in ex if R.blob(TIP, root + p.split('/', 3)[3]))
    L.append(f'  exchange outbox/fills/{u}/ at {EXCH[:8]}: {len(ex)} files, {same} byte-identical to the records copy')
out('manifests.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- frozen.txt and sorries.txt
L, S = [], []
tot = collections.Counter()
for n, d in sorted(PRS.items()):
    for p in d['files']:
        bt, ht = R.show(d['base'], p), R.show(d['head'], p)
        tg = set(d['targets'][p])
        res, B, H = lean43.compare(bt, ht, tg)
        c = collections.Counter(code for code, _ in res)
        tot.update(c)
        bd = [x for x in B if x['kind'] == 'decl']
        L.append(f'#{n} {p}: base {len(B)} items ({len(bd)} declarations), head {len(H)} items; targets {len(tg)}; '
                 f'DIFF {c["DIFF"]} REMOVED {c["REMOVED"]} ORDER {c["ORDER"]} BADADD {c["BADADD"]} ADDED {c["ADDED"]}')
        L.extend(f'    {code}: {msg}' for code, msg in res)
        hd = {x['name']: x for x in H if x['kind'] == 'decl'}
        for t in d['targets'][p]:
            b = next(x for x in bd if x['name'] == t)
            h = hd[t]
            S.append(f'#{n} {p.split("/")[-1]} {t}: base line {b["line"]} body sorry {lean43.body_is_sorry(b)}; head line '
                     f'{h["line"]} sorry-free {not lean43.has_sorry(h["body"])}; header identical {b["header"] == h["header"]}')
        S.append(f'#{n} {p}: sorry tokens (comments stripped) {lean43.sorry_count(bt)} -> {lean43.sorry_count(ht)}')
L.append(f'TOTAL over the 7 files: {dict(tot)}')
# controls on one file per PR
L.append('')
L.append('Controls (each mutates the head text in memory; expected count in brackets):')
for n, p, t, reader, defn in ((339, G + 'Noise.lean', 'Encrypts.mul', 'encrypts_iff', 'mul'),
                              (338, G + 'Security.lean', 'distAdv_encrypt_le', 'realView_eq', 'reduction')):
    d = PRS[n]
    bt, ht = R.show(d['base'], p), R.show(d['head'], p)
    tg = set(d['targets'][p])
    H = lean43.split_items(ht)
    hd = {x['name']: x for x in H if x['kind'] == 'decl'}
    tgt, rdr, dfn = hd[t], hd[reader], hd[defn]

    def run(txt):
        return collections.Counter(code for code, _ in lean43.compare(bt, txt, tg)[0])
    hdr = tgt['header']
    i = hdr.find(':', hdr.find(t) + len(t))
    m1 = ht.replace(hdr, hdr[:i] + ' ' + hdr[i:], 1)
    sk = tgt['doc']
    m2 = ht.replace(sk, sk.replace(lean43.SKETCH, lean43.SKETCH + ' (edited)', 1), 1) if lean43.SKETCH in sk else ht
    m3 = ht.replace(rdr['text'] + '\n', '', 1)
    pr = sk.find(lean43.SKETCH)
    m4 = ht.replace(sk, sk[:pr - 2] + 'X' + sk[pr - 2:], 1)
    m5 = ht.replace(dfn['text'], dfn['text'].rstrip() + ' ', 1) if dfn['text'] in ht else ht
    base_c = run(ht)
    for label, txt, exp in (('identity', ht, 'DIFF 0, REMOVED 0'), ('one header character of ' + t, m1, 'DIFF 1'),
                            ('sketch-only edit of ' + t, m2, 'DIFF 0'), ('deleted reader ' + reader, m3, 'REMOVED 1'),
                            ('one prose character of ' + t, m4, 'DIFF 1'),
                            ('one character of the definition ' + defn, m5, 'DIFF 1')):
        c = run(txt)
        L.append(f'  #{n} {p.split("/")[-1]} {label}: DIFF {c["DIFF"]} REMOVED {c["REMOVED"]} ORDER {c["ORDER"]} '
                 f'[{exp}]; text changed {txt != ht}')
if REVTOOLS:
    L.append('')
    L.append('Re-run of the reviews\' own tools (unmodified, from the review evidence ZIPs) on the PR base/head blobs:')
    with tempfile.TemporaryDirectory() as td:
        for n, d in sorted(PRS.items()):
            tool = (os.path.join(REVTOOLS, 'gsw-core-r1', 'frozen.py') if n == 339 else
                    os.path.join(REVTOOLS, 'gsw-security-r1', 'frozen_check.py'))
            for p in d['files']:
                bp, hp = os.path.join(td, 'base.lean'), os.path.join(td, 'head.lean')
                open(bp, 'wb').write(R.blob(d['base'], p)); open(hp, 'wb').write(R.blob(d['head'], p))
                r = subprocess.run([sys.executable, '-I', tool, bp, hp, ','.join(d['targets'][p])], capture_output=True,
                                   text=True, cwd=td)
                last = [x for x in r.stdout.strip().splitlines() if x.strip()]
                L.append(f'  #{n} {os.path.basename(tool)} {p.split("/")[-1]}: rc {r.returncode}; ' +
                         ' | '.join(last[-3:]))
out('frozen.txt', '\n'.join(L) + '\n')
out('sorries.txt', '\n'.join(S) + '\n')

# ---------------------------------------------------------------- docs.txt
L = []
for n, d in sorted(PRS.items()):
    for p in d['files']:
        ht, bt = R.show(d['head'], p), R.show(d['base'], p)
        ls = ht.split('\n')
        if ls and ls[-1] == '':
            ls = ls[:-1]
        L.append(f'#{n} {p}: {len(ls)} lines (base {len(bt.splitlines())}); max width {max(len(x) for x in ls)}; '
                 f'> 100: {sum(len(x) > 100 for x in ls)}; micro sign {ht.count(chr(0xB5))}; tabs {ht.count(chr(9))}; '
                 f'trailing spaces {sum(x != x.rstrip() for x in ls)}; @[simp] {ht.count("@[simp")}; '
                 f'attribute commands base/head {len(re.findall(r"(?m)^attribute", bt))}/{len(re.findall(r"(?m)^attribute", ht))}')
        H = lean43.split_items(ht)
        B = {x['name']: x for x in lean43.split_items(bt) if x['kind'] == 'decl'}
        long_ = []
        for it in H:
            if it['kind'] != 'decl':
                continue
            nb = len([x for x in it['body'].split('\n') if x.strip()])
            if nb >= 15:
                long_.append((it['name'], nb, lean43.SKETCH in it['doc'],
                              len(re.findall(r'(?m)^\s+-- ', it['body']))))
        L.append(f'    proofs of >= 15 non-blank body lines: {len(long_)}; without a sketch: '
                 f'{[x[0] for x in long_ if not x[2]]}')
        for nm, nb, sk, cm in long_:
            L.append(f'      {nm}: {nb} lines, sketch {sk}, step comments {cm}')
        for t in d['targets'][p]:
            h = next(x for x in H if x['kind'] == 'decl' and x['name'] == t)
            same = lean43.doc_sketch(B[t]['doc']) == lean43.doc_sketch(h['doc'])
            L.append(f'    target {t}: sketch {"kept" if same else "rewritten"}')
        for it in H:
            if it['kind'] == 'decl' and it['name'] not in B:
                L.append(f'    new {"private " if it["private"] else ""}{it["keyword"]} {it["name"]}: docstring '
                         f'{"yes" if it["doc"] else "NO"}: {lean43.norm(it["doc"])[:160]!r}')
out('docs.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- sources.txt
L = []
reg = json.loads(R.show(TIP, 'blueprint/src/references/sources.json'))['tags']
allgroups = []
for n, d in sorted(PRS.items()):
    for p in d['files']:
        gb = collections.Counter(g for _, g in lean43.citations(R.show(d['base'], p)))
        gh = collections.Counter(g for _, g in lean43.citations(R.show(d['head'], p)))
        L.append(f'#{n} {p}: citation groups base {sum(gb.values())}, head {sum(gh.values())}; multiset equal {gb == gh}')
        for g in sorted((gh - gb)):
            L.append(f'    added at head: {g}')
        for g in sorted((gb - gh)):
            L.append(f'    removed at head: {g}')
        allgroups += [(p, ln, g) for ln, g in lean43.citations(R.show(d['head'], p))]
keys = collections.Counter(k for _, _, g in allgroups for k, _ in lean43.locators(g))
L.append('')
L.append('Keys cited at the heads (citation parts), with the registry (blueprint/src/references/sources.json at the tip):')
docs = {}
for k, c in sorted(keys.items()):
    e = reg.get(k)
    ds = e['documents'] if e else []
    present = [x for x in ds if R.blob(TIP, f'blueprint/src/references/{x}.md') is not None]
    L.append(f'  {k}: {c} parts; registered {bool(e)}; documents {ds}; .md present {present}')
    if present:
        docs[k] = '\n'.join(R.show(TIP, f'blueprint/src/references/{x}.md') + '\n' +
                            (R.show(TIP, f'blueprint/src/references/{x}.raw.md') or '') for x in present)
L.append('')
L.append('Locator lookup (aid only): for each distinct (key, kind, number) at the heads, whether the number occurs '
         'next to the kind word, or as a heading number, or as an equation tag, in the key\'s transcription '
         '(.md + .raw.md at the tip):')
seen = collections.OrderedDict()
for p, ln, g in allgroups:
    for k, locs in lean43.locators(g):
        for kind, num in locs:
            seen.setdefault((k, kind, num), []).append(f'{p.split("/")[-1]}:{ln}')
hit = miss = 0
for (k, kind, num), where in seen.items():
    t = docs.get(k)
    if t is None:
        res = 'no transcription'
    else:
        first = re.split(r'\s*[–-]\s*', num)[0]
        word = kind.rstrip('s').replace('ie', 'y') if kind not in ('Equation',) else ''
        pats = [rf'{re.escape(word[:6])}\w*\.?\s*{re.escape(first)}\b'] if word else []
        pats += [rf'(?m)^#+\s*(?:§\s*)?{re.escape(first)}\b', rf'§\s*{re.escape(first)}\b',
                 rf'\({re.escape(first)}\)']
        found = any(re.search(x, t, re.I) for x in pats)
        res = 'found' if found else 'NOT FOUND'
        hit += found; miss += not found
    L.append(f'  [{k}, {kind} {num}] {res}; cited at {", ".join(sorted(set(where))[:6])}')
L.append(f'  lookup: {hit} found, {miss} not found (a miss means the regex did not see it, not that the citation is wrong)')
out('sources.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- names.txt
L = []
alln = collections.defaultdict(list)
for p in R.git('ls-tree', '-r', '--name-only', TIP).stdout.split():
    if p.endswith('.lean') and p.startswith(('TCSlib/', 'audits/')):
        for i, l in enumerate(R.show(TIP, p).split('\n'), 1):
            m = lean43.DECL_RE.match(l)
            if m and m.group(3):
                alln[lean43.short(m.group(3))].append(f'{p}:{i}')
for n, d in sorted(PRS.items()):
    for p in d['files']:
        bn = {x['name'] for x in lean43.split_items(R.show(d['base'], p)) if x['kind'] == 'decl'}
        for it in lean43.split_items(R.show(d['head'], p)):
            if it['kind'] == 'decl' and it['name'] not in bn:
                hits = alln.get(lean43.short(it['name']), [])
                L.append(f'#{n} new {"private " if it["private"] else ""}{it["name"]} ({p.split("/")[-1]}:{it["line"]}): '
                         f'declarations with this last component in TCSlib/ and audits/ at the tip: {len(hits)} {hits[:5]}')
L.append(f'(new declarations in #338: {sum(1 for x in L if x.startswith("#338"))})')
out('names.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- mergetrees.txt and downstream.txt
L, D = [], []
H9, H8 = PRS[339]['head'], PRS[338]['head']
cmp = [('the tip', TIP)] + [(f'#{k} ({v})', R.rp('origin/' + v)) for k, v in OTHER_OPEN.items()]
for n, d in sorted(PRS.items()):
    for label, x in cmp + ([('#339', H9)] if n == 338 else []):
        tree, rc, outp = R.mergetree(d['head'], x)
        mb = R.git('merge-base', d['head'], x).stdout.strip()
        other = set(R.git('diff', '--name-only', mb, x).stdout.split())
        shared = sorted(set(d['files']) & other)
        L.append(f'#{n} {d["head"][:8]} with {label} {x[:8]}: merge-tree rc {rc}, tree {tree[:12]}; merge base {mb[:8]}; '
                 f'shared changed paths {shared}')
tree, rc, _ = R.mergetree(H9, H8)
L.append(f'combined #339 + #338 (git merge-tree {H9[:8]} {H8[:8]}): rc {rc}, tree {tree}')
tl = {l.split('\t')[1]: l.split()[2] for l in R.git('ls-tree', '-r', TIP, 'TCSlib', 'TCSlib.lean', 'audits', 'scripts',
                                                    'lakefile.lean', 'lake-manifest.json', 'lean-toolchain').stdout.splitlines()}
cl = {l.split('\t')[1]: l.split()[2] for l in R.git('ls-tree', '-r', tree, 'TCSlib', 'TCSlib.lean', 'audits', 'scripts',
                                                    'lakefile.lean', 'lake-manifest.json', 'lean-toolchain').stdout.splitlines()}
diffp = sorted(p for p in set(tl) | set(cl) if tl.get(p) != cl.get(p))
want = sorted(PRS[339]['files'] + PRS[338]['files'])
L.append(f'  its TCSlib/, audits/, scripts/ and lake files differ from the tip\'s in exactly the 7 owned paths: '
         f'{diffp == want}; each equal to its PR head blob: '
         f'{all(cl[p] == R.git("rev-parse", (H9 if p in PRS[339]["files"] else H8) + ":" + p).stdout.strip() for p in want)}')
BUILT = {339: ('76fae5c89bce2097cf32b536edfdec6544a49bcb', 'gsw-core review Phase 2 build source (tip 4941b511 + d4ebb0be)'),
         338: ('ac512a9b66b6ff0633f523144eb41390f637c67e', 'gsw-security review Phase 2 build source (scratch merge a51294c5 '
                                                           '= tip e2f5850f + a9f97edd)')}
LEANP = ('TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean', 'lake-manifest.json', 'lean-toolchain')


def leanpart(t):
    return {l.split('\t')[1]: l.split()[2] for l in R.git('ls-tree', '-r', t, *LEANP).stdout.splitlines()}


for n, (bt, label) in sorted(BUILT.items()):
    mt = R.mergetree(TIP, PRS[n]['head'])[0]
    a, b = leanpart(bt), leanpart(mt)
    dd = sorted(p for p in set(a) | set(b) if a.get(p) != b.get(p))
    L.append(f'#{n}: the {label}, tree {bt[:12]}: its TCSlib/, TCSlib.lean, audits/, scripts/ and lake files equal those of '
             f'git merge-tree tip #{n} ({mt[:12]}): {not dd} ({len(a)} paths; differing {dd[:5]})')
tree2, rc2, _ = R.mergetree(TIP, H9)
L.append(f'  merge order check: tip+#339 tree {tree2[:12]} (rc {rc2}); tip+#338 tree {R.mergetree(TIP, H8)[0][:12]}; '
         f'paths disjoint, so either order gives the same combined Lean tree')
out('mergetrees.txt', '\n'.join(L) + '\n')
g = R.graph(tree)
f9 = set(PRS[339]['files']); f8 = set(PRS[338]['files'])
d9, d8 = downstream(g, f9), downstream(g, f8)
both = sorted(d9 & d8)
D.append(f'import graph of the combined tree {tree[:12]}: {len(g)} modules (TCSlib/ and audits/)')
D.append(f'downstream of #339 (incl. its files): {len(d9)}; of #338: {len(d8)}; of both: {len(both)}')
D.extend('  ' + x for x in both)
D.append('with the other open PRs on the base (each PR\'s own Lean changes from its merge base with the tip; graph of '
         'the merge-tree of the two heads):')
for k, v in OTHER_OPEN.items():
    x = R.rp('origin/' + v)
    xs = set(p for p in R.git('diff', '--name-only', R.git('merge-base', TIP, x).stdout.strip(), x).stdout.split()
             if p.endswith('.lean'))
    for n, d in sorted(PRS.items()):
        t = R.mergetree(d['head'], x)[0]
        gg = R.graph(t)
        jb = sorted(downstream(gg, set(d['files'])) & downstream(gg, xs))
        D.append(f'  #{n} x #{k}: {len(xs)} Lean files changed by #{k}; downstream of both: {len(jb)} {jb[:8]}')
D.append('direct imports of #338\'s files at its head:')
for p in sorted(f8):
    imps = re.findall(r'(?m)^import\s+(\S+)', R.show(H8, p))
    D.append(f'  {p}: {imps}')
D.append('#339 files imported by #338 files (transitively, at the combined tree): '
         f'{sorted(f9 & closure(g, list(f8)))}')
D.append('#338 files imported by #339 files (transitively): ' + f'{sorted(f8 & closure(g, list(f9)))}')
out('downstream.txt', '\n'.join(D) + '\n')

# ---------------------------------------------------------------- dupscan.txt
L = []
pat = collections.OrderedDict([
    ('getD/getElem of List.ofFn (DL-47 class)', r'getD_eq_getElem|getElem_ofFn|getElem\?_ofFn|getD_ofFn'),
    ('case splits closed by rfl/decide/simp (GC-02 Bool toNat identities)', r'cases\b.*<;>\s*(rfl|decide|simp)'),
    ('triangle steps abs_sub_le (GS-01 F6)', r'abs_sub_le\b|abs_sub_comm|abs_sub_le_sum_hybrids'),
    ('augmentation key equivalence (GS-06)', r'augmented_bijective|Equiv\.ofBijective'),
    ('translation by the gadget/codepoint (GS-06)', r'Equiv\.addRight'),
    ('acceptProb planting identities (GS-01 F5)', r'acceptProb_bind|acceptProb_comp_equiv|acceptProb_update|uprob_comp_equiv'),
    ('hybrid helpers named by GS-02', r'pairHybrid|pairRed|distAdv_multi_le_sum|distAdv_comp|multicopy'),
    ('binary subset sums', r'binaryErrorSum_bound|subsetError_bound|error_sum_bound'),
    ('runWith_rel / runWith_sim', r'runWith_rel|runWith_sim|runWith_remap_rel'),
])
for n, d in sorted(PRS.items()):
    L.append(f'=== #{n}: added lines of pr-{n}.diff.txt matching each pattern ===')
    cur, ln, adds = None, 0, []
    for l in d['diff'].decode().split('\n'):
        if l.startswith('+++ b/'):
            cur = l[6:]
        elif l.startswith('@@'):
            ln = int(re.search(r'\+(\d+)', l).group(1))
        elif l.startswith('+') and not l.startswith('+++'):
            adds.append((cur, ln, l[1:])); ln += 1
        elif not l.startswith('-'):
            ln += 1
    for label, rx in pat.items():
        hits = [f'{c.split("/")[-1]}:{i}' for c, i, t in adds if re.search(rx, t)]
        L.append(f'  {label}: {len(hits)} {hits[:24]}')
L.append('')
L.append('=== named relatives at the tip (declaration lines) ===')
rel = ['pairTuple', 'pairHybrid', 'pairRed', 'acceptProb_pairHybrid_zero', 'acceptProb_pairHybrid_self',
       'acceptProb_pairRed_left', 'acceptProb_pairRed_right', 'exists_pairRed_ge', 'distAdv_multi_le_sum',
       'distAdv_tuple_le_sum', 'distAdv_comp', 'multicopyHybrid', 'multicopyRed', 'abs_sub_le_sum_hybrids',
       'exists_hybrid_gap', 'distAdv_hash_uniform_le', 'columnHybrid', 'column_gap', 'getD_ofFn_lt\'',
       'getD_ofFn_lt', 'headD_drop_ofFn', 'blocksEquiv', 'augmented_bijective', 'real_uniformKey_advantage',
       'uniformKey_uniform_advantage_le', 'distAdv_encrypt_le', 'runWith_rel', 'runWith_sim', 'binaryErrorSum_bound',
       'decode_codepoint_add', 'hashParameters']
for r_ in rel:
    L.append(f'  {r_}: {alln.get(r_, [])[:6]}')
L.append('')
L.append('=== inline key-equivalence / translation sites at the PR heads and the tip (GS-06) ===')
for label, rev, p in ([('tip', TIP, 'TCSlib/Cryptography/Encryption/PublicKey/Regev/Experiments.lean')] +
                      [(f'#{n}', d['head'], p) for n, d in sorted(PRS.items()) for p in d['files']]):
    for i, l in enumerate(R.show(rev, p).split('\n'), 1):
        if re.search(r'augmented_bijective|Equiv\.addRight|keyEquiv', l):
            L.append(f'  {label} {p.split("TCSlib/Cryptography/")[-1]}:{i}: {l.strip()[:110]}')
out('dupscan.txt', '\n'.join(L) + '\n')

# ---------------------------------------------------------------- ledger.txt (working tree vs the records tip)
LP = 'briefs/pass-shelat-ch5-8/duplication-ledger.md'
a = R.show(TIP, LP).split('\n')
b = open(os.path.join(repo, LP), encoding='utf-8').read().split('\n')
L = [f'{LP}: records tip {TIP[:8]} {len(a)} lines, working tree (the pin commit\'s version) {len(b)} lines']
dl = [i for i in range(max(len(a), len(b))) if (a[i] if i < len(a) else None) != (b[i] if i < len(b) else None)]
L.append(f'differing lines: {[i + 1 for i in dl]}')
for i in dl:
    old_, new_ = a[i], b[i]
    k = 0
    while k < min(len(old_), len(new_)) and old_[k] == new_[k]:
        k += 1
    ins = new_[k:len(new_) - (len(old_) - k)]
    L.append(f'line {i + 1}: row {old_.split("|")[1].strip()!r}; pure insertion: '
             f'{new_[:k] + new_[k + len(ins):] == old_}; inserted {len(ins)} characters after '
             f'{old_[max(0, k - 60):k]!r}:')
    L.append('  ' + ins)
out('ledger.txt', '\n'.join(L) + '\n')
print('wrote', ', '.join(sorted(files)))
