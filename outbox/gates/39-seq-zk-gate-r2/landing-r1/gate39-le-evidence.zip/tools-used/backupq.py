"""backupq.py <tree> <backup-dir> <snapshot-pre> <queue> <backed-up.txt> <new-oleans.txt>: (LE-gate39, new) before a build,
copy aside every <tree> olean of a <queue> module that is in the pre-build snapshot (hash checked against it, appended to
<backed-up.txt> in the snapshot's `<sha256>  <relpath>` form unless already listed) and append the queue modules with no
snapshot olean to <new-oleans.txt> (unless listed). Copies are verified."""
import sys, os, hashlib, shutil
tree, bk, snap, queue, bul, newl = sys.argv[1:7]
S = {}
for l in open(snap):
    h, p = l.rstrip('\n').split('  ', 1); S[p] = h
have = {l.split('  ', 1)[1].rstrip('\n') for l in open(bul)} if os.path.exists(bul) else set()
havenew = {l.strip() for l in open(newl)} if os.path.exists(newl) else set()
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
nb = nn = 0
with open(bul, 'a') as b, open(newl, 'a') as n:
    for m in (l.strip() for l in open(queue) if l.strip()):
        p = m + '.olean'
        if p in S:
            if p in have: continue
            assert sha(os.path.join(tree, p)) == S[p], p
            os.makedirs(os.path.dirname(os.path.join(bk, p)) or bk, exist_ok=True)
            shutil.copy2(os.path.join(tree, p), os.path.join(bk, p))
            assert sha(os.path.join(bk, p)) == S[p], p
            b.write(f'{S[p]}  {p}\n'); have.add(p); nb += 1
        elif m not in havenew:
            assert not os.path.exists(os.path.join(tree, p)), p
            n.write(m + '\n'); havenew.add(m); nn += 1
print(f'backed up {nb} (verified), new {nn}; totals backed-up {len(have)} new {len(havenew)}')
