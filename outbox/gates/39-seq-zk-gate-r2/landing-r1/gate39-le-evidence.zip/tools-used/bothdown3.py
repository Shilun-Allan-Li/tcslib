r"""bothdown3.py <repo> <rev> <outdir> <tag> <seedA.txt> <seedB.txt> <seedC.txt>: bothdown.py / bothdown317.py (int-317 tools-used,
same import parsing as downorder.py) generalised to three seed sets read from files (here #313 learning, #323 sc-garble,
#324 sc-compose; each the PR's changed Lean modules): TCSlib/audits modules at <rev> downstream of (transitively import, or are)
a module of each set, and, for each pair, the union and the modules downstream of BOTH. Seeds missing at <rev> are skipped
(counted). Writes <tag>-downA/-downB/-downC.txt (named by the seed-file stems), <tag>-union.txt, <tag>-<X>-<Y>-both.txt."""
import sys, re, subprocess, os
repo, rev, outd, tag = sys.argv[1:5]; sf = sys.argv[5:8]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
rdep = {}
for m in files:
    for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M):
        if local(i): rdep.setdefault(i.replace('.', '/'), set()).add(m)
fs = set(files)
def down(seeds):
    seen, todo = set(), [s for s in seeds if s in fs]
    while todo:
        m = todo.pop()
        if m in seen: continue
        seen.add(m); todo.extend(rdep.get(m, ()))
    return seen
names, sets, present = [], [], []
for f in sf:
    seeds = [l.strip() for l in open(f) if l.strip()]
    names.append(os.path.basename(f).rsplit('.', 1)[0]); sets.append(down(seeds)); present.append(f'{sum(s in fs for s in seeds)}/{len(seeds)}')
w = lambda n, xs: open(os.path.join(outd, f'{tag}-{n}.txt'), 'w').write(''.join(x + '\n' for x in sorted(xs)))
for n, s in zip(names, sets): w('down' + n, s)
u = set().union(*sets); w('union', u)
msg = [f'{tag} {rev}: files {len(files)}; seeds present ' + ', '.join(f'{n} {p}' for n, p in zip(names, present)),
       '  ' + '; '.join(f'down{n} {len(s)}' for n, s in zip(names, sets)) + f'; union {len(u)}']
for i in range(3):
    for j in range(i + 1, 3):
        b = sets[i] & sets[j]; w(f'{names[i]}-{names[j]}-both', b)
        msg.append(f'  both {names[i]} & {names[j]}: {len(b)} (union {len(sets[i] | sets[j])})')
a3 = sets[0] & sets[1] & sets[2]; w('all3', a3); msg.append(f'  downstream of all three: {len(a3)}')
print('\n'.join(msg))
