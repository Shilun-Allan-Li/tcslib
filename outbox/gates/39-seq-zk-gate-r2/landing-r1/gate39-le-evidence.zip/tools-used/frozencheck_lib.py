"""frozencheck_lib.py: the scanner of frozencheck.py (everything above main), imported by draftcmp.py."""
import sys, re, subprocess

TOP = ('theorem', 'lemma', 'def', 'abbrev', 'structure', 'inductive', 'class', 'instance', 'opaque',
       'axiom', 'private', 'protected', 'noncomputable', 'nonrec', 'partial', 'unsafe', 'omit', 'namespace',
       'end', 'section', 'open', 'variable', 'universe', 'set_option', 'attribute', 'example', 'import',
       'mutual', 'deriving', 'macro', 'syntax', 'notation', 'infix', 'infixl', 'infixr', 'prefix', 'postfix',
       'local', 'scoped', '#', '@[', '/--', '/-!', 'initialize', 'elab', 'termination_by', 'decreasing_by')
KW = ('theorem', 'lemma', 'def', 'abbrev', 'structure', 'inductive', 'class', 'instance', 'opaque', 'axiom')
DEFKINDS = ('def', 'abbrev', 'structure', 'inductive', 'class', 'instance', 'opaque')
MODS = ('private', 'protected', 'noncomputable', 'nonrec', 'partial', 'unsafe')


def show(repo, rev, f):
    if rev.startswith('WT:'):
        return open(rev[3:] + '/' + f, encoding='utf-8').read()
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True)
    if r.returncode:
        return None
    return r.stdout.decode('utf-8')


def code_mask(s):
    """Per character: True if outside comments and literals."""
    n = len(s); m = [True] * n; i = 0; depth = 0
    while i < n:
        if depth == 0 and s.startswith('--', i):
            j = s.find('\n', i); j = n if j < 0 else j
            for k in range(i, j): m[k] = False
            i = j; continue
        if s.startswith('/-', i):
            depth += 1; m[i] = m[i + 1] = False; i += 2; continue
        if depth > 0:
            if s.startswith('-/', i):
                depth -= 1; m[i] = m[i + 1] = False; i += 2; continue
            m[i] = False; i += 1; continue
        if s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            for k in range(i, min(j + 1, n)): m[k] = False
            i = j + 1; continue
        i += 1
    return m


def chunks(s):
    """Split into top-level chunks: (start, end) offsets, cut at column-0 tokens outside comments.
    A doc comment `/--` at column 0 starts a chunk (its start is outside code: it is the comment opener)."""
    m = code_mask(s); starts = [0]; pos = 0
    for line in s.split('\n')[:-1] + [s.split('\n')[-1]]:
        if pos > 0 and line and not line[0].isspace():
            if line.startswith('/--') or line.startswith('/-!'):
                # a comment opener at column 0 is top-level iff the newline before it is outside comments
                if m[pos - 1]:
                    starts.append(pos)
            elif m[pos] and any(line.startswith(t) and (len(line) == len(t) or not (line[len(t)].isalnum() or line[len(t)] in '_.\'')
                                                     or t in ('#', '@[', '/--', '/-!')) for t in TOP):
                starts.append(pos)
        pos += len(line) + 1
    starts.append(len(s))
    return [(starts[i], starts[i + 1]) for i in range(len(starts) - 1)], m


def first_word(t):
    t = t.lstrip()
    mm = re.match(r"[^\s(\[{:]+", t)
    return mm.group(0) if mm else ''


def header_end(s, m, a, b):
    """First depth-0 `:=`, `where` token, or line-leading `|`, scanning code chars in [a, b)."""
    d = 0; i = a; linestart = False
    while i < b:
        c = s[i]
        if not m[i]:
            i += 1; continue
        if c == '\n':
            linestart = True; i += 1; continue
        if linestart and c in ' \t':
            i += 1; continue
        if linestart and c == '|' and d == 0:
            return i
        linestart = False
        if c in '([{⟨⦃': d += 1
        elif c in ')]}⟩⦄': d -= 1
        elif d == 0 and s.startswith(':=', i):
            return i
        elif d == 0 and s.startswith('where', i) and (i == 0 or not (s[i - 1].isalnum() or s[i - 1] == '_')) \
                and (i + 5 >= len(s) or not (s[i + 5].isalnum() or s[i + 5] == '_')):
            return i
        i += 1
    return b


def decls(s):
    cs, m = chunks(s)
    ns = []; out = []; pend_doc = None; pend_omit = []; pend_attr = []
    for a, b in cs:
        t = s[a:b]; w = first_word(t)
        if t.startswith('/--'):
            pend_doc = (a, b); continue
        if w == 'omit':
            pend_omit.append((a, b)); continue
        if t.startswith('@[') and not re.match(r'@\[[^\]]*\]\s*(' + '|'.join(MODS + KW) + r')\b', t, re.S):
            pend_attr.append((a, b)); continue
        if w == 'namespace':
            ns.append(t.split()[1]); pend_doc = None; pend_omit = []; continue
        if w == 'section':
            parts = t.split(); ns.append(('§', parts[1] if len(parts) > 1 and not parts[1].startswith('--') else ''))
            pend_doc = None; continue
        if w == 'end':
            if ns: ns.pop()
            pend_doc = None; continue
        mm = re.match(r'((?:@\[[^\]]*\]\s*)*)((?:(?:' + '|'.join(MODS) + r')\s+)*)(' + '|'.join(KW) + r')\b\s*([^\s(:{\[⦃]*)', t, re.S)
        if mm:
            kind = mm.group(3); name = mm.group(4)
            full = '.'.join([x for x in ns if isinstance(x, str)] + ([name] if name else []))
            if name.startswith('_root_.'): full = name[7:]
            hs = pend_omit[0][0] if pend_omit else (pend_attr[0][0] if pend_attr else a)
            he = header_end(s, m, a, b)
            header = s[hs:a] if pend_omit or pend_attr else ''
            # pending omit/attr text between them and the keyword, minus the doc comment (kept separately)
            if pend_doc and pend_omit and pend_doc[0] > pend_omit[0][0]:
                header = s[pend_omit[0][0]:pend_doc[0]] + s[pend_doc[1]:a]
            header += s[a:he]
            doc = s[pend_doc[0]:pend_doc[1]] if pend_doc else ''
            k = doc.find('**Proof sketch')
            prose = doc[:k] if k >= 0 else doc
            whole = (s[min([x for x in [hs, pend_doc[0] if pend_doc else a] ]):b]).rstrip()
            out.append(dict(kind=kind, name=full, header=header, prose=prose.rstrip(), whole=whole, line=s.count('\n', 0, a) + 1,
                            hdr_span=(a, he)))
        pend_doc = None; pend_omit = []; pend_attr = []
    return out


def compare(base_txt, head_txt):
    B, H = decls(base_txt), decls(head_txt)
    hk = {}
    for i, d in enumerate(H): hk.setdefault((d['kind'], d['name']), []).append(i)
    diffs = []; idx = []
    for d in B:
        key = (d['kind'], d['name'])
        if key not in hk:
            diffs.append(('MISSING', d['name'], d['kind'], d['line'])); continue
        j = hk[key][0]; h = H[j]; idx.append(j)
        if d['header'] != h['header']: diffs.append(('HEADER', d['name'], d['kind'], h['line']))
        if d['prose'] != h['prose']: diffs.append(('PROSE', d['name'], d['kind'], h['line']))
        if d['kind'] in DEFKINDS and d['whole'] != h['whole']: diffs.append(('BODY', d['name'], d['kind'], h['line']))
    order_ok = idx == sorted(idx)
    if not order_ok: diffs.append(('ORDER', '-', '-', 0))
    return B, H, diffs


