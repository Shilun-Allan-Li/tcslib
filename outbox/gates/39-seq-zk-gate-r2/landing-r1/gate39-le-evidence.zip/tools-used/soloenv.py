r"""soloenv.py <repo> <solo-rev> <own-records.jsonl> <rebuild.txt> <tree> <backup-dir> <outdir> [--apply]
Prepares, inside the one olean tree <tree>, the environment of a separate tip+PR check of <rebuild.txt> (solocheck.py's set).
Every module of the local import closure (at <solo-rev>) of the rebuild set, outside the set, has the same source and import
closure as in the PR's own integration build (solocheck.py), so its olean there is the expected one: the object SHA-256 of
its last rc-0 record in <own-records.jsonl>. For each such module: OK (the tree's olean has that hash), RESTORE (the
backup of the base snapshot has it; with --apply it is copied into the tree, hash re-checked), or MISSING (no copy on disk:
it must be rebuilt at <solo-rev> before the set, and must reproduce the expected hash). Writes status.tsv, missing.txt,
queue.txt (missing + rebuild set, imports-first) and expected.tsv (module -> expected hash, for every closure module)."""
import sys, os, re, json, hashlib, subprocess, shutil
repo, rev, recf, rbf, tree, bk, outd = sys.argv[1:8]; apply = '--apply' in sys.argv
os.makedirs(outd, exist_ok=True)
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
rec = {}
for l in open(recf):
    r = json.loads(l)
    if 'module' in r and r['rc'] == 0: rec[r['module']] = r
rb = [l.strip() for l in open(rbf) if l.strip()]; rbs = set(rb)
imp = {}
def imps(m):
    if m not in imp:
        imp[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean').decode(), re.M) if local(i)]
    return imp[m]
order, vis = [], set()
sys.setrecursionlimit(100000)
def visit(m):
    if m in vis: return
    vis.add(m)
    for i in imps(m): visit(i)
    order.append(m)
for m in rb: visit(m)
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
st = []; missing = []
for m in order:
    if m in rbs: continue
    r = rec[m]; exp = r['object_sha256']
    assert r['source_sha256'] == hashlib.sha256(git('show', f'{rev}:{m}.lean')).hexdigest(), m
    cur = sha(os.path.join(tree, m + '.olean'))
    if cur == exp: st.append((m, 'OK', exp)); continue
    b = os.path.join(bk, m + '.olean')
    if sha(b) == exp:
        if apply:
            shutil.copy2(b, os.path.join(tree, m + '.olean'))
            assert sha(os.path.join(tree, m + '.olean')) == exp
        st.append((m, 'RESTORE', exp)); continue
    st.append((m, 'MISSING', exp)); missing.append(m)
ms = set(missing)
q = [m for m in order if m in ms or m in rbs]
w = lambda n, xs: open(os.path.join(outd, n), 'w').write(''.join(x + '\n' for x in xs))
w('status.tsv', ['\t'.join(x) for x in st]); w('missing.txt', missing); w('queue.txt', q)
w('expected.tsv', [f'{m}\t{rec[m]["object_sha256"]}' for m in order if m not in rbs])
from collections import Counter
c = Counter(x[1] for x in st)
print(f'{rev[:8]}: rebuild set {len(rb)}; import closure outside it {len(st)}: ' + ', '.join(f'{k} {v}' for k, v in sorted(c.items()))
      + f'; queue {len(q)}' + (' (applied)' if apply else ' (dry run)'))
