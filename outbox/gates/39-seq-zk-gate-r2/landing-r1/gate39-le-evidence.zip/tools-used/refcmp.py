"""refcmp.py <results.jsonl> <ref-results.jsonl>...: for each module of the run, compare its source and object SHA-256
with the last record of the same module in the reference runs; prints SAME/DIFF per category and a summary."""
import sys, json
rs = [json.loads(l) for l in open(sys.argv[1])]; ms = [r for r in rs if 'module' in r]
ref = {}
for f in sys.argv[2:]:
    for l in open(f):
        r = json.loads(l)
        if 'module' in r: ref[r['module']] = r
cnt = {}
for r in ms:
    x = ref.get(r['module'])
    k = 'NOREF' if x is None else ('src-' + ('same' if x['source_sha256'] == r['source_sha256'] else 'DIFF') + ' obj-' +
                                    ('same' if x['object_sha256'] == r['object_sha256'] else 'DIFF'))
    cnt[k] = cnt.get(k, 0) + 1
    if k != 'src-same obj-same': print(k, r['module'])
print('summary', cnt)
