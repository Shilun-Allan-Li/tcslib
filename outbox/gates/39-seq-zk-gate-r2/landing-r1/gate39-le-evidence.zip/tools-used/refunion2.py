"""refunion2.py <results.jsonl> <out-prefix> <name=ref-results.jsonl>...: refunion.py (int-313-323-324) with every reference
build run kept as its own reference and only rc-0 records used (a failed record has no valid object). For each module of the
run (last record), per reference (last rc-0 record of that module in it): SAME (source and olean SHA-256 equal), SRCSAME-OBJDIFF,
SRCDIFF, or NOREF. Writes <out-prefix>-matrix.tsv (module x reference) and prints:
  SRC-SAME-OBJ-DIFF <module> <refs>  -- a reference with the same source but a different olean;
  NO-SAME-REF <module> ...           -- no reference has the same source and olean;
and a summary."""
import sys, json
res, outp = sys.argv[1:3]
ms = {}
for l in open(res):
    r = json.loads(l)
    if 'module' in r: ms[r['module']] = r
refs = []
for a in sys.argv[3:]:
    n, f = a.split('=', 1); d = {}
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: d[r['module']] = r
    refs.append((n, d))
def cls(r, d):
    x = d.get(r['module'])
    if x is None: return 'NOREF'
    if x['source_sha256'] != r['source_sha256']: return 'SRCDIFF'
    return 'SAME' if x['object_sha256'] == r['object_sha256'] else 'SRCSAME-OBJDIFF'
cov = 0; ssod = []; none = []
with open(outp + '-matrix.tsv', 'w') as o:
    o.write('module\t' + '\t'.join(n for n, _ in refs) + '\n')
    for m, r in ms.items():
        c = [cls(r, d) for _, d in refs]
        o.write(m + '\t' + '\t'.join(c) + '\n')
        if 'SAME' in c: cov += 1
        else: none.append(m); print('NO-SAME-REF', m, [f'{n}:{x}' for (n, _), x in zip(refs, c) if x != 'NOREF'] or ['all NOREF'])
        so = [n for (n, _), x in zip(refs, c) if x == 'SRCSAME-OBJDIFF']
        if so: ssod.append(m); print('SRC-SAME-OBJ-DIFF', m, so, 'also SAME in:', [n for (n, _), x in zip(refs, c) if x == 'SAME'])
print(f'summary modules {len(ms)}; byte-identical (source and olean) to at least one reference {cov}; none {len(none)}; '
      f'modules with a same-source different-olean reference {len(ssod)}')
