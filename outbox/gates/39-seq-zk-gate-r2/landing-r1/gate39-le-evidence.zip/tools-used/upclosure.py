r"""upclosure.py <repo> <rev> <module>: the local (TCSlib/audits) upstream import closure of <module> at <rev> (same import
parsing as downorder.py), one module per line, sorted; also asserts <module> is not in its own closure (acyclic)."""
import sys, re, subprocess
repo, rev, m0 = sys.argv[1:4]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
imps = lambda m: [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M) if i.split('.')[0] in ('TCSlib', 'audits')]
seen, todo = set(), list(imps(m0))
while todo:
    m = todo.pop()
    if m in seen: continue
    seen.add(m); todo.extend(imps(m))
assert m0 not in seen
print('\n'.join(sorted(seen)))
