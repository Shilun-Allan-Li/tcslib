r"""buildset.py <repo> <rev> <orderdir> <outdir> <seed-module>...: the integration build set.
Imports are parsed at <rev> exactly as downorder.py does (`^import\s+(\S+)`, local = TCSlib.* / audits.*).
seed.txt      = the seed modules (here #314's 2 and #315's 6);
down-seed.txt = every module (TCSlib/**, root TCSlib, audits/**) that transitively imports a seed (seeds included);
up-seed.txt   = the local upstream closure of down-seed.txt (down-seed included);
build-set.txt = up-seed  intersected with  <orderdir>/down.txt (downorder's downstream closure of the base delta
                since the olean snapshot), i.e. down-seed plus every base-delta-affected module it needs;
build-queue.txt = <orderdir>/order.txt (imports-first) restricted to build-set.txt;
excluded.txt  = <orderdir>/down.txt minus build-set.txt (base-delta-affected, not needed by the seeds' closure)."""
import sys, re, subprocess, os
repo, rev, orderd, outd = sys.argv[1:5]; seeds = sys.argv[5:]
os.makedirs(outd, exist_ok=True)
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
fs = set(files)
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
imp = {}
for m in files:
    imp[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M) if local(i)]
for s in seeds: assert s in fs, s
rdep = {}
for m, xs in imp.items():
    for i in xs: rdep.setdefault(i, set()).add(m)
def walk(start, nxt):
    seen, todo = set(), list(start)
    while todo:
        m = todo.pop()
        if m in seen: continue
        seen.add(m); todo.extend(nxt(m))
    return seen
dseed = walk(seeds, lambda m: rdep.get(m, ()))
useed = walk(dseed, lambda m: imp.get(m, ()))
rd = lambda n: [l.strip() for l in open(os.path.join(orderd, n)) if l.strip()]
down, order = set(rd('down.txt')), rd('order.txt')
bs = useed & down
assert dseed <= down
q = [m for m in order if m in bs]
assert set(q) == bs and len(q) == len(bs)
pos = {m: k for k, m in enumerate(q)}
for m in q:
    for i in imp[m]:
        if i in pos: assert pos[i] < pos[m], (i, m)
w = lambda n, xs: open(os.path.join(outd, n), 'w').write(''.join(x + '\n' for x in xs))
w('seed.txt', seeds); w('down-seed.txt', sorted(dseed)); w('up-seed.txt', sorted(useed)); w('build-set.txt', sorted(bs))
w('build-queue.txt', q); w('excluded.txt', sorted(down - bs))
aud = sorted(m for m in dseed if m == 'TCSlib' or m.startswith('audits/'))
print(f'seeds {len(seeds)} down-seed {len(dseed)} up-seed {len(useed)} build-set {len(bs)} '
      f'(base-delta extra {len(bs - dseed)}) excluded {len(down - bs)}; roots/audits in down-seed {aud}')
