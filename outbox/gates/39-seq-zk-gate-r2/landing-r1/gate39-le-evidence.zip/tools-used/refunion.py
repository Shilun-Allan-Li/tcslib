"""refunion.py <results.jsonl> <name=ref-results.jsonl>...: per module of the run, which references (last record of the module in
each) have the same source and object SHA-256; lists modules matched by none, with the reason per reference, and a summary."""
import sys, json
ms = [json.loads(l) for l in open(sys.argv[1])]; ms = [r for r in ms if 'module' in r]
refs = []
for a in sys.argv[2:]:
    n, f = a.split('=', 1); d = {}
    for l in open(f):
        r = json.loads(l)
        if 'module' in r: d[r['module']] = r
    refs.append((n, d))
cov = 0
for r in ms:
    hit = [n for n, d in refs if r['module'] in d and d[r['module']]['source_sha256'] == r['source_sha256'] and d[r['module']]['object_sha256'] == r['object_sha256']]
    srcsame_objdiff = [n for n, d in refs if r['module'] in d and d[r['module']]['source_sha256'] == r['source_sha256'] and d[r['module']]['object_sha256'] != r['object_sha256']]
    if srcsame_objdiff: print('SRC-SAME-OBJ-DIFF', r['module'], srcsame_objdiff)
    if hit: cov += 1
    else: print('NO-SAME-REF', r['module'], ['%s:%s' % (n, 'noref' if r['module'] not in d else 'src-diff') for n, d in refs])
print(f'summary modules {len(ms)}; byte-identical (source and olean) to at least one reference {cov}; none {len(ms) - cov}')
