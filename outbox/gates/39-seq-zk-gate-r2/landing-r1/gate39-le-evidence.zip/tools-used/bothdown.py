r"""bothdown.py <repo> <rev> <outdir> <tag>: TCSlib/audits modules at <rev> (same import parsing as downorder.py) that are
downstream of (transitively import, or are) a #314 module, a #315 module, either, and both. #315's modules missing at <rev>
are skipped. Writes <tag>-down314.txt, <tag>-down315.txt, <tag>-union.txt, <tag>-both.txt."""
import sys, re, subprocess, os
repo, rev, outd, tag = sys.argv[1:5]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
rdep = {}
for m in files:
    for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M):
        if local(i): rdep.setdefault(i.replace('.', '/'), set()).add(m)
P = 'TCSlib/Cryptography/'
s314 = [P + 'Pseudorandom/Functions/Defs', P + 'Encryption/PrivateKey/EncryptThenTag/Reduction']
s315 = [P + x for x in ('Encryption/PrivateKey', 'Encryption/PrivateKey/FromPRF', 'Encryption/PrivateKey/FromPRF/Hybrid',
        'Encryption/PrivateKey/FromPRF/MultiMsgOut', 'Encryption/PrivateKey/FromPRF/ReductionMachine', 'Pseudorandom/Functions/Asymptotic/Defs')]
fs = set(files)
def down(seeds):
    seen, todo = set(), [s for s in seeds if s in fs]
    while todo:
        m = todo.pop()
        if m in seen: continue
        seen.add(m); todo.extend(rdep.get(m, ()))
    return seen
a, b = down(s314), down(s315)
w = lambda n, xs: open(os.path.join(outd, f'{tag}-{n}.txt'), 'w').write(''.join(x + '\n' for x in sorted(xs)))
w('down314', a); w('down315', b); w('union', a | b); w('both', a & b)
print(f'{tag} {rev}: files {len(files)}; #315 seeds present {sum(s in fs for s in s315)}/6; down314 {len(a)} down315 {len(b)} union {len(a | b)} both {len(a & b)}')
