r"""solocheck.py <repo> <solo-rev> <own-records.jsonl> <outdir> [order.txt]: does a PR's own integration build cover its merge onto the
current tip?  <solo-rev> = scratch merge tip + PR; <own-records.jsonl> = the full record set of the tree the PR's own integration
build left (base records + that build; last rc-0 record per module). For every TCSlib/audits module at <solo-rev>, its source
SHA-256 is compared with that record. differ.txt = modules whose source differs or that have no record (reason given);
rebuild.txt = their downstream closure at <solo-rev> (same import parsing as downorder.py), imports-first (DFS order of the
local import graph), i.e. exactly the modules whose source or import closure differs from the PR's own build. With order.txt
(downorder.py's order at <solo-rev>: the upstream closure of the downstream set, which contains root TCSlib and both audits
Checks), modules outside it (never built by any integration build, e.g. files not imported by root TCSlib) are not compared."""
import sys, re, json, hashlib, subprocess, os
repo, rev, recf, outd = sys.argv[1:5]
scope = set(l.strip() for l in open(sys.argv[5]) if l.strip()) if len(sys.argv) > 5 else None
os.makedirs(outd, exist_ok=True)
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').decode().split() if f.endswith('.lean')]
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
rec = {}
for l in open(recf):
    r = json.loads(l)
    if 'module' in r and r['rc'] == 0: rec[r['module']] = r
imp, src = {}, {}
for m in files:
    b = git('show', f'{rev}:{m}.lean'); src[m] = hashlib.sha256(b).hexdigest()
    imp[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', b.decode(), re.M) if local(i)]
rdep = {}
for m, xs in imp.items():
    for i in xs: rdep.setdefault(i, set()).add(m)
differ = []
for m in files:
    if scope is not None and m not in scope: continue
    r = rec.get(m)
    if r is None: differ.append((m, 'no-record'))
    elif r['source_sha256'] != src[m]: differ.append((m, 'source-differs'))
seen, todo = set(), [m for m, _ in differ]
while todo:
    m = todo.pop()
    if m in seen: continue
    seen.add(m); todo.extend(rdep.get(m, ()))
order, vis = [], set()
sys.setrecursionlimit(100000)
def visit(m):
    if m in vis: return
    vis.add(m)
    for i in imp.get(m, ()): visit(i)
    order.append(m)
for m in sorted(files): visit(m)
rb = [m for m in order if m in seen]
open(os.path.join(outd, 'differ.txt'), 'w').write(''.join(f'{m}\t{why}\n' for m, why in differ))
open(os.path.join(outd, 'rebuild.txt'), 'w').write(''.join(m + '\n' for m in rb))
print(f'{rev}: modules {len(files)}, compared {len(files) if scope is None else len(scope & set(files))}; source differs or no record {len(differ)}; rebuild (their downstream closure) {len(rb)}')
