"""soloverify.py <solo-dir> <name=ref.jsonl>...: after solorun.sh. (1) every module soloenv.py marked MISSING was rebuilt at the
solo source and reproduced the expected olean SHA-256 (its own-build record), so the environment equals the PR's own build
outside the rebuild set; (2) per rebuild-set module: rc, errors, sorry, warnings, and the references holding the same source
and olean (rc-0 records)."""
import sys, json, os
d = sys.argv[1]
exp = dict(l.split('\t') for l in open(os.path.join(d, 'env/expected.tsv')).read().splitlines())
miss = [l for l in open(os.path.join(d, 'env/missing.txt')).read().splitlines() if l]
rb = [l for l in open(os.path.join(d, 'rebuild.txt')).read().splitlines() if l]
res = {}
for l in open(os.path.join(d, 'build/results.jsonl')):
    r = json.loads(l)
    if 'module' in r: res[r['module']] = r
refs = []
for a in sys.argv[2:]:
    n, f = a.split('=', 1); x = {}
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: x[r['module']] = r
    refs.append((n, x))
ok = True
for m in miss:
    r = res.get(m); good = r is not None and r['rc'] == 0 and r['object_sha256'] == exp[m]
    ok &= good
    print(f"ENV {'OK ' if good else 'BAD'} {m}: rebuilt rc {r and r['rc']}, olean {'= expected (own-build record)' if good else 'differs'}")
for m in rb:
    r = res[m]; ok &= r['rc'] == 0 and r['errors'] == 0
    same = [n for n, x in refs if m in x and x[m]['source_sha256'] == r['source_sha256'] and x[m]['object_sha256'] == r['object_sha256']]
    print(f"SET {m}: rc {r['rc']} errors {r['errors']} sorry {r['sorry']} warnings {r['warnings']}; byte-identical to: {same or 'none'}")
print('RESULT', 'OK' if ok else 'FAIL', f'(environment rebuilt {len(miss)}, rebuild set {len(rb)})')
