#!/usr/bin/env bash
# solorun.sh <J2> <pr> <solo-commit> <own-records.jsonl>: one separate tip+PR check in the shared olean tree $SP/dl-oleans:
# checkout the worktree at the solo merge, soloenv.py --apply (copy base-snapshot oleans back where they are the expected ones),
# then runner.py over queue.txt (modules with no expected olean on disk + the rebuild set), imports-first, NOSTOP unset.
set -u
J2=$1; P=$2; C=$3; REC=$4; SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
W=$SP/wt-int-all; D=$J2/solo/pr$P
cd $W && git checkout -q --detach $C && test "$(git rev-parse HEAD)" = "$C" && test -z "$(git status --short)" || exit 3
python3 -I $J2/tools-used/soloenv.py /home/user/tcslib $C $REC $D/rebuild.txt $SP/dl-oleans $SP/dl-intall-backup $D/env --apply > $D/env.out || exit 4
cat $D/env.out
cd $J2 && python3 -I $J2/tools-used/review/runner.py $W $D/env/queue.txt $SP/dl-oleans $D/build > $D/build-runner.out 2>&1; echo "runner rc $?"
python3 -I $J2/tools-used/review/buildsum.py $D/build/results.jsonl | head -1
