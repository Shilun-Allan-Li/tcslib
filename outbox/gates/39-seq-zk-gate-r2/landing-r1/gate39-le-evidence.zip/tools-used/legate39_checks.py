"""legate39_checks.py <worktree> <parent> <head> <file>: (LE-gate39, new) for one edited file, parent vs head:
(1) headers: frozencheck_lib.compare (every declaration's header text before `:=`, its statement prose, def bodies);
(2) stripped code diff: doc and module comments removed (`/-[-!] ... -/`, as doconly_sg.py), unified diff, 0 context;
(3) docstring pure-insertion: for each changed docstring, the parent docstring is the head docstring with ONE contiguous
    chunk removed (prints the chunk)."""
import sys, os, re, difflib, subprocess
wt, par, head, f = sys.argv[1:5]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import frozencheck_lib as fc
show = lambda rev: subprocess.run(['git', '-C', wt, 'show', f'{rev}:{f}'], capture_output=True, check=True).stdout.decode()
old, new = show(par), show(head)
B, H, diffs = fc.compare(old, new)
hb = {(d['kind'], d['name']): d for d in H}
print(f'== (1) header check {f}: {len(B)} declarations at parent, {len(H)} at head')
for d in B:
    h = hb.get((d['kind'], d['name']))
    st = 'MISSING' if h is None else ('header identical' if d['header'] == h['header'] else 'HEADER-DIFF')
    extra = '' if h is None else (', prose same' if d['prose'] == h['prose'] else ', prose changed') + \
        (', whole same' if d['whole'] == h['whole'] else ', whole changed')
    print(f"{d['kind']} {d['name']}: {st}{extra}")
print('diffs:', diffs if diffs else 'none')
strip = lambda s: re.sub(r'/-[-!].*?-/', '/--DOC-/', s, flags=re.S)
so, sn = strip(old).split('\n'), strip(new).split('\n')
d = list(difflib.unified_diff(so, sn, f'a/{f}', f'b/{f}', n=0, lineterm=''))
ch = sum(1 for l in d if l[:1] in '+-' and not l.startswith(('+++', '---')))
print(f'== (2) stripped code diff: code lines changed after stripping doc/module comments: {ch}')
print('\n'.join(d))
docs = lambda s: re.findall(r'/-[-!].*?-/', s, flags=re.S)
do, dn = docs(old), docs(new)
print(f'== (3) docstrings {len(do)} -> {len(dn)}')
for a, b in zip(do, dn):
    if a == b: continue
    i = 0
    while i < len(a) and a[i] == b[i]: i += 1
    j = 0
    while j < len(a) - i and a[-1 - j] == b[-1 - j]: j += 1
    chunk = b[i:len(b) - j]
    ok = b[:i] + b[len(b) - j:] == a
    print(f'changed docstring: pure insertion {ok}; inserted chunk {chunk!r}')
w = max(len(l) for l in new.split('\n'))
print(f'max width {w}; lines {old.count(chr(10))} -> {new.count(chr(10))}')
