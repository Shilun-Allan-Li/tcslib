r"""bothdownN.py <repo> <rev> <outdir> <tag> <seed1.txt> ... <seedN.txt>: bothdown3.py (int-313-323-324 tools-used) generalised
to N seed sets (same import parsing as downorder.py): TCSlib/audits modules at <rev> downstream of (transitively import, or are)
a module of each set, their union, and for every pair the modules downstream of BOTH; also the modules downstream of three or
more sets. Writes <tag>-down<X>.txt, <tag>-union.txt, <tag>-<X>-<Y>-both.txt, <tag>-multi.tsv (module, count, sets)."""
import sys, re, subprocess, os, itertools
repo, rev, outd, tag = sys.argv[1:5]; sf = sys.argv[5:]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
rdep = {}
for m in files:
    for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M):
        if local(i): rdep.setdefault(i.replace('.', '/'), set()).add(m)
fs = set(files)
def down(seeds):
    seen, todo = set(), [s for s in seeds if s in fs]
    while todo:
        m = todo.pop()
        if m in seen: continue
        seen.add(m); todo.extend(rdep.get(m, ()))
    return seen
names, sets, present = [], [], []
for f in sf:
    seeds = [l.strip() for l in open(f) if l.strip()]
    names.append(os.path.basename(f).rsplit('.', 1)[0]); sets.append(down(seeds)); present.append(f'{sum(s in fs for s in seeds)}/{len(seeds)}')
w = lambda n, xs: open(os.path.join(outd, f'{tag}-{n}.txt'), 'w').write(''.join(x + '\n' for x in sorted(xs)))
for n, s in zip(names, sets): w('down' + n, s)
u = set().union(*sets); w('union', u)
msg = [f'{tag} {rev}: files {len(files)}; seeds present ' + ', '.join(f'{n} {p}' for n, p in zip(names, present)),
       '  ' + '; '.join(f'down{n} {len(s)}' for n, s in zip(names, sets)) + f'; union {len(u)}']
for i, j in itertools.combinations(range(len(sets)), 2):
    b = sets[i] & sets[j]; w(f'{names[i]}-{names[j]}-both', b)
    msg.append(f'  both {names[i]} & {names[j]}: {len(b)} (union {len(sets[i] | sets[j])})')
multi = sorted((m, [n for n, s in zip(names, sets) if m in s]) for m in u)
with open(os.path.join(outd, f'{tag}-multi.tsv'), 'w') as o:
    for m, ns in multi:
        if len(ns) >= 2: o.write(f'{m}\t{len(ns)}\t{",".join(ns)}\n')
from collections import Counter
c = Counter(len(ns) for m, ns in multi)
msg.append('  modules by number of PRs they are downstream of: ' + ', '.join(f'{k}: {c[k]}' for k in sorted(c)))
print('\n'.join(msg))
