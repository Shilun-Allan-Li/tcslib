import TCSlib
/-! Supplementary probe (not in the 308-309 method). In the root environment of the trial tree, set A = constants
declared in #307's 9 modules, set B = constants declared in the HashAndSign* and Lamport* modules and the
Authentication facade. Reports fully-qualified collisions (should be impossible once `import TCSlib` succeeds) and
last-component (short-name) overlaps, i.e. names that could become ambiguous under `open`. Internal details,
auxiliary recursors and noConfusion constants are skipped. -/
open Lean

def inA (m : Name) : Bool :=
  m == `TCSlib.Cryptography.Candidates.DiscreteLog || m == `TCSlib.Cryptography.Hashing ||
  (`TCSlib.Cryptography.Hashing.FromDiscreteLog).isPrefixOf m

def inB (m : Name) : Bool :=
  m == `TCSlib.Cryptography.Authentication ||
  (`TCSlib.Cryptography.Authentication.Signatures.HashAndSign).isPrefixOf m ||
  (`TCSlib.Cryptography.Authentication.Signatures.Lamport).isPrefixOf m

def lastComp : Name → String
  | .str _ s => s
  | n => toString n

run_cmd do
  let env ← getEnv
  let mut A : Std.HashMap String (Array (Name × Name)) := {}
  let mut B : Std.HashMap String (Array (Name × Name)) := {}
  let mut na := 0
  let mut nb := 0
  for (n, _) in env.constants.map₁.toList do
    if n.isInternalDetail || isAuxRecursor env n || isNoConfusion env n then continue
    match env.getModuleIdxFor? n with
    | none => pure ()
    | some i =>
      let m := env.header.moduleNames[i.toNat]!
      if inA m then
        A := A.insert (lastComp n) ((A.getD (lastComp n) #[]).push (n, m)); na := na + 1
      else if inB m then
        B := B.insert (lastComp n) ((B.getD (lastComp n) #[]).push (n, m)); nb := nb + 1
  let mut full := 0
  let mut short := 0
  let keys := (A.toList.map (·.1)).toArray.qsort (· < ·)
  for k in keys do
    match B.get? k with
    | none => pure ()
    | some bs =>
      for (a, ma) in A.getD k #[] do
        for (b, mb) in bs do
          if a == b then full := full + 1
          short := short + 1
          logInfo m!"OVERLAP {k}: A {a} ({ma}) | B {b} ({mb})"
  logInfo m!"SUMMARY A constants {na}, B constants {nb}, fully-qualified collisions {full}, short-name overlap pairs {short}"
