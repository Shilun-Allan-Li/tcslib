# sources-r1.zip · Gate 50 (GSW 6a fills #366 with LE-g50, and #368) round 1

Every file is a git blob, written unchanged. Each line below gives its SHA-256, its path in this ZIP and its
origin (`git <rev>:<path>`, with the blob id).

- `pr366/head-597fb736/`: the 23 Lean files #366 changes against its merge base `555f0fe1`, at the head `597fb736`.
- `pr366/gate45-frozen-d154c883/`: the 6a files at #359's head `d154c883`, the frozen statements Gate 45 cleared
  (the targets with `sorry`).
- `pr366/tip-base-555f0fe1/`: the six #360 / LE-gf3 / LE-g50 owner files at #366's merge base (the records tip, whose
  Lean is snapshot #8's T).
- `pr366/before-leg50-93ae671e/`: the three files LE-g50 edits, before it.
- `pr368/base-55f55371/`, `pr368/head-1953898b/`: the two files of #368.
- `mathlib-029db123/`, `batteries-39260e31/`: the pinned Mathlib and Batteries files holding the lemmas the landing
  edits reuse (`Nat.pow_log_le_add_one`, `Finset.sum_le_card_nsmul`, `IsCycleOn.pow_apply_eq_pow_apply`,
  `IsCycle.isCycleOn`, `Finset.sum_pi_single'`) and the nearest relatives (`Nat.ofBits_testBit`).
- `references/`: the ingested transcriptions of [Bar89], [BV14], [BV11] and [GSW13] at the records tip.

```text
9e5aeeb7598b7af644836a58f29cc3382b02e00f839c4478f174ecd855676f3b  pr366/head-597fb736/TCSlib.lean  git 597fb736e545:TCSlib.lean (blob 8db619ce45cb)
eb3b2700e88e5d05b88c737fb34371187e8b3a100cba24a5cca80beb87d28709  pr366/head-597fb736/TCSlib/Complexity/BranchingPrograms.lean  git 597fb736e545:TCSlib/Complexity/BranchingPrograms.lean (blob 8fa0bd2aa3b8)
bdc515cdf938c65029469f11f869961daafc72330b7eea1dcb6d0b7f29b0d162  pr366/head-597fb736/TCSlib/Complexity/BranchingPrograms/Barrington.lean  git 597fb736e545:TCSlib/Complexity/BranchingPrograms/Barrington.lean (blob 3bdf3d8f5833)
0ee5fcc2406b520f90a04d2d7f0301bd8df0377bf1e9298a35df3cd52e8d2088  pr366/head-597fb736/TCSlib/Complexity/BranchingPrograms/BarringtonConverse.lean  git 597fb736e545:TCSlib/Complexity/BranchingPrograms/BarringtonConverse.lean (blob 26446454b818)
8a5037dd17241285a7cc1241cd821c6ef38e68ecf93cc1e24c072321b8dc8b2c  pr366/head-597fb736/TCSlib/Complexity/BranchingPrograms/Defs.lean  git 597fb736e545:TCSlib/Complexity/BranchingPrograms/Defs.lean (blob 3d2aed4a55ca)
c515299f272ad71393013e392816d8e76cf2714c0e7557dcb6b37dca689f2ad7  pr366/head-597fb736/TCSlib/Complexity/BranchingPrograms/Eval.lean  git 597fb736e545:TCSlib/Complexity/BranchingPrograms/Eval.lean (blob 668c04a3b5cb)
6e4b4aac390bfa5e1870700d281d4d5d012ef6d4cede7a9f8c1903ba5b0988ef  pr366/head-597fb736/TCSlib/Complexity/BranchingPrograms/NC1.lean  git 597fb736e545:TCSlib/Complexity/BranchingPrograms/NC1.lean (blob ba089ea1b9c0)
5356732e92a06d9e317dbecb9a10e3f322fcb4d01df90b6996a987f56f0d8251  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity.lean (blob 3306c1f225fe)
76577ac65f2f0c3d0b95181f2636b67d19a059633d3bcf850ffa4b6217111cd3  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/Adder.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/Adder.lean (blob 12e87e0875e7)
e8184991f837c1ea999ce1b36d9e1b51f9a3e5c845a3bf0587b8e6190e2e2f0a  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/Basic.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/Basic.lean (blob 76333630a82e)
220b694c23453ca29c8dcdda0dfc0ff5d8464802105ac794877162221dcc75ac  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean (blob 1e327b89c607)
e0b1d80688fe62410fd9a0c0ff5eda5fc95426af966362068339346ff9b89593  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/DAGTransform.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/DAGTransform.lean (blob 5bf2df0c0b63)
0cdc9004710fc0220762b59fdab54937d999cbe81ac7737c277f36561be6e7dd  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/FormulaArith.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/FormulaArith.lean (blob a18ae12588b5)
2ab6afd5667c344581b416dd1d43397c7864b662c44c71b83f14653c44e2fcab  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/FormulaArith/CarrySave.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/FormulaArith/CarrySave.lean (blob c2c5c847486b)
11fdc51380bd80c36a3e46ddd5cc215b974aebcac0b01e3a2b078c84bd242de7  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean (blob f1bb1e985a92)
2402a2b81131fae4c1fb2bbc5ace2ffde309533fbe9a6603e603d78b93a5d82a  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/FormulaArith/Compare.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/FormulaArith/Compare.lean (blob fc48875d81ae)
0ab74c23ed7e1084211caf91bf2cd15e58869b73f0ce3e01eb56275067057e9f  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean (blob b6a4f3d7295f)
45b38f764a314258024a0cf52899eb0f9b0af147bcb5a5c93b22b496d1ca74c9  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/Hierarchy.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/Hierarchy.lean (blob 9be5c41fb40b)
56028d0263f0b238f53795aa8017dc2921699809aee70807bc1dd59a8411f7b2  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/NANDForm.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/NANDForm.lean (blob f0efb6ef2885)
814e24c2053417b567d44c4b3e34f2943f83007069a58b65c6c110611b8cd55b  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/NANDLayering.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/NANDLayering.lean (blob 007ef266d5a6)
66a1b0f5948ba39ed5d4a601b32880279c128d871727e8836af95a5c61e9aba5  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/TreeDAG.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/TreeDAG.lean (blob a625f4cebeb0)
61e908579cecb7561eabae06b6607b1d291980791d4399ca5a85a20e1a789f25  pr366/head-597fb736/TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean  git 597fb736e545:TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean (blob c687a1fe7bbe)
28a5b64bbf9ffb2b0b93642deed791966f543df981e6468666cca18b2b310863  pr366/head-597fb736/TCSlib/ComputationalModels.lean  git 597fb736e545:TCSlib/ComputationalModels.lean (blob 5e0814c802fa)
6466c5c72eb42ab89f6602cf68ac72838986847ebd8b518a49c046ecaad3c852  pr366/gate45-frozen-d154c883/TCSlib/Complexity/BranchingPrograms/Barrington.lean  git d154c8830fc8:TCSlib/Complexity/BranchingPrograms/Barrington.lean (blob 3c3c6ffe4eed)
16663708223833cf70b86518f5f254c3b7a5c2ecba66cd6bba32fc717ece63dd  pr366/gate45-frozen-d154c883/TCSlib/Complexity/BranchingPrograms/BarringtonConverse.lean  git d154c8830fc8:TCSlib/Complexity/BranchingPrograms/BarringtonConverse.lean (blob af7b15bbbf7d)
0067e3a13ad09c94ce7424094aa62c6971ba3a803d5ea8eefaef6f62c036a8f2  pr366/gate45-frozen-d154c883/TCSlib/Complexity/BranchingPrograms/Defs.lean  git d154c8830fc8:TCSlib/Complexity/BranchingPrograms/Defs.lean (blob 9b75523bcc85)
67cae626f0a43691cfe83c3e97760b305f6deb464ba46421837b372e2740b0e0  pr366/gate45-frozen-d154c883/TCSlib/Complexity/BranchingPrograms/Eval.lean  git d154c8830fc8:TCSlib/Complexity/BranchingPrograms/Eval.lean (blob 8697666a9e10)
63062599ab4bee887bba0afef19d2e5c7d1c6465d8808c39247cc77070b03f13  pr366/gate45-frozen-d154c883/TCSlib/Complexity/BranchingPrograms/NC1.lean  git d154c8830fc8:TCSlib/Complexity/BranchingPrograms/NC1.lean (blob b0140ad0fdb4)
d541a3f699e4dcd980d48adec08f89c42ec777766b5ccb1505ae2a158636b03a  pr366/gate45-frozen-d154c883/TCSlib/Complexity/CircuitComplexity/FormulaArith/CarrySave.lean  git d154c8830fc8:TCSlib/Complexity/CircuitComplexity/FormulaArith/CarrySave.lean (blob e49dca78d752)
a8ff284e1e9d40637542e2902769e3cc49e19c980a37f45f3a7193161fcf54f4  pr366/gate45-frozen-d154c883/TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean  git d154c8830fc8:TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean (blob 34108210f0af)
6e895de7d97ee9bee81cd52881e593d824c8231d45b6b3276c84198d17c9edb7  pr366/gate45-frozen-d154c883/TCSlib/Complexity/CircuitComplexity/FormulaArith/Compare.lean  git d154c8830fc8:TCSlib/Complexity/CircuitComplexity/FormulaArith/Compare.lean (blob 0cc16191bd74)
1b2ae77a9a8bdc78cdd247d2fb656040ed7ec39a9992248bfab9ec2971ca2c13  pr366/gate45-frozen-d154c883/TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean  git d154c8830fc8:TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean (blob ba24bf30f1b6)
a9f4665587351d5470af45451e3444e55cd7d48558de6c56ad533588ba7f2359  pr366/gate45-frozen-d154c883/TCSlib/Complexity/CircuitComplexity/NANDForm.lean  git d154c8830fc8:TCSlib/Complexity/CircuitComplexity/NANDForm.lean (blob 04a932b7a710)
06b50b373928bee06b0c8299b734b8863a180288e70dc5b4d21f468433c977b7  pr366/gate45-frozen-d154c883/TCSlib/Complexity/CircuitComplexity/NANDLayering.lean  git d154c8830fc8:TCSlib/Complexity/CircuitComplexity/NANDLayering.lean (blob 759617826a58)
24559b1e5fc92322ecababf99d32fe31bcb80c861e452e8eb655e6b5f790eb10  pr366/tip-base-555f0fe1/TCSlib/Complexity/CircuitComplexity/Adder.lean  git 555f0fe1b10a:TCSlib/Complexity/CircuitComplexity/Adder.lean (blob 53e226200a08)
05d5f8769bfa5384b306f4f9d51f092d6e23368c748f994438a98bbf56bf39af  pr366/tip-base-555f0fe1/TCSlib/Complexity/CircuitComplexity/Basic.lean  git 555f0fe1b10a:TCSlib/Complexity/CircuitComplexity/Basic.lean (blob 81243c43e95b)
f827741cefa617d447e7af0b0634bb1c3457ae0c45ddf5f894af685fea81b5fc  pr366/tip-base-555f0fe1/TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean  git 555f0fe1b10a:TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean (blob ba29d2cd627d)
023b6115dd010206120f1c0cb642db8f5588db7c4be5d9e699572b4f68488a9f  pr366/tip-base-555f0fe1/TCSlib/Complexity/CircuitComplexity/DAGTransform.lean  git 555f0fe1b10a:TCSlib/Complexity/CircuitComplexity/DAGTransform.lean (blob d6312c3f9e14)
2b9824996de35e2f56a69e589113bebaf035a5c05de4062eef781151cb01f8a2  pr366/tip-base-555f0fe1/TCSlib/Complexity/CircuitComplexity/TreeDAG.lean  git 555f0fe1b10a:TCSlib/Complexity/CircuitComplexity/TreeDAG.lean (blob 1849bd1401ee)
d162dd43c3d7fff48900a7882b49ed82bfee0337fc84cb131b88ab6b8e66e071  pr366/tip-base-555f0fe1/TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean  git 555f0fe1b10a:TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean (blob 02cebfca85e3)
08c2d7b034a6ea04d21d926599b316270ef25b0467fcf72b74587797a2925bd7  pr366/before-leg50-93ae671e/TCSlib/Complexity/BranchingPrograms/Barrington.lean  git 93ae671e8f63:TCSlib/Complexity/BranchingPrograms/Barrington.lean (blob d1d6aa925bb7)
76a34433952ec4326328e88d9ed3e3d76a8b181e7e0b289bd4229f30e3a54414  pr366/before-leg50-93ae671e/TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean  git 93ae671e8f63:TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean (blob 3ba96b1c724a)
1df08c3686adb72e57160976deff7e614757a66a46fcf53abbbe6543feb01a17  pr366/before-leg50-93ae671e/TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean  git 93ae671e8f63:TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean (blob a22414d9d608)
d824b5a0c49ec5e5babc56cdf8d789cf51fb0d1249f17c789997e15ef800c433  pr368/base-55f55371/TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean  git 55f553715f28:TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean (blob a067fa818efc)
d2f1d208f6afa81bf1b4667491fe652d9a2351a1dc8bf4a161565e96895f3789  pr368/head-1953898b/TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean  git 1953898b18a3:TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean (blob 8b8721aa01f1)
43f97356379dd81a8b7a9425d0b636f1be46bafaec32fcc7d1900a071b217e50  pr368/base-55f55371/TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean  git 55f553715f28:TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean (blob 3e39a03c5851)
cd5adfc38ef23d2c9270246fdb1416e4194f70b77836ac5749b0f65515458e81  pr368/head-1953898b/TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean  git 1953898b18a3:TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean (blob 835d4db07787)
8e0e2f7aa05dff8862f60a46058c880270e81c418646c5e9157615a8331ee29a  mathlib-029db123/Mathlib/Data/Nat/Log.lean  git 029db123ddaa:Mathlib/Data/Nat/Log.lean (blob a942dd3113ef)
c6e448b283c8c0c9cb4050b7e0972aa36d50ce8b070cf036c75bea5ba0ad5b16  mathlib-029db123/Mathlib/GroupTheory/Perm/Cycle/Basic.lean  git 029db123ddaa:Mathlib/GroupTheory/Perm/Cycle/Basic.lean (blob 9c39303aa00c)
72b419419b56619b3125dc6bdd8a72577516c9a0435f3a9c979f7c0c67cfe99a  mathlib-029db123/Mathlib/GroupTheory/Perm/Cycle/Type.lean  git 029db123ddaa:Mathlib/GroupTheory/Perm/Cycle/Type.lean (blob 8fb97d2ae4bd)
38888fba19655034ce5bc180ec4a81e542a9d4fba0bcb71ed99e91474dea5c4f  mathlib-029db123/Mathlib/Algebra/Order/BigOperators/Group/Finset.lean  git 029db123ddaa:Mathlib/Algebra/Order/BigOperators/Group/Finset.lean (blob bd7cde0b9f29)
53a4f5488226df586a75bb8b45945aade5501b072ffe83f52ffbc0be619f3f5a  mathlib-029db123/Mathlib/Algebra/BigOperators/Group/Finset/Piecewise.lean  git 029db123ddaa:Mathlib/Algebra/BigOperators/Group/Finset/Piecewise.lean (blob a32891c72d29)
4150abd22d6ba29b0df80a95ec8ed47457a814ff14a656595e9d8311c5836bf0  batteries-39260e31/Batteries/Data/Nat/Lemmas.lean  git 39260e31b7b3:Batteries/Data/Nat/Lemmas.lean (blob a1a4c7f8263d)
35ed4bb722eb42b75285ed4fad6d3adec73f2cc381d6d0c61eec4e5f8a3dd3f3  batteries-39260e31/Batteries/Data/Nat/Basic.lean  git 39260e31b7b3:Batteries/Data/Nat/Basic.lean (blob 3bbdede1f9e0)
0e14d97efe06b4c9f0e2f7672d744885b4e53fa2a3777c3694a664322620c71a  references/barrington-1989-bounded-width-bp.md  git f19b8056488f:blueprint/src/references/barrington-1989-bounded-width-bp.md (blob 3885e63029e7)
3da79813fa63acfea4a83229c46f2f8947a7a754657fac8f4d6bf1e7891e9392  references/brakerski-vaikuntanathan-2014-fhe.md  git f19b8056488f:blueprint/src/references/brakerski-vaikuntanathan-2014-fhe.md (blob 045afa6f7871)
f415fdbd4488316e2044e0a8e767c75b69964ff48fb6294617b35ae125177eba  references/brakerski-vaikuntanathan-2011-fhe.md  git f19b8056488f:blueprint/src/references/brakerski-vaikuntanathan-2011-fhe.md (blob f09eb2c4fe41)
df0d793d8a5a952662502a6c80cb2e3dc41a7372d4ae8e26c7aa49b6219ca540  references/gentry-sahai-waters-2013-fhe.md  git f19b8056488f:blueprint/src/references/gentry-sahai-waters-2013-fhe.md (blob 300410b7f713)
```
