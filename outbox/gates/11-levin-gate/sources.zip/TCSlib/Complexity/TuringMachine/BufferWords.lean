/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.TuringMachine.Simulation

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Buffer tapes of composite words

Cell identities for the buffer tape `Turing.FinTM.bufferTape w`, which holds the word `w` from
cell `0` and is blank everywhere else, when `w` is built from smaller words: a suffix read at an
offset, a middle word's letters, a prefix or a suffix of the word, the blank cells off the word,
and the cells of a unary word with its terminator. A machine's contract can then read the fields
of a serialized layout, such as a pair encoding followed by a unary state and a table, cell by
cell. Every proof reads `bufferTape` only through its published equations.

## Main results

* `Turing.FinTM.bufferTape_append_shift` — past a prefix `u`, the buffer of `u ++ w` reads `w`'s
  buffer.
* `Turing.FinTM.bufferTape_append_mid` — the letters of the middle word of `u ++ w ++ v`.
* `Turing.FinTM.bufferTape_drop`, `Turing.FinTM.bufferTape_take` — the buffer of a suffix or a
  prefix of a word.
* `Turing.FinTM.bufferTape_eq_none_of_not_mem` — every cell off the word is blank.
* `Turing.FinTM.bufferTape_unary` — the cells of the unary word `1^q 0`, its terminator
  included.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (§1.2: tapes holding words; §1.4: encodings of machines as
  strings, whose fields these identities read.)
-/

namespace Turing.FinTM

/-- **A suffix at an offset**: at a cell `z ≥ 0` past the prefix `u`, the buffer of `u ++ w`
reads the buffer of `w` at `z`, including `w`'s right blank and every cell beyond it.

**Proof sketch.** Both cells are nonnegative, and list lookup in `u ++ w` at `|u| + z` is lookup
in `w` at `z`. -/
theorem bufferTape_append_shift {Symbol : Type*} (u w : List Symbol) {z : ℤ} (hz : 0 ≤ z) :
    bufferTape (u ++ w) (u.length + z) = bufferTape w z := by
  rw [bufferTape_eq, bufferTape_eq, if_pos (by omega), if_pos hz,
    show ((u.length : ℤ) + z).toNat = u.length + z.toNat by omega,
    List.getElem?_append_right (Nat.le_add_right _ _), Nat.add_sub_cancel_left]

/-- **A middle word's letters**: in the buffer of `u ++ w ++ v`, the cell `|u| + r` holds `w`'s
letter `r`, for `r < |w|`.

**Proof sketch.** Past `u`, the buffer reads the buffer of `w ++ v`
(`Turing.FinTM.bufferTape_append_shift`), whose cell `r < |w|` is `w`'s letter. -/
theorem bufferTape_append_mid {Symbol : Type*} (u w v : List Symbol) (r : ℕ) (hr : r < w.length) :
    bufferTape (u ++ w ++ v) (u.length + r) = some w[r] := by
  rw [List.append_assoc, bufferTape_append_shift u (w ++ v) (Int.natCast_nonneg r), bufferTape_nat,
    List.getElem?_append_left hr, List.getElem?_eq_getElem hr]

/-- **The buffer of a suffix**: at a cell `z ≥ 0`, the buffer of `w.drop r` reads the buffer of
`w` at `r + z`.

**Proof sketch.** `w` is `w.take r ++ w.drop r`. If `r ≤ |w|`, the prefix has length `r` and
`Turing.FinTM.bufferTape_append_shift` applies. Otherwise the suffix is empty, and the cell
`r + z` is past `w`'s end, so both sides are blank. -/
theorem bufferTape_drop {Symbol : Type*} (w : List Symbol) (r : ℕ) {z : ℤ} (hz : 0 ≤ z) :
    bufferTape (w.drop r) z = bufferTape w (r + z) := by
  by_cases hr : r ≤ w.length
  · have h := bufferTape_append_shift (w.take r) (w.drop r) hz
    rw [List.take_append_drop, List.length_take, min_eq_left hr] at h
    exact h.symm
  · rw [List.drop_eq_nil_of_le (by omega), bufferTape_eq, bufferTape_eq, if_pos hz,
      if_pos (by omega), List.getElem?_nil, List.getElem?_eq_none (by omega)]

/-- **The buffer of a prefix**: at a cell `z < n`, the buffer of `w.take n` reads the buffer of
`w`.

**Proof sketch.** Negative cells are blank on both sides. At `0 ≤ z < n`, list lookup in
`w.take n` is lookup in `w`. -/
theorem bufferTape_take {Symbol : Type*} (w : List Symbol) (n : ℕ) {z : ℤ} (hz : z < n) :
    bufferTape (w.take n) z = bufferTape w z := by
  rw [bufferTape_eq, bufferTape_eq]
  split_ifs with h
  · rw [List.getElem?_take, if_pos (by omega)]
  · rfl

/-- **Off the word, the buffer is blank**: every cell outside `[0, |w|)` reads `none`.

**Proof sketch.** A negative cell is blank by the buffer's equation, and a cell at or past `|w|`
is past the end of the list. -/
theorem bufferTape_eq_none_of_not_mem {Symbol : Type*} (w : List Symbol) {z : ℤ}
    (hz : ¬(0 ≤ z ∧ z < w.length)) : bufferTape w z = none := by
  rw [bufferTape_eq]
  split_ifs with h
  · exact List.getElem?_eq_none (by omega)
  · rfl

/-- **A unary word's cells**: the buffer of `1^q 0` (`q` letters `true`, then the terminator
`false`) reads `true` at the cells `r < q` and `false` at `r = q`, that is,
`some (decide (r < q))` for every `r ≤ q`.

**Proof sketch.** At `r < q` list lookup stays in the block of `true`s; at `r = q` it reads the
terminator. -/
theorem bufferTape_unary (q r : ℕ) (hr : r ≤ q) :
    bufferTape (List.replicate q true ++ [false]) r = some (decide (r < q)) := by
  rw [bufferTape_nat]
  by_cases hlt : r < q
  · rw [List.getElem?_append_left (by rw [List.length_replicate]; exact hlt),
      List.getElem?_replicate_of_lt hlt, decide_eq_true hlt]
  · obtain rfl : r = q := by omega
    rw [List.getElem?_append_right (by rw [List.length_replicate]), List.length_replicate,
      Nat.sub_self, decide_eq_false (Nat.lt_irrefl r)]
    rfl

end Turing.FinTM
