/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.TuringMachine.Encoding
import TCSlib.Complexity.TuringMachine.NDCodes
import TCSlib.Complexity.TuringMachine.MathlibBridge
import Mathlib.Tactic.FinCases
import TCSlib.Complexity.TuringMachine.Build.VirtualInput
import TCSlib.Complexity.TuringMachine.Build.Catalog
-- B5a sanctioned import: the shared canonizer and uniform simulator.
import TCSlib.Complexity.TuringMachine.CodeSimulator

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Deterministic two-work-tape machine codes (Z3)

The deterministic code layer currently covers only the one-work-tape
binary normal form (`Turing.CodeTM`/`Turing.MachineCode`/
`Turing.EffectiveMachineCode`, `Encoding.lean`), which is why the received
time hierarchy arrives at `f²` strength (plan §2.1): converting to that
normal form costs a square. This file is §13's Z3: the **deterministic
two-work-tape** code scheme, the codes the two-work-tape universal machine
(stage 1, plan §4b) reads, over **the same `Turing.actionBits₂` record
format** that `Turing.CodeNDTM` fixed for the nondeterministic two-tape
codes (design §13a: one branch instead of two — never a second
serialization). The file name reads *codes for two-tape machines*
(decision 13.3, renamed from `Codes2` by the user).

Mirrors: `Turing.CodeTM` → `Turing.Code2TM`; `Turing.MachineCode` →
`Turing.MachineCode2`; `Turing.EffectiveMachineCode` →
`Turing.EffectiveMachineCode2`; and, per the P3.2 lesson (a variable-code
consumer needs uniformly timed decoding — `EffectiveMachineCode` bounds no
decoding time), `UniformMachineCode` (`Diagonalization/EXPCOM.lean`) →
`Turing.UniformMachineCode2`.

## Status

The effective and the uniform schemes are proved, with no admission. The uniform scheme
instantiates the shared canonizer and the uniform simulator of `CodeSimulator`
(`Turing.MachineFormat.exists_polyCanonizer`, `Turing.MachineFormat.exists_uniformSimulator`) at
two work tapes.

## Main definitions and results

* `Turing.Code2TM`, `Turing.Code2TM.serialize` — the deterministic
  two-work-tape normal form and its fixed, scheme-independent
  serialization (27 `Turing.actionBits₂` records per state: three input
  reads by three reads on each of the two work tapes).
* `Turing.MachineCode2`, `Turing.EffectiveMachineCode2`,
  `Turing.UniformMachineCode2` — the scheme laws, the effective scheme,
  and the uniformly timed scheme.
* `Turing.Code2TM.serialize_eq_serializeK` — the frozen serialization is the generic
  `k`-record one at two work tapes.
* `Turing.exists_effectiveMachineCode2`,
  `Turing.exists_uniformMachineCode2` — proved existence statements (the latter
  modulo the uniform simulator).

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern
  Approach*, Cambridge University Press, 2009. (§1.4, machine codes;
  §1.7/§3.1 for the two-tape consumer.)

**ZF-B status appendix.** The skeleton-status text above records the received
statement phase. `exists_effectiveMachineCode2` is now proved; the uniform
simulator remains the continuation target. The new implementation includes
private adaptations of inaccessible helpers in `CodeParser.lean` and
`MathlibBridge.lean`, with declaration-level provenance in `REPORT.md`.

**ZF-B2 cleanup appendix.** The ZF-B provenance above records the original
delivery. Its 46 format-independent local copies have now been deleted:
all uses cite the promoted public readers and primitive-recursion lemmas.
The 24 remaining private declarations implement the two-tape format and
its 354-bit regression; their one-tape counterparts and retained proof
material are itemized in this delivery's duplication ledger.

## Item-8 appendix

The two-work-tape parser and canonizer now instantiate the shared `CodeFormat`
layer. ZF-B3 consumes its decoded-size and guard corollaries, with the existing
silent fallback and every public scheme statement preserved.
-/

namespace Turing

/-- The coded normal form of a deterministic machine with **two** work
tapes: a binary-alphabet machine with state space `Fin (numStates + 1)`
(never empty). Two work tapes, not one, because the Hennie-Stearns
conversion lands there at `O(T log T)` and the two-tape universal machine
(its consumer) runs such codes at linear overhead — the whole point of
strengthening past `Turing.CodeTM`'s square. Mirrors `Turing.CodeTM` and
`Turing.CodeNDTM`. [AB09, §1.4, §1.7] -/
structure Code2TM where
  /-- one less than the number of states (so the state space is never empty) -/
  numStates : ℕ
  /-- the underlying two-work-tape deterministic machine -/
  tm : MultiTapeTM 2 Bool (Fin (numStates + 1))

/-- The bundled machine of a coded two-tape machine. -/
def Code2TM.toFinTM (M : Code2TM) : FinTM Bool where
  k := 2
  State := Fin (M.numStates + 1)
  tm := M.tm

/-- The **fixed, scheme-independent** canonical serialization, mirroring
`Turing.CodeTM.serialize` and `Turing.CodeNDTM.serialize` over the same
`Turing.actionBits₂` record: the state count, the initial state, then the
full transition table in the fixed enumeration order — states in `Fin`
order, then the input read and the two work reads each over `none`,
`some false`, `some true` (27 records per state; the nondeterministic
table's outermost choice bit is absent). This is the target format of
`Turing.EffectiveMachineCode2.canonizer` and the input format of the
two-work-tape universal machine. -/
def Code2TM.serialize (M : Code2TM) : List Bool :=
  pairEncode (Nat.bits M.numStates)
    (unaryFin M.tm.q₀ ++
      (List.finRange (M.numStates + 1)).flatMap fun q =>
        ([none, some false, some true] : List (Option Bool)).flatMap fun inp =>
          ([none, some false, some true] : List (Option Bool)).flatMap fun w₀ =>
            ([none, some false, some true] : List (Option Bool)).flatMap fun w₁ =>
              actionBits₂ (M.tm.tr q inp (workPair w₀ w₁)))

/-- The algebraic laws of a representation scheme for coded two-tape
machines, mirroring `Turing.MachineCode` [AB09, §1.4]: a total decoding
(property 1), an encoding, and recovery under arbitrary `true`-padding
(property 2 — every machine has infinitely many representations). -/
structure MachineCode2 where
  /-- encode a machine as a binary string -/
  encode : Code2TM → List Bool
  /-- decode any binary string to a machine (total by type: property 1) -/
  decode : List Bool → Code2TM
  /-- a code followed by any amount of `true`-padding decodes to the
  machine (property 2) -/
  decode_encode_pad : ∀ M m, decode (encode M ++ List.replicate m true) = M

/-- Decoding a code recovers the machine (padding by zero symbols).
Skeleton-time proof, mirroring `Turing.MachineCode.decode_encode`. -/
theorem MachineCode2.decode_encode (c : MachineCode2) (M : Code2TM) :
    c.decode (c.encode M) = M := by
  simpa using c.decode_encode_pad M 0

/-- An *effective* representation scheme for two-tape machines: the
algebraic laws together with a machine of this development computing the
fixed serialization of the decoded machine — the mirror of
`Turing.EffectiveMachineCode`, with the same Argument-A rationale (the
target `Turing.Code2TM.serialize` is scheme-independent). As there, the
canonizer's time bound is arbitrary: fixed-code consumers absorb it into
their constants, and variable-code consumers must use
`Turing.UniformMachineCode2` instead. -/
structure EffectiveMachineCode2 extends MachineCode2 where
  /-- a machine computing the fixed serialization of the decoded machine -/
  canonizer : FinTM Bool
  /-- the canonizer's (arbitrary) time bound -/
  canonizerTime : ℕ → ℕ
  /-- the canonizer computes `serialize ∘ decode` -/
  canonizer_computes :
    canonizer.ComputesFunInTime (fun α => (decode α).serialize) canonizerTime

/-! ### Private parser and canonizer implementation (ZF-B)

The fixed silent fallback and the two-work-tape instance of `CodeFormat` supply
this format's parser and canonizer. The common record, table and primitive-recursion
laws live in `CodeFormat` and `MathlibBridge`; `zfBDecode` remains a typed alias
for the frozen uniform-simulator statements.
-/



/-- The fallback is the one-state, immediately halting, silent machine. -/
private def zfBFallback : Code2TM :=
  ⟨0, ⟨0, fun _ _ _ => ⟨.zero, fun _ => (none, .zero), none, none⟩⟩⟩

/-- The one-state halting fallback has the audited 354-bit serialization.
The closed computation includes its header and all 27 thirteen-bit records. -/
private lemma zfBFallback_serialize_length : zfBFallback.serialize.length = 354 := by
  unfold Code2TM.serialize
  dsimp only [zfBFallback]
  set_option maxRecDepth 10000 in
    norm_num [length_pairEncode, unaryFin, actionBits₂, signBits, optOptBoolBits,
      optBoolBits, optStateBits, List.finRange_succ, List.finRange_zero]

/-- The deterministic two-work-tape code format, with 27 records per state
and the fixed silent fallback. [AB09, §1.4] -/
private def twoTapeFormat : CodeFormat where
  Code := Code2TM
  Table := CodeTable2
  numStates := Code2TM.numStates
  assemble := fun n q t => ⟨n, ⟨q, fun s inp w => t s inp (w 0) (w 1)⟩⟩
  serialize := Code2TM.serialize
  tableBits := fun t => codeTable2Bits t
  readTable := codeReadTable2
  skipTable := codeSkipTable2
  guard := 351
  fallback := zfBFallback
  numStates_assemble := fun _ _ _ => rfl
  serialize_assemble := fun _ _ _ => by
    simp [Code2TM.serialize, codeTable2Bits, actionBits₂_eq_actionBitsK, workPair]
  assemble_surj := by
    rintro ⟨n, q, tr⟩
    refine ⟨n, q, fun s inp w₀ w₁ => tr s inp (workPair w₀ w₁), ?_⟩
    show Code2TM.mk n ⟨q, fun s inp w => tr s inp (workPair (w 0) (w 1))⟩ = Code2TM.mk n ⟨q, tr⟩
    congr 1
    congr 1
    funext s inp w
    apply congrArg (tr s inp)
    funext i
    fin_cases i <;> simp [workPair]
  readTable_append := fun _ t xs => codeReadTable2_append t xs
  readTable_sound := fun _ xs t rest h => codeReadTable2_sound xs t rest h
  readTable_erase := codeEraseTable2
  tableBits_length := fun _ t => codeTable2Bits_length t

/-- Total decoding: every malformed string denotes the fixed fallback. -/
private def zfBDecode (xs : List Bool) : Code2TM := twoTapeFormat.decode xs

/-- **An effective two-tape code scheme exists** (spec, fill pending —
tranche A-S2).

**Proof sketch.** Mirror the received constructions over the
single-branch table: `encode := Code2TM.serialize` itself; `decode`
parses the `Turing.pairEncode`d state count, the initial state, and the
transition table by the received parser architecture
(`TCSlib.Complexity.TuringMachine.CodeParser`, retargeted to the
`Turing.actionBits₂` record at **27 records per state** — the
nondeterministic retarget's `2 · 27 = 54` without the choice bit, so its
minimum-length guard scales by exactly half), with the single-state
do-nothing machine as the fallback on parse failure and trailing
`true`-padding tolerated by the end-marker discipline (property 2); the
canonizer re-serializes the parsed record by the arbitrary-time
computability route of the received deterministic construction
(`TCSlib.Complexity.TuringMachine.MathlibBridge`), so no polynomial
canonizer is claimed. Fill obligations, named: the record parser and its
fallback totalization; the pad-tolerance lemma; the canonizer assembly
and its time bound.

**ZF-B implementation appendix.** The private seven-field parser and its
suffix scanner implement this route, including the up-front 351-per-state
length guard. The scanner-based canonizer is proved primitive recursive,
then compiled by the public `codePrim_machine` theorem. Its arbitrary
length-only time bound is supplied by that theorem. The private parser and
primitive-recursion adaptations are itemized in the delivery's duplication
ledger; no ND existence theorem is used. 

**Item-8 appendix.** The two-work-tape instance now consumes the shared
`CodeFormat` parser, padded round trip and canonizer construction. The 351-per-state
guard and fixed fallback are unchanged; the private parser copies are removed. -/
theorem exists_effectiveMachineCode2 : Nonempty EffectiveMachineCode2 := by
  obtain ⟨M, T, h⟩ := twoTapeFormat.exists_canonizer codePrimSkipTable2
  exact ⟨⟨⟨Code2TM.serialize, zfBDecode, twoTapeFormat.decode_serialize_pad⟩, M, T, h⟩⟩

/-- A *uniformly timed* scheme for two-tape codes: the effective scheme
together with a bounded-acceptance simulator whose budget is one
polynomial **jointly** in the code length, input length, and time bound —
the mirror of `UniformMachineCode` (`Diagonalization/EXPCOM.lean`), which
exists because `EffectiveMachineCode2` deliberately bounds no decoding
time (the P3.2 lesson: with an arbitrary scheme, a variable-code consumer
can be made to pay unboundedly for decoding). -/
structure UniformMachineCode2 extends EffectiveMachineCode2 where
  /-- the uniformly timed bounded-acceptance simulator -/
  simulator : FinTM Bool
  /-- the simulator's single polynomial degree and coefficient -/
  simDegree : ℕ
  /-- on bounded acceptance, the simulator answers `[true]` within the
  uniform polynomial budget -/
  simulator_accepts : ∀ (α x : List Bool) (t : ℕ),
    (decode α).toFinTM.ComputesInTime x [true] t →
    simulator.ComputesInTime (pairEncode (pairEncode (Nat.bits t) α) x) [true]
      (simDegree * (α.length + x.length + t + 1) ^ simDegree)
  /-- otherwise it answers `[false]` within the same budget -/
  simulator_rejects : ∀ (α x : List Bool) (t : ℕ),
    ¬(decode α).toFinTM.ComputesInTime x [true] t →
    simulator.ComputesInTime (pairEncode (pairEncode (Nat.bits t) α) x) [false]
      (simDegree * (α.length + x.length + t + 1) ^ simDegree)

/-! ### Uniform-simulator instance (B5a, D4)

The specialized ZF-B3 preparation is superseded by `MachineFormat`. Its seven
output-summary/clock declarations moved, generalized, to `CodeSimulator`;
the nine remaining private preparation declarations were removed.
The 354-bit fallback regression above is retained.
-/

/-- **The two-tape serialization is the generic one** [AB09, §1.4]: for every coded two-tape
machine `M`, the frozen serialization `M.serialize` is the fixed `k`-record serialization
`serializeK M.tm` at two work tapes. (Promoted from the private `twoTape_serialize_eq` for the
two-tape scheme's `k`-tape view `Turing.EffectiveMachineCode2.toK`; statement and proof
unchanged.) -/
lemma Code2TM.serialize_eq_serializeK (M : Code2TM) : M.serialize = serializeK M.tm := by
  unfold Code2TM.serialize serializeK
  rw [tableBitsK_two]
  simp only [codeTable2Bits, actionBits₂_eq_actionBitsK]

/-- The existing two-tape parser equipped with its fixed machine semantics. -/
private def twoTapeMachineFormat : MachineFormat :=
  MachineFormat.mk twoTapeFormat 2 Code2TM.tm
    Code2TM.serialize_eq_serializeK codeSkipTable2_eq_codeSkipTableK

/-- **A uniformly timed two-tape scheme exists**.

**Proof sketch.** The concrete scheme of
`Turing.exists_effectiveMachineCode2` with the uniform simulator built as
in the received `exists_uniformMachineCode` route
(`Diagonalization/EXPCOM.lean`, P3.2 round 2): parse the nested input
keeping the deadline in binary; check the table's minimum-length guard by
binary arithmetic before any per-state iteration (a huge declared state
count is never expanded in unary; the guard constant halves against the
nondeterministic table); then run the clocked step-by-step simulation of
the decoded two-tape machine, charging one uniform polynomial jointly in
`|α| + |x| + t + 1`. The two-work-tape simulation is *easier* than the
received one-tape case for the step itself (the simulator hosts the two
coded tapes on two physical tapes — no tape reduction), and the Z1
virtual-input layer supplies the input discipline.

**Fill appendix (B5a).** This is the two-tape instance of the shared §12.11
canonizer and H1, as in the statement probe's `uniform_two`. The two-tape
writer and skipper bridges supply the format laws. The canonizer and the
uniform simulator are proved; no specialized interpreter is introduced. -/
theorem exists_uniformMachineCode2 : Nonempty UniformMachineCode2 := by
  obtain ⟨C, dC, hC⟩ := twoTapeMachineFormat.exists_polyCanonizer
  obtain ⟨S, d, hS⟩ := twoTapeMachineFormat.exists_uniformSimulator
  exact ⟨{
    toEffectiveMachineCode2 := {
      toMachineCode2 := ⟨Code2TM.serialize, twoTapeMachineFormat.decode,
        twoTapeFormat.decode_serialize_pad⟩
      canonizer := C
      canonizerTime := fun n => dC * (n + 1) ^ dC
      canonizer_computes := hC }
    simulator := S
    simDegree := d
    simulator_accepts := fun α x t h => (hS α x t).1 h
    simulator_rejects := fun α x t h => (hS α x t).2 h }⟩

end Turing
