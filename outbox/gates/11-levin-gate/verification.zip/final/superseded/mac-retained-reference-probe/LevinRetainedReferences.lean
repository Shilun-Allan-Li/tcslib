import Lean
set_option maxHeartbeats 0
set_option maxRecDepth 65536
open Lean
def changedInternalNames : NameSet :=
  [`Turing.FinTM.exists_emitIterTM._proof_1_1, `Turing.FinTM.exists_emitIterTM._proof_1_10, `Turing.FinTM.exists_emitIterTM._proof_1_11, `Turing.FinTM.exists_emitIterTM._proof_1_12, `Turing.FinTM.exists_emitIterTM._proof_1_13, `Turing.FinTM.exists_emitIterTM._proof_1_14, `Turing.FinTM.exists_emitIterTM._proof_1_15, `Turing.FinTM.exists_emitIterTM._proof_1_16, `Turing.FinTM.exists_emitIterTM._proof_1_17, `Turing.FinTM.exists_emitIterTM._proof_1_18, `Turing.FinTM.exists_emitIterTM._proof_1_19, `Turing.FinTM.exists_emitIterTM._proof_1_2, `Turing.FinTM.exists_emitIterTM._proof_1_20, `Turing.FinTM.exists_emitIterTM._proof_1_21, `Turing.FinTM.exists_emitIterTM._proof_1_22, `Turing.FinTM.exists_emitIterTM._proof_1_23, `Turing.FinTM.exists_emitIterTM._proof_1_3, `Turing.FinTM.exists_emitIterTM._proof_1_4, `Turing.FinTM.exists_emitIterTM._proof_1_5, `Turing.FinTM.exists_emitIterTM._proof_1_6, `Turing.FinTM.exists_emitIterTM._proof_1_7, `Turing.FinTM.exists_emitIterTM._proof_1_8, `Turing.FinTM.exists_emitIterTM._proof_1_9, `_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes._proof_1_1, `_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes._proof_1_2, `_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes._proof_1_3].foldl (fun s n => s.insert n) {}
#eval show IO Unit from do
  let modules ← IO.FS.lines "/private/tmp/tcslib-levin-proofs.g9J5YEGr/production/metadata/retained-modules.txt"
  let mut count := 0
  let mut constants := 0
  for modulePath in modules do
    let data ← Lean.readModuleData ("/private/tmp/tcslib-shim-retirement.wBNelrDf/native/oleans" / (modulePath ++ ".olean"))
    for c in data.1.constants do
      constants := constants + 1
      for dep in c.getUsedConstantsAsSet do
        if changedInternalNames.contains dep then
          throw <| IO.userError s!"Retained constant {c.name} uses changed helper {dep}"
    count := count + 1
  IO.println s!"RETAINED {count} modules, {constants} constants, zero changed-helper references"
