import sys,re,os
root,order_f,out=sys.argv[1],sys.argv[2],sys.argv[3]; seeds=sys.argv[4:]
order=[l.strip().removesuffix('.lean') for l in open(order_f) if l.strip()]
imp={}
for m in order:
    p=os.path.join(root,m+'.lean')
    ims=set()
    for l in open(p):
        mm=re.match(r'\s*import\s+(\S+)',l)
        if mm: ims.add(mm.group(1).replace('.','/'))
    imp[m]=ims
aff=set(seeds)
for m in order:
    if imp[m]&aff: aff.add(m)
res=[m for m in order if m in aff]
open(out,'w').write('\n'.join(res)+'\n'); print(len(res))
