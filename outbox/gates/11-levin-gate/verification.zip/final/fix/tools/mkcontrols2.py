"""mkcontrols2.py <tools-dir> <seals-dir> <collector-log> <worktree> <probe-subdir> <outdir>
r2 controls for the two files newly touched by fix-f1f2 (Randomized/Primitives, Build/EmitIterEmbed).
Own-seal pair: the file's own whole-file request set, generic old-style reads + readers.
Consumer-seal pair: the request set plus the file's own definitions, with the old-style reads the fix
removed (matcher-form use of computesFunInTime_pairSplitAt; obtain / anonymous constructor on SafeRun)
and the new published readers as positives. Same assembly as mkcontrols.py."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, log, wt, sub, outdir = sys.argv[1:7]
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('levin_mkcontrols', Path(__file__).with_name('mkcontrols.py'))
# reuse definitions of mkcontrols.py without running its main loop: exec only the prefix up to `out = Path(outdir)`
src = Path(__file__).with_name('mkcontrols.py').read_text()
prefix = src[:src.index("out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []")]
ns = {'__file__': str(Path(__file__).with_name('mkcontrols.py'))}
sys.argv = [sys.argv[0], tools, sealdir, log, wt, sub, outdir]
exec(compile(prefix, 'mkcontrols-prefix', 'exec'), ns)
assemble, row, cat, FUN, FUNR, PAIR, PAIRR, ANON = (ns[k] for k in ('assemble', 'row', 'cat', 'FUN', 'FUNR', 'PAIR', 'PAIRR', 'ANON'))
SAFE_CTX = "{k : ℕ} {B : Type} {x : List Bool} {H : Turing.MultiTapeTM k Bool B} {avoid : B}"
SAFE = [
 ("ctlSafeObtain", "Turing.SafeRun", True, f"""theorem ctlSafeObtain {SAFE_CTX}
    {{c c' : Turing.Cfg k Bool B x}} {{t : ℕ}} (h : Turing.SafeRun H avoid c t c') :
    H.runFrom c t = c' := by
  obtain ⟨hrun, _⟩ := h
  exact hrun
"""),
 ("ctlSafeCtor", "Turing.SafeRun", True, f"""theorem ctlSafeCtor {SAFE_CTX}
    {{c c' : Turing.Cfg k Bool B x}} {{t : ℕ}} (h₁ : H.runFrom c t = c')
    (h₂ : ∀ t' < t, (H.runFrom c t').state ≠ some avoid) : Turing.SafeRun H avoid c t c' :=
  ⟨h₁, h₂⟩
"""),
 ("ctlSafeReaderRun", "Turing.SafeRun", False, f"""theorem ctlSafeReaderRun {SAFE_CTX}
    {{c c' : Turing.Cfg k Bool B x}} {{t : ℕ}} (h : Turing.SafeRun H avoid c t c') :
    H.runFrom c t = c' := (Turing.safeRun_iff.1 h).1
"""),
 ("ctlSafeReaderIntro", "Turing.SafeRun", False, f"""theorem ctlSafeReaderIntro {SAFE_CTX}
    {{c c' : Turing.Cfg k Bool B x}} {{t : ℕ}} (h₁ : H.runFrom c t = c')
    (h₂ : ∀ t' < t, (H.runFrom c t').state ≠ some avoid) : Turing.SafeRun H avoid c t c' :=
  Turing.safeRun_iff.2 ⟨h₁, h₂⟩
""")]
SPLIT = [
 ("ctlSplitMatcher", "Turing.pairSplitAt", True, """theorem ctlSplitMatcher : ∃ (M : Turing.FinTM Bool) (c : ℕ), M.ComputesFunInTime
    (fun z => match Turing.pairDecode z with
      | some (u, b) => Turing.pairEncode (b.take u.length) (b.drop u.length)
      | none => []) fun n => c * (n + 1) :=
  Turing.FinTM.computesFunInTime_pairSplitAt
"""),
 ("ctlSplitDefeq", "Turing.pairSplitAt", True, """theorem ctlSplitDefeq (z : List Bool) :
    Turing.pairSplitAt z = (match Turing.pairDecode z with
      | some (u, b) => Turing.pairEncode (b.take u.length) (b.drop u.length)
      | none => []) := rfl
"""),
 # scan-layer control: `simp only [def]` uses the generated equation lemma, which a seal does not block;
 # it passes sealed and unsealed and is caught by the explicit-reader scan instead.
 ("ctlSplitSimpUnfold(scan-layer)", "Turing.pairSplitAt", False, """theorem ctlSplitSimpUnfold (u b : List Bool) :
    Turing.pairSplitAt (Turing.pairEncode u b) = Turing.pairEncode (b.take u.length) (b.drop u.length) := by
  simp only [Turing.pairSplitAt, Turing.pairDecode_pairEncode]
"""),
 ("ctlSplitReader", "Turing.pairSplitAt", False, """theorem ctlSplitReader (u b : List Bool) :
    Turing.pairSplitAt (Turing.pairEncode u b) = Turing.pairEncode (b.take u.length) (b.drop u.length) :=
  Turing.pairSplitAt_pairEncode u b
"""),
 ("ctlSplitReaderSome", "Turing.pairSplitAt", False, """theorem ctlSplitReaderSome {z u b : List Bool} (h : Turing.pairDecode z = some (u, b)) :
    Turing.pairSplitAt z = Turing.pairEncode (b.take u.length) (b.drop u.length) :=
  Turing.pairSplitAt_of_pairDecode_eq_some h
"""),
 ("ctlSplitReaderNone", "Turing.pairSplitAt", False, """theorem ctlSplitReaderNone {z : List Bool} (h : Turing.pairDecode z = none) :
    Turing.pairSplitAt z = [] := Turing.pairSplitAt_of_pairDecode_eq_none h
"""),
 ("ctlSplitRestated", "Turing.pairSplitAt", False, """theorem ctlSplitRestated : ∃ (M : Turing.FinTM Bool) (c : ℕ),
    M.ComputesFunInTime Turing.pairSplitAt fun n => c * (n + 1) :=
  Turing.FinTM.computesFunInTime_pairSplitAt
""")]
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
def emit(label, module, rows, bodies, kind):
    for sealed in (True, False):
        lab = label.replace('#', 'S' if sealed else 'U')
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind=kind, sealed=sealed, requested=len(rows) if sealed else 0,
                         controls=expect, expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
for name, special in (('Complexity_Randomized_Primitives', SPLIT), ('Complexity_TuringMachine_Build_EmitIterEmbed', SAFE)):
    rec = json.load(open(f'{sealdir}/Seal_{name}.json')); module = rec['module']; have = {r['spelling'] for r in rec['rows']}
    assert {'Turing.FinTM.ComputesFunInTime', 'Turing.pairEncode'} <= have
    emit('Control#_' + name, module, rec['rows'], [FUN, FUNR, PAIR, PAIRR, ANON], 'own-seal')
    own = [row(r) for r in sorted(cat.values(), key=lambda r: r['name']['display']) if r['home']['display'] == module
           and r['kind'] == 'def' and (r['matcher'] or r['status'] != 'reducible')]
    crow = sorted({r['spelling']: r for r in rec['rows'] + own}.values(), key=lambda r: r['spelling'])
    emit('Consumer#_' + name, module, crow, special, 'consumer-seal-fix-readers')
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
