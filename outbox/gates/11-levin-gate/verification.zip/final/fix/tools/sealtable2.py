"""sealtable2.py <final-dir>: r2 seal table for the four files changed by fix-f1f2."""
import sys, json, re, subprocess, collections
F = sys.argv[1]; FX = F + '/fix'; L = F.rsplit('/', 1)[0]
def norm(m):
    m = re.sub(r'G06-[A-Z-]+ label=.*', '', m); m = re.sub(r'\?m\.\d+|\?u\.\d+|_hyg\.\d+|x✝\d*', '?', m)
    m = re.sub(r'\b\d+\b', 'N', m); return ' '.join(m.split())[:200]
def mapped(rec, log, decls):
    return json.loads(subprocess.run(['python3', '-I', f'{L}/tools/sealmap.py', rec, log, decls], capture_output=True, text=True, check=True).stdout)
spec = {
 'Complexity_Randomized_Primitives': (f'{FX}/base-seals/BaseSeal_Complexity_Randomized_Primitives.json', f'{FX}/base-seal-runs/mods/LevinProbe_BaseSeals_BaseSeal_Complexity_Randomized_Primitives.log', f'{FX}/base-decls-2.json', 'base 5bcf11aa (blob equal at 4a09f399 and PR head)'),
 'Complexity_TuringMachine_Build_EmitIterEmbed': (f'{FX}/base-seals/BaseSeal_Complexity_TuringMachine_Build_EmitIterEmbed.json', f'{FX}/base-seal-runs/mods/LevinProbe_BaseSeals_BaseSeal_Complexity_TuringMachine_Build_EmitIterEmbed.log', f'{FX}/base-decls-2.json', 'base 5bcf11aa (blob equal at 4a09f399 and PR head)'),
 'Complexity_TuringMachine_Build_EmitIterBody': (f'{F}/base-seals/BaseSeal_Complexity_TuringMachine_Build_EmitIterBody.json', f'{F}/base-seal-runs/mods/LevinProbe_BaseSeals_BaseSeal_Complexity_TuringMachine_Build_EmitIterBody.log', f'{F}/comparison/base-decls.json', 'base 5bcf11aa (r1 base control)'),
 'Cryptography_Asymptotic_UniversalPadding_Machine': (None, None, None, 'new file'),
}
table = {}
for name, (brec, blog, bdecls, bnote) in spec.items():
    rec = f'{FX}/seals/Seal_{name}.json'; r = json.load(open(rec))
    log = f'{FX}/probe-runs/mods/LevinProbe_SealsR2_Seal_{name}.log'; text = open(log).read()
    errs = mapped(rec, log, f'{FX}/comparison/touched.json')
    rows = []
    for e in errs:
        if e.get('region', '').startswith('HARNESS'): cls = 'HARNESS'
        elif e.get('declaration') is None and re.match(r'failed to set `\[local irreducible\]`, `[^`]+` is currently `\[irreducible\]`', e['message']): cls = 'SELF_SEAL_REDUNDANT'
        elif e.get('touched'): cls = 'TOUCHED_FAILURE'
        else: cls = 'UNTOUCHED'
        rows.append(dict(e, cls=cls))
    base = collections.Counter()
    if brec:
        base = collections.Counter((e.get('declaration'), norm(e['message'])) for e in mapped(brec, blog, bdecls) if not e.get('region'))
    hk = collections.Counter((e.get('declaration'), norm(e['message'])) for e in rows if e['cls'] == 'UNTOUCHED')
    for e in rows:
        if e['cls'] == 'UNTOUCHED': e['base_control'] = 'SAME_FAILURE_AT_BASE' if base[(e.get('declaration'), norm(e['message']))] >= hk[(e.get('declaration'), norm(e['message']))] else 'NOT_AT_BASE'
    inst = re.search(r'G06-SEAL label=\S+ requested=(\d+) active=(\d+) already_irreducible=(\d+) verified=(\d+)', text)
    eof = re.search(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', text)
    base_only = [dict(declaration=k[0], message=k[1], count=c - hk[k]) for k, c in base.items() if c > hk[k]]
    table[r['source']] = dict(label=r['label'], requested=r['requested'], install=inst.groups() if inst else None, eof=eof.groups() if eof else None,
                              capped='maximum number of errors' in text, counts=dict(collections.Counter(e['cls'] for e in rows)),
                              errors=rows, base=bnote, base_errors=sum(base.values()) if brec else None, base_only_failures=base_only,
                              untouched_declarations=sorted({e['declaration'] for e in rows if e['cls'] == 'UNTOUCHED'}))
json.dump(table, open(f'{FX}/seal-table.json', 'w'), indent=1)
with open(f'{FX}/seals.tsv', 'w') as f:
    f.write('file\trequests\tinstall\teof\tself_seal_redundant\tuntouched\tuntouched_same_at_base\ttouched_failures\tbase_errors\tbase_only\tverdict\n')
    for s, t in table.items():
        c = t['counts']; same = sum(1 for e in t['errors'] if e.get('base_control') == 'SAME_FAILURE_AT_BASE')
        v = 'FINDING' if c.get('TOUCHED_FAILURE') or c.get('HARNESS') or same != c.get('UNTOUCHED', 0) or t['capped'] else ('PASS' if not c.get('UNTOUCHED') else 'PASS-touched;inherited-baseline-recorded')
        f.write(f"{s}\t{t['requested']}\t{t['install']}\t{t['eof']}\t{c.get('SELF_SEAL_REDUNDANT', 0)}\t{c.get('UNTOUCHED', 0)}\t{same}\t{c.get('TOUCHED_FAILURE', 0)}\t{t['base_errors']}\t{len(t['base_only_failures'])}\t{v}\n")
print(open(f'{FX}/seals.tsv').read())
for s, t in table.items():
    for b in t['base_only_failures']: print('BASE-ONLY', s.split('/')[-1], b['declaration'], b['message'][:110])
    print(s.split('/')[-1], 'untouched decls:', [d.split('.')[-1] for d in t['untouched_declarations']])
