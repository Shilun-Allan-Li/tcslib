"""mkcontrols.py <tools-dir> <seals-dir> <collector-log> <worktree> <probe-subdir> <outdir>
Sensitivity controls. For each changed file F (seal record in <seals-dir>):
  * ControlS_<F>: imports F, installs F's own whole-file seal request set with the archived
    harness (build_seals.seal_command via request_payload_adapter), then old-style body readings
    (each one theorem/example, expected to fail exactly once sealed) and published-reader positives.
  * ControlU_<F>: the same bodies without the seal (all must pass).
For each new support module N additionally ConsumerS_/ConsumerU_<N>: the seal adds N's own
definitions (a consumer's view), with an old-style reading and N's public interface as positive."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, log, wt, sub, outdir = sys.argv[1:7]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
cat = {}
for line in open(log, encoding='utf-8'):
    if line.startswith('CAT '):
        r = json.loads(line[4:]); cat[r['name']['display']] = r
def row(r): return dict(spelling=r['name']['display'], home=r['home']['display'], name_components=r['name']['components'],
                        home_components=r['home']['components'], instance=r['instance'], matcher=r['matcher'],
                        abbrev=r['abbrev'], collector_reducibility=r['status'])
FUN = ("ctlFun", "Turing.FinTM.ComputesFunInTime", True, """theorem ctlFun {M : Turing.FinTM Bool} {f : List Bool → List Bool} {T : ℕ → ℕ}
    (h : M.ComputesFunInTime f T) (x : List Bool) : M.ComputesInTime x (f x) (T x.length) := h x
""")
FUNR = ("ctlFunReader", "Turing.FinTM.ComputesFunInTime", False, """theorem ctlFunReader {M : Turing.FinTM Bool} {f : List Bool → List Bool} {T : ℕ → ℕ}
    (h : M.ComputesFunInTime f T) (x : List Bool) : M.ComputesInTime x (f x) (T x.length) :=
  (Turing.FinTM.computesFunInTime_iff M f T).1 h x
""")
PAIR = ("ctlPair", "Turing.pairEncode", True, """theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl
""")
PAIRR = ("ctlPairReader", "Turing.pairEncode", False, """theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b
""")
ANON = ("anonymous example", "Turing.pairEncode", True, """example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl
""")
NU = ("ctlNu", "TCSlib.Cryptography.PadQuad.nu", True, """theorem ctlNu (d m : ℕ) :
    TCSlib.Cryptography.PadQuad.nu d m = Nat.findGreatest (fun n => n ^ d ≤ m) m := rfl
""")
NUR = ("ctlNuReader", "TCSlib.Cryptography.PadQuad.nu", False, """theorem ctlNuReader (d m : ℕ) :
    TCSlib.Cryptography.PadQuad.nu d m = Nat.findGreatest (fun n => n ^ d ≤ m) m :=
  TCSlib.Cryptography.PadQuad.nu_eq d m
""")
PUBLIC = {
 'TCSlib.Complexity.TuringMachine.Build.WordTiming': 'Turing.FinTM.exists_append_computesFunInTime',
 'TCSlib.Complexity.Randomized.UnaryPolynomial': 'Complexity.exists_unaryPoly_succ_computesFunInTime',
 'TCSlib.Complexity.ClassP.BinaryArith.Unary': 'Complexity.BinArith.exists_binaryToUnary',
 'TCSlib.Cryptography.Asymptotic.UniversalPadding.Parameter': 'TCSlib.Cryptography.PadQuad.nu_pow_le',
 'TCSlib.Cryptography.Asymptotic.UniversalPadding.BinaryRoot': 'TCSlib.Cryptography.PadQuad.polyTimeComputable_shifted_root',
 'TCSlib.Cryptography.Asymptotic.UniversalPadding.Machine': 'TCSlib.Cryptography.PadQuad.exists_linearTime_padded'}
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace LevinControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end LevinControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
def emit(label, module, rows, bodies, kind, owner):
    for sealed in (True, False):
        lab = label.replace('#', 'S' if sealed else 'U')
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=owner, kind=kind, sealed=sealed, requested=len(rows) if sealed else 0,
                         controls=expect, expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
for rec_path in sorted(Path(sealdir).glob('Seal_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = []
    if 'Turing.FinTM.ComputesFunInTime' in have: bodies += [FUN, FUNR]
    if 'Turing.pairEncode' in have: bodies += [PAIR, PAIRR, ANON]
    if not bodies:
        # closure has no TCSlib definitions (Parameter): seal its own definitions as a consumer would
        rows = [row(r) for r in sorted(cat.values(), key=lambda r: r['name']['display']) if r['home']['display'] == module
                and r['kind'] == 'def' and (r['matcher'] or r['status'] != 'reducible')]
        bodies = [NU, NUR]
    emit('Control#_' + rec['label'][5:], module, rows, bodies, 'own-seal', module)
    if module in PUBLIC:
        own = [row(r) for r in sorted(cat.values(), key=lambda r: r['name']['display']) if r['home']['display'] == module
               and r['kind'] == 'def' and (r['matcher'] or r['status'] != 'reducible')]
        crow = sorted({r['spelling']: r for r in rec['rows'] + own}.values(), key=lambda r: r['spelling'])
        pub = PUBLIC[module]
        use = ("ctlPublic", pub, False, f"theorem ctlPublic : True := by\n  have _h := @{pub}\n  trivial\n")
        cb = [NU, NUR, use] if module.endswith('Parameter') else [FUN, FUNR, use]
        emit('Consumer#_' + rec['label'][5:], module, crow, cb, 'consumer-seal-public-reader', module)
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
