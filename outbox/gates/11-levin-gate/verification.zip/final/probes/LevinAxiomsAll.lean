import Lean
import TCSlib.Cryptography.Asymptotic.Universal

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def inScope (owner _name : Name) : Bool :=
  [ "TCSlib.Complexity.TuringMachine.Build.WordTiming", "TCSlib.Complexity.Randomized.UnaryPolynomial",
    "TCSlib.Complexity.ClassP.BinaryArith.Unary", "TCSlib.Cryptography.Asymptotic.UniversalPadding.Parameter",
    "TCSlib.Cryptography.Asymptotic.UniversalPadding.BinaryRoot", "TCSlib.Cryptography.Asymptotic.UniversalPadding.Machine",
    "TCSlib.Complexity.TuringMachine.Build.Primitives", "TCSlib.Complexity.TuringMachine.Build.EmitIterBody",
    "TCSlib.Cryptography.Asymptotic.UniversalPadding", "TCSlib.Cryptography.Asymptotic.Universal"].contains owner.toString

def home? (env : Environment) (n : Name) : Option Name := do
  let i ← env.getModuleIdxFor? n
  env.header.moduleNames[i.toNat]?

run_cmd do
  let env ← getEnv
  let mut count := 0
  let mut bad := 0
  let standard : List Name := [`propext, `Classical.choice, `Quot.sound]
  for (name, _) in env.constants.toList do
    let some owner := home? env name | continue
    unless inScope owner name do continue
    let axioms ← Lean.collectAxioms name
    unless axioms.all standard.contains do
      bad := bad + 1
      liftIO <| IO.println s!"NONSTANDARD {name} ({owner}): {axioms}"
    count := count + 1
  liftIO <| IO.println s!"NONSTANDARD-COUNT {bad}"
  liftIO <| IO.println s!"CENSUS-ALL {count} stored declarations of the ten non-facade owners use standard axioms only"

