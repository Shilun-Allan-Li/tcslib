import Lean

/-! Archived LevinCoreCensus.lean (production-checkpoint.zip), unchanged except the final paths:
base = fresh base-replay tree (5bcf11aa sources), head = fresh merged owner tree; module list = the
39 base-replay modules (the 4 changed core files and every closure consumer rebuilt at base). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean

partial def stripMetadata (expr : Expr) : Expr :=
  expr.replace fun nested =>
    if nested.isMData then some (stripMetadata nested.mdataExpr!) else none

def equalTerm (left right : Expr) : Bool :=
  left.equal right || (stripMetadata left).equal (stripMetadata right)

def constantKind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def equalBody (left right : ConstantInfo) : Bool :=
  match left.value? (allowOpaque := true), right.value? (allowOpaque := true) with
  | some a, some b => equalTerm a b
  | none, none => true
  | _, _ => false

def sameMetadata (left right : ConstantInfo) : Bool :=
  left.levelParams == right.levelParams &&
  left.isUnsafe == right.isUnsafe && left.isPartial == right.isPartial &&
  left.hints == right.hints &&
  match left, right with
  | .defnInfo a, .defnInfo b => a.all == b.all
  | .thmInfo a, .thmInfo b => a.all == b.all
  | .opaqueInfo a, .opaqueInfo b => a.all == b.all
  | .inductInfo a, .inductInfo b =>
      a.numParams == b.numParams && a.numIndices == b.numIndices && a.all == b.all &&
      a.ctors == b.ctors && a.numNested == b.numNested && a.isRec == b.isRec &&
      a.isReflexive == b.isReflexive
  | .ctorInfo a, .ctorInfo b => a == b
  | .recInfo a, .recInfo b => a == b
  | _, _ => constantKind left == constantKind right

def readModule (tree : System.FilePath) (modulePath : String) : IO ModuleData := do
  return (← Lean.readModuleData (tree / (modulePath ++ ".olean"))).1

def collect (root : System.FilePath) (modules : Array String) :
    IO (Std.HashMap Name (String × ConstantInfo)) := do
  let mut rows := {}
  for modulePath in modules do
    if ← (root / (modulePath ++ ".olean")).pathExists then
      let data ← readModule root modulePath
      for c in data.constants do
        if rows.contains c.name then
          throw <| IO.userError s!"Duplicate name in module census: {c.name}"
        rows := rows.insert c.name (modulePath, c)
  return rows

def compare (baseRoot headRoot : System.FilePath) (files : System.FilePath) : IO Unit := do
  let mods ← IO.FS.lines files
  let base ← collect baseRoot mods
  let head ← collect headRoot mods
  let mut differences := 0
  for (name, (baseHome, c)) in base.toArray.qsort (fun a b => a.1.quickLt b.1) do
    let some (headHome, d) := head[name]? | do
      IO.println s!"MISSING {baseHome} {constantKind c} {name}"
      continue
    unless equalTerm c.type d.type && sameMetadata c d do
      IO.println s!"TYPE_DIFF {baseHome} {constantKind c} {name}"
    unless baseHome == headHome do
      IO.println s!"MOVE {name} {baseHome} {headHome}"
    unless equalBody c d do
      IO.println s!"BODY_DIFF {baseHome} {constantKind c} {name}"
      differences := differences + 1
  IO.println s!"CENSUS {base.size} old declarations matched, {head.size - base.size} added, {differences} body differences"

#eval compare "/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/levin-base-oleans" "/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/levin-owner-oleans" "/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/levin/final/logs/census-modules.txt"
