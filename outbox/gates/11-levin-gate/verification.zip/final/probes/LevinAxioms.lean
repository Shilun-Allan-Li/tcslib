import Lean
import TCSlib.Cryptography.Asymptotic.Universal

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def inScope (owner name : Name) : Bool :=
    owner.toString == "TCSlib.Complexity.TuringMachine.Build.WordTiming" ||
    owner.toString == "TCSlib.Complexity.Randomized.UnaryPolynomial" ||
    owner.toString == "TCSlib.Complexity.ClassP.BinaryArith.Unary" ||
    owner.toString == "TCSlib.Cryptography.Asymptotic.UniversalPadding.Parameter" ||
    owner.toString == "TCSlib.Cryptography.Asymptotic.UniversalPadding.BinaryRoot" ||
    owner.toString == "TCSlib.Cryptography.Asymptotic.UniversalPadding.Machine" ||
    name.toString == "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes" || name.toString.startsWith "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes." ||
    name.toString == "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes_at" || name.toString.startsWith "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes_at." ||
    name.toString == "Turing.FinTM.exists_pairMapSnd_computesInTime" || name.toString.startsWith "Turing.FinTM.exists_pairMapSnd_computesInTime." ||
    name.toString == "Turing.FinTM.exists_emitIterTM_withFuel" || name.toString.startsWith "Turing.FinTM.exists_emitIterTM_withFuel." ||
    name.toString == "Turing.FinTM.exists_emitIterTM" || name.toString.startsWith "Turing.FinTM.exists_emitIterTM." ||
    name.toString == "TCSlib.Cryptography.PadQuad.exists_linearTime_gStr" || name.toString.startsWith "TCSlib.Cryptography.PadQuad.exists_linearTime_gStr."

def home? (env : Environment) (n : Name) : Option Name := do
  let i ← env.getModuleIdxFor? n
  env.header.moduleNames[i.toNat]?

run_cmd do
  let env ← getEnv
  let mut count := 0
  let standard : List Name := [`propext, `Classical.choice, `Quot.sound]
  for (name, _) in env.constants.toList do
    let some owner := home? env name | continue
    unless inScope owner name do continue
    let axioms ← Lean.collectAxioms name
    unless axioms.all standard.contains do
      throwError "Unexpected axiom set for {name}: {axioms}"
    count := count + 1
    liftIO <| IO.println s!"AXIOMS {name}: {axioms}"
  liftIO <| IO.println s!"CENSUS {count} selected declarations use standard axioms only"

#print axioms TCSlib.Cryptography.PadQuad.exists_linearTime_gStr
#print axioms TCSlib.Cryptography.lemma_64_3
#print axioms TCSlib.Cryptography.theorem_63_1
