import Lean
import TCSlib.Cryptography.Asymptotic.Universal

/-! Retained-reference check, superseding the failed Mac probe `LevinRetainedReferences.lean`.
Every module of the fresh merged tree is loaded. Names are compared through `Name.toString` of the
actual environment constants (no Name is parsed from a string), and numeric components are kept.
1. The 26 generated helper names that the Mac census reported as removed/changed: report whether
   each still exists, and every constant anywhere that references it.
2. Every reference from a constant outside the 13 changed owner modules to a generated
   (internal-detail) constant whose home is one of the 13 owners. -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536
open Lean Elab Command

def oldHelpers : List String := [
  "Turing.FinTM.exists_emitIterTM._proof_1_1",
  "Turing.FinTM.exists_emitIterTM._proof_1_10",
  "Turing.FinTM.exists_emitIterTM._proof_1_11",
  "Turing.FinTM.exists_emitIterTM._proof_1_12",
  "Turing.FinTM.exists_emitIterTM._proof_1_13",
  "Turing.FinTM.exists_emitIterTM._proof_1_14",
  "Turing.FinTM.exists_emitIterTM._proof_1_15",
  "Turing.FinTM.exists_emitIterTM._proof_1_16",
  "Turing.FinTM.exists_emitIterTM._proof_1_17",
  "Turing.FinTM.exists_emitIterTM._proof_1_18",
  "Turing.FinTM.exists_emitIterTM._proof_1_19",
  "Turing.FinTM.exists_emitIterTM._proof_1_2",
  "Turing.FinTM.exists_emitIterTM._proof_1_20",
  "Turing.FinTM.exists_emitIterTM._proof_1_21",
  "Turing.FinTM.exists_emitIterTM._proof_1_22",
  "Turing.FinTM.exists_emitIterTM._proof_1_23",
  "Turing.FinTM.exists_emitIterTM._proof_1_3",
  "Turing.FinTM.exists_emitIterTM._proof_1_4",
  "Turing.FinTM.exists_emitIterTM._proof_1_5",
  "Turing.FinTM.exists_emitIterTM._proof_1_6",
  "Turing.FinTM.exists_emitIterTM._proof_1_7",
  "Turing.FinTM.exists_emitIterTM._proof_1_8",
  "Turing.FinTM.exists_emitIterTM._proof_1_9",
  "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes._proof_1_1",
  "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes._proof_1_2",
  "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes._proof_1_3"]

def owners : List String := [
  "TCSlib.Complexity.ClassP.BinaryArith", "TCSlib.Complexity.ClassP.BinaryArith.Unary",
  "TCSlib.Complexity.Randomized", "TCSlib.Complexity.Randomized.UnaryPolynomial",
  "TCSlib.Complexity.TuringMachine", "TCSlib.Complexity.TuringMachine.Build.EmitIterBody",
  "TCSlib.Complexity.TuringMachine.Build.Primitives", "TCSlib.Complexity.TuringMachine.Build.WordTiming",
  "TCSlib.Cryptography.Asymptotic.Universal", "TCSlib.Cryptography.Asymptotic.UniversalPadding",
  "TCSlib.Cryptography.Asymptotic.UniversalPadding.BinaryRoot",
  "TCSlib.Cryptography.Asymptotic.UniversalPadding.Machine",
  "TCSlib.Cryptography.Asymptotic.UniversalPadding.Parameter"]

def generated (n : Name) : Bool :=
  n.isInternalDetail || (n.components.any fun c => match c with
    | .str _ s => s.startsWith "_proof_" || s.startsWith "_simp_" || s.startsWith "match_" ||
        s.startsWith "proof_" || s.startsWith "_auxLemma" || s.startsWith "eq_" || s == "eq_def" ||
        s.startsWith "_sunfold" || s.startsWith "_unfold" || s.startsWith "_cstage"
    | _ => false)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let home (n : Name) : String := match env.getModuleIdxFor? n with
    | some i => names[i.toNat]!.toString | none => "<current>"
  let oldSet : Std.HashSet String := oldHelpers.foldl (·.insert ·) {}
  let ownerSet : Std.HashSet String := owners.foldl (·.insert ·) {}
  let mut present : Nat := 0
  let mut constants : Nat := 0
  let mut outside : Nat := 0
  let mut oldRefs : Nat := 0
  let mut crossRefs : Nat := 0
  let mut ownerGenerated : Nat := 0
  for (n, _) in env.constants.toList do
    if oldSet.contains n.toString then
      present := present + 1
      IO.println s!"OLD-HELPER-PRESENT {n} home={home n}"
    if ownerSet.contains (home n) && generated n then ownerGenerated := ownerGenerated + 1
  for (n, c) in env.constants.toList do
    let h := home n
    unless h.startsWith "TCSlib" || h.startsWith "audits" do continue
    constants := constants + 1
    let isOutside := !ownerSet.contains h
    if isOutside then outside := outside + 1
    for d in c.getUsedConstantsAsSet do
      if oldSet.contains d.toString then
        oldRefs := oldRefs + 1
        IO.println s!"OLD-HELPER-REF {n} ({h}) -> {d}"
      if isOutside && ownerSet.contains (home d) && generated d then
        crossRefs := crossRefs + 1
        IO.println s!"CROSS-HELPER-REF {n} ({h}) -> {d} ({home d})"
  IO.println s!"HELPERS old={oldHelpers.length} present={present} old_refs={oldRefs} owner_generated={ownerGenerated}"
  IO.println s!"RETAINED modules={names.size} library_constants={constants} outside_owner_constants={outside} cross_generated_refs={crossRefs}"
