"""mkseg.py <tools-dir> <seal-record.json> <worktree> <rev> <probe-subdir> <outdir> <label> <start-line> <namespace>
Segment seal for a file whose whole-file seal stops at Lean's 100-error cap (maxErrors cannot be
raised in-file and the checker passes no -D options). Same request rows and archived harness; the
installation command is inserted before original line <start-line>, wrapped as `end <namespace>` /
install / `namespace <namespace>` so that it runs at the file's base scope (the reviewed instance
unfolding mask requires scope depth 1, and local attributes then persist to EOF); the verifier is the
ordinary EOF verifier. Valid only where the namespace holds no `open`/`variable`/`attribute`/option
commands of its own (checked). Only insertions; original bytes are preserved and checked."""
import sys, json, importlib.util, subprocess, hashlib
from pathlib import Path
tools, recp, wt, rev, sub, outdir, label, start, ns = sys.argv[1:10]
start = int(start)
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
rec = json.load(open(recp))
raw = subprocess.run(['git', '-C', wt, 'show', f"{rev}:{rec['source']}"], capture_output=True, check=True).stdout
assert hashlib.sha256(raw).hexdigest() == rec['source_sha256']
info = bs.header(raw)
lines = raw.split(b'\n'); off = lambda L: sum(len(x) + 1 for x in lines[:L - 1])
import re
code = bs.blank_comments_strings(raw.decode()).split('\n')
open_at = [i + 1 for i, l in enumerate(code) if l.startswith('namespace ' + ns)]
assert len(open_at) == 1 and open_at[0] < start, open_at
assert not [l for l in code[open_at[0]:] if re.match(r'^\s*(open|variable|attribute|set_option|section|namespace|universe|local|scoped|include|omit)\b', l)], 'scope commands inside namespace'
assert [l for l in code if l.startswith('end ' + ns)] == ['end ' + ns]
ins = []
if 'Lean' not in info['imports']: ins.append((info['first_import_offset'], 'import_Lean', b'import Lean\n'))
ins.append((off(start), 'seal_segment_install', b'end ' + ns.encode() + b'\n\n' + bs.seal_command(label, rec['rows'], end=False) + b'namespace ' + ns.encode() + b'\n\n'))
ins.append((len(raw), 'seal_eof_verifier', (b'' if raw.endswith(b'\n') else b'\n') + bs.seal_command(label, rec['rows'], end=True)))
ins.sort(key=lambda t: t[0])
out, cur, records = bytearray(), 0, []
for at, kind, add in ins:
    out += raw[cur:at]; p = len(out); out += add
    records.append(dict(kind=kind, original_byte_offset=at, probe_byte_offset=p, byte_count=len(add),
                        probe_start_line=bytes(out[:p]).count(b'\n') + 1, probe_end_line=bytes(out).count(b'\n')))
    cur = at
out += raw[cur:]; probe = bytes(out)
rcv = probe
for r in reversed(records): rcv = rcv[:r['probe_byte_offset']] + rcv[r['probe_byte_offset'] + r['byte_count']:]
assert rcv == raw
starts = [0] + [i + 1 for i, c in enumerate(raw) if c == 10 and i + 1 < len(raw)]
lmap = [dict(source_line=L, probe_line=L + sum(a.count(b'\n') for at, _, a in ins if at <= o)) for L, o in enumerate(starts, 1)]
pp = Path(wt) / sub / (label + '.lean'); pp.parent.mkdir(parents=True, exist_ok=True); pp.write_bytes(probe)
Path(outdir).mkdir(parents=True, exist_ok=True); (Path(outdir) / (label + '.lean.txt')).write_bytes(probe)
new = dict(rec, label=label, probe_sha256=hashlib.sha256(probe).hexdigest(), probe_module=f'{sub}/{label}',
           insertions=records, source_to_probe_lines=lmap, segment=dict(start_line=start, namespace=ns))
(Path(outdir) / (label + '.json')).write_text(json.dumps(new, indent=1))
print(label, 'segment', start, ns, 'requests', len(rec['rows']))
