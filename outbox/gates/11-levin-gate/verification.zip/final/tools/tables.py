"""tables.py <final-dir>: TSV tables from the JSON evidence."""
import sys, json, glob, collections
F = sys.argv[1]
def w(name, header, rows):
    with open(f'{F}/tables/{name}', 'w') as f:
        f.write('\t'.join(header) + '\n')
        for r in rows: f.write('\t'.join(str(x) for x in r) + '\n')
import os; os.makedirs(f'{F}/tables', exist_ok=True)
# bootstrap
rows = [json.loads(l) for l in open(f'{F}/bootstrap/results.jsonl')]
mods = [r for r in rows if 'module' in r]
w('bootstrap.tsv', ['module', 'rc', 'errors', 'sorry_warnings', 'warnings', 'seconds', 'maxrss_kb', 'start', 'end', 'source_sha256', 'object_sha256'],
  [[r['module'], r['rc'], r['errors'], r['sorry'], r['warnings'], r['seconds'], r['maxrss_kb'], r['start'], r['end'], r['source_sha256'], r['object_sha256']] for r in mods])
# seal table
t = json.load(open(f'{F}/seal-table.json'))
w('seals.tsv', ['file', 'requests', 'segments', 'self_seal_redundant', 'untouched_failures', 'untouched_declarations', 'touched_failures', 'untouched_same_at_base', 'untouched_not_at_base', 'base_errors', 'base_only_failures', 'verdict'],
  [[f, x['requested'], x['segments'], x['counts'].get('SELF_SEAL_REDUNDANT', 0), x['counts'].get('UNTOUCHED', 0), len(x['untouched_declarations']),
    x['counts'].get('TOUCHED_FAILURE', 0), sum(1 for e in x['errors'] if e.get('base_control') == 'SAME_FAILURE_AT_BASE' and e['cls'] == 'UNTOUCHED'),
    sum(1 for e in x['errors'] if e.get('base_control') == 'NOT_AT_BASE'), x['base_errors'], len(x['base_only_failures']),
    'PASS' if not x['counts'].get('UNTOUCHED') and not x['counts'].get('TOUCHED_FAILURE') else ('FINDING' if x['counts'].get('TOUCHED_FAILURE') else 'PASS-touched;inherited-baseline-recorded')] for f, x in t.items()])
w('seal-failures.tsv', ['file', 'source_line', 'declaration', 'status', 'class', 'base_control', 'message'],
  [[f, e.get('source_line'), e.get('declaration'), e.get('status'), e['cls'], e.get('base_control', ''), e['message'][:300].replace('\t', ' ')] for f, x in t.items() for e in x['errors']])
c = json.load(open(f'{F}/controls/controls-result.json'))
w('controls.tsv', ['probe', 'owner', 'kind', 'sealed', 'rc', 'requests', 'control', 'target', 'negative', 'errors', 'expected', 'ok'],
  [[p['label'], p['owner'], p['kind'], p['sealed'], p['rc'], p['requested'], k['control'], k['target'], k['negative'], k['errors'], k['expected'], k['ok']] for p in c['probes'] for k in p['controls']])
s = json.load(open(f'{F}/scan/explicit-classification.json'))
w('explicit-items.tsv', ['file', 'line', 'tactic', 'item', 'declaration', 'declaration_status', 'touched', 'classification', 'subkind', 'resolved', 'resolved_home'],
  [[o['file'], o['line'], o['tactic'], o['item'].replace('\t', ' '), o['declaration'], o['declaration_status'], o['touched'], o['classification'], o['subkind'], o['resolved'], o['resolved_home']] for o in s['items']])
print('tables written')
