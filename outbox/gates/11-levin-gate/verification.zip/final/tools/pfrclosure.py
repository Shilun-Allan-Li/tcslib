import sys,os,re
pk='/home/user/tcslib/.lake/packages'
srcroots={'PFR':pk+'/PFR','LeanAPAP':pk+'/LeanAPAP'}
start=sys.argv[1:]
seen=[];order=[];ext=set()
def path(m):
    top=m.split('.')[0]
    if top in srcroots: return os.path.join(srcroots[top],*m.split('.'))+'.lean'
    return None
def visit(m):
    if m in seen: return
    seen.append(m)
    p=path(m)
    if p is None: ext.add(m); return
    for line in open(p):
        mm=re.match(r'^import\s+(\S+)',line)
        if mm: visit(mm.group(1))
    order.append(m)
for s in start: visit(s)
print('\n'.join(order))
sys.stderr.write('external:\n'+'\n'.join(sorted(ext))+'\n')
