"""attrib.py <tools-dir> <record.json> <worktree> <probe-subdir> <outdir> <label> <name>...
Attribution probe: the same whole-file seal minus the named requests. If a touched failure disappears,
the removed definitions are the ones that declaration reads."""
import sys, json, importlib.util, subprocess
from pathlib import Path
tools, recp, wt, sub, outdir, label = sys.argv[1:7]; drop = set(sys.argv[7:])
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
rec = json.load(open(recp)); rows = [r for r in rec['rows'] if r['spelling'] not in drop]
assert len(rec['rows']) - len(rows) == len(drop), 'unknown name'
raw = subprocess.run(['git', '-C', wt, 'show', f"HEAD:{rec['source']}"], capture_output=True, check=True).stdout
probe, ins, lmap = bs.instrument(raw, bs.header(raw), label, rows)
(Path(wt) / sub).mkdir(parents=True, exist_ok=True); (Path(wt) / sub / (label + '.lean')).write_bytes(probe)
Path(outdir).mkdir(parents=True, exist_ok=True); (Path(outdir) / (label + '.lean.txt')).write_bytes(probe)
(Path(outdir) / (label + '.json')).write_text(json.dumps(dict(rec, label=label, rows=rows, requested=len(rows), dropped=sorted(drop), insertions=ins, source_to_probe_lines=lmap), indent=1))
print(label, len(rows))
