"""sealtable.py <final-dir> : per-file seal table. Combines whole-file and segment seals, maps every
error to its declaration, classifies (SELF_SEAL_REDUNDANT / HARNESS / touched / untouched), and
compares untouched failures with the base control (same harness, base source, base replay tree)."""
import sys, json, re, glob, subprocess, collections
F = sys.argv[1]; L = F.rsplit('/', 1)[0]
touched = json.load(open(f'{F}/comparison/touched.json'))['files']
based = json.load(open(f'{F}/comparison/base-decls.json'))['files']
def norm(m):
    m = re.sub(r'G06-[A-Z-]+ label=.*', '', m); m = re.sub(r'\?m\.\d+|\?u\.\d+|_hyg\.\d+|x✝\d*', '?', m)
    m = re.sub(r'\b\d+\b', 'N', m); return ' '.join(m.split())[:200]
def mapped(recp, logp, decls):
    out = subprocess.run(['python3', '-I', f'{L}/tools/sealmap.py', recp, logp, decls], capture_output=True, text=True, check=True).stdout
    return json.loads(out)
def collect(kind, prefix_whole, prefix_seg, sealdir, rundir, sub, declsp, declfiles):
    res = {}
    for recp in sorted(glob.glob(f'{sealdir}/{prefix_whole}_*.json')):
        rec = json.load(open(recp)); lab = rec['label']; src = rec['source']
        segs = sorted(glob.glob(f'{sealdir}/{prefix_seg}*_' + lab.split('_', 1)[1] + '.json'))
        parts = [(recp, 1)] + [(s, json.load(open(s))['segment']['start_line']) for s in segs]
        bounds = [p[1] for p in parts] + [10**9]
        errs, cap, harness = [], False, []
        for i, (p, st) in enumerate(parts):
            r = json.load(open(p)); logp = f"{rundir}/mods/{sub.replace('/', '_')}_{r['label']}.log"
            log = open(logp, encoding='utf-8', errors='replace').read()
            capped = 'maximum number of errors' in log
            for e in mapped(p, logp, declsp):
                if 'maximum number of errors' in e['message']: continue
                if e.get('region', '').startswith('HARNESS'): harness.append(e); continue
                sl = e['source_line']
                if bounds[i] <= sl < bounds[i + 1] or (i == len(parts) - 1 and sl >= bounds[i]):
                    errs.append(e)
            if i == len(parts) - 1: cap = capped
            ok_install = re.search(r'G06-SEAL label=' + re.escape(r['label']) + r' requested=(\d+) active=(\d+) already_irreducible=(\d+) verified=(\d+)', log)
            ok_end = re.search(r'G06-SEAL-END label=' + re.escape(r['label']) + r' requested=(\d+) verified=(\d+)', log)
            mask = len(re.findall(r'G06-MASK label=' + re.escape(r['label']), log))
            harness.append(dict(probe=r['label'], install=ok_install.groups() if ok_install else None,
                                eof=ok_end.groups() if ok_end else None, mask_records=mask, capped=capped))
        res[src] = dict(errors=errs, harness=harness, final_capped=cap, segments=len(parts), requested=rec['requested'], label=lab)
    return res
head = collect('head', 'Seal', 'SealSeg', f'{F}/seals', f'{F}/seal-runs', 'LevinProbe/Seals', f'{F}/comparison/touched.json', touched)
base = collect('base', 'BaseSeal', 'BaseSealSeg', f'{F}/base-seals', f'{F}/base-seal-runs', 'LevinProbe/BaseSeals', f'{F}/comparison/base-decls.json', based)
table = {}
for src, h in sorted(head.items()):
    rows = []
    rec = json.load(open(f"{F}/seals/{h['label']}.json")); reqset = {r['spelling'] for r in rec['rows']}
    for e in h['errors']:
        msg = e['message']
        m = re.match(r'failed to set `\[local irreducible\]`, `([^`]+)` is currently `\[irreducible\]`', msg)
        if e.get('declaration') is None and m:
            cls = 'SELF_SEAL_REDUNDANT'   # the file's own `attribute [local irreducible]` repeats a harness seal
        elif e.get('touched'):
            cls = 'TOUCHED_FAILURE'
        else:
            cls = 'UNTOUCHED'
        rows.append(dict(e, cls=cls, key=(e.get('declaration'), norm(msg))))
    b = base.get(src)
    bkeys = collections.Counter((e.get('declaration'), norm(e['message'])) for e in b['errors']) if b else collections.Counter()
    hkeys = collections.Counter(r['key'] for r in rows if r['cls'] in ('UNTOUCHED', 'TOUCHED_FAILURE'))
    for r in rows:
        if r['cls'] == 'UNTOUCHED':
            r['base_control'] = 'SAME_FAILURE_AT_BASE' if bkeys[r['key']] >= hkeys[r['key']] else 'NOT_AT_BASE'
        elif r['cls'] == 'TOUCHED_FAILURE':
            r['base_control'] = 'SAME_FAILURE_AT_BASE' if bkeys[r['key']] else 'NO_BASE_EQUIVALENT'
    only_base = [dict(declaration=k[0], message=k[1], count=c - hkeys[k]) for k, c in bkeys.items() if c > hkeys[k]]
    table[src] = dict(label=h['label'], requested=h['requested'], segments=h['segments'], final_capped=h['final_capped'],
                      harness=h['harness'], counts=dict(collections.Counter(r['cls'] for r in rows)),
                      untouched_declarations=sorted({r['declaration'] for r in rows if r['cls'] == 'UNTOUCHED'}),
                      errors=[{k: v for k, v in r.items() if k != 'key'} for r in rows],
                      base_label=b['label'] if b else None, base_segments=b['segments'] if b else None,
                      base_final_capped=b['final_capped'] if b else None, base_errors=len(b['errors']) if b else None,
                      base_only_failures=only_base)
json.dump(table, open(f'{F}/seal-table.json', 'w'), indent=1)
for src, t in table.items():
    nb = sum(1 for e in t['errors'] if e.get('base_control') == 'NOT_AT_BASE')
    print(f"{src}\treq={t['requested']}\tseg={t['segments']}\tcounts={t['counts']}\tuntouched_decls={len(t['untouched_declarations'])}\tnot_at_base={nb}\tbase_errors={t['base_errors']}\tbase_only={len(t['base_only_failures'])}\tcapped={t['final_capped']}")
