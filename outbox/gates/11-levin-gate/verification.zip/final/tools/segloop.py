"""segloop.py <levin-dir> <record.json> <worktree> <rev> <tree> <decls.json> <probe-subdir> <outdir> <rundir> <prefix> <first-start> <namespace>
Chains segment seals (mkseg.py) until a segment finishes without reaching Lean's 100-error cap.
The next segment starts at the first line of the declaration containing the capped position."""
import sys, json, subprocess, re, os
L, recp, wt, rev, tree, declsp, sub, outdir, rundir, prefix, start, verify = sys.argv[1:13]
start = int(start); ns = verify
rec = json.load(open(recp))
decls = json.load(open(declsp))['files'][rec['source']]['declarations']
k = 2
while True:
    label = f'{prefix}{k}_' + rec['label'].split('_', 1)[1]
    subprocess.run(['python3', '-I', f'{L}/tools/mkseg.py', f'{L}/x-verification/tools', recp, wt, rev, sub, outdir, label, str(start), ns], check=True)
    q = f'{rundir}/queue-{label}.txt'; open(q, 'w').write(f'{sub}/{label}\n')
    subprocess.run(['python3', '-I', f'{L}/tools/runner.py', wt, q, tree, rundir], env=dict(os.environ, NOSTOP='1'))
    log = open(f"{rundir}/mods/{sub.replace('/', '_')}_{label}.log", encoding='utf-8', errors='replace').read()
    m = re.search(r':(\d+):\d+: error: maximum number of errors', log)
    if not m: print('segment', label, 'complete (no cap)'); break
    seg = json.load(open(f'{outdir}/{label}.json'))
    pl = seg['source_to_probe_lines']; pline = int(m.group(1))
    src = max(x['source_line'] for x in pl if x['probe_line'] <= pline)
    d = [x for x in decls if x['start'] <= src <= x['end']]
    nxt = d[0]['start'] if d else src
    print('segment', label, 'capped at source line', src, '-> next start', nxt)
    assert nxt > start, 'no progress'
    start = nxt; k += 1
