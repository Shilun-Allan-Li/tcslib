"""sealmap.py <seal-record.json> <probe-log> <touched.json-or-'-'> [base-touched]
Maps each error diagnostic of a seal probe log back to its source line and declaration."""
import sys, json, re, bisect
rec = json.load(open(sys.argv[1])); log = open(sys.argv[2], encoding='utf-8', errors='replace').read()
touched = json.load(open(sys.argv[3]))['files'] if sys.argv[3] != '-' else None
pl = rec['source_to_probe_lines']; probe_lines = [x['probe_line'] for x in pl]
harness = [(i['probe_start_line'], i['probe_end_line'], i['kind']) for i in rec['insertions']]
decls = touched[rec['source']]['declarations'] if touched and rec['source'] in touched else None
out = []
for m in re.finditer(r'^(\S+\.lean):(\d+):(\d+): error: (.*(?:\n(?!\S+\.lean:\d+:\d+:).*)*)', log, re.M):
    line = int(m.group(2)); msg = m.group(4)
    h = [k for a, b, k in harness if a <= line <= b]
    if h:
        out.append(dict(probe_line=line, region='HARNESS:' + h[0], message=msg[:400])); continue
    k = bisect.bisect_right(probe_lines, line) - 1
    src = pl[k]['source_line'] + (line - pl[k]['probe_line'])
    d = [x for x in decls if x['start'] <= src <= x['end']] if decls else []
    out.append(dict(probe_line=line, source_line=src, declaration=d[0]['name'] if d else None,
                    status=d[0]['status'] if d else None, touched=d[0]['touched'] if d else None,
                    message=' '.join(msg.split())[:300]))
json.dump(out, sys.stdout, indent=1)
