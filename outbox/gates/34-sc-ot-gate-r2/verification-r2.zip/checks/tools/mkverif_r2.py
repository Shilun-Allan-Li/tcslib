"""mkverif_r2.py <repo> <rec-rev> <34|36> <checks-dir> <tools-dir> <out.zip>: verification-r2.zip for Gate 34 or 36
round 2. The Gate 29 round-2 method (g3637/tools/mkverif29r2.py): byte-identical originals of the records the outbox
does not already carry as files (git objects at records commit REC, each checked equal to the working tree), plus
checks/, the pack's re-checks generated from git objects alone, with their scripts. Writes PROVENANCE.txt and
SHA256SUMS."""
import hashlib, os, subprocess, sys, zipfile

repo, REC, gate, chk, tools, out = sys.argv[1:7]
B = 'briefs/pass-shelat-ch5-8'
CFG = {
    '34': dict(pr=318, name='sc-ot', head='b0bad23ae611983e3323460bb8c564da90ad6e8c',
               srcs=['PassShelatChapter5-8Plan.md', f'{B}/duplication-ledger.md', f'{B}/fills/sc-ot/final-r1/review.md'],
               desc=[('PassShelatChapter5-8Plan.md', 'the decision log, with the rows of 2026-11-15 and 2026-11-16 (Gate 34\n'
                      '    HOLD and the ruling "fix 01, ledger 02"; #316 and #317 merged; LE-gate34 and the rebase, pushed\n'
                      '    with Seyoon\'s approval)'),
                     ('duplication-ledger.md', 'DL-48 (the sc-ot overlaps, with the G34-02 entry and its cleanup) and\n'
                      '    DL-47 (the pre-existing headD/getD copies)'),
                     ('fills/sc-ot/final-r1/review.md', 'the round-1 maintainer review (as it now stands)')],
               checks='mergetrees.txt, downstream.txt, srcequality.txt and namecheck.txt (the head against the tip\n'
                      '  and every other open PR), rebase.txt (the range-diff of the rebase, the signatures), lecheck.txt\n'
                      '  (LE-gate34, the headers since round 1, headD_drop), basemove.txt (the base move since round 1),\n'
                      '  dl48.txt (the G34-02 disposition), dupscan.txt (the lines changed since round 1, reading-lemma lines,\n'
                      '  a statement scan against the tip delta and the open PRs), the decls2 comparisons'),
    '36': dict(pr=323, name='sc-garble', head='8c3f3e3fe2912784f680c10f8c478d2eeeeb7f6a',
               srcs=['PassShelatChapter5-8Plan.md', f'{B}/duplication-ledger.md', f'{B}/fills/sc-garble/final-r1/review.md',
                     f'{B}/gates/37-sc-compose/integration/PROVENANCE.txt'],
               desc=[('PassShelatChapter5-8Plan.md', 'the decision log, with the rows of 2026-11-16 (#313 merged; Gate 36\n'
                      '    HOLD, LE-gate36 planned; LE-gate36 applied as signed 8c3f3e3f and fast-forward pushed)'),
                     ('duplication-ledger.md', 'DL-46 and DL-47 (with SG-F04), the dispositions round 1 checked G36-01\n'
                      '    against'),
                     ('fills/sc-garble/final-r1/review.md', 'the round-1 maintainer review (as it now stands)'),
                     ('gates/37-sc-compose/integration/PROVENANCE.txt', 'the combined build tip + #313 + #323 + #324\n'
                      '    (int-313-323-324, at cd9a4843), the reference LE-gate36\'s build compares against')],
               checks='mergetrees.txt, downstream.txt, srcequality.txt and namecheck.txt (the head against the tip\n'
                      '  and every other open PR), replica.txt (the scratch replica of landing-r1/ against the pushed head),\n'
                      '  rebase.txt (the series and signatures), lecheck.txt (LE-gate36, the headers since round 1, the\n'
                      '  import and closures, length_le_length_encodeList), dupscan.txt (the lines changed since round 1,\n'
                      '  reading-lemma lines, a statement scan against the tip delta and the open PRs), the decls2 comparisons'),
}[gate]
TOOLS = ['packchk_r2.py', 'gitlib.py', 'decls2rev.py', 'mksources.py', 'mkverif_r2.py']


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


sha = lambda b: hashlib.sha256(b).hexdigest()
members = []
for src in CFG['srcs']:
    b = git('show', f'{REC}:{src}')
    assert open(f'{repo}/{src}', 'rb').read() == b, f'working tree differs from {REC[:8]} for {src}'
    members.append((f'records/{src}', b, f'records {REC[:8]}:{src}'))
for c in sorted(os.listdir(chk)):
    members.append((f'checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
for t in TOOLS:
    members.append((f'checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
prov = f"""Gate {gate} round 2 ({CFG['name']}, draft PR #{CFG['pr']}, Lean head {CFG['head']}) verification-r2.zip

The round-2 records the pack cites that the outbox does not already carry as files, and the pack's re-checks.
- records/: byte-identical originals from records commit {REC} (each also equal to the working tree):
""" + ''.join(f'  - {p}: {d};\n' for p, d in CFG['desc']) + f"""- checks/: generated from git objects alone (nothing was built or run): {CFG['checks']}, and
  tools/ (packchk_r2.py with gitlib.py; decls2rev.py = maintainer/tools/decls2.py's parser on two revisions;
  mksources.py, which wrote sources-r2.zip, pr.diff-r2.txt and source-head-r2.json; this script).
SHA256SUMS lists every entry except itself.

Sources:
""" + ''.join(f'  {p}  <-  {s}\n' for p, _, s in members)
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
members.append(('SHA256SUMS', sums.encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as z:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=(2026, 11, 16, 0, 0, 0))
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
with zipfile.ZipFile(out) as z:
    listed = z.namelist()
    inner = {l.split('  ', 1)[1] for l in z.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == inner | {'SHA256SUMS'} and len(listed) == len(inner) + 1
    for l in z.read('SHA256SUMS').decode().splitlines():
        h, p = l.split('  ', 1)
        assert sha(z.read(p)) == h, p
print(f'OK {len(listed)} entries; sha256 {sha(open(out, "rb").read())}')
