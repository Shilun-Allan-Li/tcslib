"""gitlib.py: shared git-object helpers for the Gate 29 r2 / 36 / 37 pack re-checks (no Lean). Read with git only:
`git cat-file --batch` for blobs, `git merge-tree --write-tree` for trial merges. Imported by packchk.py."""
import re, subprocess


class Repo:
    def __init__(self, path):
        self.path = path
        self._cat = None
        self._cache = {}

    def git(self, *a, check=True):
        return subprocess.run(['git', '-C', self.path, *a], check=check, capture_output=True, text=True)

    def gitb(self, *a):
        return subprocess.run(['git', '-C', self.path, *a], check=True, capture_output=True).stdout

    def rp(self, r):
        return self.git('rev-parse', r).stdout.strip()

    def blob(self, rev, path):
        """bytes of rev:path, or None if absent (batch reader)."""
        key = (rev, path)
        if key in self._cache:
            return self._cache[key]
        if self._cat is None:
            self._cat = subprocess.Popen(['git', '-C', self.path, 'cat-file', '--batch'], stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE)
        self._cat.stdin.write(f'{rev}:{path}\n'.encode()); self._cat.stdin.flush()
        head = self._cat.stdout.readline().decode()
        if head.endswith('missing\n') or ' ' not in head:
            self._cache[key] = None
            return None
        size = int(head.split()[2])
        data = self._cat.stdout.read(size); self._cat.stdout.read(1)
        if len(self._cache) < 20000:
            self._cache[key] = data
        return data

    def show(self, rev, path):
        b = self.blob(rev, path)
        return '' if b is None else b.decode('utf-8')

    def lean_changed(self, a, b):
        return [p for p in self.git('diff', '--name-only', '--no-renames', a, b).stdout.split() if p.endswith('.lean')]

    def anc(self, a, b):
        return self.git('merge-base', '--is-ancestor', a, b, check=False).returncode == 0

    def mergetree(self, a, b):
        r = self.git('merge-tree', '--write-tree', '--name-only', a, b, check=False)
        return r.stdout.split('\n')[0], r.returncode, r.stdout

    def graph(self, rev):
        g = {}
        for p in self.git('ls-tree', '-r', '--name-only', rev).stdout.split():
            if p.endswith('.lean') and p.startswith(('TCSlib', 'audits')):
                g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', self.show(rev, p))
                        if m.startswith(('TCSlib', 'audits'))]
        return g


def closure(g, roots):
    seen, st = set(), list(roots)
    while st:
        x = st.pop()
        if x in seen or x not in g:
            continue
        seen.add(x); st.extend(g[x])
    return seen


def downstream(g, mods):
    """modules whose import closure (itself included) meets mods."""
    rev = {}
    for p, imps in g.items():
        for q in imps:
            rev.setdefault(q, []).append(p)
    seen, st = set(), [m for m in mods if m in g]
    while st:
        x = st.pop()
        if x in seen:
            continue
        seen.add(x); st.extend(rev.get(x, []))
    return seen


KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)')
NM = re.compile(r'(?m)^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                r'(?:theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)')


def decls(text):
    """name -> (kind, line, header, docstring, private): the g34 pack3435.py parser (header = keyword line to the
    top-level := for theorems and lemmas, the whole block up to the next blank line for definitions), plus the
    `open/include/omit … in` prefix lines directly above, which count as part of the header."""
    Ls = text.split('\n'); res = {}
    for i, l in enumerate(Ls):
        m = KW.match(l)
        if not m:
            continue
        kind, name = m.groups(); j = i
        while j < len(Ls) and Ls[j].strip() != '':
            j += 1
        block = '\n'.join(Ls[i:j])
        if kind in ('theorem', 'lemma'):
            d, cut = 0, None
            for k, ch in enumerate(block):
                if ch in '([{⟨': d += 1
                elif ch in ')]}⟩': d -= 1
                elif d == 0 and block.startswith(':=', k): cut = k; break
            block = block[:cut] if cut is not None else block
        k = i - 1; pre = []
        while k >= 0 and re.match(r'^(open|include|omit)\b.*\bin\s*$', Ls[k]):
            pre.insert(0, Ls[k]); k -= 1
        doc = ''
        if k >= 0 and Ls[k].rstrip().endswith('-/'):
            s = k
            while s >= 0 and '/--' not in Ls[s]:
                s -= 1
            doc = '\n'.join(Ls[s:k + 1])
        key, c = name, 1
        while key in res:
            c += 1; key = f'{name}#{c}'
        res[key] = (kind, i + 1, '\n'.join(pre + [block]), doc, 'private' in l.split(name)[0])
    return res


ws = lambda t: re.sub(r'\s+', ' ', t).strip()
blank_docs = lambda t: re.sub(r'/-[-!].*?-/', '', t, flags=re.S)
docs = lambda t: re.findall(r'/--.*?-/', t, flags=re.S)
