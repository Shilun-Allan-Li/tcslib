"""packchk_r2.py <repo> <34|36> <out-dir>: round-2 pack re-checks from git objects only (no Lean) for Gate 34 (#318,
sc-ot) and Gate 36 (#323, sc-garble). The Gate 29 round-2 method (g3637/tools/packchk.py), for these units: every head
is trial-merged with the tip and with every other open PR (#318 or #323, #319, #324, #326, #327).
Writes mergetrees.txt, downstream.txt, namecheck.txt, srcequality.txt, rebase.txt, lecheck.txt, dupscan.txt and, for
Gate 34, basemove.txt and dl48.txt; for Gate 36, replica.txt."""
import hashlib, json, os, re, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls, ws, NM

repo_path, gate, out = sys.argv[1], sys.argv[2], sys.argv[3]
R = Repo(repo_path); rp = R.rp
B = 'briefs/pass-shelat-ch5-8'
TIPREF = 'origin/cryptography/pass-shelat-ch2-4'
TIP = rp(TIPREF)
OPEN = {'#318': rp('origin/land/pass-shelat-sc-ot'), '#319': rp('origin/land/pass-shelat-canonizer'),
        '#323': rp('origin/land/pass-shelat-sc-garble'), '#324': rp('origin/land/pass-shelat-sc-compose'),
        '#326': rp('origin/land/pass-shelat-derand'), '#327': rp('origin/land/pass-shelat-seq-zk')}
assert OPEN['#319'] == rp('47daa90792e96b93510384adbab9f6e492ccef3a'), OPEN['#319']
assert OPEN['#324'] == rp('a6eaebd78c48e7fdfd06263edb84b70bc00ec593'), OPEN['#324']
SC = 'TCSlib/Cryptography/SecureComputation'
OT = f'{SC}/ObliviousTransfer'
CFG = {
    '34': dict(pr='#318', name='sc-ot', head=rp('b0bad23ae611983e3323460bb8c564da90ad6e8c'),
               r1head=rp('f62a25b3eda099c9cf9371900664752e7b89007d'), r1base=rp('a334ec2e1d87dbde7eac40812286ba60e85c9078'),
               r1rec=rp('5d719839503c1f29f65f5ffa200410349a782276'), rebased=rp('e0ecdf223490ad9c99fc9151ca5bef5821e6cf29'),
               unit=[f'{OT}.lean'] + [f'{OT}/{x}.lean' for x in
                                      ('Shape', 'Efficiency', 'Simulators', 'ViewA', 'Predictor', 'ViewB')],
               zip=f'{B}/gates/34-sc-ot/landing-r1/gate34-le-evidence.zip', parts=['build/results.jsonl']),
    '36': dict(pr='#323', name='sc-garble', head=rp('8c3f3e3fe2912784f680c10f8c478d2eeeeb7f6a'),
               r1head=rp('cd9a48438c2a6548fe9e246ce569be57c9df96b3'), r1base=rp('1321b9cb358867f5b51974b8c5d0781519a9cfdb'),
               r1rec=rp('fb18d199fdce1f8cd1ae94ea9e092c52b157ce86'),
               unit=[f'{SC}/{x}.lean' for x in (
                   'SpecialEncryptionSecurity', 'SpecialEncryptionMulti', 'Garbling', 'GarblingSecurity', 'Yao',
                   'Garbling/CoinBlocks', 'Garbling/Probability', 'GarblingSecurity/CoinMarginals',
                   'GarblingSecurity/NestedBounds', 'SpecialEncryptionMulti/SliceParser',
                   'SpecialEncryptionMulti/SliceReduction', 'SpecialEncryptionSecurity/Pad',
                   'SpecialEncryptionSecurity/WrongKey')] + ['TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean'],
               zip=f'{B}/gates/36-sc-garble/landing-r1/gate36-le-evidence.zip',
               parts=['build/results.jsonl', 'build-rerun/results.jsonl'],
               rtip=rp('654323f27fbbed3a1b3664908b6c14cf563e52a2'), rhead=rp('d32328f79cdef7d7e9c2a628d9f22c105f768a1c'),
               rpar=rp('4366cd962ceab226b680760b14c48dc17e54a3b1'),
               rtree=rp('5662520d23695e1451bb3aa849ace82f71685393'), rptree=rp('63ce05ff49c0295a946d4e9fa4fcfc38bfab5bb4')),
}[gate]
HEAD, UNIT, PR, R1H, R1B = CFG['head'], CFG['unit'], CFG['pr'], CFG['r1head'], CFG['r1base']
assert OPEN[PR] == HEAD, (PR, OPEN[PR], HEAD)
BASE = rp(R.git('merge-base', HEAD, TIP).stdout.strip())
CMP = [('tip', TIP)] + [(k, v) for k, v in OPEN.items() if k != PR]
os.makedirs(out, exist_ok=True)
W = lambda name, L: open(os.path.join(out, name), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
lean = R.lean_changed
assert sorted(lean(BASE, HEAD)) == sorted(UNIT), sorted(set(lean(BASE, HEAD)) ^ set(UNIT))


def series(a, b):
    L = []
    for c in R.git('rev-list', '--reverse', f'{a}..{b}').stdout.split():
        o = R.git('cat-file', '-p', c).stdout
        L.append(f'  {c} gpgsig {len(re.findall(r"(?m)^gpgsig", o))} | '
                 f'{R.git("log", "-1", "--format=author %an <%ae> | committer %cn <%ce> | %s", c).stdout.strip()}')
    return L


def edit_report(a, b, label):
    fs = lean(a, b)
    d = R.git('diff', '-U0', a, b).stdout
    L = [f'{label} {a[:8]}..{b[:8]}: files {fs}; numstat {R.git("diff", "--numstat", a, b).stdout.split()}',
         '  hunks: ' + ' | '.join(h.strip() for h in re.findall(r'(?m)^(@@ .*? @@)', d))]
    L += ['  ' + x for x in d.splitlines() if x[:1] in '+-' and not x.startswith(('+++', '---'))]
    for p in fs:
        x, y = decls(R.show(a, p)), decls(R.show(b, p))
        L.append(f'  {p.split("/")[-1]}: declarations {len(x)} -> {len(y)}; removed {[n for n in x if n not in y]}; '
                 f'added {[n for n in y if n not in x]}; headers differing '
                 f'{[n for n in x if n in y and x[n][2] != y[n][2]]}; docstrings changed '
                 f'{[n for n in x if n in y and x[n][3] != y[n][3]]}; order kept '
                 f'{[n for n in y if n in x] == [n for n in x if n in y]}')
        ia, ib = re.findall(r'(?m)^import .*', R.show(a, p)), re.findall(r'(?m)^import .*', R.show(b, p))
        L.append(f'  imports identical {ia == ib}; added {[i for i in ib if i not in ia]}; removed '
                 f'{[i for i in ia if i not in ib]}')
    return L


def hdrcmp(old, new_, files, label):
    L = [f'# {label}: every declaration (private included) at {old[:8]} against {new_[:8]}; header = keyword line to '
         f'the top-level := for theorems, the whole block for definitions, with any open/include/omit ... in prefix']
    for f in files:
        a, b = decls(R.show(old, f)), decls(R.show(new_, f))
        same = [n for n in a if n in b and a[n][2] == b[n][2]]
        defs = [n for n in a if a[n][0] not in ('theorem', 'lemma') and n in b]
        L.append(f'## {f.split("/", 2)[-1]}: {len(a)} -> {len(b)}; headers identical {len(same)}, differing '
                 f'{[n for n in a if n in b and a[n][2] != b[n][2]]}, removed {[n for n in a if n not in b]}, new '
                 f'{[n for n in b if n not in a]}; order kept {[n for n in b if n in a] == [n for n in a if n in b]}; '
                 f'docstrings changed {[n for n in a if n in b and a[n][3] != b[n][3]]}; definition blocks '
                 f'{sum(a[n][2] == b[n][2] for n in defs)}/{len(defs)} identical')
    return L


# 1. merge trees ---------------------------------------------------------------------------------------------------
L = [f'PR {PR} ({CFG["name"]}) head {HEAD}; merge base with the tip {TIP} ({TIPREF}): {BASE}',
     f'{PR} changed .lean paths ({BASE[:8]}..head, {len(UNIT)}): {sorted(lean(BASE, HEAD))}',
     f'tip .lean delta since the merge base ({BASE[:8]}..{TIP[:8]}): {lean(BASE, TIP)}',
     'open PR heads (origin branch refs at the time of this check): '
     + ', '.join(f'{k} {v}' for k, v in OPEN.items()), '']
trees, changed, mb = {}, {}, {}
for k, v in CMP:
    mb[k] = rp(R.git('merge-base', HEAD, v).stdout.strip())
    changed[k] = lean(mb[k], v)
    t, rc, raw = R.mergetree(HEAD, v); trees[k] = t
    L.append(f'git merge-tree --write-tree {HEAD} {v} ({k}): tree {t} rc {rc} ({"clean" if rc == 0 else "CONFLICT"})')
    if rc:
        L.append(raw)
    dh = [p for p in R.git('diff', '--name-only', HEAD, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    do = [p for p in R.git('diff', '--name-only', v, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    L.append(f'  Lean paths of the merged tree differing from the {PR} head ({len(dh)}): {dh}')
    L.append(f'  and from {k} ({len(do)}): {do}')
    shared = sorted(set(changed[k]) & set(UNIT))
    L.append(f'  merge base {mb[k]}; {k} changed .lean paths from it: {len(changed[k])}; shared with {PR}: {shared}')
    if k != 'tip':
        mine = set(lean(mb[k], HEAD))
        L.append(f'  {PR} .lean paths from that merge base: {len(mine)}; of them outside the {PR} unit (base delta of one '
                 f'side): {len(mine - set(UNIT))}')
W('mergetrees.txt', L)

# 2. downstream ----------------------------------------------------------------------------------------------------
gh = R.graph(HEAD)
uclo = set().union(*[closure(gh, [p]) for p in UNIT])
L = [f'# import graph at the {PR} head {HEAD[:8]} (TCSlib and audits modules); a module counts as downstream of itself',
     f'unit modules: {len(UNIT)}; union of their import closures: {len(uclo)} modules']
shared_down = {}
for k, v in CMP:
    ch = set(changed[k])
    L.append(f'{k} ({v[:8]}): its changed modules (from the merge base {mb[k][:8]}) inside the unit closure: '
             f'{sorted(ch & uclo)}')
    gm = R.graph(trees[k])
    both = sorted(downstream(gm, set(UNIT)) & downstream(gm, ch - set(UNIT)))
    shared_down[k] = both
    L.append(f'  merged tree {trees[k][:8]}: {len(both)} modules downstream of both a {PR} module and a {k} module: '
             f'{[p[:-5] for p in both]}')
W('downstream.txt', L)

# 3. source equality of the landing build --------------------------------------------------------------------------
zp = CFG['zip']
z = zipfile.ZipFile(os.path.join(repo_path, zp))
final, nrec = {}, []
for part in CFG['parts']:
    rows = [json.loads(l) for l in z.read(part).decode().splitlines() if l.strip()]
    mods = [x for x in rows if 'module' in x]
    nrec.append((part, len(mods), sum(x['rc'] == 0 for x in mods), sum(x['errors'] for x in mods),
                 sum(x.get('error_substr', 0) for x in mods), 'done' in rows[-1]))
    for x in mods:
        final[x['module']] = x
L = [f'{zp} (SHA-256 {hashlib.sha256(open(os.path.join(repo_path, zp), "rb").read()).hexdigest()}):']
L += [f'  {p}: {n} module records, rc 0 {ok}, errors {e}, substring "error" {e2}, last record "done": {d}'
      for p, n, ok, e, e2, d in nrec]
L.append(f'  modules (later records override earlier): {len(final)}; unit modules built: '
         f'{sorted(set(m + ".lean" for m in final) & set(UNIT)) == sorted(UNIT)}')
revs = [('head', HEAD)]
if gate == '36':
    revs = [(f'built tree {CFG["rtree"][:8]} (scratch replica d32328f7)', CFG['rtree'])] + revs
for k, rev in revs + [(f'merged with {k}', trees[k]) for k, _ in CMP]:
    diff = [m for m, x in final.items()
            if hashlib.sha256(R.blob(rev, m + '.lean') or b'').hexdigest() != x['source_sha256']]
    L.append(f'{k} {rev[:8]}: {len(final) - len(diff)} built sources equal, {len(diff)} differ {diff}')
W('srcequality.txt', L)

# 4. names ---------------------------------------------------------------------------------------------------------
new = sorted({n for p in UNIT for n in NM.findall(R.show(HEAD, p))} - {n for p in UNIT for n in NM.findall(R.show(BASE, p))})
L = [f'# the {len(new)} declaration names new at the head (short names as written) against the declarations of the '
     f'.lean files each comparator changed since its merge base with the head (unit files excluded)']
for k, v in CMP:
    hits = []
    for p in changed[k]:
        if p in UNIT:
            continue
        for i, l in enumerate(R.show(v, p).splitlines()):
            m = NM.match(l)
            if m and m.group(1) in new:
                hits.append(f'{p}:{i + 1}: {l.strip()[:120]}')
    L.append(f'{k} ({len(changed[k])} changed files): {len(hits)} declarations with a new name')
    L += ['    ' + h for h in hits]
W('namecheck.txt', L)

# 5. duplication since round 1 -------------------------------------------------------------------------------------
PAT = re.compile(r'headD_drop\b|getD_eq_getElem\?_getD|getElem\?_ofFn|getD_eq_getElem\b|getElem_ofFn|headD_ofFn|'
                 r'head\?_drop|getD_ofFn|ofFn_succ.*headD|headD.*ofFn_succ|List\.headD_cons|length_le_length_encodeList|'
                 r'length_ofFn_coins|encodeList_cons|encodeList_nil')
L = [f'# A. every line added or removed since round 1 ({R1H[:8]}..{HEAD[:8]}) in the unit files']
for p in UNIT:
    d = R.git('diff', '-U0', R1H, HEAD, '--', p).stdout
    L += [f'  {p.split("/", 2)[-1]}: {x[:150]}' for x in d.splitlines()
          if x[:1] in '+-' and not x.startswith(('+++', '---'))]
nr1 = {n for p in UNIT for n in decls(R.show(R1H, p))}
nh = {n for p in UNIT for n in decls(R.show(HEAD, p))}
L.append(f'declarations in the unit files: round 1 {len(nr1)}, head {len(nh)}; new since round 1 {sorted(nh - nr1)}; '
         f'removed since round 1 {sorted(nr1 - nh)}')
L.append(f'# B. lines of the reading-lemma class (DL-47 headD/getD readers; the G34-02 / G36-01 lemmas) added '
         f'{BASE[:8]}..{HEAD[:8]}')
for p in UNIT:
    d = R.git('diff', '-U0', BASE, HEAD, '--', p).stdout
    ln = 0
    for x in d.splitlines():
        m = re.match(r'@@ -\S+ \+(\d+)', x)
        if m:
            ln = int(m.group(1)); continue
        if x.startswith('+') and not x.startswith('+++'):
            if PAT.search(x):
                L.append(f'  {p.split("/", 2)[-1]}:{ln}: {x[1:].strip()[:140]}')
            ln += 1


def sig(kind, hdr, name):
    """the statement without its keyword and name: the binder list and type, whitespace-normalised."""
    h = hdr.split('\n')
    h = [x for x in h if not re.match(r'^(open|include|omit)\b', x)]
    s = ws('\n'.join(h))
    i = s.find(name)
    return s[i + len(name):].strip() if i >= 0 else s


newdecl = {}
for p in UNIT:
    a, b = decls(R.show(BASE, p)), decls(R.show(HEAD, p))
    for n, v in b.items():
        if n not in a and v[0] in ('theorem', 'lemma'):
            newdecl[(p, n)] = sig(v[0], v[2], n.split('#')[0])
since = rp(R.git('merge-base', R1H, TIP).stdout.strip())
L.append(f'# C. statement scan: each of the {len(newdecl)} theorems new at the head (vs the base) against every theorem '
         f'in the .lean files changed since round 1 on the tip ({since[:8]}..{TIP[:8]}) and in each other open PR '
         f'(from its merge base with the head); a hit = identical binders and type after whitespace normalisation')
pools = [('tip since round 1', TIP, [p for p in lean(since, TIP) if p not in UNIT])] + \
        [(k, v, [p for p in changed[k] if p not in UNIT]) for k, v in CMP if k != 'tip']
for lab, rev, files in pools:
    hits, n = [], 0
    for p in files:
        for nm, v in decls(R.show(rev, p)).items():
            if v[0] not in ('theorem', 'lemma'):
                continue
            n += 1
            s = sig(v[0], v[2], nm.split('#')[0])
            for (up, un), us in newdecl.items():
                if us == s:
                    hits.append(f'    {un} ({up.split("/")[-1]}) = {nm} ({p}:{v[1]})')
    L.append(f'  {lab} ({rev[:8]}): {len(files)} files, {n} theorems scanned; hits {len(hits)}')
    L += hits
W('dupscan.txt', L)

# ===================================================================================================================
if gate == '34':
    RB, R1REC = CFG['rebased'], CFG['r1rec']
    L = ['# the rebase onto the tip of 2026-11-15 and LE-gate34']
    r = R.git('range-diff', f'{R1B}..{R1H}', f'{BASE}..{RB}').stdout
    L.append(f'git range-diff {R1B[:8]}..{R1H[:8]} (round 1) {BASE[:8]}..{RB[:8]} (rebased, before LE-gate34):')
    L += ['  ' + x for x in r.splitlines()]
    L.append(f'unit files byte-identical at {R1H[:8]} and {RB[:8]}: {all(R.blob(R1H, p) == R.blob(RB, p) for p in UNIT)}')
    L.append(f'git diff {R1H[:8]} {HEAD[:8]} restricted to TCSlib/audits = git diff {RB[:8]} {HEAD[:8]} (LE-gate34): '
             f'{R.git("diff", R1H, HEAD, "--", *UNIT).stdout == R.git("diff", RB, HEAD).stdout}')
    L.append(f'{HEAD[:8]}^ = {rp(HEAD + "^")}; tree {rp(HEAD + "^{tree}")}')
    L.append(f'commits {BASE[:8]}..{HEAD[:8]}:')
    L += series(BASE, HEAD)
    W('rebase.txt', L)
    # LE-gate34
    EF = f'{OT}/Efficiency.lean'
    BL = 'TCSlib/Cryptography/Foundations/BitLists.lean'
    L = ['# LE-gate34 (G34-01) from git objects'] + edit_report(RB, HEAD, 'LE-gate34')
    L += [''] + hdrcmp(R1H, HEAD, UNIT, f'round-1 head {R1H[:8]} -> round-2 head')
    L.append('')
    L.append(f'TCSlib.Cryptography.headD_drop at the head: '
             f'{[f"{BL}:{i + 1}: {l.strip()}" for i, l in enumerate(R.show(HEAD, BL).splitlines()) if re.match(r"theorem headD_drop\b", l)]}'
             f'; BitLists blob head = tip: {R.blob(HEAD, BL) == R.blob(TIP, BL)}; = round-1 head: '
             f'{R.blob(HEAD, BL) == R.blob(R1H, BL)}')
    L.append(f'BitLists in the import closure of Efficiency: at the head {BL in closure(gh, [EF])}; at the round-1 head '
             f'{BL in closure(R.graph(R1H), [EF])}')
    for n in ('getD_zero_eq', "getD_one_eq'"):
        g = R.git('grep', '-n', '-w', '-F', n, HEAD, '--', 'TCSlib', 'audits', check=False).stdout.splitlines()
        L.append(f'occurrences of {n} at the head: {len(g)}: {[x.split(":", 1)[1][:110] for x in g]}')
    W('lecheck.txt', L)
    # base move
    L = [f'# the PR base moved from {R1B[:8]} (round 1) to {BASE[:8]}; round 1 audited against the records tip '
         f'{R1REC[:8]}', f'first-parent merges {R1B[:8]}..{BASE[:8]}:']
    for c in R.git('log', '--merges', '--first-parent', '--format=%H %s', f'{R1B}..{BASE}').stdout.splitlines():
        h = c.split()[0]
        L.append(f'  {c[:110]}; in the round-1 records tip {R1REC[:8]}: {R.anc(h, R1REC)}')
    L.append(f'first-parent merges eff2dcd0..{R1B[:8]} (already in the round-1 base; the integration build covers '
             f'everything changed since eff2dcd0):')
    for c in R.git('log', '--merges', '--first-parent', '--format=%H %s', f'eff2dcd0..{R1B}').stdout.splitlines():
        L.append(f'  {c[:110]}')
    d1 = lean(R1B, BASE)
    L.append(f'.lean delta {R1B[:8]}..{BASE[:8]} ({len(d1)}): {d1}')
    L.append(f'  of these, in the unit closure at the head: {sorted(set(d1) & uclo)}')
    L.append(f'.lean delta {R1REC[:8]} (round-1 records tip)..{BASE[:8]}: {lean(R1REC, BASE)}')
    r1clo = set().union(*[closure(R.graph(R1H), [p]) for p in UNIT])
    L.append(f'unit closure at the head: {len(uclo)} modules; at the round-1 head: {len(r1clo)}; added '
             f'{sorted(uclo - r1clo)}; removed {sorted(r1clo - uclo)}')
    L.append(f'.lean delta since the base on the tip ({BASE[:8]}..{TIP[:8]}): {lean(BASE, TIP)}')
    W('basemove.txt', L)
    # G34-02 / DL-48
    SIM = f'{OT}/Simulators.lean'
    RO = 'TCSlib/Cryptography/Encryption/PublicKey/NonMalleability/Simulation/Rounds.lean'
    led = R.show(TIP, f'{B}/duplication-ledger.md')
    row = [l for l in led.splitlines() if l.startswith('| DL-48 |')]
    L = ['# G34-02 disposition (ruling Seyoon 2026-11-15, "ledger 02"): DL-48',
         f'duplication-ledger.md at the tip {TIP[:8]}: DL-48 rows {len(row)}; mentions G34-02 '
         f'{"G34-02" in (row[0] if row else "")}; names OT.length_ofFn_coins {"OT.length_ofFn_coins" in (row[0] if row else "")}'
         f'; names Composability.NMSim.length_ofFn_coins {"NMSim.length_ofFn_coins" in (row[0] if row else "")}; '
         f'cleanup line present {"G34-02 cleanup" in (row[0] if row else "")}',
         f'last commit touching the ledger: {R.git("log", "-1", "--format=%H %s", TIP, "--", f"{B}/duplication-ledger.md").stdout.strip()}']
    m = re.search(r'\*\*Gate 34 G34-02.*?\|', row[0]) if row else None
    L.append(f'  DL-48 G34-02 text: {m.group(0) if m else None}')
    for rev, lab in [(R1H, 'round-1 head'), (HEAD, 'head')]:
        a = decls(R.show(rev, SIM)).get('length_ofFn_coins')
        b = decls(R.show(rev, RO)).get('length_ofFn_coins')
        L.append(f'{lab} {rev[:8]}: OT.length_ofFn_coins {SIM.split("/")[-1]}:{a[1] if a else None}; '
                 f'NMSim.length_ofFn_coins {RO.split("/", 2)[-1]}:{b[1] if b else None}; headers identical '
                 f'{a and b and a[2] == b[2]}')
    L.append(f'Simulators.lean blob round-1 head = head: {R.blob(R1H, SIM) == R.blob(HEAD, SIM)}; Rounds.lean in the '
             f'unit closure at the head: {RO in uclo}')
    W('dl48.txt', L)

if gate == '36':
    RT, RH, RPAR, RTREE, RPTREE = CFG['rtip'], CFG['rhead'], CFG['rpar'], CFG['rtree'], CFG['rptree']
    # replica
    L = ['# the scratch replica (landing-r1/) and the pushed head']
    L.append(f'pushed head {HEAD}: parent {rp(HEAD + "^")} (= round-1 head {R1H[:8]}: {rp(HEAD + "^") == R1H}); '
             f'tree {rp(HEAD + "^{tree}")}; merge base with the tip {BASE}')
    L.append(f'replica tip {RT} (records tip after #313 merged); tip now {TIP}; .lean delta {RT[:8]}..{TIP[:8]}: '
             f'{lean(RT, TIP)}; all paths: {R.git("diff", "--name-only", RT, TIP).stdout.split()[:3]} ... '
             f'({len(R.git("diff", "--name-only", RT, TIP).stdout.split())} paths, all records: '
             f'{all(p.startswith(("briefs/", "PassShelat")) for p in R.git("diff", "--name-only", RT, TIP).stdout.split())})')
    L.append(f'replica parent {RPAR}: tree {rp(RPAR + "^{tree}")} (= {RPTREE[:8]}: {rp(RPAR + "^{tree}") == RPTREE}); '
             f'git merge-tree --write-tree {RT[:8]} {R1H[:8]} = {R.mergetree(RT, R1H)[0]} (= replica parent tree: '
             f'{R.mergetree(RT, R1H)[0] == RPTREE})')
    L.append(f'replica head {RH}: parent {rp(RH + "^")}; tree {rp(RH + "^{tree}")} (= {RTREE[:8]}: '
             f'{rp(RH + "^{tree}") == RTREE}); gpgsig {len(re.findall(r"(?m)^gpgsig", R.git("cat-file", "-p", RH).stdout))}')
    t1 = R.mergetree(RT, HEAD)[0]
    L.append(f'git merge-tree --write-tree {RT} {HEAD} = {t1}; = built tree {RTREE}: {t1 == RTREE}')
    t2 = R.mergetree(TIP, HEAD)[0]
    dd = R.git('diff', '--name-only', RTREE, t2).stdout.split()
    L.append(f'git merge-tree --write-tree {TIP} {HEAD} (current tip) = {t2}; paths differing from {RTREE[:8]}: {len(dd)}, '
             f'all records (briefs/ or the plan): {all(p.startswith(("briefs/", "PassShelat")) for p in dd)}; TCSlib and '
             f'audits subtrees identical: '
             f'{all(rp(f"{t2}:{s}") == rp(f"{RTREE}:{s}") for s in ("TCSlib", "audits"))}')
    p1, p2 = R.git('diff', R1H, HEAD).stdout, R.git('diff', RPAR, RH).stdout
    L.append(f'patch git diff {R1H[:8]} {HEAD[:8]} (LE-gate36, pushed) = git diff {RPAR[:8]} {RH[:8]} (replica): {p1 == p2}')
    msg = lambda c: R.git('log', '-1', '--format=%B', c).stdout
    L.append(f'commit message pushed = replica: {msg(HEAD) == msg(RH)}; subject: {msg(HEAD).splitlines()[0]}')
    rd = R.git('range-diff', f'{R1B}..{R1H}', f'{RT}..{RPAR}').stdout
    L.append(f'git range-diff {R1B[:8]}..{R1H[:8]} {RT[:8]}..{RPAR[:8]} (replayed series):')
    L += ['  ' + x for x in rd.splitlines()]
    tt = R.mergetree(RH, OPEN['#324'])[0]
    L.append(f'landing-r1 trial with #324: git merge-tree --write-tree {RH[:8]} {OPEN["#324"][:8]} = {tt} (the trial tree '
             f'a025d7ab7c4911b6e42ef18b0c05b1c2ac1d4251: {tt == rp("a025d7ab7c4911b6e42ef18b0c05b1c2ac1d4251")}); it covers the replica tip '
             f'{RT[:8]} + #323 + #324')
    L.append(f'replica commits are on no ref: {R.git("branch", "-a", "--contains", RH).stdout.strip() == ""}')
    W('replica.txt', L)
    # series
    L = [f'# the PR series: round-1 head {R1H[:8]} plus LE-gate36, no rebase (base {BASE[:8]} = round-1 base '
         f'{R1B[:8]}: {BASE == R1B})', f'commits {BASE[:8]}..{HEAD[:8]}:'] + series(BASE, HEAD)
    L.append(f'unit files changed {R1H[:8]}..{HEAD[:8]}: {lean(R1H, HEAD)}')
    W('rebase.txt', L)
    # LE-gate36
    SP_ = f'{SC}/SpecialEncryptionMulti/SliceParser.lean'
    BE = 'TCSlib/Cryptography/Asymptotic/BlockEncryptor.lean'
    L = ['# LE-gate36 (G36-01) from git objects'] + edit_report(R1H, HEAD, 'LE-gate36')
    L += [''] + hdrcmp(R1H, HEAD, UNIT, f'round-1 head {R1H[:8]} -> round-2 head')
    L.append('')
    c0, c1 = closure(R.graph(R1H), [SP_]), closure(gh, [SP_])
    L.append(f'SliceParser import closure: round-1 head {len(c0)}, head {len(c1)}; added {sorted(c1 - c0)}; removed '
             f'{sorted(c0 - c1)}')
    L.append(f'acyclic: SliceParser in the import closure of BlockEncryptor at the head: {SP_ in closure(gh, [BE])}; '
             f'any unit module in it: {sorted(set(UNIT) & closure(gh, [BE]))}')
    uc0 = set().union(*[closure(R.graph(R1H), [p]) for p in UNIT])
    L.append(f'unit closure: round-1 head {len(uc0)}, head {len(uclo)}; added {sorted(uclo - uc0)}')
    L.append(f'TCSlib.Cryptography.length_le_length_encodeList at the head: '
             f'{[f"{BE}:{i + 1}: {l.strip()}" for i, l in enumerate(R.show(HEAD, BE).splitlines()) if "theorem length_le_length_encodeList" in l]}'
             f'; BlockEncryptor blob head = tip: {R.blob(HEAD, BE) == R.blob(TIP, BE)}; = round-1 base: '
             f'{R.blob(HEAD, BE) == R.blob(R1B, BE)}')
    for rev, lab in [(R1H, 'round-1 head'), (HEAD, 'head')]:
        g = R.git('grep', '-n', '-w', 'length_le_encodeList', rev, '--', 'TCSlib', 'audits', check=False).stdout.splitlines()
        L.append(f'occurrences of length_le_encodeList at the {lab}: {len(g)}: {[x.split(":", 1)[1][:120] for x in g]}')
    W('lecheck.txt', L)

print('OK', gate, BASE[:8], {k: (v[:8], len(shared_down[k])) for k, v in trees.items()})
