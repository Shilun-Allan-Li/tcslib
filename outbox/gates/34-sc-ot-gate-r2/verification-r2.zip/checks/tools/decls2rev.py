"""decls2rev.py <repo> <old-rev> <new-rev> <file>...: maintainer/tools/decls2.py's decls() applied to two git
revisions (both read with git show), same output format. Used for pack re-checks from git objects."""
import subprocess, sys
repo, old, new = sys.argv[1:4]
files = sys.argv[4:]
src = open(f'{repo}/briefs/pass-shelat-ch5-8/maintainer/tools/decls2.py', encoding='utf-8').read()
src = src[:src.index('for f in files:')]
g = {'__name__': 'decls2', 'sys': sys}
sys_argv = sys.argv; sys.argv = ['decls2', repo, old]
exec(compile(src, 'decls2.py', 'exec'), g)
sys.argv = sys_argv
decls = g['decls']
def show(rev, f):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, text=True)
    return r.stdout if r.returncode == 0 else ''
n_un = 0
for f in files:
    a, b = (decls(show(old, f)) if show(old, f) else {}), decls(show(new, f))
    for n in sorted(set(a) | set(b)):
        if n in a and n not in b: print(f"REMOVED\t{f}:{a[n][1]}\t{n}\t{a[n][0]}\t{a[n][2]}")
        elif n in b and n not in a: print(f"ADDED\t{f}:{b[n][1]}\t{n}\t{b[n][0]}\t{b[n][2]}")
        elif a[n][2] != b[n][2]: print(f"CHANGED\t{f}:{a[n][1]}->{b[n][1]}\t{n}\t{b[n][0]}\t{a[n][2]}\t=>\t{b[n][2]}")
        else: n_un += 1
print(f'# unchanged {n_un}', file=sys.stderr)
