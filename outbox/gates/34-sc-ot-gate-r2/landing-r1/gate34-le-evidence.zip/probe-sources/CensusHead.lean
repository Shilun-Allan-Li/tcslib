import Lean
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Efficiency
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Predictor
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Shape
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Simulators
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer.ViewA
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer.ViewB
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-ot review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_polyTime
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_simulators
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.OT.polyTime_of_isOT
#print axioms TCSlib.Cryptography.SecureComputation.OT.simulators_of_isOT
#print axioms TCSlib.Cryptography.SecureComputation.OT.exists_negligible_bob
#print axioms TCSlib.Cryptography.SecureComputation.OT.distAdv_realA_idealA_le
#print axioms TCSlib.Cryptography.SecureComputation.OT.uprob_signedPredictor_false
#print axioms TCSlib.Cryptography.SecureComputation.OT.uprob_signedPredictor_true
#print axioms TCSlib.Cryptography.SecureComputation.OT.negligible_finset_sum
#print axioms TCSlib.Cryptography.SecureComputation.OT.pairSndD_nil'

def owners : List Name := [`TCSlib.Cryptography.SecureComputation.ObliviousTransfer,
  `TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Efficiency,
  `TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Predictor,
  `TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Shape,
  `TCSlib.Cryptography.SecureComputation.ObliviousTransfer.Simulators,
  `TCSlib.Cryptography.SecureComputation.ObliviousTransfer.ViewA,
  `TCSlib.Cryptography.SecureComputation.ObliviousTransfer.ViewB]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

