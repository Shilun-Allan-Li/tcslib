import Lean
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-yao review axiom/trace/census probe (landing head). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536
open Lean Elab Command

/-- Does the constant's type or value mention `sorryAx` directly? -/
def directSorry (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some ci =>
    ci.type.getUsedConstants.contains ``sorryAx ||
      (match ci.value? (allowOpaque := true) with
       | some v => v.getUsedConstants.contains ``sorryAx
       | none => false)
  | none => false

/-- Every constant reachable from `start` through types and values. -/
def closureOf (env : Environment) (start : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut todo : Array Name := #[start]
  for _ in [0:100000000] do
    if todo.isEmpty then break
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    if let some ci := env.find? n then
      for c in ci.type.getUsedConstants do todo := todo.push c
      if let some v := ci.value? (allowOpaque := true) then
        for c in v.getUsedConstants do todo := todo.push c
  return seen

/-- `#admitted n`: the declarations in `n`'s closure that use `sorryAx` directly. -/
elab "#admitted " id:ident : command => do
  let env ← getEnv
  let n := id.getId
  unless env.contains n do throwError "unknown constant {n}"
  let s := closureOf env n
  let adm := (s.toList.filter (fun m => m != ``sorryAx && directSorry env m)).toArray.qsort
    (fun a b => a.toString < b.toString)
  logInfo m!"ADMITTED {n}: closure {s.size}; direct sorryAx {adm.size}: {adm.toList}"

#print axioms TCSlib.Cryptography.SecureComputation.yaoHybrid_polyTime
#print axioms TCSlib.Cryptography.SecureComputation.yaoHybrid_simulators
#print axioms TCSlib.Cryptography.SecureComputation.yaoHybrid_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.yaoSeed_good_whp
#print axioms TCSlib.Cryptography.SecureComputation.sliceMultiMessageSecure_of_prfOut
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_polyTime
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_simulators
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.hbcSecure_compose
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.CoinSeedRelabel.assignmentFold_lt_four
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.CoinSeedRelabel.assignmentFold_injective
#print axioms TCSlib.Cryptography.SecureComputation.GarblingProbability.assignmentFold_small
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.DescriptionDecoder.decodeDescription_host
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.RunWithHost.exists_machine
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.garbledRunWith_poly
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.GateHybridSecurity.endpoint_negligible
#print axioms TCSlib.Cryptography.SecureComputation.YaoHybridProof.FakeSimulatorFactory.exists_simulator
#print axioms BoolCircuit.DAGCircuit.isFaninTwo_iff
#print axioms BoolCircuit.encodeList_nil
#print axioms BoolCircuit.encodeList_cons
#print axioms BoolCircuit.GateKind.encode_and
#print axioms BoolCircuit.GateKind.encode_or
#print axioms BoolCircuit.GateKind.encode_not
#print axioms BoolCircuit.DAGGate.encode_eq
#print axioms BoolCircuit.DAGCircuit.encode_parts
#admitted TCSlib.Cryptography.SecureComputation.yaoHybrid_polyTime
#admitted TCSlib.Cryptography.SecureComputation.yaoHybrid_simulators
#admitted TCSlib.Cryptography.SecureComputation.yaoHybrid_hbcSecure
#admitted TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure
#admitted TCSlib.Cryptography.SecureComputation.yaoSeed_good_whp

-- the LE-doc job's one assumption: argument order of Data.make
#check @TCSlib.Cryptography.SecureComputation.YaoHybridProof.FakeSimulator.Data.make

def owners : List Name := [
  `TCSlib.Cryptography.SecureComputation.Yao,
  `TCSlib.Complexity.CircuitComplexity.Uniform,
  `TCSlib.Complexity.CircuitComplexity.DAGCircuit,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceSimulator,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceStatistical,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AllTables,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobIO,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobInit,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobSimulator,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobStageZero,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobStatistical,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobTables,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobViewShape,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CallEquations,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.ChunkScanner,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinGarbling,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinRead,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinRelabel,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinSeedRelabel,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoordinateSwap,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Decryption,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.DescriptionDecoder,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.EvalGate,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeMessage,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeObjects,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeSimulator,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeSimulatorFactory,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FirstTagged,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GarbledRun,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Garbling,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GarblingProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridChain,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridMessage,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridSecurity,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybrids,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateOccurrences,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateStepCases,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Lengths,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.NonceCoordinates,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.OTAnswerWords,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.OTInputs,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.ProtocolEfficiency,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RelabelGarbling,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RowFromCoins,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RunWithHost,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SamplerEndpoints,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SeedCoordinates,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedAdviceBounds,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedFields,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedLaw,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedPlan,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedRows,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedSeed,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedSlices,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStep,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStepChoices,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStepSecurity,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedTables,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SimulationBound,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SliceReconstruction,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SliceReduction,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.StatisticalSwitch,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Strategies,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TablesFromCoins,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TapeValues,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TwoMoveViews,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.WordLists]

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  let mut nonstd := 0
  let mut simpN := 0
  let mut instN := 0
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let bad := axs.filter (fun a => a != "propext" && a != "Classical.choice" && a != "Quot.sound")
    if !bad.isEmpty then
      nonstd := nonstd + 1
      IO.println s!"NONSTD\t{c}\t{home}\t{axs.toList}"
    if simps.isLemma (.decl c) then
      simpN := simpN + 1
      IO.println s!"SIMP\t{c}\t{home}"
    if Lean.Meta.isInstanceCore env c then instN := instN + 1
    IO.println s!"AX\t{c}\t{home}\t{axs.toList}"
    n := n + 1
  IO.println s!"CENSUS stored {n}; nonstandard {nonstd}; simp-lemmas {simpN}; instances {instN}"
