import Lean
import TCSlib.Cryptography.SecureComputation.Yao
import TCSlib.Complexity.CircuitComplexity.Uniform
import TCSlib.Complexity.CircuitComplexity.DAGCircuit
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceProgram
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceSimulator
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceStatistical
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AllTables
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobIO
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobInit
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobProgram
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobSimulator
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobStageZero
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobStatistical
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobTables
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobViewShape
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CallEquations
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.ChunkScanner
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinGarbling
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinRead
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinRelabel
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinSeedRelabel
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoordinateSwap
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Decryption
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.DescriptionDecoder
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.EvalGate
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeMessage
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeObjects
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeProgram
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeSimulator
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeSimulatorFactory
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FirstTagged
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GarbledRun
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Garbling
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GarblingProgram
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridChain
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridMessage
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridSecurity
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybrids
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateOccurrences
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateStepCases
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Lengths
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.NonceCoordinates
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.OTAnswerWords
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.OTInputs
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.ProtocolEfficiency
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RelabelGarbling
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RowFromCoins
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RunWithHost
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SamplerEndpoints
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SeedCoordinates
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedAdviceBounds
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedFields
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedLaw
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedPlan
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedRows
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedSeed
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedSlices
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStep
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStepChoices
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStepSecurity
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedTables
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SimulationBound
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SliceReconstruction
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SliceReduction
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.StatisticalSwitch
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Strategies
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TablesFromCoins
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TapeValues
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TwoMoveViews
import TCSlib.Cryptography.SecureComputation.Yao.HybridProof.WordLists

/-! sc-yao review collector (landing head): CLOSURE/ROOT for the owners, CAT for every TCSlib definition. -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def owners : List Name := [
  `TCSlib.Cryptography.SecureComputation.Yao,
  `TCSlib.Complexity.CircuitComplexity.Uniform,
  `TCSlib.Complexity.CircuitComplexity.DAGCircuit,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceSimulator,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AliceStatistical,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.AllTables,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobIO,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobInit,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobSimulator,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobStageZero,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobStatistical,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobTables,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.BobViewShape,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CallEquations,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.ChunkScanner,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinGarbling,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinRead,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinRelabel,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoinSeedRelabel,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.CoordinateSwap,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Decryption,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.DescriptionDecoder,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.EvalGate,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeMessage,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeObjects,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeSimulator,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FakeSimulatorFactory,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.FirstTagged,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GarbledRun,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Garbling,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GarblingProgram,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridChain,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridMessage,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybridSecurity,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateHybrids,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateOccurrences,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.GateStepCases,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Lengths,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.NonceCoordinates,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.OTAnswerWords,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.OTInputs,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.ProtocolEfficiency,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RelabelGarbling,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RowFromCoins,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RunWithHost,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SamplerEndpoints,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SeedCoordinates,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedAdviceBounds,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedFields,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedLaw,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedPlan,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedRows,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedSeed,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedSlices,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStep,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStepChoices,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedStepSecurity,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SelectedTables,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SimulationBound,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SliceReconstruction,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.SliceReduction,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.StatisticalSwitch,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.Strategies,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TablesFromCoins,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TapeValues,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.TwoMoveViews,
  `TCSlib.Cryptography.SecureComputation.Yao.HybridProof.WordLists]

def nameParts : Name → List (String × String)
  | .anonymous => []
  | .str p s => nameParts p ++ [("str", s)]
  | .num p n => nameParts p ++ [("num", toString n)]

def ident (n : Name) : Json := Json.mkObj [("display", toJson n.toString), ("components", toJson (nameParts n))]

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let idx : Std.HashMap Name Nat := names.size.fold (fun i _ m => m.insert names[i]! i) {}
  -- transitive TCSlib import closures
  for o in owners do
    let some i := idx[o]? | throwError "owner not loaded: {o}"
    let mut seen : Std.HashSet Name := {}
    let mut stack : Array Name := (env.header.moduleData[i]!.imports.map (·.module))
    while !stack.isEmpty do
      let m := stack.back!
      stack := stack.pop
      if seen.contains m then continue
      seen := seen.insert m
      if let some j := idx[m]? then
        stack := stack ++ env.header.moduleData[j]!.imports.map (·.module)
    let tcs := (seen.toArray.filter fun m => (`TCSlib).isPrefixOf m).qsort (·.toString < ·.toString)
    IO.println ("CLOSURE " ++ (Json.mkObj [("module", toJson o.toString), ("closure", toJson (tcs.map (·.toString)))]).compress)
  let mut catCount := 0
  let mut rootCount : Std.HashMap Name Nat := {}
  for (n, c) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := names[mi.toNat]!
    unless (`TCSlib).isPrefixOf home do continue
    if c.isDefinition then
      let abbrevFlag := match c with
        | .defnInfo d => match d.hints with | .abbrev => true | _ => false
        | _ => false
      IO.println ("CAT " ++ (Json.mkObj [("name", ident n), ("home", ident home), ("kind", toJson (kindOf c)),
        ("status", toJson (match Lean.getReducibilityStatusCore env n with
            | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible")),
        ("instance", toJson (Lean.Meta.isInstanceCore env n)), ("matcher", toJson (Lean.Meta.isMatcherCore env n)),
        ("abbrev", toJson abbrevFlag)]).compress)
      catCount := catCount + 1
    if owners.contains home then
      rootCount := rootCount.insert home ((rootCount[home]?.getD 0) + 1)
      let refs (e : Expr) : Array Json := Id.run do
        let mut out := #[]
        for d in e.getUsedConstants do
          let some dj := env.getModuleIdxFor? d | continue
          let dh := names[dj.toNat]!
          unless (`TCSlib).isPrefixOf dh && dh != home do continue
          let some di := env.find? d | continue
          unless di.isDefinition do continue
          out := out.push (ident d)
        return out
      let valueRefs := match c.value? (allowOpaque := true) with | some v => refs v | none => #[]
      IO.println ("ROOT " ++ (Json.mkObj [("module", toJson home.toString), ("name", ident n), ("kind", toJson (kindOf c)),
        ("type_refs", toJson (refs c.type)), ("value_refs", toJson valueRefs)]).compress)
  IO.println s!"CAT-COUNT {catCount}"
  for o in owners do
    IO.println s!"MODULE {o}: stored {rootCount[o]?.getD 0}"

/-! sc-yao review addition: projection-coercion instances (ruling 2026-11-14: a `CoeFun`/`Coe` instance whose
body is a structure projection is notation in the coe variant). One `COEPROJ` line per TCSlib definition. -/
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let mut k := 0
  for (n, c) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := names[mi.toNat]!
    unless (`TCSlib).isPrefixOf home do continue
    let .defnInfo d := c | continue
    let rec body : Nat → Expr → Expr
      | 0, e => e
      | fuel+1, .lam _ _ b _ => body fuel b
      | fuel+1, .letE _ _ v b _ => body fuel (b.instantiate1 v)
      | _, e => e
    let ty := d.type.getForallBody.getAppFn.constName?
    let coe := ty == some `CoeFun || ty == some `Coe
    unless coe do continue
    let val := body 64 d.value
    let map := if val.getAppArgs.isEmpty then val else val.getAppArgs.back!
    let projection := match (body 64 map).getAppFn with
      | .proj .. => true
      | .const m _ => env.isProjectionFn m
      | _ => false
    IO.println s!"COEINST\t{n}\t{home}\tprojection={projection}"
    if projection then k := k + 1
  IO.println s!"COEPROJ-COUNT {k}"
