#!/usr/bin/env python3
"""Maintainer frozen-scope check for sc-yao (own masking script, independent of the delivery's).

usage:
  frozen_sy.py yao <base Yao.lean> <final Yao.lean>
  frozen_sy.py circuit <base file> <final file> <expected reader names, comma separated>
  frozen_sy.py block <file A> <file B> <theorem name>     (byte-compare one reader block)

`yao`: masks exactly the six SY-approved regions (hub import, main-results bullet, the two
sketches, the two bodies) in both files, located by anchors, and compares the rest byte for
byte; reports the differing hunks, the base line numbers of each region, region-content rules,
line count and width.
`circuit`: requires the diff to be pure insertions, each one formula-docstring `rfl`/`Iff.rfl`
reader with no attribute, placed directly after a `def`; removal must restore the base exactly.
"""
import difflib
import re
import sys

HUB_RE = re.compile(r'^import TCSlib\.Cryptography\.SecureComputation\.Yao\.[A-Za-z0-9_]+\n$')
DECL_RE = re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:private |protected |noncomputable |nonrec )*'
                     r'(theorem|lemma|def|abbrev|instance|structure|inductive|class|example|'
                     r'axiom|opaque|notation|macro|syntax|set_option|attribute|open|namespace|'
                     r'section|end|variable|include|omit|local|scoped|universe)\b')


def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read().splitlines(keepends=True)


def once(lines, pred, what):
    idx = [i for i, l in enumerate(lines) if pred(l)]
    if len(idx) != 1:
        raise SystemExit(f'ANCHOR {what}: found {len(idx)} matches')
    return idx[0]


def regions(lines, final):
    """Return list of (name, start, end) half-open line-index regions."""
    out = []
    imp = once(lines, lambda l: l == 'import TCSlib.Cryptography.Foundations.BitLists\n', 'imp')
    if final:
        out.append(('import', imp + 1, imp + 2))
    else:
        out.append(('import', imp + 1, imp + 1))
    a = once(lines, lambda l: l == '  execution when the garbling is good with distinct output keys.\n',
             'bullet-start')
    b = once(lines, lambda l: l.startswith('* `SecureComputation.yaoHybrid_hbcSecure`'), 'bullet-end')
    out.append(('bullet', a + 1, b))
    for thm, hdr_end in (
            ('yaoHybrid_polyTime',
             '    (yaoHybrid Y E₁ E₂).PolyTime (yaoFunctionality Y) := by\n'),
            ('yaoHybrid_simulators',
             '            ((yaoFunctionality Y).idealB SB n x y) (D.distinguisherL n) ≤ ε n := by\n')):
        h = once(lines, lambda l, t=thm: l.startswith(f'theorem {t} '), thm)
        # sketch: from the last '**Proof sketch.**' line above the header to header-1 (the '-/' line)
        s = max(i for i in range(h) if lines[i].startswith('**Proof sketch.**'))
        if not lines[h - 1].rstrip('\n').endswith('-/'):
            raise SystemExit(f'{thm}: line before header does not close the docstring')
        opener = max(i for i in range(h) if lines[i].startswith('/--'))
        if not opener < s:
            raise SystemExit(f'{thm}: sketch outside its docstring')
        out.append((f'sketch:{thm}', s, h))
        e = h
        while lines[e] != hdr_end:
            e += 1
        nxt = min(i for i in range(e + 1, len(lines)) if lines[i] == 'include hGE₁ hGE₂ in\n')
        if lines[nxt - 1] != '\n':
            raise SystemExit(f'{thm}: no blank line before the next include')
        out.append((f'body:{thm}', e + 1, nxt - 1))
    return out


def mask(lines, regs):
    res = []
    i = 0
    for k, (name, s, e) in enumerate(sorted(regs, key=lambda r: r[1])):
        res.extend(lines[i:s])
        res.append(f'<<MASK {name}>>\n')
        i = e
    res.extend(lines[i:])
    return res


def yao(basep, finalp):
    B, F = read(basep), read(finalp)
    rb, rf = regions(B, False), regions(F, True)
    print('base regions (1-based inclusive lines):')
    for name, s, e in rb:
        print(f'  {name}: {s + 1}-{e}' if e > s else f'  {name}: insertion after line {s}')
    print('final regions:')
    for name, s, e in rf:
        print(f'  {name}: {s + 1}-{e} ({e - s} lines)')
    mb, mf = mask(B, rb), mask(F, rf)
    viol = 0
    if mb == mf:
        print('MASKED_COMPARE: byte-identical outside the six approved regions')
    else:
        sm = difflib.SequenceMatcher(a=mb, b=mf, autojunk=False)
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag != 'equal':
                viol += 1
                print(f'VIOLATION {tag} masked-base {i1 + 1}-{i2} masked-final {j1 + 1}-{j2}')
                for l in mb[i1:i2][:3]:
                    print('   - ' + l.rstrip('\n'))
                for l in mf[j1:j2][:3]:
                    print('   + ' + l.rstrip('\n'))
    # region content rules on the final
    rule = 0
    d = {n: (s, e) for n, s, e in rf}
    s, e = d['import']
    if not HUB_RE.match(F[s]):
        rule += 1
        print('RULE import line is not a single Yao.<Hub> import:', F[s].rstrip())
    hub_imports = [l for l in F if l.startswith('import ')]
    print(f'import lines: base {sum(l.startswith("import ") for l in B)}, final {len(hub_imports)}')
    for n in ('body:yaoHybrid_polyTime', 'body:yaoHybrid_simulators'):
        s, e = d[n]
        for i in range(s, e):
            l = F[i]
            if l.strip() and not l.startswith('  '):
                rule += 1
                print(f'RULE {n}: column-0 line {i + 1}: {l.rstrip()}')
            if re.search(r'\bsorry\b|\badmit\b|\bnative_decide\b', l):
                rule += 1
                print(f'RULE {n}: forbidden token at line {i + 1}')
        print(f'{n}: {e - s} lines')
    for n in ('sketch:yaoHybrid_polyTime', 'sketch:yaoHybrid_simulators'):
        s, e = d[n]
        txt = ''.join(F[s:e])
        if '/-' in txt.replace('-/', ''):
            rule += 1
            print(f'RULE {n}: nested comment opener')
        for i in range(s, e):
            if DECL_RE.match(F[i]):
                rule += 1
                print(f'RULE {n}: declaration-like line {i + 1}')
        print(f'{n}: {e - s} lines; mentions "not yet stated": {"not yet stated" in txt}')
    s, e = d['bullet']
    for i in range(s, e):
        if not (F[i].startswith('* `') or F[i].startswith('  ')):
            rule += 1
            print(f'RULE bullet: odd line {i + 1}')
    print('bullet final text:')
    for i in range(s, e):
        print('   | ' + F[i].rstrip('\n'))
    width = max(len(l.rstrip('\n')) for l in F)
    print(f'lines: base {len(B)}, final {len(F)} (net {len(F) - len(B):+d}); max width {width}')
    print(f'RESULT violations={viol} rule_breaks={rule}')


def circuit(basep, finalp, names):
    B, F = read(basep), read(finalp)
    want = [n for n in names.split(',') if n]
    sm = difflib.SequenceMatcher(a=B, b=F, autojunk=False)
    bad = 0
    found = []
    kept = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            kept.extend(F[j1:j2])
            continue
        if tag != 'insert':
            bad += 1
            print(f'NONINSERT {tag} base {i1 + 1}-{i2} final {j1 + 1}-{j2}')
            kept.extend(F[j1:j2])
            continue
        blk = F[j1:j2]
        # split the inserted block into declarations separated by blank lines
        txt = ''.join(blk)
        thms = re.findall(r'^theorem ([^\s:({]+)', txt, flags=re.M)
        others = [l for l in blk if DECL_RE.match(l) and not l.startswith('theorem ')]
        attrs = [l for l in blk if l.lstrip().startswith('@[')]
        proofs = re.findall(r':= (rfl|Iff\.rfl)\n', txt)
        docs = txt.count('/--')
        # nearest preceding def in the base
        prev = [l for l in B[:i1] if re.match(r'^(private )?def ', l)]
        print(f'INSERT after base line {i1}: theorems={thms} docstrings={docs} '
              f'rfl_proofs={len(proofs)} attrs={len(attrs)} other_cmds={len(others)} '
              f'preceding_def={prev[-1].split(":")[0].strip() if prev else None!r} '
              f'line_before={B[i1 - 1].rstrip()!r}')
        if len(thms) != len(proofs) or len(thms) != docs or attrs or others:
            bad += 1
            print('  BAD block shape')
        found.extend(thms)
    restored = kept == B
    print(f'readers found: {found}')
    print(f'expected: {want}; equal={found == want}')
    print(f'removal of insertions restores base exactly: {restored}')
    width = max(len(l.rstrip("\n")) for l in F)
    print(f'lines: base {len(B)}, final {len(F)}; max width {width}')
    print(f'RESULT bad={bad} restored={restored} names_ok={found == want}')


def block(a, b, name):
    def get(p):
        L = read(p)
        h = once(L, lambda l: l.startswith(f'theorem {name} '), name) if any(
            l.startswith(f'theorem {name} ') for l in L) else once(
            L, lambda l: l.startswith(f'theorem {name}'), name)
        s = h
        while not L[s].startswith('/--'):
            s -= 1
        e = h
        while L[e] != '\n':
            e += 1
        return ''.join(L[s - 1:e + 1]), s
    x, sx = get(a)
    y, sy = get(b)
    print(f'{name}: A block starts line {sx + 1}, B block starts line {sy + 1}; '
          f'byte-identical (with surrounding blank lines): {x == y}')


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'yao':
        yao(sys.argv[2], sys.argv[3])
    elif mode == 'circuit':
        circuit(sys.argv[2], sys.argv[3], sys.argv[4])
    elif mode == 'block':
        block(sys.argv[2], sys.argv[3], sys.argv[4])
