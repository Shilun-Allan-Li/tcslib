"""tailcmp.py <a> <b> <anchor-prefix>: byte-compare two files from the first line starting with the anchor to EOF."""
import sys
def tail(p, a):
    L = open(p, encoding='utf-8').read().split('\n')
    i = next(k for k, l in enumerate(L) if l.startswith(a))
    return '\n'.join(L[i:]), i + 1
x, i = tail(sys.argv[1], sys.argv[3]); y, j = tail(sys.argv[2], sys.argv[3])
print(f'from line {i} (A) / {j} (B) to EOF: byte-identical = {x == y}')
