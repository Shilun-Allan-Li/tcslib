"""stmts.py <worktree> <touched.json> <out.tsv>: header text (keyword .. first top-level `:=`/`where`)
of every new declaration, whitespace-normalized, plus a GENERIC flag when the statement mentions
none of the domain identifiers below (candidates for library-utility duplication)."""
import json, re, sys
wt, tj, out = sys.argv[1:4]
T = json.load(open(tj))['files']
DOMAIN = re.compile(r'garbled|Garble|nestedSpecial|DAGCircuit|DAGGate|GateKind|runWith|evalGate|Protocol|'
                    r'Strategy|Functionality|HybridProtocol|NUPPT|sliceMulti|sliceEnc|spEnc|spDec|keyAt|'
                    r'argKeys|gateOut|inputKeys|MultiEnc|View|PRFOut|tableWith|rowWith|seed|Seed|'
                    r'encWords|getW|pairEncode|pairFstD|pairSndD|Machine|ModuleHost|stateFind|emit|'
                    r'circuit|Circuit|gates|outs|Tagged|Data|innerLen|stage|Stage|Selected|slot|Slot|'
                    r'occurrence|Occurrence|record|plan|advice|budget|Budget')
with open(out, 'w', encoding='utf-8') as o:
    for f, info in T.items():
        lines = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
        for d in info['declarations']:
            if d['status'] not in ('ADDED', 'NEW_FILE') or d['kind'] not in ('theorem', 'lemma'): continue
            blk = lines[d['decl_line'] - 1:d['end']]
            txt = ' '.join(l.strip() for l in blk)
            # cut at the first ':=' at bracket depth 0
            depth = 0; cut = len(txt)
            for i, ch in enumerate(txt):
                if ch in '([{⟨': depth += 1
                elif ch in ')]}⟩': depth -= 1
                elif txt.startswith(':=', i) and depth == 0: cut = i; break
            hdr = txt[:cut].strip()
            gen = 'GENERIC' if not DOMAIN.search(hdr.split(' ', 2)[-1]) else 'domain'
            o.write('\t'.join([gen, 'private' if d['private'] else 'public', d['name'].split('.')[-1],
                               f"{f.split('/')[-1]}:{d['decl_line']}", hdr]) + '\n')
