#!/usr/bin/env python3
"""Verify a delivered SHA256SUMS manifest directly against git blobs (no extraction).

usage: mancheck_git.py <repo> <commit> <prefix> <manifest-relpath-under-prefix> <scope-relpath-or-.>

The manifest's paths are relative to <prefix>/<dirname(manifest)>.  The checked file set is every
blob under that directory, excluding the manifest itself.  Reports path-set equality (missing,
extra, leading './', duplicates) and every byte hash, by streaming blobs via `git cat-file --batch`.
"""
import hashlib
import subprocess
import sys


def main():
    repo, commit, prefix, man = sys.argv[1:5]
    prefix = prefix.rstrip('/')
    mdir = man.rsplit('/', 1)[0] if '/' in man else ''
    root = prefix + ('/' + mdir if mdir else '')
    ls = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', '-z', '--full-tree', commit, root + '/'],
                        capture_output=True, check=True).stdout.split(b'\0')
    blobs = {}
    for ent in ls:
        if not ent:
            continue
        meta, path = ent.split(b'\t', 1)
        mode, typ, sha = meta.split()
        path = path.decode()
        assert path.startswith(root + '/'), path
        blobs[path[len(root) + 1:]] = sha.decode()
    mname = man.rsplit('/', 1)[-1]
    text = subprocess.run(['git', '-C', repo, 'show', f'{commit}:{prefix}/{man}'],
                          capture_output=True, check=True).stdout.decode()
    entries = []
    bad_lines = 0
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split('  ', 1)
        if len(parts) != 2 or len(parts[0]) != 64:
            bad_lines += 1
            continue
        entries.append((parts[0], parts[1]))
    names = [p for _, p in entries]
    dot = [p for p in names if p.startswith('./')]
    dups = len(names) - len(set(names))
    files = set(blobs) - {mname}
    missing = sorted(set(names) - files)
    extra = sorted(files - set(names))
    # stream hashes
    want = [(h, p) for h, p in entries if p in blobs]
    proc = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE)
    ok = 0
    mism = []
    for h, p in want:
        proc.stdin.write((blobs[p] + '\n').encode())
        proc.stdin.flush()
        hdr = proc.stdout.readline().split()
        size = int(hdr[2])
        data = proc.stdout.read(size)
        proc.stdout.read(1)
        if hashlib.sha256(data).hexdigest() == h:
            ok += 1
        else:
            mism.append(p)
    proc.stdin.close()
    proc.wait()
    print(f'manifest {prefix}/{man}: entries={len(entries)} malformed_lines={bad_lines} '
          f'leading_dot={len(dot)} duplicates={dups}')
    print(f'files_under_dir_excluding_manifest={len(files)} missing_from_tree={len(missing)} '
          f'extra_in_tree={len(extra)}')
    print(f'hash_ok={ok}/{len(entries)} mismatches={len(mism)}')
    for p in missing[:20]:
        print('MISSING', p)
    for p in extra[:20]:
        print('EXTRA', p)
    for p in mism[:20]:
        print('MISMATCH', p)
    clean = not (bad_lines or dot or dups or missing or extra or mism)
    print('RESULT', 'OK' if clean else 'FAIL')


if __name__ == '__main__':
    main()
