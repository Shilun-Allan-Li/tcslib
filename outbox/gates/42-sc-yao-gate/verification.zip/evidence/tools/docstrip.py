"""docstrip.py <repo> <rev-a> <rev-b>: for every .lean file changed between the revs, strip block comments
(nested `/- -/`, including doc and module comments), line comments and string-free whitespace, and compare the
remaining token streams. Prints per-file CODE-EQUAL / CODE-DIFF, plus line counts and max widths at rev-b."""
import re, subprocess, sys
repo, a, b = sys.argv[1:4]
git = lambda *x: subprocess.run(['git', '-C', repo, *x], capture_output=True, text=True).stdout
def strip(s):
    out, i, depth = [], 0, 0
    while i < len(s):
        if s.startswith('/-', i): depth += 1; i += 2; continue
        if depth and s.startswith('-/', i): depth -= 1; i += 2; continue
        if depth: i += 1; continue
        if s.startswith('--', i):
            j = s.find('\n', i); i = len(s) if j < 0 else j; continue
        out.append(s[i]); i += 1
    return ' '.join(''.join(out).split())
files = [f for f in git('diff', '--name-only', a, b).split() if f.endswith('.lean')]
bad = 0; mw = 0; ml = 0
for f in files:
    x, y = strip(git('show', f'{a}:{f}')), strip(git('show', f'{b}:{f}'))
    src = git('show', f'{b}:{f}').split('\n')[:-1]
    mw = max(mw, max(len(l) for l in src)); ml = max(ml, len(src)) if not f.endswith('SecureComputation/Yao.lean') else ml
    ok = x == y; bad += not ok
    print(('CODE-EQUAL' if ok else 'CODE-DIFF'), f, len(src))
print(f'files {len(files)}; code-different {bad}; max width {mw}; max lines (excluding Yao.lean) {ml}')
