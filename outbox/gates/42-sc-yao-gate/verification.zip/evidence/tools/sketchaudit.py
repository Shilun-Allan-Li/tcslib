"""sketchaudit.py <worktree> <touched.json> [min-proof-lines]: for every touched theorem (private
included), the proof length (lines from the declaration's `:= by`/`:=` to the span end) and whether
its docstring carries `**Proof sketch`. Lists theorems with proofs of at least min lines (default 15)
and no sketch."""
import json, re, sys
wt, tj = sys.argv[1:3]; mn = int(sys.argv[3]) if len(sys.argv) > 3 else 15
t = json.load(open(tj))['files']; tot = miss = 0
for f, info in t.items():
    lines = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    for d in info['declarations']:
        if not d['touched'] or d['kind'] not in ('theorem', 'lemma'): continue
        block = lines[d['start'] - 1:d['end']]
        txt = '\n'.join(block)
        m = re.search(r':=\s*(by)?\s*$', txt, re.M)
        k = next((i for i, l in enumerate(block) if re.search(r':=\s*(by\b.*)?$', l)), 0)
        n = len([l for l in block[k + 1:] if l.strip()])
        if n < mn: continue
        tot += 1; sk = '**Proof sketch' in txt
        if not sk:
            miss += 1
            print(f"NO-SKETCH\t{f.split('PrivateKey/')[-1]}:{d['start']}\t{d['name'].split('Composability.')[-1]}\t{'private' if d['private'] else 'public'}\t{n}")
print(f'TOTAL theorems with >= {mn} proof lines: {tot}; without sketch: {miss}')
