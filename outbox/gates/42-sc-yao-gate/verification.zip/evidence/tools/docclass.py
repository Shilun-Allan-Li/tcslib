"""docclass.py <docaudit.tsv>: refine docaudit rows: STRICT (backticked relation), PROSE (a
backticked term plus a prose relation word), NONE (no backticked term). Counts by kind."""
import re, sys, collections
REL = re.compile(r'`[^`]*(=|≤|<|≥|>|↔|≃|∈|≠|→)[^`]*`')
WORD = re.compile(r'\b(is|are|equals?|at most|at least|bounded|reads?|gives?|maps?|returns?|computes?)\b')
cnt = collections.Counter(); rows = []
for line in open(sys.argv[1], encoding='utf-8'):
    f = line.rstrip('\n').split('\t')
    if len(f) < 4: continue
    flag, loc, name, kind = f[:4]; doc = f[4] if len(f) > 4 else ''
    if flag == 'NO-DOC': c = 'NODOC'
    elif REL.search(doc) or flag == 'OK': c = 'STRICT'
    elif '`' in doc and WORD.search(doc): c = 'PROSE'
    else: c = 'NONE'
    cnt[(kind, c)] += 1; rows.append((c, kind, loc, name, doc))
for k in sorted(cnt): print(k, cnt[k])
for r in rows:
    if r[0] in ('NONE', 'NODOC') and r[1] == 'theorem': print('\t'.join(r)[:240])
