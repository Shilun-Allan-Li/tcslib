"""docaudit2.py <worktree> <touched.json>: for every touched public declaration, classify its
full docstring (text before **Proof sketch**): STRICT = a backticked span with a relation symbol
(=, ≤, <, ↔, ≃, ∈, ≠, →, ...); PROSE = a backticked term and a relation word in prose; NONE = no
backticked formula; NODOC = no docstring. Also flags PolyTimeComputable-style statements whose
docstring never names `PolyTimeComputable`. Prints counts by kind, then NONE/NODOC rows."""
import json, re, sys, collections
wt, tj = sys.argv[1:3]
t = json.load(open(tj))['files']
REL = re.compile(r'`[^`]*(=|≤|<|≥|>|↔|≃|∈|≠|→|⊆)[^`]*`')
WORD = re.compile(r'\b(is|are|equals?|at most|at least|bounded|reads?|gives?|maps?|returns?|computes?)\b')
cnt = collections.Counter(); out = []
for f, info in t.items():
    lines = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    for d in info['declarations']:
        if not d['touched'] or d['private']: continue
        block = '\n'.join(lines[d['start'] - 1:d['end']])
        m = re.match(r'\s*/--(.*?)-/', block, re.S)
        if not m: c = 'NODOC'; doc = ''
        else:
            doc = m.group(1).split('**Proof sketch')[0]
            if REL.search(doc): c = 'STRICT'
            elif '`' in doc and WORD.search(doc): c = 'PROSE'
            else: c = 'NONE'
        cnt[(d['kind'], c)] += 1
        out.append((c, d['kind'], f'{f}:{d["start"]}', d['name'].split('YaoHybridProof.')[-1], ' '.join(doc.split())[:150]))
for k in sorted(cnt): print('COUNT', k, cnt[k])
for r in out:
    if r[0] in ('NONE', 'NODOC'): print('\t'.join(r))
