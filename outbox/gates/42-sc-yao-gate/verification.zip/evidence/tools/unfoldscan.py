"""unfoldscan.py <tip-tree> <sc-yao-tree> <files...>: explicit-unfold scan. Index every TCSlib
`def`/`abbrev`/`instance`/`structure` name (short and dotted suffixes) of <tip-tree> (non-helper
files) and of each helper file; then, for every tactic-list identifier in `simp only [..]`,
`simp [..]`, `dsimp [..]`, `rw [..]`, `rwa [..]`, `unfold ..`, `delta ..`, `simp_rw [..]`, `nth_rw`,
`erw`, or a `X.eq_1`/`X.eq_def`/`X.def` term in the given files, report references that resolve to
a definition declared in a different file (foreign) by short name. Reports candidates only."""
import os, re, sys
tip, yt = sys.argv[1:3]
files = sys.argv[3:]
DEF = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|partial|unsafe)\s+)*(def|abbrev|instance|structure|inductive|class)\s+([^\s(:{\[]+)')
defs = {}
def index(path, rel):
    ns = []
    for l in open(path, encoding='utf-8'):
        m = re.match(r'^namespace\s+(\S+)', l)
        if m: ns.append(m.group(1)); continue
        m = re.match(r'^end\s+(\S+)\s*$', l)
        if m and ns and ns[-1] == m.group(1): ns.pop(); continue
        m = DEF.match(l)
        if m:
            n = m.group(2); full = n[7:] if n.startswith('_root_.') else '.'.join(ns + [n])
            defs.setdefault(full.split('.')[-1], set()).add((full, rel))
for r, _, fs in os.walk(os.path.join(tip, 'TCSlib')):
    for f in fs:
        if f.endswith('.lean'):
            p = os.path.join(r, f); rel = os.path.relpath(p, tip)
            if '/Yao/HybridProof' in rel or rel.endswith('SecureComputation/Yao.lean'): continue
            index(p, rel)
for f in files: index(os.path.join(yt, f), f)
TAC = re.compile(r'\b(simp only|simp|dsimp only|dsimp|rw|rwa|erw|simp_rw|nth_rw \d+|rewrite|simpa only|simpa)\s*\[([^\]]*)\]')
UNF = re.compile(r'\b(unfold|delta)\s+([^\n]+)')
EQ = re.compile(r'\b([A-Za-z_][\w.\']*)\.(eq_\d+|eq_def|def)\b')
hits = 0; refs = 0
for f in files:
    txt = open(os.path.join(yt, f), encoding='utf-8').read()
    txt = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), txt, flags=re.S)
    for ln, line in enumerate(txt.split('\n'), 1):
        line = line.split('--')[0]
        names = []
        for m in TAC.finditer(line):
            names += [x.strip().lstrip('←').strip() for x in m.group(2).split(',')]
        for m in UNF.finditer(line):
            names += m.group(2).split()
        names += [m.group(1) for m in EQ.finditer(line)]
        for n in names:
            n = re.sub(r'\s.*', '', n)
            if not n or not re.match(r'^[A-Za-z_]', n): continue
            refs += 1
            short = n.split('.')[-1]
            cands = [c for c in defs.get(short, set()) if c[0].endswith(n) or n.endswith(c[0].split('.')[-1])]
            foreign = [c for c in cands if c[1] != f]
            own = [c for c in cands if c[1] == f]
            if foreign and not own:
                hits += 1
                print(f'CANDIDATE\t{f}:{ln}\t{n}\t{sorted(foreign)[:3]}')
print(f'tactic references scanned: {refs}; foreign-definition candidates: {hits}')
