# loose variant: short identifiers (1-3 chars) replaced by _ before comparison
"""tipstmts.py <tree> <stmts.tsv>: index every theorem/lemma header in <tree>/TCSlib (statement text
after the name, whitespace-normalized, binder names alpha-normalized crudely by stripping binder
identifiers) and report sc-yao statements whose normalized body equals a tip statement."""
import os, re, sys
tree, st = sys.argv[1:3]
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(theorem|lemma)\s+(\S+)')
def norm(body):
    b = ' '.join(body.split())
    # strip binder names: (x y : T) -> (: T)
    b = re.sub(r'([({\[])\s*[^:(){}\[\]]*?\s:', r'\1:', b)
    b = re.sub(r"(?<![A-Za-z0-9_.])[a-zA-Zα-ωΑ-Ω][a-zA-Z0-9₀-₉']{0,2}(?![A-Za-z0-9_.])", "_", b)
    return b
def header(lines, i):
    txt = ' '.join(l.strip() for l in lines[i:i + 40])
    m = KW.match(txt)
    rest = txt[m.end():]
    depth = 0
    for k, ch in enumerate(rest):
        if ch in '([{⟨': depth += 1
        elif ch in ')]}⟩': depth -= 1
        elif rest.startswith(':=', k) and depth == 0: return m.group(2), rest[:k]
    return m.group(2), rest
idx = {}
for r, _, fs in os.walk(os.path.join(tree, 'TCSlib')):
    for f in fs:
        if not f.endswith('.lean'): continue
        p = os.path.join(r, f)
        if '/SecureComputation/Yao/HybridProof' in p: continue
        L = open(p, encoding='utf-8').read().split('\n')
        for i, l in enumerate(L):
            if KW.match(l):
                n, b = header(L, i)
                idx.setdefault(norm(b), []).append((n, os.path.relpath(p, tree), i + 1))
hits = 0
for line in open(st, encoding='utf-8'):
    gen, vis, name, loc, hdr = line.rstrip('\n').split('\t')
    m = re.match(r'^(?:private )?theorem \S+', hdr)
    b = norm(hdr[m.end():])
    if b in idx and not loc.startswith(('Uniform.lean', 'DAGCircuit.lean')):
        hits += 1
        print('MATCH', name, loc, '->', idx[b][:3])
print('indexed tip statements:', sum(len(v) for v in idx.values()), 'matches:', hits)
