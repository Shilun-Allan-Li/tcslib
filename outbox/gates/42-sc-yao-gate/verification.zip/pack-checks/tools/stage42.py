"""stage42.py <repo> <gate-dir> <exchange-wt> <tools-dir>: write the outbox of Gate 42 (sc-yao, draft PR #341) in the
layout of the Gate 36 pack: README.md, pack.md, bundle.md, BUNDLE-FILES.txt, LEAN-HEAD.txt, RECORDS.txt, SHA256SUMS,
byte copies of the gate directory's pack files (pack.md, pr-description.md, pr.diff.txt, source-head.json, sources.zip,
verification.zip; checked against the gate directory's SHA256SUMS), review.md, post-merge-addendum.md and the review's
landing PROVENANCE (records pin), worker-report.md (the delivery's REPORT.md at the final exchange commit) and landing/
(byte copies of review-evidence entries: the build, the state check, the axioms census, the frozen-scope checks).

The gate directory is the records working tree's briefs/pass-shelat-ch5-8/gates/42-sc-yao/, written before the
maintainer commits it; so the bundle's pack sections are read from the pack files (`pack` and `zip:` sources of
mkbundle42.py), and its records sections from the records pin by `git show`.

pincheck: before writing, every verification.zip member whose PROVENANCE source is a git object (records at the pin or
the interim commit, the exchange delivery, 201bf57a, the head) or a review-evidence entry is compared with that source,
byte for byte, or the stage stops."""
import hashlib, os, re, subprocess, sys, zipfile, io, tempfile

repo, gdir, wt, tools = sys.argv[1:5]
PIN = 'f22e0f6798815b9263893e61928b4f16452f74ee'
RUL = '67423db6c9d6448ae531b04f42c315585d00d502'
HEAD = 'e9b03c437aca251846430ff23b40ee5ff3d3347a'
BASE = 'f9fda8fe8d11fc68c233df2979a86d356ddfe1ab'
CUR = '201bf57a941131d1737295089ffd7477e1d7f7b9'
INTERIM = '9902d727b89dc8ff8be77ddbe677371c7a4f6158'
FINAL = '47c38c479e4be52654cd2c055141dfb64be975c4'
EV = 'briefs/pass-shelat-ch5-8/fills/sc-yao/final-r1/'
IS = 'briefs/pass-shelat-ch5-8/fills/sc-yao/issued-r1/'
G = 'briefs/pass-shelat-ch5-8/gates/42-sc-yao'
OUT = 'outbox/gates/42-sc-yao-gate'
SC = 'TCSlib/Cryptography/SecureComputation/'
REVS = {r[:8]: r for r in (PIN, RUL, INTERIM, HEAD, CUR)} | {FINAL[:9]: FINAL}
sha = lambda b: hashlib.sha256(b).hexdigest()


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


show = lambda rev, path: git('show', f'{rev}:{path}')
PACK = ['pack.md', 'pr-description.md', 'pr.diff.txt', 'source-head.json', 'sources.zip', 'verification.zip']
rows = [l.split('  ', 1) for l in open(os.path.join(gdir, 'SHA256SUMS'), encoding='utf-8').read().splitlines() if l]
assert sorted(p for _, p in rows) == sorted(PACK), 'records SHA256SUMS lists exactly the pack files'
files = {}
for h, p in rows:
    b = open(os.path.join(gdir, p), 'rb').read()
    assert sha(b) == h, f'records SHA256SUMS: {p}'
    files[p] = b
print(f'records {G}/SHA256SUMS: {len(rows)}/{len(rows)} verify')

# pincheck
zb = show(PIN, EV + 'review-evidence.zip')
evz = zipfile.ZipFile(io.BytesIO(zb))
vz = zipfile.ZipFile(io.BytesIO(files['verification.zip']))
prov = vz.read('PROVENANCE.txt').decode()
src = re.findall(r'^  (\S+)  <-  (.*)$', prov.split('\nSources:\n', 1)[1], re.M)
n_git = n_ev = n_other = 0
for member, d in src:
    b = vz.read(member)
    m = re.match(r'(?:records |exchange |head |201bf57a \(#327, #324 merged\) )([0-9a-f]{8,9}):(\S+)$', d)
    if m:
        assert b == show(REVS[m.group(1)], m.group(2)), f'pincheck: {member}'
        n_git += 1
        continue
    m = re.match(r'review-evidence\.zip entry (\S+) ', d)
    if m:
        assert b == evz.read(m.group(1)), f'pincheck: {member}'
        n_ev += 1
        continue
    n_other += 1
print(f'pincheck: {n_git} members equal to their git objects, {n_ev} equal to their review-evidence entries; '
      f'{n_other} generated, re-check or PR members')

out = {p: files[p] for p in PACK}
out['review.md'] = show(PIN, EV + 'review.md')
out['post-merge-addendum.md'] = show(PIN, EV + 'post-merge-addendum.md')
out['rulings.md'] = show(RUL, EV + 'rulings.md')
out['worker-report.md'] = show(FINAL, 'inbox/fills/sc-yao/REPORT.md')
LANDING = {'landing/build-summary.txt': 'phase2/build-head/summary.txt',
           'landing/root-checks.jsonl': 'phase2/build-head/results.jsonl',
           'landing/tree-check-head.txt': 'phase2/build-head/statecheck.txt',
           'landing/census-head.log': 'phase2/probe-runs/mods/ScYaoProbe_AxiomsLand.log',
           'landing/axioms-summary.txt': 'phase2/axioms-summary.txt',
           'landing/frozen-check.txt': 'landing/yao-scope-vs-tip-final.txt',
           'landing/uniform-check.txt': 'landing/uniform-scope-vs-tip.txt'}
for k, v in LANDING.items():
    out[k] = evz.read(v)
helpers = sorted(p for p in git('ls-tree', '-r', '--name-only', HEAD, SC + 'Yao/').decode().split())
listing = [('pack', 'pack.md', f'{G}/pack.md'), (PIN, 'policy.md'), (PIN, EV + 'review.md'),
           (PIN, EV + 'post-merge-addendum.md'), (PIN, EV + 'landing/PROVENANCE.txt'),
           (INTERIM, EV + 'review.md', f'{EV}review.md@{INTERIM[:8]}-interim-phase1'),
           (FINAL, 'inbox/fills/sc-yao/REPORT.md'), (PIN, IS + 'README.md'), (PIN, IS + 'brief.md'),
           (PIN, IS + 'ruling-SY.md'), (RUL, EV + 'rulings.md', f'{EV}rulings.md@{RUL[:8]}'),
           (RUL, 'briefs/pass-shelat-ch5-8/duplication-ledger.md',
            f'briefs/pass-shelat-ch5-8/duplication-ledger.md@{RUL[:8]}'),
           (RUL, 'briefs/pass-shelat-ch5-8/deferred-work.md', f'briefs/pass-shelat-ch5-8/deferred-work.md@{RUL[:8]}'),
           (PIN, 'briefs/pass-shelat-ch5-8/gates/27-b1-multimsg/resolutions-r1.md'),
           ('pack', 'pr-description.md', f'{G}/pr-description.md')]
listing += [('zip:verification.zip', f'pack-checks/{c}') for c in
            ('frozen-files.diff', 'frozen.txt', 'lecheck.txt', 'dupscan.txt', 'sources.txt', 'names.txt',
             'mergetrees.txt', 'rule10.txt')]
listing += [('zip:sources.zip', 'PS10/README.md'), ('zip:sources.zip', 'PS10/ps10-6.2-book-pp154-164.txt')]
listing += [(HEAD, SC + 'Yao.lean'), (HEAD, 'TCSlib/Complexity/CircuitComplexity/Uniform.lean')]
listing += [(HEAD, p) for p in helpers]
listing += [(HEAD, SC + f + '.lean') for f in ('Defs', 'Hybrid', 'Garbling', 'GarblingSpecial', 'SpecialEncryptionMulti',
                                               'YaoReal')]
listing += [(CUR, 'TCSlib/Cryptography/Composability/SequentialZK/Normalization.lean'),
            (CUR, SC + 'ComposeSecurity/Lengths.lean')]
out['BUNDLE-FILES.txt'] = ''.join(' '.join(x) + '\n' for x in listing).encode()
od = os.path.join(wt, OUT)
assert not os.path.exists(od), od
os.makedirs(os.path.join(od, 'landing'))
for p, b in out.items():
    open(os.path.join(od, p), 'wb').write(b)
with tempfile.TemporaryDirectory() as td:
    lp, bp = os.path.join(td, 'list.txt'), os.path.join(td, 'bundle.md')
    open(lp, 'wb').write(out['BUNDLE-FILES.txt'])
    r = subprocess.run([sys.executable, '-I', os.path.join(tools, 'mkbundle42.py'), repo, od, bp, lp],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    print('mkbundle42:', r.stdout.strip())
    out['bundle.md'] = open(bp, 'rb').read()
out['LEAN-HEAD.txt'] = f'#341 {HEAD}\n'.encode()
out['RECORDS.txt'] = f'{PIN}\n'.encode()
n_help = len(helpers)
out['README.md'] = f"""# Codex audit · Gate 42 sc-yao (#341)

Audit draft PR #341 at {HEAD} using the scope in pack.md: a **proof audit** of the two frozen
Yao targets `yaoHybrid_polyTime` and `yaoHybrid_simulators` (and the derived `yaoHybrid_hbcSecure`), Yao's
garbled-circuit protocol in the bit-transfer (OT) hybrid model [PS10, Protocol 162.6, Theorem 163.7], with the frozen
`Yao.lean` regions, the seven SY-3 readers in `Uniform.lean`, the landing edits LE-bullet, LE-reuse, LE-title and LE-doc,
duplication (SY-F01 to SY-F12), Rule 10, and the docstring, sketch, sources and evidence rules.
Campaign records are pinned at {PIN}; Seyoon's rulings on SY-F01 to SY-F03 (ledger rows DL-51 and the
DL-49 extension) are recorded after the pin, at {RUL}.

The bundle contains the pack, policy, the maintainer's final review, its post-merge addendum and landing PROVENANCE,
the interim (Phase 1) review it supersedes, the worker report, the issued package's README, brief and rulings SY-1 to
SY-6, Seyoon's rulings on SY-F01 to SY-F03 with the duplication ledger and deferred-work register as they stand after
them (records commit {RUL}, after the pin), Gate 27's resolutions (the hand-off obligations), the PR
description, the frozen files' diff and the pack's main re-checks, the PS10 §6.2 excerpt (text), `Yao.lean` and
`Uniform.lean` at the head, the hub and its {n_help - 1} helpers at the head, and as context six frozen
SecureComputation files at the head (Defs, Hybrid, Garbling, GarblingSpecial, SpecialEncryptionMulti, YaoReal) and the
two #327/#324 files the duplication findings compare against, at 201bf57a.

Also:
- pr.diff.txt: the full diff from the PR's merge base {BASE} to the head (70 paths);
- pr-description.md: the PR description as read on GitHub;
- source-head.json: the head hashes, line counts and over-width counts of the changed files;
- sources.zip: the source closure at the head of every changed module (TCSlib/), and PS10/: [PS10] §6.2 (book pages
  154-164) from the PDF at the records pin, as PDF pages and as text, with a README;
- verification.zip: the review's manifest and a pointer to its 19 MB evidence ZIP at its committed path at the records
  pin, byte copies of every evidence entry the pack cites, the cited records, the worker extracts (worker/), context
  files, the PR data, and the pack's git-object re-checks with their scripts (pack-checks/); its entries are exactly
  its SHA256SUMS plus SHA256SUMS;
- review.md, post-merge-addendum.md: the maintainer's final review and addendum (records pin); rulings.md: Seyoon's
  rulings on SY-F01 to SY-F03 (records commit {RUL[:8]});
- worker-report.md: the worker's REPORT.md at the final delivery {FINAL}.

landing/ holds byte copies of review-evidence entries (the build summary and results, the whole-order state check, the
axioms census and summary, the Yao.lean and Uniform.lean scope checks against the tip). The worker's own evidence is
on this branch under inbox/fills/sc-yao/ (final delivery commit {FINAL}).

Check SHA256SUMS before using the pack.

Return gate42-sc-yao-findings.md as Markdown in the chat. If you have several evidence files, return a ZIP
containing that Markdown and the evidence. The user dispatches and merges.
""".encode()
for p in ('LEAN-HEAD.txt', 'RECORDS.txt', 'README.md', 'bundle.md'):
    open(os.path.join(od, p), 'wb').write(out[p])
out['SHA256SUMS'] = ''.join(f'{sha(out[p])}  {p}\n' for p in sorted(out)).encode()
open(os.path.join(od, 'SHA256SUMS'), 'wb').write(out['SHA256SUMS'])
for p in out:
    assert open(os.path.join(od, p), 'rb').read() == out[p]
on_disk = sorted(os.path.relpath(os.path.join(a, f), od) for a, _, fs in os.walk(od) for f in fs)
assert on_disk == sorted(out), (on_disk, sorted(out))
print(f'{OUT}: {len(out)} files; SHA256SUMS {sha(out["SHA256SUMS"])}; bundle {sha(out["bundle.md"])} '
      f'({len(listing)} sections, {len(out["bundle.md"])} bytes); verification.zip {sha(out["verification.zip"])}; '
      f'sources.zip {sha(out["sources.zip"])}')
