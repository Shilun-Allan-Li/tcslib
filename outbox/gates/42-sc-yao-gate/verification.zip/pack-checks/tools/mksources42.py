"""mksources42.py <repo> <out-dir>: the Gate 42 source files (sc-yao, draft PR #341), from git objects only (the layout of
mksources43.py, one PR):
- pr.diff.txt = git diff f9fda8fe..e9b03c43, the PR's merge base with the records pin to its head (= the three-dot diff
  pin...head, which GitHub shows);
- source-head.json: the head, the base and the records pin, and for each changed file its status, SHA-256, line count
  and lines over 100 characters (the layout of Gate 36's source-head.json, with `base` and `records_pin` added);
- sources.zip:
  - TCSlib/: the import closure at the head of every changed module (TCSlib modules), which contains the frozen
    statements' files (Yao.lean, Uniform.lean, DAGCircuit.lean) and every file they and the helpers read;
  - PS10/: the source the targets cite, [PS10] §6.2 (book pages 154-164, PDF pages 166-176 of "Pass–Shelat.pdf" at the
    records pin): the 11 pages as a PDF (pypdf page extract, byte-deterministic) and as text (`pdftotext -layout`,
    pages separated by form feeds), with a README giving the provenance and where each cited item is. There is no
    curated chapter-6 transcription in blueprint/src/references/ at the pin (only chapters 2-4 and the appendix).
  Directory entries first, then files, each sorted; files deflated (the PDF stored); dated 2026-11-16.
Requires pdftotext (poppler) and pypdf; prints their versions into the README."""
import hashlib, io, json, os, subprocess, sys, tempfile, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure  # noqa: E402

repo, out = sys.argv[1:3]
R = Repo(repo)
PIN = 'f22e0f6798815b9263893e61928b4f16452f74ee'
HEAD = 'e9b03c437aca251846430ff23b40ee5ff3d3347a'
BASE = R.git('merge-base', PIN, HEAD).stdout.strip()
assert BASE == 'f9fda8fe8d11fc68c233df2979a86d356ddfe1ab'
DATE = (2026, 11, 16, 0, 0, 0)
os.makedirs(out, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()

diff = R.gitb('diff', f'{BASE}..{HEAD}')
assert diff == R.gitb('diff', f'{PIN}...{HEAD}')
open(os.path.join(out, 'pr.diff.txt'), 'wb').write(diff)
st = {}
for l in R.git('diff', '--name-status', '--no-renames', BASE, HEAD).stdout.splitlines():
    s, p = l.split('\t')
    st[p] = s
meta = {}
for p in sorted(st):
    b = R.blob(HEAD, p)
    t = b.decode('utf-8')
    meta[p] = dict(status=st[p], sha256=sha(b), lines=len(t.splitlines()),
                   lines_over_100=sum(len(x) > 100 for x in t.splitlines()))
js = json.dumps(dict(rev=HEAD, base=BASE, records_pin=PIN, files=meta,
                     deleted=sorted(p for p, s in st.items() if s == 'D')), indent=1, ensure_ascii=False)
open(os.path.join(out, 'source-head.json'), 'w', encoding='utf-8').write(js)

g = R.graph(HEAD)
clo = sorted(p for p in set().union(*[closure(g, [p]) for p in st if p.endswith('.lean')]) if p.startswith('TCSlib'))
entries = [(p, R.blob(HEAD, p)) for p in clo]

# PS10 §6.2 from the PDF at the pin
pdf = R.gitb('show', f'{PIN}:Pass–Shelat.pdf')
pdfblob = R.git('rev-parse', f'{PIN}:Pass–Shelat.pdf').stdout.strip()
F, T = 166, 176                      # PDF pages; book page = PDF page - 12
with tempfile.TemporaryDirectory() as td:
    pp = os.path.join(td, 'ps10.pdf')
    open(pp, 'wb').write(pdf)
    txt = subprocess.run(['pdftotext', '-layout', '-f', str(F), '-l', str(T), pp, '-'], capture_output=True,
                         check=True).stdout
    ver = subprocess.run(['pdftotext', '-v'], capture_output=True, text=True).stderr.splitlines()[0]
import pypdf  # noqa: E402
rd = pypdf.PdfReader(io.BytesIO(pdf))
w = pypdf.PdfWriter()
for i in range(F - 1, T):
    w.add_page(rd.pages[i])
bio = io.BytesIO(); w.write(bio); ex_pdf = bio.getvalue()
pages = txt.decode('utf-8').split('\f')
LOC = [('Definition 155.1 (two-party honest-but-curious secure protocol)', 'definition 155.1', '155–156'),
       ('§6.2.1 Circuit Representations (fan-in two)', '6.2.1', '156'),
       ('§6.2.2 Garbled Wires; Algorithm 157.2 (special encryption); the unnumbered wrong-key property, inventory '
        '"Claim 157.a"', 'algorithm 157.2', '157'),
       ('§6.2.3 Garbled Gates: the permuted doubly-encrypted tables, inventory "Construction 158.a"; one row decrypts, '
        'inventory "Claim 159.a"; Figure 159.3', '6.2.3', '157–159'),
       ('§6.2.4 Oblivious Transfer; Protocol 160.4; Proposition 161.5', 'protocol 160.4', '160–162'),
       ('§6.2.5; Protocol 162.6 (honest-but-curious secure computation)', 'protocol 162.6', '162–163'),
       ('Theorem 163.7 and its proof (the simulators S_A, S_B; "using a hybrid argument")', 'theorem 163.7', '163–164')]
rows = []
for label, key, span in LOC:
    hit = [154 + i for i, pg in enumerate(pages) if key in pg.lower()]
    rows.append(f'| {label} | {span} | {", ".join(map(str, hit))} |')
readme = f"""# PS10 §6.2 (Yao circuit evaluation): the source excerpt for Gate 42

[PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 2010: the PDF committed as `Pass–Shelat.pdf` at the
root of the records branch, blob `{pdfblob}` at the records pin `{PIN}` (SHA-256 `{sha(pdf)}`, {len(pdf)} bytes, {len(rd.pages)}
pages). Book page = PDF page − 12.

- `ps10-6.2-book-pp154-164.pdf`: PDF pages {F}–{T} (book pages 154–164), extracted with pypdf {pypdf.__version__} (`PdfWriter`,
  the pages unchanged; byte-deterministic). SHA-256 `{sha(ex_pdf)}`.
- `ps10-6.2-book-pp154-164.txt`: the same pages as text, `pdftotext -layout -f {F} -l {T}` ({ver}), pages separated by
  form feeds; mathematics and figures are garbled in places, so read the PDF where they matter. SHA-256 `{sha(txt)}`.

This is a mechanical extraction for convenience, not a curated transcription: `blueprint/src/references/` at the pin has
PS10 transcriptions only for chapters 2–4 and the appendix (`pass-shelat-2010-ch{{2,3,4}}.raw.md`,
`pass-shelat-2010-appendix.raw.md`), and `sources.json` registers no PS10 tag. The PDF is authoritative.

The labels "Claim 157.a", "Construction 158.a" and "Claim 159.a" are the campaign inventory's names for unnumbered text
(`briefs/pass-shelat-ch5-8/inventory-ch5-8.md`; the secure-computation plan, §0). Book pages of the cited items:

| Item | Book pages | Its label or heading found on (text) |
|---|---|---|
""" + '\n'.join(rows) + '\n'
ps = [('PS10/README.md', readme.encode()), ('PS10/ps10-6.2-book-pp154-164.pdf', ex_pdf),
      ('PS10/ps10-6.2-book-pp154-164.txt', txt)]
entries += ps
names = [e[0] for e in entries]
dirs = sorted({'/'.join(p.split('/')[:k]) + '/' for p in names for k in range(1, p.count('/') + 1)})
with zipfile.ZipFile(os.path.join(out, 'sources.zip'), 'w') as z:
    for name in dirs:
        zi = zipfile.ZipInfo(name, date_time=DATE); zi.create_system = 3
        zi.external_attr = 0o40755 << 16
        z.writestr(zi, b'')
    for name, b in sorted(entries):
        zi = zipfile.ZipInfo(name, date_time=DATE); zi.create_system = 3
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_STORED if name.endswith('.pdf') else zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
print(f'pr.diff.txt {len(diff)} bytes sha256 {sha(diff)} ({R.git("diff", "--shortstat", BASE, HEAD).stdout.strip()})')
print(f'source-head.json {len(meta)} files sha256 {sha(js.encode())}')
print(f'sources.zip: {len(clo)} TCSlib files + {len(ps)} PS10 files ({len(dirs)} directories), sha256 '
      f'{sha(open(os.path.join(out, "sources.zip"), "rb").read())}')
print(readme)
