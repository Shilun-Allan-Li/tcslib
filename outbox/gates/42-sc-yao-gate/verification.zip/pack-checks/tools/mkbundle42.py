"""mkbundle42.py <repo> <pack-dir> <out.md> <list.txt>: the maintainer's mkbundle2.py
(briefs/pass-shelat-ch5-8/maintainer/tools/mkbundle2.py) extended with two non-git section sources, for a pack whose own
files are not committed yet. list.txt lines: '<source> <path> [<label>]', where <source> is
  - a 40-hex revision: the section is `git show <rev>:<path>`;
  - `pack`: the section is the file <pack-dir>/<path> (a file of this pack, listed in the pack's SHA256SUMS);
  - `zip:<name>`: the section is the member <path> of the ZIP <pack-dir>/<name>.
Each section is '## ===== <label> =====' + blank line + the file's bytes (+ newline if missing); the default label is
the path, prefixed `<name>:` for a ZIP member. Verified by splitting the output back and comparing every section with
its source, as mkbundle2.py does."""
import hashlib, os, re, subprocess, sys, zipfile

repo, pdir, out, lst = sys.argv[1:5]
items = []
for l in open(lst, encoding='utf-8'):
    if not l.strip():
        continue
    f = l.split()
    src, path = f[0], f[1]
    label = f[2] if len(f) > 2 else (f'{src[4:]}:{path}' if src.startswith('zip:') else path)
    assert re.fullmatch(r'[0-9a-f]{40}', src) or src == 'pack' or src.startswith('zip:'), src
    items.append((src, path, label))
assert len({lab for _, _, lab in items}) == len(items), 'duplicate labels'


def get(src, path):
    if src == 'pack':
        b = open(os.path.join(pdir, path), 'rb').read()
    elif src.startswith('zip:'):
        b = zipfile.ZipFile(os.path.join(pdir, src[4:])).read(path)
    else:
        b = subprocess.run(['git', '-C', repo, 'show', f'{src}:{path}'], check=True, capture_output=True).stdout
    return b.decode('utf-8')


parts = []
for src, path, label in items:
    body = get(src, path)
    if not body.endswith('\n'):
        body += '\n'
    assert not any(x.startswith('## ===== ') for x in body.splitlines()), f'header line inside {path}'
    parts.append(f'## ===== {label} =====\n\n{body}')
open(out, 'w', encoding='utf-8').write('\n'.join(parts))
text = open(out, encoding='utf-8').read()
chunks = re.split(r'(?m)^## ===== ', text)[1:]
assert len(chunks) == len(items)
for j, ((src, path, label), ch) in enumerate(zip(items, chunks)):
    head, _, body = ch.partition(' =====\n\n'); assert head == label, (head, label)
    want = get(src, path)
    if not want.endswith('\n'):
        want += '\n'
    got = body if j == len(items) - 1 else body[:-1]
    assert body.endswith('\n') and got == want, f'mismatch in {label}'
print(f'OK {len(items)} sections verified; sha256 {hashlib.sha256(open(out, "rb").read()).hexdigest()}')
