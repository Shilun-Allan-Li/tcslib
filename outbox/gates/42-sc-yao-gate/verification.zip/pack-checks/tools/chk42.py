"""chk42.py <repo> <out-dir> <pr-json> <ps10-excerpt.txt>: the Gate 42 pack re-checks (sc-yao, draft PR #341), from git
objects only (no Lean, no lake, no checkout). Python as `python3 -I`. Writes into <out-dir>:

  series.txt     PR metadata (GitHub REST, fetched 2026-11-16; the body equals the MCP read byte for byte), the merge
                 base, the 12 landed commits with their SSH signatures verified (ed25519, python `cryptography`, with a
                 one-byte tamper control), the 8 delivered commits (issue base 6ce4658d .. worker tip 6e7ef601), per-commit
                 patch-ids, git range-diff, and pr.diff.txt = git diff base..head = the three-dot diff
  delivery.txt   the final delivery (exchange 47c38c47) and its checkpoints touch only inbox/fills/sc-yao/; src/ against the
                 rebased worker head e737096b and the landing head; the delivered patches' patch-ids; COMMITS.tsv
  manifests.txt  the delivery's SHA256SUMS (top level and evidence/) verified by streaming every blob from git; the review
                 evidence ZIP at the records pin against its records manifest evidence-SHA256SUMS; the issue package
  frozen.txt     Yao.lean tip -> head by masking the six approved regions and LE-title's title line, with controls; the
                 declaration headers, definitions and statement prose; Uniform.lean = pure insertion of the seven SY-3
                 readers; DAGCircuit.lean unchanged; every other changed path is a new helper under Yao/HybridProof
  lecheck.txt    the four landing edits: LE-bullet (one bullet), LE-reuse (proof only), LE-title (the title line), LE-doc
                 (comment-only: each touched file identical after stripping comments)
  sorries.txt    `sorry` tokens outside comments, per declaration, in TCSlib at the tip and at the head
  docs.txt       sizes and widths; @[simp], attribute commands, instances, native_decide; the sketch rule (proofs of at
                 least 15 lines carry `**Proof sketch.**`); docstring presence and a formula aid for new declarations
  sources.txt    citation groups of the changed files, tip -> head; tags against each file's `## References`; the tag
                 registry; each PS10 locator looked up in the PS10 §6.2 excerpt (an aid, not a verdict)
  names.txt      new declaration names (namespace-resolved) against every declaration of TCSlib at 201bf57a (with #327
                 and #324) and against the names those two PRs added
  mergetrees.txt git merge-tree of the head with the records pin, with 201bf57a and with the open PRs on the records
                 branch; shared paths; the downstream of sc-yao at the head
  dupscan.txt    the relatives named by SY-F02, SY-F03 (with the post-merge addendum), SY-F05, SY-F06 and SY-F08, shown
                 from git objects; the ledger rows DL-46, DL-47, DL-49 at the pin, and DL-49 (extended) and DL-51 at the
                 rulings commit 67423db6 checked against the code
  rule10.txt     recount, from the review evidence ZIP's raw seal and control logs, of both error forms per seal
  rule10-errors.txt every error diagnostic of the frozen files' seals, with its message and enclosing declaration
  frozen-files.diff git diff f9fda8fe..e9b03c43 of Yao.lean, Uniform.lean and DAGCircuit.lean (the last is empty)
"""
import base64, collections, difflib, hashlib, io, json, os, re, subprocess, sys, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls, ws  # noqa: E402

repo, OUT, PRJ, PS10TXT = sys.argv[1:5]
R = Repo(repo)
sha = lambda b: hashlib.sha256(b).hexdigest()
PIN = 'f22e0f6798815b9263893e61928b4f16452f74ee'
RUL = '67423db6c9d6448ae531b04f42c315585d00d502'   # rulings after the pin (records only)
HEAD = 'e9b03c437aca251846430ff23b40ee5ff3d3347a'
BASE = 'f9fda8fe8d11fc68c233df2979a86d356ddfe1ab'
CUR = '201bf57a941131d1737295089ffd7477e1d7f7b9'
M327 = '7d532e2002127eec45080495e31f549573444b43'
ISSUE = '6ce4658db08a1dc2a03a149987197660db078011'
WTIP = '6e7ef601ad9a05d5e26d09f32eadb9c17a4a6cbc'
REB = 'e737096bb22fdb13d36b18d77d496cceac49ef3b'
FINAL = '47c38c479e4be52654cd2c055141dfb64be975c4'
CKPTS = ['f0a9a6163c5c91599147eb550fd5bb929cc68aa0', '816971fc6922646f056a47efd41b1407f762320d',
         'acc868271367d525350da2c1043e7f470f1c0a98', '171a341ab208261d7a29865a32260c1640617158']
EXCH = '14e681e6cfe2e70fb5248fbf2938a024290b061d'
LE = {'LE-bullet': '13690d2e9191be063f298fd69fc9ea8ede358233', 'LE-reuse': '81d526d8ff63e9ee5e9209bd5377a0b2b8688b4a',
      'LE-title': 'bd7832d7fbac20b04db75bc858086b143ba4735b', 'LE-doc': HEAD}
OPEN = {331: '9e7a96481785d6cac4dea3b2e990c49ac278b060', 338: 'd45d3682089cb6fd04f4d075f48a464fefaa143c',
        339: '839f36cca9b4af0570c014f03f19858d0a03cbfb', 340: '916afc25c21f5e52b4b01958186ad55d2f615fd1'}
SC = 'TCSlib/Cryptography/SecureComputation/'
YAO = SC + 'Yao.lean'
UNI = 'TCSlib/Complexity/CircuitComplexity/Uniform.lean'
DAG = 'TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean'
HUB = SC + 'Yao/HybridProof'
EV = 'briefs/pass-shelat-ch5-8/fills/sc-yao/final-r1/'
ROOT = 'inbox/fills/sc-yao/'
files = {}


def out(name, lines):
    text = '\n'.join(lines) + '\n'
    files[name] = text
    open(os.path.join(OUT, name), 'w', encoding='utf-8').write(text)


class Stream:
    """git cat-file --batch without a cache (the delivery is ~296 MB)."""
    def __init__(self):
        self.p = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE)

    def get(self, spec):
        self.p.stdin.write(spec.encode() + b'\n'); self.p.stdin.flush()
        head = self.p.stdout.readline().decode()
        if head.endswith('missing\n'):
            return None
        n = int(head.split()[2]); data = self.p.stdout.read(n); self.p.stdout.read(1)
        return data


ST = Stream()


# ---------------------------------------------------------------- Lean text helpers
def strip_comments(t):
    """Lean source without `--` line comments and (nested) `/- -/` block comments, doc comments included;
    string literals are kept."""
    o, i, n, depth = [], 0, len(t), 0
    while i < n:
        if depth:
            if t.startswith('/-', i):
                depth += 1; i += 2
            elif t.startswith('-/', i):
                depth -= 1; i += 2
            else:
                if t[i] == '\n':
                    o.append('\n')
                i += 1
            continue
        c = t[i]
        if c == '"':
            j = i + 1
            while j < n and t[j] != '"':
                j += 2 if t[j] == '\\' else 1
            o.append(t[i:j + 1]); i = j + 1
        elif t.startswith('/-', i):
            depth = 1; i += 2
        elif t.startswith('--', i):
            j = t.find('\n', i)
            i = n if j < 0 else j
        else:
            o.append(c); i += 1
    return ''.join(o)


def code_lines(t):
    return [l.rstrip() for l in strip_comments(t).split('\n') if l.strip()]


NSRE = re.compile(r'^(namespace|section|end)\b\s*(\S*)')


def full_names(text):
    """(full name, kind, line, private) of every declaration, with namespaces resolved (namespace/section/end;
    `protected`/`private` kept; a name starting with `_root_.` is absolute)."""
    stack, res = [], []
    d = decls(text)
    bylines = {v[1]: (k.split('#')[0], v) for k, v in d.items()}
    for i, l in enumerate(text.split('\n'), 1):
        m = NSRE.match(l)
        if m:
            kw, nm = m.groups()
            if kw == 'namespace':
                stack.append(('ns', nm))
            elif kw == 'section':
                stack.append(('sec', nm))
            elif stack:
                stack.pop()
            continue
        if i in bylines:
            nm, v = bylines[i]
            if nm.startswith('_root_.'):
                full = nm[len('_root_.'):]
            else:
                full = '.'.join([x for k, x in stack if k == 'ns'] + [nm])
            res.append((full, v[0], i, v[4]))
    return res


def doc_of(text, v):
    """the docstring of a declaration, also when attribute lines stand between it and the keyword."""
    if v[3]:
        return v[3]
    Ls = text.split('\n'); k = v[1] - 2
    while k >= 0 and Ls[k].startswith('@['):
        k -= 1
    if k >= 0 and Ls[k].rstrip().endswith('-/'):
        s = k
        while s >= 0 and '/--' not in Ls[s]:
            s -= 1
        return '\n'.join(Ls[s:k + 1])
    return ''


def decl_spans(text):
    """name -> (start line index of the docstring or keyword, keyword line index, end index exclusive): a declaration
    ends at the first blank line after its keyword line."""
    L = text.split('\n'); d = decls(text); res = {}
    for k, v in d.items():
        i = v[1] - 1; j = i
        while j < len(L) and L[j].strip() != '':
            j += 1
        s = i
        if v[3]:
            s = i - 1
            while s >= 0 and '/--' not in L[s]:
                s -= 1
        res[k] = (s, i, j)
    return res


# ---------------------------------------------------------------- signatures (as Gate 43's chk43.py)
def ssh_sig(commit, tamper=False):
    raw = R.gitb('cat-file', 'commit', commit)
    if tamper:
        raw = raw.replace(b'\ncommitter ', b'\ncommitter  ', 1)
    lines = raw.split(b'\n')
    sig, rest, i = [], [], 0
    while i < len(lines):
        l = lines[i]
        if l == b'':
            rest.extend(lines[i:]); break
        if l.startswith(b'gpgsig '):
            sig.append(l[7:]); i += 1
            while i < len(lines) and lines[i].startswith(b' '):
                sig.append(lines[i][1:]); i += 1
            continue
        rest.append(l); i += 1
    if not sig:
        return dict(n=0)
    payload = b'\n'.join(rest)
    armor = b'\n'.join(sig).decode()
    blob = base64.b64decode(''.join(x for x in armor.splitlines() if not x.startswith('-----')))

    def rd(b, k):
        n = int.from_bytes(b[k:k + 4], 'big'); return b[k + 4:k + 4 + n], k + 4 + n
    assert blob[:6] == b'SSHSIG'
    k = 10
    pub, k = rd(blob, k); ns, k = rd(blob, k); _, k = rd(blob, k); halg, k = rd(blob, k); sigblob, k = rd(blob, k)
    fp = 'SHA256:' + base64.b64encode(hashlib.sha256(pub).digest()).decode().rstrip('=')
    ktype, kk = rd(pub, 0)
    st, kk2 = rd(sigblob, 0)
    sigraw, _ = rd(sigblob, kk2)
    h = hashlib.sha512(payload).digest() if halg == b'sha512' else hashlib.sha256(payload).digest()

    def s(x):
        return len(x).to_bytes(4, 'big') + x
    signed = b'SSHSIG' + s(ns) + s(b'') + s(halg) + s(h)
    ok = None
    if ktype == b'ssh-ed25519':
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            keyraw, _ = rd(pub, kk)
            Ed25519PublicKey.from_public_bytes(keyraw).verify(sigraw, signed)
            ok = True
        except ImportError:
            ok = None
        except Exception:
            ok = False
    return dict(n=sum(1 for l in lines if l.startswith(b'gpgsig ')), fp=fp, ns=ns.decode(), alg=halg.decode(),
                ktype=ktype.decode(), ok=ok)


def cinfo(c):
    f = R.git('show', '-s', '--format=%H%x00%an <%ae>%x00%ad%x00%cn <%ce>%x00%cd%x00%s', '--date=raw', c).stdout
    return dict(zip(['hash', 'author', 'adate', 'committer', 'cdate', 'subject'], f.rstrip('\n').split('\x00')))


def patch_id(c):
    p = subprocess.run(['git', '-C', repo, 'show', '--format=', '--no-color', c], capture_output=True, check=True).stdout
    r = subprocess.run(['git', '-C', repo, 'patch-id', '--stable'], input=p, capture_output=True, check=True).stdout
    return r.split()[0].decode() if r.strip() else ''


def patch_id_text(b):
    r = subprocess.run(['git', '-C', repo, 'patch-id', '--stable'], input=b, capture_output=True, check=True).stdout
    return r.split()[0].decode() if r.strip() else ''


changed = R.git('diff', '--name-status', '--no-renames', BASE, HEAD).stdout.splitlines()
STATUS = {l.split('\t')[1]: l.split('\t')[0] for l in changed}
PATHS = sorted(STATUS)

# ---------------------------------------------------------------- series.txt
pj = json.load(open(PRJ))
L = [f'records pin {PIN}; merge base of the head with the pin {R.git("merge-base", PIN, HEAD).stdout.strip()}; '
     f'with 201bf57a {R.git("merge-base", CUR, HEAD).stdout.strip()} (= the old tip {BASE}: '
     f'{R.git("merge-base", PIN, HEAD).stdout.strip() == BASE})',
     f'201bf57a (#327 merged as {M327[:8]}, then #324) is an ancestor of the pin: {R.anc(CUR, PIN)}; the old tip '
     f'{BASE[:8]} an ancestor of 201bf57a: {R.anc(BASE, CUR)}']
lean_after = R.git('diff', '--name-only', CUR, PIN, '--', 'TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean',
                   'lake-manifest.json', 'lean-toolchain').stdout.split()
L.append(f'TCSlib/root/audits/scripts/lake paths changed 201bf57a..pin: {len(lean_after)} (records only after the merges)')
delta = R.git('diff', '--name-only', BASE, CUR).stdout.split()
L.append(f'paths changed {BASE[:8]}..201bf57a (#327, #324, records): {len(delta)}; shared with the PR\'s {len(PATHS)} '
         f'paths: {sorted(set(delta) & set(PATHS))}')
L.append('')
L.append(f'PR #341 (GitHub REST GET /repos/Shilun-Allan-Li/tcslib/pulls/341, 2026-11-16): state {pj["state"]}, draft '
         f'{pj["draft"]}, head {pj["head"]["ref"]} {pj["head"]["sha"]}, base {pj["base"]["ref"]} {pj["base"]["sha"]}, '
         f'changed_files {pj["changed_files"]}, +{pj["additions"]}/-{pj["deletions"]}, commits {pj["commits"]}')
L.append(f'  REST head = {HEAD}: {pj["head"]["sha"] == HEAD}; REST base sha = the records pin: {pj["base"]["sha"] == PIN}; '
         f'body sha256 {sha(pj["body"].encode())} ({len(pj["body"].encode())} bytes)')
L.append(f'origin/land/pass-shelat-sc-yao = {R.rp("origin/land/pass-shelat-sc-yao")} (= head: '
         f'{R.rp("origin/land/pass-shelat-sc-yao") == HEAD}); head tree {R.rp(HEAD + "^{tree}")}')
tipsig = ssh_sig(PIN)
L.append(f'records pin commit signature: headers {tipsig.get("n")}, key {tipsig.get("fp")}, namespace {tipsig.get("ns")}, '
         f'verified {tipsig.get("ok")}')
L.append(f'signature control: the head with one byte added to its committer line verifies: '
         f'{ssh_sig(HEAD, tamper=True).get("ok")} (expected False)')
landed = R.git('rev-list', '--reverse', f'{BASE}..{HEAD}').stdout.split()
deliv = R.git('rev-list', '--reverse', f'{ISSUE}..{WTIP}').stdout.split()
L.append(f'landed commits {BASE[:8]}..{HEAD[:8]}: {len(landed)}; delivered commits {ISSUE[:8]}..{WTIP[:8]}: {len(deliv)}')
for k, a in enumerate(landed):
    ia, sa = cinfo(a), ssh_sig(a)
    L.append(f'  landed {k + 1:2d} {a} | gpgsig {sa["n"]} {sa.get("ktype", "")} {sa.get("fp", "")} ns={sa.get("ns", "")} '
             f'verified={sa.get("ok")} same key as the pin={sa.get("fp") == tipsig.get("fp")} | author {ia["author"]} | '
             f'committer {ia["committer"]} | {ia["subject"]}')
    if k < len(deliv):
        b = deliv[k]; ib, sb = cinfo(b), ssh_sig(b)
        pa, pb = patch_id(a), patch_id(b)
        L.append(f'     delivered {b} | gpgsig {sb["n"]} | author {ib["author"]} {ib["adate"]} | committer '
                 f'{ib["committer"]} | patch-id equal {pa == pb}; author and author date equal '
                 f'{ia["author"] == ib["author"] and ia["adate"] == ib["adate"]}; subject equal '
                 f'{ia["subject"] == ib["subject"]}')
rd = R.git('range-diff', '--no-color', f'{ISSUE}..{WTIP}', f'{BASE}..{REB}').stdout
L.append(f'git range-diff {ISSUE[:8]}..{WTIP[:8]} {BASE[:8]}..{REB[:8]} (the worker\'s 8, before the landing edits):')
L.extend('  ' + x for x in rd.rstrip('\n').split('\n') if re.match(r'^\s*\d+:', x))
L.append(f'  "=" rows: {sum(" = " in x for x in rd.splitlines() if re.match(r"^\s*\d+:", x))} of {len(deliv)}')
pr_diff = R.gitb('diff', f'{BASE}..{HEAD}')
three = R.gitb('diff', f'{PIN}...{HEAD}')
L.append(f'pr.diff.txt = git diff {BASE[:8]}..{HEAD[:8]}: {len(pr_diff)} bytes, sha256 {sha(pr_diff)}; '
         f'{R.git("diff", "--shortstat", BASE, HEAD).stdout.strip()}')
L.append(f'  = git diff {PIN[:8]}...{HEAD[:8]} (three-dot, GitHub\'s view) byte for byte: {pr_diff == three}')
L.append(f'  statuses: {dict(collections.Counter(STATUS.values()))}')
out('series.txt', L)

# ---------------------------------------------------------------- delivery.txt
L = [f'final delivery {FINAL} ({cinfo(FINAL)["subject"]}); checkpoints {", ".join(c[:8] for c in CKPTS)}',
     f'all on the fetched exchange tip {EXCH[:8]}: {all(R.anc(c, EXCH) for c in CKPTS + [FINAL])}']
for c in CKPTS + [FINAL]:
    ch = R.git('diff-tree', '--no-commit-id', '--name-only', '-r', f'{c}^', c).stdout.split()
    L.append(f'  {c[:9]} ({cinfo(c)["subject"]}; author {cinfo(c)["author"].split(" <")[0]}; gpgsig '
             f'{ssh_sig(c)["n"]}): {len(ch)} paths, all under {ROOT}: {all(x.startswith(ROOT) for x in ch)}')
later = R.git('log', '--format=%H', f'{FINAL}..{EXCH}', '--', ROOT).stdout.split()
L.append(f'commits after the final touching {ROOT} up to {EXCH[:8]}: {len(later)}')
srcs = sorted(p[len(ROOT) + 4:] for p in R.git('ls-tree', '-r', '--name-only', FINAL, ROOT + 'src/').stdout.split())
L.append(f'src/ paths: {len(srcs)}; = the PR paths plus DAGCircuit.lean: {srcs == sorted(PATHS + [DAG])}')
eq_reb = sum(R.blob(FINAL, ROOT + 'src/' + p) == R.blob(REB, p) for p in srcs if p not in (YAO, DAG))
eq_head = sum(R.blob(FINAL, ROOT + 'src/' + p) == R.blob(HEAD, p) for p in srcs if p not in (YAO, DAG))
L.append(f'helpers and Uniform.lean ({len(srcs) - 2}): src/ = rebased worker head {REB[:8]}: {eq_reb}; = landing head '
         f'{HEAD[:8]}: {eq_head} (LE-reuse touches 1 helper, LE-doc 64)')
le_files = set(R.git('diff', '--name-only', REB, HEAD).stdout.split())
diff_ok = [p for p in srcs if p not in (YAO, DAG) and R.blob(FINAL, ROOT + 'src/' + p) != R.blob(HEAD, p)]
L.append(f'  paths where src/ differs from the head: {len(diff_ok)}; all among the landing edits\' paths: '
         f'{set(diff_ok) <= le_files}')
dsrc, dtip = R.blob(FINAL, ROOT + 'src/' + DAG), R.blob(BASE, DAG)
L.append(f'DAGCircuit.lean: src/ = tip {BASE[:8]}: {dsrc == dtip} (the tip also has #332\'s readers); the delivered '
         f'isFaninTwo_iff block against the tip\'s: frozen.txt; head = tip: {R.blob(HEAD, DAG) == dtip}')
ys = R.show(FINAL, ROOT + 'src/' + YAO); yr = R.show(REB, YAO)
anchor = '/-- **Efficiency.**'
cut_s = ys.rfind('\n\n', 0, ys.find('theorem yaoHybrid_polyTime')) + 2
cut_r = yr.rfind('\n\n', 0, yr.find('theorem yaoHybrid_polyTime')) + 2
L.append(f'Yao.lean: src/ = rebased head {REB[:8]} from the docstring of yaoHybrid_polyTime to EOF: '
         f'{ys[cut_s:] == yr[cut_r:]} ({len(ys[cut_s:].splitlines())} lines)')
pats = sorted(p for p in R.git('ls-tree', '--name-only', FINAL, ROOT + 'patches/').stdout.split() if p.endswith('.patch'))
L.append(f'patches: {len(pats)}')
for p, c in zip(pats, deliv):
    b = R.blob(FINAL, p)
    m = re.match(rb'From ([0-9a-f]{40})', b)
    L.append(f'  {p.split("/")[-1]}: From {m.group(1).decode() if m else "?"}; patch-id = delivered {c[:12]}: '
             f'{patch_id_text(b) == patch_id(c)}')
tsv = R.show(FINAL, ROOT + 'patches/COMMITS.tsv').splitlines()
rows = [r.split('\t') for r in tsv[1:] if r.strip()]
L.append(f'COMMITS.tsv: {len(rows)} rows; signing column {sorted({r[-1] for r in rows})}; row hashes = the series '
         f'{ISSUE[:8]}..{WTIP[:8]} (reproduced by the review\'s git am): {[r[0] for r in rows] == deliv}')
for r, c in zip(rows, deliv):
    ci = R.git('show', '-s', '--format=%an|%aI|%cn|%cI', c).stdout.strip().split('|')
    L.append(f'  row {r[0][:12]} -> {c[:12]}: author, author date, committer, committer date as in the row: '
             f'{[ci[0], ci[1], ci[2], ci[3]] == [r[1], r[3], r[4], r[6]]}; row hash = commit id: {r[0] == c}')
out('delivery.txt', L)

# ---------------------------------------------------------------- manifests.txt
L = []


def tree_blobs(rev, root):
    res = {}
    for l in R.git('ls-tree', '-r', rev, root).stdout.splitlines():
        meta, p = l.split('\t', 1)
        res[p[len(root):]] = meta.split()[2]
    return res


tb = tree_blobs(FINAL, ROOT)
L.append(f'delivery {FINAL} under {ROOT}: {len(tb)} files')
for man, pre in (('SHA256SUMS', ''), ('evidence/SHA256SUMS', 'evidence/')):
    rows = [x.split('  ', 1) for x in R.show(FINAL, ROOT + man).splitlines() if x.strip()]
    listed = {pre + p for _, p in rows}
    have = {p for p in tb if p.startswith(pre) and p != man}
    bad = [p for h, p in rows if pre + p in tb and sha(ST.get(tb[pre + p])) != h]
    miss = sorted(listed - set(tb))
    extra = sorted(have - listed)
    L.append(f'  {man}: {len(rows)} rows; present {len(listed & set(tb))}; hash mismatches {len(bad)} {bad[:3]}; '
             f'missing {len(miss)}; unlisted {len(extra)} {extra[:5]}; "./" prefixes {sum(p.startswith("./") for _, p in rows)}')
zb = R.blob(PIN, EV + 'review-evidence.zip')
L.append('')
L.append(f'review evidence {EV}review-evidence.zip at the pin: {len(zb)} bytes, sha256 {sha(zb)}; working tree copy equal: '
         f'{open(os.path.join(repo, EV, "review-evidence.zip"), "rb").read() == zb}')
z = zipfile.ZipFile(io.BytesIO(zb))
names = z.namelist()
man = z.read('SHA256SUMS')
rows = [x.split('  ', 1) for x in man.decode().splitlines()]
ok = sum(sha(z.read(p)) == h for h, p in rows)
rec = R.blob(PIN, EV + 'evidence-SHA256SUMS')
L.append(f'  {len(names)} entries ({sum(n.endswith("/") for n in names)} directories, no top folder); inner SHA256SUMS '
         f'{len(rows)} rows, {ok} verify; entries = rows + SHA256SUMS: {set(names) == {p for _, p in rows} | {"SHA256SUMS"}}')
L.append(f'  records copy {EV}evidence-SHA256SUMS ({len(rec)} bytes, sha256 {sha(rec)}) = the inner manifest: {rec == man}')
L.append(f'  landing/PROVENANCE.txt in the ZIP = the records copy {EV}landing/PROVENANCE.txt: '
         f'{z.read("landing/PROVENANCE.txt") == R.blob(PIN, EV + "landing/PROVENANCE.txt")}')
L.append('')
ip = 'briefs/pass-shelat-ch5-8/fills/sc-yao/issued-r1/'
rows = [x.split('  ', 1) for x in R.show(PIN, ip + 'SHA256SUMS').splitlines() if x.strip()]
L.append(f'issue package {ip}: SHA256SUMS {sum(sha(R.blob(PIN, ip + p)) == h for h, p in rows)}/{len(rows)} verify at the pin')
rows = [x.split('  ', 1) for x in R.show(PIN, ip + 'SOURCE-SHA256SUMS').splitlines() if x.strip()]
L.append(f'  SOURCE-SHA256SUMS: {sum(sha(R.blob(ISSUE, p.strip()) or b"") == h for h, p in rows)}/{len(rows)} verify at '
         f'the issue base {ISSUE[:8]}')
out('manifests.txt', L)
EVZ = z

# ---------------------------------------------------------------- frozen.txt
TARGETS = ('yaoHybrid_polyTime', 'yaoHybrid_simulators')


def yao_regions(text):
    """the approved regions as (name, start, end) line-index spans [start, end) of `text`."""
    Ls = text.split('\n'); reg = []
    imp = [i for i, l in enumerate(Ls) if l == 'import TCSlib.Cryptography.Foundations.BitLists'][0]
    hub = [i for i, l in enumerate(Ls) if l.startswith('import TCSlib.Cryptography.SecureComputation.Yao.')]
    reg.append(('hub import', imp + 1, imp + 1 + len(hub)))
    t = [i for i, l in enumerate(Ls) if l.startswith('# Yao')][0]
    reg.append(('title line (LE-title)', t, t + 1))
    b0 = [i for i, l in enumerate(Ls) if l.startswith('* `SecureComputation.yaoHybrid_polyTime`')][0]
    b1 = [i for i, l in enumerate(Ls) if l.startswith('* `SecureComputation.yaoHybrid_hbcSecure`')][0]
    reg.append(('Main results bullet', b0, b1))
    for tg in TARGETS:
        k = [i for i, l in enumerate(Ls) if re.match(rf'^theorem {tg}\b', l)][0]
        e = k - 1
        while not Ls[e].rstrip().endswith('-/'):
            e -= 1
        s = e
        while '**Proof sketch.**' not in Ls[s]:
            s -= 1
        reg.append((f'{tg} sketch', s, e + 1))
        h = k
        while not re.search(r':= by\s*$', Ls[h]):
            h += 1
        j = h + 1
        while j < len(Ls) and Ls[j].strip() != '':
            j += 1
        reg.append((f'{tg} body', h + 1, j))
    return reg


def mask(text, regs):
    Ls = text.split('\n'); o = []; i = 0
    for name, s, e in sorted(regs, key=lambda r: r[1]):
        o.extend(Ls[i:s]); o.append(f'<<{name}>>'); i = e
    o.extend(Ls[i:])
    return o


def yao_check(bt, ht):
    rb, rh = yao_regions(bt), yao_regions(ht)
    mb, mh = mask(bt, rb), mask(ht, rh)
    ops = [op for op in difflib.SequenceMatcher(None, mb, mh, autojunk=False).get_opcodes() if op[0] != 'equal']
    Lh = ht.split('\n')
    rules = []
    for name, s, e in rh:
        if name.endswith('body'):
            body = Lh[s:e]
            if any(x and not x.startswith(' ') for x in body):
                rules.append(f'{name}: a column-0 line')
            if any(re.search(r'\bsorry\b', x) for x in body):
                rules.append(f'{name}: sorry')
        if name.endswith('sketch') and 'not yet stated' in '\n'.join(Lh[s:e]):
            rules.append(f'{name}: "not yet stated"')
        if name == 'hub import' and e - s != 1:
            rules.append(f'hub import: {e - s} lines')
    return rb, rh, ops, rules, mb, mh


L = []
bt, ht = R.show(BASE, YAO), R.show(HEAD, YAO)
rb, rh, ops, rules, mb, mh = yao_check(bt, ht)
L.append(f'=== {YAO}: tip {BASE[:8]} ({len(bt.splitlines())} lines) -> head {HEAD[:8]} ({len(ht.splitlines())} lines; '
         f'SY-2 cap 1200: {len(ht.splitlines()) <= 1200}; max width {max(len(x) for x in ht.splitlines())})')
L.append('approved regions (1-based line ranges, tip | head):')
for (n1, s1, e1), (n2, s2, e2) in zip(rb, rh):
    L.append(f'  {n1:32s} tip {s1 + 1}-{e1} ({e1 - s1} lines) | head {s2 + 1}-{e2} ({e2 - s2} lines)')
L.append(f'masked tip = masked head (everything outside the regions byte-identical): {mb == mh}; violations {len(ops)}')
L.append(f'rule breaks (column-0 line or sorry in a body, "not yet stated" in a sketch, hub import not one line): '
         f'{len(rules)} {rules}')
raw = [op for op in difflib.SequenceMatcher(None, bt.split('\n'), ht.split('\n'), autojunk=False).get_opcodes()
       if op[0] != 'equal']
L.append(f'unmasked diff hunks: {len(raw)}; each inside one region on both sides:')
for tag, i1, i2, j1, j2 in raw:
    hit = [n for (n, s, e), (_, s2, e2) in zip(rb, rh) if s <= i1 and i2 <= e and s2 <= j1 and j2 <= e2]
    L.append(f'  {tag:7s} tip {i1 + 1}-{i2} head {j1 + 1}-{j2}: {hit}')
db, dh = decls(bt), decls(ht)
L.append(f'declarations: tip {len(db)} ({sum(v[4] for v in db.values())} private), head {len(dh)}; same names in the '
         f'same order: {list(db) == list(dh)}')
hdr = [k for k in db if k in dh and db[k][2] != dh[k][2]]
defs = [k for k in db if k in dh and db[k][0] not in ('theorem', 'lemma') and db[k][2] != dh[k][2]]
docs_ = [k for k in db if k in dh and db[k][3] != dh[k][3]]
L.append(f'  headers differing: {hdr}; definition blocks differing: {defs}; docstrings differing: {docs_}')
for tg in TARGETS:
    pb, ph = db[tg][3].split('**Proof sketch.**')[0], dh[tg][3].split('**Proof sketch.**')[0]
    L.append(f'  {tg}: statement prose before **Proof sketch.** byte-identical: {pb == ph} ({len(pb.splitlines())} '
             f'lines); header byte-identical: {db[tg][2] == dh[tg][2]}')
yb = decl_spans(bt)['yaoSeed_good_whp']; yh = decl_spans(ht)['yaoSeed_good_whp']
L.append(f'  yaoSeed_good_whp (sc-garble\'s, proved on the tip): docstring, header and body byte-identical: '
         f'{bt.split(chr(10))[yb[0]:yb[2]] == ht.split(chr(10))[yh[0]:yh[2]]}')
imps_b = [l for l in bt.splitlines() if l.startswith('import ')]
imps_h = [l for l in ht.splitlines() if l.startswith('import ')]
L.append(f'  imports: tip {len(imps_b)}, head {len(imps_h)}; added {[x for x in imps_h if x not in imps_b]}; '
         f'removed {[x for x in imps_b if x not in imps_h]}')
L.append(f'  the tip title line: {bt.split(chr(10))[rb[1][1]]!r}; the head title line: {ht.split(chr(10))[rh[1][1]]!r}')
# controls
Lh = ht.split('\n')
C = []
k = [i for i, l in enumerate(Lh) if l.startswith('theorem yaoHybrid_hbcSecure')][0]
c1 = Lh[:]; c1[k] = c1[k].replace('yaoHybrid_hbcSecure', 'yaoHybrid_hbcSecurf', 1)
C.append(('one character in a frozen header (yaoHybrid_hbcSecure)', '\n'.join(c1), 1, 0))
p = [i for i, l in enumerate(Lh) if 'yaoSeed_good_whp' in l and l.startswith('theorem')][0] - 2
c2 = Lh[:p] + ['frozen-region extra line'] + Lh[p:]
C.append(('one extra line in a frozen region (above yaoSeed_good_whp)', '\n'.join(c2), 1, 0))
c3 = Lh[:rh[0][2]] + ['import TCSlib.Cryptography.Foundations.Negligible'] + Lh[rh[0][2]:]
C.append(('a second new import line', '\n'.join(c3), 1, 0))
bs = [r for r in rh if r[0] == 'yaoHybrid_simulators body'][0]
c4 = Lh[:bs[1] + 1] + ['theorem smuggled : True := trivial'] + Lh[bs[1] + 1:]
C.append(('a declaration smuggled into a body', '\n'.join(c4), 0, 1))
ss = [r for r in rh if r[0] == 'yaoHybrid_polyTime sketch'][0]
c5 = Lh[:]; c5[ss[1] + 1] = c5[ss[1] + 1] + ' (edited)'
C.append(('an edit inside a sketch (allowed)', '\n'.join(c5), 0, 0))
ks = [i for i, l in enumerate(Lh) if l.startswith('theorem yaoHybrid_simulators')][0]
pr_ = ks
while not Lh[pr_].startswith('/--'):
    pr_ -= 1
pr_ += 1
c6 = Lh[:]; c6[pr_] = c6[pr_].replace(' ', '  ', 1)
C.append((f'one doubled space in yaoHybrid_simulators\' statement prose (head line {pr_ + 1})', '\n'.join(c6), 1, 0))
L.append('controls (each a copy of the head; expected violations, rule breaks):')
for name, txt, ev, er in C:
    try:
        _, _, o2, r2, _, _ = yao_check(bt, txt)
        L.append(f'  {name}: violations {len(o2)}, rule breaks {len(r2)} (expected {ev}, {er}): '
                 f'{"OK" if (len(o2), len(r2)) == (ev, er) else "UNEXPECTED"}')
    except Exception as e:  # a control that breaks the region parser counts as caught
        L.append(f'  {name}: region parser rejects it ({type(e).__name__}) (expected {ev}, {er})')
L.append('')
# Uniform.lean
ub, uh = R.show(BASE, UNI), R.show(HEAD, UNI)
uo = [op for op in difflib.SequenceMatcher(None, ub.split('\n'), uh.split('\n'), autojunk=False).get_opcodes()
      if op[0] != 'equal']
L.append(f'=== {UNI}: tip {len(ub.splitlines())} -> head {len(uh.splitlines())} lines; hunks {len(uo)}, all pure '
         f'insertions: {all(o[0] == "insert" for o in uo)}')
Luh = uh.split('\n')
ins = set()
for _, i1, i2, j1, j2 in uo:
    ins |= set(range(j1, j2))
restored = '\n'.join(l for i, l in enumerate(Luh) if i not in ins)
L.append(f'  removing the inserted lines restores the tip byte for byte: {restored == ub}')
du, dt = decls(uh), decls(ub)
new = [k for k in du if k not in dt]
L.append(f'  new declarations: {len(new)}: {new}')
Lub = ub.split('\n')
for k in new:
    kind, line, header, doc, priv = du[k]
    s, i, j = decl_spans(uh)[k]
    block = '\n'.join(Luh[s:j])
    proof = block.split(':=')[-1].strip()
    prev = s - 2
    while prev >= 0 and not re.match(r'^(def|theorem|private|/--|@)', Luh[prev]):
        prev -= 1
    pd = [kk for kk, vv in du.items() if vv[1] - 1 <= prev and kk not in new]
    before = max(pd, key=lambda kk: du[kk][1]) if pd else None
    L.append(f'    {kind} {k} (head line {line}): proof `{proof}`; formula docstring {bool(doc) and "`" in doc}; '
             f'attribute {"@[" in block or "attribute" in block}; private {priv}; directly after its def: '
             f'{before} ({du[before][0] if before else None})')
L.append('')
def faninblock(t):
    sp = decl_spans(t)['isFaninTwo_iff']
    return '\n'.join(t.split('\n')[sp[0]:sp[2]])


dsrc, dtip, diss = R.show(FINAL, ROOT + 'src/' + DAG), R.show(BASE, DAG), R.show(ISSUE, DAG)
fb = faninblock(dsrc)
L.append(f'=== {DAG}: tip blob = head blob: {R.blob(BASE, DAG) == R.blob(HEAD, DAG)}')
L.append(f'  the worker\'s src/ copy (exchange {FINAL[:8]}) = the issue base plus exactly the isFaninTwo_iff block and one '
         f'blank line: {dsrc.replace(fb + chr(10) + chr(10), "", 1) == diss}; that block = the tip\'s block (#323) byte for '
         f'byte: {fb == faninblock(dtip)} ({len(fb.splitlines())} lines); the issue base has no isFaninTwo_iff: '
         f'{"isFaninTwo_iff" not in diss}')
L.append(f'  the tip differs from the issue base by #323\'s reader and #332\'s readers: added declarations '
         f'{[k for k in decls(dtip) if k not in decls(diss)]}')
other = [p for p in PATHS if p not in (YAO, UNI)]
L.append(f'=== other changed paths: {len(other)}; all added: {all(STATUS[p] == "A" for p in other)}; all the hub or '
         f'under it: {all(p == HUB + ".lean" or p.startswith(HUB + "/") for p in other)}')
yao_dir = [p for p in R.git('ls-tree', '-r', '--name-only', HEAD, SC + 'Yao/').stdout.split()]
L.append(f'  files directly under Yao/: {[p for p in yao_dir if p.count("/") == SC.count("/") + 1]}')
hub = R.show(HEAD, HUB + '.lean')
children = sorted(p for p in other if p.startswith(HUB + '/'))
hub_imps = re.findall(r'(?m)^import (\S+)', hub)
L.append(f'  hub imports {len(hub_imps)}; = the {len(children)} children: '
         f'{sorted(m.replace(".", "/") + ".lean" for m in hub_imps) == children}; `## Contents` in the hub: '
         f'{"## Contents" in hub}')
out('frozen.txt', L)
fd = R.gitb('diff', f'{BASE}..{HEAD}', '--', YAO, UNI, DAG).decode('utf-8')
files['frozen-files.diff'] = fd
open(os.path.join(OUT, 'frozen-files.diff'), 'w', encoding='utf-8').write(fd)

# ---------------------------------------------------------------- lecheck.txt
L = []
order = ['LE-bullet', 'LE-reuse', 'LE-title', 'LE-doc']
for name in order:
    c = LE[name]; par = R.rp(c + '^')
    ps = R.git('diff', '--name-only', par, c).stdout.split()
    L.append(f'=== {name} {c} (parent {par[:8]}): {cinfo(c)["subject"]}; {len(ps)} file(s); '
             f'{R.git("diff", "--shortstat", par, c).stdout.strip()}')
    if name in ('LE-bullet', 'LE-title'):
        d = [x for x in R.git('diff', '-U0', par, c).stdout.splitlines() if x[:1] in '+-' and x[:3] not in ('+++', '---')]
        L.extend('  ' + x for x in d)
    if name == 'LE-reuse':
        for p in ps:
            a, b = R.show(par, p), R.show(c, p)
            da, dbb = decls(a), decls(b)
            L.append(f'  {p}: declarations {len(da)} -> {len(dbb)}, same order {list(da) == list(dbb)}; headers '
                     f'byte-identical {all(da[k][2] == dbb[k][2] for k in da if k in dbb)}; imports unchanged '
                     f'{re.findall(r"(?m)^import .*", a) == re.findall(r"(?m)^import .*", b)}; changed declarations '
                     f'{[k for k in da if k in dbb and (da[k][3] != dbb[k][3] or decl_spans(a)[k] and a.split(chr(10))[decl_spans(a)[k][1]:decl_spans(a)[k][2]] != b.split(chr(10))[decl_spans(b)[k][1]:decl_spans(b)[k][2]])]}')
            L.append(f'  new proof terms: {re.findall(r"GarblingProbability.assignmentFold_small[^\n]*", b)}')
    if name == 'LE-doc':
        same, bad, wid, mx = 0, [], 0, 0
        for p in ps:
            a, b = R.show(par, p), R.show(c, p)
            if code_lines(a) == code_lines(b):
                same += 1
            else:
                bad.append(p)
            wid = max(wid, max(len(x) for x in b.splitlines())); mx = max(mx, len(b.splitlines()))
        L.append(f'  files identical after stripping comments (line and block, doc comments included): {same}/{len(ps)}; '
                 f'differing {bad}')
        L.append(f'  touches Yao.lean, Uniform.lean or DAGCircuit.lean: {bool({YAO, UNI, DAG} & set(ps))}; all under the '
                 f'hub: {all(p.startswith(HUB) for p in ps)}; max width {wid}; largest touched file {mx} lines')
        # control: a one-token code edit must be caught
        p0 = ps[0]; b0 = R.show(c, p0)
        i0 = [i for i, l in enumerate(b0.split('\n')) if re.search(r':= by\s*$', l)][0]
        ctl = b0.split('\n'); ctl[i0] = ctl[i0].replace(':= by', ':=  by  ')
        ctl2 = b0.split('\n'); ctl2[i0 + 1] = ctl2[i0 + 1] + ' <;> rfl'
        L.append(f'  controls on {p0.split("/")[-1]}: added spaces only -> caught {code_lines(R.show(par, p0)) != code_lines(chr(10).join(ctl))} '
                 f'(whitespace inside a line counts; expected True); one added tactic -> caught '
                 f'{code_lines(R.show(par, p0)) != code_lines(chr(10).join(ctl2))} (expected True)')
    sig = ssh_sig(c)
    msg = R.git("show", "-s", "--format=%B", c).stdout.splitlines()
    L.append(f'  signed: {sig["n"]} gpgsig, verified {sig.get("ok")}; Co-Authored-By and Claude-Session trailer lines '
             f'present: {any(x.startswith("Co-Authored-By: ") for x in msg)}, {any(x.startswith("Claude-Session: ") for x in msg)}')
out('lecheck.txt', L)

# ---------------------------------------------------------------- sorries.txt
def sorry_decls(rev):
    res = collections.Counter()
    for p in R.git('ls-tree', '-r', '--name-only', rev, 'TCSlib').stdout.split():
        if not p.endswith('.lean'):
            continue
        t = R.blob(rev, p).decode('utf-8')
        if 'sorry' not in t:
            continue
        s = strip_comments(t)
        if not re.search(r'\bsorry\b', s):
            continue
        Ls = s.split('\n')
        cur = None
        for l in Ls:
            m = re.match(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma|def|abbrev|'
                         r'instance)\s+([^\s({:\[]+)', l)
            if m:
                cur = m.group(1)
            for _ in re.findall(r'\bsorry\b', l):
                res[(p, cur)] += 1
    return res


sb_, sh_ = sorry_decls(BASE), sorry_decls(HEAD)
L = [f'source-level `sorry` outside comments, by declaration, TCSlib/ (an aid; the review counts admissions per '
     f'declaration)', f'tip {BASE[:8]}: {len(sb_)} declarations in {len({p for p, _ in sb_})} files; head '
     f'{HEAD[:8]}: {len(sh_)} declarations in {len({p for p, _ in sh_})} files']
L.append(f'removed: {sorted(set(sb_) - set(sh_))}')
L.append(f'added: {sorted(set(sh_) - set(sb_))}')
L.append(f'in the PR\'s changed files at the head: {[k for k in sh_ if k[0] in PATHS]}')
sc_ = sorry_decls(CUR)
L.append(f'201bf57a (with #327, #324): {len(sc_)} declarations; head merged with 201bf57a would keep '
         f'{len(set(sc_) - {k for k in sb_ if k not in sh_})} (= 201bf57a minus the two targets)')
L.append('the remaining declarations at the head:')
L.extend(f'  {p}: {d} ({n})' for (p, d), n in sorted(sh_.items()))
out('sorries.txt', L)

# ---------------------------------------------------------------- docs.txt
L = []
tot = collections.Counter()
over = []
for p in PATHS:
    t = R.show(HEAD, p); Ls = t.splitlines()
    w = max(len(x) for x in Ls)
    if len(Ls) > (1200 if p == YAO else 1000) or w > 100:
        over.append((p, len(Ls), w))
    tot['lines'] += len(Ls)
mx = max(((len(R.show(HEAD, p).splitlines()), p) for p in PATHS if p.startswith(HUB)))
L.append(f'{len(PATHS)} changed files; over the size cap (Yao.lean 1200 under SY-2, others 1000) or 100 characters: {over}; '
         f'largest helper {mx[1].split("/")[-1]} {mx[0]} lines; hub and helpers '
         f'{sum(len(R.show(HEAD, p).splitlines()) for p in PATHS if p.startswith(HUB))} lines')
cnt = collections.Counter()
pats = {'@[simp] (the attribute, not simps)': r'@\[simp[\s,\]]', '@[simps': r'@\[simps\b',
        '@[simps …] without isSimp := false': None, 'attribute [': r'(?m)^\s*attribute \[',
        'instance': r'(?m)^\s*(?:@\[[^\]]*\]\s*)?instance\b', 'native_decide': r'\bnative_decide\b',
        'unsafe': r'\bunsafe\b', 'admit': r'\badmit\b', 'sorry': r'\bsorry\b', 'axiom': r'(?m)^\s*axiom\b',
        'local notation': r'\blocal notation\b', 'abbrev (public)': r'(?m)^\s*(?:@\[[^\]]*\]\s*)?abbrev\b',
        'set_option': r'(?m)^\s*set_option\b'}
setopts = collections.Counter()
for p in PATHS:
    hs = strip_comments(R.show(HEAD, p)); bs = strip_comments(R.show(BASE, p)) if STATUS[p] == 'M' else ''
    for k, rx in pats.items():
        if rx is None:
            n = lambda t: len([m for m in re.findall(r'@\[simps[^\]]*\]', t) if 'isSimp := false' not in m])
            cnt[k] += n(hs) - n(bs)
        else:
            cnt[k] += len(re.findall(rx, hs)) - len(re.findall(rx, bs))
    for m in re.findall(r'(?m)^\s*set_option\s+(\S+\s+\S+)', hs):
        setopts[m] += 1
    for m in re.findall(r'(?m)^\s*set_option\s+(\S+\s+\S+)', bs):
        setopts[m] -= 1
for k in pats:
    L.append(f'code (comments stripped) occurrences added by the PR, head minus tip: {k!r}: {cnt[k]}')
L.append(f'  set_option lines added, by option and value: {dict(+setopts)}')
L.append('')
sk_tot, sk_miss, nodoc, noform, newd = 0, [], [], [], 0
REL = re.compile(r'[=≤<≥>↔→∈∉≠⊆∀∃]|\bdist|\bNegligible\b|\bPolyTimeComputable\b|\.Efficient\b|Injective|Bijective|'
                 r'\)\.[A-Z][A-Za-z]*`')
for p in PATHS:
    t = R.show(HEAD, p); Ls = t.split('\n')
    old = decls(R.show(BASE, p)) if STATUS[p] == 'M' else {}
    sp = decl_spans(t)
    for k, v in decls(t).items():
        kind, line, header, _, priv = v
        doc = doc_of(t, v)
        s, i, j = sp[k]
        if kind in ('theorem', 'lemma') and (k not in old or k in TARGETS):
            h = next((x for x in range(i, j) if re.search(r':=( by)?\s*$', Ls[x])), None)
            plen = 0 if h is None else j - h - 1
            if plen >= 15:
                sk_tot += 1
                if '**Proof sketch.**' not in doc:
                    sk_miss.append(f'{p.split("/")[-1]}:{line} {k} ({plen} lines)')
        if k in old or priv:
            continue
        newd += 1
        if not doc:
            nodoc.append(f'{p.split("/")[-1]}:{line} {kind} {k}')
        elif kind in ('theorem', 'lemma') and not ('`' in doc and REL.search(doc)):
            noform.append(f'{p.split("/")[-1]}:{line} {k}')
L.append(f'sketch rule: new theorems (and the two targets) whose proof after the `:= by`/`:=` line has >= 15 lines: '
         f'{sk_tot}; without `**Proof sketch.**`: {len(sk_miss)}')
L.extend('  ' + x for x in sk_miss)
L.append(f'new public declarations: {newd}; without a docstring: {len(nodoc)} {nodoc}')
L.append(f'new public theorems whose docstring has no backticked term with a relation symbol (a formula aid, not a '
         f'verdict): {len(noform)}')
L.extend('  ' + x for x in noform)
out('docs.txt', L)

# ---------------------------------------------------------------- sources.txt
CIT = re.compile(r'\[((?:PS10|LP09|BMR90|Gol04|Gol01|AB09|Gar26|LP07|Yao86|KL\d\d|BHR12|Lin17)[^\]]*)\]')
L = []
for p in (YAO, UNI):
    a = collections.Counter(CIT.findall(R.show(BASE, p))); b = collections.Counter(CIT.findall(R.show(HEAD, p)))
    L.append(f'{p}: citation groups tip {sum(a.values())} -> head {sum(b.values())}; added {dict(b - a)}; '
             f'removed {dict(a - b)}')
newc = collections.Counter()
reftags = {}
missing_refs = []
for p in PATHS:
    t = R.show(HEAD, p)
    groups = CIT.findall(t)
    if STATUS[p] == 'A':
        newc.update(groups)
    refsec = t.split('## References', 1)[1].split('-/', 1)[0] if '## References' in t else ''
    TAG = re.compile(r'^\s*([A-Z][A-Za-z]*\d{2})\b')
    tags = {m.group(1) for g in groups for x in g.split(';') for m in [TAG.match(x)] if m}
    declared = set(re.findall(r'\[([A-Za-z]+\d+)\]', refsec))
    for tg in sorted(tags):
        reftags.setdefault(tg, 0); reftags[tg] += 1
        if tg not in declared:
            missing_refs.append(f'{p.split("/")[-1]}: [{tg}]')
L.append(f'new files: {sum(newc.values())} citation groups, {len(newc)} distinct; tags by number of files: {reftags}')
L.append(f'tags used in a file but absent from its `## References`: {len(missing_refs)} {missing_refs}')
reg = json.loads(R.show(PIN, 'blueprint/src/references/sources.json'))['tags']
L.append(f'registry blueprint/src/references/sources.json at the pin: {sorted(reg)}')
L.append(f'  registered among the used tags: {[t for t in reftags if t in reg]}; unregistered: '
         f'{[t for t in reftags if t not in reg]}')
ps10refs = sorted(p for p in R.git('ls-tree', '--name-only', PIN, 'blueprint/src/references/').stdout.split()
                  if 'pass-shelat' in p)
L.append(f'  PS10 transcriptions at the pin: {ps10refs} (chapters 2-4 and the appendix; none for chapter 6); the PDF '
         f'"Pass–Shelat.pdf" at the root, blob {R.git("rev-parse", PIN + ":Pass–Shelat.pdf").stdout.strip()}')
ex = open(PS10TXT, encoding='utf-8').read()
pages = ex.split('\f')
loc = collections.Counter()
for g, n in (newc + collections.Counter(CIT.findall(R.show(HEAD, YAO)))).items():
    for part in g.split(';'):
        part = part.strip()
        m = re.match(r'(?:PS10,\s*)?((?:Definition|Protocol|Theorem|Algorithm|Construction|Claim|Proposition|Figure)'
                     r'\s+\d+\.[0-9a-z]+|§[\d.–-]+)', part)
        if m and (part.startswith('PS10') or g.startswith('PS10')):
            loc[m.group(1)] += n
L.append('PS10 locators in the new files and Yao.lean (count) -> lookup in sources.zip PS10/ (book page = PDF page - 12):')
for k, n in sorted(loc.items()):
    if k.startswith('§'):
        num = k[1:].split('–')[0].split('-')[0]
        hit = [i for i, pg in enumerate(pages) if re.search(rf'(?m)^\s*{re.escape(num)}\s', pg)]
    else:
        kind, num = k.split()
        hit = [i for i, pg in enumerate(pages) if re.search(rf'(?i)\b{kind}\s+{re.escape(num)}\b', pg)]
    where = [154 + i for i in hit]
    note = ''
    if re.search(r'\.[a-z]$', k):
        note = ' (inventory label for unnumbered text, briefs/pass-shelat-ch5-8/inventory-ch5-8.md)'
    L.append(f'  {k} ({n}): book pages {where or "not found"}{note}')
inv = R.show(PIN, 'briefs/pass-shelat-ch5-8/inventory-ch5-8.md')
for lab in ('Def-155.1', 'Alg-157.2', 'Claim-157.a', 'Constr-158.a', 'Claim-159.a', 'Prot-162.6', 'Thm-163.7'):
    row = [l for l in inv.splitlines() if l.startswith(f'| {lab} ')]
    L.append(f'  inventory row {lab}: {row[0][:160] + "…" if row else "absent"}')
out('sources.txt', L)

# ---------------------------------------------------------------- names.txt
def all_names(rev, paths=None):
    res = collections.defaultdict(list)
    for p in (paths or R.git('ls-tree', '-r', '--name-only', rev, 'TCSlib').stdout.split()):
        if p.endswith('.lean'):
            t = R.blob(rev, p)
            if t is None:
                continue
            for full, kind, line, priv in full_names(t.decode('utf-8')):
                res[full].append((p, line, kind, priv))
    return res


newn = {}
for p in PATHS:
    old = {f for f, *_ in full_names(R.show(BASE, p))} if STATUS[p] == 'M' else set()
    for full, kind, line, priv in full_names(R.show(HEAD, p)):
        if full not in old:
            newn[full] = (p, line, kind, priv)
cur = all_names(CUR)
L = [f'new declarations (namespace-resolved, private included): {len(newn)} ({sum(v[3] for v in newn.values())} private)',
     f'full-name matches against every TCSlib declaration at 201bf57a (with #327 and #324): '
     f'{[(k, cur[k]) for k in newn if k in cur]}']
d327 = R.git('diff', '--name-only', BASE, CUR, '--', 'TCSlib').stdout.split()
added_327_324 = {}
for p in d327:
    old = {f for f, *_ in full_names(R.show(BASE, p))} if R.blob(BASE, p) else set()
    for full, kind, line, priv in full_names(R.show(CUR, p)) if R.blob(CUR, p) else []:
        if full not in old:
            added_327_324[full] = (p, line)
short = collections.defaultdict(list)
for k, v in added_327_324.items():
    short[k.split('.')[-1]].append((k, v))
both = sorted({k.split('.')[-1] for k in newn} & set(short))
L.append(f'names added by #327/#324 ({BASE[:8]}..201bf57a, {len(d327)} TCSlib paths): {len(added_327_324)}; short names '
         f'shared with sc-yao\'s new names: {len(both)}')
for s in both:
    L.append(f'  {s}: sc-yao {[k for k in newn if k.split(".")[-1] == s]} | #327/#324 {[k for k, _ in short[s]]}')
yp = [k for k in newn if newn[k][3]]
L.append(f'sc-yao private names whose full name exists elsewhere at 201bf57a: {[k for k in yp if k in cur]}')
yaopriv = [f for f, kind, line, priv in full_names(R.show(HEAD, YAO)) if priv]
L.append(f'Yao.lean private declarations at the head: {yaopriv}; a public helper of the same full name: '
         f'{[k for k in yaopriv if k in newn]}')
out('names.txt', L)

# ---------------------------------------------------------------- mergetrees.txt
L = []
for lab, x in [('records pin', PIN), ('201bf57a (#327, #324 merged)', CUR)] + [(f'#{n}', h) for n, h in OPEN.items()]:
    tree, rc, txt = R.mergetree(HEAD, x)
    mb = R.git('merge-base', HEAD, x).stdout.strip()
    other = set(R.git('diff', '--name-only', mb, x).stdout.split())
    L.append(f'{lab} {x[:8]}: merge-tree rc {rc} ({"clean" if rc == 0 else "CONFLICT"}), tree {tree[:12]}; merge base '
             f'{mb[:8]}; paths changed on that side {len(other)}; shared with the PR {sorted(other & set(PATHS))}')
g = R.graph(HEAD)
down = sorted(downstream(g, PATHS))
L.append(f'modules downstream of the PR\'s changed files at the head (import graph of TCSlib and audits, the files '
         f'included): {len(down)}; outside the PR: {len([m for m in down if m not in PATHS])}: '
         f'{[m for m in down if m not in PATHS]}')
clo = sorted(p for p in set().union(*[closure(g, [p]) for p in PATHS]) if p.startswith('TCSlib'))
L.append(f'import closure at the head of the changed files (TCSlib modules, the files included): {len(clo)} '
         f'(= sources.zip\'s TCSlib part)')
oo = R.git('ls-tree', '-r', '--name-only', CUR, 'TCSlib').stdout.split()
chg_closure = [p for p in clo if p not in PATHS and R.blob(BASE, p) != R.blob(CUR, p)]
L.append(f'closure modules changed between {BASE[:8]} and 201bf57a: {chg_closure}')
out('mergetrees.txt', L)

# ---------------------------------------------------------------- dupscan.txt
def find_decl(rev, path, name):
    t = R.show(rev, path)
    if not t:
        return None
    sp = decl_spans(t)
    key = [k for k in sp if k.split('#')[0] == name]
    if not key:
        return None
    s, i, j = sp[key[0]]
    return i + 1, '\n'.join(t.split('\n')[s:j])


def grep(rev, rx, pathspec='TCSlib'):
    r = R.git('grep', '-n', '-E', rx, rev, '--', pathspec, check=False).stdout
    return [x[len(rev) + 1:] for x in r.splitlines()]


L = []
show = [
    ('SY-F02', CUR, 'TCSlib/Cryptography/Candidates/DDH.lean', 'statClose_of_uprob_ne'),
    ('SY-F02', HEAD, HUB + '/StatisticalSwitch.lean', 'statClose_of_eq_off'),
    ('SY-F02', HEAD, HUB + '/StatisticalSwitch.lean', 'distAdv_le_of_eq_off'),
    ('SY-F03', HEAD, 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/Machines.lean', 'encodeMsgs_eq_flatMap'),
    ('SY-F03', HEAD, HUB + '/Lengths.lean', 'encodeMsgs_eq_encWords'),
    ('SY-F03 (addendum)', CUR, 'TCSlib/Cryptography/Composability/SequentialZK/Normalization.lean',
     'encodeMsgs_eq_encWords'),
    ('SY-F05', HEAD, SC + 'Garbling/CoinBlocks.lean', 'assignmentFold_small'),
    ('SY-F05', HEAD, HUB + '/OTAnswerWords.lean', 'length_answersB'),
    ('SY-F05', HEAD, HUB + '/OTAnswerWords.lean', 'answersA_nil'),
    ('SY-F05 (addendum)', CUR, SC + 'ComposeSecurity/Lengths.lean', 'length_answersB'),
    ('SY-F05 (addendum)', CUR, SC + 'ComposeSecurity/Lengths.lean', 'length_answersA'),
]
for tag, rev, path, name in show:
    r = find_decl(rev, path, name)
    L.append(f'--- {tag}: {name} in {path} at {rev[:8]}: ' + (f'line {r[0]}' if r else 'NOT FOUND'))
    if r:
        L.extend('    ' + x for x in r[1].split('\n')[:40])
a = find_decl(HEAD, HUB + '/Lengths.lean', 'encodeMsgs_eq_encWords')
b = find_decl(CUR, 'TCSlib/Cryptography/Composability/SequentialZK/Normalization.lean', 'encodeMsgs_eq_encWords')
if a and b:
    cut = lambda s: s[s.find('theorem'):]
    ren = lambda t: re.sub(r'\bw\b', 'm', re.sub(r'\bL\b', 'h', t))
    L.append(f'SY-F03 addendum check: sc-yao\'s and #327\'s encodeMsgs_eq_encWords equal from the keyword to the end of '
             f'the proof: byte {cut(a[1]) == cut(b[1])}; after renaming the bound variables L -> h, w -> m: '
             f'{ren(cut(a[1])) == cut(b[1])}; docstrings equal {a[1][:a[1].find("theorem")] == b[1][:b[1].find("theorem")]} '
             f'(so: the same statement and proof up to bound-variable names, with different docstrings)')
for rx, why in [(r'SimulatorNumeric', 'SY-F03 copy file'), (r'theorem encodeMsgs_eq_flatMap', 'SY-F03 copies')]:
    L.append(f'git grep {rx!r} at 201bf57a ({why}): ' + '; '.join(x.split(':')[0] + ':' + x.split(':')[1]
                                                                    for x in grep(CUR, rx)[:6]))
for nm, why in [('def transduce', 'SY-F06 Complexity.transduce'), (r'MajLoop', 'SY-F06 StateLoop.MajLoop.acc'),
                ('statClose_prod_of_forall', 'SY-F06'), ('theorem abs_sub_le_sum_hybrids', 'SY-F06'),
                (r'theorem distAdv_chain_le|theorem distAdv_fibers_le|def scan\b|def acc\b', 'SY-F06, sc-yao side')]:
    hits = grep(HEAD, nm)
    L.append(f'git grep {nm!r} at the head ({why}): {len(hits)} hits: ' +
             '; '.join(x.split(':')[0].replace('TCSlib/', '') + ':' + x.split(':')[1] for x in hits[:8]))
g8 = {k: collections.Counter() for k in ('List.getD_eq_getElem', 'List.getElem_ofFn')}
for p in PATHS:
    if p.startswith(HUB):
        for l in strip_comments(R.show(HEAD, p)).split('\n'):
            for k in g8:
                if k in l:
                    g8[k][p.split('/')[-1]] += 1
for k, c in g8.items():
    L.append(f'SY-F08 aid: helper code lines (comments stripped) containing {k}: {sum(c.values())} in {len(c)} files {dict(c)}')
both = collections.Counter()
for p in PATHS:
    if p.startswith(HUB):
        t = strip_comments(R.show(HEAD, p))
        both[p.split('/')[-1]] = len(re.findall(r'List\.getD_eq_getElem[^\n]*(?:\n[^\n]*){0,3}?List\.getElem_ofFn', t))
L.append(f'  getD_eq_getElem followed within 3 lines by getElem_ofFn (the getD-of-ofFn chain): {sum(both.values())} in '
         f'{len(+both)} files {dict(+both)}')
dl47 = []
for p in PATHS:
    if p.startswith(HUB):
        t = R.show(HEAD, p)
        for k, v in decls(t).items():
            h = v[2]
            hh = ws(h)
            if v[0] in ('theorem', 'lemma') and re.search(
                    r':\s*\(+List\.ofFn (\w+)\)(?:\.drop \(?(\w+)\)?\))?\.(?:getD|headD)(?: \(?(\w+)\)?)? \S+ = \1 \S+$', hh):
                dl47.append(f'{p.split("/")[-1]}:{v[1]} {k}')
L.append(f'DL-47 aid: new theorems whose whole conclusion is `(List.ofFn f).getD i d = f i` or '
         f'`((List.ofFn f).drop i).headD d = f i` (the DL-47 shape, whitespace-normalized): {len(dl47)} {dl47}')
led = R.show(PIN, 'briefs/pass-shelat-ch5-8/duplication-ledger.md')
for row in ('DL-46', 'DL-47', 'DL-49'):
    r = [l for l in led.splitlines() if l.startswith(f'| {row} ')]
    L.append(f'ledger {row} at the pin: {r[0][:300] + "…" if r else "absent"}')
L.append(f'ledger rows naming sc-yao at the pin: {[l[:12] for l in led.splitlines() if "sc-yao" in l]}')
L.append('')
L.append(f'rulings after the pin: {RUL} (descendant of the pin: {R.anc(PIN, RUL)}; TCSlib/root/audits/scripts/lake paths '
         f'changed pin..{RUL[:8]}: {len(R.git("diff", "--name-only", PIN, RUL, "--", "TCSlib", "TCSlib.lean", "audits", "scripts", "lakefile.lean", "lake-manifest.json", "lean-toolchain").stdout.split())})')
led2 = R.show(RUL, 'briefs/pass-shelat-ch5-8/duplication-ledger.md')
for row in ('DL-49', 'DL-51'):
    r = [l for l in led2.splitlines() if l.startswith(f'| {row} ')]
    L.append(f'ledger {row} at {RUL[:8]}: {r[0] if r else "absent"}')
L.append('ledger rows against the code (each cited declaration at its cited place):')
for rev, path, line, name in [
        (HEAD, HUB + '/Lengths.lean', 83, 'encodeMsgs_eq_encWords'),
        (CUR, 'TCSlib/Cryptography/Composability/SequentialZK/Normalization.lean', 40, 'encodeMsgs_eq_encWords'),
        (HEAD, HUB + '/StatisticalSwitch.lean', None, 'statClose_of_eq_off'),
        (HEAD, HUB + '/StatisticalSwitch.lean', None, 'distAdv_le_of_eq_off'),
        (CUR, 'TCSlib/Cryptography/Candidates/DDH.lean', 145, 'statClose_of_uprob_ne'),
        (HEAD, 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/Machines.lean', 912, 'encodeMsgs_eq_flatMap')]:
    t = R.show(rev, path).split('\n')
    at = [i + 1 for i, l in enumerate(t) if re.match(rf'^(?:private\s+)?theorem {name}\b', l)]
    L.append(f'  {path}:{line or "-"} {name} at {rev[:8]}: declared at lines {at}; '
             f'{"matches the cited line" if line and line in at else ("present" if at and not line else "MISMATCH")}')
if a and b:
    L.append(f'  DL-49\'s extension calls the two encodeMsgs_eq_encWords "verbatim copies of each other": byte-identical from the '
             f'keyword {cut(a[1]) == cut(b[1])}; identical after renaming bound variables {ren(cut(a[1])) == cut(b[1])}; '
             f'docstrings identical {a[1][:a[1].find("theorem")] == b[1][:b[1].find("theorem")]}')
rul = R.show(RUL, EV + 'rulings.md')
L.append(f'{EV}rulings.md at {RUL[:8]}: SY-F01 confirmed {"**Confirmed.**" in rul}; SY-F05 remainder named as still open '
         f'{"Still open" in rul and "SY-F05" in rul}')
rep = R.show(FINAL, ROOT + 'REPORT.md')
L.append(f'worker REPORT § Overlap and reuse at line {[i + 1 for i, l in enumerate(rep.splitlines()) if l.startswith("## Overlap and reuse")]}; '
         f'mentions of statClose_of_uprob_ne {rep.count("statClose_of_uprob_ne")}, encodeMsgs_eq_flatMap '
         f'{rep.count("encodeMsgs_eq_flatMap")}, assignmentFold_small {rep.count("assignmentFold_small")}, '
         f'length_answersB {rep.count("length_answersB")}, transduce {rep.count("transduce")}, MajLoop {rep.count("MajLoop")}')
out('dupscan.txt', L)

# ---------------------------------------------------------------- rule10.txt
ERR = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
L = ['recount from the review evidence ZIP (the pin): every raw seal and control log, both error forms '
     '(`error:` and `error(`), with install and EOF records']
logs = sorted(n for n in names if n.endswith('.log') and re.match(r'phase2/(seal|control)-runs/mods/ScYaoSeal', n))
tab = {}
for n in logs:
    t = EVZ.read(n).decode('utf-8', 'replace')
    m = re.match(r'phase2/(?:seal|control)-runs/mods/ScYaoSeal(Base)?_(coe|strict)_(Seal[AB])_(.*)\.log$', n)
    if not m:
        continue
    base, var, ab, mod = m.groups()
    e1 = len(re.findall(r'^\S+\.lean:\d+:\d+: error:', t, re.M)); e2 = len(re.findall(r'^\S+\.lean:\d+:\d+: error\(', t, re.M))
    ends = re.findall(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', t)
    tab[(bool(base), var, ab, mod)] = (e1, e2, 'phase=install' in t, 'phase=eof' in t, len(ends),
                                        all(a == b for a, b in ends), sum(int(a) for a, _ in ends))
L.append(f'seal logs (phase2/seal-runs/mods/ScYaoSeal_*, and the tip seals phase2/control-runs/mods/ScYaoSealBase_*): '
         f'{len(logs)}; parsed {len(tab)}')
for key in sorted(tab):
    base, var, ab, mod = key
    e1, e2, inst, eof, nend, ver, req = tab[key]
    if 'HybridProof' in mod:
        continue
    L.append(f'  {"tip " if base else "head"} {var:6s} {ab} {mod}: error: {e1}, error( {e2}; install {inst}, eof {eof}, '
             f'SEAL-END parts {nend}, requested = verified {ver}, requests {req}')
helpers = {k: v for k, v in tab.items() if 'HybridProof' in k[3] and not k[0]}
cA = [k for k in helpers if k[1] == 'coe' and k[2] == 'SealA']
L.append(f'helper and hub seals (head): {len(helpers)}; coe-A {len(cA)}, all 0 errors: '
         f'{all(sum(helpers[k][:2]) == 0 for k in cA)}; other variants {len(helpers) - len(cA)} '
         f'({sorted({k[3].split("_")[-1] for k in helpers if k not in cA})}), all 0 errors: '
         f'{all(sum(v[:2]) == 0 for v in helpers.values())}; every helper log with install and eof records and '
         f'requested = verified: {all(v[2] and v[3] and v[5] and v[4] > 0 for v in helpers.values())}')
ctl = sorted(n for n in names if re.match(r'phase2/control-runs/mods/ScYaoCtl_', n) and n.endswith('.log'))
L.append(f'control probe logs (phase2/control-runs/mods/ScYaoCtl_*): {len(ctl)} '
         f'(coe {sum("_coe_" in n for n in ctl)}, strict {sum("_strict_" in n for n in ctl)})')
for f in ('phase2/seal-sum-coe-A.tsv', 'phase2/seal-sum-coe-B.tsv', 'phase2/seal-sum-strict-A.tsv',
          'phase2/seal-sum-strict-B.tsv', 'phase2/seal-sum-base-coe-A.tsv', 'phase2/seal-sum-base-coe-B.tsv',
          'phase2/seal-sum-base-strict-A.tsv', 'phase2/seal-sum-base-strict-B.tsv'):
    rows = [x.split('\t') for x in EVZ.read(f).decode().splitlines() if x.strip()]
    L.append(f'{f}: {len(rows)} seals, errors {sum(int(r[3]) for r in rows)} '
             f'({[(r[0].split("_", 1)[1], int(r[3])) for r in rows if int(r[3])]}); all install/EOF '
             f'{all(r[4] == "1" and r[5] == "1" for r in rows)}')
for f in ('phase2/ctlcheck-coe.log', 'phase2/ctlcheck-strict.log', 'phase2/ctlcheck-strict-attribution.txt'):
    t = EVZ.read(f).decode()
    L.append(f'{f}: last lines: ' + ' | '.join(t.strip().splitlines()[-3:]))
att = EVZ.read('phase2/yao-B-attribution.txt').decode().splitlines()
L.append('phase2/yao-B-attribution.txt (first lines): ' + ' | '.join(x.strip() for x in att[:1]))
sg = 'briefs/pass-shelat-ch5-8/fills/sc-garble/final-r1/review-evidence.zip'
sgz = zipfile.ZipFile(io.BytesIO(R.blob(PIN, sg)))
sgB = [x for x in sgz.read('logs/seal-head-seals-coe-B.tsv').decode().splitlines() if 'SecureComputation_Yao\t' in x]
L.append(f'the tip\'s Yao seal B (sc-garble review, {sg} at the pin, logs/seal-head-seals-coe-B.tsv): {sgB}; sc-garble\'s '
         f'head Yao.lean = the tip\'s: {R.blob("cd9a48438c2a6548fe9e246ce569be57c9df96b3", YAO) == R.blob(BASE, YAO)}')
out('rule10.txt', L)

# ---------------------------------------------------------------- rule10-errors.txt
L = ['every error diagnostic of the frozen files\' seals, read from the raw logs in the review evidence ZIP (the pin), '
     'with its full message and the declaration that contains it in the seal probe source '
     '(phase2/probe-sources-run/<run>/<seal>.lean.txt); the logs are too large to copy (3.3 MB each for Yao.lean), so '
     'their manifest hashes are given to verify against the ZIP at its committed path']
man_ev = {pth: h for h, pth in (x.split('  ', 1) for x in EVZ.read('SHA256SUMS').decode().splitlines())}
DKW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma|def|abbrev|instance|'
                 r'structure|inductive)\s+([^\s({:\[]+)')
for run, seal, mod in [(r, s_, m) for m in ('Cryptography_SecureComputation_Yao', 'Complexity_CircuitComplexity_Uniform')
                       for r in ('ScYaoSeal_coe', 'ScYaoSeal_strict', 'ScYaoSealBase_coe', 'ScYaoSealBase_strict')
                       for s_ in ('SealA', 'SealB')]:
    d = 'control-runs' if 'Base' in run else 'seal-runs'
    lg = f'phase2/{d}/mods/{run}_{seal}_{mod}.log'
    src = f'phase2/probe-sources-run/{run}/{seal}_{mod}.lean.txt'
    if lg not in man_ev:
        continue
    t = EVZ.read(lg).decode('utf-8', 'replace').split('\n')
    so = EVZ.read(src).decode('utf-8').split('\n')
    idx = [i for i, l in enumerate(t) if re.match(r'^\S+\.lean:\d+:\d+: error', l)]
    owners = collections.Counter()
    blocks = []
    for i in idx:
        j = i + 1
        while j < len(t) and not re.match(r'^(\S+\.lean:\d+:\d+: |G06-)', t[j]):
            j += 1
        ln = int(t[i].split(':')[1])
        k = ln - 1
        while k >= 0 and not DKW.match(so[k]):
            k -= 1
        owner = DKW.match(so[k]).group(1) if k >= 0 else '?'
        owners[owner] += 1
        blocks.append((owner, t[i:j]))
    L.append('')
    L.append(f'=== {lg} (manifest sha256 {man_ev[lg]}; probe source {src}, sha256 {man_ev.get(src)}): {len(idx)} errors; '
             f'by declaration {dict(owners)}')
    if 'Yao' in mod and seal == 'SealB' and run == 'ScYaoSeal_coe' or 'Uniform' in mod and run == 'ScYaoSeal_coe' and seal == 'SealA':
        for owner, b in blocks:
            L.append(f'--- [{owner}]')
            L.extend('    ' + x for x in b)
out('rule10-errors.txt', L)
print('wrote', ', '.join(sorted(files)))
