"""mkverif42.py <repo> <checks-dir> <tools-dir> <pr-dir> <sources.zip> <out.zip>: the verification ZIP of Gate 42
(sc-yao, draft PR #341, Lean head e9b03c437aca251846430ff23b40ee5ff3d3347a; records pin
f22e0f6798815b9263893e61928b4f16452f74ee). No Lean or lake is run; everything is read from git objects.

Members are byte-identical originals, except PROVENANCE.txt, SHA256SUMS, review-evidence-POINTER.txt and pr/pr-341.json:
- review-evidence-SHA256SUMS: the records copy fills/sc-yao/final-r1/evidence-SHA256SUMS at the pin (= the ZIP's inner
  manifest); review-evidence-POINTER.txt: the committed path, size and SHA-256 of the 19 MB review evidence ZIP at the
  pin, which is NOT copied here (every entry the pack cites is, under evidence/, each checked against the manifest);
- landing/PROVENANCE.txt: the review's landing PROVENANCE (records copy at the pin, = the ZIP's entry);
- evidence/: byte copies of the review-evidence entries the pack cites (read from the ZIP blob at the pin); entries
  that contain a model identifier (the three landing-edit patch files carry commit trailers) are not copied;
- records/: the campaign records the pack cites, at the pin; records-history/9902d727/: the interim (Phase 1) review,
  which the final review supersedes and refers to for the Phase 1 detail; records-after-pin/67423db6/: Seyoon's rulings
  on SY-F01 to SY-F03 (fills/sc-yao/final-r1/rulings.md) with the ledger (DL-49 extended, DL-51) and deferred-work
  register they changed, at the records commit 67423db6c9d6448ae531b04f42c315585d00d502 (records only, after the pin);
- worker/final/: byte copies from the final delivery, exchange 47c38c479e4be52654cd2c055141dfb64be975c4 (inbox/fills/sc-yao/);
- context/: library files that the duplication questions compare against and that are not in sources.zip (whose
  TCSlib part is the head's import closure): at 201bf57a (#327 and #324 merged) or at the head;
- pr/: the PR #341 description (GitHub MCP read, equal byte for byte to the REST `.body`) and the REST metadata
  fields the re-checks read;
- pack-checks/: the pack's re-checks from git objects, with their scripts (pack-checks/tools/).
Writes PROVENANCE.txt and SHA256SUMS (every other entry)."""
import collections, hashlib, io, json, os, re, subprocess, sys, zipfile

repo, chk, tools, prd, srczip, out = sys.argv[1:7]


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


PIN = 'f22e0f6798815b9263893e61928b4f16452f74ee'
RUL = '67423db6c9d6448ae531b04f42c315585d00d502'
HEAD = 'e9b03c437aca251846430ff23b40ee5ff3d3347a'
CUR = '201bf57a941131d1737295089ffd7477e1d7f7b9'
INTERIM = '9902d727b89dc8ff8be77ddbe677371c7a4f6158'
FINAL = '47c38c479e4be52654cd2c055141dfb64be975c4'
EV = 'briefs/pass-shelat-ch5-8/fills/sc-yao/final-r1/'
assert git('merge-base', '--is-ancestor', INTERIM, PIN) == b''
assert git('merge-base', '--is-ancestor', PIN, RUL) == b''
sha = lambda b: hashlib.sha256(b).hexdigest()
# model names are written with bracket classes so that this file itself contains none
MODEL = re.compile(rb'O[p]us|S[o]nnet|H[a]iku|g[p]t-?\d|c[o]dex-(?:mini|\d)|g[e]mini', re.I)
members, skipped = [], []


def add(dst, b, desc):
    if MODEL.search(b):
        skipped.append((dst, desc)); return
    members.append((dst, b, desc))


def rec(path, dst=None, rev=PIN):
    add(dst or f'records/{path}', git('show', f'{rev}:{path}'), f'records {rev[:8]}:{path}')


# review evidence
zb = git('show', f'{PIN}:{EV}review-evidence.zip')
z = zipfile.ZipFile(io.BytesIO(zb))
man = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in z.read('SHA256SUMS').decode().splitlines()}
recman = git('show', f'{PIN}:{EV}evidence-SHA256SUMS')
assert recman == z.read('SHA256SUMS')
add('review-evidence-SHA256SUMS', recman, f'records {PIN[:8]}:{EV}evidence-SHA256SUMS (= the ZIP\'s inner SHA256SUMS)')
pointer = f"""The maintainer's review evidence for sc-yao r1 is not copied into this ZIP. It is committed at the records pin:

  path     {EV}review-evidence.zip
  commit   {PIN}
  blob     {git('rev-parse', f'{PIN}:{EV}review-evidence.zip').decode().strip()}
  size     {len(zb)} bytes
  SHA-256  {sha(zb)}
  entries  {len(z.namelist())}: the {len(man)} paths of its SHA256SUMS plus SHA256SUMS itself (no top folder)
  manifest review-evidence-SHA256SUMS in this ZIP (= {EV}evidence-SHA256SUMS at the pin = the ZIP's SHA256SUMS)

Fetch: `git show {PIN}:{EV}review-evidence.zip > review-evidence.zip`, or
https://github.com/Shilun-Allan-Li/tcslib/raw/{PIN}/{EV}review-evidence.zip

Every entry the pack cites is copied under evidence/ in this ZIP (the same path inside the review ZIP), each checked
against the manifest; pack-checks/manifests.txt verifies all {len(man)} manifest rows against the ZIP blob at the pin.
""".encode()
add('review-evidence-POINTER.txt', pointer, 'generated: the pointer to the committed review evidence ZIP')
rec(f'{EV}landing/PROVENANCE.txt', 'landing/PROVENANCE.txt')
CITE = [
    'admissions/source-sorry-bodies.txt',
    'docs/sketchaudit.txt', 'docs/stepcomments.txt', 'docs/docclass.txt', 'docs/docaudit.tsv', 'docs/docaudit2.tsv',
    'dup/internal-dups.txt', 'dup/nameclash-tip-new.txt', 'dup/new-public-names.txt', 'dup/tip-statement-matches.txt',
    'dup/tip-statement-matches-loose.txt',
    'host/slots-analysis.txt',
    'integrity/changed-paths.txt', 'integrity/git-am-reproduction.txt', 'integrity/issue-package-check.txt',
    'integrity/issue-source-sums.txt', 'integrity/manifest-evidence.txt', 'integrity/manifest-top.txt',
    'integrity/src-equality.txt',
    'landing/PROVENANCE.txt', 'landing/changed-paths-vs-tip.txt', 'landing/cherry-pick-1.log', 'landing/cherry-pick-2.log',
    'landing/cherry-pick-3.log', 'landing/commits-signing.txt', 'landing/commits.tsv', 'landing/diffstat.txt',
    'landing/head-tree.txt', 'landing/head.txt', 'landing/le-and-yao.diff', 'landing/range-diff-rebase.txt',
    'landing/tip.txt', 'landing/uniform-scope-vs-tip.txt', 'landing/yao-scope-vs-tip-final.txt',
    'landing/yao-scope-vs-tip-pre-le.txt',
    'layout/children.txt', 'layout/external-imports.txt', 'layout/hub-imports.txt', 'layout/import-order-check.txt',
    'layout/size-width.txt',
    'lint/linediff-base-final.txt', 'lint/linediff-tip-head-complexity.txt', 'lint/linediff-tip-head-ledoc.txt',
    'lint/linediff-tip-landing.txt',
    'phase2/PROVENANCE-phase2.txt', 'phase2/axioms-summary.txt', 'phase2/build-head/summary.txt',
    'phase2/build-head/statecheck.txt', 'phase2/build-head/results.jsonl', 'phase2/yao-B-attribution.txt',
    'phase2/ctlcheck-coe.log', 'phase2/ctlcheck-strict.log', 'phase2/ctlcheck-strict-attribution.txt',
    'phase2/ctlcheck-coe.json', 'phase2/ctlcheck-strict.json', 'phase2/controls-coe.gen.log',
    'phase2/controls-strict.gen.log', 'phase2/seal-coe-names.txt', 'phase2/seal-records-pruned.txt',
    'phase2/ledoc/docstrip.txt', 'phase2/probe-src/AxiomsLand.lean', 'phase2/probe-src/CollectLand.lean',
    'phase2/probe-src/owners.txt', 'phase2/probe-runs/results.jsonl', 'phase2/probe-runs/mods/ScYaoProbe_AxiomsLand.log',
    'phase2/seal-runs/results.jsonl', 'phase2/control-runs/results.jsonl', 'phase2/touched-tip-uniform.json',
    'phase2/build-mathlib-extra/overlay-count.txt', 'phase2/restore/restore-log.txt',
    'rule10/delivered-axiom-trace-parse.txt', 'rule10/delivered-seal-recount.txt', 'rule10/reader-control-logs.txt',
    'rule10/reader-control-recount.txt', 'rule10/unfoldscan.txt',
    'scope/controls-results.txt', 'scope/dag-check.txt', 'scope/faninTwo-vs-tip.txt', 'scope/uniform-check.txt',
    'scope/yao-check.txt',
]
CITE += sorted(n for n in man if re.match(r'phase2/seal-sum-.*\.tsv$', n))
CITE += sorted(n for n in man if re.match(r'phase2/seal-runs/mods/ScYaoSeal_.*(DAGCircuit|Uniform)\.log$', n))
CITE += sorted(n for n in man if re.match(r'phase2/control-runs/mods/ScYaoSealBase_.*\.log$', n))
CITE += sorted(n for n in man if re.match(r'phase2/probe-sources-run/ScYaoSeal(Base)?_(coe|strict)/Seal[AB]_'
                                           r'(Cryptography_SecureComputation_Yao|Complexity_CircuitComplexity_Uniform)'
                                           r'\.lean\.txt$', n))
CITE += sorted(n for n in man if re.match(r'tools/[^/]+\.py$', n))
CITE += sorted(n for n in man if re.match(r'phase2/tools-seal/(mkseals_sy|mkctl_sy|mkcollect|sealsum|sealtable|ctlcheck2|'
                                           r'censuscmp|sorrycensus)\.py$', n))
CITE += ['phase2/tools/stateplan.py', 'phase2/tools/buildsum.py', 'phase2/tools/treecheck.py', 'phase2/tools/runner.py']
assert len(set(CITE)) == len(CITE), [c for c in CITE if CITE.count(c) > 1]
for c in CITE:
    b = z.read(c)
    assert sha(b) == man[c], c
    add(f'evidence/{c}', b, f'review-evidence.zip entry {c} (manifest {man[c][:12]}…)')
# records at the pin
for f in ('README.md', 'brief.md', 'ruling-SY.md', 'SHA256SUMS', 'SOURCE-SHA256SUMS', 'base-sorries.txt', 'dispatch.md',
          'fill-environment-addendum.md', 'order.txt', 'roots.txt'):
    rec(f'briefs/pass-shelat-ch5-8/fills/sc-yao/issued-r1/{f}')
for f in ('review.md', 'post-merge-addendum.md', 'evidence-SHA256SUMS'):
    if f != 'evidence-SHA256SUMS':
        rec(f'{EV}{f}')
rec(f'{EV}review.md', f'records-history/{INTERIM[:8]}/{EV}review.md', rev=INTERIM)
for p in ('policy.md', 'PassShelatChapter5-8Plan.md', 'briefs/pass-shelat-ch5-8/duplication-ledger.md',
          'briefs/pass-shelat-ch5-8/deferred-work.md', 'briefs/pass-shelat-ch5-8/inventory-ch5-8.md',
          'briefs/pass-shelat-ch5-8/maintainer/securecomp-plan-2026-11-14/plan.md',
          'briefs/pass-shelat-ch5-8/fills/codex-host-2026-11-15/host-addendum.md',
          'briefs/pass-shelat-ch5-8/design/S3b-yao-hybrid.md', 'briefs/pass-shelat-ch5-8/design/S3b-yao-runWith.md',
          'briefs/pass-shelat-ch5-8/gates/27-b1-multimsg/resolutions-r1.md',
          'briefs/pass-shelat-ch5-8/gates/36-sc-garble/resolutions-r1.md',
          'briefs/pass-shelat-ch5-8/gates/36-sc-garble/resolutions-r2.md',
          'briefs/pass-shelat-ch5-8/gates/36-sc-garble/findings/gate36-sc-garble-findings.md',
          'briefs/pass-shelat-ch5-8/gates/36-sc-garble/findings-r2/gate36-sc-garble-r2-findings.md',
          'briefs/pass-shelat-ch5-8/fills/sc-garble/issued-r1/ruling-SG-1.md',
          'blueprint/src/references/sources.json'):
    rec(p)
for p in git('ls-tree', '-r', '--name-only', PIN, 'briefs/pass-shelat-ch5-8/gates/27-b1-multimsg/').decode().split():
    if '/findings' in p and p.endswith('.md'):
        rec(p)
for p in (f'{EV}rulings.md', 'briefs/pass-shelat-ch5-8/duplication-ledger.md', 'briefs/pass-shelat-ch5-8/deferred-work.md'):
    rec(p, f'records-after-pin/{RUL[:8]}/{p}', rev=RUL)
# worker files from the exchange
W = 'inbox/fills/sc-yao/'
wl = ['REPORT.md', 'SHA256SUMS', 'patches/COMMITS.tsv', 'evidence/WORKLOG.md', 'evidence/patch-reproduction.log',
      'evidence/final-frozen-seal-summary.json', 'evidence/final-helper-seal-summary.json',
      'evidence/final-security-audit-summary.json', 'evidence/final-publication-security-audit-summary.json',
      'evidence/final-sweep-summary.json', 'evidence/final-publication-sweep-summary.json',
      'evidence/headers/check_headers.py', 'evidence/headers/final-exact.log', 'evidence/headers/final-candidate-scope.json',
      'evidence/readers/manifest.json', 'evidence/clash/name_clash.py', 'evidence/clash/results.json',
      'evidence/reports/common-contract-disclosures.md', 'evidence/interfaces/source-inventory.json']
wl += sorted(p[len(W):] for p in git('ls-tree', '-r', '--name-only', FINAL,
                                      W + 'evidence/headers/final-exact/').decode().split()
             if not p.endswith(('.base', '.lean.txt')))
for d in ('evidence/scope-request/', 'evidence/unfold/', 'evidence/subagents/final-seal-attribution/'):
    wl += sorted(p[len(W):] for p in git('ls-tree', '-r', '--name-only', FINAL, W + d).decode().split())
wsums = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in git('show', f'{FINAL}:{W}SHA256SUMS').decode().splitlines()}
for p in wl:
    b = git('show', f'{FINAL}:{W}{p}')
    assert p == 'SHA256SUMS' or sha(b) == wsums[p], p
    add(f'worker/final/{p}', b, f'exchange {FINAL[:9]}:{W}{p}')
# context
src = zipfile.ZipFile(srczip)
inzip = {n for n in src.namelist() if n.startswith('TCSlib/')}
CTX = [(CUR, 'TCSlib/Cryptography/Composability/SequentialZK/Normalization.lean'),
       (CUR, 'TCSlib/Cryptography/SecureComputation/ComposeSecurity/Lengths.lean'),
       (CUR, 'TCSlib/Cryptography/SecureComputation/ComposeSecurity/Machines.lean'),
       (CUR, 'TCSlib/Cryptography/Candidates/DDH.lean'),
       (CUR, 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/Machines.lean'),
       (CUR, 'TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/SimulatorNumeric.lean'),
       (CUR, 'TCSlib/Complexity/ClassNP/Transducer.lean'),
       (CUR, 'TCSlib/Complexity/Randomized/Build/StateLoop.lean'),
       (CUR, 'TCSlib/Cryptography/SecureComputation/ObliviousTransfer/ViewA.lean'),
       (CUR, 'TCSlib/Cryptography/Foundations/Probability.lean'),
       (CUR, 'TCSlib/Cryptography/SecureComputation/YaoReal.lean'),
       (CUR, 'TCSlib/Cryptography/SecureComputation/ComposeSecurity.lean')]
for rev, p in CTX:
    b = git('show', f'{rev}:{p}')
    if p in inzip and src.read(p) == b:
        continue
    add(f'context/{p}', b, f'{"201bf57a (#327, #324 merged)" if rev == CUR else "head"} {rev[:8]}:{p}')
# PR
add('pr/pr-341-description.md', open(os.path.join(prd, 'pr-341-description.md'), 'rb').read(),
    'GitHub MCP pull_request_read (method get) for PR #341, .body, read 2026-11-16; equal byte for byte to REST GET '
    '/repos/Shilun-Allan-Li/tcslib/pulls/341 .body')
add('pr/pr-341.json', open(os.path.join(prd, 'pr-341.json'), 'rb').read(),
    'the REST fields the re-checks read (number, state, draft, head, base, changed_files, additions, deletions, commits, '
    'body), GET /repos/Shilun-Allan-Li/tcslib/pulls/341, fetched 2026-11-16')
for c in sorted(os.listdir(chk)):
    add(f'pack-checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}')
for t in sorted(os.listdir(tools)):
    if t.endswith('.py'):
        add(f'pack-checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}')
title = ('Gate 42 (sc-yao: draft PR #341, Lean head e9b03c437aca251846430ff23b40ee5ff3d3347a; records pin '
         'f22e0f6798815b9263893e61928b4f16452f74ee)')
prov = (f'{title}: verification.zip\n\nBuilt from git objects only (records pin {PIN}; rulings after the pin {RUL}; '
        f'interim review {INTERIM}; '
        f'exchange {FINAL}; 201bf57a = {CUR}). No Lean or lake was run.\n\n' + __doc__.split('\n\n', 1)[1] +
        '\nNot copied: the review ZIP\'s landing/series/0009-0011 patch files (the landing edits\' format-patch output, '
        'whose commit trailers name a model); the commits themselves are on the PR branch and pack-checks/lecheck.txt '
        're-reads them. Members skipped by the model-identifier filter: ' + (', '.join(p for p, _ in skipped) or 'none')
        + '\n' +
        '\nSources:\n' + ''.join(f'  {p}  <-  {d}\n' for p, _, d in sorted(members)))
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
assert len({p for p, _, _ in members}) == len(members), 'duplicate member'
assert not any(MODEL.search(b) for _, b, _ in members)
sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
members.append(('SHA256SUMS', sums.encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as zz:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=(2026, 11, 16, 0, 0, 0))
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_STORED if p.endswith(('.zip', '.pdf')) else zipfile.ZIP_DEFLATED
        zz.writestr(zi, b)
with zipfile.ZipFile(out) as zz:
    listed = zz.namelist()
    inn = {l.split('  ', 1)[1] for l in zz.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == inn | {'SHA256SUMS'} and len(listed) == len(inn) + 1
    for l in zz.read('SHA256SUMS').decode().splitlines():
        h, p = l.split('  ', 1)
        assert sha(zz.read(p)) == h, p
print(f'OK: {len(listed)} entries {dict(collections.Counter(n.split("/")[0] for n in listed))}; skipped {len(skipped)} '
      f'{[p for p, _ in skipped]}; sha256 {sha(open(out, "rb").read())}; size {os.path.getsize(out)}')
