# Gate 44 round 2 source bundle

Every entry is read from git objects; SHA-256 of the bytes and the origin `rev:path`.

- `pr346-head-98cb0e52/`, `pr346-round1-89a18a82/`: the three files LE-g44 changes, at LE-g44 (= T44's blobs) and at its parent.
- `T44p-bee027f0/`: `Candidates/DiscreteLog.lean`, home of `sampleBelowL` (line 578) and `statClose_sampleBelowL` (line 618), which LE-g44 cites; the same blob at T44, at 89a18a82 and at the records tip.
- `references/`: [PS10] section 2.8 (Theorem 52.3), the lines round 1 bundled.
- The source closure is round 1's `sources-r1.zip` (`T44-33681cb8/`); T44' differs from T44 only in the three LE-g44 files.

| Entry | SHA-256 | Origin |
|---|---|---|
| `pr346-head-98cb0e52/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Draws.lean` | `4532190ccbb5709d0599df72d1678f5c95584ece2919e4f4a5aec38a374f6b30` | `98cb0e521a94e94c304c78348fb5d3033435a3ed:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Draws.lean` |
| `pr346-round1-89a18a82/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Draws.lean` | `4645417997e38df096816b6b085ccd71ed83a069fc3547bf1da8ec903ffa6bfe` | `89a18a8225be1b76166af12a15179da291747783:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Draws.lean` |
| `pr346-head-98cb0e52/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Words.lean` | `b1e454a97822036f91841abce3ce603454b785c59b40c647b4b92110cfbb0d76` | `98cb0e521a94e94c304c78348fb5d3033435a3ed:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Words.lean` |
| `pr346-round1-89a18a82/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Words.lean` | `a31d6ac2a5c09d25b8004edcb1947451ffd44288018e8d9f964b9c122382f7cf` | `89a18a8225be1b76166af12a15179da291747783:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Words.lean` |
| `pr346-head-98cb0e52/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Handler.lean` | `63192cea1640c70d893ff900368c523590203cd9f6ba1a457c1814ee3a2cb229` | `98cb0e521a94e94c304c78348fb5d3033435a3ed:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Handler.lean` |
| `pr346-round1-89a18a82/TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Handler.lean` | `5d0c96a0c0659a9bed880036aa7f498a5b7a9adbd27c9c267f51f915b223983e` | `89a18a8225be1b76166af12a15179da291747783:TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/Handler.lean` |
| `T44p-bee027f0/TCSlib/Cryptography/Candidates/DiscreteLog.lean` | `53dc62e2f35843c55ee0a4513bd48d3eada29e5e618f09101f6f1095c7ab1920` | `bee027f0903d531b3a43511cea16bfa123210291:TCSlib/Cryptography/Candidates/DiscreteLog.lean` |
| `references/pass-shelat-2010-ch2.raw.lines1338-1420.md` | `c3c40915f3d8116c69e199b195a9c87cbb0096c98c8aea4834994e5091c0f326` | `4f4a7592a54cf82fa04f96b83645d7936672614c:blueprint/src/references/pass-shelat-2010-ch2.raw.md lines 1338-1420 (section 2.8, Theorem 52.3)` |
