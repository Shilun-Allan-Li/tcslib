 2.8 Discrete Logarithm-based Collection
 Another often used collection is based on the discrete logarithm
 problem in the group Z∗p for a prime p.

 2.8.1   Discrete logarithm modulo p
 An instance ( p, g, y) of the discrete logarithm problem consists
 of a prime p and two elements g, y ∈ Z∗p . The task is to find an
 x such that g x = y mod p. In some special cases (e.g., g = 1 or
 when p − 1 has many small prime factors), it is easy to either
 declare that no solution exists or solve the problem. However,
 when g is a generator of Z∗p , the problem is believed to be hard.
 52                              chapter 2. computational hardness


.Definition 52.1 (Generator of a Group) A element g of a multi-
 plicative group G is a generator if the set { g, g2 , g3 , . . .} = G. We
 denote the set of all generators of a group G by GenG .

.Assumption 52.2 (Discrete Log) If Gq is a group of prime order q,
 then for every adversary A, there exists a negligible function e such
 that
          h                                             i
       Pr q ← Πn ; g ← GenGq ; x ← Zq : A( g x ) = x < e(n)

 Recall that Πn is the set of n-bit prime numbers. Note that it is
 important that G is a group of prime-order. Thus, for example, the
 normal multiplicative group Z∗p has order ( p − 1) and therefore
 does not satisfy the assumption.
     Instead, one usually picks a prime of the form p = 2q + 1
 (known as a Sophie Germain prime or a “safe prime”) and then
 sets G to be the subgroup of squares in Z∗p . Notice that this
 subgroup has order q which is prime. The practical method for
 sampling safe primes is simple: first pick a prime q as usual,
 and then check whether 2q + 1 is also prime. Unfortunately,
 even though this procedure always terminates in practice, its
 basic theoretical properties are unknown. It is unknown even (a)
 whether there are an infinite number of Sophie Germain primes,
 (b) and even so, whether this simple procedure for finding them
 continues to quickly succeed as the size of q increases. Another
 way to instantiate the assumption is to use the points on an
 elliptic curve for which these issues do not arise.

.Theorem 52.3 Let DL = { f i : Di → Ri }i∈ I where
                      I = {(q, g) | q ∈ Πk , g ∈ GenGq }
                       D i = { x | x ∈ Zq }
                       Ri = G p
                f p,g ( x ) = g x

 If the Discrete Log Assumption holds, then DL is a collection of one-way
 functions.

 Proof. It is easy to sample the domain Di and to evaluate the
 function f p,g ( x ). The discrete log assumption implies that f p,g is
 2.9. RSA Collection                                                    53


 hard to invert. Thus, all that remains is to prove that I can be
 sampled efficiently. Unfortunately, given only a prime p, it is not
 known how to efficiently choose a generator g ∈ Gen p . However,
 it is possible to sample both a prime and a generator g at the same
 time. One approach proposed by Bach and later adapted by Kalai
 is to sample a k-bit integer x in factored form (i.e., sample the
 integer and its factorization at the same time) such that p = x + 1
 is prime. A special case of this approach is to pick safe primes
 of the form p = 2q + 1 as mentioned above. Given such a pair
 p, (q1 , . . . , qk ), one can use a central result from group theory to
 test whether an element is a generator. For example, in the case
 of safe primes, testing whether an element g ∈ Z∗p is a generator
 consists of checking g 6= ±1 mod p and gq 6= 1 mod p.                 
      As we will see later, the collection DL is also a special collec-
 tion of one-way functions in which each function is a permuta-
 tion.


 2.9 RSA Collection
 Another popular assumption is the RSA Assumption. The RSA
 Assumption implies the Factoring assumption; it is not known
 whether the converse is true.

.Assumption 53.1 (RSA Assumption) Given a triple ( N, e, y) such
 that N = pq where p, q ∈ Πn , gcd(e, Φ( N )) = 1 and y ∈ Z∗N ,
 the probability that any adversary A is able to produce x such that
 x e = y mod N is a negligible function e(n).
