#!/usr/bin/env bash
# axcheck.sh <tag>: axiom audit probe against the current olean of Hierarchy
. /work/f6/env.sh; cd "$TCSLIB_REPO"; tag=$1
cp /work/f6/tools/lean/axprobe.lean.txt ScratchProbes/Ax_$tag.lean
cp ScratchProbes/Ax_$tag.lean $EV/axioms/Ax_$tag.lean.txt
s0=$(date +%s); bash devtools/seyoon/leanelab.sh "$TCSLIB_REPO" "$TCSLIB_OLEANS" ScratchProbes/Ax_$tag.lean > $EV/axioms/Ax_$tag.out 2>&1; st=$?
echo "exit=$st secs=$(( $(date +%s)-s0 )) olean_sha256=$(sha256sum $TCSLIB_OLEANS/TCSlib/Complexity/SpaceComplexity/Hierarchy.olean | cut -c1-64) head=$(git rev-parse HEAD)" >> $EV/axioms/Ax_$tag.out
grep -o "AXSUMMARY.*\|'Complexity.space_universal' depends on axioms: \[[^]]*\]\|exit=.*" $EV/axioms/Ax_$tag.out
