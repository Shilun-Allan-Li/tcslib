#!/usr/bin/env bash
# final-static.sh <rev> <tag>: non-Lean final checks at a fill revision: declaration/public/import freeze,
# byte-level chunk comparison, static admission census over the 229 final-order files, style lints
# (base vs head), and simp/rw/unfold argument scans of the new declarations.
. /work/f6/env.sh; REV=$1; TAG=$2; B=3023dc1408c3d216fc07a7cbba9ae30135b861ed; F=TCSlib/Complexity/SpaceComplexity/Hierarchy.lean
cd /work/f6; L=evidence/logs; mkdir -p evidence/lint evidence/seal
test "$(git -C $TCSLIB_REPO rev-parse HEAD)" = "$(git -C $TCSLIB_REPO rev-parse $REV)" || { echo "HEAD is not $REV"; exit 1; }
test -z "$(git -C $TCSLIB_REPO status --porcelain -- TCSlib)" || { echo dirty; exit 1; }
python3 -I tools/freeze.py $TCSLIB_REPO $B $F > $L/freeze-$TAG.txt; echo "freeze: $(tail -1 $L/freeze-$TAG.txt)"
python3 -I tools/chunkcmp.py $TCSLIB_REPO $B $REV $F > $L/chunkcmp-$TAG.txt; echo "chunkcmp: $(sed -n 2p $L/chunkcmp-$TAG.txt)"
python3 -I tools/sorrycount.py $TCSLIB_REPO $REV $(sed 's/$/.lean/' $L/final-order.txt) > $L/static-sorry-$TAG.txt; echo "census: $(tail -1 $L/static-sorry-$TAG.txt)"
H=scratch/linttree; rm -rf $H; mkdir -p $H; git -C $TCSLIB_REPO archive $REV TCSlib scripts devtools campaign/duplication-ledger.md | tar -x -C $H
( cd $H && python3 -I scripts/style_lint.py $F > /work/f6/evidence/lint/style_lint-$TAG.txt 2>&1; echo "exit=$?" >> /work/f6/evidence/lint/style_lint-$TAG.txt
  python3 -I scripts/campaign_style_lint.py TCSlib/Complexity/SpaceComplexity > /work/f6/evidence/lint/campaign_style_lint-$TAG.txt 2>&1; echo "exit=$?" >> /work/f6/evidence/lint/campaign_style_lint-$TAG.txt )
echo "style_lint: $(grep -v '^exit' evidence/lint/style_lint-$TAG.txt | tail -3 | tr '\n' ' ')"
diff <(grep -v "^INFO\|^exit" evidence/lint/campaign_style_lint-base.txt) <(grep -v "^INFO\|^exit" evidence/lint/campaign_style_lint-$TAG.txt) > evidence/lint/campaign_style_lint-diff-$TAG.txt; echo "campaign lint diff lines: $(wc -l < evidence/lint/campaign_style_lint-diff-$TAG.txt)"
N=$(grep -o "Complexity\.f6_[A-Za-z_]*" $L/chunkcmp-$TAG.txt | sort -u | sed 's/Complexity.//' | tr '\n' ','); N="${N}space_universal"; echo "$N" > evidence/seal/new-declarations-$TAG.txt
python3 -I tools/argscan.py $TCSLIB_REPO $F "$N" > evidence/seal/argscan-$TAG.txt; echo "argscan: $(tail -1 evidence/seal/argscan-$TAG.txt)"
python3 -I tools/argall.py $TCSLIB_REPO $F "$N" > evidence/seal/argall-$TAG.txt; echo "argall: $(tail -1 evidence/seal/argall-$TAG.txt)"
