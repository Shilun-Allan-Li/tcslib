#!/usr/bin/env bash
# preflight.sh: addendum v2.6 preflight (disk floor 12 GiB, memory headroom 4 GiB)
. /work/f6/env.sh
echo "# preflight $(date -u +%FT%TZ)"; echo "nproc: $(nproc)"
echo "## cgroup"; cat /proc/self/cgroup
for f in memory.max memory.current memory.events; do echo "--- $f"; cat /sys/fs/cgroup/$f 2>&1; done
M=/sys/fs/cgroup/memory; echo "--- v1 memory.limit_in_bytes"; cat $M/memory.limit_in_bytes; echo "--- v1 memory.usage_in_bytes"; cat $M/memory.usage_in_bytes
echo "## /proc/meminfo"; cat /proc/meminfo
echo "## df"; df -B1 /work/f6 /work/f6/scratch $TMPDIR $HOME; df -T /work/f6 $TMPDIR $HOME
echo "## cgroup v1 memory.stat"; cat $M/memory.stat; echo "--- memory.failcnt $(cat $M/memory.failcnt)"; echo "--- memory.oom_control"; cat $M/memory.oom_control
python3 -I - <<'PY'
import os,re
M='/sys/fs/cgroup/memory/'
lim=int(open(M+'memory.limit_in_bytes').read()); use=int(open(M+'memory.usage_in_bytes').read())
st=dict(l.split() for l in open(M+'memory.stat'))
cache=int(st['total_cache']); shm=int(st['total_shmem']); inuse=use-cache+shm
mi={l.split(':')[0]:int(l.split()[1])*1024 for l in open('/proc/meminfo')}
phys=mi['MemTotal']; avail=mi['MemAvailable']
print('## computation'); print(f'limit={lim} usage={use} total_cache={cache} total_shmem={shm} in_use={inuse}')
head=min(lim-inuse,avail) if lim<phys else avail
print(f'headroom = {head} bytes = {head/2**30:.2f} GiB' + (' (cgroup limit >= physical; MemAvailable)' if lim>=phys else ''))
s=os.statvfs('/work/f6'); free=s.f_bavail*s.f_frsize
print(f'clone free disk = {free} bytes = {free/2**30:.2f} GiB (floor 12 GiB)')
print('VERDICT:', 'PASS' if free>=12*2**30 and head>=4*2**30 else 'FAIL', '(disk >= 12 GiB, headroom >= 4 GiB)')
PY
