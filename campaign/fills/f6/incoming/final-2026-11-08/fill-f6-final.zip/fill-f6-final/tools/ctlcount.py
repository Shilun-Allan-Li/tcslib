"""ctlcount.py <lean output> <pass|fail> <n definitions>: multiplicity checker for the paired seal
controls. pass: exactly 2n CONTROL|..|PASS lines (one per definition and mode, all distinct), no
FAIL line, no error, exit 0. fail: exactly 2n CONTROL|..|FAIL lines, all distinct, exactly 2n
`error` diagnostics each tagged RFL_CONTROL for the same (definition, mode), no PASS line, exit != 0."""
import re, sys
o = open(sys.argv[1], encoding='utf-8').read(); mode = sys.argv[2]; n = int(sys.argv[3])
ctl = re.findall(r'CONTROL\|([^|\s]+)\|(point|abstract)\|(PASS|FAIL)', o)
errs = re.findall(r': error: (?:[^\n]*?)RFL_CONTROL\|([^|\s]+)\|(point|abstract)\|', o)
allerr = len(re.findall(r': error', o))
m = re.search(r'^exit=(\d+)', o, re.M); code = int(m.group(1)) if m else None
want = 'PASS' if mode == 'pass' else 'FAIL'
got = [(a, b) for a, b, c in ctl if c == want]; other = [(a, b) for a, b, c in ctl if c != want]
ok = len(got) == 2 * n and len(set(got)) == 2 * n and not other
if mode == 'pass': ok = ok and allerr == 0 and code == 0
else: ok = ok and allerr == 2 * n and sorted(errs) == sorted(got) and code not in (None, 0)
print(f'definitions={n} controls_{want}={len(got)} distinct={len(set(got))} other={len(other)} errors={allerr} tagged_errors={len(errs)} exit={code}')
print('RESULT:', 'PASS' if ok else 'FAIL')
