#!/usr/bin/env bash
# sealrun.sh <tag> <comma-separated declarations> <space-separated sealed definitions> <space-separated -simp names>
# Sealed copy of the owned module (each new declaration in its own section with the seal attributes),
# elaborated once with leanelab.sh; then the paired delta controls, unsealed and sealed, with the
# multiplicity checker.
. /work/f6/env.sh; cd "$TCSLIB_REPO"; tag=$1; decls=$2; irr=$3; nosimp=$4; S=$EV/seal; mkdir -p $S
F=TCSlib/Complexity/SpaceComplexity/Hierarchy.lean
python3 -I /work/f6/tools/mkseal.py $F ScratchProbes/Seal_$tag.lean "$decls" "$(echo $irr | tr ' ' ',')" "$(echo $nosimp | tr ' ' ',')" > $S/Seal_$tag.gen 2>&1 || { cat $S/Seal_$tag.gen; exit 1; }
cp ScratchProbes/Seal_$tag.lean $S/Seal_$tag.lean.txt
s0=$(date +%s); bash devtools/seyoon/leanelab.sh "$TCSLIB_REPO" "$TCSLIB_OLEANS" ScratchProbes/Seal_$tag.lean > $S/Seal_$tag.out 2>&1; st=$?
echo "exit=$st secs=$(( $(date +%s)-s0 )) head=$(git rev-parse HEAD) source_sha256=$(sha256sum $F | cut -c1-64)" >> $S/Seal_$tag.out
echo "seal $tag exit=$st errors=$(grep -c ': error' $S/Seal_$tag.out) warnings=$(grep -c ': warning' $S/Seal_$tag.out) $(cat $S/Seal_$tag.gen | cut -c1-60)"
n=$(echo $irr | wc -w); NL="[$(echo $irr | sed 's/\([^ ]*\)/`\1/g; s/ /, /g')]"
for mode in unsealed sealed; do
  line=""; [ $mode = sealed ] && line="attribute [local irreducible] $irr"
  python3 -I - "$line" "$NL" > ScratchProbes/Controls_${tag}_$mode.lean <<'PY'
import sys
t = open('/work/f6/tools/lean/controls.lean.txt').read()
print(t.replace('SEAL_LINE', sys.argv[1]).replace('NAME_LIST', sys.argv[2]), end='')
PY
  cp ScratchProbes/Controls_${tag}_$mode.lean $S/Controls_${tag}_$mode.lean.txt
  bash devtools/seyoon/leanelab.sh "$TCSLIB_REPO" "$TCSLIB_OLEANS" ScratchProbes/Controls_${tag}_$mode.lean > $S/Controls_${tag}_$mode.out 2>&1; st=$?
  echo "exit=$st" >> $S/Controls_${tag}_$mode.out
  exp=pass; [ $mode = sealed ] && exp=fail
  python3 -I /work/f6/tools/ctlcount.py $S/Controls_${tag}_$mode.out $exp $n > $S/Controls_${tag}_$mode.check
  echo "controls $mode: $(tr '\n' ' ' < $S/Controls_${tag}_$mode.check)"
done
