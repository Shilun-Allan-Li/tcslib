#!/usr/bin/env bash
# dev.sh <file relative to clone> <tag>: one leanelab.sh elaboration (slot-locked, nice, -j4),
# raw output + timing to $EV/logs/dev/<tag>.out, copy of the source to <tag>.lean.txt
. /work/f6/env.sh; cd "$TCSLIB_REPO"; mkdir -p $EV/logs/dev
F=$1; tag=$2; O=$EV/logs/dev/$tag.out; cp "$F" $EV/logs/dev/$tag.lean.txt
s0=$(date +%s); echo "# $tag $F start $(date -u +%FT%TZ) head=$(git rev-parse --short HEAD)" > $O
/usr/bin/time -v -o $O.time bash devtools/seyoon/leanelab.sh "$TCSLIB_REPO" "$TCSLIB_OLEANS" "$F" >> $O 2>&1; st=$?
echo "# exit=$st secs=$(( $(date +%s)-s0 )) maxrss_kb=$(awk -F': ' '/Maximum resident/{print $2}' $O.time) end $(date -u +%FT%TZ)" >> $O
echo "$tag exit=$st errors=$(grep -c ': error' $O) warnings=$(grep -c ': warning' $O) secs=$(( $(date +%s)-s0 ))"
