export TCSLIB_REPO=/work/f6/clone
export TCSLIB_SCRATCH=/work/f6/scratch
export TCSLIB_LEAN_SLOTS=1
export TCSLIB_OLEANS=/work/f6/scratch/oleans
export TMPDIR=/work/f6/scratch/tmp
export EV=/work/f6/evidence
[ -d "$HOME/.elan/bin" ] && export PATH="$HOME/.elan/bin:$PATH"
