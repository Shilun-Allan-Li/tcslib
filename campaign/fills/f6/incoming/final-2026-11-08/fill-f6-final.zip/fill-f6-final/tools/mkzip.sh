#!/usr/bin/env bash
# mkzip.sh <name> <REPORT.md> [extra dir to include as extra/]: assemble a cumulative delivery zip
# from the pinned base to the fill branch HEAD, checksum it, zip it and verify the zip.
set -euo pipefail
. /work/f6/env.sh
NAME=$1; REP=$2; EXTRA=${3:-}; REV=${REV:-HEAD}
BASE=3023dc1408c3d216fc07a7cbba9ae30135b861ed; OWN=TCSlib/Complexity/SpaceComplexity/Hierarchy.lean
OUT=/work/f6/deliver; ST=$OUT/$NAME; rm -rf "$ST" "$OUT/$NAME.zip"; mkdir -p "$ST"/{patches,evidence,tools}
cd "$TCSLIB_REPO"
REV=$(git rev-parse "$REV")
test -z "$(git status --porcelain -- TCSlib)" || { echo "dirty TCSlib tree"; exit 1; }
cp "$REP" "$ST/REPORT.md"
mkdir -p "$ST/$(dirname $OWN)"; git show "$REV:$OWN" > "$ST/$OWN"
git format-patch -q -o "$ST/patches" "$BASE..$REV"
git diff "$BASE" "$REV" -- "$OWN" > "$ST/patches/cumulative-$NAME.diff"
git branch -f f6-delivery-tmp "$REV"; git bundle create "$ST/fill-f6-space-universal.bundle" "$BASE..f6-delivery-tmp" 2>/dev/null; git branch -D f6-delivery-tmp >/dev/null
echo "$REV" > "$ST/HEAD.txt"; echo "$BASE" > "$ST/BASE.txt"
git log --format='%H %an <%ae> %cI %s' "$BASE..$REV" > "$ST/COMMITS.txt"
{ echo "base $(git show $BASE:$OWN | sha256sum | cut -c1-64) $OWN"; echo "head $(git show $REV:$OWN | sha256sum | cut -c1-64) $OWN"; } > "$ST/SOURCE-SHA256.txt"
cp -r "$EV/logs" "$ST/evidence/logs"
for d in seal screens axioms probes; do [ -d "$EV/$d" ] && cp -r "$EV/$d" "$ST/evidence/$d"; done
cp /work/f6/env.sh "$ST/tools/"; cp -r /work/f6/tools/. "$ST/tools/"
[ -n "$EXTRA" ] && cp "$EXTRA"/*.md "$ST/"
python3 -I - "$ST" "$NAME" <<'PY'
import json, os, hashlib, sys, subprocess
st, name = sys.argv[1], sys.argv[2]
files = []
for root, _, fs in os.walk(st):
    for f in sorted(fs):
        p = os.path.join(root, f); rel = os.path.relpath(p, st)
        if rel in ('MANIFEST.json', 'SHA256SUMS'): continue
        files.append({'path': rel, 'bytes': os.path.getsize(p), 'sha256': hashlib.sha256(open(p, 'rb').read()).hexdigest()})
files.sort(key=lambda d: d['path'])
m = {'delivery': name, 'fill': 'F6 space_universal (Claude, ruler-hosted suffix)',
     'repository': 'https://github.com/Shilun-Allan-Li/tcslib', 'proof_base_branch': 'complexity/arora-barak-ch3-4',
     'proof_base': open(os.path.join(st, 'BASE.txt')).read().strip(), 'work_branch': 'fill/f6-space-universal',
     'head': open(os.path.join(st, 'HEAD.txt')).read().strip(),
     'records_commit': 'f41bdaea207724606d8934bfc2c9a823c5dd1e2f',
     'exchange_commit_of_bundle': '2adb80788611696d2cad6f907285c0c5a197ae09',
     'bundle': 'arora-barak-ch3-4/outbox/fills/f6-space-universal/f6-space-universal-bundle.md',
     'bundle_sha256': '8fa482702846898f7fa04c4e1b0aa012300b4febaa6385ee8caa869cf14740be', 'bundle_sections': 624,
     'owned_file': 'TCSlib/Complexity/SpaceComplexity/Hierarchy.lean', 'files': files}
json.dump(m, open(os.path.join(st, 'MANIFEST.json'), 'w'), indent=1)
PY
( cd "$ST" && find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS )
( cd "$OUT" && zip -qr "$NAME.zip" "$NAME" )
V=$(mktemp -d); ( cd "$V" && unzip -q "$OUT/$NAME.zip" && cd "$NAME" && sha256sum -c --quiet SHA256SUMS && echo "checksums OK ($(wc -l < SHA256SUMS) files)" )
git bundle verify "$ST/fill-f6-space-universal.bundle" 2>&1 | tail -1
( cd "$V" && git init -q b && cd b && git fetch -q "$TCSLIB_REPO" "$BASE" 2>/dev/null; git fetch -q "$V/$NAME/fill-f6-space-universal.bundle" f6-delivery-tmp:t && echo "bundle head $(git rev-parse t)" )
rm -rf "$V"
sha256sum "$OUT/$NAME.zip"; stat -c '%s bytes' "$OUT/$NAME.zip"
