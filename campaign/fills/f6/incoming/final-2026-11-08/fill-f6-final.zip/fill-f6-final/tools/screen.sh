#!/usr/bin/env bash
# screen.sh <tag> <tree root>: one serialized copy-text screen (screen lock, nice -n 10) over the issued
# 21-file population, tool scripts/copy-text-screen-v3.py of the fill branch (byte-identical to the issued input).
. /work/f6/env.sh; tag=$1; root=$2; L=$TCSLIB_SCRATCH/locks/screen
mkdir -p $TCSLIB_SCRATCH/locks; until mkdir $L 2>/dev/null; do sleep 5; done; echo $$ > $L/pid
s0=$(date +%s); t0=$(date -u +%FT%TZ)
cd $root && nice -n 10 python3 -I $TCSLIB_REPO/scripts/copy-text-screen-v3.py $root $(cat $EV/screens/screen-population.txt) > $EV/screens/screen-$tag.txt 2>&1; st=$?
echo "{\"tag\":\"$tag\",\"root\":\"$root\",\"tool_sha256\":\"$(sha256sum $TCSLIB_REPO/scripts/copy-text-screen-v3.py | cut -c1-64)\",\"start\":\"$t0\",\"end\":\"$(date -u +%FT%TZ)\",\"exit\":$st,\"seconds\":$(( $(date +%s)-s0 )),\"output_sha256\":\"$(sha256sum $EV/screens/screen-$tag.txt | cut -c1-64)\",\"population_sha256\":\"$(sha256sum $EV/screens/screen-population.txt | cut -c1-64)\"}" > $EV/screens/screen-$tag-run.json
rm -f $L/pid; rmdir $L
