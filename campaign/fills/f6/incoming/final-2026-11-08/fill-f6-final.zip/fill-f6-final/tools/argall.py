"""argall.py <repo> <module> <decl,names>: every argument of simp/simp only/simpa/dsimp/rw/rewrite/
erw/simp_rw/unfold/delta in the named declarations, deduplicated per declaration and tactic, with a
classification: TCSlib public definition elsewhere (DEF), TCSlib theorem/lemma (THM), Mathlib/core or
local name (OTHER). For inspection beside argscan.py and the seal run."""
import os, re, sys
repo, mod, names = sys.argv[1], sys.argv[2], [n for n in sys.argv[3].split(',') if n]
code = open(os.path.join(repo, 'devtools/seyoon/declfreeze.py'), encoding='utf-8').read()
code = code[:code.index('a = chunks(open(sys.argv[1])')]; ns = {}; exec(compile(code, 'df', 'exec'), ns); chunks = ns['chunks']
kinds = {}
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(def|abbrev|theorem|lemma)\s', re.M)
for root, _, fs in os.walk(os.path.join(repo, 'TCSlib')):
    for f in fs:
        if f.endswith('.lean'):
            t = open(os.path.join(root, f), encoding='utf-8').read()
            for n, priv, txt in chunks(t):
                body = txt.split('-/', 1)[1] if txt.startswith('/--') else txt
                m = KW.search(body)
                if m and not priv:
                    parts = n.split('.')
                    for k in range(1, len(parts) + 1):
                        kinds.setdefault('.'.join(parts[-k:]), set()).add('DEF' if m.group(1) in ('def', 'abbrev') else 'THM')
text = open(os.path.join(repo, mod), encoding='utf-8').read()
ch = {n: t for n, p, t in chunks(text)}
TAC = re.compile(r'\b(simp only|simpa only|simp_rw|dsimp only|simp|simpa|dsimp|rw|rewrite|erw|unfold|delta)\b\s*(\[[^\]]*\])?')
total = {}
for want in names:
    key = [k for k in ch if k == want or k.endswith('.' + want)][0]
    t = ch[key].split('-/', 1)[1] if ch[key].startswith('/--') else ch[key]
    seen = {}
    for m in TAC.finditer(t):
        lst = m.group(2) or ''
        for e in re.findall(r'(?:←\s*)?([A-Za-z_][A-Za-z0-9_.\'₀-₉]*)', lst[1:-1]):
            seen.setdefault(m.group(1), set()).add(e)
    for tac in sorted(seen):
        for e in sorted(seen[tac]):
            k = '/'.join(sorted(kinds.get(e, {'OTHER'})))
            total[k] = total.get(k, 0) + 1
            print(f'{key}\t{tac}\t{e}\t{k}')
print('TOTALS', total)
