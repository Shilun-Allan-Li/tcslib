#!/usr/bin/env bash
# push.sh <file>... : copy files into arora-barak-ch3-4/inbox/fill-f6/ on the exchange branch,
# pull --rebase, commit and push (no force); retries on network failure with backoff.
set -e
X=/workspace/tcslib; D=arora-barak-ch3-4/inbox/fill-f6; MSG="$PUSHMSG"; B=exchange/pass-shelat-ch5-8
cd $X; git checkout -q $B
test -z "$(git status --porcelain)" || { echo "exchange checkout not clean"; exit 1; }
for i in 1 2 3 4; do git pull -q --rebase origin $B && break; sleep $((2**i)); done
mkdir -p $D; for f in "$@"; do cp "$f" $D/; done
git add $D; git status --short
if git diff --cached --name-only | grep -v "^$D/"; then echo "unexpected path"; exit 1; fi
git commit -q -m "${MSG:-F6 fill delivery}"
ok=0
for i in 1 2 3 4 5; do
  if git pull -q --rebase origin $B && git push -u origin $B; then ok=1; break; fi
  sleep $((2**i))
done
[ $ok = 1 ] || { echo "PUSH FAILED"; exit 1; }
git log -1 --format='%H %s'
