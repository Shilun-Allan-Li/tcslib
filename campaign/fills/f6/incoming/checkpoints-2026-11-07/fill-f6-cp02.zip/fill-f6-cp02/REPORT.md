# F6 `space_universal` fill — checkpoint cp02 (Claude)

**Status: CHECKPOINT. Target still admitted (`sorry`).** Cumulative from the pinned base; includes cp01.

| Item | Value |
|---|---|
| Proof base | `3023dc1408c3d216fc07a7cbba9ae30135b861ed` (`complexity/arora-barak-ch3-4`) |
| Work branch / cp02 head | `fill/f6-space-universal` @ `34c1c0e84f3a82857baf26cd7fb1e89dadd3ac6c` (cp01 `27638178…`) |
| Records / bundle | records `f41bdaea…`; exchange `2adb8078…`; bundle SHA-256 `8fa48270…40be`, 624 sections (verified) |
| Owned file | `TCSlib/Complexity/SpaceComplexity/Hierarchy.lean` only |

## Proven at cp02 (checked), in addition to cp01

* `f6_loop` — **OWN-2**: `exists_forwardLoopTM 1` embedded into the first three of `K+3` bank tapes,
  hosted by `exists_rulerHostTM`, fixed before the code. For every coded one-tape machine `M` halting on
  `x` by `t`: from the host presentation of the loop's initial encoding the host halts with `M`'s output
  (first halt `t₀ ≤ t` from `forwardLoop_forward`), and every tape's visited set has at most
  `spaceUsed_M(t) + (2D+1) + ℓ + 3` cells: mirrored tape ⊆ source cells at `t₀` ⊆ at `t`; tapes 1,2 in
  `[-D,D]`, `D = 50(|table|+1)+C`; idle bank tapes `{0}`; ruler in `[-1,ℓ]` (both boundary cells).
* `f6_last_ruler_layout` — the literal prefix endpoint relabelled at the host entry is the ruler-host
  presentation (public fields; last-ruler bank, not `suffixRulerCfg_embed`).
* `f6_cast_*` (6) and `f6_final_seam` — equality-induction transport `K+4 = 0+((K+2)+2)` and both
  `startupLoopTM_runFrom` / `startupLoopTM_spaceUsed_le` at the zero-outer specialization.

Logs: `evidence/logs/elab/cp02-Hierarchy.out` (exit 0, 0 errors, 1 warning = target `sorry`),
`elab/cp02-SpaceComplexity.out` (exit 0); axioms `evidence/axioms/Ax_cp02.out` (50 declarations incl.
auxiliaries; only `space_universal` non-standard, by its `sorryAx`). Freeze vs base: PASS
(`freeze-cp02.txt`: public 4→4, no header/visibility/order/import change); `chunkcmp-cp02.txt`: no base
chunk changed by any byte, 21 private chunks added. Static census: 22 admitted declarations (baseline).

**NOT RUN — not yet at final stage:** final 229 sweep at the final head, seal + paired controls of the
Hierarchy sections, argument scan, lints, copy-text screens, boundary write-up. The scratch file
`evidence/logs/dev/dev07.lean.txt` (native) / `devseal02` (sealed) elaborates the complete target proof;
the final commit transplants it.
