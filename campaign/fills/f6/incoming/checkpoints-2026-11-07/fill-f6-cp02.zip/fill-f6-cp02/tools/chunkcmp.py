"""chunkcmp.py <repo> <base rev> <head rev|WORKTREE> <file>: byte comparison of every base declaration
chunk (docstring included; devtools/seyoon/declfreeze.py chunking) with the head's, the head's added
chunks, and the non-declaration text outside chunks (module docstring, comments)."""
import os, subprocess, sys, difflib
repo, base, head, f = sys.argv[1:5]
code = open(os.path.join(repo, 'devtools/seyoon/declfreeze.py'), encoding='utf-8').read()
code = code[:code.index('a = chunks(open(sys.argv[1])')]; ns = {}; exec(compile(code, 'df', 'exec'), ns)
A_t = subprocess.run(['git', '-C', repo, 'show', f'{base}:{f}'], capture_output=True, text=True).stdout
B_t = open(os.path.join(repo, f), encoding='utf-8').read() if head == 'WORKTREE' else \
    subprocess.run(['git', '-C', repo, 'show', f'{head}:{f}'], capture_output=True, text=True).stdout
A = {n: t for n, p, t in ns['chunks'](A_t)}; B = {n: t for n, p, t in ns['chunks'](B_t)}
changed = [n for n in A if n in B and A[n] != B[n]]
removed = [n for n in A if n not in B]; added = [n for n in B if n not in A]
print('base chunks', len(A), 'head chunks', len(B))
print('changed base chunks (any byte, docstring included):', changed)
print('removed:', removed); print('added:', added)
def rest(t, ch):
    for c in ch.values(): t = t.replace(c, '\u0000', 1)
    return t
ra, rb = rest(A_t, A), rest(B_t, B)
d = list(difflib.unified_diff(ra.split('\n'), rb.split('\n'), 'base-outside-chunks', 'head-outside-chunks', lineterm='', n=0))
print('outside-chunk diff lines:', len(d)); print('\n'.join(d))
