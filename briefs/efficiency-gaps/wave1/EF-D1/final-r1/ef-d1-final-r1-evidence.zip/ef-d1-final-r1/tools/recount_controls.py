"""EF-D1 final r1 phase 1: recount paired controls. Each example ends with --NEG or --POS on its last
line; an error belongs to the example whose span contains its line. Sealed: every NEG exactly one
error, POS none. Unsealed: no error at all."""
import sys, re
from pathlib import Path
d = Path(sys.argv[1]); ok = True
for stem in ["Ctl_lwe_sealed", "Ctl_lwe_unsealed", "Ctl_sis_sealed", "Ctl_sis_unsealed"]:
    lines = (d / f"{stem}.lean").read_text().split('\n')
    spans, start = [], None
    for i, l in enumerate(lines, 1):
        if l.startswith('example'): start = i
        m = re.search(r'--(NEG|POS)\s*$', l)
        if m and start: spans.append((start, i, m.group(1))); start = None
    errs = [int(m.group(1)) for m in re.finditer(r'\.lean:(\d+):\d+: error', (d / f"{stem}.out").read_text())]
    cnt = {s: 0 for s in spans}; stray = 0
    for e in errs:
        hit = [s for s in spans if s[0] <= e <= s[1]]
        if hit: cnt[hit[0]] += 1
        else: stray += 1
    sealed = 'unsealed' not in stem
    good = stray == 0 and all((c == 1) if (sealed and s[2] == 'NEG') else (c == 0) for s, c in cnt.items())
    ok &= good
    print(f"{stem}: NEG={sum(s[2]=='NEG' for s in spans)} POS={sum(s[2]=='POS' for s in spans)} "
          f"errors={len(errs)} stray={stray} {'OK' if good else 'BAD'}")
print("ALL_OK" if ok else "NOT_OK")
