"""EF-D1 final r1 phase 1: recount the delivered canonical seals.
For each variant and owner: the sealed file minus the one seal line equals the head source byte for
byte, the seal line's names equal the candidate list, and the results line says PASS with 0 errors.
Also reports whether chosen foreign definitions are in the coe-A request set."""
import sys, hashlib
from pathlib import Path
E, SRC = Path(sys.argv[1]), Path(sys.argv[2])
owners = {"TCSlib.Cryptography.LWE.Efficient": "TCSlib/Cryptography/LWE/Efficient.lean",
          "TCSlib.Cryptography.SIS.Efficient": "TCSlib/Cryptography/SIS/Efficient.lean"}
probe = ["TCSlib.Cryptography.LWE.bitNoise", "TCSlib.Cryptography.LWE.centeredNoise",
         "TCSlib.Cryptography.LWE.centeredValue", "TCSlib.Cryptography.CoinSampling.DrawSamplable",
         "TCSlib.Cryptography.CoinSampling.SamplesEfficiently", "TCSlib.Cryptography.CoinSampling.modulusWord",
         "TCSlib.Cryptography.CoinSampling.residueEnc", "Complexity.PolyExpr.eval",
         "TCSlib.Cryptography.LWE.Parameters.encode", "TCSlib.Cryptography.LWE.EfficientFamily",
         "Complexity.Randomized.onesW", "Complexity.BinArith.countLoop"]
ok = True
for v in ["A-coe", "A-strict", "B-coe", "B-strict"]:
    res = (E / f"seal/canon/out-{v}/results_{v}.txt").read_text().splitlines()
    for mod, path in owners.items():
        cand = [l.split('\t')[0] for l in (E / f"seal/canon/cand-{v}/{mod}.txt").read_text().splitlines()
                if l.strip() and not l.startswith('#')]
        sealed = (E / f"seal/canon/out-{v}/{path.replace('/', '_')[:-5]}_{v}.lean").read_text().split('\n')
        seal_lines = [i for i, l in enumerate(sealed) if l.startswith("attribute [local irreducible] ")]
        sl = seal_lines[0]
        names = sealed[sl].split()[3:]
        rest = '\n'.join(sealed[:sl] + sealed[sl + 1:])
        src = (SRC / path).read_text()
        eq = rest == src
        rline = [r for r in res if r.startswith(path + ":")][0]
        good = eq and names == cand and len(seal_lines) == 1 and "PASS (rc=0, error lines=0)" in rline \
            and f"candidates={len(cand)}" in rline
        ok &= good
        print(f"{v}\t{mod}\tcand={len(cand)}\tseal_names_eq={names == cand}\tsrc_eq={eq}"
              f"\tsrc_sha={hashlib.sha256(src.encode()).hexdigest()[:12]}\t{'OK' if good else 'BAD'}\t{rline.split(': ',1)[1]}")
        if v == "A-coe":
            s = set(cand)
            for p in probe:
                print(f"   in-coe-A {p}: {p in s}")
print("ALL_OK" if ok else "NOT_OK")
