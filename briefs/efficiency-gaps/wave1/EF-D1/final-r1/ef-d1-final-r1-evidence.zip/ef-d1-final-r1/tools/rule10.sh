#!/usr/bin/env bash
# EF-D1 final r1 phase 2 driver: probes (collector, axioms, smoke, SR1 demo, delivered controls) and the canonical
# coe-A seal of the two new owners (mkseals_coe.py, unmodified recipe tool), every probe through runner_full.py
# (lean -DmaxErrors=0, no -o: nothing written to the olean tree). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efd1/p2; TREE=$SP/olean-replay-efd1; W=$P2/mergewt; R=$P2/rule10
T=$SP/efd1/recipe/x/olean-advance-a6d01b1b/tools-used/seal; G=$T/review/archived-gate10-tools
H=e3fc2ce29436efeb3870f883f8a8e40cb9292c0f
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$P2/tmp; mkdir -p $TMPDIR
test "$(git -C $W rev-parse HEAD)" = "$H" || { echo "worktree not at H"; exit 1; }
echo "start $(date -u +%FT%TZ) lean=$(pgrep -c -x lean)"
printf 'EFD1Probe/CollectHead\nEFD1Probe/AxiomsHead\nEFD1Probe/SmokeHead\nEFD1Probe/SR1Demo\nEFD1Probe/Ctl_lwe_sealed\nEFD1Probe/Ctl_lwe_unsealed\nEFD1Probe/Ctl_sis_sealed\nEFD1Probe/Ctl_sis_unsealed\n' > $R/order/probes.txt
python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1
echo "probes $(date -u +%FT%TZ)"
LOG=$R/probe-runs/mods/EFD1Probe_CollectHead.log
python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A EFD1Probe/C SealA_ \
  TCSlib.Cryptography.LWE.Efficient TCSlib.Cryptography.SIS.Efficient > $R/mkseals-coe-A.log 2>&1
echo "mkseals rc=$? $(date -u +%FT%TZ)"
(cd $W && ls EFD1Probe/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
echo "seal lean=$(pgrep -c -x lean)"
python3 -I $T/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
echo '{"files":{}}' > $R/touched-empty.json
python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $R/touched-empty.json $R/seals-coe-A.tsv
cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv
echo "PHASE-DONE $(date -u +%FT%TZ)"
