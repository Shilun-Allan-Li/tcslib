import TCSlib.Cryptography.LWE.Efficient
import TCSlib.Cryptography.SIS.Efficient
import TCSlib.Cryptography.LWE.Ratio

/-! EF-D1 final r1 phase 2: consumer smoke test on the merged tree (D1-P2 re-run), with #377's
`LWE.Family.RatioBounded` now on the tree: an `EfficientFamily` passes through `toFamily`. -/
open TCSlib.Cryptography Complexity

example : ∀ (F : LWE.EfficientFamily) (_ : LWE.DLWEAssumption F.toFamily) (D : NUPPT),
    Negligible fun κ => F.toFamily.advantageAt D κ :=
  fun _ h D => h D
example : ∀ (F : SIS.EfficientFamily) (_ : SIS.SISAssumption F.toFamily) (D : NUPPT),
    Negligible fun κ => F.toFamily.successAt D κ :=
  fun _ h D => h D
example (F : LWE.EfficientFamily) (B : ℕ → ℕ) (p : PolyExpr) : Prop := F.toFamily.RatioBounded B p
#check @LWE.EfficientFamily.noise_efficient
#check @LWE.EfficientFamily.params_uniform
#check @SIS.EfficientFamily.params_uniform
#print axioms LWE.dyadicExample
#print axioms SIS.dyadicExample
