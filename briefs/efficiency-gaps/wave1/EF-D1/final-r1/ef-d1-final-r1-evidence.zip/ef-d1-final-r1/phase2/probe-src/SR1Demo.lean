import TCSlib.Cryptography.LWE.BitNoise

/-! EF-D1 final r1 phase 2: EF-D1-SR1, extended. With `bitNoise`/`centeredNoise` sealed (as every
consumer's canonical seal makes them), each attempt below to read the sample at a `Coins`-typed seed
through the published readers is expected to fail; the last two (the proposed readers, stated here
unsealed, i.e. as in the owner file) are expected to pass. -/
namespace TCSlib.Cryptography.LWE
section Sealed
attribute [local irreducible] bitNoise centeredNoise
-- S1 direct application
example (t : ℕ) (f : (Fin t → Bool) → ℤ) (c : (bitNoise t f).Coins) :
    (bitNoise t f).sample c = f (cast (bitNoise_Coins t f) c) := bitNoise_sample t f c
-- S2 rewrite with the reader
example (t : ℕ) (f : (Fin t → Bool) → ℤ) (c : (bitNoise t f).Coins) :
    (bitNoise t f).sample c = f (cast (bitNoise_Coins t f) c) := by rw [bitNoise_sample]
-- S3 simp with the reader
example (t : ℕ) (f : (Fin t → Bool) → ℤ) (c : (bitNoise t f).Coins) :
    (bitNoise t f).sample c = f (cast (bitNoise_Coins t f) c) := by simp only [bitNoise_sample]
-- S4 through the cast round trip
example (t : ℕ) (f : (Fin t → Bool) → ℤ) (c : (bitNoise t f).Coins) :
    (bitNoise t f).sample c = f (cast (bitNoise_Coins t f) c) := by
  have h := bitNoise_sample t f (cast (bitNoise_Coins t f) c)
  rw [← h]
-- S5 centered, rewrite
example (t : ℕ) (c : (centeredNoise t).Coins) :
    (centeredNoise t).sample c = centeredValue t (cast (centeredNoise_Coins t) c) := by
  rw [centeredNoise_sample]
end Sealed
-- P1, P2: the proposed readers, unsealed (owner-file form): expected to pass by rfl
example (t : ℕ) (f : (Fin t → Bool) → ℤ) (c : (bitNoise t f).Coins) :
    (bitNoise t f).sample c = f (cast (bitNoise_Coins t f) c) := rfl
example (t : ℕ) (c : (centeredNoise t).Coins) :
    (centeredNoise t).sample c = centeredValue t (cast (centeredNoise_Coins t) c) := rfl
end TCSlib.Cryptography.LWE
