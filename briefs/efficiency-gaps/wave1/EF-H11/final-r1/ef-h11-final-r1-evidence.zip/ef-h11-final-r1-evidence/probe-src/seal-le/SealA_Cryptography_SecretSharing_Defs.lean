/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import Mathlib.Data.Finset.Card
import Mathlib.Logic.Equiv.Defs
import Mathlib.SetTheory.Cardinal.Finite
/- G06-HARNESS INSTALL SealA_Cryptography_SecretSharing_Defs -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_SecretSharing_Defs"
  let payload : String := ""
  let expectedRequests : Nat := 0
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := ""
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Secret sharing: access structures and security definitions

This file sets up the scheme-independent vocabulary of secret sharing: monotone access
structures, the data of a sharing scheme, and the two security requirements (correctness for
authorized sets, perfect privacy for unauthorized sets). Nothing here mentions polynomials;
`TCSlib.Cryptography.SecretSharing.Shamir` instantiates all of it.

Perfect privacy is stated in *randomness-bijection* form: for any unauthorized set `B` and any
two secrets there is a bijection of the randomness space carrying the one secret's `B`-view to
the other's. For uniformly distributed randomness this is equivalent to the usual statement
that the joint distribution of the shares held by `B` is independent of the secret, but it is
finiteness-free and measure-theory-free, and it is what a scheme's proof naturally produces.
`PerfectPrivacy.card_view_eq` extracts the counting consequence.

## Main definitions

* `SecretSharing.AccessStructure`: a monotone family of authorized sets of parties.
* `SecretSharing.AccessStructure.threshold`: the `k`-out-of-`n` access structure.
* `SecretSharing.Scheme`: the data of a scheme (a randomized sharing map and a reconstruction
  map).
* `SecretSharing.Scheme.Correct`, `SecretSharing.Scheme.PerfectPrivacy`: the two security
  requirements.
* `SecretSharing.Scheme.LocalReconstruct`: reconstruction from `A` only reads the shares of `A`.

## Main results

* `SecretSharing.Scheme.PerfectPrivacy.card_view_eq`: an unauthorized set's view has the same
  number of randomness preimages under every secret.

## References

* [Sha79] A. Shamir, *How to share a secret*, Communications of the ACM 22(11), 1979.
* [Bei11] A. Beimel, *Secret-sharing schemes: a survey*, IWCC 2011, §1–2.
* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §6.1.1 (Definition 152.1, `(k, n)` secret sharing).
-/

namespace TCSlib.SecretSharing

open Finset

variable {P : Type*}

/-- A monotone access structure on a party type `P`: a predicate `Auth` on finite sets of
parties, closed under taking supersets. `Auth A` means the parties in `A` are together allowed
to recover the secret. [Bei11, §1] -/
structure AccessStructure (P : Type*) where
  /-- The authorized sets. -/
  Auth : Finset P → Prop
  /-- Authorization is monotone: a superset of an authorized set is authorized. -/
  mono : ∀ {A B : Finset P}, A ⊆ B → Auth A → Auth B

/-- The `k`-out-of-`n` threshold access structure: a set of parties is authorized exactly when
it has at least `k` members. [Sha79, §1] -/
def AccessStructure.threshold (k : ℕ) : AccessStructure P where
  Auth A := k ≤ #A
  mono hAB hA := hA.trans (card_le_card hAB)

@[simp]
theorem AccessStructure.threshold_auth {k : ℕ} {A : Finset P} :
    (AccessStructure.threshold k).Auth A ↔ k ≤ #A := Iff.rfl

/-- The data of a secret sharing scheme: `share sec r i` is the share handed to party `i` when
the secret is `sec` and the dealer's coins are `r`, and `reconstruct A f` is the secret that the
set `A` computes from the share assignment `f`. Security is not part of the data; see
`Scheme.Correct` and `Scheme.PerfectPrivacy`. [Bei11, §1]; the pair `(Share, Recon)` of
[PS10, Def 152.1].

**Deviation:** [PS10] asks `Share` and `Recon` to be probabilistic polynomial-time; efficiency is
not modelled here, since the security notions are information-theoretic. [PS10]'s `Recon`
receives `k` shares with their indices; here it receives a set of parties and a share assignment,
and `LocalReconstruct` says it reads only the shares of that set. -/
structure Scheme (P Secret Share Rand : Type*) where
  /-- The dealer's sharing map. -/
  share : Secret → Rand → P → Share
  /-- The reconstruction map used by a set of parties. -/
  reconstruct : Finset P → (P → Share) → Secret

namespace Scheme

variable {Secret Share Rand : Type*} (S : Scheme P Secret Share Rand)

/-- Every authorized set recovers the secret, whatever the dealer's coins were. [Bei11, §1]
For the threshold structure, together with `LocalReconstruct`, this gives
[PS10, Def 152.1, item 2]: any `k` shares reconstruct. -/
def Correct (Γ : AccessStructure P) : Prop :=
  ∀ A : Finset P, Γ.Auth A → ∀ (sec : Secret) (r : Rand), S.reconstruct A (S.share sec r) = sec

/-- Reconstruction by `A` only inspects the shares held by `A`. This is a well-formedness
condition on the syntax of the scheme, not a security property, but without it `Correct` could
be satisfied by a reconstruction map that peeks at shares outside `A`. -/
def LocalReconstruct : Prop :=
  ∀ (A : Finset P) (f g : P → Share), (∀ i ∈ A, f i = g i) → S.reconstruct A f = S.reconstruct A g

/-- Perfect privacy: for every unauthorized set `B` and every pair of secrets there is a
bijection `e` of the randomness space such that sharing `sec'` with coins `e r` gives the
parties of `B` exactly the shares they would have received had the secret been `sec` with coins
`r`. With uniform coins this says the `B`-view is distributed independently of the secret.
[Bei11, §1], [Sha79, §2]

For the threshold structure and finite, uniformly sampled coins, this gives
[PS10, Def 152.1, item 3]: the shares of fewer than `k` parties have the same distribution for
any two secrets, so they are statistically close at distance zero. ([PS10] writes both "at most
`k`" and "`|S′| < k`"; the latter is meant, since `k` shares reconstruct.) **Deviation:** stated
as a bijection of the coins rather than as closeness of
distributions; this is the stronger, perfect form, and the one Shamir's scheme achieves
(`card_view_eq` gives the counting consequence). -/
def PerfectPrivacy (Γ : AccessStructure P) : Prop :=
  ∀ B : Finset P, ¬ Γ.Auth B → ∀ sec sec' : Secret,
    ∃ e : Rand ≃ Rand, ∀ (r : Rand), ∀ i ∈ B, S.share sec' (e r) i = S.share sec r i

/-- The defining equation of `Correct`. -/
theorem correct_iff (Γ : AccessStructure P) : S.Correct Γ ↔
    ∀ A : Finset P, Γ.Auth A → ∀ (sec : Secret) (r : Rand), S.reconstruct A (S.share sec r) = sec :=
  Iff.rfl

/-- The defining equation of `LocalReconstruct`. -/
theorem localReconstruct_iff : S.LocalReconstruct ↔
    ∀ (A : Finset P) (f g : P → Share), (∀ i ∈ A, f i = g i) →
      S.reconstruct A f = S.reconstruct A g := Iff.rfl

/-- The defining equation of `PerfectPrivacy`. -/
theorem perfectPrivacy_iff (Γ : AccessStructure P) : S.PerfectPrivacy Γ ↔
    ∀ B : Finset P, ¬ Γ.Auth B → ∀ sec sec' : Secret,
      ∃ e : Rand ≃ Rand, ∀ (r : Rand), ∀ i ∈ B, S.share sec' (e r) i = S.share sec r i := Iff.rfl

variable {S}

/-- The counting form of perfect privacy: for an unauthorized set `B` and any candidate view
`w`, the number of coin tosses producing that view is the same for every secret. In particular
an unbounded adversary holding the shares of `B` learns nothing about the secret.

**Proof sketch.** The privacy bijection `e` sending `sec`-coins to `sec'`-coins restricts to a
bijection between the two fibres, since it preserves the `B`-view by construction. -/
theorem PerfectPrivacy.card_view_eq {Γ : AccessStructure P} (h : S.PerfectPrivacy Γ)
    {B : Finset P} (hB : ¬ Γ.Auth B) (sec sec' : Secret) (w : P → Share) :
    Nat.card {r : Rand // ∀ i ∈ B, S.share sec r i = w i} =
      Nat.card {r : Rand // ∀ i ∈ B, S.share sec' r i = w i} := by
  obtain ⟨e, he⟩ := h B hB sec sec'
  refine Nat.card_congr ⟨fun r => ⟨e r.1, fun i hi => (he r.1 i hi).trans (r.2 i hi)⟩,
    fun r => ⟨e.symm r.1, fun i hi => ?_⟩, fun r => by simp, fun r => by simp⟩
  have := he (e.symm r.1) i hi
  rw [e.apply_symm_apply] at this
  exact this ▸ r.2 i hi

end Scheme

end TCSlib.SecretSharing
/- G06-HARNESS EOF-VERIFY SealA_Cryptography_SecretSharing_Defs -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_SecretSharing_Defs"
  let payload : String := ""
  let expectedRequests : Nat := 0
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := ""
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

