import TCSlib.Cryptography.SecretSharing.Efficient
import TCSlib.Cryptography.SecretSharing.ShamirEfficient
import TCSlib.Cryptography.MPC.BGW.Efficient
open Lean Elab Command

/-! EF-H11 final r1 phase 2: axiom census of every constant stored by the three new owners (the recipe's
`AxiomProbe.r2.lean` with the owner list replaced), and a `sorry` control. -/

theorem efh11SorryControl : (1 : Nat) = 2 := sorry

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.SecretSharing.Efficient, `TCSlib.Cryptography.SecretSharing.ShamirEfficient, `TCSlib.Cryptography.MPC.BGW.Efficient]
  let idxs := mods.filterMap env.getModuleIdx?
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        out := out.push s!"{tag}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    | none => pure ()
  for l in out.qsort (· < ·) do
    IO.println l
  let c ← liftCoreM (Lean.collectAxioms `efh11SorryControl)
  IO.println s!"CONTROL\tefh11SorryControl\t{c.toList}"
