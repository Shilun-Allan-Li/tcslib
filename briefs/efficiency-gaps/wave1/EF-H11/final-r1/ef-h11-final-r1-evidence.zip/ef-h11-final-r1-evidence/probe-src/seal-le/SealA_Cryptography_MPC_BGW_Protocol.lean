/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.SecretSharing.Sharing
import TCSlib.Cryptography.MPC.ArithmeticCircuit
/- G06-HARNESS INSTALL SealA_Cryptography_MPC_BGW_Protocol -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_MPC_BGW_Protocol"
  let payload : String := "TCSlib.Interpolation.fixedEvalEquiv\tTCSlib.Cryptography.SecretSharing.Interpolation\nTCSlib.MPC.Circuit.IsLinear\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.IsLinear._sunfold\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.IsLinear._unsafe_rec\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit._sizeOf_1\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit._sizeOf_inst\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval._sunfold\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval._unsafe_rec\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval.match_1\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.instInhabitedCircuit\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.instInhabitedCircuit.default\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.threshold\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.Correct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.LocalReconstruct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.Shamir.IsSharing\tTCSlib.Cryptography.SecretSharing.Sharing\nTCSlib.Shamir.poly\tTCSlib.Cryptography.SecretSharing.Shamir\nTCSlib.Shamir.recombine\tTCSlib.Cryptography.SecretSharing.Sharing\nTCSlib.Shamir.recombineCoeff\tTCSlib.Cryptography.SecretSharing.Sharing\nTCSlib.Shamir.scheme\tTCSlib.Cryptography.SecretSharing.Shamir"
  let expectedRequests : Nat := 27
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Interpolation.fixedEvalEquiv\t[[\"str\",\"TCSlib\"],[\"str\",\"Interpolation\"],[\"str\",\"fixedEvalEquiv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Interpolation\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.IsLinear\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"IsLinear\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.IsLinear._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"IsLinear\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.IsLinear._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"IsLinear\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\ttrue\nTCSlib.MPC.Circuit._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\ttrue\tfalse\ttrue\nTCSlib.MPC.Circuit.eval\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.eval._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.eval._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.eval.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\ttrue\ttrue\nTCSlib.MPC.instInhabitedCircuit\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"instInhabitedCircuit\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\ttrue\tfalse\tfalse\nTCSlib.MPC.instInhabitedCircuit.default\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"instInhabitedCircuit\"],[\"str\",\"default\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.threshold\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"threshold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.Correct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"Correct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.LocalReconstruct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"LocalReconstruct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"PerfectPrivacy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.Scheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Shamir.IsSharing\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"IsSharing\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Sharing\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.poly\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"poly\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.recombine\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"recombine\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Sharing\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.recombineCoeff\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"recombineCoeff\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Sharing\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.scheme\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"scheme\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The BGW protocol: gate-by-gate evaluation on Shamir shares

The semi-honest BGW protocol evaluates an arithmetic circuit on Shamir-shared inputs, keeping the
invariant that every wire of the circuit is held as a degree-`d` sharing of its true value:

* an addition gate is evaluated by adding shares locally;
* multiplication by a public constant, and introducing a constant, are local;
* a multiplication gate is evaluated by multiplying shares locally — which computes the right
  value but doubles the degree to `2d` — and then *reducing the degree*: every party re-shares
  its product share with a fresh degree-`d` sharing, and all parties take the fixed Lagrange
  combination `∑ λ_i ·` of those re-sharings. This is the only interactive step, and it is why
  BGW needs `2d + 1` honest parties.

The protocol is modelled as a function `bgwEval` from input share vectors to output share
vectors, parameterised by a `Resharer` — the re-sharings the parties contribute at multiplication
gates, which in the real protocol are produced from their private coins. Correctness holds for
*every* resharer, so no probabilistic reasoning is needed for this half of the theorem.

## Main definitions

* `TCSlib.MPC.BGW.Resharer`: a party's ability to produce a degree-`d` sharing of a value it
  holds.
* `TCSlib.MPC.BGW.degreeReduce`: the Lagrange recombination of the parties' re-sharings.
* `TCSlib.MPC.BGW.bgwEval`: the protocol's share-level evaluation of a circuit.

## Main results

* `TCSlib.MPC.BGW.isSharing_degreeReduce`: degree reduction turns a degree-`2d` sharing into a
  degree-`d` sharing of the same value, given `2d + 1` participating parties.
* `TCSlib.MPC.BGW.bgwEval_isSharing`: **correctness invariant** — every wire is a degree-`d`
  sharing of its true value.
* `TCSlib.MPC.BGW.bgwEval_recombine`: **correctness** — the parties' output shares recombine to
  the value the circuit computes.
* `TCSlib.MPC.BGW.bgwEval_of_isLinear`: on a circuit without multiplication gates the protocol is
  non-interactive: the output shares do not depend on the resharer at all.

## References

* [BGW88] M. Ben-Or, S. Goldwasser, A. Wigderson, *Completeness theorems for non-cryptographic
  fault-tolerant distributed computation*, STOC 1988, §3.
* [AL17] G. Asharov, Y. Lindell, *A full proof of the BGW protocol for perfectly secure
  multiparty computation*, J. Cryptology 30(1), 2017, §3–4.
-/

namespace TCSlib.MPC.BGW

open Finset TCSlib.Shamir

variable {F : Type*} [Field F] [DecidableEq F] {ι : Type*} {d : ℕ}

/-- A resharing strategy: each party can turn any value it holds into a degree-`d` sharing of
that value. In the real protocol `reshare i x` is party `i`'s Shamir sharing of `x` using its
private coins; correctness does not care which coins were used, only that the result is a
sharing, so the coins are abstracted away here. [BGW88, §3] -/
structure Resharer (F : Type*) [Field F] (d : ℕ) where
  /-- Party `i`'s degree-`d` sharing of the value `x` it holds. -/
  reshare : Party F → F → Party F → F
  /-- It really is a degree-`d` sharing of `x`. -/
  isSharing_reshare : ∀ i x, IsSharing d x (reshare i x)

variable (R : Resharer F d) (A : Finset (Party F))

/-- The degree reduction step: each party `i ∈ A` re-shares its share `u i`, and the parties take
the Lagrange combination of those re-sharings with the coefficients of `A`. [BGW88, §3] -/
noncomputable def degreeReduce (u : Party F → F) : Party F → F :=
  fun j => ∑ i ∈ A, recombineCoeff A i * R.reshare i (u i) j

/-- The defining equation of `degreeReduce`. -/
theorem degreeReduce_apply (u : Party F → F) (j : Party F) :
    degreeReduce R A u j = ∑ i ∈ A, recombineCoeff A i * R.reshare i (u i) j := rfl

/-- **Degree reduction.** If `u` is a degree-`2d` sharing of `z` and at least `2d + 1` parties
take part, then the reduced vector is a degree-`d` sharing of the *same* value `z`. [BGW88, §3],
[AL17, §3.3]

**Proof sketch.** Recombination is a fixed linear functional `∑ λ_i · (−)` of the shares, and by
reconstruction `∑ λ_i · u i = z` because `2d + 1 ≤ #A`. Each summand `λ_i · reshare i (u i)` is a
degree-`d` sharing of `λ_i · u i`, and degree-`d` sharings are closed under sums, so the total is
a degree-`d` sharing of `∑ λ_i · u i = z`. The two uses of linearity — on values and on share
vectors — are the same linear functional, which is the whole trick. -/
theorem isSharing_degreeReduce {z : F} {u : Party F → F} (hu : IsSharing (2 * d) z u)
    (hA : 2 * d + 1 ≤ #A) : IsSharing d z (degreeReduce R A u) := by
  have hsum : IsSharing d (∑ i ∈ A, recombineCoeff A i * u i)
      (fun j => ∑ i ∈ A, recombineCoeff A i * R.reshare i (u i) j) :=
    IsSharing.sum A fun i _ => IsSharing.smul _ (R.isSharing_reshare i (u i))
  have hz : ∑ i ∈ A, recombineCoeff A i * u i = z := hu.recombine_eq hA
  rw [hz] at hsum
  exact hsum

/-- The BGW protocol's share-level evaluation of a circuit: local operations at addition and
constant-multiplication gates, local multiplication followed by degree reduction at
multiplication gates. [BGW88, §3] -/
noncomputable def bgwEval (inp : ι → Party F → F) : Circuit F ι → (Party F → F)
  | .input i => inp i
  | .const c => fun _ => c
  | .add a b => bgwEval inp a + bgwEval inp b
  | .smul c a => fun j => c * bgwEval inp a j
  | .mul a b => degreeReduce R A (bgwEval inp a * bgwEval inp b)

@[simp] theorem bgwEval_input (inp : ι → Party F → F) (i : ι) :
    bgwEval R A inp (.input i) = inp i := rfl
@[simp] theorem bgwEval_const (inp : ι → Party F → F) (c : F) :
    bgwEval R A inp (.const c) = fun _ => c := rfl
@[simp] theorem bgwEval_add (inp : ι → Party F → F) (a b : Circuit F ι) :
    bgwEval R A inp (a.add b) = bgwEval R A inp a + bgwEval R A inp b := rfl
@[simp] theorem bgwEval_smul (inp : ι → Party F → F) (c : F) (a : Circuit F ι) :
    bgwEval R A inp (a.smul c) = fun j => c * bgwEval R A inp a j := rfl
@[simp] theorem bgwEval_mul (inp : ι → Party F → F) (a b : Circuit F ι) :
    bgwEval R A inp (a.mul b) = degreeReduce R A (bgwEval R A inp a * bgwEval R A inp b) := rfl

/-- **Correctness invariant of BGW.** If the inputs are degree-`d` sharings of `v` and at least
`2d + 1` parties take part, then after evaluating any circuit gate by gate, the wire vector is a
degree-`d` sharing of the value that wire carries in the clear. [BGW88, §3], [AL17, Thm 3.1]

**Proof sketch.** Induction on the circuit. Inputs hold by hypothesis and constants are shared by
the constant polynomial. Addition and constant-multiplication preserve both the degree and the
shared value because sharings are closed under those operations. At a multiplication gate the
product of the two share vectors is a degree-`2d` sharing of the product of the values — degrees
add — and degree reduction brings it back to `d` without changing the value. -/
theorem bgwEval_isSharing {v : ι → F} {inp : ι → Party F → F}
    (hinp : ∀ i, IsSharing d (v i) (inp i)) (hA : 2 * d + 1 ≤ #A) :
    ∀ C : Circuit F ι, IsSharing d (C.eval v) (bgwEval R A inp C)
  | .input i => hinp i
  | .const c => isSharing_const d c
  | .add a b => (bgwEval_isSharing hinp hA a).add (bgwEval_isSharing hinp hA b)
  | .smul c a => IsSharing.smul c (bgwEval_isSharing hinp hA a)
  | .mul a b => by
      refine isSharing_degreeReduce R A ?_ hA
      have := (bgwEval_isSharing hinp hA a).mul (bgwEval_isSharing hinp hA b)
      rwa [two_mul]

/-- **Correctness of BGW.** With at least `2d + 1` participating parties, the output shares
produced by the protocol recombine to exactly the value the circuit computes on the inputs.
[BGW88, §3], [AL17, Thm 3.1] -/
theorem bgwEval_recombine {v : ι → F} {inp : ι → Party F → F}
    (hinp : ∀ i, IsSharing d (v i) (inp i)) (hA : 2 * d + 1 ≤ #A) (C : Circuit F ι) :
    recombine A (bgwEval R A inp C) = C.eval v :=
  (bgwEval_isSharing R A hinp hA C).recombine_eq (le_trans (by omega) hA)

/-- On a circuit with no multiplication gates the protocol never uses the resharer: the parties
compute their output shares locally, without interaction. -/
theorem bgwEval_of_isLinear (R' : Resharer F d) (inp : ι → Party F → F) :
    ∀ C : Circuit F ι, C.IsLinear → bgwEval R A inp C = bgwEval R' A inp C
  | .input _, _ => rfl
  | .const _, _ => rfl
  | .add a b, h => by
      rw [bgwEval_add, bgwEval_add, bgwEval_of_isLinear R' inp a h.1,
        bgwEval_of_isLinear R' inp b h.2]
  | .smul c a, h => by
      rw [bgwEval_smul, bgwEval_smul, bgwEval_of_isLinear R' inp a h]
  | .mul _ _, h => absurd h not_false

end TCSlib.MPC.BGW
/- G06-HARNESS EOF-VERIFY SealA_Cryptography_MPC_BGW_Protocol -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_MPC_BGW_Protocol"
  let payload : String := "TCSlib.Interpolation.fixedEvalEquiv\tTCSlib.Cryptography.SecretSharing.Interpolation\nTCSlib.MPC.Circuit.IsLinear\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.IsLinear._sunfold\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.IsLinear._unsafe_rec\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit._sizeOf_1\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit._sizeOf_inst\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval._sunfold\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval._unsafe_rec\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.Circuit.eval.match_1\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.instInhabitedCircuit\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.MPC.instInhabitedCircuit.default\tTCSlib.Cryptography.MPC.ArithmeticCircuit\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.threshold\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.Correct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.LocalReconstruct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.Shamir.IsSharing\tTCSlib.Cryptography.SecretSharing.Sharing\nTCSlib.Shamir.poly\tTCSlib.Cryptography.SecretSharing.Shamir\nTCSlib.Shamir.recombine\tTCSlib.Cryptography.SecretSharing.Sharing\nTCSlib.Shamir.recombineCoeff\tTCSlib.Cryptography.SecretSharing.Sharing\nTCSlib.Shamir.scheme\tTCSlib.Cryptography.SecretSharing.Shamir"
  let expectedRequests : Nat := 27
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Interpolation.fixedEvalEquiv\t[[\"str\",\"TCSlib\"],[\"str\",\"Interpolation\"],[\"str\",\"fixedEvalEquiv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Interpolation\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.IsLinear\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"IsLinear\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.IsLinear._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"IsLinear\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.IsLinear._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"IsLinear\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\ttrue\nTCSlib.MPC.Circuit._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\ttrue\tfalse\ttrue\nTCSlib.MPC.Circuit.eval\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.eval._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.eval._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.MPC.Circuit.eval.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"Circuit\"],[\"str\",\"eval\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\ttrue\ttrue\nTCSlib.MPC.instInhabitedCircuit\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"instInhabitedCircuit\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\ttrue\tfalse\tfalse\nTCSlib.MPC.instInhabitedCircuit.default\t[[\"str\",\"TCSlib\"],[\"str\",\"MPC\"],[\"str\",\"instInhabitedCircuit\"],[\"str\",\"default\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MPC\"],[\"str\",\"ArithmeticCircuit\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.threshold\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"threshold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.Correct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"Correct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.LocalReconstruct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"LocalReconstruct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"PerfectPrivacy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.Scheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Shamir.IsSharing\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"IsSharing\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Sharing\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.poly\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"poly\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.recombine\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"recombine\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Sharing\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.recombineCoeff\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"recombineCoeff\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Sharing\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.scheme\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"scheme\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

