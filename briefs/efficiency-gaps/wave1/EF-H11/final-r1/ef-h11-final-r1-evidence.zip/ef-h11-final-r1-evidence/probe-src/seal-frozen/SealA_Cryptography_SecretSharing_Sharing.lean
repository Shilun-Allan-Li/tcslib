/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.SecretSharing.Shamir
/- G06-HARNESS INSTALL SealA_Cryptography_SecretSharing_Sharing -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_SecretSharing_Sharing"
  let payload : String := "TCSlib.Interpolation.fixedEvalEquiv\tTCSlib.Cryptography.SecretSharing.Interpolation\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.threshold\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.Correct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.LocalReconstruct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.Shamir.poly\tTCSlib.Cryptography.SecretSharing.Shamir\nTCSlib.Shamir.scheme\tTCSlib.Cryptography.SecretSharing.Shamir"
  let expectedRequests : Nat := 13
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Interpolation.fixedEvalEquiv\t[[\"str\",\"TCSlib\"],[\"str\",\"Interpolation\"],[\"str\",\"fixedEvalEquiv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Interpolation\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.threshold\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"threshold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.Correct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"Correct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.LocalReconstruct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"LocalReconstruct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"PerfectPrivacy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.Scheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Shamir.poly\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"poly\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.scheme\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"scheme\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The algebra of Shamir sharings

For protocols built on Shamir's scheme it is the *relation* "the share vector `f` is a degree-`d`
sharing of the value `x`" that one reasons about, not the dealer's coins. This file introduces
that relation, `Shamir.IsSharing`, and proves that it is closed under the operations protocols
perform locally: adding share vectors adds the secrets, scaling scales, and multiplying share
vectors multiplies the secrets *at the cost of doubling the degree*. It also isolates
reconstruction as a fixed linear functional `Shamir.recombine`, whose coefficients depend on the
reconstructing set alone and not on the shares.

These two facts — local operations act on secrets, reconstruction is linear — are exactly what
the BGW protocol runs on; see `TCSlib.Cryptography.MPC.BGW`.

## Main definitions

* `TCSlib.Shamir.IsSharing d x f`: `f` is the evaluation vector of a polynomial of degree `≤ d`
  with constant term `x`.
* `TCSlib.Shamir.recombine A f`: the Lagrange recombination of the shares held by `A`, a fixed
  linear combination `∑ i ∈ A, recombineCoeff A i * f i`.

## Main results

* `IsSharing.add`, `IsSharing.smul`, `IsSharing.mul`, `IsSharing.sum`: closure properties.
* `IsSharing.recombine_eq`: any `d + 1` parties recombine to the shared value.
* `recombine_add`, `recombine_smul`, `recombine_sum`: recombination is linear in the shares.

## References

* [Sha79] A. Shamir, *How to share a secret*, Communications of the ACM 22(11), 1979.
* [BGW88] M. Ben-Or, S. Goldwasser, A. Wigderson, *Completeness theorems for non-cryptographic
  fault-tolerant distributed computation*, STOC 1988, §3.
* [AL17] G. Asharov, Y. Lindell, *A full proof of the BGW protocol for perfectly secure
  multiparty computation*, J. Cryptology 30(1), 2017, §3.
-/

namespace TCSlib.Shamir

open Finset Polynomial

variable {F : Type*} [Field F] {d e : ℕ} {x y : F} {f g : Party F → F}

/-- `IsSharing d x f` says the share vector `f` is a degree-`d` Shamir sharing of `x`: there is a
polynomial of degree `≤ d` with constant term `x` whose evaluation at each party's label is that
party's share. The dealer's output `Shamir.scheme.share` is the running example, but a sharing
may also arise from local computation on other sharings. [BGW88, §3] -/
def IsSharing (d : ℕ) (x : F) (f : Party F → F) : Prop :=
  ∃ p : F[X], p.degree < ((d + 1 : ℕ) : WithBot ℕ) ∧ p.eval 0 = x ∧ ∀ i, f i = p.eval (label i)

/-- What the dealer hands out is a degree-`(k-1)` sharing of the secret. -/
theorem isSharing_share [DecidableEq F] {k : ℕ} (hk : 0 < k) (sec : F)
    (q : degreeLT F (k - 1)) :
    IsSharing (k - 1) sec (fun i => (scheme k F).share sec q i) := by
  refine ⟨poly sec q, ?_, poly_eval_zero sec q, fun i => rfl⟩
  have : k - 1 + 1 = k := Nat.succ_pred_eq_of_pos hk
  rw [this]
  exact degree_poly_lt hk sec q

/-- A sharing of degree `d` is one of any larger degree. -/
theorem IsSharing.mono (h : IsSharing d x f) (hde : d ≤ e) : IsSharing e x f := by
  obtain ⟨p, hp, hp0, hpf⟩ := h
  exact ⟨p, lt_of_lt_of_le hp (by exact_mod_cast Nat.succ_le_succ hde), hp0, hpf⟩

/-- The constant share vector is a sharing of that constant: parties can introduce public
values into the computation without interaction. -/
theorem isSharing_const (d : ℕ) (c : F) : IsSharing d c (fun _ => c) :=
  ⟨C c, lt_of_le_of_lt degree_C_le (by exact_mod_cast Nat.succ_pos d), by simp, fun _ => by simp⟩

/-- **Addition gate.** Adding share vectors componentwise adds the shared values, with no
interaction and no growth in degree. [BGW88, §3] -/
theorem IsSharing.add (hf : IsSharing d x f) (hg : IsSharing d y g) :
    IsSharing d (x + y) (f + g) := by
  obtain ⟨p, hp, hp0, hpf⟩ := hf
  obtain ⟨r, hr, hr0, hrg⟩ := hg
  exact ⟨p + r, lt_of_le_of_lt (degree_add_le _ _) (max_lt hp hr), by simp [hp0, hr0],
    fun i => by simp [Pi.add_apply, hpf i, hrg i]⟩

/-- **Scalar multiplication gate.** Scaling every share by a public constant scales the shared
value. [BGW88, §3] -/
theorem IsSharing.smul (c : F) (hf : IsSharing d x f) : IsSharing d (c * x) (fun i => c * f i) := by
  obtain ⟨p, hp, hp0, hpf⟩ := hf
  refine ⟨C c * p, lt_of_le_of_lt (degree_mul_le _ _) ?_, by simp [hp0], fun i => by simp [hpf i]⟩
  exact lt_of_le_of_lt (add_le_add_right degree_C_le _) (by simpa using hp)

/-- **Multiplication gate, before degree reduction.** Multiplying share vectors componentwise
multiplies the shared values, but the degree adds: `d + e` instead of `d`. Undoing this growth is
the only step of BGW that requires interaction. [BGW88, §3] -/
theorem IsSharing.mul (hf : IsSharing d x f) (hg : IsSharing e y g) :
    IsSharing (d + e) (x * y) (f * g) := by
  obtain ⟨p, hp, hp0, hpf⟩ := hf
  obtain ⟨r, hr, hr0, hrg⟩ := hg
  refine ⟨p * r, lt_of_le_of_lt (degree_mul_le _ _) ?_, by simp [hp0, hr0],
    fun i => by simp [Pi.mul_apply, hpf i, hrg i]⟩
  calc p.degree + r.degree
      ≤ ((d : WithBot ℕ)) + (e : WithBot ℕ) := by
        exact add_le_add (Order.le_of_lt_succ (by exact_mod_cast hp))
          (Order.le_of_lt_succ (by exact_mod_cast hr))
    _ < ((d + e + 1 : ℕ) : WithBot ℕ) := by push_cast; exact_mod_cast Nat.lt_succ_self (d + e)

/-- A finite sum of degree-`d` sharings is a degree-`d` sharing of the sum. -/
theorem IsSharing.sum {ι : Type*} (s : Finset ι) {v : ι → F} {h : ι → Party F → F}
    (hs : ∀ i ∈ s, IsSharing d (v i) (h i)) :
    IsSharing d (∑ i ∈ s, v i) (fun j => ∑ i ∈ s, h i j) := by
  classical
  induction s using Finset.induction with
  | empty => simpa using isSharing_const d (0 : F)
  | insert a s ha ih =>
    rw [Finset.sum_insert ha]
    have hrest := ih (fun i hi => hs i (Finset.mem_insert_of_mem hi))
    have key : (fun j => ∑ i ∈ insert a s, h i j) = h a + (fun j => ∑ i ∈ s, h i j) := by
      funext j; simp [Finset.sum_insert ha]
    rw [key]
    exact (hs a (Finset.mem_insert_self a s)).add hrest

section Recombine

variable [DecidableEq F]

/-- The Lagrange recombination coefficient of party `i` inside the reconstructing set `A`: the
value at `0` of `i`'s Lagrange basis polynomial for `A`. It depends only on `A` — not on the
shares, and not on what is being shared. -/
noncomputable def recombineCoeff (A : Finset (Party F)) (i : Party F) : F :=
  (Lagrange.basis A label i).eval 0

/-- Reconstruction as a fixed linear functional of the shares: `∑ i ∈ A, λ_i · f i`. This is the
same value as `Shamir.scheme.reconstruct A f`, but written so that its linearity in `f` is
manifest; BGW's degree reduction is exactly an application of that linearity. [BGW88, §3] -/
noncomputable def recombine (A : Finset (Party F)) (f : Party F → F) : F :=
  ∑ i ∈ A, recombineCoeff A i * f i

theorem recombine_eq_eval_interpolate (A : Finset (Party F)) (f : Party F → F) :
    recombine A f = (Lagrange.interpolate A label f).eval 0 := by
  simp [recombine, recombineCoeff, Lagrange.interpolate_apply, eval_finset_sum, mul_comm]

theorem recombine_eq_reconstruct (A : Finset (Party F)) (f : Party F → F) {k : ℕ} :
    recombine A f = (scheme k F).reconstruct A f :=
  recombine_eq_eval_interpolate A f

/-- **Reconstruction.** Any `d + 1` parties recombine a degree-`d` sharing to the shared value.

**Proof sketch.** The sharing polynomial has degree `≤ d < #A` and agrees with the shares on the
`#A` distinct nodes of `A`, so it *is* the Lagrange interpolant of those shares; recombination
evaluates that interpolant at `0`, returning its constant term. -/
theorem IsSharing.recombine_eq (h : IsSharing d x f) {A : Finset (Party F)} (hA : d + 1 ≤ #A) :
    recombine A f = x := by
  obtain ⟨p, hp, hp0, hpf⟩ := h
  have hinj : Set.InjOn label (A : Set (Party F)) := label_injective.injOn
  have hdeg : p.degree < (#A : WithBot ℕ) := lt_of_lt_of_le hp (by exact_mod_cast hA)
  have : p = Lagrange.interpolate A label f :=
    Lagrange.eq_interpolate_of_eval_eq _ hinj hdeg (fun i _ => (hpf i).symm)
  rw [recombine_eq_eval_interpolate, ← this, hp0]

@[simp]
theorem recombine_add (A : Finset (Party F)) (f g : Party F → F) :
    recombine A (f + g) = recombine A f + recombine A g := by
  simp [recombine, mul_add, Finset.sum_add_distrib]

@[simp]
theorem recombine_smul (A : Finset (Party F)) (c : F) (f : Party F → F) :
    recombine A (fun i => c * f i) = c * recombine A f := by
  simp only [recombine, Finset.mul_sum]
  exact Finset.sum_congr rfl fun i _ => by ring

/-- Recombination commutes with finite sums of share vectors. -/
theorem recombine_sum {ι : Type*} (A : Finset (Party F)) (s : Finset ι)
    (h : ι → Party F → F) :
    recombine A (fun j => ∑ i ∈ s, h i j) = ∑ i ∈ s, recombine A (h i) := by
  simp only [recombine, Finset.mul_sum]
  exact Finset.sum_comm

end Recombine

end TCSlib.Shamir
/- G06-HARNESS EOF-VERIFY SealA_Cryptography_SecretSharing_Sharing -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_SecretSharing_Sharing"
  let payload : String := "TCSlib.Interpolation.fixedEvalEquiv\tTCSlib.Cryptography.SecretSharing.Interpolation\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.AccessStructure.threshold\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.Correct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.LocalReconstruct\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_1\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme._sizeOf_inst\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\tTCSlib.Cryptography.SecretSharing.Defs\nTCSlib.Shamir.poly\tTCSlib.Cryptography.SecretSharing.Shamir\nTCSlib.Shamir.scheme\tTCSlib.Cryptography.SecretSharing.Shamir"
  let expectedRequests : Nat := 13
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Interpolation.fixedEvalEquiv\t[[\"str\",\"TCSlib\"],[\"str\",\"Interpolation\"],[\"str\",\"fixedEvalEquiv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Interpolation\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.AccessStructure._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.AccessStructure.threshold\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"AccessStructure\"],[\"str\",\"threshold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.Correct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"Correct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.LocalReconstruct\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"LocalReconstruct\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme.PerfectPrivacy\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"PerfectPrivacy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.SecretSharing.Scheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.SecretSharing.Scheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.SecretSharing.Scheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"SecretSharing\"],[\"str\",\"Scheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Shamir.poly\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"poly\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse\nTCSlib.Shamir.scheme\t[[\"str\",\"TCSlib\"],[\"str\",\"Shamir\"],[\"str\",\"scheme\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SecretSharing\"],[\"str\",\"Shamir\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

