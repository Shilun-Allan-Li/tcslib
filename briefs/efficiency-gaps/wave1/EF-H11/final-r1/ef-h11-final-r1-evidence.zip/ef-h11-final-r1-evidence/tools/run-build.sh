#!/usr/bin/env bash
# EF-H11 final r1 phase 2: replay build on olean-replay-efh11 (recipe runner.py, unmodified; one Lean process at a time).
set -u
export PATH=$HOME/.elan/bin:$PATH
echo "start $(date -u +%FT%TZ) lean_procs=$(pgrep -c -x lean)"
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/efh11-final/recipe/olean-advance-a6d01b1b/tools-used/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/efh11-final/p2/wt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/efh11-final/p2/plan/out/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-efh11 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/efh11-final/p2/build
echo "runner rc=$? end $(date -u +%FT%TZ) lean_procs=$(pgrep -c -x lean)"
