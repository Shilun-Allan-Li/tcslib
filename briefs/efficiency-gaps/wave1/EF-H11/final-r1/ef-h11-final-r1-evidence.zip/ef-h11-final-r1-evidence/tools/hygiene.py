"""EF-H11 review: hygiene scan (widths, docstrings, sketches, tags/glue, forbidden tokens)."""
import re, sys
TAG = re.compile(r"\[(PS10|Sha79|Bei11|BGW88|AL17)[^\]]*\]")
for path in sys.argv[1:]:
    L = open(path, encoding='utf-8').read().split('\n')
    print(f"== {path}: {len(L)} lines, max width {max(len(l) for l in L)}")
    for tok in ['sorry', 'admit', 'native_decide', '@[simp]', 'axiom ', 'opaque ', 'private ']:
        n = sum(1 for l in L if tok in l and not l.strip().startswith('--'))
        if n: print("  TOKEN", tok, n)
    decl = re.compile(r'^(noncomputable )?(theorem|def|structure|instance|abbrev|lemma)\s+(\S+)?')
    starts = [i for i, l in enumerate(L) if decl.match(l)]
    for k, i in enumerate(starts):
        m = decl.match(L[i]); name = m.group(3) or '(anon)'
        # docstring: walk back over 'omit ... in' lines
        j = i - 1
        while j >= 0 and L[j].startswith('omit '): j -= 1
        doc = ''
        if j >= 0 and L[j].rstrip().endswith('-/'):
            s = j
            while s >= 0 and '/--' not in L[s]: s -= 1
            doc = '\n'.join(L[s:j+1])
        end = starts[k+1] if k+1 < len(starts) else len(L)
        # body length: until next blank line followed by docstring/decl
        e = i
        while e < end and not (L[e].strip() == '' ): e += 1
        body = e - i
        flags = []
        if not doc: flags.append('NO-DOC')
        else:
            if not TAG.search(doc) and 'Glue' not in doc: flags.append('no-tag/glue')
            if body >= 20 and 'Proof sketch' not in doc: flags.append(f'NO-SKETCH({body})')
        if flags: print(f"  {path.split('/')[-1]}:{i+1} {m.group(2)} {name} body={body} {' '.join(flags)}")
