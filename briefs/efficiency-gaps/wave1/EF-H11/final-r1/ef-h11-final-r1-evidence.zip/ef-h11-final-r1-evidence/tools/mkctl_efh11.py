"""mkctl_efh11.py <wt> <ctl-dir>: EF-H11 review paired controls. For each owner, CtlS_<X> = the canonical coe-A seal
file with the control block inserted after the owner's closing `end <ns>` (before the EOF verification), and
CtlU_<X> = the owner's source with the same block appended (no seal). Expected: each CTL-NEG line fails exactly once
sealed and passes unsealed; every CTL-POS line passes in both."""
import sys, os
wt, cd = sys.argv[1:3]
owners = [('A', 'SecretSharing_Efficient', 'TCSlib/Cryptography/SecretSharing/Efficient.lean', 'end TCSlib.SecretSharing'),
          ('B', 'SecretSharing_ShamirEfficient', 'TCSlib/Cryptography/SecretSharing/ShamirEfficient.lean', 'end TCSlib.Shamir'),
          ('C', 'MPC_BGW_Efficient', 'TCSlib/Cryptography/MPC/BGW/Efficient.lean', 'end TCSlib.MPC.BGW')]
for tag, stem, src, endl in owners:
    ctl = open(os.path.join(cd, f'ctl_{tag}.txt'), encoding='utf-8').read()
    seal = open(os.path.join(wt, 'EFH11Probe/C', f'SealA_Cryptography_{stem}.lean'), encoding='utf-8').read().split('\n')
    idx = [i for i, l in enumerate(seal) if l == endl]; assert len(idx) == 1, (tag, idx)
    out = seal[:idx[0] + 1] + ctl.rstrip('\n').split('\n') + seal[idx[0] + 1:]
    open(os.path.join(wt, 'EFH11Probe', f'CtlS_{tag}.lean'), 'w', encoding='utf-8').write('\n'.join(out))
    own = open(os.path.join(wt, src), encoding='utf-8').read()
    open(os.path.join(wt, 'EFH11Probe', f'CtlU_{tag}.lean'), 'w', encoding='utf-8').write(own.rstrip('\n') + '\n' + ctl)
    print(tag, 'sealed lines', len(out), 'unsealed lines', own.count('\n') + ctl.count('\n') + 1)
