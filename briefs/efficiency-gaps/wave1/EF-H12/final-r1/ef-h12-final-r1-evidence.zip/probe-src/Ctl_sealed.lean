import TCSlib.Cryptography.ZeroKnowledge.LevinHardness
set_option autoImplicit false
set_option maxHeartbeats 0
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

section Ctl1
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.descPrefix
example : type_of% @TCSlib.Cryptography.LevinHardness.descPrefix_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.descPrefix_eq := @TCSlib.Cryptography.LevinHardness.descPrefix_eq
end Ctl1
section Ctl2
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.padInput
example : type_of% @TCSlib.Cryptography.LevinHardness.padInput_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.padInput_eq := @TCSlib.Cryptography.LevinHardness.padInput_eq
end Ctl2
section Ctl3
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.retarget
example : type_of% @TCSlib.Cryptography.LevinHardness.retarget_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.retarget_eq := @TCSlib.Cryptography.LevinHardness.retarget_eq
end Ctl3
section Ctl4
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.stripNext
example : type_of% @TCSlib.Cryptography.LevinHardness.stripNext_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.stripNext_eq := @TCSlib.Cryptography.LevinHardness.stripNext_eq
end Ctl4
section Ctl5
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.stripOut
example : type_of% @TCSlib.Cryptography.LevinHardness.stripOut_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.stripOut_eq := @TCSlib.Cryptography.LevinHardness.stripOut_eq
end Ctl5
section Ctl6
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.wireValue
example : type_of% @TCSlib.Cryptography.LevinHardness.wireValue_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.wireValue_eq := @TCSlib.Cryptography.LevinHardness.wireValue_eq
end Ctl6
section Ctl7
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.wireValues
example : type_of% @TCSlib.Cryptography.LevinHardness.wireValues_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.wireValues_eq := @TCSlib.Cryptography.LevinHardness.wireValues_eq
end Ctl7
section Ctl8
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.withOutput
example : type_of% @TCSlib.Cryptography.LevinHardness.withOutput_gates := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.withOutput_gates := @TCSlib.Cryptography.LevinHardness.withOutput_gates
end Ctl8
section Ctl9
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.clauseCode
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseCode_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseCode_eq := @TCSlib.Cryptography.LevinHardness.clauseCode_eq
end Ctl9
section Ctl10
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.clauseEquiv
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseEquiv_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseEquiv_apply := @TCSlib.Cryptography.LevinHardness.clauseEquiv_apply
end Ctl10
section Ctl11
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.colorInst
example : type_of% @TCSlib.Cryptography.LevinHardness.colorInst_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.colorInst_eq := @TCSlib.Cryptography.LevinHardness.colorInst_eq
end Ctl11
section Ctl12
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetSimpleGraph
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetSimpleGraph_adj := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetSimpleGraph_adj := @TCSlib.Cryptography.LevinHardness.gadgetSimpleGraph_adj
end Ctl12
section Ctl13
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.goodS
example (s : List Bool) : TCSlib.Cryptography.LevinHardness.goodS s = (Std.Sat.CNF.decode s).all fun C => decide (1 ≤ C.length) && decide (C.length ≤ 3) := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.goodS_iff := @TCSlib.Cryptography.LevinHardness.goodS_iff
end Ctl13
section Ctl14
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.k4
example : type_of% @TCSlib.Cryptography.LevinHardness.k4_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.k4_apply := @TCSlib.Cryptography.LevinHardness.k4_apply
end Ctl14
section Ctl15
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.litCode
example : type_of% @TCSlib.Cryptography.LevinHardness.litCode_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.litCode_eq := @TCSlib.Cryptography.LevinHardness.litCode_eq
end Ctl15
section Ctl16
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.litEquiv
example : type_of% @TCSlib.Cryptography.LevinHardness.litEquiv_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.litEquiv_apply := @TCSlib.Cryptography.LevinHardness.litEquiv_apply
end Ctl16
section Ctl17
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.memS
example (s : List Bool) (c : ℕ) : TCSlib.Cryptography.LevinHardness.memS s c = (Std.Sat.CNF.decode s).any fun C => decide (1 ≤ C.length) && decide (C.length ≤ 3) && decide (TCSlib.Cryptography.LevinHardness.clauseCode s.length C = c) := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.memS_iff := @TCSlib.Cryptography.LevinHardness.memS_iff
end Ctl17
section Ctl18
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.vertexEquiv
example : type_of% @TCSlib.Cryptography.LevinHardness.vertexEquiv_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.vertexEquiv_apply := @TCSlib.Cryptography.LevinHardness.vertexEquiv_apply
end Ctl18
section Ctl19
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.wideLit
example : type_of% @TCSlib.Cryptography.LevinHardness.wideLit_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.wideLit_eq := @TCSlib.Cryptography.LevinHardness.wideLit_eq
end Ctl19
section Ctl20
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.candClause
example : type_of% @TCSlib.Cryptography.LevinHardness.candClause_one := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.candClause_one := @TCSlib.Cryptography.LevinHardness.candClause_one
end Ctl20
section Ctl21
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.candValid
example : type_of% @TCSlib.Cryptography.LevinHardness.candValid_one := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.candValid_one := @TCSlib.Cryptography.LevinHardness.candValid_one
end Ctl21
section Ctl22
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.clauseRec
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseRec_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseRec_eq := @TCSlib.Cryptography.LevinHardness.clauseRec_eq
end Ctl22
section Ctl23
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.hasRec
example : type_of% @TCSlib.Cryptography.LevinHardness.hasRec_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.hasRec_eq := @TCSlib.Cryptography.LevinHardness.hasRec_eq
end Ctl23
section Ctl24
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.litOfCode
example : type_of% @TCSlib.Cryptography.LevinHardness.litOfCode_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.litOfCode_eq := @TCSlib.Cryptography.LevinHardness.litOfCode_eq
end Ctl24
section Ctl25
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.memAlg
example : type_of% @TCSlib.Cryptography.LevinHardness.memAlg_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.memAlg_eq := @TCSlib.Cryptography.LevinHardness.memAlg_eq
end Ctl25
section Ctl26
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.widthStep
example : type_of% @TCSlib.Cryptography.LevinHardness.widthStep_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.widthStep_eq := @TCSlib.Cryptography.LevinHardness.widthStep_eq
end Ctl26
section Ctl27
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.colorWord
example : type_of% @TCSlib.Cryptography.LevinHardness.colorWord_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.colorWord_eq := @TCSlib.Cryptography.LevinHardness.colorWord_eq
end Ctl27
section Ctl28
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetColor
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetColor_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetColor_eq := @TCSlib.Cryptography.LevinHardness.gadgetColor_eq
end Ctl28
section Ctl29
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetNodeColor
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetNodeColor_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetNodeColor_eq := @TCSlib.Cryptography.LevinHardness.gadgetNodeColor_eq
end Ctl29
section Ctl30
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.clauseLit
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseLit_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseLit_eq := @TCSlib.Cryptography.LevinHardness.clauseLit_eq
end Ctl30
section Ctl31
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.clauseSat
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseSat_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.clauseSat_eq := @TCSlib.Cryptography.LevinHardness.clauseSat_eq
end Ctl31
section Ctl32
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetAdj
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetAdj_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetAdj_eq := @TCSlib.Cryptography.LevinHardness.gadgetAdj_eq
end Ctl32
section Ctl33
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetEdge
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetEdge_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetEdge_eq := @TCSlib.Cryptography.LevinHardness.gadgetEdge_eq
end Ctl33
section Ctl34
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetGraph
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetGraph_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetGraph_apply := @TCSlib.Cryptography.LevinHardness.gadgetGraph_apply
end Ctl34
section Ctl35
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetN
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetN_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetN_eq := @TCSlib.Cryptography.LevinHardness.gadgetN_eq
end Ctl35
section Ctl36
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.litVal
example : type_of% @TCSlib.Cryptography.LevinHardness.litVal_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.litVal_eq := @TCSlib.Cryptography.LevinHardness.litVal_eq
end Ctl36
section Ctl37
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.padColWord
example : type_of% @TCSlib.Cryptography.LevinHardness.padColWord_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.padColWord_eq := @TCSlib.Cryptography.LevinHardness.padColWord_eq
end Ctl37
section Ctl38
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.padColoring
example : type_of% @TCSlib.Cryptography.LevinHardness.padColoring_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.padColoring_apply := @TCSlib.Cryptography.LevinHardness.padColoring_apply
end Ctl38
section Ctl39
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.padGraph
example : type_of% @TCSlib.Cryptography.LevinHardness.padGraph_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.padGraph_apply := @TCSlib.Cryptography.LevinHardness.padGraph_apply
end Ctl39
section Ctl40
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.padWord
example : type_of% @TCSlib.Cryptography.LevinHardness.padWord_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.padWord_eq := @TCSlib.Cryptography.LevinHardness.padWord_eq
end Ctl40
section Ctl41
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.R_3SAT
example : type_of% @TCSlib.Cryptography.LevinHardness.R_3SAT_iff := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.R_3SAT_iff := @TCSlib.Cryptography.LevinHardness.R_3SAT_iff
end Ctl41
section Ctl42
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.R_CKT
example : type_of% @TCSlib.Cryptography.LevinHardness.R_CKT_iff := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.R_CKT_iff := @TCSlib.Cryptography.LevinHardness.R_CKT_iff
end Ctl42
section Ctl43
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.gadgetFormula
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetFormula_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.gadgetFormula_eq := @TCSlib.Cryptography.LevinHardness.gadgetFormula_eq
end Ctl43
section Ctl44
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.reductionGraphHom
example : type_of% @TCSlib.Cryptography.LevinHardness.reductionGraphHom_apply := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.reductionGraphHom_apply := @TCSlib.Cryptography.LevinHardness.reductionGraphHom_apply
end Ctl44
section Ctl45
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.certOf
example : type_of% @TCSlib.Cryptography.LevinHardness.certOf_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.certOf_eq := @TCSlib.Cryptography.LevinHardness.certOf_eq
end Ctl45
section Ctl46
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.stripCert
example : type_of% @TCSlib.Cryptography.LevinHardness.stripCert_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.stripCert_eq := @TCSlib.Cryptography.LevinHardness.stripCert_eq
end Ctl46
section Ctl47
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.tabCkt
example : type_of% @TCSlib.Cryptography.LevinHardness.tabCkt_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.tabCkt_eq := @TCSlib.Cryptography.LevinHardness.tabCkt_eq
end Ctl47
section Ctl48
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.tabInst
example : type_of% @TCSlib.Cryptography.LevinHardness.tabInst_def := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.tabInst_def := @TCSlib.Cryptography.LevinHardness.tabInst_def
end Ctl48
section Ctl49
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.verTest
example : type_of% @TCSlib.Cryptography.LevinHardness.verTest_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.verTest_eq := @TCSlib.Cryptography.LevinHardness.verTest_eq
end Ctl49
section Ctl50
attribute [local irreducible] TCSlib.Cryptography.LevinHardness.verTime
example : type_of% @TCSlib.Cryptography.LevinHardness.verTime_eq := by intros; first | exact rfl | exact Iff.rfl
example : type_of% @TCSlib.Cryptography.LevinHardness.verTime_eq := @TCSlib.Cryptography.LevinHardness.verTime_eq
end Ctl50
