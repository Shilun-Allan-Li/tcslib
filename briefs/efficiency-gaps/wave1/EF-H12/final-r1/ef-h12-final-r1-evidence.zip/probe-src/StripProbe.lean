import TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Verifier
set_option autoImplicit false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

/-! EF-H12 phase 2: attribution of the one canonical coe-A seal failure (`polyTimeComputable_stripCert`,
Verifier.lean:133) and candidate landing edits. Each section is independent. -/

open Complexity Turing

namespace TCSlib.Cryptography.LevinHardness

#print stripCert
#print axioms polyTimeComputable_stripCert

-- S0 (control): the delivered proof, nothing sealed. Expected: passes.
section S0
example : PolyTimeComputable stripCert := by
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_stripLast
  exact (polyTimeComputable_iff _).2 ⟨M, c, 2, hM⟩
end S0

-- S1 (attribution): only the catalog statement's matcher sealed. Expected: fails (as under coe-A).
section S1
attribute [local irreducible] Turing.FinTM.stripLastTM_computes.match_1
example : PolyTimeComputable stripCert := by
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_stripLast
  exact (polyTimeComputable_iff _).2 ⟨M, c, 2, hM⟩
end S1

-- F1: transport along the pointwise equation, splitting both matches through their splitters.
section F1
attribute [local irreducible] Turing.FinTM.stripLastTM_computes.match_1 stripCert
example : PolyTimeComputable stripCert := by
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_stripLast
  refine (polyTimeComputable_iff _).2 ⟨M, c, 2, ?_⟩
  convert hM using 2
  rename_i z
  rw [stripCert_eq]
  split <;> split <;> simp_all
end F1

-- F2: as F1, case analysis on `pairDecode z` and `splitAtLastTrue v` first, then `simp only`.
section F2
attribute [local irreducible] Turing.FinTM.stripLastTM_computes.match_1 stripCert
example : PolyTimeComputable stripCert := by
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_stripLast
  refine (polyTimeComputable_iff _).2 ⟨M, c, 2, ?_⟩
  convert hM using 2
  rename_i z
  rw [stripCert_eq]
  rcases h : pairDecode z with _ | ⟨a, v⟩
  · simp
  · rcases h' : splitAtLastTrue v with _ | u <;> simp
end F2

-- F3: as F1, with `split` repeated and closing by `rfl` on reduced branches.
section F3
attribute [local irreducible] Turing.FinTM.stripLastTM_computes.match_1 stripCert
example : PolyTimeComputable stripCert := by
  obtain ⟨M, c, hM⟩ := FinTM.computesFunInTime_stripLast
  refine (polyTimeComputable_iff _).2 ⟨M, c, 2, ?_⟩
  convert hM using 2
  rename_i z
  rw [stripCert_eq]
  repeat' split
  all_goals simp_all
end F3

end TCSlib.Cryptography.LevinHardness
