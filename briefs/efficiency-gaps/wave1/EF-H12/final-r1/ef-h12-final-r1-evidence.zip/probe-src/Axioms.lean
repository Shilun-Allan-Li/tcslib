import TCSlib.Cryptography.ZeroKnowledge
open Lean Elab Command

/-! EF-H12 final r1 phase 2 (P2-3): axiom census of every constant stored by the 12 new LevinHardness modules and
their facade (the recipe's `AxiomProbe.r2.lean` with the owner list replaced), the headline and both corollaries by
name, and a `sorry` control. -/

theorem efh12SorryControl : (1 : Nat) = 2 := sorry

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Relations, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Bridge, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Gadget, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Padding, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.UnaryArith, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Verifier, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.CircuitWitness, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.ColoringGraph, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.ColoringWitness, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.ColoringParse, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Soundness, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness.Hardness, `TCSlib.Cryptography.ZeroKnowledge.LevinHardness]
  let extra : List Name := [`TCSlib.Cryptography.levinNPHard_L3COL,
    `TCSlib.Cryptography.zk_proof_of_witnessRelation_of_owp_unconditional,
    `TCSlib.Cryptography.zk_proof_of_mem_NP_of_owp_unconditional]
  let idxs := mods.filterMap env.getModuleIdx?
  IO.println s!"OWNERS\t{mods.length}\t{idxs.length}"
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        out := out.push s!"{tag}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    | none => pure ()
  for n in extra do
    if env.contains n then
      let axs ← liftCoreM (Lean.collectAxioms n)
      out := out.push s!"HEADLINE\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    else
      out := out.push s!"MISSING\t{n}\t-"
  for l in out.qsort (· < ·) do
    IO.println l
  let c ← liftCoreM (Lean.collectAxioms `efh12SorryControl)
  IO.println s!"CONTROL\tefh12SorryControl\t{c.toList}"

#print axioms TCSlib.Cryptography.levinNPHard_L3COL
#print axioms TCSlib.Cryptography.zk_proof_of_witnessRelation_of_owp_unconditional
#print axioms TCSlib.Cryptography.zk_proof_of_mem_NP_of_owp_unconditional
