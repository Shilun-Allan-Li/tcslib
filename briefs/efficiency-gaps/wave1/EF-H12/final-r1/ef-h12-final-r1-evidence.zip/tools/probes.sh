#!/usr/bin/env bash
# EF-H12 final r1 phase 2: copy the named probe sources from probe-src/ into the scratch worktree's EFH12Probe/ and run
# them one at a time through runq.sh + the recipe's runner_full.py (lean -DmaxErrors=0, no -o: nothing is written to
# the olean tree). Usage: probes.sh <batch-name> <ProbeName>...
set -u
B=$1; shift
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efh12/p2; W=$P2/wt; PS=$P2/probe-src; TREE=$SP/olean-replay-efh12; R=$P2/rule10/$B
S=$P2/recipe/x/olean-advance-a6d01b1b/tools-used/seal
export TMPDIR=$P2/tmp; mkdir -p $TMPDIR $R $W/EFH12Probe
test "$(git -C $W rev-parse HEAD)" = 63d619e8440969a4afc06d5274b55c418cf309f7 || { echo "worktree not at check head"; exit 1; }
: > $R/queue.txt
for p in "$@"; do
  mkdir -p "$(dirname $W/EFH12Probe/$p.lean)"; cp $PS/$p.lean $W/EFH12Probe/$p.lean
  sha256sum $W/EFH12Probe/$p.lean >> $R/probe-sources.sha256; echo EFH12Probe/$p >> $R/queue.txt
done
bash $P2/tools/runq.sh $S/runner_full.py $W $R/queue.txt $TREE $R/runs 0
python3 -I -c 'import json,sys
for l in open(sys.argv[1]):
  r=json.loads(l)
  if "module" in r: print(r["module"], "rc", r["rc"], "errors", r["errors"], "sorry", r["sorry"], "warnings", r["warnings"], r["seconds"], "s")' $R/runs/results.jsonl
