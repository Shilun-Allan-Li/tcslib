"""sealparts.py <records-dir> <rundir>: per seal probe, the harness parts' install (G06-SEAL) and end (G06-SEAL-END)
records, with requested/verified per part, the EOF verification-probe results, rc and errors, time."""
import sys, json, re, glob, os
recdir, rd = sys.argv[1:3]
res = {}
for l in open(os.path.join(rd, 'results.jsonl')):
    x = json.loads(l)
    if 'module' in x: res[x['module']] = x
for p in sorted(glob.glob(os.path.join(recdir, '*.json'))):
    if p.endswith('manifest.json'): continue
    r = json.load(open(p)); m = r['probe_module']; x = res.get(m)
    if not x: print(r['label'], 'NOT RUN'); continue
    log = open(os.path.join(rd, 'mods', m.replace('/', '_') + '.log'), encoding='utf-8', errors='replace').read()
    ends = re.findall(r'G06-SEAL-END label=(\S+) requested=(\d+) verified=(\d+)', log)
    inst = re.findall(r'G06-SEAL label=(\S+)', log)
    ok = all(a == b for _, a, b in ends) and sum(int(a) for _, a, _ in ends) == r['requested'] and len(inst) == len(ends) > 0
    print(f"{r['module'].split('.')[-1]}\trequests {r['requested']}\tterms {r['term_names']}\texcluded {len(r['term_excluded'])} {sorted(r['term_excluded'].items())}\tstored {r['stored_constants']}"
          f"\tparts {'+'.join(a for _, a, _ in ends)}\tinstall {len(inst)} end {len(ends)} verified=requested {ok}\trc {x['rc']} errors {x['errors']}\t{x['seconds']} s")
