#!/usr/bin/env bash
# EF-H12 final r1 phase 2, P2-6 (F02): rebuild the LE-h12-pow scratch commit's downstream (10 modules) on a separate
# hard-linked copy of the accepted replay tree, $SP/olean-replay-efh12-le, one module at a time (runq.sh + runner.py).
# The accepted check-head tree $SP/olean-replay-efh12 is only read and hard-linked; rebuilt modules are unlinked first
# by lean_check_tree.sh, so nothing is written through to it (or to the snapshot).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efh12/p2; T=$P2/recipe/x/olean-advance-a6d01b1b/tools-used; LE=7880f92458c3e894a4b8b09b49305c75197b6ff9
OUT=$SP/olean-replay-efh12-le; export TMPDIR=$P2/tmp
test -e $OUT && { echo "$OUT exists"; exit 1; }
free=$(df -BM --output=avail / | tail -1 | tr -dc 0-9); [ $free -lt 2000 ] && { echo "disk $free"; exit 3; }
cp -al $SP/olean-replay-efh12 $OUT
echo "copy $(find $OUT -type f | wc -l) files, $(find $OUT -type l | wc -l) symlinks $(date -u +%FT%TZ)"
bash $P2/tools/runq.sh $T/runner.py $P2/tree-le $P2/plan-le/plan/queue.txt $OUT $P2/build-le 1
python3 -I $T/permod.py $P2/build-le $P2/build-le/permod.tsv
cd $P2/plan-le && python3 -I $T/stateplan.py update $P2/wt $LE state.json $P2/build-le/results.jsonl $OUT \
  && python3 -I $T/stateplan.py check $P2/wt $LE full-order.txt state.json $OUT check-out
while read m; do echo "$(stat -c %h $OUT/$m.olean) $m"; done < $P2/plan-le/plan/queue.txt
echo "LE-DONE $(date -u +%FT%TZ)"
