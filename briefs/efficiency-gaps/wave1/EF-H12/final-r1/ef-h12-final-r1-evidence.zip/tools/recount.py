"""recount.py ctl <ctl-lines.tsv> <sealed.log> <open.log> | lines <log>: EF-H12 phase-2 recounts.
ctl: every error line of the sealed control log must be a NEG line, each NEG must fail exactly once, no POS fails;
the open log must have 0 errors. lines: print the error lines (line:col) of a Lean log, one per line."""
import sys, re
from collections import Counter
def errs(p):
    return [int(m.group(1)) for m in re.finditer(r'^\S+\.lean:(\d+):\d+: error[:(]', open(p, encoding='utf-8', errors='replace').read(), re.M)]
if sys.argv[1] == 'ctl':
    rows = [l.rstrip('\n').split('\t') for l in open(sys.argv[2]) if l[0].isdigit()]
    rows = rows[:len(rows) // 2]  # sealed block comes first
    e = Counter(errs(sys.argv[3])); eo = errs(sys.argv[4])
    neg = {int(r[3]): r for r in rows}; pos = {int(r[4]): r for r in rows}
    bad = []
    for ln, r in neg.items():
        ok = e.get(ln, 0) == 1
        print(f'pair {r[0]}\t{r[1].split(".")[-1]}\t{r[2].split(".")[-1]}\tNEG line {ln} errors {e.get(ln, 0)}\tPOS line {r[4]} errors {e.get(int(r[4]), 0)}\t{"OK" if ok and not e.get(int(r[4])) else "BAD"}')
        if not ok or e.get(int(r[4])): bad.append(r[0])
    stray = [ln for ln in e if ln not in neg]
    print(f'pairs {len(rows)}; NEG failing exactly once {sum(1 for ln in neg if e.get(ln) == 1)}; POS failing {sum(1 for ln in pos if e.get(ln))}; stray error lines {stray}; open-file errors {len(eo)}; {"ALL_OK" if not bad and not stray and not eo else "NOT_OK " + str(bad)}')
else:
    for ln, c in sorted(Counter(errs(sys.argv[2])).items()): print(ln, c)
