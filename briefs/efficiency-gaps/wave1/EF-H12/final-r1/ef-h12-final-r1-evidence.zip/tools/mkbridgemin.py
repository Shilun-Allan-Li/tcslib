"""mkbridgemin.py <worker sealed Bridge copy> <head Bridge.lean> <out.lean> [overrides.tsv]: EF-H12 phase-2 minimal
unseal of Bridge.lean. Takes the worker's strict sealed copy (one whole-file `attribute [local irreducible]` line of the
20 bridged candidates, and one `section G04R4Unseal / attribute [local semireducible] ... / end` per declaration),
checks that removing the seal line and the wrappers gives the head source byte for byte, and rewrites each unseal line
to name ONLY the definition the declaration is named for (TARGET below), or the names given for it in overrides.tsv
(<decl>\t<names...>). Prints decl, unseal names, worker's names, declaration line."""
import sys, re
src, head, out = sys.argv[1:4]
ov = {}
if len(sys.argv) > 4:
    for l in open(sys.argv[4]):
        if l.strip(): d, *ns = l.split(); ov[d] = ns
TARGET = {
 'levinNPHard_iff': 'TCSlib.Cryptography.LevinNPHard', 'toCNF_eq': 'BoolCircuit.DAGCircuit.toCNF',
 'widthAtMost_iff': 'Std.Sat.CNF.WidthAtMost', 'numVars_eq': 'Std.Sat.CNF.numVars',
 'serializeLit_eq': 'Std.Sat.CNF.serializeLit', 'serializeClause_eq': 'Std.Sat.CNF.serializeClause',
 'serialize_eq': 'Std.Sat.CNF.serialize', 'decode_eq': 'Std.Sat.CNF.decode', 'fallback_eq': 'Std.Sat.CNF.fallback',
 'syntaxStep_eq': 'Std.Sat.CNF.syntaxStep', 'syntaxOK_eq': 'Std.Sat.CNF.syntaxOK',
 'satisfiesLiteral_pos': 'SATtoColor.SatisfiesLiteral', 'satisfiesLiteral_neg': 'SATtoColor.SatisfiesLiteral',
 'satisfiesClause_eq': 'SATtoColor.SatisfiesClause', 'satisfiesSat3_eq': 'SATtoColor.SatisfiesSat3',
 'isSatisfiable_iff': 'SATtoColor.IsSatisfiable', 'is3Colorable_iff': 'SATtoColor.Is3Colorable',
 'reductionGraph_adj': 'SATtoColor.ReductionGraph'}
L = open(src, encoding='utf-8').read().split('\n')
# reconstruct head: drop the seal line and the wrappers
H = [l for l in L if not (l.startswith('attribute [local irreducible]') or l in ('section G04R4Unseal', 'end G04R4Unseal')
     or l.startswith('attribute [local semireducible]'))]
assert '\n'.join(H) == open(head, encoding='utf-8').read(), 'worker sealed copy minus wrappers != head'
outL, pend = [], None
for i, l in enumerate(L):
    if l.startswith('attribute [local semireducible]'):
        j = next(k for k in range(i + 1, len(L)) if L[k].startswith('theorem '))
        d = L[j].split()[1]
        names = ov.get(d) or [TARGET.get(d, 'SATtoColor.EdgeRelation' if d.startswith('edgeRelation_') else None)]
        assert names[0], d
        print(f'{d}\t{" ".join(names)}\tworker: {l.split("]", 1)[1].strip()}\tline {j + 1}')
        outL.append('attribute [local semireducible] ' + ' '.join(names))
    else:
        outL.append(l)
open(out, 'w', encoding='utf-8').write('\n'.join(outL))
