"""mkowner.py <repo> <rev> <Bridge.lean> <outdir>: EF-H12 phase-2 owner-form overlay (P2-5.2). For each of the 5 owner
files, writes <outdir>/Owner_<name>.lean = the owner source at <rev> (byte for byte) followed by one appended block:
a namespace TCSlib.Cryptography.LevinHardness.Bridge with the owner-specific `open` line(s), and that owner's readers
copied VERBATIM (docstring + statement + proof) from Bridge.lean. Prints owner, reader count, readers."""
import sys, re, subprocess
repo, rev, bridge, outd = sys.argv[1:5]
B = open(bridge, encoding='utf-8').read()
# blocks: from a line starting '/--' up to the line before the next blank line
blocks = {}
for m in re.finditer(r'(?ms)^/--.*?\n(?:theorem) (\S+).*?(?=\n\n|\nend TCSlib)', B):
    blocks[m.group(1)] = m.group(0)
OWN = [
 ('CNF', 'TCSlib/Complexity/Formulas/CNF.lean', ['open Std.Sat (CNF)'], ['widthAtMost_iff', 'numVars_eq']),
 ('CNFEncoding', 'TCSlib/Complexity/Formulas/CNFEncoding.lean', ['open Std.Sat (CNF)'],
  ['serializeLit_eq', 'serializeClause_eq', 'serialize_eq', 'decode_eq', 'fallback_eq', 'syntaxStep_eq', 'syntaxOK_eq']),
 ('DAGCircuitSat', 'TCSlib/Complexity/CircuitComplexity/DAGCircuitSat.lean', ['open BoolCircuit'], ['toCNF_eq']),
 ('ThreeSATToColoring', 'TCSlib/Complexity/NPReductions/ThreeSATToColoring.lean', ['open SATtoColor'],
  ['satisfiesLiteral_pos', 'satisfiesLiteral_neg', 'satisfiesClause_eq', 'satisfiesSat3_eq', 'isSatisfiable_iff',
   'is3Colorable_iff', 'reductionGraph_adj'] + [n for n in blocks if n.startswith('edgeRelation_')]),
 ('NP', 'TCSlib/Cryptography/ZeroKnowledge/NP.lean', ['open Complexity'], ['levinNPHard_iff'])]
seen = []
for name, path, opens, rs in OWN:
    src = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True, check=True).stdout.decode()
    blk = ['', '/-! EF-H12 phase-2 owner-form overlay (scratch only, never committed): the `Bridge.lean` readers of',
           'this owner, copied verbatim. -/', '', 'namespace TCSlib.Cryptography.LevinHardness.Bridge', ''] + opens + ['']
    for r in rs:
        blk += [blocks[r], '']; seen.append(r)
    blk += ['end TCSlib.Cryptography.LevinHardness.Bridge', '']
    out = src if src.endswith('\n') else src + '\n'
    open(f'{outd}/Owner_{name}.lean', 'w', encoding='utf-8').write(out + '\n'.join(blk))
    print(name, path, len(rs), ' '.join(rs))
assert sorted(seen) == sorted(blocks), (sorted(set(blocks) - set(seen)))
print('total', len(seen), 'of', len(blocks))
