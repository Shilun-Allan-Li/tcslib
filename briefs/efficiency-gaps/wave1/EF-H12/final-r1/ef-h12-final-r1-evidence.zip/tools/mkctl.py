"""mkctl.py <pairs.tsv> <out-sealed.lean> <out-open.lean>: EF-H12 phase-2 paired controls, one per new public
definition. pairs.tsv rows: <definition>\t<reader>[\t<NEG binders and statement>] (full names); the optional third
column replaces the reader's statement in NEG by an explicit body read (for readers that are specifications, not
definitional restatements). For each pair, a section that (sealed file only)
makes the definition locally irreducible, then
  NEG  example : type_of% @reader := by intros; first | exact rfl | exact Iff.rfl     -- reads the body
  POS  example : type_of% @reader := @reader                                         -- goes through the reader
The open file is identical minus the attribute lines (so line numbers differ only by them). Prints a TSV of
pair index, definition, reader, NEG line, POS line (for the sealed file) to stdout."""
import sys
pairs = [l.rstrip('\n').split('\t') for l in open(sys.argv[1]) if l.strip() and not l.startswith('#')]
for sealed, out in ((True, sys.argv[2]), (False, sys.argv[3])):
    L = ['import TCSlib.Cryptography.ZeroKnowledge.LevinHardness', 'set_option autoImplicit false',
         'set_option maxHeartbeats 0',
         'set_option linter.unusedTactic false', 'set_option linter.unreachableTactic false', '']
    rows = []
    for i, row in enumerate(pairs, 1):
        d, r = row[0], row[1]
        L.append(f'section Ctl{i}')
        if sealed: L.append(f'attribute [local irreducible] {d}')
        if len(row) > 2: L.append(f'example {row[2]} := by intros; first | exact rfl | exact Iff.rfl')
        else: L.append(f'example : type_of% @{r} := by intros; first | exact rfl | exact Iff.rfl')
        neg = len(L)
        L.append(f'example : type_of% @{r} := @{r}')
        pos = len(L)
        L.append(f'end Ctl{i}')
        rows.append((i, d, r, neg, pos))
    open(out, 'w').write('\n'.join(L) + '\n')
    print(('sealed' if sealed else 'open') + '\t' + out)
    for x in rows: print('\t'.join(map(str, x)))
