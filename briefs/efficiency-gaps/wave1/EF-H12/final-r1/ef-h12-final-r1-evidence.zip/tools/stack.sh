#!/usr/bin/env bash
# EF-H12 final r1 phase 2, P2-1: (a) reproduce the worker head c8d5b3c7 at REC cf6a2266 by git am of the 19 delivered
# patches with each commit's committer name/e-mail/date from COMMITS.tsv (unsigned); (b) the check head: the same 19
# patches applied by git am onto bff0567b (unsigned, committer "EF-H12 phase2 scratch", fixed date 2026-11-18T12:00:00Z).
# Scratch only: detached sparse worktree, never pushed.
set -eu
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efh12/p2; D=$P2/deliv/inbox/fills/ef-h12-levin-3col; W=$P2/wt
cd $W
git checkout -q --detach cf6a2266e9556ca8ad61e56f7232266ccc6d4e62
i=0
tail -n +2 $D/COMMITS.tsv | while IFS=$'\t' read -r h an ae ad cn ce cd sig subj; do
  i=$((i+1)); p=$(ls $D/patches/ | sed -n "${i}p")
  GIT_COMMITTER_NAME="$cn" GIT_COMMITTER_EMAIL="$ce" GIT_COMMITTER_DATE="$cd" \
    git -c commit.gpgsign=false am -q --keep-cr "$D/patches/$p"
  got=$(git rev-parse HEAD); [ "$got" = "$h" ] && echo "repro $i $got OK" || { echo "repro $i $got != $h"; exit 1; }
done
git rev-parse HEAD > $P2/logs/worker-head.txt
git checkout -q --detach bff0567b6c4b6b724c8fd20ff3ef92258eb3fc9d
for p in $(ls $D/patches/); do
  GIT_COMMITTER_NAME="EF-H12 phase2 scratch" GIT_COMMITTER_EMAIL="noreply@anthropic.com" GIT_COMMITTER_DATE="2026-11-18T12:00:00Z" \
    git -c commit.gpgsign=false am -q --keep-cr "$D/patches/$p"
done
echo "check head $(git rev-parse HEAD) tree $(git rev-parse HEAD^{tree})"
