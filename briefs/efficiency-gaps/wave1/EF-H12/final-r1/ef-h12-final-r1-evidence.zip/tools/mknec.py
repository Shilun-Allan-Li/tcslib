"""mknec.py <wt> <seal-names.txt> <outdir>: EF-H12 phase-2 bridge necessity demonstration (P2-5.1). For each consumer
(CircuitWitness, ColoringParse, Soundness, Hardness) writes two copies of the head source:
  Nec_<F>_sealed.lean : the 20 bridged definitions made locally irreducible (one line after the options), and every
                        code use `Bridge.X` replaced by `(by intros; first | exact rfl | exact Iff.rfl : type_of% @Bridge.X)`,
                        i.e. the reader's statement proved in place by a definitional read instead of by the reader;
  Nec_<F>_open.lean   : the same replacement without the seal (the control).
Comments and docstrings are left untouched. Prints per file the use lines (1-based, in the sealed copy) and names."""
import sys, re
wt, sealf, outd = sys.argv[1:4]
names = [l.strip() for l in open(sealf) if l.strip()]
SEAL = 'attribute [local irreducible] ' + ' '.join(names)
def code_mask(src):
    m, i, depth, n = [], 0, 0, len(src)
    while i < n:
        if depth == 0 and src.startswith('--', i):
            j = src.find('\n', i); j = n if j < 0 else j; m += [False] * (j - i); i = j; continue
        if src.startswith('/-', i): depth += 1; m += [False, False]; i += 2; continue
        if depth > 0 and src.startswith('-/', i): depth -= 1; m += [False, False]; i += 2; continue
        m.append(depth == 0); i += 1
    return m
for F in ['CircuitWitness', 'ColoringParse', 'Soundness', 'Hardness']:
    src = open(f'{wt}/TCSlib/Cryptography/ZeroKnowledge/LevinHardness/{F}.lean', encoding='utf-8').read()
    mask = code_mask(src); out, last, uses = [], 0, []
    for mt in re.finditer(r'(?<![\w.])Bridge\.([A-Za-z0-9_]+)', src):
        if not mask[mt.start()]: continue
        out.append(src[last:mt.start()])
        out.append(f'(by intros; first | exact rfl | exact Iff.rfl : type_of% @Bridge.{mt.group(1)})')
        last = mt.end(); uses.append((src.count('\n', 0, mt.start()) + 1, mt.group(1)))
    out.append(src[last:]); body = ''.join(out)
    L = body.split('\n'); k = max(i for i, l in enumerate(L) if l.startswith('set_option autoImplicit false'))
    sealed = '\n'.join(L[:k + 1] + [SEAL] + L[k + 1:])
    opts = 'set_option linter.unusedTactic false\nset_option linter.unreachableTactic false\n'
    open(f'{outd}/Nec_{F}_sealed.lean', 'w', encoding='utf-8').write(sealed)
    open(f'{outd}/Nec_{F}_open.lean', 'w', encoding='utf-8').write(body)
    # use lines in the sealed copy are +1 (the seal line) after line k+1
    print(F, len(uses), ' '.join(f'{ln + (1 if ln > k + 1 else 0)}:{nm}' for ln, nm in uses))
