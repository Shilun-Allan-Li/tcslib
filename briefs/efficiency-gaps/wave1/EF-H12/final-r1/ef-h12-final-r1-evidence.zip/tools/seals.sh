#!/usr/bin/env bash
# EF-H12 final r1 phase 2, P2-4: gate-04 collector (for the explicit-unfold scan), the worker's strict whole-file seals
# re-run on this tree, then the canonical coe-A and seal-B (SEAL_EVAL=1) harness seals of the 11 non-bridge owners
# (written by mkseals_coe.py into EFH12Probe/C and EFH12Probe/CB), all through runq.sh + runner_full.py, one at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efh12/p2; W=$P2/wt; TREE=$SP/olean-replay-efh12; S=$P2/recipe/x/olean-advance-a6d01b1b/tools-used/seal
export TMPDIR=$P2/tmp
bash $P2/tools/probes.sh b3 G04Collect
bash $P2/tools/probes.sh strict $(cd $P2/probe-src && ls Strict/*.lean | sed 's/\.lean$//')
for V in A B; do
  d=C; [ $V = B ] && d=CB
  R=$P2/rule10/seal/runs-$V; mkdir -p $R
  (cd $W && ls EFH12Probe/$d/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/queue.txt
  bash $P2/tools/runq.sh $S/runner_full.py $W $R/queue.txt $TREE $R 0
  echo '{"files":{}}' > $R/touched-empty.json
  python3 -I $S/review/sealsum.py $P2/rule10/seal/$V $R $R/touched-empty.json $P2/rule10/seal/seals-coe-$V.tsv
  echo "variant $V done $(date -u +%FT%TZ)"
done
echo "SEALS-DONE $(date -u +%FT%TZ)"
