import TCSlib.Cryptography.Encoding.ModularArithmetic
import TCSlib.Cryptography.Encryption.Symmetric.Regev.Asymptotic
import TCSlib.Cryptography.Encryption.PublicKey.Regev.Asymptotic

/-! EF-R2/R3 final r1 phase 2, the maintainer's own R-P1 and R-P2 probes (`#eval` evidence only,
never proofs). Written from scratch because the delivery's `evidence/probes/` files are listed in its
manifests but absent from the delivered tree (EFR23-F02).

R-P1: `addMod`, `vecAddModWords` and `subsetSumModWords` in the canonical context `modContext w q`
against `ZMod q` arithmetic, for `q ∈ {2, 3, 5, 7, 8, 12}` at the least width `w` with `q ≤ 2^w`
(so `q = 2^w` for `q = 2, 8`), lengths `≤ 3`, rows `≤ 3`, columns `≤ 2`, every bit vector, with
two unread extra subset bits. R-P2: `shiftPre` and `encryptPre` against the encodings of `shift` and
`view` on the toy parameters `n = 1`, `m = 2`, `q = 5`, width `3`, over every challenge. -/

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Encoding.ModularArithmetic

namespace EFR23Probe

/-- Base-`q` digits of `k` as a vector of length `len`. -/
def vecOf (q len k : ℕ) : Fin len → ZMod q := fun i => (((k / q ^ (i : ℕ)) % q : ℕ) : ZMod q)

/-- The bit vector of `j`. -/
def bitsOf (m j : ℕ) : Fin m → Bool := fun i => Nat.testBit j i

/-- At most `c` indices spread over `range N`. -/
def sample (N c : ℕ) : List ℕ :=
  if N ≤ c then List.range N else ((List.range c).map fun i => i * N / c).dedup

/-- `(cases, mismatches)` for scalar addition: all pairs of residues. -/
def addCheck (q : ℕ) [NeZero q] : ℕ × ℕ :=
  let w := Nat.clog 2 q
  (List.range q).foldl (fun acc a => (List.range q).foldl (fun acc b =>
    let x : ZMod q := (a : ZMod q); let y : ZMod q := (b : ZMod q)
    let ok := addMod (pairEncode (modContext w q)
        (pairEncode (Candidates.natToList w x.val) (Candidates.natToList w y.val))) ==
      Candidates.natToList w (x + y).val
    (acc.1 + 1, acc.2 + if ok then 0 else 1)) acc) (0, 0)

/-- `(cases, mismatches)` for vector addition at length `len`, up to 20 × 20 vector pairs. -/
def vecCheck (q : ℕ) [NeZero q] (len : ℕ) : ℕ × ℕ :=
  let w := Nat.clog 2 q
  let ks := sample (q ^ len) 20
  ks.foldl (fun acc k₁ => ks.foldl (fun acc k₂ =>
    let u := vecOf q len k₁; let v := vecOf q len k₂
    let ok := vecAddModWords (modContext w q) (List.replicate len true)
        (Encoding.Modular.encodeVector w u) (Encoding.Modular.encodeVector w v) ==
      Encoding.Modular.encodeVector w (u + v)
    (acc.1 + 1, acc.2 + if ok then 0 else 1)) acc) (0, 0)

/-- `(cases, mismatches)` for `m × n` subset sums: up to 12 matrices, every bit vector, two extra
unread bits; plus the one-column residue form against `∑ i, b i * r i`. -/
def subsetCheck (q : ℕ) [NeZero q] (m n : ℕ) : ℕ × ℕ :=
  let w := Nat.clog 2 q
  let extra := [true, false]
  (sample (q ^ (m * n)) 12).foldl (fun acc k => (List.range (2 ^ m)).foldl (fun acc j =>
    let A : Matrix (Fin m) (Fin n) (ZMod q) := fun i c => vecOf q (m * n) k
      ⟨(i : ℕ) * n + c, by
        have hi := i.isLt; have hc := c.isLt
        calc (i : ℕ) * n + c < (i : ℕ) * n + n := by omega
          _ = ((i : ℕ) + 1) * n := by ring
          _ ≤ m * n := Nat.mul_le_mul_right n hi⟩
    let r := bitsOf m j
    let b : Fin m → ZMod q := vecOf q m (k + j)
    let ok₁ := subsetSumModWords (modContext w q) (List.replicate n true) (List.replicate m true)
        (Encoding.Modular.encodeMatrix w A) (List.ofFn r ++ extra) ==
      Encoding.Modular.encodeVector w (A.transpose.mulVec fun i => ((r i).toNat : ZMod q))
    let ok₂ := subsetSumModWords (modContext w q) [true] (List.replicate m true)
        (Encoding.Modular.encodeVector w b) (List.ofFn r ++ extra) ==
      Candidates.natToList w (∑ i, b i * ((r i).toNat : ZMod q)).val
    (acc.1 + 2, acc.2 + (if ok₁ then 0 else 1) + (if ok₂ then 0 else 1))) acc) (0, 0)

/-- The R-P1 rows of one modulus. -/
def rows (q : ℕ) (h : q ≠ 0) : List String :=
  haveI : NeZero q := ⟨h⟩
  let w := Nat.clog 2 q
  let a := addCheck q
  [s!"RP1 q={q} w={w} add cases={a.1} mismatches={a.2}"] ++
  (List.range 4).map (fun len =>
    let c := vecCheck q len
    s!"RP1 q={q} w={w} vec len={len} cases={c.1} mismatches={c.2}") ++
  ([(1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (3, 2)] : List (ℕ × ℕ)).map (fun mn =>
    let c := subsetCheck q mn.1 mn.2
    s!"RP1 q={q} w={w} subset {mn.1}x{mn.2} cases={c.1} mismatches={c.2}")

#eval (rows 2 (by decide)).forM IO.println
#eval (rows 3 (by decide)).forM IO.println
#eval (rows 5 (by decide)).forM IO.println
#eval (rows 7 (by decide)).forM IO.println
#eval (rows 8 (by decide)).forM IO.println
#eval (rows 12 (by decide)).forM IO.println

-- Malformed inputs: every map is total; these evaluate to some string.
#eval IO.println s!"RP1 malformed {addMod [true, false, true]} {vecAddModWords [] [true] [true] []} {subsetSumModWords [true] [] [true, true] [false] [true]} {Encryption.Symmetric.Regev.shiftPre [true]} {Encryption.PublicKey.Regev.encryptPre [false, true]}"

/-! R-P2: the toy parameters `n = 1`, `m = 2`, `q = 5`, width `3`. -/

def toyP : LWE.Parameters := ⟨1, 2, 5, by decide⟩

/-- The challenge with index `k < 5^4`: matrix digits then value digits. -/
def chal (k : ℕ) : Matrix (Fin toyP.samples) (Fin toyP.dimension) (ZMod toyP.modulus) ×
    (Fin toyP.samples → ZMod toyP.modulus) :=
  (fun i _ => (((k / 5 ^ (i : ℕ)) % 5 : ℕ) : ZMod toyP.modulus),
    fun i => (((k / 5 ^ (2 + (i : ℕ))) % 5 : ℕ) : ZMod toyP.modulus))

def bitsP (j : ℕ) : Fin toyP.samples → Bool := fun i => Nat.testBit j i

/-- `(cases, mismatches)`: `shiftPre ⟨shiftAdvice μ, enc x⟩ = enc (shift μ x)`. -/
def shiftCheck : ℕ × ℕ :=
  (List.range 625).foldl (fun acc k => (List.range 4).foldl (fun acc j =>
    let x := chal k; let μ := bitsP j
    let ok := Encryption.Symmetric.Regev.shiftPre
        (pairEncode (Encryption.Symmetric.Regev.shiftAdvice toyP 3 μ) (LWE.encodeChallenge toyP 3 x)) ==
      LWE.encodeChallenge toyP 3 (Encryption.Symmetric.Regev.shift toyP μ x)
    (acc.1 + 1, acc.2 + if ok then 0 else 1)) acc) (0, 0)

/-- `(cases, mismatches)`: `encryptPre ⟨encryptAdvice μ, ⟨enc pk, r ++ extra⟩⟩ = encodeView (view μ pk r)`. -/
def encryptCheck : ℕ × ℕ :=
  (List.range 625).foldl (fun acc k => [false, true].foldl (fun acc μ => (List.range 4).foldl
    (fun acc j =>
      let pk := chal k; let r := bitsP j
      let ok := Encryption.PublicKey.Regev.encryptPre
          (pairEncode (Encryption.PublicKey.Regev.encryptAdvice toyP 3 μ)
            (pairEncode (LWE.encodeChallenge toyP 3 pk) (List.ofFn r ++ [true, true, false]))) ==
        Encryption.PublicKey.Regev.encodeView toyP 3 (Encryption.PublicKey.Regev.view toyP μ pk r)
      (acc.1 + 1, acc.2 + if ok then 0 else 1)) acc) acc) (0, 0)

#eval IO.println s!"RP2 shiftPre cases={shiftCheck.1} mismatches={shiftCheck.2}"
#eval IO.println s!"RP2 encryptPre cases={encryptCheck.1} mismatches={encryptCheck.2}"

-- A negative control: a wrong codepoint advice must mismatch.
#eval IO.println s!"RP2 control (wrong bit) equal={Encryption.PublicKey.Regev.encryptPre (pairEncode (Encryption.PublicKey.Regev.encryptAdvice toyP 3 true) (pairEncode (LWE.encodeChallenge toyP 3 (chal 7)) (List.ofFn (bitsP 1)))) == Encryption.PublicKey.Regev.encodeView toyP 3 (Encryption.PublicKey.Regev.view toyP false (chal 7) (bitsP 1))}"

end EFR23Probe
