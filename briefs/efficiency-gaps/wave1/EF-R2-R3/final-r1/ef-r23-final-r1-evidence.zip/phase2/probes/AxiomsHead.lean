import TCSlib.Cryptography.Encoding.ModularArithmetic
import TCSlib.Cryptography.Encryption.Symmetric.Regev.Asymptotic
import TCSlib.Cryptography.Encryption.PublicKey.Regev.Asymptotic
open Lean Elab Command

/-! EF-R2/R3 final r1 phase 2: axiom census of every constant stored by the three new owners (the
recipe's `AxiomProbe.r2.lean` with the owner list replaced, as in the EF-D1 review), and a `sorry`
control. -/

theorem efr23SorryControl : (1 : Nat) = 2 := sorry

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.Encoding.ModularArithmetic,
    `TCSlib.Cryptography.Encryption.Symmetric.Regev.Asymptotic,
    `TCSlib.Cryptography.Encryption.PublicKey.Regev.Asymptotic]
  let idxs := mods.filterMap env.getModuleIdx?
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        out := out.push s!"{tag}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    | none => pure ()
  for l in out.qsort (· < ·) do
    IO.println l
  let c ← liftCoreM (Lean.collectAxioms `efr23SorryControl)
  IO.println s!"CONTROL\tefr23SorryControl\t{c.toList}"
