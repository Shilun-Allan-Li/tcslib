"""EF-R2/R3 final r1 phase 1: recount the delivered Rule-10 seal and control logs.
usage: python3 -I recount_r10.py <evidence/rule10/rule10> <head worktree>"""
import sys, os, re, json, hashlib
R, WT = sys.argv[1], sys.argv[2]
sha = lambda b: hashlib.sha256(b).hexdigest()
res = {}
for line in open(os.path.join(R, 'seal-runs/results.jsonl')):
    d = json.loads(line)
    if 'module' not in d: continue
    m = d['module']; res[os.path.basename(os.path.dirname(m)) + '_' + os.path.basename(m)] = d
E1 = re.compile(r'^\S+\.lean:\d+:\d+: error:', re.M); E2 = re.compile(r'^\S+\.lean:\d+:\d+: error\(', re.M)
mods = os.path.join(R, 'seal-runs/mods')
owners = {'Encoding_ModularArithmetic': 'TCSlib/Cryptography/Encoding/ModularArithmetic.lean',
 'Encoding': 'TCSlib/Cryptography/Encoding.lean',
 'Encryption_Symmetric_Regev_Asymptotic': 'TCSlib/Cryptography/Encryption/Symmetric/Regev/Asymptotic.lean',
 'Encryption_Symmetric_Regev': 'TCSlib/Cryptography/Encryption/Symmetric/Regev.lean',
 'Encryption_PublicKey_Regev_Asymptotic': 'TCSlib/Cryptography/Encryption/PublicKey/Regev/Asymptotic.lean',
 'Encryption_PublicKey_Regev': 'TCSlib/Cryptography/Encryption/PublicKey/Regev.lean'}
tot = {'logs': 0, 'err1': 0, 'err2': 0, 'sorry': 0, 'sha_ok': 0, 'end_ok': 0}
rows = []
for f in sorted(os.listdir(mods)):
    b = open(os.path.join(mods, f), 'rb').read(); t = b.decode('utf8', 'replace')
    key = f.split('_rule10_', 1)[1][:-4]  # e.g. C_SealA_Cryptography_Encoding
    kind, name = key.split('_', 1)
    e1, e2 = len(E1.findall(t)), len(E2.findall(t)); so = len(re.findall(r'declaration uses .sorry.', t))
    r = res.get(key); shaok = r is not None and r['log_sha256'] == sha(b) and r['rc'] == 0
    ends = re.findall(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', t)
    endok = (len(ends) == 1 and ends[0][0] == ends[0][1]) if name.startswith('Seal') else None
    tot['logs'] += 1; tot['err1'] += e1; tot['err2'] += e2; tot['sorry'] += so
    tot['sha_ok'] += bool(shaok); tot['end_ok'] += bool(endok)
    rows.append((kind, name, e1, e2, so, shaok, ends[0] if ends else '-'))
for r in rows: print('\t'.join(map(str, r)))
print('TOTAL', tot)
# sealed sources: does each embed the head source body (after the header comment) verbatim?
for d in ['seals/A', 'seals/B', 'seals-coe/A', 'seals-coe/B']:
    for f in sorted(os.listdir(os.path.join(R, d))):
        if not f.endswith('.lean.txt'): continue
        own = f[len('SealA_Cryptography_'):-len('.lean.txt')]
        src = open(os.path.join(WT, owners[own]), encoding='utf8').read()
        body = src.split('\n', 4)[4]  # drop the 4-line copyright header
        body_noimp = '\n'.join(l for l in body.split('\n') if not l.startswith('import '))
        sealed = open(os.path.join(R, d, f), encoding='utf8').read()
        print('EMBED', d, own, body_noimp.strip() in sealed)
