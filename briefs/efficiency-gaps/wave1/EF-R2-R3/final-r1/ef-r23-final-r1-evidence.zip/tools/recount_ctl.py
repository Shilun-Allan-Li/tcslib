"""EF-R2/R3 final r1 phase 2: recount the delivered coe-A paired controls re-run on the replay tree.
Each control is a `theorem ctl<Name>` (negative: a foreign `rfl` read) or `theorem ctl<Name>Reader`
(positive: through the published reader); an error belongs to the theorem whose span holds its line.
Sealed (CtlS_*): every negative fails exactly once, no positive fails. Unsealed (CtlU_*): no error.
usage: python3 -I recount_ctl.py <probe dir> <log dir>"""
import sys, re, os
src, logs = sys.argv[1], sys.argv[2]; ok = True
for stem in sorted(f[:-5] for f in os.listdir(src) if f.startswith('Ctl') and f.endswith('.lean')):
    lines = open(os.path.join(src, stem + '.lean'), encoding='utf-8').read().split('\n')
    starts = [(i, m.group(1)) for i, l in enumerate(lines, 1) for m in [re.match(r'theorem (ctl\w+)', l)] if m]
    spans = [(a, (starts[k + 1][0] - 1) if k + 1 < len(starts) else len(lines), n) for k, (a, n) in enumerate(starts)]
    log = open(os.path.join(logs, f'EFR23Probe_{stem}.log'), encoding='utf-8', errors='replace').read()
    errs = [int(m.group(1)) for m in re.finditer(r'^\S+\.lean:(\d+):\d+: error[:(]', log, re.M)]
    cnt = {s: 0 for s in spans}; stray = 0
    for e in errs:
        hit = [s for s in spans if s[0] <= e <= s[1]]
        if hit: cnt[hit[0]] += 1
        else: stray += 1
    sealed = stem.startswith('CtlS')
    neg = [s for s in spans if not s[2].endswith('Reader')]; pos = [s for s in spans if s[2].endswith('Reader')]
    good = stray == 0 and all(cnt[s] == (1 if sealed else 0) for s in neg) and all(cnt[s] == 0 for s in pos)
    ok &= good
    print(f"{stem}: NEG={len(neg)} POS={len(pos)} errors={len(errs)} stray={stray} {'OK' if good else 'BAD'}")
print("ALL_OK" if ok else "NOT_OK")
