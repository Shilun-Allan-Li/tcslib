#!/usr/bin/env bash
# EF-R2/R3 final r1 phase 2 driver (after the probes): the canonical coe-A seal of the three new owners
# (mkseals_coe.py, unmodified recipe tool, SEAL_CHUNK=1000), then the LE-F01 demonstration on the scratch
# demo commit (compile, axioms, coe-A seal of the edited owner). Every Lean run through runner_full.py
# (lean -DmaxErrors=0, no -o: nothing written to the olean tree). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efr23/p2; TREE=$SP/olean-replay-efr23; W=$P2/mergewt; DW=$P2/demowt; R=$P2/rule10
T=$SP/efd1/recipe/x/olean-advance-a6d01b1b/tools-used/seal; G=$T/review/archived-gate10-tools
H=15e18eb89a401de141b36de782ae94dd3cf676aa; HD=9012382292416e82ff40267f96523e4e67296230
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$P2/tmp SEAL_CHUNK=1000; mkdir -p $TMPDIR $R/order
test "$(git -C $W rev-parse HEAD)" = "$H" || { echo "worktree not at H"; exit 1; }
test "$(git -C $DW rev-parse HEAD)" = "$HD" || { echo "demo worktree not at HD"; exit 1; }
LOG=$R/probe-runs/mods/EFR23Probe_CollectHead.log
echo "start $(date -u +%FT%TZ) lean=$(pgrep -c -x lean)"
python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A EFR23Probe/C SealA_ \
  TCSlib.Cryptography.Encoding.ModularArithmetic TCSlib.Cryptography.Encryption.Symmetric.Regev.Asymptotic \
  TCSlib.Cryptography.Encryption.PublicKey.Regev.Asymptotic > $R/mkseals-coe-A.log 2>&1
echo "mkseals rc=$? $(date -u +%FT%TZ)"
(cd $W && ls EFR23Probe/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
echo "seal lean=$(pgrep -c -x lean) parts=$(wc -l < $R/order/seal-queue.txt)"
python3 -I $T/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
echo "seals done $(date -u +%FT%TZ)"
echo '{"files":{}}' > $R/touched-empty.json
python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $R/touched-empty.json $R/seals-coe-A.tsv
# LE-F01 demonstration: the edited owner compiled, its axioms, and its own coe-A seal.
printf 'TCSlib/Cryptography/Encryption/PublicKey/Regev/Asymptotic\nEFR23Probe/PKEFixedAx\n' > $R/order/demo.txt
python3 -I $T/runner_full.py $DW $R/order/demo.txt $TREE $R/demo-runs > $R/demo-runner.out 2>&1
python3 -I $T/review/mkseals_coe.py $G $LOG $DW $HD $R/demo-seal/A EFR23Probe/C SealA_ \
  TCSlib.Cryptography.Encryption.PublicKey.Regev.Asymptotic > $R/mkseals-demo.log 2>&1
echo "mkseals demo rc=$?"
(cd $DW && ls EFR23Probe/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/demo-seal-queue.txt
python3 -I $T/runner_full.py $DW $R/order/demo-seal-queue.txt $TREE $R/demo-seal-runs > $R/demo-seal-runner.out 2>&1
python3 -I $T/review/sealsum.py $R/demo-seal/A $R/demo-seal-runs $R/touched-empty.json $R/demo-seal-A.tsv
cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv $R/mkseals-demo.log $R/demo-seal-A.tsv
echo "PHASE-DONE $(date -u +%FT%TZ)"
