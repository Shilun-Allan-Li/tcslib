#!/bin/bash
# EF-R2/R3 final r1 phase 1: git am reproduction of the delivered patches at the IO base.
set -u
R=/home/user/tcslib; W=$1; P=$2; BASE=5ed465f62e4ae0f93ded1a1ba49e807591b589eb
WT=$W/amwt
git -C $R worktree add --detach --no-checkout $WT $BASE >/dev/null 2>&1 || exit 2
git -C $WT sparse-checkout set --no-cone /TCSlib/Cryptography/Encoding/ /TCSlib/Cryptography/Encoding.lean /TCSlib/Cryptography/Encryption/ >/dev/null
git -C $WT checkout -q --detach $BASE
i=0
tail -n +2 $P/patches/COMMITS.tsv | while IFS=$'\t' read h an ae ad cn ce cd sg; do
  i=$((i+1)); f=$(ls $P/patches/$(printf '%04d' $i)-*.patch)
  GIT_COMMITTER_NAME="$cn" GIT_COMMITTER_EMAIL="$ce" GIT_COMMITTER_DATE="$cd" \
    git -C $WT -c commit.gpgsign=false am -q "$f" || { echo "AM FAIL $i"; exit 3; }
  got=$(git -C $WT rev-parse HEAD)
  [ "$got" = "$h" ] && echo "REPRODUCED $i $got" || echo "MISMATCH $i want $h got $got"
  echo "gpgsig $(git -C $WT cat-file -p HEAD | grep -c gpgsig)"
done
for f in TCSlib/Cryptography/Encoding/ModularArithmetic.lean TCSlib/Cryptography/Encoding.lean TCSlib/Cryptography/Encryption/Symmetric/Regev/Asymptotic.lean TCSlib/Cryptography/Encryption/Symmetric/Regev.lean TCSlib/Cryptography/Encryption/PublicKey/Regev/Asymptotic.lean TCSlib/Cryptography/Encryption/PublicKey/Regev.lean; do
  a=$(git -C $WT show HEAD:$f | sha256sum | cut -c1-64); b=$(sha256sum < $P/src/$f | cut -c1-64)
  [ "$a" = "$b" ] && echo "SRC EQUAL $f $a" || echo "SRC DIFF $f $a $b"
done
echo "--- diff --stat base..head"; git -C $WT diff --stat $BASE HEAD
echo "--- src file list"; (cd $P/src && find . -type f | sort)
