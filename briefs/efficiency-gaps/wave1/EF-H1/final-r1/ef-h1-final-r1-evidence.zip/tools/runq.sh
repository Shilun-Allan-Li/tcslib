#!/usr/bin/env bash
# EF-H1 phase 2: run a queue one module at a time through the recipe's runner.py (or runner_full.py),
# checking before EACH Lean start that the host has at most 2 other Lean processes (`pgrep -fc "bin/lean "`),
# so this job never takes the machine past its cap of 3. Waits (polling) while the host is full.
# Usage: runq.sh <runner.py|runner_full.py> <worktree> <queue> <tree> <logdir> <stop-on-fail 0|1>
set -u
RUN=$1; W=$2; Q=$3; TREE=$4; LOG=$5; STOP=$6
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
T=$SP/efh1/recipe/x/olean-advance-a6d01b1b/tools-used
SLOT=$SP/efh1/p2/logs/slot.log
mkdir -p "$LOG"
while read -r m; do
  [ -z "$m" ] && continue
  while :; do
    n=$(pgrep -fc "bin/lean ")
    free=$(df -BM --output=avail "$SP" | tail -1 | tr -dc 0-9)
    if [ "$free" -lt 2048 ]; then echo "DISK-STOP ${free}M before $m $(date -u +%FT%TZ)" | tee -a "$SLOT"; exit 3; fi
    [ "$n" -le 2 ] && break
    echo "wait slots=$n before $m $(date -u +%FT%TZ)" >> "$SLOT"; sleep 30
  done
  echo "start $m slots=$n disk=${free}M $(date -u +%FT%TZ)" >> "$SLOT"
  printf '%s\n' "$m" > "$LOG/one.txt"
  python3 -I "$RUN" "$W" "$LOG/one.txt" "$TREE" "$LOG" >> "$LOG/runner.out" 2>&1
  rc=$(python3 -I -c 'import sys,json
r=[json.loads(l) for l in open(sys.argv[1]) if l.strip()]
r=[x for x in r if x.get("module")==sys.argv[2]]
print(r[-1]["rc"] if r else "none")' "$LOG/results.jsonl" "$m")
  echo "end $m rc=$rc $(date -u +%FT%TZ)" >> "$SLOT"
  if [ "$rc" != "0" ] && [ "$STOP" = "1" ]; then echo "STOP at $m rc=$rc" >> "$SLOT"; exit 1; fi
done < "$Q"
echo "QUEUE-DONE $Q $(date -u +%FT%TZ)" >> "$SLOT"
