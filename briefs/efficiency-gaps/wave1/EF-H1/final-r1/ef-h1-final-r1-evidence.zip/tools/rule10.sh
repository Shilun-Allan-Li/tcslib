#!/usr/bin/env bash
# EF-H1 final r1 phase 2 driver for one run (A or B): probes (collector, axioms, smoke, H1-P1, delivered controls,
# I2 probes) and the canonical coe-A seal of the three new owners (mkseals_coe.py, unmodified recipe tool, SEAL_CHUNK=1000
# as in the EF-D1 precedent), every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing written to the tree),
# one module at a time through runq.sh (slot check before each Lean start).
# Usage: rule10.sh <A|B> <head>
set -u
RUN=$1; H=$2
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P2=$SP/efh1/p2; TREE=$SP/olean-replay-efh1; W=$P2/stackwt; R=$P2/rule10-$RUN; PS=$P2/probe-src
T=$SP/efh1/recipe/x/olean-advance-a6d01b1b/tools-used; S=$T/seal; G=$S/review/archived-gate10-tools
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$P2/tmp; mkdir -p $TMPDIR $R/order
git -C $W -c advice.detachedHead=false checkout -q $H || exit 1
test "$(git -C $W rev-parse HEAD)" = "$H" || { echo "worktree not at H"; exit 1; }
echo "start $RUN $(date -u +%FT%TZ) lean=$(pgrep -fc 'bin/lean ')"
rm -rf $W/EFH1Probe; mkdir -p $W/EFH1Probe
C=TCSlib/Cryptography/Candidates
printf '%s\n' $C/ArithmeticDischarge $C/ExtendedEuclidMachine $C/PrimesInP > $R/order/owners.txt
python3 -I $S/review/mkcollect.py $S/review/NmCollect.template.lean $R/order/owners.txt \
  "EF-H1 final r1 phase-2 collector (run $RUN)" $W/EFH1Probe/Collect.lean
cp $PS/Smoke.lean $PS/H1P1.lean $PS/I2_sealed.lean $PS/I2_unsealed.lean $PS/I2_reducibility.lean $W/EFH1Probe/
if [ $RUN = A ]; then
  cp $PS/AxiomsA.lean $W/EFH1Probe/Axioms.lean
  cp $PS/Ctl_sealed.lean $W/EFH1Probe/Ctl_sealed.lean; cp $PS/Ctl_unsealed.lean $W/EFH1Probe/Ctl_unsealed.lean
else
  cp $PS/AxiomsB.lean $W/EFH1Probe/Axioms.lean
  cp $PS/CtlB_sealed.lean $W/EFH1Probe/Ctl_sealed.lean; cp $PS/CtlB_unsealed.lean $W/EFH1Probe/Ctl_unsealed.lean
fi
sha256sum $W/EFH1Probe/*.lean > $R/probe-sources.sha256
printf 'EFH1Probe/%s\n' Collect Axioms Smoke H1P1 Ctl_sealed Ctl_unsealed I2_sealed I2_unsealed I2_reducibility > $R/order/probes.txt
bash $P2/runq.sh $S/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs 0
echo "probes $(date -u +%FT%TZ)"
LOG=$R/probe-runs/mods/EFH1Probe_Collect.log
SEAL_CHUNK=1000 python3 -I $S/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A EFH1Probe/C SealA_ \
  TCSlib.Cryptography.Candidates.ArithmeticDischarge TCSlib.Cryptography.Candidates.ExtendedEuclidMachine \
  TCSlib.Cryptography.Candidates.PrimesInP > $R/mkseals-coe-A.log 2>&1
echo "mkseals rc=$? $(date -u +%FT%TZ)"
(cd $W && ls EFH1Probe/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
bash $P2/runq.sh $S/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs 0
echo '{"files":{}}' > $R/touched-empty.json
python3 -I $S/review/sealsum.py $R/seals-coe/A $R/seal-runs $R/touched-empty.json $R/seals-coe-A.tsv
cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv
echo "PHASE-DONE $RUN $(date -u +%FT%TZ)"
