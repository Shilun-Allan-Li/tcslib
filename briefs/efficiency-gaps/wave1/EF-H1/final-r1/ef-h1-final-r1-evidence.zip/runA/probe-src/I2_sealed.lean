import TCSlib.Cryptography.Candidates.PrimesInP
attribute [local irreducible] TCSlib.Cryptography.Candidates.xgcdLoopStep TCSlib.Cryptography.Candidates.xgcdInvWord
open Complexity Turing TCSlib.Cryptography.NumberTheory TCSlib.Cryptography.Candidates
open TCSlib.Cryptography.Encoding.BinaryArith

-- owner ExtendedEuclidMachine: xgcdLoopStep
example (S : List Bool) : xgcdLoopStep S =
    if decide (LogProg.bitsVal (pairSndD (pairFstD (pairSndD S))) = 0) then S
    else pairEncode (pairFstD S)
      (pairEncode
        (pairEncode (pairSndD (pairFstD (pairSndD S)))
          (BinArith.mod (pairEncode (pairFstD (pairFstD (pairSndD S)))
            (pairSndD (pairFstD (pairSndD S))))))
        (pairEncode (pairSndD (pairSndD (pairSndD S))) (xgcdCoefStep S))) := rfl  -- NEG5
example (S : List Bool) : xgcdLoopStep S =
    if decide (LogProg.bitsVal (pairSndD (pairFstD (pairSndD S))) = 0) then S
    else pairEncode (pairFstD S)
      (pairEncode
        (pairEncode (pairSndD (pairFstD (pairSndD S)))
          (BinArith.mod (pairEncode (pairFstD (pairFstD (pairSndD S)))
            (pairSndD (pairFstD (pairSndD S))))))
        (pairEncode (pairSndD (pairSndD (pairSndD S))) (xgcdCoefStep S))) :=
  xgcdLoopStep_eq S  -- POS5
-- owner ExtendedEuclidMachine: xgcdInvWord
example (z : List Bool) : xgcdInvWord z =
    if decide (LogProg.bitsVal (toLE (pairSndD z)) = 0) then
      (if decide (LogProg.bitsVal (toLE (pairFstD z)) = 0) then Nat.bits 0 else Nat.bits 1)
    else xgcdLoopOut z := rfl  -- NEG6
example (z : List Bool) : xgcdInvWord z = Nat.bits
    ((listToNat (pairFstD z) : ZMod (listToNat (pairSndD z)))⁻¹).val :=
  xgcdInvWord_spec z  -- POS6
