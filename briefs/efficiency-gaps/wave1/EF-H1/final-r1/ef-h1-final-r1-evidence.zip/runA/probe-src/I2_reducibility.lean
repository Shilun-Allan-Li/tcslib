import TCSlib.Cryptography.NumberTheory.Euclid
open Lean

/-! EF-H1 phase 2, I2: reducibility status of the well-founded `extEuclidCalls` and `extEuclid`
(expected: irreducible, which is why the canonical seal list does not request them), and a
definitional read that must FAIL because of it (exactly one error expected, line 12). -/

#eval show CoreM Unit from do
  for n in [``TCSlib.Cryptography.NumberTheory.extEuclidCalls, ``TCSlib.Cryptography.NumberTheory.extEuclid] do
    let s ← getReducibilityStatus n
    IO.println s!"{n}\t{repr s}"
example : TCSlib.Cryptography.NumberTheory.extEuclidCalls 3 2 = 1 := rfl  -- expected to fail
