import TCSlib.Cryptography.Candidates
open Lean Elab Command

/-! EF-H1 final r1 phase 2: axiom census of every constant stored by the new owners (the recipe's
`AxiomProbe.r2.lean` with the owner list replaced), plus the named owner-file readers of the overlay,
and a `sorry` control. -/

theorem efh1SorryControl : (1 : Nat) = 2 := sorry

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.Candidates.ArithmeticDischarge, `TCSlib.Cryptography.Candidates.ExtendedEuclidMachine, `TCSlib.Cryptography.Candidates.PrimesInP]
  let extra : List Name := [`TCSlib.Cryptography.Candidates.mulStr_eq, `TCSlib.Cryptography.Candidates.addStr_eq, `TCSlib.Cryptography.Candidates.subStr_eq, `TCSlib.Cryptography.Candidates.divModStr_eq, `TCSlib.Cryptography.Candidates.xgcdStr_eq, `TCSlib.Cryptography.Candidates.modExpStr_eq, `TCSlib.Cryptography.Candidates.leStr_eq, `Randomized.mem_PRIMES, `Randomized.mem_PRIMESBin]
  let idxs := mods.filterMap env.getModuleIdx?
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        out := out.push s!"{tag}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    | none => pure ()
  for n in extra do
    if env.contains n then
      let axs ← liftCoreM (Lean.collectAxioms n)
      out := out.push s!"READER\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    else
      out := out.push s!"MISSING\t{n}\t-"
  for l in out.qsort (· < ·) do
    IO.println l
  let c ← liftCoreM (Lean.collectAxioms `efh1SorryControl)
  IO.println s!"CONTROL\tefh1SorryControl\t{c.toList}"
