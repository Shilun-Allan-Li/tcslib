  -- Build the four clean calls and their shared host, read through the typed views.
  obtain ⟨S, aS, dS, hS⟩ := ModuleHost.clean_install (polyTimeComputable_id.pairEncode hinit)
  obtain ⟨V, aV, dV, hV⟩ := ModuleHost.clean_install (verdictWord_poly hacc)
  obtain ⟨I, aI, dI, hI⟩ := ModuleHost.clean_install (stepWord_poly hg P)
  obtain ⟨E, aE, dE, hE⟩ := ModuleHost.clean_emit (outWord_poly hout)
  let M : Fin 5 → FinTM Bool := fun i => match i.val with
    | 0 => copyTMView | 1 => S | 2 => V | 3 => I | _ => E
  let K := S.k + V.k + I.k + E.k
  have hk : ∀ i, (M i).k ≤ K + 1 := by
    intro i; fin_cases i <;> simp [M, K] <;> omega
  let H := ModuleHost.hostTMView M (K + 1) hk (hostCtrl M K) (hostRet M) (ModuleHost.entry M 0)
  let anchor : H.State := .inl 0
  have hclean := ModuleHost.host_clean_view M (K + 1) hk (hostCtrl M K) (hostRet M)
    (ModuleHost.entry M 0)
  -- A seam with an empty output prefix is the seam.
  have hseam (x : List Bool) (q : ModuleHost.State (Fin 3) M) (w : List Bool) :
      ({Cfg.ofWords (input := x) q (stateWord (K + 1) w) with output := []} :
        Cfg (K + 1) Bool (ModuleHost.State (Fin 3) M) x) = Cfg.ofWords q (stateWord (K + 1) w) :=
    Cfg.ext rfl rfl rfl rfl (Cfg.ofWords_output q _).symm
  -- The three control steps (the table `hostCtrl`), read through the typed view.
  have hdisp (x w : List Bool) :
      H.tm.step (Cfg.ofWords (input := x) anchor (stateWord (K + 1) w)) =
        Cfg.ofWords (ModuleHost.entry M 2) (stateWord (K + 1) w) := by
    rw [ModuleHost.hostTMView_step_inl _ _ _ _ _ _ _ 0 (Cfg.ofWords_state _ _), hostCtrl_eq,
      if_pos rfl, FinTM.controlAction_apply, moveInputPos_zero, Cfg.ofWords_def, Cfg.ofWords_def]
  have hbranch (x : List Bool) (b : Bool) (w : List Bool) (hw : w[0]? = some b) :
      H.tm.step (Cfg.ofWords (input := x) (.inl 1) (stateWord (K + 1) w)) =
        Cfg.ofWords (ModuleHost.entry M (if b then 4 else 3)) (stateWord (K + 1) w) := by
    have hread : (Cfg.ofWords (input := x) (.inl 1 : ModuleHost.State (Fin 3) M)
        (stateWord (K + 1) w)).workTapeSymbols 0 = some b := by
      simp only [Cfg.workTapeSymbols_eq, Cfg.ofWords_workTapes, Cfg.ofWords_workTapePos,
        stateWord_eq, FinTM.bufferTape_eq]
      simpa using hw
    rw [ModuleHost.hostTMView_step_inl _ _ _ _ _ _ _ 1 (Cfg.ofWords_state _ _), hostCtrl_eq,
      if_neg (by decide), if_pos rfl, hread, FinTM.controlAction_apply, moveInputPos_zero,
      Cfg.ofWords_def, Cfg.ofWords_def]
    cases b <;> rfl
  have hhalt (x w o : List Bool) :
      H.tm.step {Cfg.ofWords (input := x) (.inl 2) (stateWord (K + 1) w) with output := o} =
        {Cfg.ofWords (input := x) (.inl 2 : ModuleHost.State (Fin 3) M) (stateWord (K + 1) w)
          with state := none, output := o} := by
    rw [ModuleHost.hostTMView_step_inl _ _ _ _ _ _
      {Cfg.ofWords (input := x) (.inl 2) (stateWord (K + 1) w) with output := o} 2
      (Cfg.ofWords_state _ _), hostCtrl_eq, if_neg (by decide), if_neg (by decide),
      FinTM.controlAction_apply, moveInputPos_zero]
  let D := dS + dV + dI + dE + dF + 1
  let A := aS + aV + aI + aE + aF + 5
  let pow (n : ℕ) := (2 * n + 2 + P.eval n + 5) ^ D
  let T (n : ℕ) := A * pow n
  have hpow (n : ℕ) : n + 1 ≤ pow n := by
    have h := Nat.pow_le_pow_right (show 0 < 2 * n + 2 + P.eval n + 5 by omega)
      (show 1 ≤ D by dsimp [D]; omega)
    simp only [Nat.pow_one] at h
    exact (by omega : n + 1 ≤ 2 * n + 2 + P.eval n + 5).trans h
  -- Startup copies the input and installs the chosen initial state.
  have hstart : ∀ x : List Bool, ∃ t ≤ T x.length,
      (∀ v < t, (H.tm.runFrom (H.tm.initCfg x) v).state ≠ some anchor) ∧
      H.tm.runFrom (H.tm.initCfg x) t =
        Cfg.ofWords anchor (stateWord H.k (pairEncode x (init x))) := by
    intro x
    obtain ⟨hcg, hce⟩ := copy_clean_view x
    obtain ⟨hcGuard, hcEnd⟩ := ModuleHost.host_call_view M (K + 1) hk (hostCtrl M K) (hostRet M)
      (ModuleHost.entry M 0) 0 Nat.one_pos x [] x [] [] (0 : Fin 2) (2 * x.length + 2) hcg
      (hce.trans (Cfg.ext rfl rfl rfl rfl (Cfg.ofWords_output _ _)))
    have hi : H.tm.initCfg x = Cfg.ofWords (ModuleHost.entry M 0) (stateWord (K + 1) []) := by
      rw [initCfg_ofWords, ModuleHost.hostTMView_q₀]
      congr 1
      funext i
      rw [stateWord_eq, ite_self]
    simp only [List.nil_append, hseam] at hcGuard hcEnd
    rw [hostRet_zero] at hcEnd
    obtain ⟨ts, hspos, hst, hsGuard, hsEnd⟩ := hclean 1
      (fun x => pairEncode x (init x)) (fun _ => []) (fun n => aS * (n + 1) ^ dS)
      (by simpa [M] using hS) x x []
    simp only [List.nil_append, hseam] at hsGuard hsEnd
    rw [hostRet_one] at hsEnd
    have hsB := ModuleHost.request_budget aS dS D (2 * x.length + 2 + P.eval x.length + 5) x.length
      (by dsimp [D]; omega) (by omega)
    have hp := hpow x.length
    refine ⟨2 * x.length + 2 + ts, ?_, ?_, ?_⟩
    · dsimp only [T, A, pow]
      simp only [Nat.add_mul]
      dsimp only [pow] at hp
      omega
    · rw [hi]
      exact ModuleHost.guard_add H.tm anchor _ _ _ ts (fun v hv => hcGuard v hv 0) hcEnd
        (fun v hv => hsGuard v hv 0)
    · rw [hi, MultiTapeTM.runFrom_add, hcEnd, hsEnd]
      rfl
  -- A positive round either emits its payload or advances the guarded state.
  have hround : ∀ x w : List Bool, Inv P x w → ∃ t, 0 < t ∧ t ≤ T x.length ∧
      (∀ t', 0 < t' → t' < t →
        (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord H.k w)) t').state
          ≠ some anchor) ∧
      if acc (pairSndD w) then
        (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord H.k w)) t).state = none ∧
        (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord H.k w)) t).output =
          out (pairSndD w)
      else
        H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord H.k w)) t =
          Cfg.ofWords anchor (stateWord H.k (step g P x w)) := by
    intro x w hw
    obtain ⟨s, rfl, hs⟩ := hw
    have hwlen : (pairEncode x s).length ≤ 2 * x.length + 2 + P.eval x.length := by
      rw [length_pairEncode]; omega
    have hw'len : (verdictWord acc (pairEncode x s)).length =
        (pairEncode x s).length + 4 := verdictWord_length acc _
    have hpow' := hpow x.length
    -- the dispatch, the verdict call, the branch
    have hdisp := hdisp x (pairEncode x s)
    obtain ⟨tv, hvpos, hvt, hvGuard, hvEnd⟩ := hclean 2 (verdictWord acc)
      (fun _ => []) (fun n => aV * (n + 1) ^ dV) (by simpa [M] using hV) x (pairEncode x s) []
    simp only [List.nil_append, hseam] at hvGuard hvEnd
    rw [hostRet_two] at hvEnd
    have hbr := hbranch x (acc s) (verdictWord acc (pairEncode x s))
      (by rw [verdictWord_head, pairSndD_pairEncode])
    have hvB := ModuleHost.request_budget aV dV D (2 * x.length + 2 + P.eval x.length + 5)
      (pairEncode x s).length (by dsimp [D]; omega) (by omega)
    have hseg : H.tm.runFrom (Cfg.ofWords (input := x) (ModuleHost.entry M 2)
        (stateWord (K + 1) (pairEncode x s))) (tv + 1) =
        Cfg.ofWords (ModuleHost.entry M (if acc s then 4 else 3))
          (stateWord (K + 1) (verdictWord acc (pairEncode x s))) := by
      rw [MultiTapeTM.runFrom_succ_eq_step', hvEnd, hbr]
    have hsegGuard : ∀ v < tv + 1, (H.tm.runFrom (Cfg.ofWords (input := x) (ModuleHost.entry M 2)
        (stateWord (K + 1) (pairEncode x s))) v).state ≠ some anchor := by
      refine ModuleHost.guard_add H.tm anchor _ _ tv 1 (fun v hv => hvGuard v hv 0) hvEnd ?_
      intro v hv
      have hv0 : v = 0 := by omega
      subst hv0
      simp [Cfg.ofWords_def, anchor]
    by_cases hb : acc s = true
    · -- accepting round: the payload call, then the halt
      rw [if_pos hb] at hseg
      obtain ⟨te, hepos, het, heGuard, heEnd⟩ := hclean 4 id (outWord out)
        (fun n => aE * (n + 1) ^ dE) (by simpa [M] using hE) x
        (verdictWord acc (pairEncode x s)) []
      simp only [List.nil_append, hseam] at heGuard heEnd
      rw [hostRet_four, outWord_verdictWord] at heEnd
      have hhalt := hhalt x (verdictWord acc (pairEncode x s)) (out s)
      have heB := ModuleHost.request_budget aE dE D (2 * x.length + 2 + P.eval x.length + 5)
        (verdictWord acc (pairEncode x s)).length (by dsimp [D]; omega) (by omega)
      have hall : H.tm.runFrom (Cfg.ofWords (input := x) (ModuleHost.entry M 2)
          (stateWord (K + 1) (pairEncode x s))) (tv + 1 + te + 1) =
          {Cfg.ofWords (input := x) (.inl 2 : ModuleHost.State (Fin 3) M) (stateWord (K + 1)
            (verdictWord acc (pairEncode x s))) with state := none, output := out s} := by
        rw [MultiTapeTM.runFrom_succ_eq_step', MultiTapeTM.runFrom_add, hseg, heEnd, hhalt]
      have hallGuard : ∀ v < tv + 1 + te + 1, (H.tm.runFrom (Cfg.ofWords (input := x)
          (ModuleHost.entry M 2) (stateWord (K + 1) (pairEncode x s))) v).state ≠ some anchor := by
        refine ModuleHost.guard_add H.tm anchor _ {Cfg.ofWords (input := x)
          (.inl 2 : ModuleHost.State (Fin 3) M)
          (stateWord (K + 1) (verdictWord acc (pairEncode x s))) with output := out s}
          (tv + 1 + te) 1 ?_ ?_ ?_
        · exact ModuleHost.guard_add H.tm anchor _ _ (tv + 1) te hsegGuard hseg
            (fun v hv => heGuard v hv 0)
        · rw [MultiTapeTM.runFrom_add, hseg, heEnd]
        · intro v hv
          have hv0 : v = 0 := by omega
          subst hv0
          simp [Cfg.ofWords_def, anchor]
      refine ⟨tv + 1 + te + 1 + 1, by omega, ?_, ?_, ?_⟩
      · dsimp only [T, A, pow]
        simp only [Nat.add_mul]
        dsimp only [pow] at hpow'
        omega
      · intro v hv hvt
        have hvform : v = (v - 1) + 1 := by omega
        change (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord (K + 1)
          (pairEncode x s))) v).state ≠ some anchor
        rw [hvform, MultiTapeTM.runFrom_succ_eq_step, hdisp]
        exact hallGuard (v - 1) (by omega)
      · rw [pairSndD_pairEncode, if_pos hb]
        change (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord (K + 1)
            (pairEncode x s))) (tv + 1 + te + 1 + 1)).state = none ∧
          (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord (K + 1)
            (pairEncode x s))) (tv + 1 + te + 1 + 1)).output = out s
        rw [MultiTapeTM.runFrom_succ_eq_step, hdisp, hall]
        exact ⟨rfl, rfl⟩
    · -- advancing round: the step call returns to the anchor
      rw [if_neg hb] at hseg
      obtain ⟨ti, hipos, hit, hiGuard, hiEnd⟩ := hclean 3 (stepWord g P)
        (fun _ => []) (fun n => aI * (n + 1) ^ dI) (by simpa [M] using hI) x
        (verdictWord acc (pairEncode x s)) []
      simp only [List.nil_append, hseam] at hiGuard hiEnd
      rw [hostRet_three, stepWord_verdictWord] at hiEnd
      have hiB := ModuleHost.request_budget aI dI D (2 * x.length + 2 + P.eval x.length + 5)
        (verdictWord acc (pairEncode x s)).length (by dsimp [D]; omega) (by omega)
      have hall : H.tm.runFrom (Cfg.ofWords (input := x) (ModuleHost.entry M 2)
          (stateWord (K + 1) (pairEncode x s))) (tv + 1 + ti) =
          Cfg.ofWords anchor (stateWord (K + 1) (step g P x (pairEncode x s))) := by
        rw [MultiTapeTM.runFrom_add, hseg, hiEnd]
      have hallGuard : ∀ v < tv + 1 + ti, (H.tm.runFrom (Cfg.ofWords (input := x)
          (ModuleHost.entry M 2) (stateWord (K + 1) (pairEncode x s))) v).state ≠ some anchor :=
        ModuleHost.guard_add H.tm anchor _ _ (tv + 1) ti hsegGuard hseg
          (fun v hv => hiGuard v hv 0)
      refine ⟨tv + 1 + ti + 1, by omega, ?_, ?_, ?_⟩
      · dsimp only [T, A, pow]
        simp only [Nat.add_mul]
        dsimp only [pow] at hpow'
        omega
      · intro v hv hvt
        have hvform : v = (v - 1) + 1 := by omega
        change (H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord (K + 1)
          (pairEncode x s))) v).state ≠ some anchor
        rw [hvform, MultiTapeTM.runFrom_succ_eq_step, hdisp]
        exact hallGuard (v - 1) (by omega)
      · rw [pairSndD_pairEncode, if_neg hb]
        change H.tm.runFrom (Cfg.ofWords (input := x) anchor (stateWord (K + 1)
            (pairEncode x s))) (tv + 1 + ti + 1) =
          Cfg.ofWords anchor (stateWord (K + 1) (step g P x (pairEncode x s)))
        rw [MultiTapeTM.runFrom_succ_eq_step, hdisp, hall]
  -- Pay for binary fuel in the same polynomial budget, then apply the host.
  have hFuel : F.ComputesFunInTime (fun x => Nat.bits (R x.length)) T := by
    apply (FinTM.computesFunInTime_iff _ _ _).2
    intro x
    apply ((FinTM.computesFunInTime_iff _ _ _).1 hF x).mono
    have h := ModuleHost.request_budget aF dF D (2 * x.length + 2 + P.eval x.length + 5) x.length
      (by dsimp [D]; omega) (by omega)
    have hp := hpow x.length
    dsimp only [T, A, pow]
    simp only [Nat.add_mul]
    dsimp only [pow] at hp
    omega
  obtain ⟨L, c, hL⟩ := FinTM.exists_loopFindTM H F anchor (Inv P) (step g P)
    (fun _ w => acc (pairSndD w)) (fun _ w => out (pairSndD w)) (fun x => pairEncode x (init x))
    R T hFuel (fun x => ⟨init x, rfl, hbound x⟩)
    (fun x w h => inv_step g P x w h) hstart hround
  refine ⟨L, c, A, D, (FinTM.computesFunInTime_iff _ _ _).mpr fun x => ?_⟩
  have hx := (FinTM.computesFunInTime_iff _ _ _).mp hL x
  simp only [T, pow] at hx
  -- The combinator states its result with its own `match`; read both by cases on the search.
  revert hx
  cases (List.range (R x.length + 1)).find?
    (fun i => acc (pairSndD ((step g P x)^[i] (pairEncode x (init x))))) <;> exact id
