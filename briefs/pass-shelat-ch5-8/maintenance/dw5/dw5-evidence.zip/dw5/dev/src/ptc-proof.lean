  have hbits : PolyTimeComputable fun x => Nat.bits (R.eval x.length) := by
    have h := (polyTimeComputable_of_linear FinTM.computesFunInTime_lengthBits).comp
      (polyTimeComputable_unaryPoly R)
    convert h using 1
    funext x
    simp
  obtain ⟨F, aF, dF, hF⟩ := (polyTimeComputable_iff _).1 hbits
  obtain ⟨L, c, A, D, hL⟩ := computesFunInTime_find hg hacc hout polyTimeComputable_id
    (fun n => R.eval n) P (fun x => by simpa using horbit x 0 (Nat.zero_le _)) F aF dF hF
  obtain ⟨CP, cP, hCP⟩ := P.eval_le
  obtain ⟨CR, cR, hCR⟩ := R.eval_le
  refine (polyTimeComputable_iff _).2 ⟨L, c * (A * (CP + 7) ^ D + 1) * (CR + 2),
    (cP + 1) * D + cR, (FinTM.computesFunInTime_iff _ _ _).2 fun x => ?_⟩
  exact ((FinTM.computesFunInTime_iff _ _ _).1 hL x).mono
    (final_bound c A D CP cP CR cR x.length (P.eval x.length) (R.eval x.length) (hCP _) (hCR _))
