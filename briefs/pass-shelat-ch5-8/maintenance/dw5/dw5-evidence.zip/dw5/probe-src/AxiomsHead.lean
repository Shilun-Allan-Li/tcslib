import Lean
import TCSlib.Complexity.TuringMachine.Build.ModuleHost
import TCSlib.Complexity.Randomized.Build.IterateFindHost
import TCSlib.Complexity.Randomized.Build.IterateFind
import TCSlib.Complexity.ClassP.DTIME
import TCSlib.Complexity.Randomized.Classes
import TCSlib.Complexity.Randomized.SeedMajority
import TCSlib.Complexity.Randomized.SeedMajority.Enumeration
import TCSlib.Complexity.Randomized.SeedMajority.Envelope
import TCSlib.Complexity.Randomized.SeedMajority.State
import TCSlib.Complexity.Randomized.SeedMajority.Words
import TCSlib.Cryptography.Randomness.Derandomization
import TCSlib.Cryptography.Randomness.Derandomization.AdviceGap
import TCSlib.Cryptography.Randomness.Derandomization.CoinGap
import TCSlib.Cryptography.Randomness.Derandomization.Expanded
import TCSlib.Cryptography.Randomness.Derandomization.Majority
import TCSlib.Cryptography.Randomness.Derandomization.RootSchedule
import TCSlib.Cryptography.Randomness.Derandomization.TimeBound
import TCSlib.Complexity.Randomized.Repetition

/-! DW-5 axioms probe (head): the derand review's census probe (CensusHead.lean) with the readers and the two
re-derived theorems added to its `#print axioms` list and its owner census narrowed to the three DW-5 owners. -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms Complexity.exists_seedMajorityTM
#print axioms Complexity.seedMajority_mem_DTIME
#print axioms TCSlib.Cryptography.Randomness.bpp_subset_dtime_subexp
#print axioms Complexity.IterateFind.polyTimeComputable_find
#print axioms Complexity.polyTimeComputable_iterateFind
#print axioms Complexity.IterateFind.computesFunInTime_find
#print axioms Turing.FinTM.decidesInTime_iff
#print axioms Complexity.mem_DTIME_iff
#print axioms Randomized.inBPP_iff
#print axioms Complexity.SeedMajority.exists_countingTM
#print axioms Complexity.SeedMajority.envelope_of_computesInTime
#print axioms TCSlib.Cryptography.Randomness.Derand.exists_seed_majority
#print axioms TCSlib.Cryptography.Randomness.Derand.exists_coin_gap_threshold
#print axioms TCSlib.Cryptography.Randomness.Derand.exists_verifier_gap_bound
#print axioms TCSlib.Cryptography.Randomness.Derand.exists_secure_cover
#print axioms TCSlib.Cryptography.Randomness.Derand.seed_time_le_subexp
#print axioms TCSlib.Cryptography.Randomness.Derand.polyTimeComputable_ceilRoot
#print axioms TCSlib.Cryptography.Randomness.Derand.eff_mapCoins

#print axioms Turing.ModuleHost.hostTMView
#print axioms Turing.ModuleHost.hostTMView_eq
#print axioms Turing.ModuleHost.hostTMView_q₀
#print axioms Turing.ModuleHost.hostTMView_step_inl
#print axioms Turing.ModuleHost.host_call_view
#print axioms Turing.ModuleHost.host_clean_view
#print axioms Complexity.IterateFind.copyTMView
#print axioms Complexity.IterateFind.copyTMView_eq
#print axioms Complexity.IterateFind.copy_clean_view

def owners : List Name := [`TCSlib.Complexity.TuringMachine.Build.ModuleHost,
  `TCSlib.Complexity.Randomized.Build.IterateFindHost,
  `TCSlib.Complexity.Randomized.Build.IterateFind]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

