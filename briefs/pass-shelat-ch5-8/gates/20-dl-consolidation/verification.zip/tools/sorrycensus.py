"""sorrycensus.py <issued base-sorries.txt> <results.jsonl> <repo> <issue-base> <head> <out>:
per-module `declaration uses 'sorry'` warnings of the head build (latest record per module) against the
issued base admissions (module -> count). Modules outside the issued list: reported with their count and
whether their source changed between the issue base and the head."""
import sys, json, re, subprocess
iss_p, res_p, repo, base, head, out = sys.argv[1:7]
iss = {}
for l in open(iss_p):
    m = re.match(r'^(\S+): (\d+): (.*)$', l.strip())
    if m:
        k = m.group(1); k = k if k.startswith('TCSlib/') else 'TCSlib/Complexity/' + k
        iss[k] = (int(m.group(2)), m.group(3))
b = {}
for l in open(res_p):
    x = json.loads(l)
    if 'module' in x: b[x['module']] = x
ch = set(subprocess.run(['git', '-C', repo, 'diff', '--name-only', base, head], capture_output=True, text=True).stdout.split())
f = open(out, 'w'); ti = tb = 0; outside = 0; diffs = []
for k in sorted(set(iss) | {m for m, x in b.items() if x['sorry']}):
    a = iss.get(k, (0, ''))[0]; c = b[k]['sorry'] if k in b else None
    tag = 'OK  ' if a == c else 'DIFF'
    inl = k in iss
    if inl: ti += a
    tb += c or 0
    if not inl: outside += c or 0
    if a != c and inl: diffs.append(k)
    f.write(f"{tag} {k}: issued-base {a if inl else '-'} head-build {c}" + ('' if inl else f"  (outside issued order; source changed since issue base: {k + '.lean' in ch})") + '\n')
f.write(f"TOTAL issued-base {ti} in {len(iss)} modules; head-build {tb} warnings ({tb - outside} in issued modules, {outside} outside); modules differing {diffs}\n")
f.close(); print(open(out).read().splitlines()[-1])
