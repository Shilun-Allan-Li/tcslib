"""le_review.py <worktree>: landing edit LE-review (docstrings and widths only; no code change)."""
import sys, re
W = sys.argv[1] + '/TCSlib/Cryptography/'
def sub(path, old, new):
    p = W + path; s = open(p, encoding='utf-8').read()
    assert s.count(old) == 1, (path, old); open(p, 'w', encoding='utf-8').write(s.replace(old, new))
E = 'Games/Efficiency.lean'
for nm, txt, body in [('rU', 'The parameter `1^n` of a round input', 'pairFstD (pairFstD w)'),
                      ('rZ', 'The reduction input `z` of a round input', 'pairFstD (pairSndD (pairFstD w))'),
                      ('rW', 'The seed `ω` of a round input', 'pairSndD (pairSndD (pairFstD w))'),
                      ('rS', 'The state `s` of a round input', 'pairFstD (pairSndD w)'),
                      ('rI', 'The oracle index `1^i` of a round input', 'pairFstD (pairFstD (pairSndD (pairSndD w)))'),
                      ('rX', 'The query `x` of a round input', 'pairSndD (pairFstD (pairSndD (pairSndD w)))'),
                      ('rL', 'The outer log `L` of a round input', 'pairSndD (pairSndD (pairSndD w))')]:
    sub(E, f'/-- {txt}. -/\ndef {nm} (w : List Bool) : List Bool := {body}\n',
        f'/-- {txt}: `{nm} w = {body}`. -/\ndef {nm} (w : List Bool) : List Bool := {body}\n')
sub(E, '/-- The first component `pairFstD s` of the state of a round input. -/\n',
    '/-- The first component `pairFstD s` of the state of a round input: `rCnt w = pairFstD (rS w)`. -/\n')
for nm in ['rU', 'rZ', 'rW', 'rS', 'rI', 'rX', 'rL', 'rCnt']:
    sub(E, f'/-- `{nm}` is polynomial-time. -/\n', f'/-- `{nm}` is polynomial-time: `PolyTimeComputable {nm}`. -/\n')
sub('Foundations/BitLists.lean', '/-- Exclusive-or with a fixed vector `v`, as a permutation of `{0,1}ⁿ`. -/\n',
    '/-- Exclusive-or with a fixed vector `v`, as a permutation of `{0,1}ⁿ`: `xorPerm v y = y ⊕ v`. -/\n')
sub('Games/Hopping.lean', 'state `s` a computation making at most `m` queries ends in a bad state with probability at most\n`m · (sz s + m) · δ`.\n',
    'state `s` a computation making at most `m` queries ends in a bad state with probability at most\n`m · (sz s + m) · δ`: `Pr[bad (simulate impl c s).2] ≤ m · (sz s + m) · δ`.\n')
sub('Games/Hopping.lean', 'probability at most `|L| / |T|` (`prob_mem_le` for a fixed list). -/',
    'probability at most `|L| / |T|`: `𝔼_{t ← T} [t ∈ L] ≤ |L| / |T|` (`prob_mem_le` for a fixed list). -/')
# widths (docstring lines over 100 characters introduced by the delivery)
sub('Encryption/PrivateKey/OracleFromPRF/Collision.lean',
    '  table (`lazyImpl_grow`). A potential argument sums these over `q` queries (`ProbComp.prob_bad_le`).\n',
    '  table (`lazyImpl_grow`). A potential argument sums these over `q` queries\n  (`ProbComp.prob_bad_le`).\n')
sub('Encryption/PublicKey/AdaptiveCPA/Hybrid.lean',
    '`ProbComp.expect_sample_coord` replaces `T j` by fresh coins; then apply the induction hypothesis. -/',
    '`ProbComp.expect_sample_coord` replaces `T j` by fresh coins; then apply the induction\nhypothesis. -/')
sub('Encryption/PublicKey/ElGamal.lean',
    '(`egSquareGen_valid`). The padding of the tuple is lossless (`ofFn_padFin_of_length`, `length_ddhTuple`),\nso `D_b`',
    '(`egSquareGen_valid`). The padding of the tuple is lossless (`ofFn_padFin_of_length`,\n`length_ddhTuple`), so `D_b`')
print('ok')
