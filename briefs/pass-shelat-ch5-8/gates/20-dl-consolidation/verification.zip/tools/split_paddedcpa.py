"""split_paddedcpa.py <worktree>: LE-split. Moves the block from '/-! ### From ensemble security to CPA -/'
through 'end PaddedCPA' of PublicKey/OracleSecurity.lean verbatim into the new module
PublicKey/OracleSecurity/PaddedCPA.lean (no renames, no statement changes), and moves the
ChallengeSim/RecordHandler imports with it."""
import sys, os
wt = sys.argv[1]
base = os.path.join(wt, 'TCSlib/Cryptography/Encryption/PublicKey')
P = os.path.join(base, 'OracleSecurity.lean')
N = os.path.join(base, 'OracleSecurity/PaddedCPA.lean')
L = open(P, encoding='utf-8').read().split('\n')
a = L.index('/-! ### From ensemble security to CPA -/')
b = L.index('end PaddedCPA')
assert L[a + 2] == 'section PaddedCPA' and L[b + 1] == '' and L[b + 2] == 'end TCSlib.Cryptography.Composability'
block = L[a:b + 1]
rest = L[:a] + L[b + 2:]
imps = ['import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.ChallengeSim',
        'import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.RecordHandler']
for i in imps:
    assert rest.count(i) == 1
    rest.remove(i)
open(P, 'w', encoding='utf-8').write('\n'.join(rest))
header = '''/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.ChallengeSim
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.RecordHandler

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Single-bit security gives CPA security of the padded scheme

The claim after [PS10, Definition 171.5]: a single-bit secure public-key scheme, padded to fixed
length (`BitPublicKeyScheme.padded`, `Encryption.PublicKey.OracleSecurity`), is CPA-secure in the
oracle game `FixedLengthPKScheme.indGame`.

Under CPA the adversary's view is `pk`, its coins and the padded challenge. Only the first
challenge query uses coins, so the encryption coins may be sampled in advance
(`expect_simulate_indImpl_cpa`). The distinguisher answers every challenge with its own padded
ciphertext and outputs the adversary's bit, corrected by the first challenge pair; it is T1's
machine for the recording handler (`OracleSecurity.RecordHandler`). The two advantages are equal
at every `n` (`padded_cpa_advantage_eq`). The deterministic run and first-challenge congruence
are `OracleSecurity.ChallengeSim`'s.

## Main results

* `expect_simulate_indImpl_cpa`: eager challenge coins under CPA.
* `BitPublicKeyScheme.SingleBitSecure.padded_cpa`: single-bit security gives CPA security of
  the padded scheme.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §7.1.4, Definition 171.5 and the claim after it (book pp. 171–172).
-/

namespace TCSlib.Cryptography.Composability

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games
'''
open(N, 'w', encoding='utf-8').write(header + '\n' + '\n'.join(block) + '\n\nend TCSlib.Cryptography.Composability\n')
print('moved lines', a + 1, '..', b + 1, '(', len(block), 'lines )')
