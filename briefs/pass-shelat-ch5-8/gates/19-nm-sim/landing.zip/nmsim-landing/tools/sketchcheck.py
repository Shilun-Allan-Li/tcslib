"""sketchcheck.py <worktree> <file>...: for every theorem/lemma (private included), its proof length (non-blank
lines after the line ending the statement with `:=`/`:= by`, up to the next top-level item) and whether its docstring has
`**Proof sketch` (with or without a period); prints NOSKETCH rows for proofs of more than 20 lines, and LABELONLY rows for
docstrings saying "described above"."""
import re, sys
wt = sys.argv[1]
TOP = re.compile(r'^(/--|/-!|@\[|(private |protected |noncomputable )*(theorem|lemma|def|abbrev|instance|structure|'
                 r'inductive|class)\b|end\b|section\b|namespace\b|variable\b|open\b|set_option\b|#)')
DECL = re.compile(r'^(@\[[^\]]*\]\s*)?((?:private|protected)\s+)?(theorem|lemma)\s+(\S+)')
n_bad = 0
for f in sys.argv[2:]:
    lines = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    for i, l in enumerate(lines):
        m = DECL.match(l)
        if not m: continue
        j = i + 1
        while j < len(lines) and not TOP.match(lines[j]): j += 1
        body = next((t for t in range(i, j) if re.search(r':=\s*(by)?\s*$', lines[t]) or ':= by' in lines[t]), i)
        length = len([x for x in lines[body + 1:j] if x.strip()])  # proof-body lines after `:=`/`:= by`
        k = i - 1; doc = []
        if k >= 0 and lines[k].rstrip().endswith('-/'):
            while k >= 0:
                doc.insert(0, lines[k])
                if lines[k].lstrip().startswith('/--'): break
                k -= 1
        d = '\n'.join(doc)
        if 'described above' in d: print('LABELONLY', f, i + 1, m.group(4)); n_bad += 1
        if length > 20 and '**Proof sketch' not in d:
            print('NOSKETCH', f'{f}:{i+1}', m.group(4), length, 'private' if m.group(2) else 'public'); n_bad += 1
print('TOTAL_FLAGGED', n_bad)
