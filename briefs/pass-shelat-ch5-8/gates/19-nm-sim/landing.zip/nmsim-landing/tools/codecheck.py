"""codecheck.py <dirA> <dirB> <relpath>...: per file, the text with all /- ... -/ comments (incl.
docstrings, nested) and -- line comments removed, whitespace-tokenized, must be identical."""
import sys, re
a, b = sys.argv[1], sys.argv[2]
def strip(s):
    out, i, depth = [], 0, 0
    while i < len(s):
        if s.startswith('/-', i): depth += 1; i += 2; continue
        if depth and s.startswith('-/', i): depth -= 1; i += 2; continue
        if depth: i += 1; continue
        if s.startswith('--', i):
            j = s.find('\n', i); i = len(s) if j < 0 else j; continue
        out.append(s[i]); i += 1
    return ''.join(out).split()
bad = 0
for r in sys.argv[3:]:
    x = strip(open(f'{a}/{r}', encoding='utf-8').read()); y = strip(open(f'{b}/{r}', encoding='utf-8').read())
    ok = x == y; bad += not ok
    print('SAME' if ok else 'DIFF', len(x), r)
print('ALL_CODE_TOKENS_EQUAL' if not bad else f'{bad} FILES DIFFER'); sys.exit(1 if bad else 0)
