"""doc_edits.py <worktree>: LE-D1/D2/D3 docstring-only edits of the nm-sim landing.
Each edit replaces an exact text that must occur exactly once; only comment text changes."""
import sys
from pathlib import Path

wt = Path(sys.argv[1])
D = wt / 'TCSlib/Cryptography/Encryption/PublicKey/NonMalleability/Simulation'

EDITS = {
    # ---------- LE-D1: formula docstrings ----------
    'Challenge.lean': [
        ("/-- `chalRun P w` is the round described above. -/\n",
         "/-- `chalRun P w` is `⟨[true], 0^{msgLen+1} ‖ s⟩` if `i = 0`; else\n"
         "`⟨[true], (s.drop 1).take (ctLen + hl) ‖ s⟩` if the flag is set; else\n"
         "`⟨[false], ⟨1^j, qry w⟩⟩` if the outer log is empty; else\n"
         "`⟨[true], Y ‖ H ‖ (true :: Y ‖ H ‖ padL pl x)⟩`, with `Y = ansY w` and `H = ansH w`. -/\n"),
        # LE-D2
        ("answers `⟨Y, H⟩ = ⟨ansY w₁, ansH w₁⟩` (`w₁` the round input with `y` in the log), recording\n"
         "`⟨Y, H, x⟩`. -/\n",
         "answers `⟨Y, H⟩ = ⟨ansY w₁, ansH w₁⟩` (`w₁` the round input with `y` in the log), recording\n"
         "`⟨Y, H, x⟩`.\n"
         "\n"
         "**Proof sketch.** `impl_of_query` with the answer `ansY w₁ ‖ ansH w₁` and the encoded state\n"
         "`chalState (some ⟨Y, H, x⟩)` (lengths by `ansY_len`, `ansH_len`; `perCall = 1`). The first\n"
         "round, on `w₀` (a challenge, flag unset, empty log), is the query branch of `chalRun_eq`; the\n"
         "second, on `w₁`, is its answer branch, with `x` read back through `padL`\n"
         "(`ofFn_chalState_some`, `ofFn_padFin_of_length`). -/\n"),
    ],
    'Simulator.lean': [
        ("/-- `simFin S r w` is the round described above. -/\n",
         "/-- `simFin S r w = ⟨[true], F ‖ a.drop (r·ctLen)⟩`, with `F = flag^r` if `ctLen(n) = 0` and\n"
         "`F = chunkMap ctLen flagF ⟨⟨1^n, s⟩, a.take (r·ctLen)⟩` otherwise. -/\n"),
        ("/-- **The finalization round on a finalization input** (for `A`'s output of `r·ctLen + sl` bits)\n"
         "returns `⟨[true], simOutL …⟩`. -/\n",
         "/-- **The finalization round on a finalization input** (for `A`'s output of `r·ctLen + sl` bits)\n"
         "returns `⟨[true], simOutL …⟩`.\n"
         "\n"
         "**Proof sketch.** Read the fields of the input in `simFin_eq` and split on `ctLen(n)`. If\n"
         "`ctLen(n) = 0`, every chunk is empty and equals `ỹ`, so every flagged entry is `[flag]` and the\n"
         "`r` entries flatten to `flag^r`. Otherwise cut `a.take (r·ctLen)` into its `r` chunks of\n"
         "`ctLen(n)` bits (`take_eq_flatten_chunkAt`, `length_chunkAt`); `chunkMap_flatten` maps\n"
         "`flagF` over them, which is `simOutL_eq`. -/\n"),
    ],
    'Reduction.lean': [
        ("/-- `nmFin S samp hl r w` is the round described above. -/\n",
         "/-- `nmFin S samp hl r w = ⟨[true], E ‖ B⟩`, with `E = chunkMap ctLen encF ⟨ctx, a.take (r·ctLen)⟩`\n"
         "and `B = chunkMap 1 bitF ⟨ctx, aP ‖ M(aP; ρ) ‖ a.drop (r·ctLen)⟩`, where\n"
         "`ctx = ⟨1^n, ⟨z, ⟨ω, s⟩⟩⟩`, `aP = s.drop (1 + ctLen + hl)`, `ρ = ω.take coins` and\n"
         "`M(aP; ρ) = padL msgLen (M.output (layout 1^n aP (snd z) ρ))`. -/\n"),
        ("/-- The finalization round is polynomial-time. -/\n"
         "theorem polyTimeComputable_nmFin",
         "/-- The finalization round is polynomial-time.\n"
         "\n"
         "**Proof sketch.** From the polynomial-time field readers (`polyTimeComputable_finFields`,\n"
         "`polyTimeComputable_finSt`): the context by `pairEncode`; the cuts of `a` at `r·ctLen`, the\n"
         "parameter `aP` and the coins `ρ` by `pairTakePoly`/`pairDropPoly`; the message by\n"
         "`polyTimeComputable_padL` of `M`'s output on `layout`. The two chunk maps are\n"
         "`polyTimeComputable_chunkMap` of `encF` and `bitF`, joined by `append` and `pairEncode`. -/\n"
         "theorem polyTimeComputable_nmFin"),
        ("/-- **The finalization round on a finalization input** (for `A`'s output of `r·ctLen + sl` bits, and\n"
         "`ctLen(n) > 0`) returns `⟨[true], nmOutL …⟩`. -/\n",
         "/-- **The finalization round on a finalization input** (for `A`'s output of `r·ctLen + sl` bits, and\n"
         "`ctLen(n) > 0`) returns `⟨[true], nmOutL …⟩`.\n"
         "\n"
         "**Proof sketch.** Read the fields of the input in `nmFin_eq` (`fields_finInput`,\n"
         "`finSt_finInput`). Cut `a.take (r·ctLen)` into its `r` chunks of `ctLen(n) > 0` bits\n"
         "(`take_eq_flatten_chunkAt`, `length_chunkAt`), so the first chunk map is `encF` over them\n"
         "(`chunkMap_flatten`). Write `aP ‖ M(aP; ρ) ‖ σ` as the flatten of its singletons, so the second,\n"
         "with chunk length `1`, is `bitF` over its bits; both match `nmOutL_eq`. -/\n"),
    ],
    # ---------- LE-D2: proof sketches ----------
    'Generic.lean': [
        ("(`Complexity.polyTimeComputable_iterateEmit` with the step `chunkStep`, which never lengthens a\n"
         "word, and `|x|` rounds). -/\n",
         "(`Complexity.polyTimeComputable_iterateEmit` with the step `chunkStep`, which never lengthens a\n"
         "word, and `|x|` rounds).\n"
         "\n"
         "**Proof sketch.** The step (keep `ctx`, drop `c(n)` bits) and the emission (`[]` on an empty\n"
         "rest, else `f ctx` of the next `c(n)` bits) are polynomial-time by the pair readers,\n"
         "`pairTakePoly`/`pairDropPoly` and `polyTimeComputable_ite`. The iterates stay within `|x| + 2`\n"
         "bits (`length_iterate_chunkStep_le`), so `polyTimeComputable_iterateEmit` gives `chunkMap_eq`. -/\n"),
    ],
    'Recover.lean': [
        ("/-- The reading of the view is polynomial-time, as a function of `⟨U, u⟩`. -/\n",
         "/-- The reading of the view is polynomial-time, as a function of `⟨U, u⟩`.\n"
         "\n"
         "**Proof sketch.** The chunk maps `B` (of `bitG`, on the `drop` of `u` after the `r` groups) and\n"
         "`E` (of `entF`, on the matching `take`) are `polyTimeComputable_chunkMap` composed with\n"
         "`pairTakePoly`/`pairDropPoly`. The three pieces of `B` cut `⟨U, B⟩` the same way (`take pl`,\n"
         "`take msgLen` of `drop pl`, `drop (pl + msgLen)`), and `recView_eq` joins the four parts by\n"
         "`append`. -/\n"),
    ],
    'Rounds.lean': [
        ("(with `perCall ≥ 1`) the call is `query j x' (fun y => pure (padFin _ (u y), padFin _ (v y)))`. -/\n",
         "(with `perCall ≥ 1`) the call is `query j x' (fun y => pure (padFin _ (u y), padFin _ (v y)))`.\n"
         "\n"
         "**Proof sketch.** Unfold the call (`impl_apply`, `call_eq`) at the budget `perCall = p + 1`. The\n"
         "first round decodes to the query (`decodeBitMove_query`), which `buildComp_succ_of_query` asks.\n"
         "After the answer `y` the log encodes as in `hrun₁` (`bitCodec_encodeEntry`), the second round\n"
         "decodes to the return of `padFin _ (u y ‖ v y)` (`buildComp_of_ret`, `decodeBitMove_ret`), and\n"
         "`padFin_append_split` splits it into the answer and the state. -/\n"),
    ],
    'SimIND.lean': [
        ("/-- `D'`'s raw function is polynomial-time. -/\n",
         "/-- `D'`'s raw function is polynomial-time.\n"
         "\n"
         "**Proof sketch.** `a₀`, `a₁`, `m` and the entries are `take`/`drop`s of `msgLen(n)` bits of the\n"
         "view (`polyTimeComputable_takeMsg`, `polyTimeComputable_dropMsg`), the tails are\n"
         "`polyTimeComputable_entryTails`, `D`'s verdict is `D.output` on `layout`, and the equality tests\n"
         "use `polyTimeComputable_pairEq`. The outer test is `polyTimeComputable_ite`, and `[v == w]` is\n"
         "the `ite` on `v` of `[w]` and `[!w]`. -/\n"),
        ("halves, and a bad parameter stays recorded. -/\n",
         "halves, and a bad parameter stays recorded.\n"
         "\n"
         "**Proof sketch.** `expect_eq_until_bad` with the bad event `badHalves`. The empty state is good\n"
         "(its parameter reads `0`, `ofFn_zeroBits`), and a recorded state stays recorded (`rImpl_dec`,\n"
         "`rImpl_some`), so bad is sticky. From a good state the two oracles agree: `Dec` and repeated\n"
         "challenges do not read the coin (the history is empty), and on a first challenge, after the same\n"
         "encryption coins, the new state is bad on both sides or `m₀ = m₁` and the two draws coincide\n"
         "(`ofFn_drawWith_half`). -/\n"),
    ],
    'SimINDGap.lean': [
        # LE-D3
        ("So `NM`'s advantage is at most `2·adv(D') + adv(D'')`.\n"
         "\n"
         "## Main results\n",
         "So `NM`'s advantage is at most `2·adv(D') + adv(D'')`.\n"
         "\n"
         "## Main definitions\n"
         "\n"
         "* `NMSim.simHandler`: the SIM adversary's handler, `copyHandler` on the real experiment's\n"
         "  oracles with the parameter `⟨m₀, m₁⟩` and the empty history.\n"
         "\n"
         "## Main results\n"),
        # LE-D2
        ("`runB … β` (with any `ρ'`), the views read with the coin `β`. -/\n",
         "`runB … β` (with any `ρ'`), the views read with the coin `β`.\n"
         "\n"
         "**Proof sketch.** `realAcc_copyHandler` makes the experiment `A`'s run against the hybrid oracle\n"
         "whose sampler coins `ρ` also stand in its `ρ'` slot, and `expect_sample_halfCoins` splits the\n"
         "average over `ρ` into the two coins `β`. For each `β`, the oracle with `b = false` does not read\n"
         "`ρ'` (`rImpl_false_coins`), so the run is `runB … β`, after transporting the output length\n"
         "(`expect_toCompOn_outLen`). -/\n"),
    ],
}

for fname, edits in EDITS.items():
    p = D / fname
    src = p.read_text(encoding='utf-8')
    for old, new in edits:
        c = src.count(old)
        assert c == 1, (fname, c, old[:80])
        src = src.replace(old, new)
    p.write_text(src, encoding='utf-8')
    print('edited', fname, len(edits))
