"""legate30_edit.py <worktree>: #314 resolution edit LE-gate30 (Gate 30 G30-01), docstring only, one exact replacement.
EncryptThenTag/Reduction.lean, ETTGame.prfAdv_eq_expect: the overlap note is kept as provenance without the claim of a
local derivation; the rewrite-chain sketch becomes a direct specialization of TCSlib.Cryptography.prfAdv_eq_expect."""
import sys, os
wt = sys.argv[1]
def edit(rel, R):
    f = os.path.join(wt, rel); s = open(f, encoding='utf-8').read()
    for a, b in R:
        c = s.count(a); assert c == 1, (rel, c, a[:70]); s = s.replace(a, b)
    open(f, 'w', encoding='utf-8').write(s); print(rel, len(R), 'replacements')
edit('TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Reduction.lean', [
('''/-- **The PRF advantage as expectations** (PRFGame overlap: `prfAdv_prfReduction`, re-derived here
in general form from the published readers): for an oracle adversary `A'` on `m`-bit strings,
`prfAdv F A' = |𝔼_k 𝔼_c [A'(c)^{F k} = 1] − 𝔼_R 𝔼_c [A'(c)^R = 1]|`.

This is the published `TCSlib.Cryptography.prfAdv_eq_expect` at `K = I = O = {0,1}^m`.

**Proof sketch.** `prfAdv_def`, `distAdv_def`; each acceptance probability is an average over the
key (resp. the function table) and the coins (`Bridge.acceptProb_eq`, `accept_eq`,
`Bridge.acceptGame_eq`, `prob_bind`, `oracleDist_apply`, `randomFunction_apply`). -/
''', '''/-- **The PRF advantage as expectations** (PRFGame overlap: `prfAdv_prfReduction`): for an oracle
adversary `A'` on `m`-bit strings,
`prfAdv F A' = |𝔼_k 𝔼_c [A'(c)^{F k} = 1] − 𝔼_R 𝔼_c [A'(c)^R = 1]|`.

This is the published `TCSlib.Cryptography.prfAdv_eq_expect` at `K = I = O = {0,1}^m`.

**Proof sketch.** A direct specialization of `TCSlib.Cryptography.prfAdv_eq_expect` to the family
`Fm` and the adversary `A'`. -/
'''),
])
