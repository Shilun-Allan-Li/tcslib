import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity

/-! nm-cca2 review, escalation E-READER (independent check). With only
`FixedLengthPKScheme.outLens` sealed (a subset of every whole-file seal of a consumer), the cast form
of `indImpl_dec_onSpec` is attempted from the published readers by four routes (each expected to
fail: `EXPECT-FAIL`), and `indSpec_decRng` from `indSpec_rng`/`outLens_zero` (expected to pass).
The unsealed section repeats the reader's one-line proof (expected to pass). -/

set_option maxHeartbeats 400000
set_option autoImplicit false

namespace TCSlib.Cryptography.Composability.EscCheck

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games

section Sealed

attribute [local irreducible] FixedLengthPKScheme.outLens

variable (S : FixedLengthPKScheme)

theorem decRng (n : ℕ) : (S.indSpec n).rng 0 = (Fin (S.msgLen.eval n + 1) → Bool) := by
  rw [S.indSpec_rng, S.outLens_zero]

-- EXPECT-FAIL route 1: the home-file proof
example (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (c : (S.indSpec n).dom 0) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.indImpl atk b n pk sk 0 c s =
      if FixedLengthScheme.decOpen atk s.isSome && !decide (s = some (cast (S.indSpec_decDom n) c))
      then .pure (cast (decRng S n).symm (FixedLengthScheme.decAnswer
        (decodeFin _ (S.dec (pairEncode sk (List.ofFn (cast (S.indSpec_decDom n) c)))))), s)
      else .pure (zeroBits _, s) := by
  simpa only [cast_eq] using S.indImpl_dec_onSpec atk b n pk sk c s

-- EXPECT-FAIL route 2: rewrite with the published reader, then close by reflexivity
example (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (c : (S.indSpec n).dom 0) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.indImpl atk b n pk sk 0 c s =
      if FixedLengthScheme.decOpen atk s.isSome && !decide (s = some (cast (S.indSpec_decDom n) c))
      then .pure (cast (decRng S n).symm (FixedLengthScheme.decAnswer
        (decodeFin _ (S.dec (pairEncode sk (List.ofFn (cast (S.indSpec_decDom n) c)))))), s)
      else .pure (zeroBits _, s) := by
  rw [S.indImpl_dec_onSpec]
  rfl

-- EXPECT-FAIL route 3: case split, then `cast_eq_iff_heq` with `cast_heq`
example (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (c : (S.indSpec n).dom 0) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.indImpl atk b n pk sk 0 c s =
      if FixedLengthScheme.decOpen atk s.isSome && !decide (s = some (cast (S.indSpec_decDom n) c))
      then .pure (cast (decRng S n).symm (FixedLengthScheme.decAnswer
        (decodeFin _ (S.dec (pairEncode sk (List.ofFn (cast (S.indSpec_decDom n) c)))))), s)
      else .pure (zeroBits _, s) := by
  rw [S.indImpl_dec_onSpec]
  split
  · congr 2
    exact (cast_eq_iff_heq.2 (cast_heq _ _)).symm
  · rfl

-- EXPECT-FAIL route 4: through the ciphertext-typed reader `indImpl_dec` and `cast_cast`
example (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (c : Fin (S.ctLen.eval n) → Bool) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.indImpl atk b n pk sk 0 (cast (S.indSpec_decDom n).symm c) s =
      if FixedLengthScheme.decOpen atk s.isSome && !decide (s = some c)
      then .pure (cast (decRng S n).symm (FixedLengthScheme.decAnswer
        (decodeFin _ (S.dec (pairEncode sk (List.ofFn c))))), s)
      else .pure (zeroBits _, s) := by
  rw [S.indImpl_dec_onSpec, cast_cast, cast_eq]
  simp only [cast_eq]

end Sealed

section Unsealed

variable (S : FixedLengthPKScheme)

-- EXPECT-PASS: the reader with `outLens` readable (as in its home file)
example (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (c : (S.indSpec n).dom 0) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.indImpl atk b n pk sk 0 c s =
      if FixedLengthScheme.decOpen atk s.isSome && !decide (s = some (cast (S.indSpec_decDom n) c))
      then .pure (cast (decRng S n).symm (FixedLengthScheme.decAnswer
        (decodeFin _ (S.dec (pairEncode sk (List.ofFn (cast (S.indSpec_decDom n) c)))))), s)
      else .pure (zeroBits _, s) := by
  simpa only [cast_eq] using S.indImpl_dec_onSpec atk b n pk sk c s

end Unsealed

end TCSlib.Cryptography.Composability.EscCheck
