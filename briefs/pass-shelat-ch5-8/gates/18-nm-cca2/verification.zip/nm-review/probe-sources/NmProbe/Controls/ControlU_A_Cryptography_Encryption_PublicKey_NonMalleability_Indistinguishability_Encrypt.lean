import Lean
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Encrypt

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace NmControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

open TCSlib.Cryptography.Games in
theorem ctlSimulate {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl

open TCSlib.Cryptography.Games in
theorem ctlSimulateReader {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := TCSlib.Cryptography.Games.simulate_pure impl a s

theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl

theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=
  TCSlib.Cryptography.Games.seedIn_eq n z ω

theorem ctlFinInput (n : ℕ) (z ω s a L : List Bool) : TCSlib.Cryptography.Games.InteractiveHandler.finInput n z ω s a L =
    Turing.pairEncode (TCSlib.Cryptography.Games.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) := rfl

theorem ctlFinInputReader (n : ℕ) (z ω s a L : List Bool) : TCSlib.Cryptography.Games.InteractiveHandler.finInput n z ω s a L =
    Turing.pairEncode (TCSlib.Cryptography.Games.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) :=
  TCSlib.Cryptography.Games.InteractiveHandler.finInput_eq n z ω s a L

theorem ctlPkInLens (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl

theorem ctlPkInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=
  S.inLens_zero n

theorem ctlPkOutLens (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.outLens n 0 = S.msgLen.eval n + 1 := rfl

theorem ctlPkOutLensReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.outLens n 0 = S.msgLen.eval n + 1 :=
  S.outLens_zero n

open TCSlib.Cryptography.Games in
theorem ctlPkIndImpl (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) (c : Fin (S.ctLen.eval n) → Bool) :
    S.indImpl atk b n pk sk 1 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) := rfl

open TCSlib.Cryptography.Games in
theorem ctlPkIndImplReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) (c : Fin (S.ctLen.eval n) → Bool) :
    S.indImpl atk b n pk sk 1 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) :=
  S.indImpl_challenge_repeat_onSpec atk b n pk sk mm c

theorem ctlAcDin (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) : TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 0 = S.ctLen := rfl

theorem ctlAcDinReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) : TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 0 = S.ctLen := TCSlib.Cryptography.Composability.AdaptiveCPA.acDin_zero S

theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :
    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =
      Fin.cons (α := fun _ => Bool) true m := rfl

theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :
    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =
      Fin.cons (α := fun _ => Bool) true m :=
  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m

theorem ctlDecOpen (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false := rfl

theorem ctlDecOpenReader (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false :=
  TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen_cpa c

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in
theorem ctlFwdHandler {k : ℕ} (din dout : Fin k → PolyExpr) (sl : PolyExpr) (ai : List Bool → List Bool)
    (hai : PolyTimeComputable ai) (ol fc : PolyExpr) (fr : List Bool → List Bool) (hfr : PolyTimeComputable fr) :
    (TCSlib.Cryptography.Composability.NMCCA2.fwdHandler din dout sl ai hai ol fc fr hfr).perCall = .const 1 := rfl

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in
theorem ctlFwdHandlerReader {k : ℕ} (din dout : Fin k → PolyExpr) (sl : PolyExpr) (ai : List Bool → List Bool)
    (hai : PolyTimeComputable ai) (ol fc : PolyExpr) (fr : List Bool → List Bool) (hfr : PolyTimeComputable fr) :
    (TCSlib.Cryptography.Composability.NMCCA2.fwdHandler din dout sl ai hai ol fc fr hfr).perCall = .const 1 :=
  TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_perCall din dout sl ai hai ol fc fr hfr

theorem ctlFinU (w : List Bool) : TCSlib.Cryptography.Composability.NMCCA2.finU w = Complexity.pairFstD (Complexity.pairFstD w) := rfl

theorem ctlFinUReader (w : List Bool) : TCSlib.Cryptography.Composability.NMCCA2.finU w = Complexity.pairFstD (Complexity.pairFstD w) :=
  TCSlib.Cryptography.Composability.NMCCA2.finU_eq w

theorem ctlLogEmit (G : List Bool → List Bool) (L : List Bool) :
    TCSlib.Cryptography.Composability.NMCCA2.logEmit G L = (List.range (L.length + 1)).flatMap fun i => G (Complexity.pairSndD^[i] L) := rfl

theorem ctlLogEmitReader (G : List Bool → List Bool) (L : List Bool) :
    TCSlib.Cryptography.Composability.NMCCA2.logEmit G L = (List.range (L.length + 1)).flatMap fun i => G (Complexity.pairSndD^[i] L) :=
  TCSlib.Cryptography.Composability.NMCCA2.logEmit_eq G L

end NmControls

