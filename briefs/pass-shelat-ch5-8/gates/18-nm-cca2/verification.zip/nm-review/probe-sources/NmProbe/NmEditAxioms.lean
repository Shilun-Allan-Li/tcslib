import Lean
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation

/-! nm-cca2 review, landing-edit state: axioms of the target, the two moved readers and
simNMSecure_cpa_iff_nmSecure_cpa, and of every stored constant of the two edited modules. -/

set_option maxHeartbeats 0

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSpec_decRng
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_dec_onSpec_cast
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let owners : List Name := [`TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability]
  let mut n := 0
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"AX {home} {c} {axs.toList}"
    n := n + 1
  IO.println s!"AX-COUNT {n}"
