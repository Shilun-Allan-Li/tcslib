import Lean
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation

/-! nm-cca2 review: axioms of the target and of simNMSecure_cpa_iff_nmSecure_cpa (explicit
`#print axioms`), and of every stored constant of the five touched modules (collectAxioms). -/

set_option maxHeartbeats 0

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_cca2_of_indSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_of_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let owners : List Name := [`TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Readers,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Forward,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Decrypt,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Encrypt,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability]
  let mut n := 0
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"AX {home} {c} {axs.toList}"
    n := n + 1
  IO.println s!"AX-COUNT {n}"
