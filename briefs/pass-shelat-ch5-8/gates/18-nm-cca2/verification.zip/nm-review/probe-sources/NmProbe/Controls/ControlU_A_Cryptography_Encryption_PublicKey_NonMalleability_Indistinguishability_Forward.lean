import Lean
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Forward

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace NmControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

open TCSlib.Cryptography.Games in
theorem ctlSimulate {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl

open TCSlib.Cryptography.Games in
theorem ctlSimulateReader {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := TCSlib.Cryptography.Games.simulate_pure impl a s

theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl

theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=
  TCSlib.Cryptography.Games.seedIn_eq n z ω

theorem ctlFinInput (n : ℕ) (z ω s a L : List Bool) : TCSlib.Cryptography.Games.InteractiveHandler.finInput n z ω s a L =
    Turing.pairEncode (TCSlib.Cryptography.Games.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) := rfl

theorem ctlFinInputReader (n : ℕ) (z ω s a L : List Bool) : TCSlib.Cryptography.Games.InteractiveHandler.finInput n z ω s a L =
    Turing.pairEncode (TCSlib.Cryptography.Games.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) :=
  TCSlib.Cryptography.Games.InteractiveHandler.finInput_eq n z ω s a L

end NmControls

