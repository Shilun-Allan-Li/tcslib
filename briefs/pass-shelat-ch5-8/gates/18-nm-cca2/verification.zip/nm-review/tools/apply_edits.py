"""apply_edits.py <b-root>: the nm-cca2 landing edits, as exact old->new replacements (each must occur
exactly once), plus the deletion of Indistinguishability/Readers.lean.
E-READER: add `FixedLengthPKScheme.indSpec_decRng` and `indImpl_dec_onSpec_cast` to
PublicKey/OracleSecurity.lean right after `indImpl_dec_onSpec` (formula docstrings, no simp attribute);
delete Readers.lean, its import and its Contents line; re-point the one use in the owned file
(`castImpl_indImpl_dec`) to `S.indImpl_dec_onSpec_cast`. Also: drop the stale "(statement phase)"
from the owned file's module title, and two doubled blank lines."""
import sys, os
root = sys.argv[1] + '/TCSlib/Cryptography/Encryption/PublicKey/'
E = {}
def e(f, old, new): E.setdefault(f, []).append((old, new))
OS, OWN = 'OracleSecurity.lean', 'NonMalleability/Indistinguishability.lean'
READERS = 'NonMalleability/Indistinguishability/Readers.lean'
anchor = """      else .pure (zeroBits _, s) := by
  simpa only [cast_eq] using S.indImpl_dec atk b n pk sk c s
"""
e(OS, anchor, anchor + """
/-- The decryption oracle answers a validity bit followed by one message:
`(S.indSpec n).rng 0 = (Fin (S.msgLen.eval n + 1) → Bool)`. -/
theorem indSpec_decRng (n : ℕ) : (S.indSpec n).rng 0 = (Fin (S.msgLen.eval n + 1) → Bool) := by
  rw [S.indSpec_rng, S.outLens_zero]

/-- `indImpl_dec_onSpec` with the answer cast through `indSpec_decRng`: for `c' = cast _ c`,
`S.indImpl atk b n pk sk 0 c s = if decOpen atk s.isSome && s ≠ some c' then
pure (cast _ (decAnswer (decodeFin _ (Dec ⟨sk, c'⟩))), s) else pure (zeroBits _, s)`. -/
theorem indImpl_dec_onSpec_cast (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (c : (S.indSpec n).dom 0) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.indImpl atk b n pk sk 0 c s =
      if FixedLengthScheme.decOpen atk s.isSome && !decide (s = some (cast (S.indSpec_decDom n) c))
      then .pure (cast (S.indSpec_decRng n).symm (FixedLengthScheme.decAnswer
        (decodeFin _ (S.dec (pairEncode sk (List.ofFn (cast (S.indSpec_decDom n) c)))))), s)
      else .pure (zeroBits _, s) := by
  simpa only [cast_eq] using S.indImpl_dec_onSpec atk b n pk sk c s
""")
e(OWN, "import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Readers\n", "")
e(OWN, "# Non-malleable encryption (statement phase)\n", "# Non-malleable encryption\n")
e(OWN, """* `NonMalleability.Indistinguishability.Readers`: the two decryption-oracle readers requested for
  `PublicKey/OracleSecurity.lean` (the fill's escalation).
""", "")
e(OWN, "  rw [castImpl_eq, indImpl_dec_onSpec_cast, FixedLengthScheme.decOpen_cca2, Bool.true_and,",
       "  rw [castImpl_eq, S.indImpl_dec_onSpec_cast, FixedLengthScheme.decOpen_cca2, Bool.true_and,")
e(OWN, "decBlock_eq_nthCt S ℓ n a i (by rw [List.length_map, List.length_range] at h₁; exact h₁)]\n\n\n",
       "decBlock_eq_nthCt S ℓ n a i (by rw [List.length_map, List.length_range] at h₁; exact h₁)]\n\n")
e(OWN, "    simpa only [if_pos rfl] using guessBit_valid hm g _\n\n\n",
       "    simpa only [if_pos rfl] using guessBit_valid hm g _\n\n")
for f, lst in E.items():
    p = root + f; s = open(p, encoding='utf-8').read()
    for old, new in lst:
        assert s.count(old) == 1, (f, old[:60], s.count(old))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
os.remove(root + READERS)
print('applied', sum(len(v) for v in E.values()), 'replacements in', len(E), 'files; deleted', READERS)
