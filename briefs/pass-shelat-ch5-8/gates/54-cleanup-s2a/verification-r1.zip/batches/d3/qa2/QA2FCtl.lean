import TCSlib.Cryptography.Candidates.Factoring

/-! S2-A D3, Q-A2 (a) probes: the two `Factoring` bodies changed in D3 are `rfl`-equal to their
bodies at D2's head `a1545eae`, copied verbatim under the suffix `_d1` (`plantFactor_d1` reads
`fmult_d1`). Unsealed. -/

namespace TCSlib.Cryptography.Candidates

open Complexity Turing NumberTheory Finset

def fmult_d1 : FunFamily where
  inLen := .mul (.const 2) .var
  outLen := .mul (.const 2) .var
  f n x := natToBits (2 * n)
    (fmultNat (bitsToNat (FunFamily.blocks 2 n x 0)) (bitsToNat (FunFamily.blocks 2 n x 1)))

example (n : ℕ) (x : Fin (2 * n) → Bool) : fmult.f n x = fmult_d1.f n (fun i => !x i) := rfl

def plantFactor_d1 {n : ℕ} {ρ : Type*}
    (B : (Fin (fmultBlocks.eval n) → (Fin (2 * n) → Bool)) → ρ →
      (Fin (fmultBlocks.eval n) → (Fin (2 * n) → Bool)))
    (N : Fin (2 * n) → Bool)
    (c : Fin (fmultBlocks.eval n) × ((Fin (fmultBlocks.eval n) → (Fin (2 * n) → Bool)) × ρ)) :
    Fin n → Bool :=
  FunFamily.blocks 2 n (OneWay.yaoTry (fmult_d1.f n) B N c) 0

example {n : ℕ} {ρ : Type*}
    (B : (Fin (fmultBlocks.eval n) → (Fin (2 * n) → Bool)) → ρ →
      (Fin (fmultBlocks.eval n) → (Fin (2 * n) → Bool))) :
    @plantFactor n ρ B = fun N c => @plantFactor_d1 n ρ B (fun i => !N i) c := rfl

end TCSlib.Cryptography.Candidates
