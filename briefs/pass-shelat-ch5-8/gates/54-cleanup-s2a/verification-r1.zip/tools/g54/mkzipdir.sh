#!/usr/bin/env bash
# mkzipdir.sh (Gate 54): assemble the verification ZIP's tree in $G/zip (merge/ and batches/ are assembled before it).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; G=$SP/g54; Z=$G/zip; R=$G/replay
cpf(){ src=$1; dst=$2; [ -e "$src" ] || { echo "MISSING $src"; return; }; mkdir -p "$(dirname "$Z/$dst")"; cp -r "$src" "$Z/$dst"; }
for f in full-order.txt order-H.txt fullorder.out plan.out startcheck.out startcheck.txt state-start.sha permod.tsv permod.out update.out statecheck.txt statecheck.out links.txt output-map.tsv outmap.out rebuilt-vs-snapshot11.txt keycmp-snapshot11.txt roots-queue.txt roots-before.txt permod-roots.tsv permod-roots.out statecheck-final.txt statecheck-final.out outmap-final.out state.json; do cpf $R/$f replay/$f; done
cpf $R/plan replay/plan
for d in build build-roots build-attempt1-no-toolchain; do mkdir -p $Z/replay/$d; for f in results.jsonl runner.start runner.exit df-launch.txt slot-log.txt slot-waits.txt run-replay.out; do [ -f $R/$d/$f ] && cp $R/$d/$f $Z/replay/$d/; done; cp -r $R/$d/mods $Z/replay/$d/; done
cp $R/run-replay.out $Z/replay/build/run-replay.out
for t in before after final; do cpf $G/log/rehash-d4-$t.txt replay/rehash-d4-$t.txt; done; cpf $G/log/notes.txt log/notes.txt
sha256sum $SP/olean-snapshot.map-bff0567b.tsv | sed "s|$SP/||" > $Z/replay/snapshot11-map.sha256
cpf $G/admissions admissions
S=$G/seal/merged; mkdir -p $Z/seal/seal-runs $Z/seal/probe-runs
for f in run.out head.txt mkseals-coe-A.log seal-source-vs-d4.txt compare-d4.txt; do cp $S/$f $Z/seal/; done; cp -r $S/order $Z/seal/
cp $S/seal-runs/results.jsonl $S/seal-runs/slot-log.txt $Z/seal/seal-runs/; cp -r $S/seal-runs/mods $Z/seal/seal-runs/
cp $S/probe-runs/results.jsonl $Z/seal/probe-runs/; cp $S/probe-sources/Collect.lean.txt $Z/seal/
(cd $S/seals-coe/A && sha256sum *) > $Z/seal/seals-coe-A.sha256; (cd $S/probe-runs/mods && sha256sum *.log) > $Z/seal/collector-log.sha256
cpf $G/lint lint
for t in TCSlib_Complexity TCSlib_Cryptography; do cp $SP/s2a-d1/lint/campaign-base-$t.txt $Z/lint/d1-base-campaign-$t.txt; cp $SP/s2a-d4/lint/campaign-head-$t.txt $Z/lint/d4-head-campaign-$t.txt; done
cpf $G/checks checks; cp $SP/s2a-d4/decls2/base-vs-head.tsv $Z/checks/decls2-base-vs-head.tsv
mkdir -p $Z/tools/g54 $Z/tools/used/seal-review; cp $G/tools/* $Z/tools/g54/
T=$SP/snaptools3/olean-advance-a6d01b1b/tools-used; cp $T/stateplan.py $T/runner.py $T/fullorder.py $T/permod.py $Z/tools/used/
cp $SP/s2a-d4/tools/mapnoml.py $SP/s2a-d4/tools/sorryscan.py $SP/s2a-d4/tools/gated_full.sh $SP/s2a-d4/tools/finalseal.sh $SP/s2a-d4/tools/errdecl.py $Z/tools/used/
cp $SP/g6a-p2/tools/seal/runner_full.py /home/user/tcslib/scripts/lean_check_tree.sh $Z/tools/used/
cp $SP/s2a-d4/tools/seal/review/mkcollect.py $SP/s2a-d4/tools/seal/review/mkseals_coe.py $SP/s2a-d4/tools/seal/review/NmCollect.template.lean $Z/tools/used/seal-review/
cp -r $SP/s2a-d4/tools/seal/review/archived-gate10-tools $Z/tools/used/seal-review/
