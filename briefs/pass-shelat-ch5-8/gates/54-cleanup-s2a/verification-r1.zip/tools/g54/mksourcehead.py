r"""mksourcehead.py <repo> <out.json> (Gate 54 staging, git objects only): pins, Lean equality, the 43 commits of PR #390,
per-file statistics of the 63 S2-A files at the base and the head, the merged tree, and the SHA-256 of the records the pack
cites at the records tip."""
import sys, json, subprocess, hashlib, re
repo, out = sys.argv[1:3]
g = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout
gs = lambda *a: g(*a).decode().strip()
B = '61a5f0fb640622c15fdd33df56efa470b2bf26c8'; H = '9f7f409c2e09749428db75b9ddd324f92695e4af'
PINS = open(sys.argv[3]).read().split(); TIP = PINS[0]; M = PINS[3]
NOW = gs('rev-parse', 'origin/cryptography/pass-shelat-ch2-4')
def stats(rev, p):
    try: b = g('show', f'{rev}:{p}')
    except subprocess.CalledProcessError: return None
    t = b.decode('utf-8'); L = t.split('\n')
    if L and L[-1] == '': L = L[:-1]
    return dict(git_blob=gs('rev-parse', f'{rev}:{p}'), sha256=hashlib.sha256(b).hexdigest(), lines=len(L),
                max_width=max((len(x) for x in L), default=0), over_100=sum(len(x) > 100 for x in L),
                tabs=sum('\t' in x for x in L), trailing_space=sum(x != x.rstrip() for x in L),
                sorry_tokens=len(re.findall(r'(?<![A-Za-z0-9_])sorry(?![A-Za-z0-9_])', t)), micro_sign=t.count('µ'))
files = gs('diff', '--name-only', B, H).split('\n')
commits = []
for c in gs('rev-list', '--reverse', f'{B}..{H}').split('\n'):
    raw = g('cat-file', '-p', c).decode()
    commits.append(dict(commit=c, parents=gs('rev-list', '--parents', '-n1', c).split()[1:], tree=gs('rev-parse', f'{c}^{{tree}}'),
        tcslib_tree=gs('rev-parse', f'{c}:TCSlib'), subject=gs('log', '-1', '--format=%s', c), author=gs('log', '-1', '--format=%an <%ae>', c),
        author_date=gs('log', '-1', '--format=%aI', c), committer_date=gs('log', '-1', '--format=%cI', c),
        signature='ssh' if '-----BEGIN SSH SIGNATURE-----' in raw else ('gpg' if 'gpgsig' in raw else 'none'),
        files=gs('diff-tree', '--no-commit-id', '--name-only', '-r', c).split('\n'),
        shortstat=gs('diff', '--shortstat', f'{c}^', c)))
cited = ['policy.md', 'PassShelatChapter5-8Plan.md', 'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md',
         'briefs/pass-shelat-ch5-8/cleanup-stages.md', 'briefs/pass-shelat-ch5-8/duplication-ledger.md',
         'briefs/pass-shelat-ch5-8/deferred-work.md']
cited += [f'briefs/pass-shelat-ch5-8/cleanup-stage2/{f}' for f in ['plan-r1.md', 'scope.tsv', 's2a-workplan-r1.md', 's2a-items.tsv',
          's2a-d1-report.md', 's2a-d2-report.md', 's2a-d3-report.md', 's2a-d4-report.md']]
rec = {}
for p in cited:
    try: rec[p] = hashlib.sha256(g('show', f'{NOW}:{p}')).hexdigest()
    except subprocess.CalledProcessError: rec[p] = None
J = dict(gate=54, round=1, name='Cleanup Stage 2, S2-A (PR #390)', staged='2026-11-19', toolchain=gs('show', f'{H}:lean-toolchain'),
    pr=dict(number=390, branch='cleanup/stage2-s2a', head=H, head_tree=gs('rev-parse', f'{H}^{{tree}}'), head_tcslib_tree=gs('rev-parse', f'{H}:TCSlib'),
            base_branch='cryptography/pass-shelat-ch2-4', s2a_base=B, base_tcslib_tree=gs('rev-parse', f'{B}:TCSlib'),
            merge_base_with_records_tip=gs('merge-base', TIP, H), commits=len(commits), changed_files=len(files),
            shortstat=gs('diff', '--shortstat', B, H)),
    records_tip_replayed=TIP, records_tip_replayed_tcslib_tree=gs('rev-parse', f'{TIP}:TCSlib'),
    records_tip_at_staging=NOW, records_tip_at_staging_tcslib_tree=gs('rev-parse', f'{NOW}:TCSlib'),
    records_tip_at_staging_lean_paths_changed_since_replayed=[x for x in gs('diff', '--name-only', TIP, NOW, '--', 'TCSlib', 'TCSlib.lean', 'audits', 'lean-toolchain', 'lake-manifest.json', 'lakefile.lean').split('\n') if x],
    merge_tree_at_staging_tip=gs('merge-tree', '--write-tree', NOW, H), merge_tree_at_staging_tip_tcslib_tree=gs('rev-parse', gs('merge-tree', '--write-tree', NOW, H) + ':TCSlib'),
    merged=dict(merge_tree=gs('merge-tree', '--write-tree', TIP, H), scratch_commit=M, scratch_commit_on_any_ref=False,
                tcslib_tree=gs('rev-parse', f'{M}:TCSlib'), parents=[TIP, H]),
    lean_paths_changed_records_side=gs('diff', '--name-only', B, TIP, '--', 'TCSlib', 'TCSlib.lean', 'audits').split('\n'),
    unchanged_everywhere={p: gs('rev-parse', f'{M}:{p}') for p in ['TCSlib.lean', 'audits', 'lean-toolchain', 'lake-manifest.json', 'lakefile.lean']},
    mathlib=json.loads(g('show', f'{H}:lake-manifest.json'))['packages'][0]['rev'] if False else None,
    commits=commits, files={p: dict(base=stats(B, p), head=stats(H, p), merged_blob_equals_head=gs('rev-parse', f'{M}:{p}') == gs('rev-parse', f'{H}:{p}')) for p in files},
    records_sha256_at_staging_tip=rec)
man = json.loads(g('show', f'{H}:lake-manifest.json'))
J['manifest_packages'] = {p['name']: p.get('rev') for p in man['packages']}
del J['mathlib']
json.dump(J, open(out, 'w'), indent=1, sort_keys=True, ensure_ascii=False); open(out, 'a').write('\n')
print('files', len(files), 'commits', len(commits), 'records', sum(v is not None for v in rec.values()), '/', len(rec))
