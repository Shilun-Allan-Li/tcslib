"""docworddiff.py <repo> <base> <head> <file>: word-level diff of the whole file text between
<base> and <head> (whitespace-normalised), to show the exact wording change."""
import sys, subprocess, difflib
repo, base, head, f = sys.argv[1:5]
show = lambda r: subprocess.run(['git', '-C', repo, 'show', f'{r}:{f}'], capture_output=True,
                                check=True).stdout.decode('utf-8').split()
a, b = show(base), show(head)
for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
    if op != 'equal':
        print(op, repr(' '.join(a[i1:i2])), '->', repr(' '.join(b[j1:j2])))
