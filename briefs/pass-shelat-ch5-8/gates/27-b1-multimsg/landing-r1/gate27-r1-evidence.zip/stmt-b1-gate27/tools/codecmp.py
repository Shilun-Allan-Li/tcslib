"""codecmp.py <repo> <base> <head> <file>: blank every comment (nested /- -/ block comments,
including /-- -/ and /-! -/ doc comments, and -- line comments; string literals respected),
keeping newlines, then compare the code of <file> at <base> and <head>. Also extracts every
declaration header (from a declaration keyword to the first top-level `:=`, `|` or `where`,
whitespace-normalised) and compares the lists."""
import sys, subprocess, re, hashlib
repo, base, head, f = sys.argv[1:5]
def show(rev):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True,
                          check=True).stdout.decode('utf-8')
def blank(s):
    out, i, n, depth = [], 0, len(s), 0
    while i < n:
        if depth == 0 and s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1; continue
        if s.startswith('/-', i):
            depth += 1; out.append('  '); i += 2; continue
        if depth and s.startswith('-/', i):
            depth -= 1; out.append('  '); i += 2; continue
        if depth == 0 and s.startswith('--', i):
            j = s.find('\n', i); j = n if j < 0 else j
            out.append(' ' * (j - i)); i = j; continue
        out.append(s[i] if (depth == 0 or s[i] == '\n') else ' '); i += 1
    return ''.join(out)
KW = r'(?:theorem|lemma|def|abbrev|structure|class|instance|inductive|axiom|opaque|example)'
def headers(code):
    hs = []
    for m in re.finditer(r'^(?:(?:private|protected|noncomputable|@\[[^\]]*\])\s+)*' + KW + r'\b',
                         code, re.M):
        rest = code[m.start():]
        e = re.search(r":=|\bwhere\b|^\s*\|\s", rest, re.M)
        hs.append(' '.join(rest[:e.start() if e else len(rest)].split()))
    return hs
b, h = blank(show(base)), blank(show(head))
nb = [l.rstrip() for l in b.split('\n')]; nh = [l.rstrip() for l in h.split('\n')]
print('code identical (comments blanked, trailing spaces trimmed):', nb == nh)
print('code identical (comments blanked, whitespace-normalised):', b.split() == h.split())
hb, hh = headers(b), headers(h)
print('headers', len(hb), len(hh), 'identical:', hb == hh)
print('code sha256 base', hashlib.sha256('\n'.join(nb).encode()).hexdigest())
print('code sha256 head', hashlib.sha256('\n'.join(nh).encode()).hexdigest())
if hb != hh:
    for x in hb:
        if x not in hh: print('- ', x)
    for x in hh:
        if x not in hb: print('+ ', x)
