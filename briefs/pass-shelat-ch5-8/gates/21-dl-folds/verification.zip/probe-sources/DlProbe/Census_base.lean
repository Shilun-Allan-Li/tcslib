import Lean
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Asymptotic.EnsemblesLemmas
import TCSlib.Cryptography.Authentication.Signatures.Lamport
import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Handler
import TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Handler
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Decrypt
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Encrypt
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Forward
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Challenge
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Generic
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Hybrid
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.IndSim
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Recover
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Reduction
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Rounds
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimIND
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Simulator
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.ChallengeSim
import TCSlib.Cryptography.Foundations.BitLists
import TCSlib.Cryptography.Games
import TCSlib.Cryptography.Games.BitCodec
import TCSlib.Cryptography.Games.Efficiency
import TCSlib.Cryptography.Games.Efficiency.OracleBridge
import TCSlib.Cryptography.Games.Hopping
import TCSlib.Cryptography.Games.Machines
import TCSlib.Cryptography.Games.OracleComp
import TCSlib.Cryptography.Games.Probability
import TCSlib.Cryptography.Games.Simulate
import TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM.Evaluator
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.SoundnessRep
import TCSlib.Cryptography.ZeroKnowledge.ThreeColoring.Machines
import TCSlib.Cryptography.Implications.PublicKey
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation

/-! dl-consolidation review census probe (base side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_of_simNMSecure
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_of_nmSecure_cpa
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure.adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.bitwise_padded_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.exists_adaptive_cpa
#print axioms TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.padded_cpa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_rsa
#print axioms TCSlib.Cryptography.Implications.PublicKey.exists_adaptiveCPA_of_factoring
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_cca2_of_indSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_of_nmSecure_cca2
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2

def owners : List Name := [`TCSlib.Cryptography.Asymptotic.Adversary,
  `TCSlib.Cryptography.Asymptotic.EnsemblesLemmas,
  `TCSlib.Cryptography.Authentication.Signatures.Lamport,
  `TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine,
  `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Handler,
  `TCSlib.Cryptography.Encryption.PublicKey.AdaptiveCPA.Handler,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Decrypt,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Encrypt,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability.Forward,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Challenge,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Generic,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Hybrid,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.IndSim,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Recover,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Reduction,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Rounds,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimIND,
  `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Simulator,
  `TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity,
  `TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity.ChallengeSim,
  `TCSlib.Cryptography.Foundations.BitLists,
  `TCSlib.Cryptography.Games,
  `TCSlib.Cryptography.Games.BitCodec,
  `TCSlib.Cryptography.Games.Efficiency,
  `TCSlib.Cryptography.Games.Efficiency.OracleBridge,
  `TCSlib.Cryptography.Games.Hopping,
  `TCSlib.Cryptography.Games.Machines,
  `TCSlib.Cryptography.Games.OracleComp,
  `TCSlib.Cryptography.Games.Probability,
  `TCSlib.Cryptography.Games.Simulate,
  `TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM.Evaluator,
  `TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.SoundnessRep,
  `TCSlib.Cryptography.ZeroKnowledge.ThreeColoring.Machines]
def nameMap : Std.HashMap String String := Std.HashMap.ofList [("TCSlib.Cryptography.Composability.NMSim.buildComp_budget_eq", "TCSlib.Cryptography.Games.buildComp_budget_eq"),
  ("TCSlib.Cryptography.Composability.NMSim.toCompOn_budget_eq", "Complexity.NUPPT.toCompOn_budget_eq"),
  ("TCSlib.Cryptography.Composability.NMSim.buildComp_of_ret", "TCSlib.Cryptography.Games.buildComp_of_ret"),
  ("TCSlib.Cryptography.Composability.NMSim.impl_of_ret", "TCSlib.Cryptography.Games.InteractiveHandler.impl_of_ret_padFin"),
  ("TCSlib.Cryptography.Composability.NMSim.impl_of_query", "TCSlib.Cryptography.Games.InteractiveHandler.impl_of_query_padFin"),
  ("TCSlib.Cryptography.Composability.NMSim.finish_of_ret", "TCSlib.Cryptography.Games.InteractiveHandler.finish_of_ret_padFin"),
  ("TCSlib.Cryptography.Composability.NMSim.expect_toCompOn_outLen", "TCSlib.Cryptography.Games.expect_toCompOn_outLen"),
  ("TCSlib.Cryptography.Composability.NMSim.expect_congr_of_allOutputs", "TCSlib.Cryptography.Games.ProbComp.expect_congr_of_allOutputs"),
  ("TCSlib.Cryptography.Composability.NMSim.bind_congr_of_allOutputs", "TCSlib.Cryptography.Games.OracleComp.bind_congr_of_allOutputs"),
  ("TCSlib.Cryptography.Composability.NMSim.expect_expect_sample", "TCSlib.Cryptography.Games.ProbComp.expect_expect_sample"),
  ("TCSlib.Cryptography.Composability.NMSim.costBoundedBy_bind_of_allOutputs", "TCSlib.Cryptography.Games.OracleComp.CostBoundedBy.bind_of_allOutputs"),
  ("TCSlib.Cryptography.Composability.NMSim.simulate_costBoundedBy_once", "TCSlib.Cryptography.Games.simulate_costBoundedBy_once"),
  ("TCSlib.Cryptography.Composability.NMSim.expect_simulate_eager", "TCSlib.Cryptography.Games.expect_simulate_eager"),
  ("TCSlib.Cryptography.Composability.NMSim.expect_eq_until_bad", "TCSlib.Cryptography.Games.expect_eq_until_bad"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler", "TCSlib.Cryptography.Games.fwdHandler"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_stateLen", "TCSlib.Cryptography.Games.fwdHandler_stateLen"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_seedLen", "TCSlib.Cryptography.Games.fwdHandler_seedLen"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_perCall", "TCSlib.Cryptography.Games.fwdHandler_perCall"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_init", "TCSlib.Cryptography.Games.fwdHandler_init"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_advIn", "TCSlib.Cryptography.Games.fwdHandler_advIn"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_outLen", "TCSlib.Cryptography.Games.fwdHandler_outLen"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_finCall", "TCSlib.Cryptography.Games.fwdHandler_finCall"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_finRun", "TCSlib.Cryptography.Games.fwdHandler_finRun"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler_impl", "TCSlib.Cryptography.Games.fwdHandler_impl"),
  ("TCSlib.Cryptography.Composability.NMCCA2.exists_withAdviceOn", "Complexity.NUPPT.exists_withAdviceOn"),
  ("TCSlib.Cryptography.Composability.NMCCA2.cntRead", "TCSlib.Cryptography.Games.cntRead"),
  ("TCSlib.Cryptography.Composability.NMCCA2.cntRead_eq", "TCSlib.Cryptography.Games.cntRead_eq"),
  ("TCSlib.Cryptography.Composability.NMCCA2.polyTimeComputable_cntRead", "TCSlib.Cryptography.Games.polyTimeComputable_cntRead"),
  ("TCSlib.Cryptography.Composability.NMCCA2.ansRead", "TCSlib.Cryptography.Games.ansRead"),
  ("TCSlib.Cryptography.Composability.NMCCA2.ansRead_eq", "TCSlib.Cryptography.Games.ansRead_eq"),
  ("TCSlib.Cryptography.Composability.NMCCA2.polyTimeComputable_ansRead", "TCSlib.Cryptography.Games.polyTimeComputable_ansRead"),
  ("TCSlib.Cryptography.Composability.NMCCA2.fwdHandler.congr_simp", "TCSlib.Cryptography.Games.fwdHandler.congr_simp"),
  ("TCSlib.Cryptography.Composability.NMCCA2.finU", "TCSlib.Cryptography.Games.InteractiveHandler.rU"),
  ("TCSlib.Cryptography.Composability.NMCCA2.finZ", "TCSlib.Cryptography.Games.InteractiveHandler.rZ"),
  ("TCSlib.Cryptography.Composability.NMCCA2.finW", "TCSlib.Cryptography.Games.InteractiveHandler.rW"),
  ("TCSlib.Cryptography.Composability.NMCCA2.finA", "TCSlib.Cryptography.Games.InteractiveHandler.finA"),
  ("TCSlib.Cryptography.Composability.NMCCA2.finL", "TCSlib.Cryptography.Games.InteractiveHandler.rL"),
  ("TCSlib.Cryptography.Composability.NMSim.finSt", "TCSlib.Cryptography.Games.InteractiveHandler.rS"),
  ("TCSlib.Cryptography.Composability.NMSim.finSt_finInput", "TCSlib.Cryptography.Games.InteractiveHandler.rS_finInput"),
  ("TCSlib.Cryptography.Composability.NMSim.polyTimeComputable_finSt", "TCSlib.Cryptography.Games.InteractiveHandler.polyTimeComputable_rS"),
  ("TCSlib.Cryptography.Composability.NMSim.rdU", "TCSlib.Cryptography.Games.InteractiveHandler.rU"),
  ("TCSlib.Cryptography.Composability.NMSim.rdZ", "TCSlib.Cryptography.Games.InteractiveHandler.rZ"),
  ("TCSlib.Cryptography.Composability.NMSim.rdW", "TCSlib.Cryptography.Games.InteractiveHandler.rW"),
  ("TCSlib.Cryptography.Composability.NMSim.rdState", "TCSlib.Cryptography.Games.InteractiveHandler.rS"),
  ("TCSlib.Cryptography.Composability.NMSim.rdIdx", "TCSlib.Cryptography.Games.InteractiveHandler.rI"),
  ("TCSlib.Cryptography.Composability.NMSim.rdQuery", "TCSlib.Cryptography.Games.InteractiveHandler.rX"),
  ("TCSlib.Cryptography.Composability.NMSim.rdLog", "TCSlib.Cryptography.Games.InteractiveHandler.rL"),
  ("TCSlib.Cryptography.Composability.NMSim.rdAns", "TCSlib.Cryptography.Games.InteractiveHandler.rAns"),
  ("TCSlib.Cryptography.Composability.NMSim.rdAns_eq", "TCSlib.Cryptography.Games.InteractiveHandler.rAns_eq"),
  ("TCSlib.Cryptography.Composability.NMSim.rdAns_input", "TCSlib.Cryptography.Games.InteractiveHandler.rAns_input"),
  ("TCSlib.Cryptography.Composability.NMSim.chunkAt", "TCSlib.Cryptography.coinBlock"),
  ("TCSlib.Cryptography.Composability.NMSim.chunkAt_eq", "TCSlib.Cryptography.coinBlock_eq"),
  ("TCSlib.Cryptography.Composability.NMSim.length_chunkAt", "TCSlib.Cryptography.length_coinBlock"),
  ("TCSlib.Cryptography.Composability.NMSim.chunkAt_flatten_append", "TCSlib.Cryptography.coinBlock_flatten_append"),
  ("TCSlib.Cryptography.Composability.NMSim.map_chunkAt_flatten", "TCSlib.Cryptography.map_coinBlock_flatten"),
  ("TCSlib.Cryptography.Composability.NMSim.ofFn_block", "TCSlib.Cryptography.ofFn_block_eq_coinBlock"),
  ("TCSlib.Cryptography.Authentication.coinBlock_flatten", "TCSlib.Cryptography.coinBlock_flatten"),
  ("TCSlib.Cryptography.Composability.NMSim.ofFn_natAdd_eq_drop", "TCSlib.Cryptography.ofFn_natAdd_eq_drop"),
  ("TCSlib.Cryptography.Composability.NMSim.decide_map_ofFn", "TCSlib.Cryptography.decide_map_ofFn"),
  ("TCSlib.Cryptography.Composability.NMSim.length_flatten_map_const", "TCSlib.Cryptography.length_flatten_map_const"),
  ("TCSlib.Cryptography.Composability.NMSim.length_flatten_map_range", "TCSlib.Cryptography.length_flatten_map_range"),
  ("TCSlib.Cryptography.Composability.NMSim.ofFn_eq_map_range", "TCSlib.Cryptography.ofFn_eq_map_range"),
  ("TCSlib.Cryptography.ColMachines.ofFn_eq_map_range", "TCSlib.Cryptography.ofFn_eq_map_range"),
  ("TCSlib.Cryptography.GI.ofFn_eq_map_range", "TCSlib.Cryptography.ofFn_eq_map_range"),
  ("TCSlib.Cryptography.Composability.NMSim.padFin_append_split", "TCSlib.Cryptography.Games.padFin_append_split"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquiv", "TCSlib.Cryptography.EnsembleLemmas.seedEquiv"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquiv_ofFn", "TCSlib.Cryptography.EnsembleLemmas.seedEquiv_ofFn"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquivPoly", "TCSlib.Cryptography.EnsembleLemmas.seedEquivPoly"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquivPoly_ofFn", "TCSlib.Cryptography.EnsembleLemmas.seedEquivPoly_ofFn"),
  ("TCSlib.Cryptography.Composability.NMSim.ofFn_padFin_eq_padL", "TCSlib.Cryptography.EnsembleLemmas.ofFn_padFin_eq_padL"),
  ("TCSlib.Cryptography.Authentication.coinBlock_flatten.match_1_1", "TCSlib.Cryptography.coinBlock_flatten.match_1_1"),
  ("TCSlib.Cryptography.Composability.NMCCA2.finA.eq_1", "TCSlib.Cryptography.Games.InteractiveHandler.finA.eq_1"),
  ("TCSlib.Cryptography.Composability.NMSim.rdAns.eq_1", "TCSlib.Cryptography.Games.InteractiveHandler.rAns.eq_1"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquiv.congr_simp", "TCSlib.Cryptography.EnsembleLemmas.seedEquiv.congr_simp"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquiv.eq_1", "TCSlib.Cryptography.EnsembleLemmas.seedEquiv.eq_1"),
  ("TCSlib.Cryptography.Composability.NMSim.seedEquivPoly.eq_1", "TCSlib.Cryptography.EnsembleLemmas.seedEquivPoly.eq_1"),
  ("TCSlib.Cryptography.Composability.NMSim.polyTimeComputable_guessBit", "TCSlib.Cryptography.Composability.NMCCA2.polyTimeComputable_guessBit"),
  ("TCSlib.Cryptography.Composability.NMSim.ctLen_pos", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.ctLen_pos"),
  ("TCSlib.Cryptography.Composability.NMCCA2.indImpl_eq_of_msgLen_eq_zero", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_eq_of_msgLen_eq_zero"),
  ("TCSlib.Cryptography.Composability.NMCCA2.indImpl_eq_of_msgLen_eq_zero.match_1_1", "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_eq_of_msgLen_eq_zero.match_1_1")]

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

