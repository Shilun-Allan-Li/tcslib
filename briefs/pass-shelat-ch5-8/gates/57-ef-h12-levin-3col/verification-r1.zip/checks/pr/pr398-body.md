Efficiency wave 1, job EF-H12 (`ef-h12-levin-3col`). It proves `LevinNPHard L3COL R3COL` with no hypothesis: every
language with a witness relation has a Levin reduction to `(3COL, R_3COL)` whose instance map and witness map are
`PolyTimeComputable` string maps with exact output lengths. With it, the two ZK theorems of [PS10, Theorem 124.1]
hold without their `LevinNPHard` hypothesis.

**Not stacked.** The base is the records branch, and this PR depends on no other open PR. Its diff is 23 commits and
14 files, +4,068/−0: 13 new files under `ZeroKnowledge/LevinHardness/`, plus the `ZeroKnowledge` facade.

## Contents
- **Route:** `(L, R) → (CKT-SAT, R_CKT) → (3SAT, R_3SAT) → (3COL, R_3COL)`.
  - The circuit route is [AB09, Lemmas 6.10 and 6.11], with the wire values as the witness [PS10, Theorem 124.1,
    step 2].
  - The 3SAT → 3COL step is Stockmeyer's reduction [St73] in the variant of the course file
    `NPReductions/ThreeSATToColoring.lean`.
  - Padding with isolated vertices gives exact lengths.
- **Files:**
  - `Relations` defines `R_CKT` and `R_3SAT`.
  - `Verifier` is step 1: the certificate, the verifier in `P` and the tableau instance map.
  - `CircuitWitness` is step 2: the Tseitin map with the wire-value witness.
  - `Gadget`, `UnaryArith`, `ColoringGraph` and `ColoringParse` give step 3: the gadget instance map and its
    polynomial-time tests.
  - `ColoringWitness` is step 4: the explicit colouring witness.
  - `Soundness` is the course theorem, transported along a homomorphism; it is not re-proved.
  - `Padding` pads graphs and colourings.
  - `Hardness` holds `levinNPHard_L3COL` and `zk_proof_of_{witnessRelation,mem_NP}_of_owp_unconditional`.
- **`Bridge.lean`** is a bounded, recorded Rule-10 exception (decision-log row "EF-H12-R1 ruled (A)", ledger
  DL-65). It holds exactly 27 readers of definitions in files this PR may not edit:
  - 10 for `Formulas/CNF`, `Formulas/CNFEncoding` and `DAGCircuitSat`;
  - `levinNPHard_iff` for `ZeroKnowledge/NP.lean`;
  - 16 for the course file.

  17 are `rfl`/`Iff.rfl`, and 10 are case lemmas, as its docstring says. Each group is repaid by an owner PR (below).

## Commits
1–19. The worker's 19 commits, applied with `git am`. Authorship and messages are kept, and the tree after commit
   19 equals the phase-2 check head's (`efdd41d8…`).
20. `4230f872` **LE-h12-arith** (EFH12-F02; EF-H12-R3 (B)). `unaryPow_poly`, `unaryDiv_poly` and `unaryMod_poly` are
    deleted. The call sites use `unaryPolyOf_poly` and `divNum_poly`/`modNum_poly` with `divNum_eq`/`modNum_eq`.
21. `76676c14` **LE-h12-strip** (EFH12-F08). `polyTimeComputable_stripCert` reads the catalog's `match` through its
    matcher's equation lemmas, not by defeq. A kernel check with that matcher replaced by an axiom accepts it and
    rejects the delivered proof.
22. `ad07b07c` **LE-h12-bridge** (EFH12-F01; EF-H12-R1 (A)). The bridge docstrings cite the decision-log row, name the
    owners and the repayment, and mark the case lemmas.
23. `11f33ef3` **LE-h12-doc** (EFH12-F05(c), F07). The citation fixes from the [AB09] ch. 2/6 ingest (Def 6.9 →
    Def 6.1, the TCSlib reading convention, the "§2.3" tags on glue files). [St73] is cited for the Karp form and
    the reduction (Theorem, p. 22; proof pp. 21–22; Fig. 1, p. 24), with a deviation note on
    `levinNPHard_L3COL`.

All 23 commits are signed.

## Checks
- **Maintainer review:** ACCEPT WITH LANDING EDITS, with phase 2 passed
  (`briefs/efficiency-gaps/wave1/EF-H12/final-r1/`). All its landing edits are applied; the landing record is
  `landing.md`.
- **Merged-tree replay of the landing head** with the records tip (Lean = `bff0567b` + U12/U13), on a copy of
  phase 2's state-checked tree:
  - 27 modules rebuilt with rc 0 and 0 errors, including root `TCSlib` and `audits/pass-shelat/Checks`. The 15
    `sorry` warnings are the records side's GSW admissions; the EF-H12 modules have 0 `sorry` and 0 warnings.
  - The state check gave 1469/1469 OK.
- **Axioms:** all 488 constants stored by the 12 modules and the facade are within
  `{propext, Classical.choice, Quot.sound}`. The headline and both corollaries are
  `[propext, Classical.choice, Quot.sound]`.
- **Canonical coe-A seals:**
  - **0 errors on all 11 non-bridge owners**, `Verifier` included (F08 closed).
  - `Bridge.lean`, the recorded exception, has 43 errors on 20 readers, the definitional readers, as
    expected. The 7 `simp [EdgeRelation]` readers are the scan's 7 hits.
  - Seal B gives the same result. The worker's strict seals pass 11/11, the bridge's minimal unseal passes, and
    the 50 paired controls are ALL_OK.
  - Explicit-unfold scan: 0 hits outside `Bridge.lean`.
- **decls2** against the base: 242 added, 0 changed, 0 removed. That is the delivery's 245 minus the three deleted
  helpers.
- **Lint:** no new FAIL or WARN, and `style_lint` reports 0 findings on the 14 files.

## Still to do
- **A Codex gate is to be staged** for this PR. It also does the Codex source review of the AB09 ch. 2/6, GJS74
  and St73 ingests (`blueprint/src/references/`), whose anchors are "awaiting Codex source review".
- **Follow-ups, not in this PR:**
  - The **Complexity owner PR** adds the bridge's 10 `Formulas/CNF`, `Formulas/CNFEncoding` and `DAGCircuitSat`
    readers, EF-H1's `mem_PRIMES`/`mem_PRIMESBin`, and the DL-70 readers. After it merges, the bridge rows
    are deleted and their consumers re-pointed.
  - The **course-file owner PR** (EF-H12-R2 (B)) adds the 16 readers, makes `sat3Coloring` public with its
    properness lemma, and adds the [St73] References line with the gadget-variant note. Then the bridge's course
    section and the re-derived properness proof are dropped.
  - `levinNPHard_iff` moves into `ZeroKnowledge/NP.lean` after #390 merges.
  - The sorried FormulaKit rows (`Emit.lean:216-271`) are queued for their owner.
  - Information, for the Complexity owner: the catalog statement `computesFunInTime_stripLast` also uses a private
    matcher of `Build/Primitives.lean`, which no seal can cover. A named function with a reader beside that row
    would let `polyTimeComputable_stripCert` avoid reducing it.

---
_Generated by [Claude Code](https://claude.ai/code)_