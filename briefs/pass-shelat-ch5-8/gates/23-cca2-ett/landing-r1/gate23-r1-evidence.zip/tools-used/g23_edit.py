"""g23_edit.py <worktree>: LE-gate23 (G23-02) docstring edits; each old text must occur exactly once."""
import sys
D = sys.argv[1] + '/TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/'
EDITS = [
    ('Reduction.lean',
     "/-- `dAbs q E hE b n s = (dHState q E hE b n s.2 s.1.1, ())`. -/\n",
     "/-- `dAbs E hE q b n s = (dHState q E hE b n s.2 s.1.1, ())`. -/\n"),
    ('Handler.lean',
     "* `ETTGame.dHandler E hE q b`: the handler.\n",
     "* `ETTGame.dHandler q E hE b`: the handler.\n"),
    ('CPAHandler.lean',
     "* `ETTGame.bHandler q hq b`: the handler.\n",
     "* `ETTGame.bHandler q`: the handler.\n"),
    ('CPAReduction.lean',
     "`bAbs ((o, L), j)` with the invariant and `j < q(n)`, the handler composed with the CPA oracles\n",
     "`bAbs q n ((o, L), j)` with the invariant and `j < q(n)`, the handler composed with the CPA oracles\n"),
]
for f, old, new in EDITS:
    p = D + f
    s = open(p, encoding='utf-8').read()
    c = s.count(old)
    assert c == 1, (f, c)
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
    print('applied', f)
