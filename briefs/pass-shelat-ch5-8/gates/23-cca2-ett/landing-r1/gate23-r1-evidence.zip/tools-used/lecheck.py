"""lecheck.py <repo> <old> <new> <mode>: check a landing edit old..new on .lean files.
mode ws: identical after deleting all whitespace; doc: identical after blanking /-- -/ and /-! -/ comments
(nesting-aware; string literals skipped); imports: only `import` lines added/removed; order: same line multiset."""
import subprocess, sys, re
repo, old, new, mode = sys.argv[1:5]
def git(*a): return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout.decode()
def show(r, p):
    x = subprocess.run(['git', '-C', repo, 'show', f'{r}:{p}'], capture_output=True)
    return x.stdout.decode() if x.returncode == 0 else ''
def blank_doc(s):
    out, i, n = [], 0, len(s)
    while i < n:
        if s.startswith('--', i):
            j = s.find('\n', i); j = n if j < 0 else j; out.append(s[i:j]); i = j; continue
        if s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1; continue
        if s.startswith('/-', i):
            doc = s.startswith('/--', i) or s.startswith('/-!', i)
            d, j = 1, i + 2
            while j < n and d:
                if s.startswith('/-', j): d += 1; j += 2
                elif s.startswith('-/', j): d -= 1; j += 2
                else: j += 1
            out.append('/-DOC-/' if doc else s[i:j]); i = j; continue
        out.append(s[i]); i += 1
    return ''.join(out)
paths = [p for p in git('diff', '--name-only', old, new).split() if p.endswith('.lean')]
others = [p for p in git('diff', '--name-only', old, new).split() if not p.endswith('.lean')]
bad = list(others)
for p in paths:
    a, b = show(old, p), show(new, p)
    if mode == 'ws': ok = re.sub(r'\s', '', a) == re.sub(r'\s', '', b)
    elif mode == 'doc': ok = blank_doc(a) == blank_doc(b)
    elif mode == 'imports':
        da = [l for l in a.splitlines() if not l.startswith('import ')]
        db = [l for l in b.splitlines() if not l.startswith('import ')]
        ok = da == db
    elif mode == 'order': ok = sorted(a.splitlines()) == sorted(b.splitlines())
    if not ok: bad.append(p)
print(f'{mode} {old[:8]}..{new[:8]}: {len(paths)} lean files, non-lean {others}, failing {bad}')
sys.exit(1 if bad else 0)
