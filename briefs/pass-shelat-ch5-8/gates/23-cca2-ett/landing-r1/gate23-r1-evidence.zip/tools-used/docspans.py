"""docspans.py <file>...: every backtick code span inside a /-- -/ or /-! -/ doc comment that names
dAbs, dHandler, bHandler or bAbs (as a whole word), with its line number."""
import re, sys
NAMES = re.compile(r'(?<![\w.])(?:ETTGame\.)?(dAbs|dHandler|bHandler|bAbs)(?![\w_\'])')
def docs(s):
    i, n = 0, len(s)
    while i < n:
        if s.startswith('--', i):
            j = s.find('\n', i); i = n if j < 0 else j; continue
        if s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"': j += 2 if s[j] == '\\' else 1
            i = j + 1; continue
        if s.startswith('/-', i):
            doc = s.startswith('/--', i) or s.startswith('/-!', i)
            d, j = 1, i + 2
            while j < n and d:
                if s.startswith('/-', j): d += 1; j += 2
                elif s.startswith('-/', j): d -= 1; j += 2
                else: j += 1
            if doc: yield i, s[i:j]
            i = j; continue
        i += 1
for f in sys.argv[1:]:
    s = open(f, encoding='utf-8').read()
    for st, d in docs(s):
        for m in re.finditer(r'`([^`]*)`', d):
            if NAMES.search(m.group(1)):
                ln = s.count('\n', 0, st + m.start()) + 1
                print(f'{f.split("/")[-1]}:{ln}: `{m.group(1)}`'.replace('\n', ' '))
