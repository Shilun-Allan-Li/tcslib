import Lean
import TCSlib.Cryptography.Randomness.Learning.Random
/- DLC-SEAL lean_proof_learn_ctl_CtlCoe: whole-file closure seal of `lean_proof/learn/ctl/CtlCoe.lean`, variant A (PolyExpr.eval open), strict. -/
/-- Strip leading lambdas (seal harness). -/
partial def dlcStripLam : Lean.Expr → Lean.Expr
  | .lam _ _ b _ => dlcStripLam b
  | e => e

set_option maxHeartbeats 0 in
run_cmd do
  let env ← Lean.getEnv
  let excl : List Lean.Name := [`Complexity.PolyExpr.eval]
  let coeOpen : Bool := false
  let coeClasses : List Lean.Name := [`CoeFun, `Coe, `CoeSort, `CoeOut, `CoeTail, `CoeHead,
    `CoeTC, `CoeHTCT, `CoeDep]
  let mut sealed : Array Lean.Name := #[]
  let mut abbrevs : Nat := 0
  let mut already : Nat := 0
  let mut excluded : Nat := 0
  let mut coeExcl : Array Lean.Name := #[]
  for (n, ci) in env.constants.map₁.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let m := env.header.moduleNames[mi.toNat]!
    unless (`TCSlib).isPrefixOf m do continue
    let .defnInfo d := ci | continue
    if excl.contains n then
      excluded := excluded + 1
      continue
    if coeOpen && Lean.Meta.isInstanceCore env n then
      let isCoeCls := match d.type.getForallBody.getAppFn.constName? with
        | some c => coeClasses.contains c
        | none => false
      if isCoeCls then
        let body := dlcStripLam d.value
        let args := body.getAppArgs
        let projArg := match args.back? with
          | some a => match (dlcStripLam a).getAppFn.constName? with
            | some p => (env.getProjectionFnInfo? p).isSome
            | none => false
          | none => false
        if projArg then
          coeExcl := coeExcl.push n
          continue
    match d.hints with
    | .abbrev =>
      abbrevs := abbrevs + 1
      continue
    | _ => pure ()
    let st ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if st == .irreducible then
      already := already + 1
      sealed := sealed.push n
      continue
    Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $(Lean.mkIdent n):ident))
    let st' ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless st' == .irreducible do throwError "DLC-SEAL: not sealed {n}"
    sealed := sealed.push n
  Lean.modifyEnv fun cur =>
    Lean.Meta.globalInstanceExtension.modifyState cur fun s => sealed.foldl (fun s n => s.erase n) s
  let env' ← Lean.getEnv
  for n in sealed do
    if Lean.Meta.isGlobalInstance env' n then throwError "DLC-SEAL: instance unfolding kept for {n}"
  Lean.logInfo m!"DLC-SEAL lean_proof_learn_ctl_CtlCoe: sealed={sealed.size} (already irreducible {already}) abbrev-excluded={abbrevs} excluded={excluded} coe-excluded={coeExcl.size} {coeExcl.toList}"


/-! Negative control for the projection coercions: exactly one unfolding of the instance
`FinDist.instCoeFunForallReal` (`⟨FinDist.prob⟩`), written explicitly, by `rfl`. Passes unsealed
and under the coe seals (projection coercions treated as notation); must fail exactly once under
the strict seals. -/

set_option trace.Meta.isDefEq true in
theorem ctl_unfold_coe (p : TCSlib.InformationTheory.FinDist Bool) (b : Bool) :
    @CoeFun.coe (TCSlib.InformationTheory.FinDist Bool) (fun _ => Bool → ℝ)
      TCSlib.InformationTheory.FinDist.instCoeFunForallReal p b = p.prob b := rfl

#eval show Lean.MetaM Unit from do
  let st ← Lean.getReducibilityStatus ``TCSlib.InformationTheory.FinDist.instCoeFunForallReal
  IO.println s!"status {repr st}"
  IO.println s!"isInstance {Lean.Meta.isInstanceCore (← Lean.getEnv) ``TCSlib.InformationTheory.FinDist.instCoeFunForallReal}"
