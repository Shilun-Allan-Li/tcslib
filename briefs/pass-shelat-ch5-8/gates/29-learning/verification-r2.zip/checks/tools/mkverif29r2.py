"""mkverif29r2.py <repo> <rec-rev> <checks-dir> <tools-dir> <out.zip>: Gate 29 round-2 verification-r2.zip. The Gate
24/28 round-2 method (g28r2tools/mkverif28r2.py): byte-identical originals of the round-2 records the outbox does not
already carry as files (git objects at records commit REC, each checked equal to the working tree), plus checks/, the
pack's re-checks generated from git objects alone, with their scripts. Writes PROVENANCE.txt and SHA256SUMS."""
import hashlib, os, subprocess, sys, zipfile

repo, REC, chk, tools, out = sys.argv[1:6]
B = 'briefs/pass-shelat-ch5-8'
SRCS = ['PassShelatChapter5-8Plan.md', f'{B}/duplication-ledger.md', f'{B}/gates/32-headd-promote/resolutions-r1.md',
        f'{B}/fills/learning/final-r1/review.md']
HEAD = '2b6c29816de4cb1cd0e6b74fa3ae848c9f0f1be9'


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


sha = lambda b: hashlib.sha256(b).hexdigest()
members = []
for src in SRCS:
    b = git('show', f'{REC}:{src}')
    assert open(f'{repo}/{src}', 'rb').read() == b, f'working tree differs from {REC[:8]} for {src}'
    members.append((f'records/{src}', b, f'records {REC[:8]}:{src}'))
for c in sorted(os.listdir(chk)):
    members.append((f'checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
for t in ['packchk.py', 'gitlib.py', 'decls2rev.py', 'mkverif29r2.py']:
    members.append((f'checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
prov = f"""Gate 29 round 2 (learning, draft PR #313, Lean head {HEAD}) verification-r2.zip

The round-2 records the pack cites that the outbox does not already carry as files, and the pack's re-checks.
- records/: byte-identical originals from records commit {REC} (each also equal to the working tree):
  - PassShelatChapter5-8Plan.md: the decision log, with the rows of 2026-11-15 (Gate 29 findings in and the G29-02
    ruling; Gate 32 CLOSED by disposition with DL-47 extended; #317 then #316 merged; LE-gate29b done, #313 rebased and
    force-pushed with Seyoon's approval);
  - duplication-ledger.md: DL-45 (the learning overlaps) and DL-47 (the headD/getD copies, pre-existing, with the
    Gate 32 extension and SG-F04);
  - gates/32-headd-promote/resolutions-r1.md: the promotion gate's disposition (#316 unchanged, DL-47 extended);
  - fills/learning/final-r1/review.md: the round-1 maintainer review (as it now stands).
- checks/: generated from git objects alone (nothing was built or run): mergetrees.txt, downstream.txt,
  srcequality.txt and namecheck.txt (the head against the tip and every other open PR), rebase.txt (the range-diff of
  the rebase, the signatures), lecheck.txt (LE-gate29a and LE-gate29b, the headers since round 1, headD_drop_ofFn),
  basemove.txt (the base move since round 1), dupscan.txt (headD/getD reading lines), the decls2 comparisons, and
  tools/ (packchk.py with gitlib.py; decls2rev.py = maintainer/tools/decls2.py's parser on two revisions; this script).
SHA256SUMS lists every entry except itself.

Sources:
""" + ''.join(f'  {p}  <-  {s}\n' for p, _, s in members)
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
members.append(('SHA256SUMS', sums.encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as z:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=(2026, 11, 15, 0, 0, 0))
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
with zipfile.ZipFile(out) as z:
    listed = z.namelist()
    inner = {l.split('  ', 1)[1] for l in z.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == inner | {'SHA256SUMS'} and len(listed) == len(inner) + 1
    for l in z.read('SHA256SUMS').decode().splitlines():
        h, p = l.split('  ', 1)
        assert sha(z.read(p)) == h, p
print(f'OK {len(listed)} entries; sha256 {sha(open(out, "rb").read())}')
