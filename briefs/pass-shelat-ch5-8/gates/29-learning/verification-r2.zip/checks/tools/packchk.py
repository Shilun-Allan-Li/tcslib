"""packchk.py <repo> <29|36|37> <out-dir>: pack re-checks from git objects only (no Lean) for Gate 29 round 2 (#313,
learning), Gate 36 (#323, sc-garble) and Gate 37 (#324, sc-compose). The Gate 33-35 method (g34/tools/pack3435.py),
generalized: every head is trial-merged with the tip and with every other open PR (#313, #318, #319, #323, #324).
Writes mergetrees.txt, downstream.txt, namecheck.txt, rebase.txt, srcequality.txt, lecheck.txt, headers.txt and the
gate's own checks (29: basemove.txt, dupscan.txt; 36: sg1.txt, dagcircuit.txt, yao.txt, dupscan.txt; 37: leprose.txt)."""
import hashlib, io, json, os, re, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls, ws, blank_docs, docs, NM

repo_path, gate, out = sys.argv[1], sys.argv[2], sys.argv[3]
R = Repo(repo_path); rp = R.rp
B = 'briefs/pass-shelat-ch5-8'
TIPREF = 'origin/cryptography/pass-shelat-ch2-4'
TIP = rp(TIPREF)
OPEN = {'#313': rp('origin/land/pass-shelat-learning'), '#318': rp('origin/land/pass-shelat-sc-ot'),
        '#319': rp('origin/land/pass-shelat-canonizer'), '#323': rp('origin/land/pass-shelat-sc-garble'),
        '#324': rp('origin/land/pass-shelat-sc-compose')}
SC = 'TCSlib/Cryptography/SecureComputation'
LRN = 'TCSlib/Cryptography/Randomness/Learning'
CFG = {
    '29': dict(pr='#313', name='learning', head=rp('2b6c29816de4cb1cd0e6b74fa3ae848c9f0f1be9'),
               unit=[f'{LRN}.lean'] + [f'{LRN}/{x}.lean' for x in ('Sample', 'Distinguisher', 'Law', 'Random')],
               owned=[f'{LRN}.lean'], issue=None,
               zip=(f'{B}/gates/29-learning/landing-r2/gate29-le-b-evidence.zip', '', ['build/results.jsonl']),
               built_at=rp('2b6c29816de4cb1cd0e6b74fa3ae848c9f0f1be9')),
    '36': dict(pr='#323', name='sc-garble', head=rp('cd9a48438c2a6548fe9e246ce569be57c9df96b3'),
               unit=[f'{SC}/{x}.lean' for x in (
                   'SpecialEncryptionSecurity', 'SpecialEncryptionMulti', 'Garbling', 'GarblingSecurity', 'Yao',
                   'Garbling/CoinBlocks', 'Garbling/Probability', 'GarblingSecurity/CoinMarginals',
                   'GarblingSecurity/NestedBounds', 'SpecialEncryptionMulti/SliceParser',
                   'SpecialEncryptionMulti/SliceReduction', 'SpecialEncryptionSecurity/Pad',
                   'SpecialEncryptionSecurity/WrongKey')] + ['TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean'],
               owned=[f'{SC}/{x}.lean' for x in ('SpecialEncryptionSecurity', 'SpecialEncryptionMulti', 'Garbling',
                                                 'GarblingSecurity', 'Yao')]
                     + ['TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean'],
               issue=rp('fbd37f447596d4207c8d08b7ef7602f57fe95198'),
               zip=(f'{B}/fills/sc-garble/final-r1/review-evidence.zip', '',
                    ['build/results.jsonl', 'edit-build/results.jsonl']),
               built_at=rp('cd9a48438c2a6548fe9e246ce569be57c9df96b3'),
               exch=rp('a73072f19787ee437f2201777711c7eb3154c714'), wk=rp('e5cb61299'),
               wkhead=rp('81795f776e7de58a6ab112d12fbd5be4e7aaa2f8'), ledoc=rp('cd9a48438c2a6548fe9e246ce569be57c9df96b3')),
    '37': dict(pr='#324', name='sc-compose', head=rp('a6eaebd78c48e7fdfd06263edb84b70bc00ec593'),
               unit=[f'{SC}/ComposeSecurity.lean'] + [f'{SC}/ComposeSecurity/{x}.lean' for x in (
                   'Accept', 'Assembly', 'Bounds', 'Chain', 'Correct', 'Efficiency', 'Lengths', 'Machines',
                   'Probability', 'Reductions', 'Runs', 'SideA', 'SideB', 'Sim', 'Template')],
               owned=[f'{SC}/ComposeSecurity.lean'], issue=rp('107f1e8c218733eac12d6b9bee6fece441271317'),
               zip=(f'{B}/fills/sc-compose/final-r1/review-evidence.zip', '',
                    ['build/results.jsonl', 'edit-build/results.jsonl']),
               built_at=rp('f61ce08fa74401660345f1f50c36dffb37588391'),
               exch=rp('bdfdcb76d0d78bedd61025b33cb7382b26ee7c70'), wk=rp('f3036c690'),
               wkhead=rp('d3f405d4671a3ad0ffd3930ef182a43cb12ed134'), ledoc=rp('f61ce08fa74401660345f1f50c36dffb37588391'),
               leprose=rp('a6eaebd78c48e7fdfd06263edb84b70bc00ec593')),
}[gate]
HEAD, UNIT, OWNED, PR = CFG['head'], CFG['unit'], CFG['owned'], CFG['pr']
assert OPEN[PR] == HEAD, (PR, OPEN[PR], HEAD)
BASE = rp(R.git('merge-base', HEAD, TIP).stdout.strip())
CMP = [('tip', TIP)] + [(k, v) for k, v in OPEN.items() if k != PR]
os.makedirs(out, exist_ok=True)
W = lambda name, L: open(os.path.join(out, name), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
lean = R.lean_changed
assert sorted(lean(BASE, HEAD)) == sorted(UNIT), sorted(set(lean(BASE, HEAD)) ^ set(UNIT))

# 1. merge trees ---------------------------------------------------------------------------------------------------
L = [f'PR {PR} ({CFG["name"]}) head {HEAD}; merge base with the tip {TIP} ({TIPREF}): {BASE}',
     f'{PR} changed .lean paths ({BASE[:8]}..head, {len(UNIT)}): {sorted(lean(BASE, HEAD))}',
     f'tip .lean delta since the merge base ({BASE[:8]}..{TIP[:8]}): {lean(BASE, TIP)}',
     'open PR heads (origin branch refs at the time of this check): '
     + ', '.join(f'{k} {v}' for k, v in OPEN.items()), '']
trees, changed, mb = {}, {}, {}
for k, v in CMP:
    mb[k] = rp(R.git('merge-base', HEAD, v).stdout.strip())
    changed[k] = lean(mb[k], v)
    t, rc, raw = R.mergetree(HEAD, v); trees[k] = t
    L.append(f'git merge-tree --write-tree {HEAD} {v} ({k}): tree {t} rc {rc} ({"clean" if rc == 0 else "CONFLICT"})')
    if rc:
        L.append(raw)
    dh = [p for p in R.git('diff', '--name-only', HEAD, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    do = [p for p in R.git('diff', '--name-only', v, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    L.append(f'  Lean paths of the merged tree differing from the {PR} head ({len(dh)}): {dh}')
    L.append(f'  and from {k} ({len(do)}): {do}')
    shared = sorted(set(changed[k]) & set(UNIT))
    L.append(f'  merge base {mb[k]}; {k} changed .lean paths from it: {len(changed[k])}; shared with {PR}: {shared}')
    if k != 'tip':
        mine = set(lean(mb[k], HEAD))
        L.append(f'  {PR} .lean paths from that merge base: {len(mine)}; of them outside the {PR} unit (base delta of one '
                 f'side): {len(mine - set(UNIT))}')
W('mergetrees.txt', L)

# 2. downstream ----------------------------------------------------------------------------------------------------
gh = R.graph(HEAD)
uclo = set().union(*[closure(gh, [p]) for p in UNIT])
L = [f'# import graph at the {PR} head {HEAD[:8]} (TCSlib and audits modules); a module counts as downstream of itself',
     f'unit modules: {len(UNIT)}; union of their import closures: {len(uclo)} modules']
shared_down = {}
for k, v in CMP:
    ch = set(changed[k])
    up = sorted(ch & uclo)
    L.append(f'{k} ({v[:8]}): its changed modules (from the merge base {mb[k][:8]}) inside the unit closure: {up}')
    gm = R.graph(trees[k])
    both = sorted(downstream(gm, set(UNIT)) & downstream(gm, ch - set(UNIT)))
    shared_down[k] = both
    L.append(f'  merged tree {trees[k][:8]}: {len(both)} modules downstream of both a {PR} module and a {k} module: '
             f'{[p[:-5] for p in both]}')
W('downstream.txt', L)

# 3. source equality of the review / landing build ---------------------------------------------------------------
zp, pre, parts = CFG['zip']
z = zipfile.ZipFile(os.path.join(repo_path, zp))
final = {}
nrec = []
for part in parts:
    rows = [json.loads(l) for l in z.read(pre + part).decode().splitlines() if l.strip()]
    mods = [x for x in rows if 'module' in x]
    nrec.append((part, len(mods), sum(x['rc'] == 0 for x in mods), sum(x['errors'] for x in mods),
                 sum(x.get('errors_diag', x.get('error_substr', 0)) for x in mods), 'done' in rows[-1]))
    for x in mods:
        final[x['module']] = x
L = [f'{zp} (SHA-256 {hashlib.sha256(open(os.path.join(repo_path, zp), "rb").read()).hexdigest()}):']
L += [f'  {p}: {n} module records, rc 0 {ok}, errors {e}, second form {e2}, last record "done": {d}'
      for p, n, ok, e, e2, d in nrec]
L.append(f'  modules (later records override earlier): {len(final)}; unit modules built: '
         f'{sorted(set(m + ".lean" for m in final) & set(UNIT)) == sorted(UNIT)}')
for k, rev in [('built revision ' + CFG['built_at'][:8], CFG['built_at']), ('head', HEAD)] + \
        [(f'merged with {k}', trees[k]) for k, _ in CMP]:
    diff = [m for m, x in final.items()
            if hashlib.sha256(R.blob(rev, m + '.lean') or b'').hexdigest() != x['source_sha256']]
    L.append(f'{k} {rev[:8]}: {len(final) - len(diff)} built sources equal, {len(diff)} differ {diff}')
W('srcequality.txt', L)

# 4. names ---------------------------------------------------------------------------------------------------------
new = sorted({n for p in UNIT for n in NM.findall(R.show(HEAD, p))} - {n for p in UNIT for n in NM.findall(R.show(BASE, p))})
L = [f'# the {len(new)} declaration names new at the head (short names as written) against the declarations of the '
     f'.lean files each comparator changed since its merge base with the head (unit files excluded)']
for k, v in CMP:
    hits = []
    for p in changed[k]:
        if p in UNIT:
            continue
        for i, l in enumerate(R.show(v, p).splitlines()):
            m = NM.match(l)
            if m and m.group(1) in new:
                hits.append(f'{p}:{i + 1}: {l.strip()[:120]}')
    L.append(f'{k} ({len(changed[k])} changed files): {len(hits)} declarations with a new name')
    L += ['    ' + h for h in hits]
W('namecheck.txt', L)


# 5. headers of the pre-existing declarations ----------------------------------------------------------------------
def hdrcmp(old, new_, files, label):
    L = [f'# {label}: every declaration (private included) at {old[:8]} against {new_[:8]}; header = keyword line to the '
         f'top-level := for theorems, the whole block for definitions, with any open/include/omit … in prefix']
    tot = {}
    for f in files:
        a, b = decls(R.show(old, f)), decls(R.show(new_, f))
        if not a:
            L.append(f'## {f}: new file, {len(b)} declarations'); continue
        same = [n for n in a if n in b and a[n][2] == b[n][2]]
        ch = [n for n in a if n in b and a[n][2] != b[n][2]]
        gone = [n for n in a if n not in b]
        dch = [n for n in a if n in b and a[n][3] != b[n][3]]
        order = [n for n in b if n in a] == [n for n in a if n in b]
        L.append(f'## {f}: base {len(a)}, head {len(b)}; headers identical {len(same)}, differing {ch}, removed {gone}; '
                 f'order kept {order}; docstrings changed {dch}; new {[n for n in b if n not in a]}')
        defs = [n for n in a if a[n][0] not in ('theorem', 'lemma') and n in b]
        L.append(f'   definitions (def/abbrev/structure/inductive/instance/class): {len(defs)}, blocks byte-identical '
                 f'{sum(a[n][2] == b[n][2] for n in defs)}')
        tot[f] = (a, b, ch, gone, dch)
    return L, tot


# 6. landing edits -------------------------------------------------------------------------------------------------
def doc_only(a, b, label):
    fs = lean(a, b)
    L = [f'{label} {a[:8]}..{b[:8]}: {len(fs)} files; numstat {R.git("diff", "--numstat", a, b).stdout.split()}']
    tot = 0
    for p in fs:
        x, y = R.show(a, p), R.show(b, p)
        dx, dy = docs(x), docs(y)
        n = sum(u != v for u, v in zip(dx, dy)) if len(dx) == len(dy) else None
        tot += n or 0
        L.append(f'  {p.split("/")[-1]}: identical with doc comments deleted: {blank_docs(x) == blank_docs(y)}; '
                 f'docstrings {len(dx)} -> {len(dy)}, changed {n}; module docs changed '
                 f'{sum(u != v for u, v in zip(re.findall(r"/-!.*?-/", x, flags=re.S), re.findall(r"/-!.*?-/", y, flags=re.S)))}'
                 f'; max width {max(len(l) for l in y.splitlines())}')
    L.append(f'  docstrings changed in total: {tot}')
    return L


def series(a, b):
    L = []
    for c in R.git('rev-list', '--reverse', f'{a}..{b}').stdout.split():
        o = R.git('cat-file', '-p', c).stdout
        L.append(f'  {c} gpgsig {len(re.findall(r"(?m)^gpgsig", o))} | '
                 f'{R.git("log", "-1", "--format=author %an | committer %cn <%ce> | %s", c).stdout.strip()}')
    return L


# ===================================================================================================================
if gate == '29':
    R1H, R1B = rp('8befc58966fd39f974a54250849736df194584b9'), rp('4561c3407f9f015da55255a6a4cbcfc5840fd1f3')
    LEA, LEAR = rp('94b31964ee94b97bf3ed3b4b4338cacae8183194'), rp('9b40c7cee')
    R1TIP = rp('f52a24be7442013d00bef3608ce5336429dd4719')
    # rebase and series
    L = ['# rebase identity, the landing edits, the signatures']
    r = R.git('range-diff', f'{R1B}..{LEA}', f'{BASE}..{LEAR}').stdout
    L.append(f'git range-diff {R1B[:8]}..{LEA[:8]} (round-1 head 8befc589 + LE-gate29a) {BASE[:8]}..{LEAR[:8]}:')
    L += ['  ' + x for x in r.splitlines()]
    L.append(f'unit files byte-identical at {LEA[:8]} and {LEAR[:8]}: '
             f'{all(R.blob(LEA, p) == R.blob(LEAR, p) for p in UNIT)}')
    L.append(f'git diff {R1H[:8]} {LEA[:8]} (LE-gate29a, original): '
             f'{R.git("diff", "--numstat", R1H, LEA).stdout.split()}')
    L.append(f'patch of LE-gate29a = patch of its rebased commit {LEAR[:8]}: '
             f'{R.git("diff", R1H, LEA).stdout == R.git("diff", rp(LEAR + "^"), LEAR).stdout}')
    L.append(f'commits {BASE[:8]}..{HEAD[:8]}:')
    L += series(BASE, HEAD)
    W('rebase.txt', L)
    # landing edits
    L = ['# the two resolution edits since round 1 (round-1 head 8befc589)']
    for a, b, lab in [(R1H, LEA, 'LE-gate29a (original)'), (LEAR, HEAD, 'LE-gate29b')]:
        fs = lean(a, b)
        d = R.git('diff', '-U0', a, b).stdout
        L.append(f'{lab} {a[:8]}..{b[:8]}: files {fs}; numstat {R.git("diff", "--numstat", a, b).stdout.split()}')
        L.append('  hunks: ' + ' | '.join(h.strip() for h in re.findall(r'(?m)^@@ .*? @@(.*)$', d)))
        L += ['  ' + x for x in d.splitlines() if x[:1] in '+-' and not x.startswith(('+++', '---'))]
        for p in fs:
            x, y = decls(R.show(a, p)), decls(R.show(b, p))
            L.append(f'  {p.split("/")[-1]}: {len(x)} declarations; headers differing '
                     f'{[n for n in x if x[n][2] != y.get(n, (0, 0, None))[2]]}; docstrings changed '
                     f'{[n for n in x if x[n][3] != y.get(n, (0, 0, 0, None))[3]]}; imports identical '
                     f'{re.findall(r"(?m)^import .*", R.show(a, p)) == re.findall(r"(?m)^import .*", R.show(b, p))}')
    hl, _ = hdrcmp(R1H, HEAD, UNIT, f'round-1 head {R1H[:8]} -> round-2 head')
    L += [''] + hl
    bl = 'TCSlib/Cryptography/Foundations/BitLists.lean'
    L.append('')
    L.append(f'TCSlib.Cryptography.headD_drop_ofFn at the tip and the head: '
             f'{[f"{bl}:{i + 1}: {l.strip()}" for i, l in enumerate(R.show(HEAD, bl).splitlines()) if "theorem headD_drop_ofFn" in l]}; '
             f'BitLists blob tip = head: {R.blob(TIP, bl) == R.blob(HEAD, bl)}; in the import closure of Random at the head: '
             f'{bl in closure(gh, [f"{LRN}/Random.lean"])}; in it at the round-1 head: '
             f'{bl in closure(R.graph(R1H), [f"{LRN}/Random.lean"])}')
    ms = 'TCSlib/Cryptography/Authentication/Signatures/Lamport/MachineSpec.lean'
    L.append(f'LamportFill.headD_drop_ofFn at the head: '
             f'{[f"{ms}:{i + 1}: {l.strip()}" for i, l in enumerate(R.show(HEAD, ms).splitlines()) if "headD_drop_ofFn" in l]}')
    W('lecheck.txt', L)
    # base move
    L = [f'# the PR base moved from {R1B[:8]} (round 1) to {BASE[:8]}; round 1 audited against the records tip '
         f'{R1TIP[:8]}', f'first-parent merges {R1B[:8]}..{BASE[:8]}:']
    for c in R.git('log', '--merges', '--first-parent', '--format=%H %s', f'{R1B}..{BASE}').stdout.splitlines():
        h = c.split()[0]
        L.append(f'  {c[:110]}; in the round-1 tip {R1TIP[:8]}: {R.anc(h, R1TIP)}')
    d1 = lean(R1B, BASE)
    L.append(f'.lean delta {R1B[:8]}..{BASE[:8]} ({len(d1)}): {d1}')
    d2 = lean(R1TIP, BASE)
    L.append(f'.lean delta since the round-1 records tip {R1TIP[:8]}..{BASE[:8]} ({len(d2)}): {d2}')
    L.append(f'  of these, in the unit closure at the head: {sorted(set(d1) & uclo)}')
    L.append(f'  unit closure at the head: {len(uclo)} modules; at the round-1 head: '
             f'{len(set().union(*[closure(R.graph(R1H), [p]) for p in UNIT]))}')
    W('basemove.txt', L)

if gate in ('36', '37'):
    ISS, WK, WKH, EX, LED = CFG['issue'], CFG['wk'], CFG['wkhead'], CFG['exch'], CFG['ledoc']
    # rebase
    L = ['# the landing: rebase identity, the worker src/, the signatures']
    r = R.git('range-diff', f'{ISS}..{WKH}', f'{BASE}..{WK}').stdout
    L.append(f'git range-diff {ISS[:8]}..{WKH[:8]} (the worker series at the issue base) {BASE[:8]}..{WK[:8]} '
             f'(the landing before the edits):')
    L += ['  ' + x for x in r.splitlines()]
    for p in UNIT:
        w = R.blob(EX, f'inbox/fills/{CFG["name"]}/src/{p}')
        L.append(f'{p.split("/")[-1]}: worker src/ (exchange {EX[:8]}) = landing worker head {WK[:8]}: {w == R.blob(WK, p)}'
                 f'; = worker head {WKH[:8]}: {w == R.blob(WKH, p)}')
    src = R.git('ls-tree', '-r', '--name-only', EX, f'inbox/fills/{CFG["name"]}/src').stdout.split()
    L.append(f'src/ holds {len(src)} files; the landing changes {len(lean(BASE, WK))} .lean paths before the edits')
    L.append(f'the {len(UNIT)} paths at the issue base = at the landing base {BASE[:8]}: '
             f'{all(R.blob(ISS, p) == R.blob(BASE, p) for p in UNIT)}')
    L.append(f'.lean delta issue base {ISS[:8]} -> landing base {BASE[:8]}: {lean(ISS, BASE)}')
    L.append(f'commits {BASE[:8]}..{HEAD[:8]}:')
    L += series(BASE, HEAD)
    W('rebase.txt', L)
    # headers
    hl, tot = hdrcmp(ISS, HEAD, OWNED, f'issue base {ISS[:8]} -> head')
    W('headers.txt', hl)
    # LE
    L = ['# the landing edits from git objects'] + doc_only(WK, LED, 'LE-doc')
    if gate == '37':
        L += doc_only(LED, CFG['leprose'], 'LE-prose')
    W('lecheck.txt', L)

if gate == '36':
    SEM = f'{SC}/SpecialEncryptionMulti.lean'
    a, b, ch, gone, dch = tot[SEM]
    SIX = ['specialScheme_gen_runAt', 'specialScheme_enc_runAt', 'specialKeyEq', 'ofFn_specialKeyEq', 'specialNonceEq',
           'ofFn_specialNonceEq']
    L = ['# ruling SG-1: SpecialEncryptionMulti.lean, issue base -> head (private declarations included)',
         f'removed: {gone}; = the six SG-1 names exactly: {sorted(gone) == sorted(SIX)}; each private at the base: '
         f'{[a[n][4] for n in SIX]}',
         f'headers differing: {ch} (0 CHANGED: {ch == []})',
         f'docstrings changed: {dch}',
         f'zipWith_xor_append_of_le present at the head: {"zipWith_xor_append_of_le" in b}']
    oj = 'specialScheme_multiMessageSecure_of_joint'
    L.append(f'{oj}: header byte-identical {a[oj][2] == b[oj][2]}; docstring byte-identical {a[oj][3] == b[oj][3]}')

    def body(text, name):
        Ls = text.split('\n'); d = decls(text); i = d[name][1] - 1; j = i + 1
        while j < len(Ls) and not (Ls[j].startswith(('theorem', 'lemma', 'def', 'private', '/--', 'end ', 'section',
                                                        '/-!', 'noncomputable', '@[', 'abbrev', 'open', 'include'))):
            j += 1
        return '\n'.join(Ls[i:j]).rstrip()
    ob, nb = body(R.show(ISS, SEM), oj), body(R.show(HEAD, SEM), oj)
    L.append(f'{oj} text (keyword to the next declaration), base {len(ob.splitlines())} lines, head '
             f'{len(nb.splitlines())} lines:')
    L += ['  - ' + x for x in ob.splitlines()] + ['  + ' + x for x in nb.splitlines()]
    for n in SIX:
        g = R.git('grep', '-n', '-w', n, HEAD, '--', 'TCSlib', 'audits', check=False).stdout.splitlines()
        g0 = R.git('grep', '-n', '-w', n, ISS, '--', 'TCSlib', 'audits', check=False).stdout.splitlines()
        L.append(f'  {n}: occurrences at the issue base in files {sorted({x.split(":")[1] for x in g0})}; at the head '
                 f'{len(g)} in {sorted({x.split(":")[1] for x in g})}')
    sesn = f'{SC}/SpecialEncryptionSecurity.lean'
    L.append(f'public readers now in SpecialEncryptionSecurity.lean (new at the head): '
             f'{[n for n in decls(R.show(HEAD, sesn)) if n not in decls(R.show(ISS, sesn))]}')
    for f in OWNED:
        x, y, c, gn, dc = tot[f]
        L.append(f'{f.split("/")[-1]}: base {len(x)} declarations; CHANGED headers {c}; REMOVED {gn}')
    L.append(f'base declarations in the 5 owned files: {sum(len(tot[f][0]) for f in OWNED[:5])}; in DAGCircuit: '
             f'{len(tot[OWNED[5]][0])}')
    W('sg1.txt', L)
    # DAGCircuit
    DG = 'TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean'
    d = R.git('diff', '-U3', ISS, HEAD, '--', DG).stdout
    plus = [x[1:] for x in d.splitlines() if x.startswith('+') and not x.startswith('+++')]
    minus = [x for x in d.splitlines() if x.startswith('-') and not x.startswith('---')]
    pat = R.show(EX, 'inbox/fills/sc-garble/evidence/scope-request/fanin-reader.patch')
    pplus = [x[1:] for x in pat.splitlines() if x.startswith('+') and not x.startswith('+++')]
    pminus = [x for x in pat.splitlines() if x.startswith('-') and not x.startswith('---')]
    L = [f'# the one frozen-file change: {DG}, issue base {ISS[:8]} -> head',
         f'hunks {re.findall(r"(?m)^@@ .*? @@", d)}; {len(plus)} added lines, {len(minus)} removed']
    L += ['  + ' + x for x in plus]
    L.append(f'added lines = the approved patch evidence/scope-request/fanin-reader.patch (exchange {EX[:8]}) added '
             f'lines: {plus == pplus}; removed lines both empty: {minus == [] and pminus == []}')
    hs = R.show(HEAD, DG).splitlines(keepends=True)
    k0 = int(re.match(r'@@ -\S+ \+(\d+)', re.findall(r'(?m)^@@ .*? @@', R.git('diff', '-U0', ISS, HEAD, '--', DG).stdout)[0]).group(1)) - 1
    L.append(f'head file with the added lines cut out = the base file byte for byte: '
             f'{"".join(hs[:k0] + hs[k0 + len(plus):]) == R.show(ISS, DG)}')
    dd = [n for n in decls(R.show(HEAD, DG)) if n not in decls(R.show(ISS, DG))]
    L.append(f'new declarations: {dd}')
    sy = R.git('grep', '-n', 'isFaninTwo_iff', TIP, '--', f'{B}/fills/sc-yao', check=False).stdout.splitlines()
    L.append(f'sc-yao issued-r1 mentions of isFaninTwo_iff at the tip: {len(sy)}')
    for f in R.git('ls-tree', '-r', '--name-only', TIP, f'{B}/fills/sc-yao/issued-r1').stdout.split():
        if f.endswith(('.patch', '.diff')):
            t = R.show(TIP, f)
            tp = [x[1:] for x in t.splitlines() if x.startswith('+') and not x.startswith('+++')]
            L.append(f'  {f}: added lines = #323 DAGCircuit added lines: {tp == plus}')
    W('dagcircuit.txt', L)
    # Yao
    Y = f'{SC}/Yao.lean'
    d = R.git('diff', '-U0', ISS, HEAD, '--', Y).stdout
    yb, yh = decls(R.show(ISS, Y)), decls(R.show(HEAD, Y))
    L = [f'# Yao.lean (shared with sc-yao), issue base -> head: {len(R.show(ISS, Y).splitlines())} -> '
         f'{len(R.show(HEAD, Y).splitlines())} lines; hunks:']
    hl_ = R.show(HEAD, Y).split('\n')
    tgt = yh['yaoSeed_good_whp'][1]
    for h in re.findall(r'(?m)^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', d):
        s, n = int(h[2]), int(h[3] or 1)
        prev = [x for x in yh.values() if x[1] <= s + max(n, 1)]
        L.append(f'  head lines {s}-{s + n - 1}: {hl_[s - 1][:80]!r}')
    L.append(f'declarations other than yaoSeed_good_whp with changed header or docstring: '
             f'{[n for n in yb if n != "yaoSeed_good_whp" and (yb[n][2:4] != yh.get(n, (0, 0, 0, 0))[2:4])]}')
    L.append(f'yaoSeed_good_whp header identical: {yb["yaoSeed_good_whp"][2] == yh["yaoSeed_good_whp"][2]}; head line '
             f'{tgt}; imports identical: {re.findall(r"(?m)^import .*", R.show(ISS, Y)) == re.findall(r"(?m)^import .*", R.show(HEAD, Y))}; '
             f'declaration names identical: {list(yb) == list(yh)}')
    W('yao.txt', L)

# duplication scan of the added lines (29, 36, 37) ---------------------------------------------------------------------
PAT = re.compile(r'headD_drop\b|getD_eq_getElem\?_getD|getElem\?_ofFn|getD_eq_getElem\b|getElem_ofFn|headD_ofFn|'
                 r'head\?_drop|getD_ofFn|ofFn_succ.*headD|headD.*ofFn_succ|List\.headD_cons')
base_for_dup = rp('8befc58966fd39f974a54250849736df194584b9') if gate == '29' else BASE
L = [f'# lines added {BASE[:8]}..{HEAD[:8]} that use a headD/getD-of-List.ofFn reading lemma (the DL-47 class)']
for p in UNIT:
    d = R.git('diff', '-U0', BASE, HEAD, '--', p).stdout
    ln = 0
    for x in d.splitlines():
        m = re.match(r'@@ -\S+ \+(\d+)', x)
        if m:
            ln = int(m.group(1)); continue
        if x.startswith('+') and not x.startswith('+++'):
            if PAT.search(x):
                L.append(f'  {p}:{ln}: {x[1:].strip()[:140]}')
            ln += 1
if gate == '29':
    L.append(f'# and since round 1 ({base_for_dup[:8]}..{HEAD[:8]}):')
    for p in UNIT:
        d = R.git('diff', '-U0', base_for_dup, HEAD, '--', p).stdout
        L += [f'  {p}: +{x[1:].strip()[:140]}' for x in d.splitlines()
              if x.startswith('+') and not x.startswith('+++') and PAT.search(x)]
        L += [f'  {p}: -{x[1:].strip()[:140]}' for x in d.splitlines()
              if x.startswith('-') and not x.startswith('---') and PAT.search(x)]
W('dupscan.txt', L)

if gate == '37':
    CS = f'{SC}/ComposeSecurity.lean'
    a_, b_ = R.show(CFG['ledoc'], CS), R.show(HEAD, CS)
    x, y = decls(a_), decls(b_)
    L = [f'# LE-prose {CFG["ledoc"][:8]}..{HEAD[:8]} (SC-F03): {CS}',
         f'diff: {R.git("diff", "--numstat", CFG["ledoc"], HEAD).stdout.split()}',
         f'identical with doc comments deleted: {blank_docs(a_) == blank_docs(b_)}',
         f'declarations whose docstring changed: {[n for n in x if x[n][3] != y[n][3]]}; headers changed: '
         f'{[n for n in x if x[n][2] != y[n][2]]}']
    L += ['  ' + l for l in R.git('diff', '-U0', CFG['ledoc'], HEAD).stdout.splitlines()
          if l[:1] in '+-' and not l.startswith(('+++', '---'))]
    L.append(f'polyTime_compose docstring at the issue base = at LE-doc {CFG["ledoc"][:8]}: '
             f'{decls(R.show(CFG["issue"], CS))["polyTime_compose"][3] == x["polyTime_compose"][3]}')
    L.append(f'built at {CFG["built_at"][:8]} (the review build and edit-build); not rebuilt at {HEAD[:8]}: the one '
             f'source that differs is {CS} (srcequality.txt)')
    W('leprose.txt', L)

print('OK', gate, BASE[:8], {k: (v[:8], len(shared_down[k])) for k, v in trees.items()})
