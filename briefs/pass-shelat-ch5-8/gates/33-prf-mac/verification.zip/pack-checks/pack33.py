"""pack33.py <repo> <out-dir>: Gate 33 (#317, prf-mac, Theorem 135.4) re-checks from git objects only (no Lean).
Writes mergetrees.txt, downstream.txt, headers.txt, lecheck.txt, srcequality.txt and rebase.txt."""
import hashlib, io, json, os, re, subprocess, sys, zipfile
repo, out = sys.argv[1:3]
def git(*a, check=True):
    return subprocess.run(['git', '-C', repo, *a], check=check, capture_output=True, text=True)
def gitb(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout
rp = lambda r: git('rev-parse', r).stdout.strip()
HEAD = rp('590d1a56a350d9e8e75ee33d31e0501182169f67'); LEDOC = rp('997dd8caeb8e9dfdde28da4b85f70467fed9c998')
WK = rp('404da63de0429501dd8929cd840f7e2637d5acf2'); BASE = rp('e99987221593020b9f7dbb87fe577bd6aac5ecbb')
ISSUE = rp('107f1e8c218733eac12d6b9bee6fece441271317'); REVHEAD = rp('bd45faecffa420497557dfeba9e2818d7d3cf4a3')
REVBASE = rp('e7fa2605318a303fd46ad8360cd8593e75a5f81b'); EXCH = rp('51ae2c1215554ccda3dde19d8d72908ea74dd339')
OPEN = {'#313': rp('94b31964ee94b97bf3ed3b4b4338cacae8183194'), '#315': rp('fbd37f447596d4207c8d08b7ef7602f57fe95198'),
        '#316': rp('c18afbe66101381eed1617801d942dcf691506ea')}
U = 'TCSlib/Cryptography/Authentication/MAC/FromPRF'
UNIT = [f'{U}.lean'] + [f'{U}/{x}.lean' for x in ('Bound', 'Game', 'Handler', 'Random', 'Reduction')]
show = lambda rev, p: git('show', f'{rev}:{p}', check=False).stdout
lean = lambda a, b: [p for p in git('diff', '--name-only', '--no-renames', a, b).stdout.split() if p.endswith('.lean')]
def graph(rev):
    g = {}
    for p in git('ls-tree', '-r', '--name-only', rev).stdout.split():
        if p.endswith('.lean') and p.startswith(('TCSlib', 'audits')):
            g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', show(rev, p))
                    if m.startswith(('TCSlib', 'audits'))]
    return g
def closure(g, roots):
    seen, st = set(), list(roots)
    while st:
        x = st.pop()
        if x in seen or x not in g: continue
        seen.add(x); st.extend(g[x])
    return seen

# 1. merge trees
mb = {k: rp(git('merge-base', HEAD, v).stdout.strip()) for k, v in OPEN.items()}
changed = {k: lean(mb[k], v) for k, v in OPEN.items()}
L = [f'PR #317 head {HEAD}; PR base {BASE} (= merge base with the tip {rp("origin/cryptography/pass-shelat-ch2-4")}: '
     f'{rp(git("merge-base", HEAD, "origin/cryptography/pass-shelat-ch2-4").stdout.strip())})',
     f'#317 changed .lean paths (base..head): {lean(BASE, HEAD)}', '']
trees = {}
for k, v in [('tip', rp('origin/cryptography/pass-shelat-ch2-4'))] + list(OPEN.items()):
    r = git('merge-tree', '--write-tree', '--name-only', HEAD, v, check=False)
    t = r.stdout.split('\n')[0]; trees[k] = t
    L.append(f'git merge-tree --write-tree {HEAD} {v} ({k}): {t} rc {r.returncode}')
    if r.returncode: L.append(r.stdout)
    dh = [p for p in git('diff', '--name-only', HEAD, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    do = [p for p in git('diff', '--name-only', v, t).stdout.split() if p.startswith(('TCSlib', 'audits'))]
    L.append(f'  Lean paths of the merged tree differing from the #317 head ({len(dh)}): {dh}')
    L.append(f'  and from {k} ({len(do)}): {do}')
L.append('')
for k in OPEN:
    L.append(f'{k} head {OPEN[k]}: merge base with #317 {mb[k]}; changed .lean paths from it: {changed[k]}; '
             f'shared with #317: {sorted(set(changed[k]) & set(UNIT))}')
open(os.path.join(out, 'mergetrees.txt'), 'w').write('\n'.join(L) + '\n')

# 2. downstream: unit modules vs the other open PRs' changed modules (head graph and merged-tree graphs)
gh = graph(HEAD)
L = [f'# graph at the #317 head {HEAD[:8]} (TCSlib and audits modules); a module counts as downstream of itself']
clo = {p: closure(gh, [p]) for p in UNIT}
for k in OPEN:
    hit = {p: sorted(set(changed[k]) & clo[p]) for p in UNIT}
    L.append(f'{k}: changed modules in the closure of a #317 unit module: '
             f'{sorted(set().union(*hit.values()))}')
    for p in UNIT:
        L.append(f'    {p.split("/")[-1]}: {len(hit[p])}')
    gm = graph(trees[k])
    both = sorted(p for p in gm if (set(UNIT) & closure(gm, [p])) and (set(changed[k]) & closure(gm, [p])))
    L.append(f'  in the merged tree {trees[k][:8]}: {len(both)} modules downstream of both a #317 module and a {k} module')
open(os.path.join(out, 'downstream.txt'), 'w').write('\n'.join(L) + '\n')

# 3. headers and docstrings of the owned file's base declarations, issue base -> head; new-file declarations listed
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)')
def decls(text):
    Ls = text.split('\n'); res = {}
    for i, l in enumerate(Ls):
        m = KW.match(l)
        if not m: continue
        kind, name = m.groups(); j = i
        while j < len(Ls) and Ls[j].strip() != '': j += 1
        block = '\n'.join(Ls[i:j])
        if kind in ('theorem', 'lemma'):
            d, cut = 0, None
            for k, ch in enumerate(block):
                if ch in '([{⟨': d += 1
                elif ch in ')]}⟩': d -= 1
                elif d == 0 and block.startswith(':=', k): cut = k; break
            block = block[:cut] if cut is not None else block
        k = i - 1; doc = ''
        if k >= 0 and Ls[k].rstrip().endswith('-/'):
            s = k
            while s >= 0 and '/--' not in Ls[s]: s -= 1
            doc = '\n'.join(Ls[s:k + 1])
        res[name] = (kind, i + 1, block, doc)
    return res
L = [f'# owned file: every base declaration at the issue base {ISSUE[:8]} and at the PR base {BASE[:8]} against the head '
     f'{HEAD[:8]} (header = keyword line to the top-level := for theorems, the whole block for definitions)']
own = UNIT[0]
L.append(f'owned file blob at {ISSUE[:8]} = at {BASE[:8]}: {show(ISSUE, own) == show(BASE, own)}')
a, b = decls(show(BASE, own)), decls(show(HEAD, own))
for n in a:
    ka, la, ha, da = a[n]; kb, lb, hb, db = b.get(n, (None,) * 4)
    L.append(f'{"IDENTICAL" if ha == hb else "DIFF"}\theader\t{ka} {n}\t{la}->{lb}\tdocstring '
             f'{"identical" if da == db else "changed"}')
L.append(f'order kept: {[n for n in b if n in a] == list(a)}; base {len(a)}, head {len(b)}')
for p in UNIT[1:]:
    L.append(f'{p}: new file (absent at {BASE[:8]}: {show(BASE, p) == ""}), {len(decls(show(HEAD, p)))} named declarations (an anonymous instance is not counted)')
open(os.path.join(out, 'headers.txt'), 'w').write('\n'.join(L) + '\n')

# 4. landing edits
def blank_docs(t): return re.sub(r'/-[-!].*?-/', '', t, flags=re.S)
L = ['# landing edits from git objects']
fs = lean(WK, LEDOC)
L.append(f'LE-doc {WK[:8]}..{LEDOC[:8]}: {len(fs)} files {fs}')
for p in fs:
    L.append(f'  {p.split("/")[-1]}: identical with doc comments (/-- -/, /-! -/) deleted: {blank_docs(show(WK, p)) == blank_docs(show(LEDOC, p))}')
fs = lean(LEDOC, HEAD)
L.append(f'LE-reuse {LEDOC[:8]}..{HEAD[:8]}: {len(fs)} files {fs}; numstat {git("diff", "--numstat", LEDOC, HEAD).stdout.strip()}')
d = git('diff', '-U0', LEDOC, HEAD).stdout
hunks = re.findall(r'(?m)^@@ .*? @@(.*)$', d)
L.append(f'  hunks: {len(hunks)}; hunk contexts: {[h.strip()[:60] for h in hunks]}')
a, b = decls(show(LEDOC, fs[0])), decls(show(HEAD, fs[0]))
for n in a:
    L.append(f'  {n}: header {"identical" if a[n][2] == b[n][2] else "DIFF"}; docstring '
             f'{"identical" if a[n][3] == b[n][3] else "changed"}')
L.append(f'  imports identical: {re.findall(r"(?m)^import .*", show(LEDOC, fs[0])) == re.findall(r"(?m)^import .*", show(HEAD, fs[0]))}')
L.append(f'  names in the head file: prfAdv_eq_expect {show(HEAD, fs[0]).count("prfAdv_eq_expect")}, '
         f'prfAdv_def {show(HEAD, fs[0]).count("prfAdv_def")}, Bridge.acceptGame_eq {show(HEAD, fs[0]).count("Bridge.acceptGame_eq")} '
         f'(the remaining occurrences are in the docstring sketch)')
open(os.path.join(out, 'lecheck.txt'), 'w').write('\n'.join(L) + '\n')

# 5. rebase and worker sources
L = ['# rebase identity and the worker src/']
r = git('range-diff', f'{REVBASE}..{REVHEAD}', f'{BASE}..{LEDOC}').stdout
L.append(f'git range-diff {REVBASE[:8]}..{REVHEAD[:8]} (the review head) {BASE[:8]}..{LEDOC[:8]}:'); L += ['  ' + x for x in r.splitlines()]
L.append(f'unit diff review head {REVHEAD[:8]} vs LE-doc {LEDOC[:8]}: '
         f'{"empty" if not git("diff", REVHEAD, LEDOC, "--", *UNIT).stdout else "NONEMPTY"}')
for p in UNIT:
    w = gitb('show', f'{EXCH}:inbox/fills/prf-mac/src/{p}')
    L.append(f'{p.split("/")[-1]}: worker src/ (exchange {EXCH[:8]}) = {WK[:8]}: {w == gitb("show", f"{WK}:{p}")}')
src = [x for x in git('ls-tree', '-r', '--name-only', EXCH, 'inbox/fills/prf-mac/src').stdout.split()]
L.append(f'src/ holds {len(src)} files')
L.append(f'commits {BASE[:8]}..{HEAD[:8]}:')
for c in git('rev-list', '--reverse', f'{BASE}..{HEAD}').stdout.split():
    o = git('cat-file', '-p', c).stdout
    L.append(f'  {c} gpgsig {len(re.findall(r"(?m)^gpgsig", o))} | {git("log", "-1", "--format=%an <%ae> | %cn <%ce> | %s", c).stdout.strip()}')
open(os.path.join(out, 'rebase.txt'), 'w').write('\n'.join(L) + '\n')

# 6. built sources (LE-reuse build) against the head and the merged trees
zp = os.path.join(repo, 'briefs/pass-shelat-ch5-8/fills/prf-mac/final-r1/landing-reuse/prf-mac-reuse-evidence.zip')
rows = [json.loads(l) for l in zipfile.ZipFile(zp).read('build/results.jsonl').decode().splitlines() if l.strip()]
mods = [x for x in rows if 'module' in x]
L = [f'prf-mac-reuse-evidence.zip:build/results.jsonl: {len(mods)} module records; last record keys {sorted(rows[-1])}; '
     f'rc 0 {sum(x["rc"] == 0 for x in mods)}, errors {sum(x["errors"] for x in mods)}']
for k, rev in [('head', HEAD)] + [(f'merged with {k}', trees[k]) for k in OPEN]:
    diff = [x['module'] for x in mods if hashlib.sha256(gitb('show', f'{rev}:{x["module"]}.lean')).hexdigest() != x['source_sha256']]
    L.append(f'{k} {rev[:8]}: {len(mods) - len(diff)} equal, {len(diff)} differ {diff}')
open(os.path.join(out, 'srcequality.txt'), 'w').write('\n'.join(L) + '\n')
print('OK', {k: v[:8] for k, v in trees.items()})
