#!/usr/bin/env bash
# rule10_cs1p2.sh <head|tip> <outdir>   (cleanup-stage1 phase 2; adapted from the worker's rule10_s1.sh and DW-5's
# rule10_dw5.sh/rule10_b.sh). Recipe seal tools (snaptools3 .../tools-used/seal, read only, = the worker's seal/ except
# runner_full.py, for which the recipe's copy is used). Every probe runs through runner_full.py (lean -DmaxErrors=0, no -o:
# nothing is written to the olean tree). One Lean process at a time.
#  head: TS1 tree 1eaf940b (tip x #347 x #355) on $SP/olean-replay-cs1; owners = Stage 1's 19 (17 changed + 2 new) and
#        #347's other two (ModuleHost, IterateFind): 21. Seals A/B strict/coe; controls: the worker's mkctl_s1.py +
#        controls-spec.json (20 pairs, 19 owners), strict and coe; DW-5's mkctl_dw5.py (readers), strict and coe; axioms probe;
#        explicit-unfold scan of the 21 owner files, touched = tip -> TS1.
#  tip:  records tip e1d39836 (Lean = snapshot #5 T 3f540c22) on $SP/olean-snapshot (read only); the 19 owners that exist
#        at the tip; seals A/B strict/coe and the scan (touched = tip -> tip, for attribution).
set -u
MODE=$1; OUT=$2
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; W0=$SP/cs1p2
T=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/seal; G=$T/review/archived-gate10-tools; TL=$SP/snaptools3/olean-advance-a6d01b1b/tools-used
TIP=e1d39836ed4a69a34914c35f4c73c71de853dcc6; TS1=1eaf940b938bb52e3919f5569893b58522df599b
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$W0/tmp GIT_DIR=/home/user/tcslib/.git
OWN17="TCSlib.Complexity.Randomized.Build.IterateFindHost TCSlib.Complexity.Randomized.PPT
 TCSlib.Cryptography.Asymptotic.Adversary TCSlib.Cryptography.Asymptotic.Sampling
 TCSlib.Cryptography.Authentication.Encoding TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity
 TCSlib.Cryptography.Encryption.PublicKey.Trapdoor TCSlib.Cryptography.Foundations.BitLists
 TCSlib.Cryptography.Games.Bridges.Experiments TCSlib.Cryptography.Games.Efficiency.Strings
 TCSlib.Cryptography.Games.Machines TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.Defs
 TCSlib.Cryptography.ZeroKnowledge.EncodingMachines TCSlib.Cryptography.ZeroKnowledge.Interaction
 TCSlib.InformationTheory.Entropy TCSlib.InformationTheory.FinDist TCSlib.InformationTheory.Samples"
OWN347="TCSlib.Complexity.TuringMachine.Build.ModuleHost TCSlib.Complexity.Randomized.Build.IterateFind"
if [ "$MODE" = head ]; then
  REV=$TS1; TREE=$SP/olean-replay-cs1; WT=$W0/W; P=CS1P2H; BASE=$TIP
  OWNERS="$OWN17 TCSlib.Cryptography.Games.Tapes TCSlib.Cryptography.ZeroKnowledge.InteractionWords $OWN347"
else
  REV=$TIP; TREE=$SP/olean-snapshot; WT=$W0/Wtip; P=CS1P2T; BASE=$TIP
  OWNERS="$OWN17 $OWN347"
fi
mkdir -p $OUT/order $OUT/probe-sources $OUT/statements $OUT/scan
echo "start $(date -u +%FT%TZ) mode=$MODE rev=$REV tree=$TREE"
rm -rf $WT/$P; mkdir -p $WT/$P
FILES=$(printf '%s\n' $OWNERS | sed 's|\.|/|g; s|$|.lean|')
# source check: worktree files equal the rev's blobs
for f in $FILES; do [ "$(git hash-object $WT/$f)" = "$(git rev-parse $REV:$f)" ] || { echo "worktree differs: $f"; exit 1; }; done
# 1. collector
printf '%s\n' $OWNERS > $OUT/order/owners.txt
python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $OUT/order/owners.txt "cs1 phase 2 collector ($MODE)" $WT/$P/Collect.lean
cp $WT/$P/Collect.lean $OUT/probe-sources/Collect.lean.txt
echo $P/Collect > $OUT/order/collect.txt
python3 -I $T/runner_full.py $WT $OUT/order/collect.txt $TREE $OUT/collect-runs > $OUT/collect-runner.out 2>&1
LOG=$OUT/collect-runs/mods/${P}_Collect.log
grep -q '^CAT-COUNT' $LOG || { echo "collector failed"; tail -20 $LOG; exit 1; }
echo "collector $(date -u +%FT%TZ)"
# 2. seals: strict (A, B) and coe (A, B)
python3 -I $T/review/mkseals_ab.py $G $LOG $WT $REV $OUT/seals/A $P/S SealA_ $OWNERS > $OUT/mkseals-A.log
SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $G $LOG $WT $REV $OUT/seals/B $P/S SealB_ $OWNERS > $OUT/mkseals-B.log
python3 -I $T/review/mkseals_coe.py $G $LOG $WT $REV $OUT/seals-coe/A $P/C SealA_ $OWNERS > $OUT/mkseals-coe-A.log
SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $WT $REV $OUT/seals-coe/B $P/C SealB_ $OWNERS > $OUT/mkseals-coe-B.log
# 3. controls and axioms (head only)
if [ "$MODE" = head ]; then
  python3 -I $W0/ref/tools/mkctl_s1.py $G $LOG $W0/ref/tools/controls-spec.json $WT $P/KS $OUT/controls-strict strict > $OUT/mkctl-strict.log
  python3 -I $W0/ref/tools/mkctl_s1.py $G $LOG $W0/ref/tools/controls-spec.json $WT $P/K $OUT/controls-coe coe > $OUT/mkctl-coe.log
  mkdir -p $OUT/seals-flat $OUT/seals-coe-flat
  for v in A B; do cp $OUT/seals/$v/Seal*.json $OUT/seals-flat/; cp $OUT/seals-coe/$v/Seal*.json $OUT/seals-coe-flat/; done
  python3 -I $TL/mkctl_dw5.py $G $OUT/seals-flat $WT $P/DS $OUT/controls-dw5-strict > $OUT/mkctl-dw5-strict.log
  python3 -I $TL/mkctl_dw5.py $G $OUT/seals-coe-flat $WT $P/DK $OUT/controls-dw5-coe > $OUT/mkctl-dw5-coe.log
  python3 -I $W0/scripts/mkaxioms.py $W0/ref/imports-s1.txt $W0/ref/imports-dw5.txt --names $W0/ref/names-s1.txt $W0/ref/names-dw5.txt \
    --owners $OUT/order/owners.txt --out $WT/$P/Axioms.lean > $OUT/mkaxioms.log
  cp $WT/$P/Axioms.lean $OUT/probe-sources/Axioms.lean.txt
fi
(cd $WT && { ls $P/Axioms.lean 2>/dev/null; ls $P/C/*.lean $P/K/*.lean $P/KS/*.lean $P/DS/*.lean $P/DK/*.lean $P/S/*.lean 2>/dev/null; } | sed 's/\.lean$//') \
  > $OUT/order/seal-control-queue.txt
echo "queue $(wc -l < $OUT/order/seal-control-queue.txt) probes $(date -u +%FT%TZ)"
python3 -I $T/runner_full.py $WT $OUT/order/seal-control-queue.txt $TREE $OUT/seal-runs > $OUT/seal-runner.out 2>&1 || true
# 4. summaries
python3 -I $T/review/touched.py /home/user/tcslib $BASE $REV $OUT/statements/touched.json $FILES > $OUT/statements/touched.tsv
TJ=$OUT/statements/touched.json
for v in A B; do
  python3 -I $T/review/sealsum.py $OUT/seals/$v $OUT/seal-runs $TJ $OUT/seals-$v.tsv
  python3 -I $T/review/sealsum.py $OUT/seals-coe/$v $OUT/seal-runs $TJ $OUT/seals-coe-$v.tsv
done
if [ "$MODE" = head ]; then
  for c in strict coe dw5-strict dw5-coe; do
    python3 -I $T/review/ctlcheck2.py $OUT/controls-$c/controls-plan.json $OUT/seal-runs $OUT/ctlcheck-$c.json > $OUT/ctlcheck-$c.log || true
  done
fi
# 5. explicit-unfold scan over the owners' files
SCAN_IMPORTS="$OWNERS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $WT $TJ $OUT/scan/items.json \
  $WT/$P/ScanKinds.lean $FILES > $OUT/scan/scan1.out 2>&1
cp $WT/$P/ScanKinds.lean $OUT/probe-sources/ScanKinds.lean.txt
echo $P/ScanKinds > $OUT/order/scan.txt
python3 -I $T/runner_full.py $WT $OUT/order/scan.txt $TREE $OUT/scan/runs > $OUT/scan/scan-runner.out 2>&1
python3 -I $T/scan2.py $OUT/scan/items.json $OUT/scan/runs/mods/${P}_ScanKinds.log $OUT/scan/explicit.json > $OUT/scan/scan2.log 2>&1
cat $OUT/mkseals-*.log $OUT/mkctl-*.log 2>/dev/null; cat $OUT/seals-*.tsv | cut -c1-250
tail -n 1 $OUT/ctlcheck-*.log 2>/dev/null
echo "PHASE-DONE $(date -u +%FT%TZ)"
