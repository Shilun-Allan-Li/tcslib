"""admcmp.py <census-T> <census-TS1> <queue>: per-module sorry counts T vs TS1 (tipcensus output)."""
import sys, re
def rd(p):
    d = {}
    for l in open(p):
        m = re.match(r'^\s*(\d+) (\S+)', l)
        if m: d[m.group(2)] = int(m.group(1))
        elif l.startswith('NOREC '): d[l.split()[1]] = None
    return d
a, b = rd(sys.argv[1]), rd(sys.argv[2]); q = [l.strip() for l in open(sys.argv[3]) if l.strip()]
diff = [(m, a.get(m, 'absent'), b.get(m)) for m in sorted(set(a) | set(b)) if a.get(m, 'absent') != b.get(m, 'absent')]
print('modules T', len(a), 'TS1', len(b), '; differing', len(diff))
for x in diff: print('  ', x)
tq = sum(a[m] or 0 for m in q if m in a); bq = sum(b[m] or 0 for m in q)
print('rebuilt set: T total', tq, 'TS1 total', bq, '; NOREC at T in rebuilt set', [m for m in q if a.get(m, 'absent') is None or a.get(m) == 'absent'])
print('tree totals T', sum(v or 0 for v in a.values()), 'TS1', sum(v or 0 for v in b.values()))
