"""mkaxioms.py <imports...file> <names-file>... --owners <owners-file> --out <probe.lean>
cs1 phase 2 axioms probe: imports the union of the import lists, `#print axioms` for every listed name (the 69 Stage 1
constants and DW-5's 27), then a census of every constant whose home module is an owner: name, kind, axioms."""
import sys
a = sys.argv[1:]; out = a[a.index('--out') + 1]; ownf = a[a.index('--owners') + 1]
imp_files = a[:a.index('--names')]; name_files = a[a.index('--names') + 1:a.index('--owners')]
imps = []
for f in imp_files + [ownf]:
    for l in open(f):
        l = l.strip().replace('/', '.')
        if l and l != 'Lean' and l not in imps: imps.append(l)
names = []
for f in name_files:
    for l in open(f):
        if l.strip() and l.strip() not in names: names.append(l.strip())
owners = [l.strip().replace('/', '.') for l in open(ownf) if l.strip()]
s = 'import Lean\n' + ''.join(f'import {i}\n' for i in imps)
s += '\n/-! cleanup-stage1 phase 2 axioms probe (TS1). -/\n\nset_option maxHeartbeats 0\nset_option maxRecDepth 65536\n\nopen Lean Elab Command\n\n'
s += ''.join(f'#print axioms {n}\n' for n in names)
s += '\ndef owners : List Name := [' + ',\n  '.join('`' + o for o in owners) + ']\n\n'
s += '''def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"C\\t{c}\\t{home}\\t{kindOf ci}\\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"
'''
open(out, 'w', encoding='utf-8').write(s)
print('imports', len(imps), 'names', len(names), 'owners', len(owners))
