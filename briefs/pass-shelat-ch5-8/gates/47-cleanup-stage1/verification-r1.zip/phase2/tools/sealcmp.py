"""sealcmp.py <mine-dir> <ref-dir> [label-filter]: compare sealsum TSVs (seals-A/B, seals-coe-A/B) per label:
requests, rc, errors, install, EOF and failing-declaration set. Prints SAME/DIFF per row and a summary."""
import sys, os
a, b = sys.argv[1:3]; flt = sys.argv[3] if len(sys.argv) > 3 else ''
tot = same = 0; missing = []
for v in ('seals-A', 'seals-B', 'seals-coe-A', 'seals-coe-B'):
    rd = lambda d: {r[0]: r for r in (l.rstrip('\n').split('\t') for l in open(os.path.join(d, v + '.tsv'))) if flt in r[0]} if os.path.exists(os.path.join(d, v + '.tsv')) else {}
    A, B = rd(a), rd(b)
    for k in sorted(A):
        if k not in B: missing.append((v, k)); continue
        x, y = A[k], B[k]; tot += 1
        ok = x[1:6] == y[1:6] and set(filter(None, x[6].split(','))) == set(filter(None, y[6].split(',')))
        same += ok
        if not ok: print('DIFF', v, k, 'mine', x[1:6], 'ref', y[1:6], '\n   +', sorted(set(filter(None, x[6].split(','))) - set(filter(None, y[6].split(',')))), '\n   -', sorted(set(filter(None, y[6].split(','))) - set(filter(None, x[6].split(',')))))
print(f'compared {tot}; same {same}; diff {tot - same}; mine-only {missing}')
