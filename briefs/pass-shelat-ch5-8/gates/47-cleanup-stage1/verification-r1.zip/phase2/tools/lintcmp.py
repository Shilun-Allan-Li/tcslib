"""lintcmp.py <dir>: FAIL/WARN line multisets (line numbers dropped) of campaign lint, tip vs ts1, per area."""
import sys, re, collections
d = sys.argv[1]
for a in ('Cryptography', 'InformationTheory', 'Complexity'):
    L = {}
    for s in ('tip', 'ts1'):
        L[s] = collections.Counter(re.sub(r':\d+', '', x.rstrip()) for x in open(f'{d}/campaign-TCSlib_{a}-{s}.txt', encoding='utf-8') if x.startswith(('FAIL', 'WARN')))
    gone = L['tip'] - L['ts1']; new = L['ts1'] - L['tip']
    print(f'{a}: tip FAIL/WARN {sum(1 for x in L["tip"].elements() if x.startswith("FAIL"))}/{sum(1 for x in L["tip"].elements() if x.startswith("WARN"))}; '
          f'ts1 {sum(1 for x in L["ts1"].elements() if x.startswith("FAIL"))}/{sum(1 for x in L["ts1"].elements() if x.startswith("WARN"))}; removed {sum(gone.values())}; new {sum(new.values())}')
    for x in sorted(gone.elements()): print('  removed:', x[:300])
    for x in sorted(new.elements()): print('  NEW:', x[:300])
