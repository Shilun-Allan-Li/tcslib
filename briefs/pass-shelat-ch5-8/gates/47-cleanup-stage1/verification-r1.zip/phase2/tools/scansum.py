"""scansum.py <explicit.json> [<ref explicit.json>...]: items, items in touched declarations by classification, foreign
items and the foreign multiset (file basename, declaration short name, tactic, item, class); compares multisets with refs."""
import sys, json, collections, os
def load(p):
    it = json.load(open(p))['items']
    fm = collections.Counter((os.path.basename(x['file']), x['declaration'].rsplit('.', 1)[-1] if x['declaration'] else None, x['tactic'], x['item'], x['classification'])
                             for x in it if x['classification'].startswith('FOREIGN'))
    return it, fm
it, fm = load(sys.argv[1])
t = [x for x in it if x['touched']]
print('items', len(it), '; in touched declarations', len(t), dict(collections.Counter(x['classification'] for x in t)))
print('  touched-declaration statuses', dict(collections.Counter(x['declaration_status'] for x in t)))
print('  foreign in touched', sum(1 for x in t if x['classification'].startswith('FOREIGN')), '; owned-definition items in touched',
      sorted({(x['declaration'], x['item']) for x in t if x['classification'] == 'OWNED_DEFINITION'}))
print('foreign total', sum(fm.values()), 'by file', dict(collections.Counter(k[0] for k in fm.elements())))
for r in sys.argv[2:]:
    _, rf = load(r); print('foreign multiset equal to', r.split('/cs1p2/')[-1], ':', rf == fm, '; ref-only', dict(rf - fm), '; mine-only', dict(fm - rf))
