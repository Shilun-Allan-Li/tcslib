"""r10pack.py <r10dir> <outdir>: compact Rule-10 evidence. Copies the TSV summaries, ctlcheck, controls plans, manifests,
touched, scan outputs and probe-sources; for each seal record writes a compact JSON (all fields but rows/maps; requested
spellings listed) and the SHA-256 of the full record; for each run log the error/diagnostic lines and the seal install/EOF
lines with the log SHA-256 (the full logs stay in the scratchpad)."""
import sys, os, json, glob, shutil, hashlib, re
src, out = sys.argv[1:3]; os.makedirs(out, exist_ok=True)
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
for p in glob.glob(os.path.join(src, '*.tsv')) + glob.glob(os.path.join(src, 'ctlcheck-*')) + glob.glob(os.path.join(src, 'mk*.log')) + [os.path.join(src, 'driver.out')]:
    if os.path.exists(p): shutil.copy(p, out)
for d in ('order', 'statements', 'probe-sources'):
    if os.path.isdir(os.path.join(src, d)): shutil.copytree(os.path.join(src, d), os.path.join(out, d), dirs_exist_ok=True)
os.makedirs(os.path.join(out, 'scan'), exist_ok=True)
for f in ('items.json', 'explicit.json', 'scan1.out', 'scan2.log', 'scan-runner.out'):
    p = os.path.join(src, 'scan', f)
    if os.path.exists(p): shutil.copy(p, os.path.join(out, 'scan'))
sums = []
for rd in sorted(glob.glob(os.path.join(src, 'seals*')) + glob.glob(os.path.join(src, 'controls-*'))):
    if not os.path.isdir(rd) or rd.endswith('-flat'): continue
    for p in sorted(glob.glob(os.path.join(rd, '**', '*'), recursive=True)):
        if os.path.isdir(p): continue
        rel = os.path.relpath(p, src); sums.append(f'{sha(p)}  {rel}')
        o = os.path.join(out, 'records', rel); os.makedirs(os.path.dirname(o), exist_ok=True)
        if p.endswith('.json') and not p.endswith(('manifest.json', 'controls-plan.json')):
            r = json.load(open(p))
            c = {k: v for k, v in r.items() if k not in ('rows', 'source_to_probe_lines', 'term_readers')}
            c['requested_spellings'] = sorted(x['spelling'] for x in r.get('rows', []))
            json.dump(c, open(o, 'w'), indent=0)
        elif p.endswith(('manifest.json', 'controls-plan.json')): shutil.copy(p, o)
open(os.path.join(out, 'records', 'FULL-RECORDS-SHA256'), 'w').write('\n'.join(sums) + '\n')
for runs in ('seal-runs', 'collect-runs', 'scan/runs'):
    rr = os.path.join(src, runs)
    if not os.path.isdir(rr): continue
    o = os.path.join(out, 'runs', runs.replace('/', '-')); os.makedirs(o, exist_ok=True)
    shutil.copy(os.path.join(rr, 'results.jsonl'), o)
    with open(os.path.join(o, 'diagnostics.txt'), 'w') as f:
        for p in sorted(glob.glob(os.path.join(rr, 'mods', '*.log'))):
            t = open(p, encoding='utf-8', errors='replace').read().splitlines()
            keep = [l for l in t if re.match(r'^\S+\.lean:\d+:\d+: (error|warning)', l) or 'G06-SEAL' in l[:40] or l.startswith(("'", 'C-COUNT', 'CAT-COUNT'))]
            f.write(f'== {os.path.basename(p)} sha256 {sha(p)} lines {len(t)}\n' + ''.join(x[:400] + '\n' for x in keep))
print('packed', out)
