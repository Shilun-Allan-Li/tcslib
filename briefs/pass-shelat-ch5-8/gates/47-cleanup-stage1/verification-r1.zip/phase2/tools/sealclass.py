"""sealclass.py <r10dir>: per owner, failing declarations in the four variants, which are touched (tip -> TS1), the coe/strict
request differences (from the seal records), and the strict-only failures."""
import sys, json, os, glob
d = sys.argv[1]
tj = json.load(open(os.path.join(d, 'statements/touched.json')))['files']
touched = {x['name'] for f in tj.values() for x in f['declarations'] if x['touched']}
def tsv(v): return {r[0]: (int(r[3]), set(filter(None, r[6].split(',')))) for r in (l.rstrip('\n').split('\t') for l in open(os.path.join(d, v + '.tsv')))}
V = {v: tsv(v) for v in ('seals-A', 'seals-B', 'seals-coe-A', 'seals-coe-B')}
def rows(sub, lab): return {r['spelling'] for r in json.load(open(os.path.join(d, sub, lab + '.json')))['rows']}
labs = sorted(k[6:] for k in V['seals-A'])
tot_new_coe = 0; tot_new_strict = 0
for t in labs:
    A, B = 'SealA_' + t, 'SealB_' + t
    sA, sB, cA, cB = rows('seals/A', A), rows('seals/B', B), rows('seals-coe/A', A), rows('seals-coe/B', B)
    e = [V['seals-A'][A], V['seals-B'][B], V['seals-coe-A'][A], V['seals-coe-B'][B]]
    newfail = [sorted(x[1] & touched) for x in e]
    tot_new_coe += len(newfail[2]) + len(newfail[3]); tot_new_strict += len(newfail[0]) + len(newfail[1])
    print(f"{t}: errors sA/sB/cA/cB {e[0][0]}/{e[1][0]}/{e[2][0]}/{e[3][0]}; req diff sA-cA {sorted(sA - cA)} sB-sA {sorted(sB - sA)} cA-sA {sorted(cA - sA)}")
    so = sorted((e[0][1] | e[1][1]) - (e[2][1] | e[3][1])); bo = sorted(e[1][1] - e[0][1])
    if so: print('   strict-only failing decls:', so, '; touched among them:', sorted(set(so) & touched))
    if bo: print('   B-only failing decls:', bo, '; touched among them:', sorted(set(bo) & touched))
    if any(newfail): print('   failing touched decls sA/sB/cA/cB:', newfail)
print('touched declarations', len(touched), '; failures in touched declarations: coe', tot_new_coe, 'strict', tot_new_strict)
