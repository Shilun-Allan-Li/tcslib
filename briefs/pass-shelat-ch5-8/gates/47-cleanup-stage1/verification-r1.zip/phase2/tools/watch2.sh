#!/usr/bin/env bash
# watch2.sh <logdir> <driver-pattern>: while the driver runs, log disk and host Lean count every 30 s; disk < 1500 MB: stop
# our current lean and the driver; > 3 Lean processes host-wide: SIGSTOP our lean until <= 3.
B=$1; PAT=$2; paused=0
while pgrep -f "$PAT" > /dev/null; do
  f=$(df -B1M / | tail -1 | awk '{print $4}'); n=$(pgrep -x lean | wc -l)
  lp=$(cut -d' ' -f1 $B/current.pid 2>/dev/null)
  echo "$(date -u +%FT%TZ) $f MB free; lean procs $n; ours $lp" >> $B/watch.log
  if [ "$f" -lt 1500 ]; then echo "LOW-DISK STOP ($f MB)" >> $B/watch.log; pkill -f "$PAT"; [ -n "$lp" ] && kill -CONT $lp 2>/dev/null; [ -n "$lp" ] && kill $lp; break; fi
  if [ "$n" -gt 3 ] && [ -n "$lp" ] && [ $paused = 0 ]; then kill -STOP $lp && paused=$lp && echo "PAUSE $lp" >> $B/watch.log; fi
  if [ $paused != 0 ] && [ "$n" -le 3 ]; then kill -CONT $paused; echo "RESUME $paused" >> $B/watch.log; paused=0; fi
  sleep 30
done
[ $paused != 0 ] && kill -CONT $paused 2>/dev/null; echo "$(date -u +%FT%TZ) end" >> $B/watch.log
