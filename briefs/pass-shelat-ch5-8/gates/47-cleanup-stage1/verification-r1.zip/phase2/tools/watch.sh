#!/usr/bin/env bash
# cs1 phase 2 watcher: every 30 s log free disk and the host-wide Lean process count.
# Disk < 1500 MB: stop this job's runner and checker (job brief: stop and report).
# More than 3 Lean processes host-wide (ours included): SIGSTOP our own lean until the count is back to <= 3.
B=$1; paused=0
while [ ! -s $B/runner.exit ]; do
  f=$(df -B1M / | tail -1 | awk '{print $4}')
  cp=$(cut -d' ' -f1 $B/current.pid 2>/dev/null); lp=$(pgrep -P "$cp" -x lean 2>/dev/null | head -1)
  n=$(pgrep -x lean | wc -l)
  echo "$(date -u +%FT%TZ) $f MB free; lean procs $n; ours $lp" >> $B/watch.log
  if [ "$f" -lt 1500 ]; then echo "$(date -u +%FT%TZ) LOW-DISK STOP ($f MB)" >> $B/watch.log
    [ -n "$lp" ] && kill -CONT $lp 2>/dev/null; kill $(cat $B/runner.pid) 2>/dev/null; kill $cp 2>/dev/null; [ -n "$lp" ] && kill $lp 2>/dev/null; break; fi
  if [ "$n" -gt 3 ] && [ -n "$lp" ] && [ $paused = 0 ]; then kill -STOP $lp && paused=$lp && echo "$(date -u +%FT%TZ) PAUSE lean $lp (procs $n)" >> $B/watch.log; fi
  if [ $paused != 0 ] && [ "$n" -le 3 ]; then kill -CONT $paused; echo "$(date -u +%FT%TZ) RESUME lean $paused" >> $B/watch.log; paused=0; fi
  sleep 30
done
[ $paused != 0 ] && kill -CONT $paused 2>/dev/null
echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free (end)" >> $B/watch.log
