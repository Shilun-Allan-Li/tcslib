# verification-r1.zip · what is not copied, and where it is

All paths are on the records branch at the pin `659542ecd9413b504d30da8c937b9805e6c1f71f` unless stated.

| Evidence | Where | SHA-256 |
|---|---|---|
| Stage 1 final, phase 1 (whole) | `briefs/pass-shelat-ch5-8/cleanup-stage1/final-r1/cleanup-stage1-final-r1-phase1-evidence.zip` (66 entries) | `37bfa7506c63716b43e632c75c3af7490ffe3ffd1702f2725ec0c8b2fd0cdbd1` |
| Stage 1 final, phase 2 (whole: build records of 556 modules, all probe sources and logs at head and tip, state files) | `briefs/pass-shelat-ch5-8/cleanup-stage1/final-r1/cleanup-stage1-final-r1-phase2-evidence.zip` (2.2 MB) | `854d6430fad819e469b126565c0e3200f43b86c8ac2f83d4b133ed75c6bfd9f3` |
| Stage 1 checkpoint-1 review evidence | `briefs/pass-shelat-ch5-8/cleanup-stage1/checkpoint1-review-evidence.zip` | `5b2402d680c5d2d24f18d8cc1a960baea436a9f7f12847dd0661697a73aa06d8` |
| DW-5 (#347) evidence (whole: 706-module build, base and head seals, probes, controls, scan, restore) | `briefs/pass-shelat-ch5-8/maintenance/dw5/dw5-evidence.zip` (4.5 MB); every entry in `maintenance/dw5/SHA256SUMS` | `12abc05a61c08de7cb38b9d3bccdea5b3dd44dff6f65f036a50584a39e1dd630` |
| Stage 1 issued package | `briefs/pass-shelat-ch5-8/cleanup-stage1/issued-r1/` (`SHA256SUMS`, `SOURCE-SHA256SUMS`, closures, order) | per its `SHA256SUMS` |
| Worker delivery (whole: patches, build logs, seal records, controls, probes) | exchange branch, `inbox/fills/cleanup-stage1/` at `5451d3cd6fa9b8c313c9f18f5a4da3542c85f02a` (final) and `bc2bf64a0c8449adb61234d957acb0e737fb66d5` (checkpoint 1) | per its `SHA256SUMS` |
| The replay output itself | maintainer scratchpad `$SP/olean-replay-cs1` (not in the repository; no longer adoptable: the #357 merge voided it and snapshot #6 was adopted at `8060f6b7`; #347/#355 re-replay on #6) | phase 2's `plan/state-after-update-1eaf940b.json.gz` |
