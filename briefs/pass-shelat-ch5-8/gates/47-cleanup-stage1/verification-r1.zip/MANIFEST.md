# verification-r1.zip · Gate 47 (cleanup Stage 1 gate: #347 and #355) · manifest

Built at staging (2026-11-17) from git objects and from evidence already recorded; **nothing was re-run** except the
git-only checks under `checks/`. No Lean, no `lake`. `SHA256SUMS` lists every other entry of this zip.

| Path | Provenance |
|---|---|
| `checks/series.txt` | Pins, both PRs' commits (parent, tree, signature header, author, committer, trailers with the Co-Authored-By value elided, files), TS1 recomputation, the range-diff of the worker series `c8021348` against #355. `tools/gitchecks.py`. |
| `checks/insertion.txt` | Per-file `+/−` of #347 (from its merge base `2da7e0f3`) and #355 (from `daa6e173`), with every deleted line outside `IterateFind.lean` listed. |
| `checks/sizes.txt` | The 23 TS1 paths: lines at `e1d39836` and at TS1, maximum width of the file and of the added lines, blob and SHA-256. |
| `checks/source-head-r1.json` | Same content as the pack's `source-head-r1.json`. |
| `checks/mergetrees.txt` | `git merge-tree --write-tree` of #347/#355 with #357, #358, #359 and #360, in both orders against the records pin, and all together. `tools/mergetrees.sh` (temporary unreferenced commit objects only). |
| `checks/downstream.txt` | Import-graph overlap on each merged tree: modules downstream of TS1's 23 paths and of each other PR's paths. `tools/downstream.py` (validated: it gives 556 at TS1, equal to phase 2's `plan/queue.txt`). |
| `checks/dup-sweep.txt` | The duplication sweep over the 78 new declarations: method, classification A (in the records) and B (not in the ledger). |
| `checks/dup/` | Raw sweep outputs: same-short-name hits (TS1 and Mathlib/Batteries/core), shape hits, statement-header hits. |
| `checks/tools/` | Every script this staging ran. |
| `phase1/` | Subset of `cleanup-stage1-final-r1-phase1-evidence.zip` (records, SHA-256 `37bfa750…`), paths under its `cs1-final-r1/`; `SHA256SUMS.original` holds the original lines for the copied files. |
| `phase2/` | Subset of `cleanup-stage1-final-r1-phase2-evidence.zip` (`854d6430…`), under its `cs1-final-r1-phase2/`; `SHA256SUMS.original` likewise. |
| `dw5/` | Subset of `maintenance/dw5/dw5-evidence.zip` (`12abc05a…`), under its `dw5/`; `SHA256SUMS.original` holds the lines of the records' `maintenance/dw5/SHA256SUMS`. |
| `delivery/` | `REPORT.md`, `reuse-table.md`, `repoint.tsv` of the Stage 1 worker delivery, read at exchange `5451d3cd6fa9b8c313c9f18f5a4da3542c85f02a`. |
| `records/` | Campaign records read at the pin `95da6120f0b3b3c80e3078b1d497cbc93aa15fc4`: `cleanup-stages.md`, `deferred-work.md`, `duplication-ledger.md`, the DW-5 README, the Stage 1 checkpoint-1 review, final review, phase 2, the Stage 2 addendum, the issued brief, `snapshots.md`, `policy.md`, `workflow.md`, the Gate 44/45/48 findings, and `decision-log-rows.md` (filtered rows, verbatim). |
| `pr/` | `gh api repos/Shilun-Allan-Li/tcslib/pulls/{347,355}` at staging (REST fields, bodies). |
