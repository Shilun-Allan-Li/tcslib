"""Gate 47 staging: build sources-r1.zip from git objects (no checkout).

Entries: ts1/<the 23 changed Lean paths at TS1>, base-e1d39836/<the 21 existing ones at the phase-2 tip>,
head347-daa6e173/<#347's 3 files>, head355-d3c7cb00/TCSlib/Cryptography/Games.lean (the one TS1 file that is not
blob-equal to #355), overlap-ts1/<files the duplication sweep cites>, MANIFEST.txt, SHA256SUMS.
Usage: python3 -I mksources.py REPO OUT.zip
"""
import hashlib
import subprocess
import sys
import zipfile

repo, out = sys.argv[1:3]
E = "e1d39836ed4a69a34914c35f4c73c71de853dcc6"
A = "daa6e173cdd94cad1475b9a96eca613bce53ba61"
B = "d3c7cb00092ad5913904654d922f30fc7d5fce4a"
TS1 = "1eaf940b938bb52e3919f5569893b58522df599b"
OVERLAP = """
TCSlib/Cryptography/Pseudorandom/Functions/LazySampling.lean
TCSlib/Cryptography/Encryption/PublicKey/AdaptiveCPA/Hybrid.lean
TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Tools.lean
TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Lazy.lean
TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Handler.lean
TCSlib/Cryptography/Encryption/PrivateKey/OracleFromPRF/Handler.lean
TCSlib/Cryptography/Randomness/Extraction/Rejection.lean
TCSlib/Complexity/FormulaKit/Emit.lean
TCSlib/Cryptography/Asymptotic/CollectionsLemmas.lean
TCSlib/Cryptography/Asymptotic/EnsemblesLemmas.lean
TCSlib/Cryptography/Asymptotic/BlockEncryptor.lean
TCSlib/Cryptography/Candidates/DDH.lean
TCSlib/Cryptography/Hashing/FromDiscreteLog/Encoding.lean
TCSlib/Cryptography/Hashing/FromDiscreteLog/Probability.lean
TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/SoundnessRep.lean
TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/ColZKMachine.lean
TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/Machines.lean
TCSlib/Cryptography/SecureComputation/ComposeSecurity/Machines.lean
TCSlib/Cryptography/Encryption/PublicKey/NonMalleability/Simulation/Rounds.lean
TCSlib/Cryptography/SecureComputation/ObliviousTransfer/Simulators.lean
TCSlib/Cryptography/Pseudorandom/Functions/Asymptotic/GGM/Evaluator.lean
TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/EfficiencyRep.lean
TCSlib/Complexity/ClassP/BinaryArith/Unary.lean
TCSlib/Cryptography/Composability/SequentialZK/Normalization.lean
TCSlib/Cryptography/SecureComputation/Yao/HybridProof/Lengths.lean
""".split()


def git(*a):
    return subprocess.run(["git", "-C", repo, *a], capture_output=True, text=True).stdout


def blob(rev, p):
    return subprocess.run(["git", "-C", repo, "cat-file", "blob", f"{rev}:{p}"], capture_output=True,
                          check=True).stdout


changed = git("diff", "--name-only", E, TS1).split()
entries = []
for p in changed:
    entries.append((f"ts1/{p}", TS1, p))
    if git("cat-file", "-t", f"{E}:{p}").strip() == "blob":
        entries.append((f"base-e1d39836/{p}", E, p))
for p in git("diff", "--name-only", "2da7e0f3cd65ec93ed71813b7828c3b66ba18942", A).split():
    entries.append((f"head347-daa6e173/{p}", A, p))
entries.append(("head355-d3c7cb00/TCSlib/Cryptography/Games.lean", B, "TCSlib/Cryptography/Games.lean"))
for p in OVERLAP:
    entries.append((f"overlap-ts1/{p}", TS1, p))

sums, man = [], ["entry\trevision\tsource path\tgit blob"]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for name, rev, p in entries:
        data = blob(rev, p)
        zi = zipfile.ZipInfo(name, date_time=(2026, 11, 17, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, data)
        sums.append(f"{hashlib.sha256(data).hexdigest()}  {name}")
        man.append(f"{name}\t{rev}\t{p}\t{git('rev-parse', f'{rev}:{p}').strip()}")
    for name, text in (("MANIFEST.txt", "\n".join(man) + "\n"), ("SHA256SUMS", "\n".join(sums) + "\n")):
        zi = zipfile.ZipInfo(name, date_time=(2026, 11, 17, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, text.encode())
print(len(entries), "files")
