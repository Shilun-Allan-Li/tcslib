"""Gate 47 staging: import-graph overlap of two change sets on one merged tree.

Reads the `import TCSlib.*` / `import audits.*` lines of every .lean file under TCSlib/,
TCSlib.lean and audits/ of TREE (git cat-file, no checkout), then prints, for change sets
S1 (TS1's 23 paths) and S2 (the other PR's paths): the modules downstream of S1 (changed
modules included), downstream of S2, and their intersection.
Usage: python3 -I downstream.py REPO TREE S1-PATHS-FILE S2-PATHS-FILE LABEL
"""
import re
import subprocess
import sys

repo, tree, f1, f2, label = sys.argv[1:6]
ls = subprocess.run(["git", "-C", repo, "ls-tree", "-r", "--name-only", tree, "--",
                     "TCSlib", "TCSlib.lean", "audits"], capture_output=True, text=True).stdout.split()
paths = [p for p in ls if p.endswith(".lean")]
batch = subprocess.run(["git", "-C", repo, "cat-file", "--batch"],
                       input="".join(f"{tree}:{p}\n" for p in paths).encode(),
                       capture_output=True).stdout
mods, imports, pos = {}, {}, 0
for p in paths:
    nl = batch.index(b"\n", pos)
    size = int(batch[pos:nl].split()[2])
    body = batch[nl + 1:nl + 1 + size].decode("utf-8", "replace")
    pos = nl + 1 + size + 1
    m = p[:-5].replace("/", ".")
    mods[m] = p
    imports[m] = set(re.findall(r"^import\s+((?:TCSlib|audits)[\w.]*)", body, re.M))
rev = {m: set() for m in mods}
for m, ims in imports.items():
    for i in ims:
        if i in rev:
            rev[i].add(m)


def down(seed):
    seen, stack = set(seed), list(seed)
    while stack:
        x = stack.pop()
        for y in rev.get(x, ()):
            if y not in seen:
                seen.add(y)
                stack.append(y)
    return seen


def seedof(f):
    return {l.strip()[:-5].replace("/", ".") for l in open(f) if l.strip().endswith(".lean")} & set(mods)


s1, s2 = seedof(f1), seedof(f2)
d1, d2 = down(s1), down(s2)
both = sorted(d1 & d2)
print(f"{label}: tree {tree}; modules {len(mods)}")
print(f"  S1 changed modules {len(s1)}, downstream (incl.) {len(d1)}")
print(f"  S2 changed modules {len(s2)}, downstream (incl.) {len(d2)}")
print(f"  S2 changed modules downstream of S1: {sorted(s2 & d1)}")
print(f"  S1 changed modules downstream of S2: {sorted(s1 & d2)}")
print(f"  downstream of both ({len(both)}): {both if len(both) <= 12 else both[:12] + ['...']}")
