#!/bin/bash
# Gate 47 staging: merge-tree interaction of TS1's PR heads (#347, #355) with #357-#360.
# git merge-tree --write-tree only; intermediate merges are passed as temporary unreferenced
# commit objects (git commit-tree, no ref). Usage: mergetrees.sh REPO
set -u
R=$1; cd "$R" || exit 1
P=659542ecd9413b504d30da8c937b9805e6c1f71f   # records pin (records-only advance from 95da6120, which holds the #357 merge 8060f6b7)
E=e1d39836ed4a69a34914c35f4c73c71de853dcc6   # records tip at phase 2 (TS1 = E x #347 x #355)
A=daa6e173cdd94cad1475b9a96eca613bce53ba61   # #347
B=d3c7cb00092ad5913904654d922f30fc7d5fce4a   # #355
TS1=1eaf940b938bb52e3919f5569893b58522df599b
declare -A X=([357]=dfdc56f21898abe2d9d6cef83b0cfe57da87d28d [358]=a616adcac0760ab56b1b0a2a4869f4763843f9ab
              [359]=d154c8830fc8ffc52671b41992e7dbef61e30959 [360]=cc05f76c43cd2d2f565ff0dfaec1c85b47e06d25)
L="TCSlib TCSlib.lean audits scripts lakefile.lean lakefile.toml lake-manifest.json lean-toolchain"
export GIT_AUTHOR_NAME=tmp GIT_AUTHOR_EMAIL=tmp@invalid GIT_COMMITTER_NAME=tmp GIT_COMMITTER_EMAIL=tmp@invalid
export GIT_AUTHOR_DATE='2026-11-17T00:00:00Z' GIT_COMMITTER_DATE='2026-11-17T00:00:00Z'
mt() { # mt LABEL C1 C2 -> prints line, sets T
  local out rc; out=$(git merge-tree --write-tree --name-only "$2" "$3" 2>&1); rc=$?
  T=$(echo "$out" | head -1)
  local conf=$(echo "$out" | tail -n +2 | grep -v '^$' | paste -sd, -)
  printf '%-44s rc=%s tree=%s mb=%s %s\n' "$1" "$rc" "$T" "$(git merge-base "$2" "$3" | cut -c1-8)" "${conf:+conflicts:$conf}"
}
tmpc() { git commit-tree -p "$2" -p "$3" -m tmp "$1"; }
echo "git $(git --version | awk '{print $3}'); pin $P; #347 $A; #355 $B; TS1 $TS1"
for k in 357 358 359 360; do echo "#$k head ${X[$k]}"; done
echo
mt "pin x #347" $P $A; PA=$(tmpc $T $P $A)
mt "(pin x #347) x #355" $PA $B; T1=$T
mt "pin x #355" $P $B; PB=$(tmpc $T $P $B); T2=$T
echo "Lean diff (pin x #347 x #355) vs (pin x #355): $(git diff --name-only $T1 $T2 -- $L | wc -l) paths"
echo "Lean paths differing (pin x #355) vs TS1: $(git diff --name-only $T2 $TS1 -- $L | paste -sd, -)"; echo "  each blob-equal to the #357 head dfdc56f2: $(for p in $(git diff --name-only $T2 $TS1 -- $L); do [ "$(git rev-parse $T2:$p)" = "$(git rev-parse dfdc56f21898abe2d9d6cef83b0cfe57da87d28d:$p)" ] && echo y || echo n; done | sort | uniq -c | paste -sd" " -)"; echo "Lean of pin vs e1d39836 x #357 (tree 2888323275e1): $(git diff --name-only $P 2888323275e12562ecb3dc1873c12cc6628a1143 -- $L | wc -l) paths differ"
echo
for k in 357 358 359 360; do
  H=${X[$k]}
  echo "== #$k ${H}"
  mt "  #347 x #$k" $A $H
  mt "  #355 x #$k" $B $H
  mt "  (pin x #355) x #$k  [TS1 first]" $PB $H; Tf=$T
  mt "  pin x #$k" $P $H; PX=$(tmpc $T $P $H)
  mt "  (pin x #$k) x #355  [#$k first]" $PX $B; Tr=$T
  echo "  order-independent tree: $([ "$Tf" = "$Tr" ] && echo yes || echo NO)"
  # every TS1 path blob-equal to TS1, every #k path blob-equal to #k's head
  base=$(git merge-base $H $P)
  nk=0; okk=0; for p in $(git diff --name-only $base $H); do nk=$((nk+1)); [ "$(git rev-parse $Tf:$p 2>/dev/null)" = "$(git rev-parse $H:$p 2>/dev/null)" ] && okk=$((okk+1)); done
  nt=0; okt=0; for p in $(git diff --name-only $E $TS1); do nt=$((nt+1)); [ "$(git rev-parse $Tf:$p 2>/dev/null)" = "$(git rev-parse $TS1:$p 2>/dev/null)" ] && okt=$((okt+1)); done
  echo "  #$k paths blob-equal to its head: $okk/$nk; TS1 paths blob-equal to TS1: $okt/$nt"
  echo "  shared paths with #347/#355: $(comm -12 <(git diff --name-only $E $TS1 | sort) <(git diff --name-only $base $H | sort) | paste -sd, -)"
done
echo
echo "== all together: ((((pin x #355) x #357) x #359) x #360)  [#359 contains #358]"
mt "  step #357" $PB ${X[357]}; C=$(tmpc $T $PB ${X[357]})
mt "  step #359" $C ${X[359]}; C=$(tmpc $T $C ${X[359]})
mt "  step #360" $C ${X[360]}
