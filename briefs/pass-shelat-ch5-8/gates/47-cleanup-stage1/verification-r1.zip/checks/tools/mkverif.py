"""Gate 47 staging: build verification-r1.zip (reuses recorded evidence; re-runs nothing).

Sections: checks/ (this staging's git-object checks, the duplication sweep and its tools), phase1/ and phase2/
(subsets of the two Stage 1 final evidence zips, with the original SHA256SUMS lines of the copied files as
SHA256SUMS.original), dw5/ (subset of dw5-evidence.zip, same), delivery/ (the worker's REPORT, reuse table and
repoint table at exchange 5451d3cd), records/ (campaign records read at the pin), pr/ (REST fields).
MANIFEST.md and POINTERS.md come from the staging folder; SHA256SUMS lists every other entry.
Usage: python3 -I mkverif.py REPO STAGEDIR OUT.zip
"""
import hashlib
import os
import subprocess
import sys
import zipfile

repo, stage, out = sys.argv[1:4]
PIN = "659542ecd9413b504d30da8c937b9805e6c1f71f"
DELIV = "5451d3cd6fa9b8c313c9f18f5a4da3542c85f02a"
P1 = os.path.join(stage, "ev/p1/cs1-final-r1")
P2 = os.path.join(stage, "ev/p2/cs1-final-r1-phase2")
D5 = os.path.join(stage, "ev/dw5/dw5")
DW5SUMS = os.path.join(repo, "briefs/pass-shelat-ch5-8/maintenance/dw5/SHA256SUMS")

P1_FILES = """PROVENANCE.txt PHASE2-PLAN.txt integrity/signing-keys.txt integrity/manifests.txt
statements/decls2.mine.tsv statements/decls2.mine.err statements/stmtcmp.out statements/stmtcmp.checkpoint1.out
statements/doccheck.out statements/prooflen.out statements/sizes.txt statements/added-scan.txt
statements/style_lint-head.txt recount/buildrecount.out recount/sealrecount.out recount/ctlrecount.out
recount/scan-axioms-lint.txt clash/fresh.txt clash/short_all.txt clash/shorthits-01cc6259.txt
clash/shorthits-66036926.txt clash/shorthits-916afc25.txt clash/shorthits-98cb0e52.txt clash/shorthits-b8dfca4e.txt
landing/merge-trees.txt landing/games-facade-union.diff landing/files-stage1-and-347.txt
stage2/stage2-addendum.tsv stage2/rowlines-at-check-base.txt stage2/unlisted-copies-source.txt
stage2/dl35-public-alias-uses-at-check-base.txt""".split()
P2_FILES = """PROVENANCE.txt admissions/admcmp.out admissions/source-scan.txt admissions/record-sets-used.txt
axioms/axsum.out axioms/Axioms.lean.txt build/check.out build/linkcount.txt build/permod.out build/update.out
build/runner.exit build/overlay.txt build/mathlibextra.log cmp/controls.txt cmp/head-classify.txt
cmp/head-vs-dw5-head.txt cmp/head-vs-tip.txt cmp/head-vs-worker-head.txt cmp/scan-head.txt cmp/scan-tip.txt
cmp/tip-classify.txt lint/lintcmp.out lint/style_lint-tip.txt lint/style_lint-ts1.txt merge/diffstat-5a2e818d-to-TS1.txt
merge/files-tip-to-TS1.txt merge/merge-trees.txt plan/queue-vs-review-551.txt plan/queue.txt
snapshot/inputs.sha256 snapshot/verify-pre/out.txt snapshot/verify-after-build/out.txt
snapshot/verify-after-all-lean/out.txt rule10/head/seals-A.tsv rule10/head/seals-B.tsv rule10/head/seals-coe-A.tsv
rule10/head/seals-coe-B.tsv rule10/tip/seals-A.tsv rule10/tip/seals-B.tsv rule10/tip/seals-coe-A.tsv
rule10/tip/seals-coe-B.tsv rule10/head/ctlcheck-strict.json rule10/head/ctlcheck-coe.json
rule10/head/ctlcheck-dw5-strict.json rule10/head/ctlcheck-dw5-coe.json rule10/head/driver.out rule10/tip/driver.out
rule10/tip-first-attempt-driver.out rule10/head/statements/touched.tsv tools/admcmp.py tools/blob-ids.txt
tools/controls-spec.json tools/lintcmp.py tools/mkaxioms.py tools/mkctl_s1.py tools/r10pack.py
tools/recipe-seal-tree.sha256 tools/recipe-tools-used.sha256 tools/rule10_cs1p2.sh tools/run-build.sh
tools/scansum.py tools/sealclass.py tools/sealcmp.py tools/watch.sh tools/watch2.sh tools/worker-seal-tree.sha256""".split()
D5_FILES = """statements/decls2.tsv statements/frozencheck.txt statements/frozencheck-control.txt statements/pr-files.txt
statements/touched.out compare/collector-base-vs-head.txt compare/seals-base-vs-head.txt
admissions/census-tip-vs-head-summary.txt axioms/axioms-summary.txt rule10/seals-A.tsv rule10/seals-B.tsv
rule10/seals-coe-A.tsv rule10/seals-coe-B.tsv rule10/ctlcheck-strict.json rule10/ctlcheck-coe.json
rule10/rule10-driver.out checks/nameclash.txt scan/scan-base-vs-head.txt scan/scan1.out scan/scan2-head.log
scan/files.txt lint/linediff-Complexity.txt lint/campaign-linediff-Complexity.txt cleanup.txt""".split()
RECORDS = {
    "records/cleanup-stages.md": "briefs/pass-shelat-ch5-8/cleanup-stages.md",
    "records/deferred-work.md": "briefs/pass-shelat-ch5-8/deferred-work.md",
    "records/duplication-ledger.md": "briefs/pass-shelat-ch5-8/duplication-ledger.md",
    "records/maintenance-dw5-README.md": "briefs/pass-shelat-ch5-8/maintenance/dw5/README.md",
    "records/cleanup-stage1/checkpoint1-review.md": "briefs/pass-shelat-ch5-8/cleanup-stage1/checkpoint1-review.md",
    "records/cleanup-stage1/final-r1/review.md": "briefs/pass-shelat-ch5-8/cleanup-stage1/final-r1/review.md",
    "records/cleanup-stage1/final-r1/phase2.md": "briefs/pass-shelat-ch5-8/cleanup-stage1/final-r1/phase2.md",
    "records/cleanup-stage1/final-r1/stage2-addendum.tsv":
        "briefs/pass-shelat-ch5-8/cleanup-stage1/final-r1/stage2-addendum.tsv",
    "records/cleanup-stage1/final-r1/evidence-SHA256SUMS":
        "briefs/pass-shelat-ch5-8/cleanup-stage1/final-r1/evidence-SHA256SUMS",
    "records/cleanup-stage1/issued-r1/brief.md": "briefs/pass-shelat-ch5-8/cleanup-stage1/issued-r1/brief.md",
    "records/maintainer-snapshots.md": "briefs/pass-shelat-ch5-8/maintainer/snapshots.md",
    "records/olean-snapshot-6-adopt-README.md": "briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-6-adopt/README.md",
    "records/handoff-complexity-README.md": "briefs/pass-shelat-ch5-8/cleanup-dw10/handoff-complexity/README.md",
    "records/policy.md": "policy.md",
    "records/workflow.md": "workflow.md",
    "records/gates/44-findings-r1.md": "briefs/pairings/gates/44-pairing-fills/findings-r1.md",
    "records/gates/44-findings-r2.md": "briefs/pairings/gates/44-pairing-fills/findings-r2.md",
    "records/gates/45-findings-r1.md": "briefs/lattice-gsw/gates/45-gsw-6a/findings-r1.md",
    "records/gates/48-findings-r1.md": "briefs/pairings/gates/48-bb1-sim-fill/findings-r1.md",
}
DELIVERY = {
    "delivery/REPORT.md": "inbox/fills/cleanup-stage1/REPORT.md",
    "delivery/reuse-table.md": "inbox/fills/cleanup-stage1/evidence/reuse/reuse-table.md",
    "delivery/repoint.tsv": "inbox/fills/cleanup-stage1/evidence/stage2/repoint.tsv",
}


def show(rev, p):
    return subprocess.run(["git", "-C", repo, "show", f"{rev}:{p}"], capture_output=True, check=True).stdout


def sumlines(sumfile, prefix, files):
    want = {prefix + f for f in files}
    got = {}
    for l in open(sumfile, encoding="utf-8"):
        h, _, n = l.rstrip("\n").partition("  ")
        n = n.lstrip("*")
        if n.startswith("./"):
            n = n[2:]
        if n in want:
            got[n] = l if l.endswith("\n") else l + "\n"
    miss = want - set(got)
    if miss:
        raise SystemExit(f"missing in {sumfile}: {sorted(miss)[:5]}")
    return "".join(got[n] for n in sorted(got))


entries = []  # (name, bytes)
for root in ("checks",):
    for dp, _, fs in os.walk(os.path.join(stage, root)):
        for f in sorted(fs):
            full = os.path.join(dp, f)
            entries.append((os.path.relpath(full, stage), open(full, "rb").read()))
for f in sorted(os.listdir(os.path.join(stage, "tools"))):
    entries.append((f"checks/tools/{f}", open(os.path.join(stage, "tools", f), "rb").read()))
for f in P1_FILES:
    entries.append((f"phase1/{f}", open(os.path.join(P1, f), "rb").read()))
entries.append(("phase1/SHA256SUMS.original", sumlines(os.path.join(P1, "SHA256SUMS"), "", P1_FILES).encode()))
for f in P2_FILES:
    entries.append((f"phase2/{f}", open(os.path.join(P2, f), "rb").read()))
entries.append(("phase2/SHA256SUMS.original", sumlines(os.path.join(P2, "SHA256SUMS"), "", P2_FILES).encode()))
for f in D5_FILES:
    entries.append((f"dw5/{f}", open(os.path.join(D5, f), "rb").read()))
entries.append(("dw5/SHA256SUMS.original", sumlines(DW5SUMS, "dw5/", D5_FILES).encode()))
for n, p in DELIVERY.items():
    entries.append((n, show(DELIV, p)))
for n, p in RECORDS.items():
    entries.append((n, show(PIN, p)))
entries.append(("records/decision-log-rows.md", open(os.path.join(stage, "sweep/dlog-rows.md"), "rb").read()))
for n in ("347", "355"):
    entries.append((f"pr/pr{n}.json", open(os.path.join(stage, f"sweep/pr{n}.json"), "rb").read()))
for f in ("MANIFEST.md", "POINTERS.md"):
    entries.append((f, open(os.path.join(stage, "vmeta", f), "rb").read()))

names = [n for n, _ in entries]
assert len(names) == len(set(names)), "duplicate entry"
sums = "".join(f"{hashlib.sha256(b).hexdigest()}  {n}\n" for n, b in entries)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for n, b in entries + [("SHA256SUMS", sums.encode())]:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
print(len(entries) + 1, "entries")
