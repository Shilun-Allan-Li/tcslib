"""Gate 47 staging: build bundle.md and BUNDLE-FILES.txt (one uploadable file, workflow.md section 3).

Each section is '## ===== <path> (<source>) =====' followed by the file verbatim. Sources: this pack's files, the
records at the pin, the worker delivery at its exchange commit, entries of verification-r1.zip, and Lean files of the
TS1 tree. Usage: python3 -I mkbundle.py REPO PACKDIR OUTDIR
"""
import os
import subprocess
import sys
import zipfile

repo, packdir, outdir = sys.argv[1:4]
PIN = "95da6120f0b3b3c80e3078b1d497cbc93aa15fc4"
DELIV = "5451d3cd6fa9b8c313c9f18f5a4da3542c85f02a"
TS1 = "1eaf940b938bb52e3919f5569893b58522df599b"
R = "briefs/pass-shelat-ch5-8/"
Z = zipfile.ZipFile(os.path.join(packdir, "verification-r1.zip"))

plan = [("pack", "pack-r1.md")]
plan += [("rec", R + p) for p in (
    "cleanup-stage1/final-r1/review.md", "cleanup-stage1/final-r1/phase2.md",
    "cleanup-stage1/final-r1/stage2-addendum.tsv", "cleanup-stage1/checkpoint1-review.md", "cleanup-stages.md",
    "deferred-work.md", "duplication-ledger.md", "maintenance/dw5/README.md")]
plan += [("deliv", "inbox/fills/cleanup-stage1/" + p) for p in (
    "REPORT.md", "evidence/reuse/reuse-table.md", "evidence/stage2/repoint.tsv")]
plan += [("pack", "pr347-description.md"), ("pack", "pr355-description.md")]
plan += [("zip", p) for p in (
    "records/decision-log-rows.md", "MANIFEST.md", "POINTERS.md", "checks/series.txt", "checks/insertion.txt",
    "checks/sizes.txt", "checks/mergetrees.txt", "checks/downstream.txt", "checks/dup-sweep.txt",
    "phase2/PROVENANCE.txt", "phase2/build/permod.out", "phase2/build/check.out", "phase2/build/linkcount.txt",
    "phase2/admissions/admcmp.out", "phase2/axioms/axsum.out", "phase2/cmp/head-classify.txt",
    "phase2/cmp/tip-classify.txt", "phase2/cmp/head-vs-tip.txt", "phase2/cmp/head-vs-worker-head.txt",
    "phase2/cmp/head-vs-dw5-head.txt", "phase2/cmp/controls.txt", "phase2/cmp/scan-head.txt", "phase2/lint/lintcmp.out",
    "phase2/merge/merge-trees.txt", "phase1/PROVENANCE.txt", "phase1/statements/stmtcmp.out",
    "phase1/statements/doccheck.out", "phase1/statements/prooflen.out", "phase1/statements/added-scan.txt",
    "dw5/statements/frozencheck.txt", "dw5/statements/touched.out", "dw5/compare/seals-base-vs-head.txt",
    "dw5/axioms/axioms-summary.txt", "dw5/checks/nameclash.txt")]
plan += [("pack", "pr347.diff.txt"), ("pack", "pr355.diff.txt")]
plan += [("ts1", p) for p in (
    "TCSlib/Complexity/TuringMachine/Build/ModuleHost.lean",
    "TCSlib/Complexity/Randomized/Build/IterateFindHost.lean",
    "TCSlib/Complexity/Randomized/Build/IterateFind.lean",
    "TCSlib/Cryptography/Games/Tapes.lean",
    "TCSlib/Cryptography/ZeroKnowledge/InteractionWords.lean",
    "TCSlib/Cryptography/Pseudorandom/Functions/LazySampling.lean")]
plan += [("rec", p) for p in (
    "policy.md", "workflow.md", "briefs/pairings/gates/44-pairing-fills/findings-r1.md",
    "briefs/pairings/gates/44-pairing-fills/findings-r2.md", "briefs/lattice-gsw/gates/45-gsw-6a/findings-r1.md",
    "briefs/pairings/gates/48-bb1-sim-fill/findings-r1.md")]


def show(rev, p):
    return subprocess.run(["git", "-C", repo, "show", f"{rev}:{p}"], capture_output=True, check=True).stdout.decode()


parts, files = [], []
for kind, p in plan:
    if kind == "pack":
        text, hdr, line = open(os.path.join(packdir, p), encoding="utf-8").read(), f"{p} (this pack)", f"pack {p}"
    elif kind == "rec":
        text, hdr, line = show(PIN, p), f"{p} (records, at {PIN})", f"{PIN} {p}"
    elif kind == "deliv":
        text, hdr, line = show(DELIV, p), f"{p} (exchange delivery, at {DELIV})", f"{DELIV} {p}"
    elif kind == "zip":
        text = Z.read(p).decode("utf-8")
        hdr, line = f"verification-r1.zip:{p} (this pack)", f"zip:verification-r1.zip {p}"
    else:
        text, hdr, line = show(TS1, p), f"{p} (Lean, TS1 tree {TS1})", f"tree:{TS1} {p}"
    if p == "pack-r1.md":
        hdr = "pack-r1.md (this pack)"
    parts.append(f"## ===== {hdr} =====\n\n{text}{'' if text.endswith(chr(10)) else chr(10)}\n")
    files.append(line)
open(os.path.join(outdir, "bundle.md"), "w", encoding="utf-8").write("".join(parts))
open(os.path.join(outdir, "BUNDLE-FILES.txt"), "w", encoding="utf-8").write("\n".join(files) + "\n")
print(len(files), "sections")
