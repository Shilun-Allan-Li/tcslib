"""Gate 47 duplication sweep, step 1: same-short-name declarations.

For every new declaration of #347 and #355, list every declaration with the same
last name component in (a) the TS1 tree (TCSlib/ and audits/, read with git grep on
the tree object, no checkout) and (b) Mathlib, Batteries and Lean core at the pin.
Usage: python3 -I namesweep.py REPO TREE NAMEFILE... > out.tsv
"""
import os
import re
import subprocess
import sys

repo, tree = sys.argv[1], sys.argv[2]
names = []
for f in sys.argv[3:]:
    tag = os.path.basename(f).replace("names-", "").replace(".txt", "")
    for line in open(f, encoding="utf-8"):
        line = line.strip()
        if line:
            names.append((tag, line))

ext_roots = [
    os.path.join(repo, ".lake/packages/mathlib/Mathlib"),
    os.path.join(repo, ".lake/packages/batteries/Batteries"),
    os.path.expanduser("~/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean/Init"),
    os.path.expanduser("~/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean/Std"),
]
KW = r"(?:theorem|lemma|def|abbrev|instance|structure|inductive|class)"


def short(n):
    return n.split(".")[-1]


def git_grep(pat):
    r = subprocess.run(
        ["git", "-C", repo, "grep", "-n", "-P", pat, tree, "--", "TCSlib", "audits"],
        capture_output=True, text=True)
    return [l for l in r.stdout.splitlines() if l]


def ext_grep(pat):
    out = []
    for root in ext_roots:
        r = subprocess.run(["grep", "-rnP", "--include=*.lean", pat, root],
                           capture_output=True, text=True)
        out += [l.replace(os.path.expanduser("~"), "~") for l in r.stdout.splitlines() if l]
    return out


print("pr\tname\tscope\thit")
for tag, n in names:
    s = re.escape(short(n))
    pat = r"^\s*(?:@\[[^\]]*\]\s*)?(?:(?:protected|private|noncomputable|nonrec)\s+)*" + KW + r"\s+(?:\S*\.)?" + s + r"(?=[\s:({\[]|$)"
    for h in git_grep(pat):
        print(f"{tag}\t{n}\tTS1\t{h[len(tree)+1:]}")
    for h in ext_grep(pat):
        print(f"{tag}\t{n}\text\t{h}")
