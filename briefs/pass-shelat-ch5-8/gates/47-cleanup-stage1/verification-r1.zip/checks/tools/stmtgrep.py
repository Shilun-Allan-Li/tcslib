"""Gate 47 duplication sweep, step 3: statement-level regex search.

Reads every TCSlib .lean file of a tree object (git ls-tree / cat-file, no checkout),
splits it into declaration headers (from a theorem/lemma/def/abbrev keyword to the
first ':=' or '|' line), and prints the headers whose text matches the regex.
Usage: python3 -I stmtgrep.py REPO TREE REGEX [PATHPREFIX]
"""
import re
import subprocess
import sys

repo, tree, rx = sys.argv[1], sys.argv[2], re.compile(sys.argv[3], re.S)
prefix = sys.argv[4] if len(sys.argv) > 4 else "TCSlib"
ls = subprocess.run(["git", "-C", repo, "ls-tree", "-r", "--name-only", tree, "--", prefix],
                    capture_output=True, text=True).stdout.split()
KW = re.compile(r"^\s*(?:@\[[^\]]*\]\s*)?(?:(?:protected|private|noncomputable|nonrec)\s+)*"
                r"(theorem|lemma|def|abbrev)\s+(\S+)")
for path in ls:
    if not path.endswith(".lean"):
        continue
    src = subprocess.run(["git", "-C", repo, "show", f"{tree}:{path}"],
                         capture_output=True, text=True).stdout.splitlines()
    i = 0
    while i < len(src):
        m = KW.match(src[i])
        if not m:
            i += 1
            continue
        j, hdr = i, []
        while j < len(src) and j < i + 12:
            hdr.append(src[j])
            if ":=" in src[j] or (j > i and src[j].lstrip().startswith("|")):
                break
            j += 1
        text = " ".join(h.strip() for h in hdr)
        text = text.split(":=")[0]
        if rx.search(text):
            print(f"{path}:{i+1}\t{m.group(2)}\t{text[:300]}")
        i = j + 1
