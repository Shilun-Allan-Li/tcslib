"""Gate 47 staging: git-object checks for #347 and #355 (no checkout, no Lean).

Writes into OUTDIR: series.txt, insertion.txt, sizes.txt and source-head-r1.json.
Usage: python3 -I gitchecks.py REPO OUTDIR PR347.json PR355.json DIFF347 DIFF355
"""
import hashlib
import json
import os
import subprocess
import sys

repo, out, j347, j355, d347, d355 = sys.argv[1:7]
PIN = "659542ecd9413b504d30da8c937b9805e6c1f71f"
E = "e1d39836ed4a69a34914c35f4c73c71de853dcc6"
BASE347 = "2da7e0f3cd65ec93ed71813b7828c3b66ba18942"
A = "daa6e173cdd94cad1475b9a96eca613bce53ba61"
B = "d3c7cb00092ad5913904654d922f30fc7d5fce4a"
TS1 = "1eaf940b938bb52e3919f5569893b58522df599b"
PINX355 = "20d1101ade46ba26919f01e30f7ee9422495669b"
LEAN = ["TCSlib", "TCSlib.lean", "audits", "scripts", "lakefile.lean", "lakefile.toml",
        "lake-manifest.json", "lean-toolchain"]


def git(*a, inp=None):
    return subprocess.run(["git", "-C", repo, *a], capture_output=True, text=True,
                          input=inp).stdout


def commits(base, head):
    res = []
    for c in git("rev-list", "--reverse", f"{base}..{head}").split():
        raw = git("cat-file", "-p", c)
        hdr = raw.split("\n\n", 1)[0]
        res.append({
            "commit": c,
            "parent": git("rev-parse", f"{c}^").strip(),
            "tree": git("rev-parse", f"{c}^{{tree}}").strip(),
            "gpgsig": int("\ngpgsig " in "\n" + hdr),
            "author": git("log", "-1", "--format=%an <%ae> %aI", c).strip(),
            "committer": git("log", "-1", "--format=%cn <%ce> %cI", c).strip(),
            "subject": git("log", "-1", "--format=%s", c).strip(),
            "trailers": [("Co-Authored-By: (present)" if t.startswith("Co-Authored-By:") else t)
                         for t in git("log", "-1", "--format=%(trailers:only,unfold)", c).strip().splitlines()],
            "files": git("diff-tree", "--no-commit-id", "--name-only", "-r", c).split(),
        })
    return res


def numstat(a, b):
    rows = []
    for l in git("diff", "--numstat", a, b).splitlines():
        ad, de, p = l.split("\t")
        rows.append((p, int(ad), int(de)))
    return rows


def fileinfo(rev, path):
    blob = git("rev-parse", f"{rev}:{path}").strip()
    data = subprocess.run(["git", "-C", repo, "cat-file", "blob", blob], capture_output=True).stdout
    text = data.decode("utf-8")
    lines = text.splitlines()
    return {"blob": blob, "sha256": hashlib.sha256(data).hexdigest(), "lines": len(lines),
            "max_width": max((len(l) for l in lines), default=0)}


s = []
s.append(f"records pin (records-only advance from 95da6120, the tip fetched 2026-11-17 11:24 UTC): {PIN}")
s.append(f"  pin log: {git('log', '-1', '--format=%s', PIN).strip()}")
s.append(f"  phase-2 records tip e1d39836 is an ancestor of the pin: "
         f"{subprocess.run(['git','-C',repo,'merge-base','--is-ancestor',E,PIN]).returncode == 0}")
lean_e_pin = git("diff", "--name-only", E, PIN, "--", *LEAN).split()
s.append(f"  Lean paths 95da6120..pin: {len(git('diff', '--name-only', '95da6120f0b3b3c80e3078b1d497cbc93aa15fc4', PIN, '--', *LEAN).split())}")
s.append(f"  Lean paths e1d39836..pin: {len(lean_e_pin)} (the #357 merge 8060f6b7): {', '.join(lean_e_pin)}")
s.append("")
s.append(f"#347 head {A}; merge base with the pin {git('merge-base', A, PIN).strip()}")
s.append(f"#355 head {B}; base branch cleanup/dw5-derand-readers = {A}; #347 is an ancestor: "
         f"{subprocess.run(['git','-C',repo,'merge-base','--is-ancestor',A,B]).returncode == 0}")
s.append(f"#355 tree {git('rev-parse', B + '^{tree}').strip()} (records: 508f9154...)")
for name, base, head in (("#347", BASE347, A), ("#355", A, B)):
    s.append(f"\n{name} commits {base[:8]}..{head[:8]}:")
    for c in commits(base, head):
        s.append(f"  {c['commit']} parent {c['parent'][:8]} tree {c['tree'][:8]} gpgsig {c['gpgsig']}"
                 f" | {c['subject']}")
        s.append(f"    author {c['author']}; committer {c['committer']}")
        s.append(f"    trailers: {' / '.join(c['trailers'])}")
        s.append(f"    files: {', '.join(c['files'])}")
t_ea = git("merge-tree", "--write-tree", E, A).split()[0]
s.append(f"\nTS1 recomputation: merge-tree e1d39836 x #347 = {t_ea}; TS1 = {TS1} (recorded); "
         f"TS1 is a tree object: {git('cat-file', '-t', TS1).strip()}")
s.append(f"TS1 vs e1d39836 Lean: {git('diff', '--shortstat', E, TS1, '--', *LEAN).strip()}")
s.append(f"pin x #355 = {PINX355}; Lean paths differing from TS1: "
         f"{len(git('diff', '--name-only', TS1, PINX355, '--', *LEAN).split())} (exactly #357's 9, blob-equal "
         f"to dfdc56f2; mergetrees.txt)")
s.append("\nrange-diff of the worker series (exchange 5451d3cd, COMMITS.tsv) against #355:")
s.append(git("range-diff", f"{A}..c8021348f9bc2d16cfa52ca5e8ff489dc9543592", f"{A}..{B}").rstrip())
s.append(f"worker head c8021348 tree {git('rev-parse', 'c8021348f9bc2d16cfa52ca5e8ff489dc9543592^{tree}').strip()}")
open(os.path.join(out, "series.txt"), "w").write("\n".join(s) + "\n")

ins = ["Per-file line counts (git diff --numstat); deleted lines are listed in full.", ""]
for name, base, head in (("#347", BASE347, A), ("#355", A, B)):
    rows = numstat(base, head)
    ins.append(f"{name} {base[:8]}..{head[:8]}: {len(rows)} files, +{sum(r[1] for r in rows)}/-{sum(r[2] for r in rows)}")
    for p, ad, de in rows:
        ins.append(f"  +{ad:<5} -{de:<5} {p}")
    for p, ad, de in rows:
        if de and not p.endswith("IterateFind.lean"):
            ins.append(f"  deleted lines in {p}:")
            for l in git("diff", "-U0", base, head, "--", p).splitlines():
                if l.startswith("-") and not l.startswith("---"):
                    ins.append(f"    {l}")
    ins.append("")
open(os.path.join(out, "insertion.txt"), "w").write("\n".join(ins) + "\n")

paths = git("diff", "--name-only", E, TS1).split()
sz = ["path\tlines base(e1d39836)\tlines TS1\tmax width TS1\tmax width of added lines\tblob TS1\tsha256 TS1"]
files = {}
for p in paths:
    hi = fileinfo(TS1, p)
    if git("cat-file", "-t", f"{E}:{p}").strip() == "blob":
        bi = fileinfo(E, p)
        bl = str(bi["lines"])
    else:
        bi, bl = None, "new"
    added = [l[1:] for l in git("diff", "-U0", E, TS1, "--", p).splitlines()
             if l.startswith("+") and not l.startswith("+++")]
    aw = max((len(l) for l in added), default=0)
    files[p] = {"ts1": hi, "base_e1d39836": bi,
                "blob_equal_355_head": git("rev-parse", f"{B}:{p}").strip() == hi["blob"]}
    sz.append(f"{p}\t{bl}\t{hi['lines']}\t{hi['max_width']}\t{aw}\t{hi['blob'][:12]}\t{hi['sha256']}")
open(os.path.join(out, "sizes.txt"), "w").write("\n".join(sz) + "\n")

p347, p355 = json.load(open(j347)), json.load(open(j355))
sh = {
    "records_pin": PIN,
    "phase2_records_tip": E,
    "TS1": TS1,
    "pin_x_355_tree": PINX355,
    "pr347": {"head": A, "branch": "cleanup/dw5-derand-readers", "base_branch": p347["base"]["ref"],
              "merge_base": BASE347, "rest_base_sha": p347["base"]["sha"],
              "rest_updated_at": p347["updated_at"], "draft": p347["draft"],
              "commits": commits(BASE347, A),
              "diff_sha256": hashlib.sha256(open(d347, "rb").read()).hexdigest()},
    "pr355": {"head": B, "branch": "land/cleanup-stage1", "base_branch": p355["base"]["ref"],
              "base": A, "rest_base_sha": p355["base"]["sha"], "rest_updated_at": p355["updated_at"],
              "draft": p355["draft"], "commits": commits(A, B),
              "diff_sha256": hashlib.sha256(open(d355, "rb").read()).hexdigest()},
    "files_tip_to_TS1": files,
}
json.dump(sh, open(os.path.join(out, "source-head-r1.json"), "w"), indent=1, ensure_ascii=False)
print("ok", len(paths))
