#!/bin/bash
# Gate 47 duplication sweep, step 2: statement-shape greps on the TS1 tree object
# (git grep, no checkout) and on Mathlib, Batteries and Lean core at the pin.
# Usage: shapesweep.sh REPO TREE > out.txt
R=$1; T=$2
ML=$R/.lake/packages/mathlib/Mathlib; BT=$R/.lake/packages/batteries/Batteries
CORE=$HOME/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean
g() { echo "### TS1 $1"; git -C "$R" grep -n -P -e "$2" "$T" -- TCSlib audits | sed "s|^$T:||" | cut -c1-260; }
x() { echo "### EXT $1"; grep -rnP --include=*.lean -e "$2" "$ML" "$BT" "$CORE/Init" "$CORE/Std" 2>/dev/null | sed "s|$R/.lake/packages/||; s|$HOME|~|" | cut -c1-260; }

g getD_ofFn            '\(List\.ofFn [^)]*\)\.getD'
x getD_ofFn            '(theorem|lemma) \S*getD\S*ofFn|(theorem|lemma) \S*ofFn\S*getD'
g zipWith_xor          'zipWith xor \(List\.zipWith xor|zipWith \(\. \^\^ \.\) \(List\.zipWith'
x zipWith_xor          '(theorem|lemma) \S*(xor|Xor)\S*(cancel|self)|zipWith \(\. \^\^ \.\)|zipWith xor'
g recordBits           'false :: List\.replicate'
g statClose_uprob_ne   'StatClose .*uprob fun [a-z]+ => [^ ]+ [a-z]+ ≠'
g expect_sample_uexp   'expect \(sample [^)]*\) [a-z]+ = uexp|uexp [a-z]+ = expect \(sample'
g costBounded_zero     'CostBoundedBy[^:]*\) 0\)? *:|CostBoundedBy \(fun _ => 1\) 0'
g encodeList_flatMap   'encodeList [a-z]+ = [a-z]+\.flatMap'
g pkPredictor          'pkPredictor [A-Za-z]+ [a-z]+ [a-z]+ [a-z]+ ='
g length_ofFn_coins    '\(List\.ofFn [a-z]+\)\.length = [A-Za-z]+\.coins\.eval'
g toOracleAdv_padFin   'toOracleAdversary .*\.eval .*padFin'
g blocks_symm_flatMap  'blocks [^)]*\)\.symm [A-Za-z]+\) = '
g splitBits_take       'ofFn \(split(Bits|Coins) [a-z]+\)\.(1|2|fst|snd) = |\(List\.ofFn [a-z]+\)\.(take|drop) [a-z]+ = List\.ofFn \(split'
x ofFn_take_drop       '(theorem|lemma) (List\.)?(ofFn_take|take_ofFn|drop_ofFn|ofFn_drop|ofFn_add|ofFn_fin_append|ofFn_append)\b'
g extTape_shape        'if h : [a-z]+ < [a-zκ]+ then [A-Za-z]+ ⟨[a-z]+, h⟩ else Classical\.arbitrary'
g ovr_shape            'Function\.update \([a-zA-Z]+ [A-Z] [A-Z]\) [a-z] [a-z]'
g tape_expect          'expect \(sample \(Fin [a-zκ]+ → [a-zτA-Z]+\)\)'
g fresh_impl           '\(sample [τA-Za-z]+\)\.bind \([A-Z] [a-z] [a-z] [a-z]\)'
g encodeLog_length     '\.length ≤ \([a-z]+\.encodeLog [a-z]+\)\.length'
g padTo_shape          '\(w \+\+ List\.replicate [A-Za-z]+ false\)\.take|\.take [A-Z] *$'
x takeD                '(theorem|lemma|def) (List\.)?(takeD|takeD_\S*|\S*_takeD)\b|(theorem|lemma) (List\.)?rightpad\S*'
g zeros_shape          'PolyTimeComputable fun [a-z]+ => List\.replicate \([A-Za-z]+ [a-z]+\) false'
g flatMap_range_ite    '\(List\.range [A-Z]+\)\.flatMap \(fun [a-z]+ => if'
g flatMap_range_poly   'PolyTimeComputable fun [a-z]+ => \(List\.range'
g iterSnd              'PolyTimeComputable fun [a-z]+ => pairSndD\^\['
g encodeMsgs_foldr     'encodeMsgs [a-z]+ = [a-z]+\.foldr pairEncode'
g encodeMsgs_flatMap   'encodeMsgs [a-zA-Z]+ = [a-zA-Z]+\.flatMap'
g iterate_pairSndD     'pairSndD\^\[[a-z]+\] \((Strategy\.)?encodeMsgs [a-z]+\) = '
g msgAt                'pairFstD \(pairSndD\^\[[a-z]+\] \((Strategy\.)?encodeMsgs|getD [a-z]+ \[\] = pairFstD'
g encWords             'encodeMsgs [A-Za-z]+ = (Complexity\.)?(BinArith\.)?encWords'
g findist_map_map      '\(([a-z]+)\.map [a-z]+\)\.map [a-z]+ = '
g findist_probTrue     'probTrue [A-Z] ≤ 1|0 ≤ [a-z]+\.probTrue'
g findist_uniform_prod '\(FinDist\.uniform [α-ω]\)\.prod|uniform [α-ω]\)\.map [a-z]+ = (FinDist\.)?uniform'
g findist_mixture      '[a-z]+ \* [a-z]+ [a-z] \+ \(1 - [a-z]+\) \* [a-z]+ [a-z]'
g host_views           'hostTMView|copyTMView'
g host_step_shape      '\(hostTM [^)]*\)\.tm\.step'
