/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity
/- G06-HARNESS INSTALL AdaptiveSecuritySeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "AdaptiveSecuritySeal"
  let payload : String := "Complexity.NUPPT.coinLen\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.runAt\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.toCompOn\tTCSlib.Cryptography.Games.Machines\nComplexity.pairFstD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nComplexity.pairSndD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.inLens\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indCodec\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indGame\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.outLens\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Games.OracleComp.bind\tTCSlib.Cryptography.Games.OracleComp\nTCSlib.Cryptography.Games.ProbComp.sample\tTCSlib.Cryptography.Games.Probability\nTCSlib.Cryptography.Games.advantage\tTCSlib.Cryptography.Games.Advantage\nTCSlib.Cryptography.Games.simulate\tTCSlib.Cryptography.Games.Simulate\nTCSlib.Cryptography.Games.zeroBits\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Negligible\tTCSlib.Cryptography.Foundations.Negligible\nTCSlib.Cryptography.decodeFin\tTCSlib.Cryptography.Asymptotic.Adversary\nTCSlib.Cryptography.padFin\tTCSlib.Cryptography.Asymptotic.Adversary\nTuring.pairEncode\tTCSlib.Complexity.TuringMachine.Encoding"
  let expectedRequests : Nat := 23
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "Complexity.NUPPT.coinLen\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"coinLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.runAt\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"runAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.toCompOn\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"toCompOn\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nComplexity.pairFstD\t[[\"str\",\"Complexity\"],[\"str\",\"pairFstD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nComplexity.pairSndD\t[[\"str\",\"Complexity\"],[\"str\",\"pairSndD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"INDSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.inLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"inLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"indCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"indGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"indImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.outLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"outLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"splitHalf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.OracleComp.bind\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"],[\"str\",\"bind\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.ProbComp.sample\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"ProbComp\"],[\"str\",\"sample\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.advantage\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"advantage\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Advantage\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.simulate\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"simulate\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Simulate\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.zeroBits\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"zeroBits\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Negligible\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Negligible\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Negligible\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.decodeFin\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"decodeFin\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Adversary\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.padFin\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"padFin\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Adversary\"]]\tfalse\tfalse\tfalse\nTuring.pairEncode\t[[\"str\",\"Turing\"],[\"str\",\"pairEncode\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"TuringMachine\"],[\"str\",\"Encoding\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Adaptive left-or-right public-key security

An extension of the fixed-length game of [PS10, Definition 171.5] with one hidden bit,
one generated key pair, and a polynomial cap on fresh challenges. The adversary may
choose each pair of messages after seeing the earlier answers. In the CCA2 game the
decryptor refuses every ciphertext already issued as a challenge.

## Main definitions

* `FixedLengthPKScheme.adaptiveIndImpl` implements the two oracles and their history.
* `FixedLengthPKScheme.adaptiveIndGame` runs the existing adversary codec with those oracles.
* `FixedLengthPKScheme.AdaptiveINDSecure` is the negligible-advantage condition.

## Main results

* `FixedLengthPKScheme.adaptiveIndGame_one` recovers the exact single-challenge game.
* `FixedLengthPKScheme.AdaptiveINDSecure.single` specializes the security predicate.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
-/

namespace TCSlib.Cryptography.Composability.FixedLengthPKScheme

open Complexity Turing TCSlib.Cryptography.Games

variable (S : FixedLengthPKScheme)

/-- Extend [PS10, Definition 171.5] to a bounded list of fresh left-or-right challenges.
The history records each issued challenge. A decryption query in the history receives
the existing refusal reply. Once the challenge cap is reached the game repeats the
latest ciphertext, with a zero reply for a zero cap and empty history. The history is
a list so a repeated ciphertext still consumes one fresh challenge. -/
noncomputable def adaptiveIndImpl (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (cap : ℕ) : QueryImpl (S.indSpec n) (List (Fin (S.ctLen.eval n) → Bool)) unifSpec
  | 0, c, history =>
    if cast (S.indSpec_decDom n) c ∈ history then
      .pure (zeroBits _, history)
    else
      (S.indImpl atk b n pk sk 0 c history.head?).bind fun res => .pure (res.1, history)
  | 1, mm, history =>
    if history.length < cap then
      (S.indImpl atk b n pk sk 1 mm none).bind fun res => .pure (res.1, res.2.toList ++ history)
    else
      match history.head? with
      | none => .pure (zeroBits _, history)
      | some c =>
        (S.indImpl atk b n pk sk 1 mm (some c)).bind fun res => .pure (res.1, history)

/-- Decryption refuses every ciphertext recorded in the challenge history. -/
theorem adaptiveIndImpl_dec_issued (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (cap : ℕ) (c : (S.indSpec n).dom 0)
    (history : List (Fin (S.ctLen.eval n) → Bool))
    (hc : cast (S.indSpec_decDom n) c ∈ history) :
    S.adaptiveIndImpl atk b n pk sk cap 0 c history = .pure (zeroBits _, history) := by
  rw [adaptiveIndImpl, if_pos hc]

/-- A challenge below the cap uses the single game's fresh challenge branch, then
adds that ciphertext to the history. -/
theorem adaptiveIndImpl_challenge_fresh (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (cap : ℕ) (mm : (S.indSpec n).dom 1)
    (history : List (Fin (S.ctLen.eval n) → Bool)) (h : history.length < cap) :
    S.adaptiveIndImpl atk b n pk sk cap 1 mm history =
      (S.indImpl atk b n pk sk 1 mm none).bind
        (fun res => .pure (res.1, res.2.toList ++ history)) := by
  rw [adaptiveIndImpl, if_pos h]

/-- A fresh challenge samples an encryption tape, returns the selected encryption, and
prepends exactly that ciphertext to the history.

**Proof sketch.** Read the original game's first-challenge equation on the specification's
type, then simplify the continuation that saves the returned ciphertext. -/
theorem adaptiveIndImpl_challenge_encrypt (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (cap : ℕ) (mm : (S.indSpec n).dom 1)
    (history : List (Fin (S.ctLen.eval n) → Bool)) (h : history.length < cap) :
    S.adaptiveIndImpl atk b n pk sk cap 1 mm history =
      (ProbComp.sample (S.enc.Coins n)).bind fun r =>
        let halves := FixedLengthScheme.splitHalf (cast (S.indSpec_challengeDom n) mm)
        let c := padFin (S.ctLen.eval n) (S.enc.runAt n
          (pairEncode pk (List.ofFn (if b then halves.2 else halves.1))) r)
        .pure (cast (S.indSpec_challengeRng n).symm c, c :: history) := by
  rw [S.adaptiveIndImpl_challenge_fresh atk b n pk sk cap mm history h,
    S.indImpl_challenge_none_onSpec, OracleComp.bind_assoc]
  simp only [OracleComp.pure_bind, Option.toList_some, List.singleton_append]

/-- A positive cap of one issues a fresh first challenge, as in Definition 171.5. -/
private theorem adaptiveIndImpl_one_empty (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) :
    S.adaptiveIndImpl atk b n pk sk 1 1 mm [] =
      (S.indImpl atk b n pk sk 1 mm none).bind (fun res => .pure (res.1, res.2.toList)) := by
  rw [S.adaptiveIndImpl_challenge_fresh atk b n pk sk 1 mm []
    (by simp only [List.length_nil, Nat.zero_lt_one])]
  simp only [List.append_nil]

/-- At a full challenge cap, repeat the latest ciphertext without adding to the history. -/
theorem adaptiveIndImpl_challenge_full (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (cap : ℕ) (mm : (S.indSpec n).dom 1)
    (history : List (Fin (S.ctLen.eval n) → Bool)) (h : cap ≤ history.length)
    (c : Fin (S.ctLen.eval n) → Bool) (hc : history.head? = some c) :
    S.adaptiveIndImpl atk b n pk sk cap 1 mm history =
      (S.indImpl atk b n pk sk 1 mm (some c)).bind
        (fun res => .pure (res.1, history)) := by
  rw [adaptiveIndImpl, if_neg (Nat.not_lt_of_ge h), hc]

/-- A zero challenge cap keeps the initial history empty and returns the zero reply. -/
theorem adaptiveIndImpl_challenge_zero (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) :
    S.adaptiveIndImpl atk b n pk sk 0 1 mm [] = .pure (zeroBits _, []) := by
  rw [adaptiveIndImpl, if_neg (Nat.not_lt_zero _)]
  rfl

/-- Decryption outside the history uses the original oracle's availability and decoding
rules. Its answer leaves the full history unchanged. -/
theorem adaptiveIndImpl_dec_other (atk : Attack) (b : Bool) (n : ℕ)
    (pk sk : List Bool) (cap : ℕ) (c : (S.indSpec n).dom 0)
    (history : List (Fin (S.ctLen.eval n) → Bool))
    (hc : cast (S.indSpec_decDom n) c ∉ history) :
    S.adaptiveIndImpl atk b n pk sk cap 0 c history =
      (S.indImpl atk b n pk sk 0 c history.head?).bind (fun res => .pure (res.1, history)) := by
  rw [adaptiveIndImpl, if_neg hc]

/-- At cap one, each oracle call agrees with the old game when the optional challenge is
represented as a list.

**Proof sketch.** Split by oracle and old challenge state. For decryption the
single-game state is preserved. A fresh challenge creates one list entry, and a repeat
returns the same state. -/
theorem adaptiveIndImpl_one (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    (i : Fin 2) (x : (S.indSpec n).dom i) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    S.adaptiveIndImpl atk b n pk sk 1 i x s.toList =
      (S.indImpl atk b n pk sk i x s).bind (fun res => .pure (res.1, res.2.toList)) := by
  have hi : i = 0 ∨ i = 1 := by fin_cases i <;> decide
  rcases hi with rfl | rfl
  · cases s with
    | none =>
      rw [Option.toList_none, S.adaptiveIndImpl_dec_other atk b n pk sk 1 x []
        List.not_mem_nil, List.head?_nil, S.indImpl_dec_onSpec]
      split <;> simp only [OracleComp.pure_bind, Option.toList_none]
    | some c =>
      by_cases h : cast (S.indSpec_decDom n) x = c
      · rw [S.adaptiveIndImpl_dec_issued atk b n pk sk 1 x (some c).toList (by
          simp only [Option.toList_some, List.mem_singleton]; exact h)]
        rw [S.indImpl_dec_onSpec, h]
        simp
      · rw [S.adaptiveIndImpl_dec_other atk b n pk sk 1 x (some c).toList (by
          simp only [Option.toList_some, List.mem_singleton]; exact h)]
        simp only [Option.toList_some, List.head?_cons, S.indImpl_dec_onSpec]
        split <;> simp only [OracleComp.pure_bind, Option.toList_some]
  · cases s with
    | none => exact S.adaptiveIndImpl_one_empty atk b n pk sk x
    | some c =>
      rw [S.adaptiveIndImpl_challenge_full atk b n pk sk 1 x (some c).toList (by simp) c (by simp),
        S.indImpl_challenge_repeat_onSpec]
      simp only [OracleComp.pure_bind]

/-- Cap-one simulation is the single-challenge simulation with its final state encoded
as a list.

**Proof sketch.** Induct over the adversary's query tree and apply the per-call equality. -/
theorem simulate_adaptiveIndImpl_one (atk : Attack) (b : Bool) (n : ℕ) (pk sk : List Bool)
    {α : Type} (t : OracleComp (S.indSpec n) α) (s : Option (Fin (S.ctLen.eval n) → Bool)) :
    simulate (S.adaptiveIndImpl atk b n pk sk 1) t s.toList =
      (simulate (S.indImpl atk b n pk sk) t s).bind
        (fun res => .pure (res.1, res.2.toList)) := by
  induction t generalizing s with
  | pure a => simp only [simulate_pure, OracleComp.pure_bind]
  | query i x k ih =>
    simp only [simulate_query, S.adaptiveIndImpl_one, OracleComp.bind_assoc, OracleComp.pure_bind]
    congr 1
    funext res
    exact ih res.1 res.2

/-- The left-or-right game uses one key and hidden bit across the adaptive queries. -/
noncomputable def adaptiveIndGame (atk : Attack) (A : NUPPT) (q cap : ℕ) (b : Bool) (n : ℕ) :
    ProbComp Bool :=
  (ProbComp.sample (S.gen.Coins n)).bind fun rg =>
  (ProbComp.sample (A.Coins n)).bind fun r =>
  (simulate (S.adaptiveIndImpl atk b n (pairFstD (S.gen.runAt n [] rg))
      (pairSndD (S.gen.runAt n [] rg)) cap)
      (A.toCompOn (S.indCodec n) n q (pairFstD (S.gen.runAt n [] rg)) r) []).bind
    fun res => .pure (res.1 0)

/-- The experiment's only sampled keys come from one activation of key generation. -/
theorem adaptiveIndGame_eq (atk : Attack) (A : NUPPT) (q cap : ℕ) (b : Bool) (n : ℕ) :
    S.adaptiveIndGame atk A q cap b n =
      (ProbComp.sample (S.gen.Coins n)).bind fun rg =>
      (ProbComp.sample (A.Coins n)).bind fun r =>
      (simulate (S.adaptiveIndImpl atk b n (pairFstD (S.gen.runAt n [] rg))
          (pairSndD (S.gen.runAt n [] rg)) cap)
          (A.toCompOn (S.indCodec n) n q (pairFstD (S.gen.runAt n [] rg)) r) []).bind
        fun res => .pure (res.1 0) := rfl

/-- The cap-one experiment and the existing single-challenge experiment return the same bit
on the same sampled generator and adversary tapes.

**Proof sketch.** Fix both sampled tapes and apply the simulation correspondence.
Both experiments read the same bit of the simulation's result. -/
theorem adaptiveIndGame_one (atk : Attack) (A : NUPPT) (q : ℕ) (b : Bool) (n : ℕ) :
    S.adaptiveIndGame atk A q 1 b n = S.indGame atk A q b n := by
  simp only [S.adaptiveIndGame_eq, S.indGame_eq]
  congr 1
  funext rg
  congr 1
  funext r
  rw [← Option.toList_none (α := Fin (S.ctLen.eval n) → Bool), S.simulate_adaptiveIndImpl_one,
    OracleComp.bind_assoc]
  simp only [OracleComp.pure_bind]

/-- The adversary's left-or-right advantage is negligible for polynomial total and
challenge budgets. The first catalog witnesses will have message length equal to the
security parameter. -/
def AdaptiveINDSecure (atk : Attack) : Prop :=
  ∀ (A : NUPPT) (q cap : PolyExpr), ∃ ε : ℕ → ℝ, Negligible ε ∧ ∀ n,
    advantage (S.adaptiveIndGame atk A (q.eval n) (cap.eval n) false n)
      (S.adaptiveIndGame atk A (q.eval n) (cap.eval n) true n) ≤ ε n

/-- The adaptive predicate quantifies over both the total query and challenge budgets. -/
theorem adaptiveINDSecure_iff (atk : Attack) :
    S.AdaptiveINDSecure atk ↔
      ∀ (A : NUPPT) (q cap : PolyExpr), ∃ ε : ℕ → ℝ, Negligible ε ∧ ∀ n,
        advantage (S.adaptiveIndGame atk A (q.eval n) (cap.eval n) false n)
          (S.adaptiveIndGame atk A (q.eval n) (cap.eval n) true n) ≤ ε n :=
  Iff.rfl

/-- Adaptive security entails security in the original game.

**Proof sketch.** Use the constant cap one and the exact simulation equation. -/
theorem AdaptiveINDSecure.single {atk : Attack} (h : S.AdaptiveINDSecure atk) :
    S.INDSecure atk := by
  rw [S.adaptiveINDSecure_iff] at h
  rw [S.INDSecure_iff]
  intro A q
  obtain ⟨ε, hε, hb⟩ := h A q (.const 1)
  refine ⟨ε, hε, fun n => ?_⟩
  simpa only [PolyExpr.eval_const, S.adaptiveIndGame_one] using hb n

end TCSlib.Cryptography.Composability.FixedLengthPKScheme
/- G06-HARNESS EOF-VERIFY AdaptiveSecuritySeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "AdaptiveSecuritySeal"
  let payload : String := "Complexity.NUPPT.coinLen\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.runAt\tTCSlib.Complexity.Randomized.PPT\nComplexity.NUPPT.toCompOn\tTCSlib.Cryptography.Games.Machines\nComplexity.pairFstD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nComplexity.pairSndD\tTCSlib.Complexity.ClassNP.PolyTimePairing\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.inLens\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indCodec\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indGame\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.outLens\tTCSlib.Cryptography.Encryption.PublicKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Games.OracleComp.bind\tTCSlib.Cryptography.Games.OracleComp\nTCSlib.Cryptography.Games.ProbComp.sample\tTCSlib.Cryptography.Games.Probability\nTCSlib.Cryptography.Games.advantage\tTCSlib.Cryptography.Games.Advantage\nTCSlib.Cryptography.Games.simulate\tTCSlib.Cryptography.Games.Simulate\nTCSlib.Cryptography.Games.zeroBits\tTCSlib.Cryptography.Games.BitCodec\nTCSlib.Cryptography.Negligible\tTCSlib.Cryptography.Foundations.Negligible\nTCSlib.Cryptography.decodeFin\tTCSlib.Cryptography.Asymptotic.Adversary\nTCSlib.Cryptography.padFin\tTCSlib.Cryptography.Asymptotic.Adversary\nTuring.pairEncode\tTCSlib.Complexity.TuringMachine.Encoding"
  let expectedRequests : Nat := 23
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "Complexity.NUPPT.coinLen\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"coinLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.runAt\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"runAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"Randomized\"],[\"str\",\"PPT\"]]\tfalse\tfalse\tfalse\nComplexity.NUPPT.toCompOn\t[[\"str\",\"Complexity\"],[\"str\",\"NUPPT\"],[\"str\",\"toCompOn\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Machines\"]]\tfalse\tfalse\tfalse\nComplexity.pairFstD\t[[\"str\",\"Complexity\"],[\"str\",\"pairFstD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nComplexity.pairSndD\t[[\"str\",\"Complexity\"],[\"str\",\"pairSndD\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"ClassNP\"],[\"str\",\"PolyTimePairing\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.INDSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"INDSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.inLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"inLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"indCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"indGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"indImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthPKScheme.outLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthPKScheme\"],[\"str\",\"outLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PublicKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"splitHalf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.OracleComp.bind\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"],[\"str\",\"bind\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"OracleComp\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.ProbComp.sample\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"ProbComp\"],[\"str\",\"sample\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.advantage\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"advantage\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Advantage\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.simulate\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"simulate\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"Simulate\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Games.zeroBits\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"zeroBits\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Games\"],[\"str\",\"BitCodec\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Negligible\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Negligible\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Negligible\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.decodeFin\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"decodeFin\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Adversary\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.padFin\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"padFin\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Adversary\"]]\tfalse\tfalse\tfalse\nTuring.pairEncode\t[[\"str\",\"Turing\"],[\"str\",\"pairEncode\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Complexity\"],[\"str\",\"TuringMachine\"],[\"str\",\"Encoding\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

