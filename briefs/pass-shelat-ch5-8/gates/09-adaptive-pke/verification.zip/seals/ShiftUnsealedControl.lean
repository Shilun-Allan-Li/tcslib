import TCSlib.Cryptography.Asymptotic.CollectionShift

open TCSlib.Cryptography

example (T : TrapdoorCollection) (c : Nat) : (T.shiftParameter c).eval = T.eval := by
  rfl
