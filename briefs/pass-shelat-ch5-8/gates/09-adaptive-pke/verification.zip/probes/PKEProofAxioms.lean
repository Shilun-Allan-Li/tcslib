import Lean
import TCSlib.Cryptography.Encryption.PublicKey
import TCSlib.Cryptography.ZeroKnowledge.NP
import TCSlib.Cryptography.Asymptotic

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def selectedLegacy : Array String := #[
  "TCSlib.Cryptography.Candidates.rsaTrapdoor_encD_length",
  "TCSlib.Cryptography.Candidates.rsaTrapdoor_shiftParameter_encD_length",
  "TCSlib.Cryptography.Candidates.rabinBlumTrapdoor_encD_length",
  "TCSlib.Cryptography.Candidates.rabinBlumTrapdoor_shiftParameter_encD_length",
  "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSpec_decDom",
  "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSpec_challengeDom",
  "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSpec_challengeRng",
  "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_dec_onSpec",
  "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_challenge_repeat_onSpec",
  "TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_challenge_none_onSpec",
  "TCSlib.Cryptography.Negligible.comp_of_le"]

def inScope (owner : Name) (name : Name) : Bool :=
  owner.toString.endsWith ".AdaptiveSecurity" || owner.toString.endsWith ".CollectionShift" ||
    selectedLegacy.any (fun root => name.toString == root || name.toString.startsWith (root ++ "."))

def home? (env : Environment) (n : Name) : Option Name := do
  let i ← env.getModuleIdxFor? n
  env.header.moduleNames[i.toNat]?

run_cmd do
  let env ← getEnv
  let mut count := 0
  let standard : List Name := [`propext, `Classical.choice, `Quot.sound]
  for (name, _) in env.constants.toList do
    let some owner := home? env name | continue
    unless inScope owner name do continue
    let axioms ← Lean.collectAxioms name
    unless axioms.all standard.contains do
      throwError "Unexpected axiom set for {name}: {axioms}"
    count := count + 1
    liftIO <| IO.println s!"AXIOMS {name}: {axioms}"
  liftIO <| IO.println s!"CENSUS {count} selected declarations use standard axioms only"
