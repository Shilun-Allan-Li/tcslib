import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
tools = Path(sys.argv[1])
root = Path("audit-overlay")
probe = Path("probe")
evidence = Path("pke-evidence")
scope = evidence / "seals"
scope.mkdir(exist_ok=True)

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

bs = load(tools / "build_seals.py", "seal_builder")
controls = load(tools / "build_controls.py", "seal_controls")
adapter = load(tools / "request_payload_adapter.py", "seal_adapter")
adapter.configure_builders(bs, controls)

rows = [json.loads(line.removeprefix("SEAL_CAND "))
        for line in (evidence / "probes/PKESealCandidates.log").read_text().splitlines()
        if line.startswith("SEAL_CAND ")]
assert rows
groups = {}
for row in rows:
    if row["name"] == "Complexity.PolyExpr.eval" or (row["status"] == "[reducible]" and not row["matcher"]):
        continue
    req = {**row, "spelling": row["name"], "collector_reducibility": row["status"][1:-1]}
    groups.setdefault(row["owner"], []).append(req)

def emit(label, raw, requests, source):
    requests = sorted(requests, key=lambda r: r["spelling"])
    data, insertions, mapping = bs.instrument(raw, bs.header(raw), label, requests)
    (probe / f"{label}.lean").write_bytes(data)
    (scope / f"{label}.json").write_text(json.dumps({
        "source": source, "source_sha256": bs.sha(raw), "probe_sha256": bs.sha(data),
        "requests": requests, "insertions": insertions, "line_map": mapping,
    }, indent=2, ensure_ascii=False) + "\n")
    print(label, len(requests))

for module, requests in sorted(groups.items()):
    if not requests:
        continue
    path = module.replace(".", "/") + ".lean"
    name = module.rsplit(".", 1)[-1]
    raw = (root / path).read_bytes()
    emit(f"{name}Seal", raw, requests, path)

control = b"""import TCSlib.Cryptography.Asymptotic.CollectionShift

open TCSlib.Cryptography

example (T : TrapdoorCollection) (c : Nat) : (T.shiftParameter c).eval = T.eval := by
  rfl
"""
(probe / "ShiftUnsealedControl.lean").write_bytes(control)
shift = next(r for r in rows if r["name"] == "TCSlib.Cryptography.TrapdoorCollection.shiftParameter")
requests = [{**shift, "spelling": shift["name"], "collector_reducibility": shift["status"][1:-1]}]
emit("ShiftSealedControl", control, requests, "negative control")
emit("ShiftReaderControl", control.replace(b"  rfl", b"  exact T.shiftParameter_eval c"),
     requests, "published equation control")
