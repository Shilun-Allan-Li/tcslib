"""Own bounded CCA comment proposal and finite illustrations; no Lean or mutations."""
from pathlib import Path
from itertools import product
from fractions import Fraction
import difflib
import hashlib
import json
import subprocess

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
HERE = Path(__file__).resolve().parent
HEAD = '3f6db40e1688c4a0bb922c9575dd3bd2157a650b'
PATH = 'TCSlib/Cryptography/Composability/CCA2Scheme.lean'
REPORT = HERE.parent / 'gate06C-r1-findings.md'
REPORT_SHA = '577621ca9f6fa665dbc6bd3150f4625ddf2b05d19b9f6021bf652c30c8580ac4'
INPUTS = []


def sha(data): return hashlib.sha256(data).hexdigest()
def save(name, value):
    with (HERE / name).open('x') as f: json.dump(value, f, indent=2); f.write('\n')
def git(*args):
    return subprocess.run(['git', '-C', str(ROOT), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout
def mask(text):
    out = list(text); i = depth = 0; quoted = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i): out[i:i+2] = '  '; depth += 1; i += 2
            elif text.startswith('-/', i): out[i:i+2] = '  '; depth -= 1; i += 2
            else:
                if text[i] != '\n': out[i] = ' '
                i += 1
        elif quoted:
            if text[i] == '\\':
                i += 2
            else:
                if text[i] == '"': quoted = False
                i += 1
        elif text.startswith('/-', i): out[i:i+2] = '  '; depth = 1; i += 2
        elif text.startswith('--', i):
            end = text.find('\n', i); end = len(text) if end < 0 else end
            out[i:end] = ' ' * (end-i); i = end
        elif text[i] == '"': quoted = True; i += 1
        else: i += 1
    assert depth == 0 and not quoted
    return ''.join(out)


def main():
    report = REPORT.read_bytes(); assert sha(report) == REPORT_SHA
    assert len(report.decode().splitlines()) == 522
    INPUTS.append({'path': str(REPORT), 'bytes': len(report), 'sha256': sha(report)})
    assert git('rev-parse', 'HEAD').decode().strip() == HEAD
    for path in (PATH, 'TCSlib/Cryptography/Composability/Defs.lean',
                 'TCSlib/Complexity/TuringMachine/Encoding.lean',
                 'TCSlib/Complexity/ClassNP/PolyTimePairing.lean',
                 'TCSlib/Cryptography/Games/Advantage.lean'):
        raw = (ROOT / path).read_bytes(); assert raw == git('show', HEAD + ':' + path)
        INPUTS.append({'path': str(ROOT / path), 'repository_path': path, 'source_rev': HEAD, 'bytes': len(raw), 'sha256': sha(raw)})
    original = (ROOT / PATH).read_text()
    replacements = [
('''- **Tagging `c₁` alone would not be CCA2-secure.** Take the challenge `(r*, c₁*, t*)` and an
  encryption `(r₁, f_{k₁}(r₁), t₁)` of `0^n`, and ask `Dec′` for `(r*, f_{k₁}(r₁), t₁)`. Its tag is
  valid and it is not the challenge. The answer `f_{k₁}(r₁) ⊕ f_{k₁}(r*)` reveals `f_{k₁}(r*)`,
  and with it `m_b`.
''', '''- **Tagging `c₁` alone would not be CCA2-secure.** For positive `n`, choose challenge messages
  `0^n` and `1^n`, obtain `(r*, c₁*, t*)`, and obtain an encryption
  `(r₁, f_{k₁}(r₁), t₁)` of `0^n`. In this short-tag variant the query
  `(r*, f_{k₁}(r₁), t₁)` has a valid tag. If it equals the challenge, do not query it and count
  that branch as attack failure; otherwise its answer `f_{k₁}(r₁) ⊕ f_{k₁}(r*)` reveals the pad
  `f_{k₁}(r*)` and hence `m_b`. Equality can occur, in particular when `r₁ = r*` and `m_b = 0^n`.
  In the random-pad hybrid, nonce equality and accidental masked-message equality have total
  probability at most `2 / 2^n`; the real PRF setting adds a negligible reduction error.
  The attack is therefore overwhelmingly successful, rather than unconditionally query-distinct.
'''),
('''- `Dec′` is defined by the source on well-formed triples. On any other string it outputs `⊥`. The
  guard matters for the same reason as for the §3.9 scheme: the evaluator `E` agrees with `F` only
  on `⟨s, x⟩` with `|s| = |x|`.
''', '''- `Dec′` is specified on well-formed triples. Here total pair projections and the two length
  guards enforce malformed rejection for generated keys when `n > 0`: both ciphertext pair layers
  must parse, and evaluator agreement then forces the valid tag to have `2n` bits. The evaluator
  `E` agrees with `F` only on `⟨s, x⟩` with `|s| = |x|`. At `n = 0`, failed projections can all be
  empty: the malformed four-bit word `0000`, for example, decrypts to the valid empty message.
  This finite-prefix behavior is retained; the malformed-rejection claim is only for positive
  parameters. There is only one plaintext at zero, so this does not change the security statement.
'''),
('''2. In the resulting game, call a `Dec′` query `(r, c₁, t)` *fresh* if `(r, c₁)` is not the
   ciphertext part of an earlier `Enc′` or challenge answer. A fresh query has a valid tag with
   probability `2^{-2n}` (a fresh value of `RF`), so by the union bound all fresh queries are
   refused except with probability `q(n)/2^{2n}`. A query that is not fresh and has a valid tag
   is an earlier answer itself, since the tag is a function of `(r, c₁)`: refused if it is the
   challenge, and otherwise an encryption whose message the adversary chose.
3. Off that bad event, the CCA2 adversary is simulated by a CPA adversary against the §3.9 scheme
   under `k₁` (the source's simulator): `Enc′` answers come from the CPA encryption oracle,
   tagged by a lazily sampled `RF`; `Dec′` answers come from the table of earlier answers, or
   are `⊥`. So its advantage is at most the CPA advantage (`prfFixedScheme_cpa`), plus
   `q(n)/2^{2n}`, plus the PRF advantage: negligible.
''', '''2. For positive `n`, call a `Dec′` query `(r, c₁, t)` *fresh* if `(r, c₁)` is not the
   ciphertext part of an earlier `Enc′` or challenge answer. Compare with a game that always
   rejects fresh-pair queries. Couple both games with the same tapes and `RF`: they agree until
   the first fresh-pair query with a valid tag. In the always-reject game, prior rejected guesses
   reveal no value of `RF` at such a pair. Each guess therefore hits that unrevealed uniform
   `2n`-bit value with probability at most `2^{-2n}`, even if the pair was queried before. The union bound
   gives a first-discrepancy probability at most `q(n)/2^{2n}` in each bit-game. This does not
   assert the same conditional probability after failed guesses in the original game.
   A nonfresh valid-tag query is an earlier answer itself: canonical parsing and the tag's
   dependence on `(r, c₁)` make it the refused challenge or an encryption of a chosen message.
3. The always-reject game is simulated by a CPA adversary against the §3.9 scheme under `k₁`:
   `Enc′` answers come from the CPA encryption oracle, tagged by a lazily sampled `RF`; `Dec′`
   answers come from the table of earlier answers, or are `⊥`. Up to fixed constant factors
   when combining the two bit-games, the advantage is bounded by the CPA advantage
   (`prfFixedScheme_cpa`), the first-discrepancy term `q(n)/2^{2n}`, and the PRF advantage.
   Each is negligible; the zero-parameter behavior described above changes no asymptotic claim.
''')]
    proposed = original
    for old, new in replacements:
        assert proposed.count(old) == 1
        begin = proposed.index(old); assert not mask(proposed)[begin:begin+len(old)].strip()
        proposed = proposed.replace(old, new, 1)
    # Removing every comment leaves the same code tokens, strings and admission.
    assert mask(original).split() == mask(proposed).split()
    assert mask(original).count('sorry') == mask(proposed).count('sorry') == 1
    with (HERE / 'CCA2Scheme.baseline.source.txt').open('x') as f: f.write(original)
    with (HERE / 'CCA2Scheme.proposed.source.txt').open('x') as f: f.write(proposed)
    patch = ''.join(difflib.unified_diff(original.splitlines(keepends=True), proposed.splitlines(keepends=True),
                    fromfile='a/' + PATH, tofile='b/' + PATH, n=3))
    with (HERE / 'CCA2Scheme-comment-only.patch').open('x') as f: f.write(patch)
    # Own literal transcription of the tiny pairing/guard fragments, not received code.
    def encode(a, b): return tuple(x for v in a for x in (v, v)) + (0, 1) + tuple(b)
    def decode(w):
        prefix = []; i = 0
        while i+1 < len(w):
            a, b = w[i:i+2]
            if a == b: prefix.append(a); i += 2
            elif (a, b) == (0, 1): return tuple(prefix), tuple(w[i+2:])
            else: return None
        return None
    def fst(w): return decode(w)[0] if decode(w) is not None else ()
    def snd(w): return decode(w)[1] if decode(w) is not None else ()
    def evaluator(w):
        pair = decode(w)
        return tuple(a ^ b for a, b in zip(*pair)) if pair is not None and len(pair[0]) == len(pair[1]) else ()
    def guard(n, k2, w):
        r, c, tag = fst(w), fst(snd(w)), snd(snd(w))
        return len(r) == n and len(c) == n and evaluator(encode(k2, r+c)) == tag
    finite = []
    for n in (0, 1, 2):
        limit = 6*n+4; tested = accepted = malformed_accepted = 0
        for length in range(limit+1):
            for w in product((0, 1), repeat=length):
                tested += 1
                if decode(w) is not None: assert encode(*decode(w)) == w
                if not guard(n, (1,)*(2*n), w): continue
                accepted += 1; parsed = decode(w)
                canonical = parsed is not None and decode(parsed[1]) is not None
                if not canonical: malformed_accepted += 1
                if n > 0:
                    assert canonical
                    r, tail = parsed; c, tag = decode(tail)
                    assert len(r) == len(c) == n and len(tag) == 2*n and len(w) == 6*n+4
        finite.append({'n': n, 'word_lengths_tested': [0, limit], 'tested': tested, 'accepted': accepted,
                       'accepted_noncanonical': malformed_accepted})
    assert encode((), ()) == (0, 1) and encode((), encode((), ())) == (0, 1, 0, 1)
    assert decode((0, 0, 0, 0)) is None and guard(0, (), (0, 0, 0, 0))
    collisions = []
    for n in (1, 2):
        m = 2**n; failures = [0, 0]; total = m**m * m*m
        for table in product(range(m), repeat=m):
            for r in range(m):
                for r1 in range(m):
                    for beta, msg in enumerate((0, m-1)):
                        failures[beta] += (table[r1] == (msg ^ table[r]))
        actual = [Fraction(x, total) for x in failures]; p = Fraction(1, m)
        assert actual == [2*p-p*p, (1-p)*p]
        collisions.append({'n': n, 'trials_per_choice': total, 'failure_probabilities': [str(x) for x in actual],
                           'bound_each': str(2*p)})
    assert Fraction(1, 4-1) == Fraction(1, 3) and Fraction(2, 4) == Fraction(1, 2)
    save('finite-checks.json', {'parsing_guard': finite, 'zero_example': '0000 accepted as empty; honest zero ciphertext 0101',
         'C02_toy': {'range': 4, 'conditional_second_distinct_guess_after_failure': '1/3',
                     'forced_game_bad_probability_two_guesses': '1/2', 'union_bound': '2/4'},
         'C04_random_function_enumeration': collisions,
         'limits': 'Finite source transcription and probability illustrations only; XOR evaluator is not a PRF. No kernel, asymptotic security or native result claimed.'})
    save('proposal-validation.json', {'source_head': HEAD, 'path': PATH,
        'original_sha256': sha(original.encode()), 'proposed_sha256': sha(proposed.encode()), 'patch_sha256': sha(patch.encode()),
        'edited_comment_regions': len(replacements), 'all_old_regions_completely_comment_text': True,
        'comment_stripped_code_tokens_strings_identical': True, 'direct_admissions_before_after': [1, 1],
        'declaration_headers_bodies_hypotheses_costs_attributes_unchanged': True,
        'tracked_source_edited': False, 'native_or_incoming_execution': False})
    save('input-bindings.json', INPUTS)
    print('COMMENT_ONLY_PROPOSAL_OK', sha(patch.encode()), finite, collisions)


if __name__ == '__main__': main()
