"""basecollector2.py <repo> <base-rev> <head-collector-log> <module> <out-log> [allowed-module ...]
Variant of basecollector.py (not-cca2 review): closure modules named in [allowed-module ...] may differ
between base and head; the caller must have verified (decls2) that their diff adds theorems only, so the
head CAT definition rows equal the base rows.

Base-control collector log: the head collector's CAT rows (every TCSlib definition of the head
environment; mkseals keeps only those whose home is in the closure), and a CLOSURE row for <module>
computed from the base sources (`git show <base-rev>:<path>` of every module reached). Every module
of the base closure must have byte-identical sources at base and head (checked) so its head
catalogue rows are the base rows. No ROOT rows (the elaborated-term subset check is a head-only check)."""
import sys, json, re, subprocess
repo, base, log, module, out = sys.argv[1:6]
allowed = set(sys.argv[6:])
def src(rev, m):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{m.replace(".", "/")}.lean'], capture_output=True)
    return r.stdout if r.returncode == 0 else None
seen, st = set(), [module]
while st:
    x = st.pop()
    for i in re.findall(rb'^import\s+(\S+)', src(base, x) or b'', re.M):
        i = i.decode()
        if i.startswith('TCSlib') and i not in seen: seen.add(i); st.append(i)
diff = [m for m in seen if src(base, m) != src('HEAD', m) and m not in allowed]
print('allowed differing modules', sorted(m for m in seen if m in allowed and src(base, m) != src('HEAD', m)))
assert not diff, diff
with open(out, 'w') as f:
    for line in open(log, encoding='utf-8'):
        if line.startswith('CAT ') or line.startswith('CAT-COUNT'): f.write(line)
    f.write('CLOSURE ' + json.dumps({'module': module, 'closure': sorted(seen)}, separators=(',', ':')) + '\n')
    f.write(f'MODULE {module}: stored 0\n')
print('base closure', len(seen), 'modules; all byte-identical at head')
