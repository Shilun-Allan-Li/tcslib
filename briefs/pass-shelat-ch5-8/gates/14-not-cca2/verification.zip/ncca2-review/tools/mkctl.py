"""mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
Sensitivity controls for the not-cca2 review (copied from the padded-cpa review's mkctl.py; only B and the namespace differ), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (pairEncode, padFin, zeroBits, inLens, decAnswer, prfScheme)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
B = {
 'Turing.pairEncode': [
  ("ctlPair", True, "theorem ctlPair (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n"),
  ("ctlPairReader", False, "theorem ctlPairReader (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b\n"),
  ("anonymous example", True, "example (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n")],
 'TCSlib.Cryptography.padFin': [
  ("ctlPadFin", True, "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n"),
  ("ctlPadFinReader", False, "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n")],
 'TCSlib.Cryptography.Games.zeroBits': [
  ("ctlZeroBits", True, "theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl\n"),
  ("ctlZeroBitsReader", False, "theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=\n  TCSlib.Cryptography.Games.zeroBits_apply d j\n")],
 'TCSlib.Cryptography.Composability.FixedLengthScheme.inLens': [
  ("ctlInLens", True, "theorem ctlInLens (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :\n    S.inLens n 2 = n + n := rfl\n"),
  ("ctlInLensReader", False, "theorem ctlInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :\n    S.inLens n 2 = n + n := S.inLens_two n\n")],
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer': [
  ("ctlDecAnswer", True, "theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m := rfl\n"),
  ("ctlDecAnswerReader", False, "theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m\n")],
 'TCSlib.Cryptography.prfScheme': [
  ("ctlPrfSchemeDec", True, "theorem ctlPrfSchemeDec (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))\n    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)\n    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =\n      List.ofFn (F n s x)) :\n    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform\n      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) := rfl\n"),
  ("ctlPrfSchemeDecReader", False, "theorem ctlPrfSchemeDecReader (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))\n    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)\n    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =\n      List.ofFn (F n s x)) :\n    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform\n      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) :=\n  TCSlib.Cryptography.prfScheme_dec F E hE hFE\n")],
}
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace NcControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end NcControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
for rec_path in sorted(Path(sealdir).glob('Seal_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][5:]
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
