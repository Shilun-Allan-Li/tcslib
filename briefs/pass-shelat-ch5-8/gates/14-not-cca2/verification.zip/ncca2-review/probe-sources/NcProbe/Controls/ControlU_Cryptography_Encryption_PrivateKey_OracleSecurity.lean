import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace NcControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

end NcControls

