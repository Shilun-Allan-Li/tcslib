import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

/-! not-cca2 review: axioms of the target, its corollary, the new public readers (explicit
`#print axioms`), and of every stored constant of the three changed modules (collectAxioms). -/

set_option maxHeartbeats 0

#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#print axioms TCSlib.Cryptography.prfScheme_dec
#print axioms TCSlib.Cryptography.Composability.FixedLengthScheme.indSpec_decDom
#print axioms TCSlib.Cryptography.Composability.FixedLengthScheme.indSpec_decRng
#print axioms TCSlib.Cryptography.Composability.FixedLengthScheme.indSpec_challengeDom
#print axioms TCSlib.Cryptography.Composability.FixedLengthScheme.indSpec_challengeRng
#print axioms TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl_dec_onSpec
#print axioms TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl_challenge_none_onSpec

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let owners : List Name := [`TCSlib.Cryptography.Encryption.PrivateKey.FromPRF,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF]
  let mut n := 0
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"AX {home} {c} {axs.toList}"
    n := n + 1
  IO.println s!"AX-COUNT {n}"
