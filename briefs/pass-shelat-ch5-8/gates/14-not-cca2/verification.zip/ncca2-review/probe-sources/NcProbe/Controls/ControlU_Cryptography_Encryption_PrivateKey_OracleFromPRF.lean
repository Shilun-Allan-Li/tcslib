import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace NcControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

theorem ctlInLens (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :
    S.inLens n 2 = n + n := rfl

theorem ctlInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :
    S.inLens n 2 = n + n := S.inLens_two n

theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :
    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =
      Fin.cons (α := fun _ => Bool) true m := rfl

theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :
    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =
      Fin.cons (α := fun _ => Bool) true m :=
  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m

theorem ctlPrfSchemeDec (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)
    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (F n s x)) :
    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform
      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) := rfl

theorem ctlPrfSchemeDecReader (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)
    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (F n s x)) :
    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform
      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) :=
  TCSlib.Cryptography.prfScheme_dec F E hE hFE

end NcControls

