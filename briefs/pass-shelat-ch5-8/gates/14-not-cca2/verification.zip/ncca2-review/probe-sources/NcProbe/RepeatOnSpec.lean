import TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity

/-! not-cca2 review: the optional `indImpl_challenge_repeat_onSpec` reader (not in the
delivery), in the form of the public-key file's reader, checked against the delivered file. -/

namespace TCSlib.Cryptography.Composability.FixedLengthScheme

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games

variable (S : FixedLengthScheme)

/-- The repeated challenge equation on the query specification's type: on the state `some c`,
`S.indImpl atk b n k 2 mm (some c)` returns `cast _ c` and keeps the state `some c`. -/
theorem indImpl_challenge_repeat_onSpec (atk : Attack) (b : Bool) (n : ℕ) (k : List Bool)
    (mm : (S.indSpec n).dom 2) (c : Fin (S.ctLen.eval n) → Bool) :
    S.indImpl atk b n k 2 mm (some c) =
      .pure (cast (S.indSpec_challengeRng n).symm c, some c) := by
  simpa only [cast_eq] using S.indImpl_challenge_repeat atk b n k mm c

end TCSlib.Cryptography.Composability.FixedLengthScheme
