"""mkverif39r2.py <repo> <rec-rev> <checks-dir> <tools-dir> <out.zip>: the verification ZIP of Gate 39 round 2
(verification-r2.zip), by the Gate 37 round-2 method (g373839/tools/mkverif373839.py, gate 37).

Members: byte-identical originals of records at the records commit REC (each checked equal to the working tree), then
checks/: the pack's re-checks from git objects (and of the LE-gate39 evidence ZIP), with their scripts. Writes
PROVENANCE.txt and SHA256SUMS (every other entry)."""
import collections, hashlib, os, subprocess, sys, zipfile

repo, REC, chk, tools, out = sys.argv[1:6]
B = 'briefs/pass-shelat-ch5-8'
TOOLS = ['packchk39r2.py', 'gitlib.py', 'decls2rev.py', 'mksources.py', 'mkverif39r2.py']
DATE = (2026, 11, 16, 0, 0, 0)


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


sha = lambda b: hashlib.sha256(b).hexdigest()
members = []
recs = [('PassShelatChapter5-8Plan.md', 'the decision log, with the rows of 2026-11-16 (Gate 39 HOLD and the planned fix\n'
         '    LE-gate39; #326 merged; LE-gate39 pushed on #327, with its two rebuilds)'),
        (f'{B}/duplication-ledger.md', 'the duplication ledger (no row for G39-01: the duplicate is removed, not debt)'),
        (f'{B}/deferred-work.md', 'the deferred-work register'),
        (f'{B}/fills/seq-zk/final-r1/review.md', 'the seq-zk maintainer review (as it now stands)')]
for src, _ in recs:
    b = git('show', f'{REC}:{src}')
    assert open(os.path.join(repo, src), 'rb').read() == b, f'working tree differs from {REC[:8]} for {src}'
    members.append((f'records/{src}', b, f'records {REC[:8]}:{src}'))
for c in sorted(os.listdir(chk)):
    members.append((f'checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
for t in TOOLS:
    members.append((f'checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
head = f"""Gate 39 round 2 (seq-zk, draft PR #327, Lean head a94ba750b2f21ea5f2c3e58bc7959ad5ac9de871) verification-r2.zip

The round-2 records the pack cites that the outbox does not already carry as files, and the pack's re-checks.
- records/: byte-identical originals from records commit {REC} (each also equal to the working tree):
""" + ''.join(f'  - {p.replace(B + "/", "")}: {d};\n' for p, d in recs)
tail = """- checks/: generated from git objects alone (nothing was built or run): rebase.txt (the series and signatures, the
  diff against the base), lecheck.txt (LE-gate39: the edit, every header of the 41 files since round 1, the stripped
  code diff, the docstring insertion, the import and the closures, the public lemma and the replaced local proof),
  mergetrees.txt, downstream.txt and namecheck.txt (the head against the current tip, the tip the LE-gate39 job built
  on, the open PRs #324, #331, #332 and #333, and the merged head of #326), integration.txt (the final combined tree
  against the current tip, in both merge orders, and against the earlier combined build), srcequality.txt (the
  sources of both LE-gate39 builds against the head and the merged trees), dupscan.txt (the lines changed since round
  1, the G39-01 pattern, statement scans against the pools and the whole tree), evidence.txt (the LE-gate39 evidence
  ZIP against its manifest, and the entries the pack cites), the decls2 comparisons (base and round 1 against the
  head), and tools/ (packchk39r2.py with gitlib.py; decls2rev.py = maintainer/tools/decls2.py's parser on two
  revisions; mksources.py, which wrote sources-r2.zip, pr.diff-r2.txt and source-head-r2.json; this script).
SHA256SUMS lists every entry except itself.
"""
prov = head + tail + '\nSources:\n' + ''.join(f'  {p}  <-  {d}\n' for p, _, d in sorted(members))
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
assert len({p for p, _, _ in members}) == len(members), 'duplicate member'
members.append(('SHA256SUMS', ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members).encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as z:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=DATE)
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_STORED if p.endswith('.zip') else zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
with zipfile.ZipFile(out) as z:
    listed = z.namelist()
    inner = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in z.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == set(inner) | {'SHA256SUMS'} and len(listed) == len(inner) + 1
    assert all(sha(z.read(p)) == h for p, h in inner.items())
print(f'OK: {len(listed)} entries {dict(collections.Counter(n.split("/")[0] for n in listed))}; '
      f'sha256 {sha(open(out, "rb").read())}')
