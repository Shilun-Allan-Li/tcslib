"""packchk39r2.py <repo> <evidence-dir> <out-dir>: the Gate 39 round-2 pack re-checks (#327, seq-zk, LE-gate39), from
git objects only (no Lean), plus a read-only cross-check of the LE-gate39 evidence ZIP (extracted into <evidence-dir>
from records gates/39-seq-zk/landing-r1/gate39-le-evidence.zip; the ZIP itself is re-verified here).

The Gate 37 round-2 method (g373839/tools/packchk373839.py, gate 37) applied to Gate 39 round 2. Writes rebase.txt,
lecheck.txt, mergetrees.txt, downstream.txt, namecheck.txt, integration.txt, srcequality.txt, dupscan.txt and
evidence.txt."""
import difflib, hashlib, io, itertools, json, os, re, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls, ws, blank_docs, docs, NM

repo_path, evd, out = sys.argv[1:4]
R = Repo(repo_path); rp = R.rp
B = 'briefs/pass-shelat-ch5-8'
GD = f'{B}/gates/39-seq-zk'
TIPREF = 'origin/cryptography/pass-shelat-ch2-4'
TIP = rp(TIPREF)
SQZ = 'TCSlib/Cryptography/Composability/SequentialZK'
RPB, PT = f'{SQZ}/RealPrefixBounds.lean', f'{SQZ}/ProofTransfers.lean'
HEAD = rp('a94ba750b2f21ea5f2c3e58bc7959ad5ac9de871')
R1H = rp('bd19c433a4cf3d4027ffc891d7d3c06e927e9dfa')
BASE0 = rp('05d26fe5b41fcb9426ec220d877d03264b9c8e8c')
assert rp('origin/land/pass-shelat-seq-zk') == HEAD
EVTIP = rp('0542dd9210ccdb844ad125cd95f8488c9f553153')     # the tip the LE-gate39 job built on (#326 merged)
EVA = dict(tree=rp('daac61401cafe36fb036598e1bb33cdf6d5e743e'), commit=rp('4cd422c76c73cdcf4270b94a9c4ca9fcecd0fd9a'))
EVB = dict(tree=rp('129810e45fa842afa19219804e6cde7fe64cee7c'), commit=rp('c51cf08dcf588ca6bbd79670462df5b8bb0ecb92'))
INT = dict(tree=rp('3fb05ea062395caf069c09643a8caf751d3ad6da'), commit=rp('639d16d943d4bb4777c77ae8614cd8c2ed91f1bd'))
OPEN = {'#324': rp('origin/land/pass-shelat-sc-compose'), '#331': rp('origin/stmt/pairings'),
        '#332': rp('origin/stmt/dagcircuit-readers'), '#333': rp('origin/stmt/gsw')}
assert OPEN['#324'] == '4bd2d80bfb58fab5243c66c9f1a697a30b533756', OPEN
MERGED = {'#326': rp('c27005d67298f79c785a4e8ac1648da0a67d3614')}
assert R.anc(MERGED['#326'], TIP) and R.anc(EVTIP, TIP)
BASE = rp(R.git('merge-base', HEAD, TIP).stdout.strip())
assert BASE == BASE0, BASE
lean = R.lean_changed
UNIT = sorted(lean(BASE, HEAD))
CMP = [('tip', TIP), ('LE-gate39 build tip', EVTIP)] + list(OPEN.items()) + [(f'{k} (merged)', v) for k, v in MERGED.items()]
os.makedirs(out, exist_ok=True)
W = lambda name, L: open(os.path.join(out, name), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
short = lambda p: p.replace('TCSlib/Cryptography/', '').replace('TCSlib/Complexity/', 'Complexity/')
sha = lambda b: hashlib.sha256(b).hexdigest()
sub = lambda rev, s: R.git('rev-parse', f'{rev}:{s}', check=False).stdout.strip()

# 1. the series -------------------------------------------------------------------------------------------------------
L = [f'PR #327 (seq-zk) head {HEAD} (origin/land/pass-shelat-seq-zk), tree {rp(HEAD + "^{tree}")}',
     f'merge base with the tip {TIP} ({TIPREF}): {BASE} (round 1: the same)',
     f'parent of the head: {rp(HEAD + "^")} (= the round-1 head {R1H}: {rp(HEAD + "^") == R1H}); round-1 head an ancestor: '
     f'{R.anc(R1H, HEAD)}; commits {R1H[:8]}..{HEAD[:8]}: {len(R.git("rev-list", f"{R1H}..{HEAD}").stdout.split())}',
     f'commits {BASE[:8]}..{HEAD[:8]} (oldest first; gpgsig = number of signature headers in the commit object):']
for c in R.git('rev-list', '--reverse', f'{BASE}..{HEAD}').stdout.split():
    o = R.git('cat-file', '-p', c).stdout
    L.append(f'  {c} gpgsig {len(re.findall(r"(?m)^gpgsig", o))} | '
             f'{R.git("log", "-1", "--format=author %an <%ae> | committer %cn <%ce> | %s", c).stdout.strip()}')
L.append(f'the first 7 are round 1\'s series unchanged ({BASE[:8]}..{R1H[:8]}): '
         f'{R.git("rev-list", "--reverse", f"{BASE}..{R1H}").stdout.split() == R.git("rev-list", "--reverse", f"{BASE}..{HEAD}").stdout.split()[:-1]}')
d3 = R.gitb('diff', f'{TIPREF}...{HEAD}')
d2 = R.gitb('diff', f'{BASE}..{HEAD}')
L.append(f'git diff {TIPREF}...{HEAD[:8]} = git diff {BASE[:8]}..{HEAD[:8]} byte for byte: {d3 == d2}; '
         f'{R.git("diff", "--shortstat", BASE, HEAD).stdout.strip()}; SHA-256 {sha(d2)}')
L.append(f'the same against round 1 ({BASE[:8]}..{R1H[:8]}): {R.git("diff", "--shortstat", BASE, R1H).stdout.strip()}')
W('rebase.txt', L)

# 2. LE-gate39 -------------------------------------------------------------------------------------------------------
L = []
fs = lean(R1H, HEAD)
diff = R.gitb('diff', R1H, HEAD)
L.append(f'# A. the edit: git diff {R1H[:8]} {HEAD[:8]} (SHA-256 {sha(diff)}): files {fs}; all paths '
         f'{R.git("diff", "--name-only", R1H, HEAD).stdout.split()}; numstat {R.git("diff", "--numstat", R1H, HEAD).stdout.split()}')
for p in fs:
    x, y = decls(R.show(R1H, p)), decls(R.show(HEAD, p))
    L.append(f'  {short(p)}: declarations {len(x)} -> {len(y)} {list(y)}; removed {[n for n in x if n not in y]}; added '
             f'{[n for n in y if n not in x]}; headers differing {[n for n in x if n in y and x[n][2] != y[n][2]]}; '
             f'docstrings changed {[n for n in x if n in y and x[n][3] != y[n][3]]}; order kept '
             f'{[n for n in y if n in x] == [n for n in x if n in y]}')
    ia, ib = re.findall(r'(?m)^import .*', R.show(R1H, p)), re.findall(r'(?m)^import .*', R.show(HEAD, p))
    L.append(f'    imports: round 1 {ia}; head {ib}; added {[i for i in ib if i not in ia]}; removed '
             f'{[i for i in ia if i not in ib]}')
    xa, yb = R.show(R1H, p), R.show(HEAD, p)
    L.append(f'    lines {len(xa.splitlines())} -> {len(yb.splitlines())}; max width at the head '
             f'{max(len(l) for l in yb.splitlines())}; docstrings {len(docs(xa))} -> {len(docs(yb))}')
L.append('# B. code lines that differ after deleting doc and module comments on both sides (difflib, n=0)')
for p in fs:
    x, y = blank_docs(R.show(R1H, p)).splitlines(), blank_docs(R.show(HEAD, p)).splitlines()
    dl = [l for l in difflib.unified_diff(x, y, lineterm='', n=0) if l[:1] in '+-' and not l.startswith(('+++', '---'))]
    L.append(f'  {short(p)}: {len(dl)} lines')
    L += ['    ' + l for l in dl]
L.append('# C. the one changed docstring (realPrefix_bounds): round 1 -> head')
da, db_ = decls(R.show(R1H, RPB))['realPrefix_bounds'][3], decls(R.show(HEAD, RPB))['realPrefix_bounds'][3]
sm = difflib.SequenceMatcher(None, da, db_, autojunk=False)
ops = [o for o in sm.get_opcodes() if o[0] != 'equal']
L.append(f'  non-equal opcodes: {[(o[0], da[o[1]:o[2]], db_[o[3]:o[4]]) for o in ops]}')
L.append(f'  pure insertion of one contiguous chunk: {len(ops) == 1 and ops[0][0] == "insert"}; removing it gives the '
         f'round-1 text: {len(ops) == 1 and db_[:ops[0][3]] + db_[ops[0][4]:] == da}')
L.append('# D. every declaration of the 41 unit files, round 1 -> head (header = keyword line to the top-level := for '
         'theorems, the whole block for definitions, with any open/include/omit ... in prefix)')
tot = dict(n=0, same=0, doc=[], blk=0, nblk=0)
for p in UNIT:
    a, b = decls(R.show(R1H, p)), decls(R.show(HEAD, p))
    assert list(a) == list(b), p
    tot['n'] += len(a)
    tot['same'] += sum(a[n][2] == b[n][2] for n in a)
    tot['doc'] += [n for n in a if a[n][3] != b[n][3]]
    defs = [n for n in a if a[n][0] not in ('theorem', 'lemma')]
    tot['blk'] += sum(a[n][2] == b[n][2] for n in defs); tot['nblk'] += len(defs)
L.append(f'  {len(UNIT)} files, {tot["n"]} declarations, the same names in the same order in every file; headers '
         f'identical {tot["same"]}/{tot["n"]}; definition blocks identical {tot["blk"]}/{tot["nblk"]}; docstrings '
         f'changed {tot["doc"]}')
L.append(f'  files whose blob changed {R1H[:8]} -> {HEAD[:8]}: {[short(p) for p in UNIT if R.blob(R1H, p) != R.blob(HEAD, p)]}')
L.append('# E. the import and the closures (import graphs of TCSlib and audits modules, from git objects)')
g1, gh = R.graph(R1H), R.graph(HEAD)
c1, ch = closure(g1, [RPB]), closure(gh, [RPB])
cpt = closure(gh, [PT])
L.append(f'  closure of RealPrefixBounds (itself included): round 1 {len(c1)}, head {len(ch)}; added {sorted(ch - c1)}; '
         f'removed {sorted(c1 - ch)}')
L.append(f'  closure of ProofTransfers at the head: {len(cpt)} modules; contains RealPrefixBounds: {RPB in cpt} (so the '
         f'import is acyclic); subset of the RealPrefixBounds closure at round 1 plus ProofTransfers: '
         f'{cpt <= (c1 | {PT})}')
L.append(f'  ProofTransfers blob: {R1H[:8]} {sub(R1H, PT)[:12]}, head {sub(HEAD, PT)[:12]}: unchanged '
         f'{sub(R1H, PT) == sub(HEAD, PT)}; its imports {gh[PT]}')
u1 = set().union(*[closure(g1, [p]) for p in UNIT]); uh = set().union(*[closure(gh, [p]) for p in UNIT])
L.append(f'  union of the 41 unit closures: round 1 {len(u1)}, head {len(uh)}; equal {u1 == uh}')
dn1, dnh = downstream(g1, {RPB}), downstream(gh, {RPB})
L.append(f'  downstream of RealPrefixBounds (itself included): round 1 {len(dn1)}, head {len(dnh)}: '
         f'{[short(p[:-5]) for p in sorted(dnh)]}')
dpt = downstream(gh, {PT})
L.append(f'  modules downstream of ProofTransfers at the head: {len(dpt)}; at round 1 {len(downstream(g1, {PT}))}; new '
         f'{[short(p[:-5]) for p in sorted(dpt - downstream(g1, {PT}))]}')
L.append('# F. the public lemma and the replaced local proof')
for rev, p, name in [(HEAD, PT, 'next_length_le')]:
    t = R.show(rev, p).splitlines()
    i = next(k for k, l in enumerate(t) if l.startswith(f'theorem {name}'))
    s = i
    while not t[s - 1].startswith('/--') and s > 0:
        s -= 1
    j = i
    while t[j].strip():
        j += 1
    L.append(f'  {short(p)}:{i + 1} at the head (lines {s}-{j}):')
    L += ['    ' + l for l in t[s - 1:j]]
L.append(f'  commits that add or remove "theorem next_length_le" ({BASE[:8]}..{HEAD[:8]}): '
         f'{R.git("log", "--format=%h %s", "-S", "theorem next_length_le", f"{BASE}..{HEAD}", "--", "TCSlib").stdout.splitlines()}')
L.append(f'  commits that add or remove the local proof line "split_ifs <;> first | exact hbound _ _" '
         f'({BASE[:8]}..{HEAD[:8]}): {R.git("log", "--format=%h %s", "-S", "split_ifs <;> first | exact hbound _ _", f"{BASE}..{HEAD}", "--", "TCSlib").stdout.splitlines()}')
for rev, lab in [(R1H, 'round 1'), (HEAD, 'head')]:
    t = R.show(rev, RPB).splitlines()
    i = next(k for k, l in enumerate(t) if 'have hsource' in l)
    j = i + 1
    while t[j].startswith('    '):
        j += 1
    L.append(f'  hsource at {lab} ({short(RPB)}:{i + 1}-{j}):')
    L += ['    ' + l for l in t[i:j]]
t = R.show(HEAD, RPB)
L.append(f'  realPrefix_bounds binds hbound as `(hbound : ∀ r hist, (π.P.next x y r hist).length ≤ B)`: '
         f'{"(hbound : ∀ r hist, (π.P.next x y r hist).length ≤ B)" in t}; next_length_le\'s hypothesis hB has the '
         f'same type: {"(hB : ∀ r hist, (π.P.next x y r hist).length ≤ B)" in R.show(HEAD, PT)}; its conclusion '
         f'`∀ r hist, (ρ.P.next x y r hist).length ≤ B` at r := tape is the type of hsource')
uses = [f'{short(p)}:{k + 1}: {l.strip()}' for p in UNIT for k, l in enumerate(R.show(HEAD, p).splitlines())
        if 'next_length_le' in l]
L.append(f'  occurrences of next_length_le in the unit at the head ({len(uses)}):')
L += ['    ' + u for u in uses]
W('lecheck.txt', L)

# 3. merge trees -----------------------------------------------------------------------------------------------------
L = [f'PR #327 head {HEAD}; base {BASE}; .lean paths changed {len(UNIT)}',
     'comparators: the current tip; the tip LE-gate39 built on; the open PRs targeting the records branch (origin '
     'branch heads at the time of this check); #326, merged since round 1 (an ancestor of the tip): '
     + ', '.join(f'{k} {v}' for k, v in CMP), '']
trees, changed, mb = {}, {}, {}
for k, v in CMP:
    mb[k] = rp(R.git('merge-base', HEAD, v).stdout.strip())
    changed[k] = lean(mb[k], v)
    t, rc, raw = R.mergetree(HEAD, v); trees[k] = t
    L.append(f'git merge-tree --write-tree {HEAD} {v} ({k}): tree {t} rc {rc} ({"clean" if rc == 0 else "CONFLICT"})')
    if rc:
        L.append(raw)
    shared = sorted(set(changed[k]) & set(UNIT))
    L.append(f'  merge base {mb[k]}; {k} changed .lean paths from it: {len(changed[k])}; shared with #327: {shared}')
L.append('')
L.append(f'the tip LE-gate39 built on: merge-tree({EVTIP[:8]}, {HEAD[:8]}) = {trees["LE-gate39 build tip"]}; = the built '
         f'(a) tree {EVA["tree"]}: {trees["LE-gate39 build tip"] == EVA["tree"]}; scratch commit {EVA["commit"][:8]} has '
         f'that tree: {rp(EVA["commit"] + "^{tree}") == EVA["tree"]}, parents {R.git("log", "-1", "--format=%P", EVA["commit"]).stdout.strip()}')
dd = R.git('diff', '--name-only', EVTIP, TIP).stdout.split()
L.append(f'the tip since then ({EVTIP[:8]}..{TIP[:8]}): {len(dd)} paths changed, under TCSlib/ or audits/: '
         f'{[p for p in dd if p.startswith(("TCSlib/", "audits/"))]}; first-parent commits: '
         f'{len(R.git("log", "--first-parent", "--format=%h", f"{EVTIP}..{TIP}").stdout.split())}, merges among them: '
         f'{R.git("log", "--first-parent", "--merges", "--format=%h %s", f"{EVTIP}..{TIP}").stdout.splitlines()}')
dva = R.git('diff', '--name-only', EVA['tree'], trees['tip']).stdout.split()
L.append(f'merge-tree(current tip {TIP[:8]}, head) = {trees["tip"][:8]}: TCSlib and audits subtrees = the built (a) '
         f'tree\'s: {all(sub(trees["tip"], s) == sub(EVA["tree"], s) for s in ("TCSlib", "audits"))}; paths differing '
         f'from {EVA["tree"][:8]}: {len(dva)}, all records (under briefs/ or a *Plan.md): '
         f'{all(p.startswith("briefs/") or p.endswith("Plan.md") for p in dva)}')
W('mergetrees.txt', L)

# 4. downstream ------------------------------------------------------------------------------------------------------
uclo = set().union(*[closure(gh, [p]) for p in UNIT])
L = [f'# import graph at the #327 head {HEAD[:8]}; a module counts as downstream of itself',
     f'unit modules: {len(UNIT)}; union of their import closures: {len(uclo)} modules',
     f'downstream of RealPrefixBounds (the only module LE-gate39 changes) at the head: {len(dnh)}']
for k, v in CMP:
    ch_ = set(changed[k])
    gm = R.graph(trees[k])
    both = sorted(downstream(gm, set(UNIT)) & downstream(gm, ch_ - set(UNIT)))
    brpb = sorted(downstream(gm, {RPB}) & downstream(gm, ch_ - set(UNIT)))
    L.append(f'{k} ({v[:8]}): its changed modules (from the merge base {mb[k][:8]}) inside the unit closure: '
             f'{[short(p) for p in sorted(ch_ & uclo)]}')
    L.append(f'  merged tree {trees[k][:8]}: downstream of both a #327 module and a {k} module: {len(both)}'
             + (f': {[short(p[:-5]) for p in both]}' if len(both) <= 40 else f' (first 40: {[short(p[:-5]) for p in both[:40]]})'))
    L.append(f'  of them downstream of RealPrefixBounds: {[short(p[:-5]) for p in brpb]}')
W('downstream.txt', L)

# 5. names -----------------------------------------------------------------------------------------------------------
new = sorted({n for p in UNIT for n in NM.findall(R.show(HEAD, p))} - {n for p in UNIT for n in NM.findall(R.show(BASE, p))})
newr1 = sorted({n for p in UNIT for n in NM.findall(R.show(R1H, p))} - {n for p in UNIT for n in NM.findall(R.show(BASE, p))})
L = [f'# the {len(new)} declaration names new at the head (short names as written; round 1: {len(newr1)}, the same set: '
     f'{new == newr1}) against the declarations of the .lean files each comparator changed since its merge base with '
     f'the head (unit files excluded)']
for k, v in CMP:
    hits = []
    for p in changed[k]:
        if p in UNIT:
            continue
        for i, l in enumerate(R.show(v, p).splitlines()):
            m = NM.match(l)
            if m and m.group(1) in new:
                hits.append(f'{p}:{i + 1}: {l.strip()[:120]}')
    L.append(f'{k} ({len(changed[k])} changed files): {len(hits)} declarations with a new name')
    L += ['    ' + h for h in hits]
W('namecheck.txt', L)

# 6. the final combined tree ----------------------------------------------------------------------------------------
L = [f'# the final combined tree of the LE-gate39 evidence, (b): {EVB["tree"]} (scratch commit {EVB["commit"][:8]}, '
     f'parents {R.git("log", "-1", "--format=%P", EVB["commit"]).stdout.strip()}; its tree = {EVB["tree"][:8]}: '
     f'{rp(EVB["commit"] + "^{tree}") == EVB["tree"]})']
orders = {}
for perm in itertools.permutations(['#327', '#324']):
    cur, chain = TIP, []
    for k in perm:
        v = HEAD if k == '#327' else OPEN['#324']
        t, rc, _ = R.mergetree(cur, v)
        assert rc == 0, (perm, k)
        cur = R.git('commit-tree', '--no-gpg-sign', '-p', cur, '-p', v, '-m', f'scratch {k}', t).stdout.strip()
        chain.append(t)
    orders[perm] = chain
    L.append(f'tip {TIP[:8]} + {" + ".join(perm)} (git merge-tree chain, unsigned scratch commits on no ref): trees '
             f'{[t[:8] for t in chain]}, every step clean; final TCSlib and audits subtrees = (b)\'s: '
             f'{all(sub(chain[-1], s) == sub(EVB["tree"], s) for s in ("TCSlib", "audits"))}')
fin = orders[('#327', '#324')][-1]
dvb = R.git('diff', '--name-only', EVB['tree'], fin).stdout.split()
L.append(f'  the final merged tree on the current tip {fin[:8]} differs from (b) {EVB["tree"][:8]} in {len(dvb)} paths, all '
         f'records (under briefs/ or a *Plan.md): {all(p.startswith("briefs/") or p.endswith("Plan.md") for p in dvb)}')
ddi = R.git('diff', '--name-only', INT['tree'], EVB['tree']).stdout.split()
L.append(f'the earlier combined build of all open PRs (int-all-open, tree {INT["tree"][:8]}, commit {INT["commit"][:8]}) '
         f'against (b): {len(ddi)} paths differ; under TCSlib/ or audits/: '
         f'{[p for p in ddi if p.startswith(("TCSlib/", "audits/"))]}; the others are records: '
         f'{all(p.startswith("briefs/") or p.endswith("Plan.md") for p in ddi if not p.startswith(("TCSlib/", "audits/")))}')
c324 = R.git('commit-tree', '--no-gpg-sign', '-p', TIP, '-p', OPEN['#324'], '-m', 'scratch #324',
             R.mergetree(TIP, OPEN['#324'])[0]).stdout.strip()
t1 = R.mergetree(c324, R1H)[0]
L.append(f'  control: the same chain with #327 at round 1 ({R1H[:8]}) instead of the head gives tree {t1[:8]}, whose '
         f'TCSlib and audits subtrees = int-all-open\'s: {all(sub(t1, s) == sub(INT["tree"], s) for s in ("TCSlib", "audits"))}')
W('integration.txt', L)

# 7. source equality of the LE-gate39 builds ------------------------------------------------------------------------
L = []
for part, lab, revs in [('build-a/results.jsonl', '(a) #327 alone on the tip 0542dd92, 679 modules',
                         [('the head', HEAD), ('(a) tree', EVA['tree']), ('#327 merged into the current tip', trees['tip'])]),
                        ('build-b/build/results.jsonl', '(b) the 26-module rebuild on the final combined tree',
                         [('the head', HEAD), ('(b) tree', EVB['tree']), ('the final merged tree on the current tip', fin)])]:
    rr = [json.loads(l) for l in open(os.path.join(evd, part), encoding='utf-8') if l.strip()]
    mm = {x['module']: x for x in rr if 'module' in x}
    L.append(f'{part} ({lab}): {len([x for x in rr if "module" in x])} records, {len(mm)} modules; rc 0 '
             f'{sum(x["rc"] == 0 for x in mm.values())}; errors {sum(x["errors"] for x in mm.values())}; substring '
             f'"error" {sum(x.get("error_substr", 0) for x in mm.values())}; sorry {sum(x.get("sorry", 0) for x in mm.values())}; '
             f'last record "done": {"done" in rr[-1]}; unit modules built {len(set(m + ".lean" for m in mm) & set(UNIT))}/{len(UNIT)}')
    for k, rev in revs:
        dff = [m for m, x in mm.items() if sha(R.blob(rev, m + '.lean') or b'') != x['source_sha256']]
        L.append(f'  {k} {rev[:8]}: {len(mm) - len(dff)} built sources equal, {len(dff)} differ'
                 + (f' {[short(m) for m in dff]}' if len(dff) <= 30 else f' ({len(dff)}; first 30 {[short(m) for m in dff[:30]]})'))
    if RPB[:-5] in mm:
        x = mm[RPB[:-5]]
        L.append(f'  RealPrefixBounds: rc {x["rc"]}, errors {x["errors"]}, sorry {x["sorry"]}, warnings {x["warnings"]}, '
                 f'source = the head blob: {x["source_sha256"] == sha(R.blob(HEAD, RPB))}')
W('srcequality.txt', L)

# 8. duplication scan ------------------------------------------------------------------------------------------------
L = [f'# A. every code line added or removed since round 1 ({R1H[:8]}..{HEAD[:8]}) in the 41 unit files, doc comments '
     f'deleted on both sides']
for p in UNIT:
    x, y = blank_docs(R.show(R1H, p)).splitlines(), blank_docs(R.show(HEAD, p)).splitlines()
    dl = [l for l in difflib.unified_diff(x, y, lineterm='', n=0) if l[:1] in '+-' and not l.startswith(('+++', '---'))]
    if dl:
        L.append(f'  {short(p)}: {len(dl)} lines'); L += ['    ' + l for l in dl]
L.append(f'  other unit files: 0 lines ({len(UNIT) - 1} files)')
nr1 = [(p, n) for p in UNIT for n in decls(R.show(R1H, p))]; nh = [(p, n) for p in UNIT for n in decls(R.show(HEAD, p))]
L.append(f'declarations in the unit files: round 1 {len(nr1)}, head {len(nh)}; identical lists {nr1 == nh}')
L.append('# B. the G39-01 pattern at the head: a local re-derivation of a repeated-prover reply bound from the '
         'specification\'s reply equation (`rw [d.next`/`rw [spec.next`, then `split_ifs` closing with a bound and '
         '`Nat.zero_le`), and every proof line in the unit that rewrites with a PaddedProverSpec reply equation')
PATB = re.compile(r'rw \[[^\]]*\b\w+\.next\b|split_ifs <;> first \| exact h\w* _ _ \| exact Nat\.zero_le')
for p in UNIT:
    for k, l in enumerate(R.show(HEAD, p).splitlines()):
        if PATB.search(l):
            L.append(f'  {short(p)}:{k + 1}: {l.strip()[:140]}')


def sig(hdr, name):
    h = [x for x in hdr.split('\n') if not re.match(r'^(open|include|omit)\b', x)]
    s = ws('\n'.join(h)); i = s.find(name)
    return s[i + len(name):].strip() if i >= 0 else s


newdecl = {}
for p in UNIT:
    a, b = decls(R.show(BASE, p)), decls(R.show(HEAD, p))
    for n, v in b.items():
        if n not in a and v[0] in ('theorem', 'lemma'):
            newdecl[(p, n)] = sig(v[2], n.split('#')[0])
pools = [(f'tip since the base {BASE[:8]} (#313, #318, #319, #323, #326 merged)', TIP,
          [p for p in lean(BASE, TIP) if p not in UNIT])] + \
        [(k, v, [p for p in changed[k] if p not in UNIT]) for k, v in OPEN.items()]
L.append(f'# C. statement scan: each of the {len(newdecl)} theorems new at the head (against the base) compared with '
         f'every theorem of the pools below; a hit = identical binders and type after whitespace normalisation, name '
         f'excluded')
for lab, rev, files in pools:
    hits, n = [], 0
    for p in files:
        for nm, v in decls(R.show(rev, p)).items():
            if v[0] not in ('theorem', 'lemma'):
                continue
            n += 1
            s = sig(v[2], nm.split('#')[0])
            hits += [f'    {un} ({short(up)}) = {nm} ({p}:{v[1]})' for (up, un), us in newdecl.items() if us == s]
    L.append(f'  {lab} ({rev[:8]}): {len(files)} files, {n} theorems scanned; hits {len(hits)}')
    L += hits
allf = [p for p in R.git('ls-tree', '-r', '--name-only', HEAD, 'TCSlib').stdout.split() if p.endswith('.lean') and p not in UNIT]
idx = {}
for (up, un), us in newdecl.items():
    idx.setdefault(us, []).append((up, un))
hits, n = [], 0
for p in allf:
    for nm, v in decls(R.show(HEAD, p)).items():
        if v[0] not in ('theorem', 'lemma'):
            continue
        n += 1
        hits += [f'    {un} ({short(up)}) = {nm} ({p}:{v[1]})' for up, un in idx.get(sig(v[2], nm.split('#')[0]), [])]
L.append(f'# D. the same scan against every theorem of the {len(allf)} other TCSlib files at the head ({n} theorems): '
         f'hits {len(hits)}')
L += hits
W('dupscan.txt', L)

# 9. the LE-gate39 evidence ------------------------------------------------------------------------------------------
L = []
zp = f'{GD}/landing-r1/gate39-le-evidence.zip'
zb = open(os.path.join(repo_path, zp), 'rb').read()
z = zipfile.ZipFile(io.BytesIO(zb))
names = z.namelist(); files = [n for n in names if not n.endswith('/')]
man = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in
       open(os.path.join(repo_path, GD, 'landing-r1/evidence-SHA256SUMS'), encoding='utf-8').read().splitlines() if l.strip()}
L.append(f'{zp}: SHA-256 {sha(zb)}; {len(names)} entries = {len(names) - len(files)} directories + {len(files)} files; the '
         f'files are the {len(man)} manifest paths plus SHA256SUMS: {set(files) == set(man) | {"SHA256SUMS"}}; every '
         f'manifest hash verifies: {all(sha(z.read(p)) == h for p, h in man.items())}; inner SHA256SUMS = '
         f'landing-r1/evidence-SHA256SUMS: {z.read("SHA256SUMS") == open(os.path.join(repo_path, GD, "landing-r1/evidence-SHA256SUMS"), "rb").read()}; '
         f'PROVENANCE.txt = landing-r1/PROVENANCE.txt: {z.read("PROVENANCE.txt") == open(os.path.join(repo_path, GD, "landing-r1/PROVENANCE.txt"), "rb").read()}')
ex = all(open(os.path.join(evd, p), 'rb').read() == z.read(p) for p in files)
L.append(f'the extracted copy used below equals the ZIP entry for entry: {ex}')
rd = lambda p: z.read(p).decode('utf-8')
L.append(f'landing/le-gate39.diff = git diff {R1H[:8]} {HEAD[:8]}: {z.read("landing/le-gate39.diff") == diff}')
pat = [n for n in files if n.startswith('landing/patch/')]
pb = rd(pat[0])
pdiff = pb[pb.index('diff --git'):pb.rindex('\n-- \n') + 1]
L.append(f'{pat[0]}: names the commit {HEAD}: {pb.startswith("From " + HEAD)}; its diff part = git diff '
         f'{R1H[:8]} {HEAD[:8]}: {pdiff.encode() == diff}')
cm = rd('landing/commit-msg.txt')
L.append(f'landing/commit-msg.txt = the commit message of {HEAD[:8]}: '
         f'{cm.strip() == R.git("log", "-1", "--format=%B", HEAD).stdout.strip()}')
L.append(f'landing/commits.txt first line: {rd("landing/commits.txt").splitlines()[0]}')
for f, tr in [('landing/merge-tree-a-tip-x-327.txt', EVA['tree']), ('landing/merge-tree-b-SA-x-324.txt', EVB['tree'])]:
    L.append(f'{f} records the tree {tr[:8]}: {tr in rd(f)}')
L.append(f'statements/decls2-vs-parent.tsv bytes {len(z.read("statements/decls2-vs-parent.tsv"))} (empty: no declaration '
         f'ADDED, CHANGED or REMOVED against round 1)')
L.append(f'statements/touched-vs-parent.tsv: {[l for l in rd("statements/touched-vs-parent.tsv").splitlines() if not l.startswith("UNCHANGED")][:6]}')
L.append(f'checks/legate39-checks.txt: {[l for l in rd("checks/legate39-checks.txt").splitlines() if l.startswith(("==", "theorem", "changed", "max"))]}')
L.append(f'checks/doconly-sg.txt: {rd("checks/doconly-sg.txt").splitlines()} (RESULT FAIL = "not docstring-only", as '
         f'expected for a proof and import change)')
L.append(f'checks/combined-old-639d16d9-vs-new-c51cf08d-code.txt: {rd("checks/combined-old-639d16d9-vs-new-c51cf08d-code.txt").splitlines()}')
L.append(f'lint/linediff-Cryptography-bd19c433-vs-a94ba750.txt bytes: {len(z.read("lint/linediff-Cryptography-bd19c433-vs-a94ba750.txt"))}')
for f in ('build-a/summary.txt', 'build-b/build/summary.txt'):
    L.append(f'{f}: {rd(f).splitlines()[0]}')
L.append(f'build-b/verify.txt: {[l for l in rd("build-b/verify.txt").splitlines() if l.startswith("RESULT") or "RealPrefixBounds" in l]}')
for f in ('admissions/census-tip-0542dd92.txt', 'admissions/census-a-4cd422c7.txt', 'admissions/census-b-c51cf08d.txt'):
    t = rd(f)
    tot_ = re.search(r'TOTAL (\d+) sorry warnings over (\d+) modules', t)
    sq = [l.strip() for l in t.splitlines() if re.search(r'Composability/SequentialZK\s', l + ' ')][:1]
    L.append(f'{f}: TOTAL {tot_.group(1)} over {tot_.group(2)} modules; {sq}; disagreeing '
             f'{re.search(r"disagreeing (\[.*?\])", t).group(1)}')
L.append(f'admissions/census-b-vs-int-all-open-639d16d9.diff bytes {len(z.read("admissions/census-b-vs-int-all-open-639d16d9.diff"))}')
L.append(f'tree/tree-check-combined.txt: {rd("tree/tree-check-combined.txt").splitlines()[-1]}')
L.append(f'restore/snapshot-post.out: {rd("restore/snapshot-post.out").strip().splitlines()[-1]}')
L.append(f'axioms/probe-runs/mods/G39Probe_Axioms.log:')
L += ['  ' + ' '.join(x.split()) for x in re.split(r"\n(?=')", rd('axioms/probe-runs/mods/G39Probe_Axioms.log').strip())]
for v in ('A', 'B', 'coe-A', 'coe-B'):
    L.append(f'rule10/seals-{v}.tsv: {rd(f"rule10/seals-{v}.tsv").strip()}')
for v in ('coe', 'strict'):
    t = rd(f'rule10/ctlcheck-{v}.log')
    sealed = [l for l in t.splitlines() if l.split(' ')[1:2] and l.split(' ')[1].startswith('ControlS_')]
    neg = {}
    for l in sealed:
        pr_ = l.split(' ')[1]
        pairs = re.findall(r"\('(\w+)', (\d+)\)", l)
        neg[pr_] = (sum(1 for n_, c in pairs if not n_.endswith('Reader') and c == '1'),
                    sum(1 for n_, c in pairs if not n_.endswith('Reader')),
                    [n_ for n_, c in pairs if n_.endswith('Reader') and c != '0'])
    L.append(f'rule10/ctlcheck-{v}.log: {t.strip().splitlines()[-1]}; sealed probes (negatives failing once / '
             f'negatives, readers failing): {neg}')
W('evidence.txt', L)
print('OK', out)
