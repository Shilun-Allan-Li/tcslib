/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.Hashing.CollisionResistant
import TCSlib.Cryptography.Hashing.FromDiscreteLog
import TCSlib.Cryptography.Hashing.FromDiscreteLog.Algebra
import TCSlib.Cryptography.Hashing.FromDiscreteLog.Coins
import TCSlib.Cryptography.Hashing.FromDiscreteLog.Encoding
import TCSlib.Cryptography.Hashing.FromDiscreteLog.Probability
import TCSlib.Cryptography.Hashing.FromDiscreteLog.Reduction
import TCSlib.Cryptography.Hashing.FromDiscreteLog.Sampling
import TCSlib.Cryptography.Hashing.SIS

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Cryptographic hashing constructions

## Contents

* `CollisionResistant` — the machine-level hash family interface, compression, and collision game.
* `FromDiscreteLog` — the discrete-log hash family, efficient evaluator and security statement.
* `SIS` — binary matrix hashing, its encoded evaluator, and the negligible raw-collision bound
  for the dyadic profile under the independent SIS assumption [Pei16, §5.1].

`Authentication.Signatures.HashAndSign` consumes the hash interface to extend a signature
scheme's message space. The hash domain and digest width conditions are stated there.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  Definition 140.1, Protocol 142.2 and Theorem 142.3.
* [Pei16] C. Peikert, *A Decade of Lattice Cryptography*, 17 February 2016.
-/
