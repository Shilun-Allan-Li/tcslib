import TCSlib

#print axioms TCSlib.Cryptography.Composability.ccaScheme_cca2
#print axioms TCSlib.Cryptography.Authentication.dlHash_crh
#print axioms TCSlib.Cryptography.Authentication.hashAndSign_oneTimeSecure
#print axioms TCSlib.Cryptography.Authentication.lamport_oneTimeSecure
#print axioms TCSlib.Cryptography.Authentication.exists_oneTimeSecure_of_crh_owf
