"""objcmp.py <mine.jsonl> <ref.jsonl> <label>: per module of <mine>, whether its source and olean SHA-256
equal the latest record of the same module in <ref>."""
import sys, json
def last(p):
    d = {}
    for l in open(p):
        r = json.loads(l)
        if 'module' in r: d[r['module']] = r
    return d
me, ref, lab = last(sys.argv[1]), last(sys.argv[2]), sys.argv[3]
for m, r in me.items():
    o = ref.get(m)
    print(m, f'{lab}:' + ('absent' if o is None else ('src=' if o['source_sha256'] == r['source_sha256'] else 'src!') + ('obj=' if o['object_sha256'] == r['object_sha256'] else 'obj!')))
