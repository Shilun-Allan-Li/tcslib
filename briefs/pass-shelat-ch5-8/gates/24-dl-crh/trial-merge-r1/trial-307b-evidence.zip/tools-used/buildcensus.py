"""buildcensus.py <prefix> <out> <records.jsonl>...: for every module under <prefix> (plus the facade
<prefix> itself), the `declaration uses 'sorry'` count of its latest record across the given record files
(later files win), with the file it came from."""
import sys, json
pre, out, files = sys.argv[1], sys.argv[2], sys.argv[3:]
last = {}
for f in files:
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and (r['module'] == pre or r['module'].startswith(pre + '/')): last[r['module']] = (r, f)
L = [f"{r['sorry']}\trc {r['rc']}\t{m}\t{f.split('/')[-2]}/{f.split('/')[-1]}" for m, (r, f) in sorted(last.items())]
L.append(f"TOTAL {sum(r['sorry'] for r, _ in last.values())} sorry warnings in {sum(1 for r, _ in last.values() if r['sorry'])} of {len(last)} modules; rc!=0: {[m for m, (r, _) in last.items() if r['rc']]}")
open(out, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))
