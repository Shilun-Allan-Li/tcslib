"""srcsorry.py <repo> <rev> <dir> <out>: per-file count of `sorry` tokens in code (nested /- -/ block
comments, -- line comments and string literals removed) for every .lean file under <dir> at <rev>."""
import sys, re, subprocess
repo, rev, d, out = sys.argv[1:5]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
def strip(s):
    o, i, n, depth = [], 0, len(s), 0
    while i < n:
        if depth:
            if s.startswith('/-', i): depth += 1; i += 2
            elif s.startswith('-/', i): depth -= 1; i += 2
            else: i += 1
        elif s.startswith('/-', i): depth = 1; i += 2
        elif s.startswith('--', i):
            j = s.find('\n', i); i = n if j < 0 else j
        elif s[i] == '"':
            i += 1
            while i < n and s[i] != '"': i += 2 if s[i] == '\\' else 1
            i += 1
        else: o.append(s[i]); i += 1
    return ''.join(o)
fs = sorted(f for f in git('ls-tree', '-r', '--name-only', rev, d).split() if f.endswith('.lean'))
tot = 0; lines = []
for f in fs:
    c = len(re.findall(r'(?<![\w.])sorry(?![\w])', strip(git('show', f'{rev}:{f}'))))
    tot += c; lines.append(f'{c}\t{f}')
lines.append(f'TOTAL {tot} sorry tokens in {sum(1 for l in lines if not l.startswith("0"))} of {len(fs)} files under {d} at {rev}')
open(out, 'w').write('\n'.join(lines) + '\n'); print(lines[-1])
