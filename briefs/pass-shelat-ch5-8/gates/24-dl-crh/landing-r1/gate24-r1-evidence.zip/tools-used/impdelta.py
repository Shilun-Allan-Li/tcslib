"""impdelta.py <repo-root> <added-import> <module>...: for each module, the project modules that adding
`import <added-import>` to Encoding brings newly into its transitive closure (source-level)."""
import sys, os, re
root, add, mods = sys.argv[1], sys.argv[2], sys.argv[3:]
def path(m): return os.path.join(root, *m.split('.')) + '.lean'
def imports(m):
    out = []
    for line in open(path(m), encoding='utf-8'):
        mm = re.match(r'^import\s+(\S+)', line.strip())
        if mm: out.append(mm.group(1))
    return [y for y in out if os.path.exists(path(y))]
def closure(m):
    seen, stack = set(), [m]
    while stack:
        x = stack.pop()
        for y in imports(x):
            if y not in seen: seen.add(y); stack.append(y)
    return seen
addc = closure(add) | {add}
for m in mods:
    c = closure(m)
    print(f'{m}: closure {len(c)}; ReductionSupport-closure modules not yet in it: {len(addc - c)}')
    for x in sorted(addc - c): print('   +', x)
