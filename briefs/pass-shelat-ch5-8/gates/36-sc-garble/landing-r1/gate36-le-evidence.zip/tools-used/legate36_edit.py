r"""legate36_edit.py <file>: LE-gate36 (G36-01) on SpecialEncryptionMulti/SliceParser.lean, 3 exact replacements (each must
occur exactly once): add `import TCSlib.Cryptography.Asymptotic.BlockEncryptor`; delete the duplicate
`SliceReduction.length_le_encodeList` with its docstring (and the blank line after it); at its one use in slicePost_encode
call the public `TCSlib.Cryptography.length_le_length_encodeList`."""
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
R = [
 ('import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.MultiMsgOut\n',
  'import TCSlib.Cryptography.Asymptotic.BlockEncryptor\nimport TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.MultiMsgOut\n'),
 ('''/-- Each encoded list has at least as many bits as entries:
`l.length ≤ (PrivateKeyScheme.encodeList l).length`. -/
theorem length_le_encodeList (l : List (List Bool)) :
    l.length ≤ (PrivateKeyScheme.encodeList l).length := by
  induction l with
  | nil => rw [List.length_nil, PrivateKeyScheme.encodeList_nil, List.length_nil]
  | cons a l ih =>
    rw [List.length_cons, PrivateKeyScheme.encodeList_cons, length_pairEncode]
    omega

''', ''),
 ('    have h := length_le_encodeList (l.map Prod.snd)\n',
  '    have h := TCSlib.Cryptography.length_le_length_encodeList (l.map Prod.snd)\n'),
]
for a, b in R:
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s)
print('3 replacements applied')
