"""mkverif3637.py <repo> <36|37> <rec-rev> <checks-dir> <tools-dir> <out.zip>: Gate 36 (sc-garble, #323) and Gate 37
(sc-compose, #324) verification.zip from byte-identical originals: the Gate 34/35 method (g34/tools/mkverif3435.py) for
review ZIPs without a top folder. Members: the review evidence ZIP and its manifest and the review's landing extract
(git objects at REC, checked equal to the working tree); the cited records at REC; byte copies of cited entries of the
evidence ZIP; the worker's extracts from the delivery commit(s); and the pack's git-object re-checks with their
scripts. Writes SHA256SUMS (every other entry) and PROVENANCE.txt inside the ZIP. Also writes the gate's landing/
extracts (byte copies of evidence entries) next to the ZIP."""
import collections, hashlib, io, os, subprocess, sys, zipfile

repo, gate, REC, chk, tools, out = sys.argv[1:7]
B = 'briefs/pass-shelat-ch5-8'
COMMON_EXT = ['logs/payload-check.txt', 'logs/git-am-integrity.log', 'logs/src-equality.txt', 'logs/issue-package-check.txt',
              'logs/source-sums-check.txt', 'logs/census-summary.txt', 'logs/census-base-vs-head.tsv', 'logs/sorry-census.txt',
              'logs/seal-table-seals.txt', 'logs/seal-table-seals-coe.txt', 'logs/seal-head-seals-coe-A.tsv',
              'logs/seal-head-seals-A.tsv', 'logs/seal-head-seals-coe-B.tsv', 'logs/seal-head-seals-B.tsv',
              'logs/seal-base-seals-coe-A.tsv', 'logs/seal-base-seals-A.tsv', 'logs/ctlcheck.log', 'logs/ctlcheck-strict.log',
              'logs/controls-strict-attribution.txt', 'logs/scan2-head.log', 'logs/open-pr-overlap.txt',
              'logs/mkseals-coe-A.log', 'logs/mkseals-ab-A.log', 'logs/mkseals-coe-B.log', 'logs/mkseals-ab-B.log',
              'clash/nameclash-head.txt', 'landing/landing.log', 'landing/commits.txt', 'landing/changed-paths-vs-origin.txt',
              'landing/origin-delta-since-issue-base.txt', 'landing/le-doc.diff', 'landing/le-doc-doconly.txt',
              'landing/commit-msg-le-doc.txt', 'order/build-queue.txt', 'order/le-build-queue.txt',
              'order/control-probes.txt', 'probe-sources/head/CensusHead.lean', 'probe-sources/head/DepTrace.lean',
              'probe-runs/mods/PlProbe_H_DepTrace.log', 'restore/restore-log.txt', 'tree/snapshot-pre.txt',
              'tree/snapshot-post.txt', 'tree/tree-check-post.txt', 'controls/controls-plan.json',
              'controls-strict/controls-plan.json', 'logs/worker-REPORT.md']
CFG = {
    '36': dict(
        unit='sc-garble', pr=323, head='cd9a48438c2a6548fe9e246ce569be57c9df96b3',
        exch={'final': 'a73072f19787ee437f2201777711c7eb3154c714'},
        rev='5a121c0290969e1f7725f997b8e5683169613a62ba4db203669a74590bd0e658',
        recs=[f'{B}/duplication-ledger.md', 'PassShelatChapter5-8Plan.md', f'{B}/gates/27-b1-multimsg/resolutions-r1.md',
              f'{B}/gates/31-prf-long/findings/gate31-prf-long-findings.md', f'{B}/gates/31-prf-long/resolutions-r1.md',
              f'{B}/gates/31-prf-long/worker-report.md', f'{B}/maintainer/securecomp-plan-2026-11-14/plan.md',
              f'{B}/fills/codex-host-2026-11-15/host-addendum.md', f'{B}/fills/sc-yao/issued-r1/ruling-SY.md'],
        worker=[('final', w) for w in [
            'patches/COMMITS.tsv', 'evidence/scope-request/fanin-reader.patch', 'evidence/scope-request/fanin-reader.md',
            'evidence/scope-request/autonomy.md', 'evidence/seals/B-attribution.md', 'evidence/seals/final-summary.txt',
            'evidence/logs/final-axiom-summary.txt', 'evidence/logs/preflight.log',
            'evidence/coordination/checkpoint1-push-review.md', 'evidence/headers/final/results.json',
            'evidence/headers/final/controls.json', 'evidence/headers/final/run.log', 'evidence/headers/final/Yao.diff',
            'evidence/headers/corollary-proof.diff', 'evidence/headers/private-uses-base.log',
            'evidence/headers/checkpoint2/approved-reader.diff', 'evidence/headers/checkpoint2/approved-reader-check.txt',
            'evidence/clash/final.log', 'evidence/declarations/final-signatures.txt']],
        dx=None,
        ext=COMMON_EXT + [
            'logs/seal-B-attribution.txt', 'logs/scan-attribution.txt', 'logs/duplication-review.txt',
            'logs/ruling-SG-1.md', 'logs/census-base-vs-head-namemap.tsv', 'logs/exchange-commits.txt',
            'logs/exchange-commits-after-final.txt', 'logs/open-prs.txt', 'dup/getd-headd-added-lines.txt',
            'clash/unit-new-short-names.txt', 'statements/frozen/frozen-check.txt', 'statements/frozen/frozen-check-le.txt',
            'statements/frozen/controls-summary.txt', 'statements/frozen/sg1-private-uses.txt',
            'statements/frozen/yao.diff', 'statements/frozen/specialEncryptionMulti.diff',
            'statements/frozen/dagcircuit.diff', 'statements/frozen/control-remove-zipWith_xor_append_of_le.txt',
            'statements/frozen/control-header-of_joint.txt', 'statements/frozen/control-body-IsFaninTwo.txt',
            'statements/namemap-sg1.txt', 'statements/head/touched.tsv', 'statements/head/decls2-vs-base.tsv',
            'statements/head/docaudit.tsv', 'statements/head/sketchaudit.txt', 'statements/head/sizes-widths.txt',
            'lint/linediff.txt', 'lint/lint-landing-head.txt', 'lint/lint-records-tip-1321b9cb.txt',
            'lint/lint-complexity-landing-head.txt', 'lint/lint-complexity-records-tip-1321b9cb.txt',
            'lint/oldlint-linediff.txt', 'order/seal-probes-head.txt', 'order/seal-probes-base.txt',
            'order/base-phase/base-build-queue.txt', 'scan/explicit-head.json', 'edit-build/summary.txt']),
    '37': dict(
        unit='sc-compose', pr=324, head='a6eaebd78c48e7fdfd06263edb84b70bc00ec593',
        exch={'final': 'bdfdcb76d0d78bedd61025b33cb7382b26ee7c70', 'cp1': '419c4ceb', 'cp2': 'f1ba0b1a'},
        rev='c11ce8bb81d2ab7bf19259740f78c1dd2006d08e14e6672f9b257a131445a24b',
        recs=[f'{B}/duplication-ledger.md', 'PassShelatChapter5-8Plan.md',
              f'{B}/maintainer/securecomp-plan-2026-11-14/plan.md'],
        worker=[('final', w) for w in [
            'patches/COMMITS.tsv', 'evidence/final/census-diff.txt', 'evidence/final/sorry-census-final.txt',
            'evidence/lint/lintdiff-final.txt', 'evidence/axioms/axioms-final.log', 'evidence/amcheck/amcheck-final.log',
            'evidence/headers/headers-final.txt', 'evidence/headers/control-final.txt',
            'evidence/checks/sketches-final.txt', 'evidence/checks/widths-final.txt', 'evidence/controls/results.json']]
               + [('cp1', 'REPORT.md'), ('cp2', 'REPORT.md')],
        dx={('cp1', 'REPORT.md'): 'checkpoint-reports/REPORT-cp1-419c4ceb.md',
            ('cp2', 'REPORT.md'): 'checkpoint-reports/REPORT-cp2-f1ba0b1a.md'},
        ext=COMMON_EXT + [
            'logs/git-am-integrity-unsigned.log', 'logs/census-base-vs-head-namemap.tsv', 'logs/exchange-commits.txt',
            'statements/owned-file-blobs.txt', 'statements/frozen/frozen-check.txt', 'statements/frozen/controls-summary.txt',
            'statements/frozen/owned.diff', 'statements/head-le/frozen-check.txt', 'statements/head-le/touched.tsv',
            'statements/head-le/decls2-vs-base.tsv', 'statements/head-le/decls2-vs-worker.tsv',
            'statements/head-le/docaudit.tsv', 'statements/head-le/sketchaudit.txt', 'statements/head-le/sizes-widths.txt',
            'statements/head/ledoc-candidates.tsv', 'landing/le-doc-plan.tsv', 'lint/linediff-preLE.txt',
            'lint/lint-landing-head-preLE.txt', 'lint/lint-records-tip-6ce4658d.txt', 'order/seal-probes-head.txt',
            'order/seal-probes-base.txt', 'order/base-build-queue.txt', 'scan/explicit-head.json',
            'edit-build/summary.txt']),
}[gate]
LANDING = [('root-checks.jsonl', 'build/results.jsonl'), ('build-summary.txt', 'build/summary.txt'),
           ('edit-build-results.jsonl', 'edit-build/results.jsonl'), ('edit-build-summary.txt', 'edit-build/summary.txt'),
           ('census-head.log', 'probe-runs/mods/PlProbe_H_CensusHead.log'),
           ('frozen-check.txt', 'statements/frozen/frozen-check-le.txt' if gate == '36' else 'statements/head-le/frozen-check.txt'),
           ('tree-check-head.txt', 'tree/tree-check-head.txt')]
unit, HEAD, REV = CFG['unit'], CFG['head'], CFG['rev']
FR, IR = f'{B}/fills/{unit}/final-r1', f'{B}/fills/{unit}/issued-r1'
GD = f'{B}/gates/{"36-sc-garble" if gate == "36" else "37-sc-compose"}'


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


show = lambda rev, path: git('show', f'{rev}:{path}')
sha = lambda b: hashlib.sha256(b).hexdigest()
EX = {k: git('rev-parse', v).decode().strip() for k, v in CFG['exch'].items()}
members = []


def from_rec(src, dst):
    b = show(REC, src)
    assert open(os.path.join(repo, src), 'rb').read() == b, f'working tree differs from {REC[:8]} for {src}'
    members.append((dst, b, f'records {REC[:8]}:{src}'))


from_rec(f'{FR}/review-evidence.zip', 'review-evidence.zip')
from_rec(f'{FR}/evidence-SHA256SUMS', 'review-evidence-SHA256SUMS')
for name in sorted(os.listdir(os.path.join(repo, FR, 'landing'))):
    from_rec(f'{FR}/landing/{name}', f'landing/{name}')
for name in sorted(os.listdir(os.path.join(repo, IR))):
    from_rec(f'{IR}/{name}', f'records/{IR}/{name}')
for src in CFG['recs']:
    from_rec(src, f'records/{src}')
for k, w in CFG['worker']:
    members.append((f'worker/{k}/{w}', show(EX[k], f'inbox/fills/{unit}/{w}'),
                    f'exchange {EX[k][:8]}:inbox/fills/{unit}/{w}'))
by = {p: b for p, b, _ in members}
assert sha(by['review-evidence.zip']) == REV, 'review-evidence.zip hash'
man = {}
for l in by['review-evidence-SHA256SUMS'].decode().splitlines():
    if l.strip():
        h, p = l.split('  ', 1); man[p] = h
zf = zipfile.ZipFile(io.BytesIO(by['review-evidence.zip']))
allnames = zf.namelist(); names = [n for n in allnames if not n.endswith('/')]
assert set(names) == set(man) | {'SHA256SUMS'}, sorted(set(names) ^ (set(man) | {'SHA256SUMS'}))[:5]
for p, h in man.items():
    assert sha(zf.read(p)) == h, p
assert zf.read('SHA256SUMS') == by['review-evidence-SHA256SUMS'], 'inner SHA256SUMS differs from the manifest'
cnt = (len(allnames), len(allnames) - len(names), len(names), len(man))
assert by['landing/PROVENANCE.txt'] == zf.read('PROVENANCE.txt')
dx = []
for (k, w), e in (CFG['dx'] or {}).items():
    assert by[f'worker/{k}/{w}'] == zf.read(f'logs/delivery-extracts/{e}'), w
    dx.append(f'worker/{k}/{w} = logs/delivery-extracts/{e}')
for k, w in CFG['worker']:
    e = f'logs/delivery-extracts/{w}'
    if k == 'final' and e in man:
        assert by[f'worker/{k}/{w}'] == zf.read(e), w
        dx.append(f'worker/{k}/{w} = {e}')
for e in CFG['ext']:
    members.append((f'evidence/{e}', zf.read(e), f'review-evidence.zip:{e}'))
for c in sorted(os.listdir(chk)):
    members.append((f'pack-checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
for t in ['packchk.py', 'gitlib.py', 'decls2rev.py', 'mkverif3637.py']:
    members.append((f'pack-checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
# landing/ extracts beside the ZIP (records), byte copies of evidence entries
os.makedirs(os.path.join(repo, GD, 'landing'), exist_ok=True)
for dst, e in LANDING:
    open(os.path.join(repo, GD, 'landing', dst), 'wb').write(zf.read(e))
nrec = sum(p.startswith('records/') for p, _, _ in members)
nw = sum(p.startswith('worker/') for p, _, _ in members)
prov = f"""Gate {gate} ({unit}, draft PR #{CFG['pr']}, Lean head {HEAD}) verification.zip

Every file that the maintainer review (final-r1/review.md) cites and the pack uses, as byte-identical originals. Nothing
was re-run to build this ZIP; pack-checks/ holds the pack's own re-checks from git objects (no Lean), with their scripts.
- review-evidence.zip: the delivery review's raw evidence (final-r1/review-evidence.zip, SHA-256 {REV}), with its
  manifest review-evidence-SHA256SUMS (= final-r1/evidence-SHA256SUMS). The ZIP has {cnt[0]} entries, no top folder:
  {cnt[1]} directory entries and {cnt[2]} file entries. The file entries are exactly the {cnt[3]} manifest paths plus
  SHA256SUMS, which is byte-identical to the manifest; every manifest hash verifies.
- landing/PROVENANCE.txt: the review's PROVENANCE (final-r1/landing/), byte-identical to the ZIP's PROVENANCE.txt.
- records/ ({nrec}): git objects at records commit {REC} (each equal to the working tree): the issue package
  {IR}/ and the records the pack cites.
- evidence/: byte copies of the review-evidence.zip entries the pack cites (path = the entry's path).
- worker/ ({nw}): byte copies from exchange/pass-shelat-ch5-8 (inbox/fills/{unit}/) at """ + ', '.join(
    f'{k} {v}' for k, v in EX.items()) + f""".
  Byte-identical to the review's copies under logs/delivery-extracts/ ({len(dx)}):
""" + ''.join(f'    {x}\n' for x in dx) + f"""  The worker's final REPORT.md is worker-report.md in the gate pack.
- pack-checks/: the maintainer's re-checks for this pack, from git objects only, and tools/ (packchk.py with gitlib.py;
  decls2rev.py = maintainer/tools/decls2.py's parser applied to two revisions; this script).
SHA256SUMS lists every entry except itself.

Sources:
""" + ''.join(f'  {p}  <-  {d}\n' for p, _, d in sorted(members))
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
assert len({p for p, _, _ in members}) == len(members), 'duplicate member'
sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
members.append(('SHA256SUMS', sums.encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as z:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=(2026, 11, 15, 0, 0, 0))
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_STORED if p.endswith('.zip') else zipfile.ZIP_DEFLATED
        z.writestr(zi, b)
with zipfile.ZipFile(out) as z:
    listed = z.namelist()
    inner = {l.split('  ', 1)[1] for l in z.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == inner | {'SHA256SUMS'} and len(listed) == len(inner) + 1
    for l in z.read('SHA256SUMS').decode().splitlines():
        h, p = l.split('  ', 1)
        assert sha(z.read(p)) == h, p
print(f'OK gate {gate}: {len(listed)} entries {dict(collections.Counter(n.split("/")[0] for n in listed))}; review {cnt}; '
      f'dx {len(dx)}; sha256 {sha(open(out, "rb").read())}')
