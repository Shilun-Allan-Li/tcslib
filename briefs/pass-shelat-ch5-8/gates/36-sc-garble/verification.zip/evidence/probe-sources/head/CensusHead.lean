import Lean
import TCSlib.Complexity.CircuitComplexity.DAGCircuit
import TCSlib.Cryptography.SecureComputation.Garbling
import TCSlib.Cryptography.SecureComputation.Garbling.CoinBlocks
import TCSlib.Cryptography.SecureComputation.Garbling.Probability
import TCSlib.Cryptography.SecureComputation.GarblingSecurity
import TCSlib.Cryptography.SecureComputation.GarblingSecurity.CoinMarginals
import TCSlib.Cryptography.SecureComputation.GarblingSecurity.NestedBounds
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti.SliceParser
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti.SliceReduction
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity.Pad
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity.WrongKey
import TCSlib.Cryptography.SecureComputation.Yao
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-garble review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.SecureComputation.spDecStr_wrongKey
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_wrongKey
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_multiMessageSecure
#print axioms TCSlib.Cryptography.SecureComputation.nestedSpecial_wrongKeyBot
#print axioms TCSlib.Cryptography.SecureComputation.uprob_not_good_le
#print axioms TCSlib.Cryptography.SecureComputation.yaoSeed_good_whp
#print axioms TCSlib.Cryptography.SecureComputation.sliceMultiMessageSecure_of_prfOut
#print axioms TCSlib.Cryptography.SecureComputation.garbling_good_whp
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_multiMessageSecure_of_joint
#print axioms TCSlib.Cryptography.SecureComputation.yaoHybrid_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.uprob_not_good_le_of_perm
#print axioms TCSlib.Cryptography.SecureComputation.uprob_not_good_le_of_uniform_data
#print axioms TCSlib.Cryptography.SecureComputation.uprob_not_good_distinct_le_of_uniform_data
#print axioms TCSlib.Cryptography.SecureComputation.GarblingCoins.nestedSpecial_wrongKeyBot_of_string_bounds
#print axioms TCSlib.Cryptography.SecureComputation.SpecialWrongKey.exists_negligible_prefix_collision
#print axioms TCSlib.Cryptography.SecureComputation.SliceReduction.slicePost_tuple
#print axioms TCSlib.Cryptography.SecureComputation.SliceReduction.exists_slicePost_nuppt
#print axioms TCSlib.Cryptography.SecureComputation.SliceReduction.polyTimeComputable_slicePost
#print axioms BoolCircuit.DAGCircuit.isFaninTwo_iff

def owners : List Name := [`TCSlib.Complexity.CircuitComplexity.DAGCircuit,
  `TCSlib.Cryptography.SecureComputation.Garbling,
  `TCSlib.Cryptography.SecureComputation.Garbling.CoinBlocks,
  `TCSlib.Cryptography.SecureComputation.Garbling.Probability,
  `TCSlib.Cryptography.SecureComputation.GarblingSecurity,
  `TCSlib.Cryptography.SecureComputation.GarblingSecurity.CoinMarginals,
  `TCSlib.Cryptography.SecureComputation.GarblingSecurity.NestedBounds,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti.SliceParser,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti.SliceReduction,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity.Pad,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity.WrongKey,
  `TCSlib.Cryptography.SecureComputation.Yao]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

