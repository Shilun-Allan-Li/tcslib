import Lean
import TCSlib.Cryptography.Asymptotic.Universal
import TCSlib.Cryptography.Asymptotic.Universal.Canonizer
import TCSlib.Complexity.TuringMachine.CodeFormat
import TCSlib.Complexity.TuringMachine.CodeSimulator

/-! canonizer review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.exists_canonizerExp
#print axioms Turing.MachineFormat.exists_polyCanonizer
#print axioms Turing.FinTM.computesFunInTime_appendBit
#print axioms TCSlib.Cryptography.fUniversal_easy
#print axioms TCSlib.Cryptography.fUniversal_hard
#print axioms TCSlib.Cryptography.fUniversal_weakOneWay
#print axioms TCSlib.Cryptography.theorem_63_1
#print axioms TCSlib.Cryptography.exists_codeCanonizer
#print axioms TCSlib.Cryptography.exists_effectiveMachineCode_canonizerTime_le
#print axioms Turing.oneTapeFormat_serialize_decode
#print axioms Turing.oneTapeMachineFormat_serialize_decode

def owners : List Name := [`TCSlib.Cryptography.Asymptotic.Universal,
  `TCSlib.Cryptography.Asymptotic.Universal.Canonizer,
  `TCSlib.Complexity.TuringMachine.CodeFormat,
  `TCSlib.Complexity.TuringMachine.CodeSimulator]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

