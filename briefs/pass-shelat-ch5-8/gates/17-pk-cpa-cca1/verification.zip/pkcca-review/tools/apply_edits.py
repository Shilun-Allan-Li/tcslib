"""apply_edits.py <b-root>: the pk-cpa-cca1 landing edits, as exact old->new replacements (each must
occur exactly once). Docstring-only edits, plus: drop PRFGame.toComp_costBoundedBy (= published
Complexity.NUPPT.toComp_costBoundedBy) and PRFGame.eq_of_ofFn_eq (= List.ofFn_injective), and wrap
three lines over 100 characters."""
import sys
root = sys.argv[1] + '/TCSlib/Cryptography/Encryption/PrivateKey/'
E = {}
def e(f, old, new): E.setdefault(f, []).append((old, new))
C, L, T, RD, H, G, O = ('OracleFromPRF/Collision.lean', 'OracleFromPRF/Lazy.lean', 'OracleFromPRF/Transfer.lean',
  'OracleFromPRF/Reduction.lean', 'OracleFromPRF/Handler.lean', 'OracleFromPRF/Games.lean', 'OracleFromPRF.lean')
# --- formula docstrings
e(C, "/-- A key with a value in an association list is one of its keys. -/",
     "/-- A key with a value in an association list is one of its keys:\n`(T.lookup x).isSome → x ∈ T.map Prod.fst`. -/")
e(C, "/-- Adding a point grows the table by at most one. -/",
     "/-- Adding a point grows the table by at most one: `|(addPt b st x y hit).1| ≤ |st.1| + 1`. -/")
e(C, "/-- Away from the challenge's nonce the recorded values do not depend on `b`. -/",
     "/-- Away from the challenge's nonce the recorded values do not depend on `b`:\n`hitStar st x = false → look b st x = look b' st x`. -/")
e(C, "/-- Which points have a recorded value does not depend on `b`. -/",
     "/-- Which points have a recorded value does not depend on `b`:\n`(look b st x).isSome = (look b' st x).isSome`. -/")
e(C, "/-- Adding a point does not depend on `b`. -/",
     "/-- Adding a point does not depend on `b`: `addPt b st x y hit = addPt b' st x y hit`. -/")
e(C, "/-- **The flag stays raised.** -/",
     "/-- **The flag stays raised:** if `s.2.2 = true`, every outcome `ys` of\n`lazyImpl … b i x s` has `ys.2.2.2 = true`.\n\n**Proof sketch.** By the oracle: every branch keeps the flag or ors it with a new bit\n(`addPt_eq`, `lazyImpl_*`). -/")
e(C, "/-- **Each query grows the table by at most one point.** -/",
     "/-- **Each query grows the table by at most one point:** every outcome `ys` of\n`lazyImpl … b i x s` has `|ys.2.1| ≤ |s.1| + 1`.\n\n**Proof sketch.** By the oracle: encryptions and open decryptions add at most one point\n(`length_addPt_le`); challenges, closed decryptions and repeats keep the table. -/")
e(C, "/-- Expectations of functions `ε`-close at every point are `ε`-close. -/",
     "/-- Expectations of functions `ε`-close at every point are `ε`-close:\n`(∀ x, |f x - g x| ≤ ε) → |𝔼_c f - 𝔼_c g| ≤ ε`. -/")
e(C, """same law to good successors.

**Proof sketch.** An encryption""", """same law to good successors: for every `g`,
`𝔼[ys.2.2.2 ? 0 : g ys] (lazyImpl … b i x s) = 𝔼[ys.2.2.2 ? 0 : g ys] (lazyImpl … b' i x s)`.

**Proof sketch.** An encryption""")
e(C, """`⟨r, m₀ ⊕ y⟩ = ⟨r, m₁ ⊕ (y ⊕ m₀ ⊕ m₁)⟩`. -/""", """`⟨r, m₀ ⊕ y⟩ = ⟨r, m₁ ⊕ (y ⊕ m₀ ⊕ m₁)⟩`.

**Proof sketch.** Both are `pairEncode ⟦r⟧ _`; compare the second components position by
position: `m₀ᵢ ⊕ yᵢ = m₁ᵢ ⊕ (yᵢ ⊕ m₀ᵢ ⊕ m₁ᵢ)` by cases on the three bits. -/""")
e(L, "/-- Without a challenge record, the recorded values are the table's. -/",
     "/-- Without a challenge record, the recorded values are the table's:\n`look b (T, none, bd) x = T.lookup x`. -/")
e(L, "/-- With the challenge record `⟨ml, c⟩`, the value at `r*` is the pad, elsewhere the table's. -/",
     "/-- With the challenge record `⟨ml, c⟩`, the value at `r*` is the pad, elsewhere the table's:\n`look b (T, some (ml, c), bd) x = if x = rStar c then some (padAt b ml c) else T.lookup x`. -/")
e(L, "/-- The flag does not change the recorded values. -/",
     "/-- The flag does not change the recorded values: `look b (st.1, st.2.1, bd) = look b st`. -/")
e(L, """changes no recorded value, so `ovr` is unchanged. -/""",
     """changes no recorded value, so `ovr` is unchanged: `ovr b (addPt b st x y hit) R = ovr b st R`. -/""")
e(L, """`ovr b (addPt b st x y hit) R = ovr b st (Function.update R x y)`. -/""",
     """`ovr b (addPt b st x y hit) R = ovr b st (Function.update R x y)`.

**Proof sketch.** At `z = x` both sides read `y` (the new table entry, resp. the update); at
`z ≠ x` the new entry is skipped by `lookup` and the update is not read (`look_none`, `look_some`,
`List.lookup_cons`, `Function.update_of_ne`). -/""")
e(T, "/-- Reading a vector at an equal width keeps its word. -/",
     "/-- Reading a vector at an equal width keeps its word:\n`⟦(arrowCongr (finCongr h) (refl Bool)) v⟧ = ⟦v⟧`. -/")
e(T, "/-- An all-`false` list reads as the all-`false` vector at every width. -/",
     "/-- An all-`false` list reads as the all-`false` vector at every width:\n`padFin d (List.replicate m false) = zeroBits d`. -/")
# --- reuse: List.ofFn_injective for eq_of_ofFn_eq
e(T, """/-- Vectors with the same word are equal. -/
theorem eq_of_ofFn_eq {d : ℕ} {a c : Fin d → Bool} (h : List.ofFn a = List.ofFn c) :
    a = c :=
  List.ofFn_injective h

""", "")
e(T, "* `PRFGame.padFin_nil`, `padFin_replicate_false`, `eq_of_ofFn_eq`, `ofFn_arrowCongr_finCongr`:",
     "* `PRFGame.padFin_nil`, `padFin_replicate_false`, `ofFn_arrowCongr_finCongr`:")
# --- reuse: NUPPT.toComp_costBoundedBy
e(RD, """/-- The cost bound of a machine's computation: at most `q` queries. -/
theorem toComp_costBoundedBy {ι α : Type} {spec : OracleSpec ι} (A : NUPPT)
    (codec : MachineCodec spec α) (n q : ℕ) (r : A.Coins n) :
    (A.toComp codec n q r).CostBoundedBy (fun _ => 1) q := by
  rw [NUPPT.toComp_eq]
  exact buildComp_costBoundedBy _ _ q []

""", "")
e(RD, "`q(n)` queries, `toComp_costBoundedBy`) the composite", "`q(n)` queries, `NUPPT.toComp_costBoundedBy`) the composite")
e(RD, "        (toComp_costBoundedBy A _ n (q.eval n) r) (0, none) (Nat.zero_add _).le,",
      "        (A.toComp_costBoundedBy _ n (q.eval n) r) (0, none) (Nat.zero_add _).le,")
e(RD, "      (toComp_costBoundedBy A _ n (q.eval n) r) 0 (by omega) none]",
      "      (A.toComp_costBoundedBy _ n (q.eval n) r) 0 (by omega) none]")
e(O, "adversary makes at most `q(n)` queries, `toComp_costBoundedBy`).", "adversary makes at most `q(n)` queries, `NUPPT.toComp_costBoundedBy`).")
e(O, "      (fun r => toComp_costBoundedBy A _ n _ r)", "      (fun r => A.toComp_costBoundedBy _ n _ r)")
# --- lines over 100 characters
e(RD, "      rw [QueryImpl.comp_apply, pkAbs_eq, pkHState_eq, pkHandler_impl_dec_open q atkBit b n z ω x j o hj.le hop,",
      "      rw [QueryImpl.comp_apply, pkAbs_eq, pkHState_eq,\n        pkHandler_impl_dec_open q atkBit b n z ω x j o hj.le hop,")
e(RD, "      rw [QueryImpl.comp_apply, pkAbs_eq, pkHState_eq, pkHandler_impl_dec_closed q atkBit b n z ω x j o hj.le\n          hop,",
      "      rw [QueryImpl.comp_apply, pkAbs_eq, pkHState_eq,\n        pkHandler_impl_dec_closed q atkBit b n z ω x j o hj.le hop,")
e(RD, "      rw [QueryImpl.comp_apply, pkAbs_eq, pkHState_eq, pkHandler_impl_challenge_none q atkBit b n z ω x j hj,",
      "      rw [QueryImpl.comp_apply, pkAbs_eq, pkHState_eq,\n        pkHandler_impl_challenge_none q atkBit b n z ω x j hj,")
# --- handler answer sketches
e(H, """state `pkState (j + 1) o`. -/
theorem pkHandler_impl_enc""", """state `pkState (j + 1) o`.

**Proof sketch.** Read the round input field by field (`fields_input`); the first round, with an
empty log, asks the outer oracle at the tape `T_j` (`rNonce_fields`); the second, with the answer
`y` in the log (`rY_one`), returns `⟨T_j, m ⊕ y⟩` and the state with count `j + 1`
(`rNew_fields`); `impl_of_query` assembles the two rounds. -/
theorem pkHandler_impl_enc""")
e(H, """state is kept. -/
theorem pkHandler_impl_dec_open""", """state is kept.

**Proof sketch.** As for `pkHandler_impl_enc`: the open test reads `atkBit`, the flag and the
well-formedness of `⟦x⟧` (`fields_input`); the first round asks the outer oracle at `x₀`, the second
returns `⟨1, v ⊕ y⟩` with the state unchanged (`impl_of_query`). -/
theorem pkHandler_impl_dec_open""")
e(H, """recorded in the state `pkState (j + 1) (some c)`. -/
theorem pkHandler_impl_challenge_none""", """recorded in the state `pkState (j + 1) (some c)`.

**Proof sketch.** As for `pkHandler_impl_enc`, with the selected half `m_b` (`rMsg`, `msgOf_eq`)
and the new record `recBits (some c)` written into the state (`rNew_fields`). -/
theorem pkHandler_impl_challenge_none""")
for f, eds in E.items():
    p = root + f; s = open(p, encoding='utf-8').read()
    for old, new in eds:
        k = s.count(old)
        assert k == 1, (f, k, old[:80])
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print(f, len(eds), 'edits')
