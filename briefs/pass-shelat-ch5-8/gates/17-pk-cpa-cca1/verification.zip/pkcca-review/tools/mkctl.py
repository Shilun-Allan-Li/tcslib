"""mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
AC = 'TCSlib.Cryptography.Composability.AdaptiveCPA'
PK = 'TCSlib.Cryptography.Composability.FixedLengthPKScheme'
G = 'TCSlib.Cryptography.Games'
B = {
 'Turing.pairEncode': [
  ("ctlPair", True, "theorem ctlPair (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n"),
  ("ctlPairReader", False, "theorem ctlPairReader (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b\n"),
  ("anonymous example", True, "example (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n")],
 'TCSlib.Cryptography.padFin': [
  ("ctlPadFin", True, "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n"),
  ("ctlPadFinReader", False, "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n")],
 'TCSlib.Cryptography.Games.zeroBits': [
  ("ctlZeroBits", True, "theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl\n"),
  ("ctlZeroBitsReader", False, "theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=\n  TCSlib.Cryptography.Games.zeroBits_apply d j\n")],
 CS + '.chRun': [
  ("ctlChRun", True, f"theorem ctlChRun {{ins outs : Fin 2 → ℕ}} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)\n    (s : Option (Fin (outs 1) → Bool)) : {CS}.chRun g (.pure a) s = (a, s) := rfl\n"),
  ("ctlChRunReader", False, f"theorem ctlChRunReader {{ins outs : Fin 2 → ℕ}} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)\n    (s : Option (Fin (outs 1) → Bool)) : {CS}.chRun g (.pure a) s = (a, s) := {CS}.chRun_pure g a s\n")],
 CS + '.recAdvIn': [
  ("ctlRecAdvIn", True, f"theorem ctlRecAdvIn (c : List Bool) : {CS}.recAdvIn c =\n    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl\n"),
  ("ctlRecAdvInReader", False, f"theorem ctlRecAdvInReader (c : List Bool) : {CS}.recAdvIn c =\n    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := {CS}.recAdvIn_eq c\n")],
 f'{G}.simulate': [
  ("ctlSimulate", True, f"open {G} in\ntheorem ctlSimulate {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl\n"),
  ("ctlSimulateReader", False, f"open {G} in\ntheorem ctlSimulateReader {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := {G}.simulate_pure impl a s\n")],
 f'{PK}.inLens': [
  ("ctlPkInLens", True, f"theorem ctlPkInLens (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl\n"),
  ("ctlPkInLensReader", False, f"theorem ctlPkInLensReader (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=\n  S.inLens_zero n\n")],
 f'{AC}.castImpl': [
  ("ctlCastImpl", True, f"open {G} in\ntheorem ctlCastImpl {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) := rfl\n"),
  ("ctlCastImplReader", False, f"open {G} in\ntheorem ctlCastImplReader {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) :=\n  {AC}.castImpl_eq O i x s\n")],
 f'{AC}.hybImpl': [
  ("ctlHybImpl", True, f"open {G} in\ntheorem ctlHybImpl {{ins outs : Fin 2 → ℕ}} {{L : ℕ}} {{C : Type}} [Fintype C] [Nonempty C] (κ : ℕ)\n    (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)\n    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :\n    {AC}.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) := rfl\n"),
  ("ctlHybImplReader", False, f"open {G} in\ntheorem ctlHybImplReader {{ins outs : Fin 2 → ℕ}} {{L : ℕ}} {{C : Type}} [Fintype C] [Nonempty C]\n    (κ : ℕ) (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)\n    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :\n    {AC}.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) :=\n  {AC}.hybImpl_zero κ E sel x h\n")],
 f'{AC}.msgOf': [
  ("ctlMsgOf", True, f"theorem ctlMsgOf (m : ℕ) (β : Bool) (l : List Bool) :\n    {AC}.msgOf m β l = if β then l.drop m else l.take m := rfl\n"),
  ("ctlMsgOfReader", False, f"theorem ctlMsgOfReader (m : ℕ) (β : Bool) (l : List Bool) :\n    {AC}.msgOf m β l = if β then l.drop m else l.take m := {AC}.msgOf_eq m β l\n")],
 f'{AC}.acDin': [
  ("ctlAcDin", True, f"theorem ctlAcDin (S : {PK}) : {AC}.acDin S 0 = S.ctLen := rfl\n"),
  ("ctlAcDinReader", False, f"theorem ctlAcDinReader (S : {PK}) : {AC}.acDin S 0 = S.ctLen := {AC}.acDin_zero S\n")],
 f'{AC}.acHandler': [
  ("ctlAcHandler", True, f"theorem ctlAcHandler (S : {PK}) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :\n    ({AC}.acHandler S cap ist).perCall = .const 1 := rfl\n"),
  ("ctlAcHandlerReader", False, f"theorem ctlAcHandlerReader (S : {PK}) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :\n    ({AC}.acHandler S cap ist).perCall = .const 1 := {AC}.acHandler_perCall S cap ist\n")],
 f'{AC}.acEnc': [
  ("ctlAcEnc", True, f"theorem ctlAcEnc (S : {PK}) (n : ℕ) (pk : List Bool) (β : Bool)\n    (mm : Fin (({AC}.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :\n    {AC}.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n\n      (Turing.pairEncode pk ({AC}.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) := rfl\n"),
  ("ctlAcEncReader", False, f"theorem ctlAcEncReader (S : {PK}) (n : ℕ) (pk : List Bool) (β : Bool)\n    (mm : Fin (({AC}.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :\n    {AC}.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n\n      (Turing.pairEncode pk ({AC}.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) :=\n  {AC}.acEnc_eq S n pk β mm r\n")],
}
CP = 'TCSlib.Cryptography.Composability'
BW = CP + '.BitwiseSim'
OP = "open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in\n"
B.update({
 CP + '.padCt': [
  ("ctlPadCt", True, f"theorem ctlPadCt (L : ℕ) (c : List Bool) :\n    {CP}.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) := rfl\n"),
  ("ctlPadCtReader", False, f"theorem ctlPadCtReader (L : ℕ) (c : List Bool) :\n    {CP}.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) :=\n  {CP}.padCt_eq L c\n")],
 G + '.seedIn': [
  ("ctlSeedIn", True, f"theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl\n"),
  ("ctlSeedInReader", False, f"theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=\n  {G}.seedIn_eq n z ω\n")],
 'TCSlib.Cryptography.coinBlock': [
  ("ctlCoinBlock", True, "theorem ctlCoinBlock (B i : ℕ) (r : List Bool) :\n    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B := rfl\n"),
  ("ctlCoinBlockReader", False, "theorem ctlCoinBlockReader (B i : ℕ) (r : List Bool) :\n    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B :=\n  TCSlib.Cryptography.coinBlock_eq B i r\n")],
 'TCSlib.Cryptography.blockState': [
  ("ctlBlockState", True, "theorem ctlBlockState (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =\n    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) := rfl\n"),
  ("ctlBlockStateReader", False, "theorem ctlBlockStateReader (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =\n    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) :=\n  TCSlib.Cryptography.blockState_eq u pk m r\n")],
 'TCSlib.Cryptography.PublicKeyScheme.padded': [
  ("ctlPadded", True, OP + "theorem ctlPadded (S : PublicKeyScheme) (L : PolyExpr)\n    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),\n      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length\n        + 2 ≤ L.eval n)\n    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen := rfl\n"),
  ("ctlPaddedReader", False, OP + "theorem ctlPaddedReader (S : PublicKeyScheme) (L : PolyExpr)\n    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),\n      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length\n        + 2 ≤ L.eval n)\n    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen :=\n  PublicKeyScheme.padded_gen S L hL hmsg\n")],
 'TCSlib.Cryptography.BitPublicKeyScheme.bitwise': [
  ("ctlBitwise", True, "theorem ctlBitwise (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen := rfl\n"),
  ("ctlBitwiseReader", False, "theorem ctlBitwiseReader (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen :=\n  TCSlib.Cryptography.BitPublicKeyScheme.bitwise_gen S\n")],
 BW + '.qDin': [
  ("ctlQDin", True, f"theorem ctlQDin (Lc Lq : Complexity.PolyExpr) : {BW}.qDin Lc Lq 1 = Lq := rfl\n"),
  ("ctlQDinReader", False, f"theorem ctlQDinReader (Lc Lq : Complexity.PolyExpr) : {BW}.qDin Lc Lq 1 = Lq :=\n  {BW}.qDin_one Lc Lq\n")],
 BW + '.qHandler': [
  ("ctlQHandler", True, OP + f"theorem ctlQHandler (Lc Lq Ld Laux Lseed : PolyExpr) (aux : ℕ → List Bool)\n    (ans : List Bool → List Bool) (hans : PolyTimeComputable ans) (fin : List Bool → List Bool)\n    (hfin : PolyTimeComputable fin) :\n    ({BW}.qHandler Lc Lq Ld Laux Lseed aux ans hans fin hfin).seedLen = Lseed := rfl\n"),
  ("ctlQHandlerReader", False, OP + f"theorem ctlQHandlerReader (Lc Lq Ld Laux Lseed : PolyExpr) (aux : ℕ → List Bool)\n    (ans : List Bool → List Bool) (hans : PolyTimeComputable ans) (fin : List Bool → List Bool)\n    (hfin : PolyTimeComputable fin) :\n    ({BW}.qHandler Lc Lq Ld Laux Lseed aux ans hans fin hfin).seedLen = Lseed :=\n  {BW}.qHandler_seedLen Lc Lq Ld Laux Lseed aux ans hans fin hfin\n")],
 BW + '.plantAns': [
  ("ctlPlantAns", True, OP + f"theorem ctlPlantAns (Enc : NUPPT) (L : PolyExpr) (w : List Bool) :\n    {BW}.plantAns Enc L w =\n      {CP}.padCt (L.eval (pairFstD (pairFstD w)).length) ({BW}.plantTuple Enc w) := rfl\n"),
  ("ctlPlantAnsReader", False, OP + f"theorem ctlPlantAnsReader (Enc : NUPPT) (L : PolyExpr) (w : List Bool) :\n    {BW}.plantAns Enc L w =\n      {CP}.padCt (L.eval (pairFstD (pairFstD w)).length) ({BW}.plantTuple Enc w) :=\n  {BW}.plantAns_eq Enc L w\n")],
})
B.update({
 'TCSlib.Cryptography.Composability.FixedLengthScheme.inLens': [
  ("ctlInLens", True, "theorem ctlInLens (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :\n    S.inLens n 2 = n + n := rfl\n"),
  ("ctlInLensReader", False, "theorem ctlInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :\n    S.inLens n 2 = n + n := S.inLens_two n\n")],
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer': [
  ("ctlDecAnswer", True, "theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m := rfl\n"),
  ("ctlDecAnswerReader", False, "theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m\n")],

 'TCSlib.Cryptography.prfScheme': [
  ("ctlPrfSchemeDec", True, "theorem ctlPrfSchemeDec (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))\n    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)\n    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =\n      List.ofFn (F n s x)) :\n    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform\n      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) := rfl\n"),
  ("ctlPrfSchemeDecReader", False, "theorem ctlPrfSchemeDecReader (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))\n    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)\n    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =\n      List.ofFn (F n s x)) :\n    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform\n      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) :=\n  TCSlib.Cryptography.prfScheme_dec F E hE hFE\n")],
})
B.update({
 'TCSlib.Cryptography.Composability.PRFGame.ctOf': [
  ('ctlCtOf', True, 'theorem ctlCtOf {n : ℕ} (r : Fin n → Bool) (m : List Bool) (y : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.ctOf r m y = Turing.pairEncode (List.ofFn r) (List.zipWith xor m (List.ofFn y)) := rfl\n'),
  ('ctlCtOfReader', False, 'theorem ctlCtOfReader {n : ℕ} (r : Fin n → Bool) (m : List Bool) (y : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.ctOf r m y = Turing.pairEncode (List.ofFn r) (List.zipWith xor m (List.ofFn y)) :=\n  TCSlib.Cryptography.Composability.PRFGame.ctOf_eq r m y\n')],
 'TCSlib.Cryptography.Composability.PRFGame.decWF': [
  ('ctlDecWF', True, 'theorem ctlDecWF (n : ℕ) (w : List Bool) : TCSlib.Cryptography.Composability.PRFGame.decWF n w =\n    (decide ((Complexity.pairFstD w).length = n) && decide ((Complexity.pairSndD w).length = n)) := rfl\n'),
  ('ctlDecWFReader', False, 'theorem ctlDecWFReader (n : ℕ) (w : List Bool) : TCSlib.Cryptography.Composability.PRFGame.decWF n w =\n    (decide ((Complexity.pairFstD w).length = n) && decide ((Complexity.pairSndD w).length = n)) :=\n  TCSlib.Cryptography.Composability.PRFGame.decWF_eq n w\n')],
 'TCSlib.Cryptography.Composability.PRFGame.fImpl': [
  ('ctlFImpl', True, 'open TCSlib.Cryptography.Games in\ntheorem ctlFImpl (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)\n    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (mm : Fin (ins 2) → Bool) (c : Fin d → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.fImpl ins outs d n atk b f 2 mm (some c) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), some c) := rfl\n'),
  ('ctlFImplReader', False, 'open TCSlib.Cryptography.Games in\ntheorem ctlFImplReader (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)\n    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (mm : Fin (ins 2) → Bool) (c : Fin d → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.fImpl ins outs d n atk b f 2 mm (some c) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), some c) :=\n  TCSlib.Cryptography.Composability.PRFGame.fImpl_challenge_some ins outs d n atk b f mm c\n')],
 'TCSlib.Cryptography.Composability.PRFGame.eImpl': [
  ('ctlEImpl', True, 'open TCSlib.Cryptography.Games in\ntheorem ctlEImpl (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)\n    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (T : ℕ → Fin n → Bool) (mm : Fin (ins 2) → Bool)\n    (j : ℕ) (c : Fin d → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.eImpl ins outs d n atk b f T 2 mm (j, some c) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (j, some c)) := rfl\n'),
  ('ctlEImplReader', False, 'open TCSlib.Cryptography.Games in\ntheorem ctlEImplReader (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)\n    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (T : ℕ → Fin n → Bool) (mm : Fin (ins 2) → Bool)\n    (j : ℕ) (c : Fin d → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.eImpl ins outs d n atk b f T 2 mm (j, some c) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (j, some c)) :=\n  TCSlib.Cryptography.Composability.PRFGame.eImpl_challenge_some ins outs d n atk b f T mm j c\n')],
 'TCSlib.Cryptography.Composability.PRFGame.pkDin': [
  ('ctlPkDin', True, 'theorem ctlPkDin : TCSlib.Cryptography.Composability.PRFGame.pkDin 0 = .var := rfl\n'),
  ('ctlPkDinReader', False, 'theorem ctlPkDinReader : TCSlib.Cryptography.Composability.PRFGame.pkDin 0 = .var :=\n  TCSlib.Cryptography.Composability.PRFGame.pkDin_zero\n')],
 'TCSlib.Cryptography.Composability.PRFGame.pkHandler': [
  ('ctlPkHandler', True, 'theorem ctlPkHandler (q : Complexity.PolyExpr) (atkBit b : Bool) :\n    (TCSlib.Cryptography.Composability.PRFGame.pkHandler q atkBit b).perCall = .const 1 := rfl\n'),
  ('ctlPkHandlerReader', False, 'theorem ctlPkHandlerReader (q : Complexity.PolyExpr) (atkBit b : Bool) :\n    (TCSlib.Cryptography.Composability.PRFGame.pkHandler q atkBit b).perCall = .const 1 :=\n  TCSlib.Cryptography.Composability.PRFGame.pkHandler_perCall q atkBit b\n')],
 'TCSlib.Cryptography.Composability.PRFGame.recBits': [
  ('ctlRecBits', True, 'theorem ctlRecBits (n : ℕ) :\n    TCSlib.Cryptography.Composability.PRFGame.recBits n none = false :: List.replicate (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) false := rfl\n'),
  ('ctlRecBitsReader', False, 'theorem ctlRecBitsReader (n : ℕ) :\n    TCSlib.Cryptography.Composability.PRFGame.recBits n none = false :: List.replicate (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) false :=\n  TCSlib.Cryptography.Composability.PRFGame.recBits_none n\n')],
 'TCSlib.Cryptography.Composability.PRFGame.pkState': [
  ('ctlPkState', True, 'theorem ctlPkState (q : Complexity.PolyExpr) (n j : ℕ) (o : Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :\n    TCSlib.Cryptography.Composability.PRFGame.pkState q n j o =\n      TCSlib.Cryptography.padFin _ (Turing.pairEncode (List.replicate j true) (TCSlib.Cryptography.Composability.PRFGame.recBits n o)) := rfl\n'),
  ('ctlPkStateReader', False, 'theorem ctlPkStateReader (q : Complexity.PolyExpr) (n j : ℕ) (o : Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :\n    TCSlib.Cryptography.Composability.PRFGame.pkState q n j o =\n      TCSlib.Cryptography.padFin _ (Turing.pairEncode (List.replicate j true) (TCSlib.Cryptography.Composability.PRFGame.recBits n o)) :=\n  TCSlib.Cryptography.Composability.PRFGame.pkState_eq q n j o\n')],
 'TCSlib.Cryptography.Composability.PRFGame.atkOf': [
  ('ctlAtkOf', True, 'theorem ctlAtkOf : TCSlib.Cryptography.Composability.PRFGame.atkOf false = .cpa := rfl\n'),
  ('ctlAtkOfReader', False, 'theorem ctlAtkOfReader : TCSlib.Cryptography.Composability.PRFGame.atkOf false = .cpa :=\n  TCSlib.Cryptography.Composability.PRFGame.atkOf_false\n')],
 'TCSlib.Cryptography.Composability.PRFGame.qRed': [
  ('ctlQRed', True, 'theorem ctlQRed (q : Complexity.PolyExpr) (n : ℕ) : (TCSlib.Cryptography.Composability.PRFGame.qRed q).eval n =\n    q.eval n * (Complexity.PolyExpr.const 1).eval n + (Complexity.PolyExpr.const 0).eval n := rfl\n'),
  ('ctlQRedReader', False, 'theorem ctlQRedReader (q : Complexity.PolyExpr) (n : ℕ) : (TCSlib.Cryptography.Composability.PRFGame.qRed q).eval n =\n    q.eval n * (Complexity.PolyExpr.const 1).eval n + (Complexity.PolyExpr.const 0).eval n :=\n  TCSlib.Cryptography.Composability.PRFGame.qRed_eval q n\n')],
 'TCSlib.Cryptography.Composability.PRFGame.pkAbs': [
  ('ctlPkAbs', True, 'theorem ctlPkAbs (q : Complexity.PolyExpr) (atkBit b : Bool) (n : ℕ)\n    (s : ℕ × Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :\n    TCSlib.Cryptography.Composability.PRFGame.pkAbs q atkBit b n s = (TCSlib.Cryptography.Composability.PRFGame.pkHState q atkBit b n s.1 s.2, ()) := rfl\n'),
  ('ctlPkAbsReader', False, 'theorem ctlPkAbsReader (q : Complexity.PolyExpr) (atkBit b : Bool) (n : ℕ)\n    (s : ℕ × Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :\n    TCSlib.Cryptography.Composability.PRFGame.pkAbs q atkBit b n s = (TCSlib.Cryptography.Composability.PRFGame.pkHState q atkBit b n s.1 s.2, ()) :=\n  TCSlib.Cryptography.Composability.PRFGame.pkAbs_eq q atkBit b n s\n')],
 'TCSlib.Cryptography.Composability.PRFGame.rStar': [
  ('ctlRStar', True, 'theorem ctlRStar {n d : ℕ} (c : Fin d → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.rStar (n := n) c = TCSlib.Cryptography.padFin n (Complexity.pairFstD (List.ofFn c)) := rfl\n'),
  ('ctlRStarReader', False, 'theorem ctlRStarReader {n d : ℕ} (c : Fin d → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.rStar (n := n) c = TCSlib.Cryptography.padFin n (Complexity.pairFstD (List.ofFn c)) :=\n  TCSlib.Cryptography.Composability.PRFGame.rStar_eq c\n')],
 'TCSlib.Cryptography.Composability.PRFGame.look': [
  ('ctlLook', True, 'theorem ctlLook {n d : ℕ} (b : Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)\n    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.look b ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = T.lookup x := rfl\n'),
  ('ctlLookReader', False, 'theorem ctlLookReader {n d : ℕ} (b : Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)\n    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.look b ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = T.lookup x :=\n  TCSlib.Cryptography.Composability.PRFGame.look_none b T bd x\n')],
 'TCSlib.Cryptography.Composability.PRFGame.ovr': [
  ('ctlOvr', True, 'theorem ctlOvr {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (R : (Fin n → Bool) → (Fin n → Bool))\n    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.ovr b st R x = (TCSlib.Cryptography.Composability.PRFGame.look b st x).getD (R x) := rfl\n'),
  ('ctlOvrReader', False, 'theorem ctlOvrReader {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (R : (Fin n → Bool) → (Fin n → Bool))\n    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.ovr b st R x = (TCSlib.Cryptography.Composability.PRFGame.look b st x).getD (R x) :=\n  TCSlib.Cryptography.Composability.PRFGame.ovr_apply b st R x\n')],
 'TCSlib.Cryptography.Composability.PRFGame.addPt': [
  ('ctlAddPt', True, 'theorem ctlAddPt {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (x y : Fin n → Bool) (hit : Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.addPt b st x y hit =\n      (if (TCSlib.Cryptography.Composability.PRFGame.look b st x).isSome then st.1 else (x, y) :: st.1, st.2.1, st.2.2 || hit) := rfl\n'),
  ('ctlAddPtReader', False, 'theorem ctlAddPtReader {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (x y : Fin n → Bool) (hit : Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.addPt b st x y hit =\n      (if (TCSlib.Cryptography.Composability.PRFGame.look b st x).isSome then st.1 else (x, y) :: st.1, st.2.1, st.2.2 || hit) :=\n  TCSlib.Cryptography.Composability.PRFGame.addPt_eq b st x y hit\n')],
 'TCSlib.Cryptography.Composability.PRFGame.hitStar': [
  ('ctlHitStar', True, 'theorem ctlHitStar {n d : ℕ} (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)\n    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.hitStar ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = false := rfl\n'),
  ('ctlHitStarReader', False, 'theorem ctlHitStarReader {n d : ℕ} (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)\n    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.hitStar ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = false :=\n  TCSlib.Cryptography.Composability.PRFGame.hitStar_none T bd x\n')],
 'TCSlib.Cryptography.Composability.PRFGame.lazyImpl': [
  ('ctlLazyImpl', True, 'open TCSlib.Cryptography.Games in\ntheorem ctlLazyImpl (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)\n    (b : Bool) (mm : Fin (ins 2) → Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (ml : List Bool)\n    (c : Fin d → Bool) (bd : Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.lazyImpl ins outs d n atk b 2 mm (T, some (ml, c), bd) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (T, some (ml, c), bd)) := rfl\n'),
  ('ctlLazyImplReader', False, 'open TCSlib.Cryptography.Games in\ntheorem ctlLazyImplReader (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)\n    (b : Bool) (mm : Fin (ins 2) → Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (ml : List Bool)\n    (c : Fin d → Bool) (bd : Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.lazyImpl ins outs d n atk b 2 mm (T, some (ml, c), bd) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (T, some (ml, c), bd)) :=\n  TCSlib.Cryptography.Composability.PRFGame.lazyImpl_challenge_some ins outs d n atk b mm T ml c bd\n')],
 'TCSlib.Cryptography.Composability.PRFGame.xorPerm': [
  ('ctlXorPerm', True, 'theorem ctlXorPerm {n : ℕ} (v y : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.xorPerm v y = fun i => xor (y i) (v i) := rfl\n'),
  ('ctlXorPermReader', False, 'theorem ctlXorPermReader {n : ℕ} (v y : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.PRFGame.xorPerm v y = fun i => xor (y i) (v i) :=\n  TCSlib.Cryptography.Composability.PRFGame.xorPerm_apply v y\n')],
 'TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl': [
  ('ctlIndImpl', True, 'open TCSlib.Cryptography.Games in\ntheorem ctlIndImpl (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)\n    (k : List Bool) (mm : (S.indSpec n).dom 2) (c : Fin (S.ctLen.eval n) → Bool) :\n    S.indImpl atk b n k 2 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) := rfl\n'),
  ('ctlIndImplReader', False, 'open TCSlib.Cryptography.Games in\ntheorem ctlIndImplReader (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)\n    (k : List Bool) (mm : (S.indSpec n).dom 2) (c : Fin (S.ctLen.eval n) → Bool) :\n    S.indImpl atk b n k 2 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) :=\n  S.indImpl_challenge_repeat_onSpec atk b n k mm c\n')],
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen': [
  ('ctlDecOpen', True, 'theorem ctlDecOpen (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false := rfl\n'),
  ('ctlDecOpenReader', False, 'theorem ctlDecOpenReader (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen_cpa c\n')],
})
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace PkControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end PkControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
for rec_path in sorted(Path(sealdir).glob('Seal_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][5:]
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
