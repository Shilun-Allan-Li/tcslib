import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace PkControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

theorem ctlChRun {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := rfl

theorem ctlChRunReader {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := TCSlib.Cryptography.Composability.ChallengeSim.chRun_pure g a s

theorem ctlRecAdvIn (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl

theorem ctlRecAdvInReader (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn_eq c

open TCSlib.Cryptography.Games in
theorem ctlSimulate {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl

open TCSlib.Cryptography.Games in
theorem ctlSimulateReader {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := TCSlib.Cryptography.Games.simulate_pure impl a s

theorem ctlPkInLens (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl

theorem ctlPkInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=
  S.inLens_zero n

open TCSlib.Cryptography.Games in
theorem ctlCastImpl {k : ℕ} {σ : Type} {ins ins' outs outs' : Fin k → ℕ}
    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.castImpl (ins := ins) (outs := outs) O i x s =
      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>
        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) := rfl

open TCSlib.Cryptography.Games in
theorem ctlCastImplReader {k : ℕ} {σ : Type} {ins ins' outs outs' : Fin k → ℕ}
    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.castImpl (ins := ins) (outs := outs) O i x s =
      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>
        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) :=
  TCSlib.Cryptography.Composability.AdaptiveCPA.castImpl_eq O i x s

open TCSlib.Cryptography.Games in
theorem ctlHybImpl {ins outs : Fin 2 → ℕ} {L : ℕ} {C : Type} [Fintype C] [Nonempty C] (κ : ℕ)
    (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)
    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) := rfl

open TCSlib.Cryptography.Games in
theorem ctlHybImplReader {ins outs : Fin 2 → ℕ} {L : ℕ} {C : Type} [Fintype C] [Nonempty C]
    (κ : ℕ) (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)
    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) :=
  TCSlib.Cryptography.Composability.AdaptiveCPA.hybImpl_zero κ E sel x h

theorem ctlMsgOf (m : ℕ) (β : Bool) (l : List Bool) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf m β l = if β then l.drop m else l.take m := rfl

theorem ctlMsgOfReader (m : ℕ) (β : Bool) (l : List Bool) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf m β l = if β then l.drop m else l.take m := TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf_eq m β l

theorem ctlAcDin (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) : TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 0 = S.ctLen := rfl

theorem ctlAcDinReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) : TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 0 = S.ctLen := TCSlib.Cryptography.Composability.AdaptiveCPA.acDin_zero S

theorem ctlAcHandler (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :
    (TCSlib.Cryptography.Composability.AdaptiveCPA.acHandler S cap ist).perCall = .const 1 := rfl

theorem ctlAcHandlerReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :
    (TCSlib.Cryptography.Composability.AdaptiveCPA.acHandler S cap ist).perCall = .const 1 := TCSlib.Cryptography.Composability.AdaptiveCPA.acHandler_perCall S cap ist

theorem ctlAcEnc (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) (pk : List Bool) (β : Bool)
    (mm : Fin ((TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n
      (Turing.pairEncode pk (TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) := rfl

theorem ctlAcEncReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) (pk : List Bool) (β : Bool)
    (mm : Fin ((TCSlib.Cryptography.Composability.AdaptiveCPA.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :
    TCSlib.Cryptography.Composability.AdaptiveCPA.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n
      (Turing.pairEncode pk (TCSlib.Cryptography.Composability.AdaptiveCPA.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) :=
  TCSlib.Cryptography.Composability.AdaptiveCPA.acEnc_eq S n pk β mm r

theorem ctlPadCt (L : ℕ) (c : List Bool) :
    TCSlib.Cryptography.Composability.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) := rfl

theorem ctlPadCtReader (L : ℕ) (c : List Bool) :
    TCSlib.Cryptography.Composability.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) :=
  TCSlib.Cryptography.Composability.padCt_eq L c

theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl

theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=
  TCSlib.Cryptography.Games.seedIn_eq n z ω

theorem ctlCoinBlock (B i : ℕ) (r : List Bool) :
    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B := rfl

theorem ctlCoinBlockReader (B i : ℕ) (r : List Bool) :
    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B :=
  TCSlib.Cryptography.coinBlock_eq B i r

theorem ctlBlockState (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =
    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) := rfl

theorem ctlBlockStateReader (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =
    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) :=
  TCSlib.Cryptography.blockState_eq u pk m r

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in
theorem ctlPadded (S : PublicKeyScheme) (L : PolyExpr)
    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),
      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length
        + 2 ≤ L.eval n)
    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen := rfl

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in
theorem ctlPaddedReader (S : PublicKeyScheme) (L : PolyExpr)
    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),
      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length
        + 2 ≤ L.eval n)
    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen :=
  PublicKeyScheme.padded_gen S L hL hmsg

theorem ctlBitwise (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen := rfl

theorem ctlBitwiseReader (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen :=
  TCSlib.Cryptography.BitPublicKeyScheme.bitwise_gen S

theorem ctlInLens (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :
    S.inLens n 2 = n + n := rfl

theorem ctlInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (n : ℕ) :
    S.inLens n 2 = n + n := S.inLens_two n

theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :
    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =
      Fin.cons (α := fun _ => Bool) true m := rfl

theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :
    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =
      Fin.cons (α := fun _ => Bool) true m :=
  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m

theorem ctlPrfSchemeDec (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)
    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (F n s x)) :
    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform
      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) := rfl

theorem ctlPrfSchemeDecReader (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
    (E : List Bool → List Bool) (hE : Complexity.PolyTimeComputable E)
    (hFE : ∀ n (s x : Fin n → Bool), E (Turing.pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (F n s x)) :
    (TCSlib.Cryptography.prfScheme F E hE hFE).dec = Complexity.NUPPT.ofPolyTimeUniform
      (TCSlib.Cryptography.polyTimeComputable_prfDecFun hE) (.const 0) :=
  TCSlib.Cryptography.prfScheme_dec F E hE hFE

theorem ctlCtOf {n : ℕ} (r : Fin n → Bool) (m : List Bool) (y : Fin n → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.ctOf r m y = Turing.pairEncode (List.ofFn r) (List.zipWith xor m (List.ofFn y)) := rfl

theorem ctlCtOfReader {n : ℕ} (r : Fin n → Bool) (m : List Bool) (y : Fin n → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.ctOf r m y = Turing.pairEncode (List.ofFn r) (List.zipWith xor m (List.ofFn y)) :=
  TCSlib.Cryptography.Composability.PRFGame.ctOf_eq r m y

theorem ctlDecWF (n : ℕ) (w : List Bool) : TCSlib.Cryptography.Composability.PRFGame.decWF n w =
    (decide ((Complexity.pairFstD w).length = n) && decide ((Complexity.pairSndD w).length = n)) := rfl

theorem ctlDecWFReader (n : ℕ) (w : List Bool) : TCSlib.Cryptography.Composability.PRFGame.decWF n w =
    (decide ((Complexity.pairFstD w).length = n) && decide ((Complexity.pairSndD w).length = n)) :=
  TCSlib.Cryptography.Composability.PRFGame.decWF_eq n w

open TCSlib.Cryptography.Games in
theorem ctlFImpl (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)
    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (mm : Fin (ins 2) → Bool) (c : Fin d → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.fImpl ins outs d n atk b f 2 mm (some c) =
      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), some c) := rfl

open TCSlib.Cryptography.Games in
theorem ctlFImplReader (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)
    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (mm : Fin (ins 2) → Bool) (c : Fin d → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.fImpl ins outs d n atk b f 2 mm (some c) =
      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), some c) :=
  TCSlib.Cryptography.Composability.PRFGame.fImpl_challenge_some ins outs d n atk b f mm c

open TCSlib.Cryptography.Games in
theorem ctlEImpl (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)
    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (T : ℕ → Fin n → Bool) (mm : Fin (ins 2) → Bool)
    (j : ℕ) (c : Fin d → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.eImpl ins outs d n atk b f T 2 mm (j, some c) =
      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (j, some c)) := rfl

open TCSlib.Cryptography.Games in
theorem ctlEImplReader (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)
    (b : Bool) (f : (Fin n → Bool) → (Fin n → Bool)) (T : ℕ → Fin n → Bool) (mm : Fin (ins 2) → Bool)
    (j : ℕ) (c : Fin d → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.eImpl ins outs d n atk b f T 2 mm (j, some c) =
      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (j, some c)) :=
  TCSlib.Cryptography.Composability.PRFGame.eImpl_challenge_some ins outs d n atk b f T mm j c

theorem ctlPkDin : TCSlib.Cryptography.Composability.PRFGame.pkDin 0 = .var := rfl

theorem ctlPkDinReader : TCSlib.Cryptography.Composability.PRFGame.pkDin 0 = .var :=
  TCSlib.Cryptography.Composability.PRFGame.pkDin_zero

theorem ctlPkHandler (q : Complexity.PolyExpr) (atkBit b : Bool) :
    (TCSlib.Cryptography.Composability.PRFGame.pkHandler q atkBit b).perCall = .const 1 := rfl

theorem ctlPkHandlerReader (q : Complexity.PolyExpr) (atkBit b : Bool) :
    (TCSlib.Cryptography.Composability.PRFGame.pkHandler q atkBit b).perCall = .const 1 :=
  TCSlib.Cryptography.Composability.PRFGame.pkHandler_perCall q atkBit b

theorem ctlRecBits (n : ℕ) :
    TCSlib.Cryptography.Composability.PRFGame.recBits n none = false :: List.replicate (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) false := rfl

theorem ctlRecBitsReader (n : ℕ) :
    TCSlib.Cryptography.Composability.PRFGame.recBits n none = false :: List.replicate (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) false :=
  TCSlib.Cryptography.Composability.PRFGame.recBits_none n

theorem ctlPkState (q : Complexity.PolyExpr) (n j : ℕ) (o : Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :
    TCSlib.Cryptography.Composability.PRFGame.pkState q n j o =
      TCSlib.Cryptography.padFin _ (Turing.pairEncode (List.replicate j true) (TCSlib.Cryptography.Composability.PRFGame.recBits n o)) := rfl

theorem ctlPkStateReader (q : Complexity.PolyExpr) (n j : ℕ) (o : Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :
    TCSlib.Cryptography.Composability.PRFGame.pkState q n j o =
      TCSlib.Cryptography.padFin _ (Turing.pairEncode (List.replicate j true) (TCSlib.Cryptography.Composability.PRFGame.recBits n o)) :=
  TCSlib.Cryptography.Composability.PRFGame.pkState_eq q n j o

theorem ctlAtkOf : TCSlib.Cryptography.Composability.PRFGame.atkOf false = .cpa := rfl

theorem ctlAtkOfReader : TCSlib.Cryptography.Composability.PRFGame.atkOf false = .cpa :=
  TCSlib.Cryptography.Composability.PRFGame.atkOf_false

theorem ctlQRed (q : Complexity.PolyExpr) (n : ℕ) : (TCSlib.Cryptography.Composability.PRFGame.qRed q).eval n =
    q.eval n * (Complexity.PolyExpr.const 1).eval n + (Complexity.PolyExpr.const 0).eval n := rfl

theorem ctlQRedReader (q : Complexity.PolyExpr) (n : ℕ) : (TCSlib.Cryptography.Composability.PRFGame.qRed q).eval n =
    q.eval n * (Complexity.PolyExpr.const 1).eval n + (Complexity.PolyExpr.const 0).eval n :=
  TCSlib.Cryptography.Composability.PRFGame.qRed_eval q n

theorem ctlPkAbs (q : Complexity.PolyExpr) (atkBit b : Bool) (n : ℕ)
    (s : ℕ × Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :
    TCSlib.Cryptography.Composability.PRFGame.pkAbs q atkBit b n s = (TCSlib.Cryptography.Composability.PRFGame.pkHState q atkBit b n s.1 s.2, ()) := rfl

theorem ctlPkAbsReader (q : Complexity.PolyExpr) (atkBit b : Bool) (n : ℕ)
    (s : ℕ × Option (Fin (TCSlib.Cryptography.Composability.PRFGame.ctP.eval n) → Bool)) :
    TCSlib.Cryptography.Composability.PRFGame.pkAbs q atkBit b n s = (TCSlib.Cryptography.Composability.PRFGame.pkHState q atkBit b n s.1 s.2, ()) :=
  TCSlib.Cryptography.Composability.PRFGame.pkAbs_eq q atkBit b n s

theorem ctlRStar {n d : ℕ} (c : Fin d → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.rStar (n := n) c = TCSlib.Cryptography.padFin n (Complexity.pairFstD (List.ofFn c)) := rfl

theorem ctlRStarReader {n d : ℕ} (c : Fin d → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.rStar (n := n) c = TCSlib.Cryptography.padFin n (Complexity.pairFstD (List.ofFn c)) :=
  TCSlib.Cryptography.Composability.PRFGame.rStar_eq c

theorem ctlLook {n d : ℕ} (b : Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)
    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.look b ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = T.lookup x := rfl

theorem ctlLookReader {n d : ℕ} (b : Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)
    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.look b ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = T.lookup x :=
  TCSlib.Cryptography.Composability.PRFGame.look_none b T bd x

theorem ctlOvr {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (R : (Fin n → Bool) → (Fin n → Bool))
    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.ovr b st R x = (TCSlib.Cryptography.Composability.PRFGame.look b st x).getD (R x) := rfl

theorem ctlOvrReader {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (R : (Fin n → Bool) → (Fin n → Bool))
    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.ovr b st R x = (TCSlib.Cryptography.Composability.PRFGame.look b st x).getD (R x) :=
  TCSlib.Cryptography.Composability.PRFGame.ovr_apply b st R x

theorem ctlAddPt {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (x y : Fin n → Bool) (hit : Bool) :
    TCSlib.Cryptography.Composability.PRFGame.addPt b st x y hit =
      (if (TCSlib.Cryptography.Composability.PRFGame.look b st x).isSome then st.1 else (x, y) :: st.1, st.2.1, st.2.2 || hit) := rfl

theorem ctlAddPtReader {n d : ℕ} (b : Bool) (st : TCSlib.Cryptography.Composability.PRFGame.LState n d) (x y : Fin n → Bool) (hit : Bool) :
    TCSlib.Cryptography.Composability.PRFGame.addPt b st x y hit =
      (if (TCSlib.Cryptography.Composability.PRFGame.look b st x).isSome then st.1 else (x, y) :: st.1, st.2.1, st.2.2 || hit) :=
  TCSlib.Cryptography.Composability.PRFGame.addPt_eq b st x y hit

theorem ctlHitStar {n d : ℕ} (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)
    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.hitStar ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = false := rfl

theorem ctlHitStarReader {n d : ℕ} (T : List ((Fin n → Bool) × (Fin n → Bool))) (bd : Bool)
    (x : Fin n → Bool) : TCSlib.Cryptography.Composability.PRFGame.hitStar ((T, none, bd) : TCSlib.Cryptography.Composability.PRFGame.LState n d) x = false :=
  TCSlib.Cryptography.Composability.PRFGame.hitStar_none T bd x

open TCSlib.Cryptography.Games in
theorem ctlLazyImpl (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)
    (b : Bool) (mm : Fin (ins 2) → Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (ml : List Bool)
    (c : Fin d → Bool) (bd : Bool) :
    TCSlib.Cryptography.Composability.PRFGame.lazyImpl ins outs d n atk b 2 mm (T, some (ml, c), bd) =
      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (T, some (ml, c), bd)) := rfl

open TCSlib.Cryptography.Games in
theorem ctlLazyImplReader (ins outs : Fin 3 → ℕ) (d n : ℕ) (atk : TCSlib.Cryptography.Composability.Attack)
    (b : Bool) (mm : Fin (ins 2) → Bool) (T : List ((Fin n → Bool) × (Fin n → Bool))) (ml : List Bool)
    (c : Fin d → Bool) (bd : Bool) :
    TCSlib.Cryptography.Composability.PRFGame.lazyImpl ins outs d n atk b 2 mm (T, some (ml, c), bd) =
      .pure (TCSlib.Cryptography.padFin _ (List.ofFn c), (T, some (ml, c), bd)) :=
  TCSlib.Cryptography.Composability.PRFGame.lazyImpl_challenge_some ins outs d n atk b mm T ml c bd

theorem ctlXorPerm {n : ℕ} (v y : Fin n → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.xorPerm v y = fun i => xor (y i) (v i) := rfl

theorem ctlXorPermReader {n : ℕ} (v y : Fin n → Bool) :
    TCSlib.Cryptography.Composability.PRFGame.xorPerm v y = fun i => xor (y i) (v i) :=
  TCSlib.Cryptography.Composability.PRFGame.xorPerm_apply v y

open TCSlib.Cryptography.Games in
theorem ctlIndImpl (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)
    (k : List Bool) (mm : (S.indSpec n).dom 2) (c : Fin (S.ctLen.eval n) → Bool) :
    S.indImpl atk b n k 2 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) := rfl

open TCSlib.Cryptography.Games in
theorem ctlIndImplReader (S : TCSlib.Cryptography.Composability.FixedLengthScheme) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)
    (k : List Bool) (mm : (S.indSpec n).dom 2) (c : Fin (S.ctLen.eval n) → Bool) :
    S.indImpl atk b n k 2 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) :=
  S.indImpl_challenge_repeat_onSpec atk b n k mm c

theorem ctlDecOpen (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false := rfl

theorem ctlDecOpenReader (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false :=
  TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen_cpa c

end PkControls

