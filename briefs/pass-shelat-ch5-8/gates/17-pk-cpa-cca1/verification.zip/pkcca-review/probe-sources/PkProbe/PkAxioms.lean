import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

/-! pk-cpa-cca1 review: axioms of the two targets and of the CCA2 claim and corollary (explicit
`#print axioms`), and of every stored constant of the eight touched modules (collectAxioms). -/

set_option maxHeartbeats 0

#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let owners : List Name := [`TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Games,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Handler,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Reduction,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Transfer,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Lazy,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF.Collision,
    `TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF]
  let mut n := 0
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"AX {home} {c} {axs.toList}"
    n := n + 1
  IO.println s!"AX-COUNT {n}"
