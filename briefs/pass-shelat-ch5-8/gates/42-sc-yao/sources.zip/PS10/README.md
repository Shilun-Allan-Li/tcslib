# PS10 §6.2 (Yao circuit evaluation): the source excerpt for Gate 42

[PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 2010: the PDF committed as `Pass–Shelat.pdf` at the
root of the records branch, blob `695a6b18d3e4c3fd9a7cacfc45b301c94b8c24b3` at the records pin `f22e0f6798815b9263893e61928b4f16452f74ee` (SHA-256 `7624556077a7a272ba0b3ddb7cd47b96574fb0b4b4947a25467d1f91bb61bda8`, 1771458 bytes, 204
pages). Book page = PDF page − 12.

- `ps10-6.2-book-pp154-164.pdf`: PDF pages 166–176 (book pages 154–164), extracted with pypdf 6.17.0 (`PdfWriter`,
  the pages unchanged; byte-deterministic). SHA-256 `97b26aed80b62d2dd77373665632c13503de12f7ec2f62e830cfdd9ad6530604`.
- `ps10-6.2-book-pp154-164.txt`: the same pages as text, `pdftotext -layout -f 166 -l 176` (pdftotext version 24.02.0), pages separated by
  form feeds; mathematics and figures are garbled in places, so read the PDF where they matter. SHA-256 `4c2f90ca0e764383282bacf1e4c35f0f577e16277a5df79e48111947605b76ab`.

This is a mechanical extraction for convenience, not a curated transcription: `blueprint/src/references/` at the pin has
PS10 transcriptions only for chapters 2–4 and the appendix (`pass-shelat-2010-ch{2,3,4}.raw.md`,
`pass-shelat-2010-appendix.raw.md`), and `sources.json` registers no PS10 tag. The PDF is authoritative.

The labels "Claim 157.a", "Construction 158.a" and "Claim 159.a" are the campaign inventory's names for unnumbered text
(`briefs/pass-shelat-ch5-8/inventory-ch5-8.md`; the secure-computation plan, §0). Book pages of the cited items:

| Item | Book pages | Its label or heading found on (text) |
|---|---|---|
| Definition 155.1 (two-party honest-but-curious secure protocol) | 155–156 | 155 |
| §6.2.1 Circuit Representations (fan-in two) | 156 | 156 |
| §6.2.2 Garbled Wires; Algorithm 157.2 (special encryption); the unnumbered wrong-key property, inventory "Claim 157.a" | 157 | 157 |
| §6.2.3 Garbled Gates: the permuted doubly-encrypted tables, inventory "Construction 158.a"; one row decrypts, inventory "Claim 159.a"; Figure 159.3 | 157–159 | 157 |
| §6.2.4 Oblivious Transfer; Protocol 160.4; Proposition 161.5 | 160–162 | 161 |
| §6.2.5; Protocol 162.6 (honest-but-curious secure computation) | 162–163 | 162, 163 |
| Theorem 163.7 and its proof (the simulators S_A, S_B; "using a hybrid argument") | 163–164 | 163 |
