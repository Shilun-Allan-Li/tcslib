# sources-r2.zip · Gate 42 round 2

Round 1's sources.zip (records briefs/pass-shelat-ch5-8/gates/42-sc-yao/sources.zip, SHA-256 105be989cda0f946c79d2f0e0241e659a4701aff25813722736a674f25c22d91) holds the source closure of every
changed module at the round-1 head e9b03c437aca251846430ff23b40ee5ff3d3347a (262 files under TCSlib/) and PS10/ ([PS10] §6.2, book pages 154-164).

At the round-2 head 355a0288d56290e8c984228cbc1824187029e456 the closure has the same 262 paths (no import line of the 70 PR files changed). 253 of them
are byte-identical to round 1's members. The other 9 are exactly the files of the round-1 -> round-2 diff, and this ZIP
holds them at 355a0288 under TCSlib/:

- TCSlib/Cryptography/SecureComputation/Yao.lean (sha256 a4d1a963b5dd2010c40fd67fbed6a45e905331806cbadbc389f93cb72887dca2)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/BobIO.lean (sha256 baf7071fab2361420cd2a0f8df44ecb1375f92a64e74c68df480b5b8ac30111f)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/ChunkScanner.lean (sha256 23067e359b478b3de1e5c0093c165fbd03a1180be782e52f0cb9f9a212bcd207)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/FakeProgram.lean (sha256 35bd4a952055423861eac0179ba5d4aa4b2075f72cdb03921b56db29aa3e7207)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/FakeSimulatorFactory.lean (sha256 3dd8cd4050bdcdc1185c8365ecc530376253687958be4f87405e527b11d7e1ec)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/GarblingProgram.lean (sha256 f77f00c2469b986f621339a318f2814526fe10000c1715a12b893bfc4057c2f8)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/RunWithHost.lean (sha256 040c95e7da188de02ac1eafafa99991380566f1c4bf2e8e410f5f00bf1f87456)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/SeedCoordinates.lean (sha256 4c6b3ea210eaf3af7c8a4cce6d784821309ae4284a6e58cd36d710e4b81cd181)
- TCSlib/Cryptography/SecureComputation/Yao/HybridProof/SelectedLaw.lean (sha256 c718b46ba5c7eb863eefe5dc07792662ebe3364d97d0f4aa7c28721d88f1ff67)

So round 1's sources.zip with these 9 files replaced is the source closure at the round-2 head; PS10/ is unchanged.
checks/closure-r2.txt in verification-r2.zip records the comparison.
