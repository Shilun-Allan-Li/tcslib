"""headerbytes.py <repo> <base-rev> <head-rev> <touched-base.json> <touched-head.json> <out> <file>... -- <endpoint full name>...
Raw byte comparison of declaration headers: for every declaration (private included) of the given files, and for
every listed endpoint, the source text from the declaration keyword line to the first top-level `:=` (or `where`,
or the end of the span), exactly as written, at base and head."""
import sys, json, subprocess, re
repo, base, head, tb, th, out = sys.argv[1:7]
rest = sys.argv[7:]; k = rest.index('--'); files, endpoints = rest[:k], rest[k + 1:]
TB, TH = json.load(open(tb))['files'], json.load(open(th))['files']
def show(rev, f): return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True).stdout.decode('utf-8')
def headers(T, rev):
    d = {}
    for f, info in T.items():
        src = show(rev, f).split('\n')
        for x in info['declarations']:
            text = '\n'.join(src[x['decl_line'] - 1:x['end']])
            dep = 0; cut = len(text); i = 0
            while i < len(text):
                c = text[i]
                if c in '([{⟨': dep += 1
                elif c in ')]}⟩': dep -= 1
                elif dep == 0 and text.startswith(':=', i): cut = i; break
                elif dep == 0 and re.match(r'(?<![\w.])where\b', text[i:]) and (i == 0 or not (text[i-1].isalnum() or text[i-1] in '_.')): cut = i; break
                i += 1
            d[x['name']] = (f, text[:cut])
    return d
HB, HH = headers(TB, base), headers(TH, head)
o = open(out, 'w'); n = bad = 0
sel = [n_ for n_ in HH if HH[n_][0] in files] + endpoints
for name in sel:
    a, b = HB.get(name), HH.get(name)
    if a is None or b is None:
        o.write(f'MISSING\t{name}\tbase={a is not None}\thead={b is not None}\n'); bad += 1; continue
    same = a[1] == b[1]; n += 1; bad += not same
    o.write(f"{'IDENTICAL' if same else 'DIFFERENT'}\t{name}\t{b[0]}\n")
o.write(f'TOTAL {n} compared, {bad} different or missing\n'); o.close()
print(open(out).read().splitlines()[-1])
