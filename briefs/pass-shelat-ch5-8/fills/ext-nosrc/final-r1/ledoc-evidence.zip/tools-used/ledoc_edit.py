"""ledoc_edit.py <worktree>: LE-doc docstring replacements (exact, each old text must occur once)."""
import sys
wt = sys.argv[1]
P = 'TCSlib/Cryptography/Randomness/'
E = {}
E[P + 'Extraction/Rejection.lean'] = [
("""/-- A Boolean acceptance probability is nonnegative. -/""",
 """/-- A Boolean acceptance probability is nonnegative: `0 ≤ Pr_p[D]`. -/"""),
("""/-- A Boolean acceptance probability is at most one. -/""",
 """/-- A Boolean acceptance probability is at most one: `Pr_p[D] ≤ 1`. -/"""),
("""/-- A nonempty tuple is equivalent to its first entry and its tail. -/""",
 """/-- A nonempty tuple is equivalent to its first entry and its tail:
`(Fin (t+1+1) → α) ≃ α × (Fin (t+1) → α)`. -/"""),
("""/-- The first entry of the inverse tuple equivalence is the pair's first coordinate. -/""",
 """/-- The first entry of the inverse tuple equivalence is the pair's first coordinate:
`(tupleEquiv t).symm z 0 = z.1`. -/"""),
("""/-- Each successor entry of the inverse tuple equivalence is the corresponding tail entry. -/""",
 """/-- Each successor entry of the inverse tuple equivalence is the corresponding tail entry:
`(tupleEquiv t).symm z i.succ = z.2 i`. -/"""),
("""/-- Select the first accepted entry among `t` trials; if all fail, return the final entry.
There are""",
 """/-- Select the first accepted entry among `t` trials; if all fail, return the final entry:
`select D 0 x = x 0` and `select D (t+1) x = if D (x 0) then x 0 else select D t (x ∘ succ)`.
There are"""),
("""/-- The law of rejection sampling with `t` trials and an independent uniform fallback.
At each""",
 """/-- The law of rejection sampling with `t` trials and an independent uniform fallback:
`law D 0 = U_α` and `law D (t+1) = map (fun (x,y) => if D x then x else y) (U_α × law D t)`.
At each"""),
("""/-- Independent branching returns the first point on acceptance and the second on rejection:
its mass at `a` is `1_{D(a)} p(a) + Pr_p[¬D] q(a)`.""",
 """/-- Independent branching returns the first point on acceptance and the second on rejection:
`map (fun (x,y) => if D x then x else y) (p × q) a = 1_{D(a)} p(a) + (1-Pr_p[D]) q(a)`."""),
("""/-- For positive uniform acceptance `q`, the rejection law's point mass is
`(1-q)^t / |α| + 1_{D(a)} (1-(1-q)^t) / (|α| q)`.""",
 """/-- For positive uniform acceptance `q = Pr_{U_α}[D] > 0`, the rejection law's point mass is
`law D t a = (1-q)^t / |α| + 1_{D(a)} (1-(1-q)^t) / (|α| q)`."""),
("""/-- Positive uniform acceptance implies that the accepted set is nonempty. -/""",
 """/-- Positive uniform acceptance implies that the accepted set is nonempty:
`0 < Pr_{U_α}[D] → {a : D a}.Nonempty`. -/"""),
("""/-- Mixtures of two `k`-sources are `k`-sources: their point probabilities share the same
upper bound `2^(-k)`, which is preserved by a convex combination. -/""",
 """/-- Mixtures of two `k`-sources are `k`-sources:
`IsSource k p → IsSource k q → IsSource k (mixture w p q)`. Their point probabilities share
the same upper bound `2^(-k)`, which is preserved by a convex combination. -/"""),
("""/-- The probability `(1-q)^t` that all rejection trials fail is nonnegative. -/""",
 """/-- The probability `(1-q)^t` that all rejection trials fail is nonnegative:
`0 ≤ (1-Pr_{U_α}[D])^t`. -/"""),
("""/-- The probability `(1-q)^t` that all rejection trials fail is at most one. -/""",
 """/-- The probability `(1-q)^t` that all rejection trials fail is at most one:
`(1-Pr_{U_α}[D])^t ≤ 1`. -/"""),
("""/-- The rejection law is exactly the convex mixture
`(1-q)^t U_α + (1-(1-q)^t) flat({a : D a})`. -/""",
 """/-- The rejection law is exactly the convex mixture
`law D t = mixture ((1-q)^t) U_α flat({a : D a})` for `q = Pr_{U_α}[D] > 0`, that is,
`(1-q)^t U_α + (1-(1-q)^t) flat({a : D a})`. -/"""),
("""/-- The rejection law is a `k`-source whenever its uniform and accepted-flat components are
`k`-sources. This follows""",
 """/-- The rejection law is a `k`-source whenever its uniform and accepted-flat components are
`k`-sources: `IsSource k U_α → IsSource k flat({a : D a}) → IsSource k (law D t)`.
This follows"""),
]
E[P + 'Extraction/Sampler.lean'] = [
("""/-- Trying `t` blocks of width `n` and falling back to block `t` means returning the first
block whose extractor output starts with `true`, or the final block if every test fails.
[PS10, Theorem 183.6].""",
 """/-- Trying `t` blocks of width `n` and falling back to block `t` means returning the first
block whose extractor output starts with `true`, or the final block if every test fails:
`chooseWord Ext n 0 r = r.take n`, and `chooseWord Ext n (t+1) r = r.take n` if
`(Ext (r.take n)).headD false`, otherwise
`chooseWord Ext n (t+1) r = chooseWord Ext n t (r.drop n)`.
[PS10, Theorem 183.6]."""),
("""/-- One additional trial tests the first block, returning it on acceptance and otherwise
running the remaining trials on the tape with that block dropped. -/""",
 """/-- One additional trial tests the first block, returning it on acceptance and otherwise
running the remaining trials on the tape with that block dropped:
`chooseWord Ext n (t+1) r = if (Ext (r.take n)).headD false then r.take n else
chooseWord Ext n t (r.drop n)`. -/"""),
("""/-- Taking any fixed number `n` of input bits is polynomial-time computable.
""",
 """/-- Taking any fixed number `n` of input bits is polynomial-time computable:
`PolyTimeComputable (fun r : List Bool => r.take n)`.
"""),
("""/-- If `Ext` is polynomial-time, the fixed-width sampler with any fixed number of trials is
polynomial-time. [PS10, Theorem 183.6, the efficiency claim].""",
 """/-- If `Ext` is polynomial-time, the fixed-width sampler with any fixed number of trials is
polynomial-time: `PolyTimeComputable Ext → PolyTimeComputable (chooseWord Ext n t)`.
[PS10, Theorem 183.6, the efficiency claim]."""),
("""/-- The bounded rejection machine on `(t + 1) * n` coins has empty advice and runs
`chooseWord Ext n t` on its coin tape. [PS10, Theorem 183.6]. -/""",
 """/-- The bounded rejection machine on `(t + 1) * n` coins has empty advice and runs
`chooseWord Ext n t` on its coin tape: `(machine hExt n t).runAtL m y r = chooseWord Ext n t r`
and `(machine hExt n t).coins = .const ((t + 1) * n)`. [PS10, Theorem 183.6]. -/"""),
("""/-- The defining equation of `machine` packages the polynomial-time coin function with
constant coin polynomial `(t + 1) * n` and empty advice. -/""",
 """/-- The rejection machine packages the polynomial-time coin function with constant coin
polynomial `(t + 1) * n` and empty advice:
`machine hExt n t = NUPPT.ofPolyTimeUniform f (.const ((t + 1) * n))`, where `f` is
`(chooseWord_poly hExt n t).comp polyTimeComputable_pairSndD`. -/"""),
("""/-- The bounded rejection machine is uniform: it has empty advice at every parameter. -/""",
 """/-- The bounded rejection machine is uniform: it has empty advice at every parameter,
`(machine hExt n t).Uniform`, i.e. `∀ m, (machine hExt n t).advice m = []`. -/"""),
("""/-- The rejection machine's coin polynomial is the constant `(t + 1) * n`. -/""",
 """/-- The rejection machine's coin polynomial is the constant `(t + 1) * n`:
`(machine hExt n t).coins = .const ((t + 1) * n)`. -/"""),
("""/-- On an untyped coin tape `r`, at every activation parameter and argument, the rejection
machine returns `chooseWord Ext n t r`. -/""",
 """/-- On an untyped coin tape `r`, at every activation parameter and argument, the rejection
machine returns `chooseWord Ext n t r`: `(machine hExt n t).runAtL m y r = chooseWord Ext n t r`.
-/"""),
("""/-- On typed coins, the rejection machine runs `chooseWord` on the coin string. -/""",
 """/-- On typed coins, the rejection machine runs `chooseWord` on the coin string:
`(machine hExt n t).runAt m y r = chooseWord Ext n t (List.ofFn r)`. -/"""),
("""/-- At every activation parameter, the rejection machine uses exactly `(t + 1) * n` bits. -/""",
 """/-- At every activation parameter, the rejection machine uses exactly `(t + 1) * n` bits:
`(machine hExt n t).coinLen m = (t + 1) * n`. -/"""),
("""/-- The rejection machine's coins are canonically the bit tape of length `(t + 1) * n`,
independently of its activation parameter. -/""",
 """/-- The rejection machine's coins are canonically the bit tape of length `(t + 1) * n`,
independently of its activation parameter:
`(machine hExt n t).Coins m ≃ (Fin ((t + 1) * n) → Bool)`. -/"""),
("""/-- The canonical rejection-coin equivalence preserves the encoded coin string. -/""",
 """/-- The canonical rejection-coin equivalence preserves the encoded coin string:
`List.ofFn (coinEquiv hExt n t m r) = List.ofFn r`. -/"""),
("""/-- The inverse canonical rejection-coin equivalence preserves the encoded coin string. -/""",
 """/-- The inverse canonical rejection-coin equivalence preserves the encoded coin string:
`List.ofFn ((coinEquiv hExt n t m).symm r) = List.ofFn r`. -/"""),
("""/-- Running the rejection machine on a tape transported through `coinEquiv` is precisely
`chooseWord Ext n t` on that tape. -/""",
 """/-- Running the rejection machine on a tape transported through `coinEquiv` is precisely
`chooseWord Ext n t` on that tape:
`(machine hExt n t).runAt m y ((coinEquiv hExt n t m).symm r) = chooseWord Ext n t (List.ofFn r)`.
-/"""),
]
E[P + 'Extraction.lean'] = [
("""/-- The uniform sampler at the fixed width `n` outputs its `n` coin bits and has no advice. -/""",
 """/-- The uniform sampler at the fixed width `n` outputs its `n` coin bits and has no advice:
`(uniformSampler n).runAt n [] r = List.ofFn r` and `(uniformSampler n).coins = .const n`. -/"""),
("""/-- The uniform sampler uses the constant coin polynomial `n`. -/""",
 """/-- The uniform sampler uses the constant coin polynomial `n`:
`(uniformSampler n).coins = .const n`. -/"""),
("""/-- The uniform sampler has empty advice at every activation parameter. -/""",
 """/-- The uniform sampler has empty advice at every activation parameter:
`(uniformSampler n).Uniform`, i.e. `∀ m, (uniformSampler n).advice m = []`. -/"""),
("""/-- The uniform sampler returns the encoding of its coin vector. -/""",
 """/-- The uniform sampler returns the encoding of its coin vector:
`(uniformSampler n).runAt n [] r = List.ofFn r`. -/"""),
("""/-- The coins of the uniform sampler are canonically the `n`-bit vectors. -/""",
 """/-- The coins of the uniform sampler are canonically the `n`-bit vectors:
`(uniformSampler n).Coins n ≃ (Fin n → Bool)`. -/"""),
("""/-- The canonical uniform-sampler coin equivalence is the composition of the published
coin-polynomial identification with the constant-polynomial width equality. -/""",
 """/-- The canonical uniform-sampler coin equivalence is the composition of the published
coin-polynomial identification with the constant-polynomial width equality:
`uniformSamplerCoins n = e₁.trans e₂`, where `e₁ = NUPPT.coinsEquivPoly (uniformSampler_coins n) n`
and `e₂ = Equiv.arrowCongr (finCongr (PolyExpr.eval_const n n)) (Equiv.refl Bool)`. -/"""),
("""/-- The uniform sampler's coin equivalence preserves the encoded word. -/""",
 """/-- The uniform sampler's coin equivalence preserves the encoded word:
`List.ofFn (uniformSamplerCoins n r) = List.ofFn r`. -/"""),
("""/-- The law of the sampler that returns its coins is the uniform law on `n`-bit strings.
The coin""",
 """/-- The law of the sampler that returns its coins is the uniform law on `n`-bit strings:
`samplerLaw (uniformSampler n) n = U_n`.
The coin"""),
("""/-- Uniform `n`-bit strings form an efficiently samplable `(n−2)`-source. -/""",
 """/-- Uniform `n`-bit strings form an efficiently samplable `(n−2)`-source:
`U_n ∈ effSources (fun n => n - 2) n`. -/"""),
("""/-- The first output bit read by `extBit` is the head of the extractor's output,
with `false` for an empty output. -/""",
 """/-- The first output bit read by `extBit` is the head of the extractor's output,
with `false` for an empty output: `extBit Ext n x 0 = (Ext (List.ofFn x)).headD false`. -/"""),
("""/-- A uniform one-bit word has its first bit true with probability `1/2`. -/""",
 """/-- A uniform one-bit word has its first bit true with probability `1/2`:
`Pr_{U_1}[fun x => x 0] = 1/2`. -/"""),
("""/-- If the candidate extractor succeeds on every efficient `(n−2)`-source, then its first
bit on the uniform source is true with probability at least `1/4`.
The uniform""",
 """/-- If the candidate extractor succeeds on every efficient `(n−2)`-source, then its first
bit on the uniform source is true with probability at least `1/4`:
`IsExtractor (effSources (fun n => n - 2) n) (1/4) (extBit Ext n) →
1/4 ≤ Pr_{U_n}[fun x => extBit Ext n x 0]`.
The uniform"""),
("""/-- The bounded rejection machine's law at width `n` is the finite first-success law
on `t` trials and an independent uniform fallback.
""",
 """/-- The bounded rejection machine's law at width `n` is the finite first-success law
on `t` trials and an independent uniform fallback:
`samplerLaw (RejectionSampler.machine hExt n t) n = Rejection.law D t`, where
`D a = (Ext (List.ofFn a)).headD false`.
"""),
("""/-- When uniform acceptance is at least `1/4`, ten rejection trials and a fresh fallback
produce an efficiently samplable `(n−2)`-source.
""",
 """/-- When uniform acceptance is at least `1/4`, ten rejection trials and a fresh fallback
produce an efficiently samplable `(n−2)`-source:
`1/4 ≤ Pr_{U_n}[D] → Rejection.law D 10 ∈ effSources (fun n => n - 2) n`, where
`D a = (Ext (List.ofFn a)).headD false`.
"""),
]
for f, reps in E.items():
    p = f'{wt}/{f}'
    s = open(p, encoding='utf-8').read()
    for old, new in reps:
        c = s.count(old)
        assert c == 1, (f, c, old[:60])
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print(f, len(reps))
