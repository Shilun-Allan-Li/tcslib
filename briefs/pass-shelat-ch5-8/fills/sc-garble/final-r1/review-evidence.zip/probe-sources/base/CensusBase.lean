import Lean
import TCSlib.Complexity.CircuitComplexity.DAGCircuit
import TCSlib.Cryptography.SecureComputation.Garbling
import TCSlib.Cryptography.SecureComputation.GarblingSecurity
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity
import TCSlib.Cryptography.SecureComputation.Yao
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-garble review census probe (base side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.SecureComputation.spDecStr_wrongKey
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_wrongKey
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_multiMessageSecure
#print axioms TCSlib.Cryptography.SecureComputation.nestedSpecial_wrongKeyBot
#print axioms TCSlib.Cryptography.SecureComputation.uprob_not_good_le
#print axioms TCSlib.Cryptography.SecureComputation.yaoSeed_good_whp
#print axioms TCSlib.Cryptography.SecureComputation.sliceMultiMessageSecure_of_prfOut
#print axioms TCSlib.Cryptography.SecureComputation.garbling_good_whp
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_multiMessageSecure_of_joint
#print axioms TCSlib.Cryptography.SecureComputation.yaoHybrid_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure

def owners : List Name := [`TCSlib.Complexity.CircuitComplexity.DAGCircuit,
  `TCSlib.Cryptography.SecureComputation.Garbling,
  `TCSlib.Cryptography.SecureComputation.GarblingSecurity,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti,
  `TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity,
  `TCSlib.Cryptography.SecureComputation.Yao]
def nameMap : Std.HashMap String String := Std.HashMap.ofList [("TCSlib.Cryptography.SecureComputation.specialKeyEq", "TCSlib.Cryptography.SecureComputation.specialScheme_keyCoinsEquiv"),
  ("TCSlib.Cryptography.SecureComputation.ofFn_specialKeyEq", "TCSlib.Cryptography.SecureComputation.specialScheme_keyCoinsEquiv_ofFn"),
  ("TCSlib.Cryptography.SecureComputation.specialNonceEq", "TCSlib.Cryptography.SecureComputation.specialScheme_nonceCoinsEquiv"),
  ("TCSlib.Cryptography.SecureComputation.ofFn_specialNonceEq", "TCSlib.Cryptography.SecureComputation.specialScheme_nonceCoinsEquiv_ofFn")]

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

