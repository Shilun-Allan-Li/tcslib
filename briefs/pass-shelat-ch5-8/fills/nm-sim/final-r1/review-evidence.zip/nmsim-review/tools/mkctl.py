"""mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
AC = 'TCSlib.Cryptography.Composability.AdaptiveCPA'
PK = 'TCSlib.Cryptography.Composability.FixedLengthPKScheme'
G = 'TCSlib.Cryptography.Games'
NM = 'TCSlib.Cryptography.Composability.NMCCA2'
OP = "open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in\n"
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
B = {
 'Turing.pairEncode': row("ctlPair",
   "theorem ctlPair (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n",
   "theorem ctlPairReader (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b\n"),
 'TCSlib.Cryptography.padFin': row("ctlPadFin",
   "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n",
   "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n"),
 G + '.zeroBits': row("ctlZeroBits",
   f"theorem ctlZeroBits (d : ℕ) (j : Fin d) : {G}.zeroBits d j = false := rfl\n",
   f"theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : {G}.zeroBits d j = false :=\n  {G}.zeroBits_apply d j\n"),
 G + '.simulate': row("ctlSimulate",
   f"open {G} in\ntheorem ctlSimulate {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl\n",
   f"open {G} in\ntheorem ctlSimulateReader {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := {G}.simulate_pure impl a s\n"),
 G + '.seedIn': row("ctlSeedIn",
   f"theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl\n",
   f"theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=\n  {G}.seedIn_eq n z ω\n"),
 G + '.InteractiveHandler.finInput': row("ctlFinInput",
   f"theorem ctlFinInput (n : ℕ) (z ω s a L : List Bool) : {G}.InteractiveHandler.finInput n z ω s a L =\n    Turing.pairEncode ({G}.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) := rfl\n",
   f"theorem ctlFinInputReader (n : ℕ) (z ω s a L : List Bool) : {G}.InteractiveHandler.finInput n z ω s a L =\n    Turing.pairEncode ({G}.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) :=\n  {G}.InteractiveHandler.finInput_eq n z ω s a L\n"),
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 PK + '.inLens': row("ctlPkInLens",
   f"theorem ctlPkInLens (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl\n",
   f"theorem ctlPkInLensReader (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=\n  S.inLens_zero n\n"),
 PK + '.outLens': row("ctlPkOutLens",
   f"theorem ctlPkOutLens (S : {PK}) (n : ℕ) : S.outLens n 0 = S.msgLen.eval n + 1 := rfl\n",
   f"theorem ctlPkOutLensReader (S : {PK}) (n : ℕ) : S.outLens n 0 = S.msgLen.eval n + 1 :=\n  S.outLens_zero n\n"),
 PK + '.indImpl': row("ctlPkIndImpl",
   f"open TCSlib.Cryptography.Games in\ntheorem ctlPkIndImpl (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)\n    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) (c : Fin (S.ctLen.eval n) → Bool) :\n    S.indImpl atk b n pk sk 1 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) := rfl\n",
   f"open TCSlib.Cryptography.Games in\ntheorem ctlPkIndImplReader (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)\n    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) (c : Fin (S.ctLen.eval n) → Bool) :\n    S.indImpl atk b n pk sk 1 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) :=\n  S.indImpl_challenge_repeat_onSpec atk b n pk sk mm c\n"),
 AC + '.acDin': row("ctlAcDin",
   f"theorem ctlAcDin (S : {PK}) : {AC}.acDin S 0 = S.ctLen := rfl\n",
   f"theorem ctlAcDinReader (S : {PK}) : {AC}.acDin S 0 = S.ctLen := {AC}.acDin_zero S\n"),
 AC + '.castImpl': row("ctlCastImpl",
   f"open {G} in\ntheorem ctlCastImpl {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) := rfl\n",
   f"open {G} in\ntheorem ctlCastImplReader {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) :=\n  {AC}.castImpl_eq O i x s\n"),
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer': row("ctlDecAnswer",
   "theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m := rfl\n",
   "theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m\n"),
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen': row("ctlDecOpen",
   "theorem ctlDecOpen (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false := rfl\n",
   "theorem ctlDecOpenReader (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen_cpa c\n"),
 NM + '.fwdHandler': row("ctlFwdHandler",
   OP + f"theorem ctlFwdHandler {{k : ℕ}} (din dout : Fin k → PolyExpr) (sl : PolyExpr) (ai : List Bool → List Bool)\n    (hai : PolyTimeComputable ai) (ol fc : PolyExpr) (fr : List Bool → List Bool) (hfr : PolyTimeComputable fr) :\n    ({NM}.fwdHandler din dout sl ai hai ol fc fr hfr).perCall = .const 1 := rfl\n",
   OP + f"theorem ctlFwdHandlerReader {{k : ℕ}} (din dout : Fin k → PolyExpr) (sl : PolyExpr) (ai : List Bool → List Bool)\n    (hai : PolyTimeComputable ai) (ol fc : PolyExpr) (fr : List Bool → List Bool) (hfr : PolyTimeComputable fr) :\n    ({NM}.fwdHandler din dout sl ai hai ol fc fr hfr).perCall = .const 1 :=\n  {NM}.fwdHandler_perCall din dout sl ai hai ol fc fr hfr\n"),
 NM + '.finU': row("ctlFinU",
   f"theorem ctlFinU (w : List Bool) : {NM}.finU w = Complexity.pairFstD (Complexity.pairFstD w) := rfl\n",
   f"theorem ctlFinUReader (w : List Bool) : {NM}.finU w = Complexity.pairFstD (Complexity.pairFstD w) :=\n  {NM}.finU_eq w\n"),
 NM + '.logEmit': row("ctlLogEmit",
   f"theorem ctlLogEmit (G : List Bool → List Bool) (L : List Bool) :\n    {NM}.logEmit G L = (List.range (L.length + 1)).flatMap fun i => G (Complexity.pairSndD^[i] L) := rfl\n",
   f"theorem ctlLogEmitReader (G : List Bool → List Bool) (L : List Bool) :\n    {NM}.logEmit G L = (List.range (L.length + 1)).flatMap fun i => G (Complexity.pairSndD^[i] L) :=\n  {NM}.logEmit_eq G L\n"),
 NM + '.cntRead': row("ctlCntRead",
   f"theorem ctlCntRead (v : List Bool) : {NM}.cntRead v = if decide (v = []) then [] else [true] := rfl\n",
   f"theorem ctlCntReadReader (v : List Bool) : {NM}.cntRead v = if decide (v = []) then [] else [true] :=\n  {NM}.cntRead_eq v\n"),
 NM + '.decHandler': row("ctlDecHandler",
   f"theorem ctlDecHandler (S : {PK}) (ℓ : Complexity.PolyExpr) (D : Complexity.NUPPT) :\n    ({NM}.decHandler S ℓ D).perCall = .const 1 := rfl\n",
   f"theorem ctlDecHandlerReader (S : {PK}) (ℓ : Complexity.PolyExpr) (D : Complexity.NUPPT) :\n    ({NM}.decHandler S ℓ D).perCall = .const 1 := {NM}.decHandler_perCall S ℓ D\n"),
 NM + '.encHandler': row("ctlEncHandler",
   f"theorem ctlEncHandler (S : {PK}) : ({NM}.encHandler S).perCall = .const 1 := rfl\n",
   f"theorem ctlEncHandlerReader (S : {PK}) : ({NM}.encHandler S).perCall = .const 1 :=\n  {NM}.encHandler_perCall S\n"),
 NM + '.guessBit': row("ctlGuessBit",
   f"theorem ctlGuessBit (w : List Bool) : {NM}.guessBit w =\n    if w.headD false then (w.drop 1).headD false else !w.reverse.headD false := rfl\n",
   f"theorem ctlGuessBitReader (w : List Bool) : {NM}.guessBit w =\n    if w.headD false then (w.drop 1).headD false else !w.reverse.headD false := {NM}.guessBit_eq w\n"),
}
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace NmControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end NmControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
for rec_path in sorted(Path(sealdir).glob('Seal?_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
