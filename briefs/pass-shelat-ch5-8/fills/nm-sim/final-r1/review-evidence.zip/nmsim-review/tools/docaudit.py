"""docaudit.py <worktree> <touched.json>: for every touched public declaration (and every
theorem/def/abbrev in new files), report docstring presence and whether the docstring states a
formula (a backticked span containing a relation symbol), plus label-only phrasing."""
import json, re, sys
wt, tj = sys.argv[1:3]
t = json.load(open(tj))['files']
REL = re.compile(r'`[^`]*(=|≤|<|≥|>|↔|≃|∈|≠|→)[^`]*`')
for f, info in t.items():
    lines = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    for d in info['declarations']:
        if not d['touched'] or d['private']: continue
        s, e = d['start'] - 1, d['end']
        block = '\n'.join(lines[s:e])
        if re.search(r'^\s*private\b', block, re.M) and not block.lstrip().startswith('/--'):
            pass
        m = re.match(r'\s*/--(.*?)-/', block, re.S)
        head = block[m.end():] if m else block
        if re.match(r'\s*(@\[[^\]]*\]\s*)*private\b', head): continue
        kind = re.match(r'\s*(@\[[^\]]*\]\s*)*(?:noncomputable\s+)?(\w+)', head).group(2)
        doc = m.group(1).strip() if m else None
        flag = []
        if doc is None: flag.append('NO-DOC')
        else:
            first = doc.split('**Proof sketch')[0]
            if not REL.search(first): flag.append('NO-FORMULA')
            if re.search(r'defining equation|equation of `', first): flag.append('LABEL')
            sk = '**Proof sketch' in doc
        print('\t'.join([','.join(flag) or 'OK', f"{f.split('PrivateKey/')[-1]}:{d['start']}", d['name'].split('Composability.')[-1], kind, (doc or '')[:110].replace('\n', ' ')]))
