"""mkctl_nmsim.py (nm-sim review: the nm-cca2 review mkctl.py with nm-sim rows appended to B and namespace NmSimControls)
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmSimControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
AC = 'TCSlib.Cryptography.Composability.AdaptiveCPA'
PK = 'TCSlib.Cryptography.Composability.FixedLengthPKScheme'
G = 'TCSlib.Cryptography.Games'
NM = 'TCSlib.Cryptography.Composability.NMCCA2'
OP = "open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in\n"
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
B = {
 'Turing.pairEncode': row("ctlPair",
   "theorem ctlPair (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n",
   "theorem ctlPairReader (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b\n"),
 'TCSlib.Cryptography.padFin': row("ctlPadFin",
   "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n",
   "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n"),
 G + '.zeroBits': row("ctlZeroBits",
   f"theorem ctlZeroBits (d : ℕ) (j : Fin d) : {G}.zeroBits d j = false := rfl\n",
   f"theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : {G}.zeroBits d j = false :=\n  {G}.zeroBits_apply d j\n"),
 G + '.simulate': row("ctlSimulate",
   f"open {G} in\ntheorem ctlSimulate {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl\n",
   f"open {G} in\ntheorem ctlSimulateReader {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := {G}.simulate_pure impl a s\n"),
 G + '.seedIn': row("ctlSeedIn",
   f"theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl\n",
   f"theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=\n  {G}.seedIn_eq n z ω\n"),
 G + '.InteractiveHandler.finInput': row("ctlFinInput",
   f"theorem ctlFinInput (n : ℕ) (z ω s a L : List Bool) : {G}.InteractiveHandler.finInput n z ω s a L =\n    Turing.pairEncode ({G}.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) := rfl\n",
   f"theorem ctlFinInputReader (n : ℕ) (z ω s a L : List Bool) : {G}.InteractiveHandler.finInput n z ω s a L =\n    Turing.pairEncode ({G}.seedIn n z ω) (Turing.pairEncode s (Turing.pairEncode a L)) :=\n  {G}.InteractiveHandler.finInput_eq n z ω s a L\n"),
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 PK + '.inLens': row("ctlPkInLens",
   f"theorem ctlPkInLens (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl\n",
   f"theorem ctlPkInLensReader (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=\n  S.inLens_zero n\n"),
 PK + '.outLens': row("ctlPkOutLens",
   f"theorem ctlPkOutLens (S : {PK}) (n : ℕ) : S.outLens n 0 = S.msgLen.eval n + 1 := rfl\n",
   f"theorem ctlPkOutLensReader (S : {PK}) (n : ℕ) : S.outLens n 0 = S.msgLen.eval n + 1 :=\n  S.outLens_zero n\n"),
 PK + '.indImpl': row("ctlPkIndImpl",
   f"open TCSlib.Cryptography.Games in\ntheorem ctlPkIndImpl (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)\n    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) (c : Fin (S.ctLen.eval n) → Bool) :\n    S.indImpl atk b n pk sk 1 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) := rfl\n",
   f"open TCSlib.Cryptography.Games in\ntheorem ctlPkIndImplReader (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (n : ℕ)\n    (pk sk : List Bool) (mm : (S.indSpec n).dom 1) (c : Fin (S.ctLen.eval n) → Bool) :\n    S.indImpl atk b n pk sk 1 mm (some c) = .pure (cast (S.indSpec_challengeRng n).symm c, some c) :=\n  S.indImpl_challenge_repeat_onSpec atk b n pk sk mm c\n"),
 AC + '.acDin': row("ctlAcDin",
   f"theorem ctlAcDin (S : {PK}) : {AC}.acDin S 0 = S.ctLen := rfl\n",
   f"theorem ctlAcDinReader (S : {PK}) : {AC}.acDin S 0 = S.ctLen := {AC}.acDin_zero S\n"),
 AC + '.castImpl': row("ctlCastImpl",
   f"open {G} in\ntheorem ctlCastImpl {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) := rfl\n",
   f"open {G} in\ntheorem ctlCastImplReader {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) :=\n  {AC}.castImpl_eq O i x s\n"),
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer': row("ctlDecAnswer",
   "theorem ctlDecAnswer {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m := rfl\n",
   "theorem ctlDecAnswerReader {n : ℕ} (m : Fin n → Bool) :\n    TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer (some m) =\n      Fin.cons (α := fun _ => Bool) true m :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer_some m\n"),
 'TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen': row("ctlDecOpen",
   "theorem ctlDecOpen (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false := rfl\n",
   "theorem ctlDecOpenReader (c : Bool) : TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen .cpa c = false :=\n  TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen_cpa c\n"),
 NM + '.fwdHandler': row("ctlFwdHandler",
   OP + f"theorem ctlFwdHandler {{k : ℕ}} (din dout : Fin k → PolyExpr) (sl : PolyExpr) (ai : List Bool → List Bool)\n    (hai : PolyTimeComputable ai) (ol fc : PolyExpr) (fr : List Bool → List Bool) (hfr : PolyTimeComputable fr) :\n    ({NM}.fwdHandler din dout sl ai hai ol fc fr hfr).perCall = .const 1 := rfl\n",
   OP + f"theorem ctlFwdHandlerReader {{k : ℕ}} (din dout : Fin k → PolyExpr) (sl : PolyExpr) (ai : List Bool → List Bool)\n    (hai : PolyTimeComputable ai) (ol fc : PolyExpr) (fr : List Bool → List Bool) (hfr : PolyTimeComputable fr) :\n    ({NM}.fwdHandler din dout sl ai hai ol fc fr hfr).perCall = .const 1 :=\n  {NM}.fwdHandler_perCall din dout sl ai hai ol fc fr hfr\n"),
 NM + '.finU': row("ctlFinU",
   f"theorem ctlFinU (w : List Bool) : {NM}.finU w = Complexity.pairFstD (Complexity.pairFstD w) := rfl\n",
   f"theorem ctlFinUReader (w : List Bool) : {NM}.finU w = Complexity.pairFstD (Complexity.pairFstD w) :=\n  {NM}.finU_eq w\n"),
 NM + '.logEmit': row("ctlLogEmit",
   f"theorem ctlLogEmit (G : List Bool → List Bool) (L : List Bool) :\n    {NM}.logEmit G L = (List.range (L.length + 1)).flatMap fun i => G (Complexity.pairSndD^[i] L) := rfl\n",
   f"theorem ctlLogEmitReader (G : List Bool → List Bool) (L : List Bool) :\n    {NM}.logEmit G L = (List.range (L.length + 1)).flatMap fun i => G (Complexity.pairSndD^[i] L) :=\n  {NM}.logEmit_eq G L\n"),
 NM + '.cntRead': row("ctlCntRead",
   f"theorem ctlCntRead (v : List Bool) : {NM}.cntRead v = if decide (v = []) then [] else [true] := rfl\n",
   f"theorem ctlCntReadReader (v : List Bool) : {NM}.cntRead v = if decide (v = []) then [] else [true] :=\n  {NM}.cntRead_eq v\n"),
 NM + '.decHandler': row("ctlDecHandler",
   f"theorem ctlDecHandler (S : {PK}) (ℓ : Complexity.PolyExpr) (D : Complexity.NUPPT) :\n    ({NM}.decHandler S ℓ D).perCall = .const 1 := rfl\n",
   f"theorem ctlDecHandlerReader (S : {PK}) (ℓ : Complexity.PolyExpr) (D : Complexity.NUPPT) :\n    ({NM}.decHandler S ℓ D).perCall = .const 1 := {NM}.decHandler_perCall S ℓ D\n"),
 NM + '.encHandler': row("ctlEncHandler",
   f"theorem ctlEncHandler (S : {PK}) : ({NM}.encHandler S).perCall = .const 1 := rfl\n",
   f"theorem ctlEncHandlerReader (S : {PK}) : ({NM}.encHandler S).perCall = .const 1 :=\n  {NM}.encHandler_perCall S\n"),
 NM + '.guessBit': row("ctlGuessBit",
   f"theorem ctlGuessBit (w : List Bool) : {NM}.guessBit w =\n    if w.headD false then (w.drop 1).headD false else !w.reverse.headD false := rfl\n",
   f"theorem ctlGuessBitReader (w : List Bool) : {NM}.guessBit w =\n    if w.headD false then (w.drop 1).headD false else !w.reverse.headD false := {NM}.guessBit_eq w\n"),
}

NS = 'TCSlib.Cryptography.Composability.NMSim'
GO = 'TCSlib.Cryptography.Games.OracleComp'
def rw_pos(name, stmt, lemma):
    return f"theorem {name}Reader {stmt} := by\n  rw [{lemma}]\n"
B.update({
 NS + '.chunkMap': row("ctlChunkMap",
   f"theorem ctlChunkMap (c : Complexity.PolyExpr) (f : List Bool → List Bool → List Bool) (x : List Bool) :\n    {NS}.chunkMap c f x = (List.range (x.length + 1)).flatMap fun i =>\n      {NS}.chunkEmit c f (({NS}.chunkStep c)^[i] x) := rfl\n",
   f"theorem ctlChunkMapReader (c : Complexity.PolyExpr) (f : List Bool → List Bool → List Bool) (x : List Bool) :\n    {NS}.chunkMap c f x = (List.range (x.length + 1)).flatMap fun i =>\n      {NS}.chunkEmit c f (({NS}.chunkStep c)^[i] x) := {NS}.chunkMap_eq c f x\n"),
 NS + '.snmDin': row("ctlSnmDin",
   f"theorem ctlSnmDin (S : {PK}) (pl : Complexity.PolyExpr) : {NS}.snmDin S pl 1 = pl := rfl\n",
   f"theorem ctlSnmDinReader (S : {PK}) (pl : Complexity.PolyExpr) : {NS}.snmDin S pl 1 = pl :=\n  {NS}.snmDin_one S pl\n"),
 NS + '.drawWith': row("ctlDrawWith",
   f"theorem ctlDrawWith (samp : Complexity.NUPPT) (l n : ℕ) {{k : ℕ}} (a : Fin k → Bool) (ρ : samp.Coins n) :\n    {NS}.drawWith samp l n a ρ = TCSlib.Cryptography.padFin l (samp.runAt n (List.ofFn a) ρ) := rfl\n",
   f"theorem ctlDrawWithReader (samp : Complexity.NUPPT) (l n : ℕ) {{k : ℕ}} (a : Fin k → Bool) (ρ : samp.Coins n) :\n    {NS}.drawWith samp l n a ρ = TCSlib.Cryptography.padFin l (samp.runAt n (List.ofFn a) ρ) :=\n  {NS}.drawWith_eq samp l n a ρ\n"),
 NS + '.chunkAt': row("ctlChunkAt",
   f"theorem ctlChunkAt (k i : ℕ) (w : List Bool) : {NS}.chunkAt k i w = (w.drop (i * k)).take k := rfl\n",
   f"theorem ctlChunkAtReader (k i : ℕ) (w : List Bool) : {NS}.chunkAt k i w = (w.drop (i * k)).take k :=\n  {NS}.chunkAt_eq k i w\n"),
 NS + '.rImpl': row("ctlRImpl",
   f"open TCSlib.Cryptography.Games in\ntheorem ctlRImpl (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (samp : Complexity.NUPPT)\n    (pl hl : Complexity.PolyExpr) (hist : List Bool → List Bool) (n : ℕ) (pk sk : List Bool) (ρ ρ' : samp.Coins n)\n    (ce : Option (S.enc.Coins n)) (x : Fin (({NS}.snmDin S pl 1).eval n) → Bool) (y : Fin (S.ctLen.eval n) → Bool)\n    (a : Fin (pl.eval n) → Bool) :\n    {NS}.rImpl S atk b samp pl hl hist n pk sk ρ ρ' ce 1 x (some (y, a)) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn y ++ List.ofFn ({NS}.histWith hist (hl.eval n)\n        ({NS}.drawWith samp (S.msgLen.eval n) n a ρ))), some (y, a)) := rfl\n",
   f"open TCSlib.Cryptography.Games in\ntheorem ctlRImplReader (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) (b : Bool) (samp : Complexity.NUPPT)\n    (pl hl : Complexity.PolyExpr) (hist : List Bool → List Bool) (n : ℕ) (pk sk : List Bool) (ρ ρ' : samp.Coins n)\n    (ce : Option (S.enc.Coins n)) (x : Fin (({NS}.snmDin S pl 1).eval n) → Bool) (y : Fin (S.ctLen.eval n) → Bool)\n    (a : Fin (pl.eval n) → Bool) :\n    {NS}.rImpl S atk b samp pl hl hist n pk sk ρ ρ' ce 1 x (some (y, a)) =\n      .pure (TCSlib.Cryptography.padFin _ (List.ofFn y ++ List.ofFn ({NS}.histWith hist (hl.eval n)\n        ({NS}.drawWith samp (S.msgLen.eval n) n a ρ))), some (y, a)) := by\n  rw [{NS}.rImpl_some]\n"),
 NS + '.entryTails': row("ctlEntryTails",
   f"theorem ctlEntryTails (S : {PK}) :\n    {NS}.entryTails S = {NS}.chunkMap (S.msgLen.add (.const 2)) fun _ ch => ch.drop 1 := rfl\n",
   f"theorem ctlEntryTailsReader (S : {PK}) :\n    {NS}.entryTails S = {NS}.chunkMap (S.msgLen.add (.const 2)) fun _ ch => ch.drop 1 :=\n  {NS}.entryTails_eq S\n"),
 NS + '.halfCoins': row("ctlHalfCoins",
   f"theorem ctlHalfCoins (S : {PK}) (n : ℕ) (ρ : ({NS}.halfSamp S).Coins n) :\n    {NS}.halfCoins S n ρ = (List.ofFn ρ).headD false := rfl\n",
   f"theorem ctlHalfCoinsReader (S : {PK}) (n : ℕ) (ρ : ({NS}.halfSamp S).Coins n) :\n    {NS}.halfCoins S n ρ = (List.ofFn ρ).headD false := {NS}.halfCoins_apply S n ρ\n"),
 NS + '.simHandler': row("ctlSimHandler",
   f"theorem ctlSimHandler (S : {PK}) (l : Complexity.PolyExpr) :\n    {NS}.simHandler S l = {NS}.copyHandler S (S.msgLen.add S.msgLen) (.const 0)\n      ((l.mul S.ctLen).add (.const 0)) := rfl\n",
   f"theorem ctlSimHandlerReader (S : {PK}) (l : Complexity.PolyExpr) :\n    {NS}.simHandler S l = {NS}.copyHandler S (S.msgLen.add S.msgLen) (.const 0)\n      ((l.mul S.ctLen).add (.const 0)) := {NS}.simHandler_eq S l\n"),
 NS + '.rdState': row("ctlRdState",
   f"theorem ctlRdState (w : List Bool) : {NS}.rdState w = Complexity.pairFstD (Complexity.pairSndD w) := rfl\n",
   f"theorem ctlRdStateReader (w : List Bool) : {NS}.rdState w = Complexity.pairFstD (Complexity.pairSndD w) :=\n  {NS}.rdState_eq w\n"),
 NS + '.chalHandler': row("ctlChalHandler",
   f"theorem ctlChalHandler (S : {PK}) (pl hl : Complexity.PolyExpr) (k' : ℕ) (din' dout' : Fin k' → Complexity.PolyExpr)\n    (P : {NS}.ChalParams S pl hl k' din' dout') (n : ℕ) :\n    ({NS}.chalHandler P).init n = {NS}.chalState P n none := rfl\n",
   f"theorem ctlChalHandlerReader (S : {PK}) (pl hl : Complexity.PolyExpr) (k' : ℕ) (din' dout' : Fin k' → Complexity.PolyExpr)\n    (P : {NS}.ChalParams S pl hl k' din' dout') (n : ℕ) :\n    ({NS}.chalHandler P).init n = {NS}.chalState P n none := by\n  rw [{NS}.chalHandler_init]\n"),
 NS + '.finSt': row("ctlFinSt",
   f"theorem ctlFinSt (w : List Bool) : {NS}.finSt w = Complexity.pairFstD (Complexity.pairSndD w) := rfl\n",
   f"theorem ctlFinStReader (w : List Bool) : {NS}.finSt w = Complexity.pairFstD (Complexity.pairSndD w) :=\n  {NS}.finSt_eq w\n"),
 NS + '.encPair': row("ctlEncPair",
   f"theorem ctlEncPair (S : {PK}) (samp : Complexity.NUPPT) (ctx : List Bool) (x : Bool) :\n    {NS}.encPair S samp ctx x = {NS}.encBit S samp ctx x ++ {NS}.encBit S samp ctx (!x) := rfl\n",
   f"theorem ctlEncPairReader (S : {PK}) (samp : Complexity.NUPPT) (ctx : List Bool) (x : Bool) :\n    {NS}.encPair S samp ctx x = {NS}.encBit S samp ctx x ++ {NS}.encBit S samp ctx (!x) :=\n  {NS}.encPair_eq S samp ctx x\n"),
 NS + '.bitG': row("ctlBitG",
   f"theorem ctlBitG (ctx ch : List Bool) : {NS}.bitG ctx ch = [{NM}.guessBit ch] := rfl\n",
   f"theorem ctlBitGReader (ctx ch : List Bool) : {NS}.bitG ctx ch = [{NM}.guessBit ch] := {NS}.bitG_eq ctx ch\n"),
 PK + '.NMSecure': row("ctlNMSecure",
   f"theorem ctlNMSecure (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) :\n    S.NMSecure atk ↔ ∀ (A : Complexity.NUPPT) (q l : Complexity.PolyExpr) (D : Complexity.NUPPT),\n      ∃ ε : ℕ → ℝ, TCSlib.Cryptography.Negligible ε ∧ ∀ n, TCSlib.Cryptography.Games.advantage\n        (S.nmGame atk A (q.eval n) (l.eval n) D false n) (S.nmGame atk A (q.eval n) (l.eval n) D true n) ≤ ε n :=\n  Iff.rfl\n",
   f"theorem ctlNMSecureReader (S : {PK}) (atk : TCSlib.Cryptography.Composability.Attack) :\n    S.NMSecure atk ↔ ∀ (A : Complexity.NUPPT) (q l : Complexity.PolyExpr) (D : Complexity.NUPPT),\n      ∃ ε : ℕ → ℝ, TCSlib.Cryptography.Negligible ε ∧ ∀ n, TCSlib.Cryptography.Games.advantage\n        (S.nmGame atk A (q.eval n) (l.eval n) D false n) (S.nmGame atk A (q.eval n) (l.eval n) D true n) ≤ ε n :=\n  S.NMSecure_iff atk\n"),
 GO + '.AllOutputs': row("ctlAllOutputs",
   f"theorem ctlAllOutputs {{α : Type}} (a : α) (P : α → Prop) :\n    (TCSlib.Cryptography.Games.OracleComp.pure (spec := TCSlib.Cryptography.Games.unifSpec) a).AllOutputs P ↔ P a := Iff.rfl\n",
   f"theorem ctlAllOutputsReader {{α : Type}} (a : α) (P : α → Prop) :\n    (TCSlib.Cryptography.Games.OracleComp.pure (spec := TCSlib.Cryptography.Games.unifSpec) a).AllOutputs P ↔ P a :=\n  {GO}.allOutputs_pure\n"),
})

def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace NmSimControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end NmSimControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
for rec_path in sorted(Path(sealdir).glob('Seal?_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
