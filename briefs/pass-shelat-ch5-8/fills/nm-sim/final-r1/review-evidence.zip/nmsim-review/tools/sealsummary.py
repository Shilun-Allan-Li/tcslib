"""sealsummary.py <rundir>: per seal probe, rc, error count, harness install record
(requested, active, already_irreducible, verified) and EOF record (requested, verified)."""
import json,sys,re
d=sys.argv[1]
for l in open(d+'/results.jsonl'):
    r=json.loads(l)
    if 'module' not in r: continue
    lab=r['module'].split('/')[-1]
    log=open(f"{d}/mods/{r['module'].replace('/','_')}.log",encoding='utf-8',errors='replace').read()
    m=re.search(r'G06-SEAL label=\S+ requested=(\d+) active=(\d+) already_irreducible=(\d+) verified=(\d+)',log)
    e=re.search(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)',log)
    print(f"{lab:85} rc {r['rc']} errors {r['errors']} install {'/'.join(m.groups()) if m else None} eof {'/'.join(e.groups()) if e else None}")
