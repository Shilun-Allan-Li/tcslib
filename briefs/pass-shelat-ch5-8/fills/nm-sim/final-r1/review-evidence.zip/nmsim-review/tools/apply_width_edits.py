"""apply_width_edits.py <root>: nm-sim landing edit LE-W (line widths <= 100 characters).
Exact old -> new line replacements in the 11 nm-sim files; each old text must occur exactly the
stated number of times. Pure re-wrapping: no token is added, removed or reordered, except that the
doc comment of `entryL_eq` closes on its own line's end (`-/` moved up)."""
import sys
root = sys.argv[1] + '/TCSlib/Cryptography/Encryption/PublicKey/NonMalleability/'
E = []
def e(f, old, new, cnt=1): E.append((f, old, new, cnt))
O, C, G, H, I, Rc, Rd, Ro, SI, SG, Sm = ('Simulation.lean',) + tuple('Simulation/%s.lean' % x for x in
  ['Challenge', 'Generic', 'Hybrid', 'IndSim', 'Recover', 'Reduction', 'Rounds', 'SimIND', 'SimINDGap', 'Simulator'])
# owned file
e(O, "    (w : Fin (r * (S.ctLen.eval n + 1) + sl) → Bool) (sa : Option (Fin (M.paramLen.eval n) → Bool)) :\n",
     "    (w : Fin (r * (S.ctLen.eval n + 1) + sl) → Bool)\n    (sa : Option (Fin (M.paramLen.eval n) → Bool)) :\n")
e(O, "`accept (snmReal atk M A q r sl X n) = NMSim.realAcc S atk M.samp M.paramLen M.histLen M.hist A q r sl X n`.\n",
     "`accept (snmReal atk M A q r sl X n) =\nNMSim.realAcc S atk M.samp M.paramLen M.histLen M.hist A q r sl X n`.\n")
e(O, "`accept (snmIdeal M Sim r sl X n) = NMSim.idealAcc S M.samp M.paramLen M.histLen M.hist Sim r sl X n`.\n",
     "`accept (snmIdeal M Sim r sl X n) =\nNMSim.idealAcc S M.samp M.paramLen M.histLen M.hist Sim r sl X n`.\n")
e(O, "   outputs each of `A`'s ciphertexts followed by the pair `Enc_pk(f^{msgLen})`, `Enc_pk((¬f)^{msgLen})`\n",
     "   outputs each of `A`'s ciphertexts followed by the pair\n   `Enc_pk(f^{msgLen})`, `Enc_pk((¬f)^{msgLen})`\n")
# Challenge
e(C, "    (o : Option ((Fin (S.ctLen.eval n) → Bool) × (Fin (hl.eval n) → Bool) × (Fin (pl.eval n) → Bool))) :\n",
     "    (o : Option ((Fin (S.ctLen.eval n) → Bool) × (Fin (hl.eval n) → Bool) ×\n      (Fin (pl.eval n) → Bool))) :\n", 2)
e(C, "private theorem padFin_replicate_false (d m : ℕ) : padFin d (List.replicate m false) = zeroBits d := by\n",
     "private theorem padFin_replicate_false (d m : ℕ) :\n    padFin d (List.replicate m false) = zeroBits d := by\n")
e(C, "                  (List.ofFn (chalState P n none)) (1 : Fin 2) (List.ofFn x) [])) (List.ofFn y))) [])) ++\n",
     "                  (List.ofFn (chalState P n none)) (1 : Fin 2) (List.ofFn x) []))\n                  (List.ofFn y))) [])) ++\n")
e(C, "                  (List.ofFn (chalState P n none)) (1 : Fin 2) (List.ofFn x) [])) (List.ofFn y))) []))),\n",
     "                  (List.ofFn (chalState P n none)) (1 : Fin 2) (List.ofFn x) []))\n                  (List.ofFn y))) []))),\n", 3)
e(C, "    InteractiveHandler.input n z (List.ofFn ω) (List.ofFn (chalState P n none)) (1 : Fin 2) (List.ofFn x)\n",
     "    InteractiveHandler.input n z (List.ofFn ω) (List.ofFn (chalState P n none)) (1 : Fin 2)\n      (List.ofFn x)\n")
# Generic
e(G, "* `NMSim.expect_congr_of_allOutputs`, `NMSim.expect_expect_sample`, `NMSim.bind_congr_of_allOutputs`.\n",
     "* `NMSim.expect_congr_of_allOutputs`, `NMSim.expect_expect_sample`,\n  `NMSim.bind_congr_of_allOutputs`.\n")
e(G, "            ProbComp.expect (simulate impl₁ (k ys.1) ys.2) (fun r => if bad r.2 then 0 else G r) := by\n",
     "            ProbComp.expect (simulate impl₁ (k ys.1) ys.2)\n              (fun r => if bad r.2 then 0 else G r) := by\n", 2)
# Hybrid
e(H, "/-- Blocks of `k` bits, one per element: `|(l.map g).flatten| = |l|·k` when every `g x` has `k` bits. -/\n",
     "/-- Blocks of `k` bits, one per element: `|(l.map g).flatten| = |l|·k` when every `g x` has\n`k` bits. -/\n")
e(H, "/-- `entryL S n sk copy c = if copy then true :: 0^{msgLen + 1} else false :: ⟦decAnswer (Dec_sk c)⟧`.\n-/\n",
     "/-- `entryL S n sk copy c =\nif copy then true :: 0^{msgLen + 1} else false :: ⟦decAnswer (Dec_sk c)⟧`. -/\n")
e(H, "    realAcc S atk samp pl hl hist A q r sl X n = hybAcc S atk false samp pl hl hist A q r sl X n := by\n",
     "    realAcc S atk samp pl hl hist A q r sl X n =\n      hybAcc S atk false samp pl hl hist A q r sl X n := by\n")
# IndSim
e(I, "  have hs : ((PolyExpr.const 1).add (S.ctLen.add hl)).eval n = 1 + (S.ctLen.eval n + hl.eval n) := by\n",
     "  have hs : ((PolyExpr.const 1).add (S.ctLen.add hl)).eval n =\n      1 + (S.ctLen.eval n + hl.eval n) := by\n")
e(I, "            (finMsg S samp n (pairSndD (pairEncode (pairFstD (S.gen.runAt n [] rg)) (samp.advice n)))\n",
     "            (finMsg S samp n\n              (pairSndD (pairEncode (pairFstD (S.gen.runAt n [] rg)) (samp.advice n)))\n")
e(I, "              (stParam S hl n (List.ofFn (nmAbs S samp pl hl hist hist_poly r sl n ρ ρ' s).1)))))))) =\n",
     "              (stParam S hl n\n                (List.ofFn (nmAbs S samp pl hl hist hist_poly r sl n ρ ρ' s).1)))))))) =\n")
e(I, "  have haP : (stParam S hl n (List.ofFn (nmAbs S samp pl hl hist hist_poly r sl n ρ ρ' s).1)).length =\n",
     "  have haP :\n      (stParam S hl n (List.ofFn (nmAbs S samp pl hl hist hist_poly r sl n ρ ρ' s).1)).length =\n")
e(I, "  have hmP : (finMsg S samp n (pairSndD (pairEncode (pairFstD (S.gen.runAt n [] rg)) (samp.advice n)))\n",
     "  have hmP : (finMsg S samp n\n      (pairSndD (pairEncode (pairFstD (S.gen.runAt n [] rg)) (samp.advice n)))\n")
e(I, "        (fun p => if (recDist S pl r X).distinguisherL n (S.nmOutput (pairSndD (S.gen.runAt n [] rg))\n",
     "        (fun p => if (recDist S pl r X).distinguisherL n\n          (S.nmOutput (pairSndD (S.gen.runAt n [] rg))\n")
e(I, "`seedEquivPoly`, `seedEquiv`, `expect_sample_prod`) and the distinguisher's as `X`'s; pointwise this is\n",
     "`seedEquivPoly`, `seedEquiv`, `expect_sample_prod`) and the distinguisher's as `X`'s; pointwise\nthis is\n")
# Recover
e(Rc, "ciphertext and the encoding of its copy flag, on the context `⟨1^n, _⟩`: `COPY` if `guessBit (v₁ ‖ v₂)`,\n",
      "ciphertext and the encoding of its copy flag, on the context `⟨1^n, _⟩`: `COPY` if\n`guessBit (v₁ ‖ v₂)`,\n")
e(Rc, "/-- `entF S ctx ch = if guessBit (ch.drop (msgLen + 1)) then COPY else false :: ch.take (msgLen + 1)`. -/\n",
      "/-- `entF S ctx ch =\nif guessBit (ch.drop (msgLen + 1)) then COPY else false :: ch.take (msgLen + 1)`. -/\n")
e(Rc, "`E` (`chunkMap` of `entF` over the first `r` groups of three decryptions) and the bits `B` (`chunkMap`\n",
      "`E` (`chunkMap` of `entF` over the first `r` groups of three decryptions) and the bits `B`\n(`chunkMap`\n")
e(Rc, "  have hcut : ∀ p : PolyExpr, PolyTimeComputable (fun z => (pairSndD z).take (p.eval (pairFstD z).length)) ∧\n",
      "  have hcut : ∀ p : PolyExpr,\n      PolyTimeComputable (fun z => (pairSndD z).take (p.eval (pairFstD z).length)) ∧\n")
for h in ('h1', 'h2a', 'h3'):
    e(Rc, f"  have {h} : PolyTimeComputable fun z => (chunkMap ((PolyExpr.const 2).mul (S.msgLen.add (.const 1))) bitG\n",
          f"  have {h} : PolyTimeComputable fun z =>\n      (chunkMap ((PolyExpr.const 2).mul (S.msgLen.add (.const 1))) bitG\n")
e(Rc, "    (hL : 0 < S.msgLen.eval n) (z ω st : List Bool) (hz : pairFstD z = pairFstD (S.gen.runAt n [] rg))\n",
      "    (hL : 0 < S.msgLen.eval n) (z ω st : List Bool)\n    (hz : pairFstD z = pairFstD (S.gen.runAt n [] rg))\n")
e(Rc, "        (encBit S samp (pairEncode (List.replicate n true) (pairEncode z (pairEncode ω st))) x)).drop 1 ++\n",
      "        (encBit S samp (pairEncode (List.replicate n true) (pairEncode z (pairEncode ω st)))\n          x)).drop 1 ++\n")
e(Rc, "  have henc : ∀ y, encBit S samp (pairEncode (List.replicate n true) (pairEncode z (pairEncode ω st)))\n",
      "  have henc : ∀ y,\n      encBit S samp (pairEncode (List.replicate n true) (pairEncode z (pairEncode ω st)))\n")
e(Rc, "  have he : ∀ x, (encBit S samp ctx x).length = S.ctLen.eval n := fun x => length_encBit S samp n _ x\n",
      "  have he : ∀ x, (encBit S samp ctx x).length = S.ctLen.eval n := fun x =>\n    length_encBit S samp n _ x\n")
# Reduction
e(Rd, "def encPair (ctx : List Bool) (x : Bool) : List Bool := encBit S samp ctx x ++ encBit S samp ctx (!x)\n",
      "def encPair (ctx : List Bool) (x : Bool) : List Bool :=\n  encBit S samp ctx x ++ encBit S samp ctx (!x)\n")
e(Rd, "theorem polyTimeComputable_encF : PolyTimeComputable fun z => encF S samp (pairFstD z) (pairSndD z) := by\n",
      "theorem polyTimeComputable_encF :\n    PolyTimeComputable fun z => encF S samp (pairFstD z) (pairSndD z) := by\n")
e(Rd, "theorem polyTimeComputable_bitF : PolyTimeComputable fun z => bitF S samp (pairFstD z) (pairSndD z) :=\n",
      "theorem polyTimeComputable_bitF :\n    PolyTimeComputable fun z => bitF S samp (pairFstD z) (pairSndD z) :=\n")
e(Rd, "      ((List.range (r.eval n)).map fun i => encF S samp ctx (chunkAt (S.ctLen.eval n) i a)).flatten ++\n",
      "      ((List.range (r.eval n)).map fun i =>\n        encF S samp ctx (chunkAt (S.ctLen.eval n) i a)).flatten ++\n")
e(Rd, "Definition 171.5 on T2's lengths): the first challenge `a` asks the challenge `⟨m, m̃⟩` (oracle `1`),\n",
      "Definition 171.5 on T2's lengths): the first challenge `a` asks the challenge `⟨m, m̃⟩`\n(oracle `1`),\n")
e(Rd, "    (chalHandler (nmParams S samp pl hl hist hist_poly r sl)).advInput n (pairEncode pk α) ω = pk := by\n",
      "    (chalHandler (nmParams S samp pl hl hist hist_poly r sl)).advInput n (pairEncode pk α) ω =\n      pk := by\n")
e(Rd, "theorem length_nmOutL (e a aP mP : List Bool) (ha : a.length = r.eval n * S.ctLen.eval n + sl.eval n)\n",
      "theorem length_nmOutL (e a aP mP : List Bool)\n    (ha : a.length = r.eval n * S.ctLen.eval n + sl.eval n)\n")
e(Rd, "`(empty, none)`; the challenge `y` on `a` is `(⟨y, h(M(a; ρ)), a⟩, some (y, ⟨M(a; ρ), M(a; ρ̃)⟩))`. -/\n",
      "`(empty, none)`; the challenge `y` on `a` is\n`(⟨y, h(M(a; ρ)), a⟩, some (y, ⟨M(a; ρ), M(a; ρ̃)⟩))`. -/\n")
e(Rd, "`⟨pk, M.advice n⟩` and the seed `ρ ‖ ρ̃ ‖ re`, the composition of `NM_b`'s oracles (the hybrid oracle\n",
      "`⟨pk, M.advice n⟩` and the seed `ρ ‖ ρ̃ ‖ re`, the composition of `NM_b`'s oracles (the hybrid\noracle\n")
e(Rd, "          (List.ofFn x) (pairEncode (pairEncode (List.replicate ((1 : Fin 2) : ℕ) true) (pairEncode q t))\n",
      "          (List.ofFn x)\n          (pairEncode (pairEncode (List.replicate ((1 : Fin 2) : ℕ) true) (pairEncode q t))\n", 2)
e(Rd, "      have hlen : (List.ofFn (drawWith samp (S.msgLen.eval n) n (padFin (pl.eval n) (List.ofFn x)) ρ)\n",
      "      have hlen : (List.ofFn (drawWith samp (S.msgLen.eval n) n (padFin (pl.eval n) (List.ofFn x))\n            ρ)\n")
# Rounds
e(Ro, "* **Readers of a round input** `⟨⟨1^n, ⟨z, ω⟩⟩, ⟨s, ⟨⟨1^i, x⟩, L⟩⟩⟩` (`rdU`, `rdZ`, `rdW`, `rdState`,\n",
      "* **Readers of a round input** `⟨⟨1^n, ⟨z, ω⟩⟩, ⟨s, ⟨⟨1^i, x⟩, L⟩⟩⟩` (`rdU`, `rdZ`, `rdW`,\n  `rdState`,\n")
# SimIND
e(SI, "/-- **The CCA oracles of `Ind_β` are the hybrid oracle with the sampler's coin `β`** (on T2's lengths\n",
      "/-- **The CCA oracles of `Ind_β` are the hybrid oracle with the sampler's coin `β`** (on T2's\nlengths\n")
e(SI, "`castImpl (Ind_β) i x (s.map fst) = (rImpl … (coin β) … i x s).bind fun p => pure (p.1, p.2.map fst)`.\n",
      "`castImpl (Ind_β) i x (s.map fst) =\n(rImpl … (coin β) … i x s).bind fun p => pure (p.1, p.2.map fst)`.\n")
e(SI, "                (cast (S.indSpec_challengeDom n) (padFin (S.inLens n 1) (List.ofFn x)))).1))) re) := by\n",
      "                (cast (S.indSpec_challengeDom n)\n                  (padFin (S.inLens n 1) (List.ofFn x)))).1))) re) := by\n")
e(SI, "theorem nmOutput_eq_entryTails (n ℓ : ℕ) (sk : List Bool) (s' : Option (Fin (S.ctLen.eval n) → Bool))\n",
      "theorem nmOutput_eq_entryTails (n ℓ : ℕ) (sk : List Bool)\n    (s' : Option (Fin (S.ctLen.eval n) → Bool))\n")
# SimINDGap
e(SG, "`c`, `b`, then `2·((𝔼T₀ + 𝔼T₁)/2) − (𝔼H₀ + 𝔼H₁)/2 = 𝔼V₁ − 𝔼V₀` (uniform samples; `e` a bijection). -/\n",
      "`c`, `b`, then `2·((𝔼T₀ + 𝔼T₁)/2) − (𝔼H₀ + 𝔼H₁)/2 = 𝔼V₁ − 𝔼V₀` (uniform samples; `e` a\nbijection). -/\n")
e(SG, "/-- **The SIM adversary's handler** for an NM adversary with `ℓ` output ciphertexts: `copyHandler` on\n",
      "/-- **The SIM adversary's handler** for an NM adversary with `ℓ` output ciphertexts:\n`copyHandler` on\n")
e(SG, "    simHandler S ℓ = copyHandler S (S.msgLen.add S.msgLen) (.const 0) ((ℓ.mul S.ctLen).add (.const 0)) :=\n",
      "    simHandler S ℓ =\n      copyHandler S (S.msgLen.add S.msgLen) (.const 0) ((ℓ.mul S.ctLen).add (.const 0)) :=\n")
e(SG, "          expect (runB S atk A (q.eval n) (ℓ.eval n) n (fun _ => []) (pairFstD (S.gen.runAt n [] rg))\n",
      "          expect (runB S atk A (q.eval n) (ℓ.eval n) n (fun _ => [])\n            (pairFstD (S.gen.runAt n [] rg))\n", 2)
e(SG, "              (pairSndD (S.gen.runAt n [] rg)) ((halfCoins S n).symm false) (List.ofFn p.1) p.2) rX =\n",
      "              (pairSndD (S.gen.runAt n [] rg)) ((halfCoins S n).symm false) (List.ofFn p.1)\n              p.2) rX =\n")
e(SG, "          (fun _ => (PolyExpr.const 0).eval n) (r * (S.ctLen.eval n + 1) + (PolyExpr.const 0).eval n))\n",
      "          (fun _ => (PolyExpr.const 0).eval n)\n          (r * (S.ctLen.eval n + 1) + (PolyExpr.const 0).eval n))\n")
# Simulator
e(Sm, "    simFin S r (InteractiveHandler.finInput n z ω s a L) = pairEncode [true] (simOutL S r n s a) := by\n",
      "    simFin S r (InteractiveHandler.finInput n z ω s a L) =\n      pairEncode [true] (simOutL S r n s a) := by\n")
e(Sm, "/-- **The dummy challenge in a round of the simulator** (input `⟨pk, M.advice n⟩`, seed `ρ̃ ‖ re`, on\n",
      "/-- **The dummy challenge in a round of the simulator** (input `⟨pk, M.advice n⟩`, seed\n`ρ̃ ‖ re`, on\n")
e(Sm, "`⟨Enc_pk(M(a; ρ̃); re), h(M(a; ρ))⟩` (`chalHandler_impl_none`, `simCt_input`, `rImpl_none_eager`). -/\n",
      "`⟨Enc_pk(M(a; ρ̃); re), h(M(a; ρ))⟩` (`chalHandler_impl_none`, `simCt_input`,\n`rImpl_none_eager`). -/\n")
e(Sm, "        (simParams S samp pl hl r sl).qry (InteractiveHandler.input n (pairEncode pk (samp.advice n))\n",
      "        (simParams S samp pl hl r sl).qry\n          (InteractiveHandler.input n (pairEncode pk (samp.advice n))\n")
e(Sm, "        (simParams S samp pl hl r sl).ansH (InteractiveHandler.input n (pairEncode pk (samp.advice n))\n",
      "        (simParams S samp pl hl r sl).ansH\n          (InteractiveHandler.input n (pairEncode pk (samp.advice n))\n")
e(Sm, "      (ω : Fin ((chalHandler (simParams S samp pl hl r sl)).seedLen.eval n) → Bool) (rA : A.Coins n),\n",
      "      (ω : Fin ((chalHandler (simParams S samp pl hl r sl)).seedLen.eval n) → Bool)\n      (rA : A.Coins n),\n")
e(Sm, "      (chalHandler (simParams S samp pl hl r sl)).finish n z ω st a = .pure (padFin _ (simOutL S r n (List.ofFn st) (List.ofFn a))) :=\n",
      "      (chalHandler (simParams S samp pl hl r sl)).finish n z ω st a =\n        .pure (padFin _ (simOutL S r n (List.ofFn st) (List.ofFn a))) :=\n")
e(Sm, "    exact OracleComp.costBoundedBy_pure _ _ _), ← hφ z ω rA, simParams_advInput, chalHandler_init, simulate_bind,\n",
      "    exact OracleComp.costBoundedBy_pure _ _ _), ← hφ z ω rA, simParams_advInput, chalHandler_init,\n    simulate_bind,\n")
files = {}
for f, old, new, cnt in E:
    s = files.get(f) or open(root + f, encoding='utf-8').read()
    assert s.count(old) == cnt, (f, old[:70], s.count(old), cnt)
    assert old.split() == new.split() or f == H, (f, old[:50])
    files[f] = s.replace(old, new)
for f, s in files.items():
    open(root + f, 'w', encoding='utf-8').write(s)
    bad = [(i, len(l)) for i, l in enumerate(s.split('\n'), 1) if len(l) > 100]
    assert not bad, (f, bad)
print('applied', sum(c for *_, c in E), 'replacements in', len(files), 'files; all lines <= 100')
