"""census.py <issued base-sorries> <landing-head base-sorries (fillinputs)> <bootstrap results.jsonl> <out>:
per-module sorry counts: issued base (source), landing head (source), landing head (build warnings)."""
import sys, json, re
def load(p):
    d = {}
    for l in open(p):
        m = re.match(r'^(\S+): (\d+): (.*)$', l.strip())
        if m:
            k = m.group(1); k = k if k.startswith('TCSlib/') else 'TCSlib/Complexity/' + k
            d[k] = (int(m.group(2)), [x.strip() for x in m.group(3).split(',')])
    return d
iss, head = load(sys.argv[1]), load(sys.argv[2])
build = {}
for l in open(sys.argv[3]):
    r = json.loads(l)
    if 'module' in r: build[r['module']] = r['sorry']
out = open(sys.argv[4], 'w')
ti = th = tb = 0
for k in sorted(set(iss) | set(head) | {m for m, c in build.items() if c}):
    a = iss.get(k, (0, []))[0]; b = head.get(k, (0, []))[0]; c = build.get(k)
    ti += a; th += b; tb += c or 0
    rem = sorted(set(iss.get(k, (0, []))[1]) - set(head.get(k, (0, []))[1]))
    add = sorted(set(head.get(k, (0, []))[1]) - set(iss.get(k, (0, []))[1]))
    tag = 'OK  ' if a == b == c else 'DIFF'
    out.write(f"{tag} {k}: issued-base {a} landing-head(src) {b} landing-head(build) {c}" + (f"   removed {rem}" if rem else '') + (f"   added {add}" if add else '') + '\n')
out.write(f"TOTAL issued-base {ti} landing-head(src) {th} landing-head(build) {tb}\n")
