import Lean
import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation

/-! nm-sim review: axioms of the two targets and of simNMSecure_cpa_iff_nmSecure_cpa (explicit
`#print axioms`), and of every stored constant of the eleven changed/new modules (collectAxioms). -/

set_option maxHeartbeats 0

#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_of_simNMSecure
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_of_nmSecure_cpa
#print axioms TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let owners : List Name := [`TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Generic, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Hybrid,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimIND, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.SimINDGap, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Rounds,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Challenge, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Simulator, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Reduction,
    `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.Recover, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation.IndSim, `TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation]
  for (c, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    IO.println s!"AX {home} {c} {axs.toList}"
