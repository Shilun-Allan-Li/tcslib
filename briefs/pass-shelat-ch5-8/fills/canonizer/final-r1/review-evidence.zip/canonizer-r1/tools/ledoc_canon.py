"""ledoc_canon.py <worktree>: the canonizer landing edit LE-doc (docstring only): the formula of
exists_codeCanonizer (Universal/Canonizer.lean), the one new public declaration docaudit flagged."""
import sys
wt = sys.argv[1]
F = 'TCSlib/Cryptography/Asymptotic/Universal/Canonizer.lean'
a = """(malformed codes included: they decode to the fallback machine).

**Proof sketch.** `Turing.MachineFormat.exists_polyCanonizer`"""
b = """(malformed codes included: they decode to the fallback machine):
`∃ C d, C.ComputesFunInTime (fun α => (codeDecode α).serialize) fun n => d * (n + 1) ^ d`.

**Proof sketch.** `Turing.MachineFormat.exists_polyCanonizer`"""
p = f'{wt}/{F}'; s = open(p, encoding='utf-8').read()
assert s.count(a) == 1
open(p, 'w', encoding='utf-8').write(s.replace(a, b)); print('LE-doc applied')
