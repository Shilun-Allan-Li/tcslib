import Lean
import TCSlib.Cryptography.Asymptotic.Universal

/-! canonizer review: dependency trace of `exists_canonizerExp`. Walks the transitive closure of the
constants used by the target (types and values) and reports whether the admitted
`Turing.FinTM.appendBitTM_computes` and the proved `Turing.FinTM.computesFunInTime_appendBit` are
in it, together with the axioms. -/

set_option maxHeartbeats 0
open Lean Elab Command

#print axioms TCSlib.Cryptography.exists_canonizerExp
#print axioms Turing.MachineFormat.exists_polyCanonizer
#print axioms Turing.FinTM.computesFunInTime_appendBit
#print axioms Turing.FinTM.appendBitTM_computes

run_cmd do
  let env ← getEnv
  let root := `TCSlib.Cryptography.exists_canonizerExp
  let mut seen : NameSet := {}
  let mut todo : Array Name := #[root]
  while !todo.isEmpty do
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | some ci =>
      for c in ci.getUsedConstantsAsSet.toList do
        unless seen.contains c do todo := todo.push c
    | none => pure ()
  logInfo m!"DEPTRACE closure size {seen.size}"
  for t in [`Turing.FinTM.appendBitTM_computes, `Turing.FinTM.computesFunInTime_appendBit,
      `Turing.MachineFormat.exists_polyCanonizer, `Turing.oneTapeFormat_serialize_decode,
      `Turing.oneTapeMachineFormat_serialize_decode, `sorryAx] do
    logInfo m!"DEPTRACE {t} in closure: {seen.contains t}"
