# canonizer · pre-approved scope exception (Seyoon, 2026-11-14)

Seyoon pre-approved exactly the two `rfl` readers named in the brief's checkpoint 1. The worker does not need to
send a scope request for them.

1. In `TCSlib/Complexity/TuringMachine/CodeFormat.lean`:
   `oneTapeFormat.serialize (oneTapeFormat.decode xs) = (codeDecode xs).serialize`.
2. In `TCSlib/Complexity/TuringMachine/CodeSimulator.lean`:
   `oneTapeMachineFormat.serialize (oneTapeMachineFormat.decode α) = oneTapeFormat.serialize (oneTapeFormat.decode α)`.

Requirements for both readers:
- Each is proved by `rfl` in its own file and placed beside the definitions.
- Each carries a formula docstring and no attribute.
- Each is stated between `List Bool` values.

The worker must still include the seal probe that shows each reader is needed.

Any other change to a frozen file still needs a scope request. That includes a different statement, a third
reader, or any change to an existing declaration.
