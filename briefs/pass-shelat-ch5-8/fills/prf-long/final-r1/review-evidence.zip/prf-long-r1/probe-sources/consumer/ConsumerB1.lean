import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti
import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.MultiMsgOut

/-! prf-long review, consumer probe (reviewer-written): the delivered D1/D3/D4 names resolve and apply
inside the merged B1 module's namespace (`TCSlib.Cryptography.SecureComputation`, with its `open`s),
at the hypothesis `hG : PRFOut ℓ G` of `sliceMultiMessageSecure_of_prfOut`, and the slice sampler's
seed space is the seed space of `prfEncRealOut (G n)` (no coin relabelling needed). -/

namespace TCSlib.Cryptography.SecureComputation

open Complexity Turing TCSlib.Cryptography

-- step 3: the total at the B1 hypothesis, for an arbitrary (post-processing) distinguisher `D'`
example {ℓ : PolyExpr} {G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (ℓ.eval n) → Bool)}
    (hG : PRFOut ℓ G) (D' : NUPPT) (q : PolyExpr) :
    ∃ ε : ℕ → ℝ, Negligible ε ∧ ∀ n (w w' : Fin (q.eval n + 1) → Fin (ℓ.eval n) → Bool),
      distAdv (fun z => encodeTupleOut (prfEncRealOut (G n) w z))
        (fun z => encodeTupleOut (prfEncRealOut (G n) w' z)) (D'.distinguisherL n) ≤ ε n :=
  MultiMsg.exists_negligible_distAdv_prfEncRealOut hG.pseudorandom D' q

-- the seeds of the slice sampler and of the ℓ-output real hybrid are the same type
example {ℓ : PolyExpr} (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (ℓ.eval n) → Bool)) (n q : ℕ)
    (o len : Fin (q + 1) → ℕ) (m : ∀ i, Fin (len i) → Bool) (w : Fin (q + 1) → Fin (ℓ.eval n) → Bool)
    (t : (Fin n → Bool) × (Fin (q + 1) → Fin n → Bool)) :
    (sliceMultiEncDist G n q o len m t, encodeTupleOut (prfEncRealOut (G n) w t)) =
      (sliceMultiEncDist G n q o len m t, encodeTupleOut (prfEncRealOut (G n) w t)) := rfl

-- the entries of the ℓ-output real hybrid read through the published reader
example {ℓ : PolyExpr} (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (ℓ.eval n) → Bool)) (n q : ℕ)
    (w : Fin (q + 1) → Fin (ℓ.eval n) → Bool) (t : (Fin n → Bool) × (Fin (q + 1) → Fin n → Bool))
    (j : Fin (q + 1)) : prfEncRealOut (G n) w t j = (t.2 j, w j + G n t.1 (t.2 j)) :=
  prfEncRealOut_apply (G n) w t j

-- step 1 / `spDecStr_wrongKey`: the one-query machine and its negligible PRF advantage (budget 1)
example (ℓ : PolyExpr)
    (G' : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin ((PolyExpr.add .var ℓ).eval n) → Bool))
    (hG' : PRFOut (.add .var ℓ) G') (D : NUPPT) :
    ∃ B : NUPPT, (∀ n, ∃ φ : (Fin n → Bool) × D.Coins n ≃ B.Coins n,
      ∀ (g : (Fin n → Bool) → (Fin ((PolyExpr.add .var ℓ).eval n) → Bool)) (r : Fin n → Bool)
        (c : D.Coins n),
        (B.toOracleAdversary n n ((PolyExpr.add .var ℓ).eval n) 1 (φ (r, c))).eval g =
          decide (D.runAt n (pairEncode (List.ofFn r) (List.ofFn (g r))) c = [true])) ∧
      Negligible fun n => prfAdv (G' n) (B.toOracleAdversary n n ((PolyExpr.add .var ℓ).eval n) 1) := by
  obtain ⟨B, hB⟩ := MultiMsg.exists_oneQuery_nuppt D (.add .var ℓ)
  exact ⟨B, hB, by simpa only [PolyExpr.eval_const] using hG'.pseudorandom.negligible_prfAdv B (.const 1)⟩

end TCSlib.Cryptography.SecureComputation
