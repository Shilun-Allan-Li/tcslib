import Lean
import TCSlib.Cryptography.SecureComputation.ComposeSecurity
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Accept
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Assembly
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Bounds
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Chain
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Correct
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Efficiency
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Lengths
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Machines
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Probability
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Reductions
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Runs
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.SideA
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.SideB
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Sim
import TCSlib.Cryptography.SecureComputation.ComposeSecurity.Template
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-compose review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.composeP_efficient
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.composeV_efficient
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.hbcSecure_compose
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.polyTime_compose
#print axioms TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.exists_simA
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.exists_simB
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.realA_compose_sampleA
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.exists_gapA
#print axioms TCSlib.Cryptography.SecureComputation.HybridProtocol.acceptProb_realA_dPhi
#print axioms TCSlib.Cryptography.SecureComputation.ComposeProb.abs_chain_le
#print axioms TCSlib.Cryptography.SecureComputation.ComposeSim.exists_gap_le
#print axioms TCSlib.Cryptography.SecureComputation.ComposeSim.exists_simulator
#print axioms TCSlib.Cryptography.SecureComputation.ComposeMachines.polyTimeComputable_flatMap_range

def owners : List Name := [`TCSlib.Cryptography.SecureComputation.ComposeSecurity,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Accept,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Assembly,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Bounds,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Chain,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Correct,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Efficiency,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Lengths,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Machines,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Probability,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Reductions,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Runs,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.SideA,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.SideB,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Sim,
  `TCSlib.Cryptography.SecureComputation.ComposeSecurity.Template]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

