import Lean
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-compose review (copy of the sc-garble DepTrace): the admitted declarations (`sorryAx` occurring directly in the value) in the transitive
constant closure of `yaoProtocol_hbcSecure` and `yaoHybrid_hbcSecure`. -/

open Lean Elab Command

def directSorry (ci : ConstantInfo) : Bool :=
  match ci.value? (allowOpaque := true) with
  | some v => v.getUsedConstants.contains ``sorryAx
  | none => false

partial def sgClosure (env : Environment) (root : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut stack := [root]
  while !stack.isEmpty do
    let c := stack.head!; stack := stack.tail!
    if seen.contains c then continue
    seen := seen.insert c
    if let some ci := env.find? c then
      for d in ci.type.getUsedConstants ++ ((ci.value? (allowOpaque := true)).map (·.getUsedConstants)).getD #[] do
        unless seen.contains d do stack := d :: stack
  return seen

run_cmd do
  let env ← getEnv
  for r in [``TCSlib.Cryptography.SecureComputation.yaoProtocol_hbcSecure,
            ``TCSlib.Cryptography.SecureComputation.yaoHybrid_hbcSecure] do
    let s := sgClosure env r
    let mut hits : Array String := #[]
    for c in s.toList do
      if let some ci := env.find? c then
        if directSorry ci then hits := hits.push c.toString
    IO.println s!"TRACE {r}: closure {s.size} constants; admitted (direct sorryAx): {hits.qsort (· < ·)}"
