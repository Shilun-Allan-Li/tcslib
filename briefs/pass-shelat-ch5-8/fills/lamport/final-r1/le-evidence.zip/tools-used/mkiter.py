"""mkiter.py <old-probe> <old-json> <new-source> <out-probe>: iteration-only seal probe.
Splices <new-source> into the reviewed probe: probe prefix through the seal preamble, the new
source after its import block (same byte offset as the reviewed one), then the EOF verifier."""
import sys, json
op, oj, ns, out = sys.argv[1:5]
p = open(op, 'rb').read(); j = json.load(open(oj)); s = open(ns, 'rb').read()
ins = {i['kind']: i for i in j['insertions']}
pre = ins['seal_preamble']; eof = ins['seal_eof_verifier']
assert pre['original_byte_offset'] == 350
cut = pre['probe_byte_offset'] + pre['byte_count']
ver = p[eof['probe_byte_offset']:eof['probe_byte_offset'] + eof['byte_count']]
old_src_head = p[:pre['probe_byte_offset']]
assert old_src_head.replace(b'import Lean\n', b'', 1) == s[:350], 'import block changed'
open(out, 'wb').write(p[:cut] + s[350:] + ver)
print('ok', len(p[:cut]), len(s) - 350, len(ver))
