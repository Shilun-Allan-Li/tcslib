# ledoc_spec.py: the lamport LE-doc texts for ledoc_edit.py.
# SPEC[file][declaration short name] = (new first paragraph, new proof-sketch paragraph or None).
# Each new first paragraph repeats the old first paragraph's words and adds a backticked formula
# transcribed from the Lean statement (defs: the defining equation, or the declared type for an
# equivalence whose `_apply`/`_eq` reader follows). `LamportFill.` prefixes are omitted in
# Lamport.lean, as is usual inside the namespace's documentation.
B = 'TCSlib/Cryptography/Authentication/Signatures/'
D = B + 'Lamport/'
SPEC = {}

ADV = ("`adv Y r = A.toCompOn (bitCodec (fun _ : Fin 1 => n) (fun _ => n * n) (n + n * n)) "
       "n 1 (publicWord Y) r`")
SPEC[B + 'Lamport.lean'] = {
 'lamportGen_coins': ("Lamport's generator uses the coin polynomial `2n²`: "
   "`(lamportGen hE).coins = .mul (.mul (.const 2) .var) .var`.", None),
 'lamportGen_coinLen': ("The generator's coin tape has `2n²` bits at parameter `n`: "
   "`(lamportGen hE).coinLen n = 2 * n * n`.", None),
 'lamportCoinTables': ("Lamport's generator coin tapes are equivalent to its row-major preimage "
   "tables: `lamportCoinTables hE n : (lamportGen hE).Coins n ≃ Table n`.", None),
 'lamportCoinTables_eq': ("The coin-table equivalence first casts the tape width to `2n²`, then "
   "groups its blocks: `lamportCoinTables hE n = (Equiv.arrowCongr (finCongr (lamportGen_coinLen "
   "hE n)) (Equiv.refl Bool)).trans (tableCoins n)`.", None),
 'lamportCoinTables_symm': ("The inverse coin-table equivalence serializes the table and casts "
   "back to the generator's declared coin length: `(lamportCoinTables hE n).symm T = "
   "(Equiv.arrowCongr (finCongr (lamportGen_coinLen hE n).symm) (Equiv.refl Bool)) "
   "((tableCoins n).symm T)`.", None),
 'ofFn_lamportCoinTables_symm': ("The coin tape for table `T` is exactly its row-major secret "
   "word: `List.ofFn ((lamportCoinTables hE n).symm T) = secretWord T`.", None),
 'secretWord_lamportCoinTables': ("Serializing the table of a generator coin tape recovers that "
   "tape's word: `secretWord (lamportCoinTables hE n ρ) = List.ofFn ρ`.", None),
 'lamportSign_coins': ("Lamport's deterministic signer uses the zero coin polynomial: "
   "`lamportSign.coins = .const 0`.", None),
 'runAt_lamportGen_table': ("On a serialized preimage table, key generation returns its public "
   "images and the table itself [PS10, Protocol 137.1]: if `List.ofFn ρ = secretWord T`, then "
   "`(lamportGen hE).runAt n [] ρ = pairEncode (publicWord (tablePublic (f n) T)) "
   "(secretWord T)`.",
   "**Proof sketch.** Block `i` of `secretWord T` is `T (i, false) ‖ T (i, true)` "
   "(`coinBlock_flatten_ofFn`); `lamportHalf` reads its halves, and `hfE` maps them to their "
   "images."),
 'runAt_lamportSign_table': ("On a serialized preimage table, signing returns the typed "
   "signature selected from that table, independently of its signing coins [PS10, Protocol "
   "137.1]: `lamportSign.runAt n (pairEncode (secretWord T) (List.ofFn m)) r = "
   "List.ofFn (tableSignature T m)`.", None),
 'lamportGenFun_table': ("On the canonical layout of a table, the generator string function "
   "returns its public images paired with its secret serialization [PS10, Protocol 137.1]: "
   "`lamportGenFun E (NUPPT.layout (List.replicate n true) [] [] (secretWord T)) = "
   "pairEncode (publicWord (tablePublic (f n) T)) (secretWord T)`.", None),
 'lamportSignFun_table': ("On the canonical signing layout, the signing string function returns "
   "the selected preimage vector [PS10, Protocol 137.1]: `lamportSignFun (NUPPT.layout "
   "(List.replicate n true) (pairEncode (secretWord T) (List.ofFn m)) [] []) = "
   "List.ofFn (tableSignature T m)`.", None),
 'lamportVerFun_publicWord_iff': ("Verification of a typed public table accepts exactly when "
   "each signature block maps to the image selected by the corresponding message bit [PS10, "
   "Protocol 137.1]: `lamportVerFun L E (atParam n (pairEncode (publicWord Y) (pairEncode "
   "(List.ofFn m) (List.ofFn σ)))) = [true] ↔ ∀ i, f n (signatureBlock σ i) = Y (i, m i)`.",
   None),
 'lamport_forgerCodec': ("Lamport's forger codec is the canonical bit codec with query width "
   "`n`, answer width `n²` and final width `n+n²`: `(lamport L f E hE hfE).forgerCodec n = "
   "bitCodec (fun _ : Fin 1 => n) (fun _ => n * n) (n + n * n)`.", None),
 'lamport_signImpl_expect': ("Against a serialized key table, every Lamport signing call has "
   "exactly the deterministic selected-preimage law. The equality holds for every function of "
   "the answer and state: `ProbComp.expect ((lamport L f E hE hfE).signImpl n (secretWord T) i m "
   "s) G = ProbComp.expect (tableSigner T i m s) G`.", None),
 'lamport_loggedSignImpl_expect': ("Logging preserves the equality between actual Lamport "
   "signing and typed table signing, including the full appended query and answer log: "
   "`ProbComp.expect (((lamport L f E hE hfE).signImpl n (secretWord T)).withLog i m s) G = "
   "ProbComp.expect ((tableSigner T).withLog i m s) G`.", None),
 'lamport_forgeGame_accept_eq_honestProbability': ("The actual one-query Lamport forgery game "
   "has exactly the typed honest-table success probability [PS10, Definition 136.2 and proof "
   "of Theorem 137.2]: `accept ((lamport L f E hE hfE).forgeGame A 1 n) = honestProbability "
   "(f n) adv`, where " + ADV + ".", None),
 'lamport_exists_best_position': ("For every positive parameter, some fixed position with a "
   "fair planted bit gives reduction success at least the actual one-query forgery probability "
   "divided by `2n` [PS10, averaging step in the proof of Theorem 137.2]: if `0 < n`, then "
   "`∃ i : Fin n, accept ((lamport L f E hE hfE).forgeGame A 1 n) / (2 * (n : ℝ)) ≤ "
   "ProbComp.expect (ProbComp.sample Bool) (fun c => redProbability (f n) adv (i, c))`, with "
   "`adv` as in `lamport_forgeGame_accept_eq_honestProbability`.", None),
}

SPEC[D + 'Advice.lean'] = {
 'indexBits_eq': ("The index word is the serialized inverse image of `i` under `bitsEquiv`: "
   "`indexBits n i hi = List.ofFn ((bitsEquiv (Nat.size n)).symm ⟨i, hi.trans_lt "
   "(Nat.lt_size_self n)⟩)`.", None),
 'length_indexBits': ("The binary index word has exactly `Nat.size n` bits: "
   "`(indexBits n i hi).length = Nat.size n`.", None),
 'length_indexBits_le': ("Its logarithmic width is bounded by the polynomial width `n`: "
   "`(indexBits n i hi).length ≤ n`.", None),
 'indexBits_value': ("Reading the binary index word gives the original natural number `i`: "
   "`OneWay.bitListToNat (indexBits n i hi) = i`.", None),
 'expandIndex': ("On a parameter-aware input `⟨1^n,⟨y,b⟩⟩`, decode the bounded binary index "
   "`b` to unary and return `⟨y,U(⟨1^n,b⟩)⟩`: `expandIndex U w = pairEncode (pairFstD "
   "(pairSndD w)) (U (pairEncode (pairFstD w) (pairSndD (pairSndD w))))`.", None),
 'expandIndex_eq': ("The expansion pairs the challenge with `U` applied to the parameter and "
   "binary index: `expandIndex U w = pairEncode (pairFstD (pairSndD w)) (U (pairEncode "
   "(pairFstD w) (pairSndD (pairSndD w))))`.", None),
 'expandIndex_poly': ("Expanding binary index advice is polynomial-time whenever the bounded "
   "decoder is: `PolyTimeComputable U → PolyTimeComputable (expandIndex U)`.", None),
 'expandIndex_advInput': ("On canonical parameter-aware input, the bounded decoder expands `b` "
   "to its unary numeric value: if `OneWay.bitListToNat b ≤ n` and `U (pairEncode p b) = "
   "List.replicate (OneWay.bitListToNat b) true` whenever `OneWay.bitListToNat b ≤ p.length`, "
   "then `expandIndex U (NUPPT.advInput n (pairEncode y b)) = pairEncode y (List.replicate "
   "(OneWay.bitListToNat b) true)`. This reads `advInput` and pairing only through their "
   "public equations.", None),
 'runAt_indexAdvice': ("A same-coins machine with the indexed untyped activation equation has "
   "the corresponding typed activation equation through the published `coinsCongr` "
   "equivalence: if `hcoins : B.coins = A.coins` and `B.runAtL n y r = A.runAtL n (pairEncode "
   "y (List.replicate (i n) true)) r` for all `n`, `y`, `r`, then `B.runAt n y "
   "(NUPPT.coinsCongr hcoins.symm n r) = A.runAt n (pairEncode y (List.replicate (i n) true)) "
   "r`.", None),
}

SPEC[D + 'Averaging.lean'] = {
 'favourable_expect_ge': ("For distinct messages on a nonempty finite position type, uniform "
   "`(i,c)` is jointly favourable with probability at least `1 / (2 |I|)`: if `m ≠ m'`, then "
   "`1 / (2 * (Fintype.card ι : ℝ)) ≤ ProbComp.expect (ProbComp.sample (ι × Bool)) (fun p => "
   "if m p.1 ≠ p.2 ∧ m' p.1 = p.2 then (1 : ℝ) else 0)`. [PS10, proof of Theorem 137.2].",
   None),
 'noQuery_expect_eq_half': ("When there was no signing query, a uniform position and bit agrees "
   "with the forged message bit with probability exactly `1 / 2`: `ProbComp.expect "
   "(ProbComp.sample (ι × Bool)) (fun p => if m' p.1 = p.2 then (1 : ℝ) else 0) = 1 / 2`. "
   "[PS10, proof of Theorem 137.2].", None),
 'exists_expect_sample_le': ("A uniform finite average has a position whose value is at least "
   "the average: `∃ i, ProbComp.expect (ProbComp.sample ι) g ≤ g i`.", None),
 'expect_favourable_of_success': ("If nonnegative favourable mass is at least `b` on every "
   "successful output, its average is at least `b` times the success probability: if "
   "`∀ a, 0 ≤ q a` and `∀ a, P a → b ≤ q a`, then `b * ProbComp.prob c P ≤ ProbComp.expect c "
   "q`. This is the finite averaging step in [PS10, proof of Theorem 137.2].", None),
}

SPEC[D + 'AveragingExtra.lean'] = {
 'optionQuery_favourable_expect_ge': ("If an optional queried message differs from the forged "
   "message, a uniform position and bit avoids revealing the planted preimage and selects the "
   "forged preimage with probability at least `1 / (2 |I|)`: if `q ≠ some m'`, then "
   "`1 / (2 * (Fintype.card ι : ℝ)) ≤ ProbComp.expect (ProbComp.sample (ι × Bool)) (fun p => "
   "if (∀ m, q = some m → m p.1 ≠ p.2) ∧ m' p.1 = p.2 then (1 : ℝ) else 0)`. An absent query "
   "imposes no avoidance constraint. [PS10, proof of Theorem 137.2].", None),
 'exists_position_fairBit_expect_ge': ("For every payoff `v(i,c)` on a nonempty finite position "
   "type and a bit, there is a position whose average over a fair bit is at least the average "
   "over a uniform position and fair bit: `∃ i, ProbComp.expect (ProbComp.sample (ι × Bool)) "
   "(fun p => v p.1 p.2) ≤ ProbComp.expect (ProbComp.sample Bool) (v i)`. [PS10, proof of "
   "Theorem 137.2].", None),
}

SPEC[D + 'Closing.lean'] = {
 'negligible_of_inversion_bound': ("A nonnegative advantage bounded by `2n` times the inversion "
   "probability of a fixed machine against a strong one-way family is negligible for all "
   "parameters, with no condition needed at zero: if `F.StrongOneWay`, `∀ n, 0 ≤ e n` and "
   "`∀ n ≥ 1, e n ≤ 2 * (n : ℝ) * F.invProbAt B n`, then `Negligible e`. [PS10, final step of "
   "the proof of Theorem 137.2].", None),
}

SPEC[D + 'Encoding.lean'] = {
 'encodeList_eq_iff': ("Two nested-pair list encodings agree exactly when their lists of blocks "
   "agree: `encodeList xs = encodeList ys ↔ xs = ys`.", None),
}

COST = "every `adv Y r` has `(adv Y r).CostBoundedBy (fun _ => 1) 1`"
HS = ("`HonestSuccess g adv T r ↔ (∀ j, g (signatureBlock σ j) = g (T (j, m j))) ∧ "
      "firstQuery (adv (tablePublic g T) r) ≠ some m`, where `(m, σ) = splitBits "
      "(honestOutput g adv T r)`")
FAV = ("`Favourable g adv T r p ↔ Safe (adv (tablePublic g T) r) p.1 p.2 ∧ (splitBits "
       "(honestOutput g adv T r)).1 p.1 = p.2`")
RED = ("`RedSuccess g adv y T r p ↔ ∃ a, simulate (abortingImpl T p.1 p.2) (adv (plantedPublic "
       "g T p.1 p.2 y) r) false = .pure (a, false) ∧ g (signatureBlock (splitBits a).2 p.1) = "
       "y`")
HO = "`honestOutput g adv T r = (adv (tablePublic g T) r).evalFn (fun _ m => tableSignature T m)`"
HP = ("`honestProbability g adv = ProbComp.expect (ProbComp.sample (Table n)) (fun T => "
      "ProbComp.expect (ProbComp.sample ρ) fun r => if HonestSuccess g adv T r then 1 else 0)`")
RP = ("`redProbability g adv p = ProbComp.expect (ProbComp.sample (Fin n → Bool)) (fun x => "
      "ProbComp.expect (ProbComp.sample (Table n)) fun T => ProbComp.expect (ProbComp.sample ρ) "
      "fun r => if RedSuccess g adv (g x) T r p then 1 else 0)`")
SPEC[D + 'Experiment.lean'] = {
 'honestOutput': ("Evaluate the forger on the honest public table with deterministic table "
   "signing: " + HO + ".", None),
 'honestOutput_eq': ("The honest output is functional evaluation against the selected-preimage "
   "signing function: " + HO + ".", None),
 'HonestSuccess': ("An honest output succeeds when all its signature blocks verify and its "
   "message was not the optional signing query [PS10, Definition 136.2]: " + HS + ".", None),
 'honestSuccess_iff': ("Honest success is coordinate verification together with inequality to "
   "the optional query: " + HS + ".", None),
 'Favourable': ("A position-bit pair is favorable when its signing query is safe and its forged "
   "message uses the planted bit [PS10, proof of Theorem 137.2]: " + FAV + ".", None),
 'favourable_iff': ("Favorability is signing-query safety conjoined with the forged message's "
   "planted bit: " + FAV + ".", None),
 'RedSuccess': ("The planted reduction succeeds if it ends without abort and its extracted "
   "signature block is a preimage of the challenge [PS10, proof of Theorem 137.2]: " + RED + ".",
   None),
 'redSuccess_iff': ("Reduction success means a pure nonaborting simulation output whose selected "
   "block maps to the challenge: " + RED + ".", None),
 'plantTable_self': ("Replacing a table coordinate by its present value leaves the table "
   "unchanged: `plantTable T i c (T (i, c)) = T`.", None),
 'redSuccess_plant_iff': ("Reduction success ignores the original table preimage at the planted "
   "position: `RedSuccess g adv y (plantTable T p.1 p.2 x) r p ↔ RedSuccess g adv y T r p`.",
   None),
 'diagonal_red_of_success_favourable': ("A favorable successful honest run is a successful "
   "planted reduction when challenged with the image of its own selected table entry [PS10, "
   "proof of Theorem 137.2]: if " + COST + ", `HonestSuccess g adv T r` and `Favourable g adv T "
   "r p`, then `RedSuccess g adv (g (T p)) T r p`.",
   "**Proof sketch.** Planting the present entry `T p` leaves the planted public table equal to "
   "the honest one and the key unchanged (`plantedPublic_image`, `plantTable_self`). Safety then "
   "gives, by `planted_coupling`, the nonaborting output `honestOutput g adv T r`. Acceptance at "
   "position `p.1`, whose forged bit is `p.2`, says that its block maps to `g (T p)`."),
 'favourable_mass_of_success': ("On every successful honest run, favorable position-bit mass is "
   "at least `1/(2n)`; the no-query case has mass exactly `1/2` [PS10, proof of Theorem "
   "137.2]: if `HonestSuccess g adv T r`, then `1 / (2 * (n : ℝ)) ≤ ProbComp.expect "
   "(ProbComp.sample (Fin n × Bool)) (fun p => if Favourable g adv T r p then (1 : ℝ) else 0)`.",
   "**Proof sketch.** Freshness says that the optional first query differs from the forged "
   "message, so `optionQuery_favourable_expect_ge` bounds the mass of the pairs that avoid the "
   "query and select the forged bit. Each such pair is favourable (`favourable_iff`, "
   "`safe_iff`), and expectation is monotone."),
 'honestProbability': ("Honest success probability averages over the complete key table and "
   "forger coins: " + HP + ".", None),
 'honestProbability_eq': ("Honest probability is the nested uniform expectation of the "
   "honest-success indicator: " + HP + ".", None),
 'redProbability': ("The fixed-position reduction's success probability uses an independent "
   "challenge preimage, a complete random table, and forger coins: " + RP + ".", None),
 'redProbability_eq': ("Fixed-position reduction probability is the nested average of its "
   "nonaborting inversion indicator over independent challenge, key-table and forger samples: "
   + RP + ".", None),
 'averaged_redProbability_ge': ("A uniform position-bit planted reduction succeeds with "
   "probability at least the honest forgery probability divided by `2n` [PS10, proof of "
   "Theorem 137.2]: if " + COST + ", then `honestProbability g adv / (2 * (n : ℝ)) ≤ "
   "ProbComp.expect (ProbComp.sample (Fin n × Bool)) (redProbability g adv)`.", None),
 'exists_best_position': ("Some fixed position, while its planted bit remains fair, has "
   "reduction probability at least `H/(2n)` [PS10, proof of Theorem 137.2]: if " + COST +
   ", then `∃ i : Fin n, honestProbability g adv / (2 * (n : ℝ)) ≤ ProbComp.expect "
   "(ProbComp.sample Bool) (fun c => redProbability g adv (i, c))`. This is the position "
   "supplied as advice.", None),
}

SPEC[D + 'InversionProbability.lean'] = {
 'fairBit_redProbability_le_invProbAt': ("Suppose a machine's coins are a fair planting bit, a "
   "complete key table and forger coins, and every successful typed planted run yields the "
   "machine's correctly encoded preimage. Then the typed reduction's success averaged over the "
   "fair bit is at most the machine's inversion probability against the function family: "
   "`ProbComp.expect (ProbComp.sample Bool) (fun c => redProbability (F.f n) adv (i, c)) ≤ "
   "F.invProbAt B n`, provided `RedSuccess (F.f n) adv y T r (i, c) → ∃ x', B.runAt n "
   "(List.ofFn y) (e ((c, T), r)) = List.ofFn x' ∧ F.f n x' = y` for all `y`, `T`, `c`, `r`. "
   "The preimage width is the family's actual input width, so no dependent width casts are "
   "needed. [PS10, proof of Theorem 137.2].", None),
}

SPEC[D + 'Nonabort.lean'] = {
 'safe_of_nonabort': ("A planted run with at most one query ending with a false abort bit "
   "queried no message that reveals the planted cell [PS10, proof of Theorem 137.2]: if "
   "`tree.CostBoundedBy (fun _ => 1) 1` and `simulate (abortingImpl T i c) tree false = .pure "
   "(a', false)`, then `Safe tree i c`.", None),
}

MF = ("A.toCompOn (bitCodec (fun _ : Fin 1 => n) (fun _ => n * n) (n + n * n)) n 1 "
      "(publicWord Y) r")
SPEC[D + 'Realization.lean'] = {
 'machineForger': ("Run a machine forger on the serialized typed public table, using the "
   "canonical message/signature codec and a budget of one signing query: `machineForger L A n "
   "Y r = " + MF + "`.", None),
 'machineForger_eq': ("The typed machine forger is `A.toCompOn` on the serialized public table: "
   "`machineForger L A n Y r = " + MF + "`.", None),
 'machineForger_eq_fun': ("As a function of the public table and coins, the machine forger is "
   "the canonical one-query `toCompOn` construction: `machineForger L A n = fun Y r => " + MF +
   "`. This form also reads it beneath an opaque expectation.", None),
 'machineForger_cost': ("Every typed machine-forger tree has unit-query cost at most one: "
   "`(machineForger L A n Y r).CostBoundedBy (fun _ => 1) 1`.", None),
 'exists_realization_machine': ("The planted experiment's successful nonaborting outputs are "
   "actual inverter outputs: `∃ B : NUPPT, ∀ n, ∃ φ : ((Bool × Table n) × A.Coins n) ≃ "
   "B.Coins n, ∀ i y T c r, RedSuccess (f n) (machineForger L A n) y T r (i, c) → ∃ x', "
   "B.runAt n (pairEncode (List.ofFn y) (List.replicate i.val true)) (φ ((c, T), r)) = "
   "List.ofFn x' ∧ f n x' = y`, given the evaluator, generator, signer and block-reader "
   "contracts `hEval`, `hGen`, `hSign` and `hcoin`. The machine uses one fair seed bit, one "
   "random table, and the forger's own random tape. [PS10, machine-realization step in the "
   "proof of Theorem 137.2].", None),
}

X = "(Equiv.arrowCongr (finCongr (seedCoins_width n)) (Equiv.refl Bool)) x"
SPEC[D + 'Seed.lean'] = {
 'seedCoins_width': ("The seed width `1 + 2n²` is the successor width `2n² + 1`: "
   "`1 + 2 * n * n = 2 * n * n + 1`.", None),
 'seedCoins': ("A seed of `1 + 2n²` bits is equivalent to a Boolean planting bit and a typed "
   "key table: `seedCoins n : (Fin (1 + 2 * n * n) → Bool) ≃ Bool × Table n`. The bit is the "
   "first seed entry and the table occupies the remaining entries in row order.", None),
 'seedCoins_apply': ("`seedCoins n x` consists of the first entry of `x` and the table "
   "represented by its remaining entries, after the equality cast to successor width: "
   "`seedCoins n x = (x' 0, tableCoins n (Fin.tail x'))`, where `x' = " + X + "`.", None),
 'seedCoins_symm': ("The inverse seed equivalence prepends `c` to the coin tape represented by "
   "`T`, and casts back from successor width to `1 + 2n²`: `(seedCoins n).symm (c, T) = "
   "(Equiv.arrowCongr (finCongr (seedCoins_width n).symm) (Equiv.refl Bool)) (Fin.cons c "
   "((tableCoins n).symm T))`.", None),
 'ofFn_seedCoins': ("Every seed word is its extracted planting bit followed by its extracted "
   "key table's serialization: `List.ofFn x = (seedCoins n x).1 :: secretWord (seedCoins n "
   "x).2`.", None),
}

SPEC[D + 'Statistics.lean'] = {
 'coordinate_reduction_bound': ("Suppose every successful honest run has favorable position "
   "mass at least `b`, and every successful favorable run makes a reduction succeed when "
   "challenged at its own table coordinate. If the reduction ignores that original "
   "coordinate, the average reduction success for an independent challenge is at least `b` "
   "times honest success: if `∀ T r, P T r → b ≤ 𝔼 p, [Q T r p]`, `∀ T r p, P T r → Q T r p → "
   "R (T p) T r p` and `∀ x x' T r p, R x (Function.update T p x') r p ↔ R x T r p`, then "
   "`b * 𝔼 T, 𝔼 r, [P T r] ≤ 𝔼 p, 𝔼 x, 𝔼 T, 𝔼 r, [R x T r p]`, writing `𝔼 v, h v` for "
   "`ProbComp.expect (ProbComp.sample V) (fun v => h v)` with `T : Table n`, `r : ρ`, "
   "`p : Fin n × Bool`, `x : Fin n → Bool`, and `[A]` for `if A then (1 : ℝ) else 0`.", None),
}

SPEC[D + 'TableCoins.lean'] = {
 'tableCoins_width': ("The row-major tape width `n(2n)` equals the generator width `2n²`: "
   "`2 * n * n = n * (2 * n)`.", None),
 'tableCoins_apply': ("The cell `(i,c)` of `tableCoins n x` is block `c` of the `i`th "
   "two-preimage row of `x`, with `false` selecting block zero and `true` block one: "
   "`tableCoins n x (i, c) = FunFamily.blocks 2 n (FunFamily.blocks n (2 * n) ((Equiv.arrowCongr "
   "(finCongr (tableCoins_width n)) (Equiv.refl Bool)) x) i) (finTwoEquiv.symm c)`.", None),
 'tableCoins_symm': ("The inverse of `tableCoins` concatenates the two preimage cells of each row "
   "and then concatenates the rows, casting only between the equal widths `n(2n)` and `2n²`: "
   "`(tableCoins n).symm T = (Equiv.arrowCongr (finCongr (tableCoins_width n).symm) (Equiv.refl "
   "Bool)) ((FunFamily.blocks n (2 * n)).symm fun i => (FunFamily.blocks 2 n).symm fun j => "
   "T (i, finTwoEquiv j))`.", None),
}

CTX = "(seedIn n (pairEncode challenge (List.replicate i.val true)) (c :: secretWord T))"
CTXC = ("(seedIn n (pairEncode (List.ofFn challenge) (List.replicate i.val true)) "
        "(c :: secretWord T))")
SPEC[D + 'MachineSpec.lean'] = {
 'publicWord_flatten': ("The serialized public table is the concatenation of its "
   "self-delimiting image-pair blocks: `publicWord Y = (List.ofFn fun i : Fin n => pairEncode "
   "(pairEncode (List.ofFn (Y (i, false))) (List.ofFn (Y (i, true)))) []).flatten`. This reads "
   "the public tuple encoding through `encodeList_eq_flatMap`.", None),
 'first_context': ("Reading the first `n`-bit half of the selected sampled row returns "
   "`T(i,false)`: `LamportMachine.first " + CTX + " = List.ofFn (T (i, false))`.",
   "**Proof sketch.** On this context `first` takes `n` bits of `secretWord T` after the "
   "offset `2n·i` (`first_eq`, `tape_seedIn`, `offset_eq`, `pos_seedIn`, `u_seedIn`). By "
   "`hcoin`, the `2n` bits there are row `i`, that is `T (i, false) ‖ T (i, true)`, and the "
   "first `n` of them are `T (i, false)`."),
 'second_context': ("Reading the second `n`-bit half of the selected sampled row returns "
   "`T(i,true)`: `LamportMachine.second " + CTX + " = List.ofFn (T (i, true))`.",
   "**Proof sketch.** On this context `second` takes `n` bits of `secretWord T` after the "
   "offset `2n·i + n` (`second_eq`, `tape_seedIn`, `offset_eq`, `pos_seedIn`, `u_seedIn`). By "
   "`hcoin`, the `2n` bits after offset `2n·i` are row `i`, that is `T (i, false) ‖ T (i, "
   "true)`, and dropping its first `n` bits leaves `T (i, true)`."),
 'replacement_context': ("The machine's replacement block serializes the planted row, using "
   "the evaluator's published agreement on `n`-bit inputs: `LamportMachine.replacement E " + CTXC
   + " = pairEncode (pairEncode (List.ofFn (plantedPublic g T i c challenge (i, false))) "
   "(List.ofFn (plantedPublic g T i c challenge (i, true)))) []`.", None),
 'advIn_context': ("On a canonical seed context, the machine's public-key input is exactly the "
   "serialized typed planted table: if `W.eval n = 6 * ℓ + 6`, then `LamportMachine.advIn W E "
   "G " + CTXC + " = publicWord (plantedPublic g T i c challenge)`. The only "
   "generator/evaluator facts required are their stated functional contracts; the owned "
   "Lamport module supplies them.", None),
 'headD_drop_ofFn': ("The selected bit of a serialized message is its typed bit at that "
   "position: `((List.ofFn m).drop i.val).headD false = m i`.", None),
 'run_safe': ("A safe query from non-abort state returns the typed signature and a false abort "
   "bit: if `m i ≠ c`, then `LamportMachine.run S (PolyHandler.input n (pairEncode challenge "
   "(List.replicate i.val true)) (c :: secretWord T) [false] j (List.ofFn m)) = pairEncode "
   "(List.ofFn (tableSignature T m)) [false]`.", None),
 'out_nonabort': ("Finalization in non-abort state returns exactly the selected block of the "
   "typed forged signature, after its first `n` message bits: if `LamportMachine.pos (seedIn n "
   "z ρ) = List.replicate i.val true`, then `LamportMachine.out (pairEncode (seedIn n z ρ) "
   "(pairEncode [false] (List.ofFn a))) = List.ofFn (signatureBlock (splitBits a).2 i)`.",
   "**Proof sketch.** With state `[false]`, `out` drops the `n` message bits, then `n·i` more "
   "bits, and takes `n` (`out_eq`, `u_seedIn`, `offset_eq`, `hz`). After the message the word "
   "is `List.ofFn (splitBits a).2` (`splitBits_snd`, `ofFn_natAdd_eq_drop`), and its block `i` "
   "is the signature block (`FunFamily.ofFn_blocks`, `signatureBlock_eq`)."),
}

TREE = "OracleComp (bitSpec (fun _ : Fin 1 => n) (fun _ => n * n)) α"
C1 = "`tree.CostBoundedBy (fun _ => 1) 1`"
EXT = ("`extractionExperiment T i c tree signature = (simulate (abortingImpl T i c) tree "
       "false).bind (fun res => .pure (if res.2 then zeroBits n else signatureBlock (signature "
       "res.1) i))`")
PEX = ("`plantedExperiment g T i c y adv signature = extractionExperiment T i c (adv "
       "(plantedPublic g T i c y)) signature`")
PW = ("`publicWord Y = PrivateKeyScheme.encodeList (List.ofFn fun i : Fin n => pairEncode "
      "(List.ofFn (Y (i, false))) (List.ofFn (Y (i, true))))`")
SW = ("`secretWord T = (List.ofFn fun i : Fin n => List.ofFn (T (i, false)) ++ List.ofFn "
      "(T (i, true))).flatten`")
SPEC[D + 'Planted.lean'] = {
 'Table': ("A table has an `n`-bit preimage at each coordinate `(i,c)`: `Table n = "
   "((Fin n × Bool) → Fin n → Bool)`.", None),
 'publicWord': ("Serialize a public table as the tuple of its pairs of images: " + PW + ".",
   None),
 'publicWord_eq': ("The public word is the tuple of the encoded pairs `⟨Y(i,0),Y(i,1)⟩`: " + PW
   + ".", None),
 'secretWord': ("Serialize a preimage table in row order, with its false and true cells "
   "adjacent: " + SW + ".", None),
 'secretWord_eq': ("The secret word concatenates `T(i,0) ‖ T(i,1)` for consecutive rows `i`: "
   + SW + ".", None),
 'length_secretWord': ("A serialized table contains `n` rows of `2n` bits, hence `2n²` bits: "
   "`(secretWord T).length = 2 * n * n`.", None),
 'plantTable': ("Replace preimage `(i,c)` by `x`, leaving every other cell unchanged: "
   "`plantTable T i c x p = if p = (i, c) then x else T p`.", None),
 'plantTable_eq': ("Planting returns `x` at the selected cell and `T p` elsewhere: "
   "`plantTable T i c x p = if p = (i, c) then x else T p`.", None),
 'plantTable_at': ("The planted cell contains `x`: `plantTable T i c x (i, c) = x`.", None),
 'plantTable_ne': ("A cell different from `(i,c)` retains its original preimage: if "
   "`p ≠ (i, c)`, then `plantTable T i c x p = T p`.", None),
 'plantTable_update': ("Planting a table is the ordinary update of its selected coordinate: "
   "`plantTable T i c x = Function.update T (i, c) x`.", None),
 'tableSignature': ("The signature is the flattened table of preimages selected by the message "
   "bits: `tableSignature T m j = T (k.1, m k.1) k.2` with `k = finProdFinEquiv.symm j`.",
   None),
 'tableSignature_apply': ("At the flattened index for `(i,k)`, the signature reads bit `k` of "
   "`T(i,m i)`: `tableSignature T m (finProdFinEquiv (i, k)) = T (i, m i) k`.", None),
 'ofFn_tableSignature': ("The word of a selected signature concatenates the selected preimage "
   "words: `List.ofFn (tableSignature T m) = (List.ofFn fun i : Fin n => List.ofFn (T (i, m "
   "i))).flatten`.", None),
 'tableSignature_plant_of_safe': ("A message avoiding the planted cell has exactly its original "
   "signature: if `m i ≠ c`, then `tableSignature (plantTable T i c x) m = tableSignature T m`.",
   "**Proof sketch.** Entry `j` of either signature reads the cell `(k.1, m k.1)` with "
   "`k = finProdFinEquiv.symm j`. That cell is not `(i, c)`, since `k.1 = i` would give "
   "`m i = c`, so `plantTable_ne` returns its original preimage."),
 'tablePublic': ("The public table applies the one-way map to every preimage: "
   "`tablePublic g T p = g (T p)`.", None),
 'tablePublic_eq': ("The public image at cell `p` is `g (T p)`: `tablePublic g T p = g (T p)`.",
   None),
 'plantedPublic': ("Replace the public image at `(i,c)` by `y`, without knowing a preimage of "
   "`y`: `plantedPublic g T i c y p = if p = (i, c) then y else g (T p)`.", None),
 'plantedPublic_eq': ("The planted public table reads `y` at `(i,c)` and the original images "
   "elsewhere: `plantedPublic g T i c y p = if p = (i, c) then y else g (T p)`.", None),
 'plantedPublic_plant': ("The planted public table ignores the original preimage at its planted "
   "coordinate: `plantedPublic g (plantTable T i c x) i c y = plantedPublic g T i c y`.", None),
 'signatureBlock': ("Extract the `i`-th preimage block from a flattened signature: "
   "`signatureBlock σ i = fun k => σ (finProdFinEquiv (i, k))`.", None),
 'signatureBlock_eq': ("Extracted block `i` reads the flattened signature at indices `(i,k)`: "
   "`signatureBlock σ i = fun k => σ (finProdFinEquiv (i, k))`.", None),
 'extract_planted': ("An accepting signature on a message with bit `c` at `i` supplies a "
   "preimage of `g(x)` under the planted public table [PS10, Theorem 137.2]: if "
   "`∀ j, g (signatureBlock σ j) = plantedPublic g T i c (g x) (j, m j)` and `m i = c`, then "
   "`g (signatureBlock σ i) = g x`.", None),
 'exists_pure_of_cost_zero': ("A computation of cost zero under unit query costs is a return: "
   "if `tree.CostBoundedBy (fun _ => 1) 0`, then `∃ a, tree = .pure a`.", None),
 'firstQuery': ("The first query of a typed signature-forging computation, or `none` if it "
   "returns: `firstQuery (.pure a) = none` and `firstQuery (.query j m k) = some m`.", None),
 'firstQuery_pure': ("A return has no first query: `firstQuery (.pure a : " + TREE + ") = "
   "none`.", None),
 'firstQuery_query': ("A query node's first query is its own message: `firstQuery (.query j m "
   "k) = some m`.", None),
 'tableSigner': ("The deterministic typed signing oracle returns the table's selected "
   "preimages: `tableSigner T = QueryImpl.ofComp fun _ m => .pure (tableSignature T m)`.", None),
 'tableSigner_eq': ("The table signer is the stateless implementation of `m ↦ pure "
   "(tableSignature T m)`: `tableSigner T = QueryImpl.ofComp (fun _ m => .pure (tableSignature "
   "T m))`.", None),
 'firstLog': ("The log of a computation with at most one query consists of its first query and "
   "answer, or is empty if it returns immediately: `firstLog T (.pure a) = []` and "
   "`firstLog T (.query j m k) = [⟨j, m, tableSignature T m⟩]`.", None),
 'firstLog_pure': ("A return has an empty first-query log: `firstLog T (.pure a : " + TREE +
   ") = []`.", None),
 'firstLog_query': ("A query node's first-query log contains exactly its message and "
   "deterministic answer: `firstLog T (.query j m k) = [⟨j, m, tableSignature T m⟩]`.", None),
 'honest_transcript': ("A computation with at most one query against the logged deterministic "
   "signer returns its functional evaluation and exactly its first-query log: if " + C1 +
   ", then `simulate (tableSigner T).withLog tree ((), []) = .pure (tree.evalFn (fun _ m => "
   "tableSignature T m), ((), firstLog T tree))`.", None),
 'exists_honest_transcript': ("The logged one-query signing run has an output and log whose "
   "freshness condition is equivalent to avoiding the optional first query, for any projection "
   "of a forgery's message: if " + C1 + ", then `∃ a log, simulate (tableSigner T).withLog tree "
   "((), []) = .pure (a, ((), log)) ∧ a = tree.evalFn (fun _ m => tableSignature T m) ∧ "
   "((∀ e ∈ log, e.2.1 ≠ message a) ↔ firstQuery tree ≠ some (message a))`.", None),
 'Safe': ("The sole signing query, if present, avoids the planted cell: `Safe tree i c ↔ ∀ m, "
   "firstQuery tree = some m → m i ≠ c`.", None),
 'safe_iff': ("Safety means that every message recorded as the first query has bit different "
   "from `c`: `Safe tree i c ↔ ∀ m, firstQuery tree = some m → m i ≠ c`.", None),
 'abortingAnswer': ("The aborting oracle answers an unsafe query with zero and answers a safe "
   "one honestly: `abortingAnswer T i c m = if m i = c then zeroBits _ else tableSignature T "
   "m`.", None),
 'abortingAnswer_plant': ("The aborting answer ignores the original preimage at the planted "
   "coordinate: `abortingAnswer (plantTable T i c x) i c m = abortingAnswer T i c m`.", None),
 'abortingImpl': ("The planted implementation remembers whether an unsafe query has occurred: "
   "`abortingImpl T i c j m bad = .pure (abortingAnswer T i c m, bad || decide (m i = c))`.",
   None),
 'abortingImpl_plant': ("The aborting implementation ignores the original preimage at its "
   "planted coordinate: `abortingImpl (plantTable T i c x) i c = abortingImpl T i c`.", None),
 'abortingImpl_safe': ("A safe call agrees with the updated key and leaves the abort bit false: "
   "if `m i ≠ c`, then `abortingImpl T i c j m false = .pure (tableSignature (plantTable T i c "
   "x) m, false)`.", None),
 'planted_coupling': ("A safe run with at most one signing query has exactly the honest output "
   "for the updated key and never aborts [PS10, Theorem 137.2]: if " + C1 + " and `Safe tree i "
   "c`, then `simulate (abortingImpl T i c) tree false = .pure (tree.evalFn (fun _ m => "
   "tableSignature (plantTable T i c x) m), false)`.", None),
 'extractionExperiment': ("Run a fixed-position planted forger and extract block `i`, returning "
   "zero after an abort: " + EXT + ".", None),
 'extractionExperiment_eq': ("The extraction experiment simulates the aborting implementation "
   "and selects the `i`-th signature block when the final abort bit is false: " + EXT + ".",
   None),
 'extractionExperiment_plant': ("The extraction experiment ignores the original preimage at the "
   "planted coordinate: `extractionExperiment (plantTable T i c x) i c tree signature = "
   "extractionExperiment T i c tree signature`.", None),
 'plantedExperiment': ("The fixed-position reduction builds the planted public table, runs the "
   "forger against the aborting signer, and extracts the `i`-th signature block: " + PEX + ".",
   None),
 'plantedExperiment_eq': ("The planted experiment is extraction after running the adversary on "
   "the planted public table: " + PEX + ".", None),
 'plantedExperiment_plant': ("The entire planted experiment ignores the original preimage at "
   "`(i,c)`, `plantedExperiment g (plantTable T i c x) i c y adv signature = plantedExperiment "
   "g T i c y adv signature`; this is the coordinate-invariance hypothesis for sampling that "
   "preimage independently.", None),
 'favorable_extraction': ("A safe, accepting honest run whose forged message uses the planted "
   "bit produces an inverse of the planted image in the reduction experiment [PS10, Theorem "
   "137.2]: if " + C1 + ", `Safe tree i c`, and the updated-key honest output `a` satisfies "
   "`∀ j, g (signatureBlock (signature a) j) = plantedPublic g T i c (g x) (j, message a j)` "
   "and `message a i = c`, then `∃ z, extractionExperiment T i c tree signature = .pure z ∧ "
   "g z = g x`, where `a = tree.evalFn (fun _ m => tableSignature (plantTable T i c x) m)`.",
   None),
}

H = "(handler W E G S hE hG hS)"
SPEC[D + 'Machine.lean'] = {
 'u': ("The context's unary parameter is its first component: `u v = pairFstD v`.", None),
 'u_poly': ("The unary parameter projection is polynomial-time: `PolyTimeComputable u`, for "
   "`u : List Bool → List Bool`.", None),
 'y': ("The context's challenge is the first component of its reduction input: "
   "`y v = pairFstD (pairFstD (pairSndD v))`.", None),
 'y_poly': ("The challenge projection is polynomial-time: `PolyTimeComputable y`, for "
   "`y : List Bool → List Bool`.", None),
 'pos': ("The planted position is the second component of the reduction input, encoded in "
   "unary: `pos v = pairSndD (pairFstD (pairSndD v))`.", None),
 'pos_poly': ("The position projection is polynomial-time: `PolyTimeComputable pos`, for "
   "`pos : List Bool → List Bool`.", None),
 'seed': ("The handler seed is the second component of the context's second component: "
   "`seed v = pairSndD (pairSndD v)`.", None),
 'seed_poly': ("The seed projection is polynomial-time: `PolyTimeComputable seed`, for "
   "`seed : List Bool → List Bool`.", None),
 'bit': ("The planted half is the first seed bit, defaulting to false: "
   "`bit v = (seed v).headD false`.", None),
 'bit_poly': ("The planted bit is polynomial-time as a one-bit output: `PolyTimeComputable "
   "(fun v => [bit v])`, for `bit : List Bool → Bool`.", None),
 'tape': ("The sampled preimage tape is the seed after its planted bit: "
   "`tape v = (seed v).drop 1`.", None),
 'tape_poly': ("Removing the planted bit is polynomial-time: `PolyTimeComputable tape`, for "
   "`tape : List Bool → List Bool`.", None),
 'u_seedIn': ("A canonical context exposes its unary parameter: `u (seedIn n z ω) = "
   "List.replicate n true`.", None),
 'y_seedIn': ("A canonical context with input `⟨challenge,index⟩` exposes its challenge: "
   "`y (seedIn n (pairEncode challenge index) ω) = challenge`.", None),
 'pos_seedIn': ("A canonical context with input `⟨challenge,index⟩` exposes its unary position: "
   "`pos (seedIn n (pairEncode challenge index) ω) = index`.", None),
 'seed_seedIn': ("A canonical context exposes its seed: `seed (seedIn n z ω) = ω`.", None),
 'bit_seedIn': ("A seed beginning with `c` supplies the planted half `c`: "
   "`bit (seedIn n z (c :: ρ)) = c`.", None),
 'tape_seedIn': ("A seed beginning with `c` leaves exactly the sampled preimage tape after it: "
   "`tape (seedIn n z (c :: ρ)) = ρ`.", None),
 'width': ("A fixed polynomial width, encoded as a unary word of length `W(|u|)`: "
   "`width W v = List.replicate (W.eval (u v).length) true`.", None),
 'width_poly': ("A polynomial width is polynomial-time in the context: `PolyTimeComputable "
   "(width W)`, for `width W : List Bool → List Bool`.", None),
 'offset': ("The unary offset to block `i` at width `W(n)` has `i · W(n)` symbols: "
   "`offset W v = List.replicate ((pos v).length * W.eval (u v).length) true`.", None),
 'offset_poly': ("Block offsets are polynomial-time by the existing unary multiplication "
   "machine: `PolyTimeComputable (offset W)`, for `offset W : List Bool → List Bool`.", None),
 'first': ("The first preimage at the selected position consists of `n` bits after offset "
   "`2ni`: `first v = ((tape v).drop (offset (.mul (.const 2) .var) v).length).take (u "
   "v).length`.", None),
 'first_eq': ("`first` is the first `n`-bit half of the selected preimage pair: `first v = "
   "((tape v).drop (offset (.mul (.const 2) .var) v).length).take (u v).length`.", None),
 'first_poly': ("Selecting the first preimage is polynomial-time: `PolyTimeComputable first`, "
   "for `first : List Bool → List Bool`.", None),
 'second': ("The second preimage is the next `n` bits after offset `2ni+n`: `second v = "
   "((tape v).drop ((offset (.mul (.const 2) .var) v).length + (u v).length)).take (u "
   "v).length`.", None),
 'second_eq': ("`second` is the second `n`-bit half of the selected preimage pair: `second v = "
   "((tape v).drop ((offset (.mul (.const 2) .var) v).length + (u v).length)).take (u "
   "v).length`.", None),
 'second_poly': ("Selecting the second preimage is polynomial-time: `PolyTimeComputable "
   "second`, for `second : List Bool → List Bool`.", None),
 'honestPk': ("The ordinary generated public key on the sampled tape: `honestPk G v = pairFstD "
   "(G (NUPPT.layout (u v) [] [] (tape v)))`.", None),
 'honestPk_eq': ("`honestPk G` runs `G` on the sampled preimage tape and reads its public-key "
   "component: `honestPk G v = pairFstD (G (NUPPT.layout (u v) [] [] (tape v)))`.", None),
 'honestPk_poly': ("Generating the ordinary public key is polynomial-time when `G` is: "
   "`PolyTimeComputable G → PolyTimeComputable (honestPk G)`.", None),
 'replacement': ("The replacement public-key block is `⟨⟨y,E(x¹)⟩,[]⟩` for bit false and "
   "`⟨⟨E(x⁰),y⟩,[]⟩` for bit true: `replacement E v = pairEncode (pairEncode (if bit v then E "
   "(pairEncode (u v) (first v)) else y v) (if bit v then y v else E (pairEncode (u v) (second "
   "v)))) []`.", None),
 'replacement_eq': ("The replacement block plants the challenge in the selected half: "
   "`replacement E v = pairEncode (pairEncode (if bit v then E (pairEncode (u v) (first v)) "
   "else y v) (if bit v then y v else E (pairEncode (u v) (second v)))) []`.", None),
 'replacement_poly': ("Building the replacement public-key block is polynomial-time when `E` "
   "is: `PolyTimeComputable E → PolyTimeComputable (replacement E)`.", None),
 'advIn': ("The adversary's public key replaces one width-`W(n)` block of the ordinary "
   "generated key with the planted block: `advIn W E G v = (honestPk G v).take (offset W "
   "v).length ++ replacement E v ++ (honestPk G v).drop ((offset W v).length + (width W "
   "v).length)`. [PS10, proof of Theorem 137.2].", None),
 'advIn_eq': ("`advIn` keeps the prefix and suffix around the planted block: `advIn W E G v = "
   "(honestPk G v).take (offset W v).length ++ replacement E v ++ (honestPk G v).drop ((offset "
   "W v).length + (width W v).length)`.", None),
 'advIn_poly': ("Planting one public-key block is polynomial-time: `PolyTimeComputable E → "
   "PolyTimeComputable G → PolyTimeComputable (advIn W E G)`.", None),
 'context': ("The context of a query or finalization input is its first component: "
   "`context w = pairFstD w`.", None),
 'context_poly': ("The context of an activation is polynomial-time: `PolyTimeComputable "
   "context`, for `context : List Bool → List Bool`.", None),
 'state': ("The current abort state is the first component of the second input component: "
   "`state w = pairFstD (pairSndD w)`.", None),
 'state_poly': ("The current state projection is polynomial-time: `PolyTimeComputable state`, "
   "for `state : List Bool → List Bool`.", None),
 'message': ("The query message is the second component after the state and oracle index: "
   "`message w = pairSndD (pairSndD (pairSndD w))`.", None),
 'message_poly': ("The query message projection is polynomial-time: `PolyTimeComputable "
   "message`, for `message : List Bool → List Bool`.", None),
 'context_input': ("The context of a canonical handler query is its original seed context: "
   "`context (PolyHandler.input n z ω s i x) = seedIn n z ω`.", None),
 'state_input': ("A canonical handler query exposes its state: `state (PolyHandler.input n z ω "
   "s i x) = s`.", None),
 'message_input': ("A canonical handler query exposes its message: `message (PolyHandler.input "
   "n z ω s i x) = x`.", None),
 'blocked': ("A query is blocked precisely when its selected message bit is the planted bit: "
   "`blocked w = decide (((message w).drop (pos (context w)).length).headD false = bit "
   "(context w))`.", None),
 'blocked_eq': ("`blocked` tests equality of the query bit at the planted position and the "
   "planted half: `blocked w = decide (((message w).drop (pos (context w)).length).headD false "
   "= bit (context w))`.", None),
 'blocked_poly': ("Testing whether a query requests the planted half is polynomial-time: "
   "`PolyTimeComputable (fun w => [blocked w])`, for `blocked : List Bool → Bool`.", None),
 'run': ("A handler query returns the ordinary sampled-tape signature and sets the persistent "
   "abort bit if the planted half was requested: `run S w = pairEncode (S (NUPPT.layout (u "
   "(context w)) (pairEncode (tape (context w)) (message w)) [] [])) [(state w).headD false || "
   "blocked w]`. Continuing after an abort is harmless because finalization returns no "
   "candidate. [PS10, proof of Theorem 137.2].", None),
 'run_eq': ("The query answer uses the sampled tape and records the disjunction of old and new "
   "aborts: `run S w = pairEncode (S (NUPPT.layout (u (context w)) (pairEncode (tape (context "
   "w)) (message w)) [] [])) [(state w).headD false || blocked w]`.", None),
 'run_poly': ("Query answering and the abort-state update are polynomial-time when `S` is: "
   "`PolyTimeComputable S → PolyTimeComputable (run S)`.", None),
 'out': ("The final output is empty after an abort; otherwise it is block `i` of the forged "
   "signature (the adversary's word begins with the `n` message bits): `out w = if (state "
   "w).headD false then [] else (((pairSndD (pairSndD w)).drop (u (context w)).length).drop "
   "(offset .var (context w)).length).take (u (context w)).length`. [PS10, proof of Theorem "
   "137.2].", None),
 'out_eq': ("Finalization suppresses aborted runs and extracts the selected signature block "
   "otherwise: `out w = if (state w).headD false then [] else (((pairSndD (pairSndD w)).drop "
   "(u (context w)).length).drop (offset .var (context w)).length).take (u (context "
   "w)).length`.", None),
 'out_poly': ("Finalization is polynomial-time by three variable-prefix operations and one "
   "branch: `PolyTimeComputable out`, for `out : List Bool → List Bool`.", None),
 'handler': ("The planted Lamport handler has one abort bit and `1+2n²` seed bits, with the "
   "fair planted half first: its fields are `stateLen = .const 1`, `seedLen = .add (.const 1) "
   "(.mul (.mul (.const 2) .var) .var)`, `init = fun _ _ => false`, `run = run S`, "
   "`advIn = advIn W E G` and `out = out`. It signs at most one query and extracts one "
   "candidate preimage.", None),
 'handler_stateLen': ("The handler state-length polynomial is the constant one: "
   "`" + H + ".stateLen = .const 1`.", None),
 'handler_seedLen': ("The handler seed-length polynomial is `1+2n²`: `" + H + ".seedLen = "
   ".add (.const 1) (.mul (.mul (.const 2) .var) .var)`.", None),
 'handler_init': ("Every bit of the initial abort state is false: `" + H + ".init n i = "
   "false`.", None),
 'handler_run': ("The handler's query function is `run S`: `" + H + ".run = run S`.", None),
 'handler_advIn': ("The handler's adversary-input function is the planted public-key "
   "function: `" + H + ".advIn = advIn W E G`.", None),
 'handler_out': ("The handler's output function is the signature-block extractor: `" + H +
   ".out = out`.", None),
}

# Lamport.lean is at 973 lines: its first paragraphs are refilled from the start (whitespace only).
REFLOW = {B + 'Lamport.lean': set(SPEC[B + 'Lamport.lean'])}
