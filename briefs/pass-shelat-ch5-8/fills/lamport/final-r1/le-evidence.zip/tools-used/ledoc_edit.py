"""ledoc_edit.py <worktree> <touched.json> <spec.py> [--check]: lamport LE-doc docstring edits.
Modelled on hash-sign-r1-ledoc/tools-used/ledoc_edit.py, with the texts held in <spec.py>.

For every (file, declaration short name) of the spec, the declaration's `/-- ... -/` doc comment
is located from touched.json (the doc comment that opens the declaration's span, possibly after an
`include ... in` line) and must occur exactly once in its file. Its first paragraph (up to the
first blank line, or the closing `-/`) is replaced by the spec's text, and an optional
`**Proof sketch.**` paragraph is appended before the closing `-/`. Later paragraphs (for example
an existing proof sketch) are kept byte for byte.

Wrapping keeps every leading line (except for the declarations listed in the spec's REFLOW,
whose first paragraph is refilled from its start, to keep Lamport.lean under 1000 lines) of the old first paragraph whose words the new text repeats
unchanged; the rest of the paragraph is filled greedily to at most 100 characters (Python len),
never starting a line with a Markdown block marker (`*`, `-`, `+`, `#`, `>`, `=`, `|`, `1.`).
Only doc-comment text changes."""
import sys, json, re, runpy
wt, tj, specp = sys.argv[1:4]
check = '--check' in sys.argv[4:]
_spec = runpy.run_path(specp)
SPEC, REFLOW = _spec['SPEC'], _spec.get('REFLOW', {})
T = json.load(open(tj))['files']
W = 100
BAD = re.compile(r'^([*+\-#>=|·]|\d+[.)])$')

def fill(tokens, first_prefix=None):
    """Greedy fill; tokens joined by single spaces; a line never starts with a BAD token."""
    lines, cur = [], []
    for t in tokens:
        if cur and len(' '.join(cur + [t])) > W:
            # never start a line with a BAD token: carry preceding tokens to the new line
            moved = []
            while BAD.match((moved + [t])[0]) and len(cur) > 1:
                moved.insert(0, cur.pop())
            lines.append(' '.join(cur)); cur = moved
        cur.append(t)
    if cur: lines.append(' '.join(cur))
    for l in lines[1:]:
        assert not BAD.match(l.split()[0]), ('bad line start', l)
    return lines

def rewrap(old_lines, new_text, last, reflow=False):
    """old_lines: first paragraph lines (line 0 starts with '/--'; if last, the final line ends
    with '-/'). Returns the new paragraph lines."""
    old = list(old_lines)
    if last:
        assert old[-1].rstrip().endswith('-/'), old[-1]
        old[-1] = old[-1].rstrip()[:-2].rstrip()
    new_tokens = ['/--'] + new_text.split() + (['-/'] if last else [])
    keep, pos = [], 0
    for i, l in enumerate(old):
        tk = l.split()
        if reflow or i == len(old) - 1 or new_tokens[pos:pos + len(tk)] != tk:
            break
        keep.append(l); pos += len(tk)
    out = keep + fill(new_tokens[pos:])
    return out

files_out = {}
report = []
for f, decls in SPEC.items():
    path = f'{wt}/{f}'
    src = open(path, encoding='utf-8').read()
    info = T[f]
    by_short = {}
    for d in info['declarations']:
        by_short.setdefault(d['name'].split('.')[-1], []).append(d)
    lines = src.split('\n')
    edits = []
    for short, entry in decls.items():
        text, sketch = entry[:2]
        reflow = short in REFLOW.get(f, ())
        ds = by_short[short]
        assert len(ds) == 1, (f, short, len(ds))
        d = ds[0]
        s = d['start'] - 1
        while not lines[s].startswith('/--'):
            s += 1
            assert s < d['decl_line'], (f, short)
        e = s
        while '-/' not in lines[e]:
            e += 1
        old_doc = lines[s:e + 1]
        assert old_doc[-1].rstrip().endswith('-/'), (f, short)
        # split paragraphs
        try:
            b = old_doc.index('')
            par, rest = old_doc[:b], old_doc[b:]
        except ValueError:
            par, rest = old_doc, []
        new_par = rewrap(par, text, last=not rest, reflow=reflow)
        new_doc = new_par + rest
        if sketch:
            assert '**Proof sketch' not in '\n'.join(old_doc), (f, short)
            # drop the closing '-/' from the last line, append the sketch paragraph
            last_line = new_doc[-1].rstrip()
            assert last_line.endswith('-/')
            body = last_line[:-2].rstrip()
            new_doc = new_doc[:-1] + ([body] if body else []) + [''] + fill(sketch.split() + ['-/'])
        old_txt = '\n'.join(old_doc); new_txt = '\n'.join(new_doc)
        assert src.count(old_txt) == 1, (f, short, 'old text not unique')
        edits.append((s, e, new_doc, short))
        report.append(f"{f.split('Signatures/')[1]}\t{short}\t{len(old_doc)}->{len(new_doc)} lines"
                      f"\tsketch={'yes' if sketch else 'no'}")
    for s, e, new_doc, short in sorted(edits, reverse=True):
        lines[s:e + 1] = new_doc
    files_out[f] = '\n'.join(lines)
for r in report: print(r)
print('declarations edited:', len(report), 'files:', len(files_out))
over = [(f, i + 1, len(l)) for f, t in files_out.items() for i, l in enumerate(t.split('\n')) if len(l) > W]
print('over-width lines:', over)
for f, t in files_out.items():
    print('size', f.split('Signatures/')[1], len(t.split('\n')) - (1 if t.endswith('\n') else 0))
if not check:
    for f, t in files_out.items():
        open(f'{wt}/{f}', 'w', encoding='utf-8').write(t)
