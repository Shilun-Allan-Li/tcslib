"""mkopacity.py <worktree> <probe-subdir> <outdir> (lamport review, patch-4 analysis).
For each of the three files with the run_cmd opacity block (Lamport, Lamport/Experiment, Lamport/Statistics):
  OpacityKeep_<F>: the file verbatim + an EOF run_cmd printing the reducibility status of the three names;
  OpacityDrop_<F>: the file with exactly the 6-line run_cmd block deleted + the same EOF print.
Plus OpacityDownstream: imports the facade and prints the three statuses (local attributes must not leak)."""
import sys, pathlib, hashlib, json
wt, sub, outd = sys.argv[1:4]
BLOCK = ("run_cmd do\n"
 "  for n in [``ProbComp.expect, ``ProbComp.sample, ``OracleComp.bind] do\n"
 "    let status ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n\n"
 "    unless status == .irreducible do\n"
 "      let id := Lean.mkIdent n\n"
 "      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))\n")
PRINT = ("\nrun_cmd do\n"
 "  for n in [``TCSlib.Cryptography.Games.ProbComp.expect, ``TCSlib.Cryptography.Games.ProbComp.sample,\n"
 "      ``TCSlib.Cryptography.Games.OracleComp.bind] do\n"
 "    let s ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n\n"
 "    Lean.logInfo m!\"OPACITY-STATUS {n} {repr s}\"\n")
F = {'Lamport': 'TCSlib/Cryptography/Authentication/Signatures/Lamport.lean',
     'Experiment': 'TCSlib/Cryptography/Authentication/Signatures/Lamport/Experiment.lean',
     'Statistics': 'TCSlib/Cryptography/Authentication/Signatures/Lamport/Statistics.lean'}
out = pathlib.Path(outd); out.mkdir(parents=True, exist_ok=True); man = []
def w(label, src):
    p = pathlib.Path(wt) / sub / (label + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(src, encoding='utf-8')
    (out / (label + '.lean.txt')).write_text(src, encoding='utf-8')
    man.append(dict(label=label, module=f'{sub}/{label}', sha256=hashlib.sha256(src.encode()).hexdigest()))
for k, path in F.items():
    s = open(f'{wt}/{path}', encoding='utf-8').read()
    assert s.count(BLOCK) == 1, k
    end = s.rindex('\nend ')
    w(f'OpacityKeep_{k}', s[:end] + '\n' + PRINT + s[end:])
    d = s.replace(BLOCK, '')
    end = d.rindex('\nend ')
    w(f'OpacityDrop_{k}', d[:end] + '\n' + PRINT + d[end:])
w('OpacityDownstream', 'import Lean\nimport TCSlib.Cryptography.Authentication\n' + PRINT)
(out / 'manifest.json').write_text(json.dumps(man, indent=1))
print('\n'.join(m['module'] for m in man))
