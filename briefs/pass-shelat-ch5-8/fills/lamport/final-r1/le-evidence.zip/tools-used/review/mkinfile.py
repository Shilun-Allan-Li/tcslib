"""mkinfile.py <worktree> <seal-probe.lean.txt> <source.lean> <probe-subdir> <outdir> (lamport review, patch-4 analysis).
In-file paired controls for Lamport.lean, the file that carries the run_cmd opacity block:
  InFileS_Lamport: the canonical coe-A whole-file seal probe of Lamport.lean with control theorems inserted just
    before its EOF verifier (so the seal, the file's own opacity block and the controls are all in force);
  InFileU_Lamport: Lamport.lean verbatim with the same control theorems appended (no seal).
Controls (each a negative `rfl` reading of a foreign definition, then its published reader):
  ctlInExpect  - ProbComp.expect   (one of the three names of the opacity block)
  ctlInSecret  - LamportFill.secretWord (helper definition, foreign to Lamport.lean)
  ctlInPadFin  - padFin            (foreign campaign definition)
Writes plan.json with the line ranges."""
import sys, json, pathlib, hashlib
wt, sealtxt, src, sub, outd = sys.argv[1:6]
G = 'TCSlib.Cryptography.Games'; LF = 'TCSlib.Cryptography.Authentication.LamportFill'
C = [
 ('ctlInExpect', True, f"theorem ctlInExpect (a : Bool) (g : Bool → ℝ) :\n    {G}.ProbComp.expect (.pure a) g = g a := rfl\n"),
 ('ctlInExpectReader', False, f"theorem ctlInExpectReader (a : Bool) (g : Bool → ℝ) :\n    {G}.ProbComp.expect (.pure a) g = g a := {G}.ProbComp.expect_pure a g\n"),
 ('ctlInSecret', True, f"theorem ctlInSecret {{n : ℕ}} (T : {LF}.Table n) :\n    {LF}.secretWord T =\n      (List.ofFn fun i : Fin n => List.ofFn (T (i, false)) ++ List.ofFn (T (i, true))).flatten := rfl\n"),
 ('ctlInSecretReader', False, f"theorem ctlInSecretReader {{n : ℕ}} (T : {LF}.Table n) :\n    {LF}.secretWord T =\n      (List.ofFn fun i : Fin n => List.ofFn (T (i, false)) ++ List.ofFn (T (i, true))).flatten :=\n  {LF}.secretWord_eq T\n"),
 ('ctlInPadFin', True, "theorem ctlInPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n"),
 ('ctlInPadFinReader', False, "theorem ctlInPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n"),
]
def build(prefix_text, suffix_text):
    s = prefix_text + "\nnamespace LamportInFileControls\n\n"; rows = []
    for name, neg, body in C:
        start = s.count('\n') + 1; s += body + '\n'
        rows.append(dict(control=name, negative=neg, start_line=start, end_line=start + body.count('\n') - 1))
    s += "end LamportInFileControls\n\n" + suffix_text
    return s, rows
seal = open(sealtxt, encoding='utf-8').read()
k = seal.index('/- G06-HARNESS EOF-VERIFY')
sS, rS = build(seal[:k], seal[k:])
base = open(src, encoding='utf-8').read()
sU, rU = build(base, '')
out = pathlib.Path(outd); out.mkdir(parents=True, exist_ok=True); plan = []
for label, s, rows, sealed in (('InFileS_Lamport', sS, rS, True), ('InFileU_Lamport', sU, rU, False)):
    p = pathlib.Path(wt) / sub / (label + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(s, encoding='utf-8')
    (out / (label + '.lean.txt')).write_text(s, encoding='utf-8')
    plan.append(dict(label=label, module=f'{sub}/{label}', sealed=sealed, controls=rows, sha256=hashlib.sha256(s.encode()).hexdigest()))
(out / 'plan.json').write_text(json.dumps(plan, indent=1)); print('\n'.join(p['module'] for p in plan))
