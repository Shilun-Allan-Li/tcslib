"""ledoc_edit.py <worktree>: dl-crh LE-doc docstring replacements (exact; each old text must occur
exactly once in its file, and every replacement must lie inside a /-- -/ or /-! -/ span).
Modelled on extnosrc-r1-ledoc/tools-used/ledoc_edit.py."""
import sys
wt = sys.argv[1]
C = 'TCSlib/Cryptography/Candidates/'
P = 'TCSlib/Cryptography/Hashing/'
Q = P + 'FromDiscreteLog/'
E = {}

E[C + 'DiscreteLog.lean'] = [
("""/-- The raw index generator pairs the instance generator's output with the empty trapdoor
when the parameter length is at least `G.n₀`, and otherwise pairs `dlDefaultIndex` with it. -/""",
 """/-- The raw index generator pairs the instance generator's output with the empty trapdoor
when the parameter length is at least `G.n₀`, and otherwise pairs `dlDefaultIndex` with it:
`expGenFun G z = if G.n₀ ≤ u.length then pairEncode o [] else pairEncode dlDefaultIndex []`,
where `u = NUPPT.inParam z` and `o = G.gen.output (NUPPT.layout u [] [] (NUPPT.inCoins z))`. -/"""),
("""/-- The raw exponent sampler writes the result of `sampleBelowL m (Nat.size m) n n r`,
with fallback zero, at the width of the input index; `n` and `r` are the input parameter
length and coins. -/""",
 """/-- The raw exponent sampler writes the result of `sampleBelowL m (Nat.size m) n n r`,
with fallback zero, at the width of the input index:
`expSampleRaw z = natToList (dlW i) ((sampleBelowL m (Nat.size m) n n r).getD 0)`, where
`i = NUPPT.inArg z`, `m = dlM i`, and `n` and `r` are the input parameter length and coins. -/"""),
]

E[P + 'FromDiscreteLog.lean'] = [
# module docstring: re-wrap the pre-existing 121-column line 31 (words unchanged)
("""(`expSampleRaw`, within `2^{-n}` of uniform on `Z_m`). Consequently `y` is within `2^{-n}`
of uniform on `⟨g⟩`, and, when `m = p − 1` (hypothesis `hV` of the theorem), on `Z_p^*`. Arithmetic is through the bundle
`ArithmeticFP` (D11), as for every ch. 2–4 candidate.""",
 """(`expSampleRaw`, within `2^{-n}` of uniform on `Z_m`). Consequently `y` is within `2^{-n}`
of uniform on `⟨g⟩`, and, when `m = p − 1` (hypothesis `hV` of the theorem), on `Z_p^*`.
Arithmetic is through the bundle `ArithmeticFP` (D11), as for every ch. 2–4 candidate."""),
("""/-- On generator coins followed by sampler coins, the raw hash index is the instance
generator's output above its threshold and the fixed default index below it. -/""",
 """/-- On generator coins followed by sampler coins, the raw hash index is the instance
generator's output above its threshold and the fixed default index below it:
`dlHashIdx G z₀ = if G.n₀ ≤ n then G.gen.runAt n [] r else dlDefaultIndex`, where
`z₀ = NUPPT.layout (List.replicate n true) [] [] (List.ofFn r ++ s)`. -/"""),
("""/-- Above the threshold, generator coins followed by sampler coins produce the group
index and the exponentiation of the rejection-sampled exponent [PS10, Protocol 142.2]. -/""",
 """/-- Above the threshold, generator coins followed by sampler coins produce the group
index and the exponentiation of the rejection-sampled exponent: for `G.n₀ ≤ n`,
`dlHashGenFun G z₀ = pairEncode i (expEval (pairEncode i (natToList (dlW i) w)))`, where
`z₀ = NUPPT.layout (List.replicate n true) [] [] (List.ofFn r ++ s)`, `i = G.gen.runAt n [] r`
and `w = (sampleBelowL (dlM i) (Nat.size (dlM i)) n n s).getD 0` [PS10, Protocol 142.2]. -/"""),
("""/-- Above the generator threshold, every raw generated key has the form `⟨i, g^z⟩`
for an exponent in the domain of its valid group index [PS10, Protocol 142.2].""",
 """/-- Above the generator threshold, every raw generated key has the form `⟨i, g^z⟩`
for an exponent in the domain of its valid group index: for `G.n₀ ≤ n`,
`∃ z : ZMod (expOrd i), dlHashGenFun G z₀ = pairEncode i (expF i z)`, where
`i = G.gen.runAt n [] r` and `z₀ = NUPPT.layout (List.replicate n true) [] [] (List.ofFn r ++ s)`
[PS10, Protocol 142.2]."""),
("""/-- At a well-formed valid index, the exponentiation part reads the first `n` input bits
and returns the `n`-bit numeral of their power of `g` modulo `p`. -/""",
 """/-- At a well-formed valid index, the exponentiation part reads the first `n` input bits
and returns the `n`-bit numeral of their power of `g` modulo `p`:
`dlHashPow a = natToList n (dlG i ^ x₀ % dlP i)`, where
`a = atParam n (pairEncode (pairEncode i y) (List.ofFn x))` and
`x₀ = listToNat ((List.ofFn x).take n) < dlM i`. -/"""),
("""/-- The multiplication part returns the `n`-bit numeral of the power of `g` times the
key element, reduced modulo `p`, at a valid well-formed index. -/""",
 """/-- The multiplication part returns the `n`-bit numeral of the power of `g` times the
key element, reduced modulo `p`, at a valid well-formed index:
`dlHashMul a = natToList n ((dlG i ^ x₀ % dlP i * listToNat y) % dlP i)`, where
`a = atParam n (pairEncode (pairEncode i y) (List.ofFn x))` and
`x₀ = listToNat ((List.ofFn x).take n) < dlM i`. -/"""),
("""/-- Hash evaluation at a valid well-formed index is the `n`-bit numeral of `g^x mod p`
for selector false, and of `(g^x mod p) y mod p` for selector true
[PS10, Protocol 142.2]. -/""",
 """/-- Hash evaluation at a valid well-formed index is the `n`-bit numeral of `g^x mod p`
for selector false, and of `(g^x mod p) y mod p` for selector true:
`dlHashEval a = natToList n (if x (Fin.last n) then (e * listToNat y) % dlP i else e)`, where
`a = atParam n (pairEncode (pairEncode i y) (List.ofFn x))`, `e = dlG i ^ x₀ % dlP i` and
`x₀ = listToNat ((List.ofFn x).take n) < dlM i` [PS10, Protocol 142.2]. -/"""),
("""/-- For the key element `g^z`, evaluation writes the residue of the unit
`(if b then g^z else 1) * g^x`, where `x` is the exponent prefix and `b` is the last bit
[PS10, Protocol 142.2]. -/""",
 """/-- For the key element `g^z`, evaluation writes the residue of the unit
`(if b then g^z else 1) * g^x`, where `x` is the exponent prefix and `b` is the last bit:
`dlHashEval a = natToList n (v : ZMod (dlP i)).val`, where
`a = atParam n (pairEncode (pairEncode i (expF i z)) (List.ofFn x))`, the unit is
`v = (if x (Fin.last n) then u ^ z.val else 1) * u ^ x₀ : (ZMod (dlP i))ˣ`, `u = expUnit hi`
and `x₀ = listToNat ((List.ofFn x).take n) < dlM i` [PS10, Protocol 142.2]. -/"""),
("""/-- Equal evaluations on two distinct domain inputs force different selectors and reveal
the challenge exponent as the corresponding difference modulo `m`
[PS10, proof of Theorem 142.3].""",
 """/-- Equal evaluations on two distinct domain inputs force different selectors and reveal
the challenge exponent as the corresponding difference modulo `m`: if `x ≠ x'`, `x₀ < m`,
`x₀' < m` and `dlHashEval a = dlHashEval a'`, then `x (Fin.last n) ≠ x' (Fin.last n)` and
`z.val = if x (Fin.last n) then (x₀' + (m - x₀)) % m else (x₀ + (m - x₀')) % m`, where
`a = atParam n (pairEncode (pairEncode i (expF i z)) (List.ofFn x))` (`a'` likewise for `x'`),
`x₀ = listToNat ((List.ofFn x).take n)`, `x₀'` likewise and `m = dlM i`
[PS10, proof of Theorem 142.3]."""),
("""/-- Evaluation on a domain input at a valid well-formed key has exactly `n` bits and
reads as a positive residue below `p` [PS10, compression in Theorem 142.3].""",
 """/-- Evaluation on a domain input at a valid well-formed key has exactly `n` bits and
reads as a positive residue below `p`:
`(dlHashEval a).length = n ∧ 0 < listToNat (dlHashEval a) ∧ listToNat (dlHashEval a) < dlP i`,
where `a = atParam n (pairEncode (pairEncode i (expF i z)) (List.ofFn x))` and
`listToNat ((List.ofFn x).take n) < dlM i` [PS10, compression in Theorem 142.3]."""),
("""/-- The hash generator uses the instance generator's coin polynomial plus `n²` sampler
coins [PS10, Protocol 142.2]. -/""",
 """/-- The hash generator uses the instance generator's coin polynomial plus `n²` sampler
coins: `(dlHash H G).gen.coins = .add G.gen.coins (.mul .var .var)` [PS10, Protocol 142.2]. -/"""),
("""/-- The hash generator's coins are the instance generator's coins and an independent
`n²`-bit sampler tape [PS10, Protocol 142.2]. -/""",
 """/-- The hash generator's coins are the instance generator's coins and an independent
`n²`-bit sampler tape: `(dlHash H G).gen.Coins n ≃ G.gen.Coins n × (Fin (n * n) → Bool)`
[PS10, Protocol 142.2]. -/"""),
("""/-- The hash coin equivalence splits the sum polynomial, identifies its first component
with the generator's coins, and reads the second component as `n²` bits. -/""",
 """/-- The hash coin equivalence splits the sum polynomial, identifies its first component
with the generator's coins, and reads the second component as `n²` bits:
`dlHash_coinsEquiv H G n = (sumCoinsEquiv (dlHash H G).gen _ n).trans (Equiv.prodCongr e₁ e₂)`,
where `e₁ = (NUPPT.coinsEquivPoly (A := G.gen) rfl n).symm` and
`e₂ = Equiv.arrowCongr (finCongr _) (Equiv.refl Bool)` transports
`(.mul .var .var).eval n = n * n`. -/"""),
("""/-- Combining a generator tape and a sampler tape concatenates their encoded words. -/""",
 """/-- Combining a generator tape and a sampler tape concatenates their encoded words:
`List.ofFn ((dlHash_coinsEquiv H G n).symm (r, s)) = List.ofFn r ++ List.ofFn s`. -/"""),
("""/-- On recombined generator and sampler coins, the hash generator runs its raw function
on their concatenation [PS10, Protocol 142.2]. -/""",
 """/-- On recombined generator and sampler coins, the hash generator runs its raw function
on their concatenation:
`(dlHash H G).gen.runAt n [] ((dlHash_coinsEquiv H G n).symm (r, s)) = dlHashGenFun G z₀`,
where `z₀ = NUPPT.layout (List.replicate n true) [] [] (List.ofFn r ++ List.ofFn s)`
[PS10, Protocol 142.2]. -/"""),
("""/-- The discrete-log hash compresses at every parameter above the instance generator's
threshold when its groups are the full unit groups [PS10, Theorem 142.3].""",
 """/-- The discrete-log hash compresses at every parameter above the instance generator's
threshold when its groups are the full unit groups:
`(∀ i, V i → ExpValid i ∧ dlM i = dlP i - 1) → (dlHash H G).Compresses` [PS10, Theorem 142.3]."""),
("""/-- The collision test for a raw finder output on key `⟨i, y⟩`: its two padded inputs
are distinct, have exponent prefixes below `m`, and have equal padded hash values
[PS10, Definition 140.1]. -/""",
 """/-- The collision test for a raw finder output on key `⟨i, y⟩`: its two padded inputs
are distinct, have exponent prefixes below `m`, and have equal padded hash values,
`dlHashCollision n i y raw = (x₀ < dlM i ∧ x₀' < dlM i ∧ xx.1 ≠ xx.2 ∧ h xx.1 = h xx.2)`, where
`xx = splitBits (padFin ((n + 1) + (n + 1)) raw)` (blocks of `n + 1` bits),
`x₀ = listToNat ((List.ofFn xx.1).take n)`, `x₀'` likewise for `xx.2`, and
`h v = padFin n (dlHashEval (atParam n (pairEncode (pairEncode i y) (List.ofFn v))))`
[PS10, Definition 140.1]. -/"""),
("""/-- The raw collision predicate is exactly the domain, distinctness, and equal-hash test
on its two padded output halves. -/""",
 """/-- The raw collision predicate is exactly the domain, distinctness, and equal-hash test
on its two padded output halves:
`dlHashCollision n i y raw ↔ x₀ < dlM i ∧ x₀' < dlM i ∧ xx.1 ≠ xx.2 ∧ h xx.1 = h xx.2`,
with `xx`, `x₀`, `x₀'` and `h` as in `dlHashCollision`. -/"""),
("""/-- Above the generator threshold, collision acceptance is the average over instance
coins of the joint probability over sampler and finder coins of the raw collision test
[PS10, key distribution in Theorem 142.3].""",
 """/-- Above the generator threshold, collision acceptance is the average over instance
coins of the joint probability over sampler and finder coins of the raw collision test:
for `G.n₀ ≤ n`, `accept ((dlHash H G).collisionGame A n) = uexp (fun r => uprob (fun rs =>`
`dlHashCollision n i y (A.runAt n (pairEncode i y) rs.2)))` over `r : G.gen.Coins n` and
`rs : (Fin (n * n) → Bool) × A.Coins n`, where `i = G.gen.runAt n [] r`,
`y = expEval (pairEncode i (natToList n w))` and
`w = (sampleBelowL (dlM i) (Nat.size (dlM i)) n n (List.ofFn rs.1)).getD 0`
[PS10, key distribution in Theorem 142.3]."""),
("""/-- Whenever the finder produces a collision on a valid key `⟨i, g^z⟩`, the reduction's
answer decodes to the challenge exponent [PS10, reduction in Theorem 142.3].""",
 """/-- Whenever the finder produces a collision on a valid key `⟨i, g^z⟩`, the reduction's
answer decodes to the challenge exponent: if the finder's output
`A.runAt n k (NUPPT.coinsCongr (collisionReduction_coins H A) n r)` passes the
`dlHashCollision n i (expF i z)` test (stated unfolded), then
`∃ out : Fin n → Bool, decodeFin n (B.runAt n k r) = some out ∧ bitsToNat out = z.val`, where
`k = pairEncode i (expF i z)` and `B = collisionReduction H A`
[PS10, reduction in Theorem 142.3]."""),
("""/-- For a fixed valid well-formed index and a uniform challenge exponent, the finder's
collision probability is bounded by the reduction's discrete-log success probability
[PS10, reduction in Theorem 142.3].""",
 """/-- For a fixed valid well-formed index and a uniform challenge exponent, the finder's
collision probability is bounded by the reduction's discrete-log success probability:
`uprob CA ≤ uprob DB`, where `CA (z, r) = dlHashCollision n i (expF i z) (A.runAt n k r)` on
`ZMod (expOrd i) × A.Coins n`, and on `ZMod (expOrd i) × B.Coins n`,
`DB (z, r) = ∃ out : Fin n → Bool, decodeFin n (B.runAt n k r) = some out ∧ bitsToNat out = z.val`,
with `k = pairEncode i (expF i z)` and `B = collisionReduction H A`
[PS10, reduction in Theorem 142.3]."""),
("""/-- Above the generator threshold, collision acceptance is at most the concrete
reduction's discrete-log success probability plus `(1/2)^n`
[PS10, probability bound in Theorem 142.3].""",
 """/-- Above the generator threshold, collision acceptance is at most the concrete
reduction's discrete-log success probability plus `(1/2)^n`: for `G.n₀ ≤ n`,
`accept ((dlHash H G).collisionGame A n) ≤ G.dlProb (collisionReduction H A) n + (1/2)^n`
[PS10, probability bound in Theorem 142.3]."""),
]

E[Q + 'Algebra.lean'] = [
("""/-- A collision between two distinct bounded exponent/selector pairs has different
selector bits [PS10, proof of Theorem 142.3].""",
 """/-- A collision between two distinct bounded exponent/selector pairs has different
selector bits: if `(x, b) ≠ (x', b')`, `x < dlM i`, `x' < dlM i` and
`(if b then u ^ z.val else 1) * u ^ x = (if b' then u ^ z.val else 1) * u ^ x'` for
`u = expUnit hi`, then `b ≠ b'` [PS10, proof of Theorem 142.3]."""),
("""/-- A collision between distinct bounded exponent/selector pairs reveals the
challenge exponent: it is `(x' + (m - x)) mod m` when the first selector is true,
and `(x + (m - x')) mod m` otherwise [PS10, proof of Theorem 142.3].""",
 """/-- A collision between distinct bounded exponent/selector pairs reveals the
challenge exponent: it is `(x' + (m - x)) mod m` when the first selector is true,
and `(x + (m - x')) mod m` otherwise, that is,
`b ≠ b' ∧ z.val = if b then (x' + (m - x)) % m else (x + (m - x')) % m` for `m = dlM i`,
under the hypotheses of `unitCollision_selector_ne` [PS10, proof of Theorem 142.3]."""),
]

E[Q + 'Coins.lean'] = [
("""/-- A machine with coin polynomial `c + d` has coins equivalent to a `c(n)`-bit vector and
a `d(n)`-bit vector. -/""",
 """/-- A machine with coin polynomial `c + d` has coins equivalent to a `c(n)`-bit vector and
a `d(n)`-bit vector: for `h : A.coins = .add c d`,
`A.Coins n ≃ (Fin (c.eval n) → Bool) × (Fin (d.eval n) → Bool)`. -/"""),
("""/-- The sum-coin equivalence first identifies the machine's polynomial-length coin vector,
then transports its length through evaluation of addition and applies `splitCoins`. -/""",
 """/-- The sum-coin equivalence first identifies the machine's polynomial-length coin vector,
then transports its length through evaluation of addition and applies `splitCoins`:
`sumCoinsEquiv A h n = (NUPPT.coinsEquivPoly h n).trans (e.trans s)`, where
`e = Equiv.arrowCongr (finCongr (PolyExpr.eval_add c d n)) (Equiv.refl Bool)` and
`s = splitCoins (c.eval n) (d.eval n)`. -/"""),
]

E[Q + 'Encoding.lean'] = [
("""/-- The word of the first component of `splitBits w` is the first `a` bits of `w`. -/""",
 """/-- The word of the first component of `splitBits w` is the first `a` bits of `w`:
`List.ofFn (splitBits w).1 = (List.ofFn w).take a`. -/"""),
("""/-- The word of the second component of `splitBits w` is the word of `w` after its first
`a` bits. -/""",
 """/-- The word of the second component of `splitBits w` is the word of `w` after its first
`a` bits: `List.ofFn (splitBits w).2 = (List.ofFn w).drop a`. -/"""),
("""/-- The word of an `(n + 1)`-bit vector is its first `n` bits followed by its final bit. -/""",
 """/-- The word of an `(n + 1)`-bit vector is its first `n` bits followed by its final bit:
`List.ofFn x = List.ofFn (fun j : Fin n => x j.castSucc) ++ [x (Fin.last n)]`. -/"""),
("""/-- Taking the first `n` bits of an `(n + 1)`-bit word gives its restricted vector. -/""",
 """/-- Taking the first `n` bits of an `(n + 1)`-bit word gives its restricted vector:
`(List.ofFn x).take n = List.ofFn (fun j : Fin n => x j.castSucc)`. -/"""),
("""/-- Dropping the first `n` bits of an `(n + 1)`-bit word leaves its final bit. -/""",
 """/-- Dropping the first `n` bits of an `(n + 1)`-bit word leaves its final bit:
`(List.ofFn x).drop n = [x (Fin.last n)]`. -/"""),
("""/-- An `(n + 1)`-bit input is determined by its first `n` bits and its final bit. -/""",
 """/-- An `(n + 1)`-bit input is determined by its first `n` bits and its final bit:
`(List.ofFn x).take n = (List.ofFn y).take n → x (Fin.last n) = y (Fin.last n) → x = y`. -/"""),
("""/-- An `(n + 1)`-bit input is determined by the number read from its first `n` bits
and its final selector bit. -/""",
 """/-- An `(n + 1)`-bit input is determined by the number read from its first `n` bits
and its final selector bit: `x = y` whenever `x (Fin.last n) = y (Fin.last n)` and
`listToNat ((List.ofFn x).take n) = listToNat ((List.ofFn y).take n)`. -/"""),
("""/-- The bounded-input equivalence reads the exponent and the final selector bit. -/""",
 """/-- The bounded-input equivalence reads the exponent and the final selector bit:
`boundedInputEquiv n m hm x = (⟨listToNat ((List.ofFn x.1).take n), x.2⟩, x.1 (Fin.last n))`. -/"""),
("""/-- The inverse equivalence writes an `n`-bit exponent and appends its selector bit. -/""",
 """/-- The inverse equivalence writes an `n`-bit exponent and appends its selector bit:
`((boundedInputEquiv n m hm).symm z).1 = padFin (n + 1) (natToList n z.1.val ++ [z.2])`. -/"""),
]

E[Q + 'Probability.lean'] = [
("""/-- The expectation of `f` after sampling a nonempty finite type is the uniform
average `uexp f`. Both expressions are the sum of `f` divided by the type's size. -/""",
 """/-- The expectation of `f` after sampling a nonempty finite type is the uniform
average `uexp f`: `ProbComp.expect (ProbComp.sample α) f = uexp f`. Both expressions
are the sum of `f` divided by the type's size. -/"""),
("""/-- Collision-game acceptance is the average over generator coins of the probability,
over finder coins, that the two padded output halves are distinct domain elements
with equal hashes [PS10, Definition 140.1].""",
 """/-- Collision-game acceptance is the average over generator coins of the probability,
over finder coins, that the two padded output halves are distinct domain elements
with equal hashes: `accept (C.collisionGame A n) = uexp (fun rg => uprob (fun r => W rg r))`,
where `W rg r` is `C.inDom n i xx.1 = true ∧ C.inDom n i xx.2 = true ∧ xx.1 ≠ xx.2 ∧`
`C.hash n i xx.1 = C.hash n i xx.2` for `i = C.gen.runAt n [] rg` and
`xx = splitBits (padFin (C.domLen.eval n + C.domLen.eval n) (A.runAt n i r))`
[PS10, Definition 140.1]."""),
]

E[Q + 'Reduction.lean'] = [
("""/-- The modular-difference routine adds `a` to the truncated subtraction of `b`
from `m`, divides by `m`, and keeps the remainder. -/""",
 """/-- The modular-difference routine adds `a` to the truncated subtraction of `b`
from `m`, divides by `m`, and keeps the remainder:
`modularDifference a b m = pairSndD (divModStr (pairEncode (addStr (pairEncode a s)) m))`,
where `s = subStr (pairEncode m b)`. -/"""),
("""/-- The modular-difference routine writes the `|m|`-bit numeral of
`(⟦a⟧ + (⟦m⟧ - ⟦b⟧)) mod ⟦m⟧`. -/""",
 """/-- The modular-difference routine writes the `|m|`-bit numeral of
`(⟦a⟧ + (⟦m⟧ - ⟦b⟧)) mod ⟦m⟧`:
`modularDifference a b m = natToList m.length ((⟦a⟧ + (⟦m⟧ - ⟦b⟧)) % ⟦m⟧)`, where
`⟦w⟧ = listToNat w`. -/"""),
("""/-- Applying the modular-difference routine to three polynomial-time word functions
is polynomial-time under the arithmetic bundle. -/""",
 """/-- Applying the modular-difference routine to three polynomial-time word functions
is polynomial-time under the arithmetic bundle: given `H : ArithmeticFP`,
`PolyTimeComputable a → PolyTimeComputable b → PolyTimeComputable m →`
`PolyTimeComputable fun w => modularDifference (a w) (b w) (m w)`. -/"""),
("""/-- On `⟨u, ⟨⟨i,y⟩, raw⟩⟩`, pad or truncate `raw` to two blocks of `|u|+1` bits.
Read exponents from each block's first `|u|` bits and the first selector from its
last bit. Output `x' - x mod m` if that selector is true and `x - x' mod m`
otherwise, where `m` is the order word in the index `i` [PS10, Theorem 142.3]. -/""",
 """/-- On `w = ⟨u, ⟨⟨i,y⟩, raw⟩⟩`, pad or truncate `raw` to two blocks of `|u|+1` bits and output
`collisionPost w = if s then modularDifference x' x m else modularDifference x x' m`.
Here `x`, `x'` are read from each block's first `|u|` bits and the first selector `s` from its
last bit, so the output is `x' - x mod m` if that selector is true and `x - x' mod m`
otherwise, where `m` is the order word in the index `i` [PS10, Theorem 142.3]. -/"""),
("""/-- The postprocessor pads the raw output, reads two exponent prefixes and the first
selector, and applies the corresponding modular difference. -/""",
 """/-- The postprocessor pads the raw output, reads two exponent prefixes and the first
selector, and applies the corresponding modular difference:
`collisionPost w = if s then modularDifference x' x m else modularDifference x x' m`, where
`u = pairFstD w`, `m = pairFstD (pairSndD (pairFstD (pairFstD (pairSndD w))))`,
`p = padStr (.add (.add .var (.const 1)) (.add .var (.const 1))) u (pairSndD (pairSndD w))`,
`x = p.take u.length`, `x' = (p.drop (u.length + 1)).take u.length` and
`s = (p.drop u.length).headD false`. -/"""),
("""/-- The collision postprocessor is polynomial-time under the arithmetic bundle.""",
 """/-- The collision postprocessor is polynomial-time under the arithmetic bundle:
`ArithmeticFP → PolyTimeComputable collisionPost`."""),
("""/-- At a well-formed index, postprocessing the concatenation of two `(n + 1)`-bit
inputs writes the `n`-bit numeral of their selected exponent difference modulo
`dlM i`. The first input's final bit""",
 """/-- At a well-formed index, postprocessing the concatenation of two `(n + 1)`-bit
inputs writes the `n`-bit numeral of their selected exponent difference modulo
`dlM i`: `collisionPost (pairEncode (List.replicate n true) (pairEncode (pairEncode i y) v)) =`
`natToList n (if x (Fin.last n) then (x₀' + (m - x₀)) % m else (x₀ + (m - x₀')) % m)`, where
`v = List.ofFn x ++ List.ofFn x'`, `x₀ = listToNat ((List.ofFn x).take n)`, `x₀'` likewise and
`m = dlM i`. The first input's final bit"""),
("""/-- For any raw finder output, the postprocessor writes the selected difference
of the two inputs obtained by the collision game's padding and splitting. It writes""",
 """/-- For any raw finder output, the postprocessor writes the selected difference
of the two inputs obtained by the collision game's padding and splitting:
`collisionPost (pairEncode (List.replicate n true) (pairEncode (pairEncode i y) raw)) =`
`natToList n (if xx.1 (Fin.last n) then (x₀' + (m - x₀)) % m else (x₀ + (m - x₀')) % m)`,
where `xx = splitBits (padFin ((n + 1) + (n + 1)) raw)`, `x₀ = listToNat ((List.ofFn xx.1).take n)`,
`x₀'` likewise for `xx.2` and `m = dlM i`. It writes"""),
("""/-- On a raw NUPPT layout, run `A` and apply `collisionPost` to the parameter,
the original key, and `A`'s raw output [PS10, proof of Theorem 142.3]. -/""",
 """/-- On a raw NUPPT layout, run `A` and apply `collisionPost` to the parameter,
the original key, and `A`'s raw output:
`reductionRaw A z = collisionPost (pairEncode (inParam z) (pairEncode (inArg z) (A.output z)))`
[PS10, proof of Theorem 142.3]. -/"""),
("""/-- The raw reduction passes its parameter and original argument together with
the finder's raw output to the postprocessor. -/""",
 """/-- The raw reduction passes its parameter and original argument together with
the finder's raw output to the postprocessor:
`reductionRaw A z = collisionPost (pairEncode (inParam z) (pairEncode (inArg z) (A.output z)))`,
with `inParam = NUPPT.inParam` and `inArg = NUPPT.inArg`. -/"""),
("""/-- Running a polynomial-time finder and then postprocessing its output is
polynomial-time under the arithmetic bundle. -/""",
 """/-- Running a polynomial-time finder and then postprocessing its output is
polynomial-time under the arithmetic bundle:
`ArithmeticFP → PolyTimeComputable (reductionRaw A)`. -/"""),
("""/-- The discrete-log reduction runs the collision finder and extracts the exponent
difference, using the same coins and advice [PS10, proof of Theorem 142.3]. -/""",
 """/-- The discrete-log reduction runs the collision finder and extracts the exponent
difference, using the same coins and advice: it realizes `reductionRaw A` in polynomial time
with `(collisionReduction H A).coins = A.coins` and `(collisionReduction H A).advice = A.advice`
[PS10, proof of Theorem 142.3]. -/"""),
("""/-- The reduction is the polynomial-time realization of `reductionRaw A`, with
the finder's coin polynomial, advice bound, and advice function. -/""",
 """/-- The reduction is the polynomial-time realization of `reductionRaw A`, with
the finder's coin polynomial, advice bound, and advice function:
`collisionReduction H A = NUPPT.ofPolyTime hraw A.coins A.adv A.advice A.advice_length`,
where `hraw = polyTimeComputable_reductionRaw H A`. -/"""),
("""/-- The reduction uses the collision finder's coin polynomial. -/""",
 """/-- The reduction uses the collision finder's coin polynomial:
`(collisionReduction H A).coins = A.coins`. -/"""),
("""/-- The reduction has the collision finder's advice bound. -/""",
 """/-- The reduction has the collision finder's advice bound:
`(collisionReduction H A).adv = A.adv`. -/"""),
("""/-- The reduction uses the collision finder's advice at every parameter. -/""",
 """/-- The reduction uses the collision finder's advice at every parameter:
`(collisionReduction H A).advice = A.advice`. -/"""),
("""/-- At parameter `n` on key `key` and coin list `r`, the reduction postprocesses
`A.runAtL n key r` while retaining `1^n` and the original key. -/""",
 """/-- At parameter `n` on key `key` and coin list `r`, the reduction postprocesses
`A.runAtL n key r` while retaining `1^n` and the original key:
`(collisionReduction H A).runAtL n key r = collisionPost (pairEncode u (pairEncode key o))`,
where `u = List.replicate n true` and `o = A.runAtL n key r`. -/"""),
("""/-- On typed coins, the reduction postprocesses the finder's output on the same
coin string, transported along the equality of their coin polynomials. -/""",
 """/-- On typed coins, the reduction postprocesses the finder's output on the same
coin string, transported along the equality of their coin polynomials:
`(collisionReduction H A).runAt n key r = collisionPost (pairEncode u (pairEncode key o))`,
where `u = List.replicate n true`, `o = A.runAt n key r'` and
`r' = NUPPT.coinsCongr (collisionReduction_coins H A) n r`. -/"""),
]

E[Q + 'Sampling.lean'] = [
("""/-- The residue-to-finite equivalence is Mathlib's inverse `finEquiv`, followed by
transport along the equality of the moduli. -/""",
 """/-- The residue-to-finite equivalence is Mathlib's inverse `finEquiv`, followed by
transport along the equality of the moduli:
`residueFinEquiv h = (ZMod.finEquiv m).symm.toEquiv.trans (finCongr h)`. -/"""),
("""/-- At an index well formed at parameter `n`, evaluating the `n`-bit numeral of
a residue's natural representative returns `expF i z`. -/""",
 """/-- At an index well formed at parameter `n`, evaluating the `n`-bit numeral of
a residue's natural representative returns `expF i z`:
`expEval (pairEncode i (natToList n z.val)) = expF i z`. -/"""),
("""/-- For a valid group index of order below `2^n`, any test of the rejection-sampled
exponent and independent finite auxiliary coins has probability at most its
probability for a uniform exponent in `ZMod (expOrd i)` plus `(1/2)^n`
[PS10, proof of Theorem 142.3, using the candidate-layer sampler convention].""",
 """/-- For a valid group index of order below `2^n`, any test of the rejection-sampled
exponent and independent finite auxiliary coins has probability at most its
probability for a uniform exponent in `ZMod (expOrd i)` plus `(1/2)^n`: for `m = dlM i < 2^n`,
`uprob (fun (s, a) => P ((sampleBelowL m (Nat.size m) n n (List.ofFn s)).getD 0) a) ≤`
`uprob (fun (z, a) => P z.val a) + (1/2)^n` over `s : Fin (n * n) → Bool`,
`z : ZMod (expOrd i)` and `a : ρ`
[PS10, proof of Theorem 142.3, using the candidate-layer sampler convention]."""),
]

counts = {}
for f, reps in E.items():
    path = f'{wt}/{f}'
    src = open(path, encoding='utf-8').read()
    for old, new in reps:
        k = src.count(old)
        if k != 1: sys.exit(f'{f}: old text occurs {k} times: {old[:80]!r}')
        src = src.replace(old, new)
    open(path, 'w', encoding='utf-8').write(src)
    counts[f] = len(reps)
    print(f'{f}\t{len(reps)} replacements')
print(f'TOTAL {sum(counts.values())} replacements in {len(counts)} files')
