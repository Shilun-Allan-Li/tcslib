"""lereuse_edit.py <worktree>: prf-mac LE-reuse (finding F-01), exact replacements in
Authentication/MAC/FromPRF/Bound.lean (each old string must occur exactly once): the local `hadv` of
exists_forgeGame_le is replaced by the published TCSlib.Cryptography.prfAdv_eq_expect, and the
sketch's step 3 cites it (pure insertion)."""
import sys, os
f = os.path.join(sys.argv[1], 'TCSlib/Cryptography/Authentication/MAC/FromPRF/Bound.lean')
s = open(f, encoding='utf-8').read()
R = []
R.append(('''   `Bridge.acceptProb_eq`, `Bridge.acceptGame_eq`, `oracleDist_apply`). -/
theorem exists_forgeGame_le''', '''   `Bridge.acceptProb_eq`, `Bridge.acceptGame_eq`, `oracleDist_apply`); this is the published
   `TCSlib.Cryptography.prfAdv_eq_expect`. -/
theorem exists_forgeGame_le'''))
R.append(('''  -- The PRF advantage is the gap.
  have hadv : prfAdv (F n) (D.toOracleAdversary n n n ((macBudget q).eval n)) =
      |(expect (sample (Fin n → Bool)) fun k => expect (sample (D.Coins n)) fun c =>
          if (D.toOracleAdversary n n n ((macBudget q).eval n) c).eval (F n k) = true
          then (1 : ℝ) else 0) -
        expect (sample ((Fin n → Bool) → (Fin n → Bool))) (fun R =>
          expect (sample (D.Coins n)) fun c =>
            if (D.toOracleAdversary n n n ((macBudget q).eval n) c).eval R = true
            then (1 : ℝ) else 0)| := by
    rw [prfAdv_def, distAdv_def, Bridge.acceptProb_eq, Bridge.acceptProb_eq, accept_eq, accept_eq,
      Bridge.acceptGame_eq, Bridge.acceptGame_eq, prob_bind, prob_bind]
    congr 2
    · refine congrArg _ (funext fun k => ?_)
      simp only [prob_bind, prob_pure, oracleDist_apply]
    · refine congrArg _ (funext fun R => ?_)
      simp only [prob_bind, prob_pure, oracleDist_apply, randomFunction_apply]
  rw [hreal, hadv]
''', '''  -- The PRF advantage is the gap.
  rw [hreal, TCSlib.Cryptography.prfAdv_eq_expect (F n) (D.toOracleAdversary n n n _)]
'''))
for old, new in R:
    assert s.count(old) == 1, old[:60]
    s = s.replace(old, new)
open(f, 'w', encoding='utf-8').write(s)
print('applied', len(R))
