"""sealrows.py <ref-record.json> <new-record.json>...: pairs of seal records (same label); per pair: requests, rows gone,
rows new (with home), rows common but different, and term readers/excluded terms equal."""
import sys, json
a = sys.argv[1:]
for i in range(0, len(a), 2):
    r, n = json.load(open(a[i])), json.load(open(a[i + 1]))
    R = {x['spelling']: x for x in r['rows']}; N = {x['spelling']: x for x in n['rows']}
    gone = sorted(set(R) - set(N)); new = sorted(set(N) - set(R)); diff = sorted(k for k in set(R) & set(N) if R[k] != N[k])
    print(f"{n['label']}: ref {len(R)} new {len(N)}; gone {len(gone)} {gone[:5]}; new {len(new)} {[(k, N[k]['home']) for k in new][:8]}; "
          f"changed {len(diff)}; term_readers equal {r['term_readers'] == n['term_readers']}; term_excluded equal {r['term_excluded'] == n['term_excluded']}")
