import Lean
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA.Eager

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace BcControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

theorem ctlChRun {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := rfl

theorem ctlChRunReader {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := TCSlib.Cryptography.Composability.ChallengeSim.chRun_pure g a s

theorem ctlRecAdvIn (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl

theorem ctlRecAdvInReader (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn_eq c

open TCSlib.Cryptography.Games in
theorem ctlSimulate {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl

open TCSlib.Cryptography.Games in
theorem ctlSimulateReader {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := TCSlib.Cryptography.Games.simulate_pure impl a s

theorem ctlPkInLens (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl

theorem ctlPkInLensReader (S : TCSlib.Cryptography.Composability.FixedLengthPKScheme) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=
  S.inLens_zero n

theorem ctlPadCt (L : ℕ) (c : List Bool) :
    TCSlib.Cryptography.Composability.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) := rfl

theorem ctlPadCtReader (L : ℕ) (c : List Bool) :
    TCSlib.Cryptography.Composability.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) :=
  TCSlib.Cryptography.Composability.padCt_eq L c

theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl

theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=
  TCSlib.Cryptography.Games.seedIn_eq n z ω

theorem ctlCoinBlock (B i : ℕ) (r : List Bool) :
    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B := rfl

theorem ctlCoinBlockReader (B i : ℕ) (r : List Bool) :
    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B :=
  TCSlib.Cryptography.coinBlock_eq B i r

theorem ctlBlockState (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =
    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) := rfl

theorem ctlBlockStateReader (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =
    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) :=
  TCSlib.Cryptography.blockState_eq u pk m r

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in
theorem ctlPadded (S : PublicKeyScheme) (L : PolyExpr)
    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),
      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length
        + 2 ≤ L.eval n)
    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen := rfl

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in
theorem ctlPaddedReader (S : PublicKeyScheme) (L : PolyExpr)
    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),
      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length
        + 2 ≤ L.eval n)
    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen :=
  PublicKeyScheme.padded_gen S L hL hmsg

theorem ctlBitwise (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen := rfl

theorem ctlBitwiseReader (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen :=
  TCSlib.Cryptography.BitPublicKeyScheme.bitwise_gen S

end BcControls

