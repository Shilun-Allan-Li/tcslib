import Lean
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA.QueryHandler

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace BcControls

theorem ctlPair (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPairReader (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b

example (a b : List Bool) :
    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl

theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl

theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :
    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i

theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl

theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=
  TCSlib.Cryptography.Games.zeroBits_apply d j

theorem ctlChRun {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := rfl

theorem ctlChRunReader {ins outs : Fin 2 → ℕ} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)
    (s : Option (Fin (outs 1) → Bool)) : TCSlib.Cryptography.Composability.ChallengeSim.chRun g (.pure a) s = (a, s) := TCSlib.Cryptography.Composability.ChallengeSim.chRun_pure g a s

theorem ctlRecAdvIn (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl

theorem ctlRecAdvInReader (c : List Bool) : TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn c =
    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := TCSlib.Cryptography.Composability.ChallengeSim.recAdvIn_eq c

open TCSlib.Cryptography.Games in
theorem ctlSimulate {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl

open TCSlib.Cryptography.Games in
theorem ctlSimulateReader {ι ι' σ α : Type} {spec : OracleSpec ι} {spec' : OracleSpec ι'}
    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :
    TCSlib.Cryptography.Games.simulate impl (OracleComp.pure a) s = .pure (a, s) := TCSlib.Cryptography.Games.simulate_pure impl a s

theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl

theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :
    TCSlib.Cryptography.Games.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=
  TCSlib.Cryptography.Games.seedIn_eq n z ω

theorem ctlCoinBlock (B i : ℕ) (r : List Bool) :
    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B := rfl

theorem ctlCoinBlockReader (B i : ℕ) (r : List Bool) :
    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B :=
  TCSlib.Cryptography.coinBlock_eq B i r

end BcControls

