import Lean
import TCSlib.Cryptography.Encryption.PublicKey.BitwiseCPA

def kindStr : Option Lean.ConstantInfo → String
  | some (.thmInfo _) => "theorem"
  | some (.defnInfo _) => "def"
  | some _ => "other"
  | none => "absent"

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for s in ["TCSlib.Cryptography.Composability.FixedLengthPKScheme.indImpl_dec_onSpec", "zero_mul", "Fin.isLt"] do
    IO.println s!"KIND {s} {kindStr (env.find? s.toName)}"
  for (n, c) in env.constants.toList do
    let t := n.toString
    if (t.endsWith ".expect_bind" || t.endsWith ".prob_bind" || t.endsWith ".expect_pure" ||
        t.endsWith ".prob_pure") && !n.isInternal then
      IO.println s!"FOUND {t} {kindStr (some c)}"
