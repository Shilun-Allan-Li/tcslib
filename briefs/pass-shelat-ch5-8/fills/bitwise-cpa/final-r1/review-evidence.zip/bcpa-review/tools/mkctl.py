"""mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
Sensitivity controls for the bitwise-cpa review (copied from the adaptive-cpa review's mkctl.py; only B and the namespace differ;
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
AC = 'TCSlib.Cryptography.Composability.AdaptiveCPA'
PK = 'TCSlib.Cryptography.Composability.FixedLengthPKScheme'
G = 'TCSlib.Cryptography.Games'
B = {
 'Turing.pairEncode': [
  ("ctlPair", True, "theorem ctlPair (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n"),
  ("ctlPairReader", False, "theorem ctlPairReader (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := Turing.pairEncode_eq a b\n"),
  ("anonymous example", True, "example (a b : List Bool) :\n    Turing.pairEncode a b = (a.flatMap fun x => [x, x]) ++ [false, true] ++ b := rfl\n")],
 'TCSlib.Cryptography.padFin': [
  ("ctlPadFin", True, "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n"),
  ("ctlPadFinReader", False, "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n")],
 'TCSlib.Cryptography.Games.zeroBits': [
  ("ctlZeroBits", True, "theorem ctlZeroBits (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false := rfl\n"),
  ("ctlZeroBitsReader", False, "theorem ctlZeroBitsReader (d : ℕ) (j : Fin d) : TCSlib.Cryptography.Games.zeroBits d j = false :=\n  TCSlib.Cryptography.Games.zeroBits_apply d j\n")],
 CS + '.chRun': [
  ("ctlChRun", True, f"theorem ctlChRun {{ins outs : Fin 2 → ℕ}} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)\n    (s : Option (Fin (outs 1) → Bool)) : {CS}.chRun g (.pure a) s = (a, s) := rfl\n"),
  ("ctlChRunReader", False, f"theorem ctlChRunReader {{ins outs : Fin 2 → ℕ}} (g : (Fin (ins 1) → Bool) → List Bool) (a : Bool)\n    (s : Option (Fin (outs 1) → Bool)) : {CS}.chRun g (.pure a) s = (a, s) := {CS}.chRun_pure g a s\n")],
 CS + '.recAdvIn': [
  ("ctlRecAdvIn", True, f"theorem ctlRecAdvIn (c : List Bool) : {CS}.recAdvIn c =\n    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := rfl\n"),
  ("ctlRecAdvInReader", False, f"theorem ctlRecAdvInReader (c : List Bool) : {CS}.recAdvIn c =\n    Complexity.pairFstD (Complexity.pairFstD (Complexity.pairSndD c)) := {CS}.recAdvIn_eq c\n")],
 f'{G}.simulate': [
  ("ctlSimulate", True, f"open {G} in\ntheorem ctlSimulate {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := rfl\n"),
  ("ctlSimulateReader", False, f"open {G} in\ntheorem ctlSimulateReader {{ι ι' σ α : Type}} {{spec : OracleSpec ι}} {{spec' : OracleSpec ι'}}\n    (impl : QueryImpl spec σ spec') (a : α) (s : σ) :\n    {G}.simulate impl (OracleComp.pure a) s = .pure (a, s) := {G}.simulate_pure impl a s\n")],
 f'{PK}.inLens': [
  ("ctlPkInLens", True, f"theorem ctlPkInLens (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n := rfl\n"),
  ("ctlPkInLensReader", False, f"theorem ctlPkInLensReader (S : {PK}) (n : ℕ) : S.inLens n 0 = S.ctLen.eval n :=\n  S.inLens_zero n\n")],
 f'{AC}.castImpl': [
  ("ctlCastImpl", True, f"open {G} in\ntheorem ctlCastImpl {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) := rfl\n"),
  ("ctlCastImplReader", False, f"open {G} in\ntheorem ctlCastImplReader {{k : ℕ}} {{σ : Type}} {{ins ins' outs outs' : Fin k → ℕ}}\n    (O : QueryImpl (bitSpec ins' outs') σ unifSpec) (i : Fin k) (x : Fin (ins i) → Bool) (s : σ) :\n    {AC}.castImpl (ins := ins) (outs := outs) O i x s =\n      (O i (TCSlib.Cryptography.padFin (ins' i) (List.ofFn x)) s).bind fun p =>\n        .pure (TCSlib.Cryptography.padFin (outs i) (List.ofFn p.1), p.2) :=\n  {AC}.castImpl_eq O i x s\n")],
 f'{AC}.hybImpl': [
  ("ctlHybImpl", True, f"open {G} in\ntheorem ctlHybImpl {{ins outs : Fin 2 → ℕ}} {{L : ℕ}} {{C : Type}} [Fintype C] [Nonempty C] (κ : ℕ)\n    (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)\n    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :\n    {AC}.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) := rfl\n"),
  ("ctlHybImplReader", False, f"open {G} in\ntheorem ctlHybImplReader {{ins outs : Fin 2 → ℕ}} {{L : ℕ}} {{C : Type}} [Fintype C] [Nonempty C]\n    (κ : ℕ) (E : Bool → (Fin (ins 1) → Bool) → C → (Fin L → Bool)) (sel : ℕ → Bool)\n    (x : Fin (ins 0) → Bool) (h : List (Fin L → Bool)) :\n    {AC}.hybImpl (outs := outs) κ E sel 0 x h = .pure (zeroBits _, h) :=\n  {AC}.hybImpl_zero κ E sel x h\n")],
 f'{AC}.msgOf': [
  ("ctlMsgOf", True, f"theorem ctlMsgOf (m : ℕ) (β : Bool) (l : List Bool) :\n    {AC}.msgOf m β l = if β then l.drop m else l.take m := rfl\n"),
  ("ctlMsgOfReader", False, f"theorem ctlMsgOfReader (m : ℕ) (β : Bool) (l : List Bool) :\n    {AC}.msgOf m β l = if β then l.drop m else l.take m := {AC}.msgOf_eq m β l\n")],
 f'{AC}.acDin': [
  ("ctlAcDin", True, f"theorem ctlAcDin (S : {PK}) : {AC}.acDin S 0 = S.ctLen := rfl\n"),
  ("ctlAcDinReader", False, f"theorem ctlAcDinReader (S : {PK}) : {AC}.acDin S 0 = S.ctLen := {AC}.acDin_zero S\n")],
 f'{AC}.acHandler': [
  ("ctlAcHandler", True, f"theorem ctlAcHandler (S : {PK}) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :\n    ({AC}.acHandler S cap ist).perCall = .const 1 := rfl\n"),
  ("ctlAcHandlerReader", False, f"theorem ctlAcHandlerReader (S : {PK}) (cap : Complexity.PolyExpr) (ist : ℕ → ℕ) :\n    ({AC}.acHandler S cap ist).perCall = .const 1 := {AC}.acHandler_perCall S cap ist\n")],
 f'{AC}.acEnc': [
  ("ctlAcEnc", True, f"theorem ctlAcEnc (S : {PK}) (n : ℕ) (pk : List Bool) (β : Bool)\n    (mm : Fin (({AC}.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :\n    {AC}.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n\n      (Turing.pairEncode pk ({AC}.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) := rfl\n"),
  ("ctlAcEncReader", False, f"theorem ctlAcEncReader (S : {PK}) (n : ℕ) (pk : List Bool) (β : Bool)\n    (mm : Fin (({AC}.acDin S 1).eval n) → Bool) (r : S.enc.Coins n) :\n    {AC}.acEnc S n pk β mm r = TCSlib.Cryptography.padFin _ (S.enc.runAt n\n      (Turing.pairEncode pk ({AC}.msgOf (S.msgLen.eval n) β (List.ofFn mm))) r) :=\n  {AC}.acEnc_eq S n pk β mm r\n")],
}
CP = 'TCSlib.Cryptography.Composability'
BW = CP + '.BitwiseSim'
OP = "open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in\n"
B.update({
 CP + '.padCt': [
  ("ctlPadCt", True, f"theorem ctlPadCt (L : ℕ) (c : List Bool) :\n    {CP}.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) := rfl\n"),
  ("ctlPadCtReader", False, f"theorem ctlPadCtReader (L : ℕ) (c : List Bool) :\n    {CP}.padCt L c = Turing.pairEncode c (List.replicate (L - (2 * c.length + 2)) true) :=\n  {CP}.padCt_eq L c\n")],
 G + '.seedIn': [
  ("ctlSeedIn", True, f"theorem ctlSeedIn (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) := rfl\n"),
  ("ctlSeedInReader", False, f"theorem ctlSeedInReader (n : ℕ) (z ω : List Bool) :\n    {G}.seedIn n z ω = Turing.pairEncode (List.replicate n true) (Turing.pairEncode z ω) :=\n  {G}.seedIn_eq n z ω\n")],
 'TCSlib.Cryptography.coinBlock': [
  ("ctlCoinBlock", True, "theorem ctlCoinBlock (B i : ℕ) (r : List Bool) :\n    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B := rfl\n"),
  ("ctlCoinBlockReader", False, "theorem ctlCoinBlockReader (B i : ℕ) (r : List Bool) :\n    TCSlib.Cryptography.coinBlock B i r = (r.drop (i * B)).take B :=\n  TCSlib.Cryptography.coinBlock_eq B i r\n")],
 'TCSlib.Cryptography.blockState': [
  ("ctlBlockState", True, "theorem ctlBlockState (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =\n    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) := rfl\n"),
  ("ctlBlockStateReader", False, "theorem ctlBlockStateReader (u pk m r : List Bool) : TCSlib.Cryptography.blockState u pk m r =\n    Turing.pairEncode u (Turing.pairEncode pk (Turing.pairEncode m r)) :=\n  TCSlib.Cryptography.blockState_eq u pk m r\n")],
 'TCSlib.Cryptography.PublicKeyScheme.padded': [
  ("ctlPadded", True, OP + "theorem ctlPadded (S : PublicKeyScheme) (L : PolyExpr)\n    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),\n      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length\n        + 2 ≤ L.eval n)\n    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen := rfl\n"),
  ("ctlPaddedReader", False, OP + "theorem ctlPaddedReader (S : PublicKeyScheme) (L : PolyExpr)\n    (hL : ∀ n (rg : S.gen.Coins n) (m : Fin n → Bool) (re : S.enc.Coins n),\n      2 * (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] rg)) (List.ofFn m)) re).length\n        + 2 ≤ L.eval n)\n    (hmsg : ∀ n, n ≤ L.eval n) : (S.padded L hL hmsg).gen = S.gen :=\n  PublicKeyScheme.padded_gen S L hL hmsg\n")],
 'TCSlib.Cryptography.BitPublicKeyScheme.bitwise': [
  ("ctlBitwise", True, "theorem ctlBitwise (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen := rfl\n"),
  ("ctlBitwiseReader", False, "theorem ctlBitwiseReader (S : TCSlib.Cryptography.BitPublicKeyScheme) : S.bitwise.gen = S.gen :=\n  TCSlib.Cryptography.BitPublicKeyScheme.bitwise_gen S\n")],
 BW + '.qDin': [
  ("ctlQDin", True, f"theorem ctlQDin (Lc Lq : Complexity.PolyExpr) : {BW}.qDin Lc Lq 1 = Lq := rfl\n"),
  ("ctlQDinReader", False, f"theorem ctlQDinReader (Lc Lq : Complexity.PolyExpr) : {BW}.qDin Lc Lq 1 = Lq :=\n  {BW}.qDin_one Lc Lq\n")],
 BW + '.qHandler': [
  ("ctlQHandler", True, OP + f"theorem ctlQHandler (Lc Lq Ld Laux Lseed : PolyExpr) (aux : ℕ → List Bool)\n    (ans : List Bool → List Bool) (hans : PolyTimeComputable ans) (fin : List Bool → List Bool)\n    (hfin : PolyTimeComputable fin) :\n    ({BW}.qHandler Lc Lq Ld Laux Lseed aux ans hans fin hfin).seedLen = Lseed := rfl\n"),
  ("ctlQHandlerReader", False, OP + f"theorem ctlQHandlerReader (Lc Lq Ld Laux Lseed : PolyExpr) (aux : ℕ → List Bool)\n    (ans : List Bool → List Bool) (hans : PolyTimeComputable ans) (fin : List Bool → List Bool)\n    (hfin : PolyTimeComputable fin) :\n    ({BW}.qHandler Lc Lq Ld Laux Lseed aux ans hans fin hfin).seedLen = Lseed :=\n  {BW}.qHandler_seedLen Lc Lq Ld Laux Lseed aux ans hans fin hfin\n")],
 BW + '.plantAns': [
  ("ctlPlantAns", True, OP + f"theorem ctlPlantAns (Enc : NUPPT) (L : PolyExpr) (w : List Bool) :\n    {BW}.plantAns Enc L w =\n      {CP}.padCt (L.eval (pairFstD (pairFstD w)).length) ({BW}.plantTuple Enc w) := rfl\n"),
  ("ctlPlantAnsReader", False, OP + f"theorem ctlPlantAnsReader (Enc : NUPPT) (L : PolyExpr) (w : List Bool) :\n    {BW}.plantAns Enc L w =\n      {CP}.padCt (L.eval (pairFstD (pairFstD w)).length) ({BW}.plantTuple Enc w) :=\n  {BW}.plantAns_eq Enc L w\n")],
})
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace BcControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end BcControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
for rec_path in sorted(Path(sealdir).glob('Seal_*.json')):
    rec = json.load(open(rec_path)); module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][5:]
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
