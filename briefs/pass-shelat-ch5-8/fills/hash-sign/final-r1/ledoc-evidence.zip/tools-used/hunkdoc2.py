"""hunkdoc2.py <repo> <old-rev> <new-rev>: extnosrc-r1-ledoc/tools-used/hunkdoc.py extended to
module docstrings. Doc comments are `/-- ... -/` AND `/-! ... -/` (nesting-aware).
(1) Per file of `git diff -U0 old new`: each removed line (old numbering) lies in an old-version
doc-comment span and each added line (new numbering) in a new-version span.
(2) With every doc-comment body replaced by an empty `/-- -/` (resp. `/-! -/`), old and new files
are byte-identical. (3) Line widths (Python len) and line counts; an over-100 line or a size of
1000+ lines counts as a failure only if it is NEW (the over-width line text is absent from the
old file, or the file reaches 1000 lines only at new); pre-existing ones are reported as PRE."""
import sys, re, subprocess
repo, old, new = sys.argv[1:4]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout.decode('utf-8')
files = [f for f in git('diff', '--name-only', old, new).split('\n') if f]
OPEN = re.compile(r'/-[-!]')
def walk(src):
    """Yield (start, end, opener) of every top-level doc comment."""
    i, n = 0, len(src)
    while True:
        m = OPEN.search(src, i)
        if not m: return
        k = m.start(); d, j = 1, k + 3
        while d and j < n:
            if src.startswith('/-', j): d += 1; j += 2
            elif src.startswith('-/', j): d -= 1; j += 2
            else: j += 1
        yield k, j, src[k:k + 3]; i = j
def spans(src):
    cov = set()
    for k, j, _ in walk(src):
        cov.update(range(src.count('\n', 0, k) + 1, src.count('\n', 0, j) + 2))
    return cov
def blank(src):
    out, i = [], 0
    for k, j, op in walk(src): out.append(src[i:k] + op + ' -/'); i = j
    out.append(src[i:]); return ''.join(out)
bad = 0; nh = 0; pre = 0
for f in files:
    a, b = git('show', f'{old}:{f}'), git('show', f'{new}:{f}')
    sa, sb = spans(a), spans(b)
    d = git('diff', '-U0', old, new, '--', f)
    for m in re.finditer(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', d, re.M):
        o0, oc, n0, nc = int(m[1]), int(m[2] or 1), int(m[3]), int(m[4] or 1)
        ol, nl = set(range(o0, o0 + oc)), set(range(n0, n0 + nc))
        ok = ol <= sa and nl <= sb; nh += 1; bad += not ok
        print(f"{'IN-DOCCOMMENT' if ok else 'OUTSIDE'}\t{f}\told {o0},{oc}\tnew {n0},{nc}")
    same = blank(a) == blank(b); bad += not same
    print(f"{'CODE-IDENTICAL' if same else 'CODE-DIFFERS'}\t{f}\t(doc comments blanked)")
    LA = a.split('\n'); LA = LA[:-1] if a.endswith('\n') else LA
    LB = b.split('\n'); LB = LB[:-1] if b.endswith('\n') else LB
    for tag, L in (('old', LA), ('new', LB)):
        print(f"WIDTH\t{tag}\t{f}\tlines {len(L)}\tmax {max(map(len, L))}\t"
              f"over100 {sum(len(x) > 100 for x in L)}")
    oldset = set(LA)
    for i, x in enumerate(LB, 1):
        if len(x) > 100:
            isnew = x not in oldset; bad += isnew; pre += not isnew
            print(f"{'NEW-OVER100' if isnew else 'PRE-OVER100'}\t{f}:{i}\t{len(x)}")
    if len(LB) >= 1000:
        isnew = len(LA) < 1000; bad += isnew; pre += not isnew
        print(f"{'NEW-SIZE' if isnew else 'PRE-SIZE'}\t{f}\t{len(LA)} -> {len(LB)} lines")
print(f'TOTAL {len(files)} files, {nh} hunks, {bad} failures, {pre} pre-existing width/size findings')
