"""headerbytes_perfile.py <repo> <old-rev> <new-rev> <touched-old.json> <touched-new.json>: headerbytes.py's
raw header comparison (keyword line to the first top-level `:=`/`where`), keyed by (file, name, occurrence)
instead of by name alone, so that same-named private declarations in different files are all compared."""
import sys, json, subprocess, re
repo, old, new, to, tn = sys.argv[1:6]
def show(rev, f): return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True).stdout.decode('utf-8')
def headers(T, rev):
    d = {}
    for f, info in json.load(open(T))['files'].items():
        src = show(rev, f).split('\n'); seen = {}
        for x in info['declarations']:
            text = '\n'.join(src[x['decl_line'] - 1:x['end']]); dep = 0; cut = len(text); i = 0
            while i < len(text):
                c = text[i]
                if c in '([{⟨': dep += 1
                elif c in ')]}⟩': dep -= 1
                elif dep == 0 and text.startswith(':=', i): cut = i; break
                elif dep == 0 and re.match(r'(?<![\w.])where\b', text[i:]) and (i == 0 or not (text[i-1].isalnum() or text[i-1] in '_.')): cut = i; break
                i += 1
            k = seen.get(x['name'], 0); seen[x['name']] = k + 1
            d[(f, x['name'], k)] = text[:cut]
    return d
A, B = headers(to, old), headers(tn, new); bad = 0
for key in sorted(set(A) | set(B)):
    st = 'MISSING' if key not in A or key not in B else ('IDENTICAL' if A[key] == B[key] else 'DIFFERENT')
    bad += st != 'IDENTICAL'; print(f'{st}\t{key[0]}\t{key[1]}\t#{key[2]}')
print(f'TOTAL {len(set(A) | set(B))} compared, {bad} different or missing')
