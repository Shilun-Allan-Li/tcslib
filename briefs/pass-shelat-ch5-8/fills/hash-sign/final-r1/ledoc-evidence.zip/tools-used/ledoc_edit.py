"""ledoc_edit.py <worktree>: hash-sign LE-doc docstring replacements (exact; each old text must
occur exactly once in its file). Every old text is the opening of a `/-- -/` docstring, from `/--`
through its first sentence; the new text adds a backticked formula to that sentence (and, for
polyTimeComputable_collisionRun, a Proof sketch paragraph). Modelled on
dl-crh-r1-ledoc/tools-used/ledoc_edit.py."""
import sys
wt = sys.argv[1]
B = 'TCSlib/Cryptography/Authentication/Signatures/'
D = B + 'HashAndSign/'
E = {}

EXP = ("writing `𝔼 x : X, f x` for `ProbComp.expect (ProbComp.sample X) (fun x => f x)`")
KEYS = ("`pk = pairFstD (S.gen.runAt n [] rg)`, `sk = pairSndD (S.gen.runAt n [] rg)` and\n"
        "`i = H.gen.runAt n [] ri`")
COD = ("`cod = bitCodec (fun _ : Fin 1 => H.domLen.eval n) (fun _ => S.sigLen.eval n)\n"
       "(H.domLen.eval n + S.sigLen.eval n)`")
SIG = ("`σ = S.sign.output (NUPPT.layout u (pairEncode (pairSndD (collisionKey S (seedIn n i ω)))\n"
       "(padStr S.msgLen u (H.eval (pairEncode u (pairEncode i m))))) [] (ω.drop (S.gen.coins.eval n)))`")
INV = "`L = [] ∨ ∃ j m, L = [⟨j, m, hashedReply H S n sk i rs m⟩] ∧ s = m`"

E[B + 'HashAndSign.lean'] = [
("""/-- When hash and signature message widths agree, the hash-and-sign hash word equals the
word used by the two reduction handlers, including on arbitrary list inputs.""",
 """/-- When hash and signature message widths agree, the hash-and-sign hash word equals the
word used by the two reduction handlers, including on arbitrary list inputs: under `hlen`,
`hsHashList H (List.replicate n true) i m =
HashSignForward.hashWord H S (List.replicate n true) i m`."""),
("""/-- For a computation making at most one signing query, the hash-and-sign signing oracle
has the same expected logged payoff as sampling one original signing tape before the run.""",
 """/-- For a computation making at most one signing query, the hash-and-sign signing oracle
has the same expected logged payoff as sampling one original signing tape before the run:
if `c.CostBoundedBy (fun _ => 1) 1`, then
`ProbComp.expect (simulate ((hashAndSign H S hlen).signImpl n (pairEncode sk i)).withLog c
((), [])) g = ProbComp.expect (ProbComp.sample (S.sign.Coins n)) (fun rs =>
ProbComp.expect (simulate (HashSignFill.fixedSign H S n sk i rs).withLog c ((), [])) g)`."""),
("""/-- Hash-and-sign accepts a message/signature pair exactly when the original scheme accepts
the padded hash of that message with the same signature.""",
 """/-- Hash-and-sign accepts a message/signature pair exactly when the original scheme accepts
the padded hash of that message with the same signature:
`(hashAndSign H S hlen).Accepts n (pairEncode pk i) m σ ↔
S.Accepts n pk (padFin (S.msgLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn m))))) σ`."""),
("""/-- On concatenated original-generator and hash-generator tapes, the combined generator
returns the original public and secret keys each paired with the same generated hash index.""",
 """/-- On concatenated original-generator and hash-generator tapes, the combined generator
returns the original public and secret keys each paired with the same generated hash index:
`(hsGen S H).runAt n [] (EnsembleLemmas.coinsEquiv (hsGen_coinLen S H n) (rg, ri)) =
pairEncode (pairEncode pk i) (pairEncode sk i)`, where
""" + KEYS + "."),
("""/-- The hash-and-sign forgery probability equals the common transcript's success
probability averaged over independent original key, hash-index, adversary and signing tapes.""",
 """/-- The hash-and-sign forgery probability equals the common transcript's success
probability averaged over independent original key, hash-index, adversary and signing tapes:
`accept ((hashAndSign H S hlen).forgeGame A 1 n) = 𝔼 rg : S.gen.Coins n, 𝔼 ri : H.gen.Coins n,
𝔼 rA : A.Coins n, 𝔼 rs : S.sign.Coins n, ProbComp.prob
(HashSignFill.transcript H S A n pk sk i rs rA) (HashSignFill.Success H S n pk i)`,
""" + EXP + """, with
""" + KEYS + "."),
("""/-- Every successful common transcript either gives a fresh-message hash collision or
is a successful forgery after forwarding hashes to the original signing oracle.""",
 """/-- Every successful common transcript either gives a fresh-message hash collision or
is a successful forgery after forwarding hashes to the original signing oracle: under `hlen`,
`HashSignFill.Success H S n pk i res →
HashSignFill.CollisionCase H S n i res ∨ HashSignFill.ForwardSuccess H S n pk i res`."""),
]

E[D + 'CodecReaders.lean'] = [
("""/-- Two machine codecs are equal when their move decoders, entry encoders and timeout
outputs are equal.""",
 """/-- Two machine codecs are equal when their move decoders, entry encoders and timeout
outputs are equal:
`a.decodeMove = b.decodeMove → a.encodeEntry = b.encodeEntry → a.timeout = b.timeout → a = b`."""),
("""/-- The signature forger codec is the bit codec with message-length queries,
signature-length answers and a message-plus-signature-length final output.""",
 """/-- The signature forger codec is the bit codec with message-length queries,
signature-length answers and a message-plus-signature-length final output:
`S.forgerCodec n = bitCodec (fun _ : Fin 1 => S.msgLen.eval n) (fun _ : Fin 1 => S.sigLen.eval n)
(S.msgLen.eval n + S.sigLen.eval n)`."""),
("""/-- Splitting the concatenation of two fixed-width words recovers the two words.""",
 """/-- Splitting the concatenation of two fixed-width words recovers the two words:
`splitBits (Fin.append x y) = (x, y)`."""),
("""/-- Reading the concatenated encodings of two words at their total width and splitting the
result recovers the original words.""",
 """/-- Reading the concatenated encodings of two words at their total width and splitting the
result recovers the original words: `splitBits (padFin (a + b) (List.ofFn x ++ List.ofFn y)) =
(x, y)`."""),
]

E[D + 'OneQuery.lean'] = [
("""/-- A computation with unit query costs and budget one either returns immediately or is one
query followed by a return.""",
 """/-- A computation with unit query costs and budget one either returns immediately or is one
query followed by a return: `c.CostBoundedBy (fun _ => 1) 1 →
(∃ a, c = .pure a) ∨ ∃ i x f, c = .query i x (fun y => .pure (f y))`."""),
]

E[D + 'OneQuerySampling.lean'] = [
("""/-- For a computation making at most one query, sampling an independent tape for every
oracle answer is equivalent to sampling one tape before the computation, for every real
payoff of the returned value and full query log.""",
 """/-- For a computation making at most one query, sampling an independent tape for every
oracle answer is equivalent to sampling one tape before the computation, for every real
payoff of the returned value and full query log: if `c.CostBoundedBy (fun _ => 1) 1`, then
`ProbComp.expect (simulate (QueryImpl.ofComp (σ := Unit) (fun i x =>
(ProbComp.sample R).bind fun r => .pure (ans i x r))).withLog c ((), [])) g =
ProbComp.expect (ProbComp.sample R) (fun r => ProbComp.expect
(simulate (QueryImpl.withLog (fun i x _ => .pure (ans i x r, ()))) c ((), [])) g)`."""),
]

E[D + 'CollisionGame.lean'] = [
("""/-- The collision case of a common transcript: its final message is distinct from every
logged query, and some logged query has its hash [PS10, Theorem 144.1].""",
 """/-- The collision case of a common transcript: its final message is distinct from every
logged query, and some logged query has its hash,
`CollisionCase H S n i res ↔ (∀ e ∈ res.2.2, e.2.1 ≠ m) ∧
∃ e ∈ res.2.2, H.hash n i e.2.1 = H.hash n i m`, where `m = (splitBits res.1).1`
[PS10, Theorem 144.1]."""),
("""/-- The collision case holds exactly when the final message is fresh and a logged query
has the same hash as that message.""",
 """/-- The collision case holds exactly when the final message is fresh and a logged query
has the same hash as that message: `CollisionCase H S n i res ↔ (∀ e ∈ res.2.2, e.2.1 ≠ m) ∧
∃ e ∈ res.2.2, H.hash n i e.2.1 = H.hash n i m`, where `m = (splitBits res.1).1`."""),
("""/-- A machine's collision probability bounds the collision case of the common transcript,
averaged over the original keys, hash index, adversary tape and signing tape
[PS10, Theorem 144.1].""",
 """/-- A machine's collision probability bounds the collision case of the common transcript,
averaged over the original keys, hash index, adversary tape and signing tape: if
`∀ n i x, H.inDom n i x = true`, then `∃ B : NUPPT, ∀ n, 𝔼 rg : S.gen.Coins n,
𝔼 ri : H.gen.Coins n, 𝔼 rA : A.Coins n, 𝔼 rs : S.sign.Coins n, ProbComp.prob
(transcript H S A n pk sk i rs rA) (CollisionCase H S n i) ≤ accept (H.collisionGame B n)`,
""" + EXP + """, with
""" + KEYS + """ [PS10, Theorem 144.1]."""),
]

E[D + 'CollisionHandler.lean'] = [
("""/-- The signature key word generated from the first `S.gen.coins(n)` bits of the
context seed, with empty argument and advice [PS10, Theorem 144.1].""",
 """/-- The signature key word generated from the first `S.gen.coins(n)` bits of the
context seed, with empty argument and advice,
`collisionKey S c = S.gen.output (NUPPT.layout u [] [] (ω.take (S.gen.coins.eval u.length)))`,
where `u = pairFstD c` and `ω = pairSndD (pairSndD c)` [PS10, Theorem 144.1]."""),
("""/-- `collisionKey S c` runs the original key generator on the parameter and the first
generator-sized segment of the context seed.""",
 """/-- `collisionKey S c` runs the original key generator on the parameter and the first
generator-sized segment of the context seed:
`collisionKey S c = S.gen.output (NUPPT.layout u [] [] (ω.take (S.gen.coins.eval u.length)))`,
where `u = pairFstD c` and `ω = pairSndD (pairSndD c)`."""),
("""/-- Generating the signature key from a context is polynomial-time.""",
 """/-- Generating the signature key from a context is polynomial-time:
`PolyTimeComputable (collisionKey S)`, for `collisionKey S : List Bool → List Bool`."""),
("""/-- When the context seed concatenates generator and signing tapes, `collisionKey` is
exactly the original generator's run on its own tape.""",
 """/-- When the context seed concatenates generator and signing tapes, `collisionKey` is
exactly the original generator's run on its own tape:
`collisionKey S (seedIn n i (List.ofFn rg ++ List.ofFn rs)) = S.gen.runAt n [] rg`."""),
("""/-- The adversary receives `⟨pk, i⟩`, where the context supplies the hash index and
`collisionKey` supplies the public signature key [PS10, Theorem 144.1].""",
 """/-- The adversary receives `⟨pk, i⟩`, where the context supplies the hash index and
`collisionKey` supplies the public signature key,
`collisionAdv S c = pairEncode (pairFstD (collisionKey S c)) (pairFstD (pairSndD c))`
[PS10, Theorem 144.1]."""),
("""/-- The adversary input is the original public key paired with the context index.""",
 """/-- The adversary input is the original public key paired with the context index:
`collisionAdv S c = pairEncode (pairFstD (collisionKey S c)) (pairFstD (pairSndD c))`."""),
("""/-- Pairing the generated public key with the index is polynomial-time.""",
 """/-- Pairing the generated public key with the index is polynomial-time:
`PolyTimeComputable (collisionAdv S)`, for `collisionAdv S : List Bool → List Bool`."""),
("""/-- At `seedIn n i ω`, the adversary input is `⟨pk, i⟩`, where the original generator
runs with the first `S.gen.coins(n)` seed bits.""",
 """/-- At `seedIn n i ω`, the adversary input is `⟨pk, i⟩`, where the original generator
runs with the first `S.gen.coins(n)` seed bits: `collisionAdv S (seedIn n i ω) =
pairEncode (pairFstD (S.gen.output (NUPPT.layout (List.replicate n true) [] []
(ω.take (S.gen.coins.eval n))))) i`."""),
("""/-- On concatenated generator and signing tapes, the adversary receives the public key
from that generator run paired with the supplied hash index.""",
 """/-- On concatenated generator and signing tapes, the adversary receives the public key
from that generator run paired with the supplied hash index:
`collisionAdv S (seedIn n i (List.ofFn rg ++ List.ofFn rs)) =
pairEncode (pairFstD (S.gen.runAt n [] rg)) i`."""),
("""/-- The query hash in a handler-round word is the CRH evaluator padded to the signature
message length.""",
 """/-- The query hash in a handler-round word is the CRH evaluator padded to the signature
message length: `collisionHash H S w = padStr S.msgLen u (H.eval (pairEncode u (pairEncode i x)))`,
where `u = pairFstD (pairFstD w)`, `i = pairFstD (pairSndD (pairFstD w))` and
`x = pairSndD (pairSndD (pairSndD w))`."""),
("""/-- The query hash runs the evaluator at the context parameter and index on the query
word and pads its output to the signature message length.""",
 """/-- The query hash runs the evaluator at the context parameter and index on the query
word and pads its output to the signature message length:
`collisionHash H S w = padStr S.msgLen u (H.eval (pairEncode u (pairEncode i x)))`, where
`u = pairFstD (pairFstD w)`, `i = pairFstD (pairSndD (pairFstD w))` and
`x = pairSndD (pairSndD (pairSndD w))`."""),
("""/-- Evaluating and padding the query hash is polynomial-time by the CRH evaluator and
the published padding construction.""",
 """/-- Evaluating and padding the query hash is polynomial-time by the CRH evaluator and
the published padding construction: `PolyTimeComputable (collisionHash H S)`, for
`collisionHash H S : List Bool → List Bool`."""),
("""/-- A collision-finder round signs the query hash using the remaining seed and records
the query as its new state [PS10, Theorem 144.1].""",
 """/-- A collision-finder round signs the query hash using the remaining seed and records
the query as its new state, `collisionRun H S w = pairEncode (padStr S.sigLen u
(S.sign.output (NUPPT.layout u (pairEncode (pairSndD (collisionKey S (pairFstD w)))
(collisionHash H S w)) [] (ω.drop (S.gen.coins.eval u.length))))) x`, where
`u = pairFstD (pairFstD w)`, `ω = pairSndD (pairSndD (pairFstD w))` and
`x = pairSndD (pairSndD (pairSndD w))` [PS10, Theorem 144.1]."""),
("""/-- A round returns the padded original signature and the queried message.""",
 """/-- A round returns the padded original signature and the queried message:
`collisionRun H S w = pairEncode (padStr S.sigLen u (S.sign.output (NUPPT.layout u
(pairEncode (pairSndD (collisionKey S (pairFstD w))) (collisionHash H S w)) []
(ω.drop (S.gen.coins.eval u.length))))) x`, where `u = pairFstD (pairFstD w)`,
`ω = pairSndD (pairSndD (pairFstD w))` and `x = pairSndD (pairSndD (pairSndD w))`."""),
("""/-- The collision-finder round is polynomial-time. It uses a polynomial-length coin
suffix, the polynomial-time signer and padding, then pairs the result with the query. -/""",
 """/-- The collision-finder round is polynomial-time: `PolyTimeComputable (collisionRun H S)`,
for `collisionRun H S : List Bool → List Bool`. It uses a polynomial-length coin suffix,
the polynomial-time signer and padding, then pairs the result with the query.

**Proof sketch.** Write `u` for the parameter word, `ω` for the context seed and `x` for the
query word of a round input; each is a composition of pair projections, hence polynomial-time.
The signer's tape is `ω` with its first `S.gen.coins(|u|)` bits dropped, computed by the
published polynomial-length drop construction on the pair `⟨u, ω⟩`. The secret key is the
second component of the polynomial-time `collisionKey`, and the query hash is polynomial-time
(`polyTimeComputable_collisionHash`). The original signer's output on the layout of `u`, the
pair of key and hash, empty advice and that tape is then polynomial-time, and so is padding
it to `S.sigLen(|u|)` bits by the published padding construction on `⟨u, ·⟩`. Pairing the
padded signature with `x` gives the round. -/"""),
("""/-- The collision output concatenates the remembered query with the first `H.domLen(n)`
bits of the adversary's final word [PS10, Theorem 144.1].""",
 """/-- The collision output concatenates the remembered query with the first `H.domLen(n)`
bits of the adversary's final word, `collisionOut H w = pairFstD (pairSndD w) ++
(pairSndD (pairSndD w)).take (H.domLen.eval (pairFstD (pairFstD w)).length)`
[PS10, Theorem 144.1]."""),
("""/-- The collision output is the state followed by the message prefix of the forgery.""",
 """/-- The collision output is the state followed by the message prefix of the forgery:
`collisionOut H w = pairFstD (pairSndD w) ++
(pairSndD (pairSndD w)).take (H.domLen.eval (pairFstD (pairFstD w)).length)`."""),
("""/-- Reading a polynomial-length forgery prefix and appending it to the stored query is
polynomial-time.""",
 """/-- Reading a polynomial-length forgery prefix and appending it to the stored query is
polynomial-time: `PolyTimeComputable (collisionOut H)`, for
`collisionOut H : List Bool → List Bool`."""),
("""/-- The T1 collision finder samples signature-generation and signing coins, remembers one
domain-width query, and emits the query followed by the forged message [PS10, Theorem 144.1].""",
 """/-- The T1 collision finder samples signature-generation and signing coins, remembers one
domain-width query, and emits the query followed by the forged message: its fields are
`stateLen = H.domLen`, `seedLen = .add S.gen.coins S.sign.coins`, `init _ = zeroBits _`,
`run = collisionRun H S`, `advIn = collisionAdv S` and `out = collisionOut H`
[PS10, Theorem 144.1]."""),
("""/-- On a well-formed round input, the collision handler returns the padded signature on
the query hash and stores exactly the query.""",
 """/-- On a well-formed round input, the collision handler returns the padded signature on
the query hash and stores exactly the query:
`(collisionHandler H S).run (PolyHandler.input n i ω s j m) = pairEncode (padStr S.sigLen u σ) m`,
where `u = List.replicate n true` and
""" + SIG + "."),
("""/-- The typed signature returned by the collision handler: run the original signer on the
hashed message with the seed suffix and pad its output to `S.sigLen(n)` bits.""",
 """/-- The typed signature returned by the collision handler: run the original signer on the
hashed message with the seed suffix and pad its output to `S.sigLen(n)` bits,
`collisionReply H S n i ω m = padFin (S.sigLen.eval n) σ`, where `u = List.replicate n true` and
""" + SIG + "."),
("""/-- The typed reply is the original signer output padded to the signature length.""",
 """/-- The typed reply is the original signer output padded to the signature length:
`collisionReply H S n i ω m = padFin (S.sigLen.eval n) σ`, where `u = List.replicate n true` and
""" + SIG + "."),
("""/-- With the generator and signing tapes concatenated into the context seed, the collision
handler's reply is the fixed experiment's hashed reply under those same generated keys.""",
 """/-- With the generator and signing tapes concatenated into the context seed, the collision
handler's reply is the fixed experiment's hashed reply under those same generated keys:
`collisionReply H S n i (List.ofFn rg ++ List.ofFn rs) (List.ofFn m) =
hashedReply H S n (pairSndD (S.gen.runAt n [] rg)) i rs m`."""),
("""/-- Encoding the typed reply gives exactly the padded signature word emitted by a
collision-handler round.""",
 """/-- Encoding the typed reply gives exactly the padded signature word emitted by a
collision-handler round: `List.ofFn (collisionReply H S n i ω m) = padStr S.sigLen u σ`, where
`u = List.replicate n true` and
""" + SIG + "."),
("""/-- The collision handler answers each typed query with its padded original signature and
sets the state to that query, asking no further oracle.""",
 """/-- The collision handler answers each typed query with its padded original signature and
sets the state to that query, asking no further oracle: `(collisionHandler H S).impl n i ω j m s =
.pure (collisionReply H S n i (List.ofFn ω) (List.ofFn m), m)`."""),
("""/-- Finalization returns the remembered query followed by the domain-width message prefix
of the adversary's output.""",
 """/-- Finalization returns the remembered query followed by the domain-width message prefix
of the adversary's output: `(collisionHandler H S).result n i ω s a =
List.ofFn s ++ (List.ofFn a).take (H.domLen.eval n)`."""),
("""/-- The collision handler and common fixed-tape transcript return the same adversary
output.""",
 """/-- The collision handler and common fixed-tape transcript return the same adversary
output: if `List.ofFn ω = List.ofFn rg ++ List.ofFn rs`, then `∃ a s L,
simulate ((collisionHandler H S).impl n i ω) (A.toCompOn cod n 1
((collisionHandler H S).advInput n i ω) rA) ((collisionHandler H S).init n) = .pure (a, s) ∧
transcript H S A n pk sk i rs rA = .pure (a, ((), L)) ∧
(L = [] ∨ ∃ j m, L = [⟨j, m, hashedReply H S n sk i rs m⟩] ∧ s = m)`, where
`pk = pairFstD (S.gen.runAt n [] rg)`, `sk = pairSndD (S.gen.runAt n [] rg)` and
""" + COD + "."),
("""/-- If the common transcript is fresh and contains a query with the forged message's
hash, the collision handler's final output satisfies the CRH game's exact collision
predicate on the full domain [PS10, Theorem 144.1, collision case].""",
 """/-- If the common transcript is fresh and contains a query with the forged message's
hash, the collision handler's final output satisfies the CRH game's exact collision
predicate on the full domain: given `∀ n i x, H.inDom n i x = true`,
""" + INV + """,
`∀ e ∈ L, e.2.1 ≠ (splitBits a).1` and `∃ e ∈ L, H.hash n i e.2.1 = H.hash n i (splitBits a).1`,
then `H.inDom n i x₁ = true ∧ H.inDom n i x₂ = true ∧ x₁ ≠ x₂ ∧ H.hash n i x₁ = H.hash n i x₂`,
where `(x₁, x₂) = splitBits (padFin (H.domLen.eval n + H.domLen.eval n)
((collisionHandler H S).result n i ω s a))` [PS10, Theorem 144.1, collision case]."""),
("""/-- T1 realizes the collision handler as a machine: on matching seed/adversary coins,
its output equals `collisionHandler.result` after the deterministic simulation.""",
 """/-- T1 realizes the collision handler as a machine: on matching seed/adversary coins,
its output equals `collisionHandler.result` after the deterministic simulation,
`∃ B : NUPPT, ∀ n, ∃ φ : (Fin (K.seedLen.eval n) → Bool) × A.Coins n ≃ B.Coins n, ∀ i ω r,
∃ a s, simulate (K.impl n i ω) (A.toCompOn cod n ((.const 1 : PolyExpr).eval n)
(K.advInput n i ω) r) (K.init n) = .pure (a, s) ∧ B.runAt n i (φ (ω, r)) = K.result n i ω s a`,
where `K = collisionHandler H S` and `cod = bitCodec (fun _ : Fin 1 => H.domLen.eval n)
(fun _ : Fin 1 => S.sigLen.eval n) ((PolyExpr.add H.domLen S.sigLen).eval n)`."""),
("""/-- T1 supplies a collision machine whose output is the finalization of the common
fixed-tape transcript.""",
 """/-- T1 supplies a collision machine whose output is the finalization of the common
fixed-tape transcript: `∃ B : NUPPT, ∀ n, ∃ φ : (Fin (K.seedLen.eval n) → Bool) × A.Coins n ≃
B.Coins n, ∀ i rg rs ω rA, List.ofFn ω = List.ofFn rg ++ List.ofFn rs → ∃ a s L,
transcript H S A n pk sk i rs rA = .pure (a, ((), L)) ∧
(L = [] ∨ ∃ j m, L = [⟨j, m, hashedReply H S n sk i rs m⟩] ∧ s = m) ∧
B.runAt n i (φ (ω, rA)) = K.result n i ω s a`, where `K = collisionHandler H S`,
`pk = pairFstD (S.gen.runAt n [] rg)` and `sk = pairSndD (S.gen.runAt n [] rg)`."""),
]

E[D + 'FixedGame.lean'] = [
("""/-- With signing tape `rs` fixed, hash `m` and run the original signer under `sk`, padding
the signature to the declared signature width [PS10, Theorem 144.1].""",
 """/-- With signing tape `rs` fixed, hash `m` and run the original signer under `sk`, padding
the signature to the declared signature width, `hashedReply H S n sk i rs m =
padFin (S.sigLen.eval n) (S.sign.runAt n (pairEncode sk (hashWord H S u i (List.ofFn m))) rs)`,
where `u = List.replicate n true` and `hashWord = HashSignForward.hashWord`
[PS10, Theorem 144.1]."""),
("""/-- The fixed-tape hashed reply is the padded original signer output on `⟨sk, h_i(m)⟩`.""",
 """/-- The fixed-tape hashed reply is the padded original signer output on `⟨sk, h_i(m)⟩`:
`hashedReply H S n sk i rs m =
padFin (S.sigLen.eval n) (S.sign.runAt n (pairEncode sk (hashWord H S u i (List.ofFn m))) rs)`,
where `u = List.replicate n true` and `hashWord = HashSignForward.hashWord`."""),
("""/-- The fixed-tape signing oracle answers every query using `hashedReply` and has trivial
state [PS10, Theorem 144.1].""",
 """/-- The fixed-tape signing oracle answers every query using `hashedReply` and has trivial
state, `fixedSign H S n sk i rs j m s = .pure (hashedReply H S n sk i rs m, ())`
[PS10, Theorem 144.1]."""),
("""/-- The fixed-tape oracle is the pure answer function `m ↦ (hashedReply m, ())`.""",
 """/-- The fixed-tape oracle is the pure answer function `m ↦ (hashedReply m, ())`:
`fixedSign H S n sk i rs = fun _ m _ => .pure (hashedReply H S n sk i rs m, ())`."""),
("""/-- Applying the fixed-tape oracle returns the hashed signature and trivial state.""",
 """/-- Applying the fixed-tape oracle returns the hashed signature and trivial state:
`fixedSign H S n sk i rs j m s = .pure (hashedReply H S n sk i rs m, ())`."""),
("""/-- The common transcript runs `A` on `⟨pk,i⟩` with one query allowed, fixed signing tape,
and a full query log [PS10, Theorem 144.1].""",
 """/-- The common transcript runs `A` on `⟨pk,i⟩` with one query allowed, fixed signing tape,
and a full query log, `transcript H S A n pk sk i rs rA =
simulate (fixedSign H S n sk i rs).withLog (A.toCompOn cod n 1 (pairEncode pk i) rA) ((), [])`,
where """ + COD + """ [PS10, Theorem 144.1]."""),
("""/-- The common transcript is the logged simulation with the fixed-tape signing oracle.""",
 """/-- The common transcript is the logged simulation with the fixed-tape signing oracle:
`transcript H S A n pk sk i rs rA =
simulate (fixedSign H S n sk i rs).withLog (A.toCompOn cod n 1 (pairEncode pk i) rA) ((), [])`,
where """ + COD + "."),
("""/-- The fresh-tape hash-and-sign oracle samples an original signing tape independently
for every query and keeps trivial state [PS10, Theorem 144.1].""",
 """/-- The fresh-tape hash-and-sign oracle samples an original signing tape independently
for every query and keeps trivial state, `sampledHashSign H S n sk i = QueryImpl.ofComp
fun _ m => (ProbComp.sample (S.sign.Coins n)).bind fun rs => .pure (hashedReply H S n sk i rs m)`
[PS10, Theorem 144.1]."""),
("""/-- The fresh-tape oracle is `ofComp` of the original signing-tape sample followed by
the corresponding fixed-tape hashed reply.""",
 """/-- The fresh-tape oracle is `ofComp` of the original signing-tape sample followed by
the corresponding fixed-tape hashed reply: `sampledHashSign H S n sk i = QueryImpl.ofComp
(fun _ m => (ProbComp.sample (S.sign.Coins n)).bind fun rs =>
.pure (hashedReply H S n sk i rs m))`."""),
("""/-- Applying the fresh-tape oracle samples one signing tape, returns its hashed signature,
and preserves the trivial state.""",
 """/-- Applying the fresh-tape oracle samples one signing tape, returns its hashed signature,
and preserves the trivial state: `sampledHashSign H S n sk i j m s =
(ProbComp.sample (S.sign.Coins n)).bind fun rs => .pure (hashedReply H S n sk i rs m, s)`."""),
("""/-- The expected payoff of a fresh-tape hash-and-sign simulation equals the expectation
obtained by drawing one signing tape and running the common transcript, including its log.""",
 """/-- The expected payoff of a fresh-tape hash-and-sign simulation equals the expectation
obtained by drawing one signing tape and running the common transcript, including its log:
`ProbComp.expect (simulate (sampledHashSign H S n sk i).withLog
(A.toCompOn cod n 1 (pairEncode pk i) rA) ((), [])) g = ProbComp.expect
(ProbComp.sample (S.sign.Coins n)) (fun rs =>
ProbComp.expect (transcript H S A n pk sk i rs rA) g)`,
where """ + COD + "."),
("""/-- The common transcript is a successful hash-and-sign forgery when the original verifier
accepts the hashed final message and that message did not occur in the inner query log
[PS10, Theorem 144.1].""",
 """/-- The common transcript is a successful hash-and-sign forgery when the original verifier
accepts the hashed final message and that message did not occur in the inner query log,
`Success H S n pk i res ↔ S.Accepts n pk (padFin (S.msgLen.eval n)
(H.eval (atParam n (pairEncode i (List.ofFn m))))) σ ∧ ∀ e ∈ res.2.2, e.2.1 ≠ m`, where
`(m, σ) = splitBits res.1` [PS10, Theorem 144.1]."""),
("""/-- Success is original-scheme acceptance on the hash, together with freshness of the
unhashed final message in the common query log.""",
 """/-- Success is original-scheme acceptance on the hash, together with freshness of the
unhashed final message in the common query log: `Success H S n pk i res ↔
S.Accepts n pk (padFin (S.msgLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn m))))) σ ∧
∀ e ∈ res.2.2, e.2.1 ≠ m`, where `(m, σ) = splitBits res.1`."""),
]

E[D + 'ForwardGame.lean'] = [
("""/-- The hash of a domain-width message, padded to the original signature message width.""",
 """/-- The hash of a domain-width message, padded to the original signature message width:
`queryHash H S n i m =
padFin (S.msgLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn m))))`."""),
("""/-- The typed hash reads the evaluator output at the original message width.""",
 """/-- The typed hash reads the evaluator output at the original message width:
`queryHash H S n i m =
padFin (S.msgLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn m))))`."""),
("""/-- The original signature oracle with a fixed signing tape and trivial state.""",
 """/-- The original signature oracle with a fixed signing tape and trivial state:
`origFixedSign S n sk rs j m s =
.pure (padFin (S.sigLen.eval n) (S.sign.runAt n (pairEncode sk (List.ofFn m)) rs), ())`."""),
("""/-- The fixed original signer returns its padded signature and trivial state.""",
 """/-- The fixed original signer returns its padded signature and trivial state:
`origFixedSign S n sk rs = fun _ m _ =>
.pure (padFin (S.sigLen.eval n) (S.sign.runAt n (pairEncode sk (List.ofFn m)) rs), ())`."""),
("""/-- Applying the fixed original signer returns its padded signature.""",
 """/-- Applying the fixed original signer returns its padded signature:
`origFixedSign S n sk rs j m s =
.pure (padFin (S.sigLen.eval n) (S.sign.runAt n (pairEncode sk (List.ofFn m)) rs), ())`."""),
("""/-- A forwarded log entry asks oracle zero the hash of the inner query and records the
same signature answer.""",
 """/-- A forwarded log entry asks oracle zero the hash of the inner query and records the
same signature answer: `forwardEntry H S n i e = ⟨0, queryHash H S n i e.2.1, e.2.2⟩`."""),
("""/-- Forwarding an entry replaces its query by its hash and retains its signature answer.""",
 """/-- Forwarding an entry replaces its query by its hash and retains its signature answer:
`forwardEntry H S n i e = ⟨0, queryHash H S n i e.2.1, e.2.2⟩`."""),
("""/-- The forwarded output is the hashed message followed by the unchanged signature.""",
 """/-- The forwarded output is the hashed message followed by the unchanged signature:
`forwardOutput H S n i a = Fin.append (queryHash H S n i (splitBits a).1) (splitBits a).2`."""),
("""/-- The forwarded output concatenates the hash of the message with the signature.""",
 """/-- The forwarded output concatenates the hash of the message with the signature:
`forwardOutput H S n i a = Fin.append (queryHash H S n i (splitBits a).1) (splitBits a).2`."""),
("""/-- The forwarded output transported to the declared handler output width.""",
 """/-- The forwarded output transported to the declared handler output width:
`handlerOutput H S n i a j =
forwardOutput H S n i a (Fin.cast (HashSignForward.handler_output_width H S n) j)`."""),
("""/-- The handler output is the forwarded output evaluated through its width cast.""",
 """/-- The handler output is the forwarded output evaluated through its width cast:
`handlerOutput H S n i a =
fun j => forwardOutput H S n i a (Fin.cast (HashSignForward.handler_output_width H S n) j)`."""),
("""/-- Querying the original fixed signer on a typed hash gives the common transcript's
hashed reply.""",
 """/-- Querying the original fixed signer on a typed hash gives the common transcript's
hashed reply: `origFixedSign S n sk rs 0 (queryHash H S n i m) () =
.pure (hashedReply H S n sk i rs m, ())`."""),
("""/-- The forwarding handler's finalization returns the transported forwarded output.""",
 """/-- The forwarding handler's finalization returns the transported forwarded output:
`(HashSignForward.handler H S).finish n pk ω s a =
.pure (handlerOutput H S n (H.gen.runAtL n [] (List.ofFn ω)) a)`."""),
("""/-- Fixing the signing tape gives a common adversary output for the inner transcript
and the forwarding reduction.""",
 """/-- Fixing the signing tape gives a common adversary output for the inner transcript
and the forwarding reduction: if `c.CostBoundedBy (fun _ => 1) 1`, then `∃ a L,
simulate (fixedSign H S n sk i rs).withLog c ((), []) = .pure (a, ((), L)) ∧
simulate (origFixedSign S n sk rs).withLog ((simulate (K.impl n pk ω) c (K.init n)).bind
fun res => K.finish n pk ω res.2 res.1) ((), []) =
.pure (handlerOutput H S n i a, ((), L.map (forwardEntry H S n i)))`, where
`K = HashSignForward.handler H S` and `i = H.gen.runAtL n [] (List.ofFn ω)`."""),
("""/-- The message component of the forwarded output is the hash of the inner message.""",
 """/-- The message component of the forwarded output is the hash of the inner message:
`(splitBits (forwardOutput H S n i a)).1 = queryHash H S n i (splitBits a).1`."""),
("""/-- The signature component of the forwarded output is the original signature component.""",
 """/-- The signature component of the forwarded output is the original signature component:
`(splitBits (forwardOutput H S n i a)).2 = (splitBits a).2`."""),
("""/-- If no logged inner query has the hash of the final message, the final hashed message
is fresh in the forwarded log.""",
 """/-- If no logged inner query has the hash of the final message, the final hashed message
is fresh in the forwarded log:
`(∀ e ∈ L, queryHash H S n i e.2.1 ≠ queryHash H S n i (splitBits a).1) →
∀ e ∈ L.map (forwardEntry H S n i), e.2.1 ≠ (splitBits (forwardOutput H S n i a)).1`."""),
("""/-- Forwarding succeeds when the original verifier accepts the final hashed message and
no inner query has that hash [PS10, Theorem 144.1].""",
 """/-- Forwarding succeeds when the original verifier accepts the final hashed message and
no inner query has that hash, `ForwardSuccess H S n pk i res ↔
S.Accepts n pk (queryHash H S n i m) σ ∧
∀ e ∈ res.2.2, queryHash H S n i e.2.1 ≠ queryHash H S n i m`,
where `(m, σ) = splitBits res.1` [PS10, Theorem 144.1]."""),
("""/-- Forwarding success is original-scheme acceptance and freshness of the final hash
among all hashed inner queries.""",
 """/-- Forwarding success is original-scheme acceptance and freshness of the final hash
among all hashed inner queries: `ForwardSuccess H S n pk i res ↔
S.Accepts n pk (queryHash H S n i m) σ ∧
∀ e ∈ res.2.2, queryHash H S n i e.2.1 ≠ queryHash H S n i m`,
where `(m, σ) = splitBits res.1`."""),
("""/-- The original forgery event tests acceptance and message freshness on a logged
original-signature transcript [PS10, Definition 136.2].""",
 """/-- The original forgery event tests acceptance and message freshness on a logged
original-signature transcript,
`OriginalSuccess S n pk res ↔ S.Accepts n pk m σ ∧ ∀ e ∈ res.2.2, e.2.1 ≠ m`, where
`(m, σ) = splitBits res.1` [PS10, Definition 136.2]."""),
("""/-- The original forgery event is acceptance together with freshness in its logged
original-message queries.""",
 """/-- The original forgery event is acceptance together with freshness in its logged
original-message queries:
`OriginalSuccess S n pk res ↔ S.Accepts n pk m σ ∧ ∀ e ∈ res.2.2, e.2.1 ≠ m`, where
`(m, σ) = splitBits res.1`."""),
("""/-- Hashing the output and every logged query turns the original forgery event into
the common transcript's forwarding-success event.""",
 """/-- Hashing the output and every logged query turns the original forgery event into
the common transcript's forwarding-success event:
`OriginalSuccess S n pk (forwardOutput H S n i a, ((), L.map (forwardEntry H S n i))) ↔
ForwardSuccess H S n pk i (a, ((), L))`."""),
("""/-- The original one-query forgery game may draw its signing tape before the logged
simulation [PS10, Definition 136.2, one-time specialization].""",
 """/-- The original one-query forgery game may draw its signing tape before the logged
simulation, `accept (S.forgeGame C 1 n) = 𝔼 rg : S.gen.Coins n, 𝔼 r : C.Coins n,
𝔼 rs : S.sign.Coins n, ProbComp.prob (simulate (origFixedSign S n sk rs).withLog
(C.toCompOn cod n 1 pk r) ((), [])) (OriginalSuccess S n pk)`,
""" + EXP + """, with
`pk = pairFstD (S.gen.runAt n [] rg)`, `sk = pairSndD (S.gen.runAt n [] rg)` and
`cod = bitCodec (fun _ : Fin 1 => S.msgLen.eval n) (fun _ => S.sigLen.eval n)
(S.msgLen.eval n + S.sigLen.eval n)` [PS10, Definition 136.2, one-time specialization]."""),
("""/-- The transported handler output and the forwarded output have the same bit list.""",
 """/-- The transported handler output and the forwarded output have the same bit list:
`List.ofFn (handlerOutput H S n i a) = List.ofFn (forwardOutput H S n i a)`."""),
("""/-- With all tapes fixed, reading the forwarding reduction's output list at the original
game's width gives the common transcript's forwarding-success probability.""",
 """/-- With all tapes fixed, reading the forwarding reduction's output list at the original
game's width gives the common transcript's forwarding-success probability: if
`c.CostBoundedBy (fun _ => 1) 1`, then `ProbComp.prob ((simulate (origFixedSign S n sk rs).withLog
R ((), [])).bind fun res => .pure (padFin (S.msgLen.eval n + S.sigLen.eval n) (List.ofFn res.1),
res.2)) (OriginalSuccess S n pk) = ProbComp.prob
(simulate (fixedSign H S n sk i rs).withLog c ((), [])) (ForwardSuccess H S n pk i)`, where
`R = (simulate (K.impl n pk ω) c (K.init n)).bind fun res => K.finish n pk ω res.2 res.1`,
`K = HashSignForward.handler H S` and `i = H.gen.runAtL n [] (List.ofFn ω)`."""),
("""/-- A one-query machine against the original scheme realizes exactly the common
transcript's forwarding-success probability [PS10, Theorem 144.1].""",
 """/-- A one-query machine against the original scheme realizes exactly the common
transcript's forwarding-success probability, `∃ C : NUPPT, ∀ n, accept (S.forgeGame C 1 n) =
𝔼 rg : S.gen.Coins n, 𝔼 ri : H.gen.Coins n, 𝔼 rA : A.Coins n, 𝔼 rs : S.sign.Coins n,
ProbComp.prob (transcript H S A n pk sk i rs rA) (ForwardSuccess H S n pk i)`,
""" + EXP + """, with
""" + KEYS + """ [PS10, Theorem 144.1]."""),
]

E[D + 'ForwardHandler.lean'] = [
("""/-- The index generator on parameter word `u` and seed `ω`, with empty input and advice.""",
 """/-- The index generator on parameter word `u` and seed `ω`, with empty input and advice:
`indexWord H u ω = H.gen.output (NUPPT.layout u [] [] ω)`."""),
("""/-- The index word is `H.gen.output (NUPPT.layout u [] [] ω)`.""",
 """/-- The index word is `H.gen.output (NUPPT.layout u [] [] ω)`:
`indexWord H u ω = H.gen.output (NUPPT.layout u [] [] ω)`."""),
("""/-- The hash of `m` at index `i`, padded to the original scheme's message length.""",
 """/-- The hash of `m` at index `i`, padded to the original scheme's message length:
`hashWord H S u i m = padStr S.msgLen u (H.eval (pairEncode u (pairEncode i m)))`."""),
("""/-- The hash word is the evaluator output padded to `S.msgLen(|u|)` bits.""",
 """/-- The hash word is the evaluator output padded to `S.msgLen(|u|)` bits:
`hashWord H S u i m = padStr S.msgLen u (H.eval (pairEncode u (pairEncode i m)))`."""),
("""/-- The reduction gives its adversary the public key paired with its sampled index.""",
 """/-- The reduction gives its adversary the public key paired with its sampled index:
`advWord H w =
pairEncode (pairFstD (pairSndD w)) (indexWord H (pairFstD w) (pairSndD (pairSndD w)))`."""),
("""/-- The adversary input pairs the reduction input with the index obtained from its seed.""",
 """/-- The adversary input pairs the reduction input with the index obtained from its seed:
`advWord H w =
pairEncode (pairFstD (pairSndD w)) (indexWord H (pairFstD w) (pairSndD (pairSndD w)))`."""),
("""/-- The first round asks the original signing oracle the hashed message; the second
round returns the outer signature and preserves the state.""",
 """/-- The first round asks the original signing oracle the hashed message; the second
round returns the outer signature and preserves the state: `roundWord H S w =
if decide (rL w = []) then pairEncode [false] (pairEncode [] (hashWord H S u (indexWord H u (rW w))
(rX w))) else pairEncode [true] (rAns w ++ rS w)`, where `u = rU w`."""),
("""/-- The round asks the hashed query when its outer log is empty, and otherwise returns
the first outer answer together with its unchanged state.""",
 """/-- The round asks the hashed query when its outer log is empty, and otherwise returns
the first outer answer together with its unchanged state: `roundWord H S w =
if decide (rL w = []) then pairEncode [false] (pairEncode [] (hashWord H S u (indexWord H u (rW w))
(rX w))) else pairEncode [true] (rAns w ++ rS w)`, where `u = rU w`."""),
("""/-- The finalization hashes the message prefix of the adversary output and retains
its signature suffix, making no further oracle query.""",
 """/-- The finalization hashes the message prefix of the adversary output and retains
its signature suffix, making no further oracle query: `finalWord H S w =
pairEncode [true] (hashWord H S u (indexWord H u (rW w)) (a.take k) ++ a.drop k)`, where
`u = rU w`, `a = finA w` and `k = H.domLen.eval u.length`."""),
("""/-- The final output is the hashed message prefix concatenated with the signature suffix.""",
 """/-- The final output is the hashed message prefix concatenated with the signature suffix:
`finalWord H S w =
pairEncode [true] (hashWord H S u (indexWord H u (rW w)) (a.take k) ++ a.drop k)`, where
`u = rU w`, `a = finA w` and `k = H.domLen.eval u.length`."""),
("""/-- Running the index generator on polynomial-time parameter and seed words is
polynomial-time.""",
 """/-- Running the index generator on polynomial-time parameter and seed words is
polynomial-time: `PolyTimeComputable u → PolyTimeComputable ω →
PolyTimeComputable fun w => indexWord H (u w) (ω w)`."""),
("""/-- Hashing polynomial-time parameter, index and message words and padding the result
to the original signature message length is polynomial-time.""",
 """/-- Hashing polynomial-time parameter, index and message words and padding the result
to the original signature message length is polynomial-time: `PolyTimeComputable u →
PolyTimeComputable i → PolyTimeComputable m →
PolyTimeComputable fun w => hashWord H S (u w) (i w) (m w)`."""),
("""/-- Pairing the supplied public key with the index generated from the seed is
polynomial-time.""",
 """/-- Pairing the supplied public key with the index generated from the seed is
polynomial-time: `PolyTimeComputable (advWord H)`, for `advWord H : List Bool → List Bool`."""),
("""/-- One hashing-and-forwarding round is polynomial-time: it tests whether the outer
log is empty, then either emits the hash query or returns the recorded answer.""",
 """/-- One hashing-and-forwarding round is polynomial-time, `PolyTimeComputable (roundWord H S)`
for `roundWord H S : List Bool → List Bool`: it tests whether the outer log is empty, then
either emits the hash query or returns the recorded answer."""),
("""/-- Finalization is polynomial-time: split at the polynomial domain width, hash the
message prefix and concatenate the original signature suffix.""",
 """/-- Finalization is polynomial-time, `PolyTimeComputable (finalWord H S)` for
`finalWord H S : List Bool → List Bool`: split at the polynomial domain width, hash the
message prefix and concatenate the original signature suffix."""),
("""/-- The hash-and-sign reduction handler [PS10, Theorem 144.1]: sample one hash index,
provide `⟨pk,i⟩`, forward each query after hashing it, and hash the final message.""",
 """/-- The hash-and-sign reduction handler [PS10, Theorem 144.1]: sample one hash index,
provide `⟨pk,i⟩`, forward each query after hashing it, and hash the final message, with
`seedLen = H.gen.coins`, `advIn = advWord H`, `run = roundWord H S`, `finRun = finalWord H S`,
`init _ = zeroBits _` and `outLen = .add S.msgLen S.sigLen`."""),
("""/-- At a unary parameter, the generated index word is the hash generator's literal run
with the supplied list of coins.""",
 """/-- At a unary parameter, the generated index word is the hash generator's literal run
with the supplied list of coins: `indexWord H (List.replicate n true) ω = H.gen.runAtL n [] ω`."""),
("""/-- At unary parameter `1^n`, the hash word is the list of the padded evaluator at
the original signature message length.""",
 """/-- At unary parameter `1^n`, the hash word is the list of the padded evaluator at
the original signature message length: `hashWord H S (List.replicate n true) i m =
List.ofFn (padFin (S.msgLen.eval n) (H.eval (atParam n (pairEncode i m))))`."""),
("""/-- The handler gives the adversary `⟨pk,i⟩`, where `i` is the hash generator's run
on its seed.""",
 """/-- The handler gives the adversary `⟨pk,i⟩`, where `i` is the hash generator's run
on its seed: `(handler H S).advInput n pk ω = pairEncode pk (H.gen.runAtL n [] (List.ofFn ω))`."""),
("""/-- Each call asks the original signing oracle for the hash of its inner message and
returns the outer signature unchanged, preserving the handler state.""",
 """/-- Each call asks the original signing oracle for the hash of its inner message and
returns the outer signature unchanged, preserving the handler state:
`(handler H S).impl n pk ω i x s = .query 0 (padFin (S.msgLen.eval n)
(H.eval (atParam n (pairEncode (H.gen.runAtL n [] (List.ofFn ω)) (List.ofFn x)))))
fun y => .pure (y, s)`."""),
("""/-- Finalization makes no oracle query and returns the hash of the adversary's message
prefix concatenated with its signature suffix, read at the handler's output length.""",
 """/-- Finalization makes no oracle query and returns the hash of the adversary's message
prefix concatenated with its signature suffix, read at the handler's output length:
`(handler H S).finish n pk ω s a = .pure (padFin ((handler H S).outLen.eval n)
(hashWord H S (List.replicate n true) i ((List.ofFn a).take d) ++ (List.ofFn a).drop d))`,
where `i = H.gen.runAtL n [] (List.ofFn ω)` and `d = H.domLen.eval n`."""),
("""/-- When the hash range and signature message widths agree, hashing a typed domain
message gives the list of the CRH hash, transported to the signature message width.""",
 """/-- When the hash range and signature message widths agree, hashing a typed domain
message gives the list of the CRH hash, transported to the signature message width: for
`hlen : ∀ n, H.rangeLen.eval n = S.msgLen.eval n`,
`hashWord H S (List.replicate n true) i (List.ofFn x) =
List.ofFn (fun j : Fin (S.msgLen.eval n) => H.hash n i x (Fin.cast (hlen n).symm j))`."""),
("""/-- The hash-and-sign forwarding reduction is a one-query oracle machine
[PS10, Theorem 144.1].""",
 """/-- The hash-and-sign forwarding reduction is a one-query oracle machine,
`∃ C : NUPPT, ∀ n, ∃ φ : (Fin (K.seedLen.eval n) → Bool) × A.Coins n ≃ C.Coins n, ∀ pk ω r,
(simulate (K.impl n pk ω) (A.toCompOn cod n 1 (K.advInput n pk ω) r) (K.init n)).bind
(fun res => K.finish n pk ω res.2 res.1) = C.toCompOn cod' n 1 pk (φ (ω, r))`, where
`K = handler H S`, `cod = bitCodec (fun _ : Fin 1 => H.domLen.eval n) (fun _ => S.sigLen.eval n)
(H.domLen.eval n + S.sigLen.eval n)` and `cod' = bitCodec (fun _ : Fin 1 => S.msgLen.eval n)
(fun _ => S.sigLen.eval n) (K.outLen.eval n)` [PS10, Theorem 144.1]."""),
("""/-- The handler output width is the sum of the original message and signature widths.""",
 """/-- The handler output width is the sum of the original message and signature widths:
`(handler H S).outLen.eval n = S.msgLen.eval n + S.sigLen.eval n`."""),
("""/-- Finalization returns the hashed message component paired by concatenation with
the adversary's signature component.""",
 """/-- Finalization returns the hashed message component paired by concatenation with
the adversary's signature component: `(handler H S).finish n pk ω s a = .pure (fun j =>
Fin.append
(padFin (S.msgLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn (splitBits a).1)))))
(splitBits a).2 (Fin.cast (handler_output_width H S n) j))`, where
`i = H.gen.runAtL n [] (List.ofFn ω)`."""),
]

counts = {}
for f, reps in E.items():
    path = f'{wt}/{f}'
    src = open(path, encoding='utf-8').read()
    for old, new in reps:
        k = src.count(old)
        if k != 1: sys.exit(f'{f}: old text occurs {k} times: {old[:80]!r}')
        src = src.replace(old, new)
        j = src.index(new) + len(new)
        if src[j:j + 1] == ' ' and len(src[src.rindex('\n', 0, j) + 1:src.index('\n', j)]) > 100:
            src = src[:j] + '\n' + src[j + 1:]  # continuation sentence starts a new line
    open(path, 'w', encoding='utf-8').write(src)
    counts[f] = len(reps)
    print(f'{f}\t{len(reps)} replacements')
print(f'TOTAL {sum(counts.values())} replacements in {len(counts)} files')
