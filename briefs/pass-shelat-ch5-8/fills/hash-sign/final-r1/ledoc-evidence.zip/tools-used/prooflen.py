"""prooflen.py <worktree> <touched.json> [min]: independent cross-check of sketchaudit.py. For every
touched declaration (all kinds, private included), the body is cut at the first top-level `:=`
(bracket depth 0, as in headerbytes.py) after the keyword line; non-blank body lines are counted.
Prints every declaration with at least `min` (default 15) body lines and whether its docstring has
`**Proof sketch`."""
import json, re, sys
wt, tj = sys.argv[1:3]; mn = int(sys.argv[3]) if len(sys.argv) > 3 else 15
T = json.load(open(tj))['files']; miss = tot = 0
for f, info in T.items():
    L = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    for d in info['declarations']:
        if not d['touched']: continue
        text = '\n'.join(L[d['decl_line'] - 1:d['end']]); dep = 0; cut = None; i = 0
        while i < len(text):
            c = text[i]
            if c in '([{⟨': dep += 1
            elif c in ')]}⟩': dep -= 1
            elif dep == 0 and text.startswith(':=', i): cut = i; break
            i += 1
        body = text[cut + 2:] if cut is not None else ''
        first, *rest = body.split('\n')
        n = len([x for x in rest if x.strip()]) + (1 if first.strip() not in ('', 'by') else 0)
        if n < mn: continue
        doc = '\n'.join(L[d['start'] - 1:d['decl_line'] - 1])
        sk = '**Proof sketch' in doc; tot += 1; miss += not sk
        print(f"{'SKETCH' if sk else 'NO-SKETCH'}\t{f}:{d['start']}\t{d['name']}\t{d['kind']}"
              f"{' private' if d['private'] else ''}\t{n}")
print(f'TOTAL declarations with >= {mn} body lines: {tot}; without sketch: {miss}')
