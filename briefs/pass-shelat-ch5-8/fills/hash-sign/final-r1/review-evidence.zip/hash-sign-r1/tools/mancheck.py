"""mancheck.py <root> <manifest> [exclude...]: verify a sha256sum-style manifest relative to <root>
with exact path-set equality against the files under <root> (minus the excluded relative paths/prefixes)."""
import sys, os, hashlib
root, man = sys.argv[1], sys.argv[2]; excl = sys.argv[3:]
ent = {}
for l in open(man, encoding='utf-8'):
    l = l.rstrip('\n')
    if not l: continue
    h, p = l.split('  ', 1); ent[p] = h
have = set()
for d, _, fs in os.walk(root):
    for f in fs:
        rp = os.path.relpath(os.path.join(d, f), root)
        if any(rp == x or rp.startswith(x.rstrip('/') + '/') for x in excl): continue
        have.add(rp)
ok = bad = 0
for p, h in sorted(ent.items()):
    fp = os.path.join(root, p)
    if not os.path.isfile(fp): print('MISSING', p); bad += 1; continue
    if hashlib.sha256(open(fp, 'rb').read()).hexdigest() != h: print('MISMATCH', p); bad += 1
    else: ok += 1
extra = sorted(have - set(ent))
for p in extra: print('UNLISTED', p)
print(f'entries {len(ent)} ok {ok} bad {bad} unlisted {len(extra)} files {len(have)}')
print('RESULT', 'OK' if bad == 0 and not extra else 'FAIL')
