"""sizewidth.py <worktree> <file>...: line count, max width (Python len) and every line over 100 characters."""
import sys, os
wt = sys.argv[1]
for f in sys.argv[2:]:
    L = open(os.path.join(wt, f), encoding='utf-8').read().split('\n')
    if L and L[-1] == '': L = L[:-1]
    over = [(i + 1, len(l)) for i, l in enumerate(L) if len(l) > 100]
    print(f'{f}\tlines {len(L)}\tmax {max(map(len, L))}\tover100 {len(over)}\t{over}')
