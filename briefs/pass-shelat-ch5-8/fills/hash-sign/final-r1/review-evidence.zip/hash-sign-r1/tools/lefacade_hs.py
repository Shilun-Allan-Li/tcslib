"""lefacade_hs.py <worktree>: LE-facade for hash-sign. In the frozen facade Authentication.lean the eight
approved helper imports follow their parent `Signatures.HashAndSign`, in alphabetical order like the
campaign's other helper imports (Randomness.lean: Extraction.Rejection, Extraction.Sampler;
PrivateKey.lean: FromPRF.Hybrid, FromPRF.HybridLemmas, FromPRF.ReductionMachine), except that
`OneQuerySampling` precedes `OneQuery`. This swaps those two lines (order-only; same line set)."""
import sys, os
wt = sys.argv[1]
f = os.path.join(wt, 'TCSlib/Cryptography/Authentication.lean')
a = 'import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.OneQuerySampling\n'
b = 'import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.OneQuery\n'
s = open(f, encoding='utf-8').read()
assert s.count(a + b) == 1
t = s.replace(a + b, b + a)
assert sorted(s.split('\n')) == sorted(t.split('\n'))
open(f, 'w', encoding='utf-8').write(t)
print('swapped 1')
