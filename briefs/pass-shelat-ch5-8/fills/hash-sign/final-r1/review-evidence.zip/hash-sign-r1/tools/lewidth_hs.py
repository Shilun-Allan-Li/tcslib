"""lewidth_hs.py <worktree>: LE-width for hash-sign. One exact old -> new replacement (old must occur
exactly once) in Signatures/HashAndSign.lean: the 101-character statement line of the new theorem
expect_hashAndSign_sign is split before its final argument `g` (whitespace-only: a line break and
indentation). The pre-existing 101-character line 52 of the frozen facade Authentication.lean is
left unchanged (base line 44; the approved facade exception allows no other change)."""
import sys, os
wt = sys.argv[1]
f = os.path.join(wt, 'TCSlib/Cryptography/Authentication/Signatures/HashAndSign.lean')
old = ("        ProbComp.expect (simulate (HashSignFill.fixedSign H S n sk i rs).withLog c ((), [])) g) := by\n")
new = ("        ProbComp.expect (simulate (HashSignFill.fixedSign H S n sk i rs).withLog c ((), []))\n"
       "          g) := by\n")
s = open(f, encoding='utf-8').read()
assert s.count(old) == 1, s.count(old)
open(f, 'w', encoding='utf-8').write(s.replace(old, new))
print('replaced 1')
