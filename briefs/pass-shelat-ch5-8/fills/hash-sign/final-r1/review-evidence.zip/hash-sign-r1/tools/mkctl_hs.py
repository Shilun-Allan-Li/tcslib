"""mkctl_hs.py (hash-sign review): mkctl_cca2.py with the hash-sign rows (padFin, PolyExpr.eval, padStr, splitBits, atParam, CRH.hash, HashSignForward.hashWord, HashSignFill.hashedReply, OracleComp.CostBoundedBy), namespace HashSignControls, and the A/B letter read before `Cryptography` in the seal labels (this review's labels have no underscore after the letter); harness, covering-subset choice and assembly verbatim. Previously: mkctl_cca2.py (cca2-ett review): mkctl_extnosrc.py with the cca2-ett rows (padFin, PolyExpr.eval, ETTGame.wR, ETTGame.ovr, ETTGame.recBits, PRFGame.recBits, InteractiveHandler.rCnt, GGMRed.tblEnc, AdaptiveCPA.extTape) and namespace HashSignControls; harness, covering-subset choice and assembly verbatim. Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
CS = 'TCSlib.Cryptography.Composability.ChallengeSim'
AC = 'TCSlib.Cryptography.Composability.AdaptiveCPA'
PK = 'TCSlib.Cryptography.Composability.FixedLengthPKScheme'
SK = 'TCSlib.Cryptography.Composability.FixedLengthScheme'
G = 'TCSlib.Cryptography.Games'
IH = G + '.InteractiveHandler'
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
OP = "open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games in\n"
FD = 'TCSlib.InformationTheory.FinDist'
RJ = 'TCSlib.Cryptography.Randomness.Rejection'
EG = 'TCSlib.Cryptography.Composability.ETTGame'
PG = 'TCSlib.Cryptography.Composability.PRFGame'
GR = 'TCSlib.Cryptography.GGMRed'
OPA = "open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games TCSlib.Cryptography.Authentication in\n"
AU = 'TCSlib.Cryptography.Authentication'
B = {
 'TCSlib.Cryptography.padFin': row("ctlPadFin",
   "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n",
   "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n"),
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 'TCSlib.Cryptography.padStr': row("ctlPadStr",
   OPA + "theorem ctlPadStr (p : PolyExpr) (u w : List Bool) :\n    padStr p u w = (w ++ List.replicate (p.eval u.length) false).take (p.eval u.length) := rfl\n",
   OPA + "theorem ctlPadStrReader (p : PolyExpr) (u w : List Bool) :\n    padStr p u w = (w ++ List.replicate (p.eval u.length) false).take (p.eval u.length) :=\n  padStr_eq p u w\n"),
 AU + '.splitBits': row("ctlSplit",
   OPA + "theorem ctlSplit {a b : ℕ} (w : Fin (a + b) → Bool) (i : Fin a) :\n    (splitBits w).1 i = w (Fin.castAdd b i) := rfl\n",
   OPA + "theorem ctlSplitReader {a b : ℕ} (w : Fin (a + b) → Bool) (i : Fin a) :\n    (splitBits w).1 i = w (Fin.castAdd b i) := splitBits_fst w i\n"),
 AU + '.atParam': row("ctlAtParam",
   OPA + "theorem ctlAtParam (n : ℕ) (w : List Bool) :\n    atParam n w = pairEncode (List.replicate n true) w := rfl\n",
   OPA + "theorem ctlAtParamReader (n : ℕ) (w : List Bool) :\n    atParam n w = pairEncode (List.replicate n true) w := atParam_eq n w\n"),
 AU + '.CRH.hash': row("ctlHash",
   OPA + "theorem ctlHash (H : CRH) (n : ℕ) (i : List Bool) (x : Fin (H.domLen.eval n) → Bool) :\n    H.hash n i x =\n      padFin (H.rangeLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn x)))) := rfl\n",
   OPA + "theorem ctlHashReader (H : CRH) (n : ℕ) (i : List Bool) (x : Fin (H.domLen.eval n) → Bool) :\n    H.hash n i x =\n      padFin (H.rangeLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn x)))) :=\n  CRH.hash_eq H n i x\n"),
 AU + '.HashSignForward.hashWord': row("ctlHashWord",
   OPA + "theorem ctlHashWord (H : CRH) (S : SignatureScheme) (u i m : List Bool) :\n    HashSignForward.hashWord H S u i m =\n      padStr S.msgLen u (H.eval (pairEncode u (pairEncode i m))) := rfl\n",
   OPA + "theorem ctlHashWordReader (H : CRH) (S : SignatureScheme) (u i m : List Bool) :\n    HashSignForward.hashWord H S u i m =\n      padStr S.msgLen u (H.eval (pairEncode u (pairEncode i m))) :=\n  HashSignForward.hashWord_eq H S u i m\n"),
 AU + '.HashSignFill.hashedReply': row("ctlHashedReply",
   OPA + "theorem ctlHashedReply (H : CRH) (S : SignatureScheme) (n : ℕ) (sk i : List Bool)\n    (rs : S.sign.Coins n) (m : Fin (H.domLen.eval n) → Bool) :\n    HashSignFill.hashedReply H S n sk i rs m =\n      padFin (S.sigLen.eval n) (S.sign.runAt n\n        (pairEncode sk (HashSignForward.hashWord H S (List.replicate n true) i (List.ofFn m))) rs) :=\n  rfl\n",
   OPA + "theorem ctlHashedReplyReader (H : CRH) (S : SignatureScheme) (n : ℕ) (sk i : List Bool)\n    (rs : S.sign.Coins n) (m : Fin (H.domLen.eval n) → Bool) :\n    HashSignFill.hashedReply H S n sk i rs m =\n      padFin (S.sigLen.eval n) (S.sign.runAt n\n        (pairEncode sk (HashSignForward.hashWord H S (List.replicate n true) i (List.ofFn m))) rs) :=\n  HashSignFill.hashedReply_eq H S n sk i rs m\n"),
 'TCSlib.Cryptography.Games.OracleComp.CostBoundedBy': row("ctlCost",
   OPA + "theorem ctlCost {ι α : Type} {spec : OracleSpec ι} (cost : ι → ℕ) (a : α) (q : ℕ) :\n    OracleComp.CostBoundedBy cost (OracleComp.pure (spec := spec) a) q := trivial\n",
   OPA + "theorem ctlCostReader {ι α : Type} {spec : OracleSpec ι} (cost : ι → ℕ) (a : α) (q : ℕ) :\n    OracleComp.CostBoundedBy cost (OracleComp.pure (spec := spec) a) q :=\n  OracleComp.costBoundedBy_pure cost a q\n"),
}
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace HashSignControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end HashSignControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('Cryptography')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('Cryptography')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
