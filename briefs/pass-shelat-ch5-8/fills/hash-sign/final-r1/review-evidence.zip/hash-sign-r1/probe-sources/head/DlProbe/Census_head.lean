import Lean
import TCSlib.Cryptography.Authentication
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.CodecReaders
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.CollisionGame
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.CollisionHandler
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.FixedGame
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.ForwardGame
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.ForwardHandler
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.OneQuery
import TCSlib.Cryptography.Authentication.Signatures.HashAndSign.OneQuerySampling

/-! hash-sign review census probe (head side). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

#print axioms TCSlib.Cryptography.Authentication.hashAndSign_oneTimeSecure
#print axioms TCSlib.Cryptography.Authentication.lamport_oneTimeSecure
#print axioms TCSlib.Cryptography.Authentication.exists_oneTimeSecure_of_crh_owf

def owners : List Name := [`TCSlib.Cryptography.Authentication,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.CodecReaders,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.CollisionGame,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.CollisionHandler,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.FixedGame,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.ForwardGame,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.ForwardHandler,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.OneQuery,
  `TCSlib.Cryptography.Authentication.Signatures.HashAndSign.OneQuerySampling]
def nameMap : Std.HashMap String String := Std.HashMap.ofList []

def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"

