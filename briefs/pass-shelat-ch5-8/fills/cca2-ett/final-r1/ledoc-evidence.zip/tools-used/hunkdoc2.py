"""hunkdoc2.py <repo> <old-rev> <new-rev>: hunkdoc.py with doc comments `/-- ... -/` AND module doc
comments `/-! ... -/` (the only change: the span start is the earlier of `/--` and `/-!`).
Every changed hunk lies inside a doc comment.
(1) Per file of `git diff -U0 old new`: each removed line (old numbering) lies in an old-version
docstring span and each added line (new numbering) in a new-version docstring span; each hunk's
old and new ranges are reported. (2) Stronger: with every docstring body replaced by an empty
`/-- -/`, the old and new files are byte-identical. (3) Line widths (Python len) and line counts."""
import sys, re, subprocess
repo, old, new = sys.argv[1:4]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout.decode('utf-8')
files = [f for f in git('diff', '--name-only', old, new).split('\n') if f]
def nextdoc(src, i):
    ks = [k for k in (src.find('/--', i), src.find('/-!', i)) if k >= 0]
    return min(ks) if ks else -1
def spans(src):
    """Set of 1-based line numbers covered by a doc comment `/-- ... -/` (nesting-aware)."""
    cov, i, n = set(), 0, len(src)
    while True:
        k = nextdoc(src, i)
        if k < 0: break
        d, j = 1, k + 3
        while d and j < n:
            if src.startswith('/-', j): d += 1; j += 2
            elif src.startswith('-/', j): d -= 1; j += 2
            else: j += 1
        a, b = src.count('\n', 0, k) + 1, src.count('\n', 0, j) + 1
        cov.update(range(a, b + 1)); i = j
    return cov
def blank(src):
    out, i, n = [], 0, len(src)
    while True:
        k = nextdoc(src, i)
        if k < 0: out.append(src[i:]); break
        d, j = 1, k + 3
        while d and j < n:
            if src.startswith('/-', j): d += 1; j += 2
            elif src.startswith('-/', j): d -= 1; j += 2
            else: j += 1
        out.append(src[i:k] + src[k:k + 3] + ' -/'); i = j
    return ''.join(out)
bad = 0; nh = 0
for f in files:
    a, b = git('show', f'{old}:{f}'), git('show', f'{new}:{f}')
    sa, sb = spans(a), spans(b)
    d = git('diff', '-U0', old, new, '--', f)
    for m in re.finditer(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', d, re.M):
        o0, oc, n0, nc = int(m[1]), int(m[2] or 1), int(m[3]), int(m[4] or 1)
        ol, nl = set(range(o0, o0 + oc)), set(range(n0, n0 + nc))
        ok = ol <= sa and nl <= sb; nh += 1; bad += not ok
        print(f"{'IN-DOCSTRING' if ok else 'OUTSIDE'}\t{f}\told {o0},{oc}\tnew {n0},{nc}")
    same = blank(a) == blank(b); bad += not same
    print(f"{'CODE-IDENTICAL' if same else 'CODE-DIFFERS'}\t{f}\t(docstrings blanked)")
    for tag, s in (('old', a), ('new', b)):
        L = s.split('\n'); L = L[:-1] if s.endswith('\n') else L
        w = max(len(x) for x in L); over = sum(len(x) > 100 for x in L)
        print(f"WIDTH\t{tag}\t{f}\tlines {len(L)}\tmax {w}\tover100 {over}")
        bad += over > 0 or len(L) >= 1000
print(f'TOTAL {len(files)} files, {nh} hunks, {bad} failures')
