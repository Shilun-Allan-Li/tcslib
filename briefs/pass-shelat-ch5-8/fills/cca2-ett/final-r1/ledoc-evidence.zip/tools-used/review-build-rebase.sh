#!/usr/bin/env bash
# rebase.sh <worktree> <old-base> <unit-paths-file> <logdir>
set -u
WT=$1; OLDBASE=$2; PATHS=$3; L=$4
cd "$WT"
TIP=$(git rev-parse origin/cryptography/pass-shelat-ch2-4)
OLD=$(git rev-parse HEAD); OLDT=$(git rev-parse HEAD^{tree})
{
echo "# rebase r3 (latest origin/cryptography/pass-shelat-ch2-4), $(date -u +%FT%TZ)"
echo "old head $OLD tree $OLDT"
echo "old base $(git rev-parse $OLDBASE)"
echo "new origin tip $TIP"
git merge-base --is-ancestor dee0de32ee33d7188afe97bdc3089fac68412057 $TIP && echo "dee0de32 (#305 record) is an ancestor"
git merge-base --is-ancestor $OLDBASE $TIP && echo "old base is an ancestor"
echo "commits $OLDBASE..$TIP:"; git log --format='%H %s' $OLDBASE..$TIP
echo "non-briefs paths changed $OLDBASE..$TIP:"; git diff --name-only $OLDBASE $TIP -- . ':(exclude)briefs'
echo "Lean/audits paths changed $OLDBASE..$TIP:"; git diff --name-only $OLDBASE $TIP -- '*.lean' audits
} > $L/rebase-r3.log
git ls-tree -r HEAD -- $(cat $PATHS) > $L/unit-files-before.txt
git rebase $TIP >> $L/rebase-r3.log 2>&1; echo "rebase rc=$?" >> $L/rebase-r3.log
git ls-tree -r HEAD -- $(cat $PATHS) > $L/unit-files-after.txt
{
echo "new head $(git rev-parse HEAD) tree $(git rev-parse HEAD^{tree})"
git log --format='%H %T %an <%ae> | %cn <%ce> | %s' $TIP..HEAD
echo "unit files (blob ids) before vs after (empty = byte-identical):"; diff $L/unit-files-before.txt $L/unit-files-after.txt
echo "unit file count: $(wc -l < $L/unit-files-after.txt)"
echo "diff of branch tree vs old head, TCSlib/ audits/ (empty = identical):"; git diff --stat $OLD HEAD -- TCSlib audits
echo "changed paths vs origin tip:"; git diff --name-status $TIP HEAD
echo "patch-id equality old series vs new series:"
diff <(git log -p $OLDBASE..$OLD | git patch-id --stable | cut -d' ' -f1) <(git log -p $TIP..HEAD | git patch-id --stable | cut -d' ' -f1) && echo "patch ids identical"
echo "git status:"; git status --short
} >> $L/rebase-r3.log
