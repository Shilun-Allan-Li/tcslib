"""ledoc_edit.py <worktree>: cca2-ett LE-doc docstring replacements (exact; each old text must occur
exactly once in its file). Formulas for the 94 NO-FORMULA public declarations of the r1 docaudit,
`**Proof sketch.**` paragraphs for the 15 long proofs without one, and `## Main definitions` in the
module docstrings of Forgery.lean and Transfer.lean. Only text inside `/-- -/` and `/-! -/` changes
(where an old text includes a following declaration line, that line is repeated unchanged)."""
import sys
wt = sys.argv[1]
P = 'TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/'
E = {}

# ---------------------------------------------------------------- Games.lean (24 formulas)
E[P + 'Games.lean'] = [
("""/-- The pair `r ‖ c₁` read as a `2n`-bit vector. -/""",
 """/-- The pair `r ‖ c₁` read as a `2n`-bit vector: `pairV n r c = padFin (2n) (r ++ c)`. -/"""),
("""/-- The tag `⟦g (r ‖ c₁)⟧`. -/""",
 """/-- The tag `⟦g (r ‖ c₁)⟧`: `tagL g r c = ⟦g (pairV n r c)⟧`. -/"""),
("""/-- The ciphertext word `⟨r, ⟨c₁, t⟩⟩`. -/""",
 """/-- The ciphertext word `⟨r, ⟨c₁, t⟩⟩`: `ctW r c t = pairEncode r (pairEncode c t)`. -/"""),
("""/-- **The decryption** of a word: `⟨1, wC w ⊕ ⟦f (wR w)⟧⟩`. -/""",
 """/-- **The decryption** of a word, `⟨1, wC w ⊕ ⟦f (wR w)⟧⟩`:
`decL f w = true :: (wC w ⊕ ⟦f (padFin n (wR w))⟧)`. -/"""),
("""/-- The mask of an `n`-bit message has `n` bits. -/""",
 """/-- The mask of an `n`-bit message has `n` bits: `|m| = n → |maskL f r m| = n`. -/"""),
("""/-- **The ciphertext length:** an encryption of an `n`-bit message has `6n + 4` bits. -/""",
 """/-- **The ciphertext length:** an encryption of an `n`-bit message has `6n + 4` bits:
`|m| = n → |encW f g r m| = 6n + 4`. -/"""),
("""/-- An encryption is well formed: `wfW n (encW f g r m)` for an `n`-bit `m`. -/""",
 """/-- An encryption of an `n`-bit message is well formed:
`|m| = n → wfW n (encW f g r m) = true`. -/"""),
("""/-- **The state of the experiment:** the recorded challenge and the pairs of the `Enc` answers. -/""",
 """/-- **The state of the experiment:** the recorded challenge and the pairs of the `Enc` answers,
`St n d = Option (Fin d → Bool) × List (Fin (2n) → Bool)`. -/"""),
("""/-- **The decryption answer** in state `s`, with fresh pairs rejected when `rej` holds: `decL f w`
if `w` is not refused, valid, and (when `rej`) its pair is in the list; else `[]` (read as `⊥`). -/""",
 """/-- **The decryption answer** in state `s`, with fresh pairs rejected when `rej` holds:
`decAnsW f g rej s w = if !refW s.1 w && validW g w && (!rej || pairW n w ∈ s.2) then decL f w
else []`, that is, `decL f w` if `w` is not refused, valid, and (when `rej`) its pair is in the
list; else `[]` (read as `⊥`). -/"""),
("""/-- **The bad event of a decryption query:** not refused, valid, and a fresh pair. -/""",
 """/-- **The bad event of a decryption query:** not refused, valid, and a fresh pair,
`hitW g s w = (!refW s.1 w && validW g w && !decide (pairW n w ∈ s.2))`. -/"""),
("""/-- **One step of the experiment with the nonce `r`** (see the module docstring). -/""",
 """/-- **One step of the experiment with the nonce `r`** (see the module docstring), with inputs read
by `⟦·⟧` and answers and records written by `padFin`:
`ettStep … r 0 m s = (encW f g r m, (s.1, pairV n ⟦r⟧ (maskL f r m) :: s.2))`,
`ettStep … r 1 w s = (decAnsW f g rej s w, s)`,
`ettStep … r 2 mm (some c, T) = (⟦c⟧, (some c, T))` and
`ettStep … r 2 mm (none, T) = (e, (some e, T))` with `e = encW f g r (msgOf n b mm)`. -/"""),
("""/-- `Enc` on `m` answers `encW f g r m` and adds the pair `r ‖ maskL f r m` to the list. -/""",
 """/-- `Enc` on `m` answers `encW f g r m` and adds the pair `r ‖ maskL f r m` to the list:
`ettStep … r 0 m s = (padFin _ (encW f g r ⟦m⟧), (s.1, pairV n ⟦r⟧ (maskL f r ⟦m⟧) :: s.2))`. -/"""),
("""/-- `Dec` on `w` answers `decAnsW f g rej s w` and keeps the state. -/""",
 """/-- `Dec` on `w` answers `decAnsW f g rej s w` and keeps the state:
`ettStep … r 1 w s = (padFin _ (decAnsW f g rej s ⟦w⟧), s)`. -/"""),
("""/-- A later challenge repeats the record and keeps the state. -/""",
 """/-- A later challenge repeats the record and keeps the state:
`ettStep … r 2 mm (some c, T) = (padFin _ ⟦c⟧, (some c, T))`. -/"""),
("""/-- The first challenge encrypts `m_b` with the nonce `r` and records it. -/""",
 """/-- The first challenge encrypts `m_b` with the nonce `r` and records it:
`ettStep … r 2 mm (none, T) = (padFin _ e, (some (padFin d e), T))` with
`e = encW f g r (msgOf n b ⟦mm⟧)`. -/"""),
("""/-- **The experiment with pad function `f` and tag function `g`:** every query draws a nonce `r`
and takes one `ettStep`. -/""",
 """/-- **The experiment with pad function `f` and tag function `g`:** every query draws a nonce `r`
and takes one `ettStep`,
`ettImpl … i x s = (sample (Fin n → Bool)).bind fun r => pure (ettStep … r i x s)`. -/"""),
("""/-- The experiment draws one coin per query (`freshImpl`). -/""",
 """/-- The experiment draws one coin per query (`freshImpl`):
`ettImpl … = freshImpl fun i x s r => pure (ettStep … r i x s)`. -/"""),
("""/-- The bad event of a query: a decryption query with `hitW`. -/""",
 """/-- The bad event of a query: a decryption query with `hitW`, `hitQ … 1 w s = hitW g s ⟦w⟧`,
and `hitQ … 0 m s = hitQ … 2 mm s = false`. -/"""),
("""/-- An encryption query never raises the bad flag. -/""",
 """/-- An encryption query never raises the bad flag: `hitQ … 0 m s = false`. -/"""),
("""/-- A decryption query raises the bad flag by `hitW`. -/""",
 """/-- A decryption query raises the bad flag by `hitW`: `hitQ … 1 w s = hitW g s ⟦w⟧`. -/"""),
("""/-- A challenge query never raises the bad flag. -/""",
 """/-- A challenge query never raises the bad flag: `hitQ … 2 mm s = false`. -/"""),
("""/-- **The experiment with the bad flag:** `ettImpl`, and the flag raised by `hitQ`. -/""",
 """/-- **The experiment with the bad flag:** `ettImpl`, and the flag raised by `hitQ`,
`ettBad … i x s = (ettImpl … i x s.1).bind fun p =>
pure (p.1, (p.2, s.2 || hitQ … i x s.1))`. -/"""),
("""/-- The acceptance probability lies in `[0, 1]`. -/
theorem ettAcc_nonneg (""",
 """/-- The acceptance probability lies in `[0, 1]`; the lower bound: `0 ≤ ettAcc … A Q`. -/
theorem ettAcc_nonneg ("""),
("""/-- The acceptance probability lies in `[0, 1]`. -/
theorem ettAcc_le_one (""",
 """/-- The acceptance probability lies in `[0, 1]`; the upper bound: `ettAcc … A Q ≤ 1`. -/
theorem ettAcc_le_one ("""),
]

# ---------------------------------------------------------------- Lazy.lean (24 formulas)
E[P + 'Lazy.lean'] = [
("""/-- An entry of the lazy table: a pair, its tag and the message of the encryption. -/""",
 """/-- An entry of the lazy table: a pair, its tag and the message of the encryption,
`LEntry n = (Fin (2n) → Bool) × (Fin (2n) → Bool) × List Bool`. -/"""),
("""/-- The lazy state: the recorded challenge and the table, newest entry first. -/""",
 """/-- The lazy state: the recorded challenge and the table, newest entry first,
`LSt n d = Option (Fin d → Bool) × List (LEntry n)`. -/"""),
("""/-- The pairs of the table. -/""",
 """/-- The pairs of the table: `keysL L = L.map Prod.fst`. -/"""),
("""/-- **The table's entry at a pair:** the first (newest) entry with the pair `p`, if any. -/""",
 """/-- **The table's entry at a pair:** the first (newest) entry with the pair `p`, if any,
`lookL L p = if p ∈ keysL L then some (L.getD ((keysL L).idxOf p) default) else none`. -/"""),
("""/-- **The tag of a pair:** the table's, else the challenge's at its pair, else none. -/""",
 """/-- **The tag of a pair:** the table's, else the challenge's at its pair, else none:
`tagOf s p = some e.2.1` if `lookL s.2 p = some e`; else
`tagOf s p = some (padFin (2n) (wT ⟦c⟧))` if `s.1 = some c` and `pairW n ⟦c⟧ = p`; else
`tagOf s p = none`. -/"""),
("""/-- `tagOf s p`: the table's tag, else the challenge's at its pair. -/""",
 """/-- `tagOf s p` unfolded: the table's tag, else the challenge's at its pair,
`tagOf s p = some e.2.1` if `lookL s.2 p = some e`; else
`tagOf s p = some (padFin (2n) (wT ⟦c⟧))` if `s.1 = some c` and `pairW n ⟦c⟧ = p`; else
`tagOf s p = none`. -/"""),
("""/-- **The lazy decryption answer:** `⊥` on the record; on a well-formed word whose pair is in the
table with the word's tag, `⟨1, m⟩` with the table's message; `⊥` otherwise. -/""",
 """/-- **The lazy decryption answer:** `⊥` on the record; on a well-formed word whose pair is in the
table with the word's tag, `⟨1, m⟩` with the table's message; `⊥` otherwise:
`lazyDec s w = true :: e.2.2` if `refW s.1 w = false`, `wfW n w = true`,
`lookL s.2 (pairW n w) = some e` and `⟦e.2.1⟧ = wT w`; else `lazyDec s w = []`. -/"""),
("""/-- `lazyDec s w` unfolded. -/""",
 """/-- `lazyDec s w` unfolded: `lazyDec s w = true :: e.2.2` if `refW s.1 w = false`,
`wfW n w = true`, `lookL s.2 (pairW n w) = some e` and `⟦e.2.1⟧ = wT w`; else
`lazyDec s w = []`. -/"""),
("""/-- **The tag table of a lazy state:** the entries' tags, newest first, then the challenge's. -/""",
 """/-- **The tag table of a lazy state:** the entries' tags, newest first, then the challenge's,
`tagTbl s = s.2.map (fun e => (e.1, e.2.1)) ++ [(pairW n ⟦c⟧, padFin (2n) (wT ⟦c⟧))]` for
`s.1 = some c`, and `tagTbl s = s.2.map (fun e => (e.1, e.2.1))` for `s.1 = none`. -/"""),
("""/-- `tagTbl s` unfolded. -/""",
 """/-- `tagTbl s` unfolded:
`tagTbl s = s.2.map (fun e => (e.1, e.2.1)) ++ [(pairW n ⟦c⟧, padFin (2n) (wT ⟦c⟧))]` for
`s.1 = some c`, and `tagTbl s = s.2.map (fun e => (e.1, e.2.1)) ++ []` for `s.1 = none`. -/"""),
("""/-- The keys of the tag table: the listed pairs, then the challenge's pair. -/""",
 """/-- The keys of the tag table: the listed pairs, then the challenge's pair,
`(tagTbl s).map Prod.fst = keysL s.2 ++ [pairW n ⟦c⟧]` for `s.1 = some c`, and
`(tagTbl s).map Prod.fst = keysL s.2 ++ []` for `s.1 = none`. -/"""),
("""/-- **`tagOf` reads the tag table:** for every `R`, `tagOf s p` is `ovr (tagTbl s) R p` on the keys
of the tag table, and none elsewhere. -/""",
 """/-- **`tagOf` reads the tag table:** for every `R`, `tagOf s p` is `ovr (tagTbl s) R p` on the keys
of the tag table, and none elsewhere,
`tagOf s p = if p ∈ (tagTbl s).map Prod.fst then some (ovr (tagTbl s) R p) else none`. -/"""),
("""/-- `LInv f s` unfolded. -/""",
 """/-- `LInv f s` unfolded:
`LInv n f s ↔ ∀ e ∈ s.2, ∃ r, e.1 = pairV n ⟦r⟧ (maskL f r e.2.2) ∧ |e.2.2| = n`. -/"""),
("""/-- The empty table has the invariant: `LInv f (o, [])`. -/""",
 """/-- The empty table has the invariant: `LInv n f (o, [])`, vacuously, since `LInv n f s`
quantifies over `e ∈ s.2` and here `s.2 = []`. -/"""),
("""/-- **One step of the lazy experiment** with the nonce `r` and the tape `t` (see the module
docstring). -/""",
 """/-- **One step of the lazy experiment** with the nonce `r` and the tape `t` (see the module
docstring), with inputs read by `⟦·⟧` and answers and records written by `padFin`: for
`c₁ = maskL f r m`, `p = pairV n ⟦r⟧ c₁` and `τ = (tagOf s p).getD t`,
`lazyStep … r t 0 m s = (ctW ⟦r⟧ c₁ ⟦τ⟧, (s.1, (p, τ, m) :: s.2))`,
`lazyStep … r t 1 w s = (lazyDec s w, s)`,
`lazyStep … r t 2 mm (some c, L) = (⟦c⟧, (some c, L))` and
`lazyStep … r t 2 mm (none, L) = (e, (some e, L))` with `e = ctW ⟦r⟧ c₁ ⟦τ⟧`, where here
`m = msgOf n b mm` and `s = (none, L)`. -/"""),
("""/-- `Enc′` in the lazy experiment: the tag `tagOf s p` or the tape, and a new entry. -/""",
 """/-- `Enc′` in the lazy experiment: the tag `tagOf s p` or the tape, and a new entry,
`lazyStep … r t 0 m s = (padFin _ (ctW ⟦r⟧ c₁ ⟦τ⟧), (s.1, (p, τ, ⟦m⟧) :: s.2))` with
`c₁ = maskL f r ⟦m⟧`, `p = pairV n ⟦r⟧ c₁` and `τ = (tagOf s p).getD t`. -/"""),
("""/-- `Dec′` in the lazy experiment answers `lazyDec`. -/""",
 """/-- `Dec′` in the lazy experiment answers `lazyDec`:
`lazyStep … r t 1 w s = (padFin _ (lazyDec s ⟦w⟧), s)`. -/"""),
("""/-- A repeated challenge in the lazy experiment. -/""",
 """/-- A repeated challenge in the lazy experiment:
`lazyStep … r t 2 mm (some c, L) = (padFin _ ⟦c⟧, (some c, L))`. -/"""),
("""/-- The first challenge in the lazy experiment. -/""",
 """/-- The first challenge in the lazy experiment:
`lazyStep … r t 2 mm (none, L) = (padFin _ e, (some (padFin d e), L))` with
`e = ctW ⟦r⟧ c₁ ⟦(tagOf (none, L) (pairV n ⟦r⟧ c₁)).getD t⟧` and
`c₁ = maskL f r (msgOf n b ⟦mm⟧)`. -/"""),
("""/-- One call of the lazy experiment with the tape `t`: draw the nonce and take `lazyStep`. -/""",
 """/-- One call of the lazy experiment with the tape `t`: draw the nonce and take `lazyStep`,
`ettLazyK … i x s t = (sample (Fin n → Bool)).bind fun r => pure (lazyStep … r t i x s)`. -/"""),
("""/-- **The lazy experiment:** one fresh tape per query (`freshImpl`). -/""",
 """/-- **The lazy experiment:** one fresh tape per query (`freshImpl`):
`ettLazy … = freshImpl (ettLazyK …)`. -/"""),
("""/-- **The lazy experiment with tapes in advance** (`tapeImpl`). -/""",
 """/-- **The lazy experiment with tapes in advance** (`tapeImpl`):
`ettLazyTape … T = tapeImpl (ettLazyK …) T`. -/"""),
("""/-- **Tapes in advance have the law of fresh tapes** (`expect_simulate_tapeImpl`). -/""",
 """/-- **Tapes in advance have the law of fresh tapes** (`expect_simulate_tapeImpl`): for a
computation with at most `m` queries and `j + m ≤ κ`,
`𝔼_{T ← ({0,1}^{2n})^κ} 𝔼[G (simulate (ettLazyTape … (extTape T)) c (s, j))] =
𝔼[G (simulate (ettLazy …) c s)]`. -/"""),
("""/-- One call of the lazy experiment: draw the tape, then the nonce, and take `lazyStep`. -/""",
 """/-- One call of the lazy experiment: draw the tape, then the nonce, and take `lazyStep`,
`ettLazy … i x s = (sample (Fin (2n) → Bool)).bind fun t =>
(sample (Fin n → Bool)).bind fun r => pure (lazyStep … r t i x s)`. -/"""),
]

# ---------------------------------------------------------------- Handler.lean (15 formulas, 6 sketches)
E[P + 'Handler.lean'] = [
("""/-- The ciphertext length `6n + 4`. -/""",
 """/-- The ciphertext length `6n + 4`: `ettCt = 6 · var + 4`, so `ettCt.eval n = 6n + 4`. -/"""),
("""/-- The query lengths: `n`-bit messages to `Enc`, `(6n + 4)`-bit ciphertexts to `Dec`, `2n`-bit
challenge queries. -/""",
 """/-- The query lengths: `n`-bit messages to `Enc`, `(6n + 4)`-bit ciphertexts to `Dec`, `2n`-bit
challenge queries: `ettDin 0 = var`, `ettDin 1 = ettCt` and `ettDin 2 = var + var`. -/"""),
("""/-- The answer lengths: ciphertexts, `(n + 1)`-bit decryption answers, ciphertexts. -/""",
 """/-- The answer lengths: ciphertexts, `(n + 1)`-bit decryption answers, ciphertexts:
`ettDout 0 = ettCt`, `ettDout 1 = var + 1` and `ettDout 2 = ettCt`. -/"""),
("""/-- The tag length `2n`. -/""",
 """/-- The tag length `2n`: `tagLen = 2 · var`, so `tagLen.eval n = 2n`. -/"""),
("""/-- The outer oracle: `2n`-bit queries and answers. -/""",
 """/-- The outer oracle: `2n`-bit queries and answers, `tagOut j = tagLen` for `j : Fin 1`. -/"""),
("""/-- The state length `2q + 3 + (6n + 4)`. -/""",
 """/-- The state length `2q + 3 + (6n + 4)`: `dStLen q = 2 · q + 3 + ettCt`, so
`(dStLen q).eval n = 2 q(n) + 3 + (6n + 4)`. -/"""),
("""/-- The seed length `n + q(n) · n`: the key and the tapes. -/""",
 """/-- The seed length `n + q(n) · n`: the key and the tapes, `dSeedLen q = var + q · var`, so
`(dSeedLen q).eval n = n + q(n) · n`. -/"""),
("""/-- The record of the challenge: `1 :: c` once recorded, `0^{1 + ct(n)}` before. -/""",
 """/-- The record of the challenge: `1 :: c` once recorded, `0^{1 + ct(n)}` before,
`recBits n (some c) = true :: ⟦c⟧` and
`recBits n none = false :: List.replicate (ettCt.eval n) false`. -/"""),
("""/-- The record has `1 + ct(n)` bits. -/""",
 """/-- The record has `1 + ct(n)` bits: `|recBits n o| = ettCt.eval n + 1`. -/"""),
("""/-- **The encoded state** after `j` queries, with the challenge record `o`:
`⟨1^j, recBits o⟩`, padded with `false` to the state length. -/""",
 """/-- **The encoded state** after `j` queries, with the challenge record `o`:
`⟨1^j, recBits o⟩`, padded with `false` to the state length,
`dState q n j o = padFin _ (pairEncode (List.replicate j true) (recBits n o))`. -/"""),
("""/-- The tape `j` of the tape word: block `j` of `W` (`EnsembleLemmas.blocks`). -/""",
 """/-- The tape `j` of the tape word: block `j` of `W` (`EnsembleLemmas.blocks`),
`dTape q n W j hj = blocks (q n) n W ⟨j, hj⟩`. -/"""),
("""/-- The fields of an encoded state with `j ≤ q(n)`: the count `1^j`, the flag and the record. -/""",
 """/-- The fields of an encoded state with `j ≤ q(n)`: the count `1^j`, the flag and the record.

**Proof sketch.** The pair `⟨1^j, recBits n o⟩` fits in the state length (`length_pairEncode`,
`length_recBits`, `j ≤ q(n)`), so the padding only appends `false`s to its second component
(`ofFn_padFin_of_le`, `pairEncode_append_right`). The projections then read `1^j` and
`recBits n o` followed by `false`s; its head is the flag and its next `ct(n)` bits are the record
(by cases on `o`, `recBits_none`, `recBits_some`). -/"""),
("""/-- The initial state is the encoded `(0, none)`. -/""",
 """/-- The initial state is the encoded `(0, none)`:
`(dHandler q E hE b).init n = dHState q E hE b n 0 none`. -/"""),
("""/-- The round input of a call, field by field, on an encoded state with `j < q(n)` and the seed
`dHSeed (k, W)`. -/""",
 """/-- The round input of a call, field by field, on an encoded state with `j < q(n)` and the seed
`dHSeed (k, W)`.

**Proof sketch.** The generic readers of the round input (`rU_input`, `rS_input`, `rI_input`,
`rX_input`, `rL_input`, `rW_input`, `rCnt_input`) give the parameter, state, oracle index, query,
log, seed word `⟦k⟧ ++ ⟦W⟧` (`ofFn_dHSeed`) and count; `fields_dState` gives the count `1^j`, the
flag and the record. The key is then the first `n` bits of the seed word, and the nonce is the
`n` bits after the offset `n + j · n`, which is block `j` of `W` (`take_drop_ofFn_blocks`). -/"""),
("""/-- **A refused decryption:** from `dState j o` with the query the recorded challenge, the answer
is `⊥` and the state is `dState (j + 1) o`. -/""",
 """/-- **A refused decryption:** from `dState j o` with the query the recorded challenge, the answer
is `⊥` and the state is `dState (j + 1) o`: for `j < q(n)` and `refW o ⟦x⟧ = true`,
`(dHandler …).impl n z (dHSeed … (k, W)) 1 x (dHState … j o) =
pure (padFin _ [], dHState … (j + 1) o)`.

**Proof sketch.** The handler answers in one round (`impl_of_ret`). Reading the round input
(`fields_input`), `href` makes the refusal test true (`rRef`, by cases on `o`: with the record `c`,
`⟦x⟧ = ⟦c⟧`), so `dRun` takes the refusal branch: the answer `rZero = ⊥` (`rZero_fields`) and the
new state with count `j + 1` and the same record bits (`recBits_fields`, `rNew_fields`). -/"""),
("""gives `decL f_k w` if `⟦y⟧ = wT w` and `⊥` otherwise; the state is `dState (j + 1) o`. -/""",
 """gives `decL f_k w` if `⟦y⟧ = wT w` and `⊥` otherwise; the state is `dState (j + 1) o`.

**Proof sketch.** On every log the refusal test is false (`href`, by cases on `o`) and the
well-formedness test is true (`hwf`), by `fields_input`. With `impl_of_query`: the first round,
with an empty log, asks `wR w ++ wC w` (`ofFn_padFin_pair`); the second, with the answer `y` in
the log (`rY_one`), compares `⟦y⟧` with `wT w` (`rOK`) and answers `rDec`, which is `decL f_k w` by
`hFE` on the `n`-bit nonce, or `rZero = ⊥` (`rZero_fields`); the new state is `dState (j + 1) o`
(`recBits_fields`, `rNew_fields`). -/"""),
("""/-- **A malformed decryption:** from `dState j o` with a query that is not refused and not well
formed, the answer is `⊥` and the state is `dState (j + 1) o`. -/""",
 """/-- **A malformed decryption:** from `dState j o` with a query that is not refused and not well
formed, the answer is `⊥` and the state is `dState (j + 1) o`: for `j < q(n)`,
`refW o ⟦x⟧ = false` and `wfW n ⟦x⟧ = false`,
`(dHandler …).impl n z (dHSeed … (k, W)) 1 x (dHState … j o) =
pure (padFin _ [], dHState … (j + 1) o)`.

**Proof sketch.** As for `dHandler_impl_dec_ref`, the handler answers in one round
(`impl_of_ret`); now the refusal test is false (`href`, by cases on `o`) and the well-formedness
test is false (`hwf`, through `wfW_eq`), so `dRun` takes the malformed branch: the answer
`rZero = ⊥` and the state `dState (j + 1) o` (`rZero_fields`, `recBits_fields`, `rNew_fields`). -/"""),
("""/-- **A recorded challenge is repeated:** from `dState j (some c)`, a challenge is answered `c`
and the state is `dState (j + 1) (some c)`. -/""",
 """/-- **A recorded challenge is repeated:** from `dState j (some c)`, a challenge is answered `c`
and the state is `dState (j + 1) (some c)`: for `j < q(n)`,
`(dHandler …).impl n z (dHSeed … (k, W)) 2 x (dHState … j (some c)) =
pure (padFin _ ⟦c⟧, dHState … (j + 1) (some c))`. -/"""),
("""`c₁ = maskL f_k r m_b`; its answer `y` gives the ciphertext `c = ⟨r, ⟨c₁, y⟩⟩`, recorded in the
state `dState (j + 1) (some c)`. -/""",
 """`c₁ = maskL f_k r m_b`; its answer `y` gives the ciphertext `c = ⟨r, ⟨c₁, y⟩⟩`, recorded in the
state `dState (j + 1) (some c)`.

**Proof sketch.** The selected message read from the round input is `msgOf n b ⟦x⟧` (`rMsg`,
`fields_input`), of `n` bits. With `impl_of_query`: the first round, with no record (flag false)
and an empty log, asks `r ‖ c₁` with the tape `r` (`mask_eval`, `ofFn_padFin_pair`); the second,
with `y` in the log (`rY_one`), returns `c = ⟨r, ⟨c₁, y⟩⟩` (`ctW_eq`, of `6n + 4` bits by
`length_ctW_tag`) and the new state with count `j + 1` and the record bits
`true :: ⟦c⟧ = recBits n (some c)` (`rNew_fields`). -/"""),
]

# ---------------------------------------------------------------- CPAHandler.lean (11 formulas, 5 sketches)
E[P + 'CPAHandler.lean'] = [
("""/-- The string entry of a lazy-table entry `(p, t, m)`: `(⟦p⟧, ⟦t⟧ ++ m)`. -/""",
 """/-- The string entry of a lazy-table entry `(p, t, m)`: `encE (p, t, m) = (⟦p⟧, ⟦t⟧ ++ m)`. -/"""),
("""/-- **The table word** of a lazy table: the nested pairs of its string entries (`GGMRed.tblEnc`). -/""",
 """/-- **The table word** of a lazy table: the nested pairs of its string entries (`GGMRed.tblEnc`),
`tblW L = GGMRed.tblEnc (L.map encE)`. -/"""),
("""/-- The table word of the empty table is empty. -/""",
 """/-- The table word of the empty table is empty: `tblW [] = []`. -/"""),
("""/-- The state length `2q(14n + 6) + 2q + 6n + 9`. -/""",
 """/-- The state length `2q(14n + 6) + 2q + 6n + 9`:
`(bStLen q).eval n = 2 q(n) (14n + 6) + 2 q(n) + (6n + 9)`. -/"""),
("""/-- The seed length `q(n) · 2n`: one tag tape per query. -/""",
 """/-- The seed length `q(n) · 2n`: one tag tape per query, `bSeedLen q = q · tagLen`, so
`(bSeedLen q).eval n = q(n) · 2n`. -/"""),
("""/-- **The encoded state** with the table `L`, the query count `j` and the record `o`:
`⟨tblW L, ⟨1^j, recBits o⟩⟩`, padded with `false` to the state length. -/""",
 """/-- **The encoded state** with the table `L`, the query count `j` and the record `o`:
`⟨tblW L, ⟨1^j, recBits o⟩⟩`, padded with `false` to the state length,
`bState q n j L o = padFin _ ⟨tblW L, ⟨1^j, recBits n o⟩⟩`. -/"""),
("""/-- The tag tape `j` of the tape word: block `j` of `W`. -/""",
 """/-- The tag tape `j` of the tape word: block `j` of `W`,
`bTapeOf q n W j hj = blocks (q n) (2n) W ⟨j, hj⟩`. -/"""),
("""/-- The fields of an encoded state that fits: the table word, the count `1^j`, the flag and the
record. -/""",
 """/-- The fields of an encoded state that fits: the table word, the count `1^j`, the flag and the
record.

**Proof sketch.** The encoded triple fits in the state length: `|tblW L| = |L| · (14n + 6)` with
`|L| ≤ q(n)` (`length_tblW`) and `j ≤ q(n)` (`bStLen_eval`). So the padding only appends `false`s
to the innermost component (`ofFn_padFin_of_le`, `pairEncode_append_right` twice), and the
projections read `tblW L`, `1^j` and `recBits n o` followed by `false`s, whose head is the flag and
whose next `ct(n)` bits are the record (by cases on `o`). -/"""),
("""/-- The round function is polynomial-time: pair projections, the table lookup
(`GGMRed.lookup_poly`), padding (`EnsembleLemmas.polyTimeComputable_padL`), the tape by
`unaryMulPair`, `dropPrefixByLength` and `pairTakePoly`, word tests (`pairEq`, `lenEq_poly`) and
`polyTimeComputable_ite`. -/""",
 """/-- The round function is polynomial-time: `PolyTimeComputable (bRun q)`.

**Proof sketch.** Every reader of `bRun` is assembled from the generic input readers (`rU`, `rW`,
`rS`, `rI`, `rX`, `rL`, `rAns`) and pair projections: the record by `pairTakePoly`; the tape by
`unaryMulPair`, `dropPrefixByLength` and `pairTakePoly`; the table lookup by `GGMRed.lookup_poly`;
padding by `EnsembleLemmas.polyTimeComputable_padL`; word tests by `pairEq`, `isNil` and
`lenEq_poly`. The branches for the three oracles are combined with `polyTimeComputable_ite`. -/"""),
("""/-- **The handler of the CPA reduction** for the budget `q`: state `bState` (initially the empty
table, count `0`, no record), seed `q(n)` tag tapes, one outer call per inner query, the adversary
run on the empty input, and the finalization outputting the adversary's bit. -/""",
 """/-- **The handler of the CPA reduction** for the budget `q`: state `bState` (initially the empty
table, count `0`, no record), seed `q(n)` tag tapes, one outer call per inner query, the adversary
run on the empty input, and the finalization outputting the adversary's bit:
`stateLen = bStLen q`, `seedLen = bSeedLen q`, `init n = bState q n 0 [] none`, `run = bRun q`,
`perCall = 1`, `advIn _ = []`, `outLen = 1`, `finCall = 0` and `finRun = bFin`. -/"""),
("""/-- The initial state is the empty table, count `0` and no record. -/""",
 """/-- The initial state is the empty table, count `0` and no record:
`(bHandler q).init n = bHState q n 0 [] none`. -/"""),
("""/-- The adversary's input is empty. -/""",
 """/-- The adversary's input is empty: `(bHandler q).advInput n z ω = []`. -/"""),
("""/-- **The tag of a pair `p`:** the table's, else the record's, else the tape `t`. -/""",
 """/-- **The tag of a pair `p`:** the table's, else the record's, else the tape `t`.

**Proof sketch.** The lookup on the table word is `lookL L p` (`lookup_tblW`). On an entry `e`
the lookup is nonempty and its first `2n` bits are `⟦e.2.1⟧`. Without an entry, by cases on `o`:
with no record the flag is false and the tape is taken; with the record `c`, its pair and tag
read at `2n` bits are `pairW n ⟦c⟧` and `padFin (2n) (wT ⟦c⟧)` (`bPad2_fields`), and the test
`pairW n ⟦c⟧ = p` selects the record's tag or the tape, as `tagOf` does. -/"""),
("""/-- **The lazy decryption answer of the query `⟦x⟧`:** `bDecL w = lazyDec (o, L) ⟦x⟧`. -/""",
 """/-- **The lazy decryption answer of the query `⟦x⟧`:** `bDecL w = lazyDec (o, L) ⟦x⟧`.

**Proof sketch.** The handler's tests are the lazy ones: `bRef w = refW o x` (by cases on `o`,
reading the record `c` from `recBits`), `bWF w = wfW n x`, and the decryption key read at `2n`
bits is `pairW n x` (`bPad2_fields`). The lookup on the table word is `lookL L (pairW n x)`
(`lookup_tblW`); on an entry `e` its first `2n` bits are `⟦e.2.1⟧` and the rest is `e.2.2`, so the
tag test and the answer `true :: e.2.2` are those of `lazyDec`. -/"""),
("""/-- **A recorded challenge is repeated:** from `bState j L (some c)`, a challenge is answered `c`
and the state is `bState (j + 1) L (some c)`. -/""",
 """/-- **A recorded challenge is repeated:** from `bState j L (some c)`, a challenge is answered `c`
and the state is `bState (j + 1) L (some c)`: for `j < q(n)`, `|L| ≤ q(n)` and `n`-bit messages
in `L`, `(bHandler q).impl n z (bHSeed q n W) 2 x (bHState q n j L (some c)) =
pure (padFin _ ⟦c⟧, bHState q n (j + 1) L (some c))`. -/"""),
("""`c = ⟨pairFstD y, ⟨pairSndD y, t⟩⟩` with the tag `t` of `bKeyOf n y` (`tagOf (none, L)`, else the
tape `j`), recorded in the state `bState (j + 1) L (some c)`. -/""",
 """`c = ⟨pairFstD y, ⟨pairSndD y, t⟩⟩` with the tag `t` of `bKeyOf n y` (`tagOf (none, L)`, else the
tape `j`), recorded in the state `bState (j + 1) L (some c)`.

**Proof sketch.** As for `bHandler_impl_enc`: read the round input field by field
(`fields_input`); the first round, with no record (flag false) and an empty log, asks the CPA
challenge oracle (oracle `2`) at `⟦x⟧`; the second, with the answer `y` in the log (`rAns_one`),
takes the tag of `bKeyOf n y` (`bTag_fields` with no record), returns the ciphertext `c`, and
writes the record bits `true :: ⟦c⟧ = recBits n (some c)` with the table unchanged
(`bNew_fields`); `InteractiveHandler.impl_of_query` assembles the two rounds. -/"""),
]

# ---------------------------------------------------------------- CPAReduction.lean (5 formulas, 1 sketch)
E[P + 'CPAReduction.lean'] = [
("""/-- **The abstraction:** the handler's state `bState j L o` and the CPA record of `o`, as functions
of the lazy experiment's state `(o, L)` with the counter `j`. -/""",
 """/-- **The abstraction:** the handler's state `bState j L o` and the CPA record of `o`, as functions
of the lazy experiment's state `(o, L)` with the counter `j`,
`bAbs q n ((o, L), j) = (bHState q n j L o, o.map (cpaRec n))`. -/"""),
("""/-- **The invariant:** the table has at most one entry per query, each with an `n`-bit message. -/""",
 """/-- **The invariant:** the table has at most one entry per query, each with an `n`-bit message,
`bInv n ((o, L), j) ↔ |L| ≤ j ∧ ∀ e ∈ L, |e.2.2| = n`. -/"""),
("""/-- The tag tapes of the tape word, extended to every index (`AdaptiveCPA.extTape`). -/""",
 """/-- The tag tapes of the tape word, extended to every index (`AdaptiveCPA.extTape`):
`bTapes q n W = extTape (blocks (q n) (2n) W)`. -/"""),
("""/-- **The calls of the lazy experiment keep the invariant** and raise the counter by one: an
encryption adds one entry with the `n`-bit message; the other calls keep the table. -/""",
 """/-- **The calls of the lazy experiment keep the invariant** and raise the counter by one: an
encryption adds one entry with the `n`-bit message; the other calls keep the table,
`bInv n s → (ettLazyTape … T i x s).AllOutputs fun p => bInv n p.2 ∧ p.2.2 ≤ s.2 + 1`.

**Proof sketch.** Unfold one call (`ettLazyTape_eq`, `tapeImpl_apply`, `ettLazyK_eq`): for every
nonce it is a pure step to the counter `j + 1`, so the counter bound holds by `le_rfl`. By the
oracle: an encryption adds the entry with the message `⟦x⟧` of `n` bits (`lazyStep_enc`), so
`|L| ≤ j` becomes `|L| + 1 ≤ j + 1`; decryption and both challenge cases keep the table
(`lazyStep_dec`, `lazyStep_challenge_some`, `lazyStep_challenge_none`), and `|L| ≤ j ≤ j + 1`. -/"""),
("""/-- **Step 3 of [PS10, Thm 170.4]: the rejecting experiment with a random tag function is a CPA
experiment of the §3.9 scheme.** For a machine adversary `A` with budget `q` there is a machine
""",
 """/-- **Step 3 of [PS10, Thm 170.4]: the rejecting experiment with a random tag function is a CPA
experiment of the §3.9 scheme**,
`∃ B, ∀ b n f, 𝔼_R ettAcc … f R true b A (q n) =
𝔼_r 𝔼[⟦output⟧₀ = 1 | simulate (fImpl … (atkOf false) b f) (B.toComp … (qRed q n) r) none]`.
For a machine adversary `A` with budget `q` there is a machine
"""),
]

# ---------------------------------------------------------------- Forgery.lean (6 formulas, 2 sketches, module)
E[P + 'Forgery.lean'] = [
("""  refused. The union bound over the queries gives `q / 2^{2n}` (`expect_prob_bad_le`).

## Main results
""",
 """  refused. The union bound over the queries gives `q / 2^{2n}` (`expect_prob_bad_le`).

## Main definitions

* `ETTGame.RevInv M s`: the invariant of the revealed pairs, with `keys M = M.map Prod.fst`,
  `keys M ⊆ s.2 ∪ {pairW n ⟦c⟧ | s.1 = some c}`, `s.2 ⊆ keys M`, and a record `s.1 = some c` with
  `⟦c⟧ = ctW ⟦r⟧ c₁ ⟦y⟧`, `|c₁| = n`, `pairV n ⟦r⟧ c₁ ∈ keys M` and `ovr M R (pairV n ⟦r⟧ c₁) = y`.

## Main results
"""),
("""the calls of `ettBad … false` and `ettBad … true` have the same
expectation of `G`.
""",
 """the calls of `ettBad … false` and `ettBad … true` have the same
expectation of `G`: for `s.2 ≠ true` and `G̃ ys = if ys.2.2 = true then 0 else G ys`,
`𝔼[G̃ | ettBad … false b i x s] = 𝔼[G̃ | ettBad … true b i x s]`.
"""),
("""/-- **The flag is sticky:** from a flagged state every successor is flagged. -/""",
 """/-- **The flag is sticky:** from a flagged state every successor is flagged,
`s.2 = true → (ettBad … rej b i x s).AllOutputs fun ys => ys.2.2 = true`. -/"""),
("""/-- **The flag is a ghost:** forgetting it, the simulation of `ettBad` is the simulation of
`ettImpl`, from every flag (`simulate_eq_of_abs` with the projection). -/""",
 """/-- **The flag is a ghost:** forgetting it, the simulation of `ettBad` is the simulation of
`ettImpl`, from every flag (`simulate_eq_of_abs` with the projection):
`(simulate (ettBad … rej b) c (s, β)).bind (fun p => pure (p.1, p.2.1)) =
simulate (ettImpl … rej b) c s`. -/"""),
("""word `⟨r, ⟨c₁, y⟩⟩` of a nonce, an `n`-bit mask and the table's value `y` at their pair. -/""",
 """word `⟨r, ⟨c₁, y⟩⟩` of a nonce, an `n`-bit mask and the table's value `y` at their pair: with
`keys M = M.map Prod.fst`,
`RevInv M s ↔ (∀ p ∈ keys M, p ∈ s.2 ∨ ∃ c, s.1 = some c ∧ p = pairW n ⟦c⟧) ∧
(∀ p ∈ s.2, p ∈ keys M) ∧ (∀ c, s.1 = some c → ∃ r c₁ y, ⟦c⟧ = ctW ⟦r⟧ c₁ ⟦y⟧ ∧ |c₁| = n ∧
pairV n ⟦r⟧ c₁ ∈ keys M ∧ ∀ R, ovr M R (pairV n ⟦r⟧ c₁) = y)`. -/"""),
("""/-- `RevInv M s` unfolded. -/""",
 """/-- `RevInv M s` unfolded, with `keys M = M.map Prod.fst`:
`RevInv M s ↔ (∀ p ∈ keys M, p ∈ s.2 ∨ ∃ c, s.1 = some c ∧ p = pairW n ⟦c⟧) ∧
(∀ p ∈ s.2, p ∈ keys M) ∧ (∀ c, s.1 = some c → ∃ r c₁ y, ⟦c⟧ = ctW ⟦r⟧ c₁ ⟦y⟧ ∧ |c₁| = n ∧
pairV n ⟦r⟧ c₁ ∈ keys M ∧ ∀ R, ovr M R (pairV n ⟦r⟧ c₁) = y)`. -/"""),
("""/-- The empty table and the initial state satisfy the invariant. -/""",
 """/-- The empty table and the initial state satisfy the invariant: `RevInv [] (none, [])`, since its
clauses quantify over `p ∈ []`, over `p ∈ []` and over `none = some c`. -/"""),
("""/-- An encryption at a new pair `p` with the value `t` keeps the invariant of the extended table. -/""",
 """/-- An encryption at a new pair `p` with the value `t` keeps the invariant of the extended table.

**Proof sketch.** Clause by clause. A key of `(p, t) :: M` is `p`, now listed, or a key of `M`,
listed or the challenge's pair as before. A listed pair of `p :: s.2` is `p`, now a key, or a key
of `M`. The challenge's witnesses `r, c₁, y` are kept: their pair is still a key, and it differs
from the new `p ∉ keys M`, so `ovr ((p, t) :: M) R` still gives `y` there (`ovr_cons`,
`Function.update_of_ne`). -/"""),
("""/-- Recording a challenge at a new pair with the value `t` keeps the invariant of the extended
table. -/""",
 """/-- Recording a challenge at a new pair with the value `t` keeps the invariant of the extended
table.

**Proof sketch.** Clause by clause. The new key `pairV n ⟦r⟧ c₁` is the pair of the recorded `c`
(`pairW_eq`, `wR_ctW`, `wC_ctW` on `⟦c⟧ = ctW ⟦r⟧ c₁ ⟦t⟧`); the old keys are listed, since the
state had no record. The list is unchanged and its pairs are still keys. The record's witnesses
are `r, c₁, t`: the new key is a key, and `ovr` of the extended table gives `t` there (`ovr_cons`,
`Function.update_self`). -/"""),
]

# ---------------------------------------------------------------- Transfer.lean (module)
E[P + 'Transfer.lean'] = [
("""over the key (`accept_indGame_eq`).

## Main results
""",
 """over the key (`accept_indGame_eq`).

## Main definitions

* `ETTGame.stRec`: the challenge record of the experiment's state, `stRec s = s.1`.

## Main results
"""),
]

# ---------------------------------------------------------------- Machines.lean (3 formulas)
E[P + 'Machines.lean'] = [
("""/-- The entry count is polynomial-time: an iterated emission (`polyTimeComputable_iterateEmit`)
along `pairSndD`, which does not lengthen its argument (`length_pairSndD_le`). -/""",
 """/-- The entry count is polynomial-time, `PolyTimeComputable logCount`, i.e.
`∃ M C c, M.ComputesFunInTime logCount (fun n => C * (n + 1)^c)`: an iterated emission
(`polyTimeComputable_iterateEmit`) along `pairSndD`, which does not lengthen its argument
(`length_pairSndD_le`). -/"""),
("""/-- The raw function of the capped machine: `A`'s output, except that once the argument (the
encoded log) has `q(n)` entries, an output with first component `[false]` (a query word) becomes
the empty word. -/""",
 """/-- The raw function of the capped machine: `A`'s output, except that once the argument (the
encoded log) has `q(n)` entries, an output with first component `[false]` (a query word) becomes
the empty word: `capRaw A q z = if |logCount (inArg z)| = q(|inParam z|) ∧
pairFstD (A.output z) = [false] then [] else A.output z`. -/"""),
("""/-- The capped raw function is polynomial-time: the entry count (`polyTimeComputable_logCount`),
a length comparison with `1^{q(n)}` (`EffFill.lenEq_poly`, `polyTimeComputable_unaryPoly`), a
word comparison (`polyTimeComputable_pairEq`) and `A`'s output. -/""",
 """/-- The capped raw function is polynomial-time, `PolyTimeComputable (capRaw A q)`, i.e.
`∃ M C c, M.ComputesFunInTime (capRaw A q) (fun n => C * (n + 1)^c)`: the entry count
(`polyTimeComputable_logCount`), a length comparison with `1^{q(n)}` (`EffFill.lenEq_poly`,
`polyTimeComputable_unaryPoly`), a word comparison (`polyTimeComputable_pairEq`) and `A`'s output.
-/"""),
]

# ---------------------------------------------------------------- Reduction.lean (4 formulas)
E[P + 'Reduction.lean'] = [
("""/-- **The outer oracle answering with `g`:** a query `x` is answered `g x`, lengths adjusted. -/""",
 """/-- **The outer oracle answering with `g`:** a query `x` is answered `g x`, lengths adjusted,
`gOuter n g i x s = pure (padFin _ ⟦g (padFin (2n) ⟦x⟧)⟧, s)`. -/"""),
("""/-- The handler's state and the (trivial) outer state, as functions of `ettTape`'s state. -/""",
 """/-- The handler's state and the (trivial) outer state, as functions of `ettTape`'s state:
`dAbs … (σ, j) = (dHState q E hE b n j σ.1, ())`. -/"""),
("""/-- The tapes of the tape word, extended to every index (`AdaptiveCPA.extTape`). -/""",
 """/-- The tapes of the tape word, extended to every index (`AdaptiveCPA.extTape`):
`dTapes q n W = extTape (blocks (q n) n W)`. -/"""),
("""/-- **Step 1 of [PS10, Thm 170.4]: the tag key becomes a random function.** For a machine
adversary `A` with budget `q` and a challenge bit `b` there is a next-query machine `D` such that at
""",
 """/-- **Step 1 of [PS10, Thm 170.4]: the tag key becomes a random function**,
`∃ D, ∀ n, |𝔼_{k₁} 𝔼_{k₂} ettAcc … (F n k₁) (F (2n) k₂) false b A (q n) -
𝔼_{k₁} 𝔼_R ettAcc … (F n k₁) R false b A (q n)| =
prfAdv (F (2n)) (D.toOracleAdversary (2n) (2n) (2n) (q (2n)))`.
For a machine adversary `A` with budget `q` and a challenge bit `b` there is a next-query machine
`D` such that at
"""),
]

# ---------------------------------------------------------------- Tools.lean (2 formulas)
E[P + 'Tools.lean'] = [
("""invariant `P` that every call of `impl₂` keeps.
""",
 """invariant `P` that every call of `impl₂` keeps: for `c` with at most `m` queries, `P s` and
`cnt s + m ≤ κ`, `𝔼[G | simulate impl₁ c (f s)] = 𝔼[fun p => G (p.1, f p.2) | simulate impl₂ c s]`.
"""),
("""/-- **One coin per query, from tapes in advance:** the query `x` to oracle `i` in state `(s, j)`
runs `K i x s (T j)` and advances the query counter `j`. -/""",
 """/-- **One coin per query, from tapes in advance:** the query `x` to oracle `i` in state `(s, j)`
runs `K i x s (T j)` and advances the query counter `j`,
`tapeImpl K T i x (s, j) = (K i x s (T j)).bind fun p => pure (p.1, (p.2, j + 1))`. -/"""),
]

# ---------------------------------------------------------------- EncryptThenTag.lean (1 sketch)
E['TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag.lean'] = [
("""for the tag function `F (2n) k₂`, and `⊥` otherwise (`ccaDecFun_eq`, `ccaDecOK_eq`, `hFE`). The
zero-parameter malformed words are read alike: their total projections are empty. -/""",
 """for the tag function `F (2n) k₂`, and `⊥` otherwise (`ccaDecFun_eq`, `ccaDecOK_eq`, `hFE`). The
zero-parameter malformed words are read alike: their total projections are empty.

**Proof sketch.** Unfold the decryption machine (`ccaScheme_dec`, `runAtL_ofPolyTimeUniform`,
`ccaDecFun_eq`, `ccaDecOK_eq`). Its test is `|wR w| = n`, `|wC w| = n` and
`E⟨⟦k₂⟧, wR w ++ wC w⟩ = wT w`; on `n`-bit fields `E⟨⟦k₂⟧, wR w ++ wC w⟩` is
`tagL (F (2n) k₂) (wR w) (wC w)` (`hFE`, `pairV_eq`), so the test is `validW`. On a valid word
the output `wC w ⊕ E⟨⟦k₁⟧, wR w⟩` has `n` bits and decodes, giving `decL (F n k₁) w` (`hFE`,
`decodeFin_ofFn`, `decAnswer_some`); otherwise the output `true :: 1^n` has `n + 1` bits, decodes
to nothing and is read as `0^{n+1}` (`decodeFin_eq`, `decAnswer_none`, `ofFn_zeroBits`). -/"""),
]

for f, reps in E.items():
    p = f'{wt}/{f}'
    s = open(p, encoding='utf-8').read()
    for old, new in reps:
        c = s.count(old)
        assert c == 1, (f, c, old[:70])
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print(f, len(reps))
