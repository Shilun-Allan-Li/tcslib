#!/usr/bin/env bash
# tip-probes.sh <stage>: sc-yao integration-on-tip probes on dl-oleans-2 (read-only: lean -DmaxErrors=0, no -o), one Lean
# process at a time. Stages as Phase 2's phase2-probes.sh: collect (CollectLand + AxiomsLand unmodified, AxiomsTipExtra),
# seals (canonical coe variant, A and B, Yao.lean only), runseals, sum.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/sc-yao-r1/int-tip; P2=$SP/dl-review/sc-yao-r1/phase2
WT=$SP/wt-int-sc-yao-tip; TREE=$SP/dl-oleans-2; REV=e327a5f284c043493e1b405b282e9abc5e002b61
TS=$E/tools/seal/archived-gate10-tools
export PATH=$HOME/.elan/bin:$PATH
case $1 in
collect)
  mkdir -p $WT/ScYaoTipProbe; cp $E/probe-src/CollectLand.lean $E/probe-src/AxiomsLand.lean $E/probe-src/AxiomsTipExtra.lean $WT/ScYaoTipProbe/
  printf 'ScYaoTipProbe/CollectLand\nScYaoTipProbe/AxiomsLand\nScYaoTipProbe/AxiomsTipExtra\n' > $E/probe-order.txt
  python3 -I $E/tools/runner_full.py $WT $E/probe-order.txt $TREE $E/probe-runs ;;
seals)
  LOG=$E/probe-runs/mods/ScYaoTipProbe_CollectLand.log
  grep -P '^COEINST\t' $LOG | grep 'projection=true' | cut -f2 | sort -u > $E/seal-coe-names.txt
  for v in A B; do
    mkdir -p $E/seals-coe; if [ $v = B ]; then export SEAL_EVAL=1; else unset SEAL_EVAL; fi
    export SEAL_COE_FILE=$E/seal-coe-names.txt
    SEAL_CHUNK=2000 python3 -I $E/tools/seal/mkseals_sy.py $TS $LOG $WT $REV $E/seals-coe/$v ScYaoTipSeal_coe Seal${v}_ TCSlib.Cryptography.SecureComputation.Yao > $E/seals-coe/mkseals-$v.log 2>&1 || { echo "mkseals $v failed"; exit 1; }
  done
  unset SEAL_EVAL SEAL_COE_FILE
  printf 'ScYaoTipSeal_coe/SealA_Cryptography_SecureComputation_Yao\nScYaoTipSeal_coe/SealB_Cryptography_SecureComputation_Yao\n' > $E/seal-order.txt ;;
runseals)
  python3 -I $E/tools/runner_full.py $WT $E/seal-order.txt $TREE $E/seal-runs ;;
sum)
  for v in A B; do python3 -I $E/tools/seal/sealsum.py $E/seals-coe/$v $E/seal-runs $P2/touched-head.json $E/seal-sum-coe-$v.tsv; done ;;
esac
