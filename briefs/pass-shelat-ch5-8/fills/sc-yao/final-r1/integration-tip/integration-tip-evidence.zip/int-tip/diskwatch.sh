#!/usr/bin/env bash
# log free space on / every 60 s until the build's runner.exit exists
while [ ! -s /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/build-m/runner.exit ]; do echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/build-m/df.log; sleep 60; done
echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free (end)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/build-m/df.log
