#!/usr/bin/env bash
# Integration build of M = e327a5f2 (records tip f22e0f67 x #341 head e9b03c43) on dl-oleans-2 (one Lean process; runner stops at the first failure).
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-int-sc-yao-tip
export PATH=$HOME/.elan/bin:$PATH
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/tools/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-int-sc-yao-tip /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/plan-m/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/build-m
echo "runner exit $?" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/int-tip/build-m/runner.exit
