"""zipcover.py <zip> <sums> <localbase> <outfile> <dir>...: for every file under <localbase>/<dir>, check that the zip has an entry
with the same relative path (prefix 'phase2/<dir>/...') whose bytes hash to the same SHA-256, and that <sums> lists that hash.
Prints COVERED/NOT per file and a summary; exit 0 only if every file is covered."""
import sys, os, zipfile, hashlib
zp, sums, base, out = sys.argv[1:5]; dirs = sys.argv[5:]
z = zipfile.ZipFile(zp)
S = {}
for l in open(sums):
    h, p = l.rstrip('\n').split('  ', 1); S[p] = h
names = set(z.namelist())
bad = 0; n = 0; lines = []
for d in dirs:
    root = os.path.join(base, d)
    for dp, ds, fs in os.walk(root):
        for f in sorted(fs):
            p = os.path.join(dp, f); rel = 'phase2/' + os.path.relpath(p, base)
            if os.path.islink(p): lines.append(f'NOT symlink {rel}'); bad += 1; n += 1; continue
            lh = hashlib.sha256(open(p, 'rb').read()).hexdigest(); n += 1
            if rel not in names: lines.append(f'NOT absent-in-zip {lh} {rel}'); bad += 1; continue
            zh = hashlib.sha256(z.read(rel)).hexdigest()
            sh = S.get(rel)
            if zh != lh or sh != lh: lines.append(f'NOT hash local {lh} zip {zh} sums {sh} {rel}'); bad += 1; continue
            lines.append(f'COVERED {lh} {rel}')
lines.append(f'TOTAL files {n}; covered {n - bad}; not covered {bad}')
open(out, 'w').write('\n'.join(lines) + '\n'); print(lines[-1]); sys.exit(1 if bad else 0)
