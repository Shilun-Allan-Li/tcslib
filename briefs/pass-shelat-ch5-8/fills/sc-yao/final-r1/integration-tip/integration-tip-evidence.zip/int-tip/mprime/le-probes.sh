#!/usr/bin/env bash
# le-probes.sh <stage>: M' (Gate 42 landing edits) probes on dl-oleans-2 (read-only: lean -DmaxErrors=0, no -o), one Lean process
# at a time. collect: CollectLand + AxiomsLand (unmodified) + AxiomsLE; seals: RunWithHost.lean in coe/strict x A/B; runseals; sum.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/sc-yao-r1/int-tip; F=$E/mprime; P2=$SP/dl-review/sc-yao-r1/phase2
WT=$SP/wt-int-sc-yao-tip-le; TREE=$SP/dl-oleans-2; REV=061ad60cdc485e6248eeadfc2de165a227f7cd99
TS=$E/tools/seal/archived-gate10-tools; MOD=TCSlib.Cryptography.SecureComputation.Yao.HybridProof.RunWithHost; F2=Cryptography_SecureComputation_Yao_HybridProof_RunWithHost
export PATH=$HOME/.elan/bin:$PATH
case $1 in
collect)
  mkdir -p $WT/ScYaoLEProbe; cp $F/probe-src/CollectLand.lean $F/probe-src/AxiomsLand.lean $F/probe-src/AxiomsLE.lean $WT/ScYaoLEProbe/
  printf 'ScYaoLEProbe/CollectLand\nScYaoLEProbe/AxiomsLand\nScYaoLEProbe/AxiomsLE\n' > $F/probe-order.txt
  python3 -I $E/tools/runner_full.py $WT $F/probe-order.txt $TREE $F/probe-runs ;;
seals)
  LOG=$F/probe-runs/mods/ScYaoLEProbe_CollectLand.log
  grep -P '^COEINST\t' $LOG | grep 'projection=true' | cut -f2 | sort -u > $F/seal-coe-names.txt
  : > $F/seal-order.txt
  for c in coe strict; do for v in A B; do
    mkdir -p $F/seals-$c; if [ $v = B ]; then export SEAL_EVAL=1; else unset SEAL_EVAL; fi
    if [ $c = coe ]; then export SEAL_COE_FILE=$F/seal-coe-names.txt; else unset SEAL_COE_FILE; fi
    SEAL_CHUNK=2000 python3 -I $E/tools/seal/mkseals_sy.py $TS $LOG $WT $REV $F/seals-$c/$v ScYaoLESeal_$c Seal${v}_ $MOD > $F/seals-$c/mkseals-$v.log 2>&1 || { echo "mkseals $c $v failed"; exit 1; }
    echo ScYaoLESeal_$c/Seal${v}_$F2 >> $F/seal-order.txt
  done; done
  unset SEAL_EVAL SEAL_COE_FILE ;;
runseals)
  python3 -I $E/tools/runner_full.py $WT $F/seal-order.txt $TREE $F/seal-runs ;;
sum)
  for c in coe strict; do for v in A B; do python3 -I $E/tools/seal/sealsum.py $F/seals-$c/$v $F/seal-runs ${TOUCHED:-$P2/touched-head.json} $F/seal-sum-$c-$v.tsv; done; done ;;
esac
