"""mkevidence.py <evidence-dir> <zip> <sums>: zip every regular file under <evidence-dir> as int-tip/<relpath> (sorted, deflated,
fixed timestamps), then write <sums> = `<sha256>  int-tip/<relpath>` for every entry (as read back from the zip) followed by
the zip itself. Symlinks are refused."""
import sys, os, zipfile, hashlib
src, zp, sp = sys.argv[1:4]
files = []
for d, ds, fs in os.walk(src):
    for f in fs:
        p = os.path.join(d, f)
        assert not os.path.islink(p), p
        files.append(os.path.relpath(p, src))
files.sort()
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for r in files:
        zi = zipfile.ZipInfo('int-tip/' + r, date_time=(2026, 11, 16, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, open(os.path.join(src, r), 'rb').read())
lines = []
with zipfile.ZipFile(zp) as z:
    for n in z.namelist(): lines.append(f'{hashlib.sha256(z.read(n)).hexdigest()}  {n}')
    for r in files:
        assert hashlib.sha256(z.read('int-tip/' + r)).hexdigest() == hashlib.sha256(open(os.path.join(src, r), 'rb').read()).hexdigest()
lines.append(f"{hashlib.sha256(open(zp, 'rb').read()).hexdigest()}  {os.path.basename(zp)}")
open(sp, 'w').write('\n'.join(lines) + '\n')
print(f'{len(files)} files; zip {os.path.getsize(zp)} bytes; {lines[-1]}')
