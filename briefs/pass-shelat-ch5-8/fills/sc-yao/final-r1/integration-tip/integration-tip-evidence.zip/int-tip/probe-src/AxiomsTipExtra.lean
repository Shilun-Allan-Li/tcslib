import Lean
import TCSlib.Cryptography.SecureComputation.YaoReal

/-! sc-yao integration-on-tip supplement to AxiomsLand: every `otProtocol_*` result, and `#admitted` traces for
`HybridProtocol.hbcSecure_compose` and the `otProtocol_*` security results (elaborator copied verbatim from AxiomsLand). -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536
open Lean Elab Command

/-- Does the constant's type or value mention `sorryAx` directly? -/
def directSorry (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some ci =>
    ci.type.getUsedConstants.contains ``sorryAx ||
      (match ci.value? (allowOpaque := true) with
       | some v => v.getUsedConstants.contains ``sorryAx
       | none => false)
  | none => false

/-- Every constant reachable from `start` through types and values. -/
def closureOf (env : Environment) (start : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut todo : Array Name := #[start]
  for _ in [0:100000000] do
    if todo.isEmpty then break
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    if let some ci := env.find? n then
      for c in ci.type.getUsedConstants do todo := todo.push c
      if let some v := ci.value? (allowOpaque := true) then
        for c in v.getUsedConstants do todo := todo.push c
  return seen

/-- `#admitted n`: the declarations in `n`'s closure that use `sorryAx` directly. -/
elab "#admitted " id:ident : command => do
  let env ← getEnv
  let n := id.getId
  unless env.contains n do throwError "unknown constant {n}"
  let s := closureOf env n
  let adm := (s.toList.filter (fun m => m != ``sorryAx && directSorry env m)).toArray.qsort
    (fun a b => a.toString < b.toString)
  logInfo m!"ADMITTED {n}: closure {s.size}; direct sorryAx {adm.size}: {adm.toList}"

#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_P
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_V
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_rounds
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_verifierFirst
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_isOT
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_outV
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_outP
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_simulators
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_polyTime
#print axioms TCSlib.Cryptography.SecureComputation.otProtocol_hbcSecure
#admitted TCSlib.Cryptography.SecureComputation.HybridProtocol.hbcSecure_compose
#admitted TCSlib.Cryptography.SecureComputation.otProtocol_simulators
#admitted TCSlib.Cryptography.SecureComputation.otProtocol_polyTime
#admitted TCSlib.Cryptography.SecureComputation.otProtocol_hbcSecure
