#!/usr/bin/env bash
# restore-tree.sh: restore /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 to snapshot-pre (457ba704...): hard-link backup aware.
set -u
T=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2; BK=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-scyao-backup; E=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/phase2; L=$E/restore/restore-log.txt
mkdir -p $E/restore; : > $L
echo "backup hash failures: $( (cd $BK && sha256sum -c $E/tree/backed-up.txt) | grep -vc ': OK$')" >> $L
while read h f; do
  if [ "$(sha256sum < $T/$f 2>/dev/null | cut -d' ' -f1)" = "$h" ]; then echo "UNCHANGED $f" >> $L
  else rm -f $T/$f; cp -p $BK/$f $T/$f; echo "RESTORED $f" >> $L; fi
done < $E/tree/backed-up.txt
while read m; do if [ -f $T/$m.olean ]; then echo "DELETED $(sha256sum < $T/$m.olean | cut -d' ' -f1) $m.olean" >> $L; rm $T/$m.olean; fi; done < $E/tree/new-oleans.txt
if [ -d $T/Mathlib ]; then echo "DELETED-MATHLIB-OVERLAY symlinks $(find $T/Mathlib -type l | wc -l) files $(find $T/Mathlib -type f | wc -l)" >> $L; find $T/Mathlib -type f -exec sha256sum {} + | sed "s|^|DELETED-MATHLIB-FILE |" >> $L; rm -r $T/Mathlib; fi
find $T -type d -empty | sort > $E/restore/empty-dirs-before-prune.txt
find $T -type d -empty -delete; find $T -type d -empty -delete
python3 -I $E/tools/snapshot.py $T $E/tree/snapshot-post.txt | tee -a $L
cmp $E/tree/snapshot-pre.txt $E/tree/snapshot-post.txt && echo "SNAPSHOT EQUAL" | tee -a $L || echo "SNAPSHOT DIFFERS" | tee -a $L
python3 -I $E/tools/restoreplan.py $T $E/tree/snapshot-pre.txt $E/order-head/order.txt $E/restore/plan | tee -a $L
grep -c '^RESTORED' $L; grep -c '^DELETED ' $L
