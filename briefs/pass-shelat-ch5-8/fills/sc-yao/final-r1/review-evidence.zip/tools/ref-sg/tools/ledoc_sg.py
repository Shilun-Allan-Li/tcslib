"""ledoc_sg.py <worktree>: the sc-garble LE-doc, docstring-only exact replacements (each must occur exactly once).
1. GarblingSecurity/NestedBounds.lean module docstring: list its two main theorems under ## Main results.
2. SpecialEncryptionSecurity/WrongKey.lean module docstring: list its two main theorems under ## Main results.
3. GarblingSecurity.lean, nestedSpecial_wrongKeyBot: one sentence appended to the **Proof sketch.** naming the
   delivered route (the statement prose before the sketch is untouched)."""
import sys
wt = sys.argv[1]
S = wt + '/TCSlib/Cryptography/SecureComputation/'
E = [
 (S + 'GarblingSecurity/NestedBounds.lean',
  "* `SecureComputation.GarblingCoins.length_nestedInner`: the inner ciphertext has `4n+2` bits.\n",
  "* `SecureComputation.GarblingCoins.length_nestedInner`: the inner ciphertext has `4n+2` bits.\n"
  "* `SecureComputation.GarblingCoins.nestedSpecial_wrongKeyBot_of_string_bounds`: inner and outer\n"
  "  string success bounds `ε₁, ε₂` give `(nestedSpecial E₁ E₂ n).WrongKeyBot (ε₁ + ε₂)`.\n"
  "* `SecureComputation.uprob_not_good_distinct_le_of_uniform_data`: with uniform keys and row\n"
  "  coins, goodness with distinct output keys fails with probability at most\n"
  "  `12 · |gates| · δ + m / |K|`.\n"),
 (S + 'SpecialEncryptionSecurity/WrongKey.lean',
  "* `SecureComputation.SpecialWrongKey.polyTimeComputable_prefixTest`: efficiency of the test.\n",
  "* `SecureComputation.SpecialWrongKey.polyTimeComputable_prefixTest`: efficiency of the test.\n"
  "* `SecureComputation.SpecialWrongKey.exists_negligible_prefix_collision`: two independent keys\n"
  "  give equal `n`-bit pad prefixes on a common nonce with negligible probability.\n"
  "* `SecureComputation.SpecialWrongKey.spDecStr_none_iff_prefix_ne`: an honest ciphertext\n"
  "  decrypts to `⊥` under a second key exactly when the two pad prefixes differ.\n"),
 (S + 'GarblingSecurity.lean',
  "So `δ = ε₁ + ε₂`, negligible (`Negligible.add`); `ε₁` and `ε₂` are averaged over the plaintext\n"
  "and the other layer's key and coins. -/\n",
  "So `δ = ε₁ + ε₂`, negligible (`Negligible.add`); `ε₁` and `ε₂` are averaged over the plaintext\n"
  "and the other layer's key and coins. In the proof, `spDecStr_wrongKey` at `ℓ = n` (with `G₁`)\n"
  "and at `ℓ = innerLen` (with `G₂`) gives the two string success bounds\n"
  "(`GarblingCoins.uprob_isSome_lt_of_none`), and\n"
  "`GarblingCoins.nestedSpecial_wrongKeyBot_of_string_bounds` carries out the case analysis,\n"
  "including the zero-position case, which has no distinct choices. -/\n"),
]
for p, old, new in E:
    s = open(p, encoding='utf-8').read()
    assert s.count(old) == 1, (p, s.count(old))
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
    print('edited', p[len(wt) + 1:])
