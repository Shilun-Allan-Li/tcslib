#!/usr/bin/env bash
# phase2-probes.sh <stage>: sc-yao review Phase 2 probes on /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 (read-only: lean -DmaxErrors=0, no -o),
# one Lean process at a time. Stages: collect (collector + axiom probe), seals (generate), runseals, controls (generate+run).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/phase2; WT=$SP/wt-land-sc-yao; TREE=$SP/dl-oleans-2; REV=e9b03c437aca251846430ff23b40ee5ff3d3347a
TS=$E/tools-seal/archived-gate10-tools
export PATH=$HOME/.elan/bin:$PATH
case $1 in
collect)
  mkdir -p $WT/ScYaoProbe; cp $E/probe-src/CollectLand.lean $E/probe-src/AxiomsLand.lean $WT/ScYaoProbe/
  printf 'ScYaoProbe/CollectLand\nScYaoProbe/AxiomsLand\n' > $E/probe-order.txt
  python3 -I $E/tools/runner_full.py $WT $E/probe-order.txt $TREE $E/probe-runs ;;
seals)
  LOG=$E/probe-runs/mods/ScYaoProbe_CollectLand.log
  grep -P '^COEINST\t' $LOG | grep 'projection=true' | cut -f2 | sort -u > $E/seal-coe-names.txt
  MODS=$(sed 's|/|.|g' $E/probe-src/owners.txt)
  cd $E
  for v in A B; do for c in strict coe; do
    mkdir -p $E/seals-$c; if [ $v = B ]; then export SEAL_EVAL=1; else unset SEAL_EVAL; fi
    if [ $c = coe ]; then export SEAL_COE_FILE=$E/seal-coe-names.txt; else unset SEAL_COE_FILE; fi
    SEAL_CHUNK=2000 python3 -I $E/tools-seal/mkseals_sy.py $TS $LOG $WT $REV $E/seals-$c/$v ScYaoSeal_$c Seal${v}_ $MODS > $E/seals-$c/mkseals-$v.log 2>&1 || { echo "mkseals $v $c failed"; exit 1; }
  done; done
  unset SEAL_EVAL SEAL_COE_FILE
  # order: frozen files in all four variants, then helpers coe-A, strict-A, coe-B, strict-B
  : > $E/seal-order.txt
  for f in Cryptography_SecureComputation_Yao Complexity_CircuitComplexity_Uniform Complexity_CircuitComplexity_DAGCircuit; do
    for c in coe strict; do for v in A B; do echo ScYaoSeal_$c/Seal${v}_$f >> $E/seal-order.txt; done; done; done
  for cv in coe:A strict:A coe:B strict:B; do c=${cv%:*}; v=${cv#*:}
    sed -n '4,$p' $E/probe-src/owners.txt | sed 's|^TCSlib/||; s|/|_|g' | while read f; do echo ScYaoSeal_$c/Seal${v}_$f; done >> $E/seal-order.txt
  done
  wc -l < $E/seal-order.txt ;;
runseals)
  python3 -I $E/tools/runner_full.py $WT $E/seal-order.txt $TREE $E/seal-runs ;;
controls)
  for c in coe strict; do
    mkdir -p $E/seals-$c/AB; cp $E/seals-$c/A/Seal*.json $E/seals-$c/B/Seal*.json $E/seals-$c/AB/
    python3 -I $E/tools-seal/mkctl_sy.py $TS $E/seals-$c/AB $WT ScYaoCtl_$c $E/controls-$c > $E/controls-$c.gen.log 2>&1 || { echo "mkctl $c failed"; exit 1; }
    python3 -I -c "import json; print('\n'.join(p['module'] for p in json.load(open('$E/controls-$c/controls-plan.json'))))" > $E/control-order-$c.txt
  done
  cat $E/control-order-coe.txt $E/control-order-strict.txt > $E/control-order.txt
  python3 -I $E/tools/runner_full.py $WT $E/control-order.txt $TREE $E/control-runs
  for c in coe strict; do python3 -I $E/tools-seal/ctlcheck2.py $E/controls-$c/controls-plan.json $E/control-runs $E/ctlcheck-$c.json > $E/ctlcheck-$c.log; tail -1 $E/ctlcheck-$c.log; done ;;
esac
