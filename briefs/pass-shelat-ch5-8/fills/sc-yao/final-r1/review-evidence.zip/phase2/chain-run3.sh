#!/usr/bin/env bash
# after the sample seal runner exits: run the 64 paired controls and the 4 base (tip) Uniform seals, one Lean at a time.
E=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/phase2
until [ -f $E/seal-runs.exit2 ]; do sleep 10; done
cd $E && python3 -I $E/tools/runner_full.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-land-sc-yao $E/run3-order.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 $E/control-runs
echo "run3 exit $?" > $E/run3.exit
