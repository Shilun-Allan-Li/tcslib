#!/usr/bin/env bash
# after run3: the remaining 44 canonical coe-A helper seals (completing coe-A for all 68 helpers).
E=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/phase2
until [ -f $E/run3.exit ]; do sleep 10; done
cd $E && python3 -I $E/tools/runner_full.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-land-sc-yao $E/seal-order-4.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 $E/seal-runs
echo "run4 exit $?" > $E/run4.exit
