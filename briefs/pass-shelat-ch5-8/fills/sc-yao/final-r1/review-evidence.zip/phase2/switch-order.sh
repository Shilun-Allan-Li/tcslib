#!/usr/bin/env bash
# after the 12 frozen-file probes: stop my first seal runner (own PIDs 9681/9682/9683 and its lean child) and run the sample order.
E=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/sc-yao-r1/phase2
until [ "$(grep -c '"module"' $E/seal-runs/results.jsonl)" -ge 12 ]; do sleep 5; done
L=$(pgrep -P 9683); kill 9681 9682 9683 2>/dev/null; [ -n "$L" ] && kill $L 2>/dev/null
echo "$(date -u +%FT%TZ) stopped first seal runner after 12 frozen probes (killed own PIDs 9681 9682 9683 and lean $L)" >> $E/build-head/launch.txt
sleep 3
cd $E && python3 -I $E/tools/runner_full.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-land-sc-yao $E/seal-order-2.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 $E/seal-runs
echo "sample seal runner exit $?" >> $E/seal-runs.exit2
