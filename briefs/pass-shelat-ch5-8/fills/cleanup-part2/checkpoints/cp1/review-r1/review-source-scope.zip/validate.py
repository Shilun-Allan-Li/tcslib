"""Own immutable CP1 source review; no received code import, Lean, or Git writes."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
CP=HERE.parent
PAYLOAD=CP/'payload'
MAIN=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
ISSUED=MAIN/'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1'
ANCESTOR='1aa5506f58f77c215e56d24311ec33bd931cacf1'


def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def git(*args):return subprocess.run(['git','-C',str(MAIN),*args],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
def save(name,d):
    with (HERE/('final-'+name)).open('x') as f:json.dump(d,f,indent=2);f.write('\n')


def mask(s):
    out=list(s);i=depth=0;quoted=False
    while i<len(s):
        if depth:
            if s.startswith('/-',i):out[i:i+2]='  ';depth+=1;i+=2
            elif s.startswith('-/',i):out[i:i+2]='  ';depth-=1;i+=2
            else:
                if s[i]!='\n':out[i]=' '
                i+=1
        elif quoted:
            if s[i]=='\\':
                out[i]=' ';i+=1
                if i<len(s) and s[i]!='\n':out[i]=' '
                i+=1
            else:
                if s[i]=='"':quoted=False
                if s[i]!='\n':out[i]=' '
                i+=1
        elif s.startswith('/-',i):out[i:i+2]='  ';depth=1;i+=2
        elif s.startswith('--',i):
            j=s.find('\n',i);j=len(s) if j<0 else j;out[i:j]=' '*(j-i);i=j
        elif s[i]=='"':out[i]=' ';quoted=True;i+=1
        else:i+=1
    assert not depth and not quoted
    return ''.join(out)


DECL=re.compile(r'^\s*(?:@\[[^\n]*?\]\s*)*(?P<mods>(?:(?:private|protected|noncomputable|unsafe|partial|nonrec|local)\s+)*)(?P<kind>theorem|lemma|def|abbrev|opaque|instance|structure|class|inductive|axiom)\b\s*(?P<name>[^\s(:{=]+)?')
CMD=re.compile(r'^\s*(namespace|section|end|open|variable|variables|include|omit|set_option|attribute|export|mutual|syntax|macro|elab|initialize|notation|infix[lr]?|prefix|postfix)\b|^\s*(?:@\[|#(?:check|print|eval|reduce|synth|guard|guard_msgs|exit|help|where|lint|find|min_imports)\b|noncomputable\s+section\b)')


def split_header(raw):
    code=mask(raw);depth=0;i=0
    while i<len(code):
        if code[i] in '([{⟨⦃⟮':depth+=1
        elif code[i] in ')]}⟩⦄⟯':depth-=1
        elif depth==0 and code.startswith(':=',i):return raw[:i],raw[i+2:]
        elif depth==0 and re.match(r'where\b',code[i:]):return raw[:i],raw[i+5:]
        i+=1
    # Equation-compiler declarations can use top-level `| pattern =>` clauses
    # without :=. Only use this fallback after failing to find a body delimiter,
    # so statement-level matches before := remain part of the header.
    arm=re.search(r'(?m)^\s*\|',code)
    if arm:return raw[:arm.start()],raw[arm.start():]
    return raw,''


def normalized(s):return ' '.join(mask(s).split())


def parse(text,path):
    ls=text.splitlines(keepends=True);cs=mask(text).splitlines(keepends=True)
    stack=[];ns='';ds=[];bounds=[]
    for i,line in enumerate(cs):
        m=DECL.match(line);cm=CMD.match(line)
        if m or cm:bounds.append(i)
        if m:
            name=m.group('name')
            if name and name not in ['where','extends']:
                key=name.removeprefix('_root_.') if name.startswith('_root_.') else '.'.join(x for x in [ns,name] if x)
                ds.append({'path':path,'canonical':key,'name':name,'kind':m.group('kind'),
                  'mods':m.group('mods').split(),'private':'private' in m.group('mods').split(),'start':i+1,
                  'same_line_attributes':line[:m.start('mods')].strip()})
        st=line.strip()
        if st.startswith('namespace '):
            name=st.split()[1]
            if name.startswith('_root_.'):stack.append((ns,'_root_'));ns='';name=name.removeprefix('_root_.')
            for part in name.split('.'):stack.append((ns,part));ns='.'.join(x for x in [ns,part] if x)
        elif re.match(r'(?:noncomputable\s+)?section(?:\s|$)',st) or st=='mutual':stack.append((ns,st.split('section',1)[1].strip() if 'section' in st else ''))
        elif re.match(r'end(?:\s|$)',st):
            label=st[3:].strip();n=len(label.split('.')) if label else 1
            assert len(stack)>=n,(path,i+1,st)
            for _ in range(n):ns,_=stack.pop()
    for d in ds:
        start=d['start']-1;end=next((x for x in bounds if x>start),len(ls))
        while end>start and not cs[end-1].strip():end-=1
        raw=''.join(ls[start:end]);header,body=split_header(raw)
        d.update(end=end,raw_sha256=sha(raw.encode()),raw=raw,header=header,body=body,
                 header_normalized=normalized(header),body_normalized=normalized(body))
        attrs=[];j=start-1
        while j>=0 and (not cs[j].strip() or cs[j].lstrip().startswith('@[')):
            if cs[j].lstrip().startswith('@['):attrs.append(cs[j].strip())
            j-=1
        d['preceding_attributes']=list(reversed(attrs))
    return ds


def plain(d):return {k:v for k,v in d.items() if k not in ['raw','header_normalized','body_normalized']}


def apply_patch(data,patch):
    lines=patch.decode().splitlines(keepends=True);i=0;changed=[]
    while i<len(lines):
        if not lines[i].startswith('diff --git '):i+=1;continue
        m=re.fullmatch(r'diff --git a/(\S+) b/(\S+)\n?',lines[i]);assert m,lines[i]
        oldpath,newpath=m.groups();assert oldpath==newpath and oldpath in data,(oldpath,newpath)
        path=oldpath;i+=1;index=None
        while i<len(lines) and not lines[i].startswith('@@ '):
            assert not lines[i].startswith(('new file mode','deleted file mode','rename ','copy ','old mode','new mode'))
            if lines[i].startswith('index '):
                idx=re.fullmatch(r'index ([0-9a-f]+)\.\.([0-9a-f]+)(?: 100644)?\n?',lines[i]);assert idx;index=idx.groups()
            if lines[i].startswith('--- '):assert lines[i].rstrip()=='--- a/'+path
            if lines[i].startswith('+++ '):assert lines[i].rstrip()=='+++ b/'+path
            i+=1
        assert index and blob(data[path]).startswith(index[0]),(path,'old blob',index,blob(data[path]))
        old=data[path].decode().splitlines(keepends=True);new=[];cursor=0;hunks=[]
        while i<len(lines) and lines[i].startswith('@@ '):
            h=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert h
            a,ac,b,bc=[int(x) if x is not None else 1 for x in h.groups()];i+=1
            oldseg=[];newseg=[]
            while i<len(lines):
                line=lines[i]
                if line.startswith(('@@ ','diff --git ','-- \n')):break
                if not line or line[0] not in ' +-\\':break
                if line.startswith('\\ No newline at end of file'):
                    if oldseg:oldseg[-1]=oldseg[-1].removesuffix('\n')
                    if newseg:newseg[-1]=newseg[-1].removesuffix('\n')
                else:
                    if line[0] in ' -':oldseg.append(line[1:])
                    if line[0] in ' +':newseg.append(line[1:])
                i+=1
                if len(oldseg)==ac and len(newseg)==bc and (i>=len(lines) or not lines[i].startswith('\\ No newline')):break
            assert len(oldseg)==ac and len(newseg)==bc,(path,a,'counts',len(oldseg),ac,len(newseg),bc)
            start=a-1 if ac else a
            assert start>=cursor and old[start:start+ac]==oldseg,(path,a,'exact old segment mismatch')
            new.extend(old[cursor:start]);assert len(new)==(b-1 if bc else b),(path,b,'new position')
            new.extend(newseg);cursor=start+ac;hunks.append({'old':[a,ac],'new':[b,bc]})
        new.extend(old[cursor:]);after=''.join(new).encode();assert blob(after).startswith(index[1]),(path,'new blob',index,blob(after))
        changed.append({'path':path,'before_sha256':sha(data[path]),'after_sha256':sha(after),'hunks':hunks,'index':index});data[path]=after
    return changed


def main():
    intake=json.loads((CP/'intake.json').read_text());files=json.loads((CP/'files.json').read_text())
    assert (CP/'SNAPSHOT-COMPLETE').read_text().strip()==intake['delivery_commit']
    assert sha((CP/'received.zip').read_bytes())==intake['archive_sha256']
    assert sha((PAYLOAD/'PAYLOAD-SHA256SUMS').read_bytes())==intake['supplied_manifest_sha256']
    checked=[]
    for row in files:
        p=PAYLOAD/row['path'];b=p.read_bytes()
        assert len(b)==row['bytes'] and sha(b)==row['sha256'] and blob(b)==row['git_blob'],row['path']
        checked.append(row['path'])
    assert len(checked)==len(set(checked))
    role_data=json.loads((ISSUED/'inputs/role-manifest.json').read_text())
    roles={r['path']:r['role'] for r in role_data['roles'] if r['role']!='CHECK_ONLY'}
    assert set((ISSUED/'inputs/owned-files.txt').read_text().splitlines())==set(roles)
    source_paths={str(p.relative_to(PAYLOAD/'src')) for p in (PAYLOAD/'src').rglob('*') if p.is_file()}
    assert source_paths==set(roles)
    baseline={p:git('show',ANCESTOR+':'+p) for p in sorted(roles)}
    for row in role_data['roles']:
        if row['path'] in baseline:assert sha(baseline[row['path']])==row['source_sha256']
    replay=baseline.copy();patch_results=[]
    for rel in intake['patches']:
        p=PAYLOAD/rel;raw=p.read_bytes();changed=apply_patch(replay,raw)
        assert all(c['path'] in roles for c in changed)
        commit=re.search(rb'\AFrom ([0-9a-f]{40}) ',raw).group(1).decode()
        patch_results.append({'path':rel,'metadata_commit':commit,'sha256':sha(raw),'changed_files':changed})
    for p,b in replay.items():assert b==(PAYLOAD/'src'/p).read_bytes(),('replay mismatch',p)
    changes=[];old_decls=[];new_decls=[]
    for path in sorted(roles):
        if baseline[path]!=replay[path]:changes.append({'path':path,'role':roles[path],'old_sha256':sha(baseline[path]),'new_sha256':sha(replay[path])})
        old_decls.extend(parse(baseline[path].decode(),path));new_decls.extend(parse(replay[path].decode(),path))
    def key(d):return (d['path'],d['canonical']) if d['private'] else ('PUBLIC',d['canonical'])
    oldmap=defaultdict(list);newmap=defaultdict(list)
    for d in old_decls:oldmap[key(d)].append(d)
    for d in new_decls:newmap[key(d)].append(d)
    assert all(len(v)==1 for v in oldmap.values()),[(k,len(v)) for k,v in oldmap.items() if len(v)>1]
    assert all(len(v)==1 for v in newmap.values()),[(k,len(v)) for k,v in newmap.items() if len(v)>1]
    diffs=[]
    for k in sorted(set(oldmap)|set(newmap)):
        a=oldmap.get(k,[None])[0];b=newmap.get(k,[None])[0];flags=[]
        if not a:flags.append('ADDED')
        elif not b:flags.append('REMOVED')
        else:
            if a['path']!=b['path']:flags.append('MOVED')
            if a['header_normalized']!=b['header_normalized']:flags.append('HEADER_CHANGED')
            if a['body_normalized']!=b['body_normalized']:flags.append('BODY_CHANGED')
            if a['mods']!=b['mods'] or a['preceding_attributes']!=b['preceding_attributes'] or a['same_line_attributes']!=b['same_line_attributes']:flags.append('MODIFIER_ATTRIBUTE_CHANGED')
        if flags:diffs.append({'key':k,'flags':flags,'old':plain(a) if a else None,'new':plain(b) if b else None})
    admissions=[];token=re.compile(r'(?<![\w\'])\b(sorryAx|sorry|admit|axiom)\b(?![\w\'])')
    for label,data,decls in [('BASE',baseline,old_decls),('HEAD',replay,new_decls)]:
        byfile=defaultdict(list)
        for d in decls:byfile[d['path']].append(d)
        for path,b in data.items():
            for line_no,line in enumerate(mask(b.decode()).splitlines(),1):
                for match in token.finditer(line):
                    ds=[d for d in byfile[path] if d['start']<=line_no<=d['end']];assert len(ds)<=1
                    admissions.append({'revision':label,'path':path,'line':line_no,'token':match.group(1),'declaration':ds[0]['canonical'] if ds else None})
    admission_sets={l:Counter((r['path'],r['declaration'],r['token']) for r in admissions if r['revision']==l) for l in ['BASE','HEAD']}
    save('payload-validation.json',{'intake_sha256':sha((CP/'intake.json').read_bytes()),'files_sha256':sha((CP/'files.json').read_bytes()),'delivery_commit':intake['delivery_commit'],'files_checked':len(checked),'bytes_checked':sum(r['bytes'] for r in files),'owned_snapshots':len(source_paths),'all_file_hashes_sizes_git_blobs_match':True,'all_patch_paths_owned':True,'seven_patch_replay_reproduces_all_snapshots':True})
    save('patch-replay.json',patch_results);save('changed-files.json',changes);save('declaration-diffs.json',diffs)
    save('declarations-base.json',[plain(d) for d in old_decls]);save('declarations-head.json',[plain(d) for d in new_decls])
    save('admissions.json',{'occurrences':admissions,'baseline_counts':dict(Counter(r['token'] for r in admissions if r['revision']=='BASE')),'head_counts':dict(Counter(r['token'] for r in admissions if r['revision']=='HEAD')),'per_declaration_multisets_equal':admission_sets['BASE']==admission_sets['HEAD'],'added':list((admission_sets['HEAD']-admission_sets['BASE']).items()),'removed':list((admission_sets['BASE']-admission_sets['HEAD']).items())})
    summary={'changed_files':len(changes),'changed_by_role':dict(Counter(r['role'] for r in changes)),
      'declaration_diff_flags':dict(Counter(f for d in diffs for f in d['flags'])),
      'old_declarations':len(old_decls),'new_declarations':len(new_decls),
      'baseline_owned_lexical_counts':dict(Counter(r['token'] for r in admissions if r['revision']=='BASE')),
      'head_owned_lexical_counts':dict(Counter(r['token'] for r in admissions if r['revision']=='HEAD')),
      'per_declaration_admission_multisets_equal':admission_sets['BASE']==admission_sets['HEAD'],
      'provider_existing_declaration_changes':[d for d in diffs if d['old'] and roles[d['old']['path']]=='PROVIDER_ONLY'],
      'public_header_changes':[d for d in diffs if d['old'] and not d['old']['private'] and 'HEADER_CHANGED' in d['flags']],
      'public_non_theorem_body_changes':[d for d in diffs if d['old'] and not d['old']['private'] and d['old']['kind'] not in ['theorem','lemma'] and 'BODY_CHANGED' in d['flags']],
      'modifier_attribute_changes':[d for d in diffs if 'MODIFIER_ATTRIBUTE_CHANGED' in d['flags']]}
    save('SUMMARY.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if not isinstance(v,list)},indent=2))
    print('PROVIDER_EXISTING_CHANGES',len(summary['provider_existing_declaration_changes']))
    print('PUBLIC_HEADER_CHANGES',len(summary['public_header_changes']))
    print('PUBLIC_NON_THEOREM_BODY_CHANGES',len(summary['public_non_theorem_body_changes']))


if __name__=='__main__':main()
