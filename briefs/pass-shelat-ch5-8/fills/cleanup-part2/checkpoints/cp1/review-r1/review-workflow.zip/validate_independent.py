"""Read-only CP1 evidence validation. Never execute/import received programs."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import lzma
import re
import subprocess
import tarfile

CP = Path(__file__).resolve().parent.parent
P = CP / 'payload'
OUT = Path(__file__).resolve().parent
MAIN = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
ISSUE = MAIN / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1'
BASE = '1aa5506f58f77c215e56d24311ec33bd931cacf1'
E = P / 'evidence/logs'
result = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def load(path):
    return json.loads(path.read_text())


def records(name):
    return [json.loads(line) for line in (E / name).read_text().splitlines() if line]


def git(*args, input=None):
    return subprocess.check_output(['git', '-C', str(MAIN), *args], input=input)


def mask(text):
    out = []; i = depth = 0
    while i < len(text):
        if depth:
            if text.startswith('/-', i): depth += 1; out.extend('  '); i += 2
            elif text.startswith('-/', i): depth -= 1; out.extend('  '); i += 2
            else: out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif text.startswith('/-', i): depth = 1; out.extend('  '); i += 2
        elif text.startswith('--', i):
            j = text.find('\n', i)
            if j < 0: j = len(text)
            out.extend(' ' * (j-i)); i = j
        elif text[i] == '"':
            out.append(' '); i += 1
            while i < len(text):
                c = text[i]; out.append('\n' if c == '\n' else ' '); i += 1
                if c == '\\' and i < len(text): out.append(' '); i += 1
                elif c == '"': break
        else: out.append(text[i]); i += 1
    assert depth == 0
    return ''.join(out)


def imports(raw):
    names = []
    for line in mask(raw.decode()).splitlines():
        line = line.strip()
        if not line or line in ('prelude', 'module'): continue
        m = re.fullmatch(r'(?:public\s+)?import\s+(.+)', line)
        if not m: break
        names.extend(m.group(1).split())
    return names


inventory = load(CP / 'files.json')
for row in inventory:
    raw = (P / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'] and blob(raw) == row['git_blob'], row['path']
result['payload'] = {'files': len(inventory), 'all_sizes_sha256_git_blobs_match_intake': True,
    'report_sha256': sha((P / 'REPORT.md').read_bytes()), 'delivery_commit': load(CP/'intake.json')['delivery_commit']}
owned = (ISSUE/'inputs/owned-files.txt').read_text().splitlines()
providers = set((ISSUE/'inputs/provider-only-files.txt').read_text().splitlines())
consumers = set((ISSUE/'inputs/consumer-files.txt').read_text().splitlines())
assert len(owned) == 221 and len(providers) == 124 and len(consumers) == 97

paths = git('ls-tree', '-r', '--name-only', BASE, 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean').decode().splitlines()
paths = [p for p in paths if p.endswith('.lean')]
batch = git('cat-file', '--batch', input=('\n'.join(BASE+':'+p for p in paths)+'\n').encode())
base = {}; pos = 0
for path in paths:
    end = batch.index(b'\n', pos); header = batch[pos:end].split(); size = int(header[2])
    raw = batch[end+1:end+1+size]; assert blob(raw).encode() == header[0]
    base[path] = raw; pos = end + size + 2
assert pos == len(batch)
versions = [base]; commits = [BASE]; patch_changes = []
for patch in sorted((P/'patches').glob('*.patch')):
    lines = patch.read_bytes().splitlines(keepends=True)
    commit = re.fullmatch(rb'From ([0-9a-f]{40}) Mon Sep 17 00:00:00 2001\n', lines[0]).group(1).decode()
    current = dict(versions[-1]); changed = []; i = 0
    while i < len(lines):
        m = re.fullmatch(rb'diff --git a/(.+) b/(.+)\n', lines[i])
        if not m: i += 1; continue
        assert m[1] == m[2]; path = m[1].decode(); assert path in owned, path
        old = current[path].splitlines(keepends=True); new = []; cursor = 0; i += 1
        index = None
        while i < len(lines) and not lines[i].startswith((b'@@ ', b'diff --git ')):
            mi = re.fullmatch(rb'index ([0-9a-f]+)\.\.([0-9a-f]+) 100644\n', lines[i])
            if mi: index = mi.groups()
            i += 1
        assert index and blob(current[path]).startswith(index[0].decode()), path
        while i < len(lines) and lines[i].startswith(b'@@ '):
            mh = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i]); assert mh
            start = int(mh[1]); oc = int(mh[2] or b'1'); nc = int(mh[4] or b'1')
            target = start-1 if start else 0
            assert target >= cursor; new.extend(old[cursor:target]); cursor = target
            seen_old = seen_new = 0; i += 1
            while seen_old < oc or seen_new < nc:
                line = lines[i]; prefix = line[:1]; content = line[1:]
                assert prefix in (b' ', b'+', b'-'), (path, line[:80])
                if prefix in (b' ', b'-'):
                    assert old[cursor] == content, (patch.name, path, cursor+1)
                    cursor += 1; seen_old += 1
                if prefix in (b' ', b'+'): new.append(content); seen_new += 1
                i += 1
            assert seen_old == oc and seen_new == nc
        new.extend(old[cursor:]); current[path] = b''.join(new)
        assert blob(current[path]).startswith(index[1].decode()), path
        changed.append(path)
    versions.append(current); commits.append(commit); patch_changes.append({'patch':patch.name,'commit':commit,'changed':changed})
head = versions[-1]
assert {str(f.relative_to(P/'src')) for f in (P/'src').rglob('*.lean')} == set(owned)
assert all((P/'src'/path).read_bytes() == head[path] for path in owned)
changed_final = [p for p in owned if base[p] != head[p]]
result['source_reconstruction'] = {'base':BASE,'head':commits[-1],'patches':patch_changes,
    'owned_snapshots':len(owned),'all_snapshots_exact_after_in_memory_patch_application':True,
    'final_changed_files':len(changed_final),'final_changed_providers':sorted(set(changed_final)&providers)}

allrec = []
phase_counts = {}
for f in sorted(E.glob('checks-*.jsonl')):
    rows = records(f.name)
    phase_counts[f.name] = dict(collections.Counter(r['status'] for r in rows))
    for n,r in enumerate(rows,1): r = dict(r); r['_file']=f.name; r['_row']=n; allrec.append(r)
result['record_counts'] = phase_counts
normal = '/root/.elan/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
bad_pass = [r for r in allrec if r['status']=='PASS' and not (r.get('rc')==0 and r.get('parsed_errors')==0 and r.get('object_fresh_nonempty') and r.get('object_sha256'))]
assert not bad_pass
assert all(r['tree']=='/workspace/cp2/src/.lake/cleanup-part2-oleans' and r['cwd']=='/workspace/cp2/src' for r in allrec)
assert all(r['PATH']==normal for r in allrec if r['path_mode']=='ordinary')

base_rows=records('checks-baseline.jsonl'); base_last={r['module']:r for r in base_rows}
assert len(base_last)==1037 and all(r['status']=='PASS' and sha(base[r['module']+'.lean'])==r['source_sha256'] for r in base_last.values())
dev=records('checks-dev.jsonl'); last_dev={r['module']:r for r in dev}
dev_stale=[{'module':m,'status':r['status'],'record_sha':r['source_sha256'],'head_sha':sha(head[m+'.lean'])}
           for m,r in last_dev.items() if m+'.lean' in head and (r['status']!='PASS' or r['source_sha256']!=sha(head[m+'.lean']))]
assert not dev_stale
failed_log_lost=[]
for r in dev:
    if r['status']!='FAIL': continue
    log=P/r['log'].removeprefix('/workspace/cp2/')
    text=log.read_text(); m=re.search(r'^START (.+)$',text,re.M)
    if not m or m[1]!=r['start']:
        failed_log_lost.append({'module':r['module'],'failed_start':r['start'],'current_log_start':m[1] if m else None,'log':str(log.relative_to(P))})

timed=[r for r in allrec if 'start' in r]
timed.sort(key=lambda r:r['start'])
produced={}; prereq_issues=[]; last_products={}
for r in timed:
    for d in r['direct_prerequisites']:
        name=d['module']
        key=name.replace('.','/')
        if name.startswith('PFR.'): key='.lake/packages/PFR/'+key
        if not (name.startswith('TCSlib.') or name.startswith('PFR.')): continue
        prior=produced.get(key)
        if prior is None or prior.get('object_sha256')!=d.get('sha256'):
            prereq_issues.append({'file':r['_file'],'row':r['_row'],'module':r['module'],'dependency':name,
                'observed':d.get('sha256'),'prior':prior.get('object_sha256') if prior else None})
    if r['status']=='PASS': produced[r['module']]=r; last_products[r['module']]=r
final_product_stale=[]
for m,r in last_products.items():
    if m+'.lean' not in head: continue
    if r['source_sha256']!=sha(head[m+'.lean']): final_product_stale.append({'module':m,'source_sha':r['source_sha256'],'head_sha':sha(head[m+'.lean'])})
result['replay']={'baseline_final_unique_passes':len(base_last),'dev_records':len(dev),'dev_unique_modules':len(last_dev),
    'dev_fail_records':sum(r['status']=='FAIL' for r in dev),'latest_dev_source_mismatches':dev_stale,
    'all_pass_records_internal_fields_consistent':True,'one_tree_and_ordinary_path_fields_consistent':True,
    'failed_dev_logs_overwritten':failed_log_lost,'chronological_direct_prerequisite_digest_issues':prereq_issues,
    'latest_recorded_local_products':sum(m+'.lean' in head for m in last_products),'latest_local_product_source_mismatches':final_product_stale}

def ax_table(phase):
    out={}; counts=collections.Counter()
    with lzma.open(P/'evidence/census'/phase/'axioms.tsv.xz','rt') as f:
        for line in f:
            tag,home,name,axioms=line.rstrip('\n').split('\t'); assert tag=='AXIOMS'
            key=(home,name); counts[key]+=1
            out[key]=tuple(sorted(x.strip() for x in axioms.strip('[]').split(',') if x.strip()))
    return out,counts

ownedmods={p.removesuffix('.lean').replace('/','.') for p in owned}
phase_data={}
for phase in ['baseline','j2']:
    ax,axcounts=ax_table(phase); names={}; ownnames={}; total=0
    with lzma.open(P/'evidence/census'/phase/'names.tsv.xz','rt') as f:
        for line in f:
            tag,name,kind,status,home,flags=line.rstrip('\n').split('\t'); assert tag=='NAME'; total+=1
            assert name not in names; names[name]=(home,kind,status,flags)
            if home in ownedmods: ownnames[(home,name)]=(kind,status,flags)
    assert set(ax)==set(ownnames) and all(c==1 for c in axcounts.values())
    pairs=[tuple(line.split('\t')[1:]) for line in (P/'evidence/census'/phase/'c3.tsv').read_text().splitlines() if line]
    assert len(pairs)==len(set(pairs)) and all((r[0],r[1]) in ax for r in pairs)
    assert all(names[r[2]][0]==r[3] and names[r[4]][0]==r[5] and r[0]!=r[5] for r in pairs)
    phase_data[phase]=(ax,names,pairs)
    result.setdefault('census',{})[phase]={'name_rows':total,'owned_axiom_identities':len(ax),'owned_root_set_equals_name_table':True,
        'axiom_duplicate_rows':sum(c-1 for c in axcounts.values()),'sorryAx':sorted(':'.join(k) for k,v in ax.items() if 'sorryAx' in v),
        'c3_pairs':len(pairs),'c3_consumer_pairs':sum(r[0].replace('.','/')+'.lean' in consumers for r in pairs),
        'c3_provider_pairs':sum(r[0].replace('.','/')+'.lean' in providers for r in pairs)}
bax,bnames,bpairs=phase_data['baseline']; hax,hnames,hpairs=phase_data['j2']
result['axiom_comparison']={'only_base':len(set(bax)-set(hax)),'only_head':len(set(hax)-set(bax)),
    'changed':[{'home':k[0],'name':k[1],'base':bax[k],'head':hax[k]} for k in sorted(set(bax)&set(hax)) if bax[k]!=hax[k]],
    'sorryAx_identity_sets_equal':{k for k,v in bax.items() if 'sorryAx' in v}=={k for k,v in hax.items() if 'sorryAx' in v},
    'c3_removed':len(set(bpairs)-set(hpairs)),'c3_added':len(set(hpairs)-set(bpairs))}

probe_counts={}
for phase,source in [('baseline',base),('j2',head)]:
    meta=load(E/('seal-'+phase+'.json')); chk={r['module']:r for r in records('checks-seal-'+phase+'.jsonl')}
    tables={}; counts={}; exclusions=collections.Counter(); member_extra=[]
    with tarfile.open(P/'evidence/probes'/('seal-'+phase+'-probes.tar.xz'),'r:xz') as tf:
        for member in tf.getmembers():
            if not member.isfile(): continue
            raw=tf.extractfile(member).read()
            if not member.name.startswith('seal/'+phase+'/'):
                member_extra.append({'path':member.name,'bytes':len(raw),'sha256':sha(raw)})
                continue
            key=member.name.removeprefix('seal/'+phase+'/').removesuffix('.lean')
            record=chk['.lake/cleanup-part2-probes/seal/'+phase+'/'+key]
            assert sha(raw)==record['source_sha256']
            text=raw.decode(); match=re.search(r'(?ms)^-- CP2 WHOLE-FILE SEAL.*?^-- CP2 END SEAL\n\n',text); assert match
            tail='\nrun_cmd Lean.logInfo "CP2-EOF"\n'; assert text.endswith(tail)
            restored=(text[:match.start()]+text[match.end():])[:-len(tail)].encode()
            assert restored==source[key+'.lean'],key
            assert not mask(text[:match.start()]).strip().splitlines()[-1].strip().startswith(('namespace','open','set_option'))
            requests=int(re.search(r': (\d+) requests',match[0])[1]); assert requests==meta[key]['requests']
            logpath=P/record['log'].removeprefix('/workspace/cp2/')
            log=logpath.read_text()
            chunks=[tuple(map(int,m)) for m in re.findall(r'CP2-SEAL chunk=(\d+) requested=(\d+) active=(\d+) already=(\d+)',log)]
            assert [c[0] for c in chunks]==list(range(len(chunks)))
            assert sum(c[1] for c in chunks)==requests and all(c[1]==c[2]+c[3] for c in chunks)
            assert sum(c[2] for c in chunks)==meta[key]['active'] and sum(c[3] for c in chunks)==meta[key]['already_irreducible']
            assert 'CP2-EOF' in log and not re.search(r'CP2-SEAL (?:missing|no home|wrong home|wrong kind|not installed)',log)
            assert meta[key]['valid'] and not meta[key]['harness_errors']
            if record['status']=='PASS': assert meta[key]['error_diagnostics']==0
            else: assert meta[key]['error_diagnostics']>0
            counts[key]=requests
            if phase=='j2':
                comment=re.search(r'^-- CP2 notation left unsealed.*$',text,re.M)
                if comment:
                    for n in ['Complexity.PolyExpr.eval','Complexity.PolyExpr.eval.match_1','Complexity.PolyExpr.eval._sunfold']:
                        if re.search(re.escape(n)+r'(?:,|$)',comment[0]): exclusions[n]+=1
        assert set(counts)==set(meta) and len(counts)==98
    probe_counts[phase]={'probes':len(counts),'source_snapshots_exact':True,'source_sha_matches_check_records':True,
        'chunks_status_counts_eof_checked':True,'requests':sum(counts.values()),'active':sum(v['active'] for v in meta.values()),
        'already':sum(v['already_irreducible'] for v in meta.values()),'diagnostics':sum(v['error_diagnostics'] for v in meta.values()),
        'module_local_failure_keys':sum(len(v['failing_declarations']) for v in meta.values()),'extras':member_extra,'exact_notation_omission_counts':dict(exclusions)}
result['seal_probe_validation']=probe_counts

base_probe=(P/'evidence/probes/BaseCensus.source.txt').read_bytes()
with tarfile.open(P/'evidence/probes/seal-j2-probes.tar.xz','r:xz') as tf:
    j2_probe=tf.extractfile('census/J2Census.lean').read()
assert j2_probe==base_probe.replace(b'/workspace/cp2/evidence/census/baseline',b'/workspace/cp2/evidence/census/j2')
assert sha(j2_probe)==records('checks-census-j2.jsonl')[0]['source_sha256']
assert (P/'evidence/tools/lean/CensusCore.lean.txt').read_bytes() in j2_probe
assert (P/'evidence/tools/lean/NameDump.lean.txt').read_bytes() in j2_probe
result['census_probe_identity']={'j2_probe_archive_path':'seal-j2-probes.tar.xz:census/J2Census.lean',
    'j2_sha256':sha(j2_probe),'j2_matches_native_record':True,'base_to_head_only_output_directory_change':True,
    'delivered_census_core_and_namedump_exact_substrings':True}

closure_report={}
decoder=json.JSONDecoder()
def printed_components(name):
    components=[];pos=0
    while pos<len(name):
        if name[pos]=='«':
            end=name.index('»',pos+1);components.append(('s',name[pos+1:end]));pos=end+1
        else:
            end=name.find('.',pos)
            if end<0:end=len(name)
            value=name[pos:end];components.append(('n' if value.isdecimal() else 's',value));pos=end
        if pos<len(name):assert name[pos]=='.';pos+=1
    return components

def request_name(text, pos=0):
    while text[pos].isspace(): pos+=1
    if text.startswith('Lean.Name.anonymous',pos): return [],pos+len('Lean.Name.anonymous')
    assert text[pos]=='('; pos+=1
    op=re.match(r'Lean.Name.(str|num)\s+',text[pos:]); assert op
    pos+=op.end(); parent,pos=request_name(text,pos)
    while text[pos].isspace(): pos+=1
    if op[1]=='str': value,length=decoder.raw_decode(text[pos:]);pos+=length;kind='s'
    else:
        token=re.match(r'[0-9]+',text[pos:]);assert token;value=int(token[0]);pos+=token.end();kind='n'
    assert text[pos]==')'
    return parent+[(kind,str(value))],pos+1

for phase,source,names in [('baseline',base,bnames),('j2',head,hnames)]:
    graph={path.removesuffix('.lean').replace('/','.'):imports(raw) for path,raw in source.items()}
    rows_by_aud=collections.defaultdict(dict); deps_by_aud={}; printed_counts={}
    with lzma.open(P/'evidence/census'/phase/'closure.tsv.xz','rt') as f:
        for line in f:
            fs=line.rstrip('\n').split('\t')
            if fs[0]=='CLOSURE':
                _,aud,name,home,kind,status,comp=fs
                assert name not in rows_by_aud[aud]
                components=[tuple(x.split(':',1)) for x in comp[1:-1].split(', ')] if comp!='[]' else []
                assert printed_components(name)==components,(name,components)
                rows_by_aud[aud][name]=(home,kind,status,components)
                nh,nk,ns,nf=names[name]
                assert (home,kind.split('/')[0],status)==(nh,nk,ns)
                assert 'instance,' not in nf
                assert status!='Lean.ReducibilityStatus.reducible' or 'matcher,' in nf
            elif fs[0]=='CLOSURE-DEPS':
                deps_by_aud[fs[1]]=set(fs[2][1:-1].split(', ')) if fs[2]!='[]' else set()
            elif fs[0]=='CLOSURE-COUNT': printed_counts[fs[1]]=int(fs[2])
            else: raise AssertionError(fs[0])
    candidates_by_home=collections.defaultdict(set)
    for name,(home,kind,status,flags) in names.items():
        if home.startswith('TCSlib.') and kind=='def' and 'instance,' not in flags and (status!='Lean.ReducibilityStatus.reducible' or 'matcher,' in flags):
            candidates_by_home[home].add(name)
    for aud in ownedmods:
        seen=set();todo=list(graph[aud])
        while todo:
            name=todo.pop()
            if name in seen: continue
            seen.add(name);todo.extend(graph.get(name,[]))
        deps={n for n in seen if n.startswith('TCSlib.') and n!=aud}
        assert deps_by_aud[aud]==deps,aud
        expected=set().union(*(candidates_by_home[d] for d in deps)) if deps else set()
        assert set(rows_by_aud[aud])==expected,aud
        assert printed_counts[aud]==len(expected)
    meta=load(E/('seal-'+phase+'.json'))
    all_req=0
    with tarfile.open(P/'evidence/probes'/('seal-'+phase+'-probes.tar.xz'),'r:xz') as tf:
        for member in tf.getmembers():
            if not member.isfile() or not member.name.startswith('seal/'+phase+'/'):continue
            key=member.name.removeprefix('seal/'+phase+'/').removesuffix('.lean');aud=key.replace('/','.')
            text=tf.extractfile(member).read().decode();start=text.index('-- CP2 WHOLE-FILE SEAL')
            assert all(re.fullmatch(r'(?:public\s+)?import\s+.+',line.strip()) or line.strip() in ('prelude','module')
                for line in mask(text[:start]).splitlines() if line.strip())
            found={}
            for line in text.splitlines():
                line=line.strip()
                if not line.startswith('((Lean.Name.'):continue
                tail=re.search(r', ("(?:\\.|[^"\\])*"), ("(?:\\.|[^"\\])*")\)[,\]]?$',line);assert tail,line[-300:]
                expr=line[1:tail.start()];components,end=request_name(expr);assert end==len(expr)
                home=json.loads(tail[1]);kind=json.loads(tail[2])
                compkey=tuple(components);assert compkey not in found;found[compkey]=(home,kind)
            excluded=set() if phase=='baseline' else {'Complexity.PolyExpr.eval','Complexity.PolyExpr.eval.match_1','Complexity.PolyExpr.eval._sunfold'}
            expected={tuple(v[3]):(v[0],v[1]) for n,v in rows_by_aud[aud].items() if n not in excluded}
            assert found==expected,key
            all_req+=len(found)
    closure_report[phase]={'owned_modules':len(ownedmods),'all_source_import_closures_match':True,
        'all_candidates_exact_noninstance_nonreducible_defs_plus_matchers':True,
        'all_constant_AST_components_home_kind_match_closure':True,'requested':all_req,
        'seal_immediately_after_header_only':True}
result['closure_and_constant_AST_validation']=closure_report
overlaps=[]
for a,b in zip(timed,timed[1:]):
    if b['start']<a['end']:overlaps.append({'left':(a['_file'],a['_row']),'right':(b['_file'],b['_row'])})
result['replay']['overlapping_recorded_native_intervals']=overlaps

work=load(ISSUE/'inputs/observations/canonical-work-units.json')
workkeys={(r['path'],r['canonical']) for r in work}
failkeys=set()
for path,row in load(E/'seal-j2.json').items():
    ns=[];contexts={}
    for number,line in enumerate(mask(head[path+'.lean'].decode()).splitlines(),1):
        m=re.match(r'^namespace\s+(\S+)',line)
        if m:ns.append(('ns',m[1]))
        elif re.match(r'^(?:noncomputable\s+)?section\b',line):ns.append(('section',''))
        elif re.match(r'^end\b',line) and ns:ns.pop()
        contexts[number]='.'.join(n for tag,n in ns if tag=='ns')
    for d in row['diagnostics']:
        token=d['decl'];prefix=contexts[d['decl_line_in_source']]
        full=token.removeprefix('_root_.') if token.startswith('_root_.') else prefix+'.'+token if prefix else token
        failkeys.add((path+'.lean',full))
matched=workkeys&failkeys
result['work_key_join_provisional']={'issued_keys':len(workkeys),'source_namespace_join_failed_keys':len(matched),
    'failing_blocks_outside_work_keys':len(failkeys-workkeys),'warning':'Independent lexical namespace join only; no worker per-key ledger supplied; moves/coalescing need explicit mappings',
    'notation_observation_keys':[{'path':r['path'],'canonical':r['canonical'],'still_failed_under_worker_variant':(r['path'],r['canonical']) in failkeys}
        for r in work if any(o.get('classification')=='RECORDED_EXACT_NOTATION_EXCEPTION' for o in r['observations'])]}

latest_log_checks=0
for latest in [base_last,last_dev]:
    for r in latest.values():
        log=P/r['log'].removeprefix('/workspace/cp2/')
        text=log.read_text()
        assert ('START '+r['start']+'\n') in text
        assert ('CMD '+r['command']+'\n') in text
        assert ('SOURCE '+r['source']+' sha256='+r['source_sha256']+'\n') in text
        assert ('END '+r['end']+' RC '+str(r['rc'])+' ') in text
        latest_log_checks+=1
result['replay']['latest_baseline_and_dev_log_headers_end_rc_reconciled']=latest_log_checks
checks={}
pattern=re.compile(r"'([^'\n]+)' depends on axioms: \[([^\]]*)\]|'([^'\n]+)' does not depend on any axioms",re.S)
for phase in ['baseline','dev']:
    text=(E/phase/'modules/audits/pass-shelat/Checks.log').read_text()
    checks[phase]=collections.Counter((m[1] or m[3],tuple(sorted(a.strip() for a in (m[2] or '').split(',') if a.strip()))) for m in pattern.finditer(text))
assert checks['baseline']==checks['dev']
result['aggregate_checks_axioms']={'rows':sum(checks['dev'].values()),'names':len({k[0] for k in checks['dev']}),
    'raw_multisets_equal':True,'sorryAx_rows':sum(c for k,c in checks['dev'].items() if 'sorryAx' in k[1])}
envrecords={r['module']:r for r in records('checks-checkpoint0-env.jsonl')}
pfrrows=load(ISSUE/'external-bootstrap-r1/ordered-modules.json')
for row in pfrrows:
    key='.lake/packages/PFR/'+row['package_relative_source'].removesuffix('.lean')
    rec=envrecords[key]
    assert rec['source_sha256']==row['source_sha256'] and rec['status']=='PASS'
    assert rec['path_mode']=='PFR-adapter (31 PFR checks only)'
result['PFR_record_source_binding']={'pfr_modules':len(pfrrows),'all_source_hashes_match_frozen_issue':True,'recorded_PASS_only':True,
    'reviewer_native_execution':False}

instances_by_home=collections.defaultdict(list)
for name,(home,kind,status,flags) in hnames.items():
    if home.startswith('TCSlib.') and kind=='def' and 'instance,' in flags:
        instances_by_home[home].append((name,status))
instance_pairs=[]
for aud in load(E/'seal-j2.json'):
    aud=aud.replace('/','.')
    for home in deps_by_aud[aud]:
        instance_pairs.extend((aud,name,home,status) for name,status in instances_by_home[home])
nonred=[r for r in instance_pairs if r[3]!='Lean.ReducibilityStatus.reducible']
instance_summary={'status_pair_counts':dict(collections.Counter(r[3] for r in instance_pairs)),
    'nonreducible_pairs':len(nonred),'unique_nonreducible_instances':len({r[1] for r in nonred}),
    'affected_audits':len({r[0] for r in nonred}),
    'classification':'Inherited reviewed methodology coverage limit; not a newly introduced CP1 filter deviation',
    'ordinary_data_examples':['Turing.instInhabitedCfg','BoolCircuit.instFintypeGateKind','Complexity.instDecidableEqPolyExpr'],
    'all_nonreducible_pairs':nonred}
(OUT/'instance-exclusions.json').write_text(json.dumps(instance_summary,indent=2)+'\n')
result['inherited_instance_filter_limit']={k:v for k,v in instance_summary.items() if k!='all_nonreducible_pairs'}

result['limits']=['No incoming program imported/executed','No native/Lean/cache/build/apps/Git mutation',
    'Records and supplied object hashes reconciled as data; objects not delivered or independently checked natively',
    'No acceptance or full Rule10 clearance; source-freeze semantic review assigned separately']
(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['source_reconstruction','record_counts','replay','census']},indent=2))
print('chronological prerequisite issues',len(prereq_issues),'latest product source mismatches',len(final_product_stale))
