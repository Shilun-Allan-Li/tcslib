#!/usr/bin/env python3
"""Maintainer-owned read-only CP1 API source/data checks; never import worker programs."""
from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[5]
# The review directory is <repo>/.lake/ps-maintainer/cleanup-review-2026-11-08/cp1/review-api.
assert (ROOT/'policy.md').is_file(),ROOT
P=ROOT/'.lake/ps-maintainer/cleanup-review-2026-11-08/cp1/payload'
OUT=Path(__file__).resolve().parent
A='1aa5506f58f77c215e56d24311ec33bd931cacf1'
M=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
C=M/'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(rel):return (P/'src'/rel).read_text()
cache={}
def base(rel):
 if rel not in cache:
  cache[rel]=subprocess.run(['git','show',A+':'+rel],cwd=ROOT,check=True,capture_output=True).stdout.decode()
 return cache[rel]
def decl(text,name):
 pat=r'(?m)^(?:(?:private|noncomputable|protected)\s+)*(?:theorem|lemma|def)\s+'+re.escape(name)+r'\b'
 m=re.search(pat,text);assert m,name
 tail=text[m.start():]
 # Header/body delimiters, unlike the initial ad hoc check, handle structure "where".
 cut=re.search(r':=|\bwhere\b',tail);assert cut,name
 h=tail[:cut.start()].rstrip()
 end=re.search(r'\n\s*\n(?=/--|/-!|(?:private |noncomputable )?(?:theorem|lemma|def)\b|end\b)',tail)
 body=tail[:end.start() if end else len(tail)].rstrip()
 return {'line':text.count('\n',0,m.start())+1,'header':h,'body':body}
checks=[]
def check(k,b,detail=None):
 checks.append({'id':k,'passed':bool(b),'detail':detail});assert b,k
rep=(P/'REPORT.md').read_bytes()
check('REPORT_SHA',sha(rep)=='9268a2db072f183db8a1b9eaca67dfaa6485f7eadeac212ceb49e78a33c62119')
patches=sorted((P/'patches').glob('*.patch'))
check('SEVEN_PATCH_FILES',len(patches)==7)
last=patches[-1].read_text().splitlines()[0].split()[1]
check('PATCH_REPORTED_HEAD',last=='51c245389deed467d75bcb1625627d8a4f97c4f8')
items=[('TCSlib/Cryptography/NumberTheory/Units.lean','units_val_mem'),('TCSlib/Cryptography/NumberTheory/Primality.lean','two_mul_card_le_of_ne_top'),('TCSlib/Cryptography/NumberTheory/Primality.lean','powOneSubgroup'),('TCSlib/Cryptography/NumberTheory/Primality.lean','mem_powOneSubgroup'),('TCSlib/Cryptography/NumberTheory/QuadraticResidues.lean','card_QR_prime'),('TCSlib/Cryptography/NumberTheory/QuadraticResidues.lean','sq_pow_div_four_succ'),('TCSlib/Cryptography/Candidates/Factoring.lean','fmultNat_eq_mul_prime'),('TCSlib/Cryptography/Asymptotic/GGMReduction.lean','stateLoopFun'),('TCSlib/Cryptography/Asymptotic/GGMReduction.lean','stateLoopFun_eval'),('TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/Efficiency.lean','stateFind'),('TCSlib/Cryptography/ZeroKnowledge/EncodingMachines.lean','polyTimeComputable_stateFind'),('TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/ColZKMachine.lean','polyTimeComputable_next')]
header_checks=[]
for rel,n in items:
 old,new=decl(base(rel),n),decl(read(rel),n)
 # Only trailing whitespace at the :=/where delimiter is ignored.
 check('HEADER_'+n,old['header']==new['header'],{'path':rel,'base_line':old['line'],'cp1_line':new['line']})
 header_checks.append({'path':rel,'name':n,'base_line':old['line'],'cp1_line':new['line'],'header_sha256':sha(new['header'].encode())})
 if n=='stateLoopFun':check('STATE_LOOP_DATA_BODY_EXACT',old['body']==new['body'])
old=decl(base('TCSlib/Cryptography/Asymptotic/HardCoreGL.lean'),'blocksEquivX')
new=decl(read('TCSlib/Cryptography/Asymptotic/Adversary.lean'),'blocksEquivX')
check('GENERIC_BLOCKS_BODY_EXACT',old['body']==new['body'])
old=decl(base('TCSlib/Cryptography/Candidates/Rabin.lean'),'rabin_uexp_le')['header']
new=decl(read('TCSlib/Cryptography/Asymptotic/Sampling.lean'),'uexp_le_of_statClose')['header']
old=old.replace('private theorem rabin_uexp_le','theorem uexp_le_of_statClose',1)
check('AVERAGE_PROMOTION_EXACT_TYPE',re.sub(r'\s+',' ',old)==re.sub(r'\s+',' ',new))
old=decl(base('TCSlib/Cryptography/Asymptotic/HardCoreLoops.lean'),'polyTimeComputable_stateIterate')['header']
new=decl(read('TCSlib/Complexity/Randomized/Repetition.lean'),'StateLoop.polyTimeComputable_stateIterate')['header']
# Old file opens Complexity.StateLoop; compare the expressly changed full-name/qualification spelling.
old=old.replace('theorem polyTimeComputable_stateIterate','theorem StateLoop.polyTimeComputable_stateIterate',1).replace('((gstep step B)','((StateLoop.gstep step B)')
check('FIXED_ROUND_TYPE_NAMESPACE_ONLY',re.sub(r'\s+',' ',old)==re.sub(r'\s+',' ',new))
rep=read('TCSlib/Complexity/Randomized/Repetition.lean')
check('FIXED_ROUND_AFTER_ITERATE',rep.index('theorem polyTimeComputable_iterate ' ) < rep.index('theorem StateLoop.polyTimeComputable_stateIterate'))
# Small independent arithmetic orientation sanity check, not a Lean proof/equivalence test.
cases=0
for q in range(6):
 for ell in range(6):
  for i in range(q):
   for j in range(ell):
    z=j+ell*i
    assert z<q*ell and z//ell==i and z%ell==j
    cases+=1
check('FINITE_BLOCK_INDEX_SANITY',True,{'q_ell_range':[0,5],'valid_index_cases':cases,'zero_domains_included':True})
windows=0
for L in range(10):
 tape=list(range(L))
 for a in range(L+1):
  for k in range(L-a+1):
   assert tape[a:][:k]==[tape[a+i] for i in range(k)]
   windows+=1
check('FINITE_WINDOW_SANITY',True,{'L_range':[0,9],'cases':windows,'k_zero_and_empty_tape_included':True})
# Only static import reachability for requested owner routes. Non-payload modules come from ancestor.
imports={};observed={}
def src_module(m):
 rel=m.replace('.','/')+'.lean'
 if (P/'src'/rel).is_file():t=read(rel);origin='payload'
 else:t=base(rel);origin='ancestor'
 observed[m]={'origin':origin,'source_sha256':sha(t.encode())}
 return t
def deps(m):
 if m not in imports:
  t=src_module(m)
  imports[m]=[v for line in t.splitlines() if line.startswith('import ') for v in line[7:].split() if v.startswith('TCSlib.')]
 return imports[m]
def reach(m,stack=()):
 assert m not in stack,stack+(m,)
 result={m}
 for d in deps(m):result|=reach(d,stack+(m,))
 return result
for owner in ['TCSlib.Cryptography.Asymptotic.Adversary','TCSlib.Complexity.Randomized.Repetition','TCSlib.Cryptography.ZeroKnowledge.ThreeColoring.SimulatorMachine']:
 closure=reach(owner)
 check('ACYCLIC_'+owner,True,{'closure_count':len(closure),'module_set':sorted(closure)})
sim='TCSlib.Cryptography.ZeroKnowledge.ThreeColoring.SimulatorMachine'
col='TCSlib.Cryptography.ZeroKnowledge.ThreeColoring.ColZKMachine'
check('NO_SIMULATOR_TO_COLZK_IMPORT',col not in reach(sim))
check('COLZK_IMPORTS_SIMULATOR',sim in deps(col))
# Explicit API issue witnesses: source positions and exact strings, no supplied helper execution.
issue_refs=[]
for rel in ['TCSlib/Cryptography/Asymptotic/HardCore.lean','TCSlib/Cryptography/Asymptotic/HardCoreLemmas.lean','TCSlib/Cryptography/Asymptotic/HardCoreCollection.lean']:
 for n,line in enumerate(read(rel).splitlines(),1):
  if 'NUPPT.ofPolyTimeUniform_def' in line:issue_refs.append({'path':rel,'line':n,'text':line})
check('RAW_MACHINE_ALIAS_THREE_USES',len(issue_refs)==3,issue_refs)
reviewed=set(rel for rel,_ in items)|{
 'TCSlib/Cryptography/Asymptotic/Adversary.lean','TCSlib/Cryptography/Asymptotic/CollectionsHelpers.lean','TCSlib/Cryptography/Asymptotic/PRF.lean','TCSlib/Cryptography/Asymptotic/Sampling.lean','TCSlib/Cryptography/Asymptotic/HardCoreGL.lean','TCSlib/Cryptography/Asymptotic/HardCoreLoops.lean','TCSlib/Cryptography/Asymptotic/EnsemblesLemmas.lean','TCSlib/Cryptography/Asymptotic/OneWayYao.lean','TCSlib/Cryptography/Asymptotic/MultiMessageLemmas.lean','TCSlib/Cryptography/Candidates/Concrete.lean','TCSlib/Cryptography/Candidates/DiscreteLogHardcore.lean','TCSlib/Cryptography/Candidates/RSA.lean','TCSlib/Cryptography/Candidates/Rabin.lean','TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/ColRepSound.lean','TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/ColZKLemmas.lean','TCSlib/Cryptography/ZeroKnowledge/ThreeColoring/SimulatorMachine.lean','TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/SoundnessRep.lean','TCSlib/Complexity/Randomized/Repetition.lean','TCSlib/Complexity/Randomized/PPT.lean','TCSlib/Complexity/ClassNP/PolyTime.lean','TCSlib/Complexity/TuringMachine/Build/Convention.lean','TCSlib/Complexity/TuringMachine/Build/Wrappers.lean','TCSlib/Complexity/TuringMachine/Encoding.lean','TCSlib/Cryptography/Asymptotic/HardCore.lean','TCSlib/Cryptography/Asymptotic/HardCoreLemmas.lean','TCSlib/Cryptography/Asymptotic/HardCoreCollection.lean'}
inputs={'REPORT.md':{'sha256':sha((P/'REPORT.md').read_bytes()),'bytes':(P/'REPORT.md').stat().st_size},'policy.md':{'sha256':sha((ROOT/'policy.md').read_bytes())}}
for f in ['brief.md','public-exceptions.md']:
 inputs['contract/'+f]={'path':str(C/f),'sha256':sha((C/f).read_bytes())}
for f in patches:inputs['patches/'+f.name]={'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size}
result={'review_kind':'READ_ONLY_API_SOURCE_ANALYSIS_NOT_NATIVE','ancestor':A,'reported_worker_head':last,'inputs':inputs,'checks':checks,'header_comparisons':header_checks,'reviewed_source_fingerprints':{rel:{'sha256':sha((P/'src'/rel).read_bytes()),'bytes':(P/'src'/rel).stat().st_size} for rel in sorted(reviewed)},'static_import_fingerprints':observed,'limits':['No incoming program imported or executed.','No Lean/native/build/cache/app invocation; no Git mutations.','This does not reproduce patches, validate all payload hashes, prove native success or cover every declaration.','Header checks concern the explicit targets listed; source inspection includes the reported line ranges, not full security proof audits.','Finite arithmetic checks are independent sanity tests, not formal theorem checks.']}
(OUT/'validation.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':all(c['passed'] for c in checks),'reviewed_source_fingerprints':len(reviewed),'raw_machine_alias_uses':issue_refs,'validation_sha256':sha((OUT/'validation.json').read_bytes())},indent=2))
