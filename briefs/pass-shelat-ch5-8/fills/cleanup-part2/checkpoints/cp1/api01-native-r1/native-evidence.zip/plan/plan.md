# API-01 native-check plan (read only)

**Planned run: compile the full 101-module local import closure into one fresh, empty TCSlib olean tree.** Reuse/copy no TCSlib object, join no trees, and leave the prior S2 baseline untouched. This file prepares a root-coordinated serial run; no native check has been executed by this reviewer.

Source checkout: `/Users/seyoonr/.codex/worktrees/ps-gate08-repair/tcslib-pass-shelat-ch2-4` at `b1fe3c86bb8c61f1056ffe51769920f2a4a4f00d` plus the three API-01 consumer proposals and deletion of the unused new machine alias. The three current consumer SHA256 values match the exact proposed-result hashes. The PPT source contains no `ofPolyTimeUniform_def`. All 101 current source hashes and direct local/external import edges are pinned in `modules.json`.

## Operative files

- `order.txt`: **101** dependency-first repo-relative module paths without `.lean`. SHA256 `4bbafbc40e21011226e25f13d3441704307e2b28aa9246275a4dc31a1778d4a2`.
- `modules.json`: exact rows `{module, source_sha256, local_imports, external_imports}`, in the same order. SHA256 `9061f8223493ff47210cfaf835799a4b803e0550041654857fd620a180fb5384`.
- `mathlib-roots.txt`: **66** distinct direct Mathlib roots needed by the local closure.
- `external-objects.json`: source/import/object-presence records for the required package closure, ending at installed core object leaves.
- `plan.json`: counts, source/evidence/tool pins, run boundaries and limits.
- `optional-baseline-analysis.json`: provenance comparison only; **not** the operative run order or a permission to copy/reuse objects.

The four edited targets occur at positions **20 PPT**, **93 HardCoreLemmas**, **99 HardCoreCollection**, and **101 HardCore**. The other **97** modules are their local prerequisites. The computed union includes only modules reachable by actual current import headers; dependencies precede importers. This is the minimal local import union for these targets, not all CP1 affected/downstream modules or root/Checks.

## Root-run procedure

1. Revalidate all current `modules.json` source hashes, checkout head, package/toolchain pins and the reviewed checker hash. Ensure the chosen new TCSlib output tree is empty. Suggested path: `/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/cleanup-review-2026-11-08/cp1/native-api01-r1/oleans`. Root selects/owns this directory; this plan created no object tree.
2. Use ordinary PATH with the pinned Lean 4.25.0 toolchain. Set `TCSLIB_OLEANS` to the fresh tree explicitly and run `scripts/lean_check_tree.sh` **serially** on every line of `order.txt`, retaining per-module source/hash/start/end/return-code/log/fresh-object evidence. Stop at a failed prerequisite; a target with missing prerequisites is not a valid target check.
3. Require rc0, no error diagnostics and a newly produced nonempty object for every attempted successful module. Revalidate source bytes after each run. Preserve failures and check source/prerequisite causes before deciding whether a repair is needed.
4. Summarize the 101-module run as an API-01 local/native check only. It does not substitute for CP1's remaining ledger, full affected/downstream/root/Checks replay, fresh seals/C3/controls, admission/axiom checks or final review.

**Runner caution:** current `.lake/ps-maintainer/gate06/s2_native.py:20` hardcodes the old `oleans-s2-final` tree. Do not invoke it unchanged: it would overwrite the baseline. The root will author its fresh serial checker; `scripts/lean_check_tree.sh` already supports `TCSLIB_OLEANS`. The source checkout's `.lake/build/lib/lean` was absent during this inspection; keep the runtime classpath free of an older TCSlib object tree.

## External products

All **66** direct external imports are Mathlib modules. Recursively following package-source import headers requires **2,066 package modules** and reaches **163 installed core object leaves**; every corresponding required object exists and is nonempty in the current checker-visible package/toolchain locations. Package counts: `{"LeanSearchClient": 4, "Qq": 14, "aesop": 129, "batteries": 83, "importGraph": 3, "mathlib": 1814, "plausible": 11, "proofwidgets": 8}`. No required external object was missing in this static inspection.

**PFR and LeanAPAP are not imported by this closure**, directly or transitively through the package graph. Their absent object trees, and the absent doc-generation-only packages listed in root preflight, do not require bootstrap or cache work for this particular check. Use ordinary PATH throughout; no PFR wrapper is involved. This is an object-availability observation, not a native ABI/binary import-table validation or a cold package rebuild claim.

Root preflight is pinned at SHA256 `454cd605e588f183f7387e4ebbb52bead48fc41dccf5bc3dd9e83440c8b06b7e`. Its resource/process/package-pin results are existing root evidence; this reviewer did not rerun those commands.

## Optional S2-baseline analysis (not planned reuse)

The old same-chat S2 tree's **101** relevant object hashes still match the recorded r2 provenance rows, supplemented for six rows by the earlier S2 copied-tree record plus its exact source Git pin. No old object was copied or modified here. Current raw source comparison yields **48 changed source modules**, **36 unchanged-source modules with a changed local prerequisite**, and **17 unchanged-source modules with recursively unchanged local prerequisites**. Thus a provenance-conditional incremental plan would rebuild 84; the chosen operative plan deliberately cold-compiles all 101 in a separate empty tree.

The 17/84 classification concerns local dependencies and the recorded pinned external environment. It is not an independent assertion that old binary interfaces remain valid under changed external products, and it is not used to omit any of the 101 checks. Both the source/object provenance JSON and the S2 copy record are hash-pinned in `plan.json`.

## Verification boundary

Own `python3 -I prepare_plan.py` read source headers, hashes, Git source pins and existing evidence only. The follow-up data checks verified order/row identity, all edges preceding importers, all required external objects nonempty, and the 17/84 optional classification. No received code/helper was imported or executed; no Lean/native/checker process or cache command was run; no Git, library, payload, main-record, exchange or object tree mutation occurred. Only this ignored plan directory was written. Existing API review/proposal artifacts remain unchanged.
