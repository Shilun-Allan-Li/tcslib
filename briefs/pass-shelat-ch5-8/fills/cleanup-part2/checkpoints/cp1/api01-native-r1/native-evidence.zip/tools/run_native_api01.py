"""Own serial, immutable-log native check of the bounded CP1 API follow-up."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

PREP = Path(__file__).resolve().parent
CP = PREP / 'cp1'
PLAN = CP / 'review-api/native-plan'
OUT = CP / 'native-api01-r1'
WORK = Path('/Users/seyoonr/.codex/worktrees/ps-gate08-repair/tcslib-pass-shelat-ch2-4')
TREE = WORK / '.lake/ps-maintainer/cleanup-api01-20261108/oleans'
REVIEW_HEAD = 'b1fe3c86bb8c61f1056ffe51769920f2a4a4f00d'


def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args], text=True).strip()


def processes():
    found = {}
    for name in ['lean', 'lake']:
        result = subprocess.run(['pgrep', '-x', name], capture_output=True, text=True)
        assert result.returncode in [0, 1], result.stderr
        found[name] = result.stdout.strip().splitlines()
    return found


def main():
    assert git('branch', '--show-current') == 'cryptography/pass-shelat-cleanup-part2-review'
    assert git('rev-parse', 'HEAD') == REVIEW_HEAD
    assert sha(PLAN / 'order.txt') == '4bbafbc40e21011226e25f13d3441704307e2b28aa9246275a4dc31a1778d4a2'
    assert sha(PLAN / 'modules.json') == '9061f8223493ff47210cfaf835799a4b803e0550041654857fd620a180fb5384'
    modules = json.loads((PLAN / 'modules.json').read_text())
    order = (PLAN / 'order.txt').read_text().splitlines()
    assert len(order) == 101 and order == [row['module'] for row in modules]
    assert len(set(order)) == 101
    for row in modules:
        assert sha(WORK / (row['module'] + '.lean')) == row['source_sha256']
    occupied = processes()
    assert not any(occupied.values()), occupied
    assert not TREE.exists(), 'Use a fresh empty tree; do not overwrite previous objects'
    TREE.mkdir(parents=True)
    logs = OUT / 'evidence/logs'
    logs.mkdir(parents=True, exist_ok=False)
    manifest = json.loads((WORK / 'lake-manifest.json').read_text())
    for pkg in manifest['packages']:
        path = WORK / '.lake/packages' / pkg['name']
        if path.exists():
            def package_git(*args):
                return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
            assert package_git('remote', 'get-url', 'origin') == pkg['url']
            assert package_git('rev-parse', 'HEAD') == pkg['rev']
            assert not package_git('status', '--porcelain'), pkg['name']
    assert (WORK / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.25.0'
    checker = WORK / 'scripts/lean_check_tree.sh'
    checker_sha = sha(checker)
    plan = {
        'kind': 'FULL_101_MODULE_COLD_CLOSURE', 'created_utc': now(),
        'review_head': REVIEW_HEAD, 'worktree': str(WORK), 'tree': str(TREE),
        'order_sha256': sha(PLAN / 'order.txt'), 'modules_sha256': sha(PLAN / 'modules.json'),
        'checker_sha256': checker_sha, 'runner_sha256': sha(Path(__file__)),
        'preflight_sha256': sha(OUT / 'preflight.json'), 'no_object_copy_or_reuse': True,
        'shared_pinned_package_cache': str((WORK / '.lake/packages').resolve()),
        'limits': 'Ordinary unsealed cold prerequisite/consumer check of the four-file API follow-up; not full cleanup acceptance, root/Checks or seal reproduction.',
    }
    (OUT / 'run-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    (OUT / 'runner.pid').write_text(str(os.getpid()) + '\n')
    env = dict(os.environ)
    env['PATH'] = str(Path.home() / '.elan/bin') + ':' + env['PATH']
    env['TCSLIB_OLEANS'] = str(TREE)
    env.pop('LEAN_PATH', None)
    records = {}
    stream = (OUT / 'attempts.jsonl').open('x')

    def check(module, source_sha, local_imports, number, label):
        for name in local_imports:
            assert name in records, ('missing checked prerequisite', module, name)
            assert sha(TREE / (name + '.olean')) == records[name]['object_sha256']
            assert sha(WORK / (name + '.lean')) == records[name]['source_sha256']
        assert sha(checker) == checker_sha
        source = WORK / (module + '.lean')
        assert sha(source) == source_sha
        busy = processes()
        assert not any(busy.values()), ('host occupied before native step', module, busy)
        command = ['/usr/bin/time', '-l', 'bash', 'scripts/lean_check_tree.sh', module]
        path = logs / f'{number:03d}-{label}.attempt01.log'
        start = now()
        t0 = time.monotonic()
        with path.open('xb') as log:
            header = {'event': 'START', 'start_utc': start, 'module': module,
                      'source_sha256': source_sha, 'command': command,
                      'runner_sha256': plan['runner_sha256'], 'checker_sha256': checker_sha,
                      'direct_prerequisites': {name: records[name]['object_sha256'] for name in local_imports}}
            log.write((json.dumps(header) + '\n').encode())
            log.flush()
            process = subprocess.Popen(command, cwd=WORK, env=env, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT)
            (OUT / 'active-native.json').write_text(json.dumps({
                'module': module, 'wrapper_pid': process.pid, 'start_utc': start,
                'log': str(path), 'runner_pid': os.getpid()}, indent=2) + '\n')
            rc = process.wait()
            end = now()
            elapsed = time.monotonic() - t0
            log.write((json.dumps({'event': 'END', 'end_utc': end,
                                   'rc': rc, 'elapsed_seconds': elapsed}) + '\n').encode())
        raw = path.read_text()
        obj = TREE / (module + '.olean')
        errors = len(re.findall(r'\berror(?:\([^)]*\))?:', raw))
        match = re.search(r'^\s*(\d+)\s+maximum resident set size\s*$', raw, re.M)
        nonempty = obj.exists() and obj.stat().st_size > 0
        unchanged = sha(source) == source_sha
        passed = rc == 0 and errors == 0 and nonempty and unchanged
        row = {'module': module, 'source_sha256': source_sha, 'start_utc': start, 'end_utc': end,
               'rc': rc, 'elapsed_seconds': elapsed, 'error_diagnostics': errors,
               'fresh_nonempty_object': nonempty, 'source_unchanged': unchanged,
               'object_sha256': sha(obj) if nonempty else None,
               'direct_prerequisites': header['direct_prerequisites'],
               'max_rss_bytes': int(match[1]) if match else None,
               'log': str(path.relative_to(OUT)), 'log_sha256': sha(path),
               'passed': passed}
        stream.write(json.dumps(row) + '\n')
        stream.flush()
        (OUT / 'active-native.json').unlink()
        print(json.dumps({'checked': number, 'module': module, 'passed': passed,
                          'elapsed_seconds': round(elapsed, 2), 'rc': rc}), flush=True)
        if not passed:
            (OUT / 'STOP.json').write_text(json.dumps(row, indent=2) + '\n')
            raise RuntimeError('Native check failed; preserve this exact attempt and skip dependents')
        records[module] = row

    root = (PLAN / 'mathlib-roots.txt').read_text().splitlines()[0]
    assert root.startswith('Mathlib.')
    probe_module = '.lake/ps-maintainer/cleanup-api01-20261108/CacheProbe'
    probe = WORK / (probe_module + '.lean')
    assert not probe.exists()
    probe.write_text('import ' + root + '\n')
    check(probe_module, sha(probe), [], 0, 'MathlibCacheProbe')
    for number, row in enumerate(modules, start=1):
        check(row['module'], row['source_sha256'], row['local_imports'], number,
              row['module'].replace('/', '_'))
    # Reconcile every product and source, not just the four edited targets.
    for row in modules:
        name = row['module']
        assert sha(WORK / (name + '.lean')) == row['source_sha256']
        assert sha(TREE / (name + '.olean')) == records[name]['object_sha256']
    assert sha(checker) == checker_sha and git('rev-parse', 'HEAD') == REVIEW_HEAD
    stream.close()
    result = {**plan, 'finished_utc': now(), 'checked_local_modules': 101,
              'cache_probe_passed': True, 'all_sources_objects_reconciled': True,
              'all_passed': True, 'attempts_sha256': sha(OUT / 'attempts.jsonl')}
    (OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
