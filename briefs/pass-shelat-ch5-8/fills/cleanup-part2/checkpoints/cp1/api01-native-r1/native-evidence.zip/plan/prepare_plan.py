#!/usr/bin/env python3
"""Own read-only source/hash planning. No Lean, supplied program or cache operation."""
from pathlib import Path
import hashlib,json,re,subprocess,datetime
D=Path(__file__).resolve().parent
W=Path('/Users/seyoonr/.codex/worktrees/ps-gate08-repair/tcslib-pass-shelat-ch2-4')
M=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
R=D.parents[5]
CP=D.parent.parent
B=M/'.lake/ps-maintainer/oleans-s2-final'
P=M/'.lake/ps-maintainer/cleanup-part2-prep/native/r2/provenance.json'
C=M/'briefs/pass-shelat-ch5-8/fills/shared-lemmas/s2/final/maintainer-replay/copied-tree.json'
TC=Path.home()/'.elan/toolchains/leanprover--lean4---v4.25.0'
TARGETS=['TCSlib/Complexity/Randomized/PPT','TCSlib/Cryptography/Asymptotic/HardCoreLemmas','TCSlib/Cryptography/Asymptotic/HardCoreCollection','TCSlib/Cryptography/Asymptotic/HardCore']
sha=lambda b:hashlib.sha256(b).hexdigest()
# Parse only the actual import header, ignoring nested comments and strings in body prose.
def header(raw):
 imports=[];prelude=False;depth=0
 for original in raw.decode().splitlines():
  clean=[];i=0
  while i<len(original):
   if original.startswith('/-',i):depth+=1;i+=2;continue
   if depth and original.startswith('-/',i):depth-=1;i+=2;continue
   if depth:i+=1;continue
   if original.startswith('--',i):break
   clean.append(original[i]);i+=1
  line=''.join(clean).strip()
  if not line:continue
  if line=='prelude':prelude=True;continue
  if line=='module':continue
  match=re.fullmatch(r'(?:(?:public|private|meta)\s+)*import\s+(?:all\s+)?(.+)',line)
  if match:
   modules=match[1].split()
   assert all(re.fullmatch(r"[A-Za-z_][A-Za-z_0-9.']*",m) for m in modules),line
   imports+=modules;continue
  break
 return list(dict.fromkeys(imports)),prelude

head=subprocess.run(['git','rev-parse','HEAD'],cwd=W,capture_output=True,text=True,check=True).stdout.strip()
assert head=='b1fe3c86bb8c61f1056ffe51769920f2a4a4f00d'
rows={};order=[];vis=set()
def visit(m,stack=()):
 assert m not in stack,stack+(m,)
 if m in vis:return
 raw=(W/(m+'.lean')).read_bytes();im,_=header(raw)
 row={'module':m,'source_sha256':sha(raw),'local_imports':[n.replace('.','/') for n in im if n.startswith('TCSlib.')],'external_imports':[n for n in im if not n.startswith('TCSlib.')]}
 rows[m]=row
 for n in row['local_imports']:visit(n,stack+(m,))
 vis.add(m);order.append(m)
for m in TARGETS:visit(m)
assert len(order)==101,len(order)
assert all(order.index(d)<order.index(m) for m in order for d in rows[m]['local_imports'])
assert 'ofPolyTimeUniform_def' not in (W/(TARGETS[0]+'.lean')).read_text()
for stem,module in [('01-hardcore',TARGETS[3]),('02-hardcore-lemmas',TARGETS[1]),('03-hardcore-collection',TARGETS[2])]:
 data=json.loads((D.parent/'fix-proposals'/(stem+'.json')).read_text())
 assert rows[module]['source_sha256']==data['proposed_result_sha256']
# Optional provenance comparison only: no object will be reused or copied in planned run.
prov=json.loads(P.read_text());copy=json.loads(C.read_text());pins={v['module']:v for v in prov['checked_dependencies']};cpins={v['path']:v for v in copy['objects']}
optional=[];safe=set()
for m in order:
 raw=(W/(m+'.lean')).read_bytes();o=B/(m+'.olean');assert o.is_file() and o.stat().st_size
 oh=sha(o.read_bytes());p=pins.get(m)
 if p:
  source_base=p['source_sha256'];obj_expected=p['object_sha256'];origin='r2/provenance.json'
 else:
  old=subprocess.run(['git','show',copy['source_pin']+':'+m+'.lean'],cwd=W,check=True,capture_output=True).stdout
  source_base=sha(old);obj_expected=cpins[m+'.olean']['sha256'];origin='S2 copied-tree.json + exact Git source pin'
 assert oh==obj_expected,m
 source_same=sha(raw)==source_base
 blockers=[n for n in rows[m]['local_imports'] if n not in safe]
 reusable=source_same and not blockers
 if reusable:safe.add(m)
 optional.append({'module':m,'baseline_object_path':str(o),'baseline_object_sha256':oh,'provenance':origin,'baseline_source_sha256':source_base,'current_source_sha256':sha(raw),'source_unchanged':source_same,'prerequisites_unchanged_recursively':not blockers,'non_reusable_direct_local_prerequisites':blockers,'optional_reusable':reusable,'planned_action':'COLD_REBUILD_IN_FRESH_EMPTY_TREE'})
assert len(safe)==17
# All required package import headers recursively, ending at installed core/toolchain imports.
packages=sorted((W/'.lake/packages').iterdir())
object_dirs=[p/'.lake/build/lib/lean' for p in packages if (p/'.lake/build/lib/lean').is_dir()]
roots=sorted({n for m in order for n in rows[m]['external_imports']})
external={};core={};missing=[]
def obj_for(n):
 rel=n.replace('.','/')+'.olean'
 matches=[p/rel for p in object_dirs if (p/rel).is_file()]
 assert len(matches)<=1,(n,matches)
 return matches[0] if matches else None
def walk(n,stack=()):
 assert n not in stack,(n,stack)
 if n in external or n in core:return
 rel=n.replace('.','/')
 if n.split('.')[0] in ['Init','Lean','Std']:
  o=TC/'lib/lean'/(rel+'.olean')
  core[n]={'module':n,'object_path':str(o),'exists_nonempty':o.is_file() and o.stat().st_size>0}
  if not core[n]['exists_nonempty']:missing.append(n)
  return
 choices=[p/(rel+'.lean') for p in packages if (p/(rel+'.lean')).is_file()]
 assert len(choices)==1,(n,choices)
 s=choices[0];raw=s.read_bytes();im,prelude=header(raw);o=obj_for(n)
 external[n]={'module':n,'source_path':str(s),'source_sha256':sha(raw),'direct_imports':im,'object_path':str(o) if o else None,'object_bytes':o.stat().st_size if o else None,'exists_nonempty':bool(o and o.stat().st_size),'package':s.relative_to(W/'.lake/packages').parts[0]}
 if not external[n]['exists_nonempty']:missing.append(n)
 for d in im:walk(d,stack+(n,))
 if not prelude:walk('Init',stack+(n,))
for n in roots:walk(n)
mathlib_roots=[n for n in roots if n.startswith('Mathlib.')]
assert len(mathlib_roots)==len(roots)
assert not any(v['package'] in ['PFR','LeanAPAP'] for v in external.values())
preflight=CP/'native-api01-r1/preflight.json'
files=[P,C,W/'lean-toolchain',W/'lake-manifest.json',W/'scripts/lean_check_tree.sh',R/'.lake/ps-maintainer/gate06/s2_native.py']
if preflight.is_file():files.append(preflight)
inputs={str(p):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files}
fresh=CP/'native-api01-r1/oleans'
result={'status':'PLAN_ONLY_NOT_EXECUTED','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktree':str(W),'head':head,'source_ancestor':prov['source_ancestor'],'targets':TARGETS,'planned_run':'FULL_101_MODULE_COLD_CLOSURE_SINGLE_FRESH_EMPTY_TCSLIB_TREE','suggested_output_tree':str(fresh),'suggested_tree_exists':fresh.exists(),'copy_or_reuse_existing_TCSlib_objects':False,'join_TCSlib_object_trees':False,'old_baseline_tree_read_only':str(B),'counts':{'local_closure':len(order),'planned_cold_checks':len(order),'targets':4,'other_local_prerequisites':len(order)-4,'optional_reusable_with_unchanged_prerequisites':len(safe),'optional_rebuild_count':len(order)-len(safe),'source_changed_from_pinned_baseline':sum(not v['source_unchanged'] for v in optional),'source_unchanged_but_prerequisite_changed':sum(v['source_unchanged'] and not v['optional_reusable'] for v in optional),'direct_mathlib_roots':len(mathlib_roots),'required_package_source_modules':len(external),'required_core_object_leaves':len(core),'missing_required_external_objects':len(missing)},'input_files':inputs,'module_order_file':'order.txt','module_rows_file':'modules.json','direct_mathlib_roots_file':'mathlib-roots.txt','external_object_check_file':'external-objects.json','optional_provenance_file':'optional-baseline-analysis.json','missing_required_external_objects':missing,'PFR_or_LeanAPAP_needed':False,'runner_caution':'s2_native.py hardcodes old S2 output tree at line20: do not use it unchanged. scripts/lean_check_tree.sh supports TCSLIB_OLEANS for the fresh one-tree run.','limits':['Read-only own Python source/hash analysis only, no native/cache/checker or supplied program execution.','No object tree copied, joined, removed or overwritten.','Package-object check is static existence/nonempty for the explicit package-source import closure; core imports end at installed toolchain object leaves. It is not an elaboration or binary import-table/ABI validation.','Package revision/process/resource assertions are retained from root preflight, not newly executed here.','Full 101 local closure is minimal for importing these four targets, not the full CP1 affected/downstream/root/Checks replay.','Current source or package bytes changing invalidates this plan; root should revalidate hashes before serial checks.','Ordinary PATH only: no PFR wrapper/bootstrap is needed for this closure.']}
for name,value in [('modules.json',[rows[m] for m in order]),('plan.json',result),('optional-baseline-analysis.json',optional),('external-objects.json',{'direct_roots':roots,'packages':external,'core_leaves':core,'missing':missing})]:
 (D/name).write_text(json.dumps(value,indent=2)+'\n')
(D/'order.txt').write_text('\n'.join(order)+'\n')
(D/'mathlib-roots.txt').write_text('\n'.join(mathlib_roots)+'\n')
print(json.dumps({'counts':result['counts'],'missing':missing,'target_positions':{m:order.index(m)+1 for m in TARGETS},'order_sha256':sha((D/'order.txt').read_bytes()),'modules_sha256':sha((D/'modules.json').read_bytes()),'plan_sha256':sha((D/'plan.json').read_bytes())},indent=2))
