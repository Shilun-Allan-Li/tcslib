"""Print actual axiom dependencies of the three repaired proofs and their API."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

PREP = Path(__file__).resolve().parent
OUT = PREP / 'cp1/native-api01-r1'
WORK = Path('/Users/seyoonr/.codex/worktrees/ps-gate08-repair/tcslib-pass-shelat-ch2-4')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    result = json.loads((OUT / 'RESULT.json').read_text())
    assert result['all_passed'] and result['checked_local_modules'] == 101
    tree = Path(result['tree'])
    records = [json.loads(s) for s in (OUT / 'attempts.jsonl').read_text().splitlines()]
    for row in records:
        assert row['passed']
        assert sha(WORK / (row['module'] + '.lean')) == row['source_sha256']
        assert sha(tree / (row['module'] + '.olean')) == row['object_sha256']
    for process in ['lean', 'lake']:
        response = subprocess.run(['pgrep', '-x', process], capture_output=True, text=True)
        assert response.returncode == 1, ('Native host occupied', process, response.stdout)
    names = [
        'Complexity.NUPPT.ofPolyTime',
        'Complexity.NUPPT.output_ofPolyTimeUniform',
        'Complexity.NUPPT.runAtL_ofPolyTimeUniform',
        'TCSlib.Cryptography.not_hardCore_const',
        'TCSlib.Cryptography.Collection.glPadSample_runAt',
        'TCSlib.Cryptography.Collection.glPad_sample_runAtL',
    ]
    module = '.lake/ps-maintainer/cleanup-api01-20261108/API01Axioms'
    source = WORK / (module + '.lean')
    assert not source.exists()
    source.write_text('import TCSlib.Cryptography.Asymptotic.HardCore\n\n' +
                      '\n'.join('#print axioms ' + name for name in names) + '\n')
    source_sha = sha(source)
    checker = WORK / 'scripts/lean_check_tree.sh'
    assert sha(checker) == result['checker_sha256']
    env = dict(os.environ)
    env['PATH'] = str(Path.home() / '.elan/bin') + ':' + env['PATH']
    env.pop('LEAN_PATH', None)
    env['TCSLIB_OLEANS'] = str(tree)
    command = ['/usr/bin/time', '-l', 'bash', 'scripts/lean_check_tree.sh', module]
    log_path = OUT / 'evidence/logs/102-API01Axioms.attempt01.log'
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t0 = time.monotonic()
    with log_path.open('xb') as log:
        log.write((json.dumps({'event': 'START', 'start_utc': start,
                              'module': module, 'source_sha256': source_sha,
                              'command': command, 'runner_sha256': sha(Path(__file__)),
                              'closure_result_sha256': sha(OUT / 'RESULT.json')}) + '\n').encode())
        log.flush()
        process = subprocess.Popen(command, cwd=WORK, env=env, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=subprocess.STDOUT)
        rc = process.wait()
        end = datetime.datetime.now(datetime.timezone.utc).isoformat()
        log.write((json.dumps({'event': 'END', 'end_utc': end, 'rc': rc,
                              'elapsed_seconds': time.monotonic() - t0}) + '\n').encode())
    raw = log_path.read_text()
    axiom_rows = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", raw, re.S)
    parsed = {name: [s.strip() for s in values.split(',') if s.strip()]
              for name, values in axiom_rows}
    for name in re.findall(r"'([^']+)' does not depend on any axioms", raw):
        assert name not in parsed
        parsed[name] = []
    obj = tree / (module + '.olean')
    passed = (rc == 0 and not re.search(r'\berror(?:\([^)]*\))?:', raw)
              and obj.is_file() and obj.stat().st_size > 0
              and sha(source) == source_sha and set(parsed) == set(names))
    report = {'module': module, 'source_sha256': source_sha,
              'source': source.read_text(), 'start_utc': start, 'end_utc': end,
              'rc': rc, 'passed': passed, 'axioms': parsed,
              'standard_only': set(a for values in parsed.values() for a in values)
                               <= {'propext', 'Classical.choice', 'Quot.sound'},
              'log_sha256': sha(log_path), 'log': str(log_path.relative_to(OUT)),
              'object_sha256': sha(obj) if obj.exists() else None,
              'limit': 'Six selected actual constants only; not the full cleanup census.'}
    (OUT / 'API01Axioms.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    assert passed, 'Preserve failed probe; do not claim an axiom result'


if __name__ == '__main__':
    main()
