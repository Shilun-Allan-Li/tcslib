"""Independent retained-key/row/name validation; no native or incoming execution."""
from pathlib import Path
from collections import Counter
import hashlib
import json

HERE = Path(__file__).resolve().parent
ISSUED = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/inputs')
def load(p): return json.loads(p.read_bytes())
def key(d): return d['path'], d['canonical']


def main():
    work = load(ISSUED / 'observations/canonical-work-units.json')
    history = load(ISSUED / 'historical/row-dispositions.json')
    raw = (ISSUED / 'historical/cleanup-b.tsv').read_text().splitlines()
    matrix = load(HERE / 'matrix.json')
    links = load(HERE / 'historical-row-links.json')
    mi = {tuple(x['issued_key']): x for x in matrix}
    assert len(mi) == len(matrix) == len(work) == 509
    assert set(mi) == {key(x) for x in work}
    assert Counter(x['historical_row_id'] for x in links) == Counter(range(1, 765))
    li = {x['historical_row_id']: x for x in links}
    counts = Counter()
    for r in history:
        number = r['row']; fields = raw[number - 1].split('\t')
        spelling = fields[3]
        if r['channel'] == 'seal':
            kind, spelling = spelling.split(' ', 1)
            assert kind in ('theorem', 'def') and kind == r['historical']['kind']
        assert spelling == r['source_spelling']
        link = li[number]; entry = mi[tuple(r['post_s2_work_key'])]
        assert link['original_row'] == r
        assert entry['issued_ordinal'] == link['issued_ordinal']
        assert tuple(link['issued_key']) == tuple(r['post_s2_work_key'])
        for field in ('path', 'canonical', 'kind', 'private', 'start', 'end', 'raw_sha256'):
            assert entry['baseline_source'][field] == r['current'][field], (number, field)
        assert link['cp1_source'] == entry['cp1_source']
        assert number in entry['historical_row_ids']
        assert link['native_acceptance'] == 'UNKNOWN' and link['work_acceptance'] == 'OPEN_PROVISIONAL' and not link['closed']
        counts[r['channel']] += 1
    result = {
        'retained_issued_keys': len(matrix), 'retained_original_rows': len(links),
        'original_row_channels': dict(counts),
        'all_raw_row_spellings_match': True,
        'seal_name_normalization': 'Remove only the exact theorem/def prefix; verify it agrees with original historical declaration kind.',
        'all_original_row_objects_preserved_exactly': True,
        'all_original_current_declaration_ranges_kinds_and_hashes_match_baseline': True,
        'all_row_CP1_targets_match_retained_key_targets': True,
        'all_acceptances': 'UNKNOWN_OPEN_PROVISIONAL', 'closed': 0,
        'own_validator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'native_run': False, 'incoming_program_execution': False,
    }
    with (HERE / 'retention-validation.json').open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__': main()
