"""Own non-native checks and provenance projection for the retained CP1 ledger."""
from pathlib import Path, PurePosixPath
from collections import Counter
import ast
import hashlib
import json
import tarfile

HERE = Path(__file__).resolve().parent
CP = HERE.parent
SRC = CP / 'review-source-scope'
PAYLOAD = CP / 'payload'
SOURCE_MANIFEST_SHA = '3850193db405e250cbe27d6321a138a33b88156b57a8bac82ce9da7162f6f384'
FILES_SHA = '5c269dc14c9797018223179057e5e52069ed1ff40be2e244eae429ef15572f94'
DELIVERY = '8b133945c3ba4aa7abb3b896bec38441535959b2'
ANCESTOR = '1aa5506f58f77c215e56d24311ec33bd931cacf1'


def digest(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(path.read_bytes())
def save(name, value):
    with (HERE / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
def desc(d):
    return {k: d[k] for k in ('path', 'canonical', 'name', 'kind', 'private', 'start', 'end', 'raw_sha256')} if d else None
def recover(d):
    found = {d['header'] + sep + d['body'] for sep in (':=', 'where', '')
             if digest((d['header'] + sep + d['body']).encode()) == d['raw_sha256']}
    assert len(found) == 1
    return found.pop()


def main():
    assert digest((SRC / 'manifest.json').read_bytes()) == SOURCE_MANIFEST_SHA
    assert digest((CP / 'files.json').read_bytes()) == FILES_SHA
    assert (CP / 'SNAPSHOT-COMPLETE').read_text() == DELIVERY + '\n'
    source_manifest = load(SRC / 'manifest.json')
    for group in ('inputs', 'outputs'):
        for row in source_manifest[group]:
            path = Path(row['path']) if group == 'inputs' else SRC / row['path']
            data = path.read_bytes()
            assert len(data) == row['bytes'] and digest(data) == row['sha256'], str(path)
    files = load(CP / 'files.json')
    assert len(files) == 2914 and len({x['path'] for x in files}) == 2914
    for row in files:
        rel = PurePosixPath(row['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        data = (PAYLOAD / row['path']).read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['path']
    for name in ('build_matrix.py', 'finalize.py'):
        ast.parse((HERE / name).read_text())
    matrix = load(HERE / 'matrix.json')
    links = load(HERE / 'historical-row-links.json')
    summary = load(HERE / 'summary.json')
    old = load(SRC / 'final-declarations-base.json')
    new = load(SRC / 'final-declarations-head.json')
    diffs = load(SRC / 'final-declaration-diffs.json')
    oldmap = {(d['path'], d['canonical']): d for d in old}
    newmap = {(d['path'], d['canonical']): d for d in new}
    issued = {tuple(x['issued_key']): x['issued_ordinal'] for x in matrix}
    assert len(matrix) == len(issued) == 509
    assert Counter(x['historical_row_id'] for x in links) == Counter(range(1, 765))
    source_text = {}
    for x in matrix:
        assert x['native_acceptance'] == 'UNKNOWN' and x['work_acceptance'] == 'OPEN_PROVISIONAL' and not x['closed']
        for map_, key in ((oldmap, 'baseline_source'), (newmap, 'cp1_source')):
            d = x[key]
            assert desc(map_[(d['path'], d['canonical'])]) == d
        d = newmap[(x['cp1_source']['path'], x['cp1_source']['canonical'])]
        text = source_text.setdefault(d['path'], (PAYLOAD / 'src' / d['path']).read_text())
        raw = recover(d)
        assert text.count(raw) == 1
        assert text[:text.index(raw)].count('\n') + 1 == d['start']
    # This is a projection of the already-reviewed full source map, not added work.
    delta = []
    for d in diffs:
        a, b = d['old'], d['new']
        delta.append({'map_key': d['key'], 'flags': d['flags'], 'old': desc(a), 'new': desc(b),
                      'issued_ordinal': issued.get((a['path'], a['canonical'])) if a else None,
                      'use': 'SOURCE_PROVENANCE_ONLY_NOT_A_NEW_WORK_KEY'})
    save('source-delta-locations.json', delta)
    # Exact finite X1 aliases already described in the frozen source review.
    aliases = [
        ('Asymptotic/Adversary', 'FunFamily.blocks', 'Asymptotic/Adversary', 'blocksEquivX', 'blocksEquivX q ℓ Bool'),
        ('Asymptotic/Adversary', 'FunFamily.blocks_apply', 'Asymptotic/Adversary', 'blocksEquivX_apply', 'blocksEquivX_apply q ℓ x i j'),
        ('Asymptotic/Adversary', 'FunFamily.blocks_symm_apply', 'Asymptotic/Adversary', 'blocksEquivX_symm_apply', 'blocksEquivX_symm_apply q ℓ t k'),
        ('Asymptotic/EnsemblesLemmas', 'EnsembleLemmas.blocks', 'Asymptotic/Adversary', 'FunFamily.blocks', 'FunFamily.blocks q ℓ'),
        ('GraphIsomorphism/Permutation', 'GI.blocksEquiv', 'Asymptotic/Adversary', 'FunFamily.blocks', '(FunFamily.blocks m c).symm'),
        ('Asymptotic/OneWay', 'OneWay.blocksE', 'Asymptotic/Adversary', 'FunFamily.blocks', 'FunFamily.blocks q ℓ'),
        ('Asymptotic/Collections', 'blocksEquiv', 'Asymptotic/Adversary', 'FunFamily.blocks', 'FunFamily.blocks q ℓ'),
        ('Asymptotic/Ensembles', 'Ensemble.blocks', 'Asymptotic/Adversary', 'FunFamily.blocks', 'FunFamily.blocks q ℓ'),
    ]
    # Resolve canonical names globally; check the recorded home rather than assume it.
    alias_rows = []
    for _suggested_home, short, _target_home, target, exact_body in aliases:
        ds = [d for d in new if d['canonical'] == 'TCSlib.Cryptography.' + short]
        ts = [d for d in new if d['canonical'] == 'TCSlib.Cryptography.' + target]
        assert len(ds) == len(ts) == 1, (short, target)
        d, t = ds[0], ts[0]
        assert d['body'].strip() == exact_body
        prior = [z for z in diffs if z['new'] and (z['new']['path'], z['new']['canonical']) == (d['path'], d['canonical'])]
        assert len(prior) == 1
        alias_rows.append({'old': desc(prior[0]['old']), 'new': desc(d), 'target': desc(t),
                           'exact_term_body': exact_body, 'native_equivalence': 'UNKNOWN',
                           'use': 'EXACT_SOURCE_ALIAS_LINK_NOT_DISCHARGE_OR_NEW_WORK'})
    save('alias-link-supplement.json', alias_rows)
    # Preserve why received locations were not accepted as exact source mappings.
    diagnostics = load(HERE / 'observed-diagnostics.json')
    unresolved = []
    texts = {}
    for label, archive_name, prefix in (
        ('BASE', 'seal-baseline-probes.tar.xz', 'seal/baseline/'),
        ('CP1', 'seal-j2-probes.tar.xz', 'seal/j2/')):
        with tarfile.open(PAYLOAD / 'evidence/probes' / archive_name) as archive:
            texts[label] = {m.name[len(prefix):]: archive.extractfile(m).read().decode()
                            for m in archive if m.isfile() and m.name.startswith(prefix)}
    for item in diagnostics:
        if not item['source_resolution'].startswith('UNRESOLVED'): continue
        candidates = []
        index = oldmap if item['phase'] == 'BASE' else newmap
        for candidate in item['exact_name_candidates']:
            d = index[(candidate['path'], candidate['canonical'])]
            text = texts[item['phase']][d['path']]
            raw = recover(d)
            n = text.count(raw)
            offset = text[:text.index(raw)].count('\n') + 1 - d['start'] if n == 1 else None
            line = item['raw_diagnostic']['error_line'] - offset if offset is not None else None
            candidates.append({'source': desc(d), 'raw_block_occurrences': n,
                               'probe_source_line_offset': offset, 'mapped_error_source_line': line,
                               'error_inside_source_block': line is not None and d['start'] <= line <= d['end']})
        unresolved.append({'diagnostic_id': item['id'], 'candidates': candidates,
                           'reason': 'REPORTED_DECLARATION_NAME_UNIQUE_BUT_ERROR_LINE_OUTSIDE_EXACT_BLOCK',
                           'native_acceptance': 'UNKNOWN'})
    assert len(unresolved) == 17 and all(len(x['candidates']) == 1 and not x['candidates'][0]['error_inside_source_block'] for x in unresolved)
    save('unresolved-diagnostic-details.json', unresolved)
    save('final-checks.json', {
        'delivery_commit': DELIVERY, 'ancestor': ANCESTOR,
        'frozen_source_manifest_sha256': SOURCE_MANIFEST_SHA,
        'all_frozen_source_review_inputs_outputs_still_match': True,
        'payload_rows_rehashed': len(files), 'payload_bytes_rehashed': sum(x['bytes'] for x in files),
        'all_509_old_new_descriptors_exact_map_matches': True,
        'all_509_CP1_targets_exact_raw_source_and_line_matches': True,
        'all_764_row_ids_retained_once': True,
        'source_delta_locations': len(delta),
        'full_source_owner_moves': sum('MOVED' in x['flags'] for x in delta),
        'exact_X1_source_alias_links': len(alias_rows),
        'all_acceptances': 'UNKNOWN_OPEN_PROVISIONAL', 'closed': 0,
        'native': False, 'incoming_program_execution': False,
        'local_API_01_commit_EXCLUDED': '8c047b8bcd3a2793795a02afd6d2d955c80e1806',
        'local_API_01_records_EXCLUDED': '15706ceb2e92cba77b232d572ce57bc5468a5565',
        'scope_limit': 'Retained-key source/provenance ledger only. No new obligations or acceptance inferred.'})
    print(json.dumps({'issued': len(matrix), 'rows': len(links), 'source_delta_locations': len(delta),
                      'source_owner_moves': sum('MOVED' in x['flags'] for x in delta),
                      'X1_alias_links': len(alias_rows), 'unresolved_diagnostics': len(unresolved),
                      'native_acceptance': 'UNKNOWN', 'source_report_unchanged': True}, indent=2))


if __name__ == '__main__': main()
