"""Own bounded CP1 ledger construction; received tools/probes are never executed."""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
import hashlib
import json
import lzma
import re
import tarfile

HERE=Path(__file__).resolve().parent
CP=HERE.parent
PAYLOAD=CP/'payload'
SOURCE=CP/'review-source-scope'
ISSUED=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/inputs')
INPUTS={}


def read(path):
    path=Path(path);data=path.read_bytes()
    INPUTS[str(path)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    return data


def load(path):return json.loads(read(path))
def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,data):
    with (HERE/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')


def descriptor(d):
    if not d:return None
    return {k:d[k] for k in ['path','canonical','name','kind','private','start','end','raw_sha256']}


def raw_decl(d):
    candidates=[d['header']+sep+d['body'] for sep in [':=','where','']]
    exact=list({s for s in candidates if sha(s.encode())==d['raw_sha256']})
    assert len(exact)==1,('unrecoverable exact source declaration',d['path'],d['canonical'])
    return exact[0]


def main():
    source_manifest=load(SOURCE/'manifest.json')
    for row in source_manifest['outputs']:
        data=read(SOURCE/row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
    work=load(ISSUED/'observations/canonical-work-units.json')
    historical=load(ISSUED/'historical/row-dispositions.json')
    raw_rows=read(ISSUED/'historical/cleanup-b.tsv').decode().splitlines()
    old=load(SOURCE/'final-declarations-base.json');new=load(SOURCE/'final-declarations-head.json')
    om=defaultdict(list);nm=defaultdict(list);by_file={'BASE':defaultdict(list),'CP1':defaultdict(list)}
    public_new=defaultdict(list)
    for label,ds,index in [('BASE',old,om),('CP1',new,nm)]:
        for d in ds:index[(d['path'],d['canonical'])].append(d);by_file[label][d['path']].append(d)
    for d in new:
        if not d['private']:public_new[d['canonical']].append(d)
    assert len(work)==509 and len(historical)==764 and len(raw_rows)==764
    issued_keys=[(x['path'],x['canonical']) for x in work];assert len(set(issued_keys))==len(work)
    ordinal={key:i for i,key in enumerate(issued_keys,1)}
    row_index={x['row']:x for x in historical};assert set(row_index)==set(range(1,765))
    historical_ids=[]
    for w in work:
        for o in w['observations']:
            if o['id'].startswith('H:'):historical_ids.append(int(o['id'][2:]))
    assert Counter(historical_ids)==Counter(range(1,765))
    for r in historical:
        assert tuple(r['post_s2_work_key']) in ordinal
        line=raw_rows[r['row']-1].split('\t');assert len(line)==5
        assert line[1]==r['channel'] and line[2]==r['path'] and line[4]==r['detail']
        assert int(r['row']) in [int(o['id'][2:]) for o in work[ordinal[tuple(r['post_s2_work_key'])]-1]['observations'] if o['id'].startswith('H:')]
    # Record replacements only for the three issued keys removed in CP1; no suffix joins.
    replacements={
      ('TCSlib/Cryptography/Asymptotic/Collections.lean','TCSlib.Cryptography.FunFamily.decodeFin_eq_some_iff'):
        ('TCSlib/Cryptography/Asymptotic/Adversary.lean','TCSlib.Cryptography.decodeFin_eq_some_iff','X4 explicit shared decoder contract'),
      ('TCSlib/Cryptography/Asymptotic/GGMReductionEval.lean','TCSlib.Cryptography.GGMRed.decodeFin_eq_some_iff'):
        ('TCSlib/Cryptography/Asymptotic/Adversary.lean','TCSlib.Cryptography.decodeFin_eq_some_iff','X4 explicit shared decoder contract'),
      ('TCSlib/Cryptography/ZeroKnowledge/Defs.lean','TCSlib.Cryptography.negligible_const_zero'):
        ('TCSlib/Cryptography/Foundations/Negligible.lean','TCSlib.Cryptography.negligible_zero','X4 explicit existing zero-negligibility theorem')}
    # Read probe archives as bytes only. Never extract/import/evaluate their Lean commands.
    probes={};ancillary_archive_members=[]
    for label,filename,prefix in [('BASE','seal-baseline-probes.tar.xz','seal/baseline/'),('CP1','seal-j2-probes.tar.xz','seal/j2/')]:
        path=PAYLOAD/'evidence/probes'/filename;read(path);entries={}
        with tarfile.open(path,'r:*') as archive:
            for member in archive.getmembers():
                if not member.isfile():continue
                if not member.name.startswith(prefix):
                    assert label=='CP1' and member.name=='census/J2Census.lean'
                    data=archive.extractfile(member).read()
                    ancillary_archive_members.append({'phase':label,'name':member.name,'bytes':len(data),'sha256':sha(data),'use':'RETAINED_ANCILLARY_DATA_NOT_A_SEAL_PROBE_NOT_EXECUTED'})
                    continue
                relative=member.name[len(prefix):]
                assert '..' not in PurePosixPath(relative).parts and relative.endswith('.lean')
                assert relative not in entries
                entries[relative]=archive.extractfile(member).read().decode()
        probes[label]=entries
    phase_files={'BASE':load(PAYLOAD/'evidence/logs/seal-baseline.json'),
                 'CP1':load(PAYLOAD/'evidence/logs/seal-j2.json')}
    phase_summaries={'BASE':load(PAYLOAD/'evidence/logs/seal-baseline-summary.json'),
                     'CP1':load(PAYLOAD/'evidence/logs/seal-j2-summary.json')}
    phase_names={'BASE':'BASELINE_STRICT_ALSO_SEALS_PolyExpr.eval',
                 'CP1':'CP1_STANDARD_eval_match_1_sunfold_UNSEALED'}
    diagnostics=[];diag_by_source=defaultdict(list);unresolved=[]
    placement={}
    def probe_placement(label,d):
        key=(label,d['path'],d['canonical'])
        if key not in placement:
            text=probes[label].get(d['path']);raw=raw_decl(d)
            count=text.count(raw) if text is not None else 0
            if count==1:
                line=text[:text.index(raw)].count('\n')+1
                placement[key]={'status':'EXACT_RAW_BLOCK_UNIQUE_IN_RECEIVED_PROBE',
                    'probe_start':line,'source_start':d['start'],'offset':line-d['start']}
            else:placement[key]={'status':'UNRESOLVED_RAW_BLOCK_PLACEMENT','occurrences':count}
        return placement[key]
    for label,modules in phase_files.items():
        count=0
        for module,record in modules.items():
            path=module+'.lean'
            assert path in by_file[label]
            for position,diag in enumerate(record['diagnostics'],1):
                identity=f'{label}:{module}:{position}'
                name=diag.get('decl')
                candidates=[d for d in by_file[label][path] if d['name']==name or d['canonical']==str(name).removeprefix('_root_.')]
                mapped=[]
                for d in candidates:
                    place=probe_placement(label,d)
                    error=diag.get('error_line')
                    if place['status'].startswith('EXACT') and isinstance(error,int):
                        source_line=error-place['offset']
                        if d['start']<=source_line<=d['end']:mapped.append((d,place,source_line))
                item={'id':identity,'phase':label,'variant':phase_names[label],'module':module,
                    'reported_valid_harness':record['valid'],'reported_harness_errors':record['harness_errors'],
                    'raw_diagnostic':diag,'source_resolution':'UNRESOLVED_OR_AMBIGUOUS','exact_name_candidates':[descriptor(d) for d in candidates],
                    'native_acceptance':'UNKNOWN','is_discharge':False}
                if len(mapped)==1:
                    d,place,line=mapped[0];item.update(source_resolution='EXACT_SOURCE_NAME_AND_RAW_PROBE_BLOCK',source=descriptor(d),probe_placement=place,mapped_source_line=line,
                       reported_decl_source_line_matches=diag.get('decl_line_in_source')==d['start'])
                    diag_by_source[(label,d['path'],d['canonical'])].append(identity)
                else:unresolved.append(identity)
                diagnostics.append(item);count+=1
        expected=phase_summaries[label].get('diagnostics',phase_summaries[label].get('error_diagnostics'))
        assert count==expected,(label,count,expected)
    # Scan item IDs and classifications are observations only. Match exact source
    # spellings and containing source lines, leaving unknown/ambiguous refs visible.
    scan=load_scan=json.loads(lzma.decompress(read(PAYLOAD/'evidence/logs/explicit-scan-cp1.json.xz')))
    scan_by_source=defaultdict(list);scan_unresolved=[]
    for i,item in enumerate(scan['items'],1):
        ds=[d for d in by_file['CP1'].get(item['file'],[]) if d['start']<=item['line']<=d['end'] and(d['name']==item['decl']or d['canonical']==str(item['decl']).removeprefix('_root_.'))]
        if len(ds)==1:scan_by_source[(ds[0]['path'],ds[0]['canonical'])].append((i,item['class']))
        else:scan_unresolved.append(i)
    c3=load(PAYLOAD/'evidence/logs/c3-cp1-vs-baseline.json')
    # Thin term-route references are source links, never an equivalence proof.
    all_public={d['canonical']:d for d in new if not d['private']}
    def term_route(d):
        body=d['body'].strip()
        if not body or body.startswith(('by','fun ','rfl','Iff.rfl','⟨','if ','match ')):return None
        match=re.match(r"([A-Za-z_][\w']*(?:\.[A-Za-z_][\w']*)*)\b",body)
        if not match:return None
        spelling=match.group(1)
        if re.match(r'^[A-Za-z_]\w*\.\d',body):return None
        name=d['name'];ns=d['canonical'][:-(len(name)+1)] if d['canonical'].endswith('.'+name) else ''
        prefixes=['.'.join(ns.split('.')[:n]) for n in range(len(ns.split('.')),-1,-1)] if ns else ['']
        names={'.'.join(x for x in [prefix,spelling]if x) for prefix in prefixes}
        # Explicit file opens before the declaration are data-based namespace candidates.
        text=(PAYLOAD/'src'/d['path']).read_text().splitlines()[:d['start']-1]
        for line in text:
            op=re.match(r'^open\s+([A-Za-z_][\w. ]*)$',line.strip())
            if op:
                for opened in op.group(1).split():names.add(opened+'.'+spelling)
        targets=[all_public[n] for n in sorted(names) if n in all_public]
        return {'source_term_head':spelling,'resolution':'EXACT_NAMESPACE_OR_EXPLICIT_OPEN_SOURCE_KEY'if len(targets)==1 else'UNRESOLVED_OR_AMBIGUOUS_TERM_HEAD',
                'targets':[descriptor(x)for x in targets],'native_equivalence':'UNKNOWN'}
    matrix=[];rowlinks=[];relations=Counter();moves=[];replacement_links=[]
    for i,w in enumerate(work,1):
        key=(w['path'],w['canonical']);assert len(om[key])==1
        baseline=om[key][0]
        assert baseline['start']==w['current_start']and baseline['end']==w['current_end']and baseline['raw_sha256']==w['current_raw_sha256'],('issued baseline anchor mismatch',key)
        current=nm.get(key,[]);relation='SAME_SOURCE_KEY'
        replacement_reason=None
        if not current and not baseline['private']:
            current=public_new.get(baseline['canonical'],[])
            if current:relation='OWNER_MOVED_SAME_FULLNAME'
        if not current and key in replacements:
            path,name,reason=replacements[key];current=nm.get((path,name),[])
            relation='REMOVED_SOURCE_KEY_EXPLICIT_REPLACEMENT_LINK';replacement_reason=reason
        assert len(current)<=1,('ambiguous current source key',key)
        d=current[0]if current else None
        if not d:relation='UNRESOLVED_CURRENT_SOURCE_TARGET'
        elif relation=='SAME_SOURCE_KEY':relation='SAME_KEY_RAW_BLOCK_UNCHANGED'if baseline['raw_sha256']==d['raw_sha256']else'SAME_KEY_SOURCE_CHANGED'
        links=sorted(int(o['id'][2:])for o in w['observations']if o['id'].startswith('H:'))
        baseids=diag_by_source.get(('BASE',*key),[])
        headids=diag_by_source.get(('CP1',d['path'],d['canonical']),[])if d else[]
        scanitems=scan_by_source.get((d['path'],d['canonical']),[])if d else[]
        entry={'issued_ordinal':i,'issued_key':list(key),'issued_work_record':w,'historical_row_ids':links,
           'baseline_source':descriptor(baseline),'cp1_source':descriptor(d),'source_relation':relation,'explicit_replacement_authority':replacement_reason,
           'term_route_link':term_route(d)if d else None,
           'baseline_strict_seal_observed':{'diagnostic_ids':baseids,'count':len(baseids),'absence_is_clearance':False},
           'cp1_standard_seal_observed':{'diagnostic_ids':headids,'count':len(headids),'absence_is_clearance':False},
           'cp1_explicit_scan_observed':{'item_indices':[n for n,_ in scanitems],'class_counts':dict(Counter(c for _,c in scanitems)),
              'source':'payload/evidence/logs/explicit-scan-cp1.json.xz','zero_foreign_classes_is_discharge':False},
           'c3_status':'GLOBAL_WORKER_OBSERVATION_ONLY_NOT_A_KEY_DISCHARGE',
           'native_acceptance':'UNKNOWN','work_acceptance':'OPEN_PROVISIONAL','closed':False,
           'limits':'Exact source transition and received diagnostic data only. A changed/removed/moved/alias source or absence of an observed diagnostic is not verified repair.'}
        matrix.append(entry);relations[relation]+=1
        if relation=='OWNER_MOVED_SAME_FULLNAME':moves.append({'issued_ordinal':i,'old':descriptor(baseline),'new':descriptor(d)})
        if replacement_reason:replacement_links.append({'issued_ordinal':i,'old':descriptor(baseline),'new':descriptor(d),'authority':replacement_reason})
        for n in links:rowlinks.append({'historical_row_id':n,'issued_ordinal':i,'issued_key':list(key),
             'original_row':row_index[n],'cp1_source':descriptor(d),'source_relation':relation,
             'native_acceptance':'UNKNOWN','work_acceptance':'OPEN_PROVISIONAL','closed':False})
    assert len(matrix)==509 and len({tuple(x['issued_key'])for x in matrix})==509
    assert len(rowlinks)==764 and Counter(x['historical_row_id']for x in rowlinks)==Counter(range(1,765))
    assert {tuple(x['issued_key'])for x in matrix}==set(issued_keys)
    assert all(x['native_acceptance']=='UNKNOWN'and not x['closed']for x in matrix+rowlinks)
    summary={'status':'PROVISIONAL_RETAINED_CP1_LEDGER_NO_NATIVE_ACCEPTANCE','issued_keys':len(matrix),'historical_rows':len(rowlinks),
        'all_issued_keys_retained_exactly_once':True,'all_historical_rows_linked_exactly_once':True,
        'source_relations':dict(relations),'moved_issued_keys':len(moves),'removed_keys_with_explicit_replacement_links':len(replacement_links),
        'unresolved_current_source_keys':sum(x['cp1_source']is None for x in matrix),
        'observed_cp1_standard_failing_issued_keys':sum(bool(x['cp1_standard_seal_observed']['count'])for x in matrix),
        'observed_baseline_strict_failing_issued_keys':sum(bool(x['baseline_strict_seal_observed']['count'])for x in matrix),
        'received_diagnostics':{label:sum(d['phase']==label for d in diagnostics)for label in phase_files},
        'exact_source_mapped_diagnostics':sum(d['source_resolution'].startswith('EXACT')for d in diagnostics),
        'unresolved_diagnostics':unresolved,'reported_decl_source_line_mismatches_retained':sum(d.get('reported_decl_source_line_matches')is False for d in diagnostics),
        'scan_items':len(scan['items']),'scan_source_match_unresolved_items':len(scan_unresolved),
        'worker_scan_summary':scan['summary'],'worker_c3_observation':{k:c3[k]for k in ['base_pairs','head_pairs','base_unique','head_unique']},
        'ancillary_archive_members':ancillary_archive_members,
        'native_acceptance_all':'UNKNOWN','work_acceptance_all':'OPEN_PROVISIONAL','closed_keys':0,
        'variant_limit':'Baseline strict sealed PolyExpr.eval; CP1 standard leaves eval/matcher/sunfold unsealed. Do not subtract variant diagnostics as repair evidence.',
        'no_new_work_obligations':True,'incoming_programs_executed':False,'source_report_unchanged':True}
    save('matrix.json',matrix);save('historical-row-links.json',sorted(rowlinks,key=lambda x:x['historical_row_id']))
    save('observed-diagnostics.json',diagnostics)
    save('transition-links.json',{'owner_moves':moves,'explicit_replacement_links':replacement_links})
    save('unresolved.json',{'diagnostic_ids':unresolved,'scan_item_indices':scan_unresolved,
         'source_keys':[x['issued_key']for x in matrix if not x['cp1_source']],
         'term_head_links':[{'issued_ordinal':x['issued_ordinal'],'issued_key':x['issued_key'],'link':x['term_route_link']}for x in matrix if x['term_route_link']and x['term_route_link']['resolution'].startswith('UNRESOLVED')],
         'limit':'Unresolved metadata is retained, never guessed into a source identity or turned into a new task.'})
    save('summary.json',summary)
    save('validation.json',{'inputs':INPUTS,'own_validator_sha256':sha(Path(__file__).read_bytes()),
         'checks':['Exact 509 issued-key set equality','Exact 764 row-ID multiset equality and raw TSV row consistency',
          'Every issued baseline source range/hash agrees with independently replayed source map',
          'Exact canonical/name-and-file joins only; public same-fullname moves; three explicit contract replacement links',
          'Received diagnostic counts match received variant summaries; raw probe blocks anchor resolved source diagnostics',
          'All native acceptance UNKNOWN; all work keys OPEN_PROVISIONAL; zero closed keys; no zero scan/C3 discharge'],
         'native_run':False,'incoming_program_execution':False,'source_git_mutations':False})
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
