"""Own DATA-ONLY corrected seal request planner. Never invokes Lean/Git/incoming code."""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
import hashlib
import json
import lzma
import re
import tarfile

HERE = Path(__file__).resolve().parent
DELIVERY = HERE.parent
PAYLOAD = DELIVERY / 'payload'
REVIEW = DELIVERY / 'review-source-scope'
ISSUED = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1')
PRIMARY = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean/Lean')
DELIVERY_COMMIT = '0c4d4f60203021f3a3b93f88eaf7c9085c6ab885'
SOURCE_HEAD = '03ead73ab38e74621800367c072f6fd3f0f70991'
SOURCE_ANCESTOR = '1aa5506f58f77c215e56d24311ec33bd931cacf1'
REVIEW_MANIFEST = 'a9b58ac78b9149f33cf2140fb551ca5a879d39e1b09066ac908f8c43cb26c6f8'
EVAL = 'Complexity.PolyExpr.eval'
RESTORED = (EVAL + '.match_1', EVAL + '._sunfold')
INPUTS = {}


def sha(b): return hashlib.sha256(b).hexdigest()
def read(path):
    b = path.read_bytes(); INPUTS[str(path)] = {'bytes': len(b), 'sha256': sha(b)}
    return b
def load(path): return json.loads(read(path))
def save(path, obj):
    with (HERE / path).open('x') as f: json.dump(obj, f, indent=2, ensure_ascii=False); f.write('\n')
def flags(row): return set(x for x in row['flags'].split(',') if x)
def source_module(path): return path[:-5].replace('/', '.')


def parse_components(text):
    assert text.startswith('[') and text.endswith(']')
    atoms = text[1:-1].split(', ') if text != '[]' else []
    out = []
    for atom in atoms:
        tag, sep, value = atom.partition(':')
        assert sep and tag in ('s', 'n') and value
        if tag == 'n':
            assert re.fullmatch(r'0|[1-9][0-9]*', value)
            value = int(value)
        else:
            assert not any(c in value for c in ('\t', '\n', '\r', '[', ']', ','))
        out.append((tag, value))
    assert out
    return tuple(out)


class RequestParser:
    """Strict grammar for received Name constructor tuples; never eval/Name.fromString."""
    def __init__(self, text): self.s = text; self.i = 0
    def ws(self):
        while self.i < len(self.s) and self.s[self.i].isspace(): self.i += 1
    def take(self, token):
        self.ws(); assert self.s.startswith(token, self.i), (self.i, token)
        self.i += len(token)
    def string(self):
        self.ws(); value, length = json.JSONDecoder().raw_decode(self.s[self.i:])
        assert isinstance(value, str); self.i += length
        return value
    def name(self):
        self.ws()
        if self.s.startswith('Lean.Name.anonymous', self.i):
            self.take('Lean.Name.anonymous'); return ()
        self.take('('); self.ws()
        if self.s.startswith('Lean.Name.str', self.i):
            self.take('Lean.Name.str'); parent = self.name(); value = self.string(); tag = 's'
        else:
            self.take('Lean.Name.num'); parent = self.name(); self.ws()
            m = re.match(r'0|[1-9][0-9]*', self.s[self.i:]); assert m
            value = int(m.group()); self.i += len(m.group()); tag = 'n'
        self.take(')'); return parent + ((tag, value),)
    def request(self):
        self.take('('); comps = self.name(); self.take(','); home = self.string()
        self.take(','); kind = self.string(); self.take(')'); self.ws()
        assert self.s[self.i:] in ('', ',', ']')
        return comps, home, kind


def main():
    assert sha(read(REVIEW / 'manifest.json')) == REVIEW_MANIFEST
    frozen = load(REVIEW / 'manifest.json')
    for entry in frozen['outputs']:
        if entry['path'] in ('final-changed-files.json', 'source-import-fingerprints.json', 'local-import-graph.json'):
            b = read(REVIEW / entry['path']); assert len(b) == entry['bytes'] and sha(b) == entry['sha256']
    intake = load(DELIVERY / 'intake.json')
    assert intake['delivery_commit'] == DELIVERY_COMMIT
    assert read(DELIVERY / 'SNAPSHOT-COMPLETE').decode() == DELIVERY_COMMIT + '\n'
    files = {r['path']: r for r in load(DELIVERY / 'files.json')}
    def payload(path):
        b = read(PAYLOAD / path); r = files[path]
        assert len(b) == r['bytes'] and sha(b) == r['sha256']; return b
    roles = load(ISSUED / 'inputs/role-manifest.json')['roles']
    original_input = next(r for r in frozen['inputs'] if r['path'] == str(ISSUED / 'inputs/role-manifest.json'))
    assert INPUTS[original_input['path']] == {k: original_input[k] for k in ('bytes', 'sha256')}
    consumer_paths = {r['path'] for r in roles if r['role'] == 'CONSUMER'}
    changed = load(REVIEW / 'final-changed-files.json')
    provider_paths = {r['path'] for r in changed if r['role'] == 'PROVIDER_ONLY'}
    required_paths = consumer_paths | provider_paths
    assert len(consumer_paths) == 97 and len(provider_paths) == 26 and len(required_paths) == 123
    all_owned = {r['path'] for r in roles if r['role'] != 'CHECK_ONLY'}
    all_owners = {source_module(p) for p in all_owned}
    owner_paths = {source_module(p): p for p in required_paths}
    graph = load(REVIEW / 'local-import-graph.json')['HEAD']
    topo = graph['topological_order']; edges = graph['edges']
    owners = [m for m in topo if m in owner_paths]; assert set(owners) == set(owner_paths)
    source_rows = load(REVIEW / 'source-import-fingerprints.json')
    source_index = {r['module']: r for r in source_rows if r['revision'] == 'HEAD'}
    # Validate compressed and uncompressed identities before interpreting native metadata.
    sums = {}
    for line in payload('evidence/census/final.SHA256SUMS').decode().splitlines():
        digest, name = line.split('  ', 1); sums[name] = digest
    catalog = {}; all_names = set(); name_count = 0
    name_bytes = payload('evidence/census/final/names.tsv.xz')
    name_hash = hashlib.sha256()
    with lzma.open(PAYLOAD / 'evidence/census/final/names.tsv.xz', 'rb') as stream:
        for raw in stream:
            name_hash.update(raw); a = raw.decode().removesuffix('\n').split('\t')
            assert len(a) == 6 and a[0] == 'NAME' and a[1] not in all_names
            all_names.add(a[1]); name_count += 1
            if a[4].startswith('TCSlib.'):
                catalog[a[1]] = {'actual_name': a[1], 'kind': a[2], 'status': a[3], 'home': a[4],
                                 'flags': a[5], 'native_name_row': name_count}
    assert name_hash.hexdigest() == sums['names.tsv']
    native_rows = defaultdict(list); native_deps = {}; native_counts = {}; components = {}; component_to_name = {}
    closure_bytes = payload('evidence/census/final/closure.tsv.xz')
    closure_hash = hashlib.sha256()
    with lzma.open(PAYLOAD / 'evidence/census/final/closure.tsv.xz', 'rb') as stream:
        for raw in stream:
            closure_hash.update(raw); a = raw.decode().removesuffix('\n').split('\t')
            if a[0] == 'CLOSURE':
                assert len(a) == 7
                _, owner, name, home, kind, status, comp = a
                meta = catalog[name]
                assert meta['home'] == home and meta['kind'] == 'def' and meta['status'] == status
                assert kind == ('def/matcher' if 'matcher' in flags(meta) else 'def')
                assert 'instance' not in flags(meta)
                if name not in components:
                    parsed = parse_components(comp); components[name] = (parsed, comp)
                    assert parsed not in component_to_name; component_to_name[parsed] = name
                else: assert components[name][1] == comp
                native_rows[owner].append(name)
            elif a[0] == 'CLOSURE-DEPS':
                assert len(a) == 3 and a[1] not in native_deps
                names = a[2][1:-1].split(', ') if a[2] != '[]' else []
                assert a[2].startswith('[') and a[2].endswith(']') and len(names) == len(set(names))
                assert all(re.fullmatch(r'TCSlib(?:\.[A-Za-z0-9_]+)+', m) for m in names)
                native_deps[a[1]] = set(names)
            elif a[0] == 'CLOSURE-COUNT':
                assert len(a) == 3 and a[1] not in native_counts; native_counts[a[1]] = int(a[2])
            else: raise AssertionError(('unknown closure row', a[0]))
    assert closure_hash.hexdigest() == sums['closure.tsv']
    assert set(native_deps) == set(native_counts) == all_owners
    source_deps = {}
    for owner in all_owners:
        seen = set(); stack = list(edges[owner])
        while stack:
            item = stack.pop()
            if item in seen: continue
            seen.add(item); stack.extend(edges[item])
        deps = {m for m in seen if m.startswith('TCSlib.') and m != owner}
        assert deps == native_deps[owner], ('native/source closure mismatch', owner)
        source_deps[owner] = deps
        assert len(native_rows[owner]) == len(set(native_rows[owner])) == native_counts[owner]
        expected = {n for n, r in catalog.items() if r['home'] in deps and r['kind'] == 'def' and
                    'instance' not in flags(r) and (r['status'] != 'Lean.ReducibilityStatus.reducible' or 'matcher' in flags(r))}
        assert expected == set(native_rows[owner]), ('catalog/closure exact-set mismatch', owner)
    assert components[EVAL][0] == (('s', 'Complexity'), ('s', 'PolyExpr'), ('s', 'eval'))
    # Parse the old constant-constructor requests as data and recover original source bytes.
    old_plans = {}
    for label, archive_name, prefix in (
        ('standard', 'seal-final-probes.tar.xz', 'seal-final/'),
        ('strict', 'seal-final-strict-probes.tar.xz', 'seal-final-strict/')):
        payload('evidence/probes/' + archive_name); plans = {}
        with tarfile.open(PAYLOAD / 'evidence/probes' / archive_name) as archive:
            for member in archive:
                if not member.isfile(): continue
                assert member.name.startswith(prefix)
                path = member.name[len(prefix):]; rel = PurePosixPath(path)
                assert '..' not in rel.parts and not rel.is_absolute() and path.endswith('.lean')
                owner = source_module(path); assert owner in owner_paths and owner not in plans
                text = archive.extractfile(member).read().decode()
                marker = re.search(r'(?m)^-- CP2 WHOLE-FILE SEAL .*?: (\d+) requests for (\S+)\n', text)
                assert marker and marker[2] == owner
                end_marker = '-- CP2 END SEAL\n'; end = text.index(end_marker, marker.start()) + len(end_marker)
                block = text[marker.start():end]; names = []
                for line in block.splitlines():
                    if re.match(r'^\s*\(\(?Lean\.Name\.', line):
                        parsed, home, kind = RequestParser(line.strip()).request()
                        name = component_to_name[parsed]; meta = catalog[name]
                        assert home == meta['home'] and kind == ('def/matcher' if 'matcher' in flags(meta) else 'def')
                        names.append(name)
                assert len(names) == len(set(names)) == int(marker[1])
                suffix = '\nrun_cmd Lean.logInfo "CP2-EOF"\n'; assert text.endswith(suffix)
                # mkseal inserts a newline-terminated list element between the
                # source lines; joining that list adds one separator newline.
                assert text[end] == '\n'
                original = (text[:marker.start()] + text[end+1:])[:-len(suffix)].encode()
                assert original == payload('src/' + path), ('probe source snapshot mismatch', label, owner)
                plans[owner] = {'names': names, 'request_count': len(names),
                                'probe_sha256': sha(text.encode()), 'original_source_sha256': sha(original)}
        old_plans[label] = plans
    existing = set(old_plans['standard']); assert existing == set(old_plans['strict']) and len(existing) == 98
    assert consumer_paths <= {owner_paths[m] for m in existing}
    for owner in existing:
        assert set(old_plans['strict'][owner]['names']) == set(native_rows[owner])
        assert set(old_plans['standard'][owner]['names']) == set(native_rows[owner]) - {EVAL, *RESTORED}
    missing = set(owners) - existing
    assert len(missing) == 25 and all(owner_paths[m] in provider_paths for m in missing)
    (HERE / 'per-owner').mkdir(exist_ok=False)
    owner_rows = []; reconciliation = []; excluded_instances = defaultdict(list); reduced = defaultdict(list); opaque = defaultdict(list)
    for owner in owners:
        path = owner_paths[owner]; source = payload('src/' + path)
        assert sha(source) == source_index[owner]['sha256']
        deps = source_deps[owner]; request_names = sorted(set(native_rows[owner]) - {EVAL})
        requested = []
        for name in request_names:
            r = catalog[name]
            requested.append({**r, 'request_kind': 'def/matcher' if 'matcher' in flags(r) else 'def',
                              'name_components': [[tag, value] for tag, value in components[name][0]],
                              'native_components_text': components[name][1]})
        stem = owner.replace('.', '_'); request_file = 'per-owner/' + stem + '.requests.jsonl'
        with (HERE / request_file).open('x') as f:
            for r in requested: f.write(json.dumps(r, ensure_ascii=False, separators=(',', ':')) + '\n')
        instances = sorted(n for n, r in catalog.items() if r['home'] in deps and r['kind'] == 'def' and
                           'instance' in flags(r) and r['status'] == 'Lean.ReducibilityStatus.semireducible')
        reducibles = sorted(n for n, r in catalog.items() if r['home'] in deps and r['kind'] == 'def' and
                            r['status'] == 'Lean.ReducibilityStatus.reducible' and 'matcher' not in flags(r))
        opaques = sorted(n for n, r in catalog.items() if r['home'] in deps and r['kind'] == 'opaque')
        for n in instances: excluded_instances[n].append(owner)
        for n in reducibles: reduced[n].append(owner)
        for n in opaques: opaque[n].append(owner)
        role = 'CONSUMER' if path in consumer_paths else 'CHANGED_PROVIDER_ONLY'
        record = {'owner': owner, 'path': path, 'role': role, 'source_sha256': sha(source), 'source_bytes': len(source),
                  'foreign_TCS_import_closure': sorted(deps), 'closure_native_source_exact_set_equal': True,
                  'native_catalog_def_method_rows': len(native_rows[owner]), 'exact_eval_omission': EVAL in native_rows[owner],
                  'request_count': len(requested), 'request_file': request_file,
                  'metadata_expected_semireducible': sum(r['status'] == 'Lean.ReducibilityStatus.semireducible' for r in requested),
                  'metadata_expected_already_irreducible': sum(r['status'] == 'Lean.ReducibilityStatus.irreducible' for r in requested),
                  'excluded_semireducible_def_instances': instances, 'excluded_reducible_non_matcher_definitions': reducibles,
                  'excluded_opaque_constants_by_inherited_defnInfo_method': opaques,
                  'optional_instance_inclusive_request_count_DATA_ONLY': len(requested) + len(instances),
                  'instance_component_status': 'NOT_IN_NATIVE_CLOSURE_OUTPUT; NO_NAME_RECONSTRUCTION',
                  'runtime_status': 'NOT_RUN', 'instance_filter_authority': 'INHERITED_METHOD_COVERAGE_LIMIT_NOT_USER_RULING'}
        save('per-owner/' + stem + '.plan.json', record); owner_rows.append(record)
        if owner in existing:
            restored = sorted(set(request_names) - set(old_plans['standard'][owner]['names']))
            assert set(restored) <= set(RESTORED)
            reconciliation.append({'owner': owner, 'source_sha256': sha(source),
                'old_standard': {k: v for k, v in old_plans['standard'][owner].items() if k != 'names'},
                'old_strict': {k: v for k, v in old_plans['strict'][owner].items() if k != 'names'},
                'corrected_count': len(requested), 'restored_requests': restored,
                'removed_from_old_standard': sorted(set(old_plans['standard'][owner]['names']) - set(request_names)),
                'strict_minus_exact_eval_equals_corrected': True})
    save('owners.json', owner_rows)
    save('metadata-catalog-TCS.json', [catalog[n] for n in sorted(catalog)])
    save('request-name-component-catalog.json', [{**catalog[n], 'name_components': [[tag, value] for tag, value in components[n][0]],
          'native_components_text': components[n][1]} for n in sorted(components)])
    save('existing-98-reconciliation.json', reconciliation)
    save('missing-25-provider-plans.json', [r for r in owner_rows if r['owner'] in missing])
    save('excluded-semireducible-instances.json', [{**catalog[n], 'excluded_in_owners': excluded_instances[n],
         'native_components_available': False, 'reason': 'INHERITED_INSTANCE_FILTER_NOT_LEAN_RESTRICTION_OR_NOTATION_RULING'} for n in sorted(excluded_instances)])
    save('optional-instance-inclusive-supplement-DATA.json', {'status': 'OPTIONAL_DATA_NOT_APPROVED_METHOD_NOT_RUN',
         'addition_pairs': sum(map(len, excluded_instances.values())), 'unique_additions': len(excluded_instances),
         'identities': [{**catalog[n], 'owners': excluded_instances[n], 'name_components': None} for n in sorted(excluded_instances)],
         'limit': 'Use actual environment Names after exact catalog checks in any future native plan. Never reconstruct Name components from display strings. No native run or new policy ruling is asserted.'})
    save('other-inherited-method-omissions.json', {
        'reducible_non_matcher_definitions': [{**catalog[n], 'owners': reduced[n]} for n in sorted(reduced)],
        'opaque_non_defnInfo_constants': [{**catalog[n], 'owners': opaque[n]} for n in sorted(opaque)],
        'limit': 'Full raw identities, not a new notation approval. Reducible abbreviations are notation under policy; other generated reducible declarations are an inherited validation/method limit. Opaque constants fail the pinned defnInfo reducibility validation.'})
    summary = {'status': 'REQUEST_PLAN_ONLY_NOT_NATIVE_RESULTS', 'delivery_commit': DELIVERY_COMMIT,
        'source_head': SOURCE_HEAD, 'source_ancestor': SOURCE_ANCESTOR,
        'consumer_owners': len(consumer_paths), 'changed_provider_owners': len(provider_paths), 'required_owners': len(owners),
        'existing_owners': len(existing), 'missing_provider_owners_added': len(missing),
        'old_standard_requests': sum(r['old_standard']['request_count'] for r in reconciliation),
        'old_strict_requests': sum(r['old_strict']['request_count'] for r in reconciliation),
        'restored_matcher_sunfold_requests': sum(len(r['restored_requests']) for r in reconciliation),
        'exact_eval_omission_existing_owners': sum(EVAL in native_rows[m] for m in existing),
        'corrected_existing_requests': sum(r['corrected_count'] for r in reconciliation),
        'new_provider_requests': sum(r['request_count'] for r in owner_rows if r['owner'] in missing),
        'total_requests': sum(r['request_count'] for r in owner_rows),
        'empty_request_owners': [r['owner'] for r in owner_rows if r['request_count'] == 0],
        'native_metadata_rows': name_count, 'TCS_metadata_rows': len(catalog), 'native_closure_owners_validated': len(native_counts),
        'unique_component_rows_available': len(components),
        'excluded_semireducible_instance_pairs': sum(map(len, excluded_instances.values())),
        'excluded_semireducible_instance_unique': len(excluded_instances),
        'optional_instance_inclusive_total_DATA_ONLY': sum(r['request_count'] for r in owner_rows) + sum(map(len, excluded_instances.values())),
        'all_TCS_import_closures_match_native_and_source': True, 'all_native_closure_catalog_row_sets_exact': True,
        'existing_probe_Name_tuples_parsed_without_eval': True, 'existing_probe_original_sources_equal_snapshot': True,
        'no_new_name_kind_home_source_exclusions': True, 'no_source_failure_exclusions': True,
        'no_runtime_result_or_policy_approval': True, 'root_later_repairs_incorporated': False}
    assert summary['restored_matcher_sunfold_requests'] == 154
    assert summary['old_standard_requests'] == 95177 and summary['old_strict_requests'] == 95408
    assert summary['corrected_existing_requests'] == 95331
    save('summary.json', summary)
    for path in (PRIMARY / 'Declaration.lean', PRIMARY / 'ReducibilityAttrs.lean'): read(path)
    save('input-bindings.json', [{'path': p, **v} for p, v in sorted(INPUTS.items())])
    print(json.dumps(summary, indent=2))


if __name__ == '__main__': main()
