"""Own source-only validation of the frozen eight-file local repair overlay."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import lzma
import re

HERE = Path(__file__).resolve().parent
PARTIAL = HERE.parent
OVERLAY = PARTIAL / 'local-repairs-final-r1'
PAYLOAD = PARTIAL / 'payload'
PRIOR = PARTIAL / 'review-source-scope'
ISSUED = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1')
INPUTS = {}


def sha(data): return hashlib.sha256(data).hexdigest()
def read(p):
    data = p.read_bytes(); INPUTS[str(p)] = {'bytes': len(data), 'sha256': sha(data)}
    return data
def load(p): return json.loads(read(p))
def save(name, obj):
    with (HERE / name).open('x') as f: json.dump(obj, f, indent=2); f.write('\n')


def main():
    assert sha(read(PRIOR / 'manifest.json')) == 'a9b58ac78b9149f33cf2140fb551ca5a879d39e1b09066ac908f8c43cb26c6f8'
    prior = load(PRIOR / 'manifest.json')
    util = read(PRIOR / 'validate.py')
    expected_util = next(r for r in prior['outputs'] if r['path'] == 'validate.py')
    assert sha(util) == expected_util['sha256']
    ast.parse(util.decode())
    own = {'__file__': str(PRIOR / 'validate.py'), '__name__': 'own_pure_source_utilities'}
    exec(compile(util, str(PRIOR / 'validate.py'), 'exec'), own)
    parse, mask, apply, plain = (own[n] for n in ('parse', 'mask', 'apply_patch', 'plain'))
    manifest = load(OVERLAY / 'manifest.json')
    assert manifest['worker_delivery'] == '0c4d4f60203021f3a3b93f88eaf7c9085c6ab885'
    assert manifest['base_materialized_worker_head'] == 'bf2d8df1663f51c29a1d3c55ad8bf3fa56b74fe3'
    patch = read(OVERLAY / 'repairs.patch'); assert sha(patch) == manifest['patch_sha256']
    paths = [r['path'] for r in manifest['files']]
    assert len(paths) == len(set(paths)) == 8
    actual = {str(p.relative_to(OVERLAY / 'src')) for p in (OVERLAY / 'src').rglob('*') if p.is_file()}
    assert actual == set(paths)
    roles = {r['path']: r['role'] for r in load(ISSUED / 'inputs/role-manifest.json')['roles']}
    payload_rows = {r['path']: r for r in load(PARTIAL / 'files.json')}
    base = {}; head = {}; source_hashes = []
    for r in manifest['files']:
        p = Path(r['path']); assert not p.is_absolute() and '..' not in p.parts
        assert roles[str(p)] == 'CONSUMER'
        source = OVERLAY / 'src' / p; assert not source.is_symlink()
        new = read(source); assert len(new) == r['bytes'] and sha(new) == r['sha256']
        old = read(PAYLOAD / 'src' / p); delivered = payload_rows['src/' + str(p)]
        assert len(old) == delivered['bytes'] and sha(old) == delivered['sha256']
        base[str(p)] = old; head[str(p)] = new
        source_hashes.append({'path': str(p), 'role': roles[str(p)], 'old_sha256': sha(old), 'new_sha256': sha(new)})
    replay = base.copy(); hunks = apply(replay, patch)
    assert set(r['path'] for r in hunks) == set(paths) and replay == head
    old_decls = []; new_decls = []
    for path in sorted(paths):
        old_decls.extend(parse(base[path].decode(), path)); new_decls.extend(parse(head[path].decode(), path))
    oldmap = {(d['path'], d['canonical']): d for d in old_decls}
    newmap = {(d['path'], d['canonical']): d for d in new_decls}
    assert len(oldmap) == len(old_decls) and len(newmap) == len(new_decls)
    removed = set(oldmap) - set(newmap); added = set(newmap) - set(oldmap)
    removed_key = ('TCSlib/Complexity/Randomized/PPT.lean', 'Complexity.NUPPT.ofPolyTimeUniform_def')
    assert removed == {removed_key} and not added
    issued_base = load(PRIOR / 'final-declarations-base.json')
    assert removed_key not in {(d['path'], d['canonical']) for d in issued_base}
    changed = []; unchanged_admissions = []
    for key, d in oldmap.items():
        if key not in newmap: continue
        n = newmap[key]
        assert d['header'] == n['header'], ('header changed', key)
        assert d['mods'] == n['mods'] and d['preceding_attributes'] == n['preceding_attributes'] and d['same_line_attributes'] == n['same_line_attributes']
        if d['body'] != n['body']:
            assert d['kind'] in ('theorem', 'lemma')
            changed.append({'old': plain(d), 'new': plain(n)})
        if re.search(r'\b(?:sorry|admit|sorryAx|axiom)\b', mask(d['raw'])):
            assert d['raw'] == n['raw']; unchanged_admissions.append({'path': d['path'], 'canonical': d['canonical'], 'raw_sha256': d['raw_sha256']})
    allowed = {
        'TCSlib.Cryptography.not_hardCore_const',
        'TCSlib.Cryptography.Collection.glPad_sample_runAtL',
        'TCSlib.Cryptography.Collection.glPadSample_runAt',
        'TCSlib.Cryptography.GGMRed.unaryMul_poly',
        'TCSlib.Cryptography.OneWay.polyTimeComputable_unaryMulPair',
        'TCSlib.Cryptography.EncodingMachines.unaryMul_poly',
        'TCSlib.Cryptography.GI.unaryMul_poly',
    }
    assert {d['old']['canonical'] for d in changed} == allowed
    all_sources = {}
    for r in payload_rows.values():
        if r['path'].startswith('src/'):
            path = r['path'][4:]; data = head[path] if path in head else read(PAYLOAD / r['path'])
            if path not in head: assert len(data) == r['bytes'] and sha(data) == r['sha256']
            all_sources[path] = data
    assert all(b'ofPolyTimeUniform_def' not in data for data in all_sources.values())
    # All owned admitted blocks, including those outside the overlay, remain exact.
    admissions = load(PRIOR / 'baseline-admitted-declarations.json')
    full_head = {(d['path'], d['canonical']): d for d in load(PRIOR / 'final-declarations-head.json')}
    full_head.update(newmap)
    for row in admissions:
        d = row['new']; assert full_head[(d['path'], d['canonical'])]['raw_sha256'] == d['raw_sha256']
    graph = load(PRIOR / 'local-import-graph.json')['HEAD']['edges']
    import_changes = []
    def imports(data):
        return [x for line in mask(data.decode()).splitlines() if (m := re.match(r'^import\s+(.+)', line)) for x in m[1].split()]
    for path in paths:
        a, b = set(imports(base[path])), set(imports(head[path])); mod = path[:-5].replace('/', '.')
        assert all(not x.startswith('TCSlib.') or x in graph for x in b)
        graph[mod] = [x for x in b if x in graph]
        if a != b: import_changes.append({'path': path, 'added': sorted(b-a), 'removed': sorted(a-b)})
    visiting = set(); visited = set()
    def visit(mod):
        assert mod not in visiting, ('cycle', mod)
        if mod in visited: return
        visiting.add(mod)
        for dep in graph[mod]: visit(dep)
        visiting.remove(mod); visited.add(mod)
    for mod in graph: visit(mod)
    assert len(visited) == 1071
    assert len(import_changes) == 4 and sum(len(x['added']) for x in import_changes) == 5 and not any(x['removed'] for x in import_changes)
    # Check every explicit item added to changed proofs against the native kind catalog.
    explicit = {'Function.comp_apply', 'Complexity.BinArith.length_mulU', 'List.length_replicate',
                'Complexity.pairFstD_eq', 'Complexity.pairSndD_eq', 'Option.map_none', 'Option.getD_none',
                'Option.map_some', 'Option.getD_some', 'List.length_nil', 'Nat.zero_mul', 'List.replicate_zero',
                'Complexity.NUPPT.output_ofPolyTimeUniform'}
    catalog_path = PAYLOAD / 'evidence/census/final/names.tsv.xz'; read(catalog_path); metadata = {}
    with lzma.open(catalog_path, 'rt') as f:
        for line in f:
            a = line.removesuffix('\n').split('\t')
            if len(a) == 6 and a[1] in explicit:
                assert a[1] not in metadata
                metadata[a[1]] = {'actual_name': a[1], 'kind': a[2], 'status': a[3], 'home': a[4], 'flags': a[5]}
    assert set(metadata) == explicit and all(r['kind'] == 'thm' for r in metadata.values())
    for d in changed:
        body = mask(d['new']['body'])
        assert not re.search(r'\.(?:eq_[0-9]+|eq_def|eq_unfold)\b|\b(?:sorry|admit|sorryAx|unsafe|native_decide|run_tac|run_elab)\b', body)
    directives = re.compile(r'^\s*(?:set_option|attribute|open|namespace|section|end|variable|include|omit|run_cmd|initialize|macro|elab)\b')
    for path in paths:
        a, b = (Counter(line.strip() for line in mask(src.decode()).splitlines() if directives.match(line)) for src in (base[path], head[path]))
        assert a == b
    result = {'status': 'INDEPENDENT_STATIC_LOCAL_OVERLAY_REVIEW_NOT_NATIVE_ACCEPTANCE',
        'patch_replay_exact': True, 'files': source_hashes, 'source_files': len(paths),
        'roles': {'CONSUMER': len(paths), 'PROVIDER_ONLY': 0},
        'removed_new_incoming_machine_alias': list(removed_key), 'removed_alias_absent_at_issued_ancestor': True,
        'remaining_alias_source_references': 0, 'existing_proof_blocks_changed': len(changed),
        'existing_headers_data_algorithms_modifiers_attributes_preserved': True,
        'new_declarations': 0, 'owned_admitted_blocks_preserved': len(admissions),
        'admitted_blocks_in_local_files_preserved': unchanged_admissions,
        'import_changes': import_changes, 'import_cycles': [], 'missing_local_imports': [],
        'local_graph_modules': len(visited), 'new_explicit_items_are_published_theorems': metadata,
        'native_claims': 'Root records only; no native, axiom, seal, instance or style result rerun/adopted here.',
        'no_new_typed_source_general_lemma_host_premise_cost': True,
        'scope_limit': 'Exact local overlay source review only; incoming partial work, full corrected seals and broader acceptance remain separate.'}
    save('validation.json', result); save('patch-replay.json', hunks)
    save('changed-proof-blocks.json', changed)
    save('base-declarations.json', [plain(d) for d in old_decls]); save('overlay-declarations.json', [plain(d) for d in new_decls])
    save('input-bindings.json', [{'path': p, **v} for p, v in sorted(INPUTS.items())])
    print(json.dumps({k: v for k, v in result.items() if not isinstance(v, (list, dict))}, indent=2))


if __name__ == '__main__': main()
