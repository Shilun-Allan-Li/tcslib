"""Read-only partial-r1 evidence validation. Never execute/import received programs."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import lzma
import re
import subprocess
import tarfile

CP = Path(__file__).resolve().parent.parent
P = CP / 'payload'
OUT = Path(__file__).resolve().parent
MAIN = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
ISSUE = MAIN / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1'
BASE = '1aa5506f58f77c215e56d24311ec33bd931cacf1'
E = P / 'evidence/logs'
result = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def load(path):
    return json.loads(path.read_text())


def records(name):
    return [json.loads(line) for line in (E / name).read_text().splitlines() if line]


def git(*args, input=None):
    return subprocess.check_output(['git', '-C', str(MAIN), *args], input=input)


def mask(text):
    out = []; i = depth = 0
    while i < len(text):
        if depth:
            if text.startswith('/-', i): depth += 1; out.extend('  '); i += 2
            elif text.startswith('-/', i): depth -= 1; out.extend('  '); i += 2
            else: out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif text.startswith('/-', i): depth = 1; out.extend('  '); i += 2
        elif text.startswith('--', i):
            j = text.find('\n', i)
            if j < 0: j = len(text)
            out.extend(' ' * (j-i)); i = j
        elif text[i] == '"':
            out.append(' '); i += 1
            while i < len(text):
                c = text[i]; out.append('\n' if c == '\n' else ' '); i += 1
                if c == '\\' and i < len(text): out.append(' '); i += 1
                elif c == '"': break
        else: out.append(text[i]); i += 1
    assert depth == 0
    return ''.join(out)


def imports(raw):
    names = []
    for line in mask(raw.decode()).splitlines():
        line = line.strip()
        if not line or line in ('prelude', 'module'): continue
        m = re.fullmatch(r'(?:public\s+)?import\s+(.+)', line)
        if not m: break
        names.extend(m.group(1).split())
    return names


inventory = load(CP / 'files.json')
for row in inventory:
    raw = (P / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'] and blob(raw) == row['git_blob'], row['path']
result['payload'] = {'files': len(inventory), 'all_sizes_sha256_git_blobs_match_intake': True,
    'report_sha256': sha((P / 'REPORT.md').read_bytes()), 'delivery_commit': load(CP/'intake.json')['delivery_commit']}
owned = (ISSUE/'inputs/owned-files.txt').read_text().splitlines()
providers = set((ISSUE/'inputs/provider-only-files.txt').read_text().splitlines())
consumers = set((ISSUE/'inputs/consumer-files.txt').read_text().splitlines())
assert len(owned) == 221 and len(providers) == 124 and len(consumers) == 97

paths = git('ls-tree', '-r', '--name-only', BASE, 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean').decode().splitlines()
paths = [p for p in paths if p.endswith('.lean')]
batch = git('cat-file', '--batch', input=('\n'.join(BASE+':'+p for p in paths)+'\n').encode())
base = {}; pos = 0
for path in paths:
    end = batch.index(b'\n', pos); header = batch[pos:end].split(); size = int(header[2])
    raw = batch[end+1:end+1+size]; assert blob(raw).encode() == header[0]
    base[path] = raw; pos = end + size + 2
assert pos == len(batch)
versions = [base]; commits = [BASE]; patch_changes = []
for patch in sorted((P/'patches').glob('*.patch')):
    lines = patch.read_bytes().splitlines(keepends=True)
    commit = re.fullmatch(rb'From ([0-9a-f]{40}) Mon Sep 17 00:00:00 2001\n', lines[0]).group(1).decode()
    current = dict(versions[-1]); changed = []; i = 0
    while i < len(lines):
        m = re.fullmatch(rb'diff --git a/(.+) b/(.+)\n', lines[i])
        if not m: i += 1; continue
        assert m[1] == m[2]; path = m[1].decode(); assert path in owned, path
        old = current[path].splitlines(keepends=True); new = []; cursor = 0; i += 1
        index = None
        while i < len(lines) and not lines[i].startswith((b'@@ ', b'diff --git ')):
            mi = re.fullmatch(rb'index ([0-9a-f]+)\.\.([0-9a-f]+) 100644\n', lines[i])
            if mi: index = mi.groups()
            i += 1
        assert index and blob(current[path]).startswith(index[0].decode()), path
        while i < len(lines) and lines[i].startswith(b'@@ '):
            mh = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i]); assert mh
            start = int(mh[1]); oc = int(mh[2] or b'1'); nc = int(mh[4] or b'1')
            target = start-1 if start else 0
            assert target >= cursor; new.extend(old[cursor:target]); cursor = target
            seen_old = seen_new = 0; i += 1
            while seen_old < oc or seen_new < nc:
                line = lines[i]; prefix = line[:1]; content = line[1:]
                assert prefix in (b' ', b'+', b'-'), (path, line[:80])
                if prefix in (b' ', b'-'):
                    assert old[cursor] == content, (patch.name, path, cursor+1)
                    cursor += 1; seen_old += 1
                if prefix in (b' ', b'+'): new.append(content); seen_new += 1
                i += 1
            assert seen_old == oc and seen_new == nc
        new.extend(old[cursor:]); current[path] = b''.join(new)
        assert blob(current[path]).startswith(index[1].decode()), path
        changed.append(path)
    versions.append(current); commits.append(commit); patch_changes.append({'patch':patch.name,'commit':commit,'changed':changed})
head = versions[-1]
assert {str(f.relative_to(P/'src')) for f in (P/'src').rglob('*.lean')} == set(owned)
assert all((P/'src'/path).read_bytes() == head[path] for path in owned)
changed_final = [p for p in owned if base[p] != head[p]]
result['source_reconstruction'] = {'base':BASE,'head':commits[-1],'patches':patch_changes,
    'owned_snapshots':len(owned),'all_snapshots_exact_after_in_memory_patch_application':True,
    'final_changed_files':len(changed_final),'final_changed_providers':sorted(set(changed_final)&providers)}

assert commits[-1]=='03ead73ab38e74621800367c072f6fd3f0f70991'
EA='ea37eb57c28710271e41533d528309a6d7d00519'
ea=versions[commits.index(EA)]
allrec=[]
for f in sorted(E.glob('checks-*.jsonl')):
    for i,r in enumerate(records(f.name),1):
        r=dict(r);r['_file']=f.name;r['_row']=i;allrec.append(r)
pass_bad=[(r['_file'],r['_row']) for r in allrec if r['status']=='PASS' and not
    (r.get('rc')==0 and r.get('parsed_errors')==0 and r.get('object_fresh_nonempty') and r.get('object_sha256'))]
assert not pass_bad
assert all(r['tree']=='/workspace/cp2/src/.lake/cleanup-part2-oleans' and r['cwd']=='/workspace/cp2/src' for r in allrec)
timed=sorted((r for r in allrec if 'start' in r),key=lambda r:r['start'])
produced={};prereq_issues=[];overlaps=[]
for r in timed:
    for d in r['direct_prerequisites']:
        name=d['module'];key=name.replace('.','/')
        if name.startswith('PFR.'):key='.lake/packages/PFR/'+key
        if not(name.startswith('TCSlib.') or name.startswith('PFR.')):continue
        prior=produced.get(key)
        if prior is None or prior['object_sha256']!=d.get('sha256'):
            prereq_issues.append({'file':r['_file'],'row':r['_row'],'module':r['module'],'dependency':name,
                'observed':d.get('sha256'),'prior':prior['object_sha256'] if prior else None})
    if r['status']=='PASS':produced[r['module']]=r
    elif r['status']=='FAIL':produced.pop(r['module'],None)
for a,b in zip(timed,timed[1:]):
    if b['start']<a['end']:overlaps.append({'left':(a['_file'],a['_row']),'right':(b['_file'],b['_row'])})
stale=[{'module':m,'record_sha':r['source_sha256'],'head_sha':sha(head[m+'.lean'])}
    for m,r in produced.items() if m+'.lean' in head and r['source_sha256']!=sha(head[m+'.lean'])]
replay=records('checks-final.jsonl');delta=records('checks-final-delta.jsonl')
assert len(replay)==583 and len(delta)==53
assert all(r['status']=='PASS' and r['source_sha256']==sha(ea[r['module']+'.lean']) for r in replay)
assert all(r['status']=='PASS' and r['source_sha256']==sha(head[r['module']+'.lean']) for r in delta)
order=(E/'order-final.txt').read_text().splitlines()
graph={p.removesuffix('.lean').replace('/','.'):imports(raw) for p,raw in head.items()}
def affected(old,new):
    changes={p.removesuffix('.lean') for p in owned if old[p]!=new[p]}
    aff=set(changes)
    for m in order:
        if any(n.replace('.','/') in aff for n in graph[m.replace('/','.')]):aff.add(m)
    assert changes<=set(order)
    return [m for m in order if m in aff]
aff=affected(base,ea);daff=affected(ea,head)
assert aff==(E/'affected-final.txt').read_text().splitlines()
assert daff==(E/'affected-final-delta.txt').read_text().splitlines()
assert [r['module'] for r in replay]==aff+['TCSlib','audits/pass-shelat/Checks']
assert [r['module'] for r in delta]==daff+['TCSlib','audits/pass-shelat/Checks']
latest={r['module']:r for r in replay+delta}
assert all(r['status']=='PASS' and r['source_sha256']==sha(head[m+'.lean']) for m,r in latest.items())
log_issues=[]
for r in replay+delta:
    text=(P/r['log'].removeprefix('/workspace/cp2/')).read_text()
    expected=['START '+r['start']+'\n','CMD '+r['command']+'\n',
        'SOURCE '+r['source']+' sha256='+r['source_sha256']+'\n','END '+r['end']+' RC '+str(r['rc'])+' ']
    if not all(x in text for x in expected):log_issues.append((r['_file'] if '_file' in r else r['module']))
result['native']={'ea_head':EA,'ea_replay_records':len(replay),'delta_records':len(delta),'affected':len(aff),'delta_affected':len(daff),
    'both_orders_exact_source_importer_closures':True,'latest_affected_plus_aggregates':len(latest),
    'source_hashes_match_claimed_ea_or_final_versions':True,'latest_affected_match_final_source':True,
    'chronological_direct_prerequisite_digest_issues':prereq_issues,'overlapping_recorded_intervals':overlaps,
    'latest_local_product_count':sum(m+'.lean' in head for m in produced),'latest_local_product_source_mismatches':stale,
    'final_and_delta_log_header_mismatches':log_issues,'single_uninterrupted_full_replay_at_final_head':False}

def ax_table(phase):
    out={};counts=collections.Counter()
    with lzma.open(P/'evidence/census'/phase/'axioms.tsv.xz','rt') as f:
        for line in f:
            tag,home,name,axioms=line.rstrip('\n').split('\t');assert tag=='AXIOMS'
            key=(home,name);counts[key]+=1
            out[key]=tuple(sorted(x.strip() for x in axioms.strip('[]').split(',') if x.strip()))
    assert all(c==1 for c in counts.values())
    return out
ownedmods={p.removesuffix('.lean').replace('/','.') for p in owned}
phase_data={}
for phase in ['baseline','final']:
    ax=ax_table(phase);names={};ownnames={}
    with lzma.open(P/'evidence/census'/phase/'names.tsv.xz','rt') as f:
        for line in f:
            tag,name,kind,status,home,flags=line.rstrip('\n').split('\t');assert tag=='NAME';assert name not in names
            names[name]=(home,kind,status,flags)
            if home in ownedmods:ownnames[(home,name)]=(kind,status,flags)
    assert set(ax)==set(ownnames)
    pairs=[tuple(line.split('\t')[1:]) for line in (P/'evidence/census'/phase/'c3.tsv').read_text().splitlines() if line]
    assert len(pairs)==len(set(pairs)) and all((r[0],r[1]) in ax for r in pairs)
    assert all(names[r[2]][0]==r[3] and names[r[4]][0]==r[5] and r[0]!=r[5] for r in pairs)
    phase_data[phase]=(ax,names,pairs)
    result.setdefault('census',{})[phase]={'all_names':len(names),'owned_axiom_roots':len(ax),'root_sets_exact':True,
        'sorryAx_identities':sorted(':'.join(k) for k,v in ax.items() if 'sorryAx' in v),'C3_pairs':len(pairs),
        'C3_consumer_pairs':sum(r[0].replace('.','/')+'.lean' in consumers for r in pairs)}
bax,bnames,bpairs=phase_data['baseline'];hax,hnames,hpairs=phase_data['final']
result['axiom_delta']={'only_base':len(set(bax)-set(hax)),'only_head':len(set(hax)-set(bax)),
    'changed':[{'home':k[0],'name':k[1],'base':bax[k],'head':hax[k]} for k in sorted(set(bax)&set(hax)) if bax[k]!=hax[k]],
    'same_sorryAx_identities':{k for k,v in bax.items() if 'sorryAx' in v}=={k for k,v in hax.items() if 'sorryAx' in v},
    'C3_removed':len(set(bpairs)-set(hpairs)),'C3_added':len(set(hpairs)-set(bpairs))}
pattern=re.compile(r"'([^'\n]+)' depends on axioms: \[([^\]]*)\]|'([^'\n]+)' does not depend on any axioms",re.S)
checks={}
for phase in ['baseline','final','final-delta']:
    text=(E/phase/'modules/audits/pass-shelat/Checks.log').read_text()
    checks[phase]=collections.Counter((m[1] or m[3],tuple(sorted(a.strip() for a in (m[2] or '').split(',') if a.strip()))) for m in pattern.finditer(text))
assert checks['baseline']==checks['final']==checks['final-delta']
result['Checks_axioms']={'records':sum(checks['final-delta'].values()),'names':len({k[0] for k in checks['final-delta']}),
    'all_three_multisets_equal':True}

def strip_seal(text):
    m=re.search(r'(?ms)^-- CP2 WHOLE-FILE SEAL.*?^-- CP2 END SEAL\n\n',text);assert m
    tail='\nrun_cmd Lean.logInfo "CP2-EOF"\n';assert text.endswith(tail)
    return (text[:m.start()]+text[m.end():])[:-len(tail)].encode(),m

seal_data={};probe_bytes={}
for phase in ['baseline','final','final-strict']:
    meta=load(E/('seal-'+phase+'.json'));rr=records('checks-seal-'+phase+'.jsonl');last={r['module']:r for r in rr}
    count=0;bad=[];files=set()
    with tarfile.open(P/'evidence/probes'/('seal-'+phase+'-probes.tar.xz'),'r:xz') as tf:
        for mem in tf.getmembers():
            if not mem.isfile():continue
            raw=tf.extractfile(mem).read()
            prefix='seal/baseline/' if phase=='baseline' else 'seal-'+phase+'/'
            if not mem.name.startswith(prefix):continue
            key=mem.name.removeprefix(prefix).removesuffix('.lean');files.add(key)
            source,block=strip_seal(raw.decode());target=base if phase=='baseline' else head
            assert source==target[key+'.lean'],key
            rk='.lake/cleanup-part2-probes/seal/'+phase+'/'+key;record=last[rk]
            assert sha(raw)==record['source_sha256'],key
            log=(P/record['log'].removeprefix('/workspace/cp2/')).read_text()
            assert 'START '+record['start']+'\n' in log
            chunks=[tuple(map(int,x)) for x in re.findall(r'CP2-SEAL chunk=(\d+) requested=(\d+) active=(\d+) already=(\d+)',log)]
            assert [c[0] for c in chunks]==list(range(len(chunks)))
            assert all(c[1]==c[2]+c[3] for c in chunks)
            assert sum(c[1] for c in chunks)==meta[key]['requests']
            assert sum(c[2] for c in chunks)==meta[key]['active'] and sum(c[3] for c in chunks)==meta[key]['already_irreducible']
            assert 'CP2-EOF' in log and not re.search(r'CP2-SEAL (?:missing|no home|wrong home|wrong kind|not installed)',log)
            assert meta[key]['valid'] and not meta[key]['harness_errors']
            assert (record['status']=='PASS')==(meta[key]['error_diagnostics']==0)
            probe_bytes[(phase,key)]=raw;count+=1
    assert files==set(meta) and len(files)==98
    overwritten=[]
    for r in rr:
        log=(P/r['log'].removeprefix('/workspace/cp2/')).read_text()
        if 'START '+r['start']+'\n' not in log:
            overwritten.append({'module':r['module'],'start':r['start'],'source_sha256':r['source_sha256'],
                'status':r['status'],'parsed_errors':r['parsed_errors'],'log':r['log']})
    seal_data[phase]=meta
    result.setdefault('seals',{})[phase]={'owners':count,'requests':sum(v['requests'] for v in meta.values()),
        'active':sum(v['active'] for v in meta.values()),'already':sum(v['already_irreducible'] for v in meta.values()),
        'failed_blocks':sum(len(v['failing_declarations']) for v in meta.values()),
        'diagnostics':sum(v['error_diagnostics'] for v in meta.values()),'failed_files':sum(bool(v['diagnostics']) for v in meta.values()),
        'all_probe_bytes_source_hash_status_chunks_EOF_match':True,'overwritten_older_record_logs':overwritten}
changed_providers=set(changed_final)&providers
result['provider_seal_coverage']={'changed_providers':len(changed_providers),
    'sealed_changed_providers':sorted(p for p in changed_providers if p.removesuffix('.lean') in seal_data['final']),
    'missing_changed_providers':sorted(p for p in changed_providers if p.removesuffix('.lean') not in seal_data['final']),
    'required_owner_union':len(consumers|changed_providers)}

def diagnostics(text):
    return [(int(m[1]),int(m[2]),m[3]) for m in re.finditer(r'\.lean:(\d+):(\d+): error[^:]*: ?([^\n]*)',text)]

ctl=(P/'evidence/probes/ControlsUnsealed.source.txt').read_bytes()
sctl=(P/'evidence/probes/ControlsSealed.source.txt').read_bytes()
restored,block=strip_seal(sctl.decode());assert restored==ctl
control_records=records('checks-controls-final2.jsonl')
assert len(control_records)==2
assert control_records[0]['source_sha256']==sha(ctl) and control_records[0]['status']=='PASS'
assert control_records[1]['source_sha256']==sha(sctl) and control_records[1]['status']=='FAIL'
utext=(P/control_records[0]['log'].removeprefix('/workspace/cp2/')).read_text()
stext=(P/control_records[1]['log'].removeprefix('/workspace/cp2/')).read_text()
assert not diagnostics(utext) and 'CP2-CONTROLS-EOF' in utext
prefix=sctl.decode()[:block.start()];seal_lines=len(block[0].splitlines())
end_line=sctl.decode()[:block.end()].count('\n')
se=diagnostics(stext);assert len(se)==7 and 'CP2-EOF' in stext and 'CP2-CONTROLS-EOF' in stext
sites={i:re.search(r'CP2-SITE (N[1-7])',line)[1] for i,line in enumerate(ctl.decode().splitlines(),1) if re.search(r'CP2-SITE (N[1-7])',line)}
hits=collections.Counter()
for line,col,message in se:
    original=line-seal_lines
    assert original in sites,(line,original,sites)
    hits[sites[original]]+=1
assert dict(hits)=={f'N{i}':1 for i in range(1,8)}
chunks=[tuple(map(int,x)) for x in re.findall(r'CP2-SEAL chunk=(\d+) requested=(\d+) active=(\d+) already=(\d+)',stext)]
assert sum(c[1] for c in chunks)==518 and sum(c[2] for c in chunks)==518 and sum(c[3] for c in chunks)==0
result['controls']={'latest_unsealed_rc':0,'latest_sealed_rc':1,'negative_sites_exactly_one_error_each':dict(hits),
    'other_errors':0,'positive_declarations':4,'EOF_and_install_chunks_checked':True,
    'first_unsealed_rc':records('checks-controls-final.jsonl')[0]['rc'],
    'first_attempt_note':'Unsealed and sealed both contain No goals to be solved at old N4; not passing control attempts'}
for phase,name in [('census-final','FinalCensus'),('census-final2','FinalCensus2'),('census-final3','FinalCensus3')]:
    raw=(P/'evidence/probes'/(name+'.source.txt')).read_bytes();rec=records('checks-'+phase+'.jsonl')[0]
    assert sha(raw)==rec['source_sha256'] and rec['status']=='PASS'
    if phase!='census-final':assert (P/'evidence/tools/lean/CensusCore.lean.txt').read_bytes() in raw
    log=(P/rec['log'].removeprefix('/workspace/cp2/')).read_text()
    assert 'AXIOMS-COUNT 20018' in log and 'C3-ROOTS 20018 C3-PAIRS 34' in log
c3ctl=(P/'evidence/probes/C3Controls.source.txt').read_bytes()
c3rec=records('checks-c3controls-final2.jsonl')[0]
assert sha(c3ctl)==c3rec['source_sha256'] and c3rec['status']=='PASS'
assert (P/'evidence/tools/lean/CensusCore.lean.txt').read_bytes() in c3ctl
expected_c3='C3\t_current\tcp2_c3_pos\tTuring.pairDecode.eq_def\tTCSlib.Complexity.TuringMachine.Encoding\tTuring.pairDecode\tTCSlib.Complexity.TuringMachine.Encoding\n'
assert (P/'evidence/census/c3controls/c3.tsv').read_text()==expected_c3
c3log=(P/c3rec['log'].removeprefix('/workspace/cp2/')).read_text();assert 'C3-ROOTS 34 C3-PAIRS 1' in c3log
oldctl=records('checks-c3controls-final.jsonl')[0]
oldlog=(P/oldctl['log'].removeprefix('/workspace/cp2/')).read_text();assert 'C3-ROOTS 0 C3-PAIRS 0' in oldlog
result['C3_controls']={'latest_positive_pairs':1,'latest_negative_pairs':0,'latest_control_roots':34,
    'latest_source_hash_and_core_match':True,'first_attempt_roots':0,'first_attempt_invalid_for_sensitivity':True}

line_map_defects=[]
def canonical_failures(meta,sources,phase):
    output=set();by_location={}
    for path,row in meta.items():
        stack=[];contexts={}
        for number,line in enumerate(mask(sources[path+'.lean'].decode()).splitlines(),1):
            m=re.match(r'^namespace\s+(\S+)',line)
            if m:stack.append(('ns',m[1]))
            elif re.match(r'^(?:noncomputable\s+)?section\b',line):stack.append(('sec',''))
            elif re.match(r'^end\b',line) and stack:stack.pop()
            contexts[number]='.'.join(n for tag,n in stack if tag=='ns')
        for d in row['diagnostics']:
            raw=probe_bytes[(phase,path)];_,block=strip_seal(raw.decode())
            offset=len(block[0].splitlines())
            source_start=d['decl_line_in_probe']-offset
            source_error=d['error_line']-offset
            if d['decl_line_in_source']!=source_start or d.get('error_line_in_source')!=source_error:
                line_map_defects.append({'phase':phase,'path':path,'decl':d['decl'],
                    'probe_decl_start':d['decl_line_in_probe'],'recorded_source_start':d['decl_line_in_source'],
                    'corrected_source_start':source_start,'corrected_source_error':source_error,'probe_sha256':sha(raw)})
            token=d['decl'];assert source_start in contexts,(path,source_start,len(contexts))
            prefix=contexts[source_start]
            full=token.removeprefix('_root_.') if token.startswith('_root_.') else prefix+'.'+token if prefix else token
            key=(path+'.lean',full);output.add(key);by_location[(path+'.lean',source_start)]=key
    return output,by_location
sf,sloc=canonical_failures(seal_data['final'],head,'final')
tf,tloc=canonical_failures(seal_data['final-strict'],head,'final-strict')
bf,bloc=canonical_failures(seal_data['baseline'],base,'baseline')
assert len(sf)==225 and len(tf)==348 and len(bf)==501
result['strict_failure_comparison']={'base':len(bf),'head':len(tf),'only_base':len(bf-tf),'only_head':len(tf-bf),
    'only_head_keys':sorted(tf-bf)}
result['line_map_defect_counts']=dict(collections.Counter(d['phase'] for d in line_map_defects))
(OUT/'corrected-line-maps.json').write_text(json.dumps(line_map_defects,indent=2)+'\n')
keys_in=load(ISSUE/'inputs/observations/canonical-work-units.json')
row_in=load(ISSUE/'inputs/historical/row-dispositions.json')
ledger=load(P/'evidence/maps/dispositions-final.json');assert ledger['revision']==commits[-1]
assert len(ledger['keys'])==509 and len(ledger['rows'])==764
assert {(k['path'],k['canonical']) for k in ledger['keys']}=={(k['path'],k['canonical']) for k in keys_in}
ki={(k['path'],k['canonical']):k for k in keys_in}
bad_key=[];removed=[];unmeasured=[]
def canonical_actual(home,name):
    prefix='_private.'+home+'.'
    if name.startswith(prefix):return name[len(prefix):].split('.',1)[1]
    return name
home_keys=collections.defaultdict(set)
for home,name in hax:home_keys[canonical_actual(home,name)].add(home.replace('.','/')+'.lean')
for k in ledger['keys']:
    original=ki[(k['path'],k['canonical'])]
    assert k['channels']==sorted({o['channel'] for o in original['observations']})
    assert k['observation_ids']==[o['id'] for o in original['observations']]
    path=k.get('moved_to','').replace('.','/')+'.lean' if k.get('moved_to') else k['path']
    exists=path in home_keys[k['canonical']]
    if k['disposition']=='REMOVED_EXACT_MAPPING':
        assert not home_keys[k['canonical']];removed.append((k['path'],k['canonical']));continue
    assert exists,(path,k['canonical'])
    failed=(path,k['canonical']) in sf
    output_open=k['disposition']!='REPAIRED_VERIFIED_AT_FINAL'
    if failed!=output_open:bad_key.append((path,k['canonical'],failed,k['disposition']))
    if 'NOT_MEASURED' in k.get('status',{}).values():unmeasured.append((path,k['canonical']))
    if 'strict_seal' in k.get('status',{}):assert (k['status']['strict_seal']=='FAIL')==((path,k['canonical']) in tf)
row_index={r['row']:r for r in row_in};assert len(row_index)==764
for r in ledger['rows']:
    old=row_index[r['row']]
    assert (r['path'],r['canonical'])==tuple(old['post_s2_work_key'])
    assert r['channel']==old['channel'] and r['detail']==old['detail'] and r['input_row_disposition']==old['row_disposition']
keyset={(k['path'],k['canonical']) for k in ledger['keys']}
result['dispositions']={'keys':509,'rows':764,'input_key_observation_ids_and_row_identity_detail_preserved':True,
    'key_counts':dict(collections.Counter(k['disposition'] for k in ledger['keys'])),
    'row_counts':dict(collections.Counter(r['disposition'] for r in ledger['rows'])),
    'key_status_vs_measured_failure_mismatches':bad_key,'NOT_MEASURED_keys':unmeasured,'removed':removed,
    'extra_failure_blocks':len(sf-keyset),'extra_consumer_blocks':sum(p in consumers for p,n in sf-keyset),
    'extra_provider_blocks':sum(p in providers for p,n in sf-keyset)}
assert not bad_key and not unmeasured

style=P/'evidence/logs/style'
assert set((style/'changed-files.txt').read_text().splitlines())==set(changed_final)
style_results={}
def normalize_lint(text):
    lines=[]
    for line in text.splitlines():
        if not line.strip():continue
        if line.startswith('rc='):continue
        line=re.sub(r'\bline \d+:','line N:',line)
        line=re.sub(r'(?<=\.lean):\d+:',':N:',line)
        line=re.sub(r'\b\d+\b','N',line)
        lines.append(line)
    return collections.Counter(lines)
for stem in ['style_lint','campaign-plain','campaign-check8b']:
    bt=(style/(stem+'-base.txt')).read_text();ht=(style/(stem+'-head.txt')).read_text()
    nb=normalize_lint(bt);nh=normalize_lint(ht)
    style_results[stem]={'new_normalized_lines':list((nh-nb).elements()),'removed_normalized_lines':list((nb-nh).elements()),
        'base_FAIL':sum(l.startswith('FAIL') for l in bt.splitlines()),'head_FAIL':sum(l.startswith('FAIL') for l in ht.splitlines()),
        'base_WARN':sum(l.startswith('WARN') for l in bt.splitlines()),'head_WARN':sum(l.startswith('WARN') for l in ht.splitlines())}
result['style']=style_results

def parsed_components(name):
    out=[];pos=0
    while pos<len(name):
        if name[pos]=='«':end=name.index('»',pos+1);out.append(('s',name[pos+1:end]));pos=end+1
        else:
            end=name.find('.',pos)
            if end<0:end=len(name)
            part=name[pos:end];out.append(('n' if part.isdecimal() else 's',part));pos=end
        if pos<len(name):assert name[pos]=='.';pos+=1
    return out
decoder=json.JSONDecoder()
def ast_name(text,pos=0):
    while text[pos].isspace():pos+=1
    if text.startswith('Lean.Name.anonymous',pos):return [],pos+len('Lean.Name.anonymous')
    assert text[pos]=='(';pos+=1
    op=re.match(r'Lean.Name.(str|num)\s+',text[pos:]);assert op;pos+=op.end()
    parts,pos=ast_name(text,pos)
    while text[pos].isspace():pos+=1
    if op[1]=='str':value,length=decoder.raw_decode(text[pos:]);pos+=length;kind='s'
    else:token=re.match(r'[0-9]+',text[pos:]);assert token;value=token[0];pos+=token.end();kind='n'
    assert text[pos]==')'
    return parts+[(kind,str(value))],pos+1
closure_tables={};closure_checks={}
for phase,sources,names in [('baseline',base,bnames),('final',head,hnames)]:
    rows=collections.defaultdict(dict);deps={}
    with lzma.open(P/'evidence/census'/phase/'closure.tsv.xz','rt') as f:
        for line in f:
            fs=line.rstrip('\n').split('\t')
            if fs[0]=='CLOSURE':
                _,aud,name,home,kind,status,comp=fs
                parts=[tuple(x.split(':',1)) for x in comp[1:-1].split(', ')] if comp!='[]' else []
                assert parsed_components(name)==parts
                assert name not in rows[aud];rows[aud][name]=(home,kind,status,parts)
                nh,nk,ns,nf=names[name];assert (home,kind.split('/')[0],status)==(nh,nk,ns)
            elif fs[0]=='CLOSURE-DEPS':deps[fs[1]]=set(fs[2][1:-1].split(', ')) if fs[2]!='[]' else set()
    sourcegraph={p.removesuffix('.lean').replace('/','.'):imports(raw) for p,raw in sources.items()}
    candidates=collections.defaultdict(set)
    for name,(home,kind,status,flags) in names.items():
        if home.startswith('TCSlib.') and kind=='def' and 'instance,' not in flags and (status!='Lean.ReducibilityStatus.reducible' or 'matcher,' in flags):candidates[home].add(name)
    for aud in ownedmods:
        seen=set();todo=list(sourcegraph[aud])
        while todo:
            x=todo.pop()
            if x in seen:continue
            seen.add(x);todo.extend(sourcegraph.get(x,[]))
        expected_deps={x for x in seen if x.startswith('TCSlib.') and x!=aud}
        assert deps[aud]==expected_deps
        expected=set().union(*(candidates[d] for d in expected_deps)) if expected_deps else set()
        assert set(rows[aud])==expected
    closure_tables[phase]=rows;closure_checks[phase]={'owner_closures':221,'exact_source_import_closure_and_filtered_name_catalog':True}
final_deps=deps
for phase in ['baseline','final','final-strict']:
    table=closure_tables['baseline' if phase=='baseline' else 'final'];requests=0
    for (ph,path),raw in probe_bytes.items():
        if ph!=phase:continue
        text=raw.decode();blockstart=text.index('-- CP2 WHOLE-FILE SEAL')
        assert all(re.fullmatch(r'(?:public\s+)?import\s+.+',line.strip()) or line.strip() in ('prelude','module')
            for line in mask(text[:blockstart]).splitlines() if line.strip())
        found={}
        for line in text.splitlines():
            line=line.strip()
            if not line.startswith('((Lean.Name.'):continue
            tail=re.search(r', ("(?:\\.|[^"\\])*"), ("(?:\\.|[^"\\])*")\)[,\]]?$',line);assert tail
            expr=line[1:tail.start()];parts,end=ast_name(expr);assert end==len(expr)
            key=tuple(parts);assert key not in found;found[key]=(json.loads(tail[1]),json.loads(tail[2]))
        omitted={'Complexity.PolyExpr.eval','Complexity.PolyExpr.eval.match_1','Complexity.PolyExpr.eval._sunfold'} if phase=='final' else set()
        expected={tuple(v[3]):(v[0],v[1]) for n,v in table[path.replace('/','.')].items() if n not in omitted}
        assert found==expected,path
        requests+=len(found)
    result['seals'][phase]['constant_AST_exact_against_closure_and_placement_checked']=True
    assert requests==result['seals'][phase]['requests']
result['closure_checks']=closure_checks
inst=collections.defaultdict(list)
for name,(home,kind,status,flags) in hnames.items():
    if kind=='def' and 'instance,' in flags and home.startswith('TCSlib.'):inst[home].append((name,status))
ipairs=[]
for path in seal_data['final']:
    for home in final_deps[path.replace('/','.')]:ipairs.extend((path,name,home,status) for name,status in inst[home])
semi=[r for r in ipairs if r[3]=='Lean.ReducibilityStatus.semireducible']
result['inherited_instance_filter']={'semireducible_pairs':len(semi),'distinct_semireducible_definitions':len({r[1] for r in semi}),
    'affected_audits':len({r[0] for r in semi}),'reducible_pairs':sum(r[3]=='Lean.ReducibilityStatus.reducible' for r in ipairs),
    'note':'Inherited reviewed implementation filter, not a newly introduced CP1/partial deviation; does include data-valued semireducible defs'}

def atomic_lints(text):
    output=[]
    for line in text.splitlines():
        if not line.startswith(('FAIL','WARN','INFO')):continue
        m=re.match(r'(FAIL|WARN|INFO)\s+(\S+)\s+(.*)',line);assert m
        level,path,message=m.groups()
        if 'without a lemma beside them (check 8): ' in message:
            for name in message.split('(check 8): ',1)[1].split(', '):output.append((level,path,'reader8:'+name))
        elif 'without field equations (check 8b): ' in message:
            for name in message.split('(check 8b): ',1)[1].split(', '):output.append((level,path,'reader8b:'+name))
        else:
            message=re.sub(r'\bline \d+:','line N:',message);message=re.sub(r'\b\d+\b','N',message)
            output.append((level,path,message))
    return collections.Counter(output)
result['atomic_lint_additions']={}
for stem in ['campaign-plain','campaign-check8b']:
    a=atomic_lints((style/(stem+'-base.txt')).read_text());b=atomic_lints((style/(stem+'-head.txt')).read_text())
    result['atomic_lint_additions'][stem]=list((b-a).elements())

oldcp=CP.parent/'cp1/payload'
olddev=[json.loads(l) for l in (oldcp/'evidence/logs/checks-dev.jsonl').read_text().splitlines()]
newdev=records('checks-dev.jsonl')
assert newdev[:len(olddev)]==olddev
logs={str(f.relative_to(P)):f.read_text() for f in P.rglob('*.log') if f.is_file()}
oldfail=[]
for i,r in enumerate(olddev,1):
    if r['status']!='FAIL':continue
    exact=[path for path,text in logs.items() if r['start'] in text and r['source_sha256'] in text]
    oldfail.append({'old_dev_row':i,'module':r['module'],'start':r['start'],'source_sha256':r['source_sha256'],'exact_raw_log_matches':exact})
overwritten=[]
for phase in ['final','final-strict']:
    for r in result['seals'][phase]['overwritten_older_record_logs']:
        exact=[path for path,text in logs.items() if r['start'] in text and r['source_sha256'] in text]
        overwritten.append({**r,'exact_other_raw_log_matches':exact})
(OUT/'log-preservation.json').write_text(json.dumps({'CP1_dev_failures':oldfail,'ea_seal_attempts':overwritten},indent=2)+'\n')
result['log_preservation']={'raw_log_files_scanned':len(logs),'CP1_old_dev_metadata_prefix_unchanged':True,
    'CP1_FAIL_rows':len(oldfail),'CP1_FAIL_rows_with_exact_original_raw_log':sum(bool(r['exact_raw_log_matches']) for r in oldfail),
    'overwritten_ea_seal_attempts':len(overwritten),'overwritten_ea_attempts_with_other_exact_raw_log':sum(bool(r['exact_other_raw_log_matches']) for r in overwritten),
    'qualification':'Absence is limited to received partial-r1; originals could later be provided from elsewhere'}
surface=load(E/'surface-final.json')
tool_unchanged={name:(P/'evidence/tools'/name).read_bytes()==(oldcp/'evidence/tools'/name).read_bytes()
    for name in ['surface_diff.py','surface_map.py','chk.py','mkseal.py','sealrun.py','explicit_scan.py']}
result['map_and_tool_state']={'surface_summary':surface['summary'],'surface_public_summary':surface['summary_public'],
    'tool_bytes_unchanged_from_CP1':tool_unchanged,
    'body_strings_at_truncation_limit':[r['name'] for r in surface['body_changed'] if len(r['base_body'])==400 or len(r['head_body'])==400]}
admb=load(E/'admissions-baseline.json');admh=load(E/'admissions-final.json')
assert admh['rev']==commits[-1]
def admcounts(o):return collections.Counter((r['path'],r['decl'],r['token']) for r in o['occurrences'])
assert admcounts(admb)==admcounts(admh)
result['lexical_admissions']={'head':admh['rev'],'totals':admh['totals'],'per_path_declaration_token_equal':True}

result['limits']=['No incoming script imported/executed','No Lean/cache/build/apps/Git/source mutation',
    'All native/object results reconciled as received data, not independently reproduced','No source-freeze mathematical permission clearance']

(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':result['payload']['files'],'patch_head':commits[-1],'native_source_mismatches':len(stale),
    'native_prerequisite_mismatches':len(prereq_issues),'controls':result['controls'],'ledger_counts':result['dispositions']['key_counts'],
    'strict_only_head':len(tf-bf),'line_map_defects':result['line_map_defect_counts'],'inherited_instance_filter':result['inherited_instance_filter']},indent=2))

