"""Own finite source-shape ledger for all added partial-r1 declarations."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
CP1 = HERE.parent.parent / 'cp1/review-source-scope'
def load(path): return json.loads(path.read_bytes())
def sha(data): return hashlib.sha256(data).hexdigest()
def desc(d): return {k: d[k] for k in ('path', 'canonical', 'kind', 'private', 'start', 'end', 'raw_sha256')}


def main():
    old = load(HERE / 'final-declarations-base.json')
    new = load(HERE / 'final-declarations-head.json')
    added = [d['new'] for d in load(HERE / 'final-declaration-diffs.json') if 'ADDED' in d['flags']]
    previous = {(d['path'], d['canonical']): d for d in load(CP1 / 'final-declarations-head.json')}
    current = {(d['path'], d['canonical']): d for d in new}
    baseline = {(d['path'], d['canonical']): d for d in old}
    roles_path = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/inputs/role-manifest.json')
    roles = {r['path']: r['role'] for r in load(roles_path)['roles']}
    recent = load(HERE / 'new-since-CP1-declarations.json')
    owners = [
        'InSIZE', 'InPPoly', 'PolyBound', 'PolyTimeReducible', 'VerifierHasCircuits',
        'ClosedUnderRace', 'ClosedUnderAnswerIs', 'ClosedUnderMajority', 'ClosedUnderAny', 'ClosedUnderNot',
        'runLit', 'Computes', 'InSigma2', 'InPi2', 'ClosedUnderShiftOr',
        'splitAtLastTrue', 'splitAtLastTrue', 'emitCfg', 'emitCfg', 'emitCfg', 'emitCfg',
        'padFin', 'SingleMessageSecure', 'finCastEquiv', 'finCastEquiv', 'permTrials', 'secProb',
        'decGraph', 'decGraph', 'decColoring', 'prefixLT', 'prefixLE', 'Isomorphic', 'decGraphAt',
        'decGraphAt', 'encInstance', 'instanceG₀', 'instanceG₁', 'Liso', 'Lniso', 'Riso', 'samplePerm',
        'gniProver', 'gniProtocol', 'gniProtocol', 'gniProtocolRep', 'giProtocol', 'giProtocol',
        'giProverRep', 'giVerifierRep', 'giProtocolRep', 'giProtocolRep', 'giProtocolRep', 'giProtocolRep',
        'ThreeColorable', 'edgeOf', 'argX', 'hashPair',
    ]
    assert len(owners) == len(recent) == 58
    checked = {}
    for d, owner in zip(recent, owners):
        namespace = d['canonical'].rsplit('.', 1)[0]
        candidate = current[(d['path'], namespace + '.' + owner)]
        assert (candidate['path'], candidate['canonical']) in baseline
        assert candidate['kind'] in ('def', 'abbrev')
        checked[(d['path'], d['canonical'])] = {'owner': desc(candidate),
            'reader_shape': 'PREDICATE_IFF' if '↔' in d['header'] else 'FUNCTION_CASE_OR_PROJECTION_EQUATION',
            'formula_check': 'MANUALLY_READ_HEADER_BODY_AND_EXISTING_OWNER_SOURCE',
            'public_reader_proof_route': 'decGraph_def then same-file decGraphAt reduction' if d['canonical'].endswith('.decGraph_eq_decGraphAt') else None}
    shared = {
        'Complexity.StateLoop.polyTimeComputable_stateIterate': 'X3 exact fixed-round contract',
        'TCSlib.Cryptography.ColSimMachine.polyTimeComputable_next': 'X9 exact strategy-next contract',
        'TCSlib.Cryptography.ofFn_drop_take': 'X1 exact moved window contract',
        'TCSlib.Cryptography.uexp_le_of_statClose': 'X8 exact average-switch contract',
    }
    finding = 'Complexity.NUPPT.ofPolyTimeUniform_def'
    rows = []
    for d in added:
        key = d['path'], d['canonical']
        assert d['kind'] == 'theorem' and not d['same_line_attributes'] and not d['preceding_attributes']
        if key in previous:
            assert previous[key]['raw_sha256'] == d['raw_sha256']
            basis = 'UNCHANGED_RAW_DECLARATION_FROM_FROZEN_CP1_SOURCE_REVIEW'
        else:
            assert key in checked
            basis = '58_POST_CP1_READER_SOURCE_SHAPES_REVIEWED'
        if d['canonical'] == finding:
            permission = 'MAJOR_PARTIAL_SRC_01_RAW_MACHINE_BODY_READER'
        elif d['canonical'] in shared:
            permission = shared[d['canonical']]
        elif d['canonical'].endswith('.fac_chunk_eq_blocks'):
            permission = 'X1 named private block representation glue'
        else:
            permission = 'X12 ordinary owner reader or exact X1/X4/X6 owner cases'
        rows.append({'declaration': desc(d), 'role': roles[d['path']], 'review_basis': basis,
                     'permission': permission, 'recent_owner_check': checked.get(key),
                     'proof_shape': 'rfl' if d['body'].strip() == 'rfl' else 'Iff.rfl' if d['body'].strip() == 'Iff.rfl' else 'OTHER_TERM_OR_TACTIC',
                     'native_elaboration': 'NOT_RUN', 'acceptance': 'UNKNOWN'})
    disappeared = [desc(d) for key, d in previous.items() if key not in current]
    assert len(disappeared) == 1 and disappeared[0]['canonical'] == 'Turing.MultiTapeTM.step_def'
    assert (disappeared[0]['path'], disappeared[0]['canonical']) not in baseline
    result = {'added_declarations': rows, 'count': len(rows),
        'proof_shapes': dict(Counter(r['proof_shape'] for r in rows)),
        'roles': dict(Counter(r['role'] for r in rows)),
        'retained_CP1_added_declarations_raw_identical': sum(r['review_basis'].startswith('UNCHANGED') for r in rows),
        'post_CP1_readers': len(checked), 'new_def_abbrev_instance_host_module': 0,
        'removed_since_CP1_but_not_at_issue_ancestor': disappeared,
        'machine_body_reader_findings': [r['declaration'] for r in rows if r['permission'].startswith('MAJOR')],
        'execution_permission_limit': 'One-proof-block-per-worker-invocation cannot be authenticated from format patches; no execution-history attestation.',
        'limits': 'Source permission/shape review, not a proof-validity or Rule10-closure claim.'}
    with (HERE / 'reader-permissions.json').open('x') as f: json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'added_declarations'}, indent=2))


if __name__ == '__main__': main()
