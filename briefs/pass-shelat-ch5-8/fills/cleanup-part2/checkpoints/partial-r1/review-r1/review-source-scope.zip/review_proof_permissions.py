"""Own source-permission provenance for existing proof edits; not native acceptance."""
from pathlib import Path
from collections import Counter, defaultdict
import json
import lzma
import re

HERE = Path(__file__).resolve().parent
PAYLOAD = HERE.parent / 'payload'
ISSUED = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/inputs')
def load(p): return json.loads(p.read_bytes())


def main():
    work = {(d['path'], d['canonical']) for d in load(ISSUED / 'observations/canonical-work-units.json')}
    named = {(d['path'], d['canonical']) for d in load(ISSUED / 'scope/named-targets.json')['baseline_named_targets']}
    diffs = load(HERE / 'final-declaration-diffs.json')
    seals = load(PAYLOAD / 'evidence/logs/seal-baseline.json')
    scans = json.loads(lzma.decompress((PAYLOAD / 'evidence/logs/explicit-scan-baseline-v2.json.xz').read_bytes()))
    byfile = defaultdict(list)
    for i, item in enumerate(scans['items'], 1): byfile[item['file']].append((i, item))
    helpers = {'isNil_poly', 'headBit_poly', 'tail_poly', 'not_poly', 'or_poly', 'xor_poly',
               'length_pairFstD_add_pairSndD_le', 'ptc_comp', 'ptcComp', 'negligible_const_zero'}
    # These additional old/new bodies were read in full; exact names, not suffix joins.
    manual = {
        'TCSlib.Cryptography.Candidates.rabinCollection_invProbAt_le': 'X8 rabin_uexp_le user changed to exact shared average theorem',
        'TCSlib.Cryptography.ColZK.polyTimeComputable_next': 'X9 exact old-header alias to moved strategy-next theorem',
        'TCSlib.Cryptography.GI.coinSlice_poly': 'J explicit coinSlice read; both received candidates foreign; same GI namespace owner/reader inspected',
        'TCSlib.Cryptography.GI.gni_verdict_iff': 'J explicit coinSlice read; both received candidates foreign; same GI namespace owner/reader inspected',
        'TCSlib.Cryptography.Games.decodeBitMove_eq_query_iff': 'X4 user of retired private decoder copy',
        'TCSlib.Cryptography.Games.decodeBitMove_of_not_canonical': 'X4 user of retired private decoder copy',
        "TCSlib.Cryptography.OneWay.YaoMachine.yaoRaw'_layout": 'X1 created foreign block-alias conversion; also received J2 seal source-spelling witness',
        'TCSlib.Cryptography.count_true_ofFn': 'X7/G23 exact named count theorem shortened via List.count_ofFn',
        'TCSlib.Cryptography.Candidates.dlb_oStep_round': 'X7/G23 user of retired private dlb_count_ofFn',
        'TCSlib.Cryptography.Candidates.fac_statClose_samplePrimeL': 'X1 named private fac_chunkEquiv retirement/repointing',
        'TCSlib.Cryptography.Candidates.rabin_blum_uexp': 'X8 rabin_uexp_le user changed to exact shared average theorem',
    }
    block_names = {
        'TCSlib.Cryptography.EnsembleLemmas.blocks_apply', 'TCSlib.Cryptography.EnsembleLemmas.blocks_symm_apply',
        'TCSlib.Cryptography.FunFamily.blocks_apply', 'TCSlib.Cryptography.FunFamily.blocks_symm_apply',
        'TCSlib.Cryptography.OneWay.blocksE_apply', 'TCSlib.Cryptography.OneWay.blocksE_symm_apply',
        'TCSlib.Cryptography.OneWay.pushesUniform_pbOf', 'TCSlib.Cryptography.blocksEquiv_symm_apply',
        'TCSlib.Cryptography.glBlocks_apply',
    }
    rows = []; counts = Counter(); unresolved = []
    for item in diffs:
        d = item['old']; n = item['new']
        if not (d and n and d['kind'] in ('theorem', 'lemma') and 'BODY_CHANGED' in item['flags']): continue
        key = d['path'], d['canonical']; reasons = []
        if key in work: reasons.append('ISSUED_KEY')
        if key in named: reasons.append('NAMED_TARGET')
        failures = seals.get(d['path'][:-5], {}).get('failing_declarations', [])
        if d['name'] in failures or d['canonical'] in failures:
            reasons.append('RECEIVED_BASELINE_SEAL_SOURCE_SPELLING')
        explicit = [{'item_index': i, 'class': x['class'], 'ident': x['ident'],
                     'reported_resolved': x.get('resolved'), 'reported_home': x.get('home')}
                    for i, x in byfile[d['path']] if d['start'] <= x['line'] <= d['end'] and
                    x['decl'] in (d['name'], d['canonical']) and x['class'] in ('FOREIGN_TCS_DEF', 'CORE_MATHLIB_DEF')]
        if explicit: reasons.append('RECEIVED_EXPLICIT_FOREIGN_SOURCE_ITEM')
        tokens = sorted(t for t in helpers if re.search(r"(?<![\w'])" + re.escape(t) + r"(?![\w'])", d['body']))
        if tokens: reasons.append('NAMED_RETIRED_HELPER_USER_SOURCE_ROUTE')
        if d['canonical'] in block_names: reasons.append('X1_NAMED_BLOCK_READER_OR_CREATED_FOREIGN_READ_REPAIR')
        if d['canonical'] in manual: reasons.append('EXPLICIT_CONTRACT_OR_SOURCE_ROUTE_MANUALLY_READ')
        if not reasons: unresolved.append([d['path'], d['canonical']])
        counts.update(reasons)
        fields = ('path', 'canonical', 'start', 'end', 'raw_sha256')
        rows.append({'old': {k: d[k] for k in fields}, 'new': {k: n[k] for k in fields},
                     'source_permission_reasons': reasons, 'received_explicit_items': explicit,
                     'retired_helper_source_tokens': tokens, 'manual_route': manual.get(d['canonical']),
                     'native_acceptance': 'NOT_ASSESSED'})
    assert len(rows) == 660 and not unresolved
    result = {'changed_existing_proof_blocks': len(rows), 'rows': rows,
              'unmatched_source_permission_candidates': unresolved, 'overlapping_reason_counts': dict(counts),
              'native_acceptance': 'NOT_ASSESSED',
              'limits': 'Received seal/scan records supply source-route provenance only. No incoming analyzer/classifier or native evidence is accepted merely from this matching; private/generated actual Names and each failing native term remain separate evidence work. Every non-observation named-helper/block route was source-inspected. No per-worker-invocation execution attestation.'}
    with (HERE / 'existing-proof-permissions.json').open('x') as f: json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({'changed_existing_proofs': len(rows), 'unmatched': unresolved,
                      'overlapping_reason_counts': dict(counts)}, indent=2))


if __name__ == '__main__': main()
