"""Own source-only context, graph, admission and permission checks for partial-r1."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
DELIVERY = HERE.parent
PAYLOAD = DELIVERY / 'payload'
CP1 = DELIVERY.parent / 'cp1'
MAIN = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
ISSUED = MAIN / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1'
ANCESTOR = '1aa5506f58f77c215e56d24311ec33bd931cacf1'


def sha(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(path.read_bytes())
def save(name, data):
    with (HERE / name).open('x') as f:
        json.dump(data, f, indent=2); f.write('\n')
def git(*args):
    return subprocess.run(['git', '-C', str(MAIN), *args], check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout
def descriptor(d):
    return {k: d[k] for k in ('path', 'canonical', 'kind', 'private', 'start', 'end', 'raw_sha256')}


def main():
    # Execute only the own reviewed lexical utility definitions, not incoming code.
    text = (HERE / 'validate.py').read_text(); ast.parse(text)
    own = {'__file__': str(HERE / 'validate.py'), '__name__': 'own_review_utilities'}
    exec(compile(text, str(HERE / 'validate.py'), 'exec'), own)
    mask = own['mask']; normalized = own['normalized']
    archived = git('archive', ANCESTOR, 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean')
    base = {}
    with tarfile.open(fileobj=io.BytesIO(archived)) as archive:
        for m in archive:
            if m.isfile() and m.name.endswith('.lean'):
                assert m.name not in base
                base[m.name] = archive.extractfile(m).read()
    role_data = load(ISSUED / 'inputs/role-manifest.json')
    roles = {r['path']: r['role'] for r in role_data['roles']}
    editable = {p for p, role in roles.items() if role != 'CHECK_ONLY'}
    head = base.copy()
    for path in editable:
        head[path] = (PAYLOAD / 'src' / path).read_bytes()
    modules = {p[:-5].replace('/', '.'): p for p in base}
    def imports(data):
        rows = []
        for number, line in enumerate(mask(data.decode()).splitlines(), 1):
            m = re.match(r'^\s*(?:public\s+)?import\s+(.+)', line)
            if m:
                for mod in m.group(1).split(): rows.append({'line': number, 'module': mod})
        return rows
    graphs = {}; missing = []; graph_hashes = {}; source_rows = []; changes = []
    for label, source in (('BASE', base), ('HEAD', head)):
        graph = {}
        for mod, path in sorted(modules.items()):
            imps = imports(source[path]); graph[mod] = [r['module'] for r in imps if r['module'] in modules]
            missing.extend({'revision': label, 'path': path, **r} for r in imps
                           if r['module'].startswith('TCSlib.') and r['module'] not in modules)
            source_rows.append({'revision': label, 'module': mod, 'path': path,
                                'bytes': len(source[path]), 'sha256': sha(source[path]), 'imports': imps})
        order = []; active = set(); done = set()
        def visit(mod):
            assert mod not in active, ('import cycle', label, mod, sorted(active))
            if mod in done: return
            active.add(mod)
            for dep in graph[mod]: visit(dep)
            active.remove(mod); done.add(mod); order.append(mod)
        for mod in sorted(graph): visit(mod)
        graphs[label] = {'edges': graph, 'topological_order': order}
        graph_hashes[label] = sha(json.dumps(graph, sort_keys=True).encode())
    assert not missing
    for path in sorted(editable):
        a = {x['module'] for x in imports(base[path])}; b = {x['module'] for x in imports(head[path])}
        if a != b: changes.append({'path': path, 'added': sorted(b-a), 'removed': sorted(a-b)})
    assert not any(r['module'] == 'Mathlib' for r in source_rows for r in r['imports'])
    old = load(HERE / 'final-declarations-base.json'); new = load(HERE / 'final-declarations-head.json')
    diffs = load(HERE / 'final-declaration-diffs.json')
    oldmap = {(d['path'], d['canonical']): d for d in old}
    newmap = {(d['path'], d['canonical']): d for d in new}
    raw = lambda d: next(s for sep in (':=', 'where', '')
                         if sha((s := d['header'] + sep + d['body']).encode()) == d['raw_sha256'])
    admitted = [d for d in old if re.search(r'\b(?:sorry|admit|sorryAx|axiom)\b', mask(raw(d)))]
    admitted_rows = []
    for d in admitted:
        n = newmap[(d['path'], d['canonical'])]
        assert raw(d) == raw(n)
        admitted_rows.append({'old': descriptor(d), 'new': descriptor(n),
                              'complete_raw_header_body_identical': True})
    token = re.compile(r'(?<![\w\'])\b(sorryAx|sorry|admit|axiom)\b(?![\w\'])')
    global_counts = {}; occurrences = []
    for label, source in (('BASE', base), ('HEAD', head)):
        found = []
        for path, data in source.items():
            for line, code in enumerate(mask(data.decode()).splitlines(), 1):
                for match in token.finditer(code):
                    item = {'revision': label, 'path': path, 'line': line, 'token': match.group(1)}
                    occurrences.append(item); found.append(item)
        global_counts[label] = dict(Counter(x['token'] for x in found))
    assert global_counts['BASE'] == global_counts['HEAD']
    command = re.compile(r'^\s*(?:set_option|attribute|open|namespace|section|end|export|notation|syntax|macro|elab|initialize|run_cmd|variable|variables|include|omit|noncomputable\s+section|#\w+)\b')
    commands = []; attributes = []
    for path in sorted(editable):
        rows = []
        for data in (base[path], head[path]):
            rows.append(Counter(line.strip() for line in mask(data.decode()).splitlines() if command.match(line)))
        added = list((rows[1]-rows[0]).elements()); removed = list((rows[0]-rows[1]).elements())
        if added or removed: commands.append({'path': path, 'added': added, 'removed': removed})
        a = Counter(re.findall(r'@\[[^\n]*?\]', mask(base[path].decode())))
        b = Counter(re.findall(r'@\[[^\n]*?\]', mask(head[path].decode())))
        if a != b: attributes.append({'path': path, 'added': list((b-a).elements()), 'removed': list((a-b).elements())})
    # Enumerated exception permissions are the frozen independent CP1 classification.
    frozen = load(CP1 / 'review-source-scope/manifest.json')
    efile = next(x for x in frozen['outputs'] if x['path'] == 'exception-classification.json')
    eb = (CP1 / 'review-source-scope/exception-classification.json').read_bytes()
    assert sha(eb) == efile['sha256']
    exceptions = json.loads(eb)
    authority = {(x['old_path'], x['canonical']): x for x in exceptions}
    exception_rows = []
    for d in diffs:
        a = d['old']; b = d['new']; flags = d['flags']
        needs_exception = a and ('REMOVED' in flags or 'MOVED' in flags or
                            'HEADER_CHANGED' in flags or
                            (a['kind'] not in ('theorem', 'lemma') and 'BODY_CHANGED' in flags))
        if needs_exception:
            allowed = authority[(a['path'], a['canonical'])]
            exception_rows.append({'canonical': a['canonical'], 'old': descriptor(a),
                                   'new': descriptor(b) if b else None, 'flags': flags,
                                   'permission': allowed['permission']})
    non_theorem_bytes = []
    old_public = {d['canonical']: d for d in old if not d['private']}
    new_public = {d['canonical']: d for d in new if not d['private']}
    for name, a in old_public.items():
        if a['kind'] in ('theorem', 'lemma') or name not in new_public: continue
        b = new_public[name]
        if a['body'] != b['body']:
            assert (a['path'], name) in authority
            non_theorem_bytes.append({'old': descriptor(a), 'new': descriptor(b),
                                      'permission': authority[(a['path'], name)]['permission']})
    assert not attributes and not any('MODIFIER_ATTRIBUTE_CHANGED' in d['flags'] for d in diffs)
    assert all(d['new']['kind'] == 'theorem' for d in diffs if 'ADDED' in d['flags'])
    assert not [d for d in diffs if d['old'] and roles[d['old']['path']] == 'PROVIDER_ONLY']
    save('source-import-fingerprints.json', source_rows)
    save('local-import-graph.json', graphs)
    save('baseline-admitted-declarations.json', admitted_rows)
    save('global-lexical-admissions.json', {'counts': global_counts, 'occurrences': occurrences,
          'outside_editable_source_unchanged': True,
          'sorryAx_note': 'The existing Haves.lean quoted Name metadata test is not a direct admission or an axiom-dependency count.'})
    save('exception-classification.json', exception_rows)
    save('context-import-admission-review.json', {
        'overlay_local_modules': len(modules), 'import_cycles': [], 'missing_local_imports': missing,
        'import_changes': changes, 'graph_sha256': graph_hashes,
        'attribute_command_changes': attributes, 'context_command_changes': commands,
        'global_lexical_counts': global_counts, 'owned_admitted_declarations': len(admitted),
        'every_owned_admitted_header_body_byte_identical': True,
        'public_non_theorem_raw_body_changes': non_theorem_bytes,
        'no_new_simp_attribute': True,
        'limitations': 'Source/graph/lexical checks only; no elaborated types, actual Names, kernel or transitive axioms verified.'})
    print(json.dumps({'modules': len(modules), 'imports_changed_files': len(changes),
                      'context_changes': commands, 'attributes_changed': attributes,
                      'admitted': len(admitted), 'global_counts': global_counts,
                      'exceptions_mapped': len(exception_rows),
                      'public_data_raw_body_changes': len(non_theorem_bytes)}, indent=2))


if __name__ == '__main__': main()
