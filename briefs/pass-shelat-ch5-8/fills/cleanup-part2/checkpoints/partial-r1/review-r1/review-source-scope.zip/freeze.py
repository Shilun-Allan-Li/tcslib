"""Own final hash reconciliation; writes only this new ignored review manifest."""
from pathlib import Path
import ast
import hashlib
import json

HERE = Path(__file__).resolve().parent
PARTIAL = HERE.parent
CP1 = PARTIAL.parent / 'cp1'
ISSUED = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1')
DELIVERY = '0c4d4f60203021f3a3b93f88eaf7c9085c6ab885'
ANCESTOR = '1aa5506f58f77c215e56d24311ec33bd931cacf1'
SOURCE = '03ead73ab38e74621800367c072f6fd3f0f70991'
CP1_MANIFEST = '3850193db405e250cbe27d6321a138a33b88156b57a8bac82ce9da7162f6f384'


def sha(b): return hashlib.sha256(b).hexdigest()
def row(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def load(p): return json.loads(p.read_bytes())


def main():
    assert sha((CP1 / 'review-source-scope/manifest.json').read_bytes()) == CP1_MANIFEST
    frozen = load(CP1 / 'review-source-scope/manifest.json')
    for r in frozen['outputs']:
        b = (CP1 / 'review-source-scope' / r['path']).read_bytes()
        assert len(b) == r['bytes'] and sha(b) == r['sha256']
    intake = load(PARTIAL / 'intake.json')
    assert intake['delivery_commit'] == DELIVERY
    assert (PARTIAL / 'SNAPSHOT-COMPLETE').read_text() == DELIVERY + '\n'
    assert sha((PARTIAL / 'received.zip').read_bytes()) == intake['archive_sha256']
    files = load(PARTIAL / 'files.json')
    for r in files:
        p = PARTIAL / 'payload' / r['path']
        assert not p.is_symlink() and '..' not in Path(r['path']).parts and not Path(r['path']).is_absolute()
        b = p.read_bytes()
        assert len(b) == r['bytes'] and sha(b) == r['sha256']
    for p in HERE.glob('*.py'): ast.parse(p.read_text())
    assert len(load(HERE / 'final-declarations-base.json')) == 8433
    assert len(load(HERE / 'final-declarations-head.json')) == 8629
    assert len(load(HERE / 'raw-public-header-changes.json')) == 3
    assert load(HERE / 'existing-proof-permissions.json')['unmatched_source_permission_candidates'] == []
    assert load(HERE / 'reader-permissions.json')['count'] == 219
    inputs = [PARTIAL / n for n in ('intake.json', 'files.json', 'received.zip', 'SNAPSHOT-COMPLETE')]
    inputs += [PARTIAL / 'payload' / n for n in ('PAYLOAD-SHA256SUMS', 'REPORT.md')]
    inputs += [ISSUED / n for n in ('brief.md', 'public-exceptions.md', 'inputs/role-manifest.json',
               'inputs/owned-files.txt', 'inputs/public-definition-freeze.json',
               'inputs/scope/named-targets.json', 'inputs/observations/canonical-work-units.json',
               'inputs/lexical-admission-occurrences.json', 'inputs/admission-baseline-interpretation.json')]
    inputs += [CP1 / 'intake.json', CP1 / 'files.json', CP1 / 'review-source-scope/manifest.json']
    inputs += [CP1 / 'review-source-scope' / n for n in ('validate.py', 'final-patch-replay.json',
               'final-declarations-head.json', 'manual-semantics-review.json',
               'exception-classification.json', 'report.md')]
    inputs += [PARTIAL / 'payload/evidence/logs' / n for n in ('seal-baseline.json',
               'seal-j2.json', 'explicit-scan-baseline-v2.json.xz')]
    outputs = []
    retained = []
    for p in sorted(HERE.rglob('*')):
        if p.is_file() and p.name != 'manifest.json':
            entry = row(p); entry['path'] = str(p.relative_to(HERE))
            (retained if p.parent != HERE else outputs).append(entry)
    result = {
        'status': 'FROZEN_INTERNAL_SOURCE_REVIEW_INCOMING_FINAL_PARTIAL_NOT_ACCEPTANCE',
        'delivery_commit': DELIVERY, 'source_ancestor': ANCESTOR, 'reported_source': SOURCE,
        'source_review_verdict': {'blockers': 0, 'majors': 1, 'minors': 0},
        'inputs': [row(p) for p in inputs], 'outputs': outputs,
        'retained_invalid_own_extraction_attempts': retained,
        'CP1_source_review_manifest_unchanged': CP1_MANIFEST,
        'payload_files_rehashed': len(files), 'payload_bytes_rehashed': sum(r['bytes'] for r in files),
        'complete_untruncated_maps': ['final-declarations-base.json', 'final-declarations-head.json',
             'final-declaration-diffs.json', 'final-patch-replay.json', 'source-import-fingerprints.json',
             'local-import-graph.json', 'reader-permissions.json', 'existing-proof-permissions.json'],
        'all_native_axiom_seal_control_acceptance': 'NOT_ASSESSED',
        'incoming_programs_executed': False, 'native_cache_build_apps_run': False,
        'source_Git_main_exchange_mutations': False, 'CP1_review_mutation': False,
        'local_API_01_EXCLUDED': '8c047b8bcd3a2793795a02afd6d2d955c80e1806',
        'merge_clearance': False,
    }
    with (HERE / 'manifest.json').open('x') as f: json.dump(result, f, indent=2); f.write('\n')
    for name in ('manifest.json', 'report.md', 'report.json'):
        print(name, sha((HERE / name).read_bytes()))
    print('authoritative_outputs', len(outputs), 'retained_attempt_files', len(retained))


if __name__ == '__main__': main()
