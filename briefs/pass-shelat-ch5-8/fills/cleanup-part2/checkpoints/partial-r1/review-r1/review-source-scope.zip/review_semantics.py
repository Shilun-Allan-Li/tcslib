"""Own exact source checks for the critical permitted representation changes."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
def load(p): return json.loads(p.read_bytes())
def norm(s): return ' '.join(s.split())


def main():
    old = load(HERE / 'final-declarations-base.json')
    new = load(HERE / 'final-declarations-head.json')
    oldpub = {d['canonical']: d for d in old if not d['private']}
    newpub = {d['canonical']: d for d in new if not d['private']}
    name = 'Complexity.NUPPT.ofPolyTime'
    a, b = oldpub[name], newpub[name]
    assert a['header'] == b['header']
    def fields(body):
        matches = list(re.finditer(r'(?m)^  (\w+) :=', body))
        return {m.group(1): body[m.end():matches[i+1].start() if i+1 < len(matches) else len(body)].strip()
                for i, m in enumerate(matches)}
    af, bf = fields(a['body']), fields(b['body'])
    assert set(af) == set(bf) == {'M', 'Ct', 'ct', 'coins', 'adv', 'advice', 'advice_length', 'halts'}
    canon = lambda s: norm(s.replace('((polyTimeComputable_iff f).1 hf)', 'hf'))
    for field in set(af) - {'halts'}: assert norm(af[field]) == canon(bf[field]), field
    old_halts = norm(af['halts'])
    assert old_halts.startswith('fun z => ⟨f z, ') and old_halts.endswith(' z⟩')
    proof = old_halts[len('fun z => ⟨f z, '):-len(' z⟩')]
    assert canon(bf['halts']) == 'fun z => ⟨f z, (FinTM.computesFunInTime_iff _ _ _).1 (' + proof + ') z⟩'
    moved = []
    for suffix in ('toNUPPT', 'ofPolyTime', 'uniform', 'toNUPPT_ofPolyTime'):
        n = 'Complexity.PPT.' + suffix
        assert oldpub[n]['header'] == newpub[n]['header'] and oldpub[n]['body'] == newpub[n]['body']
        moved.append({'canonical': n, 'old': oldpub[n]['path'], 'new': newpub[n]['path'], 'raw_header_body_identical': True})
    generic = 'TCSlib.Cryptography.blocksEquivX'
    assert oldpub[generic]['header'] == newpub[generic]['header'] and oldpub[generic]['body'] == newpub[generic]['body']
    assert '(X : Type*)' in newpub[generic]['header']
    protected = ['TCSlib.Cryptography.Ensemble.copies', 'TCSlib.Cryptography.GGMRed.stateLoopFun']
    exact_named_suffixes = ['distAdv_seed_to_coins', 'col_zk', 'elGamal_correct', 'cons_poly',
                            'exec_four_mul', 'pow_mod_totient_modEq', 'card_units_eq_mul_card_QR']
    unchanged = []
    for d in old:
        if d['canonical'] in protected or any(d['canonical'].endswith('.' + n) for n in exact_named_suffixes):
            matches = [x for x in new if x['canonical'] == d['canonical'] and x['path'] == d['path']]
            assert len(matches) == 1 and d['raw_sha256'] == matches[0]['raw_sha256'], d['canonical']
            unchanged.append({'canonical': d['canonical'], 'path': d['path'], 'raw_sha256': d['raw_sha256']})
    doconly = ['Turing.ModuleHost.Clean.envelope', 'TCSlib.Cryptography.Protocol.transcriptWith_eq',
               'TCSlib.Cryptography.Protocol.outV_eq']
    for n in doconly: assert oldpub[n]['header'] == newpub[n]['header'] and oldpub[n]['body'] == newpub[n]['body']
    result = {
        'NUPPT_ofPolyTime': {
            'header_byte_identical': True, 'old_fields': af, 'new_fields': bf,
            'M_Ct_ct_and_other_data_fields_only_owner_predicate_proof_substitution': True,
            'halts_only_public_computesFunInTime_iff_proof_transport': True,
            'same_witness_reason': 'polyTimeComputable_iff is the existing existential predicate, by Iff.rfl. The old and extracted evidence inhabit definitionally equal propositions; proof irrelevance therefore identifies the choose/choose_spec arguments and preserves the same M/Ct/ct. The halting output witness remains f z, with only its proof read through computesFunInTime_iff. Every other data/cost/advice field is unchanged.',
            'native_probe': 'NOT_RUN'},
        'PPT_moves': moved,
        'generic_blocks_raw_header_body_identical': True,
        'generic_Type_star_and_all_zero_width_zero_count_inputs_retained': True,
        'Bool_and_inverse_alias_formulas': 'Same X1 aliases as the frozen CP1 source review; all retained declarations are raw-identical. No positivity or Nonempty premise added.',
        'protected_declarations_raw_identical': unchanged,
        'named_doc_only_headers_proofs_byte_identical': doconly,
        'remaining_critical_contracts': 'Fixed-round, next, window, G18 and decoder new theorems are raw-identical to the independently reviewed CP1 declarations; original public headers have only the three authorized X1 spelling changes.',
        'scope_limit': 'Source/proof-irrelevance reasoning only. No checked field equality, native elaboration, actual-Name or transitive-axiom attestation.'}
    with (HERE / 'manual-semantics-review.json').open('x') as f: json.dump(result, f, indent=2); f.write('\n')
    print('CRITICAL_SOURCE_CHECKS_OK', len(unchanged), 'protected declarations')


if __name__ == '__main__': main()
