#!/usr/bin/env python3
"""Own source/hash review only; never execute delivered tools or Lean."""
from pathlib import Path
import hashlib,json,re,subprocess
D=Path(__file__).resolve().parent;PART=D.parent;P=PART/'payload'
W=D.parents[4];assert (W/'policy.md').is_file()
CP1=PART.parent/'cp1';A='1aa5506f58f77c215e56d24311ec33bd931cacf1'
C=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1')
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def ck(name,value,detail=None):
 checks.append({'name':name,'passed':bool(value),'detail':detail});assert value,name
def text(rel):return (P/'src'/rel).read_text()
def base(rel):return subprocess.run(['git','show',A+':'+rel],cwd=W,capture_output=True,check=True).stdout.decode()
def decl(s,name):
 m=re.search(r'(?m)^(?:(?:private|noncomputable|protected)\s+)*(?:theorem|lemma|def)\s+'+re.escape(name)+r'\b',s);assert m,name
 tail=s[m.start():];end=re.search(r'(?m)^/--|^/-!|^end\b|^namespace\b',tail)
 return tail[:end.start() if end else len(tail)].rstrip()
report=P/'REPORT.md';ck('REPORT_FULL_IDENTITY',sha(report.read_bytes())=='dca5f8e5961b83b402a6255ff4afd4273a555e3d04a9f1fb391fa15acdb8b57e',{'lines':len(report.read_text().splitlines()),'bytes':report.stat().st_size})
patches=sorted((P/'patches').glob('*.patch'));ck('THIRTEEN_PATCHES',len(patches)==13)
last=patches[-1].read_text().splitlines()[0].split()[1]
ck('REPORTED_HEAD_MATCHES_PATCH13',last=='03ead73ab38e74621800367c072f6fd3f0f70991')
roles={r['path']:r for r in json.loads((C/'inputs/role-manifest.json').read_text())['roles']}
provider='TCSlib/Complexity/ClassNP/PolyTime.lean';ck('POLYTIME_PROVIDER_ONLY',roles[provider]['role']=='PROVIDER_ONLY',roles[provider])
provider_declarations=[]
for name in ['polyTimeComputable_id','PolyTimeComputable.output_length_le','PolyTimeComputable.comp']:
 old,new=decl(base(provider),name),decl(text(provider),name)
 ck('PROVIDER_UNCHANGED_'+name,old==new)
 provider_declarations.append({'name':'Complexity.'+name,'header_and_proof_sha256':sha(new.encode()),'source_unchanged':True})
for rel in ['TCSlib/Complexity/TuringMachine/Build/Primitives.lean','TCSlib/Complexity/Randomized/Primitives.lean']:
 ck('PROVIDER_ROLE_'+rel,roles[rel]['role']=='PROVIDER_ONLY')
ck('ENCODINGMACHINES_CONSUMER',roles['TCSlib/Cryptography/ZeroKnowledge/EncodingMachines.lean']['role']=='CONSUMER')
# Prior patch context compatibility: check old hunk lines as data, not by applying a tool.
compat=[]
for stem,rel in [('01-hardcore','TCSlib/Cryptography/Asymptotic/HardCore.lean'),('02-hardcore-lemmas','TCSlib/Cryptography/Asymptotic/HardCoreLemmas.lean'),('03-hardcore-collection','TCSlib/Cryptography/Asymptotic/HardCoreCollection.lean')]:
 f=CP1/'review-api/fix-proposals'/(stem+'.patch');lines=f.read_text().splitlines(keepends=True)
 hunks=[];old=[]
 for l in lines:
  if l.startswith('@@'):
   if old:hunks.append(''.join(old));old=[]
  elif l.startswith(('---','+++')):continue
  elif l.startswith((' ','-')):old.append(l[1:])
 if old:hunks.append(''.join(old))
 s=text(rel);pair=('NUPPT.ofPolyTimeUniform_def,\n      NUPPT.output_ofPolyTime' if stem=='01-hardcore' else 'NUPPT.ofPolyTimeUniform_def, NUPPT.output_ofPolyTime')
 ck('ORIGINAL_READER_PAIR_STILL_UNIQUE_'+stem,s.count(pair)==1)
 result=s.replace(pair,'NUPPT.output_ofPolyTimeUniform',1)
 compat.append({'path':rel,'prior_patch_sha256':sha(f.read_bytes()),'current_source_sha256':sha(s.encode()),'old_full_hunk_match_counts':[s.count(h) for h in hunks],'old_reader_pair_unique':True,'mechanical_reader_only_result_sha256':sha(result.encode()),'status':'REPLACEMENT_REMAINS_APPLICABLE_WITH_CURRENT_CONTEXT; UNAPPLIED_UNCOMPILED'})
ppt='TCSlib/Complexity/Randomized/PPT.lean';s=text(ppt);old=(CP1/'payload/src'/ppt).read_text()
# The owner alias and its formula docstring are byte-identical, though shifted by inserted readers.
pat=r'/-- The defining equation of `ofPolyTimeUniform`:[\s\S]*?\n\s*\(ofPolyTime hf coins \(\.const 0\) \(fun _ => \[\]\) \(fun _ => by simp\)\) := rfl\n'
b=re.search(pat,old);n=re.search(pat,s);ck('OWNER_ALIAS_IDENTICAL_AND_PRESENT',b is not None and n is not None and b.group()==n.group())
ck('OWNER_OUTPUT_CONTRACT_PRESENT','theorem output_ofPolyTimeUniform ' in s)
uses=[]
for f in sorted((P/'src').rglob('*.lean')):
 for i,l in enumerate(f.read_text().splitlines(),1):
  if 'ofPolyTimeUniform_def' in l:uses.append({'path':str(f.relative_to(P/'src')),'line':i,'text':l})
ck('SAME_ALIAS_PLUS_THREE_USES',len(uses)==4,uses)
prop=json.loads((D/'01-encodingmachines-unaryMul.json').read_text());ck('PROPOSAL_PINNED_SOURCE',sha((P/'src'/prop['repository_path']).read_bytes())==prop['source_sha256'])
ck('PROPOSAL_HEADER_UNCHANGED',prop['scope']['existing_header_preserved'])
ck('PROPOSAL_ACYCLIC',not prop['acyclic_import_check']['EncodingMachines_reachable'] and not prop['acyclic_import_check']['any_Cryptography_reachable'])
# Formula sanity for the existing published length route, including zeros and arbitrary projection lengths.
cases=0
for f in range(8):
 for g in range(8):
  a=[True]*f;b=[True]*g
  assert len(b*f)==f*g and [True]*len(b*f)==[True]*(f*g)
  cases+=1
ck('UNARY_LENGTH_ZERO_SANITY',True,{'length_pairs':cases,'both_zero_included':True})
reviewed=['TCSlib/Complexity/ClassP/BinaryArith/Loops.lean','TCSlib/Complexity/ClassNP/PolyTime.lean','TCSlib/Complexity/ClassNP/PolyTimePairing.lean','TCSlib/Complexity/Randomized/Primitives.lean','TCSlib/Complexity/Randomized/Repetition.lean','TCSlib/Complexity/Randomized/Build/UnaryMul.lean','TCSlib/Complexity/Randomized/Build/IterateFind.lean','TCSlib/Complexity/TuringMachine/Build/Primitives.lean','TCSlib/Complexity/TuringMachine/Finite.lean','TCSlib/Cryptography/ZeroKnowledge/EncodingMachines.lean','TCSlib/Cryptography/Asymptotic/OneWayLemmas.lean','TCSlib/Cryptography/Asymptotic/GGMReduction.lean','TCSlib/Cryptography/ZeroKnowledge/GraphIsomorphism/EfficiencyRep.lean',ppt,'TCSlib/Cryptography/Asymptotic/HardCore.lean','TCSlib/Cryptography/Asymptotic/HardCoreLemmas.lean','TCSlib/Cryptography/Asymptotic/HardCoreCollection.lean']
inputs=[report,C/'brief.md',C/'public-exceptions.md',C/'inputs/role-manifest.json',P/'evidence/maps/residual-final.json',P/'evidence/logs/seal-final.json',P/'evidence/probes/Controls-attempt1.source.txt',P/'evidence/probes/ControlsUnsealed.source.txt',W/'policy.md']
value={'status':'BOUNDED_READ_ONLY_SOURCE_VALIDATION_NOT_NATIVE','source_ancestor':A,'reported_worker_head':last,'checks':checks,'provider_original_proofs':provider_declarations,'API01_current_uses':uses,'API01_prior_patch_compatibility':compat,'owner_alias_source_line':s[:n.start()].count('\n')+1,'owner_alias_block_sha256':sha(n.group().encode()),'reviewed_source_fingerprints':{r:sha((P/'src'/r).read_bytes()) for r in reviewed},'input_hashes':{str(f):sha(f.read_bytes()) for f in inputs},'limits':['No received program execution, native/cache/build/app command, source edit or Git mutation.','One uncompiled/unapplied proof proposal only: EncodingMachines.unaryMul_poly.','No proof of impossibility for the still-unresolved inline-match sites; no blanket E-API ruling.','Source review does not validate the full worker seal/native/census claims or finalize the job.']}
(D/'validation.json').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':all(x['passed'] for x in checks),'API01_hunk_matches':compat,'validation_sha256':sha((D/'validation.json').read_bytes())},indent=2))
