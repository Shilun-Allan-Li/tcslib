import Lean
import TCSlib.Cryptography.Games.Efficiency
import TCSlib.Cryptography.Games.Bridges.Machines
import TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM.Run
import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF
import TCSlib.Cryptography.Asymptotic.Universal

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def checkedLocalDependencies (env : Environment) (name : Name) : Array (Name × Name) := Id.run do
  let mut todo := #[name]
  let mut seen : NameSet := {}
  let mut results := #[]
  while !todo.isEmpty do
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    let some idx := env.getModuleIdxFor? n | continue
    let owner := env.header.moduleNames[idx.toNat]!
    unless owner.toString.startsWith "TCSlib." do continue
    results := results.push (n, owner)
    let some c := env.checked.get.find? n | continue
    for dep in c.getUsedConstantsAsSet do
      unless seen.contains dep do
        todo := todo.push dep
  return results

def routeRoots : Array Name := #[
  `Complexity.NUPPT.coinLen_eq,
  `Complexity.NUPPT.exists_comp,
  `Complexity.NUPPT.exists_split,
  `Complexity.NUPPT.exists_withAdvice,
  `Complexity.NUPPT.toCompOn_eq,
  `Complexity.NUPPT.toCompOn_costBoundedBy,
  `TCSlib.Cryptography.decodeFin_eq_some_iff,
  `TCSlib.Cryptography.decodeOracleMove_of_ne,
  `TCSlib.Cryptography.decodeOracleMove_pairEncode_false_of_length_ne,
  `TCSlib.Cryptography.Games.decodeBitMove_of_not_canonical,
  `TCSlib.Cryptography.Games.simulate_costBoundedBy,
  `TCSlib.Cryptography.Games.OracleComp.CostBoundedBy.bind,
  `TCSlib.Cryptography.GGMRed.stateLoopFun_poly,
  `TCSlib.Cryptography.GGMRed.stateLoopFun_eval,
  `TCSlib.Cryptography.GGMRed.pairEncode_append_right,
  `TCSlib.Cryptography.Games.exists_handlerMachine,
  `TCSlib.Cryptography.Games.exists_interactiveHandlerMachine,
  `TCSlib.Cryptography.Games.exists_toCompOn_of_toComp,
  `TCSlib.Cryptography.Games.exists_toOracleAdversary_of_bitCodec,
  `TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2,
  `TCSlib.Cryptography.PadQuad.exists_linearTime_gStr,
  `TCSlib.Cryptography.exists_canonizerExp]

run_cmd do
  let env ← getEnv
  for n in routeRoots do
    unless env.contains n do
      throwError "Missing named declaration {n}"
    let deps := checkedLocalDependencies env n
    let row := Json.mkObj [
      ("root", toJson n.toString),
      ("dependencies", toJson (deps.map fun (d, m) => (d.toString, m.toString)))]
    liftIO <| IO.println ("PROOF_ROUTE " ++ row.compress)
