from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess
import sys
import zipfile

out, previous = (Path(a) for a in sys.argv[1:])
archive_root = Path("briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1")
archive = archive_root / "11-final-read-ledger.zip"
expected = next(line.split()[0] for line in (archive_root / "SHA256SUMS").read_text().splitlines()
                if line.endswith(archive.name))
assert sha256(archive.read_bytes()).hexdigest() == expected
with zipfile.ZipFile(archive) as z:
    ledger = json.loads(z.read("deferred-read-ledger-final-r1.json"))
assert not ledger["partial"] and not ledger["needs_review"]
routes = [json.loads(l.removeprefix("PROOF_ROUTE ")) for l in (out / "dependency-probe.log").read_text().splitlines()
          if l.startswith("PROOF_ROUTE ")]
assert len(routes) == 22
primary = routes[:15]
selected = {n: home for row in primary for n, home in row["dependencies"]}
used = []
for row in ledger["current_observations"]:
    ns = {entry["name"]["display"] for entry in row.get("head_actual", [])}
    for n in ns & set(selected):
        used.append({"id": row["id"], "name": n, "home": selected[n], "channel": row["channel"],
                     "prior_path": row["path"], "prior_line": row.get("head_line"),
                     "disposition": row["disposition"], "old_statement_sha256": next(
                         a["type_sha256"] for a in row["head_actual"] if a["name"]["display"] == n)})
direct_roots = {r["root"] for r in primary}
direct = [r for r in used if r["name"] in direct_roots]
assert any(r["id"] == "SEAL-0207" for r in direct)
for r in direct:
    print("Direct route citation", r["id"], r["name"], r["home"])
print(len({r["id"] for r in used}), "historical rows on",
      len({r["name"] for r in used}), "declarations reached from", len(primary), "existing public APIs")
print("Channels:", dict(Counter(r["channel"] for r in used)))
print("Scope is the intersection with the accepted #248 ledger. Current probes check client use.")
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
plan = json.loads((previous / "PLAN.json").read_bytes())
graph = plan["graph"]
def closure(roots):
    seen = set()
    def visit(m):
        if m in seen:
            return
        seen.add(m)
        for d in graph[m]:
            visit(d)
    for r in roots:
        visit(r)
    return seen
scopes = {
    "efficiency_issue_roots": [
        "TCSlib/Cryptography/Games/Efficiency",
        "TCSlib/Cryptography/Games/Bridges",
        "TCSlib/Cryptography/Pseudorandom/Functions/Asymptotic/GGM/Run",
        "TCSlib/Cryptography/Encryption/PrivateKey/FromPRF/ReductionMachine",
    ],
    "separation_import_root": ["TCSlib/Cryptography/Encryption/PrivateKey/OracleFromPRF"],
    "levin_import_roots": [
        "TCSlib/Cryptography/Asymptotic/Universal",
        "TCSlib/Cryptography/Asymptotic/UniversalPadding",
    ],
}
for tag, roots in scopes.items():
    print(tag, len(closure(roots)), "local modules")
order = [m for m in plan["order"] if m in closure(scopes["efficiency_issue_roots"])]
assert len(order) == len(closure(scopes["efficiency_issue_roots"]))
pattern = re.compile(r"^import\s+(Mathlib\.[\w.]+)\b", re.M)
roots = sorted({dep for m in order for dep in pattern.findall(Path(m + ".lean").read_text())})
(out / "order.txt").write_text("\n".join(order) + "\n")
(out / "roots.txt").write_text("\n".join(roots) + "\n")
(out / "PROOF-DEPENDENCIES.json").write_text(json.dumps({
    "base": head, "library_objects_from": plan["head"], "ledger_sha256": expected,
    "scopes": {name: sorted(closure(r)) for name,r in scopes.items()},
    "named_api_ledger_overlap": sorted(used, key=lambda r: (r["id"],r["name"])),
    "direct_named_api_overlap": direct,
}, indent=2) + "\n")
print(len(order), "local modules and", len(roots), "direct Mathlib roots in the efficiency issue order")
