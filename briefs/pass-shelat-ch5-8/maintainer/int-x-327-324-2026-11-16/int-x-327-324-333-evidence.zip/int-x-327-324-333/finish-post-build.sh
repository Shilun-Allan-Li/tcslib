#!/usr/bin/env bash
# int-x-327-324-333 post-build steps (after build-x1/runner-rc.txt exists; before the restore). No Lean process except step 6.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-327-324-333; R=/home/user/tcslib; W=$SP/wt-int-x; TR=$SP/dl-oleans-2
X1=ffde82d6533d5b3c3fc50b7ceb5a4178fa2322c3; T=8c42b40d789a798e39e9a111dabf3877303f6ae9
cd $E
python3 -I tools-used/permod.py build-x1 build-x1/per-module.tsv > build-x1/permod.out; cat build-x1/permod.out
python3 -I tools-used/review/buildsum.py build-x1/results.jsonl > build-x1/buildsum.txt; head -1 build-x1/buildsum.txt
cp state/state.json state/state-before-x1.json
python3 -I tools-used/stateplan.py update $R $X1 state/state.json build-x1/results.jsonl $TR | tee build-x1/state-update.out
cp state/state.json state/state-after-x1.json
python3 -I tools-used/stateplan.py check $R $X1 order-x1/order.txt state/state.json $TR build-x1/statecheck.txt
mkdir -p records tree-final
cat state/base-records-from-int-317.jsonl build-x1/results.jsonl > records/records-final.jsonl
python3 -I tools-used/treecheck_ml.py $TR order-x1/order.txt records/records-final.jsonl $R $X1 tree-final/snapshot-X1.txt > tree-final/tree-check-X1.txt; cat tree-final/tree-check-X1.txt
python3 -I tools-used/tipcensus.py $R $T admissions/census-T-8c42b40d-all.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=build-x1/results.jsonl
python3 -I tools-used/tipcensus.py $R $X1 admissions/census-X1-ffde82d6.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=build-x1/results.jsonl
diff <(grep -v TOTAL admissions/census-T-8c42b40d-all.txt | sed 's/  \[.*//') <(grep -v TOTAL admissions/census-X1-ffde82d6.txt | sed 's/  \[.*//') > admissions/census-T-vs-X1.diff; cat admissions/census-T-vs-X1.diff | grep -v '^.  0 ' | head -40
python3 -I tools-used/refunion2.py build-x1/results.jsonl build-x1/refunion g39-final-b=refs/g39-records-final-b.jsonl int331-records-final=state/int331-records-final.jsonl int331-b1=refs/int331-build-1-results.jsonl int331-b2=refs/int331-build-2-results.jsonl int331-b3=refs/int331-build-3-results.jsonl int331-b4=refs/int331-build-4-results.jsonl > build-x1/refunion.txt; tail -1 build-x1/refunion.txt
python3 -I tools-used/logcheck.py build-x1/results.jsonl build-x1/logcheck.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl g39=refs/g39-records-final-b.jsonl int331-b2=refs/int331-build-2-results.jsonl
echo "zero-byte files under the tree: $(find $TR -type f -size 0 | wc -l)" | tee tree-final/zero-byte-files.txt; find $TR -type f -size 0 >> tree-final/zero-byte-files.txt
