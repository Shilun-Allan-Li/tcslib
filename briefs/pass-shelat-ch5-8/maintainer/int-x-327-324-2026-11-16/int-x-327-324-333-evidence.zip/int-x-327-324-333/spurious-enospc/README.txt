ENOSPC incident, build X1 (first launch 08:54:34 UTC). At about 09:00 UTC another job's build on the shared disk briefly filled
it. The runner stopped at queue position 71, TCSlib/Complexity/CircuitComplexity/KarpLiptonSearchFamily, rc 1 at 09:00:12 with
an EMPTY log (not even lean_check_tree.sh's FAIL lines) and a 0-byte olean; build-x1/runner-rc.txt was also written 0 bytes
(the `echo "runner rc=..."` failed): consistent with ENOSPC, not a Lean failure.
Per the maintainer's instruction every record whose run overlapped 08:57:00-09:01:00 UTC (queue positions 28-71: Advice ..
KarpLiptonSearchFamily, 44 modules, a contiguous tail of the run) plus the runner's stopped_at line is treated as spurious:
  records.jsonl               the 45 removed lines (44 module records + stopped_at), verbatim;
  results-original.jsonl      build-x1/results.jsonl as it was before the removal (73 lines);
  runner-rc-original.txt      the 0-byte runner-rc.txt; launched-utc-original.txt, current-pid-original.txt: first launch;
  mods/                       the 44 module logs of those records (moved here from build-x1/mods/);
  deleted-oleans.txt          SHA-256, size and path of the 44 oleans deleted from dl-oleans-2 before the resume
                              (KarpLiptonSearchFamily 0 bytes).
Note (before deletion): the 43 rc-0 spurious records each had an olean and log byte-identical to a same-source reference record
(base int-317 / int-stmt-331-333 records-final / LE-gate39 records-final-b), and so did the 28 kept records (positions 0-27,
all ended before 08:57:00). The queue was resumed from position 28 (Advice) with runner.py's start-module argument; the rebuilt
records are appended to build-x1/results.jsonl.
