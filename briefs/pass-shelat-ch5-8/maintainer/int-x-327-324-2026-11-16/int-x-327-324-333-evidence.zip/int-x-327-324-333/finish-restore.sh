#!/usr/bin/env bash
# int-x-327-324-333 restore of dl-oleans-2 to snapshot 457ba704... (run only when no Lean process of this job is running).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-327-324-333
bash $E/tools-used/restore_x.sh $SP/dl-oleans-2 $SP/dl-intx-backup $E | tee $E/restore/restore.out
sha256sum $E/tree/snapshot-pre.txt $E/tree/snapshot-post.txt | tee $E/restore/snapshot-hashes.txt
# only after SNAPSHOT EQUAL: rm -r $SP/dl-intx-backup; git -C /home/user/tcslib worktree remove --force $SP/wt-int-x; git -C /home/user/tcslib worktree prune
