#!/usr/bin/env bash
# build X1 (int-x-327-324-333): runner.py at X1 ffde82d6 in the worktree, queue plan-x1/queue.txt, tree dl-oleans-2
export PATH=$HOME/.elan/bin:$PATH
date -u +%FT%TZ > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-327-324-333/build-x1/launched-utc.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-327-324-333/tools-used/review/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-int-x /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-327-324-333/plan-x1/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-327-324-333/build-x1
echo "runner rc=$?" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-327-324-333/build-x1/runner-rc.txt
