import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("campaign_style_lint", Path("scripts/campaign_style_lint.py"))
lint = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lint)
path = Path("TCSlib/Cryptography/Pseudorandom.lean").resolve()
lint.check_file(path)
lint.check_facade(path)
print(json.dumps(lint.findings, indent=2))
