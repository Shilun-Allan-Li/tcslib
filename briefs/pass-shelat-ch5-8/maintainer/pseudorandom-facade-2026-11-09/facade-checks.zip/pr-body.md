## Change

- Map the finite and asymptotic pseudorandomness routes in the existing entry point.
- Link the one-way-permutation construction, next-bit characterization, PRG stretch extension and GGM to their current declarations.
- Point to the polynomial-time evaluators and reduction machines, and trace the PRG and PRF constructions into the two private-key encryption results.

The diff is a module docstring edit. It preserves the facade's import graph and declaration set.

## Verification

- The facade, library root, and campaign Checks pass the pinned one-module checks.
- Standalone finite and asymptotic probes resolve every named declaration and print the headline axiom dependencies.
- The plain style check has zero findings. The campaign style comparison has zero new findings. The five inherited transitive-import findings correspond to children imported through the existing Functions facade.

The next slice moves the asymptotic PRG contract after this PR lands.
