"""Replay the documentation change from the verified ElGamal inputs."""

from hashlib import file_digest
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from time import monotonic

area, worktree, integration, campaign = (Path(arg).resolve() for arg in sys.argv[1:])
previous = area.parent / "pke-pilot-elgamal-20261109" / "native"
record = campaign / "briefs/pass-shelat-ch5-8/maintainer/pke-pilot-elgamal-2026-11-09/VERIFICATION.json"
entry = "TCSlib/Cryptography/Pseudorandom"
checker = "scripts/lean_check_tree.sh"
checks = "audits/pass-shelat/Checks"
source = worktree / (entry + ".lean")
base = (area / "base.txt").read_text().strip()
head = (area / "head.txt").read_text().strip()
tree = area / "r2" / "oleans"
logs = area / "r2" / "logs"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=worktree, text=True).strip()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


def check(module, root=worktree, *, expected=None):
    tag = module.replace("/", "__") if root == worktree else module.rsplit("/", 1)[-1]
    out = logs / (tag + ".log")
    start = monotonic()
    with out.open("x") as stream:
        rc = subprocess.run(["bash", checker, module],
                            cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
    elapsed = round(monotonic() - start, 2)
    assert rc == 0, f"{module} returned {rc}. See {out}"
    digest = sha(tree / (module + ".olean"))
    if expected is not None:
        assert digest == expected, f"{module} differs from the accepted object"
    print(f"{module} passed ({elapsed}s)", flush=True)
    return {"module": module, "seconds": elapsed, "object_sha256": digest,
            "log_sha256": sha(out), "matches_predecessor": expected is not None}


assert git("rev-parse", "HEAD") == head and git("rev-parse", "HEAD^") == base
assert not git("status", "--porcelain")
assert git("diff", "--name-only", base, head) == entry + ".lean"
assert source.read_bytes() == (area / "head.lean").read_bytes()
base_source = (area / "base.lean").read_bytes()
assert base_source == subprocess.check_output(
    ["git", "show", base + ":" + entry + ".lean"], cwd=worktree)
marker = b"/-!\n# Pseudorandomness\n"
assert source.read_bytes().count(marker) == base_source.count(marker) == 1
assert source.read_bytes().split(marker)[0] == base_source.split(marker)[0]
assert source.read_bytes().rstrip().endswith(b"-/")

verified, plan, previous_result = read(record), read(previous / "PLAN.json"), read(previous / "RESULT.json")
assert previous_result["passed"] and verified["passed"]
assert previous_result["head"] == plan["head"] == verified["head"]
for file in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / file) == verified["artifact_sha256"]["native/" + file], file
assert not git("diff", "--name-only", verified["head"], base, "--", "*.lean",
               "lean-toolchain", checker, "lakefile.lean", "lakefile.toml", "lake-manifest.json")
assert sha(Path(plan["toolchain"])) == plan["toolchain_sha256"]
assert sha(worktree / checker) == sha(integration / checker) == plan["checker_sha256"]
assert (integration / "lean-toolchain").read_bytes() == (worktree / "lean-toolchain").read_bytes()
assert (integration / ".lake/packages").resolve() == (worktree / ".lake/packages").resolve()
assert not (worktree / ".lake/build/lib/lean").is_dir()
assert not (integration / ".lake/build/lib/lean").is_dir()
assert shutil.disk_usage(area).free >= 12 * 1024**3

products = read(previous / "PRODUCTS.json")
old_tree = Path(plan["tree"])
assert old_tree.resolve() == (previous / "oleans").resolve()
affected = {entry}
for module in plan["order"]:
    if affected.intersection(plan["graph"][module]):
        affected.add(module)
assert affected == {entry, "TCSlib"}
tree.mkdir(parents=True)
logs.mkdir()
for module in plan["order"]:
    path = worktree / (module + ".lean")
    row = products[module]
    if module == entry:
        assert sha(area / "base.lean") == row["source_sha256"]
    else:
        assert sha(path) == row["source_sha256"] == plan["source_digests"][module], module
    assert row["direct_local"] == {
        item: products[item]["object_sha256"] for item in plan["graph"][module]
    }, module
    if module not in affected:
        copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    path = Path(row["path"])
    if path.is_relative_to(old_tree):
        copy(path, tree / path.relative_to(old_tree), row["sha256"])
    else:
        assert sha(path) == row["sha256"], path
if (old_tree / "PFR").is_symlink():
    (tree / "PFR").symlink_to(os.readlink(old_tree / "PFR"), target_is_directory=True)
print(f"Verified {len(products) - len(affected)} retained local objects and "
      f"{len(plan['external'])} external objects", flush=True)

env = os.environ.copy()
env["TCSLIB_OLEANS"] = str(tree)
env["PATH"] = f"{Path.home() / '.elan/bin'}:{env['PATH']}"
reproduce = {
    "TCSlib/Cryptography/Pseudorandom/Generators",
    "TCSlib/Cryptography/Pseudorandom/Functions/GGM",
    "TCSlib/Cryptography/Asymptotic/Pseudorandom",
}
results = [
    check(module, expected=products[module]["object_sha256"])
    for module in plan["order"] if module in reproduce
]
results += [check(entry), check("TCSlib"), check(checks)]

docs = source.read_text()
finite, asymptotic = docs.split("## Asymptotic routes")
is_name = re.compile(r"`(TCSlib\.Cryptography\.[\w.]+)`")


def names(text):
    return list(dict.fromkeys(is_name.findall(text)))


def probe(name, imports, identifiers, headlines):
    p = area / (name + ".lean")
    assert not p.exists()
    body = [f"import {module}" for module in imports]
    body.extend(f"#check {identifier}" for identifier in identifiers)
    body.extend(f"#print axioms {identifier}" for identifier in headlines)
    p.write_text("\n".join(body) + "\n")
    module = p.relative_to(integration).with_suffix("").as_posix()
    result = check(module, root=integration)
    assert "sorryAx" not in (logs / (name + ".log")).read_text()
    results.append(result)


def is_module(name):
    return (worktree / (name.replace(".", "/") + ".lean")).is_file()


concrete_names = [name for name in names(finite) if not is_module(name)]
asymptotic_names = [name for name in names(asymptotic) if not is_module(name)]
asymptotic_modules = [name for name in names(asymptotic) if is_module(name)]
probe("PseudorandomConcreteProbe", [entry.replace("/", ".")], concrete_names, concrete_names[2:])
probe("PseudorandomAsymptoticProbe", asymptotic_modules, asymptotic_names, [
    f"TCSlib.Cryptography.{name}" for name in (
        "Ensemble.NextBitUnpredictable.pseudorandom",
        "Ensemble.Pseudorandom.nextBitUnpredictable",
        "owp_hardcore_prg",
        "prg_expand",
        "PRG.Secure.doubling",
        "ggmPRF_prf",
        "exists_prf_of_exists_prg",
        "prgScheme_singleMessageSecure",
        "prfScheme_multiMessageSecure",
        "exists_multiMessageSecure_of_exists_prg",
    )
])
assert git("rev-parse", "HEAD") == head and not git("status", "--porcelain")
receipt = {
    "base": base, "head": head, "source_sha256": sha(source), "passed": True,
    "predecessor": verified["head"], "predecessor_verification_sha256": sha(record),
    "retained_local_objects": len(products) - len(affected),
    "verified_external_objects": len(plan["external"]),
    "changed_lean_commands": 0, "changed_imports": 0,
    "concrete_names": concrete_names, "asymptotic_names": asymptotic_names,
    "asymptotic_modules": asymptotic_modules, "checks": results,
}
(area / "VERIFICATION.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Resolved {len(concrete_names) + len(asymptotic_names)} named declarations "
      f"and checked {len(results)} files", flush=True)
