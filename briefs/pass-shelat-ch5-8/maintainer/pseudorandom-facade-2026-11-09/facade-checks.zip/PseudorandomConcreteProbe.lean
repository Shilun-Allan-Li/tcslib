import TCSlib.Cryptography.Pseudorandom
#check TCSlib.Cryptography.prgAdv
#check TCSlib.Cryptography.prfAdv
#check TCSlib.Cryptography.exists_prgExtRed_ge
#check TCSlib.Cryptography.ggm_prfAdv_le
#print axioms TCSlib.Cryptography.exists_prgExtRed_ge
#print axioms TCSlib.Cryptography.ggm_prfAdv_le
