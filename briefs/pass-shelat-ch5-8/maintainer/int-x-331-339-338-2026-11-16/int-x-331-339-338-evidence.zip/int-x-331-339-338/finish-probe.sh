#!/usr/bin/env bash
# int-x-331-339-338 axioms probe at X (after finish-post-build.sh; before the restore). One Lean process (runner_full.py:
# lean -DmaxErrors=0, no -o, nothing written to the tree). The probe source is placed in the worktree and removed afterwards.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-331-339-338; W=$SP/wt-int-x3; TR=$SP/dl-oleans
cd $E
mkdir -p $W/IntProbe; cp axioms/AxiomsX3.lean.txt $W/IntProbe/AxiomsX3.lean; echo IntProbe/AxiomsX3 > axioms/probe-order.txt
(cd $W && sha256sum IntProbe/AxiomsX3.lean && git status --short --untracked-files=all) > axioms/probe-files-in-worktree.txt
export PATH=$HOME/.elan/bin:$PATH
python3 -I tools-used/runner_full.py $W axioms/probe-order.txt $TR axioms/probe-X
echo "runner_full exit $?" > axioms/probe-X/runner-exit.txt
rm -r $W/IntProbe; (cd $W && echo "after removal: $(git status --short --untracked-files=all | wc -l) status lines") >> axioms/probe-files-in-worktree.txt
