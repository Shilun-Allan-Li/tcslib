#!/usr/bin/env bash
# int-x-331-339-338 post-build steps (after build-x/runner-rc.txt exists; before the probe and the restore). No Lean process.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-331-339-338; R=/home/user/tcslib; TR=$SP/dl-oleans
X=7ab4196ceb257cfe7d619f61c6f167b4ea537d2c; T=76a3fba9c4bfe732d8f91980d856632a118c4561
cd $E
python3 -I tools-used/permod.py build-x build-x/per-module.tsv > build-x/permod.out; cat build-x/permod.out
python3 -I tools-used/review/buildsum.py build-x/results.jsonl > build-x/buildsum.txt; head -1 build-x/buildsum.txt
cp state/state.json state/state-before-x.json
python3 -I tools-used/stateplan.py update $R $X state/state.json build-x/results.jsonl $TR | tee build-x/state-update.out
cp state/state.json state/state-after-x.json
python3 -I tools-used/stateplan.py check $R $X order-x/order.txt state/state.json $TR build-x/statecheck.txt
mkdir -p records tree-final admissions
cat state/base-records-from-int-317.jsonl build-x/results.jsonl > records/records-final.jsonl
python3 -I tools-used/treecheck_ml.py $TR order-x/order.txt records/records-final.jsonl $R $X tree-final/snapshot-X.txt > tree-final/tree-check-X.txt; cat tree-final/tree-check-X.txt
echo "zero-byte files under the tree: $(find $TR -type f -size 0 | wc -l)" | tee tree-final/zero-byte-files.txt; find $TR -type f -size 0 >> tree-final/zero-byte-files.txt
python3 -I tools-used/tipcensus.py $R $T admissions/census-T-76a3fba9.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=refs/int-x-327-324-333-build-x1-results.jsonl
python3 -I tools-used/tipcensus.py $R $T admissions/census-T-76a3fba9-all.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=refs/int-x-327-324-333-build-x1-results.jsonl x=build-x/results.jsonl
python3 -I tools-used/tipcensus.py $R $X admissions/census-X-7ab4196c.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=refs/int-x-327-324-333-build-x1-results.jsonl x=build-x/results.jsonl
diff <(grep -v TOTAL admissions/census-T-76a3fba9-all.txt | sed 's/  \[.*//') <(grep -v TOTAL admissions/census-X-7ab4196c.txt | sed 's/  \[.*//') > admissions/census-T-vs-X.diff; grep -v '^.  0 ' admissions/census-T-vs-X.diff | head -60
python3 -I tools-used/refunion2.py build-x/results.jsonl build-x/refunion x1=refs/int-x-327-324-333-build-x1-results.jsonl int331tip=refs/int-331-tip-build-results.jsonl g40m=refs/gate40-seals-merged-build-results.jsonl gswcore=refs/gsw-core-r1-build-results.jsonl gswsec=refs/gsw-security-r1-build-results.jsonl g39-final-b=refs/g39-records-final-b.jsonl int331-records-final=state/int331-records-final.jsonl base=state/base-records-from-int-317.jsonl > build-x/refunion.txt; tail -3 build-x/refunion.txt
python3 -I tools-used/logcheck.py build-x/results.jsonl build-x/logcheck.txt base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=refs/int-x-327-324-333-build-x1-results.jsonl int331tip=refs/int-331-tip-build-results.jsonl g40m=refs/gate40-seals-merged-build-results.jsonl gswcore=refs/gsw-core-r1-build-results.jsonl gswsec=refs/gsw-security-r1-build-results.jsonl g39=refs/g39-records-final-b.jsonl; tail -2 build-x/logcheck.txt
