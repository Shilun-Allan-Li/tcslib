First probe attempt (AxiomsX3.lean.txt, b3bdf914...), started 19:40:16 UTC by finish-probe.sh under `timeout 1500` from the
tool call. Its stored-constant census (OWNERCENSUS: `collectAxioms` once per stored constant of 15 owner modules) was still
running after 25 min (lean CPU 20 min at 20:01), so `timeout` stopped the whole process group at 20:05:15 UTC (exit 124):
bash, runner_full.py and lean (own PIDs 8191, 8216, 8217). No result record was written; the log holds only the first
12288 bytes Lean had flushed (block-buffered): 50 `#print axioms`/`#admitted` pairs, all as in the second run.
The probe source stayed in the worktree and was replaced for the second run (AxiomsX3b.lean.txt: same 54 names, the census
replaced by OWNERCLOSURE, one closure traversal per module). Nothing was written to the olean tree (runner_full: no -o).
