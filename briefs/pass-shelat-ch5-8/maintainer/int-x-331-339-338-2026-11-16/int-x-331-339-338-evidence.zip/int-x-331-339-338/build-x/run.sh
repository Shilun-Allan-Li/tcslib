#!/usr/bin/env bash
# build X (int-x-331-339-338): runner.py at X 7ab4196c in the worktree, queue plan-x/queue.txt, tree dl-oleans
export PATH=$HOME/.elan/bin:$PATH
date -u +%FT%TZ > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-331-339-338/build-x/launched-utc.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-331-339-338/tools-used/review/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-int-x3 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-331-339-338/plan-x/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-331-339-338/build-x
echo "runner rc=$?" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-331-339-338/build-x/runner-rc.txt
