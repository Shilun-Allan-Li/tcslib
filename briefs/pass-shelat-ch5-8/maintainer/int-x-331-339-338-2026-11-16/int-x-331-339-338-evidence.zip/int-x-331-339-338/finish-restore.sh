#!/usr/bin/env bash
# int-x-331-339-338 restore of dl-oleans to snapshot 457ba704... (run only when no Lean process of this job is running).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-331-339-338
mkdir -p $E/restore
bash $E/tools-used/restore_x3.sh $SP/dl-oleans $SP/dl-intx3-backup $E | tee $E/restore/restore.out
sha256sum $E/tree/snapshot-pre.txt $E/tree/snapshot-post.txt | tee $E/restore/snapshot-hashes.txt
python3 -I $E/tools-used/restoreplan.py $SP/dl-oleans $E/tree/snapshot-pre.txt $E/order-x/order.txt $E/restore/verify-nodelete | tee $E/restore/verify-nodelete.out
python3 -I $E/tools-used/review/snapshot.py $SP/dl-oleans $E/restore/snapshot-recheck.txt | tee $E/restore/snapshot-recheck.out
cmp $E/tree/snapshot-pre.txt $E/restore/snapshot-recheck.txt && echo "RECHECK SNAPSHOT EQUAL" | tee -a $E/restore/snapshot-recheck.out
# only after SNAPSHOT EQUAL: rm -r $SP/dl-intx3-backup; git -C /home/user/tcslib worktree remove --force $SP/wt-int-x3; git -C /home/user/tcslib worktree prune
