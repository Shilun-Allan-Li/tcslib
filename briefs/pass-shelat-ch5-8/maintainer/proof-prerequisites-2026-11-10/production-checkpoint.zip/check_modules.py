from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys,time
repo=Path(sys.argv[1])
area=Path(__file__).resolve().parent
env=os.environ.copy()
for key in ("LEAN_SYSROOT","LEAN_SRC_PATH","LEAN_OPTS"):
    env.pop(key,None)
env["PATH"]="/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin:"+env["PATH"]
env["TCSLIB_OLEANS"]=str(area/"oleans")
for module in sys.argv[2:]:
    source=repo/(module+".lean")
    before=sha256(source.read_bytes()).hexdigest()
    log=area/"native"/(module.replace("/","_")+".log")
    begin=time.monotonic()
    with log.open("w") as output:
        proc=subprocess.run(["/bin/bash","scripts/lean_check_tree.sh",module],cwd=repo,env=env,
                            stdout=output,stderr=subprocess.STDOUT)
    assert sha256(source.read_bytes()).hexdigest()==before,module
    obj=area/"oleans"/(module+".olean")
    text=log.read_text()
    row={"module":module,"rc":proc.returncode,"source_sha256":before,
         "seconds":round(time.monotonic()-begin,3),"log_sha256":sha256(log.read_bytes()).hexdigest(),
         "olean_sha256":sha256(obj.read_bytes()).hexdigest() if obj.is_file() else None}
    with (area/"native/results.jsonl").open("a") as output:
        output.write(json.dumps(row)+"\n")
    print(module,row["rc"],row["seconds"],flush=True)
    if proc.returncode or "error:" in text or not obj.is_file():
        print(text,flush=True)
        sys.exit(1)
