import Lean
import TCSlib.Cryptography.Asymptotic.Universal

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def inScope (owner name : Name) : Bool :=
    owner.toString == "TCSlib.Complexity.TuringMachine.Build.WordTiming" ||
    owner.toString == "TCSlib.Complexity.Randomized.UnaryPolynomial" ||
    owner.toString == "TCSlib.Complexity.ClassP.BinaryArith.Unary" ||
    owner.toString == "TCSlib.Cryptography.Asymptotic.UniversalPadding.Parameter" ||
    owner.toString == "TCSlib.Cryptography.Asymptotic.UniversalPadding.BinaryRoot" ||
    owner.toString == "TCSlib.Cryptography.Asymptotic.UniversalPadding.Machine" ||
    name.toString == "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes" || name.toString.startsWith "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes." ||
    name.toString == "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes_at" || name.toString.startsWith "_private.TCSlib.Complexity.TuringMachine.Build.Primitives.0.Turing.FinTM.pairMap_computes_at." ||
    name.toString == "Turing.FinTM.exists_pairMapSnd_computesInTime" || name.toString.startsWith "Turing.FinTM.exists_pairMapSnd_computesInTime." ||
    name.toString == "Turing.FinTM.exists_emitIterTM_withFuel" || name.toString.startsWith "Turing.FinTM.exists_emitIterTM_withFuel." ||
    name.toString == "Turing.FinTM.exists_emitIterTM" || name.toString.startsWith "Turing.FinTM.exists_emitIterTM." ||
    name.toString == "TCSlib.Cryptography.PadQuad.exists_linearTime_gStr" || name.toString.startsWith "TCSlib.Cryptography.PadQuad.exists_linearTime_gStr."

def home? (env : Environment) (n : Name) : Option Name := do
  let i ← env.getModuleIdxFor? n
  env.header.moduleNames[i.toNat]?

def nameParts : Name → List (String × String)
  | .anonymous => []
  | .str p s => nameParts p ++ [("str", s)]
  | .num p n => nameParts p ++ [("num", toString n)]

run_cmd do
  let env ← getEnv
  let mut refs : Std.HashMap (Name × Name) Json := {}
  let mut count := 0
  for (name, c) in env.constants.toList do
    let some owner := home? env name | continue
    unless inScope owner name do continue
    count := count + 1
    for d in c.getUsedConstantsAsSet do
      let some other := home? env d | continue
      unless other != owner && other.toString.startsWith "TCSlib." do continue
      let some ci := env.find? d | continue
      unless ci.isDefinition do continue
      let status := Lean.getReducibilityStatusCore env d
      let isInst := Lean.Meta.isInstanceCore env d
      let matcher := Lean.Meta.isMatcherCore env d
      let abbrevFlag := match ci with
        | .defnInfo d => match d.hints with | .abbrev => true | _ => false
        | _ => false
      refs := refs.insert (owner, d) <| Json.mkObj [
        ("owner", toJson owner.toString), ("name", toJson d.toString), ("home", toJson other.toString),
        ("name_components", toJson (nameParts d)), ("home_components", toJson (nameParts other)),
        ("status", toJson status.toAttrString), ("instance", toJson isInst), ("matcher", toJson matcher),
        ("abbrev", toJson abbrevFlag)]
  for (_, row) in refs.toArray do liftIO <| IO.println ("SEAL_CAND " ++ row.compress)
  liftIO <| IO.println s!"CENSUS {count} selected declarations, {refs.size} external definitions"
