import Lean
import LevinAssemblyProbe

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Elab Command

def checkedLocalDependencies (env : Environment) (name : Name) : Array (Name × Name) := Id.run do
  let mut todo := #[name]
  let mut seen : NameSet := {}
  let mut results := #[]
  while !todo.isEmpty do
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    let some idx := env.getModuleIdxFor? n | continue
    let owner := env.header.moduleNames[idx.toNat]!
    unless owner.toString.startsWith "TCSlib." || owner.toString.startsWith "Levin" do continue
    results := results.push (n, owner)
    let some c := env.checked.get.find? n | continue
    for dep in c.getUsedConstantsAsSet do
      unless seen.contains dep do
        todo := todo.push dep
  return results

def routeRoots : Array Name := #[
  `LevinAssembly.exists_linearTime_padded,
  `LevinAssembly.exists_linearTime_shifted_root,
  `LevinAssembly.exists_linearTime_padded_of_shifted_root,
  `LevinBinaryRoot.polyTimeComputable_shifted_root,
  `LevinRootRuntime.exists_binaryToUnary,
  `LevinRootRuntime.exists_pow_width_bound,
  `Complexity.exists_unaryPoly_succ_computesFunInTime,
  `Turing.FinTM.exists_append_computesFunInTime,
  `Turing.FinTM.exists_pairMapSnd_computesInTime,
  `Turing.FinTM.exists_emitIterTM_withFuel]

run_cmd do
  let env ← getEnv
  for n in routeRoots do
    unless env.contains n do
      throwError "Missing named declaration {n}"
    let deps := checkedLocalDependencies env n
    let row := Json.mkObj [
      ("root", toJson n.toString),
      ("dependencies", toJson (deps.map fun (d, m) => (d.toString, m.toString)))]
    liftIO <| IO.println ("PROOF_ROUTE " ++ row.compress)
