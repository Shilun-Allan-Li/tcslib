import TCSlib.Complexity.TuringMachine.Build.Primitives
import TCSlib.Complexity.Randomized.PolyExpr
import Mathlib.Algebra.Polynomial.Eval.Defs

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

open Turing Complexity
open scoped BigOperators

namespace Turing.FinTM

attribute [local irreducible] FinTM.ComputesFunInTime FinTM.ComputesInTime
attribute [local irreducible] pairEncode pairDecode bufferedCompTM

/-- Two computations on the same input can have their outputs concatenated with
linear overhead in their separate time bounds and the input length.

**Proof sketch.** Duplicate the input and map the first computation over the payload.
Duplicate the resulting pair, then compute the second result from its original-input
projection. Concatenate and remove the retained input. Each call is charged at its
actual input, and the two computed words have length at most their run times. -/
theorem exists_append_computesFunInTime {F G : FinTM Bool}
    {f g : List Bool → List Bool} {A B : ℕ → ℕ}
    (hf : F.ComputesFunInTime f A) (hg : G.ComputesFunInTime g B) :
    ∃ (M : FinTM Bool) (c : ℕ),
      M.ComputesFunInTime (fun x => f x ++ g x)
        (fun n => c * (A n + B n + n + 1)) := by
  obtain ⟨D, a, hD⟩ := computesFunInTime_pairDup
  obtain ⟨P, hP⟩ := exists_pairMapSnd_computesInTime F
  let G' := bufferedCompTM (pairExtractTM true false) G
  obtain ⟨Q, hQ⟩ := exists_pairMapSnd_computesInTime G'
  let C := pairExtractTM true true
  let S := pairExtractTM false true
  let M := bufferedCompTM
    (bufferedCompTM (bufferedCompTM (bufferedCompTM (bufferedCompTM D P) D) Q) C) S
  refine ⟨M, 4 * a + 1500, (computesFunInTime_iff _ _ _).2 fun x => ?_⟩
  let n := x.length
  let budget := A n + B n + n + 1
  let p := pairEncode x x
  let s := pairEncode x (f x)
  let q := pairEncode s s
  let r := pairEncode s (g x)
  have hf' := (computesFunInTime_iff _ _ _).1 hf x
  have hg' := (computesFunInTime_iff _ _ _).1 hg x
  have hlf : (f x).length ≤ A n := by
    rw [← ((computesInTime_iff _ _ _ _).1 hf').2]
    exact F.tm.output_length_le x _
  have hlg : (g x).length ≤ B n := by
    rw [← ((computesInTime_iff _ _ _ _).1 hg').2]
    exact G.tm.output_length_le x _
  have h₁ := (computesFunInTime_iff _ _ _).1 hD x
  have h₂ := hP x x (f x) (A n) hf'
  have h₃ := (computesFunInTime_iff _ _ _).1 hD s
  have hproj : (pairExtractTM true false).ComputesInTime s x (5 * (s.length + 1)) := by
    simpa only [s, pairDecode_pairEncode, Bool.false_eq_true, ↓reduceIte, List.append_nil] using
      pairExtractTM_computes true false s
  have hrun : G'.ComputesInTime s (g x) (5 * (s.length + 1) + n + 2 + B n) :=
    bufferedCompTM_computesInTime (pairExtractTM true false) G hproj hg'
  have h₄ := hQ s s (g x) _ hrun
  have h₅ : C.ComputesInTime r (s ++ g x) (5 * (r.length + 1)) := by
    simpa only [C, r, pairDecode_pairEncode, ↓reduceIte] using
      pairExtractTM_computes true true r
  have hword : s ++ g x = pairEncode x (f x ++ g x) := by
    simp only [s, pairEncode_eq, List.append_assoc]
  have h₆ : S.ComputesInTime (s ++ g x) (f x ++ g x) (5 * ((s ++ g x).length + 1)) := by
    rw [hword]
    simpa only [S, pairDecode_pairEncode, ↓reduceIte, List.nil_append] using
      pairExtractTM_computes false true (pairEncode x (f x ++ g x))
  have h := bufferedCompTM_computesInTime D P h₁ h₂
  have h := bufferedCompTM_computesInTime _ D h h₃
  have h := bufferedCompTM_computesInTime _ Q h h₄
  have h := bufferedCompTM_computesInTime _ C h h₅
  have h := bufferedCompTM_computesInTime _ S h h₆
  have hn : n + 1 ≤ budget := by dsimp only [budget]; omega
  have hs : s.length ≤ 2 * budget := by
    rw [show s = pairEncode x (f x) from rfl, length_pairEncode]
    dsimp only [budget, n] at hlf ⊢
    omega
  have hsmall : 1 ≤ budget := by omega
  have hp : p.length ≤ 3 * budget := by
    rw [show p = pairEncode x x from rfl, length_pairEncode]
    dsimp only [n] at hn
    omega
  have hq : q.length ≤ 8 * budget := by
    rw [show q = pairEncode s s from rfl, length_pairEncode]
    omega
  have hr : r.length ≤ 7 * budget := by
    rw [show r = pairEncode s (g x) from rfl, length_pairEncode]
    have : B n ≤ budget := by dsimp only [budget]; omega
    omega
  have hd₁ : a * (n + 1) ≤ a * budget := Nat.mul_le_mul_left _ hn
  have hd₂ : a * (s.length + 1) ≤ a * (3 * budget) :=
    Nat.mul_le_mul_left _ (by omega)
  have hA : A n ≤ budget := by dsimp only [budget]; omega
  have hB : B n ≤ budget := by dsimp only [budget]; omega
  refine h.mono ?_
  have hbound : (4 * a + 1500) * budget = a * budget + a * (3 * budget) + 1500 * budget := by
    ring
  change _ ≤ (4 * a + 1500) * budget
  rw [hbound]
  rw [List.length_append]
  change a * (n + 1) + p.length + 2 + 40 * (A n + p.length + 1) +
    s.length + 2 + a * (s.length + 1) +
    q.length + 2 + 40 * (5 * (s.length + 1) + n + 2 + B n + q.length + 1) +
    r.length + 2 + 5 * (r.length + 1) +
    (s.length + (g x).length) + 2 + 5 * (s.length + (g x).length + 1) ≤ _
  omega

end Turing.FinTM

namespace Complexity

open Turing.FinTM

/-- The ordinary polynomial denoted by the syntactic arithmetic expression. -/
private noncomputable def toNatPolynomial : PolyExpr → Polynomial ℕ
  | .const a => Polynomial.C a
  | .var => Polynomial.X
  | .add p q => toNatPolynomial p + toNatPolynomial q
  | .mul p q => toNatPolynomial p * toNatPolynomial q
  | .pow p e => toNatPolynomial p ^ e

/-- The polynomial agrees with the syntactic evaluator.

**Proof sketch.** Induct over the expression using the polynomial evaluation laws. -/
private theorem toNatPolynomial_eval (p : PolyExpr) (n : ℕ) :
    (toNatPolynomial p).eval n = p.eval n := by
  induction p <;> simp_all only [toNatPolynomial, Polynomial.eval_C, Polynomial.eval_X,
    Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_pow, PolyExpr.eval_const,
    PolyExpr.eval_var, PolyExpr.eval_add, PolyExpr.eval_mul, PolyExpr.eval_pow]

/-- Nonzero monomials can be evaluated and concatenated at a cost proportional
to their total output length plus the input length.

**Proof sketch.** Induct over the finite set of exponents. The sharp monomial
emitter charges a constant multiple of the monomial, since its coefficient is
positive. Use the bounded concatenation theorem for that emitter and the tail. -/
private theorem exists_unaryMonomialSum (coeff : ℕ → ℕ) (s : Finset ℕ)
    (hs : ∀ e ∈ s, 0 < coeff e) :
    ∃ (M : FinTM Bool) (c : ℕ), M.ComputesFunInTime
      (fun x => List.replicate (∑ e ∈ s, coeff e * (x.length + 1) ^ e) true)
      (fun n => c * ((∑ e ∈ s, coeff e * (n + 1) ^ e) + n + 1)) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    refine ⟨constTM [], 1, (computesFunInTime_iff _ _ _).2 fun x => ?_⟩
    simp only [Finset.sum_empty, List.replicate_zero, Nat.zero_add, Nat.one_mul]
    exact (constTM_computes [] x).mono (by simp)
  | @insert e s he ih =>
    have hpos := hs e (Finset.mem_insert_self _ _)
    obtain ⟨G, b, hG⟩ := ih (fun i hi => hs i (Finset.mem_insert_of_mem hi))
    let a := coeff e + 5 * e + 4
    obtain ⟨M, c, hM⟩ := exists_append_computesFunInTime (polyUnaryTM_computes (coeff e) e) hG
    refine ⟨M, c * (a + b + 1), (computesFunInTime_iff _ _ _).2 fun x => ?_⟩
    rw [Finset.sum_insert he, List.replicate_add]
    let n := x.length
    let term := coeff e * (n + 1) ^ e
    let rest := ∑ i ∈ s, coeff i * (n + 1) ^ i
    let total := term + rest + n + 1
    have hpow : (n + 1) ^ e ≤ term := by
      simpa only [Nat.one_mul] using
        Nat.mul_le_mul_right ((n + 1) ^ e) hpos
    have hterm : (n + 1) ^ e ≤ total := hpow.trans (by dsimp only [total]; omega)
    have hrest : rest + n + 1 ≤ total := by dsimp only [total]; omega
    have hn : n + 1 ≤ total := by dsimp only [total]; omega
    refine ((computesFunInTime_iff _ _ _).1 hM x).mono ?_
    change c * (a * (n + 1) ^ e + b * (rest + n + 1) + n + 1) ≤
      c * (a + b + 1) * total
    calc
      _ ≤ c * (a * total + b * total + total) := by
        apply Nat.mul_le_mul_left
        simpa only [Nat.add_assoc] using
          Nat.add_le_add (Nat.add_le_add (Nat.mul_le_mul_left _ hterm)
            (Nat.mul_le_mul_left _ hrest)) hn
      _ = _ := by ring

/-- The unary value of a syntactic polynomial at one plus the input length is
computable in time proportional to the sum of the input and output lengths.

**Proof sketch.** Expand the polynomial into its nonzero monomials. For each
degree use the sharp monomial emitter, and concatenate their unary outputs. -/
theorem exists_unaryPoly_succ_computesFunInTime (p : PolyExpr) :
    ∃ (M : FinTM Bool) (c : ℕ), M.ComputesFunInTime
      (fun x => List.replicate (p.eval (x.length + 1)) true)
      (fun n => c * (p.eval (n + 1) + n + 1)) := by
  let P := toNatPolynomial p
  have heval (n : ℕ) : p.eval n = ∑ e ∈ P.support, P.coeff e * n ^ e := by
    rw [← toNatPolynomial_eval, ← show P = toNatPolynomial p from rfl,
      Polynomial.eval_eq_sum, Polynomial.sum_def]
  obtain ⟨M, c, hM⟩ := exists_unaryMonomialSum P.coeff P.support fun e he =>
    Nat.pos_of_ne_zero (Polynomial.mem_support_iff.1 he)
  refine ⟨M, c, (computesFunInTime_iff _ _ _).2 fun x => ?_⟩
  rw [heval]
  exact (computesFunInTime_iff _ _ _).1 hM x

end Complexity

#print axioms Turing.FinTM.exists_pairMapSnd_computesInTime
#print axioms Turing.FinTM.exists_append_computesFunInTime
#print axioms Complexity.exists_unaryPoly_succ_computesFunInTime
