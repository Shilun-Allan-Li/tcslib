import TCSlib.Cryptography.Asymptotic.UniversalPadding

set_option autoImplicit false

open Complexity Turing TCSlib.Cryptography

attribute [local irreducible] PadQuad.nu NUPPT.advInput

/-- At the recovered parameter, the unary data length and the time of the call
to the original machine fit a linear budget in the padded input length. -/
theorem levinTimeOnImage (ℓ : PolyExpr) (C c d n₁ : ℕ) (hd : 1 ≤ d)
    (hdom : ∀ n ≥ n₁, ℓ.eval n + C * (2 * n + 3 + ℓ.eval n) ^ c ≤ n ^ d) :
    ∃ B : ℕ, ∀ z : List Bool,
      let n := PadQuad.nu d z.length
      ℓ.eval n + C * ((NUPPT.advInput n (z.take (ℓ.eval n))).length + 1) ^ c ≤
        B * (z.length + 1) := by
  let B := ℓ.eval n₁ + C * (2 * n₁ + 3 + ℓ.eval n₁) ^ c + 1
  refine ⟨B, fun z => ?_⟩
  let n := PadQuad.nu d z.length
  change ℓ.eval n + C * ((NUPPT.advInput n (z.take (ℓ.eval n))).length + 1) ^ c ≤
    B * (z.length + 1)
  have hinput : (NUPPT.advInput n (z.take (ℓ.eval n))).length + 1 ≤
      2 * n + 3 + ℓ.eval n := by
    rw [NUPPT.length_advInput, List.length_take]
    omega
  have htime := Nat.mul_le_mul_left C (Nat.pow_le_pow_left hinput c)
  by_cases hn : n₁ ≤ n
  · have hB : 1 ≤ B := by omega
    calc
      _ ≤ ℓ.eval n + C * (2 * n + 3 + ℓ.eval n) ^ c := Nat.add_le_add_left htime _
      _ ≤ n ^ d := hdom n hn
      _ ≤ z.length := PadQuad.nu_pow_le hd _
      _ ≤ 1 * (z.length + 1) := by omega
      _ ≤ _ := Nat.mul_le_mul_right _ hB
  · have hn' : n ≤ n₁ := by omega
    have hℓ := ℓ.eval_mono hn'
    have harg : 2 * n + 3 + ℓ.eval n ≤ 2 * n₁ + 3 + ℓ.eval n₁ := by omega
    have hcost := Nat.mul_le_mul_left C (Nat.pow_le_pow_left harg c)
    calc
      _ ≤ ℓ.eval n₁ + C * (2 * n₁ + 3 + ℓ.eval n₁) ^ c :=
        Nat.add_le_add hℓ (htime.trans hcost)
      _ ≤ B := by omega
      _ ≤ _ := by simpa only [Nat.mul_one] using
        Nat.mul_le_mul_left B (Nat.succ_le_succ (Nat.zero_le z.length))

#print axioms levinTimeOnImage
