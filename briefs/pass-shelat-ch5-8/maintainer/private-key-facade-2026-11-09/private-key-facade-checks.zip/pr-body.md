## Changes

- Add `TCSlib.Cryptography.Encryption.PrivateKey` as the entry point for the ensemble and oracle developments. Import it from `TCSlib`.
- Document the proved PRG single-message and PRF fixed-vector results, including the end-to-end PRG existence theorem. Identify the pending adaptive CPA, CCA1 and CCA2 results and the pending CCA2 counterexample.
- Keep the existing declarations, proofs and import paths in place.

## Verification

- Checked the new facade, the library root and `audits/pass-shelat/Checks` one module at a time with Lean 4.25.0.
- Two probes importing only the facade resolve 21 names and confirm the expected axiom sets for 11 declarations. The four ensemble results and two oracle constructions have no admission dependencies. The four pending oracle results and the statement derived from the counterexample retain their admission dependencies.
- The source linter reports zero findings in the facade. `git diff --check` passes.
