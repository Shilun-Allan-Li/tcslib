import TCSlib.Cryptography.Encryption.PrivateKey

#check @TCSlib.Cryptography.Composability.FixedLengthScheme
#check @TCSlib.Cryptography.Composability.FixedLengthScheme.indGame
#check @TCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure
#check @TCSlib.Cryptography.Composability.prfFixedScheme
#check @TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#check @TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#check @TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#check @TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#check @TCSlib.Cryptography.Composability.ccaScheme
#check @TCSlib.Cryptography.Composability.ccaScheme_cca2

#print axioms TCSlib.Cryptography.Composability.prfFixedScheme
#print axioms TCSlib.Cryptography.Composability.ccaScheme
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#print axioms TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#print axioms TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#print axioms TCSlib.Cryptography.Composability.ccaScheme_cca2
