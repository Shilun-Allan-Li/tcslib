import TCSlib.Cryptography.Encryption.PrivateKey

#check @TCSlib.Cryptography.PrivateKeyScheme
#check @TCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure
#check @TCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure
#check @TCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure.singleMessageSecure
#check @TCSlib.Cryptography.PrivateKeyScheme.not_multiMessageSecure_of_deterministic
#check @TCSlib.Cryptography.prgScheme
#check @TCSlib.Cryptography.prgScheme_singleMessageSecure
#check @TCSlib.Cryptography.prfScheme
#check @TCSlib.Cryptography.prfScheme_multiMessageSecure
#check @TCSlib.Cryptography.exists_multiMessageSecure_of_prf
#check @TCSlib.Cryptography.exists_multiMessageSecure_of_exists_prg

#print axioms TCSlib.Cryptography.prgScheme_singleMessageSecure
#print axioms TCSlib.Cryptography.prfScheme_multiMessageSecure
#print axioms TCSlib.Cryptography.exists_multiMessageSecure_of_prf
#print axioms TCSlib.Cryptography.exists_multiMessageSecure_of_exists_prg
