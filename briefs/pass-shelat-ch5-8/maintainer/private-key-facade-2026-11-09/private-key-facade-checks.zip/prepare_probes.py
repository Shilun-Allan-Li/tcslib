"""Copy checked imports into a private tree and generate declaration and import probes."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area = Path(sys.argv[1]).resolve()
native = area / "native"
meta = area / "probes"
out = meta / "oleans"
plan = json.loads((native / "PLAN.json").read_bytes())
facade_import = "TCSlib.Cryptography.Encryption.PrivateKey"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


products = dict(plan["retained"])
for path in sorted(native.glob("run-*/check-*.json")):
    try:
        row = read(path)
    except json.JSONDecodeError:
        continue
    if row["rc"] == 0:
        assert row["head"] == plan["head"]
        assert sha(path.with_suffix(".log")) == row["log_sha256"]
        products[row["module"]] = row
pending = [facade_import.replace(".", "/")]
needed = set()
while pending:
    module = pending.pop()
    if module not in needed:
        needed.add(module)
        pending.extend(plan["graph"][module])
assert needed <= products.keys(), sorted(needed - products.keys())
out.mkdir(parents=True, exist_ok=True)
tree = Path(plan["tree"])
for module in sorted(needed):
    row = products[module]
    assert row["source_sha256"] == plan["source_digests"][module], module
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}, module
    copy(tree / (module + ".olean"), out / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(tree):
        copy(src, out / src.relative_to(tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
pfr = out / "PFR"
if not pfr.is_symlink():
    pfr.symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

crypto = "TCSlib.Cryptography."
composability = crypto + "Composability."
ensembles = tuple(crypto + name for name in (
    "PrivateKeyScheme", "PrivateKeyScheme.SingleMessageSecure", "PrivateKeyScheme.MultiMessageSecure",
    "PrivateKeyScheme.MultiMessageSecure.singleMessageSecure",
    "PrivateKeyScheme.not_multiMessageSecure_of_deterministic",
    "prgScheme", "prgScheme_singleMessageSecure", "prfScheme", "prfScheme_multiMessageSecure",
    "exists_multiMessageSecure_of_prf", "exists_multiMessageSecure_of_exists_prg",
))
oracles = tuple(composability + name for name in (
    "FixedLengthScheme", "FixedLengthScheme.indGame", "FixedLengthScheme.INDSecure",
    "prfFixedScheme", "prfFixedScheme_cpa", "prfFixedScheme_cca1", "prfFixedScheme_not_cca2",
    "not_prfFixedScheme_cca2", "ccaScheme", "ccaScheme_cca2",
))
proved = tuple(crypto + name for name in (
    "prgScheme_singleMessageSecure", "prfScheme_multiMessageSecure",
    "exists_multiMessageSecure_of_prf", "exists_multiMessageSecure_of_exists_prg",
))
oracle_constructions = tuple(composability + name for name in ("prfFixedScheme", "ccaScheme"))
admitted = tuple(composability + name for name in (
    "prfFixedScheme_cpa", "prfFixedScheme_cca1", "prfFixedScheme_not_cca2",
    "not_prfFixedScheme_cca2", "ccaScheme_cca2",
))
for name, names, axioms in (("EnsembleRoute", ensembles, proved),
                            ("OracleRoute", oracles, oracle_constructions + admitted)):
    lines = ["import " + facade_import, ""]
    lines.extend("#check @" + name for name in names)
    lines.append("")
    lines.extend("#print axioms " + name for name in axioms)
    (meta / (name + ".lean")).write_text("\n".join(lines) + "\n")
(meta / "PROBES.json").write_text(json.dumps({
    "root": facade_import, "checked_names": {"EnsembleRoute": ensembles, "OracleRoute": oracles},
    "ordinary_axioms_only": proved + oracle_constructions, "has_admission_dependency": admitted,
    "checked_local_objects": len(needed),
}, indent=2) + "\n")
print(f"Copied {len(needed)} verified local objects for the two standalone facade probes.", flush=True)
