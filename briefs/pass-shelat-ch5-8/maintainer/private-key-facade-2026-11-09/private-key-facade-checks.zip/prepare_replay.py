"""Verify the merged predecessor and stage the exact new import graph."""
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
tools = area.parent / "cleanup-incremental-20261108/tools"
previous = area.parent / "ggm-move-20261109/native"
published = (campaign / "briefs/pass-shelat-ch5-8/maintainer/ggm-move-2026-11-09"
             / "VERIFICATION.json")
out = area / "native"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location("campaign_import_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
base, head = ((area / f"{side}.txt").read_text().strip() for side in ("base", "head"))
prefix = "TCSlib/Cryptography/"
facade = prefix + "Encryption/PrivateKey"
owners = {facade}
changed = owners | {"TCSlib"}
checks = "audits/pass-shelat/Checks"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def clean_git(*args):
    return git(*args).decode().strip()


def copy(src, dst, digest):
    assert sha(src) == digest, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == digest and not dst.samefile(src), dst


def put(path, data):
    with path.open("x") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def show(revision, module):
    return git("show", f"{revision}:{module}.lean")


assert clean_git("rev-parse", "HEAD") == head and clean_git("rev-parse", "HEAD^") == base
assert not clean_git("status", "--porcelain")
assert not clean_git("diff", "--check", base, head)
assert {s[:-5] for s in clean_git("diff", "--name-only", base, head).splitlines()} == changed
old = read(previous / "PLAN.json")
products = read(previous / "PRODUCTS.json")
checked = read(previous / "RESULT.json")
receipt = read(published)
assert checked["passed"] and receipt["passed"] and checked["head"] == receipt["head"] == old["head"]
assert receipt["head"] == clean_git("rev-parse", base + "^2") == (area / "accepted-269.txt").read_text().strip()
for artifact in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / artifact) == receipt["artifact_sha256"]["native/" + artifact], artifact
assert not clean_git("diff", "--name-only", old["head"], base, "--", "*.lean", "lean-toolchain",
                     "lake-manifest.json", "lakefile.lean", "lakefile.toml", "scripts/lean_check_tree.sh")
assert sha(Path(old["toolchain"])) == old["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == old["checker_sha256"]

sources = {
    path[:-5]: (root / path).read_bytes()
    for path in clean_git("ls-files", "--", "TCSlib", "TCSlib.lean", checks + ".lean").splitlines()
    if path.endswith(".lean")
}
assert old["source_digests"].keys() | owners <= sources.keys()
digests = {module: sha256(raw).hexdigest() for module, raw in sources.items()}
for module in sources.keys() - changed:
    baseline = old["source_digests"].get(module)
    if baseline is None:
        baseline = sha256(show(base, module)).hexdigest()
    assert digests[module] == baseline, module
imports = {
    module: [name.replace(".", "/") for name in graph.imports(raw)
             if name.replace(".", "/") in sources]
    for module, raw in sources.items()
}
providers = [
    prefix + "Asymptotic/Encryption", prefix + "Asymptotic/MultiMessageLemmas",
    prefix + "Asymptotic/MultiMessage", prefix + "Composability/Defs",
    prefix + "Composability/PRFScheme", prefix + "Composability/CCA2Scheme",
]
assert imports[facade] == providers
assert [n for n in imports["TCSlib"] if n != facade] == old["graph"]["TCSlib"]
assert imports["TCSlib"].count(facade) == 1
for module in old["graph"].keys() - {"TCSlib"}:
    assert imports[module] == old["graph"][module], module
order = graph.topo(imports, ["TCSlib", checks])
assert set(order) == set(old["order"]) | owners
narrow = set(graph.topo(imports, [facade])) - {facade}
assert narrow <= set(old["order"])
assert not {facade, "TCSlib", checks, prefix + "Encryption/PublicKey"} & narrow
assert set(graph.topo(imports, ["TCSlib"])) == set(graph.topo(old["graph"], ["TCSlib"])) | owners
code = graph.comments_removed(sources[facade].decode())
assert all(line.startswith(("import ", "set_option ")) for line in code.splitlines() if line.strip())
root_source = show(base, "TCSlib").decode()
anchor = "import TCSlib.Cryptography.Encryption.PublicKey\n"
assert root_source.count(anchor) == 1
assert sources["TCSlib"].decode() == root_source.replace(anchor, f"import {facade.replace('/', '.')}\n" + anchor)
affected = changed.copy()
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
assert affected == {facade, "TCSlib"}
recheck = affected | {checks}
rebuild = [module for module in order if module in recheck]
assert len(rebuild) == 3
old_tree = Path(old["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
for module in order:
    if module in recheck:
        continue
    row = products[module]
    assert digests[module] == row["source_sha256"]
    assert row["direct_local"] == {dep: retained[dep]["object_sha256"] for dep in imports[module]}, module
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {**row, "source": "verified_ggm_tree"}
external = {}
for name, row in old["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        dest = tree / path.relative_to(old_tree)
        copy(path, dest, row["sha256"])
        path = dest
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": old["head"], "worktree": str(root), "tree": str(tree),
    "toolchain": old["toolchain"], "toolchain_sha256": old["toolchain_sha256"],
    "checker_sha256": old["checker_sha256"], "affected": sorted(affected), "rebuild": rebuild,
    "order": order, "retained": retained, "graph": {m: imports[m] for m in order},
    "external": external, "source_digests": digests,
}
put(out / "PLAN.json", plan)
put(area / "SOURCE-CHECK.json", {
    "base": base, "head": head, "baseline": old["head"], "changed_paths": sorted(changed),
    "new_owners": sorted(owners), "facade_import_closure": sorted(narrow),
    "facade_direct_imports": providers, "existing_proof_and_definition_sources_preserved": True,
    "campaign_checks_replayed": [checks],
    "affected_modules": len(affected), "retained_objects": len(retained),
    "external_objects": len(external), "predecessor_receipt_sha256": sha(published),
})
print(f"Sources match the verified #269 merge. {len(rebuild)} checks including the campaign audit, "
      f"{len(retained)} verified transfers and {len(external)} external objects.", flush=True)
