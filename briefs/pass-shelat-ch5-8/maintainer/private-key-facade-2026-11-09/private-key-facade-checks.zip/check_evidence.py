"""Verify the import-only source change and both routes through the facade."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import subprocess
import sys

area, root = (Path(s).resolve() for s in sys.argv[1:3])
native, probes = area / "native", area / "probes"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root).decode().strip()


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source, scope = read(area / "SOURCE-CHECK.json"), read(probes / "PROBES.json")
assert result["passed"] and plan["head"] == result["head"] == source["head"] == git("rev-parse", "HEAD")
assert plan["base"] == result["base"] == source["base"]
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert len(plan["affected"]) == source["affected_modules"] == 2
assert result["fresh_native_checks"] == len(plan["rebuild"]) == 3
assert result["initial_retained"] == len(plan["retained"]) == 1097
assert len(products) == len(plan["order"]) == 1100 and len(plan["external"]) == 3810
assert set(plan["rebuild"]) - set(plan["affected"]) == set(source["campaign_checks_replayed"])
assert source["existing_proof_and_definition_sources_preserved"]
assert not git("status", "--porcelain") and not git("diff", "--check", plan["base"], plan["head"])
assert "0 findings in 1 files" in (area / "style.log").read_text()
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == plan["head"] and row["rc"] == 0
    assert row["log_sha256"] == sha(receipt.with_suffix(".log"))
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}

standard = {"propext", "Classical.choice", "Quot.sound"}
axioms = {}
receipts = {}
for name, declarations in scope["checked_names"].items():
    path = probes / name
    assert path.with_suffix(".rc").read_text().strip() == "0"
    source_text = path.with_suffix(".lean").read_text()
    assert [s for s in source_text.splitlines() if s.startswith("import ")] == ["import " + scope["root"]]
    assert [s.removeprefix("#check @") for s in source_text.splitlines() if s.startswith("#check @")] == declarations
    log = path.with_suffix(".log").read_text()
    for decl, deps in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", log):
        assert decl not in axioms, decl
        axioms[decl] = {a.strip() for a in deps.split(",") if a.strip()}
    for decl in re.findall(r"'([^']+)' does not depend on any axioms", log):
        assert decl not in axioms, decl
        axioms[decl] = set()
    receipts[name] = {"checked_names": declarations, "log_sha256": sha(path.with_suffix(".log")),
                      "source_sha256": sha(path.with_suffix(".lean"))}
assert sum(len(p["checked_names"]) for p in receipts.values()) == 21
assert set(axioms) == set(scope["ordinary_axioms_only"] + scope["has_admission_dependency"]), axioms
for decl in scope["ordinary_axioms_only"]:
    assert axioms[decl] <= standard, (decl, axioms[decl])
for decl in scope["has_admission_dependency"]:
    assert "sorryAx" in axioms[decl] and axioms[decl] <= standard | {"sorryAx"}, (decl, axioms[decl])
(area / "PROOF-STATUS.json").write_text(json.dumps({
    "head": plan["head"], "base": plan["base"], "passed": True, "probes": receipts,
    "axioms": {name: sorted(values) for name, values in sorted(axioms.items())},
}, indent=2) + "\n")
print("Facade, root and campaign Checks pass. The standalone probes resolve 21 names and verify 11 axiom sets.")
