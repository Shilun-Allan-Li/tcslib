"""Stage the tagged encryption module and its compatibility and facade imports."""
import json
from pathlib import Path
import subprocess
import sys

area, repo = (Path(arg).resolve() for arg in sys.argv[1:3])
base = (area / "base.txt").read_text().strip()
crypto = "TCSlib/Cryptography/"
legacy = crypto + "Composability/CCA2Scheme"
facade = crypto + "Encryption/PrivateKey"
owner = facade + "/EncryptThenTag"
legacy_games = crypto + "Composability/Defs"
legacy_prf = crypto + "Asymptotic/PRF"
games = facade + "/OracleSecurity"
prf = crypto + "Pseudorandom/Functions/Asymptotic/Defs"
collections = crypto + "Asymptotic/CollectionsHelpers"
repetition = "TCSlib/Complexity/Randomized/Repetition"
marker = "namespace TCSlib.Cryptography.Composability\n"


def show(module):
    return subprocess.check_output(["git", "show", f"{base}:{module}.lean"], cwd=repo).decode()


def import_line(module):
    return "import " + module.replace("/", ".") + "\n"


def replace_once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


raw = show(legacy)
tagged = replace_once(raw, import_line(legacy_games), import_line(games))
tagged = replace_once(tagged, import_line(legacy_prf), import_line(prf))
tagged = replace_once(tagged, import_line(games), import_line(repetition) + import_line(games))
assert tagged[tagged.index(marker):] == raw[raw.index(marker):]
compat = raw[:raw.index("import ")] + "".join(import_line(module) for module in
                                               (legacy_games, collections, legacy_prf, owner))
compat += "\n" + raw[raw.index("set_option "):raw.index("/-!")]
compat += """/-!
# Tagged private-key encryption compatibility import

## Main definitions

`Encryption.PrivateKey.EncryptThenTag` gives the tagged scheme as a fixed-length private-key
scheme in the `TCSlib.Cryptography.Composability` namespace.

## Main results

This import exposes the correctness and ciphertext length proofs and the CCA2 security
statement for the tagged construction.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§7.1.3, Algorithm 169.3 and Theorem 170.4.)
-/
"""
facade_text = replace_once(show(facade), import_line(legacy),
    import_line(owner) + "-- This compatibility import also preserves the facade's earlier hard-core exports.\n"
    + import_line(legacy))
facade_text = replace_once(facade_text,
    "* `Composability.CCA2Scheme` gives the encrypt-then-tag scheme, which tags the\n",
    "* `Encryption.PrivateKey.EncryptThenTag` gives the encrypt-then-tag scheme, which tags the\n")
sources = {owner: tagged, legacy: compat, facade: facade_text}
for module, text in sources.items():
    path = area / "source" / (module + ".lean")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
(area / "MOVE-SCOPE.json").write_text(json.dumps({
    "legacy": legacy, "owner": owner, "facade": facade, "legacy_games": legacy_games,
    "legacy_prf": legacy_prf, "games": games, "prf": prf, "collections": collections, "repetition": repetition,
}, indent=2) + "\n")
print("Prepared the verbatim construction and statement move, compatibility import and facade update.")
