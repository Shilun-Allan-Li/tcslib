import TCSlib.Cryptography.Encryption.PrivateKey.EncryptThenTag

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Composability

variable (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (F n s x))

example : (ccaScheme F E hE hFE).ctLen = .add (.mul (.const 6) .var) (.const 4) := by
  rfl
