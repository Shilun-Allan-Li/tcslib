## Changes

- Move the tagged construction, its correctness and ciphertext-length proofs, and its CCA2 statement verbatim into `Encryption.PrivateKey.EncryptThenTag`.
- Re-export the declarations through `Composability.CCA2Scheme`. The private-key facade names the new owner and keeps the compatibility import to preserve its earlier exports.
- Import the oracle interface, PRF contract and machine support directly in the new module.

## Verification

- All five affected modules and the separate campaign Checks replay pass with Lean 4.25.0. The standalone and legacy probes agree.
- The census matches all 45 types, definition values, elaborated references and axiom sets. The CCA2 statement has the same admission dependency.
- Both whole-file seals pass with the same admission warning. The control blocks direct reduction of the scheme and accepts the published ciphertext-length equation.
- Source lint, campaign lint and the diff check pass.
