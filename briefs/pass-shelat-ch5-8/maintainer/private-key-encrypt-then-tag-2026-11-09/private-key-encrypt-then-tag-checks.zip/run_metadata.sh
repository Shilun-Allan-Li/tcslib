#!/usr/bin/env bash
set -euo pipefail
area=$1
repo=$2
campaign=$3
side=$4
meta="$area/metadata"
toolchain="$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$area/native/PLAN.json")"
cmp scripts/lean_check_tree.sh "$repo/scripts/lean_check_tree.sh"
if [ "$side" = Base ]; then
    test "$(cat "$meta/BaseCensus.rc")" = 0
    test "$(cat "$meta/BaseLegacy.rc")" = 0
    python3 -I "$area/prepare_seals.py" "$area" "$repo" Base
    target="$meta/base-seals"
    bash "$area/run_probes.sh" "$toolchain" "$meta/base/oleans" "$target/CCA2SchemeSeal"
else
    index="$(python3 -I - "$area/native/PLAN.json" "$area/MOVE-SCOPE.json" <<'PY'
import json,sys
plan, scope = (json.load(open(p)) for p in sys.argv[1:])
print(f"{plan['rebuild'].index(scope['legacy'])+1:04d}")
PY
    )"
    deadline=$((SECONDS + 120))
    until [ -n "$(find "$area/native" -maxdepth 2 -name "check-$index.json" -print -quit)" ]; do
        test "$SECONDS" -lt "$deadline"
        sleep 3
    done
    python3 -I "$area/prepare_probes.py" "$area" Head "$campaign"
    tree="$meta/head/oleans"
    bash "$area/run_probes.sh" "$toolchain" "$tree" "$meta/HeadCensus" "$meta/HeadLegacy" "$meta/Standalone"
    python3 -I "$area/prepare_seals.py" "$area" "$repo" Head
    target="$meta/head-seals"
    bash "$area/run_probes.sh" "$toolchain" "$tree" "$target/EncryptThenTagSeal" "$target/UnsealedControl" \
        "$target/SealedControl" "$target/ReaderControl"
fi
