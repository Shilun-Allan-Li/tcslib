"""Prepare the bounded OracleSecurity review and the records-only update."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

area=Path(sys.argv[1]).resolve()
mode=sys.argv[2]

def read(rel):
    return json.loads((area/rel).read_bytes())

def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()

source,native,decl,reads=map(read,('SOURCE-CHECK.json','native-final/RESULT.json','DECLARATIONS.json','READS.json'))
plan=read('native-final/PLAN.json')
base,head=native['base'],native['head']
assert all(r['base']==base and r['head']==head for r in (source,plan,decl,reads))
assert native['passed'] and reads['passed'] and decl['new_declarations']==0
assert reads['diagnostics']==0
affected=len(plan['affected'])
retained=native['initial_retained']
assert native['fresh_native_checks']==affected+1 and 'audits/pass-shelat/Checks' not in plan['affected']
count=decl['count']
moved=len(decl['rehomed'])
private=len(decl['private_name_changes'])
full=reads['whole_file_seals']
repo='https://github.com/Shilun-Allan-Li/tcslib'
plan_doc='briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md'
review='pke-pilot-oracle-2026-11-09'
review_doc=f'briefs/pass-shelat-ch5-8/maintainer/{review}/README.md'
if mode=='pr':
    (area/'pr-body.md').write_text(f"""## Public-key encryption pilot

Move the fixed-length scheme, canonical padding, challenge codecs, and
CPA, CCA1 and CCA2 games into `OracleSecurity`. Their Lean statements and
proofs move verbatim. The public-key facade exports the new module.

The legacy `Composability.PublicKey` import re-exports these declarations
and houses the trapdoor CPA corollary. `OracleSecurity` imports the shared
oracle definitions, ensemble interfaces and machine-length bounds. The
proof of `BitPublicKeyScheme.SingleBitSecure.padded_cpa` remains pending.

## Verification

- All {affected} affected modules and campaign Checks compile. The replay checks
  {retained:,} retained objects.
- Both standalone imports pass, including a test of the approved
  `pairFstD_padCt` simp rule. The census matches {count} declarations and
  {moved} owner changes, including {private} generated private names.
- All {full} scoped whole-file seals pass. The explicit tactic and
  generated-equation scans find zero foreign reads.
- Both style checks pass. The new module groups the tightly coupled
  padding and game proofs in one file.

Base `{base}`. Checked head `{head}`.

[Approved pilot map]({repo}/blob/{base}/{plan_doc})
""")
elif mode=='records':
    campaign=Path(sys.argv[3])
    pr=read('pr-live.json')
    assert pr['headRefOid']==head and pr['baseRefName']=='cryptography/pass-shelat-ch2-4'
    assert pr['state']=='OPEN' and not pr['isDraft'] and pr['mergeable']=='MERGEABLE'
    assert re.fullmatch(re.escape(repo)+r'/pull/\d+',pr['url'])
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=campaign,text=True).strip()==base
    assert {r['path'] for r in pr['files']}=={p+'.lean' for p in (
        'TCSlib/Cryptography/Composability/PublicKey','TCSlib/Cryptography/Encryption/PublicKey',
        'TCSlib/Cryptography/Encryption/PublicKey/OracleSecurity')}
    number,url=pr['number'],pr['url']
    stage=area/'records'
    evidence=stage/'evidence'
    evidence.mkdir(parents=True)
    archive=area/'oracle-checks.zip'
    digest=sha(archive)
    for file in (archive.name,'pr-live.json'):
        shutil.copyfile(area/file,evidence/file)
    files=['native-final/'+s for s in ('PLAN.json','PRODUCTS.json','RESULT.json')]
    files+=['SOURCE-CHECK.json','DECLARATIONS.json','SEALS.json','READS.json','read-scan/scan.log','pr-live.json']
    data={'base':base,'head':head,'passed':True,'pr':number,'pr_url':url,
          'native':{'affected':affected,'fresh':native['fresh_native_checks'],'retained':retained},
          'declarations':{'count':count,'rehomed':moved,'private_name_changes':private,'new':0,
                          'inherited_sorry_dependencies':len(decl['inherited_sorry_dependencies'])},
          'seals':{'whole_file':full,'requests':reads['requests'],'diagnostics':0,'explicit_or_generated_reads':0,
                   'verified_retained_controls':decl['reused_sensitivity_controls']},
          'artifact_sha256':{rel:sha(area/rel) for rel in files},
          'archive':{'name':archive.name,'sha256':digest,'bytes':archive.stat().st_size}}
    (evidence/'VERIFICATION.json').write_text(json.dumps(data,indent=2)+'\n')
    (evidence/'README.md').write_text(f"""# Fixed-length public-key schemes and oracle security

Seyoon merged the [ensemble relocation #258]({repo}/pull/258) at `{base}`.
[PR #{number}]({url}) moves the fixed-length scheme and oracle games at `{head}`.
It follows the [approved pilot](../cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md).

`OracleSecurity` groups the scheme, canonical padding, challenge codecs
and the CPA, CCA1 and CCA2 games. The general stateful oracle interfaces
live in the shared game modules. The legacy `Composability.PublicKey`
import re-exports the oracle module and houses the trapdoor CPA corollary.
The corollary still uses the pending `BitPublicKeyScheme.SingleBitSecure.padded_cpa`
bridge.

- The replay verifies {retained:,} retained objects and compiles all {affected} affected
  modules plus campaign Checks. The Checks object and output match #258.
- Standalone probes check the new and legacy imports, including the
  previously approved `pairFstD_padCt` simp rule. The new import closure
  excludes the trapdoor construction.
- The census matches all {count} declaration types, definitions, references
  and axiom dependencies. It maps {moved} declarations to the new module
  and accounts for {private} generated private names and elaborator labels.
- All {full} whole-file seals pass with {reads['requests']:,} requests.
  The explicit and generated-equation scans find zero reads. The thirteen
  sensitivity controls transfer through identical checked closures, and
  the generated-equation collector reruns its two controls.
- Plain and campaign style checks pass. `OracleSecurity` stays in one
  660-line file to keep the padding and game proofs beside their definitions.

The oracle scopes carry no diagnostics. The earlier ensemble ledger remains
the reference for the inherited reads in its own modules.

`VERIFICATION.json` binds the checked head to the evidence.
The SHA-256 of `oracle-checks.zip` is `{digest}`.

**Clear to merge — the oracle relocation and both imports pass.**
""")
    handoff=campaign/'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md'
    lines=handoff.read_text().splitlines(keepends=True)
    i,= (i for i,l in enumerate(lines) if l.startswith('| Cleanup and reorganization | '))
    prefix,marker,_=lines[i].partition('[Ensemble relocation PR #258]')
    assert marker
    lines[i]=prefix+f"""Seyoon merged the [ensemble relocation #258]({repo}/pull/258) at `{base}`. [Oracle security PR #{number}]({url}) at `{head}` is clear for Seyoon to merge. The fixed-length scheme, padding and oracle games have their new home. The legacy import exposes them and the trapdoor CPA corollary. All four oracle scopes seal cleanly. See the [relocation review](maintainer/{review}/README.md), [ensemble ledger](maintainer/pke-pilot-ensemble-2026-11-09/README.md) and [pilot map](maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md). Resume the next move after this slice lands. Efficiency still needs the recorded issue-time probes. |
"""
    (stage/'MAINTAINER-HANDOFF.md').write_text(''.join(lines))
    decision=campaign/'PassShelatChapter5-8Plan.md'
    log=decision.read_text()
    assert log.endswith('\n') and '#257 merged and PKE ensemble relocation verified' in log.splitlines()[-1]
    row=f"""| 2026-11-09 (PST) | **#258 merged and the PKE oracle security move verified.** Seyoon merged #258 at `{base}`. [PR #{number}]({url}) at `{head}` moves the fixed-length scheme, padding, codecs and CPA/CCA games. The legacy import re-exports them and houses the trapdoor CPA corollary. The {affected} affected modules and Checks pass. The census matches {count} declarations, including {moved} moves. All {full} whole-file seals pass. [Verification]({review_doc}). Seyoon merges this slice before the next move. | record |
"""
    (stage/'PassShelatChapter5-8Plan.md').write_text(log+row)
    print(review,digest)
else:
    raise ValueError(mode)
