"""Relocate the fixed-length scheme, its codecs and the oracle games."""
from pathlib import Path
import sys

crypto=Path(sys.argv[1])/'TCSlib/Cryptography'
old=crypto/'Composability/PublicKey.lean'
facade=crypto/'Encryption/PublicKey.lean'
oracle=crypto/'Encryption/PublicKey/OracleSecurity.lean'
source=old.read_text()
ns='namespace TCSlib.Cryptography.Composability'
end='end TCSlib.Cryptography.Composability'
start_bridge='/-- **Claim 172.a: Algorithm 104.3 is CPA-secure**'
assert source.count(start_bridge)==1
body,bridge=source.split(start_bridge)
bridge=start_bridge+bridge
oracle_module='TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity'
asym='TCSlib.Cryptography.Asymptotic.PublicKey'

def replace_once(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after,1)

body=replace_once(body,'import '+asym,
                  'import TCSlib.Cryptography.Asymptotic.CollectionsHelpers\n'
                  'import TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity')
body=replace_once(body,'# CPA, CCA1 and CCA2 security of public-key encryption (statement phase)',
                  '# CPA, CCA1 and CCA2 security of public-key encryption')
body=replace_once(body,'Claim 172.a (inventory): Algorithm 104.3 is CPA-secure.',
                  'The trapdoor application of Claim 172.a is in `Composability.PublicKey`.')
body=replace_once(body,"""* `TrapdoorCollection.tdpBitScheme_padded_cpa` (Claim 172.a, proved from the previous result and
  [PS10, Theorem 104.4]).
""",'')
body=replace_once(body,'/-! ### Claim 172.a -/','/-! ### From ensemble security to CPA -/')
oracle.write_text(body.rstrip()+'\n\n'+end+'\n')

copyright=source[:source.index('import ')]
options=source[source.index('set_option'):source.index('/-!\n#')]
scope=source[source.index(ns):source.index('/-! ### Canonical padding')]
old.write_text(copyright+f"""import {asym}
import {oracle_module}

"""+options+"""/-!
# Trapdoor encryption in the public-key CPA game

This module provides the original public-key game import through
`TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity`.

## Main definitions

`OracleSecurity` defines the fixed-length public-key scheme, its codecs and its security games.

## Main results

`TCSlib.Cryptography.TrapdoorCollection.tdpBitScheme_padded_cpa` applies the
ensemble-to-CPA bridge to the trapdoor construction of Algorithm 104.3.
It uses the stated `BitPublicKeyScheme.SingleBitSecure.padded_cpa` bridge.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Algorithm 104.3, Theorem 104.4 and Claim 172.a.)
-/

"""+scope+bridge)
text=facade.read_text()
text=replace_once(text,'import TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity\n',
    'import TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity\nimport '+oracle_module+'\n')
text=replace_once(text,"""* `Composability.PublicKey` provides the ciphertext codec and oracle games [PS10, §7.1.4].
  The proof of `TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.padded_cpa` is pending.
""","""* `OracleSecurity` gives the fixed-length scheme, codecs and oracle games [PS10, §7.1.4].
  The proof of `TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.padded_cpa` is pending.
* `Composability.PublicKey` re-exports the oracle games and gives the trapdoor CPA corollary.
""")
facade.write_text(text)
