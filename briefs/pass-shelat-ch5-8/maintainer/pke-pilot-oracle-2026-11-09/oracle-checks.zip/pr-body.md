## Public-key encryption pilot

Move the fixed-length scheme, canonical padding, challenge codecs, and
CPA, CCA1 and CCA2 games into `OracleSecurity`. Their Lean statements and
proofs move verbatim. The public-key facade exports the new module.

The legacy `Composability.PublicKey` import re-exports these declarations
and houses the trapdoor CPA corollary. `OracleSecurity` imports the shared
oracle definitions, ensemble interfaces and machine-length bounds. The
proof of `BitPublicKeyScheme.SingleBitSecure.padded_cpa` remains pending.

## Verification

- All 7 affected modules and campaign Checks compile. The replay checks
  1,073 retained objects.
- Both standalone imports pass, including a test of the approved
  `pairFstD_padCt` simp rule. The census matches 236 declarations and
  128 owner changes, including 6 generated private names.
- All 4 scoped whole-file seals pass. The explicit tactic and
  generated-equation scans find zero foreign reads.
- Both style checks pass. The new module groups the tightly coupled
  padding and game proofs in one file.

Base `7f3129d5b2ab5f2aac97c2a83eb4893b1217cd5f`. Checked head `b4b04839bd16de049e55f6053b2491db94a9b7e9`.

[Approved pilot map](https://github.com/Shilun-Allan-Li/tcslib/blob/7f3129d5b2ab5f2aac97c2a83eb4893b1217cd5f/briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
