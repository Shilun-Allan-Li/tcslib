"""Compare full seal coverage and verify the oracle move has no scoped reads."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import sys

area,previous,campaign=(Path(s).resolve() for s in sys.argv[1:4])


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


before=read(previous/'SEALS.json')
after=read(area/'SEALS.json')
decl=read(area/'DECLARATIONS.json')
source=read(area/'SOURCE-CHECK.json')
plan=read(area/'native-final/PLAN.json')
assert all(r['head']==plan['head'] and r['base']==plan['base'] for r in (source,decl))
receipt=read(campaign/'briefs/pass-shelat-ch5-8/maintainer/pke-pilot-ensemble-2026-11-09/VERIFICATION.json')
assert receipt['head']==plan['baseline'] and receipt['passed']
for path in ('SEALS.json','read-scan/scan.log'):
    assert receipt['artifact_sha256'][path]==sha(previous/path)
base_source=read(previous/'native-final/PLAN.json')['source_digests']
old={r['owner']:r for r in before['outcomes']}
current={r['owner']:r for r in after['outcomes']}
assert len(current)==4 and after['source_errors']==0
assert all(r['valid_harness'] and r['rc']==0 and not r['errors'] for r in current.values())
legacy='TCSlib.Cryptography.Composability.PublicKey'
oracle='TCSlib.Cryptography.Encryption.PublicKey.OracleSecurity'
consumer='TCSlib.Cryptography.Composability.NonMalleable'
moves={r['base_name']['display']:r for r in decl['rehomed']}


def meta(folder,row):
    f=folder/'seals'/(row['label']+'.json')
    assert sha(f)==row['meta_sha256'] and sha(Path(row['log']))==row['log_sha256']
    return read(f)


def translate(row):
    moved=moves.get(row['spelling'])
    if moved is None:
        return row
    assert row['home']==legacy
    name=moved['head_name']
    return {**row,'spelling':name['display'],'name_components':name['components'],
            'home':oracle,'home_components':[['str',s] for s in oracle.split('.')]}


relocated_foreign={r['spelling']:r for r in meta(area,current[consumer])['requested'] if r['home']==oracle}
assert relocated_foreign
scopes=[]
for owner,row in current.items():
    past=old[legacy if owner==oracle else owner]
    assert past['valid_harness'] and past['rc']==0 and not past['errors']
    assert base_source[past['path'][:-5]]==past['source_sha256']
    old_meta,new_meta=meta(previous,past),meta(area,row)
    keep=[translate(r) for r in old_meta['requested']]
    keep={r['spelling']:r for r in keep if r['home'] in new_meta['closure_homes']}
    if owner!=oracle:
        assert len(keep)==len(old_meta['requested']),owner
    additions=relocated_foreign if owner==legacy else {}
    assert not keep.keys()&additions.keys()
    actual={r['spelling']:r for r in new_meta['requested']}
    expected={**keep,**additions}
    assert actual==expected,(owner,actual.keys()-expected.keys(),expected.keys()-actual.keys())
    scopes.append({'owner':owner,'base_requests':len(old_meta['requested']),
                   'kept_visible_requests':len(keep),'newly_foreign':sorted(additions),
                   'current_requests':len(actual),'source_sha256':row['source_sha256']})
assert 'style_lint: 0 FAIL, 0 WARN' in (area/'style-campaign-final.log').read_text()
assert '0 findings in 3 files' in (area/'style-final.log').read_text()
scan=(area/'read-scan/scan.log').read_text()
for line in scan.splitlines():
    if line.startswith('## (c'):
        assert re.search(r': 0(?:$| \(of )',line),line
paths={old[owner]['path'] for owner in current if owner in old}
for line in (previous/'read-scan/scan.log').read_text().splitlines():
    assert not any(line.startswith(p+':') or line.startswith(p[:-5].replace('/','.')+'\t') for p in paths)

report={'base':plan['base'],'head':plan['head'],'passed':True,'scopes':scopes,
        'requests':sum(r['requested'] for r in current.values()),
        'whole_file_seals':len(current),'diagnostics':0,'c1_c2_c3_reads':0,
        'predecessor_seal_sha256':sha(previous/'SEALS.json')}
with (area/'READS.json').open('x') as f:
    json.dump(report,f,indent=2)
    f.write('\n')
print(len(scopes),'clean whole-file seals;',report['requests'],'requests;',len(relocated_foreign),'newly foreign definitions')
