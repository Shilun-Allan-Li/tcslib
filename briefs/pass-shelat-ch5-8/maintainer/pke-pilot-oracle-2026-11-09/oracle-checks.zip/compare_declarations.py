"""Compare the kernel declarations at the old and new oracle-game module homes."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys
from zipfile import ZipFile

sys.setrecursionlimit(30000)
area,previous,cleanup,campaign=(Path(s).resolve() for s in sys.argv[1:5])
native=area/'native-final'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def name_key(name):
    return tuple(map(tuple,name['components']))


plan=read(native/'PLAN.json')
result=read(native/'RESULT.json')
prior=read(previous/'native-final/PLAN.json')
assert result['passed'] and result['head']==plan['head'] and result['base']==plan['base']
assert result['plan_sha256']==sha(native/'PLAN.json') and result['products_sha256']==sha(native/'PRODUCTS.json')
assert prior['head']==plan['baseline']
assert all(prior[k]==plan[k] for k in ('toolchain_sha256','checker_sha256'))
assert {n:r['sha256'] for n,r in prior['external'].items()}=={n:r['sha256'] for n,r in plan['external'].items()}

record=campaign/'briefs/pass-shelat-ch5-8/maintainer/pke-pilot-ensemble-2026-11-09'
receipt=read(record/'VERIFICATION.json')
assert receipt['passed'] and receipt['head']==prior['head']
archive=record/receipt['archive']['name']
assert sha(archive)==receipt['archive']['sha256']
original_inputs={}
with ZipFile(archive) as prior_archive:
    for rel in ('metadata/Head-compact.json','metadata/Head.jsonl','metadata/run/C3.log'):
        with prior_archive.open(rel) as f:
            h=file_digest(f,'sha256').hexdigest()
        assert sha(previous/rel)==h
        original_inputs[rel]=h

original=read(previous/'metadata/Head-compact.json')
candidate=read(area/'metadata/Head-compact.json')
prefix='TCSlib.Cryptography.'
legacy=prefix+'Composability.PublicKey'
oracle=prefix+'Encryption.PublicKey.OracleSecurity'
bridge=prefix+'TrapdoorCollection.tdpBitScheme_padded_cpa'
before_homes={n['display'] for n in candidate['owners']}-{oracle}
assert before_homes=={prefix+'Composability.'+m for m in ('PublicKey','NonMalleable','SimNonMalleable')}
old={name_key(r['name']):r for r in original['roots'] if r['home'] in before_homes}
new={name_key(r['name']):r for r in candidate['roots']}
assert len(new)==len(candidate['roots'])==len(old)==236
assert original['axiom_names']==candidate['axiom_names']


def private_prefix(home):
    return tuple(('str',s) for s in ('_private.'+home).split('.'))


old_prefix,new_prefix=private_prefix(legacy),private_prefix(oracle)
pairs={}
for k,r in old.items():
    if k in new:
        pairs[k]=k
    else:
        assert r['home']==legacy and k[:len(old_prefix)]==old_prefix and k[len(old_prefix)][0]=='num'
        pairs[k]=new_prefix+k[len(old_prefix):]
assert set(pairs.values())==new.keys()
renames={old[k]['name']['display']:new[v]['name']['display'] for k,v in pairs.items() if k!=v}
relocations=[]
term_checks={}
for k,v in pairs.items():
    a,b=old[k],new[v]
    expected=oracle if a['home']==legacy and a['name']['display']!=bridge else a['home']
    assert b['home']==expected,b['name']
    if expected==oracle:
        relocations.append({'base_name':a['name'],'head_name':b['name'],'base_home':legacy,'head_home':oracle})
    assert all(a[f]==b[f] for f in ('kind','universes','axioms')),b['name']
    for field in ('type_refs','value_refs'):
        assert {renames.get(n,n) for n in a[field]}==set(b[field]),(b['name'],field)
    fields=[f for f,key in (('type','type_sha256'),('definition_value','definition_sha256')) if a[key]!=b[key]]
    if fields:
        term_checks[k]=fields
assert len(relocations)==128


def extract(path,roots,terms):
    rows,catalog={},{}
    with path.open() as f:
        for r in map(json.loads,f):
            if r['record'] not in ('root','catalog'):
                continue
            k=name_key(r['name'])
            if r['record']=='root' and k in terms:
                rows[k]=r
            if r['record']=='catalog' and k in roots:
                catalog[k]={f:r[f] for f in ('kind','status','abbrev','instance','matcher')}
    assert rows.keys()==terms and catalog.keys()==roots
    return rows,catalog


a_raw,a_catalog=extract(previous/'metadata/Head.jsonl',old.keys(),term_checks.keys())
b_raw,b_catalog=extract(area/'metadata/Head.jsonl',new.keys(),{pairs[k] for k in term_checks})
assert all(a_catalog[k]==b_catalog[v] for k,v in pairs.items())


def canonical(expr,mapping,labels,path=()):
    if not isinstance(expr,list) or not expr:
        return expr
    if expr[0] in ('forall','lam','let'):
        label=name_key(expr[1])
        scope=('str','_@')
        if scope in label:
            assert ('str','_hyg') in label or ('str','_hygCtx') in label,label
            labels[path+(1,)]=expr[1]
            label=label[:label.index(scope)]
        return [expr[0],label,*[canonical(x,mapping,labels,path+(i,)) for i,x in enumerate(expr[2:],2)]]
    if expr[0] in ('const','proj'):
        label=name_key(expr[1])
        name=mapping.get(label,label)
        if name!=label:
            labels[path+(1,)]=expr[1]
        return [expr[0],name,*[canonical(x,mapping,labels,path+(i,)) for i,x in enumerate(expr[2:],2)]]
    return [canonical(x,mapping,labels,path+(i,)) for i,x in enumerate(expr)]


term_adjustments=[]
for k,fields in sorted(term_checks.items()):
    v=pairs[k]
    for field in fields:
        a,b={},{}
        assert canonical(a_raw[k][field],pairs,a)==canonical(b_raw[v][field],{},b),(new[v]['name'],field)
        changed=[{'path':p,'base':a.get(p),'head':b.get(p)} for p in sorted(a.keys()|b.keys()) if a.get(p)!=b.get(p)]
        assert changed
        term_adjustments.append({'name':new[v]['name'],'field':field,'labels':changed})


def c3(path,homes):
    roots,pairs,controls=[],[],[]
    for line in path.read_text().splitlines():
        for label,dest in (('ROOT',roots),('REF',pairs),('CONTROL',controls)):
            marker='G06-C3-'+label+' '
            if line.startswith(marker):
                fields=line[len(marker):].split(' | ')
                if label=='CONTROL' or fields[0] in homes:
                    dest.append(tuple(fields))
    return roots,pairs,controls


for path,rows in ((previous/'metadata/run/C3.log',old),(area/'metadata/run/C3.log',new)):
    roots,refs,c3_controls=c3(path,{r['home'] for r in rows.values()})
    assert not refs,refs
    assert Counter((row[0],row[1]) for row in roots)==Counter((r['home'],r['name']['display']) for r in rows.values())
    assert len(c3_controls)==2 and 'expected=1 actual=1' in c3_controls[0][0] and 'expected=0 actual=0' in c3_controls[1][0]
assert f'G06-C3-END base={plan["base"]} head={plan["head"]} modules=4 roots={len(new)} pairs=0 ' in (
    area/'metadata/run/C3.log').read_text()

control_root=cleanup/'controls-final-r1'
controls=read(control_root/'RESULT.json')
control_manifest=read(control_root/'MANIFEST.json')
assert controls['passed'] and len(controls['outcomes'])==13
a_products=read(previous/'native-final/PRODUCTS.json')
b_products=read(native/'PRODUCTS.json')
pending=[control_manifest['owner'].replace('.','/')]
seen=set()
while pending:
    m=pending.pop()
    if m in seen:
        continue
    seen.add(m)
    assert prior['graph'][m]==plan['graph'][m]
    assert all(a_products[m][k]==b_products[m][k] for k in ('object_sha256','source_sha256','direct_local'))
    assert sha(Path(plan['tree'])/(m+'.olean'))==b_products[m]['object_sha256']
    pending.extend(plan['graph'][m])
for p,r in zip(control_manifest['probes'],controls['outcomes'],strict=True):
    assert all(r[k]==v for k,v in p.items()) and r['rc']==p['expected_rc'] and len(r['errors'])==p['expected_errors']
    assert sha(Path(r['module']+'.lean'))==r['source_sha256']
    assert sha(control_root/(r['label']+'.log'))==r['log_sha256']

checks='audits/pass-shelat/Checks'
assert all(a_products[checks][k]==b_products[checks][k] for k in ('object_sha256','source_sha256','log_sha256'))
out={'base':plan['base'],'head':plan['head'],'count':len(new),'rehomed':relocations,'private_name_changes':renames,
     'term_adjustments':term_adjustments,'axiom_names':candidate['axiom_names'],
     'inherited_sorry_dependencies':[r['name']['display'] for r in new.values() if 'sorryAx' in r['axioms']],
     'new_declarations':0,'same_checks_log_sha256':b_products[checks]['log_sha256'],
     'native_axiom_controls':candidate['native_axiom_controls'],'reused_sensitivity_controls':len(controls['outcomes']),
     'control_closure_modules':len(seen),'c3_controls':c3_controls,'published_baseline_inputs':original_inputs}
with (area/'DECLARATIONS.json').open('x') as f:
    json.dump(out,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(len(new),'existing declarations;',len(relocations),'moves;',len(renames),'private names;',
      len(term_adjustments),'normalized expressions;',len(out['inherited_sorry_dependencies']),'inherited admission dependencies')
