#!/usr/bin/env bash
set -euo pipefail
area=$1
repo=$2
campaign=$3
side=$4
meta="$area/metadata"
toolchain="$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$area/native/PLAN.json")"
cmp scripts/lean_check_tree.sh "$repo/scripts/lean_check_tree.sh"
if [ "$side" = Base ]; then
    test "$(cat "$meta/BaseCensus.rc")" -eq 0
    test "$(cat "$meta/BaseLegacy.rc")" -eq 0
    python3 -I "$area/prepare_seals.py" "$area" "$repo" Base
    bash "$area/run_probes.sh" "$toolchain" "$meta/base/oleans" "$meta/base-seals/EncryptionSeal"
else
    deadline=$((SECONDS + 200))
    while ! find "$area/native" -maxdepth 2 -name check-0003.json -print -quit | grep -q .; do
        test "$SECONDS" -lt "$deadline"
        sleep 3
    done
    python3 -I "$area/prepare_probes.py" "$area" Head "$campaign"
    tree="$meta/head/oleans"
    bash "$area/run_probes.sh" "$toolchain" "$tree" "$meta/HeadCensus" "$meta/HeadLegacy" "$meta/SchemeStandalone" "$meta/EnsembleStandalone"
    python3 -I "$area/prepare_seals.py" "$area" "$repo" Head
    target="$meta/head-seals"
    bash "$area/run_probes.sh" "$toolchain" "$tree" "$target/EncryptionSeal" "$target/SchemeSeal" "$target/EnsembleSecuritySeal" \
        "$target/UnsealedControl" "$target/SealedControl" "$target/ReaderControl"
fi
