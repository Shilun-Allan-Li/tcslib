"""Compare checked declaration types, definition values, and legacy imports."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
scope = json.loads((area / "MOVE-SCOPE.json").read_bytes())
legacy, scheme, games = (scope[name].replace("/", ".") for name in ("legacy", "scheme", "games"))
promoted = scope["promoted_helper"]
standard = {"propext", "Classical.choice", "Quot.sound"}
hygiene = ("str", "_@")


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def catalog(side, owners):
    rows = [json.loads(line) for line in (meta / (side + ".jsonl")).open()]
    last = rows.pop()
    assert last["record"] == "complete" and last["catalog"] == sum(r["record"] == "catalog" for r in rows)
    assert {name["display"] for name in last["owners"]} == owners
    result = {r["name"]["display"]: r for r in rows if r["record"] == "constant"}
    assert len(result) == last["count"] and {r["home"]["display"] for r in result.values()} == owners
    assert all({item["display"] for item in r["axioms"]} <= standard for r in result.values())
    return result


def suffix(r):
    name = key(r["name"])
    home = key(r["home"])
    if name[:len(home)+1] == (("str", "_private"),) + home:
        assert name[len(home)+1][0] == "num"
        return name[len(home)+2:]
    return name


def canonical(expr, names):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, label, *[canonical(part, names) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, names.get(name, name), *[canonical(part, names) for part in expr[2:]]]
    return [canonical(part, names) for part in expr]


base = catalog("Base", {legacy})
head = catalog("Head", {legacy, scheme, games})
assert len(base) == 80
suffixes = {suffix(row): name for name, row in head.items()}
assert len(suffixes) == len(head)
pairs = {}
for name, row in base.items():
    if name in head:
        pairs[name] = name
    elif name == "_private." + legacy + ".0.TCSlib.Cryptography.acceptProb_distinguisherL_congr":
        pairs[name] = promoted
    else:
        assert suffix(row) in suffixes, name
        pairs[name] = suffixes[suffix(row)]
assert set(pairs.values()) == set(head), (set(head) - set(pairs.values()), set(pairs.values()) - set(head))
renamed = {key(base[name]["name"]): key(head[new]["name"]) for name, new in pairs.items() if name != new}
assert all(name[0] == ("str", "_private") for name in renamed)
errors = []
result = []
proof_deltas = {}
for name, target in sorted(pairs.items()):
    a, b = base[name], head[target]
    old_home, new_home = a["home"]["display"], b["home"]["display"]
    for field in ("kind", "status", "abbrev", "instance", "matcher", "levels"):
        if a[field] != b[field]:
            errors.append((name, field))
    if {key(item) for item in a["axioms"]} != {key(item) for item in b["axioms"]}:
        errors.append((name, "axioms"))
    if canonical(a["type"], renamed) != canonical(b["type"], {}):
        errors.append((name, "type"))
    if {renamed.get(key(ref), key(ref)) for ref in a["type_refs"]} != {key(ref) for ref in b["type_refs"]}:
        errors.append((name, "type_refs"))
    if canonical(a["definition_value"], renamed) != canonical(b["definition_value"], {}):
        errors.append((name, "definition_value"))
    if a["kind"] == "theorem":
        mapped = {renamed.get(key(ref), key(ref)) for ref in a["value_refs"]}
        actual = {key(ref) for ref in b["value_refs"]}
        if mapped != actual:
            show = lambda refs: sorted(".".join(part for _, part in ref) for ref in refs)
            proof_deltas[name] = {"removed": show(mapped - actual), "added": show(actual - mapped)}
    result.append({"old_name": name, "new_name": target, "old_home": old_home, "new_home": new_home,
                   "kind": a["kind"], "axioms": sorted(i["display"] for i in b["axioms"])})
assert not errors, errors
labels = ("BaseCensus", "HeadCensus", "BaseLegacy", "HeadLegacy", "SchemeStandalone", "EnsembleStandalone")
assert all((meta / (label + ".rc")).read_text().strip() == "0" for label in labels)
base_log = (meta / "BaseLegacy.log").read_bytes()
assert (meta / "HeadLegacy.log").read_bytes() == base_log
assert base_log.startswith((meta / "SchemeStandalone.log").read_bytes() +
                           (meta / "EnsembleStandalone.log").read_bytes())
moved = Counter(r["new_home"] for r in result if r["old_home"] != r["new_home"])
assert set(moved) == {scheme, games}
(area / "DECLARATIONS.json").write_text(json.dumps({
    "base": (area / "base.txt").read_text().strip(), "head": (area / "head.txt").read_text().strip(),
    "matched_declarations": len(result), "relocated_declarations": sum(moved.values()),
    "new_homes": moved, "private_name_changes": len(renamed),
    "type_and_definition_comparison": "same kernel syntax modulo generated binder scopes and relocated private names",
    "axioms_match": True, "legacy_and_new_imports_agree": True,
    "catalog_sha256": {side: sha(meta / (side + ".jsonl")) for side in ("Base", "Head")},
    "promoted_helper": promoted, "proof_dependency_deltas": proof_deltas, "declarations": result,
}, indent=2) + "\n")
print("All 80 declaration types, definition values and axiom sets match.")
print("Moved declarations:", dict(moved))
