"""Stage the scheme and game move from the exact merged source."""
import json
from pathlib import Path
import subprocess
import sys

area, repo = (Path(arg).resolve() for arg in sys.argv[1:3])
base = (area / "base.txt").read_text().strip()
crypto = "TCSlib/Cryptography/"
old = crypto + "Asymptotic/Encryption"
facade = crypto + "Encryption/PrivateKey"
scheme = facade + "/Scheme"
games = facade + "/EnsembleSecurity"


def show(module):
    return subprocess.check_output(["git", "show", f"{base}:{module}.lean"], cwd=repo).decode()


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


raw = show(old)
indices = {
    "transport": raw.index("/-! ### Transporting a distinguisher"),
    "interface": raw.index("/-! ### Efficient private-key encryption"),
    "ensemble": raw.index("namespace PrivateKeyScheme\n"),
    "prg": raw.index("/-! ### The one-time pad"),
    "deterministic": raw.index("/-! ### Deterministic schemes are not multi-message secure"),
    "end": raw.index("end TCSlib.Cryptography\n"),
}
assert list(indices.values()) == sorted(indices.values())


def block(start, end):
    return raw[indices[start]:indices[end]]


def header(imports, doc):
    copyright = raw[:raw.index("import ")]
    options = raw[raw.index("set_option "):raw.index("/-!")]
    return copyright + "".join("import " + name + "\n" for name in imports) + "\n" + options + doc


crypto_dot = "TCSlib.Cryptography."
scheme_doc = """/-!
# Private-key encryption schemes

## Main definitions

`TCSlib.Cryptography.PrivateKeyScheme` packages uniform polynomial-time key generation,
encryption and decryption for `n`-bit messages [PS10, Definition 24.7].

## Main results

The `correct` field requires decryption to recover the message for every choice of
key-generation, encryption and decryption coins.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§2.1.3, Definition 24.7.)
-/

"""
game_doc = """/-!
# Private-key ensemble security

The adversary receives a ciphertext or a fixed vector of ciphertexts, together with the
security parameter. The vector uses one key and independent encryption coins. Its
polynomially many ciphertexts are encoded as nested pairs.

## Main definitions

* `PrivateKeyScheme.encDist` and `PrivateKeyScheme.multiEncDist` sample the ciphertexts.
* `PrivateKeyScheme.SingleMessageSecure` and `PrivateKeyScheme.MultiMessageSecure` express
  negligible distinguishing advantage [PS10, Definitions 91.1 and 93.1].
* `PrivateKeyScheme.Deterministic` says encryption ignores its coins.

## Main results

* `PrivateKeyScheme.MultiMessageSecure.singleMessageSecure` reduces the single-message
  game to the vector game [PS10, §3.7].
* `PrivateKeyScheme.not_multiMessageSecure_of_deterministic` uses a two-message
  distinguisher to rule out security for stateless deterministic schemes
  [PS10, Theorem 94.2].

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.5, Definition 91.1, and §3.7, Definition 93.1 and Theorem 94.2.)
-/

"""
prg_doc = """/-!
# Private-key encryption from a pseudorandom generator

The scheme interface and the single-message and fixed-vector ensemble games are defined
in `Encryption.PrivateKey.Scheme` and `Encryption.PrivateKey.EnsembleSecurity`. This
module re-exports both through the legacy import.

## Main definitions

* `padXor` masks a message with the first bits of a pad.
* `prgPadFun` and `prgScheme` implement the pad scheme [PS10, Algorithm 92.1].
  The key is an `n`-bit seed, and encryption uses the first `n` bits of the output.

## Main results

* `acceptProb_padXor` proves perfect secrecy for a uniform pad (Claim-92.a).
* `distAdv_padXor_le` bounds the ciphertext advantage by two PRG advantages.
* `prgScheme_encDist` gives the ciphertext sampler's equation.
* `prgScheme_singleMessageSecure` lifts the four-hybrid argument to the asymptotic
  scheme with an efficient generator evaluator [PS10, Theorem 92.2].

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.6, Algorithm 92.1 and Theorem 92.2.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.2–3.3 (the concrete `distAdv`, `prgAdv`, Lemma 3.2).
-/

"""
namespace = "namespace TCSlib.Cryptography\n\n"
end = "end TCSlib.Cryptography\n"
scheme_text = header([crypto_dot + "Asymptotic.Adversary"], scheme_doc)
scheme_text += namespace + "open Complexity Turing\n\n" + block("interface", "ensemble") + end

transport = replace_once(block("transport", "interface"),
                         "private theorem acceptProb_distinguisherL_congr",
                         "theorem acceptProb_distinguisherL_congr")
ensemble = replace_once(block("ensemble", "prg"), "namespace PrivateKeyScheme\n\n", "")
game_text = header([
    "TCSlib.Complexity.Randomized.Closure",
    "TCSlib.Complexity.Randomized.Repetition",
    scheme.replace("/", "."),
    crypto_dot + "Foundations.Negligible",
], game_doc)
game_text += namespace + "open Complexity Turing\n\nnamespace PrivateKeyScheme\n\n"
game_text += transport + ensemble + block("deterministic", "end") + end

prg = block("prg", "deterministic")
assert prg.count("acceptProb_distinguisherL_congr") == 4
prg = prg.replace("acceptProb_distinguisherL_congr", "PrivateKeyScheme.acceptProb_distinguisherL_congr")
prg = replace_once(prg,
    "  show (NUPPT.ofPolyTimeUniform (polyTimeComputable_prgPadFun hF) (.const 0)).runAt n",
    "  rw [PrivateKeyScheme.encDist_apply]\n"
    "  show (NUPPT.ofPolyTimeUniform (polyTimeComputable_prgPadFun hF) (.const 0)).runAt n")
prg = replace_once(prg,
    "    (prgScheme P F hF hG).SingleMessageSecure := by\n  intro D",
    "    (prgScheme P F hF hG).SingleMessageSecure := by\n"
    "  apply (PrivateKeyScheme.singleMessageSecure_iff _).2\n  intro D")
legacy_text = header([crypto_dot + "Asymptotic.Pseudorandom", games.replace("/", ".")], prg_doc)
legacy_text += namespace + "open Complexity Turing Finset\n\n" + prg + end

facade_text = replace_once(show(facade), "import " + old.replace("/", ".") + "\n",
                          "".join("import " + module.replace("/", ".") + "\n"
                                  for module in (scheme, games, old)))
facade_text = replace_once(facade_text,
    "* `Asymptotic.Encryption` gives the scheme interface, the ensemble games, and the\n"
    "  single-message construction from a PRG.",
    "* `Encryption.PrivateKey.Scheme` gives the uniform polynomial-time scheme interface.\n"
    "* `Encryption.PrivateKey.EnsembleSecurity` gives the ensemble games and their relations.\n"
    "* `Asymptotic.Encryption` gives the single-message construction from a PRG.")
sources = {scheme: scheme_text, games: game_text, old: legacy_text, facade: facade_text}
for name, text in sources.items():
    path = area / "source" / (name + ".lean")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
(area / "MOVE-SCOPE.json").write_text(json.dumps({
    "legacy": old, "facade": facade, "scheme": scheme, "games": games,
    "source_blocks": {label: raw[:index].count("\n") + 1 for label, index in indices.items()},
    "promoted_helper": "TCSlib.Cryptography.PrivateKeyScheme.acceptProb_distinguisherL_congr",
    "cross_boundary_readers": ["PrivateKeyScheme.encDist_apply", "PrivateKeyScheme.singleMessageSecure_iff"],
}, indent=2) + "\n")
print("Prepared exact source slices for Scheme and EnsembleSecurity, with two reader calls in the PRG proofs.")
