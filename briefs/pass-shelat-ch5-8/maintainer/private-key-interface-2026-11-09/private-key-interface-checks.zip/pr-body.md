## Changes

- Move `PrivateKeyScheme` and its correctness contract to `Encryption.PrivateKey.Scheme`.
- Move the ciphertext samplers, ensemble security predicates, multi-to-single-message reduction and deterministic-encryption impossibility proof to `Encryption.PrivateKey.EnsembleSecurity`.
- Re-export both modules through the facade and the legacy `Asymptotic.Encryption` import. The legacy file hosts the PRG construction and security proof.
- Give the existing coin-transport lemma a shared name in `PrivateKeyScheme`. Use the published `encDist_apply` and `singleMessageSecure_iff` in the two PRG proofs that cross the new boundary.

## Verification

- All 35 affected modules pass one-module-at-a-time Lean 4.25.0 checking, including the library root and campaign Checks.
- The legacy and standalone imports agree. The census matches all 80 declaration types, definition values and axiom sets and tracks the 56 relocated declarations.
- The whole-file seals pass and the focused seals match the baseline on eight consumers. The control checks direct reduction and the published equation for the ciphertext sampler.
- Source lint and the diff check pass. The four existing reader warnings follow their definitions.
