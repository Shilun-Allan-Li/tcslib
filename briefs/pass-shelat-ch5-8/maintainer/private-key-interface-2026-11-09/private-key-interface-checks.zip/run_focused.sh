#!/usr/bin/env bash
set -euo pipefail
area=$1
repo=$2
side=$3
toolchain="$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$area/native/PLAN.json")"
cmp scripts/lean_check_tree.sh "$repo/scripts/lean_check_tree.sh"
python3 -I "$area/prepare_seals.py" "$area" "$repo" "$side" --focus
lower=$(printf '%s' "$side" | tr '[:upper:]' '[:lower:]')
target="$area/metadata/$lower-focus"
modules=()
for src in "$target"/*Seal.lean; do
    modules+=("${src%.lean}")
done
bash "$area/run_probes.sh" "$toolchain" "$target/oleans" "${modules[@]}"
