import TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity

open TCSlib.Cryptography Turing

example (S : PrivateKeyScheme) (n : ℕ) (m : Fin n → Bool)
    (r : S.gen.Coins n × S.enc.Coins n) :
    S.encDist n m r = S.enc.runAt n (pairEncode (S.gen.runAt n [] r.1) (List.ofFn m)) r.2 := by
  rfl
