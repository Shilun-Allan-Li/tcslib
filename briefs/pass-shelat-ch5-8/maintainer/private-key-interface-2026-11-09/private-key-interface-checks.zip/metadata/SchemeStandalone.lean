import TCSlib.Cryptography.Encryption.PrivateKey.Scheme

#check @TCSlib.Cryptography.PrivateKeyScheme
#check @TCSlib.Cryptography.PrivateKeyScheme.gen
#check @TCSlib.Cryptography.PrivateKeyScheme.correct
