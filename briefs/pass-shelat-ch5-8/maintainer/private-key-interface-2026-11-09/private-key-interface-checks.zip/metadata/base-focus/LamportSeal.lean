/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Authentication.Defs
import TCSlib.Cryptography.Asymptotic.CollectionsHelpers
import TCSlib.Cryptography.Asymptotic.BlockEncryptor
import TCSlib.Cryptography.Asymptotic.OneWay
import TCSlib.Complexity.ClassNP.PolyTimeBlockLoop
/- G06-HARNESS INSTALL LamportSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "LamportSeal"
  let payload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encDist\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\tTCSlib.Cryptography.Asymptotic.Encryption\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\tTCSlib.Cryptography.Asymptotic.Encryption"
  let expectedRequests : Nat := 14
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"Deterministic\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"MultiMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"SingleMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.encDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"firstTwoEqFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"multiEncDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Lamport's one-time signatures (statement phase)

[PS10, Protocol 137.1]: for a one-way function `f`,
- `Gen(1^n)` samples `x_i^b ← U_n` for `i ∈ [n]` and `b ∈ {0, 1}`, and outputs
  `sk = (x_i^b)` and `pk = (f(x_i^b))`;
- `Sign_sk(m)` outputs `σ = (x_1^{m_1}, …, x_n^{m_n})`;
- `Ver_pk(m, σ)` accepts iff `f(σ_i) = f(x_i^{m_i})` for all `i`.

Theorem 137.2: if `f` is one-way, the scheme is one-time secure.

**The encoding.**
- `f` is a function family with `n`-bit inputs at parameter `n` (`lamportOWF`), given with a
  polynomial-time evaluator `E` on `⟨1^n, x⟩` that agrees with `f` on `n`-bit `x` (`hfE`, the
  form of `FunFamily.Easy`).
- The secret key is `Gen`'s `2n²` coins. Segment `i` (bits `2ni` to `2ni + 2n − 1`) is
  `x_i^0 ‖ x_i^1`.
- The public key is the tuple of the pairs `⟨f(x_i^0), f(x_i^1)⟩`, and a signature is the
  concatenation of the `n` revealed preimages: `n²` bits.
- The three algorithms are instances of the ch. 2–4 layer's block loop (`blockEncFun`), run over
  the message bits.

**Deviations, declared once here.**
- **`Ver` tests lengths first.** It rejects unless the message has `n` bits and the signature
  `n²`. So `E` is only ever evaluated on `n`-bit preimage candidates, where it agrees with `f`. An
  evaluator is unconstrained elsewhere, and a `Ver` evaluating it there could accept forgeries
  that do not invert `f`.
- **The one-way function is strong** ([PS10, Definition 27.3], `FunFamily.StrongOneWay`), the
  notes' "one-way function"; by §2.4 a weak one suffices.

## Main definitions

* `Authentication.lamportOWF`: `f` as a `FunFamily`.
* `Authentication.lamport`: Protocol 137.1 as a `SignatureScheme`, with correctness proved.

## Main results

* The ordinary `lamportHalf_eq`, emission and string-function equations expose the algorithms.
* `Authentication.lamportOWF_inLen`, `lamportOWF_outLen`, `lamportOWF_f`: the function-family fields.
* `Authentication.lamport_msgLen`, `lamport_sigLen`, `lamport_gen`, `lamport_sign`, `lamport_ver`:
  the signature-scheme data fields.
* `Authentication.lamportVerFun_sign`: correctness, `Ver` accepts honest signatures.
* `Authentication.lamport_oneTimeSecure` (Thm 137.2, stated; a `sorry` under the source's sketch).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §5.4, Protocol 137.1 and Theorem 137.2 (book pp. 136–138).
-/

namespace TCSlib.Cryptography.Authentication

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games
open TCSlib.Cryptography.PrivateKeyScheme (encodeList)

/-! ### Blocks and block loops -/

/-- The preimage `x_i^b` inside the segment `x_i^0 ‖ x_i^1` of `2n` bits. -/
def lamportHalf (n : ℕ) (b : Bool) (s : List Bool) : List Bool := if b then s.drop n else s.take n

/-- The selected preimage is the suffix after `n` bits for `true`, and the first `n` bits
for `false`. -/
theorem lamportHalf_eq (n : ℕ) (b : Bool) (s : List Bool) :
    lamportHalf n b s = if b then s.drop n else s.take n := rfl

/-- A half of a `2n`-bit segment has `n` bits. -/
theorem length_lamportHalf {n : ℕ} (b : Bool) {s : List Bool} (hs : s.length = 2 * n) :
    (lamportHalf n b s).length = n := by
  cases b <;> simp [lamportHalf, hs] <;> omega

/-- The concatenation of `q` blocks of `B` bits has `q · B` bits. -/
theorem length_flatten_ofFn {B : ℕ} : ∀ {q : ℕ} (g : Fin q → List Bool),
    (∀ i, (g i).length = B) → (List.ofFn g).flatten.length = q * B
  | 0, _, _ => by simp
  | q + 1, g, hg => by
    rw [List.ofFn_succ, List.flatten_cons, List.length_append, hg 0,
      length_flatten_ofFn (fun i => g i.succ) (fun i => hg i.succ), Nat.succ_mul]
    omega

/-- Segment `i` of a concatenation of `B`-bit blocks is block `i`. -/
theorem coinBlock_flatten {B : ℕ} : ∀ (l : List (List Bool)), (∀ c ∈ l, c.length = B) →
    ∀ (i : ℕ) (hi : i < l.length), coinBlock B i l.flatten = l[i]
  | [], _, _, hi => by simp at hi
  | c :: cs, hl, 0, _ => by
    have hc : c.length = B := hl c (by simp)
    simp [coinBlock_eq, ← hc]
  | c :: cs, hl, i + 1, hi => by
    have hc : c.length = B := hl c (by simp)
    have hrest := coinBlock_flatten cs (fun d hd => hl d (by simp [hd])) i (by simpa using hi)
    simp only [List.getElem_cons_succ, ← hrest, coinBlock_eq, List.flatten_cons]
    rw [show (i + 1) * B = c.length + i * B by rw [hc, Nat.succ_mul]; ring, List.drop_append,
      List.drop_eq_nil_of_le (by omega), List.nil_append, Nat.add_sub_cancel_left]

/-- Segment `i` of the concatenation of `B`-bit blocks `g 0, …, g (q − 1)` is `g i`. -/
theorem coinBlock_flatten_ofFn {q B : ℕ} (g : Fin q → List Bool) (hg : ∀ i, (g i).length = B)
    (i : Fin q) : coinBlock B i (List.ofFn g).flatten = g i := by
  rw [coinBlock_flatten (List.ofFn g) (fun c hc => by
    obtain ⟨j, rfl⟩ := List.mem_ofFn.mp hc
    exact hg j) i (by simp)]
  simp

/-- **The block loop over a message** (`blockEncFun` with one-bit blocks): its output is the
tuple of the emissions on the layouts `⟨⟨⟨u, ⟨pk, [m_i]⟩⟩, []⟩, segment i⟩`. -/
theorem blockEncFun_ofFn (G : List Bool → List Bool) (B : PolyExpr) (u pk : List Bool) {q : ℕ}
    (m : Fin q → Bool) (r : List Bool) :
    blockEncFun G (.const 1) B (blockState u pk (List.ofFn m) r) =
      encodeList (List.ofFn fun i : Fin q =>
        G (NUPPT.layout u (pairEncode pk [m i]) [] (coinBlock (B.eval u.length) i r))) := by
  have hlen : (List.ofFn m).length ≤ (blockState u pk (List.ofFn m) r).length := by
    simp only [blockState_eq, length_pairEncode, List.length_ofFn]
    omega
  rw [blockEncFun_eq]
  rw [blockEncFun_spec G (.const 1) B u pk (blockState u pk (List.ofFn m) r).length
    (List.ofFn m) r (by simpa using hlen)]
  simp only [PolyExpr.eval_const]
  rw [blockList_ofFn G _ u pk q m r _ (by simp only [List.length_ofFn] at hlen; omega)]

/-- **The tuple flattener** (`decListFun pairSndD`): on `⟨[], encodeList l⟩` it concatenates `l`. -/
theorem decListFun_pairSndD (l : List (List Bool)) :
    decListFun pairSndD (pairEncode [] (encodeList l)) = l.flatten := by
  have hlen : l.length ≤ (pairEncode [] (encodeList l)).length := by
    have := length_le_length_encodeList l
    simp only [length_pairEncode]
    omega
  rw [decListFun_eq]
  rw [decListFun_spec pairSndD [] _ l hlen]
  simp

/-! ### The algorithms as string functions -/

/-- `f(x)` on the layout `⟨⟨⟨1^n, y⟩, α⟩, x⟩`: `E(⟨1^n, x⟩)`. -/
def lamportEvalEmit (E : List Bool → List Bool) (v : List Bool) : List Bool :=
  E (pairEncode (NUPPT.inParam v) (NUPPT.inCoins v))

/-- The evaluation emission applies `E` to the parameter paired with the current coin block. -/
theorem lamportEvalEmit_eq (E : List Bool → List Bool) (v : List Bool) :
    lamportEvalEmit E v = E (pairEncode (NUPPT.inParam v) (NUPPT.inCoins v)) := rfl

/-- `Gen`'s emission on the layout `⟨⟨⟨1^n, y⟩, α⟩, x^0 ‖ x^1⟩`: the pair `⟨f(x^0), f(x^1)⟩`. -/
def lamportPairEmit (E : List Bool → List Bool) (v : List Bool) : List Bool :=
  pairEncode (E (pairEncode (NUPPT.inParam v) ((NUPPT.inCoins v).take (NUPPT.inParam v).length)))
    (E (pairEncode (NUPPT.inParam v) ((NUPPT.inCoins v).drop (NUPPT.inParam v).length)))

/-- The key-generation emission pairs the images of the first and second preimage blocks. -/
theorem lamportPairEmit_eq (E : List Bool → List Bool) (v : List Bool) :
    lamportPairEmit E v =
      pairEncode (E (pairEncode (NUPPT.inParam v)
          ((NUPPT.inCoins v).take (NUPPT.inParam v).length)))
        (E (pairEncode (NUPPT.inParam v) ((NUPPT.inCoins v).drop (NUPPT.inParam v).length))) := rfl

/-- `Sign`'s emission on the layout `⟨⟨⟨1^n, ⟨pk, [b]⟩⟩, α⟩, x^0 ‖ x^1⟩`: the preimage `x^b`. -/
def lamportSelEmit (v : List Bool) : List Bool :=
  if (pairSndD (NUPPT.inArg v)).headD false then (NUPPT.inCoins v).drop (NUPPT.inParam v).length
  else (NUPPT.inCoins v).take (NUPPT.inParam v).length

/-- The signing emission chooses the second or first preimage block according to the message
bit in the argument. -/
theorem lamportSelEmit_eq (v : List Bool) :
    lamportSelEmit v =
      if (pairSndD (NUPPT.inArg v)).headD false then
        (NUPPT.inCoins v).drop (NUPPT.inParam v).length
      else (NUPPT.inCoins v).take (NUPPT.inParam v).length := rfl

/-- `Ver`'s selection on the layout `⟨⟨⟨1^n, ⟨pk, [b]⟩⟩, α⟩, ⟨⟨y^0, y^1⟩, []⟩⟩` (a block of the
public key): `y^b`. -/
def lamportPkEmit (v : List Bool) : List Bool :=
  if (pairSndD (NUPPT.inArg v)).headD false then pairSndD (pairFstD (NUPPT.inCoins v))
  else pairFstD (pairFstD (NUPPT.inCoins v))

/-- The public-key emission chooses the second or first image in the current encoded block
according to the message bit. -/
theorem lamportPkEmit_eq (v : List Bool) :
    lamportPkEmit v =
      if (pairSndD (NUPPT.inArg v)).headD false then pairSndD (pairFstD (NUPPT.inCoins v))
      else pairFstD (pairFstD (NUPPT.inCoins v)) := rfl

/-- The length of a public-key block `⟨⟨y^0, y^1⟩, []⟩` with `L`-bit images: `6L + 6`. -/
def lamportPkBlock (L : PolyExpr) : PolyExpr := .add (.mul (.const 6) L) (.const 6)

/-- The public-key block polynomial is `6L + 6`. -/
theorem lamportPkBlock_eq (L : PolyExpr) :
    lamportPkBlock L = .add (.mul (.const 6) L) (.const 6) := rfl

/-- `Gen` on the layout `⟨⟨⟨1^n, y⟩, α⟩, ρ⟩` with `2n²` coins `ρ`: `⟨pk, ρ⟩`, where `pk` is the
tuple of the pairs `⟨f(x_i^0), f(x_i^1)⟩` over the `2n`-bit segments of `ρ`. -/
def lamportGenFun (E : List Bool → List Bool) (z : List Bool) : List Bool :=
  pairEncode
    (blockEncFun (lamportPairEmit E) (.const 1) (.mul (.const 2) .var)
      (blockState (NUPPT.inParam z) [] (List.replicate (NUPPT.inParam z).length true)
        (NUPPT.inCoins z)))
    (NUPPT.inCoins z)

/-- The generator word pairs the public-key block-loop output with the original preimage tape. -/
theorem lamportGenFun_eq (E : List Bool → List Bool) (z : List Bool) :
    lamportGenFun E z =
      pairEncode
        (blockEncFun (lamportPairEmit E) (.const 1) (.mul (.const 2) .var)
          (blockState (NUPPT.inParam z) [] (List.replicate (NUPPT.inParam z).length true)
            (NUPPT.inCoins z)))
        (NUPPT.inCoins z) := rfl

/-- `Sign` on the layout `⟨⟨⟨1^n, ⟨sk, m⟩⟩, α⟩, r⟩`: the concatenation of the `x_i^{m_i}`. -/
def lamportSignFun (z : List Bool) : List Bool :=
  decListFun pairSndD (pairEncode []
    (blockEncFun lamportSelEmit (.const 1) (.mul (.const 2) .var)
      (blockState (NUPPT.inParam z) [] (pairSndD (NUPPT.inArg z)) (pairFstD (NUPPT.inArg z)))))

/-- The signing word concatenates the preimage blocks selected by the message bits. -/
theorem lamportSignFun_eq (z : List Bool) :
    lamportSignFun z =
      decListFun pairSndD (pairEncode []
        (blockEncFun lamportSelEmit (.const 1) (.mul (.const 2) .var)
          (blockState (NUPPT.inParam z) [] (pairSndD (NUPPT.inArg z))
            (pairFstD (NUPPT.inArg z))))) := rfl

/-- `Ver` on `⟨1^n, ⟨pk, ⟨m, σ⟩⟩⟩`: `[true]` iff `m` has `n` bits, `σ` has `n²` bits, and the
images of the `n`-bit blocks of `σ` are the public-key entries selected by `m`. -/
def lamportVerFun (L : PolyExpr) (E : List Bool → List Bool) (w : List Bool) : List Bool :=
  [(decide ((pairFstD (pairSndD (pairSndD w))).length = (pairFstD w).length) &&
      decide ((pairSndD (pairSndD (pairSndD w))).length =
        (pairFstD w).length * (pairFstD w).length)) &&
    decide (blockEncFun (lamportEvalEmit E) (.const 1) .var
        (blockState (pairFstD w) [] (pairFstD (pairSndD (pairSndD w)))
          (pairSndD (pairSndD (pairSndD w)))) =
      blockEncFun lamportPkEmit (.const 1) (lamportPkBlock L)
        (blockState (pairFstD w) [] (pairFstD (pairSndD (pairSndD w))) (pairFstD (pairSndD w))))]

/-- Verification conjoins the message and signature length tests with equality of the
signature-image word and the selected public-key word. -/
theorem lamportVerFun_eq (L : PolyExpr) (E : List Bool → List Bool) (w : List Bool) :
    lamportVerFun L E w =
      [(decide ((pairFstD (pairSndD (pairSndD w))).length = (pairFstD w).length) &&
          decide ((pairSndD (pairSndD (pairSndD w))).length =
            (pairFstD w).length * (pairFstD w).length)) &&
        decide (blockEncFun (lamportEvalEmit E) (.const 1) .var
            (blockState (pairFstD w) [] (pairFstD (pairSndD (pairSndD w)))
              (pairSndD (pairSndD (pairSndD w)))) =
          blockEncFun lamportPkEmit (.const 1) (lamportPkBlock L)
            (blockState (pairFstD w) [] (pairFstD (pairSndD (pairSndD w)))
              (pairFstD (pairSndD w))))] := rfl

/-! ### Efficiency -/

section Efficiency

variable {E : List Bool → List Bool} (hE : PolyTimeComputable E)

include hE in
/-- `f(x)` on a layout is polynomial-time. -/
theorem polyTimeComputable_lamportEvalEmit : PolyTimeComputable (lamportEvalEmit E) :=
  hE.comp (NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inCoins)

include hE in
/-- `Gen`'s emission is polynomial-time. -/
theorem polyTimeComputable_lamportPairEmit : PolyTimeComputable (lamportPairEmit E) := by
  have hu := NUPPT.polyTimeComputable_inParam
  have hp := hu.pairEncode NUPPT.polyTimeComputable_inCoins
  have h := (hE.comp (hu.pairEncode ((polyTimeComputable_pairTakePoly .var).comp hp))).pairEncode
    (hE.comp (hu.pairEncode ((polyTimeComputable_pairDropPoly .var).comp hp)))
  convert h using 1
  funext v
  simp [lamportPairEmit, Function.comp_apply]

/-- `Sign`'s emission is polynomial-time. -/
theorem polyTimeComputable_lamportSelEmit : PolyTimeComputable lamportSelEmit := by
  have hp := NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inCoins
  have h := polyTimeComputable_ite
    (polyTimeComputable_headD.comp
      (polyTimeComputable_pairSndD.comp NUPPT.polyTimeComputable_inArg))
    ((polyTimeComputable_pairDropPoly .var).comp hp)
    ((polyTimeComputable_pairTakePoly .var).comp hp)
  convert h using 1
  funext v
  simp [lamportSelEmit, Function.comp_apply]

/-- `Ver`'s selection is polynomial-time. -/
theorem polyTimeComputable_lamportPkEmit : PolyTimeComputable lamportPkEmit := by
  have hc := NUPPT.polyTimeComputable_inCoins
  have h := polyTimeComputable_ite
    (polyTimeComputable_headD.comp
      (polyTimeComputable_pairSndD.comp NUPPT.polyTimeComputable_inArg))
    ((polyTimeComputable_pairSndD.comp polyTimeComputable_pairFstD).comp hc)
    ((polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD).comp hc)
  convert h using 1

include hE in
/-- `Gen` is polynomial-time. -/
theorem polyTimeComputable_lamportGenFun : PolyTimeComputable (lamportGenFun E) := by
  have hu := NUPPT.polyTimeComputable_inParam
  have hst := hu.pairEncode ((polyTimeComputable_const []).pairEncode
    ((polyTimeComputable_unary.comp hu).pairEncode NUPPT.polyTimeComputable_inCoins))
  have h := ((blockEncFun_poly (polyTimeComputable_lamportPairEmit hE) (.const 1)
    (.mul (.const 2) .var)).comp hst).pairEncode NUPPT.polyTimeComputable_inCoins
  refine h.congr fun z => ?_
  simp only [lamportGenFun_eq, blockState_eq, Function.comp_apply]

/-- `Sign` is polynomial-time. -/
theorem polyTimeComputable_lamportSignFun : PolyTimeComputable lamportSignFun := by
  have hu := NUPPT.polyTimeComputable_inParam
  have hArg := NUPPT.polyTimeComputable_inArg
  have hst := hu.pairEncode ((polyTimeComputable_const []).pairEncode
    ((polyTimeComputable_pairSndD.comp hArg).pairEncode (polyTimeComputable_pairFstD.comp hArg)))
  have h := (decListFun_poly polyTimeComputable_pairSndD).comp
    ((polyTimeComputable_const []).pairEncode
      ((blockEncFun_poly polyTimeComputable_lamportSelEmit (.const 1)
        (.mul (.const 2) .var)).comp hst))
  refine h.congr fun z => ?_
  simp only [lamportSignFun_eq, blockState_eq, Function.comp_apply]

include hE in
/-- `Ver` is polynomial-time: two length tests (`polyTimeComputable_lenEq`) and an equality of
two block loops (`polyTimeComputable_pairEq`).

**Proof sketch.** Project the parameter, public key, message and signature from the input.
Compare the message length with `n` and the signature length with `n²`, representing the latter
bound by a unary square. The two polynomial-time block loops produce the images of the
signature blocks and the public-key entries selected by the message. Compare these two words
and conjoin the result with the length tests. -/
theorem polyTimeComputable_lamportVerFun (L : PolyExpr) :
    PolyTimeComputable (lamportVerFun L E) := by
  have hu := polyTimeComputable_pairFstD
  have hpk := polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD
  have hm := polyTimeComputable_pairFstD.comp
    (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
  have hσ := polyTimeComputable_pairSndD.comp
    (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)
  have h₁ : PolyTimeComputable fun w =>
      [decide ((pairFstD (pairSndD (pairSndD w))).length = (pairFstD w).length)] := by
    convert polyTimeComputable_lenEq.comp (hm.pairEncode hu) using 1
    funext w
    simp [Function.comp_apply]
  have h₂ : PolyTimeComputable fun w =>
      [decide ((pairSndD (pairSndD (pairSndD w))).length =
        (pairFstD w).length * (pairFstD w).length)] := by
    convert polyTimeComputable_lenEq.comp
      (hσ.pairEncode ((polyTimeComputable_unaryPoly (.mul .var .var)).comp hu)) using 1
    funext w
    simp [Function.comp_apply]
  have hX := (blockEncFun_poly (polyTimeComputable_lamportEvalEmit hE) (.const 1) .var).comp
    (hu.pairEncode ((polyTimeComputable_const []).pairEncode (hm.pairEncode hσ)))
  have hY := (blockEncFun_poly polyTimeComputable_lamportPkEmit (.const 1)
    (lamportPkBlock L)).comp
    (hu.pairEncode ((polyTimeComputable_const []).pairEncode (hm.pairEncode hpk)))
  have h₃ : PolyTimeComputable fun w =>
      [decide (blockEncFun (lamportEvalEmit E) (.const 1) .var
          (blockState (pairFstD w) [] (pairFstD (pairSndD (pairSndD w)))
            (pairSndD (pairSndD (pairSndD w)))) =
        blockEncFun lamportPkEmit (.const 1) (lamportPkBlock L)
          (blockState (pairFstD w) [] (pairFstD (pairSndD (pairSndD w)))
            (pairFstD (pairSndD w))))] := by
    refine (polyTimeComputable_pairEq.comp (hX.pairEncode hY)).congr fun w => ?_
    simp only [Function.comp_apply, pairFstD_pairEncode, pairSndD_pairEncode]
    apply congrArg (fun b : Bool => [b])
    apply decide_eq_decide.mpr
    simp only [blockState_eq]
  exact polyTimeComputable_and (polyTimeComputable_and h₁ h₂) h₃

/-! ### The machines -/

/-- The machine `Gen`, with `2n²` coins. -/
noncomputable def lamportGen : NUPPT :=
  NUPPT.ofPolyTimeUniform (polyTimeComputable_lamportGenFun hE) (.mul (.mul (.const 2) .var) .var)

/-- The machine `Sign`, deterministic. -/
noncomputable def lamportSign : NUPPT :=
  NUPPT.ofPolyTimeUniform polyTimeComputable_lamportSignFun (.const 0)

/-- `Gen` on coins `ρ`: `⟨pk, ρ⟩`, `pk` the tuple of the pairs `⟨f(x_i^0), f(x_i^1)⟩` over the
`2n`-bit segments `x_i^0 ‖ x_i^1` of `ρ`. -/
theorem runAt_lamportGen (n : ℕ) (ρ : (lamportGen hE).Coins n) :
    (lamportGen hE).runAt n [] ρ =
      pairEncode (encodeList (List.ofFn fun i : Fin n =>
          pairEncode
            (E (pairEncode (List.replicate n true) (lamportHalf n false
              (coinBlock (2 * n) i (List.ofFn ρ)))))
            (E (pairEncode (List.replicate n true) (lamportHalf n true
              (coinBlock (2 * n) i (List.ofFn ρ)))))))
        (List.ofFn ρ) := by
  rw [NUPPT.runAt_eq]
  unfold lamportGen
  rw [NUPPT.runAtL_ofPolyTimeUniform]
  simp only [lamportGenFun, NUPPT.inParam_eq, NUPPT.inCoins_eq, NUPPT.advInput_eq,
    pairFstD_pairEncode,
    pairSndD_pairEncode, List.length_replicate]
  rw [show blockState (List.replicate n true) [] (List.replicate n true) (List.ofFn ρ) =
    blockState (List.replicate n true) [] (List.ofFn fun _ : Fin n => true) (List.ofFn ρ) by simp,
    blockEncFun_ofFn]
  simp [lamportPairEmit, lamportHalf]

/-- `Sign` on `⟨sk, m⟩`: the concatenation of the halves `x_i^{m_i}` of the `2n`-bit segments
of `sk`. -/
theorem runAt_lamportSign (n : ℕ) (sk : List Bool) (m : Fin n → Bool)
    (r : lamportSign.Coins n) :
    lamportSign.runAt n (pairEncode sk (List.ofFn m)) r =
      (List.ofFn fun i : Fin n => lamportHalf n (m i) (coinBlock (2 * n) i sk)).flatten := by
  rw [NUPPT.runAt_eq]
  unfold lamportSign
  rw [NUPPT.runAtL_ofPolyTimeUniform]
  simp only [lamportSignFun, NUPPT.inParam_eq, NUPPT.inArg_eq, NUPPT.advInput_eq,
    pairFstD_pairEncode,
    pairSndD_pairEncode]
  rw [blockEncFun_ofFn, decListFun_pairSndD]
  congr 1
  simp [lamportSelEmit, lamportHalf]

end Efficiency

/-! ### The scheme -/

variable (L : PolyExpr) (f : ∀ n, (Fin n → Bool) → (Fin (L.eval n) → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hfE : ∀ n (x : Fin n → Bool), E (NUPPT.advInput n (List.ofFn x)) = List.ofFn (f n x))

/-- **The one-way function of Protocol 137.1** as a function family: `n`-bit inputs and
`L(n)`-bit outputs at parameter `n`. -/
def lamportOWF : FunFamily where
  inLen := .var
  outLen := L
  f := f

/-- Lamport's function family has input-length polynomial `n`. -/
theorem lamportOWF_inLen : (lamportOWF L f).inLen = .var := rfl

/-- Lamport's function family retains the supplied output-length polynomial `L`. -/
theorem lamportOWF_outLen : (lamportOWF L f).outLen = L := rfl

/-- Lamport's function family retains the supplied family `f`. -/
theorem lamportOWF_f : (lamportOWF L f).f = f := rfl

include hfE in
/-- On `n`-bit inputs, `E` returns `L(n)` bits (it agrees with `f`). -/
theorem length_lamportEval {n : ℕ} {x : List Bool} (hx : x.length = n) :
    (E (pairEncode (List.replicate n true) x)).length = L.eval n := by
  have h := hfE n (padFin n x)
  have hx' := Collection.ofFn_padFin_of_le (le_of_eq hx)
  simp only [hx, Nat.sub_self, List.replicate_zero, List.append_nil] at hx'
  rw [hx'] at h
  simp only [NUPPT.advInput_eq] at h
  rw [h, List.length_ofFn]

include hfE in
/-- **Correctness**: `Ver` accepts `Sign`'s signature under the generated keys.

**Proof sketch.** `runAt_lamportGen` and `runAt_lamportSign` unfold the keys and the signature.
The length tests pass (`length_flatten_ofFn`). On both sides of `Ver`'s equality, the block loop
is a tuple over the message bits (`blockEncFun_ofFn`). Block `i` of the signature is
`x_i^{m_i}` (`coinBlock_flatten_ofFn`); block `i` of the public key is the pair
`⟨f(x_i^0), f(x_i^1)⟩`, of `6L + 6` bits (`length_lamportEval`). Both entries are `f(x_i^{m_i})`. -/
theorem lamportVerFun_sign (n : ℕ) (m : Fin n → Bool) (rg : (lamportGen hE).Coins n)
    (rs : lamportSign.Coins n) :
    lamportVerFun L E (atParam n (pairEncode (pairFstD ((lamportGen hE).runAt n [] rg))
      (pairEncode (List.ofFn m) (List.ofFn (padFin (n * n) (lamportSign.runAt n
        (pairEncode (pairSndD ((lamportGen hE).runAt n [] rg)) (List.ofFn m)) rs)))))) =
      [true] := by
  rw [runAt_lamportGen]
  simp only [pairFstD_pairEncode, pairSndD_pairEncode]
  rw [runAt_lamportSign]
  have hρ : (List.ofFn rg).length = 2 * n * n := by
    refine (List.length_ofFn (f := rg)).trans
      (((lamportGen hE).coinLen_eq n).trans ?_)
    simp only [lamportGen, NUPPT.coins_ofPolyTimeUniform,
      PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
  have hseg : ∀ i : Fin n, (coinBlock (2 * n) i (List.ofFn rg)).length = 2 * n := by
    intro i
    apply length_coinBlock
    rw [hρ]
    have := i.isLt
    nlinarith
  have hsel : ∀ i : Fin n, (lamportHalf n (m i) (coinBlock (2 * n) i (List.ofFn rg))).length = n :=
    fun i => length_lamportHalf _ (hseg i)
  have hσ := length_flatten_ofFn _ hsel
  have hpad := Collection.ofFn_padFin_of_le (le_of_eq hσ)
  simp only [hσ, Nat.sub_self, List.replicate_zero, List.append_nil] at hpad
  rw [hpad]
  have hy : ∀ (b : Bool) (i : Fin n), (E (pairEncode (List.replicate n true)
      (lamportHalf n b (coinBlock (2 * n) i (List.ofFn rg))))).length = L.eval n :=
    fun b i => length_lamportEval L f E hfE (length_lamportHalf b (hseg i))
  have hpk : ∀ i : Fin n, (pairEncode (pairEncode
      (E (pairEncode (List.replicate n true) (lamportHalf n false
        (coinBlock (2 * n) i (List.ofFn rg)))))
      (E (pairEncode (List.replicate n true) (lamportHalf n true
        (coinBlock (2 * n) i (List.ofFn rg)))))) []).length =
      (lamportPkBlock L).eval n := by
    intro i
    simp only [length_pairEncode, hy, lamportPkBlock, PolyExpr.eval_add, PolyExpr.eval_mul,
      PolyExpr.eval_const, List.length_nil]
    ring
  simp only [lamportVerFun, atParam_eq, pairFstD_pairEncode, pairSndD_pairEncode,
    List.length_replicate, List.length_ofFn, hσ, decide_true, Bool.true_and, List.cons.injEq,
    and_true, decide_eq_true_eq]
  have hflat : ∀ g : Fin n → List Bool,
      encodeList (List.ofFn g) = (List.ofFn fun i => pairEncode (g i) []).flatten := by
    intro g
    rw [encodeList_eq_flatMap]
    simp [List.flatMap_def, List.map_ofFn, Function.comp_def]
  rw [hflat, blockEncFun_ofFn, blockEncFun_ofFn]
  congr 1
  congr 1
  funext i
  simp only [lamportEvalEmit, lamportPkEmit, NUPPT.inParam_layout, NUPPT.inCoins_layout,
    NUPPT.inArg_layout, pairSndD_pairEncode, List.headD_cons, PolyExpr.eval_var,
    List.length_replicate]
  rw [coinBlock_flatten_ofFn _ hsel i, coinBlock_flatten_ofFn _ hpk i]
  cases m i <;> simp [lamportHalf]

include hfE in
/-- **Lamport's one-time signature scheme** [PS10, Protocol 137.1] for `f` with evaluator `E`:
`n`-bit messages, `n²`-bit signatures. -/
noncomputable def lamport : SignatureScheme where
  msgLen := .var
  sigLen := .mul .var .var
  gen := lamportGen hE
  sign := lamportSign
  ver := lamportVerFun L E
  gen_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  sign_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  ver_poly := polyTimeComputable_lamportVerFun hE L
  correct := fun n m rg rs => lamportVerFun_sign L f E hE hfE n m rg rs

/-- Lamport signs messages of length `n`. -/
theorem lamport_msgLen : (lamport L f E hE hfE).msgLen = .var := rfl

/-- Lamport's signature-length polynomial is `n²`. -/
theorem lamport_sigLen : (lamport L f E hE hfE).sigLen = .mul .var .var := rfl

/-- Lamport uses its preimage-pair generator as the scheme's key generator. -/
theorem lamport_gen : (lamport L f E hE hfE).gen = lamportGen hE := rfl

/-- Lamport uses its deterministic selected-preimage signer. -/
theorem lamport_sign : (lamport L f E hE hfE).sign = lamportSign := rfl

/-- Lamport uses its length-guarded block verifier. -/
theorem lamport_ver : (lamport L f E hE hfE).ver = lamportVerFun L E := rfl

/-- **Theorem 137.2: Lamport's scheme is one-time secure** [PS10, Theorem 137.2] when `f` is a
(strong) one-way function.

**Proof sketch** (the source's reduction, with its probability coupling explicit).
1. Fix a forger `A` making at most one signing query, and let `ε(n)` be its forgery probability.
   Work at `n ≥ 1`; the zero parameter is a finite exception for negligibility. The inverter
   `B` receives `1^n` and `y = f(x)` for a uniform `n`-bit `x`.
2. For the averaging argument, choose `i ← [n]` and a fair bit `c`, generate the other key
   entries, and put `y` at position `(i,c)`. Answer query `m` only when `m_i ≠ c`; otherwise
   abort, since the planted preimage is unknown. A valid forgery with `m'_i = c` reveals
   `σ'_i` with `f(σ'_i) = y`.
3. Couple this experiment to an honest execution, choosing `(i,c)` independently of that
   honest execution. The reduction agrees with it whenever it avoids revealing the planted
   preimage. For a successful honest run with query `m` and fresh forged message `m'`, the
   jointly favorable pairs satisfy `m_i ≠ c = m'_i`. Their fraction is
   `#{i : m_i ≠ m'_i}/(2n) ≥ 1/(2n)`. With no query, their fraction is exactly `1/2`.
   This counts the joint event without asserting independence after conditioning on non-abort.
4. Averaging over successful honest runs gives inversion probability at least `ε(n)/(2n)`.
   A best position at each length is at least as good as the uniform-position average; supply
   it as `O(log n)` bits of non-uniform advice and sample only the fair bit `c`. Thus the
   machine need not sample an exactly uniform element of `[n]` from a fixed finite coin tape.
5. `f` is one-way, so this lower bound is negligible, and polynomial-factor closure makes `ε`
   negligible. Apply T1 (`Games.exists_handlerMachine`) to the extended input `⟨y,i(n)⟩`, then
   `NUPPT.exists_withAdvice` supplies the bounded advised position. `advIn` builds the public
   key from that input and the seed, the handler answers or aborts, and `out` extracts `σ′_i`.

For zero-query successful runs the extraction fraction is `1/2`, rather than just `1/(2n)`. -/
theorem lamport_oneTimeSecure (hf : (lamportOWF L f).StrongOneWay) :
    (lamport L f E hE hfE).OneTimeSecure := by
  sorry

end TCSlib.Cryptography.Authentication
/- G06-HARNESS EOF-VERIFY LamportSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "LamportSeal"
  let payload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encDist\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\tTCSlib.Cryptography.Asymptotic.Encryption\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\tTCSlib.Cryptography.Asymptotic.Encryption"
  let expectedRequests : Nat := 14
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"Deterministic\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"MultiMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"SingleMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.encDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"firstTwoEqFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"multiEncDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

