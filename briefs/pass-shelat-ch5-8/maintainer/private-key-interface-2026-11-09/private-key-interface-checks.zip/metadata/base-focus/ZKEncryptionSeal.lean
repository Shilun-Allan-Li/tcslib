/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import Lean
import TCSlib.Cryptography.Asymptotic.Encryption
/- G06-HARNESS INSTALL ZKEncryptionSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "ZKEncryptionSeal"
  let payload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encDist\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\tTCSlib.Cryptography.Asymptotic.Encryption\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\tTCSlib.Cryptography.Asymptotic.Encryption"
  let expectedRequests : Nat := 14
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"Deterministic\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"MultiMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"SingleMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.encDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"firstTwoEqFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"multiEncDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Zero-knowledge encryption

The simulation-based notion of secure private-key encryption of [PS10, §4.2]: a scheme is
*zero-knowledge* if there is a PPT simulator `S` such that, for every non-uniform PPT `D`,
`S(1^n)` is indistinguishable from the encryption `Enc_k(m)` of every message `m ∈ {0,1}^n`
under a fresh key `k ← Gen(1^n)` [PS10, Definition 111.1] — "the ciphertext allows the
eavesdropper to compute nothing she could not have computed without it". The theorem of the
section, [PS10, Theorem 112.2], is that zero-knowledge encryption is the same as
single-message security [PS10, Definition 91.1]: security gives zero knowledge with the
simulator "encrypt a canonical message" (`SingleMessageSecure.zeroKnowledge`), and zero
knowledge gives security by the two-step hybrid `Enc_k(m₀) ≈ S(1^n) ≈ Enc_k(m₁)`
(`ZeroKnowledge.singleMessageSecure`, proved). The optional perfect variant
(`PerfectZeroKnowledge`, the two distributions identical, Def-111.a) implies the
computational one.

The scheme, the ciphertext distribution `PrivateKeyScheme.encDist` and single-message
security are those of `TCSlib.Cryptography.Asymptotic.Encryption`; the simulator is a uniform
`Complexity.NUPPT` activated at parameter `n` on the empty argument (`Sim.runAt n []`), and
the distinguisher a non-uniform PPT on the ciphertext string (`Complexity.NUPPT.distinguisherL`).

**Deviation:** `ZeroKnowledge`: the simulator is a strict PPT (D8); the distinguisher receives
`1^n` with the ciphertext (D5); the bound is `≤ ε(n)`; the message `m` is fixed per `n`
(the text's `∀ m ∈ {0,1}^n`).

**Deviation:** `singleMessageSecure_iff_zeroKnowledge` (Theorem 112.2): the text's hypothesis
"a polynomial-time `M` with `M(1^n) ∈ {0,1}^n`" is discharged by the canonical message `0^n`
(the gap list of `PassShelatChapter2-4Plan.md`), so the theorem has no hypothesis beyond the
scheme; the text's hypothesis "`Gen`, `Enc` PPT" is part of `PrivateKeyScheme`.

## Main definitions

* `TCSlib.Cryptography.PrivateKeyScheme.ZeroKnowledge` — zero-knowledge encryption
  [PS10, Definition 111.1].
* `TCSlib.Cryptography.PrivateKeyScheme.PerfectZeroKnowledge` — the perfect variant
  (the simulated and real ciphertext distributions identical; Def-111.a, optional).

## Main results

* `TCSlib.Cryptography.PrivateKeyScheme.singleMessageSecure_iff_zeroKnowledge` —
  [PS10, Theorem 112.2]: single-message security and zero knowledge are equivalent.
* `TCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure.zeroKnowledge` — the direction
  security ⇒ zero knowledge (Thm-112.2.i; simulator `Enc_k(0^n)`).
* `TCSlib.Cryptography.PrivateKeyScheme.ZeroKnowledge.singleMessageSecure` — the direction
  zero knowledge ⇒ security (Thm-112.2.ii; two-step hybrid, proved).
* `TCSlib.Cryptography.PrivateKeyScheme.PerfectZeroKnowledge.zeroKnowledge` — perfect zero
  knowledge is zero knowledge (sanity, proved).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§4.2: Definition 111.1, Theorem 112.2.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.2 (the concrete `distAdv`).
-/

namespace TCSlib.Cryptography

open Complexity Turing Finset

namespace PrivateKeyScheme

/-! ### Zero-knowledge encryption [PS10, Definition 111.1] -/

/-- **Zero-knowledge encryption** [PS10, Definition 111.1]: there is a PPT simulator `Sim`
such that for every non-uniform PPT `D` there is a negligible `ε` with, for all `n` and all
`m ∈ {0,1}^n`, `D` distinguishes `{k ← Gen(1^n) : Enc_k(m)}` from `{Sim(1^n)}` with
advantage at most `ε(n)`. The simulator is activated at parameter `n` on the empty argument
(it receives `1^n` only).

**Deviation:** the simulator is a strict PPT (D8); the distinguisher receives `1^n` with the
ciphertext (D5); the bound is `≤ ε(n)`. -/
def ZeroKnowledge (S : PrivateKeyScheme) : Prop :=
  ∃ Sim : NUPPT, Sim.Uniform ∧ ∀ D : NUPPT, ∃ ε : ℕ → ℝ, Negligible ε ∧
    ∀ n (m : Fin n → Bool),
      distAdv (S.encDist n m) (Sim.runAt n []) (D.distinguisherL n) ≤ ε n

/-- **Perfect zero-knowledge encryption** (Def-111.a, [PS10, p. 111, "we can strengthen the
definition to require that the above distributions are identical"]): a PPT simulator whose
output distribution at every `n` is exactly the ciphertext distribution of every message
(`StatClose … 0`, every test set has the same probability). -/
def PerfectZeroKnowledge (S : PrivateKeyScheme) : Prop :=
  ∃ Sim : NUPPT, Sim.Uniform ∧ ∀ n (m : Fin n → Bool),
    StatClose (S.encDist n m) (Sim.runAt n []) 0

/-- **Perfect zero knowledge is zero knowledge** (sanity): identical distributions are
indistinguishable, every advantage being `0` (`distAdv_le_of_statClose`, `negligible_zero`). -/
theorem PerfectZeroKnowledge.zeroKnowledge {S : PrivateKeyScheme} (h : S.PerfectZeroKnowledge) :
    S.ZeroKnowledge := by
  obtain ⟨Sim, hSim, hclose⟩ := h
  exact ⟨Sim, hSim, fun D => ⟨fun _ => 0, negligible_zero,
    fun n m => distAdv_le_of_statClose _ _ (hclose n m) _⟩⟩

/-! ### [PS10, Theorem 112.2]: security ⇔ zero knowledge -/

/-- **Zero knowledge implies single-message security** (Thm-112.2.ii, the direction "ZK
implies Security" of [PS10, Theorem 112.2]): with `Sim` the zero-knowledge simulator and
`ε_D` its negligible bound for `D`, for all `n`, `m₀`, `m₁`,
`distAdv (Enc_k(m₀)) (Enc_k(m₁)) D ≤ distAdv (Enc_k(m₀)) (Sim(1^n)) D + distAdv (Sim(1^n)) (Enc_k(m₁)) D ≤ 2 ε_D(n)`
— the text's "by the hybrid lemma `D` distinguishes `H¹` from `H³` or `H³` from `H²` with
probability `1/(2p(n))`" is this two-step chain (`abs_sub_le`, `Negligible.const_mul`). -/
theorem ZeroKnowledge.singleMessageSecure {S : PrivateKeyScheme} (h : S.ZeroKnowledge) :
    S.SingleMessageSecure := by
  obtain ⟨Sim, -, hSim⟩ := h
  refine (PrivateKeyScheme.singleMessageSecure_iff S).2 fun D => ?_
  obtain ⟨ε, hε, hD⟩ := hSim D
  refine ⟨fun n => 2 * ε n, hε.const_mul 2, fun n m₀ m₁ => ?_⟩
  have h₀ := hD n m₀
  have h₁ := hD n m₁
  simp only [distAdv_def] at h₀ h₁ ⊢
  calc |acceptProb (S.encDist n m₀) (D.distinguisherL n) -
        acceptProb (S.encDist n m₁) (D.distinguisherL n)|
      ≤ |acceptProb (S.encDist n m₀) (D.distinguisherL n) -
          acceptProb (Sim.runAt n []) (D.distinguisherL n)| +
        |acceptProb (Sim.runAt n []) (D.distinguisherL n) -
          acceptProb (S.encDist n m₁) (D.distinguisherL n)| := abs_sub_le _ _ _
    _ ≤ ε n + ε n := add_le_add h₀ (by rw [abs_sub_comm]; exact h₁)
    _ = 2 * ε n := by ring

/-- Masking a string with itself gives the zero string: `u ⊕ u = 0^{|u|}` (the canonical
message `0^n` of the simulator is computed from `1^n` this way). -/
private theorem zipWith_xor_self (u : List Bool) :
    List.zipWith xor u u = List.replicate u.length false := by
  rw [List.zipWith_self]
  simp [List.map_const']

/-- The raw string function of the simulator of [PS10, Theorem 112.2]: on the layout
`⟨⟨⟨u, y⟩, α⟩, r⟩` with `u = 1^n`, cut the coins `r` at `Gen`'s coin length `gen.coins n`, run
`Gen` on the first part to obtain the key `k`, and run `Enc` on `⟨k, 0^n⟩` (`0^n = u ⊕ u`)
with the second part. -/
private def zkSimFun (S : PrivateKeyScheme) (z : List Bool) : List Bool :=
  S.enc.output (NUPPT.layout (NUPPT.inParam z)
    (pairEncode
      (S.gen.output (NUPPT.layout (NUPPT.inParam z) [] []
        ((NUPPT.inCoins z).take (S.gen.coins.eval (NUPPT.inParam z).length))))
      (List.zipWith xor (NUPPT.inParam z) (NUPPT.inParam z)))
    [] ((NUPPT.inCoins z).drop (S.gen.coins.eval (NUPPT.inParam z).length)))

/-- `zkSimFun S` is polynomial-time: the layout projections, the coin cuts
`Complexity.polyTimeComputable_pairTakePoly`/`pairDropPoly` at `gen.coins`, the zero message
by `Complexity.polyTimeComputable_pairXor` on `⟨u, u⟩`, and the output functions of `Gen`
and `Enc` (`Complexity.NUPPT.polyTimeComputable_output`), assembled by
`Complexity.NUPPT.polyTimeComputable_layout`.

**Proof sketch.** The two coin segments are `pairTakePoly`/`pairDropPoly gen.coins` applied to
the re-pairing `⟨inParam z, inCoins z⟩` (as in `Complexity.NUPPT.exists_seq`); the key is
`gen.output` of the layout `⟨⟨⟨u, []⟩, []⟩, r₁⟩`; the zero message is `pairXor` of `⟨u, u⟩`;
`enc.output` of the layout `⟨⟨⟨u, ⟨k, 0^n⟩⟩, []⟩, r₂⟩` is the composite, equal to `zkSimFun S`
by unfolding `Function.comp` (`PolyTimeComputable.comp`, `PolyTimeComputable.pairEncode`,
`polyTimeComputable_const`). -/
private theorem polyTimeComputable_zkSimFun (S : PrivateKeyScheme) :
    PolyTimeComputable (zkSimFun S) := by
  have hcut := NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inCoins
  have hr₁ : PolyTimeComputable fun z =>
      (NUPPT.inCoins z).take (S.gen.coins.eval (NUPPT.inParam z).length) := by
    have := (polyTimeComputable_pairTakePoly S.gen.coins).comp hcut
    convert this using 1
    funext z
    simp [Function.comp_apply]
  have hr₂ : PolyTimeComputable fun z =>
      (NUPPT.inCoins z).drop (S.gen.coins.eval (NUPPT.inParam z).length) := by
    have := (polyTimeComputable_pairDropPoly S.gen.coins).comp hcut
    convert this using 1
    funext z
    simp [Function.comp_apply]
  have hzero : PolyTimeComputable fun z =>
      List.zipWith xor (NUPPT.inParam z) (NUPPT.inParam z) := by
    have := polyTimeComputable_pairXor.comp
      (NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inParam)
    convert this using 1
    funext z
    simp [Function.comp_apply]
  have hk := S.gen.polyTimeComputable_output.comp
    (NUPPT.polyTimeComputable_layout NUPPT.polyTimeComputable_inParam (polyTimeComputable_const [])
      (polyTimeComputable_const []) hr₁)
  have h := S.enc.polyTimeComputable_output.comp
    (NUPPT.polyTimeComputable_layout NUPPT.polyTimeComputable_inParam (hk.pairEncode hzero)
      (polyTimeComputable_const []) hr₂)
  convert h using 1

/-- The simulator of [PS10, Theorem 112.2]: the PPT with output function `zkSimFun S` and
coins `gen.coins + enc.coins` ("`Sim(1^n)` draws `k ← Gen(1^n)` and outputs `Enc_k(0^n)`"). -/
private noncomputable def zkSim (S : PrivateKeyScheme) : NUPPT :=
  NUPPT.ofPolyTimeUniform (polyTimeComputable_zkSimFun S) (.add S.gen.coins S.enc.coins)

/-- The coins of the simulator are pairs `(r₁, r₂)` of generation and encryption coins: the
split `Fin.appendEquiv` followed by the coin equivalence of `ofPolyTimeUniform`. -/
private noncomputable def zkSimCoins (S : PrivateKeyScheme) (n : ℕ) :
    S.gen.Coins n × S.enc.Coins n ≃ (zkSim S).Coins n :=
  (Fin.appendEquiv (S.gen.coinLen n) (S.enc.coinLen n)).trans
    ((Equiv.arrowCongr (finCongr (by rw [NUPPT.coinLen_eq, NUPPT.coinLen_eq, PolyExpr.eval_add]))
      (Equiv.refl Bool)).trans
      (NUPPT.coinsEquiv_ofPolyTimeUniform (polyTimeComputable_zkSimFun S)
        (.add S.gen.coins S.enc.coins) n).symm)

/-- The simulator's coin string on `(r₁, r₂)` is `r₁ ‖ r₂`. -/
private theorem ofFn_zkSimCoins (S : PrivateKeyScheme) (n : ℕ) (r₁ : S.gen.Coins n)
    (r₂ : S.enc.Coins n) :
    List.ofFn (zkSimCoins S n (r₁, r₂)) = List.ofFn r₁ ++ List.ofFn r₂ := by
  have key : ∀ w, List.ofFn ((NUPPT.coinsEquiv_ofPolyTimeUniform (polyTimeComputable_zkSimFun S)
      (.add S.gen.coins S.enc.coins) n).symm w) = List.ofFn w := fun w => by
    rw [← NUPPT.coinsEquiv_ofPolyTimeUniform_ofFn, Equiv.apply_symm_apply]
  have hlen :
      S.gen.coinLen n + S.enc.coinLen n = (PolyExpr.add S.gen.coins S.enc.coins).eval n := by
    rw [NUPPT.coinLen_eq, NUPPT.coinLen_eq, PolyExpr.eval_add]
  unfold zkSimCoins
  rw [Equiv.trans_apply, Equiv.trans_apply]
  refine (key _).trans ((List.ofFn_congr hlen
    ((Fin.appendEquiv (S.gen.coinLen n) (S.enc.coinLen n)) (r₁, r₂))).symm.trans ?_)
  exact List.ofFn_fin_append r₁ r₂

/-- On the coin string `r₁ ‖ r₂` (`zkSimCoins`) the simulator outputs exactly the
ciphertext `Enc_k(0^n)` with `k = Gen(1^n; r₁)` and encryption coins `r₂`, i.e.
`encDist n 0^n (r₁, r₂)` (`runAtL_ofPolyTimeUniform`, `List.ofFn_fin_append`, the cuts
`List.take_left'`/`List.drop_left'`, `gen_uniform`, `enc_uniform`, `zipWith_xor_self`). -/
private theorem zkSim_runAt (S : PrivateKeyScheme) (n : ℕ) (r₁ : S.gen.Coins n)
    (r₂ : S.enc.Coins n) :
    (zkSim S).runAt n [] (zkSimCoins S n (r₁, r₂)) = S.encDist n (fun _ => false) (r₁, r₂) := by
  have ht : (List.ofFn r₁ ++ List.ofFn r₂).take (S.gen.coins.eval n) = List.ofFn r₁ :=
    List.take_left' (by rw [List.length_ofFn, NUPPT.coinLen_eq])
  have hd : (List.ofFn r₁ ++ List.ofFn r₂).drop (S.gen.coins.eval n) = List.ofFn r₂ :=
    List.drop_left' (by rw [List.length_ofFn, NUPPT.coinLen_eq])
  rw [NUPPT.runAt_eq, ofFn_zkSimCoins]
  unfold zkSim
  rw [NUPPT.runAtL_ofPolyTimeUniform]
  simp only [encDist_apply, NUPPT.runAt_eq, NUPPT.runAtL_eq, NUPPT.advInput_eq,
    S.gen_uniform.advice_eq n, S.enc_uniform.advice_eq n, zkSimFun, NUPPT.layout_eq,
    NUPPT.inParam_eq, NUPPT.inCoins_eq, pairFstD_pairEncode, pairSndD_pairEncode,
    List.length_replicate, ht, hd, zipWith_xor_self, List.ofFn_const]

/-- The output distribution of the simulator is the ciphertext distribution of `0^n`: every
distinguisher accepts `Sim(1^n)` and `{k ← Gen(1^n) : Enc_k(0^n)}` with the same probability
(the coin split `Fin.appendEquiv` is a bijection of the seed spaces, `acceptProb_comp_equiv`,
and `zkSim_runAt`). -/
private theorem acceptProb_zkSim (S : PrivateKeyScheme) (n : ℕ) {ρ : Type*} [Fintype ρ]
    (Dst : List Bool → ρ → Bool) :
    acceptProb ((zkSim S).runAt n []) Dst = acceptProb (S.encDist n fun _ => false) Dst := by
  rw [← acceptProb_comp_equiv (zkSimCoins S n) ((zkSim S).runAt n []) Dst]
  congr 1
  funext s
  exact zkSim_runAt S n s.1 s.2

/-- **Single-message security implies zero knowledge** (Thm-112.2.i, the direction "Security
implies ZK" of [PS10, Theorem 112.2]): the simulator `Sim(1^n)` draws `k ← Gen(1^n)` and
outputs `Enc_k(0^n)`, the encryption of the canonical message `0^n` (the text's
`M(1^n)`); for every `D` and `m`, `Sim(1^n)` *is* the sampler `encDist n 0^n`, so the
advantage of `D` between `Enc_k(m)` and `Sim(1^n)` is its advantage between `Enc_k(m)` and
`Enc_k(0^n)`, at most `ε_D(n)` by Definition 91.1 with `m₀ := m`, `m₁ := 0^n`.

**Deviation:** the text's hypothesis "a polynomial-time `M` with `M(1^n) ∈ {0,1}^n`" is
discharged by the canonical message `0^n`.

**Proof sketch.** Machine step: `Sim := NUPPT.ofPolyTimeUniform` of the raw function
`z ↦ S.enc.output (layout u ⟨S.gen.output (layout u [] [] r₁), 0^{|u|}⟩ [] r₂)` with
`u := inParam z`, `r₁ := (inCoins z).take (S.gen.coins.eval |u|)`, `r₂` the rest, and coins
`S.gen.coins + S.enc.coins`: polynomial-time by `NUPPT.polyTimeComputable_layout`, the
projections `polyTimeComputable_inParam`/`_inCoins`, `polyTimeComputable_pairTakePoly`/
`_pairDropPoly` at `S.gen.coins`, `NUPPT.polyTimeComputable_output` of `gen` and `enc`,
`PolyTimeComputable.pairEncode`, and the canonical message `0^{|u|} = u ⊕ u`
(`Complexity.polyTimeComputable_pairXor` on `⟨u, u⟩`, `zipWith_xor_self`) — the machine
`zkSim S` with raw function `zkSimFun S` (`polyTimeComputable_zkSimFun`). Uniform by
`ofPolyTimeUniform_uniform`. Functional identity (`zkSim_runAt`: `runAtL_ofPolyTimeUniform`,
`S.gen_uniform`, `S.enc_uniform`, `List.length_replicate`): for `(r₁, r₂)`,
`Sim.runAt n [] (r₁ ‖ r₂) = S.encDist n 0^n (r₁, r₂)` where the coin string is split by
`Fin.appendEquiv` (`List.ofFn_fin_append`, `List.take_left'`, `List.drop_left'`), hence
`acceptProb (Sim.runAt n []) D' = acceptProb (S.encDist n 0^n) D'` by
`acceptProb_comp_equiv` (`acceptProb_zkSim`). Asymptotic step: for `D` take `ε` from `h D`; then
`distAdv (encDist n m) (Sim.runAt n []) (D.distinguisherL n)
  = distAdv (encDist n m) (encDist n 0^n) (D.distinguisherL n) ≤ ε n`. -/
theorem SingleMessageSecure.zeroKnowledge {S : PrivateKeyScheme} (h : S.SingleMessageSecure) :
    S.ZeroKnowledge := by
  refine ⟨zkSim S, NUPPT.ofPolyTimeUniform_uniform _ _, fun D => ?_⟩
  obtain ⟨ε, hε, hD⟩ := (PrivateKeyScheme.singleMessageSecure_iff S).1 h D
  refine ⟨ε, hε, fun n m => ?_⟩
  have := hD n m (fun _ => false)
  simp only [distAdv_def] at this ⊢
  rwa [acceptProb_zkSim]

/-- **[PS10, Theorem 112.2]: a private-key encryption scheme is single-message secure iff it
is zero-knowledge.** The two directions are `SingleMessageSecure.zeroKnowledge` (simulator
`Enc_k(0^n)`) and `ZeroKnowledge.singleMessageSecure` (two-step hybrid through the simulated
ciphertext).

**Deviation:** the text's hypothesis "a polynomial-time `M` with `M(1^n) ∈ {0,1}^n`" is
discharged by the canonical message `0^n`; "`Gen`, `Enc` PPT" is part of `PrivateKeyScheme`. -/
theorem singleMessageSecure_iff_zeroKnowledge (S : PrivateKeyScheme) :
    S.SingleMessageSecure ↔ S.ZeroKnowledge :=
  ⟨SingleMessageSecure.zeroKnowledge, ZeroKnowledge.singleMessageSecure⟩

end PrivateKeyScheme

end TCSlib.Cryptography
/- G06-HARNESS EOF-VERIFY ZKEncryptionSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "ZKEncryptionSeal"
  let payload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encDist\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\tTCSlib.Cryptography.Asymptotic.Encryption\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\tTCSlib.Cryptography.Asymptotic.Encryption\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\tTCSlib.Cryptography.Asymptotic.Encryption"
  let expectedRequests : Nat := 14
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"Deterministic\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"MultiMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"SingleMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.encDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"firstTwoEqFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"multiEncDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Asymptotic.Encryption.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Asymptotic\"],[\"str\",\"Encryption\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

