/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.SecureComputation.SpecialEncryption
import TCSlib.Cryptography.Asymptotic.Encryption
import TCSlib.Cryptography.Asymptotic.PRF
/- G06-HARNESS INSTALL SpecialEncryptionSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SpecialEncryptionSeal"
  let payload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\tTCSlib.Cryptography.Encryption.PrivateKey.Scheme\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\tTCSlib.Cryptography.Encryption.PrivateKey.Scheme\nTCSlib.Cryptography.PrivateKeyScheme.encDist\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\tTCSlib.Cryptography.Encryption.PrivateKey.Scheme\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity"
  let expectedRequests : Nat := 14
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"Deterministic\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"MultiMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"SingleMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"Scheme\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"Scheme\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.encDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"firstTwoEqFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"Scheme\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"multiEncDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The special encryption scheme of Yao's protocol: security (statement phase)

[PS10, Algorithm 157.2] as a `PrivateKeyScheme`, and Claim 157.a (inventory): the scheme is
multi-message secure, and a ciphertext decrypted under an independent key gives `⊥` except with
negligible probability ([PS10, §6.2.2], "the extra property"). The algorithms are in
`SpecialEncryption.lean`.

**The length-doubling PRF.** It is a keyed family with `n`-bit keys and inputs and `2n`-bit
outputs, pseudorandom as an oracle ensemble against random functions with `2n`-bit outputs
(`PRFOut`). This is the ch. 2–4 layer's Definition 96.2 (`PRF`) with the output length a
parameter; `OracleEnsemble.keyed` already allows any output length.

## Main definitions

* `SecureComputation.PRFOut`: a pseudorandom function family with `ℓ₂(n)`-bit outputs.
* `SecureComputation.specialScheme`: Algorithm 157.2 as a `PrivateKeyScheme` (`n`-bit messages),
  correctness proved.

## Main results

* `SecureComputation.specialScheme_multiMessageSecure`, `spDecStr_wrongKey`,
  `specialScheme_wrongKey` (Claim 157.a, stated; `sorry`s under sketches).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §6.2.2, Algorithm 157.2 (book pp. 156–157), and Definitions 93.1 and 96.2.
-/

namespace TCSlib.Cryptography.SecureComputation

open Complexity Turing TCSlib.Cryptography

/-! ### Pseudorandom functions with any output length -/

/-- **A pseudorandom function family with `ℓ₂(n)`-bit outputs** [PS10, Definition 96.2, with the
output length a parameter]: keys and inputs of `n` bits. (1) A polynomial-time evaluator `E`
computes `f_s(x)` from `⟨s, x⟩`. (2) The keyed ensemble `{s ← U_n : f_s}` is
oracle-indistinguishable from the random functions `{0,1}^n → {0,1}^{ℓ₂(n)}`. With `ℓ₂ = n + n`
it is the source's length-doubling family. -/
structure PRFOut (ℓ₂ : PolyExpr)
    (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (ℓ₂.eval n) → Bool)) : Prop where
  /-- Clause (1): `f_s(x)` is polynomial-time computable from `⟨s, x⟩`. -/
  easy : ∃ E : List Bool → List Bool, PolyTimeComputable E ∧
    ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) = List.ofFn (G n s x)
  /-- Clause (2): `{s ← U_n : f_s} ≈ {F ← RF : F}` as oracle ensembles. -/
  pseudorandom : (OracleEnsemble.keyed (ℓ₁ := .var) (ℓ₂ := ℓ₂) G).Indist
    (OracleEnsemble.random .var ℓ₂)

/-- With `n`-bit outputs, `PRFOut` is the ch. 2–4 layer's `PRF` (duplication-ledger item DL-8:
`PRFOut` generalizes `PRF`, and agrees with it at `ℓ₂ = n`). -/
theorem prfOut_var_iff (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool)) :
    PRFOut .var F ↔ PRF F :=
  ⟨fun h => ⟨h.easy, h.pseudorandom⟩, fun h => ⟨h.easy, h.pseudorandom⟩⟩

variable (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hGE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (G n s x))

/-- **The special encryption scheme** [PS10, Algorithm 157.2] as a `PrivateKeyScheme` with
`n`-bit messages, for a length-doubling family `G` with evaluator `E`: the key is `Gen`'s `n`
coins, `Enc` draws `r` as its `n` coins, and `Dec` is deterministic. -/
@[simps (config := { isSimp := false }) gen enc dec]
noncomputable def specialScheme : PrivateKeyScheme where
  gen := NUPPT.ofPolyTimeUniform polyTimeComputable_pairSndD .var
  enc := NUPPT.ofPolyTimeUniform (polyTimeComputable_spEncFun hE) .var
  dec := NUPPT.ofPolyTimeUniform (polyTimeComputable_spDecFun hE) (.const 0)
  gen_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  enc_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  dec_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  correct := by
    intro n m rg re rd
    rw [runAt_coinKey, runAt_spEnc hE, runAt_spDec hE]
    have hk : (List.ofFn rg).length = n := by
      rw [List.length_ofFn, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform,
        PolyExpr.eval_var]
    have hr : (List.ofFn re).length = n := by
      rw [List.length_ofFn, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform,
        PolyExpr.eval_var]
    have hp : (E (pairEncode (List.ofFn rg) (List.ofFn re))).length = n + n := by
      have hrg := (List.length_ofFn (f := rg)).symm.trans hk
      have hre := (List.length_ofFn (f := re)).symm.trans hr
      rw [List.ofFn_congr hrg rg, List.ofFn_congr hre re, hGE, List.length_ofFn]
    rw [spDecStr_spEncStr E hk (by simp) hr hp, Option.getD_some]
    exact decodeFin_ofFn m

/-! ### Claim 157.a -/

/-- **Claim 157.a (i): the special scheme is multi-message secure** [PS10, §6.2.2, "it is easy to
modify construction 99.1"] when `G` is a length-doubling PRF.

**Proof sketch.** As [PS10, Theorem 99.2] for Algorithm 99.1 (`prfScheme_multiMessageSecure`):
replace `f_k` by a random function with `2n`-bit outputs (PRF security, one oracle query per
ciphertext); then the pads of distinct `r`'s are independent uniform `2n`-bit strings, so the
ciphertexts are independent of the messages unless two `r`'s collide, with probability at most
`C(q(n)+1, 2) · 2^{-n}`. The zero prefix `0^n` is masked like the message. -/
theorem specialScheme_multiMessageSecure (hG : PRFOut (.add .var .var) G) :
    (specialScheme G E hE hGE).MultiMessageSecure := by
  sorry

/-- **Claim 157.a (ii), on strings: a wrong key gives `⊥`** [PS10, §6.2.2, "the extra property"]
for any polynomial message length `ℓ`: for `G` a PRF with `n + ℓ(n)`-bit outputs and every
`ℓ(n)`-bit message, encrypting under `k` and decrypting under an independent `k'` gives `⊥`
except with negligible probability.

**Proof sketch.** Decryption under `k'` succeeds only if `f_k(r)_{<n} = f_{k'}(r)_{<n}`. The
distinguisher with oracle `O` samples `k'` and `r`, queries `O(r)`, and accepts iff the first `n`
bits agree with `f_{k'}(r)`. Against a random function this has probability `2^{-n}`, so against
`f_k` it has probability at most `2^{-n}` plus the PRF advantage: negligible. The guard does not
fire on honest ciphertexts. -/
theorem spDecStr_wrongKey (ℓ : PolyExpr)
    (G' : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin ((PolyExpr.add .var ℓ).eval n) → Bool))
    (E' : List Bool → List Bool)
    (hGE' : ∀ n (s x : Fin n → Bool), E' (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G' n s x))
    (hG' : PRFOut (.add .var ℓ) G') :
    ∃ ε : ℕ → ℝ, Negligible ε ∧ ∀ n (m : Fin (ℓ.eval n) → Bool),
      1 - ε n < uprob (fun t : (Fin n → Bool) × (Fin n → Bool) × (Fin n → Bool) =>
        spDecStr E' n (ℓ.eval n) (List.ofFn t.2.1)
          (spEncStr E' (List.ofFn t.1) (List.ofFn m) (List.ofFn t.2.2)) = none) := by
  sorry

/-- **Claim 157.a (ii) for the scheme**: under an independent key, `Dec` returns `⊥` (an output
that decodes to no `n`-bit message) except with negligible probability, the source's
`Pr[k, k' ← Gen(1^n), c ← Enc_k(m) : Dec_{k'}(c) = ⊥] > 1 − ε(n)`.

**Proof sketch.** `runAt_spEnc` and `runAt_spDec` reduce it to `spDecStr_wrongKey` at `ℓ = n`;
the `⊥` string `1^{n+1}` decodes to no `n`-bit message, and a `some` output has `n` bits. -/
theorem specialScheme_wrongKey (hG : PRFOut (.add .var .var) G) :
    ∃ ε : ℕ → ℝ, Negligible ε ∧ ∀ n (m : Fin n → Bool),
      1 - ε n < uprob (fun t : (specialScheme G E hE hGE).gen.Coins n ×
          (specialScheme G E hE hGE).gen.Coins n × (specialScheme G E hE hGE).enc.Coins n ×
          (specialScheme G E hE hGE).dec.Coins n =>
        decodeFin n ((specialScheme G E hE hGE).dec.runAt n
          (pairEncode ((specialScheme G E hE hGE).gen.runAt n [] t.2.1)
            ((specialScheme G E hE hGE).enc.runAt n
              (pairEncode ((specialScheme G E hE hGE).gen.runAt n [] t.1) (List.ofFn m)) t.2.2.1))
          t.2.2.2) = none) := by
  sorry

end TCSlib.Cryptography.SecureComputation
/- G06-HARNESS EOF-VERIFY SpecialEncryptionSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SpecialEncryptionSeal"
  let payload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\tTCSlib.Cryptography.Encryption.PrivateKey.Scheme\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\tTCSlib.Cryptography.Encryption.PrivateKey.Scheme\nTCSlib.Cryptography.PrivateKeyScheme.encDist\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\tTCSlib.Cryptography.Encryption.PrivateKey.Scheme\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity"
  let expectedRequests : Nat := 14
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.PrivateKeyScheme.Deterministic\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"Deterministic\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"MultiMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"SingleMessageSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"Scheme\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"Scheme\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.encDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.firstTwoEqFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"firstTwoEqFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.PrivateKeyScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"Scheme\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.PrivateKeyScheme.multiEncDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"multiEncDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity.0.TCSlib.Cryptography.PrivateKeyScheme.encodeList.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"PrivateKeyScheme\"],[\"str\",\"encodeList\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"EnsembleSecurity\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

