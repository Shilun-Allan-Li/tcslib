"""Verify exact replay receipts, declaration comparisons, seals and the ledger map."""
from collections import Counter
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, repo, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
native, meta = area / "native", area / "metadata"
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source = read(area / "SOURCE-CHECK.json")
scope = read(area / "MOVE-SCOPE.json")
declarations = read(area / "DECLARATIONS.json")
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain") and not git("diff", "--check", base, head)
for row in (plan, result, source, declarations):
    assert (row["base"], row["head"]) == (base, head)
assert result["passed"] and result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == len(plan["affected"]) == 35
assert result["initial_retained"] == len(plan["retained"]) == 1067
assert len(products) == len(plan["order"]) == 1102 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert source["legacy_closure_preserved"] and source["facade_closure_preserved"]
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}

assert declarations["matched_declarations"] == 80 and declarations["relocated_declarations"] == 56
assert declarations["axioms_match"] and declarations["legacy_and_new_imports_agree"]
assert declarations["promoted_helper"] == scope["promoted_helper"]
assert declarations["proof_dependency_deltas"] == {
    "TCSlib.Cryptography.prgScheme_encDist": {
        "removed": [], "added": ["TCSlib.Cryptography.PrivateKeyScheme.encDist_apply"],
    },
    "TCSlib.Cryptography.prgScheme_singleMessageSecure": {
        "removed": [],
        "added": ["Iff.mpr", "TCSlib.Cryptography.PrivateKeyScheme.SingleMessageSecure",
                  "TCSlib.Cryptography.PrivateKeyScheme.singleMessageSecure_iff"],
    },
}

renamed = {row["old_name"]: row["new_name"] for row in declarations["declarations"]}
providers = {(row["old_home"], row["old_name"]): (row["new_home"], row["new_name"])
             for row in declarations["declarations"]
             if row["kind"] == "def" and row["old_home"] != row["new_home"]}
pattern = r"(?m)^[^\n]*\.lean:(\d+):(\d+): error(\([^\n]*?\))?: (.*?)(?=\n(?:G06-|FAIL\(|[^\n]*\.lean:\d+:\d+:)|\Z)"
receipts, diagnostics, requested = {}, {}, {}
for side, rev in (("base", base), ("head", head)):
    for lane in ("seals", "focus"):
        tag = side + "-" + lane
        directory = meta / tag
        masks = read(directory / "SCOPE.json")
        control = {"UnsealedControl"} if tag == "head-seals" else set()
        labels = set(masks) | control
        assert {p.stem for p in directory.glob("*.rc")} == labels, tag
        receipts[tag], diagnostics[tag], requested[tag] = {}, [], {}
        for label in sorted(labels):
            stem = directory / label
            log = stem.with_suffix(".log").read_text()
            count = masks.get(label, 0)
            manifest = read(stem.with_suffix(".json")) if label in masks else {}
            if count:
                mask = manifest["requests"]
                assert count == len(mask) == len({(r["home"], r["spelling"]) for r in mask})
                assert sha(stem.with_suffix(".lean")) == manifest["probe_sha256"]
                assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
                requested[tag][label] = {(r["home"], r["spelling"]) for r in mask}
            errors = re.findall(pattern, log, flags=re.S)
            assert len(errors) == len(re.findall(r"\.lean:\d+:\d+: error(?:\([^\n]*?\))?:", log))
            rc = int(stem.with_suffix(".rc").read_text())
            assert rc == int(bool(errors)), (tag, label, rc)
            if label.endswith("Seal"):
                filename = manifest["source_path"]
                raw = git("show", f"{rev}:{filename}")
                assert sha256(raw).hexdigest() == manifest["source_sha256"]
                lines = raw.decode().splitlines()
                mapping = {r["probe_line"]: r["source_line"] for r in manifest["line_map"]}
                assert sorted(mapping.values()) == list(range(1, len(lines) + 1))
                for probe_line, col, code, message in errors:
                    line = mapping[int(probe_line)]
                    diagnostics[tag].append({
                        "path": filename, "line": line, "column": int(col), "source": lines[line-1],
                        "code": code, "message": message.strip(),
                    })
            elif label == "SealedControl":
                assert len(errors) == 1 and "rfl" in errors[0][3] and "encDist" in errors[0][3]
            else:
                assert not errors
            receipts[tag][label] = {
                "requests_verified": count, "errors": len(errors), "rc": rc,
                "probe_sha256": sha(stem.with_suffix(".lean")), "log_sha256": sha(stem.with_suffix(".log")),
                "source_sha256": manifest.get("source_sha256"),
            }
assert not diagnostics["base-seals"] and not diagnostics["head-seals"]
assert len(receipts["base-focus"]) == len(receipts["head-focus"]) == 8
for label, mask in requested["base-focus"].items():
    assert len(mask) == 14
    assert {providers[row] for row in mask} == requested["head-focus"][label]
assert set(receipts["base-focus"]) == set(receipts["head-focus"])
for label, row in receipts["base-focus"].items():
    assert row["source_sha256"] == receipts["head-focus"][label]["source_sha256"]


def signature(row):
    message = row["message"]
    ids = {}
    message = re.sub(r"\?([mu])\.\d+\b", lambda m: "?" + m[1] + "." + str(ids.setdefault(m[0], len(ids)+1)), message)
    for before, after in renamed.items():
        message = message.replace(before, after)
    message = message.replace(".base-focus.", ".focus.").replace(".head-focus.", ".focus.")
    return (row["path"], row["line"], row["column"], row["source"], row["code"], message)


assert Counter(map(signature, diagnostics["base-focus"])) == Counter(map(signature, diagnostics["head-focus"])), diagnostics

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log, (side, log)

ledger_dir = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
ledger_archive = ledger_dir / "11-final-read-ledger.zip"
ledger_sha = next(line.split()[0] for line in (ledger_dir / "SHA256SUMS").read_text().splitlines()
                  if line.endswith("  " + ledger_archive.name))
assert sha(ledger_archive) == ledger_sha
with ZipFile(ledger_archive) as archive:
    ledger = json.loads(archive.read("deferred-read-ledger-final-r1.json"))
assert len(ledger["current_observations"]) == 813 and not ledger["partial"] and not ledger["needs_review"]
links = []
for row in ledger["current_observations"]:
    refs = {(p["home"], p["spelling"]) for p in row.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in row.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if row["channel"] == "generated-equation":
        refs.add((row["provider_home"], row["provider"]))
    if row["channel"] == "explicit-source":
        refs.add((row["head"]["provider_home"], row["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": row["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})

lint_base, lint_head = (read(area / f"campaign-lint-{side}.json") for side in ("base", "head"))
assert not any(level == "FAIL" for level, _, _ in lint_base + lint_head)


def warnings(findings):
    return sorted(name.strip() for level, _, message in findings if level == "WARN"
                  for name in message.split("(check 8):", 1)[1].split(","))


assert warnings(lint_base) == warnings(lint_head) == ["Deterministic", "firstTwoEqFun", "padXor", "prgPadFun"]
assert "0 findings in 4 files" in (area / "style.log").read_text()
save(area / "SEALS.json", {
    "base": base, "head": head, "passed": True, "receipts": receipts,
    "whole_file_errors": 0, "downstream_consumers": 8, "baseline_focused_diagnostics": len(diagnostics["base-focus"]),
    "head_focused_diagnostics": len(diagnostics["head-focus"]), "new_diagnostics": 0,
    "controls": {"unsealed_rfl": "pass", "sealed_rfl": "fails as expected", "sealed_reader": "pass"},
})
save(area / "READS.json", {
    "base": base, "head": head, "ledger_head": ledger["head"], "ledger_archive_sha256": ledger_sha,
    "relocated_provider_links": links, "focused_diagnostics": {side: diagnostics[side + "-focus"] for side in ("base", "head")},
    "explicit_foreign_definition_reads_in_edited_owners": {"base": 0, "head": 0},
    "generated_foreign_equation_reads_in_edited_owners": {"base": 0, "head": 0},
})
print(f"35 affected modules pass. Seals match across 8 consumers with {len(diagnostics['head-focus'])} inherited diagnostics.")
print(f"Mapped {len(links)} deferred provider links.")
