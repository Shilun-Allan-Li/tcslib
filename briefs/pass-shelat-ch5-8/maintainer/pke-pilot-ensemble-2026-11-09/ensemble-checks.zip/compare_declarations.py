"""Compare types, definition terms, references and axiom dependencies after relocation."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area, previous, cleanup = (Path(s).resolve() for s in sys.argv[1:4])
native=area/sys.argv[4]


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def key(name):
    return tuple(map(tuple,name['components']))


prior=read(previous/'native/PLAN.json')
plan=read(native/'PLAN.json')
result=read(native/'RESULT.json')
assert result['passed'] and result['head']==plan['head'] and result['base']==plan['base']
assert result['plan_sha256']==sha(native/'PLAN.json') and result['products_sha256']==sha(native/'PRODUCTS.json')
assert prior['head']==plan['baseline']
assert all(prior[k]==plan[k] for k in ('toolchain_sha256','checker_sha256'))
assert {n:r['sha256'] for n,r in prior['external'].items()}=={n:r['sha256'] for n,r in plan['external'].items()}

a=read(area/'base-metadata/metadata/Base-compact.json')
b=read(area/'metadata/Head-compact.json')
old={key(r['name']):r for r in a['roots']}
new={key(r['name']):r for r in b['roots']}
prefix='TCSlib.Cryptography.'
legacy=prefix+'Asymptotic.PublicKey'
support=legacy+'Lemmas'
leaves=prefix+'Encryption.PublicKey.'
ensemble=leaves+'EnsembleSecurity'
leaf_migrations={legacy:{ensemble}, support:{leaves+'Hybrid',leaves+'HybridMachine'}}
reader=prefix+'BitPublicKeyScheme.pkEncDist_eq'
repair_suffix='TCSlib.Cryptography.tdpBitScheme_pkEncDist'
assert len(old)==len(a['roots']) and len(new)==len(b['roots'])
previous_scheme=read(previous/'metadata/Head-compact.json')
previous_cleanup=read(cleanup/'census-final-r1/Head-compact.json')
combined={key(r['name']):r for r in previous_cleanup['roots'] if r['home']==support}
combined.update({key(r['name']):r for r in previous_scheme['roots'] if r['home']!=leaves+'Scheme'})
assert old==combined
assert a['axiom_names']==b['axiom_names']

new_private={}
for k,row in new.items():
    home=row['home']
    module=(('str','_private'),)+tuple(('str',part) for part in home.split('.'))
    if home.startswith(leaves) and k[:len(module)]==module:
        tail=k[len(module):]
        assert tail and tail[0][0]=='num'
        new_private[home,tail]=k

pairs={}
for k,row in old.items():
    if k in new:
        pairs[k]=k
        continue
    home=row['home']
    module=(('str','_private'),)+tuple(('str',part) for part in home.split('.'))
    assert home in leaf_migrations and k[:len(module)]==module,row['name']
    tail=k[len(module):]
    choices=[new_private[h,tail] for h in leaf_migrations[home] if (h,tail) in new_private]
    assert len(choices)==1,(row['name'],choices)
    pairs[k]=choices[0]
assert len(set(pairs.values()))==len(pairs)
extra=new.keys()-pairs.values()
assert len(extra)==1 and new[next(iter(extra))]['name']['display']==reader
reader_row=new[next(iter(extra))]
sampler=next(r for r in new.values() if r['name']['display']==reader.removesuffix('_eq'))
assert reader_row['home']==ensemble and reader_row['kind']=='theorem'
assert reader_row['axioms']==sampler['axioms'] and 'sorryAx' not in reader_row['axioms']

renames={old[k]['name']['display']:new[v]['name']['display'] for k,v in pairs.items() if k!=v}
rehomed=[]
type_candidates={}
def_candidates={}
value_ref_changes=[]
for k,v in pairs.items():
    x,y=old[k],new[v]
    if x['home']!=y['home']:
        assert y['home'] in leaf_migrations[x['home']],(x['name'],x['home'],y['home'])
        rehomed.append({'base_name':x['name'],'head_name':y['name'],
                        'base_home':x['home'],'head_home':y['home']})
    assert all(x[f]==y[f] for f in ('kind','universes','axioms')), (x['name'],y['name'])
    for field in ('type_refs','value_refs'):
        before={renames.get(ref,ref) for ref in x[field]}
        after=set(y[field])
        if before!=after:
            assert field=='value_refs',(y['name'],before-after,after-before)
            value_ref_changes.append({'name':y['name'],'removed':sorted(before-after),'added':sorted(after-before)})
    if x['type_sha256']!=y['type_sha256']:
        type_candidates[k]=v
    if x['definition_sha256']!=y['definition_sha256']:
        def_candidates[k]=v

changed_keys=type_candidates.keys()|def_candidates.keys()
def extract(path, term_keys, catalog_keys):
    terms,catalog={},{}
    with path.open() as f:
        for r in map(json.loads,f):
            if r['record'] not in ('root','catalog'):
                continue
            k=key(r['name'])
            if r['record']=='root' and k in term_keys:
                terms[k]=r
            if r['record']=='catalog' and k in catalog_keys:
                catalog[k]={f:r[f] for f in ('kind','status','instance','abbrev','matcher')}
    assert terms.keys()==term_keys and catalog.keys()==catalog_keys
    return terms,catalog

old_raw,old_catalog=extract(area/'base-metadata/metadata/Base.jsonl',changed_keys,old.keys())
new_raw,new_catalog=extract(area/'metadata/Head.jsonl',{pairs[k] for k in changed_keys},new.keys())
assert all(old_catalog[k]==new_catalog[v] for k,v in pairs.items())
assert not new_catalog[next(iter(extra))]['instance']

def canonical_expression(expr,renaming,changes,path=()):
    if not isinstance(expr,list) or not expr:
        return expr
    tag=expr[0]
    if tag in ('forall','lam','let'):
        name=key(expr[1])
        scope=('str','_@')
        if scope in name:
            assert ('str','_hyg') in name or ('str','_hygCtx') in name,name
            name=name[:name.index(scope)]
            changes.append((path+(1,),expr[1]))
        return [tag,name,*[canonical_expression(x,renaming,changes,path+(i,)) for i,x in enumerate(expr[2:],2)]]
    if tag in ('const','proj'):
        name=key(expr[1])
        replacement=renaming.get(name,name)
        if replacement!=name:
            changes.append((path+(1,),expr[1]))
        return [tag,replacement,*[canonical_expression(x,renaming,changes,path+(i,)) for i,x in enumerate(expr[2:],2)]]
    return [canonical_expression(x,renaming,changes,path+(i,)) for i,x in enumerate(expr)]

term_adjustments=[]
for field,candidates in (('type',type_candidates),('definition_value',def_candidates)):
    for k,v in sorted(candidates.items()):
        before,after=old_raw[k][field],new_raw[v][field]
        bs,hs=[],[]
        assert canonical_expression(before,pairs,bs)==canonical_expression(after,{},hs), (field,new[v]['name'])
        diff=[{'path':p,'base':dict(bs).get(p),'head':dict(hs).get(p)}
              for p in sorted(set(dict(bs))|set(dict(hs))) if dict(bs).get(p)!=dict(hs).get(p)]
        assert diff
        term_adjustments.append({'name':new[v]['name'],'field':field,'changes':diff})

# Body-reference changes are reviewed against the exact moved source and the published reader.
for row in value_ref_changes:
    if row['name']['display'].endswith(repair_suffix):
        assert row['added']==['Prod.fst','Prod.snd',reader] and not row['removed'],row
    else:
        print('Moved proof reference difference:',row,flush=True)

def c3(path):
    roots,refs,controls=[],[],[]
    for line in path.read_text().splitlines():
        for label,target in (('ROOT',roots),('REF',refs),('CONTROL',controls)):
            mark='G06-C3-'+label+' '
            if line.startswith(mark):
                target.append(tuple(line[len(mark):].split(' | ')))
    return roots,refs,controls

old_c3=area/'base-metadata/metadata/run/C3.log'
new_c3=area/'metadata/run/C3.log'
old_roots,old_refs,old_controls=c3(old_c3)
new_roots,new_refs,new_controls=c3(new_c3)
for roots,rows in ((old_roots,old),(new_roots,new)):
    assert Counter((r[0],r[1]) for r in roots)==Counter((r['home'],r['name']['display']) for r in rows.values())
assert len(new_controls)==2 and old_controls==new_controls
assert not old_refs and not new_refs,(old_refs,new_refs)
assert f'G06-C3-END base={plan["base"]} head={plan["head"]} modules={len(b["owners"])} roots={len(new)} pairs=0 ' in new_c3.read_text()

control_area=cleanup/'controls-final-r1'
control=read(control_area/'RESULT.json')
manifest=read(control_area/'MANIFEST.json')
assert control['passed'] and control['head']==manifest['head'] and len(control['outcomes'])==13
before=read(previous/'native/PRODUCTS.json')
after=read(native/'PRODUCTS.json')
pending=[manifest['owner'].replace('.','/')]
control_closure=set()
while pending:
    module=pending.pop()
    if module in control_closure:
        continue
    control_closure.add(module)
    assert prior['graph'][module]==plan['graph'][module],module
    assert all(before[module][k]==after[module][k] for k in ('object_sha256','source_sha256','direct_local')),module
    assert sha(Path(plan['tree'])/(module+'.olean'))==after[module]['object_sha256'],module
    pending.extend(plan['graph'][module])
for m,r in zip(manifest['probes'],control['outcomes'],strict=True):
    assert all(r[k]==v for k,v in m.items()) and r['rc']==m['expected_rc']
    assert len(r['errors'])==m['expected_errors']
    assert sha(Path(m['module']+'.lean'))==m['source_sha256']
    assert sha(control_area/(r['label']+'.log'))==r['log_sha256']

out={'base':plan['base'],'head':plan['head'],'base_declarations':len(old),'head_declarations':len(new),
     'rehomed':rehomed,'private_name_changes':renames,'added_reader':reader_row,
     'term_adjustments':term_adjustments,'value_reference_changes':value_ref_changes,
     'axiom_names':b['axiom_names'],'roots_with_sorryAx':sum('sorryAx' in r['axioms'] for r in new.values()),
     'native_axiom_controls':{'base':a['native_axiom_controls'],'head':b['native_axiom_controls']},
     'c3_controls':new_controls,'c3_pairs':len(new_refs),'verified_reused_controls':len(control['outcomes']),
     'control_context_modules':len(control_closure)}
with (area/'DECLARATIONS.json').open('x') as f:
    json.dump(out,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(len(old),len(new),'declarations;',len(rehomed),'moves;',len(renames),'private names;',
      len(term_adjustments),'normalized term differences;',len(value_ref_changes),'proof-reference deltas')
