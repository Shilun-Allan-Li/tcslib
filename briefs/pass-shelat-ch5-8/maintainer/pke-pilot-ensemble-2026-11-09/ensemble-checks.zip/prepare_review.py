"""Generate the review and records only from completed, pinned evidence."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

area=Path(sys.argv[1]).resolve()
mode=sys.argv[2]
native_name='native-final'
def load(path):
    return json.loads((area/path).read_bytes())

def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

native,decl,reads=map(load,(native_name+'/RESULT.json','DECLARATIONS.json','READS.json'))
base,head=(native[k] for k in ('base','head'))
assert all(x['base']==base and x['head']==head for x in (decl,reads))
assert native['passed'] and reads['passed']
assert len(decl['value_reference_changes'])==1
assert all(re.fullmatch('[0-9a-f]{40}',p) for p in (base,head))
repo='https://github.com/Shilun-Allan-Li/tcslib'
plan_path='briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md'
review='pke-pilot-ensemble-2026-11-09'
review_path=f'briefs/pass-shelat-ch5-8/maintainer/{review}/README.md'
n=decl['base_declarations']
moves=len(decl['rehomed'])
privates=len(decl['private_name_changes'])
debt=len(reads['carry_forward'])
fresh=native['fresh_native_checks']
retained=native['initial_retained']
probe_count=reads['focused']
seal_count=reads['full']
if mode=='pr':
    (area/'pr-body.md').write_text(f"""## Public-key encryption pilot

- `EnsembleSecurity` owns the single-bit, single-message and fixed-vector games,
  the bitwise construction and the single-to-multi-message theorem.
- `Hybrid` owns the shared-key advantage bound, and `HybridMachine` owns the
  polynomial-time reduction and its coin split.
- The two legacy imports still expose their original declarations. The trapdoor
  sampler proof uses the new `BitPublicKeyScheme.pkEncDist_eq` equation.

## Verification

- All {fresh} affected modules compile, including the library root and campaign
  Checks. The replay validates {retained:,} retained objects.
- The new import and both legacy imports pass standalone probes. The census
  compares all {n} existing declarations, with {moves} rehomed and {privates} private names
  updated to reflect their new file scope. Their types and axiom dependencies
  match after accounting for generated binder labels and private names.
- {seal_count} whole-file seals and {probe_count} focused probes find no new foreign reads.
  All {debt} inherited diagnostics match the accepted ledger at their new sites.
- Plain style checks report zero findings. The legacy public-key module
  now fits below the size threshold. Campaign lint retains reader warnings
  for existing definitions.

Base `{base}`. Checked head `{head}`.

[Approved pilot map]({repo}/blob/{base}/{plan_path})
""")
elif mode=='records':
    m=Path(sys.argv[3])
    pr=load('pr-live.json')
    assert pr['state']=='OPEN' and not pr['isDraft'] and pr['mergeable']=='MERGEABLE'
    assert pr['headRefOid']==head and pr['baseRefName']=='cryptography/pass-shelat-ch2-4'
    assert re.fullmatch(re.escape(repo)+r'/pull/\d+',pr['url'])
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=m,text=True).strip()==base
    number,url=(pr[k] for k in ('number','url'))
    stage=area/'records'
    evidence=stage/'evidence'
    evidence.mkdir(parents=True)
    archive=area/'ensemble-checks.zip'
    archive_sha=sha(archive)
    for name in ('ensemble-checks.zip','pr-live.json'):
        shutil.copyfile(area/name,evidence/name)
    files=[native_name+'/'+p for p in ('PLAN.json','RESULT.json','PRODUCTS.json')]
    files+=['SOURCE-MAP.json','DECLARATIONS.json','READS.json','SEALS.json','SEALS-MOVED.json',
            'read-scan/scan.log','pr-live.json']
    verify={'base':base,'head':head,'passed':True,'pr':number,'pr_url':url,
            'native':{'fresh':fresh,'retained':retained,'total':fresh+retained},
            'declarations':{'baseline':n,'candidate':decl['head_declarations'],'rehomed':moves,
                 'rehomed_private_names':privates,'new_readers':1,
                 'inherited_sorryAx_dependencies':decl['roots_with_sorryAx']},
            'seals':{'whole_file':seal_count,'focused':probe_count,'requests':reads['requests'],
                     'inherited_diagnostics':debt,'new_diagnostics':0,'explicit_or_generated_reads':0,
                     'verified_retained_controls':decl['verified_reused_controls']},
            'artifact_sha256':{p:sha(area/p) for p in files},
            'archive':{'name':archive.name,'sha256':archive_sha,'bytes':archive.stat().st_size}}
    (evidence/'VERIFICATION.json').write_text(json.dumps(verify,indent=2)+'\n')
    counts=Counter(Path(r['current_owner']).name for r in reads['carry_forward'])
    rows=''.join(f'| `{name}` | {count} |\n' for name,count in sorted(counts.items()))
    (evidence/'README.md').write_text(f"""# Public-key ensemble security and hybrid relocation

Seyoon merged the [scheme interfaces #257]({repo}/pull/257) at `{base}`.
[PR #{number}]({url}) implements the next slice of the
[approved pilot](../cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
at `{head}`.

`EnsembleSecurity.lean` owns the single-bit, single-message and fixed-vector
experiments and the two security proofs. `Hybrid.lean` owns the shared-key
bound and imports the polynomial-time reduction from `HybridMachine.lean`.
The facade lists all three leaves. `Asymptotic/PublicKey.lean` and
`Asymptotic/PublicKeyLemmas.lean` continue to expose their original interfaces.
They retain the trapdoor construction and its predictor. The one additional
lemma, `BitPublicKeyScheme.pkEncDist_eq`, supplies the sampler equation to
the trapdoor ciphertext proof.

- The replay compiles all {fresh} affected modules and verifies {retained:,}
  retained objects. The library root passes. The campaign Checks object
  and output match the checked #257 inputs. All three standalone import probes pass.
- The native census compares {n} existing declarations and the new equation.
  It records {moves} rehomed identities and {privates} private names whose module
  scope changed. The type and definition comparisons preserve binder flags
  and normalize the generated labels and private names. All existing axiom
  dependencies match. The new equation has the same axiom dependencies as
  the sampler. The only changed proof references are the equation and its
  pair projections in the trapdoor ciphertext proof.
- {seal_count} whole-file seals and {probe_count} focused probes check the moved
  definitions and downstream imports. The original thirteen sensitivity
  controls transfer through identical source and object closures. The fresh
  generated-equation collector passes both of its controls. The explicit
  tactic scan and generated-equation collector find zero scoped reads.
- Plain style lint has zero findings. Campaign lint reports zero failures
  and retains the inherited equation-reader warnings. The old public-key
  file falls from 1,023 to 570 lines.

The {debt} inherited diagnostics match the original source steps and declaration
identities. Their current homes feed the final seal cleanup.

| Current file | Inherited diagnostics |
|---|---:|
{rows}
`READS.json` maps their ledger IDs, declaration homes, ranges and provider
evidence. `VERIFICATION.json` pins the comparison and archive.
`ensemble-checks.zip` has SHA-256 `{archive_sha}`.

**Clear to merge — the relocation and both compatibility paths pass.**
""")
    handoff=m/'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md'
    lines=handoff.read_text().splitlines(keepends=True)
    index=[i for i,l in enumerate(lines) if l.startswith('| Cleanup and reorganization | ')]
    assert len(index)==1 and '#257' in lines[index[0]]
    old=lines[index[0]]
    pre=old.split('[Scheme interface PR #257]',1)[0]
    assert pre!=old
    lines[index[0]]=pre+f"""Seyoon merged the [scheme interfaces #257]({repo}/pull/257) at `{base}`. [Ensemble relocation PR #{number}]({url}) at `{head}` is clear for Seyoon to merge. The new and legacy imports pass, and the fifteen inherited diagnostics have current source and declaration homes. See the [relocation review](maintainer/{review}/README.md) and [pilot map](maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md). Resume the next move after this slice lands. The inherited seal ledger feeds the final cleanup on the new layout. Efficiency still needs the recorded issue-time probes. |
"""
    (stage/'MAINTAINER-HANDOFF.md').write_text(''.join(lines))
    log=(m/'PassShelatChapter5-8Plan.md').read_text()
    assert log.endswith('\n') and '#256 merged and PKE scheme interface relocation verified' in log.splitlines()[-1]
    row=f"""| 2026-11-09 (PST) | **#257 merged and PKE ensemble relocation verified.** Seyoon merged #257 at `{base}`. [PR #{number}]({url}) at `{head}` moves the games, the bitwise scheme, the fixed-vector security theorem and the hybrid support. Both legacy imports continue to work. The trapdoor sampler reads through the published equation. All {fresh} affected modules pass and {retained:,} objects transfer. The census matches {n} existing declarations and records {moves} owner changes. The {debt} inherited diagnostics map to current locations. [Evidence and ledger mapping]({review_path}). Seyoon merges this slice before the next move. | record |
"""
    (stage/'PassShelatChapter5-8Plan.md').write_text(log+row)
    print(review,archive_sha)
else:
    raise ValueError(mode)
