"""Verify the new seal coverage and translate the inherited diagnostics."""
from collections import Counter
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile

area,previous,cleanup,campaign=(Path(p).resolve() for p in sys.argv[1:5])
native=area/sys.argv[5]
published=campaign/'briefs/pass-shelat-ch5-8/maintainer'


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def normalize(text,renames):
    text=re.split(r'(?m)^(?:G06-(?:SEAL|COMPONENT|MASK|CONTROL)|FAIL\(|=== Lean)',text,maxsplit=1)[0].strip()
    for old,new in renames.items():
        text=text.replace(old,new)
    labels={}
    return re.sub(r'\?([mu])\.\d+\b',lambda m:'?'+m[1]+'.'+str(labels.setdefault(m[0],len(labels)+1)),text)


plan=read(native/'PLAN.json')
native_result=read(native/'RESULT.json')
assert native_result['passed'] and native_result['head']==plan['head']
products=read(native/'PRODUCTS.json')
checks='audits/pass-shelat/Checks'
previous_checks=read(previous/'native/PRODUCTS.json')[checks]
assert all(products[checks][k]==previous_checks[k] for k in ('source_sha256','object_sha256','log_sha256'))
sources=read(area/'SOURCE-MAP.json')
decl=read(area/'DECLARATIONS.json')
assert all(r['base']==plan['base'] and r['head']==plan['head'] for r in (sources,decl))
renames=decl['private_name_changes']
moved={r['base_name']['display']:r for r in decl['rehomed']}
now={r['head_name']['display']:r for r in decl['rehomed']}
prefix='TCSlib.Cryptography.'
legacy=prefix+'Asymptotic.PublicKey'
support=legacy+'Lemmas'
new=prefix+'Encryption.PublicKey.'
origin={new+'EnsembleSecurity':legacy,new+'HybridMachine':support,new+'Hybrid':support}

scheme_receipt=read(published/'pke-pilot-schemes-2026-11-09/VERIFICATION.json')
assert scheme_receipt['head']==plan['baseline'] and scheme_receipt['passed']
for f in ('SEALS.json','READS.json','read-scan/scan.log'):
    assert sha(previous/f)==scheme_receipt['artifact_sha256'][f]
prior=read(previous/'SEALS.json')
assert prior['source_errors']==9
older=read(cleanup/'seals-head-effective-final-r1.json')
old_support=next(r for r in older['outcomes'] if r['owner']==support)
older_published=published/'cleanup-incremental-2026-11-09/final-r1'
archive_digests={p:h for h,p in (l.split(maxsplit=1) for l in (older_published/'SHA256SUMS').read_text().splitlines())}
old_ledger='deferred-read-ledger-final-r1.json'
old_scan='head-read-scan-final-r1/scan.log'
for file,paths in (
    ('10-final-seals.zip',('seals-head-effective-final-r1.json','seals-head-final-r1/'+old_support['label']+'.json',
                          Path(old_support['log']).relative_to(cleanup).as_posix())),
    ('11-final-read-ledger.zip',(old_ledger,old_scan)),
):
    path=older_published/file
    assert sha(path)==archive_digests[file]
    with ZipFile(path) as archive:
        for rel in paths:
            assert sha256(archive.read(rel)).hexdigest()==sha(cleanup/rel),rel

full=read(area/'SEALS.json')
ledger_only='--ledger-only' in sys.argv
focus=None if ledger_only else read(area/'SEALS-MOVED.json')
assert len(full['outcomes'])==8
assert all(r['valid_harness'] for r in full['outcomes'])
if focus is not None:
    assert len(focus['outcomes'])==4
    assert all(r['valid_harness'] and r['rc']==0 and not r['errors'] for r in focus['outcomes']),[
        (r['owner'],r['errors']) for r in focus['outcomes'] if r['rc']!=0]
baseline={r['owner']:(r,previous/'seals') for r in prior['outcomes']}
baseline[support]=(old_support,cleanup/'seals-head-final-r1')
old_scope={origin.get(r['owner'],r['owner']) for r in full['outcomes']}
assert support in old_scope and legacy in old_scope
old_paths={baseline[m][0]['path'] for m in old_scope}
head_paths={r['path'] for r in full['outcomes']}
source_line_map=sources['lines']
inverse={tuple(p):(path,int(n)) for path,lines in source_line_map.items() for n,p in lines.items()}
assert len(inverse)==sum(len(lines) for lines in source_line_map.values())

def mask(p,r):
    return read(p/(r['label']+'.json'))


def relocated_request(r):
    movement=moved.get(r['spelling'])
    if not movement:
        return r
    name,home=movement['head_name'],movement['head_home']
    return {**r,'spelling':name['display'],'name_components':name['components'],
            'home':home,'home_components':[['str',s] for s in home.split('.')]}


expected=Counter()
for old_owner in sorted(old_scope):
    old,old_dir=baseline[old_owner]
    assert sha(old_dir/(old['label']+'.json'))==old['meta_sha256']
    assert sha(Path(old['log']))==old['log_sha256']
    assert old['source_sha256']==(read(previous/'native/PLAN.json')['source_digests'][old['path'][:-5]])
    for err in old['errors']:
        expected[old['path'],err['source_line'],err['column'],normalize(err['text'],renames)]+=1

scope=[]
actual=Counter()
err_records={}
for r in full['outcomes']:
    owner=r['owner']
    old_owner=origin.get(owner,owner)
    old,old_dir=baseline[old_owner]
    current=mask(area/'seals',r)
    past=mask(old_dir,old)
    keep={}
    for request in past['requested']:
        row=relocated_request(request)
        if row['home'] in current['closure_homes']:
            keep[row['spelling']]=row
    actual_mask={x['spelling']:x for x in current['requested']}
    newly_foreign={n:x for n,x in actual_mask.items() if n in now and now[n]['base_home']==old_owner}
    assert not keep.keys()&newly_foreign.keys()
    wanted={**keep,**newly_foreign}
    assert actual_mask==wanted,(owner,actual_mask.keys()-wanted.keys(),wanted.keys()-actual_mask.keys())
    scope.append({'owner':owner,'base_owner':old_owner,'base_requests':len(past['requested']),
                  'retained_visible_requests':len(keep),'newly_foreign_requests':sorted(newly_foreign),
                  'head_requests':len(actual_mask),'diagnostics':len(r['errors'])})
    for err in r['errors']:
        n=err['source_line']
        path,line=source_line_map.get(r['path'],{}).get(str(n),(r['path'],n))
        diagnostic=normalize(err['text'],{})
        key=(path,line,err['column'],diagnostic)
        actual[key]+=1
        assert key not in err_records
        err_records[key]=(r,err)
if expected!=actual:
    for label,rows in (('MISSING',expected-actual),('NEW',actual-expected)):
        for key,count in rows.items():
            print(label,count,*key,sep='\t')
    raise ValueError('Seal diagnostics differ')

def explicit(path,paths):
    sections=re.split(r'(?m)^## \(c[23]\)[^\n]*\n',path.read_text())
    assert len(sections)==3
    return [row for section in sections for row in section.splitlines()
            if any(row.startswith(p+':') or row.startswith(p[:-5].replace('/','.')+'\t') for p in paths)]
assert not explicit(previous/'read-scan/scan.log',old_paths)
assert not explicit(cleanup/old_scan,{old_support['path']})
assert not explicit(area/'read-scan/scan.log',head_paths)

old_rows=[]
for r in read(previous/'READS.json')['carry_forward']:
    old_rows.append({'id':r['id'],'disposition':r['disposition'],'historical_owner':r['historical_owner'],
        'path':r['current_owner'],'line':r['current_line'],'span':r['current_span'],'column':r['column'],
        'source':r['source'],'diagnostic':r['diagnostic'],'log_sha256':r['current_log_sha256'],
        'actual':r['declarations'],'providers':r['provider_pairs'],'provider_note':r.get('provider_note')})
for r in read(cleanup/old_ledger)['current_observations']:
    if r['path']==old_support['path'] and r['channel']=='whole-file-seal':
        old_rows.append({'id':r['id'],'disposition':r['disposition'],'historical_owner':r['historical_owner'],
            'path':r['path'],'line':r['head_line'],'span':r['head_span'],'column':r['column'],'source':r['head_source'],
            'diagnostic':r['head_error'],'log_sha256':r['head_log_sha256'],'actual':r['head_actual'],
            'providers':r['provider_pairs'],'provider_note':r.get('provider_note')})
assert len(old_rows)==sum(actual.values())==15
carry=[]
for r in old_rows:
    key=(r['path'],r['line'],r['column'],normalize(r['diagnostic'],renames))
    output,err=err_records.pop(key)
    dest=output['path']
    assert inverse[r['path'],r['line']]==(dest,err['source_line'])
    old_span=r['span']
    new_span={**old_span,'name':renames.get(old_span['name'],old_span['name'])}
    for point in ('start','dstart','end'):
        path,line=inverse[r['path'],old_span[point]]
        assert path==dest
        new_span[point]=line
    assert all(inverse[r['path'],i]==(dest,i-old_span['dstart']+new_span['dstart'])
               for i in range(old_span['dstart'],old_span['end']+1))
    assert output['source_sha256']==plan['source_digests'][dest[:-5]]
    current_names=[]
    for declaration in r['actual']:
        moved_decl=moved.get(declaration['name']['display'])
        current_names.append({**declaration,'name':moved_decl['head_name'],'home':moved_decl['head_home']}
                             if moved_decl else declaration)
    providers=[{**p,'current':relocated_request(p['head'])} for p in r['providers']]
    carry.append({'id':r['id'],'historical_owner':r['historical_owner'],'disposition':r['disposition'],
        'baseline_path':r['path'],'baseline_line':r['line'],'baseline_span':old_span,'baseline_log_sha256':r['log_sha256'],
        'current_owner':dest,'current_line':err['source_line'],'current_span':new_span,'current_log_sha256':output['log_sha256'],
        'current_source_sha256':output['source_sha256'],'column':r['column'],'source':r['source'],'diagnostic':key[3],
        'baseline_declarations':r['actual'],'current_declarations':current_names,'providers':providers,
        'provider_note':r['provider_note']})
assert not err_records
if ledger_only:
    print(len(carry),'inherited diagnostics matched across',len(full['outcomes']),'whole-file seals')
    sys.exit(0)
with (area/'READS.json').open('x') as f:
    json.dump({'base':plan['base'],'head':plan['head'],'passed':True,
               'requests':sum(r['requested'] for r in full['outcomes']),'full':len(full['outcomes']),
               'focused':len(focus['outcomes']),'scopes':scope,'c1_reads':0,'c2_failures':0,'c3_reads':0,
               'carry_forward':carry,'previous_read_sha256':sha(previous/'READS.json'),
               'older_ledger_sha256':sha(cleanup/old_ledger),'checks':products[checks]},f,ensure_ascii=False,indent=2)
    f.write('\n')
print(len(carry),'inherited diagnostics matched across',len(full['outcomes']),'whole-file seals;',
      len(focus['outcomes']),'clean focused relocation probes')
