#!/usr/bin/env bash
set -euo pipefail
area=$1
native=$2
toolchain=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' ".lake/ps-maintainer/pke-pilot-schemes-20261109/native/PLAN.json")
run="$area/metadata/run"
mkdir "$run"
test -s "$native/RESULT.json"
for probe in Census C3; do
  /usr/bin/memory_pressure -Q > "$run/$probe.resources.txt"
  python3 -I - "$run/$probe.resources.txt" <<'PY'
from pathlib import Path
import re,sys
text=Path(sys.argv[1]).read_text()
total=int(re.search(r'system has (\d+)',text)[1])
percent=int(re.search(r'memory free percentage:\s*(\d+)%',text)[1])
assert total*(percent-1)//100 >= 4*1024**3
PY
  module="$area/metadata/$probe"
  env -u LEAN_PATH -u LEAN_SRC_PATH -u LEAN_SYSROOT -u LEAN_OPTS -u ELAN_TOOLCHAIN -u PFR_BOOTSTRAP_CONFIG \
    TCSLIB_OLEANS="$native/oleans" PATH="${toolchain%/*}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
    bash scripts/lean_check_tree.sh "${module#"$PWD"/}" > "$run/$probe.log" 2>&1 || { tail -n 35 "$run/$probe.log"; exit 1; }
  shasum -a 256 "$module.lean" "$run/$probe.log" > "$run/$probe.sha256"
  printf 'PASS %s\n' "$probe"
done
