## Public-key encryption pilot

- `EnsembleSecurity` owns the single-bit, single-message and fixed-vector games,
  the bitwise construction and the single-to-multi-message theorem.
- `Hybrid` owns the shared-key advantage bound, and `HybridMachine` owns the
  polynomial-time reduction and its coin split.
- The two legacy imports still expose their original declarations. The trapdoor
  sampler proof uses the new `BitPublicKeyScheme.pkEncDist_eq` equation.

## Verification

- All 13 affected modules compile, including the library root and campaign
  Checks. The replay validates 1,067 retained objects.
- The new import and both legacy imports pass standalone probes. The census
  compares all 400 existing declarations, with 90 rehomed and 6 private names
  updated to reflect their new file scope. Their types and axiom dependencies
  match after accounting for generated binder labels and private names.
- 8 whole-file seals and 4 focused probes find no new foreign reads.
  All 15 inherited diagnostics match the accepted ledger at their new sites.
- Plain style checks report zero findings. The legacy public-key module
  now fits below the size threshold. Campaign lint retains reader warnings
  for existing definitions.

Base `e9f470f828db562e04e2243122b24b29a9bab581`. Checked head `313a0a9de4818417172e693512dc7a98943eaef1`.

[Approved pilot map](https://github.com/Shilun-Allan-Li/tcslib/blob/e9f470f828db562e04e2243122b24b29a9bab581/briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
