"""Move complete declaration blocks and publish the bit sampler's reader."""
from pathlib import Path
import sys

root = Path(sys.argv[1])
crypto = root/'TCSlib/Cryptography'
legacy = crypto/'Asymptotic/PublicKey.lean'
lemmas = crypto/'Asymptotic/PublicKeyLemmas.lean'
facade = crypto/'Encryption/PublicKey.lean'
destination = crypto/'Encryption/PublicKey'
source = legacy.read_text()
support = lemmas.read_text()
header = source.split('import ', 1)[0]
options = """set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false
"""
ps10 = """* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010."""
gar26 = """* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, Theorem 3.2 (the predictor from a distinguisher)."""
namespace_end = 'end TCSlib.Cryptography'
base_module = 'TCSlib.Cryptography.'
destination_module = base_module+'Encryption.PublicKey.'


def module(imports, doc, body, opens, encode_list=False):
    imports = ''.join(f'import {name}\n' for name in imports)
    if encode_list:
        opens += '\nopen PrivateKeyScheme (encodeList)'
    return (header + imports + '\n' + options + f'\n/-!\n{doc.strip()}\n-/\n'
            + f'\nnamespace TCSlib.Cryptography\n\n{opens}\n\n'
            + body.strip() + f'\n\n{namespace_end}\n')


def cut(text, start, end):
    i, j = text.index(start), text.index(end)
    assert i < j
    return text[i:j]


ensemble_start = '/-! ## Ensemble security [PS10, Definition 102.2] -/'
trapdoor_start = '/-! ## Algorithm 104.3:'
machine_start = '/-! ## Coin blocks -/'
hybrid_start = '/-! ## The shared-parameter hybrid bound (concrete) -/'
predictor_start = '/-! ## The predictor machine of Theorem 104.4 -/'
old_average_header = '/-! ## Averages and one-letter strings -/'
# Move the singleton lemma with the one-bit coin and tuple helpers.
singleton_start = support.rfind('/--', 0, support.index('theorem ofFn_fin_one '))
average_start = support.rfind('/--', 0, support.index('theorem uexp_half_add '))
assert support.index(old_average_header) < singleton_start < average_start
assert support[singleton_start:average_start].count('\ntheorem ') == 1
reader = """/-- The single-bit sampler returns the public key and the encryption of `[b]`
on the supplied key-generation and encryption coins. -/
theorem pkEncDist_eq (S : BitPublicKeyScheme) (n : ℕ) (b : Bool)
    (r : S.gen.Coins n × S.enc.Coins n) :
    S.pkEncDist n b r = pairEncode (pairFstD (S.gen.runAt n [] r.1))
      (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] r.1)) [b]) r.2) := rfl

"""
ensemble = cut(source,ensemble_start,trapdoor_start)
single_bit_secure = '/-- **Single-bit security**'
assert ensemble.count(single_bit_secure)==1
ensemble = ensemble.replace(single_bit_secure,reader+single_bit_secure,1)
ensemble_doc = f"""# Ensemble security for public-key encryption

The experiments expose the public key with the ciphertexts. In the fixed-vector
experiment, all encryptions share one key and use independent encryption coins.

The scheme interface gives decryption the secret key and ciphertext. A scheme
that needs `1^n` for decryption includes it in the secret key.

## Main definitions

* `TCSlib.Cryptography.PublicKeyScheme.pkEncDist` and `PublicKeyScheme.Secure` give the
  single-message experiment and security predicate.
* `TCSlib.Cryptography.PublicKeyScheme.pkMultiEncDist` and
  `PublicKeyScheme.MultiMessageSecure` give the fixed-vector experiment and security predicate.
* `TCSlib.Cryptography.BitPublicKeyScheme.pkEncDist` and `BitPublicKeyScheme.SingleBitSecure`
  specialize the experiment to one bit. `BitPublicKeyScheme.bitwise` encrypts a string bit by bit.
* `TCSlib.Cryptography.hybridPlant` inserts a challenge ciphertext at the selected position
  and encrypts the other messages with the public key.

## Main results

* `TCSlib.Cryptography.distAdv_multi_le_sum` bounds the fixed-vector advantage by the sum
  of the single-position advantages.
* `TCSlib.Cryptography.PublicKeyScheme.Secure.multiMessageSecure` lifts single-message
  security to fixed-vector security.
* `TCSlib.Cryptography.BitPublicKeyScheme.SingleBitSecure.bitwise` proves security of
  the bitwise scheme. `BitPublicKeyScheme.singleBitSecure_iff` characterizes single-bit
  security by the negligible advantage between the two possible messages.

## References

{ps10}
  (Definition 102.2 and p. 103.)
"""
hybrid_doc = f"""# The shared-key hybrid bound

The reduction encrypts every position except the challenge itself under the
public key. It uses advice to choose the position with maximal advantage.

## Main definitions

* `TCSlib.Cryptography.singleDist` and `TCSlib.Cryptography.multiDist` sample one
  encryption and a tuple of encryptions, respectively.
* `TCSlib.Cryptography.hybridAdv` is the planting distinguisher with typed coins.

## Main results

* `TCSlib.Cryptography.distAdv_tuple_le_sum` and `TCSlib.Cryptography.distAdv_tuple_le_mul`
  bound the tuple advantage with a shared public parameter.
* `TCSlib.Cryptography.exists_hybridBound` packages the bound using one non-uniform
  polynomial-time reduction.

## References

{ps10}
  (p. 103.)
"""
machine_doc = f"""# The public-key hybrid machine

The machine encrypts the messages outside the challenge position, inserts the
challenge ciphertext, then runs the tuple distinguisher. Its advice supplies the
hybrid index, the messages and the coin offsets.

## Main definitions

* `TCSlib.Cryptography.coinBlocks` identifies typed coin blocks with one coin string.
* `TCSlib.Cryptography.hybridPre` prepares the encoded tuple for the distinguisher.
* `TCSlib.Cryptography.hybridCoins` splits the hybrid machine's coins into encryptor
  blocks and distinguisher coins.

## Main results

* `TCSlib.Cryptography.blockEncFun_flatten` describes block encryption on a concatenation
  of messages. `TCSlib.Cryptography.encodeList_ofFn_split` splits an encoded tuple.
* `TCSlib.Cryptography.exists_hybridMachine` constructs the reduction with its coin count
  and run equation.
* `TCSlib.Cryptography.ofFn_hybridCoins` and
  `TCSlib.Cryptography.acceptProb_distinguisherL_coins` relate the machine to typed coins.

## References

{ps10}
  (p. 103.)
"""
predictor_doc = f"""# Predictor support for trapdoor encryption

This module develops the predictor used for the security of Algorithm 104.3.
It also imports the ensemble hybrid support for callers of the original
`Asymptotic.PublicKeyLemmas` module.

## Main definitions

* `TCSlib.Cryptography.tdpPredFun` computes the predictor's output from a
  distinguisher verdict and its extra coin.
* `TCSlib.Cryptography.tdpPredictor` is the predictor machine and
  `TCSlib.Cryptography.predCoins` is its coin bijection.

## Main results

* `TCSlib.Cryptography.tdpPredictor_runAtL` gives the machine's run equation.
* `TCSlib.Cryptography.uprob_tdpPredictor` gives the probability identity used in
  the prediction lemma. `TCSlib.Cryptography.uexp_half_add` and
  `TCSlib.Cryptography.uexp_half_sub` evaluate the corresponding averages.

## References

{ps10}
  (Theorem 104.4.)
{gar26}
"""
trapdoor_doc = f"""# Trapdoor bit encryption

This module builds the trapdoor construction of Algorithm 104.3.
It imports the scheme interfaces and ensemble security results through
`TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity` for existing callers.

**Deviation.** The single-bit scheme samples `r ← D_i` with the collection's sampler.
It carries `⟨1^n, ⟨i, t⟩⟩` as the secret key, runs the trapdoor inverter on the
all-`true` coin string, and takes the predicate evaluator `H` as explicit data.
Honest sampling is the field `Collection.sample_spec`.

## Main definitions

* `TCSlib.Cryptography.Collection.PredEvaluator` is a polynomial-time evaluator
  of a predicate on a collection.
* `TCSlib.Cryptography.TrapdoorCollection.tdpBitScheme` packages the key generator,
  encryptor and decryptor of Algorithm 104.3.
* `TCSlib.Cryptography.pkPredictor` turns a ciphertext distinguisher into a predictor.

## Main results

* `TCSlib.Cryptography.Collection.HardCore.nonempty_predEvaluator` obtains a predicate
  evaluator by canonical decoding.
* `TCSlib.Cryptography.TrapdoorCollection.tdpBitScheme_singleBitSecure` proves single-bit
  security from one-wayness and a hard-core predicate.
* `TCSlib.Cryptography.TrapdoorCollection.OneWay.exists_glPad_singleBitSecure` supplies
  the predicate and its evaluator through Goldreich–Levin under the width premise `henc`.

## References

{ps10}
  (Algorithm 104.3 and Theorem 104.4.)
{gar26}
"""
trapdoor = cut(source,trapdoor_start,namespace_end)
old_read = """  show pairEncode (pairFstD (T.tdpGen.runAt n [] r₀))
      ((T.tdpEnc E).runAt n (pairEncode (pairFstD (T.tdpGen.runAt n [] r₀)) [b]) s₀) = _
  rw [TrapdoorCollection.tdpGen_runAt]
"""
new_read = """  rw [BitPublicKeyScheme.pkEncDist_eq]
"""+old_read
assert trapdoor.count(old_read)==1
trapdoor = trapdoor.replace(old_read,new_read,1)
predictor = (cut(support,predictor_start,old_average_header)
             + '/-! ## Averages -/\n\n' + support[average_start:support.index(namespace_end)])
machine = cut(support,machine_start,hybrid_start)+support[singleton_start:average_start]
hybrid = cut(support,hybrid_start,predictor_start)
content = {
    destination/'HybridMachine.lean': module([base_module+'Asymptotic.BlockEncryptor'],
        machine_doc,machine,'open Complexity Turing',True),
    destination/'Hybrid.lean': module([destination_module+'HybridMachine'],
        hybrid_doc,hybrid,'open Complexity Turing',True),
    destination/'EnsembleSecurity.lean': module([base_module+'Asymptotic.EnsemblesLemmas',
        destination_module+'Scheme',destination_module+'Hybrid'],ensemble_doc,ensemble,
        'open Complexity Turing Finset',True),
    lemmas: module([destination_module+'Hybrid'],predictor_doc,predictor,'open Complexity Turing'),
    legacy: module([base_module+'Asymptotic.HardCore',base_module+'Asymptotic.Ensembles',
        base_module+'Pseudorandom.GeneratorFromPermutation',base_module+'Asymptotic.PublicKeyLemmas',
        destination_module+'EnsembleSecurity'],trapdoor_doc,trapdoor,'open Complexity Turing Finset'),
}
index=facade.read_text().replace('import '+destination_module+'Scheme\n',
    ''.join('import '+destination_module+n+'\n' for n in ('Scheme','HybridMachine','Hybrid','EnsembleSecurity')),1)
old_contents = """* `Asymptotic.PublicKey` develops trapdoor bit encryption and the ensemble hybrid
  arguments [PS10, §3.10].
"""
new_contents = """* `HybridMachine` builds the public-key hybrid reduction and its coin split.
* `Hybrid` proves the shared-key bound on tuples of encryptions.
* `EnsembleSecurity` gives the games, bitwise construction and fixed-vector security theorem.
* `Asymptotic.PublicKey` develops trapdoor bit encryption [PS10, §3.10].
"""
assert index.count(old_contents)==1
content[facade]=index.replace(old_contents,new_contents,1)
for path, text in content.items():
    path.write_text(text)
