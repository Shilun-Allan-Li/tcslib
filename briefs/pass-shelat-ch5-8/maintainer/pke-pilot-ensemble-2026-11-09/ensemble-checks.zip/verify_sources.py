"""Check the six-source diff and record exact old-to-new source-line mappings."""
from collections import Counter
from difflib import SequenceMatcher
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys

area=Path(sys.argv[1]).resolve()
native=area/sys.argv[2]
plan=json.loads((native/'PLAN.json').read_bytes())
prefix='TCSlib/Cryptography/'
legacy=prefix+'Asymptotic/PublicKey.lean'
support=prefix+'Asymptotic/PublicKeyLemmas.lean'
entry=prefix+'Encryption/PublicKey.lean'
ensemble,hybrid,machine=[entry[:-5]+'/'+s+'.lean' for s in ('EnsembleSecurity','Hybrid','HybridMachine')]
old={p:(area/'lint/base'/p).read_text() for p in (legacy,support,entry)}
new={p:(area/'lint/head'/p).read_text() for p in (legacy,support,entry,ensemble,hybrid,machine)}
for p,text in old.items():
    assert text.encode()==subprocess.check_output(['git','show',plan['base']+':'+p],cwd=plan['worktree'])
for p,text in new.items():
    assert sha256(text.encode()).hexdigest()==plan['source_digests'][p[:-5]]

start_ensemble='/-! ## Ensemble security [PS10, Definition 102.2] -/'
start_trapdoor='/-! ## Algorithm 104.3:'
start_machine='/-! ## Coin blocks -/'
start_hybrid='/-! ## The shared-parameter hybrid bound (concrete) -/'
start_predictor='/-! ## The predictor machine of Theorem 104.4 -/'
namespace_end='end TCSlib.Cryptography'
old_average='/-! ## Averages and one-letter strings -/'
new_average='/-! ## Averages -/'

def before_theorem(text, name):
    return text.rfind('/--', 0, text.index('theorem '+name+' '))

def start(text, marker):
    return marker if isinstance(marker,int) else text.index(marker)

def region(text,a,b):
    i,j=(start(text,k) for k in (a,b))
    assert i < j
    return text[i:j].strip().splitlines(), text[:i].count('\n')+1

mapping={}
additions={}
segments=[]

def same(old_path,old_a,old_b,new_path,new_a,new_b,added=None):
    b,ib=region(old[old_path],old_a,old_b)
    a,ia=region(new[new_path],new_a,new_b)
    matcher=SequenceMatcher(None,b,a,autojunk=False)
    changes=[(tag,b[i:j],a[k:l]) for tag,i,j,k,l in matcher.get_opcodes() if tag!='equal']
    if added:
        assert len(changes)==1 and changes[0][:2]==('insert',[]),changes
        assert [l for l in changes[0][2] if l]==[l for l in added if l],changes
        assert len(changes[0][2])==len(added),changes
        additions[new_path]=added
    else:
        assert not changes,(old_path,new_path,changes)
    lines=mapping.setdefault(new_path,{})
    for i,j,n in matcher.get_matching_blocks():
        for offset in range(n):
            dest=ia+j+offset
            assert dest not in lines
            lines[dest]=[old_path,ib+i+offset]
    segments.append({'base_path':old_path,'head_path':new_path,'base_start':ib,'head_start':ia,
                     'base_lines':len(b),'head_lines':len(a),'inserted_lines':len(a)-len(b)})

reader="""/-- The single-bit sampler returns the public key and the encryption of `[b]`
on the supplied key-generation and encryption coins. -/
theorem pkEncDist_eq (S : BitPublicKeyScheme) (n : ℕ) (b : Bool)
    (r : S.gen.Coins n × S.enc.Coins n) :
    S.pkEncDist n b r = pairEncode (pairFstD (S.gen.runAt n [] r.1))
      (S.enc.runAt n (pairEncode (pairFstD (S.gen.runAt n [] r.1)) [b]) r.2) := rfl

"""
same(legacy,start_ensemble,start_trapdoor,ensemble,start_ensemble,namespace_end,reader.splitlines())
same(legacy,start_trapdoor,namespace_end,legacy,start_trapdoor,namespace_end,
     ['  rw [BitPublicKeyScheme.pkEncDist_eq]'])
old_singleton=before_theorem(old[support],'ofFn_fin_one')
new_singleton=before_theorem(new[machine],'ofFn_fin_one')
same(support,start_machine,start_hybrid,machine,start_machine,new_singleton)
same(support,old_singleton,before_theorem(old[support],'uexp_half_add'),machine,new_singleton,namespace_end)
same(support,start_hybrid,start_predictor,hybrid,start_hybrid,namespace_end)
same(support,start_predictor,old_average,support,start_predictor,new_average)
same(support,before_theorem(old[support],'uexp_half_add'),namespace_end,support,
     before_theorem(new[support],'uexp_half_add'),namespace_end)

def inherited_warnings(log):
    text=(area/log).read_text()
    assert 'style_lint: 0 FAIL' in text
    names=[]
    for line in text.splitlines():
        if line.startswith('WARN '):
            if '1023 lines > 1000' in line:
                assert 'Asymptotic/PublicKey.lean' in line and log=='style-campaign-base.log'
                continue
            match=re.search(r'lemma beside them \(check 8\): (.*)',line)
            assert match,line
            names.extend(match[1].split(', '))
    return Counter(names)

a,b=inherited_warnings('style-campaign-base.log'),inherited_warnings('style-campaign-final.log')
assert not b-a
assert '0 findings in 6 files' in (area/'style-final.log').read_text()
with (area/'SOURCE-MAP.json').open('x') as f:
    json.dump({'base':plan['base'],'head':plan['head'],'segments':segments,'lines':mapping,
               'additions':additions,'reported_reader_warnings':dict(b)},f,ensure_ascii=False,indent=2)
    f.write('\n')
print(sum(len(m) for m in mapping.values()),'exact lines mapped;',len(segments),'source regions; one reader and one rewrite')
