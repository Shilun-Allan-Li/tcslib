"""Seal newly foreign definitions in isolation from the inherited read debt."""
import importlib.util
import json
from pathlib import Path
import sys

workspace=Path.cwd()
area=Path(sys.argv[1]).resolve()
previous=area.parent/'gate06-combined-20261108'
tools=previous/'rule10-evidence-r2/tool-inputs'


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod


def read(path):
    return json.loads(path.read_bytes())


def write(path,data):
    with path.open('x') as stream:
        json.dump(data,stream,ensure_ascii=False,indent=2)
        stream.write('\n')


bs=load(tools/'build_seals.py','reviewed_seals')
controls=load(tools/'build_controls.py','reviewed_controls')
adapter=load(tools/'request_payload_adapter.py','reviewed_adapter')
bound=load(previous/'rule10-payload-retry-r3/bound_payload.py','reviewed_payload_bound')
adapter.configure_builders(bs,controls)
seal=bs.seal_command
bs.seal_command=lambda label,rows,*,end: bound.bound_payloads(seal(label,rows,end=end))
full=area/'seals'
manifest=read(full/'MANIFEST.json')
plan=read(Path(manifest['native_plan']))
root=Path(plan['worktree'])
prefix='TCSlib.Cryptography.Encryption.PublicKey.'
trapdoor,predictor=(prefix+m for m in ('Trapdoor','TrapdoorPredictor'))
by_owner={r['owner']:r for r in manifest['probes']}
targets=[
    ('CleanupSealMovedChecks','audits.pass-shelat.Checks','TCSlib.Cryptography.Composability.PublicKey',
     {trapdoor,predictor}),
]
out=area/'seals-moved'
out.mkdir()
probes=[]
for ordinal,(label,owner,mask_owner,homes) in enumerate(targets,1):
    source_entry=by_owner[mask_owner]
    meta=read(full/(source_entry['label']+'.json'))
    mask=[r for r in meta['requested'] if r['home'] in homes]
    assert mask and {r['home'] for r in mask}==homes,(label,homes)
    path=owner.replace('.','/')+'.lean'
    raw=(root/path).read_bytes()
    assert bs.sha(raw)==plan['source_digests'][path[:-5]]
    seen,pending=set(),[path[:-5]]
    while pending:
        p=pending.pop()
        if p not in seen:
            seen.add(p)
            pending.extend(plan['graph'][p])
    assert all(h.replace('.','/') in seen-{path[:-5]} for h in homes)
    probe,insertions,lines=bs.instrument(raw,bs.header(raw),label,mask)
    target=out/(label+'.lean')
    target.write_bytes(probe)
    row={'label':label,'owner':owner,'path':path,'source_sha256':bs.sha(raw),'probe_sha256':bs.sha(probe)}
    write(out/(label+'.json'),{**row,'requested':mask,'insertions':insertions,'line_map':lines})
    probes.append({**row,'ordinal':ordinal,'requested':len(mask),
                   'module':target.relative_to(workspace).with_suffix('').as_posix()})
write(out/'MANIFEST.json',{**manifest,'probes':probes})
for row in probes:
    print(row['owner'],row['requested'],'focused definitions')
