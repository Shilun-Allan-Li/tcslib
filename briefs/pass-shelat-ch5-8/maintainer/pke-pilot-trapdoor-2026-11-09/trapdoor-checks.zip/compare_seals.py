"""Check the relocated mask coverage and translate the inherited proof diagnostics."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import sys

area,oracle,ensemble,campaign=(Path(s).resolve() for s in sys.argv[1:5])


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


plan=read(area/'native-final/PLAN.json')
decl=read(area/'DECLARATIONS.json')
source=read(area/'SOURCE-CHECK.json')
assert all(r['head']==plan['head'] and r['base']==plan['base'] for r in (decl,source))
prefix='TCSlib.Cryptography.'
legacy=prefix+'Asymptotic.PublicKey'
support=legacy+'Lemmas'
trapdoor=prefix+'Encryption.PublicKey.Trapdoor'
predictor=trapdoor+'Predictor'
origin={trapdoor:legacy,predictor:support}
comp={prefix+'Composability.'+m for m in ('PublicKey','NonMalleable','SimNonMalleable')}
records=campaign/'briefs/pass-shelat-ch5-8/maintainer'
old={}
verified={}
for name,folder,homes in (('oracle',oracle,comp),('ensemble',ensemble,set(origin.values()))):
    receipt=read(records/f'pke-pilot-{name}-2026-11-09'/'VERIFICATION.json')
    assert receipt['passed']
    if name=='oracle':
        assert receipt['head']==plan['baseline']
    for p in ('SEALS.json','READS.json','read-scan/scan.log'):
        assert receipt['artifact_sha256'][p]==sha(folder/p)
        verified[name+'/'+p]=sha(folder/p)
    for r in read(folder/'SEALS.json')['outcomes']:
        if r['owner'] in homes:
            assert r['owner'] not in old
            old[r['owner']]=(folder,r)

old_source=read(oracle/'native-final/PLAN.json')['source_digests']
current=read(area/'SEALS.json')
assert len(current['outcomes'])==5 and all(r['valid_harness'] for r in current['outcomes'])
assert set(origin)<={r['owner'] for r in current['outcomes']}
renames=decl['private_name_changes']
relocations={r['base_name']['display']:r for r in decl['rehomed']}

def translate(row):
    move=relocations.get(row['spelling'])
    if move is None:
        return row
    assert row['home']==move['base_home']
    home=move['head_home']
    name=move['head_name']
    return {**row,'spelling':name['display'],'name_components':name['components'],'home':home,
            'home_components':[['str',p] for p in home.split('.')]}

def meta(folder,row):
    path=folder/'seals'/(row['label']+'.json')
    assert sha(path)==row['meta_sha256'] and sha(Path(row['log']))==row['log_sha256']
    return read(path)

def clean(text,rename):
    text=re.split(r'(?m)^(?:G06-(?:SEAL|COMPONENT|MASK|CONTROL)|FAIL\(|=== Lean)',text,maxsplit=1)[0].strip()
    if rename:
        for a,b in renames.items():
            text=text.replace(a,b)
    labels={}
    return re.sub(r'\?([mu])\.\d+\b',lambda m:'?'+m[1]+'.'+str(labels.setdefault(m[0],len(labels)+1)),text)

def old_location(path,line):
    move=source['moves'].get(path)
    if move is None:
        return path,line
    offset=line-move['head_start']
    assert 0<=offset<move['lines'],(path,line)
    return move['base_path'],move['base_start']+offset

outcomes={}
scopes=[]
for r in current['outcomes']:
    owner=r['owner']
    folder,previous=old[origin.get(owner,owner)]
    assert previous['valid_harness'] and previous['source_sha256']==old_source[previous['path'][:-5]]
    before,after=meta(folder,previous),meta(area,r)
    retained=[translate(x) for x in before['requested']]
    kept={x['spelling']:x for x in retained if x['home'] in after['closure_homes']}
    if owner not in origin:
        assert len(kept)==len(retained),owner
    actual={x['spelling']:x for x in after['requested']}
    assert actual==kept,(owner,actual.keys()-kept.keys(),kept.keys()-actual.keys())
    a=Counter((previous['path'],err['source_line'],err['column'],clean(err['text'],True)) for err in previous['errors'])
    b=Counter((*old_location(r['path'],err['source_line']),err['column'],clean(err['text'],False)) for err in r['errors'])
    assert a==b,(owner,a-b,b-a)
    for err in r['errors']:
        key=(*old_location(r['path'],err['source_line']),err['column'],clean(err['text'],False))
        assert key not in outcomes
        outcomes[key]=(r,err)
    scopes.append({'owner':owner,'base_owner':previous['owner'],'base_requests':len(retained),
                   'current_requests':len(actual),'inherited_diagnostics':len(r['errors']),
                   'old_log_sha256':previous['log_sha256'],'current_log_sha256':r['log_sha256']})
assert len(outcomes)==5
ledger_only='--ledger-only' in sys.argv
focus=None if ledger_only else read(area/'SEALS-MOVED.json')
if focus is not None:
    r,=focus['outcomes']
    assert r['valid_harness'] and r['rc']==0 and not r['errors'],r
    assert r['path']=='audits/pass-shelat/Checks.lean'

def scan(path,paths):
    return [line for line in path.read_text().splitlines()
            if any(line.startswith(p+':') or line.startswith(p[:-5].replace('/','.')+'\t') for p in paths)]

for folder in (oracle,ensemble):
    assert not scan(folder/'read-scan/scan.log',{r['path'] for p,r in old.values() if p==folder})
assert not scan(area/'read-scan/scan.log',{r['path'] for r in current['outcomes']})
assert '0 findings in 5 files' in (area/'style-final.log').read_text()
assert 'style_lint: 0 FAIL, 2 WARN' in (area/'style-campaign-final.log').read_text()
assert all(x in (area/'style-campaign-base.log').read_text() and x in (area/'style-campaign-final.log').read_text()
           for x in ('(check 8): pkPredictor','(check 8): predCoins'))

roots={r['name']['display']:r for r in read(area/'metadata/Head-compact.json')['roots']}
original=read(ensemble/'READS.json')
moved_paths={m['base_path'] for m in source['moves'].values()}
carry=[]
unchanged=[]
for r in original['carry_forward']:
    path=r['current_owner']
    if path not in moved_paths:
        assert plan['source_digests'][path[:-5]]==r['current_source_sha256']
        unchanged.append(r)
        continue
    key=(path,r['current_line'],r['column'],clean(r['diagnostic'],True))
    output,err=outcomes.pop(key)
    previous=old[origin[output['owner']]][1]
    assert r['current_log_sha256']==previous['log_sha256']
    mapping=source['moves'][output['path']]
    shift=mapping['head_start']-mapping['base_start']
    assert err['source_line']==r['current_line']+shift
    old_span=r['current_span']
    assert all(mapping['base_start']<=old_span[k]<mapping['base_start']+mapping['lines'] for k in ('start','dstart','end'))
    span={**old_span,**{k:old_span[k]+shift for k in ('start','dstart','end')}}
    exact=[]
    for d in r['current_declarations']:
        name=d['name']['display']
        actual=roots[renames.get(name,name)]
        assert actual['home']==output['owner']
        exact.append({k:actual[k] for k in ('name','home','type_sha256','type_refs','value_refs')})
    providers=[{**p,'current':translate(p['current'])} for p in r['providers']]
    before=(area/'lint/base'/path).read_text().splitlines()[r['current_line']-1]
    after=(area/'lint/head'/output['path']).read_text().splitlines()[err['source_line']-1]
    assert before==after==r['source']
    carry.append({**r,'baseline_path':path,'baseline_line':r['current_line'],'baseline_span':old_span,
                  'baseline_log_sha256':r['current_log_sha256'],'baseline_declarations':r['current_declarations'],
                  'current_owner':output['path'],'current_line':err['source_line'],'current_span':span,
                  'current_log_sha256':output['log_sha256'],'current_source_sha256':output['source_sha256'],
                  'current_declarations':exact,'providers':providers,'diagnostic':key[3]})
assert not outcomes and len(carry)==5 and len(unchanged)==10
if ledger_only:
    print(len(carry),'inherited diagnostics match all scoped source steps')
    sys.exit(0)
result={'base':plan['base'],'head':plan['head'],'passed':True,'whole_file_seals':len(scopes),
        'requests':sum(s['current_requests'] for s in scopes),'focused_checks':focus['outcomes'],
        'explicit_or_generated_reads':0,'relocated_inherited':carry,'unchanged_prior_rows':unchanged,
        'scopes':scopes,'verified_predecessor_inputs':verified}
with (area/'READS.json').open('x') as f:
    json.dump(result,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(len(carry),'matched inherited diagnostics;',len(unchanged),'earlier rows unchanged; focused Checks seal passed')
