"""Generate the trapdoor PR description and D-0 records from completed verification."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

area=Path(sys.argv[1]).resolve()
mode=sys.argv[2]

def read(rel):
    return json.loads((area/rel).read_bytes())

def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()

native,source,decl,reads=map(read,('native-final/RESULT.json','SOURCE-CHECK.json','DECLARATIONS.json','READS.json'))
base,head=native['base'],native['head']
assert all(r['base']==base and r['head']==head for r in (source,decl,reads))
assert native['passed'] and reads['passed'] and decl['new_declarations']==0
fresh=native['fresh_native_checks']
retained=native['initial_retained']
moves=len(decl['rehomed'])
n=decl['count']
private=len(decl['private_name_changes'])
full=reads['whole_file_seals']
debt=len(reads['relocated_inherited'])
carry=len(reads['unchanged_prior_rows'])
repo='https://github.com/Shilun-Allan-Li/tcslib'
plan_doc='briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md'
review='pke-pilot-trapdoor-2026-11-09'
review_doc=f'briefs/pass-shelat-ch5-8/maintainer/{review}/README.md'
if mode=='pr':
    (area/'pr-body.md').write_text(f"""## Public-key encryption pilot

Move Algorithm 104.3, its correctness and single-bit security proofs, and
both Goldreich–Levin bridge theorems into `Trapdoor`. Move the reduction
machine and its probability identity into `TrapdoorPredictor`.
Both declaration bodies move verbatim, including the existing predictor
simp rule. The two legacy imports re-export their previous declarations.

The bridge keeps its encoding-width premise. The padded CPA corollary
sits in the oracle adapter and uses the existing pending CPA bridge.

## Verification

- All {fresh} affected modules compile, including the library root and campaign
  Checks. The replay verifies {retained:,} retained objects.
- The new and both legacy imports pass standalone probes. The census
  matches all {n} declarations and maps {moves} to their new owners,
  accounting for {private} private names scoped to the moved files.
- {full} whole-file seals and the focused Checks seal cover the new owners
  and consumers. All {debt} diagnostics match the accepted ledger.
  The explicit tactic and generated-equation scans find zero scoped reads.
- Plain style lint has zero findings. Campaign lint retains the two
  inherited reader warnings.

Base `{base}`. Checked head `{head}`.

[Approved pilot map]({repo}/blob/{base}/{plan_doc})
""")
elif mode=='records':
    m=Path(sys.argv[3])
    pr=read('pr-live.json')
    assert pr['headRefOid']==head and pr['baseRefName']=='cryptography/pass-shelat-ch2-4'
    assert pr['state']=='OPEN' and not pr['isDraft'] and pr['mergeable']=='MERGEABLE'
    assert re.fullmatch(re.escape(repo)+r'/pull/\d+',pr['url'])
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=m,text=True).strip()==base
    assert {x['path'] for x in pr['files']}=={p+'.lean' for p in (
        'TCSlib/Cryptography/Asymptotic/PublicKey','TCSlib/Cryptography/Asymptotic/PublicKeyLemmas',
        'TCSlib/Cryptography/Encryption/PublicKey','TCSlib/Cryptography/Encryption/PublicKey/Trapdoor',
        'TCSlib/Cryptography/Encryption/PublicKey/TrapdoorPredictor')}
    number,url=pr['number'],pr['url']
    stage=area/'records'
    evidence=stage/'evidence'
    evidence.mkdir(parents=True)
    archive=area/'trapdoor-checks.zip'
    digest=sha(archive)
    for f in (archive.name,'pr-live.json'):
        shutil.copyfile(area/f,evidence/f)
    files=['native-final/'+p for p in ('PLAN.json','PRODUCTS.json','RESULT.json')]
    files+=['SOURCE-CHECK.json','DECLARATIONS.json','SEALS.json','SEALS-MOVED.json','READS.json',
            'read-scan/scan.log','pr-live.json']
    payload={'base':base,'head':head,'passed':True,'pr':number,'pr_url':url,
        'native':{'fresh':fresh,'retained':retained,'total':fresh+retained},
        'declarations':{'count':n,'rehomed':moves,'private_name_changes':private,'new':0,
                        'inherited_sorry_dependencies':len(decl['inherited_sorry_dependencies'])},
        'seals':{'whole_file':full,'focused':len(reads['focused_checks']),'requests':reads['requests'],
                 'relocated_inherited':debt,'earlier_rows_unchanged':carry,'new_diagnostics':0,
                 'verified_retained_controls':decl['reused_sensitivity_controls']},
        'artifact_sha256':{f:sha(area/f) for f in files},
        'archive':{'name':archive.name,'sha256':digest,'bytes':archive.stat().st_size}}
    (evidence/'VERIFICATION.json').write_text(json.dumps(payload,indent=2)+'\n')
    counts=Counter(Path(r['current_owner']).name for r in reads['relocated_inherited'])
    rows=''.join(f'| `{f}` | {count} |\n' for f,count in sorted(counts.items()))
    (evidence/'README.md').write_text(f"""# Trapdoor bit encryption and the Goldreich–Levin bridge

Seyoon merged the [oracle security move #259]({repo}/pull/259) at `{base}`.
[PR #{number}]({url}) implements the next slice of the
[approved PKE pilot](../cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
at `{head}`.

`Trapdoor` owns the predicate evaluator, Algorithm 104.3, its correctness
and security proof, and the two Goldreich–Levin bridge theorems. The bridge
keeps the encoding-width premise. `TrapdoorPredictor` owns the reduction
machine, its coin split and its prediction identity. Both legacy imports
re-export their original interfaces. The padded CPA corollary belongs to
the oracle adapter and uses the pending `SingleBitSecure.padded_cpa` bridge.

- All {fresh} affected modules pass, including the library root and campaign
  Checks. The replay verifies {retained:,} retained objects. The Checks object
  and output match the pinned #259 baseline.
- The new and both legacy imports pass standalone probes, including a
  check of the existing `tdpPredictor_coins` simp rule. The new construction
  imports the ensemble interface independently of the oracle games.
- The census matches all {n} declarations. It maps {moves} to new homes and
  accounts for {private} private names and compiler-generated binder labels.
  Type and definition terms, reference sets, and axiom dependencies match.
- The {full} whole-file seals apply {reads['requests']:,} requests. The focused
  Checks seal passes. The explicit tactic and generated-equation scans
  find zero scoped reads. The thirteen sensitivity controls transfer
  through identical checked closures, and the equation collector reruns
  both its controls.
- Plain style lint reports zero findings. Campaign lint retains the two
  inherited reader warnings for `pkPredictor` and `predCoins`.

| Current file | Inherited diagnostics |
|---|---:|
{rows}
`READS.json` maps the {debt} inherited source steps and preserves the {carry}
earlier ensemble rows. `VERIFICATION.json` pins the checked evidence.
`trapdoor-checks.zip` has SHA-256 `{digest}`.

**Clear to merge — the trapdoor relocation and compatibility imports pass.**
""")
    handoff=m/'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md'
    lines=handoff.read_text().splitlines(keepends=True)
    i,=(i for i,l in enumerate(lines) if l.startswith('| Cleanup and reorganization | '))
    pre,marker,_=lines[i].partition('[Oracle security PR #259]')
    assert marker
    lines[i]=pre+f"""Seyoon merged the [oracle security move #259]({repo}/pull/259) at `{base}`. [Trapdoor relocation PR #{number}]({url}) at `{head}` is clear for Seyoon to merge. The construction, predictor and Goldreich–Levin bridge have their new homes. Both legacy imports pass. The ledger maps the five inherited diagnostics and preserves the earlier ensemble rows. See the [relocation review](maintainer/{review}/README.md) and [pilot map](maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md). Resume the next move after this slice lands. Efficiency still needs the recorded issue-time probes. |
"""
    (stage/'MAINTAINER-HANDOFF.md').write_text(''.join(lines))
    log=(m/'PassShelatChapter5-8Plan.md').read_text()
    assert log.endswith('\n') and '#258 merged and the PKE oracle security move verified' in log.splitlines()[-1]
    row=f"""| 2026-11-09 (PST) | **#259 merged and the trapdoor PKE move verified.** Seyoon merged #259 at `{base}`. [PR #{number}]({url}) at `{head}` moves Algorithm 104.3, its predictor and security proof, and the Goldreich–Levin bridge. The legacy imports re-export their interfaces. All {fresh} affected modules and the focused Checks seal pass. The census matches {n} declarations and maps {moves} new homes. The {debt} inherited diagnostics map to their current steps. [Verification and ledger]({review_doc}). Seyoon merges this slice before the next move. | record |
"""
    (stage/'PassShelatChapter5-8Plan.md').write_text(log+row)
    print(review,digest)
else:
    raise ValueError(mode)
