## Public-key encryption pilot

Move Algorithm 104.3, its correctness and single-bit security proofs, and
both Goldreich–Levin bridge theorems into `Trapdoor`. Move the reduction
machine and its probability identity into `TrapdoorPredictor`.
Both declaration bodies move verbatim, including the existing predictor
simp rule. The two legacy imports re-export their previous declarations.

The bridge keeps its encoding-width premise. The padded CPA corollary
sits in the oracle adapter and uses the existing pending CPA bridge.

## Verification

- All 12 affected modules compile, including the library root and campaign
  Checks. The replay verifies 1,071 retained objects.
- The new and both legacy imports pass standalone probes. The census
  matches all 182 declarations and maps 74 to their new owners,
  accounting for 6 private names scoped to the moved files.
- 5 whole-file seals and the focused Checks seal cover the new owners
  and consumers. All 5 diagnostics match the accepted ledger.
  The explicit tactic and generated-equation scans find zero scoped reads.
- Plain style lint has zero findings. Campaign lint retains the two
  inherited reader warnings.

Base `b1743e78750bdb9e93f0d3f5b95af60b2f7fa9fa`. Checked head `31401c7192d0e0fab716805527c1e232f82736d4`.

[Approved pilot map](https://github.com/Shilun-Allan-Li/tcslib/blob/b1743e78750bdb9e93f0d3f5b95af60b2f7fa9fa/briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
