"""Move the construction and its predictor without changing any declarations."""
from pathlib import Path
import sys

crypto=Path(sys.argv[1])/'TCSlib/Cryptography'
legacy=crypto/'Asymptotic/PublicKey.lean'
support=crypto/'Asymptotic/PublicKeyLemmas.lean'
facade=crypto/'Encryption/PublicKey.lean'
folder=crypto/'Encryption/PublicKey'
base=legacy.read_text()
proof=support.read_text()
prefix='TCSlib.Cryptography.'
pk=prefix+'Encryption.PublicKey.'
copyright=base[:base.index('import ')]
options=base[base.index('set_option'):base.index('/-!\n#')]
reference='''* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Algorithm 104.3 and Theorem 104.4.)'''


def replace_once(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new,1)


def shim(imports, title, definitions, results):
    header=''.join('import '+name+'\n' for name in imports)
    return copyright+header+'\n'+options+f'''/-!
# {title}

## Main definitions

{definitions}

## Main results

{results}

## References

{reference}
-/
'''


trapdoor=replace_once(base,
    '''import TCSlib.Cryptography.Asymptotic.HardCore
import TCSlib.Cryptography.Asymptotic.Ensembles
import TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation
import TCSlib.Cryptography.Asymptotic.PublicKeyLemmas
import TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity
''','''import TCSlib.Cryptography.Asymptotic.HardCoreCollection
import TCSlib.Cryptography.Asymptotic.Sampling
import TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity
import TCSlib.Cryptography.Encryption.PublicKey.TrapdoorPredictor
import TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation
''')
trapdoor=replace_once(trapdoor,
    '''This module builds the trapdoor construction of Algorithm 104.3.
It imports the scheme interfaces and ensemble security results through
`TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity` for existing callers.
''','''This module builds the trapdoor construction of Algorithm 104.3. The predictor
machine for the security reduction is in `TrapdoorPredictor`. The Goldreich–Levin
bridge supplies the hard-core predicate under the encoding-width premise.
''')
predictor=replace_once(proof,'import '+pk+'Hybrid','''import TCSlib.Complexity.Randomized.Closure
import TCSlib.Complexity.Randomized.Repetition
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.OneWayFunctions.Basic
import Mathlib.Logic.Equiv.Fin.Basic''')
predictor=replace_once(predictor,
    '''This module develops the predictor used for the security of Algorithm 104.3.
It also imports the ensemble hybrid support for callers of the original
`Asymptotic.PublicKeyLemmas` module.
''','''This module develops the predictor used for the security of Algorithm 104.3.
It gives the predictor's polynomial-time machine, coin split and probability identity.
''')

(folder/'Trapdoor.lean').write_text(trapdoor)
(folder/'TrapdoorPredictor.lean').write_text(predictor)
legacy.write_text(shim([prefix+'Asymptotic.HardCore',prefix+'Asymptotic.Ensembles',
    prefix+'Asymptotic.PublicKeyLemmas',pk+'Trapdoor'],
    'Public-key encryption compatibility import',
    '`TCSlib.Cryptography.Encryption.PublicKey.Trapdoor` provides the trapdoor bit scheme.\n'
    'Its ensemble interface also exposes the general public-key schemes.',
    'This import exposes the trapdoor security theorems and their Goldreich–Levin bridge.'))
support.write_text(shim([pk+'Hybrid',pk+'TrapdoorPredictor'],
    'Public-key proof support compatibility import',
    '`Hybrid` and `TrapdoorPredictor` provide the hybrid and predictor machines.',
    'This import exposes the shared-key hybrid bound and the trapdoor prediction identity.'))

text=replace_once(facade.read_text(),'import '+prefix+'Asymptotic.PublicKey\n','')
text=replace_once(text,'import '+pk+'EnsembleSecurity\n',
    ''.join('import '+pk+name+'\n' for name in ('EnsembleSecurity','TrapdoorPredictor','Trapdoor')))
text=replace_once(text,'* `Asymptotic.PublicKey` develops trapdoor bit encryption [PS10, §3.10].',
    '''* `TrapdoorPredictor` builds the machine used to predict the hard-core bit.
* `Trapdoor` proves correctness and single-bit security of Algorithm 104.3 and gives
  the Goldreich–Levin bridge [PS10, §3.10].''')
facade.write_text(text)
