"""basecheck.py <state-checked.json> <state-init-at-new-base.json> <order.txt> <out>: (olean rebase) the state a future
job gets from `stateplan.py init <repo> <new-base> <new-snapshot>` must agree, module by module, with the checked state of
this rebase (same closure key at the new base and same olean hash; only the `rev` field may differ, because reused oleans
keep their build rev). Also: the init state's modules are exactly the order's modules."""
import sys, json
a, b, order, out = sys.argv[1:5]
A = json.load(open(a)); B = json.load(open(b)); O = [l.strip() for l in open(order) if l.strip()]
bad = [m for m in O if m not in A or m not in B or A[m]['key'] != B[m]['key'] or A[m]['olean'] != B[m]['olean']]
extraB = sorted(set(B) - set(O)); missB = sorted(set(O) - set(B))
revs = {}
for m in O:
    if m in A: revs[A[m]['rev'][:8]] = revs.get(A[m]['rev'][:8], 0) + 1
with open(out, 'w') as o:
    o.write(f'order {len(O)}; checked state {len(A)}; init state {len(B)}\n')
    o.write(f'checked-state build revs over the order: {revs}\n')
    o.write(f'init modules not in order {len(extraB)} {extraB[:10]}; order modules not in init {len(missB)} {missB[:10]}\n')
    o.write(f'key/olean disagreements {len(bad)} {bad[:10]}\n')
    o.write('RESULT ' + ('OK' if not bad and not extraB and not missB else 'FAIL') + '\n')
print(open(out).read())
