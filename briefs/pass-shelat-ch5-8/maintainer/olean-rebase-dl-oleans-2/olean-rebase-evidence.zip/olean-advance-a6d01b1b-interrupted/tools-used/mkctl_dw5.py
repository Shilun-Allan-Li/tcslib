"""mkctl_dw5.py (DW-5, derand F-01 typed-view readers): mkctl_derand.py (derand review) with the harness unchanged
(assemble, the covering-subset choice of seal records, the plan format) and the rows B replaced by: PolyExpr.eval (B
only) and the ModuleHost.hostTM / hostTM_k row, both kept from mkctl_derand.py verbatim; and one row per new reader,
each negative the rfl/definitional transport through the sealed definition and each positive the published reader:
Turing.ModuleHost.hostTM -> hostTMView_eq, hostTMView_q₀, hostTMView_step_inl, host_call_view, host_clean_view;
Complexity.IterateFind.copyTM -> copyTMView_eq, copy_clean_view. The step/call/clean/copier negatives state the
reader's own type (`type_of%`) and prove it by the original contract, which type-checks only by unfolding the sealed
host or copier. Namespace DW5Controls. Previous header (mkctl_derand.py) follows.
"""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
HB = "{C : Type} [Fintype C] [DecidableEq C] {n : ℕ} (M : Fin n → Turing.FinTM Bool) (K : ℕ)\n    (hk : ∀ i, (M i).k ≤ K)\n    (ctrl : C → Option Bool → (Fin K → Option Bool) → Turing.Action K Bool (Turing.ModuleHost.State C M))\n    (ret : Fin n → Turing.ModuleHost.State C M) (q₀ : Turing.ModuleHost.State C M)"
HA = "M K hk ctrl ret q₀"
STEPB = HB + " {x : List Bool}\n    (cfg : Turing.Cfg K Bool (Turing.ModuleHost.State C M) x) (c : C) (hc : cfg.state = some (.inl c))"
STEPA = HA + " cfg c hc"
CALLB = (HB + "\n    (i : Fin n) (hp : 0 < (M i).k) (x arg result out pre : List Bool) (q : (M i).State) (t : ℕ)\n"
  "    (hg : ∀ v < t, ¬((M i).tm.runFrom\n      (Turing.Cfg.ofWords (input := x) (M i).tm.q₀ (Turing.stateWord (M i).k arg)) v).Halted)\n"
  "    (he : (M i).tm.runFrom\n      (Turing.Cfg.ofWords (input := x) (M i).tm.q₀ (Turing.stateWord (M i).k arg)) t =\n"
  "      {Turing.Cfg.ofWords q (Turing.stateWord (M i).k result) with state := none, output := out})")
CALLA = HA + " i hp x arg result out pre q t hg he"
CLEANB = HB + "\n    (i : Fin n) (f g : List Bool → List Bool) (B : ℕ → ℕ) (h : Turing.ModuleHost.Clean (M i) f g B)\n    (x arg pre : List Bool)"
CLEANA = HA + " i f g B h x arg pre"
MH = "Turing.ModuleHost."
IF = "Complexity.IterateFind."
B = {
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 'Turing.ModuleHost.hostTM':
   row("ctlHostK",
   "theorem ctlHostK {C : Type} [Fintype C] [DecidableEq C] {n : ℕ} (M : Fin n → Turing.FinTM Bool) (K : ℕ)\n    (hk : ∀ i, (M i).k ≤ K)\n    (ctrl : C → Option Bool → (Fin K → Option Bool) → Turing.Action K Bool (Turing.ModuleHost.State C M))\n    (ret : Fin n → Turing.ModuleHost.State C M) (q₀ : Turing.ModuleHost.State C M) :\n    (Turing.ModuleHost.hostTM M K hk ctrl ret q₀).k = K := rfl\n",
   "theorem ctlHostKReader {C : Type} [Fintype C] [DecidableEq C] {n : ℕ} (M : Fin n → Turing.FinTM Bool) (K : ℕ)\n    (hk : ∀ i, (M i).k ≤ K)\n    (ctrl : C → Option Bool → (Fin K → Option Bool) → Turing.Action K Bool (Turing.ModuleHost.State C M))\n    (ret : Fin n → Turing.ModuleHost.State C M) (q₀ : Turing.ModuleHost.State C M) :\n    (Turing.ModuleHost.hostTM M K hk ctrl ret q₀).k = K := by\n  rw [Turing.ModuleHost.hostTM_k]\n")
 + row("ctlHostView",
   f"theorem ctlHostView {HB} :\n    {MH}hostTMView {HA} = {MH}hostTM {HA} := rfl\n",
   f"theorem ctlHostViewReader {HB} :\n    {MH}hostTMView {HA} = {MH}hostTM {HA} :=\n  {MH}hostTMView_eq {HA}\n")
 + row("ctlHostViewQ",
   f"theorem ctlHostViewQ {HB} :\n    ({MH}hostTMView {HA}).tm.q₀ = q₀ := rfl\n",
   f"theorem ctlHostViewQReader {HB} :\n    ({MH}hostTMView {HA}).tm.q₀ = q₀ :=\n  {MH}hostTMView_q₀ {HA}\n")
 + row("ctlHostStep",
   f"theorem ctlHostStep {STEPB} :\n    type_of% ({MH}hostTMView_step_inl {STEPA}) :=\n  {MH}hostTM_step_inl {STEPA}\n",
   f"theorem ctlHostStepReader {STEPB} :\n    type_of% ({MH}hostTMView_step_inl {STEPA}) :=\n  {MH}hostTMView_step_inl {STEPA}\n")
 + row("ctlHostCall",
   f"theorem ctlHostCall {CALLB} :\n    type_of% ({MH}host_call_view {CALLA}) :=\n  {MH}host_call {CALLA}\n",
   f"theorem ctlHostCallReader {CALLB} :\n    type_of% ({MH}host_call_view {CALLA}) :=\n  {MH}host_call_view {CALLA}\n")
 + row("ctlHostClean",
   f"theorem ctlHostClean {CLEANB} :\n    type_of% ({MH}host_clean_view {CLEANA}) :=\n  {MH}host_clean {CLEANA}\n",
   f"theorem ctlHostCleanReader {CLEANB} :\n    type_of% ({MH}host_clean_view {CLEANA}) :=\n  {MH}host_clean_view {CLEANA}\n"),
 'Complexity.IterateFind.copyTM':
   row("ctlCopyView",
   f"theorem ctlCopyView : {IF}copyTMView = {IF}copyTM := rfl\n",
   f"theorem ctlCopyViewReader : {IF}copyTMView = {IF}copyTM :=\n  {IF}copyTMView_eq\n")
 + row("ctlCopyClean",
   f"theorem ctlCopyClean (x : List Bool) :\n    type_of% ({IF}copy_clean_view x) :=\n  {IF}copy_clean x\n",
   f"theorem ctlCopyCleanReader (x : List Bool) :\n    type_of% ({IF}copy_clean_view x) :=\n  {IF}copy_clean_view x\n"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace DW5Controls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end DW5Controls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
