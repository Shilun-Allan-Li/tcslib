#!/usr/bin/env bash
# devcheck.sh <tag> <module path> <seal-record.json>... (DW-5 development only): build the working-tree module on
# dl-oleans-2 (runner.py, scripts/lean_check_tree.sh), then run working-tree seal probes (devseal.py) for each record
# through runner_full.py (lean -DmaxErrors=0, no -o) and print each error mapped to its source line.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
E=$SP/dw5; W=$SP/wt-dw5; T=$E/tools-used; G=$T/seal/review/archived-gate10-tools; TREE=$SP/dl-oleans-2
TAG=$1; MOD=$2; shift 2; D=$E/dev/$TAG; mkdir -p $D; export TMPDIR=$E/tmp
echo $MOD > $D/q.txt
python3 -I $T/runner.py $W $D/q.txt $TREE $D/build > /dev/null 2>&1; echo "build rc=$?"
grep -E "error" $D/build/mods/*.log | head -40
: > $D/seal-q.txt
for rec in "$@"; do
  lab=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1]))['label'])" $rec)
  python3 -I $T/devseal.py $G $rec $W/$MOD.lean $W/DW5Dev/$lab.lean $D/$lab.map.json > /dev/null
  echo DW5Dev/$lab >> $D/seal-q.txt
done
python3 -I $T/runner_full.py $W $D/seal-q.txt $TREE $D/seals > /dev/null 2>&1
for rec in "$@"; do
  lab=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1]))['label'])" $rec)
  python3 -I - $D/seals/mods/DW5Dev_$lab.log $D/$lab.map.json $W/$MOD.lean $lab <<'PY'
import sys, re, json
log, mp, src, lab = sys.argv[1:5]
m = json.load(open(mp)); s = open(src, encoding='utf-8').read().split('\n'); t = open(log, encoding='utf-8', errors='replace').read()
errs = list(re.finditer(r'^\S+\.lean:(\d+):(\d+): (error[^\n]*)', t, re.M))
print(f'== {lab}: errors {len(errs)}; install {"G06-SEAL label=" + lab in t}; eof {"G06-SEAL-END label=" + lab in t}')
for e in errs:
    sl = m.get(e.group(1)); print(' ', sl, e.group(2), e.group(3)[:100], '|', s[sl - 1].strip()[:80] if sl else '')
PY
done
