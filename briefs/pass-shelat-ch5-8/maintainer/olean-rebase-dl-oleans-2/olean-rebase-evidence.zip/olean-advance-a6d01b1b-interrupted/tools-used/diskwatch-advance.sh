#!/usr/bin/env bash
# diskwatch-advance.sh (snapshot advance; = diskwatch-rebase.sh with the evidence dir changed): log free space on / every 60 s until
# build/runner.exit exists. Below 1000 MB, pause this job's current lean process (SIGSTOP, its own PID, a child of the
# checker in build/current.pid) and resume it (SIGCONT) once free space is back above 1200 MB. Below 250 MB, stop this
# job's runner (build/runner.pid) and checker, as DW-5's watcher does.
B=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/build; paused=0
while [ ! -s $B/runner.exit ]; do
  f=$(df -B1M / | tail -1 | awk '{print $4}'); echo "$(date -u +%FT%TZ) $f MB free" >> $B/df.log
  cp=$(cut -d' ' -f1 $B/current.pid 2>/dev/null); lp=$(pgrep -P "$cp" -x lean 2>/dev/null)
  if [ "$f" -lt 250 ]; then echo "$(date -u +%FT%TZ) LOW-DISK STOP" >> $B/df.log
    [ -n "$lp" ] && kill -CONT $lp 2>/dev/null; kill $(cat $B/runner.pid) 2>/dev/null; kill $cp 2>/dev/null; kill $lp 2>/dev/null; break; fi
  if [ "$f" -lt 1000 ] && [ -n "$lp" ] && [ $paused = 0 ]; then kill -STOP $lp && paused=$lp && echo "$(date -u +%FT%TZ) PAUSE lean $lp ($f MB)" >> $B/df.log; fi
  if [ $paused != 0 ] && [ "$f" -gt 1200 ]; then kill -CONT $paused; echo "$(date -u +%FT%TZ) RESUME lean $paused ($f MB)" >> $B/df.log; paused=0; fi
  sleep 60
done
echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free (end)" >> $B/df.log
