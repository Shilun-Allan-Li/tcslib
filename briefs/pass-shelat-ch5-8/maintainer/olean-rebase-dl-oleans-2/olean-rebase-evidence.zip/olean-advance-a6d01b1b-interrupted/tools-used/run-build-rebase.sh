#!/usr/bin/env bash
# run-build-rebase.sh (olean rebase of dl-oleans-2; = DW-5's run-build.sh with the worktree and evidence paths changed):
# the incremental build of plan/queue.txt (715 modules: closure-key changes vs the snapshot base eff2dcd0, over the
# closure of root TCSlib and both audits/*/Checks) on dl-oleans-2 through scripts/lean_check_tree.sh (tools-used/runner.py;
# one Lean process; stops at the first failure).
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-rebase2
export PATH=$HOME/.elan/bin:$PATH TMPDIR=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/tmp
echo "start $(date -u +%FT%TZ)" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/build/runner.start
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/tools-used/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-rebase2 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans-2 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/build &
rp=$!; echo $rp > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/build/runner.pid
wait $rp
echo "runner exit $? $(date -u +%FT%TZ)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-rebase-2/build/runner.exit
