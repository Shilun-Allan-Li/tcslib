r"""frozencheck.py <repo> <base-rev> <head-rev|WT:dir> <out> <file>... [--control <file> <decl-name> <rev> [header|body|prose]]

Independent frozen-statement check (prf-long review; written for this review, not derived from the
worker's headers.py). For every declaration of each file at <base-rev> it checks, at the head:
  * the declaration is present in the same file, with the same kind and full name;
  * the base declarations occur in the same relative order;
  * HEADER: the bytes from the first attribute/modifier/keyword of the declaration (preceding
    `omit ... in` lines included) to the first depth-0 `:=`, `where`, or line-leading `|` are identical;
  * PROSE: the doc comment up to `**Proof sketch` (the whole doc comment if there is none) is identical;
  * BODY (def/abbrev/structure/inductive/class/instance/opaque): the whole declaration text (doc comment,
    attributes, header and body, up to the next top-level command, trailing whitespace removed) is identical.
The scanner tracks nested block comments, line comments, string/char literals and bracket depth, and cuts
top-level commands only at column-0 tokens outside comments.
With --control, the head text of <file> at <rev> has one character of <decl-name>'s header changed
(the last character of the header before its terminator, of the whole definition, or of the prose, is
replaced by '#'), and the check is run on that text instead; it must report exactly one difference."""
import sys, re, subprocess

TOP = ('theorem', 'lemma', 'def', 'abbrev', 'structure', 'inductive', 'class', 'instance', 'opaque',
       'axiom', 'private', 'protected', 'noncomputable', 'nonrec', 'partial', 'unsafe', 'omit', 'namespace',
       'end', 'section', 'open', 'variable', 'universe', 'set_option', 'attribute', 'example', 'import',
       'mutual', 'deriving', 'macro', 'syntax', 'notation', 'infix', 'infixl', 'infixr', 'prefix', 'postfix',
       'local', 'scoped', '#', '@[', '/--', '/-!', 'initialize', 'elab', 'termination_by', 'decreasing_by')
KW = ('theorem', 'lemma', 'def', 'abbrev', 'structure', 'inductive', 'class', 'instance', 'opaque', 'axiom')
DEFKINDS = ('def', 'abbrev', 'structure', 'inductive', 'class', 'instance', 'opaque')
MODS = ('private', 'protected', 'noncomputable', 'nonrec', 'partial', 'unsafe')


def show(repo, rev, f):
    if rev.startswith('WT:'):
        return open(rev[3:] + '/' + f, encoding='utf-8').read()
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True)
    if r.returncode:
        return None
    return r.stdout.decode('utf-8')


def code_mask(s):
    """Per character: True if outside comments and literals."""
    n = len(s); m = [True] * n; i = 0; depth = 0
    while i < n:
        if depth == 0 and s.startswith('--', i):
            j = s.find('\n', i); j = n if j < 0 else j
            for k in range(i, j): m[k] = False
            i = j; continue
        if s.startswith('/-', i):
            depth += 1; m[i] = m[i + 1] = False; i += 2; continue
        if depth > 0:
            if s.startswith('-/', i):
                depth -= 1; m[i] = m[i + 1] = False; i += 2; continue
            m[i] = False; i += 1; continue
        if s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            for k in range(i, min(j + 1, n)): m[k] = False
            i = j + 1; continue
        i += 1
    return m


def chunks(s):
    """Split into top-level chunks: (start, end) offsets, cut at column-0 tokens outside comments.
    A doc comment `/--` at column 0 starts a chunk (its start is outside code: it is the comment opener)."""
    m = code_mask(s); starts = [0]; pos = 0
    for line in s.split('\n')[:-1] + [s.split('\n')[-1]]:
        if pos > 0 and line and not line[0].isspace():
            if line.startswith('/--') or line.startswith('/-!'):
                # a comment opener at column 0 is top-level iff the newline before it is outside comments
                if m[pos - 1]:
                    starts.append(pos)
            elif m[pos] and any(line.startswith(t) and (len(line) == len(t) or not (line[len(t)].isalnum() or line[len(t)] in '_.\'')
                                                     or t in ('#', '@[', '/--', '/-!')) for t in TOP):
                starts.append(pos)
        pos += len(line) + 1
    starts.append(len(s))
    return [(starts[i], starts[i + 1]) for i in range(len(starts) - 1)], m


def first_word(t):
    t = t.lstrip()
    mm = re.match(r"[^\s(\[{:]+", t)
    return mm.group(0) if mm else ''


def header_end(s, m, a, b):
    """First depth-0 `:=`, `where` token, or line-leading `|`, scanning code chars in [a, b)."""
    d = 0; i = a; linestart = False
    while i < b:
        c = s[i]
        if not m[i]:
            i += 1; continue
        if c == '\n':
            linestart = True; i += 1; continue
        if linestart and c in ' \t':
            i += 1; continue
        if linestart and c == '|' and d == 0:
            return i
        linestart = False
        if c in '([{⟨⦃': d += 1
        elif c in ')]}⟩⦄': d -= 1
        elif d == 0 and s.startswith(':=', i):
            return i
        elif d == 0 and s.startswith('where', i) and (i == 0 or not (s[i - 1].isalnum() or s[i - 1] == '_')) \
                and (i + 5 >= len(s) or not (s[i + 5].isalnum() or s[i + 5] == '_')):
            return i
        i += 1
    return b


def decls(s):
    cs, m = chunks(s)
    ns = []; out = []; pend_doc = None; pend_omit = []; pend_attr = []
    for a, b in cs:
        t = s[a:b]; w = first_word(t)
        if t.startswith('/--'):
            pend_doc = (a, b); continue
        if w == 'omit':
            pend_omit.append((a, b)); continue
        if t.startswith('@[') and not re.match(r'@\[[^\]]*\]\s*(' + '|'.join(MODS + KW) + r')\b', t, re.S):
            pend_attr.append((a, b)); continue
        if w == 'namespace':
            ns.append(t.split()[1]); pend_doc = None; pend_omit = []; continue
        if w == 'section':
            parts = t.split(); ns.append(('§', parts[1] if len(parts) > 1 and not parts[1].startswith('--') else ''))
            pend_doc = None; continue
        if w == 'end':
            if ns: ns.pop()
            pend_doc = None; continue
        mm = re.match(r'((?:@\[[^\]]*\]\s*)*)((?:(?:' + '|'.join(MODS) + r')\s+)*)(' + '|'.join(KW) + r')\b\s*([^\s(:{\[⦃]*)', t, re.S)
        if mm:
            kind = mm.group(3); name = mm.group(4)
            full = '.'.join([x for x in ns if isinstance(x, str)] + ([name] if name else []))
            if name.startswith('_root_.'): full = name[7:]
            hs = pend_omit[0][0] if pend_omit else (pend_attr[0][0] if pend_attr else a)
            he = header_end(s, m, a, b)
            header = s[hs:a] if pend_omit or pend_attr else ''
            # pending omit/attr text between them and the keyword, minus the doc comment (kept separately)
            if pend_doc and pend_omit and pend_doc[0] > pend_omit[0][0]:
                header = s[pend_omit[0][0]:pend_doc[0]] + s[pend_doc[1]:a]
            header += s[a:he]
            doc = s[pend_doc[0]:pend_doc[1]] if pend_doc else ''
            k = doc.find('**Proof sketch')
            prose = doc[:k] if k >= 0 else doc
            whole = (s[min([x for x in [hs, pend_doc[0] if pend_doc else a] ]):b]).rstrip()
            out.append(dict(kind=kind, name=full, header=header, prose=prose.rstrip(), whole=whole, line=s.count('\n', 0, a) + 1,
                            hdr_span=(a, he)))
        pend_doc = None; pend_omit = []; pend_attr = []
    return out


def compare(base_txt, head_txt):
    B, H = decls(base_txt), decls(head_txt)
    hk = {}
    for i, d in enumerate(H): hk.setdefault((d['kind'], d['name']), []).append(i)
    diffs = []; idx = []
    for d in B:
        key = (d['kind'], d['name'])
        if key not in hk:
            diffs.append(('MISSING', d['name'], d['kind'], d['line'])); continue
        j = hk[key][0]; h = H[j]; idx.append(j)
        if d['header'] != h['header']: diffs.append(('HEADER', d['name'], d['kind'], h['line']))
        if d['prose'] != h['prose']: diffs.append(('PROSE', d['name'], d['kind'], h['line']))
        if d['kind'] in DEFKINDS and d['whole'] != h['whole']: diffs.append(('BODY', d['name'], d['kind'], h['line']))
    order_ok = idx == sorted(idx)
    if not order_ok: diffs.append(('ORDER', '-', '-', 0))
    return B, H, diffs


def main():
    a = sys.argv[1:]
    ctl = None
    if '--control' in a:
        k = a.index('--control'); ctl = a[k + 1:k + 5]; a = a[:k]
        if len(ctl) < 4: ctl.append('header')
    repo, base, head, out = a[:4]; files = a[4:]
    tot = 0; lines = []
    for f in files:
        bt = show(repo, base, f); ht = show(repo, head, f)
        if ctl and f == ctl[0]:
            ht = show(repo, ctl[2], f)
            H = decls(ht); tgt = [d for d in H if d['name'] == ctl[1]][0]
            if ctl[3] == 'header':
                p = tgt['hdr_span'][1] - 1
                while ht[p] in ' \n': p -= 1
            elif ctl[3] == 'body':
                p = ht.index(tgt['whole']) + len(tgt['whole']) - 1
            else:
                p = ht.index(tgt['prose']) + len(tgt['prose']) - 1
            ht = ht[:p] + '#' + ht[p + 1:]
            lines.append(f'CONTROL {f}: changed char {p} ({ctl[3]}) of {ctl[1]} to #')
        if bt is None:
            lines.append(f'NEWFILE {f}: {len(decls(ht))} declarations'); continue
        B, H, diffs = compare(bt, ht)
        nb = len(B); nh = len(H)
        lines.append(f'FILE {f}: base {nb} declarations ({sum(d["kind"] in DEFKINDS for d in B)} definition-like), head {nh}; differences {len(diffs)}')
        for d in diffs: lines.append('  DIFF\t' + '\t'.join(map(str, d)))
        tot += len(diffs)
    lines.append(f'RESULT differences {tot}')
    open(out, 'w').write('\n'.join(lines) + '\n'); print('\n'.join(lines))


main()
