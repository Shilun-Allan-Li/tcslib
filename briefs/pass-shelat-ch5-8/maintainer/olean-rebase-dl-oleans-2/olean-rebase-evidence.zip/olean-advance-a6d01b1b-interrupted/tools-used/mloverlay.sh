#!/usr/bin/env bash
# mloverlay.sh <tree>: (derand review) make <tree>/Mathlib a symlink overlay of every .olean of the shared pinned Mathlib
# build (Lean resolves a package by the FIRST search-path entry that holds its root directory, and <tree> is first on
# scripts/lean_check_tree.sh's LEAN_PATH). Nothing is written under /home/user/tcslib. Removed again at restore.
set -u
T=$1; L=/home/user/tcslib/.lake/packages/mathlib/.lake/build/lib/lean
cd $L && find Mathlib -name '*.olean' | while read f; do mkdir -p "$T/$(dirname $f)"; ln -s "$L/$f" "$T/$f"; done
find $T/Mathlib -type l | wc -l
