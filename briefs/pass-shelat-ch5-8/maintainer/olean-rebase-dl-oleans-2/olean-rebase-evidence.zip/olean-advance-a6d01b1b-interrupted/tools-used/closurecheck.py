"""closurecheck.py <repo> <rev> <order.txt> <state.json> <out>: (olean rebase) the full import closure of root TCSlib and
every audits/*/Checks at <rev> (downorder.py's parsing) must be contained in <order.txt>; lists the .lean modules at <rev>
outside the order, and the state's (snapshot) modules outside the order."""
import sys, re, subprocess, json
repo, rev, order, st, out = sys.argv[1:6]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
roots = ['TCSlib'] + sorted(f for f in files if re.fullmatch(r'audits/[^/]+/Checks', f))
seen = set(); todo = list(roots)
while todo:
    m = todo.pop()
    if m in seen: continue
    seen.add(m)
    todo += [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M) if local(i)]
O = [l.strip() for l in open(order) if l.strip()]; S = set(O); state = json.load(open(st))
miss = sorted(seen - S); outside = sorted(set(files) - S); stout = sorted(set(state) - S)
with open(out, 'w') as o:
    o.write(f'roots {roots}\nclosure {len(seen)}; order {len(O)}; closure not in order {len(miss)} {miss}\n')
    o.write(f'order not in closure {len(S - seen)} {sorted(S - seen)}\n')
    o.write(f'.lean modules at {rev[:8]} outside the order: {len(outside)}\n' + ''.join(f'  {m}\n' for m in outside))
    o.write(f'snapshot (state) modules outside the order: {len(stout)} {stout}\n')
print(open(out).read())
