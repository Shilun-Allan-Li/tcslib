#!/usr/bin/env bash
# seals_dev.sh <rev> <outdir> <probe-prefix> <dotted owner>...: (DW-5) development/baseline seal run on dl-oleans-2:
# collector (mkcollect.py over the owners) through runner_full.py, then the four whole-file seals per owner
# (strict mkseals_ab.py / coe mkseals_coe.py, A default, B with SEAL_EVAL=1) through runner_full.py (lean -DmaxErrors=0,
# no -o), then sealsum.py per variant against an empty touched map (whole-file error counts). One Lean process at a time.
set -eu
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
E=$SP/dw5; W=$SP/wt-dw5; T=$E/tools-used/seal; G=$T/review/archived-gate10-tools; TREE=$SP/dl-oleans-2
REV=$1; R=$2; P=$3; shift 3
export TMPDIR=$E/tmp
mkdir -p $R/order $R/probe-sources $W/$P
printf '%s\n' "$@" > $R/order/owners.txt
python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "DW-5 collector" $W/$P/Collect.lean
cp $W/$P/Collect.lean $R/probe-sources/Collect.lean.txt
echo $P/Collect > $R/order/collect.txt
python3 -I $T/runner_full.py $W $R/order/collect.txt $TREE $R/probe-runs > $R/collect-runner.out 2>&1
LOG=$R/probe-runs/mods/${P}_Collect.log
python3 -I $T/review/mkseals_ab.py $G $LOG $W $REV $R/seals/A $P/S SealA_ "$@" > $R/mkseals-A.log
SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $G $LOG $W $REV $R/seals/B $P/S SealB_ "$@" > $R/mkseals-B.log
python3 -I $T/review/mkseals_coe.py $G $LOG $W $REV $R/seals-coe/A $P/C SealA_ "$@" > $R/mkseals-coe-A.log
SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $REV $R/seals-coe/B $P/C SealB_ "$@" > $R/mkseals-coe-B.log
(cd $W && ls $P/C/*.lean $P/S/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
python3 -I $T/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1 || true
echo '{"files": {}}' > $R/touched-empty.json
for v in A B; do
  python3 -I $T/review/sealsum.py $R/seals/$v $R/seal-runs $R/touched-empty.json $R/seals-$v.tsv
  python3 -I $T/review/sealsum.py $R/seals-coe/$v $R/seal-runs $R/touched-empty.json $R/seals-coe-$v.tsv
done
cat $R/mkseals-*.log; for f in $R/seals-A.tsv $R/seals-B.tsv $R/seals-coe-A.tsv $R/seals-coe-B.tsv; do echo "== $f"; cut -f1-6 $f; done
