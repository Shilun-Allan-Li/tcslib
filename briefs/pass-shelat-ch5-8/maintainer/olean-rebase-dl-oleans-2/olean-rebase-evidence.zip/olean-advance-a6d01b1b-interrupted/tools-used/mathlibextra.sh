#!/usr/bin/env bash
# mathlibextra.sh <tree> <Mathlib/Module/Path> <log>: (derand review) compile ONE pinned Mathlib module that the shared
# package tree lacks (no cache get, no lake, nothing written under /home/user/tcslib) with plain `lean -o` into <tree>
# (the review's own olean tree, searched first on LEAN_PATH by scripts/lean_check_tree.sh). Its imports must already be
# present in the package tree. Run from the pinned mathlib package root so the module name is the source path.
set -u
T=$1; M=$2; LOG=$3; PK=/home/user/tcslib/.lake/packages
LP="$T"; for d in $PK/*/.lake/build/lib/lean; do LP="$LP:$d"; done
export LEAN_PATH="$LP"; export PATH="$HOME/.elan/bin:$PATH"
mkdir -p "$T/$(dirname $M)"
cd $PK/mathlib && { git -C $PK/mathlib rev-parse HEAD; sha256sum $M.lean; } > $LOG 2>&1
( cd $PK/mathlib && time lean $M.lean -o "$T/$M.olean" ) >> $LOG 2>&1; rc=$?
echo "lean rc=$rc" >> $LOG; sha256sum "$T/$M.olean" >> $LOG 2>&1; exit $rc
