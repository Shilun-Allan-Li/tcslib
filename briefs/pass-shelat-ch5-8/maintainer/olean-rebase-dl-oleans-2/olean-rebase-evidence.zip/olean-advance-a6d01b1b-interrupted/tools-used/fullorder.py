"""fullorder.py <repo> <rev> <out>: (olean snapshot procedure) the full import closure of root TCSlib and every
audits/*/Checks at <rev>, in imports-first DFS order (downorder.py's closure() traversal and parsing). A snapshot's
completeness check runs over this order; downorder.py's order.txt covers only the closure of a change's downstream."""
import sys, re, subprocess
repo, rev, out = sys.argv[1:4]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
roots = ['TCSlib'] + [f for f in files if re.fullmatch(r'audits/[^/]+/Checks', f)]
order, seen = [], set(); sys.setrecursionlimit(100000)
def visit(m):
    if m in seen: return
    seen.add(m)
    for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M):
        if local(i): visit(i.replace('.', '/'))
    order.append(m)
for r in sorted(roots): visit(r)
open(out, 'w').write(''.join(m + '\n' for m in order)); print(f'roots {sorted(roots)}; full order {len(order)}')
