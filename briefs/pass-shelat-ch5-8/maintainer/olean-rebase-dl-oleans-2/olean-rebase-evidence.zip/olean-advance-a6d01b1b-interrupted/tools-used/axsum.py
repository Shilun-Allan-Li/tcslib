"""axsum.py <log>...: one line per `#print axioms` result (wrapped lists joined; prefix TCSlib.Cryptography.SecureComputation.
stripped, as in Phase 2's axioms-summary.txt), then the ADMITTED and CENSUS lines verbatim (same prefix stripped)."""
import sys, re
P = 'TCSlib.Cryptography.SecureComputation.'
for f in sys.argv[1:]:
    t = open(f, encoding='utf-8', errors='replace').read()
    for m in re.finditer(r"^'([^']+)' depends on axioms: \[([^\]]*)\]", t, re.M):
        print(f"{m.group(1).replace(P, '')} :: {', '.join(x.strip() for x in m.group(2).split(','))}")
    for m in re.finditer(r"^'([^']+)' does not depend on any axioms", t, re.M):
        print(f"{m.group(1).replace(P, '')} :: none")
    for l in t.splitlines():
        if l.startswith('ADMITTED ') or l.startswith('CENSUS ') or l.startswith('NONSTD'): print(l.replace(P, ''))
