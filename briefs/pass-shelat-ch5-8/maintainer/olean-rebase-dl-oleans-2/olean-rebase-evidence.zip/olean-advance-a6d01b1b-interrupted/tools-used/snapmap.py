"""snapmap.py (olean snapshot procedure, 2026-11-16): object map of a complete olean snapshot directory.

  snapmap.py make   <dir> <map.tsv>
      map.tsv = one line `<module>\t<sha256 of <module>.olean>` per .olean under <dir>, sorted by module (module = the
      path relative to <dir> without `.olean`, `/`-separated). Refuses symlinks, non-.olean files (other than .ilean,
      which are mapped as `<module>.ilean`) and empty directories, so the map describes the whole directory. Prints the
      count, the TCSlib/audits/PFR split and the map's SHA-256.
  snapmap.py verify <dir> <map.tsv> <outdir>
      rehash every file under <dir> against the map: extra.txt, changed.txt, missing.txt; prints the three counts and
      RESULT OK only if all are 0 and the directory has no symlinks or empty directories."""
import sys, os, hashlib
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def scan(d):
    files, links, other, empty = {}, [], [], []
    for r, ds, fs in os.walk(d):
        if not ds and not fs: empty.append(os.path.relpath(r, d))
        for f in fs + [x for x in ds if os.path.islink(os.path.join(r, x))]:
            p = os.path.join(r, f); rel = os.path.relpath(p, d)
            if os.path.islink(p): links.append(rel); continue
            if rel.endswith('.olean'): files[rel[:-6]] = sha(p)
            elif rel.endswith('.ilean'): files[rel] = sha(p)
            else: other.append(rel)
    return files, links, other, empty
cmd, d = sys.argv[1], sys.argv[2]
files, links, other, empty = scan(d)
if cmd == 'make':
    out = sys.argv[3]
    assert not links and not other and not empty, (links[:5], other[:5], empty[:5])
    with open(out, 'w') as o:
        for m in sorted(files): o.write(f'{m}\t{files[m]}\n')
    top = {}
    for m in files: top[m.split('/')[0]] = top.get(m.split('/')[0], 0) + 1
    print(f'entries {len(files)}; by top-level {dict(sorted(top.items()))}; map sha256 {sha(out)}')
elif cmd == 'verify':
    mp, outd = sys.argv[3:5]; os.makedirs(outd, exist_ok=True)
    M = dict(l.rstrip('\n').split('\t') for l in open(mp))
    extra = sorted(set(files) - set(M)); missing = sorted(set(M) - set(files))
    changed = sorted(m for m in files if m in M and files[m] != M[m])
    w = lambda n, xs: open(os.path.join(outd, n), 'w').write(''.join(x + '\n' for x in xs))
    w('extra.txt', extra); w('missing.txt', missing); w('changed.txt', changed)
    ok = not (extra or missing or changed or links or other or empty)
    print(f'map {mp} sha256 {sha(mp)}; on disk {len(files)}; extra {len(extra)}; changed {len(changed)}; missing {len(missing)}; '
          f'symlinks {len(links)}; other files {len(other)}; empty dirs {len(empty)}; RESULT {"OK" if ok else "FAIL"}')
