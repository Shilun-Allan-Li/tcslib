#!/usr/bin/env bash
# run-build-advance.sh (snapshot advance to a6d01b1b; = run-build-rebase.sh with the evidence dir, output dir and queue changed):
# the incremental build of plan/queue.txt (145 modules: closure-key changes vs the snapshot cd607009, over the
# closure of root TCSlib and both audits/*/Checks) on olean-replay-a6d01b1b through scripts/lean_check_tree.sh (tools-used/runner.py;
# one Lean process; stops at the first failure).
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-rebase2
export PATH=$HOME/.elan/bin:$PATH TMPDIR=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/tmp
echo "start $(date -u +%FT%TZ)" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/build/runner.start
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/tools-used/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-rebase2 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-a6d01b1b /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/build &
rp=$!; echo $rp > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/build/runner.pid
wait $rp
echo "runner exit $? $(date -u +%FT%TZ)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/olean-advance-a6d01b1b/build/runner.exit
