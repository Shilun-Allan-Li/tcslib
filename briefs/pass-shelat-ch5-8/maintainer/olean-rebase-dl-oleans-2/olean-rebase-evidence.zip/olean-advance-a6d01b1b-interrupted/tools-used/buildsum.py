"""buildsum.py <results.jsonl>: rc/error/sorry/warning summary of a runner.py run, warnings per module."""
import json, sys
r = [json.loads(l) for l in open(sys.argv[1]) if '"module"' in l]
print(f"modules {len(r)}; rc!=0 {[x['module'] for x in r if x['rc']]}; errors (G26-N1 form) {sum(x['errors'] for x in r)}; "
      f"error substring {sum(x.get('error_substr', 0) for x in r)}; sorry warnings {sum(x['sorry'] for x in r)}; warnings {sum(x['warnings'] for x in r)}; "
      f"seconds {round(sum(x['seconds'] for x in r))}")
for x in r:
    if x['warnings'] or x['sorry']: print(f"  {x['module']}: warnings {x['warnings']} sorry {x['sorry']}")
