#!/usr/bin/env bash
# diskwatch.sh (DW-5): log free space on / every 60 s until build/runner.exit exists. If free space falls below
# 250 MB, record it and stop this job's runner (its own python PID from build/runner.pid, then the checker
# process named in build/current.pid), so the shared disk is never filled.
while [ ! -s /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dw5/build/runner.exit ]; do
  f=$(df -B1M / | tail -1 | awk '{print $4}'); echo "$(date -u +%FT%TZ) $f MB free" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dw5/build/df.log
  if [ "$f" -lt 250 ]; then echo "$(date -u +%FT%TZ) LOW-DISK STOP" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dw5/build/df.log
    kill $(cat /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dw5/build/runner.pid) 2>/dev/null; kill $(cut -d' ' -f1 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dw5/build/current.pid) 2>/dev/null; break; fi
  sleep 60
done
echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free (end)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dw5/build/df.log
