"""devseal.py <archived-tools-dir> <seal-record.json> <source.lean> <probe-out.lean> <map.json> (DW-5 development only):
instrument the WORKING-TREE source with the request rows of an existing seal record (same archived Gate06/10
instrumenter as mkseals_ab.py: build_seals.instrument + request_payload_adapter.configure_builders). Used only to
iterate on uncommitted proofs; the reported seals are regenerated from the committed head by mkseals_ab/coe."""
import sys, json, importlib.util
from pathlib import Path
tools, rec, src, out, mapf = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs')
controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter')
adapter.configure_builders(bs, controls)
r = json.load(open(rec)); raw = Path(src).read_bytes()
probe, ins, lmap = bs.instrument(raw, bs.header(raw), r['label'], r['rows'])
Path(out).parent.mkdir(parents=True, exist_ok=True); Path(out).write_bytes(probe)
json.dump({d['probe_line']: d['source_line'] for d in lmap}, open(mapf, 'w'))
print(r['label'], 'rows', len(r['rows']))
