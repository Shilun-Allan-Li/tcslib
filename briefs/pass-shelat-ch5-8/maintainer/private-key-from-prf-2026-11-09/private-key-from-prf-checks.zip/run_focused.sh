#!/usr/bin/env bash
set -euo pipefail
area=$1
repo=$2
deadline=$((SECONDS+180))
until [ -f "$area/native/RESULT.json" ] && [ -f "$area/metadata/HeadCensus.rc" ]; do
    test "$SECONDS" -lt "$deadline"
    sleep 2
done
test "$(cat "$area/metadata/HeadCensus.rc")" = 0
cmp scripts/lean_check_tree.sh "$repo/scripts/lean_check_tree.sh"
toolchain="$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$area/native/PLAN.json")"
for side in Base Head; do
    python3 -I "$area/prepare_seals.py" "$area" "$repo" "$side" --focus
    lower="$(printf '%s' "$side" | tr '[:upper:]' '[:lower:]')"
    target="$area/metadata/$lower-focus"
    bash "$area/run_probes.sh" "$toolchain" "$target/oleans" "$target/PRFSchemeSeal"
done
