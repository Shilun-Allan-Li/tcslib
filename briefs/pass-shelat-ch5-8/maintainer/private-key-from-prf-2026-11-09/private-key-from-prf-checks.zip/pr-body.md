## Changes

- Move the PRF scheme, correctness and fixed-vector security proofs, and PRF/PRG existence results into `Encryption.PrivateKey.FromPRF`.
- Put the finite six-hybrid bound in `FromPRF.Hybrid`, the collision and coin-relabelling lemmas in `FromPRF.HybridLemmas`, and the next-query machine and run agreement in `FromPRF.ReductionMachine`.
- Publish `prfEncReal_apply` and `eval_multiMsgAdv` beside the hybrid definitions. The two scheme proofs use these equations across the new module boundary.
- Keep the two legacy `Asymptotic.MultiMessage*` imports working and update the private-key and pseudorandomness construction maps.

## Verification

- All 13 affected modules pass one-module-at-a-time Lean 4.25.0 checking, including the library root and campaign Checks. The legacy and standalone probes agree.
- The census matches all 157 relocated types, definition values and axiom sets. It also matches the Lean-generated `prfAdv.congr_simp` across its module change. Only the two proofs using the new equations have changed elaborated references.
- Both baseline and all four new whole-file seals pass, as do the focused seals on the fixed-length PRF wrapper. The controls check that the seal blocks direct reduction and both new equations work under it.
- Source lint and the diff check pass. The campaign linter clears the `prfEncReal` reader warning and repeats its existing direct-import flags for modules reachable through `Pseudorandom.Functions`.
