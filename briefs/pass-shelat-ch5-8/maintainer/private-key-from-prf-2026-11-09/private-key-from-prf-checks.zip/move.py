"""Stage the four FromPRF owners and compatibility imports from the exact merged source."""
from difflib import SequenceMatcher
import json
from pathlib import Path
import subprocess
import sys

area, repo = (Path(arg).resolve() for arg in sys.argv[1:3])
base = (area / "base.txt").read_text().strip()
scope = json.loads((area / "MOVE-SCOPE.json").read_bytes())
legacy, legacy_lemmas, owner, hybrid, lemmas, machine, facade, map_module = (
    scope[name] for name in ("legacy", "legacy_lemmas", "owner", "hybrid", "hybrid_lemmas", "machine", "facade", "map"))
crypto = "TCSlib/Cryptography/"
legacy_prf = crypto + "Asymptotic/PRF"
legacy_enc = crypto + "Asymptotic/Encryption"
prefix = "TCSlib.Cryptography."
namespace = "namespace TCSlib.Cryptography"
main, support = None, None


def show(module):
    return subprocess.check_output(["git", "show", f"{base}:{module}.lean"], cwd=repo).decode()


def dot(module):
    return module.replace("/", ".")


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


main, support = show(legacy), show(legacy_lemmas)
options = main[main.index("set_option "):main.index("/-!")]
copyright = main[:main.index("import ")]
ref = """## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.7, Definition 93.1, and §3.9, Algorithm 99.1 and Theorem 99.2.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.4 (oracle adversaries and PRF advantage).
-/
"""


def header(imports, doc):
    return copyright + "".join("import " + dot(name) + "\n" for name in imports) + "\n" + options + doc + ref


def math_module(imports, doc, ns, block):
    return header(imports, doc) + "\n" + ns + "\n\nopen Complexity Turing Finset\n\n" + block + "end " + ns.removeprefix("namespace ") + "\n"


def extract(text, start, end):
    left = text.index(start)
    return left, text[left:text.index(end, left)]


hybrid_start, hybrid_before = extract(main, "/-! ### Query chains", "/-! ### The scheme")
scheme_start, scheme_before = extract(main, "/-! ### The scheme", "end TCSlib.Cryptography\n")
lemmas_start, lemmas_before = extract(support, "/-! ### Probability", "/-! ### Strings")
machine_start, machine_before = extract(support, "/-! ### Strings", "end TCSlib.Cryptography.MultiMsg\n")

sampler_reader = """omit [Fintype K] in
/-- The hybrid ciphertext at position `j` contains the point `z.2 j` and the message
masked with the oracle's value at that point [PS10, Theorem 99.2, proof]. -/
theorem prfEncReal_apply (F : K → (Fin n → Bool) → (Fin n → Bool)) (m : Fin (q + 1) → Fin n → Bool)
    (z : K × (Fin (q + 1) → Fin n → Bool)) (j : Fin (q + 1)) :
    prfEncReal F m z j = (z.2 j, m j + F z.1 (z.2 j)) := rfl

"""
adversary_reader = """omit [Fintype ρ] in
/-- Evaluating the hybrid adversary on an oracle runs the tuple distinguisher on the sampled
points and the messages masked by the oracle values [PS10, Theorem 99.2, proof]. -/
theorem eval_multiMsgAdv (m : Fin (q + 1) → Fin n → Bool)
    (D : (Fin (q + 1) → (Fin n → Bool) × (Fin n → Bool)) → ρ → Bool)
    (g : (Fin n → Bool) → Fin n → Bool) (c : (Fin (q + 1) → Fin n → Bool) × ρ) :
    (multiMsgAdv m D c).eval g = D (fun j => (c.1 j, m j + g (c.1 j))) c.2 := by
  rw [multiMsgAdv, eval_chainTree]

"""
hybrid_after = replace_once(hybrid_before, "/-- The ciphertext tuple `(r_j, m_j ⊕ p_j)",
                            sampler_reader + "/-- The ciphertext tuple `(r_j, m_j ⊕ p_j)")
hybrid_after = replace_once(hybrid_after,
    "omit [Fintype ρ] in\n/-- `multiMsgAdv m D` makes at most",
    adversary_reader + "omit [Fintype ρ] in\n/-- `multiMsgAdv m D` makes at most")
scheme_after = replace_once(scheme_before,
    "  rw [h1, h2, hFE, zipWith_xor_ofFn_add]\n  rfl\n",
    "  rw [h1, h2, hFE, zipWith_xor_ofFn_add, prfEncReal_apply]\n")
scheme_after = replace_once(scheme_after,
    "      rw [hφ g w.1 w.2, multiMsgAdv, eval_chainTree, NUPPT.distinguisherL_eq, encodeTuple_eq_flatten]\n",
    "      rw [hφ g w.1 w.2, eval_multiMsgAdv, NUPPT.distinguisherL_eq, encodeTuple_eq_flatten]\n")

from_prf_doc = """/-!
# Multi-message secure encryption from a pseudorandom function

The key generator samples a key. The encryptor samples an independent point, masks the
message with the function value at that point, and returns the point with the masked message.
Decryption recomputes the mask and checks the ciphertext format [PS10, Algorithm 99.1].

## Main definitions

* `prfEncFun`, `prfDecFun` and `prfScheme` implement the scheme from a polynomial-time evaluator.
* `encodeTuple` encodes the fixed vector of ciphertext pairs as a string.

## Main results

* `prfScheme_multiEncDist` identifies the ciphertext sampler with the encoded real hybrid.
* `prfScheme_multiMessageSecure` lifts the six-hybrid bound to a negligible advantage against
  non-uniform polynomial-time distinguishers [PS10, Theorem 99.2].
* `exists_multiMessageSecure_of_prf` and `exists_multiMessageSecure_of_exists_prg` give the
  existence results from a PRF and, via GGM, from a PRG.

## Contents

* `FromPRF.Hybrid` proves the concrete six-hybrid bound.
* `FromPRF.HybridLemmas` supplies the collision and coin-relabelling estimates.
* `FromPRF.ReductionMachine` implements the next-query reduction and proves its run agreement.

"""
hybrid_doc = """/-!
# The finite PRF encryption hybrid

The outer switches use PRF advantage. The inner switches replace random-function
answers at sampled points by independent pads, with a loss bounded by the probability
of repeated points. The two independent-pad experiments agree by perfect secrecy.

## Main definitions

* `chainTree` asks a fixed tuple of oracle queries.
* `prfEncReal` and `otpEnc` sample the ciphertext tuples in the real and independent-pad experiments.
* `multiMsgAdv` runs a tuple distinguisher after querying the oracle at the sampled points.

## Main results

* `prfAdv_multiMsgAdv` identifies the outer switch with a PRF advantage.
* `distAdv_prfEncReal_random_otp_le` bounds the inner switch by the collision probability.
* `acceptProb_otpEnc` equates the two independent-pad experiments.
* `distAdv_prfEncReal_le` combines the switches [PS10, Theorem 99.2, proof].

**Deviation.** The vector has `q + 1` points, giving collision term `C(q + 1, 2) / 2^n`.

"""
lemmas_doc = """/-!
# Probability and coin relabelling for PRF encryption

## Main definitions

The lemmas use the existing uniform expectations and finite oracle adversaries.

## Main results

* `MultiMsg.abs_uexp_sub_le_uprob` bounds the difference of two expectations by the
  probability of the event on which the functions can disagree.
* `MultiMsg.card_filter_lt_pairs` counts the pairs of distinct query indices in increasing order.
* `MultiMsg.negligible_choose_div_two_pow` proves negligibility of the collision term.
* `MultiMsg.prfAdv_congr_equiv` transports the PRF advantage along a bijection of coins
  when the two adversaries agree on every oracle.

"""
machine_doc = """/-!
# The next-query machine for PRF encryption

The machine uses its coins for the query points and the distinguisher's coins.
Its advice carries the message vector. After receiving all answers, it applies the
distinguisher to the encoded vector of masked messages [PS10, Theorem 99.2, proof].

## Main definitions

* `MultiMsg.histBlock` and `MultiMsg.maskBlock` give the encodings of a history entry and a mask.
* `MultiMsg.preFun` and `MultiMsg.postFun` give the input and output processing for each move.

## Main results

* `MultiMsg.zipWith_xor_histBlock_maskBlock` relates a masked history block to a ciphertext.
* `MultiMsg.polyTimeComputable_preFun` and `MultiMsg.polyTimeComputable_postFun` bound the
  processing by polynomial time.
* `MultiMsg.exists_queryChain_nuppt` packages the reduction and proves its agreement with
  the tuple experiment after relabelling its coins.

"""
imports = {
    owner: [crypto + "Asymptotic/HardCoreLoops", facade + "/FromPRG", hybrid, lemmas, machine,
            crypto + "Pseudorandom/Functions/Asymptotic/GGM"],
    hybrid: [lemmas, crypto + "HardcoreBit/Basic", "Mathlib/Algebra/Ring/BooleanRing"],
    lemmas: ["TCSlib/Complexity/Randomized/PolyExpr", crypto + "Foundations/Negligible",
             crypto + "HardcoreBit/Basic", crypto + "OneWayFunctions/Basic",
             crypto + "Pseudorandom/Functions/Defs", crypto + "Pseudorandom/Functions/LazySampling",
             "Mathlib/Data/Nat/Choose/Bounds"],
    machine: [crypto + "Asymptotic/EnsemblesLemmas", crypto + "Asymptotic/HardCoreLoops",
              crypto + "Pseudorandom/Functions/Asymptotic/Defs"],
    legacy: [legacy_prf, legacy_enc, legacy_lemmas, owner, "Mathlib/Data/Nat/Choose/Basic"],
    legacy_lemmas: [legacy_prf, lemmas, machine, "Mathlib/Data/Nat/Choose/Basic", "Mathlib/Data/Nat/Choose/Bounds"],
}
sources = {
    owner: math_module(imports[owner], from_prf_doc, namespace, scheme_after),
    hybrid: math_module(imports[hybrid], hybrid_doc, namespace, hybrid_after),
    lemmas: math_module(imports[lemmas], lemmas_doc, namespace + ".MultiMsg", lemmas_before),
    machine: math_module(imports[machine], machine_doc, namespace + ".MultiMsg", machine_before),
}
sources[legacy] = header(imports[legacy], """/-!
# PRF-based private-key encryption compatibility import

## Main definitions

`Encryption.PrivateKey.FromPRF` defines the scheme of [PS10, Algorithm 99.1].

## Main results

The import exposes the finite hybrid, next-query reduction, and fixed-vector security
proof [PS10, Theorem 99.2].

""")
sources[legacy_lemmas] = header(imports[legacy_lemmas], """/-!
# PRF encryption proof support compatibility import

## Main definitions

`Encryption.PrivateKey.FromPRF.ReductionMachine` defines the encoded history and the
reduction's processing functions.

## Main results

`Encryption.PrivateKey.FromPRF.HybridLemmas` supplies the collision estimates and
coin transport. `ReductionMachine` proves the polynomial-time reduction and run agreement.

""")

facade_source = replace_once(show(facade),
    "import " + dot(legacy_lemmas) + "\nimport " + dot(legacy) + "\n",
    "".join("import " + dot(module) + "\n" for module in (owner, hybrid, lemmas, machine)))
sources[facade] = replace_once(facade_source,
    "* `Asymptotic.MultiMessageLemmas` gives the encoding identities and reduction machine\n"
    "  for the PRF scheme.\n"
    "* `Asymptotic.MultiMessage` gives the PRF construction, its finite hybrid bound\n"
    "  and its fixed-vector security proof [PS10, Algorithm 99.1 and Theorem 99.2].",
    "* `Encryption.PrivateKey.FromPRF` gives the PRF scheme and its fixed-vector security proof\n"
    "  [PS10, Algorithm 99.1 and Theorem 99.2].\n"
    "* `Encryption.PrivateKey.FromPRF.Hybrid` proves the finite six-hybrid bound.\n"
    "* `Encryption.PrivateKey.FromPRF.HybridLemmas` gives its probability and coin lemmas.\n"
    "* `Encryption.PrivateKey.FromPRF.ReductionMachine` implements the next-query reduction.")
sources[map_module] = replace_once(show(map_module),
    "  `TCSlib.Cryptography.Asymptotic.MultiMessage` via `TCSlib.Cryptography.prfScheme_multiMessageSecure`\n",
    "  `TCSlib.Cryptography.Encryption.PrivateKey.FromPRF` via\n"
    "  `TCSlib.Cryptography.prfScheme_multiMessageSecure`\n")

line_map = {}
for old, target, raw, start, before, after in (
    (legacy, owner, main, scheme_start, scheme_before, scheme_after),
    (legacy, hybrid, main, hybrid_start, hybrid_before, hybrid_after),
    (legacy_lemmas, lemmas, support, lemmas_start, lemmas_before, lemmas_before),
    (legacy_lemmas, machine, support, machine_start, machine_before, machine_before),
):
    old_line = raw[:start].count("\n") + 1
    new_line = sources[target][:sources[target].index(after)].count("\n") + 1
    mapping = line_map.setdefault(old, {})
    for a, b, count in SequenceMatcher(None, before.splitlines(), after.splitlines(), autojunk=False).get_matching_blocks():
        for offset in range(count):
            assert old_line + a + offset not in mapping
            mapping[old_line + a + offset] = [target, new_line + b + offset]
for module, source in sources.items():
    target = area / "source" / (module + ".lean")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.encode())
(area / "SOURCE-MAP.json").write_text(json.dumps({"base": base, "imports": imports, "lines": line_map}, indent=2) + "\n")
print("Prepared the four new owners, two compatibility imports and construction maps.")
