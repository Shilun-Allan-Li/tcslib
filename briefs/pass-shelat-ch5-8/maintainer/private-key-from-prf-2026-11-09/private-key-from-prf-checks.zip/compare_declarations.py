"""Compare checked declaration types, definition values, and legacy imports."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
scope = json.loads((area / "MOVE-SCOPE.json").read_bytes())
legacy, legacy_lemmas, owner, hybrid, lemmas, machine = (
    scope[name].replace("/", ".") for name in ("legacy", "legacy_lemmas", "owner", "hybrid", "hybrid_lemmas", "machine"))
owners = {legacy: {owner, hybrid}, legacy_lemmas: {lemmas, machine}}
readers = {"TCSlib.Cryptography.prfEncReal_apply", "TCSlib.Cryptography.eval_multiMsgAdv"}
standard = {"propext", "Classical.choice", "Quot.sound"}
hygiene = ("str", "_@")


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def catalog(side, owners):
    rows = [json.loads(line) for line in (meta / (side + ".jsonl")).open()]
    last = rows.pop()
    assert last["record"] == "complete" and last["catalog"] == sum(r["record"] == "catalog" for r in rows)
    assert {name["display"] for name in last["owners"]} == owners
    result = {r["name"]["display"]: r for r in rows if r["record"] == "constant"}
    assert len(result) == last["count"] and {r["home"]["display"] for r in result.values()} == owners
    assert all({item["display"] for item in r["axioms"]} <= standard for r in result.values())
    return result


def suffix(r):
    name = key(r["name"])
    home = key(r["home"])
    if name[:len(home)+1] == (("str", "_private"),) + home:
        assert name[len(home)+1][0] == "num"
        return name[len(home)+2:]
    return name


def canonical(expr, names):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, label, *[canonical(part, names) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, names.get(name, name), *[canonical(part, names) for part in expr[2:]]]
    return [canonical(part, names) for part in expr]


base = catalog("Base", set(owners))
head = catalog("Head", {owner, hybrid, lemmas, machine})
assert len(base) == 157
for name in readers:
    assert head[name]["kind"] == "theorem" and head[name]["home"]["display"] == hybrid
suffixes = {suffix(row): name for name, row in head.items()}
assert len(suffixes) == len(head)
pairs = {}
for name, row in base.items():
    if name in head:
        pairs[name] = name
    else:
        assert suffix(row) in suffixes, name
        pairs[name] = suffixes[suffix(row)]
generated = "TCSlib.Cryptography.prfAdv.congr_simp"
old_auxiliary_home = "TCSlib.Cryptography.Pseudorandom.Functions.GGM"
assert set(pairs.values()) | readers | {generated} == set(head)
assert not set(pairs.values()) & (readers | {generated})
aux_base = catalog("BaseAux", {old_auxiliary_home})
assert set(aux_base) == {generated}
a, b = aux_base[generated], head[generated]
assert b["home"]["display"] == hybrid and a["kind"] == b["kind"] == "theorem"
assert canonical(a["type"], {}) == canonical(b["type"], {})
for field in ("status", "abbrev", "instance", "matcher", "levels"):
    assert a[field] == b[field], field
for field in ("type_refs", "value_refs", "axioms"):
    assert {key(ref) for ref in a[field]} == {key(ref) for ref in b[field]}, field
auxiliary = {"name": generated, "old_home": old_auxiliary_home, "new_home": hybrid,
             "type_and_dependencies_match": True,
             "axioms": sorted(ref["display"] for ref in b["axioms"])}

renamed = {key(base[name]["name"]): key(head[new]["name"]) for name, new in pairs.items() if name != new}
assert all(name[0] == ("str", "_private") for name in renamed)
errors = []
result = []
proof_deltas = {}
for name, target in sorted(pairs.items()):
    a, b = base[name], head[target]
    old_home, new_home = a["home"]["display"], b["home"]["display"]
    assert new_home in owners[old_home], (name, old_home, new_home)
    for field in ("kind", "status", "abbrev", "instance", "matcher", "levels"):
        if a[field] != b[field]:
            errors.append((name, field))
    if {key(item) for item in a["axioms"]} != {key(item) for item in b["axioms"]}:
        errors.append((name, "axioms"))
    if canonical(a["type"], renamed) != canonical(b["type"], {}):
        errors.append((name, "type"))
    if {renamed.get(key(ref), key(ref)) for ref in a["type_refs"]} != {key(ref) for ref in b["type_refs"]}:
        errors.append((name, "type_refs"))
    if canonical(a["definition_value"], renamed) != canonical(b["definition_value"], {}):
        errors.append((name, "definition_value"))
    before = {renamed.get(key(ref), key(ref)) for ref in a["value_refs"]}
    after = {key(ref) for ref in b["value_refs"]}
    if before != after:
        assert a["kind"] == "theorem", name
        show = lambda refs: sorted(".".join(part for _, part in ref) for ref in refs)
        proof_deltas[name] = {"removed": show(before - after), "added": show(after - before)}
    result.append({"old_name": name, "new_name": target, "old_home": old_home, "new_home": new_home,
                   "kind": a["kind"], "axioms": sorted(i["display"] for i in b["axioms"])})
assert not errors, errors
labels = ("BaseCensus", "BaseAuxCensus", "HeadCensus", "BaseLegacy", "HeadLegacy", "BaseLemmasLegacy",
          "HeadLemmasLegacy", "Standalone", "HybridStandalone", "MachineStandalone")
for label in labels:
    assert (meta / (label + ".rc")).read_text().strip() == "0", label
for label, base_label in (("HeadLegacy", "BaseLegacy"), ("Standalone", "BaseLegacy"),
                          ("HeadLemmasLegacy", "BaseLemmasLegacy")):
    assert (meta / (label + ".log")).read_bytes() == (meta / (base_label + ".log")).read_bytes(), label
for label, imported in (("BaseLegacy", legacy), ("HeadLegacy", legacy), ("Standalone", owner),
                        ("BaseLemmasLegacy", legacy_lemmas), ("HeadLemmasLegacy", legacy_lemmas),
                        ("HybridStandalone", hybrid), ("MachineStandalone", machine)):
    imports = [line for line in (meta / (label + ".lean")).read_text().splitlines() if line.startswith("import ")]
    assert imports == ["import " + imported]
moved = Counter(r["new_home"] for r in result if r["old_home"] != r["new_home"])
assert set(moved) == {owner, hybrid, lemmas, machine}
(area / "DECLARATIONS.json").write_text(json.dumps({
    "base": (area / "base.txt").read_text().strip(), "head": (area / "head.txt").read_text().strip(),
    "matched_declarations": len(result), "relocated_declarations": sum(moved.values()),
    "new_homes": moved, "private_name_changes": len(renamed),
    "type_and_definition_comparison": "same kernel syntax modulo generated binder scopes and relocated private names",
    "axioms_match": True, "legacy_and_new_imports_agree": True,
    "proof_dependency_deltas": proof_deltas, "generated_congruence": auxiliary,
    "new_readers": {name: sorted(ref["display"] for ref in head[name]["axioms"]) for name in sorted(readers)},
    "catalog_sha256": {side: sha(meta / (side + ".jsonl")) for side in ("Base", "BaseAux", "Head")},
    "declarations": result,
}, indent=2) + "\n")
print("All 157 prior declaration types, definition values and axiom sets match.")
print("Moved declarations:", dict(moved))
