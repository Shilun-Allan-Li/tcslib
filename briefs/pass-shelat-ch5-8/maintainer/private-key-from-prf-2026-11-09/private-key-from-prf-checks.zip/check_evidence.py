"""Verify the exact source replay, declaration comparison, seals and ledger mapping."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, repo, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
native, meta = area / "native", area / "metadata"
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source, move, decls = (read(area / (name + ".json")) for name in ("SOURCE-CHECK", "MOVE-SCOPE", "DECLARATIONS"))
source_map = read(area / "SOURCE-MAP.json")
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain") and not git("diff", "--check", base, head)
assert all((r["base"], r["head"]) == (base, head) for r in (plan, result, source, decls))
assert result["passed"] and result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == len(plan["affected"]) == 13
assert result["initial_retained"] == len(plan["retained"]) == 1094
assert len(products) == len(plan["order"]) == 1107 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert source["legacy_closure_preserved"] and source["facade_closure_preserved"]
assert source["source_map_sha256"] == sha(area / "SOURCE-MAP.json") and source_map["base"] == base
assert source["published_readers"] == ["prfEncReal_apply", "eval_multiMsgAdv"]
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert decls["matched_declarations"] == decls["relocated_declarations"] == 157
assert decls["private_name_changes"] == 7 and decls["generated_congruence"]["type_and_dependencies_match"]
assert decls["axioms_match"] and decls["legacy_and_new_imports_agree"]
assert decls["new_readers"] == {
    "TCSlib.Cryptography.eval_multiMsgAdv": ["Quot.sound", "propext"],
    "TCSlib.Cryptography.prfEncReal_apply": [],
}
assert decls["proof_dependency_deltas"] == {
    "TCSlib.Cryptography.prfScheme_multiEncDist": {
        "removed": [], "added": ["Prod.mk", "TCSlib.Cryptography.prfEncReal_apply"],
    },
    "TCSlib.Cryptography.prfScheme_multiMessageSecure": {
        "removed": ["TCSlib.Cryptography.QueryTree", "TCSlib.Cryptography.chainTree",
                    "TCSlib.Cryptography.eval_chainTree", "TCSlib.Cryptography.multiMsgAdv.eq_1"],
        "added": ["TCSlib.Cryptography.eval_multiMsgAdv"],
    },
}

seals, masks, focused_warnings = {}, {}, {}
pairs = {
    (r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
    for r in decls["declarations"] if r["kind"] == "def"
}
for side, rev in (("base", base), ("head", head)):
    for lane in ("seals", "focus"):
        tag = side + "-" + lane
        directory = meta / tag
        scope = read(directory / "SCOPE.json")
        stems = sorted(label for label in scope if label.endswith("Seal"))
        assert len(stems) == (1 if lane == "focus" else 2 if side == "base" else 4)
        seals[tag], masks[tag] = {}, {}
        for label in stems:
            stem = directory / label
            manifest = read(stem.with_suffix(".json"))
            filename = manifest["source_path"]
            raw = git("show", f"{rev}:{filename}")
            assert sha256(raw).hexdigest() == manifest["source_sha256"]
            assert sorted(row["source_line"] for row in manifest["line_map"]) == list(range(1, len(raw.splitlines())+1))
            requested = {(r["home"], r["spelling"]) for r in manifest["requests"]}
            count = scope[label]
            assert len(requested) == len(manifest["requests"]) == count
            assert sha(stem.with_suffix(".lean")) == manifest["probe_sha256"]
            log = stem.with_suffix(".log").read_text()
            assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
            assert stem.with_suffix(".rc").read_text().strip() == "0"
            assert not re.search(r"\.lean:\d+:\d+: error(?:\(|:)", log)
            if lane == "focus":
                assert filename == "TCSlib/Cryptography/Composability/PRFScheme.lean"
                focused_warnings[side] = re.findall(r"\.lean:\d+:\d+: warning: ([^\n]*)", log)
            seals[tag][label] = {
                "source_sha256": manifest["source_sha256"], "probe_sha256": manifest["probe_sha256"],
                "log_sha256": sha(stem.with_suffix(".log")), "requests": count, "diagnostics": 0,
            }
            masks[tag][label] = requested
base_focus, head_focus = (masks[side + "-focus"]["PRFSchemeSeal"] for side in ("base", "head"))
assert len(base_focus) == len(head_focus) == 47
assert {pairs[row] for row in base_focus} == head_focus
assert focused_warnings["base"] == focused_warnings["head"]
assert seals["base-focus"]["PRFSchemeSeal"]["source_sha256"] == seals["head-focus"]["PRFSchemeSeal"]["source_sha256"]

reverse = {after: before for before, after in pairs.items()}
legacy_by_head = {
    "FromPRFSeal": "MultiMessageSeal", "HybridSeal": "MultiMessageSeal",
    "HybridLemmasSeal": "MultiMessageLemmasSeal", "ReductionMachineSeal": "MultiMessageLemmasSeal",
}
for label, mask in masks["head-seals"].items():
    legacy_label = legacy_by_head[label]
    legacy_home = move["legacy" if legacy_label == "MultiMessageSeal" else "legacy_lemmas"].replace("/", ".")
    baseline_mask = masks["base-seals"][legacy_label]
    for request in mask:
        before = reverse.get(request, request)
        assert before in baseline_mask or (request in reverse and before[0] == legacy_home), (label, before)
for name in ("prfEncReal", "multiMsgAdv"):
    assert (move["hybrid"].replace("/", "."), "TCSlib.Cryptography." + name) in masks["head-seals"]["FromPRFSeal"]

controls = {}
for label, rc, expected in (
    ("UnsealedControl", 0, []), ("SealedControl", 1, ["prfEncReal"]),
    ("ReaderControl", 0, ["prfEncReal", "multiMsgAdv"]),
):
    stem = meta / "head-seals" / label
    log = stem.with_suffix(".log").read_text()
    assert int(stem.with_suffix(".rc").read_text()) == rc
    source_hash = sha(stem.with_suffix(".lean"))
    if expected:
        manifest = read(stem.with_suffix(".json"))
        assert source_hash == manifest["probe_sha256"]
        assert [r["spelling"] for r in manifest["requests"]] == ["TCSlib.Cryptography." + name for name in expected]
        assert log.count(f"G06-SEAL-END label={label} requested={len(expected)} verified={len(expected)}") == 1
    errors = re.findall(r"\.lean:\d+:\d+: error(?:\([^)]*\))?: ([^\n]+)", log)
    assert len(errors) == rc
    if rc:
        assert "Tactic `rfl` failed" in errors[0] and "prfEncReal" in log[log.index(errors[0]):]
    controls[label] = {"rc": rc, "log_sha256": sha(stem.with_suffix(".log")), "source_sha256": source_hash}

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log, (side, log)
    assert "where the seal failed: 0 " in log
before, after = ({tuple(row) for row in read(area / f"campaign-lint-{side}.json")} for side in ("base", "head"))
failures = {row for row in before if row[0] == "FAIL"}
assert failures == {row for row in after if row[0] == "FAIL"} and len(failures) == 5
closure = set()
pending = [move["map"]]
while pending:
    module = pending.pop()
    if module not in closure:
        closure.add(module)
        pending.extend(plan["graph"][module])
for _, filename, message in failures:
    assert filename == move["map"] + ".lean"
    found = re.fullmatch(r"facade does not import child module `([^`]+)`", message)
    assert found and found[1].replace(".", "/") in closure


def warn_names(rows):
    return sorted(name.strip() for level, _, message in rows if level == "WARN"
                  for name in message.split("(check 8):", 1)[1].split(","))


assert len(warn_names(before)) == 22 and len(warn_names(after)) == 21
assert set(warn_names(before)) - {"prfEncReal"} == set(warn_names(after))
assert "0 findings in 8 files" in (area / "style-head.log").read_text()
archive_dir = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
archive = archive_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (archive_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
assert len(ledger["current_observations"]) == 813 and not ledger["partial"] and not ledger["needs_review"]
providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
             for r in decls["declarations"] if r["kind"] == "def"}
links = []
for row in ledger["current_observations"]:
    refs = {(p["home"], p["spelling"]) for p in row.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in row.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if row["channel"] == "generated-equation":
        refs.add((row["provider_home"], row["provider"]))
    if row["channel"] == "explicit-source":
        refs.add((row["head"]["provider_home"], row["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": row["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": seals,
                          "controls": controls, "new_diagnostics": 0, "new_campaign_findings": 0,
                          "inherited_facade_direct_import_flags": sorted(failures),
                          "inherited_reader_warnings": warn_names(after),
                          "focused_consumer_warnings": focused_warnings["head"]})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                          "ledger_archive_sha256": archive_sha, "relocated_provider_links": links,
                          "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                          "generated_foreign_equation_reads": {"base": 0, "head": 0}})
print("13 affected modules pass. All six owner seals and both focused consumer seals pass.")
print(f"The control pair and both published readers pass. Mapped {len(links)} deferred provider links.")
