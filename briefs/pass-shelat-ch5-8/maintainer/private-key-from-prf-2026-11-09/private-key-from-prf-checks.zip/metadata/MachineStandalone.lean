import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine

#check @TCSlib.Cryptography.MultiMsg.histBlock
#check @TCSlib.Cryptography.MultiMsg.maskBlock
#check @TCSlib.Cryptography.MultiMsg.postFun
#check @TCSlib.Cryptography.MultiMsg.preFun_encodeHist
#check @TCSlib.Cryptography.MultiMsg.exists_queryChain_nuppt
