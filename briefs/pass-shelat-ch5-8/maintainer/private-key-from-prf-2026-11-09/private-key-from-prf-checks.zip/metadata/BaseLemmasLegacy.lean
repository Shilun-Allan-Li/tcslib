import TCSlib.Cryptography.Asymptotic.MultiMessageLemmas

#check @TCSlib.Cryptography.MultiMsg.abs_uexp_sub_le_uprob
#check @TCSlib.Cryptography.MultiMsg.card_filter_lt_pairs
#check @TCSlib.Cryptography.MultiMsg.negligible_choose_div_two_pow
#check @TCSlib.Cryptography.MultiMsg.prfAdv_congr_equiv
#check @TCSlib.Cryptography.MultiMsg.histBlock
#check @TCSlib.Cryptography.MultiMsg.maskBlock
#check @TCSlib.Cryptography.MultiMsg.postFun
#check @TCSlib.Cryptography.MultiMsg.preFun_encodeHist
#check @TCSlib.Cryptography.MultiMsg.exists_queryChain_nuppt
