import TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid

open TCSlib.Cryptography

example {n q : ℕ} {K : Type*} (F : K → (Fin n → Bool) → Fin n → Bool)
    (m : Fin (q + 1) → Fin n → Bool) (z : K × (Fin (q + 1) → Fin n → Bool)) (j : Fin (q + 1)) :
    prfEncReal F m z j = (z.2 j, m j + F z.1 (z.2 j)) := by
  rfl
