/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Composability.Defs
import TCSlib.Cryptography.Asymptotic.MultiMessage
import Mathlib.Tactic.Simps.Basic
/- G06-HARNESS INSTALL PRFSchemeSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "PRFSchemeSeal"
  let payload : String := "TCSlib.Cryptography.MultiMsg.adviceBound\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.blockMapFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.dropPolyFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.encodeHist_eq_flatMap.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.flatMap_const_replicate.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.flatMap_const_singleton.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.flatMap_range_blocks.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.histBlock\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.histBlockLen\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.length_flatMap_of_length.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.length_flatten_of_length.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.maskBlock\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.maskOf\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postAns\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postBudget\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postCount\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postHist\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postOffset\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postPoints\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postQuery\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postVerdict\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.preFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.takePolyFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.zipWith_xor_dbl.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.zipWith_xor_flatten_ofFn.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.zipWith_xor_replicate_false.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.boundedBy_chainTree.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree._sunfold\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree._unsafe_rec\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.encodeTuple\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.eval_chainTree.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.exists_multiMessageSecure_of_exists_prg.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.exists_multiMessageSecure_of_prf.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.multiMsgAdv\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.otpEnc\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.prfDecFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfDecWF\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfEncFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfEncReal\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.prfScheme\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfScheme_coinsEquiv\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.encodeList_eq_flatMap.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.zipWith_xor_xor_self.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid.0.TCSlib.Cryptography.chainTree.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid"
  let expectedRequests : Nat := 47
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.MultiMsg.adviceBound\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"adviceBound\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.blockMapFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"blockMapFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.dropPolyFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"dropPolyFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.encodeHist_eq_flatMap.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"encodeHist_eq_flatMap\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.flatMap_const_replicate.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"flatMap_const_replicate\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.flatMap_const_singleton.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"flatMap_const_singleton\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.flatMap_range_blocks.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"flatMap_range_blocks\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.histBlock\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"histBlock\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.histBlockLen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"histBlockLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.length_flatMap_of_length.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"length_flatMap_of_length\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.length_flatten_of_length.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"length_flatten_of_length\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.maskBlock\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"maskBlock\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.maskOf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"maskOf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postAns\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postAns\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postBudget\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postBudget\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postCount\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postCount\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postHist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postHist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postOffset\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postOffset\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postPoints\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postPoints\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postQuery\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postQuery\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postVerdict\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postVerdict\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.preFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"preFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.takePolyFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"takePolyFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.zipWith_xor_dbl.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"zipWith_xor_dbl\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.zipWith_xor_flatten_ofFn.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"zipWith_xor_flatten_ofFn\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.zipWith_xor_replicate_false.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"zipWith_xor_replicate_false\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.boundedBy_chainTree.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"boundedBy_chainTree\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.chainTree\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.chainTree._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.chainTree._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.chainTree.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.encodeTuple\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"encodeTuple\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.eval_chainTree.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"eval_chainTree\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.exists_multiMessageSecure_of_exists_prg.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"exists_multiMessageSecure_of_exists_prg\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.exists_multiMessageSecure_of_prf.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"exists_multiMessageSecure_of_prf\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.multiMsgAdv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multiMsgAdv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.otpEnc\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"otpEnc\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfDecFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfDecFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfDecWF\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfDecWF\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfEncFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfEncFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfEncReal\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfEncReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfScheme\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfScheme\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfScheme_coinsEquiv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfScheme_coinsEquiv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.encodeList_eq_flatMap.match_1_1\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"encodeList_eq_flatMap\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.zipWith_xor_xor_self.match_1_1\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"zipWith_xor_xor_self\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid.0.TCSlib.Cryptography.chainTree.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The §3.9 scheme under chosen-plaintext and chosen-ciphertext attacks (statement phase)

[PS10, Theorem 168.2]: the scheme of Algorithm 99.1 (the ch. 2–4 layer's `prfScheme`:
`Enc_k(m) = ⟨r, m ⊕ f_k(r)⟩` for a fresh uniform `r`) is CPA- and CCA1-secure when `F` is a PRF.
[PS10, §7.1.3, Claim 169.a in the inventory]: it is not CCA2-secure, whatever `F`.

The CCA1 statement relies on `Dec` refusing malformed ciphertexts (`prfDecWF`): the evaluator `E`
agrees with `F` only on `⟨s, x⟩` with `|s| = |x|`, and a decryption query must not reach it
elsewhere.

## Main definitions

* `Composability.prfFixedScheme`: `prfScheme`, whose ciphertexts have `3n + 2` bits.

## Main results

* `Composability.prfFixedScheme_cpa`, `Composability.prfFixedScheme_cca1` (Thm 168.2, stated;
  `sorry`s under the source's sketch).
* `Composability.prfFixedScheme_not_cca2` (Claim 169.a, stated; a `sorry` under its sketch): an
  explicit adversary with advantage `1`.
* `Composability.not_prfFixedScheme_cca2`: hence the scheme is not CCA2-secure (proved from the
  claim).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  Algorithm 99.1, Theorem 168.2 and §7.1.3 (book pp. 99, 168–169; the theorem calls the algorithm
  "construction 99.1").
-/

namespace TCSlib.Cryptography.Composability

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games

variable (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (F n s x))

/-- **The §3.9 scheme with fixed-length ciphertexts**: `⟨r, m ⊕ f_k(r)⟩` with `r` and `m` of `n`
bits has `2n + 2 + n = 3n + 2` bits. -/
noncomputable def prfFixedScheme : FixedLengthScheme where
  toPrivateKeyScheme := prfScheme F E hE hFE
  ctLen := .add (.mul (.const 3) .var) (.const 2)
  enc_length := by
    simp only [prfScheme_gen, prfScheme_enc]
    intro n rg m r
    have hlen : ∀ {f : List Bool → List Bool} (hf : PolyTimeComputable f),
        (NUPPT.ofPolyTimeUniform hf .var).coinLen n = n :=
      fun {f} hf => (NUPPT.coinLen_eq (NUPPT.ofPolyTimeUniform hf .var) n).trans
        ((congrArg (fun p : PolyExpr => p.eval n)
          (NUPPT.coins_ofPolyTimeUniform hf .var)).trans (PolyExpr.eval_var n))
    let k : Fin n → Bool := fun j =>
      rg (Fin.cast (hlen polyTimeComputable_pairSndD).symm j)
    let x : Fin n → Bool := fun j =>
      r (Fin.cast (hlen (polyTimeComputable_prfEncFun hE)).symm j)
    have hk : List.ofFn rg = List.ofFn k :=
      List.ofFn_congr (hlen polyTimeComputable_pairSndD) rg
    have hx : List.ofFn r = List.ofFn x :=
      List.ofFn_congr (hlen (polyTimeComputable_prfEncFun hE)) r
    rw [runAt_coinKey, runAt_prfEnc hE, hk, hx, hFE, length_pairEncode]
    simp only [List.length_zipWith, List.length_ofFn, Nat.min_self, PolyExpr.eval_add,
      PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
    omega

attribute [simps (config := { isSimp := false }) toPrivateKeyScheme ctLen] prfFixedScheme

/-- The fixed-length scheme uses the key generator of `prfScheme`. -/
theorem prfFixedScheme_gen :
    (prfFixedScheme F E hE hFE).gen = (prfScheme F E hE hFE).gen :=
  congrArg PrivateKeyScheme.gen (prfFixedScheme_toPrivateKeyScheme F E hE hFE)

/-- The fixed-length scheme uses the encryption machine of `prfScheme`. -/
theorem prfFixedScheme_enc :
    (prfFixedScheme F E hE hFE).enc = (prfScheme F E hE hFE).enc :=
  congrArg PrivateKeyScheme.enc (prfFixedScheme_toPrivateKeyScheme F E hE hFE)

/-- The fixed-length scheme uses the decryption machine of `prfScheme`. -/
theorem prfFixedScheme_dec :
    (prfFixedScheme F E hE hFE).dec = (prfScheme F E hE hFE).dec :=
  congrArg PrivateKeyScheme.dec (prfFixedScheme_toPrivateKeyScheme F E hE hFE)

/-- **Theorem 168.2 (CPA)** [PS10]: if `F` is a pseudorandom function family, the §3.9 scheme is
CPA-secure.

**Proof sketch** (the source's).
1. Replace `f_k` by a random function: by PRF security, the advantage changes by a negligible
   amount (the reduction answers `Enc` and the challenge by querying its own oracle at the fresh
   `r`). T2 (`Games.exists_interactiveHandlerMachine`) implements this forwarding handler,
   with the challenge bit in the seed and a finalization that compares the guess with that
   bit; the input-free companion and T4 (`Games.exists_toOracleAdversary_of_bitCodec`)
   supply the oracle adversary used by `OracleEnsemble.Indist`.
2. With a random function, the challenge's pad `RF(r*)` is uniform and independent of everything
   else unless `r*` collides with the `r` of some `Enc` answer. A collision has probability at most
   `q(n) / 2^n` (the collision bound `prob_mem_le`, one fresh draw against at most `q` earlier
   ones).
3. Off the collision, `m_b ⊕ RF(r*)` is uniform for both `b` (identical until bad,
   `identical_until_bad`), so the advantage is at most `q(n)/2^n` plus the PRF advantage:
   negligible. -/
theorem prfFixedScheme_cpa (hF : PRF F) : (prfFixedScheme F E hE hFE).INDSecure .cpa := by
  sorry

/-- **Theorem 168.2 (CCA1)** [PS10]: if `F` is a pseudorandom function family, the §3.9 scheme
is CCA1-secure.

**Proof sketch** (the source's). As for CPA, with the reduction also answering decryption
queries before the challenge with its oracle (`Dec_k(⟨r, c⟩) = c ⊕ f_k(r)` on well-formed
ciphertexts, `runAt_prfDec`; `⊥` on the others, `decodeFin_runAt_prfDec_of_not_wf`). The bad event
adds the case that a pre-challenge decryption query used the challenge's `r*`, again at most
`q(n)/2^n`, because `r*` is drawn after those queries. -/
theorem prfFixedScheme_cca1 (hF : PRF F) : (prfFixedScheme F E hE hFE).INDSecure .cca1 := by
  sorry

/-- **Claim 169.a: the §3.9 scheme is not CCA2-secure** [PS10, §7.1.3, p. 169], whatever the
family `F`. Some adversary, with a constant query budget, has advantage `1` at every `n > 0`.

The source's attack asks `Dec` for "`c + 1`", the challenge plus one. Read as an exclusive-or with
a fixed nonzero string, it flips the last bit of the challenge. The result is a different, still
well-formed ciphertext, which CCA2's `Dec` therefore answers.

**Proof sketch.**
1. The machine `A` reads its log. With an empty log, it asks the challenge on `⟨0^n, 1^n⟩`. With
   one entry, the challenge answer `c`, it asks `Dec` on `c` with its last bit flipped. With two
   entries, the second a `Dec` answer `⟨v, m'⟩`, it outputs `¬ m'_{n-1}`. It is polynomial-time
   (`NUPPT.ofPolyTimeUniform`).
2. In `IND_b` the challenge is `c = ⟨r, b^n ⊕ f_k(r)⟩`. For `n > 0` its last bit lies in the
   second component, so the flipped string `c'` is `⟨r, b^n ⊕ e_{n-1} ⊕ f_k(r)⟩`: well-formed,
   and not `c`. CCA2's `Dec` answers `⟨1, b^n ⊕ e_{n-1}⟩` (`runAt_prfDec`).
3. So `A` outputs `b` with probability `1`, and the advantage is `|0 − 1| = 1`. -/
theorem prfFixedScheme_not_cca2 :
    ∃ (A : NUPPT) (q : PolyExpr), ∀ n, 0 < n →
      advantage ((prfFixedScheme F E hE hFE).indGame .cca2 A (q.eval n) false n)
        ((prfFixedScheme F E hE hFE).indGame .cca2 A (q.eval n) true n) = 1 := by
  sorry

/-- **The §3.9 scheme is not CCA2-secure** in the sense of Definition 168.1: an advantage equal
to `1` at every positive `n` is not negligible (Claim 169.a). -/
theorem not_prfFixedScheme_cca2 : ¬ (prfFixedScheme F E hE hFE).INDSecure .cca2 := by
  intro h
  rw [FixedLengthScheme.INDSecure_iff] at h
  obtain ⟨A, q, hA⟩ := prfFixedScheme_not_cca2 F E hE hFE
  obtain ⟨ε, hε, hle⟩ := h A q
  rw [negligible_iff] at hε
  obtain ⟨n₀, hn₀⟩ := hε 0
  have h1 := hn₀ (n₀ + 1) (by omega)
  have h2 := hle (n₀ + 1)
  rw [hA (n₀ + 1) (by omega)] at h2
  simp only [pow_zero, div_one] at h1
  linarith [le_abs_self (ε (n₀ + 1))]

end TCSlib.Cryptography.Composability
/- G06-HARNESS EOF-VERIFY PRFSchemeSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "PRFSchemeSeal"
  let payload : String := "TCSlib.Cryptography.MultiMsg.adviceBound\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.blockMapFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.dropPolyFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.encodeHist_eq_flatMap.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.flatMap_const_replicate.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.flatMap_const_singleton.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.flatMap_range_blocks.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.histBlock\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.histBlockLen\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.length_flatMap_of_length.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.length_flatten_of_length.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.maskBlock\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.maskOf\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postAns\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postBudget\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postCount\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postHist\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postOffset\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postPoints\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postQuery\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.postVerdict\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.preFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.takePolyFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.zipWith_xor_dbl.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.zipWith_xor_flatten_ofFn.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.MultiMsg.zipWith_xor_replicate_false.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.ReductionMachine\nTCSlib.Cryptography.boundedBy_chainTree.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree._sunfold\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree._unsafe_rec\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.chainTree.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.encodeTuple\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.eval_chainTree.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.exists_multiMessageSecure_of_exists_prg.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.exists_multiMessageSecure_of_prf.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.multiMsgAdv\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.otpEnc\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.prfDecFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfDecWF\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfEncFun\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfEncReal\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid\nTCSlib.Cryptography.prfScheme\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\nTCSlib.Cryptography.prfScheme_coinsEquiv\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.encodeList_eq_flatMap.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.zipWith_xor_xor_self.match_1_1\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid.0.TCSlib.Cryptography.chainTree.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid"
  let expectedRequests : Nat := 47
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.MultiMsg.adviceBound\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"adviceBound\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.blockMapFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"blockMapFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.dropPolyFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"dropPolyFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.encodeHist_eq_flatMap.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"encodeHist_eq_flatMap\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.flatMap_const_replicate.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"flatMap_const_replicate\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.flatMap_const_singleton.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"flatMap_const_singleton\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.flatMap_range_blocks.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"flatMap_range_blocks\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.histBlock\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"histBlock\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.histBlockLen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"histBlockLen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.length_flatMap_of_length.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"length_flatMap_of_length\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.length_flatten_of_length.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"length_flatten_of_length\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.maskBlock\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"maskBlock\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.maskOf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"maskOf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postAns\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postAns\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postBudget\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postBudget\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postCount\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postCount\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postHist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postHist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postOffset\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postOffset\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postPoints\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postPoints\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postQuery\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postQuery\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.postVerdict\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"postVerdict\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.preFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"preFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.takePolyFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"takePolyFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.MultiMsg.zipWith_xor_dbl.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"zipWith_xor_dbl\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.zipWith_xor_flatten_ofFn.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"zipWith_xor_flatten_ofFn\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.MultiMsg.zipWith_xor_replicate_false.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"MultiMsg\"],[\"str\",\"zipWith_xor_replicate_false\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"ReductionMachine\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.boundedBy_chainTree.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"boundedBy_chainTree\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.chainTree\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.chainTree._sunfold\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"_sunfold\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.chainTree._unsafe_rec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"_unsafe_rec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.chainTree.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.encodeTuple\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"encodeTuple\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.eval_chainTree.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"eval_chainTree\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.exists_multiMessageSecure_of_exists_prg.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"exists_multiMessageSecure_of_exists_prg\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.exists_multiMessageSecure_of_prf.match_1_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"exists_multiMessageSecure_of_prf\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.multiMsgAdv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multiMsgAdv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.otpEnc\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"otpEnc\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfDecFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfDecFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfDecWF\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfDecWF\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfEncFun\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfEncFun\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfEncReal\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfEncReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfScheme\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfScheme\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.prfScheme_coinsEquiv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"prfScheme_coinsEquiv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\tfalse\tfalse\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.encodeList_eq_flatMap.match_1_1\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"encodeList_eq_flatMap\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.0.TCSlib.Cryptography.zipWith_xor_xor_self.match_1_1\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"zipWith_xor_xor_self\"],[\"str\",\"match_1_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"]]\tfalse\ttrue\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.FromPRF.Hybrid.0.TCSlib.Cryptography.chainTree.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"chainTree\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"FromPRF\"],[\"str\",\"Hybrid\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

