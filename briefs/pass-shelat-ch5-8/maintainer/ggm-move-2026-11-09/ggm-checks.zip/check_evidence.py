"""Verify the replay and reconcile the whole-file seals with the cleanup ledger."""
from collections import Counter
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))
prefix = "TCSlib/Cryptography/"
paths = campaign / "briefs/pass-shelat-ch5-8/maintainer"
ledger_dir = paths / "cleanup-incremental-2026-11-09/final-r1"
native = area / "native"
meta = area / "metadata"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def content(rev, path):
    return git("show", f"{rev}:{path}")


def normalize(text):
    return re.sub(r"\?m\.\d+", "?m", text)


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source = read(area / "SOURCE-CHECK.json")
assert result["passed"] and plan["head"] == result["head"] == source["head"] == head
assert plan["base"] == result["base"] == source["base"] == base
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == len(plan["affected"]) == 30
assert result["initial_retained"] == len(plan["retained"]) == 1069
assert len(products) == len(plan["order"]) == 1099 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checked = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checked[row["module"]] = row["object_sha256"]
assert checked == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain")
assert not git("diff", "--check", base, head)
assert "1 findings in 11 files" in (area / "style.log").read_text()
assert "1 findings in 4 files" in (area / "style-base.log").read_text()
declarations = read(area / "DECLARATIONS.json")
assert declarations["head"] == head and declarations["base"] == base and declarations["axioms_match"]
assert declarations["matched_declarations"] == 378 and source["proof_and_definition_code_preserved"]

diagnostics, receipts = {}, {}
for side, rev in (("base", base), ("head", head)):
    directory = meta / (side + "-seals")
    scope = read(directory / "SCOPE.json")
    labels = set(scope) | ({"UnsealedControl"} if side == "head" else set())
    assert {p.stem for p in directory.glob("*.rc")} == labels
    diag = []
    receipts[side] = {}
    for label in sorted(labels):
        path = directory / label
        log = path.with_suffix(".log").read_text()
        count = scope.get(label, 0)
        manifest = read(path.with_suffix(".json")) if label in scope else {}
        if count:
            assert count == len(manifest["requests"])
            assert sha(path.with_suffix(".lean")) == manifest["probe_sha256"]
            assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
            assert len({(r["home"], r["spelling"]) for r in manifest["requests"]}) == count
        pattern = r"\.lean:(\d+):(\d+): error: (.*?)(?=\n(?:G06-|[^\n]*\.lean:\d+:\d+:)|\Z)"
        errors = re.findall(pattern, log, flags=re.S)
        assert len(errors) == len(re.findall(r"\.lean:\d+:\d+: error:", log))
        rc = int(path.with_suffix(".rc").read_text())
        assert rc == int(bool(errors))
        if label.endswith("Seal"):
            source_path = manifest["source_path"]
            raw = content(rev, source_path)
            assert sha256(raw).hexdigest() == manifest["source_sha256"]
            lines = raw.decode().splitlines()
            mapping = {r["probe_line"]: r["source_line"] for r in manifest["line_map"]}
            assert sorted(mapping.values()) == list(range(1, len(lines) + 1))
            for probe_line, col, msg in errors:
                line = mapping[int(probe_line)]
                diag.append({"path": source_path, "line": line, "source": lines[line-1],
                             "column": int(col), "message": msg.rstrip()})
        elif label == "SealedControl":
            assert len(errors) == 1 and "rfl" in errors[0][2] and "GGMRed.histEnc" in errors[0][2]
        else:
            assert not errors
        receipts[side][label] = {"requests_verified": count, "errors": len(errors), "rc": rc,
                                 "probe_sha256": sha(path.with_suffix(".lean")),
                                 "log_sha256": sha(path.with_suffix(".log")),
                                 "source_sha256": manifest.get("source_sha256")}
    diagnostics[side] = diag
moves = source["moves"]
homes = {old.replace("/", "."): new.replace("/", ".") for old, new in moves.items()}
declmap = {r["old_name"]: r["new_name"] for r in declarations["declarations"]}
assert len(diagnostics["base"]) == len(diagnostics["head"]) == 13
line_offsets = {}
for old, new in moves.items():
    before = content(base, old + ".lean").decode()
    after = content(head, new + ".lean").decode()
    marker = "namespace TCSlib.Cryptography"
    line_offsets[old + ".lean"] = after[:after.index(marker)].count("\n") - before[:before.index(marker)].count("\n")

archive = ledger_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (ledger_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
observations = ledger["current_observations"]
assert len(observations) == 813 and not ledger["partial"] and not ledger["needs_review"]
owned = [r for r in observations if (r.get("current_owner") or r["path"]) in line_offsets]
assert {r["id"] for r in owned} == {f"SEAL-{n:04}" for n in range(207, 220)} | {"C3-0002", "C3-0003"}

remaining_base = diagnostics["base"].copy()
remaining_head = diagnostics["head"].copy()
seal_rows = []
for r in owned:
    if r["channel"] != "whole-file-seal":
        continue
    old_path, old_line = r["current_owner"], r["head_line"]
    matches = [d for d in remaining_base if d["path"] == old_path and d["line"] == old_line and
               d["column"] == r["column"] and normalize(d["message"]) == normalize(r["head_error"])]
    assert len(matches) == 1, (r["id"], matches)
    old = matches[0]
    remaining_base.remove(old)
    new_path = moves[old_path[:-5]] + ".lean"
    new_line = old_line + line_offsets[old_path]
    msg = normalize(old["message"])
    for before, after in homes.items():
        msg = msg.replace("_private." + before + ".", "_private." + after + ".")
    hits = [d for d in remaining_head if d["path"] == new_path and d["line"] == new_line and
            d["source"] == old["source"] and d["column"] == old["column"] and normalize(d["message"]) == msg]
    assert len(hits) == 1, (r["id"], old, hits)
    new = hits[0]
    remaining_head.remove(new)
    seal_rows.append({"id": r["id"], "disposition": "same_proof_step_new_home",
                      "before": old, "after": new})
assert not remaining_base and not remaining_head

eq_rows = {}
for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 2\n" in log
    assert "where the seal failed: 0 " in log
    rows = [tuple(line.split("\t")) for line in log.splitlines() if not line.startswith("#")]
    assert len(rows) == 2 and all(len(r) == 6 for r in rows)
    eq_rows[side] = set(rows)
equations = []
for r in owned:
    if r["channel"] != "generated-equation":
        continue
    mod = r["path"][:-5].replace("/", ".")
    before = (mod, r["name"], r["provider"], r["reference"], r["provider_home"], r["reference_home"])
    after = (homes[mod], declmap[r["name"]], declmap[r["provider"]], declmap[r["reference"]],
             homes[r["provider_home"]], homes[r["reference_home"]])
    eq_rows["base"].remove(before)
    eq_rows["head"].remove(after)
    equations.append({"id": r["id"], "before": before, "after": after,
                      "kind": r["kind"], "disposition": "same_generated_reference_new_home"})
assert not eq_rows["base"] and not eq_rows["head"]

providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"]) for r in declarations["declarations"]
             if r["kind"] == "def"}
links = []
for r in observations:
    refs = {(p["home"], p["spelling"]) for p in r.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in r.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if r["channel"] == "generated-equation":
        refs.add((r["provider_home"], r["provider"]))
    if r["channel"] == "explicit-source":
        refs.add((r["head"]["provider_home"], r["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": r["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})
assert len(links) == 34 and len({row["id"] for row in links}) == 11

before, after = ({tuple(r) for r in read(area / f"campaign-lint-{side}.json")} for side in ("base", "head"))
assert {r for r in before if r[0] == "FAIL"} == {r for r in after if r[0] == "FAIL"}
warn_names = lambda rs: {name.strip() for level, _, msg in rs if level == "WARN" and "(check 8):" in msg
                         for name in msg.split("(check 8):", 1)[-1].split(",")}
assert warn_names(before) == warn_names(after)
size = {}
for rev, path in ((base, prefix + "Asymptotic/GGMReduction.lean"),
                  (head, prefix + "Pseudorandom/Functions/Asymptotic/GGM/Reduction.lean")):
    size[rev] = {"path": path, "lines": len(content(rev, path).decode().splitlines())}
assert [r["lines"] for r in size.values()] == [1104, 1103]
for log_name, rev in (("style-base.log", base), ("style.log", head)):
    log = (area / log_name).read_text()
    hits = [line for line in log.splitlines() if line.startswith("TCSlib/")]
    assert len(hits) == 1 and hits[0].startswith(size[rev]["path"] + ":") and "must split" in hits[0]

save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": receipts,
                           "baseline_diagnostics": 13, "head_diagnostics": 13, "new_diagnostics": 0,
                           "size_finding_relocation": size, "new_campaign_failures": 0, "new_reader_warnings": 0})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                           "ledger_archive_sha256": archive_sha, "moved_seal_diagnostics": seal_rows,
                           "moved_generated_references": equations, "relocated_provider_links": links,
                           "explicit_foreign_definition_reads": {"base": 0, "head": 0}})
print("30 affected modules pass. All 13 seal diagnostics, two generated references, and 34 provider links map to the new homes.")
