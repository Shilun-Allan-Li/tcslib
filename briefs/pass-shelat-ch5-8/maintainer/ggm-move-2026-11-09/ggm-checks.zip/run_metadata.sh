#!/usr/bin/env bash
set -euo pipefail
a=$1
w=$2
side=$3
m="$a/metadata"
lower=$(printf '%s' "$side" | tr '[:upper:]' '[:lower:]')
lean=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$a/native/PLAN.json")
tree="$m/$lower/oleans"
if [[ $side == Head ]]; then
  index=$(python3 -I - "$a/native/PLAN.json" <<'PY'
import json,sys
p=json.load(open(sys.argv[1]))
print("%04d" % (p["rebuild"].index("TCSlib/Cryptography/Asymptotic/PRF") + 1))
PY
  )
  while true; do
    receipt=$(find "$a/native" -maxdepth 2 -name "check-$index.json" -print -quit)
    if [[ -n $receipt ]]; then
      python3 -I - "$receipt" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r["rc"]==0 and r["module"]=="TCSlib/Cryptography/Asymptotic/PRF"
PY
      break
    fi
    if find "$a/native" -name 'FAILED.json' | grep -q .; then exit 1; fi
    sleep 4
  done
  python3 -I "$a/prepare_probes.py" "$a" Head
  bash "$a/run_probes.sh" "$lean" "$tree" "$m/HeadCensus" "$m/GGMStandalone" "$m/EvaluatorStandalone" \
    "$m/ReductionStandalone" "$m/RunStandalone"
else
  test "$(cat "$m/BaseCensus.rc")" -eq 0
fi
bash "$a/run_probes.sh" "$lean" "$tree" "$m/${side}GGMLegacy" "$m/${side}EvaluatorLegacy" \
  "$m/${side}ReductionLegacy" "$m/${side}RunLegacy"
python3 -I "$a/prepare_seals.py" "$a" "$w" "$side"
target="$m/$lower-seals"
if [[ $side == Base ]]; then
  bash "$a/run_probes.sh" "$lean" "$tree" "$target/PRFSeal" "$target/PRFLemmasSeal" \
    "$target/GGMReductionSeal" "$target/GGMReductionEvalSeal"
else
  bash "$a/run_probes.sh" "$lean" "$tree" "$target/GGMSeal" "$target/EvaluatorSeal" "$target/ReductionSeal" "$target/RunSeal" \
    "$target/UnsealedControl" "$target/SealedControl" "$target/ReaderControl"
fi
