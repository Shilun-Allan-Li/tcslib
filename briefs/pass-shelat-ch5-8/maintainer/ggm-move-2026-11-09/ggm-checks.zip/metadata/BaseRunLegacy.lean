import TCSlib.Cryptography.Asymptotic.GGMReductionEval

#check @TCSlib.Cryptography.GGMRed.ggmRedMachine
#check @TCSlib.Cryptography.GGMRed.ggmRedMachine_coinsEquiv
#check @TCSlib.Cryptography.GGMRed.ggmRedMachine_distinguisher
