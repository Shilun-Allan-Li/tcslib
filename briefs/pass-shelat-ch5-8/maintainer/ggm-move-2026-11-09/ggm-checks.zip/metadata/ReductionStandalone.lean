import TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM.Reduction

#check @TCSlib.Cryptography.GGMRed.histEnc
#check @TCSlib.Cryptography.GGMRed.queryOf
#check @TCSlib.Cryptography.GGMRed.buildTreeQ
