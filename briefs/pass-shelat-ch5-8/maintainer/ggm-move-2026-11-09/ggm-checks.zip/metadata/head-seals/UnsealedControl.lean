import TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM

open TCSlib.Cryptography Turing

example {ℓ₁ ℓ₂ : ℕ} (h : List ((Fin ℓ₁ → Bool) × (Fin ℓ₂ → Bool))) :
    GGMRed.histEnc h =
      h.foldr (fun p acc => pairEncode (pairEncode (List.ofFn p.1) (List.ofFn p.2)) acc) [] :=
  rfl
