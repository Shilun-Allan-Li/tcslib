import TCSlib.Cryptography.Asymptotic.PRF

#check @TCSlib.Cryptography.ggmPRF
#check @TCSlib.Cryptography.ggmPRF_prf
#check @TCSlib.Cryptography.exists_prf_of_exists_prg
#check @TCSlib.Cryptography.exists_ggmBitsDist_nuppt
#check @TCSlib.Cryptography.encodeHist_eq_histEnc
#check @TCSlib.Cryptography.PRF
#check @TCSlib.Cryptography.OracleEnsemble.Indist
