## Changes

- Put the GGM construction and `exists_prf_of_exists_prg` in `Pseudorandom.Functions.Asymptotic.GGM`.
- Put the evaluator in `GGM.Evaluator`, the lazy table, lookup loop and reduction time bounds in `GGM.Reduction`, and the machine and its run agreement in `GGM.Run`. The evaluator uses shared reduction support and the finite GGM development, giving the new route an import graph independent of the hard-core construction.
- Keep the four legacy import paths as compatibility modules. Both pseudorandomness facades export the new layout.

## Verification

All 30 affected modules pass, including the library root and campaign Checks. The Lean declarations and proof bodies moved verbatim. The census matches all 378 declaration types, definition values and axiom sets after normalizing relocated private names and generated binder scopes. The four standalone imports agree with the legacy imports.

The seals reproduce the same 13 inherited diagnostics at the relocated proof steps. The two inherited generated references follow their matcher to its new home. The control blocks direct reduction of `GGMRed.histEnc` and accepts `GGMRed.histEnc_eq` under the same mask.

The style checks carry forward the reduction's existing size finding. The lazy table, guarded state loop and polynomial-time proof stay together in their existing proof file, which is one line shorter after relocation. The campaign lint adds no reader warnings or facade findings.
