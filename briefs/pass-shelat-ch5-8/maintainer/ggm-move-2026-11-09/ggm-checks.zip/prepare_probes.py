"""Copy checked imports into a private tree and generate declaration and import probes."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area, side = Path(sys.argv[1]).resolve(), sys.argv[2]
previous = area.parent / "prf-contracts-move-20261109"
native = previous / "native-r3" if side == "Base" else area / "native"
assert side in {"Base", "Head"}
meta = area / "metadata"
out = meta / side.lower() / "oleans"
plan = json.loads((native / "PLAN.json").read_bytes())
prefix = "TCSlib.Cryptography."
old = prefix + "Asymptotic."
prf = old + "PRF"
ggm = prefix + "Pseudorandom.Functions.Asymptotic.GGM"
owners = ([old + name for name in ("PRF", "PRFLemmas", "GGMReduction", "GGMReductionEval")]
          if side == "Base" else [ggm, ggm + ".Evaluator", ggm + ".Reduction", ggm + ".Run"])


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


if side == "Base":
    products = read(native / "PRODUCTS.json")
else:
    products = dict(plan["retained"])
    for path in sorted(native.glob("run-*/check-*.json")):
        try:
            row = read(path)
        except json.JSONDecodeError:
            continue
        if row["rc"] == 0:
            assert row["head"] == plan["head"]
            assert sha(path.with_suffix(".log")) == row["log_sha256"]
            products[row["module"]] = row
pending = [prf.replace(".", "/")]
needed = set()
while pending:
    module = pending.pop()
    if module not in needed:
        needed.add(module)
        pending.extend(plan["graph"][module])
assert needed <= products.keys(), sorted(needed - products.keys())
assert set(owner.replace(".", "/") for owner in owners) <= needed
out.mkdir(parents=True)
tree = Path(plan["tree"])
for module in sorted(needed):
    row = products[module]
    assert row["source_sha256"] == plan["source_digests"][module], module
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}, module
    copy(tree / (module + ".olean"), out / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(tree):
        copy(src, out / src.relative_to(tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
(out / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

program = (previous / "metadata-r3/HeadCensus.lean").read_text()
beg = program.index("  let owners : Array Name :=")
end = program.index("\n", beg)
program = program[:beg] + "  let owners : Array Name := #[" + ", ".join(chr(96) + name for name in owners) + "]" + program[end:]
start = program.index('  let file ← IO.FS.Handle.mk "')
end = program.index("\n", start)
program = program[:start] + f'  let file ← IO.FS.Handle.mk "{meta / (side + ".jsonl")}" .write' + program[end:]
program = program.replace("Oracle and PRF contract census complete", "GGM declaration census complete")
(meta / (side + "Census.lean")).write_text(program)

routes = (
    ("GGM", prf, ggm, ("ggmPRF", "ggmPRF_prf", "exists_prf_of_exists_prg", "exists_ggmBitsDist_nuppt",
                       "encodeHist_eq_histEnc", "PRF", "OracleEnsemble.Indist")),
    ("Evaluator", old + "PRFLemmas", ggm + ".Evaluator", ("ggmEval", "ggmEval_poly", "ggmEval_ofFn")),
    ("Reduction", old + "GGMReduction", ggm + ".Reduction", ("GGMRed.histEnc", "GGMRed.queryOf",
                   "GGMRed.buildTreeQ")),
    ("Run", old + "GGMReductionEval", ggm + ".Run", ("GGMRed.ggmRedMachine",
            "GGMRed.ggmRedMachine_coinsEquiv", "GGMRed.ggmRedMachine_distinguisher")),
)
for label, before, after, names in routes:
    source = "\n".join("#check @" + prefix + name for name in names) + "\n"
    (meta / (side + label + "Legacy.lean")).write_text("import " + before + "\n\n" + source)
    if side == "Head":
        (meta / (label + "Standalone.lean")).write_text("import " + after + "\n\n" + source)
print(f"Copied {len(needed)} verified {side.lower()} module objects for the probes.", flush=True)
