"""Relocate the GGM construction and its three existing proof owners."""
from difflib import unified_diff
from pathlib import Path
import sys

root, area = (Path(p).resolve() for p in sys.argv[1:3])
crypt = "TCSlib/Cryptography/"
legacy = crypt + "Asymptotic/"
funcs = crypt + "Pseudorandom/Functions"
ggm = funcs + "/Asymptotic/GGM"
evaluator, reduction, run = (ggm + "/" + name for name in ("Evaluator", "Reduction", "Run"))
old_eval, old_red, old_run, old_prf = (legacy + name for name in ("PRFLemmas", "GGMReduction", "GGMReductionEval", "PRF"))


def read(module):
    return (root / (module + ".lean")).read_text()


def replace(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


def mod(path):
    return path.replace("/", ".")


def imports(modules):
    return "".join(f"import {mod(p)}\n" for p in modules)


source = {name: read(name) for name in (old_eval, old_red, old_run, old_prf)}
license = source[old_eval].split("import ", 1)[0]
opts = source[old_eval].split("set_option", 1)[1].split("/-!", 1)[0]
opts = "set_option" + opts
assert all(s.startswith(license) for s in source.values())


def replace_imports(text, modules):
    end = text.index("set_option")
    return license + imports(modules) + "\n" + text[end:]


def compatibility(modules, title, purpose):
    return (license + imports(modules) + "\n" + opts + f""" /-!
# {title}

{purpose}

## Contents

""" .lstrip() + "".join(f"* `{mod(module)}`\n" for module in modules) + """
## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §3.8, Theorem 97.3.
-/
""")


out = {
    evaluator: replace_imports(source[old_eval], [
        "TCSlib/Complexity/Randomized/Repetition", legacy + "ReductionSupport", funcs + "/GGM",
    ]),
    reduction: replace_imports(source[old_red], ["TCSlib/Complexity/ClassP/BinaryArith/Loops", evaluator]),
    run: replace_imports(source[old_run], [reduction]),
    ggm: replace_imports(source[old_prf], [
        funcs + "/Asymptotic/Defs", evaluator, reduction, run,
        crypt + "Pseudorandom/Generators/Asymptotic/Stretch",
    ]),
    old_eval: compatibility([legacy + "HardCore", evaluator], "Compatibility import for the GGM evaluator",
        "The evaluator, its polynomial running time, and the bit-string identities\n"
        "live in `Pseudorandom.Functions.Asymptotic.GGM.Evaluator`."),
    old_red: compatibility([old_eval, reduction], "Compatibility import for the GGM reduction",
        "The reduction's lazy table, lookup loop, machine components, and time bounds\n"
        "live in `Pseudorandom.Functions.Asymptotic.GGM.Reduction`."),
    old_run: compatibility([old_red, run], "Compatibility import for the GGM machine run",
        "The reduction machine and its agreement with the finite distinguisher\n"
        "live in `Pseudorandom.Functions.Asymptotic.GGM.Run`."),
    old_prf: compatibility([old_run, ggm], "Compatibility import for the asymptotic PRF construction",
        "The oracle and PRF contracts and the GGM construction are available\n"
        "through `Pseudorandom.Functions.Asymptotic.GGM`."),
}
out[evaluator] = replace(out[evaluator],
    "implementation to the finite GGM construction. The old import also provides\n"
    "PRG truncation through `Pseudorandom.Generators.Asymptotic.Stretch`.",
    "implementation to the finite GGM construction.")
out[reduction] = replace(out[reduction],
    "`TCSlib.Cryptography.Asymptotic.PRF` wraps it into",
    "`Pseudorandom.Functions.Asymptotic.GGM` wraps it into")
out[reduction] = replace(out[reduction],
    "`TCSlib.Cryptography.Asymptotic.PRFLemmas`",
    "`Pseudorandom.Functions.Asymptotic.GGM.Evaluator`")
out[reduction] = replace(out[reduction],
    "history of the text's tree is `buildTree` of `TCSlib.Cryptography.Asymptotic.PRF`; this file\n"
    "uses the equivalent `Option`-valued form `buildTreeQ` (no `OracleMove`), identified with\n"
    "`buildTree` in `PRF.lean`.",
    "contract tree `buildTree` is in `Pseudorandom.Functions.Asymptotic.Defs`. The construction\n"
    "proves agreement with the `Option`-valued tree `buildTreeQ` used here.")
out[reduction] = replace(out[reduction], "`TCSlib.Cryptography.Asymptotic.GGMReductionEval`.",
    "`Pseudorandom.Functions.Asymptotic.GGM.Run`.")
out[reduction] = replace(out[reduction], "`encodeHist` of `TCSlib.Cryptography.Asymptotic.PRF`",
    "`encodeHist` of `Pseudorandom.Functions.Asymptotic.Defs`")
out[run] = replace(out[run], "`TCSlib.Cryptography.Asymptotic.GGMReduction`",
    "`Pseudorandom.Functions.Asymptotic.GGM.Reduction`")
out[run] = replace(out[run],
    "text is `buildTree` of `TCSlib.Cryptography.Asymptotic.PRF`; this file uses the equivalent\n"
    "`Option`-valued form `buildTreeQ`, identified with `buildTree` in `PRF.lean`.",
    "text is `buildTree` of `Pseudorandom.Functions.Asymptotic.Defs`. The construction proves\n"
    "agreement with the `Option`-valued tree `buildTreeQ` used here.")
out[ggm] = replace(out[ggm],
    "The evaluator uses `Asymptotic.PRFLemmas`. The reduction machine and its run\n"
    "agreement are in `Asymptotic.GGMReduction` and `Asymptotic.GGMReductionEval`.\n"
    "The finite level and query hybrids come from [Gar26, Theorem 3.3].",
    "The finite level and query hybrids come from [Gar26, Theorem 3.3].")
out[ggm] = replace(out[ggm], "## References\n", """## Contents

* `GGM.Evaluator` gives the polynomial-time tree walk and its bit-string identities.
* `GGM.Reduction` gives the lazy table, lookup loop, and the time bound for the reduction.
* `GGM.Run` packages the machine and proves agreement with the finite distinguisher.

## References
""")
new_ggm_modules = [ggm, evaluator, reduction, run]
defs_import = imports([funcs + "/Asymptotic/Defs"])
f = read(funcs)
f = replace(f, defs_import, defs_import + imports(new_ggm_modules))
f = replace(f, "* `Functions/Asymptotic/Defs.lean` gives the oracle ensemble and PRF contracts.\n",
    "* `Functions/Asymptotic/Defs.lean` gives the oracle ensemble and PRF contracts.\n"
    "* `Functions/Asymptotic/GGM.lean` proves the asymptotic PRG-to-PRF implication.\n"
    "* `Functions/Asymptotic/GGM/Evaluator.lean` implements the tree walk.\n"
    "* `Functions/Asymptotic/GGM/Reduction.lean` implements the lazy table and reduction.\n"
    "* `Functions/Asymptotic/GGM/Run.lean` gives the machine and its run agreement.\n")
out[funcs] = f
pseudorandom = crypt + "Pseudorandom"
p = read(pseudorandom)
p = replace(p, defs_import, defs_import + imports(new_ggm_modules))
p = replace(p, "* `Functions.Asymptotic.Defs` gives the asymptotic oracle and PRF contracts.\n",
    "* `Functions.Asymptotic.Defs` gives the asymptotic oracle and PRF contracts.\n"
    "* `Functions.Asymptotic.GGM` proves the PRG-to-PRF implication, with its evaluator\n"
    "  and reduction machine in the child modules.\n")
p = replace(p, "  defines the oracle and PRF contracts. `TCSlib.Cryptography.Asymptotic.PRF` gives\n"
    "  the GGM construction", "  defines the oracle and PRF contracts.\n"
    "  `TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.GGM` gives the construction")
out[pseudorandom] = p
asymptotic = crypt + "Asymptotic"
out[asymptotic] = replace(read(asymptotic),
    "* `PRF` — oracle ensembles, pseudorandom functions and the GGM construction\n"
    "  [PS10, Definitions 96.1, 96.2; Theorem 97.3].",
    "* `PRF` re-exports the oracle and PRF contracts and the construction in\n"
    "  `Pseudorandom.Functions.Asymptotic.GGM` [PS10, Definitions 96.1, 96.2 and Theorem 97.3].")
for name, (definition, result) in {'PRF': ('`PRF` and `ggmPRF` give the security contract and construction.', '`ggmPRF_prf` and `exists_prf_of_exists_prg` give security and existence.'), 'PRFLemmas': ('`ggmEval` is the bit-string evaluator.', '`ggmEval_poly` and `ggmEval_ofFn` give its time bound and correctness.'), 'GGMReduction': ('`GGMRed.lookup` and `GGMRed.rawFun` implement the reduction.', '`GGMRed.lookup_poly` and `GGMRed.rawFun_poly` give the time bounds.'), 'GGMReductionEval': ('`GGMRed.ggmRedMachine` is the non-uniform reduction machine.', '`GGMRed.ggmRedMachine_distinguisher` gives its run agreement.')}.items():
    module = legacy + name
    out[module] = replace(out[module], "## Contents\n",
        f"## Main definitions\n\n{definition}\n\n## Main results\n\n{result}\n\n## Contents\n")
patch = []
for module, text in sorted(out.items()):
    path = module + ".lean"
    exists = (root / path).is_file()
    before = read(module) if exists else ""
    assert text != before and text.endswith("\n")
    patch.extend(unified_diff(before.splitlines(True), text.splitlines(True),
                              fromfile="a/" + path if exists else "/dev/null", tofile="b/" + path))
    print(f"{len(text.splitlines()):4} {path}")
(area / "move.patch").write_text("".join(patch))
