"""Verify the merged predecessor and stage the exact new import graph."""
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
tools = area.parent / "cleanup-incremental-20261108/tools"
previous = area.parent / "prf-contracts-move-20261109/native-r3"
published = (campaign / "briefs/pass-shelat-ch5-8/maintainer/prf-contracts-move-2026-11-09"
             / "VERIFICATION.json")
out = area / "native"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location("campaign_import_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
base, head = ((area / f"{side}.txt").read_text().strip() for side in ("base", "head"))
prefix = "TCSlib/Cryptography/"
asym = prefix + "Asymptotic"
legacy = {n: asym + "/" + n for n in ("PRF", "PRFLemmas", "GGMReduction", "GGMReductionEval")}
pseudo = prefix + "Pseudorandom"
funcs = pseudo + "/Functions"
ggm = funcs + "/Asymptotic/GGM"
ev, red, run = (ggm + "/" + name for name in ("Evaluator", "Reduction", "Run"))
moves = dict(zip(legacy.values(), (ggm, ev, red, run)))
owners = set(moves.values())
changed = owners | set(legacy.values()) | {asym, pseudo, funcs}
checks = "audits/pass-shelat/Checks"



def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def clean_git(*args):
    return git(*args).decode().strip()


def copy(src, dst, digest):
    assert sha(src) == digest, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == digest and not dst.samefile(src), dst


def put(path, data):
    with path.open("x") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def show(revision, module):
    return git("show", f"{revision}:{module}.lean")


assert clean_git("rev-parse", "HEAD") == head and clean_git("rev-parse", "HEAD^") == base
assert not clean_git("status", "--porcelain")
assert not clean_git("diff", "--check", base, head)
assert {s[:-5] for s in clean_git("diff", "--name-only", base, head).splitlines()} == changed
old = read(previous / "PLAN.json")
products = read(previous / "PRODUCTS.json")
checked = read(previous / "RESULT.json")
receipt = read(published)
assert checked["passed"] and receipt["passed"] and checked["head"] == receipt["head"] == old["head"]
assert receipt["head"] == clean_git("rev-parse", base + "^2") == (area / "accepted-268.txt").read_text().strip()
for artifact in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / artifact) == receipt["artifact_sha256"]["native-r3/" + artifact], artifact
assert not clean_git("diff", "--name-only", old["head"], base, "--", "*.lean", "lean-toolchain",
                     "lake-manifest.json", "lakefile.lean", "lakefile.toml", "scripts/lean_check_tree.sh")
assert sha(Path(old["toolchain"])) == old["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == old["checker_sha256"]

sources = {
    path[:-5]: (root / path).read_bytes()
    for path in clean_git("ls-files", "--", "TCSlib", "TCSlib.lean", checks + ".lean").splitlines()
    if path.endswith(".lean")
}
assert old["source_digests"].keys() | owners <= sources.keys()
digests = {module: sha256(raw).hexdigest() for module, raw in sources.items()}
for module in sources.keys() - changed:
    baseline = old["source_digests"].get(module)
    if baseline is None:
        baseline = sha256(show(base, module)).hexdigest()
    assert digests[module] == baseline, module
imports = {
    module: [name.replace(".", "/") for name in graph.imports(raw)
             if name.replace(".", "/") in sources]
    for module, raw in sources.items()
}
stretch = pseudo + "/Generators/Asymptotic/Stretch"
expected = {
    ev: ["TCSlib/Complexity/Randomized/Repetition", asym + "/ReductionSupport", funcs + "/GGM"],
    red: ["TCSlib/Complexity/ClassP/BinaryArith/Loops", ev],
    run: [red],
    ggm: [funcs + "/Asymptotic/Defs", ev, red, run, stretch],
    legacy["PRFLemmas"]: [asym + "/HardCore", ev],
    legacy["GGMReduction"]: [legacy["PRFLemmas"], red],
    legacy["GGMReductionEval"]: [legacy["GGMReduction"], run],
    legacy["PRF"]: [legacy["GGMReductionEval"], ggm],
}
for mod, deps in expected.items():
    assert imports[mod] == deps, mod
for mod in (pseudo, funcs):
    assert [name for name in imports[mod] if name not in owners] == old["graph"][mod]
    assert [name for name in imports[mod] if name in owners] == [ggm, ev, red, run]
for mod in old["graph"].keys() - changed | {asym}:
    assert imports[mod] == old["graph"][mod], mod
order = graph.topo(imports, ["TCSlib", checks])
assert set(order) == set(old["order"]) | owners


def closure(mapping, module):
    return set(graph.topo(mapping, [module])) - {module}


for module in legacy.values():
    assert closure(old["graph"], module) <= closure(imports, module), module
refs = read(area / "BASE-REFERENCES.json")
for source, target in moves.items():
    dependencies = {name.replace(".", "/") for name in refs[source.replace("/", ".")]}
    assert {moves.get(dep, dep) for dep in dependencies} <= closure(imports, target)
narrow = closure(imports, ggm)
assert not any(n.startswith(asym + "/HardCore") or n.startswith(asym + "/GGM") or
               n.startswith(asym + "/PRF") or n.endswith("/Asymptotic/FromPermutation") for n in narrow)
assert {ev, red, run, stretch, funcs + "/Asymptotic/Defs"} <= narrow


def body(text):
    return text[text.index("namespace TCSlib.Cryptography"):]


for source, target in moves.items():
    before = body(show(base, source).decode())
    after = body(sources[target].decode())
    if target == red:
        old_link = "`encodeHist` of `TCSlib.Cryptography.Asymptotic.PRF`"
        assert before.count(old_link) == 1
        before = before.replace(old_link, "`encodeHist` of `Pseudorandom.Functions.Asymptotic.Defs`")
    assert before == after, (source, target)
for module in set(legacy.values()) | {asym, funcs, pseudo}:
    assert all(line.startswith(("import ", "set_option "))
               for line in graph.comments_removed(sources[module].decode()).splitlines() if line.strip())

affected = changed.copy()
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
rebuild = [module for module in order if module in affected]
assert {"TCSlib", checks} | owners <= affected
old_tree = Path(old["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
for module in order:
    if module in affected:
        continue
    row = products[module]
    assert digests[module] == row["source_sha256"]
    assert row["direct_local"] == {dep: retained[dep]["object_sha256"] for dep in imports[module]}, module
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {**row, "source": "verified_contract_tree"}
external = {}
for name, row in old["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        dest = tree / path.relative_to(old_tree)
        copy(path, dest, row["sha256"])
        path = dest
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": old["head"], "worktree": str(root), "tree": str(tree),
    "toolchain": old["toolchain"], "toolchain_sha256": old["toolchain_sha256"],
    "checker_sha256": old["checker_sha256"], "affected": sorted(affected), "rebuild": rebuild,
    "order": order, "retained": retained, "graph": {m: imports[m] for m in order},
    "external": external, "source_digests": digests,
}
put(out / "PLAN.json", plan)
put(area / "SOURCE-CHECK.json", {
    "base": base, "head": head, "baseline": old["head"], "changed_paths": sorted(changed),
    "new_owners": sorted(owners), "old_import_closures_preserved": sorted(legacy.values()),
    "ggm_import_closure": sorted(narrow), "moves": moves,
    "proof_and_definition_code_preserved": True,
    "affected_modules": len(affected), "retained_objects": len(retained),
    "external_objects": len(external), "predecessor_receipt_sha256": sha(published),
})
print(f"Sources match the verified #268 merge. {len(rebuild)} affected checks, "
      f"{len(retained)} verified transfers and {len(external)} external objects.", flush=True)
