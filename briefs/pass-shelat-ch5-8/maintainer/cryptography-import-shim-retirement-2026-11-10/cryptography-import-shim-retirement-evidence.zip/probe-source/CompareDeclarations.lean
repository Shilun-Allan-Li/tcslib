import Lean

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean

partial def stripMetadata (expr : Expr) : Expr :=
  expr.replace fun nested =>
    if nested.isMData then some (stripMetadata nested.mdataExpr!) else none

def equalTerm (left right : Expr) : Bool :=
  left.equal right || (stripMetadata left).equal (stripMetadata right)

def stripSorryLocations (expr : Expr) : Expr :=
  expr.replace fun nested => do
    let label ← Lean.Meta.isLabeledSorry? nested
    let origin ← label.module?
    let args := nested.getAppArgs
    let tag := args[2]!
    let originTag := toExpr origin.module
    let normalized := if tag.name?.isSome then originTag else mkApp tag.appFn! originTag
    return mkAppN nested.getAppFn (args.set! 2 normalized)

def equalApartFromSorryLocations (left right : ConstantInfo) : Bool :=
  match left, right with
  | .thmInfo a, .thmInfo b =>
    equalTerm (stripSorryLocations a.value) (stripSorryLocations b.value)
  | _, _ => false

def constantKind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def equalBody (left right : ConstantInfo) : Bool :=
  match left.value? (allowOpaque := true), right.value? (allowOpaque := true) with
  | some a, some b => equalTerm a b
  | none, none => true
  | _, _ => false

def sameMetadata (left right : ConstantInfo) : Bool :=
  left.levelParams == right.levelParams &&
  left.isUnsafe == right.isUnsafe && left.isPartial == right.isPartial &&
  left.hints == right.hints &&
  match left, right with
  | .defnInfo a, .defnInfo b => a.all == b.all
  | .thmInfo a, .thmInfo b => a.all == b.all
  | .opaqueInfo a, .opaqueInfo b => a.all == b.all
  | .inductInfo a, .inductInfo b =>
      a.numParams == b.numParams && a.numIndices == b.numIndices && a.all == b.all &&
      a.ctors == b.ctors && a.numNested == b.numNested && a.isRec == b.isRec &&
      a.isReflexive == b.isReflexive
  | .ctorInfo a, .ctorInfo b => a == b
  | .recInfo a, .recInfo b => a == b
  | _, _ => constantKind left == constantKind right

def readModule (tree : System.FilePath) (modulePath : String) : IO ModuleData := do
  return (← Lean.readModuleData (tree / (modulePath ++ ".olean"))).1

def compareModule (left right : ModuleData) (modulePath : String) : IO (Nat × Nat) := do
  unless left.isModule == right.isModule do
    throw <| IO.userError s!"Module system status changed: {modulePath}"
  unless left.extraConstNames.toList.mergeSort Name.quickLt ==
      right.extraConstNames.toList.mergeSort Name.quickLt do
    throw <| IO.userError s!"Generated name set changed: {modulePath}"
  let rightMap := right.constants.foldl (fun (m : Std.HashMap Name ConstantInfo) c =>
    m.insert c.name c) {}
  unless left.constants.size == right.constants.size do
    throw <| IO.userError s!"Declaration count changed: {modulePath}"
  let mut valuesDifferent := 0
  for c in left.constants do
    let some d := rightMap[c.name]? | throw <| IO.userError s!"Missing declaration: {c.name}"
    unless equalTerm c.type d.type && sameMetadata c d do
      throw <| IO.userError s!"Type or declaration metadata changed: {modulePath} {c.name}"
    unless equalBody c d do
      unless equalApartFromSorryLocations c d do
        throw <| IO.userError s!"Body changed: {modulePath} {constantKind c} {c.name}"
      IO.println s!"SORRY_LOCATION_ONLY {modulePath} {c.name}"
      valuesDifferent := valuesDifferent + 1
  return (left.constants.size, valuesDifferent)

def mainComparison (config : String) : IO Unit := do
  let params ← IO.FS.lines config
  let baseTree : System.FilePath := ⟨params[0]!⟩
  let headTree : System.FilePath := ⟨params[1]!⟩
  let retired := (← IO.FS.lines params[2]!).map fun file => file.dropRight 5
  let rebuilt ← IO.FS.lines params[3]!
  for path in retired do
    let old ← readModule baseTree path
    unless old.constants.isEmpty && old.extraConstNames.isEmpty do
      throw <| IO.userError s!"Retired module had declarations: {path}"
    if ← (headTree / (path ++ ".olean")).pathExists then
      throw <| IO.userError s!"Retired module object present: {path}"
    IO.println s!"RETIRED_EMPTY {path}"
  let mut count := 0
  let mut bodyDiffs := 0
  for path in rebuilt do
    let (n, diffs) ← compareModule (← readModule baseTree path) (← readModule headTree path) path
    count := count + n
    bodyDiffs := bodyDiffs + diffs
    IO.println s!"COMPARED {path} {n} {diffs}"
  IO.println s!"TOTAL {retired.size} retired modules, {rebuilt.size} matched modules, {count} declarations, {bodyDiffs} existing sorry locations shifted"
#eval mainComparison "/private/tmp/tcslib-shim-retirement.wBNelrDf/probe-config.txt"
