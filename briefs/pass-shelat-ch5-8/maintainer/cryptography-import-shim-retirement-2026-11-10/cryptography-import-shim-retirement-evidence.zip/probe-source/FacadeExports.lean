import Lean

set_option maxHeartbeats 0

open Lean

def moduleNameOf (s : String) : Name :=
  (s.splitOn ".").foldl Name.str .anonymous

unsafe def inspectFacades (config : String) : IO Unit := do
  let params ← IO.FS.lines config
  let tree : System.FilePath := ⟨params[0]!⟩
  Lean.searchPathRef.modify (tree :: ·)
  let roots ← IO.FS.lines params[1]!
  let retired ← IO.FS.lines params[2]!
  let output ← IO.FS.Handle.mk params[3]! .write
  let checks := [
    ("Asymptotic.HardCore", "goldreich_levin"),
    ("Asymptotic.HardCore", "goldreich_levin_coll"),
    ("Asymptotic.HardCore", "exists_owp_hardCore"),
    ("Asymptotic.HardCore", "exists_securePRG_of_owp"),
    ("Authentication.Defs", "Authentication.MAC"),
    ("Authentication.Defs", "Authentication.SignatureScheme"),
    ("Authentication.Defs", "Authentication.CRH"),
    ("Encryption.PrivateKey", "exists_securePRG_of_owp"),
    ("Encryption.PrivateKey", "Composability.FixedLengthScheme"),
    ("Candidates", "Candidates.elGamal_secure"),
    ("Encryption.PublicKey", "Candidates.elGamal_secure")
  ]
  for root in roots do
    Lean.withImportModules #[{ module := moduleNameOf root }] {} fun env => do
      let relevant := checks.filter fun (scope, _) => root == "TCSlib.Cryptography." ++ scope
      let availability := relevant.map fun (_, name) =>
        (name, env.contains (moduleNameOf ("TCSlib.Cryptography." ++ name)))
      let row := Json.mkObj [
        ("module", toJson root),
        ("imports", toJson (env.header.moduleNames.map (·.toString))),
        ("availability", toJson availability)]
      output.putStrLn row.compress
  let hits ← retired.filterM fun name => do
    try
      (← Lean.findOLean (moduleNameOf name)).pathExists
    catch _ =>
      return false
  output.putStrLn (Json.mkObj [("resolvable_retired", toJson hits)]).compress
#eval inspectFacades "/private/tmp/tcslib-shim-retirement.wBNelrDf/facade-config.txt"
