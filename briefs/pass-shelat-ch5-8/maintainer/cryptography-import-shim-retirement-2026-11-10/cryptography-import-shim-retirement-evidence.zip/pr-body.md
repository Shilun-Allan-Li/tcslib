Retire the 23 forwarding modules left by the cryptography reorganization, including `Composability.CCA2Scheme`. Redirect the in-tree imports and live source references to the modules that own the material.

Keep `Authentication.Defs` as the MAC, signature, and hash interface facade. Focus `Asymptotic.HardCore` on the Goldreich–Levin results for function families, collections, and balanced permutations. The permutation-to-PRG and stretch theorems have dedicated modules, and the existing public-key and private-key facades preserve the earlier permutation-to-PRG exports explicitly.

## Import migrations

Paths below are relative to `TCSlib.Cryptography`. Choose the replacement that owns the declarations you use.

| Retired module | Replacement |
| --- | --- |
| `Asymptotic.Encryption` | `Encryption.PrivateKey.FromPRG` (or Scheme and EnsembleSecurity for the interfaces) |
| `Asymptotic.GGMReduction` | `Pseudorandom.Functions.Asymptotic.GGM.Reduction` |
| `Asymptotic.GGMReductionEval` | `Pseudorandom.Functions.Asymptotic.GGM.Run` |
| `Asymptotic.HardCorePermutation` | `Asymptotic.HardCorePermutation.GoldreichLevin`, `Asymptotic.HardCoreClaims`, or `Pseudorandom.Generators.Asymptotic.FromPermutation` |
| `Asymptotic.MultiMessage` | `Encryption.PrivateKey.FromPRF` |
| `Asymptotic.MultiMessageLemmas` | `Encryption.PrivateKey.FromPRF.HybridLemmas` and `Encryption.PrivateKey.FromPRF.ReductionMachine` |
| `Asymptotic.NextBit` | `Pseudorandom.NextBit` |
| `Asymptotic.PRF` | `Pseudorandom.Functions.Asymptotic.Defs` or `Pseudorandom.Functions.Asymptotic.GGM` |
| `Asymptotic.PRFLemmas` | `Pseudorandom.Functions.Asymptotic.GGM.Evaluator` |
| `Asymptotic.Pseudorandom` | `Pseudorandom.Generators.Asymptotic.Defs` |
| `Asymptotic.PublicKey` | `Encryption.PublicKey.Trapdoor` (or Scheme and EnsembleSecurity for the interfaces) |
| `Asymptotic.PublicKeyLemmas` | `Encryption.PublicKey.Hybrid` and `Encryption.PublicKey.TrapdoorPredictor` |
| `Authentication.DLHash` | `Hashing.FromDiscreteLog` |
| `Authentication.HashAndSign` | `Authentication.Signatures.HashAndSign` |
| `Authentication.Lamport` | `Authentication.Signatures.Lamport` |
| `Authentication.PRFMAC` | `Authentication.MAC.FromPRF` |
| `Candidates.ElGamal` | `Encryption.PublicKey.ElGamal` |
| `Composability.CCA2Scheme` | `Encryption.PrivateKey.EncryptThenTag` |
| `Composability.Defs` | `Encryption.PrivateKey.OracleSecurity` |
| `Composability.NonMalleable` | `Encryption.PublicKey.NonMalleability.Indistinguishability` |
| `Composability.PRFScheme` | `Encryption.PrivateKey.OracleFromPRF` |
| `Composability.PublicKey` | `Encryption.PublicKey.OracleSecurity` and `Encryption.PublicKey.TrapdoorCPA` |
| `Composability.SimNonMalleable` | `Encryption.PublicKey.NonMalleability.Simulation` |

## Verification

- All 73 native module checks pass in a tree without the retired modules, including
  the library root and both audit aggregates.
- The 12 standalone facade probes confirm the previous
  ordered providers, with the planned Goldreich–Levin scope for `Asymptotic.HardCore`.
- Lean confirms that all 23 shims owned zero declarations. The 3,385
  rebuilt declarations match in type and body apart from source-location labels on five
  existing `sorry` proofs. The style comparison reports zero new warnings or failures.
