"""Package pinned verification artifacts without including any product tree."""
from hashlib import file_digest
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

area, output = map(Path,sys.argv[1:3])
patterns = sys.argv[3:]
inputs = {}
for pattern in patterns:
    matches = sorted(area.glob(pattern))
    assert matches, pattern
    for path in matches:
        if not path.is_file():
            continue
        assert not path.is_symlink() and path.suffix not in {'.olean','.ilean','.pyc'}, path
        key = path.relative_to(area).as_posix()
        if path.suffix=='.lean':
            key = key.removesuffix('.lean') + '.source.txt'
        assert key not in inputs or inputs[key] == path
        inputs[key] = path


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


assert inputs
receipt = []
with ZipFile(output, 'x', compression=ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
    for key, path in sorted(inputs.items()):
        h = sha(path)
        archive.write(path,key)
        receipt.append({'path':key,'input_relative_path':path.relative_to(area).as_posix(),
                        'bytes':path.stat().st_size,'sha256':h})
    archive.writestr('FILE-DIGESTS.json',json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
assert output.stat().st_size <= 95*1024**2, output
with ZipFile(output) as archive:
    assert archive.testzip() is None
print(output.name, len(inputs), 'files', output.stat().st_size, sha(output), flush=True)
