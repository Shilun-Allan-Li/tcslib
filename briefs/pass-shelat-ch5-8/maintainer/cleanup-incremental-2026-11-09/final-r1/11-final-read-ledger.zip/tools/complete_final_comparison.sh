#!/usr/bin/env bash
set -euo pipefail
area=$1
tool=$area/tools
stage=$area/final-evidence-staging-r1
catalogs=("$area"/census-final-r1/FinalPins.*)
test "${#catalogs[@]}" -eq 1
python3 -I "$tool/combine_seals_final.py" "$area/seals-head-final-r1" \
  "$area/seals-head-effective-final-r1.json" "$area"/final-seal-transfer-r2-lane{1,2,3,4} \
  "$area/final-seal-transfer-r2/TRANSFER.json"
python3 -I "$tool/scan_reads.py" "$area" "$area/head-read-scan-final-r1" \
  "${catalogs[0]}/HeadKind.log" "${catalogs[0]}/HeadC3.log" \
  "$area/seals-head-effective-final-r1.json" head "$area/native-r3/PLAN.json"
python3 -I "$tool/review_explicit_reads_final.py" "$area" "$area/head-read-scan-final-r1" \
  "$area/explicit-read-review-final-r1.json"
python3 -I "$tool/review_seal_diagnostics_final.py" "$area" "$area/seal-review-final-r1.json"
python3 -I "$tool/build_deferred_ledger_final.py" "$area" "$area/seal-review-final-r1.json" \
  "$area/explicit-read-review-final-r1.json" "$area/deferred-read-ledger-final-r1.json"
python3 -I "$tool/archive_cleanup_evidence.py" "$area" "$stage/10-final-seals.zip" \
 'seals-head-final-r1/*' 'seals-head-effective-final-r1.json' 'final-seal-transfer-r2/TRANSFER.json' \
 'final-seal-transfer-r2-lane?/MANIFEST.json' 'final-seal-transfer-r2-lane?/run-*/*' \
 'controls-final-r1/*' 'relocation-witness-final-r1/*' 'relocation-witness-final-r1/run-*/*' \
 'relocation-witness-recipe-final-r1.json' 'tools/combine_seals_final.py' 'tools/transfer_head_seals.py' \
 'tools/prepare_read_witness_final.py'
python3 -I "$tool/archive_cleanup_evidence.py" "$area" "$stage/11-final-read-ledger.zip" \
 'base-read-scan-r1/**/*' 'head-read-scan-final-r1/**/*' 'explicit-read-review-final-r1.json' \
 'seal-review-final-r1.json' 'deferred-read-ledger-final-r1.json' 'additional-provider-traces-final-r1.json' \
 'tools/scan_reads.py' 'tools/review_explicit_reads_final.py' 'tools/review_seal_diagnostics_final.py' \
 'tools/build_deferred_ledger_final.py' 'tools/write_final_review.py' 'tools/complete_final_comparison.sh' \
 'tools/archive_cleanup_evidence.py'
