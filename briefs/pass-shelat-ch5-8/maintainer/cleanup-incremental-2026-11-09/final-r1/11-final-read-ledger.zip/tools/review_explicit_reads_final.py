"""Match explicit reads by declaration and tactic item, supplementing selected opens."""
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

area, head_scan, output = map(Path,sys.argv[1:4])
root = Path.cwd()
base_scan = area/'base-read-scan-r1'
plan = json.loads((area/'native-r3/PLAN.json').read_bytes())
prior = area.parent/'gate06-combined-20261108'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


lexer = load(prior/'source-review/final-static-r1/scan_explicit.py', 'reviewed_explicit_lexer')
parser = load(root/'briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1/explicit-scan-r1/declx.py',
              'reviewed_declaration_extents')
paths = (base_scan/'files.txt').read_text().splitlines()


def git_source(rev, path):
    return subprocess.check_output(['git','show',rev+':'+path]).decode()


def scan_hits(scan):
    hits = defaultdict(list)
    section = False
    for line in (scan/'scan.log').read_text().splitlines():
        if line.startswith('## '):
            section = line.startswith('## (c1)')
        elif section and not line.startswith('#'):
            loc, tactic, spelling, kind, provider, home, owner, *_ = line.split('\t')
            path, ln = loc.rsplit(':',1)
            hits[path].append({'line':int(ln),'tactic':tactic,'head':spelling,'kind':kind,
                               'provider':provider,'provider_home':home,'scanner_owner':owner})
    return hits


def extend(file_hits, raw, owner, kinds):
    scopes = parser.extents(raw)
    items = lexer.inventory(raw)
    by_loc = defaultdict(list)
    for item in items:
        by_loc[item['line'],item['tactic'],item['head']].append(item)
    by_loc = {k:list(v) for k,v in by_loc.items()}
    scopes_at = {}
    for item in file_hits:
        line, tac, name = item['line'],item['tactic'],item['head']
        options = by_loc.get((line,tac,name),[])
        # A candidate with an unresolved tactic-list item must be read manually.
        item.update({'item': ' '.join(options[0]['item'].split()) if len(options)==1 else None,
                     'source_coverage':'primary'})
    selected_opens = []
    for i, line in enumerate(lexer.blank(raw).splitlines(),1):
        m = re.fullmatch(r'open\s+([\w.]+)\s+\(([^()]*)\)\s*',line)
        if m:
            selected_opens.append((i,m[1],m[2].split()))
    for item in items:
        line, tac, name = item['line'],item['tactic'],item['head']
        if '.' in name or any((line,tac,name)==(h['line'],h['tactic'],h['head']) for h in file_hits):
            continue
        for i, prefix, selected in selected_opens:
            if i>=line or name not in selected:
                continue
            direct = prefix + '.' + name
            candidates = [n for n in (direct,'TCSlib.Cryptography.' + direct,'TCSlib.'+direct) if n in kinds]
            assert len(candidates)==1, (owner,line,prefix,name,candidates)
            provider, = candidates
            kind, home = kinds[provider]
            if home != owner and kind.startswith('def'):
                file_hits.append({**item,'item':' '.join(item['item'].split()),'kind':kind,
                                  'provider':provider,'provider_home':home,
                                  'source_coverage':'selected-open','selected_open_line':i})
    for item in file_hits:
        line = item['line']
        if line not in scopes_at:
            entries = [s for s in scopes if s['dstart'] <= line <= s['end']]
            scopes_at[line] = entries[0] if len(entries)==1 else None
        item['owner'] = scopes_at[line]
        item['source'] = raw.splitlines()[line-1]
    return file_hits


kinds = {}
for side, scan in [('base',base_scan),('head',head_scan)]:
    with (scan/'constants.tsv').open() as f:
        kinds[side] = {name:(kind,home) for name,kind,home in (line.rstrip('\n').split('\t') for line in f)}
raw_a,raw_b = scan_hits(base_scan),scan_hits(head_scan)
matches = []
no_matches = []
counts = Counter()
for path in paths:
    owner = path[:-5].replace('/','.')
    a,b = [git_source(plan[side],path) for side in ('base','head')]
    before = extend(raw_a[path],a,owner,kinds['base'])
    after = extend(raw_b[path],b,owner,kinds['head'])
    counts.update(('base_'+r['source_coverage'] for r in before))
    counts.update(('head_'+r['source_coverage'] for r in after))
    map_line = {
        j+offset+1:i+offset+1
        for i,j,size in SequenceMatcher(None,a.splitlines(),b.splitlines(),autojunk=False).get_matching_blocks()
        for offset in range(size)
    }
    used = set()
    for r in after:
        candidates = [(i,p) for i,p in enumerate(before) if i not in used and
                      all(p[k]==r[k] for k in ('tactic','head','item','provider','provider_home')) and
                      (p['owner'] or {}).get('name') == (r['owner'] or {}).get('name')]
        exact = [(i,p) for i,p in candidates if map_line.get(r['line'])==p['line']]
        options = exact or candidates
        if len(options)==1 and r['item'] is not None and r['owner'] is not None:
            i,p = options[0]
            used.add(i)
            matches.append({'path':path,'method':'exact_mapped_line' if exact else 'same_read_item',
                            'base':p,'head':r})
        else:
            no_matches.append({'path':path,'head':r,'candidates':options,
                               'mapped_line':map_line.get(r['line'])})
result = {'base':plan['base'],'head':plan['head'],'counts':dict(counts),
          'base_scan_sha256':sha256((base_scan/'scan.log').read_bytes()).hexdigest(),
          'head_scan_sha256':sha256((head_scan/'scan.log').read_bytes()).hexdigest(),
          'paired':matches,'manual_review':no_matches}
with output.open('x') as f:
    json.dump(result,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(dict(counts), len(matches), 'paired', len(no_matches), 'for review', flush=True)
