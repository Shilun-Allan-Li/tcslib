"""Write the review record only after the final pinned evidence is complete."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import sys
from zipfile import ZipFile

area, dest = map(Path,sys.argv[1:3])
target_base = sys.argv[3]


def read(name):
    return json.loads((area/name).read_bytes())


def digest(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


native = read('native-r3/RESULT.json')
plan = read('native-r3/PLAN.json')
census = read('census-final-r1/COMPARE.json')
declarations = read('declaration-scope-review-final-r1.json')
baseline = read('seals-base-effective-r1.json')
seals = read('seals-head-effective-final-r1.json')
transfer = read('final-seal-transfer-r2/TRANSFER.json')
controls = read('controls-final-r1/RESULT.json')
relocation = read('relocation-witness-final-r1/RESULT.json')
c3 = read('census-final-r1/C3-COMPARE.json')
c1 = read('explicit-read-review-final-r1.json')
ledger = read('deferred-read-ledger-final-r1.json')
head = plan['head']
base = plan['base']
assert native['passed'] and native['head']==controls['head']==head
assert len(plan['order'])==1075 and len(plan['retained'])==993 and len(plan['rebuild'])==82
assert declarations['head']==ledger['head']==c3['head_revision']==head
assert declarations['base']==ledger['base']==c3['base_revision']==base
assert len(baseline['outcomes'])==len(seals['outcomes'])==168
assert all(r['valid_harness'] for r in seals['outcomes'])
assert len(controls['outcomes'])==13 and controls['passed']
assert len(relocation['outcomes'])==2 and all(
    r['valid_harness'] and r['rc']==0 for r in relocation['outcomes'])
assert not ledger['partial'] and not ledger['needs_review']
assert not ledger['unused_manual_rows']
assert not c1['manual_review'] and not c3['new']
assert not declarations['handwritten_types_changed'] and not census['new_sorry_dependencies']
assert len(declarations['body_changes'])==13
assert all(r.get('provider_pairs') for r in ledger['current_observations']
           if r['channel']=='whole-file-seal')
inherited=dict(Counter(r['channel'] for r in ledger['current_observations']))
assert inherited['whole-file-seal']==seals['source_errors']
assert inherited['explicit-source']==len(c1['paired'])
assert inherited['generated-equation']==c3['head']
base_c2=int(re.search(r'\(c2\).* seal failed: (\d+)',(area/'base-read-scan-r1/scan.log').read_text())[1])
head_c2=int(re.search(r'\(c2\).* seal failed: (\d+)',(area/'head-read-scan-final-r1/scan.log').read_text())[1])
admitted = []
for file in ('census-r1/Base-compact.json','census-final-r1/Head-compact.json'):
    admitted.append({(r['home'],tuple(map(tuple,r['name']['components'])))
                     for r in read(file)['roots'] if 'sorryAx' in r['axioms']})
assert admitted[0]==admitted[1] and len(admitted[1])==59
scope = {'changed_lean_paths':len(plan['changed']),'affected_native_modules':len(plan['order']),
         'fresh_modules':len(plan['rebuild']),'verified_retained_modules':len(plan['retained']),
         'scoped_owners':len(seals['outcomes']),'fresh_final_seals':len(seals['outcomes'])-len(transfer['outcomes']),
         'verified_retained_seals':len(transfer['outcomes']),'final_source_passes':seals['source_passes'],
         'baseline_raw_diagnostics':baseline['source_errors'],'final_raw_diagnostics':seals['source_errors'],
         'final_control_probes':len(controls['outcomes']),'final_isolated_relocation_probes':len(relocation['outcomes']),
         'c1_head':inherited['explicit-source'],'c2_base':base_c2,'c2_head':head_c2,'c3_head':c3['head'],
         'actual_base_roots':census['base_count'],'actual_head_roots':census['head_count'],
         'admitted_declarations_in_native_scope':59}
assert scope['changed_lean_paths']==122
assert re.fullmatch(r'[0-9a-f]{40}',target_base)
with (dest/'STATUS.json').open('x') as f:
    json.dump({'source_base':base,'live_campaign_tip_checked':target_base,'head':head,
               'incremental_scope_verified':True,'scope':scope,
               'read_dispositions':ledger['inherited_counts']},f,indent=2)
    f.write('\n')

copy = dest/'PKE-PILOT.md'
assert not copy.exists()
shutil.copyfile(area/'PKE-PILOT-DRAFT.md',copy)
with (dest/'README.md').open('x') as f:
    f.write(f"""# Incremental cleanup acceptance

[PR #248](https://github.com/Shilun-Allan-Li/tcslib/pull/248) targets
`cryptography/pass-shelat-ch2-4` at candidate `{head}`.
The Lean comparison base is `{base}`.
The checked live campaign tip `{target_base}` has the
same Lean, checker, and dependency inputs. This implements the
[approved incremental target](../../../CLEANUP-PLAN.md).

The delivery's 13 attributed commits remain in the branch. Reconciliation
resolved 21 conflicts in 13 files and retained the #232 probability
projection fixes. The last commit changes two proof bodies.
`Ensemble.copies_X` and `YaoMachine.ans_layout` had acquired conversions
through the relocated block definitions. The focused checks exposed those
conversions even with their earlier blockers transparent. The repaired
proofs use the existing copy, product, and block equations. Their
statements and the representation bodies are unchanged by the repairs.

## Verification

| Check | Exact result |
|---|---|
| Ordinary Lean | 1,075 local modules pass, including `TCSlib` and campaign Checks. 82 ran fresh on the repaired head and 993 retained objects were verified against their source and prerequisites. |
| Whole-file seals | 168 valid harnesses across 122 edited owners and 46 unchanged sources with changed import closures. {scope['fresh_final_seals']} ran fresh on the repaired head and {scope['verified_retained_seals']} had identical source, masks, and transitive import objects. |
| Sensitivity | All 13 control outcomes and both repaired block-helper probes match their expectations. |
| Explicit tactic reads | {scope['c1_head']} retained entries, each paired with its baseline occurrence, including the selected-open review. |
| Generated-equation reads | {scope['c3_head']} retained actual pairs, 57 removed, with zero additions. |
| Kernel census | {scope['actual_head_roots']:,} actual stored declarations across the scoped modules. Retained handwritten types and 59 admitted-dependent identities are unchanged. The 94 changed types belong to generated auxiliaries. All five standard-axiom shifts and 13 changed definition values are accounted for. |
| Style | The repair adds no new lint failure. Four fill-owned files crossed 1,000 lines in the increment. GGMReduction, HardCoreLemmas, GraphIsomorphism, and ThreeColoring/Machines stay intact under the fill-size rule for the planned layout stage. |

The full baseline produced {scope['baseline_raw_diagnostics']} raw seal diagnostics.
The final source produced {scope['final_raw_diagnostics']}, including two
interactions with pre-existing local irreducibility attributes.
The ledger pairs the retained failures with the original source, provider,
and native evidence, including focused baseline runs for failures that
only become visible after an earlier read is repaired. Several diagnostics can come from
a single declaration. The baseline
has {base_c2} source show/change hits on failing lines and the candidate
has {head_c2}.

## Carry-forward and provenance

The archived ledger keeps all 509 original keys and 764 observations.
The prior delivery reported 173 open keys. Its independent intake
identified 34 historical failed-attempt logs absent from that payload.
The new baseline and candidate comparisons have their own raw logs and
dispositions. The three separate ClassNP/PolyTime provider proposals
remain deferred with the rest of the inherited-read cleanup.

The first candidate replay exposed stale Closeness reader names. The
first isolated Ensemble repair needed the Mathlib inverse-pair reader.
Both attempts are preserved. The initial repaired-head equation and
kind outputs had predecessor labels. The labelled probes were rerun
on the same exact repaired object tree and both outputs are archived.

After the user merges #248, the [PKE pilot map](PKE-PILOT.md) gives the
first facade and import moves. The inherited ledger remains the input
to the final seal stage on the reorganized source.

## Evidence

The numbered archives contain the source and object receipts, exact
native censuses, whole-file probes and masks, control logs, historical
intake joins, and current read dispositions. SHA256SUMS records
the file digests. Every archive has its own file digest inventory.

**Clear to merge — the repaired head meets the approved incremental target, with witnessed inherited reads recorded for the final stage.**
""")
archives = sorted(dest.glob('*.zip'))
assert len(archives)>=11
for p in archives:
    assert p.stat().st_size < 95*1024**2
    with ZipFile(p) as z:
        assert z.testzip() is None and 'FILE-DIGESTS.json' in z.namelist(), p
with (dest/'SHA256SUMS').open('x') as f:
    for p in sorted(dest.iterdir()):
        if p.is_file() and p.name != 'SHA256SUMS':
            f.write(f'{digest(p)}  {p.name}\n')
print(json.dumps(scope,indent=2),flush=True)
