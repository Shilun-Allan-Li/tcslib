"""Bind retained reads to baseline/current Names, exact sites, and historical intake."""
from collections import Counter, defaultdict
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile

area, diagnostic_path, explicit_path, dest = map(Path,sys.argv[1:5])
root = Path.cwd()
fill = root/'briefs/pass-shelat-ch5-8/fills/cleanup-part2'
received = fill/'checkpoints/partial-r1/received.zip'
observations = fill/'issued-r1/inputs/observations/canonical-work-units.json'
maps = 'inbox/fills/cleanup-part2/evidence/maps/'
diagnostic = json.loads(diagnostic_path.read_bytes())
explicit = json.loads(explicit_path.read_bytes())
census = json.loads((area/'declaration-scope-review-final-r1.json').read_bytes())
c3 = json.loads((area/'census-final-r1/C3-COMPARE.json').read_bytes())
manual = json.loads((area/'manual-seal-read-evidence-r1.json').read_bytes())
assert diagnostic['base']==explicit['base']==census['base']
assert diagnostic['head']==explicit['head']==census['head']
assert not c3['new'] and not explicit['manual_review']
with ZipFile(received) as z:
    historical_bytes = z.read(maps+'dispositions-final.json')
    historical = json.loads(historical_bytes)
    residual_bytes = z.read(maps+'residual-final.json')
    residual = json.loads(residual_bytes)
issued = {(r['path'],r['canonical']):r for r in json.loads(observations.read_bytes())}
assert len(issued)==len(historical['keys'])==509 and len(historical['rows'])==764


def digest(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def masks(label):
    return [
        {r['spelling']:r for r in json.loads((area/folder/(label+'.json')).read_bytes())['requested']}
        for folder in ('seals-base-r2','seals-head-final-r1')
    ]


recipes = {}
for p in area.glob('*-witness-base-r*/RESULT.json'):
    records = json.loads(p.read_bytes())['outcomes']
    items = json.loads((p.parent/'RECIPE.json').read_bytes())
    for recipe, witness in zip(items,records,strict=True):
        assert recipe['label']==witness['label'] and witness['valid_harness']
        assert digest(Path(witness['log']))==witness['log_sha256']
        recipes[witness['label']] = recipe,witness

review = {(r['label'],r['head_line'],r['name']):r for r in manual}
assert len(review)==len(manual)
traces = json.loads((area/'additional-provider-traces-final-r1.json').read_bytes())
provider_traces = {(r['label'],r['name']):r for r in traces}
assert len(provider_traces)==len(traces)
used_manual = set()
mask_index = {}
deferred = []
head_index = defaultdict(list)
pending = []
for index,r in enumerate(diagnostic['diagnostics'],1):
    label,path = r['label'],r['path']
    name = (r['head_span'] or {}).get('name')
    disposition = r['status']
    key = label,r['head_line'],name
    if label not in mask_index:
        mask_index[label] = masks(label)
    old_mask,new_mask = mask_index[label]
    entry = {**r,'id':f'SEAL-{index:04d}','channel':'whole-file-seal',
             'current_owner':path, 'historical_owner':path}
    if key in review and disposition=='unpaired':
        m = review[key]
        used_manual.add(key)
        assert all(n in old_mask and n in new_mask for n in m['providers']), key
        evidence = []
        if 'witness' in m:
            recipe,witness = recipes[m['witness']]
            assert recipe['source_label']==label
            lines = [e['source_line'] for e in witness['errors']]
            assert m['base_line'] in lines, (m,lines)
            evidence.append({'recipe':recipe, 'log':witness['log'],
                             'log_sha256':witness['log_sha256'],'source_line':m['base_line']})
        else:
            blocker = m.get('earlier_base_line',m['base_line'])
            assert any(p['source_line']==blocker for p in r['base_same_declaration']), m
            if blocker!=m['base_line']:
                assert r['base_mapped_line']==m['base_line']
                assert r['base_mapped_source']==r['head_source']
                assert len(r['head_actual'])==len(r['base_actual'])==1
                assert r['head_actual'][0]['type_sha256']==r['base_actual'][0]['type_sha256']
        entry.update({'disposition':'inherited_reviewed_conversion','reason':m['reason'],
                      'base_operating_line':m['base_line'],'manual_probe_evidence':evidence,
                      'provider_pairs':[{ 'base':old_mask[n], 'head':new_mask[n]} for n in m['providers']]})
    elif disposition in ('same_block','same_step_in_edited_block','targeted_baseline_match'):
        assert r['head_span'] and r['base_span']
        assert len(r['head_actual'])==len(r['base_actual'])==1
        assert r['head_actual'][0]['name']==r['base_actual'][0]['name']
        entry['disposition'] = {
            'same_block':'inherited_same_native_step',
            'same_step_in_edited_block':'inherited_same_step_after_other_repairs',
            'targeted_baseline_match':'inherited_reached_in_baseline_probe',
        }[disposition]
        entry['base_operating_line'] = (r['targeted_witnesses'][0]['diagnostic']['source_line']
                                        if r['targeted_witnesses'] else r['base_matches'][0]['source_line'])
        entry['provider_pairs'] = []
        evidence_text = r['head_error'] + '\n' + r['head_source']
        for n in r['common_sealed_native_references']:
            full = n['spelling']
            leaf = '.'.join(full.split('.')[-2:])
            if full in evidence_text or re.search(r'(?<![\w.])'+re.escape(leaf)+r'(?![\w.])',evidence_text):
                entry['provider_pairs'].append({'base':old_mask[full],'head':new_mask[full]})
        trace = provider_traces.get((label,name))
        if trace:
            provider = trace['provider']
            assert provider in old_mask and provider in new_mask, trace
            entry['provider_pairs'].append({'base':old_mask[provider],'head':new_mask[provider]})
            entry['provider_note'] = trace['reason']
        elif entry['provider_pairs']:
            entry['provider_note'] = 'Names shown in the step or native error and present in both request catalogs.'
        else:
            entry['provider_pairs'] = [
                {'base':old_mask[row['spelling']],'head':row}
                for row in r['common_sealed_native_references']
            ]
            entry['provider_note'] = 'Shared sealed references in the native declaration. The exact source and diagnostic establish the inherited step. The individual reduction is not isolated.'
    elif disposition=='same_command_outside_declaration':
        assert len(r['base_matches'])==1 and r['base_mapped_source']==r['head_source']
        assert r['head_source'].startswith('attribute [local irreducible] '), r
        provider = re.search(r'`([^ `]+)` is currently',r['head_error'])
        assert provider, r
        matching = [n for n in old_mask.keys() & new_mask.keys() if n.split('.')[-1]==provider[1]]
        assert len(matching)==1, matching
        n = matching[0]
        entry.update({'disposition':'inherited_source_attribute_interaction',
                      'provider_pairs':[{'base':old_mask[n],'head':new_mask[n]}],
                      'base_operating_line':r['base_matches'][0]['source_line'],
                      'reason':'The unchanged source attribute attempts to seal a definition already sealed by the whole-file probe on both sides.'})
    else:
        entry['disposition'] = 'requires_review'
        pending.append(entry['id'])
    deferred.append(entry)
    if name:
        head_index[path,name].append(entry['id'])

for i,r in enumerate(explicit['paired'],1):
    name = r['head']['owner']['name']
    key = f'C1-{i:04d}'
    deferred.append({'id':key,'channel':'explicit-source','disposition':'inherited_same_tactic_item',**r})
    head_index[r['path'],name].append(key)
for i,row in enumerate(c3['retained'],1):
    home,name,reference,provider,provider_home,reference_home,*kind = row
    path = home.replace('.','/')+'.lean'
    key = f'C3-{i:04d}'
    deferred.append({'id':key,'channel':'generated-equation','disposition':'inherited_same_actual_reference',
                     'path':path,'name':name,'reference':reference,'provider':provider,
                     'provider_home':provider_home,'reference_home':reference_home,'kind':kind})
    user_name = re.sub(r'^_private\.'+re.escape(home)+r'\.\d+\.','',name)
    head_index[path,user_name].append(key)

historical_links = []
for key in historical['keys']:
    path,name = key['path'],key['canonical']
    current_path = key['moved_to'].replace('.','/')+'.lean' if key.get('moved_to') else path
    known = head_index[current_path,name]
    historical_links.append({
        'issued':issued[path,name],'reported':key,'current_observation_ids':known,
        'current_status':'linked_to_current_observations' if known else 'historical_record_for_final_reconciliation',
    })

data = {'base':diagnostic['base'],'head':diagnostic['head'],'partial':diagnostic['partial'],
        'diagnostics_input_sha256':digest(diagnostic_path),
        'explicit_input_sha256':digest(explicit_path),'inherited_counts':dict(Counter(r['disposition'] for r in deferred)),
        'needs_review':pending,'unused_manual_rows':[list(k) for k in review.keys()-used_manual],
        'current_observations':deferred,'issued_historical_keys':historical_links,
        'historical_delivery':{'archive_sha256':digest(received),
            'dispositions_sha256':sha256(historical_bytes).hexdigest(),
            'residual_sha256':sha256(residual_bytes).hexdigest(),
            'reported_revision':historical['revision'],'reported_counts':historical['summary'],
            'historical_rows':historical['rows'],'historical_extra_observations':residual}}
with dest.open('x') as f:
    json.dump(data,f,indent=2,ensure_ascii=False)
    f.write('\n')
print(data['inherited_counts'], 'pending',len(pending), flush=True)
