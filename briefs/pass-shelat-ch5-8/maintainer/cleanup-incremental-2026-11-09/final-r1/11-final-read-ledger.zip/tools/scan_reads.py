from collections import defaultdict
import json
from pathlib import Path
import re
import subprocess
import sys

area, dest, kinds, c3, seal_result = map(Path, sys.argv[1:6])
side = sys.argv[6]
plan = json.loads(Path(sys.argv[7]).read_bytes())
root = Path(plan['worktree'])
revision = plan['base' if side == 'base' else 'head']
owners = json.loads((area / 'census-r1/owners.json').read_bytes())
scanner = root / 'briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1/explicit-scan-r1/scan.py'
dest.mkdir()
out_eq = dest / 'equations'
out_eq.mkdir()
(dest / 'files.txt').write_text(''.join(m.replace('.', '/') + '.lean\n' for m in owners))

text = kinds.read_text()
limits = re.findall(r'G06-EXPLICIT-CATALOG-(?:BEGIN|END).* rows=(\d+)', text)
prefix = 'G06-EXPLICIT-KIND\t'
rows = [line.split(prefix, 1)[1] for line in text.splitlines() if prefix in line]
assert len(limits) == 2 and len(rows) == int(limits[0]) == int(limits[1])
assert len({line.split('\t', 1)[0] for line in rows}) == len(rows)
(dest / 'constants.tsv').write_text('\n'.join(rows) + '\n')

root_count = defaultdict(int)
pairs = defaultdict(list)
for line in c3.read_text().splitlines():
    if 'G06-C3-ROOT ' in line:
        home = line.split('G06-C3-ROOT ', 1)[1].split(' | ', 1)[0]
        root_count[home] += 1
    if 'G06-C3-REF ' in line:
        home, decl, ref, parent, parent_home, ref_home, *_ = line.split('G06-C3-REF ', 1)[1].split(' | ')
        pairs[home].append('\t'.join((home, decl, parent, ref, parent_home, ref_home)))
assert set(root_count) <= set(owners) and set(pairs) <= set(owners)
for owner in owners:
    (out_eq / (owner + '.eqn.txt')).write_text(''.join(p + '\n' for p in pairs[owner]))

seal = json.loads(seal_result.read_bytes())
assert [p['owner'] for p in seal['outcomes']] == owners
assert all(p['valid_harness'] for p in seal['outcomes'])
(dest / 'seal-errors.txt').write_text(''.join(
    f' {probe["path"]}:{err["source_line"]}:{err["column"]}: error:\n'
    for probe in seal['outcomes'] for err in probe['errors']))
subprocess.run(['python3', '-I', str(scanner), str(root), str(dest / 'files.txt'),
                str(dest / 'constants.tsv'), str(out_eq), str(dest / 'seal-errors.txt'),
                str(dest / 'scan.log'), '--rev', revision], check=True)
