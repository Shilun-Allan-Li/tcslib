from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_output
import sys


worktree = Path(sys.argv[1])
output = Path(sys.argv[2])
candidate = output / 'candidate'
candidate.mkdir()
base = check_output(['git', '-C', str(worktree), 'rev-parse', 'MERGE_HEAD'], text=True).strip()
prior = check_output(['git', '-C', str(worktree), 'rev-parse', 'HEAD'], text=True).strip()
paths = check_output(['git', '-C', str(worktree), 'diff', '--name-only', '--diff-filter=U', '-z']).decode().strip('\0').split('\0')
conflict = re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> ' + re.escape(base) + r'\n', re.M | re.S)
assert len(paths) == 13, paths
changes = {}
choices = []


def resolve(path, match):
    ours, theirs = match.groups()
    reason = 'Keep the merged-base reader or proved bridge.'
    selected = theirs
    if path == 'TCSlib/InformationTheory/FinDist.lean':
        selected = ours + theirs
        reason = 'Keep the new collision reader and the merged-base docstring.'
    if path == 'TCSlib/Cryptography/ZeroKnowledge/Encoding.lean':
        selected = theirs + ours[ours.index('/-- The adjacency of the decoded graph:'):]
        reason = 'Keep the merged-base total decoder and vertex readers, plus the distinct adjacency reader.'
    if path.endswith('/EfficiencyRep.lean') and 'have' not in ours and 'sampleStr_poly.comp' in ours:
        selected = ours.replace('coinSlice', 'coinBlock')
        reason = 'Retain the checked public tail route with the shared coin block.'
    if path.endswith('/Simulator.lean') and 'polyTimeComputable_tail.congr' in ours:
        selected = ours.replace('coinSlice', 'coinBlock')
        reason = 'Retain the checked public tail route with the shared coin block.'
    if not theirs:
        reason = 'Retain the merged-base consolidation of the two coin-slice definitions into coinBlock.'
    choices.append({'path': path, 'line': match.string.count('\n', 0, match.start()) + 1, 'reason': reason})
    return selected


for path in paths:
    raw = (worktree / path).read_text()
    changes[path], count = conflict.subn(lambda match: resolve(path, match), raw)
    assert count and not re.search(r'^(<<<<<<<|=======|>>>>>>>)', changes[path], re.M), path
assert len(choices) == 21, len(choices)


def rename_readers(path, names):
    raw = changes[path] if path in changes else (worktree / path).read_text()
    for old, new in names.items():
        pattern = r'(?<![\w\'])' + re.escape(old) + r'(?![\w\'])'
        raw, count = re.subn(pattern, new, raw)
        assert count, (path, old)
    changes[path] = raw


pk = 'TCSlib/Cryptography/Asymptotic/'
zk = 'TCSlib/Cryptography/ZeroKnowledge/'
for file in ('PublicKey.lean', 'PublicKeyLemmas.lean'):
    rename_readers(pk + file, {'blockState_def': 'blockState_eq', 'blockEncFun_def': 'blockEncFun_eq'})
rename_readers(zk + 'GraphIsomorphism/Proofs.lean', {'decGraph_def': 'decGraph_eq'})
rename_readers(zk + 'GraphIsomorphism/Efficiency.lean', {'sampleStr_def': 'sampleStr_eq'})
rename_readers('TCSlib/Complexity/Randomized/PolyTimeModel.lean', {
    'polyLen_def': 'polyLen_eq',
    'boolVerifier_def': 'boolVerifier_apply',
})
poly = 'TCSlib/Complexity/Randomized/PolyTimeModel.lean'
assert changes[poly].count('    rw [polyLen_eq]\n') == 2
changes[poly] = changes[poly].replace('    rw [polyLen_eq]\n', '    simp only [polyLen_eq]\n')
gi = zk + 'GraphIsomorphism.lean'
for first, next_doc in (
    ('/-- The defining equation of `instanceVertexCount`:', '/-- The first graph of a common input'),
    ('/-- The defining equation of `instanceG₀`:', '/-- The second graph of a common input'),
    ('/-- The defining equation of `instanceG₁`:', '/-- A common input is well formed'),
    ('/-- The defining equation of `samplePerm`:', '/-- The number of tape bits consumed'),
):
    start = changes[gi].index(first)
    end = changes[gi].index(next_doc, start)
    changes[gi] = changes[gi][:start] + changes[gi][end:]

manifest = {'base': base, 'prior': prior, 'conflicts': choices, 'files': []}
for path, replacement in sorted(changes.items()):
    target = candidate / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(replacement)
    manifest['files'].append({
        'path': path,
        'before': sha256((worktree / path).read_bytes()).hexdigest(),
        'after': sha256(target.read_bytes()).hexdigest(),
    })
(output / 'merge-preparation.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(f'{len(choices)} hunks across {len(paths)} conflicts; {len(changes)} proposed files')
