import datetime
import fcntl
from hashlib import file_digest
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time


def digest(path):
    with path.open('rb') as f:
        return file_digest(f, 'sha256').hexdigest()


def write(path, data):
    with path.open('x') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def resources():
    snapshot = subprocess.check_output(['/usr/bin/memory_pressure', '-Q'], text=True)
    total = int(re.search(r'system has (\d+)', snapshot)[1])
    percent = int(re.search(r'memory free percentage:\s*(\d+)%', snapshot)[1])
    return {'memory_headroom_bytes': total * max(0, percent - 1) // 100,
            'disk_free_bytes': shutil.disk_usage(tree).free}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()


def verify_pins():
    assert git('rev-parse', 'HEAD') == plan['head']
    assert not git('status', '--porcelain', '--untracked-files=no')
    assert digest(lean) == plan['toolchain_sha256']
    assert digest(checker) == plan['checker_sha256']
    assert not (root / '.lake/build/lib/lean').exists()
    for name, sha in plan['source_digests'].items():
        assert digest(root / (name + '.lean')) == sha, name
    for row in plan['external'].values():
        assert digest(Path(row['path'])) == row['sha256'], row['path']


def interrupt(signum, _frame):
    raise InterruptedError(f'interrupted by signal {signum}')


plan_file = Path(sys.argv[1]).resolve()
plan = json.loads(plan_file.read_text())
root = Path(plan['worktree'])
tree = Path(plan['tree'])
out = plan_file.parent
lean = Path(plan['toolchain'])
checker = root / 'scripts/lean_check_tree.sh'
lock = (out / 'native.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (out / 'RESULT.json').exists(), 'Native result already complete'
verify_pins()
start_resources = resources()
assert start_resources['memory_headroom_bytes'] >= 4 * 1024**3 and start_resources['disk_free_bytes'] >= 12 * 1024**3, start_resources
run_dir = out / ('run-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f'))
run_dir.mkdir()
write(run_dir / 'START.json', {'utc': now(), 'pid': os.getpid(), 'head': plan['head'],
                              'plan_sha256': digest(plan_file), 'resources': start_resources})

env = os.environ.copy()
for name in ('LEAN_PATH', 'LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LEAN_OPTS', 'ELAN_TOOLCHAIN', 'PFR_BOOTSTRAP_CONFIG'):
    env.pop(name, None)
env['PATH'] = str(lean.parent) + ':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['TCSLIB_OLEANS'] = str(tree)
(out / 'tmp').mkdir(exist_ok=True)
env['TMPDIR'] = str(out / 'tmp')
for sig in (signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, interrupt)

prior = {}
for path in sorted(out.glob('run-*/check-*.json')):
    row = json.loads(path.read_bytes())
    if row['rc'] == 0 and row['object_sha256'] and digest(path.with_suffix('.log')) == row['log_sha256']:
        prior[row['module']] = row
products = dict(plan['retained'])
total = len(plan['rebuild'])
fresh = reused = 0
for ordinal, module in enumerate(plan['rebuild'], 1):
    source = root / (module + '.lean')
    obj = tree / (module + '.olean')
    source_sha = plan['source_digests'][module]
    direct = {name: products[name]['object_sha256'] for name in plan['graph'][module]}
    assert digest(source) == source_sha, module
    for dep, expected in direct.items():
        assert digest(tree / (dep + '.olean')) == expected, dep
    row = prior.get(module)
    if (row and row['source_sha256'] == source_sha and row['direct_local'] == direct
            and obj.is_file() and digest(obj) == row['object_sha256']):
        products[module] = row
        reused += 1
        continue
    before = resources()
    if before['memory_headroom_bytes'] < 4 * 1024**3:
        write(run_dir / 'DEFERRED.json', {'module': module, 'resources': before, 'utc': now()})
        print('DEFERRED for memory before', module, before, flush=True)
        sys.exit(75)
    started, tick = now(), time.monotonic()
    label = f'check-{ordinal:04d}'
    log = run_dir / (label + '.log')
    with log.open('xb') as stream:
        proc = subprocess.Popen(['bash', str(checker), module], cwd=root, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            write(run_dir / (label + '.child'), {'pid': proc.pid, 'module': module})
            rc = proc.wait()
        except BaseException:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
            raise
    row = {'module': module, 'source_sha256': source_sha, 'direct_local': direct,
           'object_sha256': digest(obj) if obj.is_file() and obj.stat().st_size else None,
           'rc': rc, 'start': started, 'end': now(), 'seconds': round(time.monotonic() - tick, 3),
           'log_sha256': digest(log), 'head': plan['head'], 'resource_start': before}
    write(run_dir / (label + '.json'), row)
    if rc or not row['object_sha256']:
        print(f'FAIL {ordinal}/{total} {module}, log {log}', flush=True)
        print(log.read_text(errors='replace')[-6500:], flush=True)
        sys.exit(1)
    products[module] = row
    fresh += 1
    print(f'PASS {ordinal}/{total} {module} ({row["seconds"]} s)', flush=True)

verify_pins()
assert set(products) == set(plan['order'])
for name, row in products.items():
    assert digest(tree / (name + '.olean')) == row['object_sha256'], name
    assert row['direct_local'] == {dep: products[dep]['object_sha256'] for dep in plan['graph'][name]}, name
write(out / 'PRODUCTS.json', products)
write(out / 'RESULT.json', {'head': plan['head'], 'base': plan['base'], 'plan_sha256': digest(plan_file),
                            'products_sha256': digest(out / 'PRODUCTS.json'), 'initial_retained': len(plan['retained']),
                            'reused_native_checks': reused, 'fresh_native_checks': fresh, 'passed': True, 'utc': now()})
print('All native checks passed', len(products), flush=True)
