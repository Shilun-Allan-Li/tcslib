import datetime
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
from subprocess import check_output
import sys

from import_graph import imports, topo

worktree = Path(sys.argv[1]).resolve()
base = sys.argv[2]
out = Path(sys.argv[3]).resolve()
prior = Path(sys.argv[4]).resolve()
verified = prior / 'projection-delta-native-r2'
local = prior / 'native-local-resume-r1'
tree = out / 'oleans'


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def read(path, expected=None):
    assert expected is None or sha(path) == expected, path
    return json.loads(path.read_bytes())


def git(*args):
    return check_output(['git', *args], cwd=worktree, text=True).strip()


def copy_object(source, target, expected):
    assert sha(source) == expected, source
    target.parent.mkdir(exist_ok=True, parents=True)
    shutil.copyfile(source, target)
    assert sha(target) == expected and not target.samefile(source), target


head = git('rev-parse', 'HEAD')
assert not git('status', '--porcelain', '--untracked-files=no')
assert not (worktree / '.lake/build/lib/lean').exists()
assert git('merge-base', head, base) == base
result = read(verified / 'RESULT.json', '57f6576250aba238b05abefef08d03cd77e2e0e6727c5e30aee5c78da418a842')
assert result['status'] == 'NATIVE_PROJECTION_DELTA_CHECKS_PASSED'
start = read(verified / 'START.json', '534c5cfdcc136d9b2f78196d5dc3c30177f6d73c2774f11bdadd741aaa0ec1f5')
baseline_sources = start['source_files']
assert start['head'] == result['head']
assert not git('diff', '--name-only', base, start['head'], '--', '*.lean',
               'scripts/lean_check_tree.sh', 'lean-toolchain', 'lake-manifest.json')
assert not git('diff', '--name-only', base, head, '--', 'scripts/lean_check_tree.sh',
               'lean-toolchain', 'lake-manifest.json', 'lakefile.lean', 'lakefile.toml')
baseline_tree = Path(result['tree'])
records = read(local / 'local-records.json', '8c59fdcd4066eda738aa30422474ffb38912b4d0fb2ea514b18fb5ae033ee9dc')
for row in result['results']:
    name = row['module']
    if name in result['rebuilt_local']:
        assert row['rc'] == row['error_diagnostics'] == 0
        records[name].update(source_sha256=row['source_sha256'], object_sha256=row['object_sha256'],
                             direct_local_object_sha256=row['direct_local_objects'])
assert len(records) == 1075
record_origins = {name: (baseline_tree, 'verified_gate06') for name in records}
for prior_run in sys.argv[5:]:
    previous = Path(prior_run).resolve()
    previous_plan = read(previous / 'PLAN.json')
    assert previous_plan['base'] == base and git('merge-base', head, previous_plan['head']) == previous_plan['head']
    previous_tree = Path(previous_plan['tree'])
    row_paths = sorted(previous.glob('run-*/check-*.json'))
    prior_rows = dict(previous_plan['retained'])
    for row_path in row_paths:
        row = read(row_path)
        if row['rc'] or not row['object_sha256']:
            continue
        assert row['head'] == previous_plan['head']
        assert sha(row_path.with_suffix('.log')) == row['log_sha256']
        prior_rows[row['module']] = row
    for module, row in prior_rows.items():
        assert row['source_sha256'] == previous_plan['source_digests'][module]
        obj = previous_tree / (module + '.olean')
        if not obj.is_file() or sha(obj) != row['object_sha256']:
            continue
        # Prefer the prior successful candidate when all of its inputs match this plan.
        records[module] = dict(row, direct_local_object_sha256=row['direct_local'])
        record_origins[module] = (previous_tree, 'verified_combined_predecessor')
external = read(local / 'external-final.json', '9ae25d17d062321af3fd766acdbb01a73cbd03a2fa92172575250910361ff0fd')
assert len(external) == 3810
config = read(prior / 'pfr-runtime-r1/config.json', '4d1a6453a3586f5263628712ad15ab734514a04bbe65e10c1c468f70bb0c8c16')
lean = Path(config['real_lean'])
assert sha(lean) == config['real_lean_sha256']
files = set(git('ls-files', '--', 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean').splitlines())
files = {f for f in files if f.endswith('.lean')}
assert files == set(baseline_sources), (len(files), len(baseline_sources))
sources = {name[:-5]: sha(worktree / name) for name in sorted(files)}
changed = {n for n, digest in sources.items() if digest != baseline_sources[n + '.lean']}
assert changed == {name[:-5] for name in git('diff', '--name-only', base, head, '--', '*.lean').splitlines()}
graph, external_roots = {}, {}
for module in sources:
    direct = list(dict.fromkeys(imports((worktree / (module + '.lean')).read_bytes())))
    graph[module] = [name.replace('.', '/') for name in direct if name.replace('.', '/') in sources]
    external_roots[module] = [name for name in direct if name.replace('.', '/') not in sources]

reconcile = read(out.parent / 'reconciliation-r1/merge-preparation.json')
priority = [r['path'][:-5] for r in reconcile['files']]
order = topo(graph, [*priority, *sorted(changed), 'TCSlib', 'audits/pass-shelat/Checks'])
unknown = sorted({name for m in order for name in external_roots[m]} - set(external))
assert not unknown, ('new external imports need a package proof', unknown)

retained, rebuild = {}, []
for module in order:
    record = records.get(module)
    if record is not None and record['source_sha256'] == sources[module] and (
        record['direct_local_object_sha256'] ==
        {dep: retained[dep]['object_sha256'] for dep in graph[module] if dep in retained}
    ) and set(graph[module]) <= set(retained):
        retained[module] = record
    else:
        rebuild.append(module)
assert 'TCSlib' in rebuild and 'audits/pass-shelat/Checks' in rebuild
assert all(record_origins[m][1] == 'verified_combined_predecessor' for m in changed & set(retained))
out.mkdir()
rows = {}
for module, record in retained.items():
    digest = record['object_sha256']
    origin_tree, origin = record_origins[module]
    copy_object(origin_tree / (module + '.olean'), tree / (module + '.olean'), digest)
    rows[module] = {'source_sha256': sources[module], 'object_sha256': digest,
                    'direct_local': record['direct_local_object_sha256'], 'source': origin}

external_paths = {}
for name, record in external.items():
    source = Path(record['object_path'])
    expected = record['object_sha256']
    if record['kind'] == 'PFR_OWN_TREE':
        target = tree / '.lake/packages/PFR' / (name.replace('.', '/') + '.olean')
        copy_object(baseline_tree / (name.replace('.', '/') + '.olean'), target, expected)
        source = target
    else:
        assert sha(source) == expected, source
    external_paths[name] = {'path': str(source), 'sha256': expected}
(tree / 'PFR').symlink_to('.lake/packages/PFR/PFR', target_is_directory=True)

plan = {
    'head': head, 'base': base, 'source_digests': sources, 'order': order,
    'graph': {m: graph[m] for m in order}, 'external_roots': {m: external_roots[m] for m in order},
    'external': external_paths, 'baseline': result['head'], 'rebuild': rebuild,
    'changed': sorted(changed), 'retained': rows, 'toolchain': str(lean),
    'toolchain_sha256': config['real_lean_sha256'], 'worktree': str(worktree),
    'checker_sha256': sha(worktree / 'scripts/lean_check_tree.sh'), 'tree': str(tree),
    'priority': priority, 'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
with (out / 'PLAN.json').open('x') as f:
    json.dump(plan, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(f'{len(changed)} changes, {len(order)} local modules, {len(retained)} verified retained, {len(rebuild)} fresh', flush=True)
print('First fresh checks:', ', '.join(rebuild[:10]), flush=True)
