import re

def comments_removed(s):
    out = []
    i = depth = 0
    while i < len(s):
        if depth:
            if s.startswith('/-', i):
                depth += 1; out.extend('  '); i += 2
            elif s.startswith('-/', i):
                depth -= 1; out.extend('  '); i += 2
            else:
                out.append('\n' if s[i] == '\n' else ' '); i += 1
        elif s.startswith('/-', i):
            depth = 1; out.extend('  '); i += 2
        elif s.startswith('--', i):
            j = s.find('\n', i)
            j = len(s) if j < 0 else j
            out.extend(' ' * (j-i)); i = j
        elif s[i] == '"':
            j = i + 1
            while j < len(s):
                if s[j] == '\\': j += 2
                elif s[j] == '"': j += 1; break
                else: j += 1
            out.extend(s[i:j]); i = j
        else:
            out.append(s[i]); i += 1
    assert depth == 0, 'Unterminated block comment'
    return ''.join(out)


def imports(b):
    result = []
    continuing = False
    for line in comments_removed(b.decode()).splitlines():
        s = line.strip()
        if not s or s in ('prelude', 'module'): continue
        m = re.fullmatch(r'(?:(?:public|meta)\s+)*import\s+(.+)', s)
        if m:
            names = m.group(1).split()
            if names[0] == 'all': names = names[1:]
            assert all(re.fullmatch(r"[A-Za-z_«][A-Za-z0-9_'.«»]*", x) for x in names), s
            result.extend(names); continuing = True
        elif continuing and re.fullmatch(r"[A-Z][A-Za-z0-9_'.]*(?:\s+[A-Z][A-Za-z0-9_'.]*)*", s):
            result.extend(s.split())
        else:
            break
    return result


def topo(graph, roots):
    order, done, active = [], set(), set()
    def visit(k):
        if k in done: return
        assert k not in active, ('Import cycle', k)
        active.add(k)
        for d in graph[k]: visit(d)
        active.remove(k); done.add(k); order.append(k)
    for r in roots: visit(r)
    return order


