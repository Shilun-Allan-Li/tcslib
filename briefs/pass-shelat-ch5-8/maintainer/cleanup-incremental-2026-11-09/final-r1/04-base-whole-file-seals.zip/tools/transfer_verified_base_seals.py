import hashlib
import json
from pathlib import Path
import re
import sys

area = Path(sys.argv[1]).resolve()
prior = area.parent / 'gate06-combined-20261108'
base = area / 'seals-base-r2'
current = json.loads((base/'MANIFEST.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None):
    raw = path.read_bytes()
    assert expected is None or sha(raw) == expected, path
    return json.loads(raw)


epoch = read(prior/'projection-delta-native-r2/START.json',
             '534c5cfdcc136d9b2f78196d5dc3c30177f6d73c2774f11bdadd741aaa0ec1f5')
final = read(prior/'projection-delta-native-r2/final-seal-and-census.json',
             '496df1baf5b893f4a237394bb815ed73c01bc68deae6e9d5bbeced3a05640437')
survey = read(prior/'rule10-payload-retry-r3/effective-results.json',
              '889a1e798e52dc1cc53cb04f0278d0c6a9fc525530d4cab1aff0181356e51e29')
native = read(prior/'projection-delta-native-r2/RESULT.json',
              '57f6576250aba238b05abefef08d03cd77e2e0e6727c5e30aee5c78da418a842')
assert final['head'] == epoch['head'] == native['head']
assert final['effective_owner_count'] == survey['completed_probes'] == 59
adapter = read(prior/'rule10-evidence-r2/final-adapter.json',
               'ec264e3f9b930f2c520534d245b4ff7588b15e21e818ffa1df147b510e20f4b2')
archive = read(prior/'rule10-evidence-r2/seal-manifest.json',adapter['seal_manifest_sha256'])
previous = {p['module']:p for p in archive['probes']}
selected = {p['module']:p for p in survey['selected']}
fresh = {p['owner']:p for p in final['fresh_seals']}
retained = set(final['retained_seal_owners'])
assert set(fresh).isdisjoint(retained) and len(set(fresh)|retained)==59
fields = ('spelling','home','matcher','collector_reducibility','instance','abbrev','name_components','home_components')

diagnostic = re.compile(r'^.+\.lean:(\d+):(\d+): (error(?:\([^\n)]*\))?|warning(?:\([^\n)]*\))?|info):', re.M)
results = []
for p in current['probes']:
    owner = p['owner']
    if owner not in previous:
        continue
    old = previous[owner]
    meta = read(base/(p['label']+'.json'))
    assert old['source'] == p['path']
    if set(old['import_closure']) != set(meta['closure_homes']):
        continue
    requests = lambda rows: [tuple(row[k] for k in fields) for row in rows]
    if requests(old['requested_names']) != requests(meta['requested']):
        continue
    assert epoch['source_files'][p['path']] == p['source_sha256']
    if owner in fresh:
        checked = fresh[owner]
        assert checked['valid_harness'] and checked['source_errors'] == 0 and checked['requested_count'] == p['requested']
        outcome = next(q for q in native['results'] if q['module'] == checked['probe'])
        assert outcome['rc'] == 0 and outcome['source_sha256'] == checked['probe_sha256']
        label = f'{10+list(fresh).index(owner)+1:02d}-Seal{checked["ordinal"]:03d}'
        log = prior/'projection-delta-native-r2'/(label+'.log')
        assert sha(log.read_bytes()) == outcome['log_sha256'] == checked['log_sha256']
        rc, errors = 0, []
        evaluated = checked['probe_sha256']
        receipt_path = prior/'projection-delta-native-r2/final-seal-and-census.json'
    else:
        assert owner in retained and old['source_sha256'] == p['source_sha256']
        chosen = selected[owner]
        suffix = 'native-seal-runs' if chosen['origin'] == 'original' else 'native-payload-retry-r3'
        receipt_path = prior/'rule10-evidence-r2'/suffix/(chosen['label']+'.classification.json')
        prior_result = read(receipt_path)
        assert sha(json.dumps(prior_result,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()) == chosen['record_sha256']
        assert prior_result['valid_harness'] and prior_result['captured_probe_sha256'] == chosen['probe_sha256']
        log = Path(prior_result['log'])
        text = log.read_text()
        assert sha(log.read_bytes()) == prior_result['log_sha256']
        rc = prior_result['result']['rc']
        hits = list(diagnostic.finditer(text))
        positions = {(e['probe_line'],e['probe_column']):e['source_line'] for e in prior_result['errors']}
        errors = []
        for i,m in enumerate(hits):
            if not m[3].startswith('error'):
                continue
            pos = (int(m[1]),int(m[2]))
            stop = hits[i+1].start() if i+1<len(hits) else len(text)
            body = text[m.end():stop].split('\nFAIL(',1)[0].strip()
            errors.append({'probe_line':pos[0],'column':pos[1],'source_line':positions[pos],'text':body})
        assert len(errors) == len(prior_result['errors']) and (rc == 0) == (not errors)
        evaluated = chosen['probe_sha256']
    results.append({**p, 'rc':rc,'errors':errors,'valid_harness':True,'problem':None,
                    'meta_sha256':sha((base/(p['label']+'.json')).read_bytes()),
                    'log':str(log),'log_sha256':sha(log.read_bytes()),
                    'native_probe_sha256':evaluated,'mode':'verified_gate06_baseline_reuse',
                    'receipt_path':str(receipt_path),'receipt_sha256':sha(receipt_path.read_bytes())})
out = area/'seals-base-verified-transfers.json'
with out.open('x') as f:
    json.dump({'base':current['base'],'native_base':epoch['head'],'outcomes':results}, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(len(results),'exact source/closure/request baseline transfers')
