from hashlib import file_digest
import json
from pathlib import Path
import sys

master, output, *lanes = map(Path, sys.argv[1:])
manifest = json.loads((master/'MANIFEST.json').read_bytes())
expected = {p['label']:p for p in manifest['probes']}


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


success = {}
for lane in (master,*(p for p in lanes if p.is_dir())):
    for path in sorted(lane.glob('run-*/CleanupSeal*.json')):
        row = json.loads(path.read_bytes())
        if not row['valid_harness']:
            continue
        label = row['label']
        assert all(row[k] == v for k,v in expected[label].items()), label
        assert sha(master/(label+'.json')) == row['meta_sha256'], label
        assert sha(Path(row['log'])) == row['log_sha256'], label
        if label in success:
            assert row['rc'] == success[label]['rc'] and row['errors'] == success[label]['errors'], label
        success.setdefault(label,row)
for transfer in (p for p in lanes if p.is_file()):
    evidence = json.loads(transfer.read_bytes())
    assert evidence['base'] == manifest['base'] and manifest['side'] == 'base'
    for row in evidence['outcomes']:
        label = row['label']
        assert row['mode'] == 'verified_gate06_baseline_reuse' and row['valid_harness']
        assert all(row[k] == v for k,v in expected[label].items()), label
        assert sha(master/(label+'.json')) == row['meta_sha256'], label
        assert sha(Path(row['log'])) == row['log_sha256'], label
        assert sha(Path(row['receipt_path'])) == row['receipt_sha256'], label
        success.setdefault(label,row)
missing = sorted(expected.keys()-success.keys())
if missing:
    print(f'{len(success)} valid probes, {len(missing)} pending, first {missing[:8]}')
    raise SystemExit(75)
ordered=[success[p['label']] for p in manifest['probes']]
with output.open('x') as stream:
    json.dump({'manifest_sha256':sha(master/'MANIFEST.json'),'outcomes':ordered,
               'source_passes':sum(r['rc']==0 for r in ordered),
               'source_errors':sum(len(r['errors']) for r in ordered)},stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(len(ordered),'valid seals')
