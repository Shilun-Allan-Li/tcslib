import json
from pathlib import Path
import sys


def names(path):
    data = json.loads(path.read_bytes())
    rows = {tuple(map(tuple, r['name']['components'])): r for r in data['roots']}
    assert len(rows) == len(data['roots'])
    return data, rows


def list_records(keys, rows):
    return [rows[key] for key in sorted(keys)]


base_path, head_path, output = map(Path, sys.argv[1:4])
base, before = names(base_path)
head, after = names(head_path)
assert base['owners'] == head['owners']
common = before.keys() & after.keys()
summary = {
    'base_count': len(before), 'head_count': len(after), 'common_count': len(common),
    'base_axiom_controls': base['native_axiom_controls'], 'head_axiom_controls': head['native_axiom_controls'],
    'base_axiom_names': base['axiom_names'], 'head_axiom_names': head['axiom_names'],
    'added': list_records(after.keys() - before.keys(), after),
    'removed': list_records(before.keys() - after.keys(), before),
    'rehomed': [], 'type_changes': [], 'definition_changes': [], 'kind_changes': [],
    'axiom_changes': [], 'new_sorry_dependencies': [], 'reference_changes': [],
}
for key in sorted(common):
    a, b = before[key], after[key]
    fields = {
        'rehomed': ('home',), 'type_changes': ('type_sha256', 'universes'),
        'definition_changes': ('definition_sha256',), 'kind_changes': ('kind',),
        'axiom_changes': ('axioms',), 'reference_changes': ('type_refs', 'value_refs'),
    }
    for tag, values in fields.items():
        if any(a[f] != b[f] for f in values):
            summary[tag].append({'name': b['name'], 'base_home': a['home'], 'head_home': b['home'],
                                 'base': {f: a[f] for f in values}, 'head': {f: b[f] for f in values}})
    if 'sorryAx' in b['axioms'] and 'sorryAx' not in a['axioms']:
        summary['new_sorry_dependencies'].append(b)
summary['new_sorry_dependencies'].extend(r for r in summary['added'] if 'sorryAx' in r['axioms'])
with output.open('x') as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print({k: len(v) if isinstance(v, list) else v for k,v in summary.items()})
