#!/usr/bin/env bash
set -euo pipefail
area=$1
side=$2
tree=$3
plan=$4
census=$area/census-final-r1
if [[ $side == Base ]]; then
    [[ -s $census/Base-compact.json && -s $tree/.verified ]]
    names=(BaseC3 BaseKind)
else
    [[ $side == Head ]]
    [[ -s $(dirname "$tree")/RESULT.json ]]
    test ! -e "$census/Head.jsonl"
    names=(Head HeadC3 HeadKind)
fi
lean_binary=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$plan")
run=$(mktemp -d "$PWD/$census/$side-metadata.XXXXXXXX")
printf '%s\n' "$run"
for name in "${names[@]}"; do
    cp "$census/$name.lean" "$run/$name.source.txt"
    /usr/bin/memory_pressure -Q > "$run/$name.resources.txt"
    python3 -I - "$run/$name.resources.txt" <<'PY'
from pathlib import Path
import re,sys
t=Path(sys.argv[1]).read_text()
assert int(re.search(r'system has (\d+)',t)[1]) * (int(re.search(r'memory free percentage:\s*(\d+)%',t)[1])-1) // 100 >= 4 * 1024**3
PY
    env -u LEAN_PATH -u LEAN_SRC_PATH -u LEAN_SYSROOT -u LEAN_OPTS -u ELAN_TOOLCHAIN -u PFR_BOOTSTRAP_CONFIG \
      TCSLIB_OLEANS="$tree" PATH="${lean_binary%/*}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
      bash scripts/lean_check_tree.sh "$census/$name" > "$run/$name.log" 2>&1 || { tail -n 35 "$run/$name.log"; exit 1; }
    shasum -a 256 "$run/$name.source.txt" "$run/$name.log" > "$run/$name.sha256"
    tail -n 1 "$run/$name.log" | cut -c 1-220
done
if [[ $side == Head ]]; then
    python3 -I "$area/tools/summarize_census.py" "$census/Head.jsonl" "$census/Head-compact.json"
    python3 -I "$area/tools/compare_census.py" "$area/census-r1/Base-compact.json" "$census/Head-compact.json" "$census/COMPARE.json"
fi
