"""Join the actual native census with the independently reviewed source exceptions."""
from collections import Counter
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area = Path(sys.argv[1])
output = Path(sys.argv[2])
root = Path.cwd()
plan = json.loads((area/'native-r3/PLAN.json').read_bytes())
d = json.loads((area/'census-final-r1/COMPARE.json').read_bytes())
prior = '32b827c017bc321ea40577bc8f27131df2c35e1a'
scope = root/'briefs/pass-shelat-ch5-8/fills/cleanup-part2/checkpoints/partial-r1'
own = area.parent/'gate06-combined-20261108/source-review/final-static-r1/scan_explicit.py'


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


lexer = load_module(own, 'reviewed_source_masker')
parser = load_module(
    root/'briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1/explicit-scan-r1/declx.py',
    'reviewed_source_extents')


def source(revision, path):
    return subprocess.check_output(['git','show',revision + ':' + path]).decode()


def digest(text):
    return sha256(text.encode()).hexdigest()


def components(row):
    return row['name']['components']


def generated(row):
    return any(k == 'str' and re.fullmatch(r'(?:_proof_|_simp_|match_|eq_)\d+(?:_\d+)*|splitter|eq_def|eq_unfold|congr_simp|_sunfold', n)
               for k, n in components(row))


def user_spelling(row):
    parts = components(row)
    if parts[0] == ['str','_private']:
        first = next(i for i, p in enumerate(parts) if p[0] == 'num') + 1
        return '.'.join(part[1] for part in parts[first:])
    return row['name']['display']


def raw_definition(revision, owner, spelling):
    path = owner.replace('.','/') + '.lean'
    text = source(revision,path)
    row, = [e for e in parser.extents(text) if e['name']==spelling]
    return ''.join(text.splitlines(keepends=True)[row['start']-1:row['end']])


with ZipFile(scope/'review-r1/review-source-scope.zip') as archive:
    approved = json.loads(archive.read('exception-classification.json'))
authorized = {r['canonical']:r for r in approved}
assert not d['kind_changes'] and not d['new_sorry_dependencies']
assert all(generated(r) for r in d['type_changes']), 'handwritten stored type changed'
assert all(r['kind']=='theorem' for r in d['added'] if not generated(r))
body_review = []
for row in d['definition_changes']:
    if generated(row):
        assert 'match_1_1' in row['name']['display'], row
        body_review.append({**row,'reason':'generated matcher or splitter for the retained proof elaboration'})
        continue
    spelling = user_spelling(row)
    item = authorized[spelling]
    assert 'BODY_CHANGED' in item['flags'], spelling
    original = raw_definition(prior,row['head_home'],spelling)
    candidate = raw_definition(plan['head'],row['head_home'],spelling)
    assert original == candidate, spelling
    body_review.append({**row,'reason':item['permission'],'reviewed_candidate_source_sha256':digest(candidate)})
retired = []
for row in d['removed']:
    if generated(row):
        continue
    spelling = user_spelling(row)
    record = authorized.get(spelling)
    # Some same-spelling private helpers have multiple homes, so check exact path.
    path = row['home'].replace('.','/') + '.lean'
    matches = [r for r in approved if r['canonical']==spelling and r.get('old',{}).get('path')==path]
    retired.append({**row, 'source_exception_matches':matches})
    if components(row)[0] != ['str','_private']:
        assert len(matches)==1, spelling
rehome_review = []
for row in d['rehomed']:
    if generated(row):
        rehome_review.append({**row,'reason':'Lean generated reference home in the broad native catalog'})
        continue
    spelling = user_spelling(row)
    permission = authorized[spelling]
    assert permission['old']['path'] == row['base_home'].replace('.','/') + '.lean'
    assert permission['new']['path'] == row['head_home'].replace('.','/') + '.lean'
    rehome_review.append({**row,'reason':permission['permission']})
admissions = []
changed_paths = (area/'static-r1/pathlist.txt').read_text().splitlines()
for path in changed_paths:
    before, after = (source(plan[side],path) for side in ('base','head'))
    def admitted(raw):
        exts = parser.extents(raw)
        result = []
        for i, line in enumerate(lexer.blank(raw).splitlines(), 1):
            for tok in re.finditer(r"(?<![\w'])\b(sorry|admit|axiom|sorryAx|implemented_by|native_decide|unsafe)\b(?![\w'])", line):
                entries = [e for e in exts if e['dstart'] <= i <= e['end']]
                assert len(entries)==1, (path,i,line,entries)
                span = entries[0]
                raw_block = ''.join(raw.splitlines(keepends=True)[span['start']-1:span['end']])
                result.append((tok[1],span['name'],digest(raw_block)))
        return Counter(result)
    a,b = admitted(before), admitted(after)
    assert a==b, (path,a-b,b-a)
    admissions.extend({'path':path,'name':nm,'token':tok,'exact_block_sha256':h,'count':n}
                      for (tok,nm,h),n in sorted(a.items()))
probability = {}
for path in (
    'TCSlib/Cryptography/Randomness/Extraction.lean',
    'TCSlib/InformationTheory/Samples.lean',
):
    a = source(plan['base'],path)
    assert a==source(plan['head'],path)
    probability[path]=digest(a)
result = {
    'base':plan['base'], 'head':plan['head'], 'prior_reviewed_head':prior,
    'generated_types_changed':d['type_changes'], 'handwritten_types_changed':[],
    'body_changes':body_review, 'rehome':rehome_review, 'retired_handwritten':retired,
    'standard_axiom_changes':d['axiom_changes'], 'new_sorry_dependencies':d['new_sorry_dependencies'],
    'unchanged_sensitive_source_tokens':admissions, 'probability_projection_repairs':probability,
}
with output.open('x') as f:
    json.dump(result,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(len(body_review), 'body changes,', len(retired), 'retired handwritten identities,',
      len(admissions), 'sensitive source token rows', flush=True)
