"""Compare actual generated-equation references and reconcile their native root sets."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import sys

area=Path(sys.argv[1])
plan=json.loads((area/'native-r3/PLAN.json').read_bytes())
base_log,=area.glob('census-r1/Base-metadata.*/BaseC3.log')
head_log,=area.glob('census-final-r1/FinalPins.*/HeadC3.log')
counts=[]
references=[]
logs=[]
for log,revision,compact in (
    (base_log,plan['base'],area/'census-r1/Base-compact.json'),
    (head_log,plan['head'],area/'census-final-r1/Head-compact.json'),
):
    text=log.read_text()
    labels=re.findall(r'G06-C3-(?:BEGIN|END) base=([0-9a-f]+) head=([0-9a-f]+)',text)
    assert labels==[(plan['base'],revision)]*2
    assert text.count('G06-C3-CONTROL generated expected=1 actual=1')==1
    assert text.count('G06-C3-CONTROL published_reader expected=0 actual=0')==1
    root_rows=[tuple(m.split(' | ')[:2]) for m in re.findall(r'(?m)^G06-C3-ROOT (.+)$',text)]
    wanted={(r['home'],r['name']['display']) for r in json.loads(compact.read_bytes())['roots']}
    assert len(root_rows)==len(wanted) and set(root_rows)==wanted
    refs=Counter(tuple(m.split(' | ')) for m in re.findall(r'(?m)^G06-C3-REF (.+)$',text))
    reported=int(re.search(r'G06-C3-END .* pairs=(\d+)',text)[1])
    assert reported==sum(refs.values())
    assert all(row[:2] in wanted for row in refs)
    with log.open('rb') as f:
        logs.append({'revision':revision,'path':str(log),'sha256':file_digest(f,'sha256').hexdigest()})
    references.append(refs)
    counts.append(len(wanted))
a,b=references
result={'base_revision':plan['base'],'head_revision':plan['head'],'root_counts':counts,
        'base':sum(a.values()),'head':sum(b.values()),'new':list((b-a).elements()),
        'removed':sum((a-b).values()),'retained':list((a&b).elements()),'logs':logs}
with (area/'census-final-r1/C3-COMPARE.json').open('x') as f:
    json.dump(result,f,indent=2,ensure_ascii=False)
    f.write('\n')
assert not result['new']
print(counts,'stored roots,', result['head'], 'retained pairs,',result['removed'],'removed',flush=True)
