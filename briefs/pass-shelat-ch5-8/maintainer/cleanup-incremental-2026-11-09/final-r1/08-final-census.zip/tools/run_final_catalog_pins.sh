#!/usr/bin/env bash
set -euo pipefail
area=$1
tree=$2
plan=$3
census=$area/census-final-r1
pin_line=$(python3 -I -c 'import json,sys; p=json.load(open(sys.argv[1])); print(p["base"],p["head"],p["toolchain"])' "$plan")
read -r base head lean_binary <<< "$pin_line"
run=$(mktemp -d "$census/FinalPins.XXXXXXXX")
printf '%s\n' "$run"
for name in HeadC3 HeadKind; do
    source="$census/pinned-sources/$name.lean"
    cp "$source" "$run/$name.source.txt"
    /usr/bin/memory_pressure -Q > "$run/$name.resources.txt"
    python3 -I - "$run/$name.resources.txt" <<'RESOURCE'
from pathlib import Path
import re,sys
s=Path(sys.argv[1]).read_text()
total=int(re.search(r'system has (\d+)',s)[1])
percent=int(re.search(r'memory free percentage:\s*(\d+)%',s)[1])
assert total*(percent-1)//100 >= 4*1024**3
RESOURCE
    env -u LEAN_PATH -u LEAN_SRC_PATH -u LEAN_SYSROOT -u LEAN_OPTS -u ELAN_TOOLCHAIN -u PFR_BOOTSTRAP_CONFIG \
      TCSLIB_OLEANS="$tree" PATH="${lean_binary%/*}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
      bash scripts/lean_check_tree.sh "${source%.lean}" > "$run/$name.log" 2>&1
    test "$(rg -c "base=$base head=$head" "$run/$name.log")" -eq 2
    shasum -a 256 "$run/$name.source.txt" "$run/$name.log" > "$run/$name.sha256"
    tail -n 1 "$run/$name.log" | cut -c 1-220
done
