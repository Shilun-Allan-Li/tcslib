from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)


def identity(value):
    return tuple(tuple(part) for part in value['components'])


def digest(value):
    raw = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
    return sha256(raw).hexdigest()


def names(rows):
    return {identity(value) for value in rows}


def compact(source):
    catalog, roots, graph, controls, display, axioms = {}, {}, {}, {}, {}, set()
    complete = None
    with source.open() as stream:
        for line in stream:
            row = json.loads(line)
            assert complete is None, 'Rows after the completion marker'
            tag = row['record']
            if tag == 'complete':
                complete = row
                continue
            name = identity(row['name'])
            label = row['name']['display']
            assert name not in display or display[name] == label, name
            display[name] = label
            if tag == 'catalog':
                assert name not in catalog
                catalog[name] = row
            elif tag == 'root':
                assert name not in roots and name in catalog
                assert catalog[name]['home'] == row['home'] and catalog[name]['kind'] == row['kind']
                roots[name] = {
                    'home': row['home']['display'], 'name': row['name'], 'kind': row['kind'],
                    'type_sha256': digest(row['type']), 'universes': row['levels'],
                    'definition_sha256': digest(row['definition_value']) if row['kind'] == 'def' else None,
                    'type_refs': sorted(names(row['type_refs'])), 'value_refs': sorted(names(row['value_refs'])),
                }
            elif tag == 'node':
                assert name not in graph
                graph[name] = names(row['dependencies'])
                if row['is_axiom']:
                    axioms.add(name)
            elif tag == 'control':
                assert name not in controls
                controls[name] = names(row['axioms'])
            else:
                raise ValueError(tag)
    assert complete and complete['catalog'] == len(catalog) and complete['roots'] == len(roots) and complete['nodes'] == len(graph)
    owners = names(complete['owners'])
    assert set(roots) == {name for name, row in catalog.items() if identity(row['home']) in owners}
    assert set(controls) <= set(roots) <= set(graph)
    assert len(controls) == len({roots[n]['home'] for n in roots})
    parents = defaultdict(set)
    for name, deps in graph.items():
        assert deps <= graph.keys(), (name, deps - graph.keys())
        for dependency in deps:
            parents[dependency].add(name)

    # Reverse reachability is exact even for inductive/constructor cycles.
    reachable = defaultdict(set)
    for axiom in sorted(axioms):
        pending = [axiom]
        seen = set(pending)
        while pending:
            name = pending.pop()
            reachable[name].add(axiom)
            for parent in parents[name] - seen:
                seen.add(parent)
                pending.append(parent)
    assert all(reachable[name] == expected for name, expected in controls.items()), 'native control differs'

    for name, row in roots.items():
        row['axioms'] = [display[ref] for ref in sorted(reachable[name])]
        row['type_refs'] = [display.get(ref, str(ref)) for ref in row['type_refs']]
        row['value_refs'] = [display.get(ref, str(ref)) for ref in row['value_refs']]
    result = {'owners': complete['owners'], 'catalog': len(catalog), 'nodes': len(graph),
              'native_axiom_controls': len(controls), 'roots': list(roots.values()),
              'axiom_names': [display[a] for a in sorted(axioms)]}
    return result


source, output = map(Path, sys.argv[1:3])
result = compact(source)
with output.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, separators=(',', ':'))
    stream.write('\n')
print(f'{len(result["roots"])} roots, {result["native_axiom_controls"]} exact native controls; axioms {result["axiom_names"]}', flush=True)
