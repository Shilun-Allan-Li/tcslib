"""Bound escaped string tokens in one generated Gate06 seal command."""

import json


MAX_TOKEN_BYTES = 65536
ASSIGNMENTS = (
    b"  let payload : String := ",
    b"  let componentPayload : String := ",
)


def quoted(value: str) -> bytes:
    return json.dumps(value, ensure_ascii=False).encode("utf-8")


def bound_literal(literal: bytes) -> bytes:
    payload = json.loads(literal)
    if not isinstance(payload, str) or quoted(payload) != literal:
        raise ValueError("seal payload is not the expected JSON string literal")
    if any(ord(char) < 32 and char not in "\t\n" for char in payload):
        raise ValueError("unexpected control character in seal payload")
    if len(literal) <= MAX_TOKEN_BYTES:
        return literal

    tokens, chunk = [], []
    size = 2  # Opening and closing quotes.
    rows = payload.split("\n")
    for index, row in enumerate(rows):
        if index + 1 < len(rows):
            row += "\n"
        escaped = quoted(row)[1:-1]
        if len(escaped) + 2 > MAX_TOKEN_BYTES:
            raise ValueError("one seal payload row exceeds the token bound")
        if size + len(escaped) > MAX_TOKEN_BYTES:
            tokens.append(b'"' + b"".join(chunk) + b'"')
            chunk, size = [], 2
        chunk.append(escaped)
        size += len(escaped)
    tokens.append(b'"' + b"".join(chunk) + b'"')
    if (any(len(token) > MAX_TOKEN_BYTES for token in tokens) or
            "".join(json.loads(token) for token in tokens) != payload):
        raise ValueError("seal payload chunking changed the decoded string or exceeded the token bound")
    return b"(" + b" ++ ".join(tokens) + b")"


def bound_payloads(raw: bytes) -> bytes:
    """Replace only the two literal expressions and preserve physical lines."""
    lines = raw.split(b"\n")
    for prefix in ASSIGNMENTS:
        matches = [index for index, line in enumerate(lines) if line.startswith(prefix)]
        if len(matches) != 1:
            raise ValueError(f"expected one seal payload assignment {prefix!r}")
        index = matches[0]
        lines[index] = prefix + bound_literal(lines[index][len(prefix):])
    result = b"\n".join(lines)
    if result.count(b"\n") != raw.count(b"\n"):
        raise ValueError("seal payload chunking changed physical line count")
    return result
