import hashlib
import importlib.util
import json
from pathlib import Path
import sys

workspace = Path.cwd()
area, seals, output = (Path(arg).resolve() for arg in sys.argv[1:4])
previous = area.parent / 'gate06-combined-20261108'
tools = previous / 'rule10-evidence-r2/tool-inputs'
evidence = previous / 'rule10-evidence-r2'


def load(file, label):
    spec = importlib.util.spec_from_file_location(label, file)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sha(b):
    return hashlib.sha256(b).hexdigest()


builder = load(tools/'build_seals.py', 'reviewed_seal_builder')
control = load(tools/'build_controls.py', 'reviewed_control_builder')
adapter = load(tools/'request_payload_adapter.py', 'reviewed_adapter')
bound = load(previous/'rule10-payload-retry-r3/bound_payload.py', 'reviewed_bound')
adapter.configure_builders(builder, control)
seal_build, catalog_build = builder.seal_command, control.catalog_command
builder.seal_command = lambda label, rows, *, end: bound.bound_payloads(seal_build(label, rows, end=end))
control.catalog_command = lambda bs, label, rows, phase: bound.bound_payloads(catalog_build(bs, label, rows, phase))

historical = json.loads((evidence/'controls-manifest.json').read_bytes())
manifest = json.loads((seals/'MANIFEST.json').read_bytes())
owner = historical['audited_module']
probe = next(row for row in manifest['probes'] if row['owner'] == owner)
rows = json.loads((seals/(probe['label']+'.json')).read_bytes())['requested']
names = {row['spelling'] for row in rows}
assert set(historical['required_negative_targets']) <= names
output.mkdir()
fresh = []
for item in historical['probes']:
    raw = Path(item['saved_source']).read_bytes()
    assert sha(raw) == item['source_sha256']
    prefix, suffix = b'namespace Gate06Sensitivity\n\n', b'\nend Gate06Sensitivity'
    assert raw.count(prefix) == raw.count(suffix) == 1
    body = raw.split(prefix, 1)[1].split(suffix, 1)[0]
    if 'body_sha256' in item:
        assert sha(body) == item['body_sha256']
    label = item['label'].replace('G06Control_', 'CleanupControl_')
    is_sealed = item['mode'].lower() == 'sealed'
    src, region = control.assemble(builder, label, owner, rows, body, sealed=is_sealed)
    target = output/(label+'.lean')
    target.write_bytes(src)
    fresh.append({'label': label, 'case': item['case'], 'sealed': is_sealed,
                  'module': target.relative_to(workspace).with_suffix('').as_posix(),
                  'source_sha256': sha(src), 'body_sha256': sha(body),
                  'rfl_lines': region['rfl_lines'], 'expected_rc': 1 if item['expected_exit'] == 'nonzero' else item['expected_exit'],
                  'expected_errors': item['expected_error_diagnostics']})
assert len(fresh) == 13 and sum(row['expected_rc'] == 0 for row in fresh) == 7
(output/'MANIFEST.json').write_text(json.dumps({'head': manifest['head'], 'owner': owner, 'requests': rows,
                                              'probes': fresh}, indent=2, ensure_ascii=False)+'\n')
print(len(fresh),'controls with',len(rows),'requested names')
