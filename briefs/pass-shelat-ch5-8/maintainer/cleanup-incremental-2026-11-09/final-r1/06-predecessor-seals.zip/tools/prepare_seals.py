import functools
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

workspace = Path.cwd()
area = Path(sys.argv[1]).resolve()
side = sys.argv[2]
census = Path(sys.argv[3]).resolve()
dest = Path(sys.argv[4]).resolve()
assert side in ('base', 'head')
previous = area.parent / 'gate06-combined-20261108'
tool_root = previous / 'rule10-evidence-r2/tool-inputs'


def load(path, label):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


bs = load(tool_root / 'build_seals.py', 'reviewed_seals')
controls = load(tool_root / 'build_controls.py', 'reviewed_controls')
adapter = load(tool_root / 'request_payload_adapter.py', 'reviewed_adapter')
bound = load(previous / 'rule10-payload-retry-r3/bound_payload.py', 'reviewed_payload_bound')
adapter.configure_builders(bs, controls)
legacy_seal = bs.seal_command


def seal_command(label, rows, *, end):
    return bound.bound_payloads(legacy_seal(label, rows, end=end))


bs.seal_command = seal_command
plan_path = Path(sys.argv[5]).resolve() if len(sys.argv) > 5 else area / 'native-r1/PLAN.json'
plan = json.loads(plan_path.read_bytes())
context = json.loads((area / 'static-r1/import-contexts.json').read_bytes())
graph = context['baseline'] if side == 'base' else plan['graph']
source_root = workspace if side == 'base' else Path(plan['worktree'])
expected_source = (json.loads((previous / 'projection-delta-native-r2/START.json').read_bytes())['source_files']
                   if side == 'base' else {p + '.lean': d for p, d in plan['source_digests'].items()})
owners = json.loads((census.parent / 'owners.json').read_bytes())

catalog, by_home, roots, complete = {}, {}, {}, None
with census.open() as stream:
    for line in stream:
        row = json.loads(line)
        tag = row['record']
        assert complete is None
        if tag == 'complete':
            complete = row
        elif tag == 'catalog':
            name = row['name']['display']
            home = row['home']['display']
            assert name not in catalog and home.startswith('TCSlib.'), row
            row['status'] = row['status'].rsplit('.', 1)[-1]
            adapter.name_key(row['name'])
            adapter.name_key(row['home'])
            catalog[name] = row
            by_home.setdefault(home, []).append(row)
        elif tag == 'root':
            name = row['name']['display']
            assert name not in roots and catalog[name]['home'] == row['home'], name
            roots[name] = {k: row[k] for k in ('home', 'type_refs', 'value_refs')}
assert complete and complete['catalog'] == len(catalog) and complete['roots'] == len(roots)
assert [r['display'] for r in complete['owners']] == owners
assert len({adapter.name_key(row['name']) for row in catalog.values()}) == len(catalog)


@functools.lru_cache(None)
def closure(name):
    direct = graph[name]
    return set(direct).union(*(closure(dep) for dep in direct))


dest.mkdir()
probes = []
for ordinal, owner in enumerate(owners, 1):
    path = owner.replace('.', '/') + '.lean'
    raw = (source_root / path).read_bytes()
    assert bs.sha(raw) == expected_source[path], path
    info = bs.header(raw)
    home_set = {p.replace('/', '.') for p in closure(owner.replace('.', '/'))}
    header_imports = [m.replace('.', '/') for m in info['imports'] if m.replace('.', '/') in graph]
    assert set(header_imports) == set(graph[owner.replace('.', '/')]), path
    requested, reducible_other = [], []
    for home in sorted(home_set):
        for row in by_home.get(home, []):
            if row['kind'] != 'def':
                continue
            name = row['name']['display']
            if name == 'Complexity.PolyExpr.eval':
                continue
            if row['status'] == 'reducible' and not row['matcher']:
                if not row['abbrev']:
                    reducible_other.append(name)
                continue
            requested.append({'spelling': name, 'home': home, 'matcher': row['matcher'],
                'collector_reducibility': row['status'], 'instance': row['instance'],
                'abbrev': row['abbrev'], 'name_components': row['name']['components'],
                'home_components': row['home']['components'], 'constant_kind': 'def'})
    requested.sort(key=lambda row: row['spelling'])
    root_rows = [r for r in roots.values() if r['home']['display'] == owner]
    root_refs = {n['display'] for r in root_rows for f in ('type_refs', 'value_refs') for n in r[f]}
    actual_terms = {n for n in root_refs if n in catalog and catalog[n]['home']['display'] != owner}
    exact_homes = {}
    for name in sorted(actual_terms):
        if catalog[name]['home']['display'] in home_set:
            continue
        assert (side, owner, name, catalog[name]['kind']) == (
            'base', 'TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphismZK',
            'Complexity.NUPPT.coinLen.eq_1', 'theorem'), (owner, name, catalog[name])
        witness = area / 'census-r1/BaselineEquationHome.log'
        native_home = 'TCSlib.Cryptography.ZeroKnowledge.Defs'
        assert native_home in home_set
        assert f'{name} at {native_home}, axioms [propext, Quot.sound, Classical.choice]' in witness.read_text()
        assert 'TCSlib.Complexity.Randomized.PPT' in home_set
        exact_homes[name] = {'native_home': native_home, 'evidence_sha256': bs.sha(witness.read_bytes())}
    label = f'CleanupSeal{ordinal:03d}'
    probe, inserts, line_map = bs.instrument(raw, info, label, requested)
    rel = dest / (label + '.lean')
    rel.write_bytes(probe)
    with (dest / (label + '.json')).open('x') as f:
        json.dump({'label': label, 'owner': owner, 'path': path, 'requested': requested,
                   'source_sha256': bs.sha(raw), 'probe_sha256': bs.sha(probe), 'insertions': inserts,
                   'line_map': line_map, 'reducible_non_abbrev': sorted(reducible_other),
                   'foreign_root_references': sorted(actual_terms), 'consumer_environment_homes': exact_homes,
                   'closure_homes': sorted(home_set)}, f,
                  ensure_ascii=False, separators=(',', ':'))
    probes.append({'ordinal': ordinal, 'label': label, 'owner': owner, 'path': path,
                   'module': rel.relative_to(workspace).with_suffix('').as_posix(),
                   'probe_sha256': bs.sha(probe), 'source_sha256': bs.sha(raw),
                   'requested': len(requested)})
with (dest / 'MANIFEST.json').open('x') as f:
    json.dump({'side': side, 'base': plan['base'], 'head': plan['head'], 'native_plan': str(plan_path), 'probes': probes}, f, indent=2)
print(f'{side}: {len(probes)} whole-file seals, {sum(p["requested"] for p in probes)} requests', flush=True)
