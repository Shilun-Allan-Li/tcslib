import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

workspace = Path.cwd()
probe_dir, tree = (Path(a).resolve() for a in sys.argv[1:3])
manifest_path = probe_dir / 'MANIFEST.json'
area = probe_dir.parent
manifest = json.loads(manifest_path.read_bytes())
plan_path = Path(manifest.get('native_plan', str(area / 'native-r1/PLAN.json')))
plan = json.loads(plan_path.read_bytes())
tool = area.parent / 'gate06-combined-20261108/rule10-evidence-r2/tool-inputs/request_payload_adapter.py'
spec = importlib.util.spec_from_file_location('reviewed_adapter', tool)
adapter = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = adapter
spec.loader.exec_module(adapter)
source_root = workspace if manifest['side'] == 'base' else Path(plan['worktree'])


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    with path.open('x') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')


def memory():
    result = subprocess.check_output(['/usr/bin/memory_pressure', '-Q'], text=True)
    total = int(re.search(r'system has (\d+)', result)[1])
    free = int(re.search(r'memory free percentage:\s*(\d+)%', result)[1])
    return total * max(free - 1, 0) // 100


def interrupt(sig, _frame):
    raise InterruptedError(f'interrupted by signal {sig}')


assert not (workspace / '.lake/build/lib/lean').exists()
assert shutil.disk_usage(tree).free >= 12 * 1024**3
lock = (tree / '.cleanup-seal.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
if manifest['side'] == 'base':
    assert tree.joinpath('.verified').read_text().strip() == plan['baseline']
else:
    replay = json.loads((tree.parent / 'RESULT.json').read_bytes())
    assert replay['head'] == manifest['head'] and replay['passed']
    assert sha(tree.parent / 'PRODUCTS.json') == replay['products_sha256']
assert not (probe_dir / 'RESULT.json').exists()
lean = Path(plan['toolchain'])
assert sha(lean) == plan['toolchain_sha256']
checker = workspace / 'scripts/lean_check_tree.sh'
assert sha(checker) == plan['checker_sha256']
env = os.environ.copy()
for key in ('LEAN_PATH', 'LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LEAN_OPTS', 'ELAN_TOOLCHAIN', 'PFR_BOOTSTRAP_CONFIG'):
    env.pop(key, None)
env['PATH'] = str(lean.parent) + ':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['TCSLIB_OLEANS'] = str(tree)
for sig in (signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, interrupt)
run = probe_dir / ('run-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f'))
run.mkdir()
write(run / 'START.json', {'manifest_sha256': sha(manifest_path), 'pid': os.getpid(), 'tree': str(tree)})
attempts = {}
for old in sorted(probe_dir.glob('run-*/CleanupSeal*.json')):
    row = json.loads(old.read_bytes())
    if row['valid_harness'] and sha(old.with_suffix('.log')) == row['log_sha256']:
        attempts[row['label']] = row
diagnostic = re.compile(r'^.+\.lean:(\d+):(\d+): (error(?:\([^\n)]*\))?|warning(?:\([^\n)]*\))?|info):', re.M)
outcomes = []
for probe in manifest['probes']:
    label = probe['label']
    meta_path = probe_dir / (label + '.json')
    meta = json.loads(meta_path.read_bytes())
    assert meta['probe_sha256'] == probe['probe_sha256'] == sha(workspace / (probe['module'] + '.lean'))
    assert meta['source_sha256'] == probe['source_sha256'] == sha(source_root / meta['path'])
    prior = attempts.get(label)
    if prior and prior['meta_sha256'] == sha(meta_path):
        outcomes.append(prior)
        continue
    headroom = memory()
    if headroom < 4 * 1024**3:
        write(run / 'DEFERRED.json', {'label': label, 'headroom_bytes': headroom})
        print('DEFERRED for memory before', label, flush=True)
        sys.exit(75)
    log = run / (label + '.log')
    tick = time.monotonic()
    with log.open('xb') as stream:
        proc = subprocess.Popen(['bash', str(checker), probe['module']], cwd=workspace, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            write(run / (label + '.child'), {'pid': proc.pid, 'module': probe['module']})
            rc = proc.wait()
        except BaseException:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
            raise
    text = log.read_text(errors='strict')
    locations = {entry['probe_line']: entry['source_line'] for entry in meta['line_map']}
    found = list(diagnostic.finditer(text))
    errors = []
    for i, match in enumerate(found):
        if not match[3].startswith('error'):
            continue
        stop = found[i+1].start() if i+1 < len(found) else len(text)
        body = text[match.end():stop].split('\nFAIL(', 1)[0].strip()
        errors.append({'probe_line': int(match[1]), 'column': int(match[2]),
                       'source_line': locations.get(int(match[1])), 'text': body})
    problem = None
    try:
        rows = meta['requested']
        expected = len(rows)
        install = re.findall(r'G06-SEAL label=' + label + r' requested=(\d+) active=(\d+) already_irreducible=(\d+) verified=(\d+)', text)
        ending = re.findall(r'G06-SEAL-END label=' + label + r' requested=(\d+) verified=(\d+)', text)
        assert len(install) == len(ending) == 1, 'missing or repeated seal markers'
        n, active, already, verified = map(int, install[0])
        assert n == verified == active + already == expected and list(map(int, ending[0])) == [expected, expected]
        adapter.verify_component_log(text, label, rows, ['install', 'eof'])
        adapter.verify_mask_log(text, label, rows, ['install', 'eof'])
        assert all(e['source_line'] is not None for e in errors), 'error in instrumentation'
        assert (rc == 0) == (not errors), 'native status differs from source diagnostics'
        assert rc in (0, 1), 'unexpected native status'
    except (AssertionError, RuntimeError, ValueError) as exc:
        problem = str(exc) or exc.__class__.__name__
    record = {**probe, 'rc': rc, 'errors': errors, 'valid_harness': problem is None,
              'problem': problem, 'meta_sha256': sha(meta_path), 'log_sha256': sha(log),
              'log': str(log), 'seconds': round(time.monotonic() - tick, 3)}
    write(run / (label + '.json'), record)
    outcomes.append(record)
    print(f'{label} {len(outcomes)}/{len(manifest["probes"])} {probe["owner"]} '
          f'{len(errors)} errors ({problem or "valid"}, {record["seconds"]} s)', flush=True)
    if problem:
        print('Stopped on invalid harness', log, flush=True)
        sys.exit(2)
assert len(outcomes) == len(manifest['probes'])
write(probe_dir / 'RESULT.json', {'manifest_sha256': sha(manifest_path), 'outcomes': outcomes,
                                 'source_passes': sum(r['rc'] == 0 for r in outcomes),
                                 'source_errors': sum(len(r['errors']) for r in outcomes)})
