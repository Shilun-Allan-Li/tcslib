import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys

root = Path.cwd()
folder, tree, plan_path = [Path(arg).resolve() for arg in sys.argv[1:4]]
plan = json.loads(plan_path.read_bytes())
manifest = json.loads((folder / 'MANIFEST.json').read_bytes())
area = folder.parent
prior = area.parent / 'gate06-combined-20261108/rule10-evidence-r2'
tool = prior / 'tool-inputs/request_payload_adapter.py'
spec = importlib.util.spec_from_file_location('reviewed_controls_adapter', tool)
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def interrupt(sig, _frame):
    raise InterruptedError(f'signal {sig}')


result = json.loads((tree.parent / 'RESULT.json').read_bytes())
assert result['passed'] and manifest['head'] == plan['head'] == result['head']
assert sha((tree.parent / 'PRODUCTS.json').read_bytes()) == result['products_sha256']
lock = (tree / '.cleanup-seal.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for sig in (signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, interrupt)
env = os.environ.copy()
for name in ('LEAN_PATH', 'LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LEAN_OPTS', 'ELAN_TOOLCHAIN', 'PFR_BOOTSTRAP_CONFIG'):
    env.pop(name, None)
env['PATH'] = str(Path(plan['toolchain']).parent) + ':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['TCSLIB_OLEANS'] = str(tree)
assert sha((root/'scripts/lean_check_tree.sh').read_bytes()) == plan['checker_sha256']
reader_count = len(json.loads((prior/'controls-manifest.json').read_bytes())['positive_readers'])
outcomes = []
for entry in manifest['probes']:
    label, mod = entry['label'], entry['module']
    assert sha((root/(mod+'.lean')).read_bytes()) == entry['source_sha256']
    mem = subprocess.check_output(['/usr/bin/memory_pressure','-Q'], text=True)
    total = int(re.search(r'system has (\d+)', mem)[1])
    percent = int(re.search(r'memory free percentage:\s*(\d+)%', mem)[1])
    assert total*(percent-1)//100 >= 4*1024**3, mem
    log = folder / (label+'.log')
    with log.open('xb') as f:
        proc = subprocess.Popen(['bash','scripts/lean_check_tree.sh',mod], cwd=root, env=env,
                                stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            (folder/(label+'.pid')).write_text(str(proc.pid)+'\n')
            rc=proc.wait()
        except BaseException:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait()
            raise
    text = log.read_text()
    sealed = entry['sealed']
    before = text.index('G06-CONTROL-CATALOG label=' + label + ' phase=before')
    begin = text.index('G06-CONTROL-BODY-BEGIN ' + label)
    end = text.index('G06-CONTROL-BODY-END ' + label)
    n = len(manifest['requests'])
    assert f'requested={n} verified={n} readers={reader_count}' in text
    if sealed:
        install = text.index('G06-SEAL label=' + label)
        eof = text.index('G06-SEAL-END label=' + label)
        assert before < install < begin < end < eof
    else:
        after = text.index('G06-CONTROL-CATALOG label=' + label + ' phase=after')
        assert before < begin < end < after and 'G06-SEAL label=' not in text
    errors=list(re.finditer(r'(?m)^.+\.lean:(\d+):\d+: error(?:\([^\n)]*\))?:', text))
    assert rc == entry['expected_rc'] and len(errors) == entry['expected_errors'], label
    assert all(int(e[1]) in entry['rfl_lines'] and begin < e.start() < end for e in errors), label
    phases = ['catalog-before', 'install', 'eof'] if sealed else ['catalog-before', 'catalog-after']
    adapter.verify_component_log(text, label, manifest['requests'], phases)
    adapter.verify_mask_log(text, label, manifest['requests'], ['install', 'eof'] if sealed else [])
    outcomes.append({**entry, 'rc': rc, 'errors': [int(e[1]) for e in errors], 'log_sha256': sha(log.read_bytes())})
    print(label, 'verified', flush=True)
with (folder/'RESULT.json').open('x') as f:
    json.dump({'head':plan['head'],'outcomes':outcomes,'passed':True},f,indent=2)
    f.write('\n')
