"""Compare exact source spans and normalized native diagnostics on the scoped pair."""
from collections import Counter, defaultdict
from difflib import SequenceMatcher, unified_diff
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

area = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
partial = '--partial' in sys.argv
plan = json.loads((area / 'native-r2/PLAN.json').read_bytes())
root = Path(plan['worktree'])
tool = root / 'briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1/explicit-scan-r1/declx.py'
spec = importlib.util.spec_from_file_location('reviewed_extents', tool)
parser = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = parser
spec.loader.exec_module(parser)


def sha(raw):
    return sha256(raw).hexdigest()


def get_source(revision, path, expected):
    raw = subprocess.check_output(['git', '-C', str(root), 'show', revision + ':' + path])
    assert sha(raw) == expected
    text = raw.decode()
    return text.splitlines(keepends=True), parser.extents(text)


def block(extent, lines):
    return lines[extent['start'] - 1:extent['end']]


def get_decl(extents, row):
    line = row['source_line']
    options = [e for e in extents if e['dstart'] <= line <= e['end']]
    return options[0] if len(options) == 1 else None


def clean(text):
    # A source diagnostic can precede the EOF seal messages in the same output
    # interval. Compare the complete diagnostic before those probe records.
    text = re.split(r'(?m)^(?:G06-(?:SEAL|COMPONENT|MASK|CONTROL)|FAIL\(|=== Lean)', text, maxsplit=1)[0].strip()
    meta_order = {}
    return re.sub(r'\?([mu])\.\d+\b', lambda m: '?' + m[1] + '.' + str(
        meta_order.setdefault(m[0], len(meta_order) + 1)), text)


def positions(old_lines, new_lines):
    return {
        j + offset + 1: i + offset + 1
        for i, j, length in SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_matching_blocks()
        for offset in range(length)
    }


def indexed(rows, key):
    result = defaultdict(list)
    for row in rows:
        result[row[key]].append(row)
    return result


def spell(actual):
    parts = actual['name']['components']
    if parts[0] == ['str', '_private']:
        ordinal = next(i for i, p in enumerate(parts) if p[0] == 'num')
        return '.'.join(p[1] for p in parts[ordinal + 1:])
    return actual['name']['display']


def native_by_source(compact):
    d = json.loads(compact.read_bytes())
    index = defaultdict(list)
    for row in d['roots']:
        index[row['home'], spell(row)].append(row)
    return index


def actual_ids(index, owner, ext):
    if ext is None:
        return []
    matches = index[owner, ext['name']]
    return [{k: r[k] for k in ('name', 'home', 'type_sha256', 'type_refs', 'value_refs')} for r in matches]


base = json.loads((area/'seals-base-effective-r1.json').read_bytes())['outcomes']
if partial:
    expected = {r['label']:r for r in json.loads((area/'seals-head-r1/MANIFEST.json').read_bytes())['probes']}
    head = {}
    for lane in sorted(area.glob('seals-head-lane*-r1')):
        for attempt in sorted(lane.glob('run-*/CleanupSeal*.json')):
            try:
                row = json.loads(attempt.read_bytes())
            except json.JSONDecodeError:
                continue  # runner is still writing the receipt
            if row['valid_harness']:
                label = row['label']
                assert all(row[k] == v for k,v in expected[label].items())
                head[label] = row
else:
    head = {r['label']:r for r in json.loads((area/'seals-head-effective-r1.json').read_bytes())['outcomes']}
    assert len(head) == len(base)
witnesses = defaultdict(list)
for folder in sorted(area.glob('*-witness-base-r*')):
    if not (folder/'RESULT.json').exists():
        continue
    result = json.loads((folder/'RESULT.json').read_bytes())
    recipe = json.loads((folder/'RECIPE.json').read_bytes())
    assert len(result['outcomes']) == len(recipe)
    for row, item in zip(result['outcomes'], recipe):
        assert row['valid_harness'] and item['side']=='base' and item['label']==row['label']
        assert sha(Path(row['log']).read_bytes()) == row['log_sha256']
        witnesses[item['source_label']].append((row,item))
native_base = native_by_source(area/'census-r1/Base-compact.json')
native_head = native_by_source(area/'census-r1/Head-compact.json')
outcomes = []
for old in base:
    label, owner, path = old['label'], old['owner'], old['path']
    if label not in head:
        continue
    new = head[label]
    assert old['valid_harness'] and new['valid_harness'] and path == new['path']
    if not new['errors']:
        continue
    a, exts_a = get_source(plan['base'], path, old['source_sha256'])
    b, exts_b = get_source(plan['head'], path, new['source_sha256'])
    map_file = positions(a,b)
    before = indexed(exts_a, 'name')
    old_errors = indexed(old['errors'], 'source_line')
    a_meta = (area / 'seals-base-r2' / (label + '.json')).read_bytes()
    b_meta = (area / 'seals-head-r1' / (label + '.json')).read_bytes()
    assert sha(a_meta) == old['meta_sha256'] and sha(b_meta) == new['meta_sha256'], label
    old_meta, new_meta = map(json.loads, (a_meta, b_meta))
    mask_a = {r['spelling']:r for r in old_meta['requested']}
    mask_b = {r['spelling']:r for r in new_meta['requested']}
    same_mask = {n for n in mask_a.keys() & mask_b.keys() if mask_a[n] == mask_b[n]}
    for failure in new['errors']:
        line = failure['source_line']
        ext_b = get_decl(exts_b,failure)
        choices = before[ext_b['name']] if ext_b else []
        ext_a = choices[0] if len(choices) == 1 else None
        mapped = map_file.get(line)
        prior = []
        change = []
        status = 'unpaired'
        if ext_a and ext_b:
            aa, bb = block(ext_a,a), block(ext_b,b)
            change = list(unified_diff(aa,bb,fromfile='base',tofile='candidate',n=2))
            in_decl = positions(aa,bb).get(line - ext_b['start'] + 1)
            if in_decl is not None:
                mapped = in_decl + ext_a['start'] - 1
        matching = [p for p in old_errors[mapped]
                    if p['column']==failure['column'] and clean(p['text'])==clean(failure['text'])]
        if len(matching) == 1:
            prior = matching
            found = get_decl(exts_a, matching[0])
            if ext_a and found == ext_a:
                status = 'same_block' if not change else 'same_step_in_edited_block'
            elif not ext_a and not found and a[mapped-1]==b[line-1]:
                status = 'same_command_outside_declaration'
            else:
                status = 'same_step_owner_unresolved'
        related = [p for p in old['errors'] if ext_a and get_decl(exts_a,p)==ext_a]
        witness_matches = []
        if status=='unpaired':
            for row, recipe in witnesses[label]:
                assert row['source_sha256']==old['source_sha256']
                candidates = [p for p in row['errors'] if clean(p['text'])==clean(failure['text'])
                              and (p['source_line']==mapped or (mapped is None and ext_a and get_decl(exts_a,p)==ext_a))]
                if len(candidates)==1:
                    witness_matches.append({'log':row['log'],'log_sha256':row['log_sha256'],
                                            'diagnostic':{**candidates[0],'text':clean(candidates[0]['text'])},
                                            'recipe':recipe})
            if witness_matches:
                status = 'targeted_baseline_match'
        id_a = actual_ids(native_base,owner,ext_a)
        id_b = actual_ids(native_head,owner,ext_b)
        if not id_a or not id_b:
            ref_same = []
        else:
            ref_same = sorted({r for p in id_a for k in ('type_refs','value_refs') for r in p[k]}
                              & {r for p in id_b for k in ('type_refs','value_refs') for r in p[k]}
                              & same_mask)
        outcomes.append({
            'path': path, 'label': label, 'status': status,
            'head_span': ext_b, 'base_span': ext_a, 'head_actual': id_b, 'base_actual': id_a,
            'head_line': line, 'base_mapped_line': mapped, 'head_source': b[line-1].rstrip(),
            'base_mapped_source': a[mapped-1].rstrip() if mapped else None,
            'head_error': clean(failure['text']), 'column': failure['column'],
            'head_log': new['log'], 'head_log_sha256': new['log_sha256'],
            'base_log': old['log'], 'base_log_sha256': old['log_sha256'],
            'base_matches': [{**p,'text':clean(p['text'])} for p in prior],
            'base_same_declaration': [{**p,'text':clean(p['text'])} for p in related],
            'targeted_witnesses': witness_matches,
            'proof_diff': change,
            'common_sealed_native_references': [mask_b[n] for n in ref_same],
        })
counts = Counter(r['status'] for r in outcomes)
result = {'base':plan['base'], 'head':plan['head'], 'valid_candidate_probes':len(head),
          'partial':partial, 'counts':dict(counts), 'diagnostics':outcomes}
with output.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(len(head), dict(counts), flush=True)
