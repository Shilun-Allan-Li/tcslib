import json
from pathlib import Path
import shutil
import sys

source, lane = map(Path, sys.argv[1:3])
start, end = map(int, sys.argv[3:5])
full = json.loads((source/'MANIFEST.json').read_bytes())
rows = full['probes'][start-1:end]
assert [p['ordinal'] for p in rows] == list(range(start,end+1))
lane.mkdir()
for row in rows:
    shutil.copyfile(source/(row['label']+'.json'),lane/(row['label']+'.json'))
with (lane/'MANIFEST.json').open('x') as f:
    json.dump({**full,'probes':rows},f,ensure_ascii=False,indent=2)
    f.write('\n')
print(f'{lane.name}: probes {start} through {end}')
