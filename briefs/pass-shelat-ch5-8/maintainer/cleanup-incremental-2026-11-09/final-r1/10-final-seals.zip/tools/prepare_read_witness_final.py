"""Instrument the unchanged source with a subset of its already verified request catalog."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

workspace = Path.cwd()
area, dest, recipe = map(lambda arg: Path(arg).resolve(), sys.argv[1:4])
base_master = area/'seals-base-r2'
head_master = area/'seals-head-final-r1'
wanted = json.loads(recipe.read_bytes())
assert wanted and all(row['side'] == wanted[0]['side'] for row in wanted)
side = wanted[0]['side']
master = base_master if side == 'base' else head_master
manifest = json.loads((master/'MANIFEST.json').read_bytes())
assert manifest['side'] == side
plan = json.loads(Path(manifest.get('native_plan', str(area/'native-r1/PLAN.json'))).read_bytes())
source_root = workspace if side == 'base' else Path(plan['worktree'])
previous = area.parent/'gate06-combined-20261108'
tool_root = previous/'rule10-evidence-r2/tool-inputs'


def load(path, label):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sha(data):
    return sha256(data).hexdigest()


bs = load(tool_root/'build_seals.py', 'reviewed_seals')
controls = load(tool_root/'build_controls.py', 'reviewed_controls')
adapter = load(tool_root/'request_payload_adapter.py', 'reviewed_adapter')
bound = load(previous/'rule10-payload-retry-r3/bound_payload.py', 'reviewed_payload_bound')
adapter.configure_builders(bs, controls)
legacy_seal = bs.seal_command


def seal_command(label, rows, *, end):
    return bound.bound_payloads(legacy_seal(label, rows, end=end))


bs.seal_command = seal_command
dest.mkdir()
probes = []
witnesses = []
for row in wanted:
    entry, = [p for p in manifest['probes'] if p['label']==row['source_label']]
    meta_path = master/(entry['label']+'.json')
    original = json.loads(meta_path.read_bytes())
    source = (source_root/entry['path']).read_bytes()
    assert sha(source) == original['source_sha256'] == entry['source_sha256']
    label = row['label']
    assert label.startswith('CleanupSealWitness') and label.isalnum()
    requested = original['requested']
    by_name = {n['spelling']:n for n in requested}
    assert set(row.get('omit', [])) <= set(by_name)
    keep = set(row.get('only', by_name)) - set(row.get('omit', []))
    assert keep and keep <= set(by_name)
    requested = [n for n in requested if n['spelling'] in keep]
    probe, inserts, line_map = bs.instrument(source, bs.header(source), label, requested)
    rel = dest/(label+'.lean')
    rel.write_bytes(probe)
    with (dest/(label+'.json')).open('x') as f:
        json.dump({**original, 'label':label, 'requested':requested, 'probe_sha256':sha(probe),
                   'insertions':inserts, 'line_map':line_map}, f, ensure_ascii=False)
    probes.append({**entry, 'label':label, 'module':rel.relative_to(workspace).with_suffix('').as_posix(),
                   'probe_sha256':sha(probe), 'requested':len(requested)})
    witnesses.append({**row, 'baseline_probe_meta_sha256':sha(meta_path.read_bytes()),
                      'effective_requests':len(requested)})
with (dest/'MANIFEST.json').open('x') as f:
    json.dump({**manifest,'probes':probes}, f, ensure_ascii=False, indent=2)
with (dest/'RECIPE.json').open('x') as f:
    json.dump(witnesses, f, ensure_ascii=False, indent=2)
print(dest, len(probes), flush=True)
