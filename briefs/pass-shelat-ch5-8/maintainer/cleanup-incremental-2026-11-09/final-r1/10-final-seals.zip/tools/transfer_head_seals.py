"""Reuse only predecessor seals with unchanged source, requests and import object bytes."""
from collections import defaultdict
from functools import lru_cache
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

old_probes, new_probes, old_effective, out = map(Path,sys.argv[1:5])


def digest(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(path,data):
    with path.open('x') as f:
        json.dump(data,f,indent=2,ensure_ascii=False)
        f.write('\n')


old_manifest = read(old_probes/'MANIFEST.json')
new_manifest = read(new_probes/'MANIFEST.json')
old_result = read(old_effective)
assert old_result['manifest_sha256']==digest(old_probes/'MANIFEST.json')
assert old_manifest['base']==new_manifest['base']
assert old_manifest['side']==new_manifest['side']=='head'
old_path,new_path = [Path(m['native_plan']) for m in (old_manifest,new_manifest)]
old_plan,new_plan = map(read,(old_path,new_path))
assert old_manifest['head']==old_plan['head'] and new_manifest['head']==new_plan['head']
assert old_plan['head']!=new_plan['head']
assert all(old_plan[k]==new_plan[k] for k in ('toolchain_sha256','checker_sha256'))
assert {k:v['sha256'] for k,v in old_plan['external'].items()}=={k:v['sha256'] for k,v in new_plan['external'].items()}
products = []
for path,plan in ((old_path,old_plan),(new_path,new_plan)):
    native_result = read(path.parent/'RESULT.json')
    product = path.parent/'PRODUCTS.json'
    assert native_result['passed'] and native_result['head']==plan['head']
    assert digest(product)==native_result['products_sha256']
    products.append(read(product))
old_products,new_products = products


@lru_cache(maxsize=None)
def closure(module,side):
    graph = (old_plan,new_plan)[side]['graph']
    direct = graph[module]
    return set(direct).union(*(closure(x,side) for x in direct))


transfer = []
pending = []
checks = {}
for old,new in zip(old_result['outcomes'],new_manifest['probes'],strict=True):
    label,owner = new['label'],new['owner']
    mod = owner.replace('.','/')
    assert old['label']==label and old['owner']==owner and old['valid_harness']
    a_meta,b_meta = (folder/(label+'.json') for folder in (old_probes,new_probes))
    a,b = read(a_meta),read(b_meta)
    assert old['meta_sha256']==digest(a_meta)
    c0,c1 = closure(mod,0),closure(mod,1)
    changes = sorted(k for k in c0 & c1 if old_products[k]['object_sha256'] != new_products[k]['object_sha256'])
    same_probe = a==b and old['source_sha256']==new['source_sha256'] and old['probe_sha256']==new['probe_sha256']
    assert digest(Path(new_plan['worktree'])/new['path'])==new['source_sha256']
    checks[label]={'same_probe':same_probe,'closure_changed':c0!=c1,'changed_dependency_objects':changes}
    if not same_probe or c0!=c1 or changes:
        pending.append((new,old['seconds']))
        continue
    assert digest(Path(old['log']))==old['log_sha256']
    transfer.append({**old,**new,'mode':'verified_candidate_predecessor_reuse',
                     'meta_sha256':digest(b_meta),'previous_head':old_plan['head'],
                     'previous_meta_sha256':old['meta_sha256'],'dependency_count':len(c0)})

out.mkdir()
save(out/'TRANSFER.json',{'head':new_plan['head'],'previous_head':old_plan['head'],'base':new_plan['base'],
                         'old_products_sha256':digest(old_path.parent/'PRODUCTS.json'),
                         'new_products_sha256':digest(new_path.parent/'PRODUCTS.json'),
                         'old_result_sha256':digest(old_effective),'outcomes':transfer,'checks':checks})
n_lanes = int(sys.argv[5]) if len(sys.argv)>5 else 3
loads = [0.0]*n_lanes
lanes = defaultdict(list)
for row,time in sorted(pending,key=lambda x:-x[1]):
    i = min(range(n_lanes),key=loads.__getitem__)
    loads[i] += time
    lanes[i].append(row)
for i,rows in sorted(lanes.items()):
    rows.sort(key=lambda r:r['ordinal'])
    lane=out.parent/(out.name+'-lane'+str(i+1))
    lane.mkdir()
    for row in rows:
        name=row['label']+'.json'
        shutil.copyfile(new_probes/name,lane/name)
    save(lane/'MANIFEST.json',{**new_manifest,'probes':rows})
    print(lane.name,len(rows), 'prior wall seconds',round(loads[i],1))
print(len(transfer),'exact prior seals;',len(pending),'fresh',flush=True)
