"""ledoc_sqz.py <worktree> <docaudit.tsv> <touched.json> <overrides.tsv> <plan-out.tsv> [--apply]
LE-doc for seq-zk S-02 and derand F-04 (docstring-only). ledoc_sc.py (sc-compose LE-doc) with three changes:
  * rows are keyed by docaudit's file:line through touched.json (docaudit prints shortened names);
  * the five frozen seq-zk targets (statement prose frozen by the brief) are skipped (FROZEN);
  * overrides.tsv (name<TAB>formula, or name<TAB>TEXT:<sentence>) replaces the extracted conclusion where the
    scanner cannot give it (anonymous instance, `let` bodies, a Prop structure); every override is in the plan.
For every other NO-FORMULA row: the declaration's own Lean conclusion (the header text after the first depth-0
':' following the binders, whitespace collapsed); for a def/abbrev/structure whose type has no relation symbol,
the conclusion of its `<name>_eq` / `<name>_iff` reader in the same file. A conclusion already present in a
backticked span of the docstring is not repeated (SKIP-already-stated). Conclusions longer than 240 characters
are cut at a space and end in ` …` (the sc-compose rule; overrides are never cut). The formula "`<conclusion>`." goes on new lines at the
end of the statement prose (before `**Proof sketch` if present, else before the closing `-/`), wrapped at 100."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import frozencheck_lib as F
wt, da, tj, ovf, planf = sys.argv[1:6]; apply = '--apply' in sys.argv
FROZEN = {'TCSlib.Cryptography.ZK.seqRep', 'TCSlib.Cryptography.StatZK.seqRep',
          'TCSlib.Cryptography.InteractiveProof.seqRep', 'TCSlib.Cryptography.InteractiveProofErr.seqRep',
          'TCSlib.Cryptography.EfficientProverProofErr.seqRep'}
REL = re.compile(r'(=|≤|<|≥|>|↔|≃|∈|≠|→)')
T = json.load(open(tj))['files']
OV = {}
if os.path.getsize(ovf):
    for l in open(ovf, encoding='utf-8'):
        if l.strip() and not l.startswith('#'):
            n, v = l.rstrip('\n').split('\t', 1); OV[n] = v
def concl(s, m, d):
    a, he = d['hdr_span']; h = s[a:he]; mk = m[a:he]
    kw = re.match(r'((?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*\w+\s+\S+)', h, re.S)
    i = kw.end(); depth = 0
    while i < len(h):
        c = h[i]
        if mk[i]:
            if c in '([{⟨⦃': depth += 1
            elif c in ')]}⟩⦄': depth -= 1
            elif c == ':' and depth == 0 and not h.startswith(':=', i): return ' '.join(h[i + 1:].split())
        i += 1
    return ''
def wrap(text, tail=0):
    """Greedy wrap at 100 characters; the last line also leaves room for `tail` characters (the text that
    follows the insertion point on its line, e.g. ` -/`)."""
    lines = ['']
    for w in text.split(' '):
        if len(lines[-1]) + len(w) + (1 if lines[-1] else 0) > 100: lines.append(w)
        else: lines[-1] = (lines[-1] + ' ' + w) if lines[-1] else w
    if tail and len(lines[-1]) + tail > 100:
        head, last = lines[-1].rsplit(' ', 1); lines[-1:] = [head, last]
    return '\n'.join(lines)
rows = [l.rstrip('\n').split('\t') for l in open(da, encoding='utf-8')]
byfile = {}
for r in rows:
    if 'NO-FORMULA' not in r[0]: continue
    path, ln = r[1].rsplit(':', 1)
    td = [d for d in T[path]['declarations'] if d['start'] == int(ln)]
    assert len(td) == 1, r
    byfile.setdefault(path, []).append(td[0])
plan = []
for path, tds in sorted(byfile.items()):
    p = os.path.join(wt, path); s = open(p, encoding='utf-8').read(); m = F.code_mask(s); ds = F.decls(s)
    byline = {d['line']: d for d in ds}; byname = {d['name']: d for d in ds}
    edits = []
    for td in tds:
        n = td['name']
        if n in FROZEN:
            plan.append((path, n, 'SKIP-frozen-target', '')); continue
        d = byline[td['decl_line']]
        src = 'conclusion'
        c = concl(s, m, d)
        if d['kind'] in F.DEFKINDS and not REL.search(c):
            for suf in ('_eq', '_iff'):
                if n + suf in byname: c = concl(s, m, byname[n + suf]); src = 'reader ' + n.rsplit('.', 1)[-1] + suf; break
        if n in OV:
            c = OV[n]; src = 'override'
        a = d['hdr_span'][0]
        ds_ = s.rfind('/--', 0, a); de = s.rfind('-/', 0, a)
        doc = s[ds_:de]
        raw = c[5:] if c.startswith('TEXT:') else None
        if raw is None and c and c.replace(' ', '') in ' '.join(re.findall(r'`([^`]*)`', doc)).replace(' ', ''):
            plan.append((path, n, 'SKIP-already-stated', c)); continue
        if not c:
            plan.append((path, n, 'SKIP-no-conclusion', c)); continue
        if raw is None and src != 'override' and len(c) > 240:
            c = c[:240].rsplit(' ', 1)[0] + ' …'
        k = doc.find('**Proof sketch')
        pos = ds_ + (k if k >= 0 else len(doc))
        pre = s[ds_:pos].rstrip(); ins_at = ds_ + len(pre)
        nl = s.find('\n', ins_at); tail = len(s[ins_at:nl if nl >= 0 else len(s)])
        text = wrap(raw if raw is not None else '`' + c + '`.', tail)
        ins = '\n' + text
        if k < 0 and s[ins_at:ins_at + 2] == '-/': ins += ' '
        edits.append((ins_at, ins)); plan.append((path, n, 'INSERT', src + ': ' + (raw if raw is not None else c)))
    if apply:
        for at, ins in sorted(edits, reverse=True): s = s[:at] + ins + s[at:]
        open(p, 'w', encoding='utf-8').write(s)
with open(planf, 'w', encoding='utf-8') as f:
    for x in plan: f.write('\t'.join(x) + '\n')
from collections import Counter
print(Counter(x[2] for x in plan))
