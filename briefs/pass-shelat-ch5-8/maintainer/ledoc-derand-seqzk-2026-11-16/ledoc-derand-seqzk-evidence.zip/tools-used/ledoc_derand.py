"""ledoc_derand.py <worktree>: derand LE-doc F-04, one exact replacement of the Randomized.inBPP_iff docstring in
TCSlib/Complexity/Randomized/Classes.lean by a 4-line docstring stating the theorem's own Lean statement
(`InBPP E L ↔ …`, argument order as in the header) with the [AB09, Definition 7.3] tag. The line count of the
docstring (4) and of the file (1415, a recorded size exceedance, SR-01) are unchanged."""
import sys
p = sys.argv[1] + '/TCSlib/Complexity/Randomized/Classes.lean'
OLD = """/-- A language `L` is in `BPP` for the verifier model `E` exactly when there are
a Boolean verifier `M` and constants `a, k` such that `E.Eff (boolVerifier M)` and,
for every input `x`, members are accepted and nonmembers rejected with probability
at least `2/3` using `polyLen a k |x|` coins. [AB09, Definition 7.3] -/
theorem inBPP_iff (L : Language Bool) :"""
NEW = """/-- Membership of `L` in `BPP` for the verifier model `E`, unfolded [AB09, Definition 7.3]:
`InBPP E L ↔ ∃ (M : List Bool → List Bool → Bool) (a k : ℕ), E.Eff (boolVerifier M) ∧
∀ x : List Bool, (x ∈ L → 2/3 ≤ randProb (polyLen a k x.length) fun r => M x r = true) ∧
(x ∉ L → 2/3 ≤ randProb (polyLen a k x.length) fun r => M x r = false)`. -/
theorem inBPP_iff (L : Language Bool) :"""
s = open(p, encoding='utf-8').read()
assert s.count(OLD) == 1, 'old text not found exactly once'
s = s.replace(OLD, NEW)
open(p, 'w', encoding='utf-8').write(s)
print('replaced 1; widths', [len(l) for l in NEW.split('\n')])
