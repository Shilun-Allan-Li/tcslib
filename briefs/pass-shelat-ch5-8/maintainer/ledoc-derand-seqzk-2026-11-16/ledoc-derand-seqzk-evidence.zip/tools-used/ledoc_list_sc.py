"""ledoc_list_sc.py <worktree> <docaudit.tsv> <out.tsv>: for every NO-FORMULA/LABEL row of docaudit.tsv, the declaration's
file:line, kind, docstring (collapsed) and its statement conclusion (the text after the last depth-0 ':' of the header,
up to the top-level ':=' / 'where', whitespace collapsed), read from the worktree with frozencheck_lib's scanner."""
import sys, re, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import frozencheck_lib as F
wt, da, out = sys.argv[1:4]
rows = [l.rstrip('\n').split('\t') for l in open(da, encoding='utf-8')]
res = []
cache = {}
for r in rows:
    if r[0] == 'OK': continue
    path, line = r[1].rsplit(':', 1); name = r[2]
    if path not in cache:
        s = open(os.path.join(wt, path), encoding='utf-8').read(); cache[path] = (s, F.decls(s), F.code_mask(s))
    s, ds, m = cache[path]
    d = [x for x in ds if x['name'] == name]
    if not d: res.append((r[0], r[1], name, '?', '', '')); continue
    d = d[0]; a, he = d['hdr_span']
    hdr = s[a:he]; mk = m[a:he]
    depth = 0; last = -1
    for i, c in enumerate(hdr):
        if not mk[i]: continue
        if c in '([{⟨⦃': depth += 1
        elif c in ')]}⟩⦄': depth -= 1
        elif c == ':' and depth == 0 and not hdr.startswith(':=', i): last = i
    concl = ' '.join(hdr[last + 1:].split()) if last >= 0 else ''
    doc = ' '.join(d['prose'].split())
    res.append((r[0], r[1], name, d['kind'], doc, concl))
with open(out, 'w', encoding='utf-8') as f:
    for x in res: f.write('\t'.join(x) + '\n')
print(len(res), 'rows')
