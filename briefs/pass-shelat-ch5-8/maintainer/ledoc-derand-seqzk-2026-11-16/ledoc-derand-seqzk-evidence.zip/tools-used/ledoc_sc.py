"""ledoc_sc.py <worktree> <docaudit.tsv> <plan-out.tsv> [--apply]: the sc-compose LE-doc (docstring-only).
For every docaudit row flagged NO-FORMULA, except the frozen targets composeP_efficient / composeV_efficient (frozen prose)
and rows whose docstring already contains the declaration's conclusion in backticks (Prop formulas without a relation
symbol, a docaudit artifact), insert (Prop conclusions without a relation symbol, e.g. `PolyTimeComputable f`, included),
insert the declaration's own Lean conclusion as a formula at the end of its statement prose
(before `**Proof sketch` if present, else before the closing `-/`): a new line "`<conclusion>`." wrapped at 100 characters.
The conclusion is the header text after the first depth-0 ':' following the binders (frozencheck_lib's scanner). For a
`def` whose type has no relation symbol (Prop, List Bool, ...), the conclusion of its `<name>_eq` / `<name>_iff` reader in the
same file is used. Conclusions longer than 240 characters are cut at a space and end in ` …`."""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import frozencheck_lib as F
wt, da, planf = sys.argv[1:4]; apply = '--apply' in sys.argv
FROZEN = {'TCSlib.Cryptography.SecureComputation.HybridProtocol.composeP_efficient',
          'TCSlib.Cryptography.SecureComputation.HybridProtocol.composeV_efficient'}
REL = re.compile(r'(=|≤|<|≥|>|↔|≃|∈|≠|→)')
def concl(s, m, d):
    a, he = d['hdr_span']; h = s[a:he]; mk = m[a:he]
    kw = re.match(r'((?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*\w+\s+\S+)', h, re.S)
    i = kw.end(); depth = 0
    while i < len(h):
        c = h[i]
        if mk[i]:
            if c in '([{⟨⦃': depth += 1
            elif c in ')]}⟩⦄': depth -= 1
            elif c == ':' and depth == 0 and not h.startswith(':=', i): return ' '.join(h[i + 1:].split())
        i += 1
    return ''
rows = [l.rstrip('\n').split('\t') for l in open(da, encoding='utf-8')]
byfile = {}
for r in rows:
    if 'NO-FORMULA' not in r[0] or r[2] in FROZEN: continue
    path = r[1].rsplit(':', 1)[0]; byfile.setdefault(path, []).append(r[2])
plan = []
for path, names in sorted(byfile.items()):
    p = os.path.join(wt, path); s = open(p, encoding='utf-8').read(); m = F.code_mask(s); ds = F.decls(s)
    by = {d['name']: d for d in ds}
    edits = []
    for n in names:
        d = by[n]; c = concl(s, m, d)
        if d['kind'] in F.DEFKINDS and not REL.search(c):
            for suf in ('_eq', '_iff'):
                if n + suf in by: c = concl(s, m, by[n + suf]); break
                base, last = n.rsplit('.', 1)
                alt = base + '.' + last[0].lower() + last[1:] + suf
                if alt in by: c = concl(s, m, by[alt]); break
        a = d['hdr_span'][0]
        ds_ = s.rfind('/--', 0, a); de = s.rfind('-/', 0, a)
        doc = s[ds_:de]
        if c and c.replace(' ', '') in ' '.join(re.findall(r'`([^`]*)`', doc)).replace(' ', ''):
            plan.append((path, n, 'SKIP-already-stated', c)); continue
        if not c:
            plan.append((path, n, 'SKIP-no-conclusion', c)); continue
        if len(c) > 240:
            c = c[:240].rsplit(' ', 1)[0] + ' …'
        k = doc.find('**Proof sketch')
        pos = ds_ + (k if k >= 0 else len(doc))
        # insertion: before the sketch, after the prose's trailing blank line/whitespace kept as is
        words = ('`' + c + '`.').split(' '); lines = ['']
        for w in words:
            if len(lines[-1]) + len(w) + (1 if lines[-1] else 0) > 100: lines.append(w)
            else: lines[-1] = (lines[-1] + ' ' + w) if lines[-1] else w
        text = '\n'.join(lines)
        if k >= 0:
            # place the formula at the end of the prose paragraph(s), before the blank line that precedes the sketch
            pre = s[ds_:pos].rstrip()
            ins_at = ds_ + len(pre); ins = '\n' + text
        else:
            pre = s[ds_:pos].rstrip(); ins_at = ds_ + len(pre); ins = '\n' + text
            if not s[ins_at:pos + 2].startswith(('\n', ' ')): ins += ''
            ins += ' ' if s[ins_at:ins_at + 2] == '-/' else ''
        edits.append((ins_at, ins)); plan.append((path, n, 'INSERT', c))
    if apply:
        for at, ins in sorted(edits, reverse=True): s = s[:at] + ins + s[at:]
        open(p, 'w', encoding='utf-8').write(s)
with open(planf, 'w', encoding='utf-8') as f:
    for x in plan: f.write('\t'.join(x) + '\n')
from collections import Counter
print(Counter(x[2] for x in plan))
