"""Move the oracle and PRF contracts and adapt the proofs that read them."""

import difflib
from pathlib import Path
import sys

root, area = (Path(p).resolve() for p in sys.argv[1:3])
prefix = "TCSlib/Cryptography/"
functions = prefix + "Pseudorandom/Functions"
old = prefix + "Asymptotic/PRF.lean"
new = functions + "/Asymptotic/Defs.lean"
lazy_path, sub_path = (functions + f"/{n}.lean" for n in ("LazySampling", "SubHybrids"))
new_import = "import " + new[:-5].replace("/", ".") + "\n"


def replace(text, before, after):
    assert text.count(before) == 1, before[:220]
    return text.replace(before, after)


prf = (root / old).read_text()
lazys = (root / lazy_path).read_text()
subs = (root / sub_path).read_text()
ns = "namespace TCSlib.Cryptography\n\nopen Complexity Turing Finset\n\n"
end = "\nend TCSlib.Cryptography\n"
assert prf.endswith(end) and lazys.endswith(end) and subs.endswith(end)
oracle_mark = "/-! ### Oracle ensembles and random functions"
ggm_mark = "/-! ### The GGM construction [PS10, Theorem 97.3]"
head = prf[:prf.index(ns)]
contract = prf[prf.index(oracle_mark):prf.index(ggm_mark)]
ggm = prf[prf.index(ggm_mark):]
hist_start = contract.index("/-- The history encoding is")
hist_end = contract.index("/-- A history is encoded pair by pair:")
bridge = contract[hist_start:hist_end]
contract = replace(contract, bridge, "")
bridge = replace(bridge, "  rw [GGMRed.histEnc_eq]\n  rfl", """  rw [GGMRed.histEnc_eq]
  induction h with
  | nil => exact encodeHist_nil
  | cons p h ih => rw [encodeHist_cons, ih, List.foldr_cons]""")
contract = replace(contract, "private theorem pairDecode_true_two", "theorem pairDecode_true_two")

random_reader = """/-- Acceptance against the random oracle ensemble is acceptance against a uniform function
table, with the same oracle adversary and its coins. -/
theorem OracleEnsemble.acceptProb_random_eq {ρ : Type*} [Fintype ρ] (ℓ₁ ℓ₂ : PolyExpr) (n : ℕ)
    (A : OracleAdversary ρ (Fin (ℓ₁.eval n) → Bool) (Fin (ℓ₂.eval n) → Bool)) :
    acceptProb ((OracleEnsemble.random ℓ₁ ℓ₂).O n) (oracleDist A) =
      acceptProb (randomFunction (Fin (ℓ₁.eval n) → Bool) (Fin (ℓ₂.eval n) → Bool)) (oracleDist A) :=
  rfl

"""
marker = "/-- **The two descriptions of a random function agree**"
contract = replace(contract, marker, random_reader + marker)
indist_reader = """/-- Oracle ensembles are indistinguishable iff the oracle advantage is negligible for
each next-query machine and polynomial query budget. -/
theorem OracleEnsemble.indist_iff {ℓ₁ ℓ₂ : PolyExpr} (O O' : OracleEnsemble ℓ₁ ℓ₂) :
    O.Indist O' ↔ ∀ (D : NUPPT) (q : PolyExpr), Negligible fun n =>
      distAdv (O.O n) (O'.O n) (oracleDist (D.toOracleAdversary n (ℓ₁.eval n) (ℓ₂.eval n) (q.eval n))) :=
  Iff.rfl

"""
marker = "/-- **Reflexivity of oracle indistinguishability**"
contract = replace(contract, marker, indist_reader + marker)
contract = replace(contract,
    'consecutive pair `H i, H (i+1)` (`i < m`) with advantage at least `ε / m`. This is the\n'
    'concrete `hybrid_lemma` (`exists_hybrid_gap`) applied to the distinguisher `oracleDist A`.',
    'consecutive pair `H i, H (i+1)` (`i < m`) with advantage at least `ε / m`. Apply the\n'
    'finite hybrid bound `exists_hybrid_gap` to the acceptance probabilities for `oracleDist A`.')
contract = replace(contract, """      ∃ i < m, distAdv (H 0) (H m) (oracleDist A) / m ≤ distAdv (H i) (H (i + 1)) (oracleDist A) :=
  hybrid_lemma hm H (oracleDist A)""".lstrip(), """∃ i < m, distAdv (H 0) (H m) (oracleDist A) / m ≤ distAdv (H i) (H (i + 1)) (oracleDist A) := by
  simpa only [distAdv_def] using exists_hybrid_gap (fun i => acceptProb (H i) (oracleDist A)) hm""")
opts = head[head.index("set_option"):head.index("/-!\n")]
license = head[:head.index("import ")]
doc = """# Asymptotic oracle indistinguishability and pseudorandom functions

An oracle ensemble samples functions at each parameter. The next-query machine
sees the encoded history, uses one coin tape for the interaction, and runs within
an explicit query budget. The pseudorandom function contract combines an efficient
evaluator with indistinguishability from the random oracle [PS10, Definitions 96.1
and 96.2].

The concrete adversaries, random functions, and lazy runs come from [Gar26, §3.4].
The decoder treats malformed moves as rejection. A query after the budget is spent
also gives verdict `false` (foundation decision D7 of `PassShelatChapter2-4Plan.md`).

## Main definitions

* `TCSlib.Cryptography.OracleEnsemble` samples functions from finite seed types.
  `OracleEnsemble.random` uses the function table and `OracleEnsemble.keyed` uses a key.
* `TCSlib.Cryptography.OracleMove`, `decodeOracleMove`, and `encodeHist` specify the
  interface for a next-query machine. `buildTree` and `Complexity.NUPPT.toOracleAdversary`
  turn such a machine into a bounded query tree.
* `TCSlib.Cryptography.OracleEnsemble.Indist` gives the oracle indistinguishability
  condition. `TCSlib.Cryptography.PRF` packages that condition with efficient evaluation.

## Main results

* `TCSlib.Cryptography.acceptProb_random_eq_lazy` equates the two descriptions of a
  random function, by its table and by lazy sampling [PS10, §3.8.1].
* `Complexity.NUPPT.toOracleAdversary_boundedBy` gives the query bound.
* `TCSlib.Cryptography.OracleEnsemble.indist_iff` expresses the contract through
  negligible advantage. `TCSlib.Cryptography.oracle_hybrid_lemma` gives the
  finite hybrid bound for oracle ensembles.
* `TCSlib.Cryptography.prfAdv_toOracleAdversary` and `PRF.negligible_prfAdv`
  connect the PRF contract to the concrete advantage.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §3.8.1 and §3.8.2, Definitions 96.1 and 96.2.
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.4 (Definitions 3.6–3.9).
"""
imports = """import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Foundations.Negligible
import TCSlib.Cryptography.Pseudorandom.Functions.Defs
import TCSlib.Cryptography.Pseudorandom.Functions.LazySampling
import TCSlib.Cryptography.Pseudorandom.Indistinguishability
"""
new_text = license + imports + "\n" + opts + "/-!\n" + doc + "-/\n\n" + ns + contract.rstrip() + "\n" + end
# Keep the bridge to the GGM state machine in the construction file.
marker = "/-- `decodeOracleMove` in terms"
ggm = replace(ggm, marker, bridge + marker)
ggm = replace(ggm, """  ⟨by rw [ggmPRF_apply, ggmBits_def]; exact hybridProb_zero _ A, hybridProb_top _ A⟩""",
"""  ⟨by rw [ggmPRF_apply, ggmBits_def]; exact hybridProb_zero _ A, by
    rw [OracleEnsemble.acceptProb_random_eq]
    exact hybridProb_top _ A⟩""")
ggm = replace(ggm, """  | 0, hist => by
    rw [GGMRed.buildTreeQ_zero]
    unfold buildTree
    rw [decodeOracleMove_eq]
    cases GGMRed.queryOf ℓ₁ (next hist) <;> rfl
  | b + 1, hist => by
    rw [GGMRed.buildTreeQ_succ]
    unfold buildTree
    rw [decodeOracleMove_eq]
    cases GGMRed.queryOf ℓ₁ (next hist) with
    | none => rfl
    | some x =>
      simp only
      congr 1
      funext o
      exact buildTree_eq_buildTreeQ next b (hist ++ [(x, o)])""",
"""  | 0, hist => by
    rw [GGMRed.buildTreeQ_zero]
    have hmove := decodeOracleMove_eq ℓ₁ (next hist)
    cases h : GGMRed.queryOf ℓ₁ (next hist) with
    | none =>
      rw [h] at hmove
      exact buildTree_zero_of_ret hmove
    | some x =>
      rw [h] at hmove
      exact buildTree_zero_of_query hmove
  | b + 1, hist => by
    rw [GGMRed.buildTreeQ_succ]
    have hmove := decodeOracleMove_eq ℓ₁ (next hist)
    cases h : GGMRed.queryOf ℓ₁ (next hist) with
    | none =>
      rw [h] at hmove
      exact buildTree_succ_of_ret hmove
    | some x =>
      rw [h] at hmove
      rw [buildTree_succ_of_query (next := fun h => decodeOracleMove ℓ₁ (next h)) (hist := hist) hmove]
      simp only
      congr 1
      funext o
      exact buildTree_eq_buildTreeQ next b (hist ++ [(x, o)])""")
ggm = replace(ggm, """/-- `buildTree` of the decoded moves is `buildTreeQ` of the raw outputs. -/""",
"""/-- `buildTree` of the decoded moves is `buildTreeQ` of the raw outputs.

**Proof sketch.** Induct on the budget. A verdict stops both trees. A query with
budget zero rejects in both. With budget remaining, both query the same string and
their continuations agree by the induction hypothesis. -/""")
ggm = replace(ggm, """    unfold NUPPT.toOracleAdversary buildTree
    cases decodeOracleMove n (D.runAt n (encodeHist []) r) with
    | ret b => exact ⟨b, rfl⟩
    | query x => exact ⟨false, rfl⟩""",
"""    rw [NUPPT.toOracleAdversary_eq]
    cases h : decodeOracleMove n (D.runAt n (encodeHist []) r) with
    | ret b => exact ⟨b, buildTree_zero_of_ret h⟩
    | query x => exact ⟨false, buildTree_zero_of_query h⟩""")
ggm = replace(ggm, """  refine ⟨exists_ggmPRF_evaluator hE hGE, fun D q => ?_⟩
  suffices hμ""", """  refine ⟨exists_ggmPRF_evaluator hE hGE, ?_⟩
  rw [OracleEnsemble.indist_iff]
  intro D q
  suffices hμ""")
ggm = replace(ggm, """next-query machine `D` and a budget `q`; we show `μ n := prfAdv (G n) (D^{(q n)})` is
negligible (`prfAdv_toOracleAdversary`).""",
"""next-query machine `D` and a budget `q` using `OracleEnsemble.indist_iff`. We show
`μ n := prfAdv (ggmPRF G n) (D^{(q n)})` is negligible (`prfAdv_toOracleAdversary`).""")
ggm = replace(ggm, """infinitely often contradicts `μ n > 1/n^c` (`not_negligible_iff`); at the finitely many `n` with
`q n = 0` the adversary makes no query and `μ n = 0`""",
"""infinitely often contradicts `μ n > 1/n^c` (`not_negligible_iff`). At parameters with
`q n = 0` the adversary makes no query and `μ n = 0`""")
ggm_doc = """# The asymptotic Goldreich–Goldwasser–Micali construction

The GGM tree of [PS10, Theorem 97.3] builds a pseudorandom function from a
length-doubling generator. The oracle and PRF contracts live in
`Pseudorandom.Functions.Asymptotic.Defs` and are available through this import.
`Pseudorandom.Generators.Asymptotic.Stretch` reduces an arbitrary secure PRG to
the length-doubling case.

The evaluator uses `Asymptotic.PRFLemmas`. The reduction machine and its run
agreement are in `Asymptotic.GGMReduction` and `Asymptotic.GGMReductionEval`.
The finite level and query hybrids come from [Gar26, Theorem 3.3].

**Deviation.** The level hybrids are indexed `HF⁰ = f_s, …, HFⁿ = RF_n` with
`n` gaps. The query sub-hybrids are indexed by distinct prefixes in order of
first appearance.

## Main definitions

* `TCSlib.Cryptography.ggmPRF` is the GGM family `f_s(b₁ … b_n) = g_{b_n}(⋯ g_{b₁}(s) ⋯)`.

## Main results

* `TCSlib.Cryptography.exists_ggmPRF_evaluator` computes the GGM family in polynomial time.
* `TCSlib.Cryptography.thm_97_3_1` and `thm_97_3_2` give the level hybrids and query
  sub-hybrid bound. `exists_ggmBitsDist_nuppt` implements the reduction as a machine.
* `TCSlib.Cryptography.ggmPRF_prf` proves security, and `exists_prf_of_exists_prg`
  composes it with PRG stretch extension.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §3.8, Theorem 97.3.
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.4, Construction 3.3 and Theorem 3.3.
"""
old_prefix = head[:head.index("set_option")].rstrip() + "\n" + new_import + "\n"
old_text = old_prefix + opts + "/-!\n" + ggm_doc + "-/\n\n" + ns + ggm

start = subs.index("/-- The oracle adversary `A` run with lazily sampled")
stop = subs.index("/-- The probability that `A` accepts in the sub-hybrid")
lazy_dist = subs[start:stop]
subs = replace(subs, lazy_dist, "")
assert subs.count("rw [lazyDist") == 2
subs = subs.replace("rw [lazyDist", "rw [lazyDist_apply")
lazy_dist = replace(lazy_dist, "omit [Fintype P] [Fintype V] [Nonempty V] [Fintype ρ] in\n", "")
lazys = replace(lazys, end, """
section LazyDistinguisher

variable {P V : Type} {ρ : Type*} [DecidableEq P]

""" + lazy_dist + "end LazyDistinguisher\n" + end)
line = "* `extendStream W`: a finite list of values `W : Fin q → O` as an answer stream.\n"
lazys = replace(lazys, line, line + "* `lazyDist A` evaluates the oracle adversary against an answer stream.\n")

facade_path = functions + ".lean"
facade = (root / facade_path).read_text()
line = "import TCSlib.Cryptography.Pseudorandom.Functions.GGM\n"
facade = replace(facade, line, line + new_import)
facade = replace(facade, """Concrete-layer formalization of [Gar26, §3.4]: adaptive oracle adversaries, pseudorandom
functions, and the Goldreich–Goldwasser–Micali construction from a length-doubling
pseudorandom generator.""",
"""The finite oracle games and Goldreich–Goldwasser–Micali construction come
from [Gar26, §3.4]. The asymptotic contracts quantify over polynomial-time
machines and polynomial query budgets [PS10, Definitions 96.1 and 96.2].""")
line = "  Theorem 3.3).\n"
facade = replace(facade, line, line + "* `Functions/Asymptotic/Defs.lean` gives the oracle ensemble and PRF contracts.\n")
facade = replace(facade, "## References\n\n", """## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §3.8.
""")
map_path = prefix + "Pseudorandom.lean"
map_ = (root / map_path).read_text()
line = "import TCSlib.Cryptography.Pseudorandom.Functions\n"
map_ = replace(map_, line, line + new_import)
line = "  proof in `TCSlib.Cryptography.Pseudorandom.Functions.GGM` [Gar26, Theorem 3.3].\n"
map_ = replace(map_, line, line + "* `Functions.Asymptotic.Defs` gives the asymptotic oracle and PRF contracts.\n")
map_ = replace(map_, """* **PRG to PRF.** `TCSlib.Cryptography.Asymptotic.PRF` defines `TCSlib.Cryptography.PRF`
  and uses `TCSlib.Cryptography.PRG.Secure.doubling` from `Stretch`.""",
"""* **PRG to PRF.** `TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.Defs`
  defines the oracle and PRF contracts. `TCSlib.Cryptography.Asymptotic.PRF` gives
  the GGM construction and uses `TCSlib.Cryptography.PRG.Secure.doubling` from `Stretch`.""")
out = {old: old_text, new: new_text, lazy_path: lazys, sub_path: subs, facade_path: facade, map_path: map_}
patch = []
for path, after in sorted(out.items()):
    exists = (root / path).is_file()
    before = (root / path).read_text() if exists else ""
    assert before != after and after.endswith("\n")
    patch.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                     fromfile="a/" + path if exists else "/dev/null",
                                     tofile="b/" + path))
    print(len(after.splitlines()), path)
(area / "move.patch").write_text("".join(patch))
