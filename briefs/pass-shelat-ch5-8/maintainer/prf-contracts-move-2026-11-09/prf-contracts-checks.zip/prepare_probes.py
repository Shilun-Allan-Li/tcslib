"""Copy checked imports into a private tree and generate declaration and import probes."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area, side = Path(sys.argv[1]).resolve(), sys.argv[2]
previous = area.parent / "prg-permutation-move-20261109"
native = previous / "native" if side == "Base" else area / "native"
assert side in {"Base", "Head"}
meta = area / "metadata"
out = meta / side.lower() / "oleans"
plan = json.loads((native / "PLAN.json").read_bytes())
prefix = "TCSlib.Cryptography."
old = prefix + "Asymptotic."
finite = prefix + "Pseudorandom.Functions."
prf = old + "PRF"
lazy, sub, contract = (finite + name for name in ("LazySampling", "SubHybrids", "Asymptotic.Defs"))
owners = [prf, lazy, sub] if side == "Base" else [prf, lazy, sub, contract]


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


if side == "Base":
    products = read(native / "PRODUCTS.json")
else:
    products = dict(plan["retained"])
    for path in sorted(native.glob("run-*/check-*.json")):
        try:
            row = read(path)
        except json.JSONDecodeError:
            continue
        if row["rc"] == 0:
            assert row["head"] == plan["head"]
            assert sha(path.with_suffix(".log")) == row["log_sha256"]
            products[row["module"]] = row
pending = [prf.replace(".", "/")]
needed = set()
while pending:
    module = pending.pop()
    if module not in needed:
        needed.add(module)
        pending.extend(plan["graph"][module])
assert needed <= products.keys(), sorted(needed - products.keys())
assert set(owner.replace(".", "/") for owner in owners) <= needed
out.mkdir(parents=True)
tree = Path(plan["tree"])
for module in sorted(needed):
    row = products[module]
    assert row["source_sha256"] == plan["source_digests"][module], module
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}, module
    copy(tree / (module + ".olean"), out / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(tree):
        copy(src, out / src.relative_to(tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
(out / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

program = (previous / "metadata/HeadCensus.lean").read_text()
program = program.replace("import " + old + "HardCorePermutation\n", "import " + prf + "\n")
beg = program.index("  let owners : Array Name :=")
end = program.index("\n", beg)
program = program[:beg] + "  let owners : Array Name := #[" + ", ".join(chr(96) + name for name in owners) + "]" + program[end:]
start = program.index('  let file ← IO.FS.Handle.mk "')
end = program.index("\n", start)
program = program[:start] + f'  let file ← IO.FS.Handle.mk "{meta / (side + ".jsonl")}" .write' + program[end:]
program = program.replace("Permutation route census complete", "Oracle and PRF contract census complete")
(meta / (side + "Census.lean")).write_text(program)

contracts = tuple(prefix + name for name in (
    "OracleEnsemble", "OracleEnsemble.random", "OracleEnsemble.keyed", "acceptProb_random_eq_lazy",
    "OracleMove", "decodeOracleMove", "encodeHist", "buildTree", "buildTree_succ_of_query",
    "OracleEnsemble.Indist", "oracle_hybrid_lemma", "PRF", "PRF.negligible_prfAdv",
)) + ("Complexity.NUPPT.toOracleAdversary", "Complexity.NUPPT.toOracleAdversary.eq_1")
ggm = tuple(prefix + name for name in ("ggmPRF_prf", "exists_prf_of_exists_prg", "encodeHist_eq_histEnc"))
lazy_api = tuple(prefix + name for name in ("lazyDist", "lazyDist_apply", "lazyDist.eq_1"))
tests = [(side + "LegacyPRF", prf, contracts + ggm),
         (side + "ContractApi", prf if side == "Base" else contract, contracts),
         (side + "LazyApi", sub if side == "Base" else lazy, lazy_api)]
for label, imports, names in tests:
    body = "".join("#check @" + name + "\n" for name in names)
    (meta / (label + ".lean")).write_text("import " + imports + "\n\n" + body)
print(f"Copied {len(needed)} verified {side.lower()} module objects for the probes.", flush=True)
