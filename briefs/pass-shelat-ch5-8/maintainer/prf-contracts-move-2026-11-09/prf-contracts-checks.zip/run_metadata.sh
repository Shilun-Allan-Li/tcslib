#!/usr/bin/env bash
set -euo pipefail
a=$1
w=$2
side=$3
m="$a/metadata"
lower=$(printf '%s' "$side" | tr '[:upper:]' '[:lower:]')
if [[ $side == Head ]]; then
  while true; do
    r=$(find "$a/native" -maxdepth 2 -name check-0010.json -print -quit)
    if [[ -n $r ]]; then
      python3 -I - "$r" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r["rc"]==0 and r["module"]=="TCSlib/Cryptography/Asymptotic/PRF"
PY
      break
    fi
    if find "$a/native" -maxdepth 2 -name 'FAILED.json' | grep -q .; then exit 1; fi
    sleep 4
  done
fi
python3 -I "$a/prepare_probes.py" "$a" "$side"
lean=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$a/native/PLAN.json")
tree="$m/$lower/oleans"
bash "$a/run_probes.sh" "$lean" "$tree" "$m/${side}Census" "$m/${side}LegacyPRF" "$m/${side}ContractApi" "$m/${side}LazyApi"
python3 -I "$a/prepare_seals.py" "$a" "$w" "$side"
target="$m/$lower-seals"
if [[ $side == Base ]]; then
  bash "$a/run_probes.sh" "$lean" "$tree" "$target/PRFSeal" "$target/LazySamplingSeal" "$target/SubHybridsSeal"
else
  bash "$a/run_probes.sh" "$lean" "$tree" "$target/DefsSeal" "$target/PRFSeal" "$target/LazySamplingSeal" "$target/SubHybridsSeal" \
    "$target/UnsealedControl" "$target/SealedControl" "$target/ReaderControl"
fi
