"""Compare checked declaration types, definition values, and legacy imports."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
head_meta = area / "metadata-r3"
prefix = "TCSlib.Cryptography."
prf = prefix + "Asymptotic.PRF"
functions = prefix + "Pseudorandom.Functions."
lazy, sub, contract = (functions + part for part in ("LazySampling", "SubHybrids", "Asymptotic.Defs"))
ondemand = prefix + "lazyDist.eq_1"
new_readers = {prefix + "OracleEnsemble." + name for name in ("acceptProb_random_eq", "indist_iff")}
generated_matcher = "_private." + prf + ".0." + prefix + "decodeOracleMove_eq.match_1"
promoted = prefix + "pairDecode_true_two"
new_congruence = prefix + "subHybridStream.congr_simp"
reused_congruence = prefix + "lazyDist.congr_simp"
private_bridge = generated_matcher.removesuffix(".match_1")
old_matcher = prefix + "decodeOracleMove.match_1"
standard = {"propext", "Classical.choice", "Quot.sound"}
hygiene = ("str", "_@")


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def catalog(side, owners):
    rows = [json.loads(line) for line in ((meta if side == "Base" else head_meta) / (side + ".jsonl")).open()]
    last = rows.pop()
    assert last["record"] == "complete" and last["catalog"] == sum(r["record"] == "catalog" for r in rows)
    assert {name["display"] for name in last["owners"]} == owners
    result = {r["name"]["display"]: r for r in rows if r["record"] == "constant"}
    assert len(result) == last["count"] and {r["home"]["display"] for r in result.values()} == owners
    assert all({item["display"] for item in r["axioms"]} <= standard for r in result.values())
    return result


def suffix(r):
    name = key(r["name"])
    home = key(r["home"])
    if name[:len(home)+1] == (("str", "_private"),) + home:
        assert name[len(home)+1][0] == "num"
        return name[len(home)+2:]
    return name


def canonical(expr, names):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, label, *[canonical(part, names) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, names.get(name, name), *[canonical(part, names) for part in expr[2:]]]
    return [canonical(part, names) for part in expr]


base = catalog("Base", {prf, lazy, sub})
head = catalog("Head", {prf, lazy, sub, contract})
assert len(base) == 185 and len(head) == 188
suffixes = {suffix(row): name for name, row in head.items()}
assert len(suffixes) == len(head)
pairs = {name: name if name in head else suffixes[suffix(r)]
         for name, r in base.items() if name != ondemand}
assert len(pairs) == 184 and set(head) - set(pairs.values()) == new_readers | {generated_matcher, new_congruence}
assert head[generated_matcher]["kind"] == "def" and head[generated_matcher]["matcher"]
assert all(head[n]["kind"] == "theorem" for n in new_readers | {new_congruence})
renamed = {key(base[name]["name"]): key(head[new]["name"]) for name, new in pairs.items() if name != new}
assert len(renamed) == 12 and all(name[0] == ("str", "_private") for name in renamed)
errors = []
result = []
for name, target in sorted(pairs.items()):
    a, b = base[name], head[target]
    old_home, new_home = a["home"]["display"], b["home"]["display"]
    if name == reused_congruence:
        assert old_home == prf and new_home == sub
    else:
        assert new_home in {prf: {prf, contract}, lazy: {lazy}, sub: {sub, lazy}}[old_home], name
    for field in ("kind", "status", "abbrev", "instance", "matcher", "levels"):
        if a[field] != b[field]:
            errors.append((name, field))
    if {key(item) for item in a["axioms"]} != {key(item) for item in b["axioms"]}:
        errors.append((name, "axioms"))
    type_renames = renamed
    if name == private_bridge:
        type_renames = renamed | {key(base[old_matcher]["name"]): key(head[generated_matcher]["name"])}
        assert canonical(a["type"], renamed) != canonical(b["type"], {}), name
    if canonical(a["type"], type_renames) != canonical(b["type"], {}):
        errors.append((name, "type"))
    if {type_renames.get(key(ref), key(ref)) for ref in a["type_refs"]} != {key(ref) for ref in b["type_refs"]}:
        errors.append((name, "type_refs"))
    if canonical(a["definition_value"], renamed) != canonical(b["definition_value"], {}):
        errors.append((name, "definition_value"))
    result.append({"old_name": name, "new_name": target, "old_home": old_home, "new_home": new_home,
                   "kind": a["kind"], "axioms": sorted(i["display"] for i in b["axioms"])})
assert not errors, errors
assert (head_meta / "PrivateDecoderType.rc").read_text().strip() == "0"
assert "Kernel checked the relocated decoder bridge at the original matcher type." in (head_meta / "PrivateDecoderType.log").read_text()
for name in ("LegacyPRF", "ContractApi", "LazyApi"):
    before, after = "Base" + name, "Head" + name
    for probe in (before, after):
        assert ((meta if probe.startswith("Base") else head_meta) / (probe + ".rc")).read_text().strip() == "0"
    assert (meta / (before + ".log")).read_bytes() == (head_meta / (after + ".log")).read_bytes(), after
assert all(((meta if side == "Base" else head_meta) / (side + "Census.rc")).read_text().strip() == "0" for side in ("Base", "Head"))
moved = Counter(r["new_home"] for r in result if r["old_home"] != r["new_home"])
assert moved == {contract: 101, lazy: 2, sub: 1}
(area / "DECLARATIONS.json").write_text(json.dumps({
    "base": (area / "base.txt").read_text().strip(), "head": (area / "head.txt").read_text().strip(),
    "matched_declarations": len(result), "relocated_declarations": sum(moved.values()),
    "new_homes": moved, "private_name_changes_including_promotion": len(renamed),
    "published_theorem": promoted, "new_readers": sorted(new_readers),
    "new_compiler_generated_matcher": generated_matcher, "on_demand_equation_checked": ondemand,
    "new_generated_congruence": new_congruence, "relocated_generated_congruence": reused_congruence,
    "private_decoder_type_definitional_equality": private_bridge,
    "private_decoder_probe_sha256": sha(head_meta / "PrivateDecoderType.log"),
    "type_and_definition_comparison": "same kernel syntax modulo generated binder scopes and relocated private names",
    "axioms_match": True, "legacy_and_new_imports_agree": True,
    "catalog_sha256": {side: sha((meta if side == "Base" else head_meta) / (side + ".jsonl")) for side in ("Base", "Head")},
    "declarations": result,
}, indent=2) + "\n")
print("All 184 paired declarations match. The previously generated lazyDist equation still resolves on demand.")
print("Moved declarations:", dict(moved))
