## Changes

- Move the oracle ensembles, next-query machine adapter, query bound, oracle indistinguishability, and PRF contract into `Pseudorandom.Functions.Asymptotic.Defs`. The new contract import is independent of GGM and the asymptotic PRG constructions.
- Move the generic `lazyDist` helper and its existing equation into `Functions.LazySampling`. The finite sub-hybrids use that equation where they read a lazy run.
- Keep the GGM construction and the bridge to its history encoding in `Asymptotic.PRF`, which re-exports the contract. The proof reads the oracle interfaces through the tree cases, the new random-oracle acceptance and indistinguishability equations, and the shared decoder lemma.

## Verification

All 30 affected modules are verified, including the library root and campaign Checks. The final commit has 24 fresh checks and six verified transfers with identical sources and dependency objects. The standalone contract, legacy PRF, and lazy API import probes agree with the base. The declaration comparison pairs 184 entries, and the generated `lazyDist` equation still resolves on demand. Lean checks the private decoder bridge at its original type.

The oracle and GGM whole-file seals pass. The final sub-hybrid seal has only the two baseline diagnostics caused by the file repeating the mask's local irreducibility attributes. The sensitivity control blocks direct reduction of `OracleEnsemble.Indist` and accepts its reader under the same mask. The explicit source and generated-equation scans find no foreign-definition reads in the checked owners. Style checks add no findings, and the existing reader warning for `OracleEnsemble.Indist` is resolved.
