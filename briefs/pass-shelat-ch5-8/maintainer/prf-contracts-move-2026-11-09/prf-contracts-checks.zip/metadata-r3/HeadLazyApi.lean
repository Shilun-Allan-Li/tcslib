import TCSlib.Cryptography.Pseudorandom.Functions.LazySampling

#check @TCSlib.Cryptography.lazyDist
#check @TCSlib.Cryptography.lazyDist_apply
#check @TCSlib.Cryptography.lazyDist.eq_1
