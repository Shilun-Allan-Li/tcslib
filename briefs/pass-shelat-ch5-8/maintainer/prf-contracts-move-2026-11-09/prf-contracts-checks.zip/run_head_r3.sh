#!/usr/bin/env bash
set -euo pipefail
a=$1
w=$2
m="$a/metadata-r3"
index=$(python3 -I - "$a/native-r3/PLAN.json" <<'PY'
import json,sys
p=json.load(open(sys.argv[1]))
print("%04d" % (p["rebuild"].index("TCSlib/Cryptography/Asymptotic/PRF") + 1))
PY
)
while true; do
  receipt=$(find "$a/native-r3" -maxdepth 2 -name "check-$index.json" -print -quit)
  if [[ -n $receipt ]]; then
    python3 -I - "$receipt" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r["rc"]==0 and r["module"]=="TCSlib/Cryptography/Asymptotic/PRF"
PY
    break
  fi
  sleep 4
done
python3 -I "$a/prepare_probes_r3.py" "$a" Head
cp "$a/metadata/PrivateDecoderType.lean" "$m/PrivateDecoderType.lean"
lean=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$a/native-r3/PLAN.json")
tree="$m/head/oleans"
bash "$a/run_probes.sh" "$lean" "$tree" "$m/HeadCensus" "$m/HeadLegacyPRF" "$m/HeadContractApi" "$m/HeadLazyApi" "$m/PrivateDecoderType"
python3 -I "$a/prepare_seals_r3.py" "$a" "$w" Head
target="$m/head-seals"
bash "$a/run_probes.sh" "$lean" "$tree" "$target/DefsSeal" "$target/PRFSeal" "$target/LazySamplingSeal" "$target/SubHybridsSeal" \
  "$target/UnsealedControl" "$target/SealedControl" "$target/ReaderControl"
