"""Verify the replay and reconcile the whole-file seals with the cleanup ledger."""
from difflib import SequenceMatcher
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))
prefix = "TCSlib/Cryptography/"
functions = prefix + "Pseudorandom/Functions/"
legacy = prefix + "Asymptotic/PRF.lean"
lazy, sub, contract = (functions + name + ".lean" for name in ("LazySampling", "SubHybrids", "Asymptotic/Defs"))
paths = campaign / "briefs/pass-shelat-ch5-8/maintainer"
ledger_dir = paths / "cleanup-incremental-2026-11-09/final-r1"
native = area / "native-r3"
first = area / "native-r2"
base_meta, head_meta = area / "metadata", area / "metadata-r3"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def content(rev, path):
    return git("show", f"{rev}:{path}")


def normalize(text):
    return re.sub(r"\?m\.\d+", "?m", text)


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source = read(area / "SOURCE-CHECK-R3.json")
assert result["passed"] and plan["head"] == result["head"] == source["head"] == head
assert plan["base"] == result["base"] == source["base"] == base
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == 24
assert len(plan["affected"]) == 30
assert len(plan["verified_prefix"]) == 6
assert result["initial_retained"] == len(plan["retained"]) == 1071
assert len(products) == len(plan["order"]) == 1095 and len(plan["external"]) == 3810
earlier, earlier_products, earlier_result = (read(first / (name + ".json")) for name in ("PLAN", "PRODUCTS", "RESULT"))
assert earlier_result["passed"] and earlier_result["fresh_native_checks"] == 28
assert earlier_result["head"] == earlier["head"] == (area / "head-r2.txt").read_text().strip()
assert earlier_result["plan_sha256"] == sha(first / "PLAN.json")
assert earlier_result["products_sha256"] == sha(first / "PRODUCTS.json")
assert set(plan["affected"]) == set(earlier["affected"])
initial = read(area / "native/RESULT.json")
assert initial["passed"] and initial["fresh_native_checks"] == 30
assert initial["head"] == (area / "head-r1.txt").read_text().strip()
assert initial["plan_sha256"] == sha(area / "native/PLAN.json")
assert initial["products_sha256"] == sha(area / "native/PRODUCTS.json")
for module, row in plan["retained"].items():
    assert all(row[key] == earlier_products[module][key] for key in
               ("source_sha256", "object_sha256", "direct_local"))
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checked = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checked[row["module"]] = row["object_sha256"]
assert checked == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain")
assert not git("diff", "--check", base, head)
assert "0 findings in 6 files" in (area / "style.log").read_text()
declarations = read(area / "DECLARATIONS.json")
assert declarations["head"] == head and declarations["base"] == base and declarations["axioms_match"]
assert declarations["matched_declarations"] == 184 and declarations["legacy_and_new_imports_agree"]

diagnostics, receipts = {}, {}
for side, rev in (("base", base), ("head", head)):
    directory = (base_meta if side == "base" else head_meta) / (side + "-seals")
    scope = read(directory / "SCOPE.json")
    labels = set(scope) | ({"UnsealedControl"} if side == "head" else set())
    assert {p.stem for p in directory.glob("*.rc")} == labels
    diag = []
    receipts[side] = {}
    for label in sorted(labels):
        path = directory / label
        log = path.with_suffix(".log").read_text()
        count = scope.get(label, 0)
        manifest = read(path.with_suffix(".json")) if label in scope else {}
        if count:
            assert count == len(manifest["requests"])
            assert sha(path.with_suffix(".lean")) == manifest["probe_sha256"]
            assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
            assert len({(r["home"], r["spelling"]) for r in manifest["requests"]}) == count
        pattern = r"\.lean:(\d+):(\d+): error: (.*?)(?=\n(?:G06-|[^\n]*\.lean:\d+:\d+:)|\Z)"
        errors = re.findall(pattern, log, flags=re.S)
        assert len(errors) == len(re.findall(r"\.lean:\d+:\d+: error:", log))
        rc = int(path.with_suffix(".rc").read_text())
        assert rc == int(bool(errors))
        if label.endswith("Seal"):
            source_path = manifest["source_path"]
            raw = content(rev, source_path)
            assert sha256(raw).hexdigest() == manifest["source_sha256"]
            lines = raw.decode().splitlines()
            mapping = {r["probe_line"]: r["source_line"] for r in manifest["line_map"]}
            assert sorted(mapping.values()) == list(range(1, len(lines) + 1))
            for probe_line, col, msg in errors:
                line = mapping[int(probe_line)]
                diag.append({"path": source_path, "line": line, "source": lines[line-1],
                             "column": int(col), "message": msg.rstrip()})
        elif label == "SealedControl":
            assert len(errors) == 1 and "Iff.rfl" in errors[0][2] and "O.Indist" in errors[0][2]
        else:
            assert not errors
        receipts[side][label] = {"requests_verified": count, "errors": len(errors), "rc": rc,
                                 "probe_sha256": sha(path.with_suffix(".lean")),
                                 "log_sha256": sha(path.with_suffix(".log")),
                                 "source_sha256": manifest.get("source_sha256")}
    diagnostics[side] = diag
assert diagnostics["base"] == diagnostics["head"] and len(diagnostics["head"]) == 2
assert all(r["path"] == sub for r in diagnostics["head"])
assert all("failed to set `[local irreducible]`" in r["message"] for r in diagnostics["head"])
for label, names in (
    ("PRFSeal", {"TCSlib.Cryptography.OracleEnsemble.Indist", "TCSlib.Cryptography.OracleEnsemble.random",
                 "TCSlib.Cryptography.buildTree", "Complexity.NUPPT.toOracleAdversary"}),
    ("SubHybridsSeal", {"TCSlib.Cryptography.lazyDist"}),
):
    req = read(head_meta / "head-seals" / (label + ".json"))["requests"]
    assert names <= {r["spelling"] for r in req}
first_seal = (base_meta / "head-seals/SubHybridsSeal.log").read_text()
focused = (area / "focus/LazyReadersR2Seal.log").read_text()
errors = lambda log: re.findall(r"\.lean:\d+:\d+: error: (.*)", log)
assert len(errors(first_seal)) == 4 and sum("rfl" in s for s in errors(first_seal)) == 2
assert errors(focused) == errors(first_seal)[:2]
archive = ledger_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (ledger_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
observations = ledger["current_observations"]
assert len(observations) == 813 and not ledger["partial"] and not ledger["needs_review"]
source_paths = {legacy, lazy, sub}
owned = [r for r in observations if (r.get("current_owner") or r["path"]) in source_paths]
assert {r["id"] for r in owned} == {"SEAL-0306", "SEAL-0307", "C1-0289", "C1-0290"}
rows = []
old_lazy = content(base, lazy).decode().splitlines()
new_lazy = content(head, lazy).decode().splitlines()
line_map = {i + k + 1: j + k + 1 for i, j, length in
            SequenceMatcher(None, old_lazy, new_lazy, autojunk=False).get_matching_blocks()
            for k in range(length)}
for r in owned:
    if r["channel"] == "whole-file-seal":
        match = [d for d in diagnostics["head"] if d["path"] == r["current_owner"] and
                 d["line"] == r["head_line"] and d["column"] == r["column"] and
                 d["message"] == r["head_error"]]
        assert len(match) == 1, r["id"]
        rows.append({"id": r["id"], "disposition": "inherited_attribute_interaction", **match[0]})
    else:
        assert r["channel"] == "explicit-source" and r["path"] == lazy
        old = r["head"]
        line = line_map[old["line"]]
        assert old["provider"] == "g" and old["provider_home"] == "TCSlib.ErrorCorrectingCodes.QuantumSingleton"
        assert old["source"] == old_lazy[old["line"]-1] == new_lazy[line-1]
        assert any("let g : O →" in text for text in new_lazy[line-20:line])
        assert all("TCSlib.ErrorCorrectingCodes" not in n for n in source["contract_import_closure"])
        rows.append({"id": r["id"], "disposition": "mapped_original_text_scan_hit_local_let",
                     "path": lazy, "old_line": old["line"], "new_line": line, "source": old["source"]})
moved_providers = {(r["old_home"], r["old_name"]) for r in declarations["declarations"]
                   if r["old_home"] != r["new_home"] and r["kind"] == "def"}
for r in observations:
    refs = {(p["home"], p["spelling"]) for p in r.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in r.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if r["channel"] == "generated-equation":
        refs.add((r["provider_home"], r["provider"]))
    if r["channel"] == "explicit-source":
        refs.add((r["head"]["provider_home"], r["head"]["provider"]))
    assert not refs & moved_providers, r["id"]

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log
    assert "where the seal failed: 0 " in log
before, after = ({tuple(r) for r in read(area / f"campaign-lint-{side}.json")} for side in ("base", "head"))
assert {r for r in before if r[0] == "FAIL"} == {r for r in after if r[0] == "FAIL"}
warn_names = lambda rs: {name.strip() for level, _, msg in rs if level == "WARN" and "(check 8):" in msg
                         for name in msg.split("(check 8):", 1)[-1].split(",")}
assert warn_names(before) - warn_names(after) == {"OracleEnsemble.Indist"}
assert warn_names(after) <= warn_names(before)
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": receipts,
                           "baseline_diagnostics": 2, "head_diagnostics": 2, "new_diagnostics": 0,
                           "new_campaign_failures": 0, "reader_warning_resolved": "OracleEnsemble.Indist"})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                           "ledger_archive_sha256": archive_sha,
                           "mapped_observations": rows, "relocated_provider_links": [],
                           "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                           "foreign_generated_equation_references": {"base": 0, "head": 0}})
print("All 30 affected modules verified. The only seal diagnostics are the two inherited attribute interactions.")
