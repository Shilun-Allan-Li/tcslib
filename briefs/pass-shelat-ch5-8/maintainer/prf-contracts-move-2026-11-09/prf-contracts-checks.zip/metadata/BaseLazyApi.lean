import TCSlib.Cryptography.Pseudorandom.Functions.SubHybrids

#check @TCSlib.Cryptography.lazyDist
#check @TCSlib.Cryptography.lazyDist_apply
#check @TCSlib.Cryptography.lazyDist.eq_1
