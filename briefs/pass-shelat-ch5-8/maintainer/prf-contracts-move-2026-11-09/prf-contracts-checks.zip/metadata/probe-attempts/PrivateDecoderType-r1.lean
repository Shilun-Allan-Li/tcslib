import Lean
import TCSlib.Cryptography.Asymptotic.PRF

open Lean Elab Command Meta in
run_cmd liftTermElabM do
  let privateRoot := Name.num `_private.TCSlib.Cryptography.Asymptotic.PRF 0
  let bridge := privateRoot ++ `TCSlib.Cryptography.decodeOracleMove_eq
  let newMatcher := bridge ++ `match_1
  let oldMatcher := `TCSlib.Cryptography.decodeOracleMove.match_1
  let info ← getConstInfo bridge
  let before := info.type.replace fun e =>
    match e with
    | .const n us => if n == newMatcher then some (.const oldMatcher us) else none
    | _ => none
  if before == info.type then
    throwError "did not replace the generated matcher"
  unless ← withTransparency .all (isDefEq before info.type) do
    throwError "private decoder lemma has different types"
  let proof := mkConst bridge (info.levelParams.map Level.param)
  liftCoreM <| addDecl <| .thmDecl {
    name := `RelocationCheck.privateDecoderType
    levelParams := info.levelParams
    type := before
    value := proof
  }
  logInfo "Kernel checked the relocated decoder bridge at the original matcher type."
