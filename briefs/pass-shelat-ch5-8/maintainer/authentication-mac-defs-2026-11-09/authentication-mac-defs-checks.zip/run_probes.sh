#!/usr/bin/env bash
set -euo pipefail
toolchain=$1
tree=$2
shift 2
export TCSLIB_OLEANS="$tree"
export PATH="${toolchain%/*}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
unset LEAN_PATH LEAN_SRC_PATH LEAN_SYSROOT LEAN_OPTS ELAN_TOOLCHAIN PFR_BOOTSTRAP_CONFIG
for probe in "$@"; do
  /usr/bin/memory_pressure -Q > "$probe.resources.txt"
  python3 -I - "$probe.resources.txt" <<'PY'
from pathlib import Path
import re,sys
text=Path(sys.argv[1]).read_text()
total=int(re.search(r'system has (\d+)',text)[1])
percent=int(re.search(r'memory free percentage:\s*(\d+)%',text)[1])
assert total*(percent-1)//100 >= 4*1024**3
PY
  test ! -e "$probe.log"
  set +e
  bash scripts/lean_check_tree.sh "${probe#"$PWD"/}" > "$probe.log" 2>&1
  rc=$?
  set -e
  printf '%s\n' "$rc" > "$probe.rc"
  printf '%s status %s\n' "${probe##*/}" "$rc"
  case "${probe##*/}" in
    *Seal|*Control) test "$rc" -le 1 ;;
    *) if [ "$rc" -ne 0 ]; then tail -25 "$probe.log"; exit "$rc"; fi ;;
  esac
done
