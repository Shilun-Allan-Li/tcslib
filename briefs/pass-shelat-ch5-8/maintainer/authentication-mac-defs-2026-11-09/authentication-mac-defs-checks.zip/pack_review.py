"""Archive the exact MAC interface verification and stage the records-only update."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

area, root, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
stage = area / "records"
slug = "authentication-mac-defs-2026-11-09"
dest = stage / slug
native = area / "native"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args, cwd=root):
    return subprocess.check_output(["git", *args], cwd=cwd)


pr = read(area / "pr-live.json")
source = read(area / "SOURCE-CHECK.json")
decls = read(area / "DECLARATIONS.json")
seals = read(area / "SEALS.json")
reads = read(area / "READS.json")
plan, result = (read(native / (name + ".json")) for name in ("PLAN", "RESULT"))
base, head = result["base"], result["head"]
assert result["passed"] and result["fresh_native_checks"] == 10
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert seals["passed"] and seals["new_diagnostics"] == 0
assert all(row["base"] == base and row["head"] == head for row in (decls, seals, reads))
assert decls["matched_declarations"] == 251
assert pr["headRefOid"] == source["head"] == head == git("rev-parse", "HEAD").decode().strip()
assert pr["baseRefName"] == "cryptography/pass-shelat-ch2-4"
assert pr["headRefName"] == "codex/pass-shelat-authentication-mac-defs"
assert pr["state"] == "OPEN" and not pr["isDraft"]
assert pr["mergeStateStatus"] == "CLEAN" and pr["mergeable"] == "MERGEABLE"
assert set(row["path"] for row in pr["files"]) == {name + ".lean" for name in source["changed_paths"]}
assert git("rev-parse", "HEAD", cwd=campaign).decode().strip() == base
assert git("rev-parse", base + "~1^2").decode().strip() == source["baseline"]
assert not git("status", "--porcelain", cwd=campaign)

paths = {
    "base.txt", "head.txt", "predecessor.txt", "authentication-mac-defs.patch",
    "prepare_replay.py", "prepare_probes.py", "prepare_seals.py", "run_probes.sh",
    "pack_review.py", "compare_declarations.py", "scan_relocation.py", "check_evidence.py", "lint.py",
    "style-head.log", "style-base.log", "campaign-lint-base.json", "campaign-lint-head.json",
    "MOVE-SCOPE.json", "SOURCE-CHECK.json", "DECLARATIONS.json", "SEALS.json", "READS.json",
    "pr-body.md", "pr-live.json", "attempt-r1/head.txt", "attempt-r1/style-head.log",
    "attempt-r1/HeadCensus.log", "attempt-r1/HeadCensus.rc", "native/PLAN.json", "native/PRODUCTS.json", "native/RESULT.json",
}
for pattern in ("native/run-*/*", "metadata/*", "metadata/*-seals/*", "read-scan/**/*"):
    paths.update(path.relative_to(area).as_posix() for path in area.glob(pattern) if path.is_file())
dest.mkdir(parents=True)
archive = dest / "authentication-mac-defs-checks.zip"
snapshots = {}
with ZipFile(archive, "x", ZIP_DEFLATED) as packed:
    for name in sorted(paths):
        packed.write(area / name, name)
    for side, revision in (("base", base), ("head", head)):
        for module in source["changed_paths"]:
            if side == "base" and module in source["new_owners"]:
                continue
            filename = module + ".lean"
            name = f"source/{side}/{filename}"
            raw = git("show", f"{revision}:{filename}")
            snapshots[name] = sha256(raw).hexdigest()
            packed.writestr(name, raw)
hashes = {name: sha(area / name) for name in sorted(paths)}
with ZipFile(archive) as packed:
    assert set(packed.namelist()) == hashes.keys() | snapshots.keys()
    for name, expected in (hashes | snapshots).items():
        with packed.open(name) as stream:
            assert file_digest(stream, "sha256").hexdigest() == expected, name
receipt = {
    "base": base, "head": head, "passed": True, "pr": pr,
    "affected_modules": len(plan["affected"]), "fresh_native_checks": result["fresh_native_checks"],
    "verified_unchanged_transfers": result["initial_retained"], "verified_external_objects": len(plan["external"]),
    "matched_declarations": decls["matched_declarations"], "relocated_declarations": decls["relocated_declarations"],
    "seal_receipts": seals["receipts"], "new_seal_diagnostics": seals["new_diagnostics"],
    "admission_dependencies": decls["admission_dependencies"],
    "relocated_provider_links": len(reads["relocated_provider_links"]),
    "artifact_sha256": hashes, "snapshot_sha256": snapshots,
    "archive": {"name": archive.name, "sha256": sha(archive)},
}
(dest / "VERIFICATION.json").write_text(json.dumps(receipt, indent=2) + "\n")
(dest / "READS.json").write_bytes((area / "READS.json").read_bytes())
number, url = pr["number"], pr["url"]
(dest / "README.md").write_text(f"""# MAC interface relocation

The campaign base `{base}` includes Seyoon's merge of #276. Its Lean and checker
inputs match the verified EncryptThenTag head `{source['baseline']}`.

[PR #{number}]({url}) at `{head}` moves the MAC interface, forgery game, security
predicate and their equations to `Authentication.MAC.Defs`. `Authentication.Encoding`
owns the shared `splitBits` and `atParam` helpers and their reading equations. Both
blocks move verbatim in the original namespace. The old definitions module
re-exports them alongside the signature and hash contracts.

- All nine affected modules and the campaign Checks aggregate pass.
  The replay verified 1,102 unchanged local objects and 3,810 external objects.
- The census matches {decls['matched_declarations']} declaration types, definition
  values, references and axiom sets, including {decls['relocated_declarations']}
  moved declarations. Lean now emits the coin-space proof separately in the
  signature game and renumbers one auxiliary proof. Their checked proof terms,
  types and axiom sets agree. The legacy and both standalone import probes agree.
- The whole-file seals pass for the original definitions file and all three
  resulting files. Focused seals on PRFMAC, Lamport and HashAndSign pass before
  and after the move. The control blocks reduction of `atParam` and accepts
  its published equation.
- The explicit and generated scans report zero foreign definition reads in
  the changed owners. Both style lints and the diff check pass.

The moved declarations have no admission dependencies. The existing PRF MAC
security statement remains admitted in its construction file. The archive
includes the initial documentation lint findings and the scratch-path probe
failure from the first candidate.

The cleanup ledger was compared against the relocated providers.
[Ledger comparison](READS.json)

`{archive.name}` has SHA-256 `{receipt['archive']['sha256']}`.
[Verification hashes](VERIFICATION.json)

**Clear to merge — the affected modules, compatibility imports and seals pass.**
""")

briefs = campaign / "briefs/pass-shelat-ch5-8"
updates = {}
handoff = briefs / "MAINTAINER-HANDOFF.md"
original = handoff.read_text()
anchor = "[EncryptThenTag verification](maintainer/private-key-encrypt-then-tag-2026-11-09/README.md)."
assert original.count(anchor) == 1
updates[handoff] = original.replace(anchor, anchor + " " + (
    f"[PR #{number}]({url}) at `{head}` moves the MAC interface and forgery game to "
    "`Authentication.MAC.Defs` and the shared helpers to `Authentication.Encoding`. "
    f"All nine affected modules and campaign Checks pass. The census matches {decls['matched_declarations']} "
    "declarations, and the owner and focused consumer seals pass. "
    f"It is clear for Seyoon to merge. [MAC relocation verification](maintainer/{slug}/README.md)."
))
decision = campaign / "PassShelatChapter5-8Plan.md"
original = decision.read_text()
assert original.rstrip().splitlines()[-1].startswith("| 2026-11-09 (PST) | **#276 merged.**")
updates[decision] = original.rstrip() + "\n" + (
    f"| 2026-11-09 (PST) | **MAC interface move verified.** [PR #{number}]({url}) at `{head}` moves the "
    "MAC interface and forgery game to `Authentication.MAC.Defs` and the shared helpers to "
    "`Authentication.Encoding`. Nine affected modules, campaign Checks, legacy and standalone imports, "
    f"and owner and focused consumer seals pass. The census matches {decls['matched_declarations']} "
    f"declarations. [Verification](briefs/pass-shelat-ch5-8/maintainer/{slug}/README.md). Seyoon merges this slice. | record |\n"
)
preimages = {}
for src, new in updates.items():
    rel = src.relative_to(campaign)
    preimages[rel.as_posix()] = sha(src)
    target = stage / "updates" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(new)
(stage / "PREIMAGES.json").write_text(json.dumps(preimages, indent=2) + "\n")
print(f"Packed {len(hashes) + len(snapshots)} verified members for PR #{number}.")
