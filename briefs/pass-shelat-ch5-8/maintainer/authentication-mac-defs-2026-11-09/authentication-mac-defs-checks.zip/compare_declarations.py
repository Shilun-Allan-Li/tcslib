"""Compare checked declaration types, definition values, and legacy imports."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
scope = json.loads((area / "MOVE-SCOPE.json").read_bytes())
legacy, owner, encoding, facade = (scope[k].replace("/", ".") for k in ("legacy", "owner", "encoding", "facade"))
consumers = {facade + "." + name for name in ("PRFMAC", "Lamport", "HashAndSign")}
standard = {"propext", "Classical.choice", "Quot.sound"}
hygiene = ("str", "_@")


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def catalog(side, owners):
    rows = [json.loads(line) for line in (meta / (side + ".jsonl")).open()]
    last = rows.pop()
    assert last["record"] == "complete" and last["catalog"] == sum(r["record"] == "catalog" for r in rows)
    assert {name["display"] for name in last["owners"]} == owners
    result = {r["name"]["display"]: r for r in rows if r["record"] == "constant"}
    assert len(result) == last["count"] and {r["home"]["display"] for r in result.values()} == owners
    assert all({item["display"] for item in r["axioms"]} <= standard | {"sorryAx"} for r in result.values())
    return result


def suffix(r):
    name = key(r["name"])
    home = key(r["home"])
    if name[:len(home)+1] == (("str", "_private"),) + home:
        assert name[len(home)+1][0] == "num"
        return name[len(home)+2:]
    return name


def canonical(expr, names):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, label, *[canonical(part, names) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, names.get(name, name), *[canonical(part, names) for part in expr[2:]]]
    return [canonical(part, names) for part in expr]


base = catalog("Base", {legacy} | consumers)
head = catalog("Head", {legacy, owner, encoding} | consumers)
assert len(head) == len(base) + 1
mac_aux = facade + ".MAC.forgeGame._proof_2"
sig_aux = facade + ".SignatureScheme.forgeGame._proof_2"
renumbered_sig_aux = facade + ".SignatureScheme.forgeGame._proof_3"
sig_game = facade + ".SignatureScheme.forgeGame"
collision_game = facade + ".CRH.collisionGame"


def expected_home(row):
    home = row["home"]["display"]
    if home != legacy:
        return home
    name = ".".join(part for kind, part in suffix(row) if kind == "str")
    relative = name.removeprefix(facade + ".")
    if relative in {"atParam", "atParam_eq", "splitBits", "splitBits_fst", "splitBits_snd"}:
        return encoding
    if relative == "MAC" or relative.startswith("MAC."):
        return owner
    return legacy


assert set(head) - set(base) == {renumbered_sig_aux} and not (set(base) - set(head))
pairs = {name: name for name in base}
pairs[sig_aux] = renumbered_sig_aux
assert set(pairs.values()) == set(head) - {sig_aux}

# Moving MAC to a separate module ends sharing of the forger's Nonempty proof.
# Compare actual checked proof bodies before normalizing the compiler's names.
def used_by(rows, name):
    return {decl for decl, row in rows.items() if any(ref["display"] == name for ref in row["value_refs"])}


assert used_by(base, mac_aux) == {facade + ".MAC.forgeGame", sig_game, collision_game}
assert used_by(head, mac_aux) == {facade + ".MAC.forgeGame"}
assert used_by(head, sig_aux) == {sig_game, collision_game}
assert used_by(base, sig_aux) == used_by(head, renumbered_sig_aux) == {sig_game}
normalize_head = {
    key(head[sig_aux]["name"]): key(base[mac_aux]["name"]),
    key(head[renumbered_sig_aux]["name"]): key(base[sig_aux]["name"]),
}
proofs = {}
for side, expected in (("Base", {mac_aux, sig_aux}), ("Head", {mac_aux, sig_aux, renumbered_sig_aux})):
    assert (meta / (side + "GeneratedProofs.rc")).read_text().strip() == "0"
    raw = (meta / (side + "GeneratedProofs.jsonl")).read_text()
    rows = [json.loads(line) for line in raw.splitlines()]
    proofs[side] = {r["name"]["display"]: r["value"] for r in rows}
    assert len(rows) == len(expected) and set(proofs[side]) == expected
for old, new in ((mac_aux, mac_aux), (mac_aux, sig_aux), (sig_aux, renumbered_sig_aux)):
    a, b = base[old], head[new]
    assert a["kind"] == b["kind"] == "theorem"
    assert canonical(a["type"], {}) == canonical(b["type"], normalize_head), (old, new, "type")
    assert {key(ref) for ref in a["axioms"]} == {key(ref) for ref in b["axioms"]}, (old, new, "axioms")
    assert canonical(proofs["Base"][old], {}) == canonical(proofs["Head"][new], normalize_head), (old, new, "proof")

errors = []
result = []
for name, target in sorted(pairs.items()):
    a, b = base[name], head[target]
    old_home, new_home = a["home"]["display"], b["home"]["display"]
    assert new_home == expected_home(a), (name, old_home, new_home)
    for field in ("kind", "status", "abbrev", "instance", "matcher", "levels"):
        if a[field] != b[field]:
            errors.append((name, field))
    if {key(item) for item in a["axioms"]} != {key(item) for item in b["axioms"]}:
        errors.append((name, "axioms"))
    if canonical(a["type"], {}) != canonical(b["type"], normalize_head):
        errors.append((name, "type"))
    if {key(ref) for ref in a["type_refs"]} != {normalize_head.get(key(ref), key(ref)) for ref in b["type_refs"]}:
        errors.append((name, "type_refs"))
    if canonical(a["definition_value"], {}) != canonical(b["definition_value"], normalize_head):
        errors.append((name, "definition_value"))
    if {key(ref) for ref in a["value_refs"]} != {normalize_head.get(key(ref), key(ref)) for ref in b["value_refs"]}:
        errors.append((name, "value_refs"))
    result.append({"old_name": name, "new_name": target, "old_home": old_home, "new_home": new_home,
                   "kind": a["kind"], "axioms": sorted(i["display"] for i in b["axioms"])})
assert not errors, errors
probe_pairs = {
    "HeadLegacy": ("BaseLegacy", legacy),
    "StandaloneMAC": ("BaseMAC", owner),
    "StandaloneEncoding": ("BaseEncoding", encoding),
}
for label in ("BaseCensus", "HeadCensus", *probe_pairs, *(p[0] for p in probe_pairs.values())):
    assert (meta / (label + ".rc")).read_text().strip() == "0", label
for label, (old_label, imported) in probe_pairs.items():
    assert (meta / (label + ".log")).read_bytes() == (meta / (old_label + ".log")).read_bytes(), label
    imports = [line for line in (meta / (label + ".lean")).read_text().splitlines() if line.startswith("import ")]
    assert imports == ["import " + imported], label
moved = Counter(r["new_home"] for r in result if r["old_home"] != r["new_home"])
assert moved.keys() == {encoding, owner} and moved[encoding] == 5, moved
assert all("sorryAx" not in row["axioms"] for row in result if row["old_home"] == legacy)
admitted = {row["old_name"] for row in result if "sorryAx" in row["axioms"]}
(area / "DECLARATIONS.json").write_text(json.dumps({
    "base": (area / "base.txt").read_text().strip(), "head": (area / "head.txt").read_text().strip(),
    "matched_declarations": len(result), "relocated_declarations": sum(moved.values()),
    "new_homes": moved, "private_name_changes": 0,
    "type_and_definition_comparison": "same kernel syntax modulo generated binder scopes and checked auxiliary proofs",
    "axioms_match": True, "admission_dependencies": sorted(admitted), "elaborated_references_match": True, "legacy_and_new_imports_agree": True,
    "catalog_sha256": {side: sha(meta / (side + ".jsonl")) for side in ("Base", "Head")},
    "generated_auxiliary_proofs": {
        "new_local_copy": {"base": mac_aux, "head": sig_aux},
        "renumbered": {"base": sig_aux, "head": renumbered_sig_aux},
        "type_proof_and_axioms_match": True,
        "proof_sha256": {side: sha(meta / (side + "GeneratedProofs.jsonl")) for side in proofs},
    },
    "declarations": result,
}, indent=2) + "\n")
print(f"All {len(result)} declaration types, definition values, references and axiom sets match.")
print("Moved declarations:", dict(moved))
