## Summary

- Move the MAC interface, forgery game, security predicate and their equations to `Authentication.MAC.Defs`.
- Give `splitBits` and `atParam` a shared home in `Authentication.Encoding`, with their reading equations.
- Preserve the legacy `Authentication.Defs` imports and list the new modules in the authentication facade.

## Verification

- All nine affected modules and the campaign Checks aggregate pass. The legacy and both standalone import probes agree.
- The comparison matches 251 declarations, including 48 moved declarations. It verifies Lean's separately emitted proof of coin-space nonemptiness and the renumbered signature-game auxiliary proof.
- All whole-file and focused consumer seals pass. The control blocks direct reduction of `atParam` and accepts its published equation. The explicit and generated read scans and both style lints pass.

The moved declarations have no admission dependencies. The existing `prfMAC_secure` statement is admitted in the PRF construction file.
