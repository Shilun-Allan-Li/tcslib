/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Authentication.Defs
import TCSlib.Cryptography.Asymptotic.Encryption
import TCSlib.Cryptography.Asymptotic.PRF
import Mathlib.Tactic.Simps.Basic
/- G06-HARNESS INSTALL PRFMACSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "PRFMACSeal"
  let payload : String := "TCSlib.Cryptography.Authentication.MAC.Accepts\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.Secure\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC._sizeOf_1\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC._sizeOf_inst\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.forgeGame\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.forgerCodec\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.instDecidableAccepts\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.mk._flat_ctor\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.tagImpl\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.atParam\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.splitBits\tTCSlib.Cryptography.Authentication.Defs"
  let expectedRequests : Nat := 11
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Authentication.MAC.Accepts\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"Accepts\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.Secure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"Secure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Authentication.MAC._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Authentication.MAC.forgeGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"forgeGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.forgerCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"forgerCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.instDecidableAccepts\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"instDecidableAccepts\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\ttrue\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Authentication.MAC.tagImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"tagImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.atParam\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"atParam\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.splitBits\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"splitBits\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The PRF MAC (statement phase)

[PS10, Protocol 134.3]: for a family `{f_s : {0,1}^n → {0,1}^n}`, `Gen(1^n)` samples a uniform
`n`-bit key, `Tag_k(m) = f_k(m)`, and `Ver_k(m, σ)` accepts iff `f_k(m) = σ`. Theorem 135.4: when
the family is pseudorandom, the MAC is secure.

**The construction.** `F` comes with its polynomial-time evaluator `E` on `⟨s, x⟩` (clause (1) of
the ch. 2–4 layer's `PRF`). `Gen` is the ch. 2–4 layer's coin-key machine (its coins are the key,
`runAt_coinKey`). `Tag` applies `E` to its argument, and `Ver` tests `E ⟨k, m⟩ = σ` with
`polyTimeComputable_pairEq`.

## Main definitions

* `Authentication.prfTagFun`, `Authentication.prfVerFun`: the tagging and verification functions.
* `Authentication.prfMAC`: Protocol 134.3 as a `MAC`, with correctness proved.

## Main results

* `Authentication.prfMAC_secure` (Thm 135.4, stated; a `sorry` under its sketch): a PRF gives a
  secure MAC.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  Protocol 134.3 and Theorem 135.4 (book pp. 134–135).
-/

namespace TCSlib.Cryptography.Authentication

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games

/-- The tagging function on the raw machine input: `E` applied to the argument `⟨k, m⟩`. -/
def prfTagFun (E : List Bool → List Bool) : List Bool → List Bool := E ∘ NUPPT.inArg

/-- The raw tagging function returns `E (NUPPT.inArg z)` on input `z`. -/
theorem prfTagFun_eq (E : List Bool → List Bool) (z : List Bool) :
    prfTagFun E z = E (NUPPT.inArg z) := rfl

/-- The verification function on `⟨1^n, ⟨k, ⟨m, σ⟩⟩⟩`: `[true]` iff `E ⟨k, m⟩ = σ`. -/
def prfVerFun (E : List Bool → List Bool) : List Bool → List Bool :=
  (fun z => [decide (pairFstD z = pairSndD z)]) ∘ fun w =>
    pairEncode (E (pairEncode (pairFstD (pairSndD w)) (pairFstD (pairSndD (pairSndD w)))))
      (pairSndD (pairSndD (pairSndD w)))

/-- The raw verifier compares `E ⟨k, m⟩` with `σ`, using the three components decoded from
the input `w` [PS10, Protocol 134.3]. -/
theorem prfVerFun_eq (E : List Bool → List Bool) (w : List Bool) :
    prfVerFun E w =
      [decide (E (pairEncode (pairFstD (pairSndD w)) (pairFstD (pairSndD (pairSndD w)))) =
        pairSndD (pairSndD (pairSndD w)))] := by
  simp only [prfVerFun, Function.comp_apply, pairFstD_pairEncode, pairSndD_pairEncode]

/-- The tagging function is polynomial-time. -/
theorem polyTimeComputable_prfTagFun {E : List Bool → List Bool} (hE : PolyTimeComputable E) :
    PolyTimeComputable (prfTagFun E) :=
  hE.comp NUPPT.polyTimeComputable_inArg

/-- The verification function is polynomial-time. -/
theorem polyTimeComputable_prfVerFun {E : List Bool → List Bool} (hE : PolyTimeComputable E) :
    PolyTimeComputable (prfVerFun E) := by
  refine polyTimeComputable_pairEq.comp ?_
  refine PolyTimeComputable.pairEncode ?_ ?_
  · exact hE.comp (PolyTimeComputable.pairEncode
      (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD)
      (polyTimeComputable_pairFstD.comp
        (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)))
  · exact polyTimeComputable_pairSndD.comp
      (polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD)

/-- **The PRF MAC** [PS10, Protocol 134.3], with `n`-bit messages and tags, for a family `F` with
evaluator `E`. -/
noncomputable def prfMAC (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
    (E : List Bool → List Bool) (hE : PolyTimeComputable E)
    (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (F n s x)) : MAC where
  msgLen := .var
  tagLen := .var
  gen := NUPPT.ofPolyTimeUniform polyTimeComputable_pairSndD .var
  tag := NUPPT.ofPolyTimeUniform (polyTimeComputable_prfTagFun hE) (.const 0)
  ver := prfVerFun E
  gen_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  tag_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  ver_poly := polyTimeComputable_prfVerFun hE
  correct := by
    intro n m rg rt
    simp only [PolyExpr.eval_var] at m ⊢
    have hlen : (NUPPT.ofPolyTimeUniform polyTimeComputable_pairSndD .var).coinLen n = n :=
      (NUPPT.coinLen_eq _ n).trans
        ((congrArg (fun p : PolyExpr => p.eval n)
          (NUPPT.coins_ofPolyTimeUniform polyTimeComputable_pairSndD .var)).trans
            (PolyExpr.eval_var n))
    let k : Fin n → Bool := fun j => rg (Fin.cast hlen.symm j)
    have hk : List.ofFn rg = List.ofFn k := List.ofFn_congr hlen rg
    simp only [runAt_coinKey, hk]
    simp only [NUPPT.runAt_eq, NUPPT.runAtL_ofPolyTimeUniform,
      prfTagFun_eq, NUPPT.inArg_eq, NUPPT.advInput_eq,
      pairFstD_pairEncode, pairSndD_pairEncode, hFE, padFin_ofFn,
      prfVerFun_eq, atParam_eq, eq_self_iff_true, decide_true]

attribute [simps (config := { isSimp := false }) msgLen tagLen gen tag ver] prfMAC

/-- **Theorem 135.4: a PRF gives a secure MAC** [PS10, Theorem 135.4]: if `F` is a pseudorandom
function family, the PRF MAC is secure.

**Proof sketch** (the source's, with its bound).
1. Fix a forger `A` with budget `q`. Let `ε(n)` be its forgery probability against the PRF MAC.
2. The distinguisher `D` runs `A` against its own oracle, answering each tagging query `m` with
   the oracle's value. It then queries the oracle at `A`'s output message `m` and outputs `1`
   iff the answer is `σ` and `m` was not queried before.
3. With the oracle `f_k`, `D` outputs `1` exactly when `A` forges: probability `ε(n)`.
4. With a random function, a forgery is a guess of a fresh uniform value: probability at most
   `2^{-n}` (the collision bound `prob_mem_le`, or a direct count).
5. So `D`'s PRF advantage is at least `ε(n) − 2^{-n}`. Since `F` is a PRF it is negligible, so
   `ε` is negligible.
6. First use the input-free companion `Games.exists_toCompOn_of_toComp` for the forger.
   The forwarding reduction is a machine by T2 (`Games.exists_interactiveHandlerMachine`):
   its finalization makes one query at the output message, checks freshness from the state,
   and returns one bit (`finCall = 1`, `outLen = 1`), with budget `q + 1`. T4
   (`Games.exists_toOracleAdversary_of_bitCodec`) then supplies `OracleEnsemble.Indist`'s
   oracle adversary.

The PRF advantage is read through `OracleEnsemble.Indist`, in framework form after the F-1
restatement. -/
theorem prfMAC_secure {F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool)}
    (hF : PRF F) (E : List Bool → List Bool) (hE : PolyTimeComputable E)
    (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (F n s x)) :
    (prfMAC F E hE hFE).Secure := by
  sorry

end TCSlib.Cryptography.Authentication
/- G06-HARNESS EOF-VERIFY PRFMACSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "PRFMACSeal"
  let payload : String := "TCSlib.Cryptography.Authentication.MAC.Accepts\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.Secure\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC._sizeOf_1\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC._sizeOf_inst\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.forgeGame\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.forgerCodec\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.instDecidableAccepts\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.mk._flat_ctor\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.MAC.tagImpl\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.atParam\tTCSlib.Cryptography.Authentication.Defs\nTCSlib.Cryptography.Authentication.splitBits\tTCSlib.Cryptography.Authentication.Defs"
  let expectedRequests : Nat := 11
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Authentication.MAC.Accepts\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"Accepts\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.Secure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"Secure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Authentication.MAC._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Authentication.MAC.forgeGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"forgeGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.forgerCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"forgerCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.instDecidableAccepts\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"instDecidableAccepts\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\ttrue\tfalse\tfalse\nTCSlib.Cryptography.Authentication.MAC.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Authentication.MAC.tagImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"MAC\"],[\"str\",\"tagImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.atParam\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"atParam\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Authentication.splitBits\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"splitBits\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Authentication\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

