import TCSlib.Cryptography.Authentication.Encoding

#check @TCSlib.Cryptography.Authentication.atParam
#check @TCSlib.Cryptography.Authentication.atParam_eq
#check @TCSlib.Cryptography.Authentication.splitBits
#check @TCSlib.Cryptography.Authentication.splitBits_fst
#check @TCSlib.Cryptography.Authentication.splitBits_snd
