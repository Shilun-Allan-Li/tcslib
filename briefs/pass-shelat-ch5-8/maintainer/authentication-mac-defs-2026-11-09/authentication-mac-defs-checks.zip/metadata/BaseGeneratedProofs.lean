import Lean
import TCSlib.Cryptography.Authentication

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Meta Elab Command

namespace CleanupIncrement

def parts : Name → List (String × String)
  | .anonymous => []
  | .str p s => parts p ++ [("str", s)]
  | .num p n => parts p ++ [("num", toString n)]

def identity (n : Name) : Json :=
  Json.mkObj [("display", toJson n.toString), ("components", toJson (parts n))]

def names (ns : Array Name) : Json := Json.arr (ns.map identity)

def kind : ConstantInfo → String
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .axiomInfo _ => "axiom"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def isAbbrev : ConstantInfo → Bool
  | .defnInfo d => match d.hints with
    | .abbrev => true
    | _ => false
  | _ => false

/-- Compare exact kernel type structure, retaining binder labels and annotations of visibility. -/
partial def exprData : Expr → Json
  | .bvar i => .arr #[.str "bvar", toJson i]
  | .fvar id => .arr #[.str "fvar", identity id.name]
  | .mvar id => .arr #[.str "mvar", identity id.name]
  | .sort l => .arr #[.str "sort", toJson (reprStr l)]
  | .const n ls => .arr #[.str "const", identity n, toJson (ls.map reprStr)]
  | .app f a => .arr #[.str "app", exprData f, exprData a]
  | .lam n t b info => .arr #[.str "lam", identity n, exprData t, exprData b, toJson (reprStr info)]
  | .forallE n t b info =>
      .arr #[.str "forall", identity n, exprData t, exprData b, toJson (reprStr info)]
  | .letE n t v b nd => .arr #[.str "let", identity n, exprData t, exprData v, exprData b, toJson nd]
  | .lit l => .arr #[.str "lit", toJson (reprStr l)]
  | .mdata _ e => exprData e
  | .proj t i e => .arr #[.str "proj", identity t, toJson i, exprData e]




run_cmd do
  let targets : Array Name := #[`TCSlib.Cryptography.Authentication.MAC.forgeGame._proof_2, `TCSlib.Cryptography.Authentication.SignatureScheme.forgeGame._proof_2]
  let env ← getEnv
  let kernel := env.checked.get
  let file ← IO.FS.Handle.mk "/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/authentication-mac-defs-r2-20261109/metadata/BaseGeneratedProofs.jsonl" .write
  for n in targets do
    let some ci := kernel.find? n | throwError "missing checked proof {n}"
    unless kind ci == "theorem" do throwError "expected generated theorem {n}"
    let some v := ci.value? (allowOpaque := true) | throwError "missing proof body {n}"
    file.putStrLn <| (Json.mkObj [("name", identity n), ("value", exprData v)]).compress

end CleanupIncrement
