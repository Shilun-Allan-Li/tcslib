import TCSlib.Cryptography.Authentication.Encoding

open Turing TCSlib.Cryptography.Authentication

example (n : ℕ) (w : List Bool) : atParam n w = pairEncode (List.replicate n true) w := by
  rfl
