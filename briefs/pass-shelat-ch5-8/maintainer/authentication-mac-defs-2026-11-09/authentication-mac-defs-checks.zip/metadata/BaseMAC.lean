import TCSlib.Cryptography.Authentication.Defs

#check @TCSlib.Cryptography.Authentication.MAC
#check @TCSlib.Cryptography.Authentication.MAC.Accepts
#check @TCSlib.Cryptography.Authentication.MAC.oracleSpec
#check @TCSlib.Cryptography.Authentication.MAC.tagImpl_eq
#check @TCSlib.Cryptography.Authentication.MAC.forgerCodec
#check @TCSlib.Cryptography.Authentication.MAC.forgeGame
#check @TCSlib.Cryptography.Authentication.MAC.forgeGame_eq
#check @TCSlib.Cryptography.Authentication.MAC.Secure
#check @TCSlib.Cryptography.Authentication.MAC.secure_iff
