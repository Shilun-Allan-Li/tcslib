import TCSlib.Cryptography.Pseudorandom.NextBit.Concrete

open TCSlib.Cryptography

example {ρ : Type} {ℓ : ℕ} (i : Fin ℓ) (A : (Fin i → Bool) → ρ → Bool)
    (t : Fin ℓ → Bool) (c : ρ) :
    nextBitDist i A t c = decide (A (prefixOf i t) c = t i) :=
  rfl
