## Change

- Put the finite next-bit experiment, hybrids, and both quantitative reductions in `Pseudorandom.NextBit.Concrete`. Its TCSlib imports are confined to the finite layer.
- Put the machine lifts and both directions of the ensemble characterization in `Pseudorandom.NextBit`.
- Publish the two existing string equations for prefixes and completions, and add equations for the finite predictor and distinguisher. The ensemble proofs use these equations and the existing `nextBitProb_eq` at the new boundary.
- Keep `Asymptotic.NextBit` as a compatibility import. Update the pseudorandomness map to point to both new modules.

## Verification

All 61 affected modules pass, including the library root and campaign Checks. The census matches 51 original declarations, with the same types, definition values, and axiom dependencies. Both standalone import probes agree.

The baseline and both split-file seals pass. The ensemble seal masks all seven finite definitions. The sensitivity control fails at the intended `rfl` step under the seal and passes using the published equation. The source scan confirms the ensemble proofs read the finite definitions through their equations. Style checks report no new findings.
