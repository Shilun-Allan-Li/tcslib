"""Collect the old and split declarations from isolated checked imports."""

from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area, root = (Path(s).resolve() for s in sys.argv[1:])
previous = area.parent / "prg-defs-move-20261109"
native = area / "native"
meta = area / "metadata"
legacy = "TCSlib.Cryptography.Asymptotic.NextBit"
finite = "TCSlib.Cryptography.Pseudorandom.NextBit.Concrete"
ensemble = "TCSlib.Cryptography.Pseudorandom.NextBit"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not src.samefile(dst), dst


base_plan = read(previous / "native/PLAN.json")
head_plan = read(native / "PLAN.json")
assert head_plan["baseline"] == base_plan["head"]
base_products = read(previous / "native/PRODUCTS.json")
head_products = dict(head_plan["retained"])
for path in sorted(native.glob("run-*/check-*.json")):
    row = read(path)
    if row["rc"] == 0:
        assert row["head"] == head_plan["head"]
        assert sha(path.with_suffix(".log")) == row["log_sha256"]
        head_products[row["module"]] = row

meta.mkdir()
for side, plan, products in (("base", base_plan, base_products), ("head", head_plan, head_products)):
    tree = meta / side / "oleans"
    tree.mkdir(parents=True)
    pending = [legacy.replace(".", "/")]
    modules = set()
    while pending:
        module = pending.pop()
        if module not in modules:
            modules.add(module)
            pending.extend(plan["graph"][module])
    old_tree = Path(plan["tree"])
    for module in sorted(modules):
        row = products[module]
        assert row["source_sha256"] == plan["source_digests"][module], module
        assert row["direct_local"] == {
            dep: products[dep]["object_sha256"] for dep in plan["graph"][module]
        }, module
        copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    for row in plan["external"].values():
        path = Path(row["path"])
        if path.is_relative_to(old_tree):
            copy(path, tree / path.relative_to(old_tree), row["sha256"])
        else:
            assert sha(path) == row["sha256"], path
    (tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
    print(f"Verified {side} probe tree with {len(modules)} local objects", flush=True)

census_template = (previous / "metadata/BaseCensus.lean").read_text()
prefix = census_template.split("run_cmd do\n", 1)[0].replace(
    "import TCSlib.Cryptography.Asymptotic.Pseudorandom\nimport TCSlib.Cryptography.Pseudorandom\n",
    "import @IMPORT@\n"
)
assert prefix.count("@IMPORT@") == 1
tick = chr(96)
for label, module in (("Base", legacy), ("Finite", finite), ("Ensemble", ensemble)):
    census = prefix.replace("@IMPORT@", module) + f"""
run_cmd do
  let owner := {tick}{module}
  let env ← getEnv
  let kernel := env.checked.get
  let file ← IO.FS.Handle.mk "{meta / (label + '.jsonl')}" .write
  let emit (j : Json) : IO Unit := file.putStrLn j.compress
  unless (env.getModuleIdx? owner).isSome do throwError "missing module {{owner}}"
  let mut count : Nat := 0
  let mut catalog : Nat := 0
  for (n, c) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[mi.toNat]!
    unless ({tick}TCSlib).isPrefixOf home do continue
    let some ci := kernel.find? n | throwError "missing checked constant {{n}}"
    unless kind ci == kind c do throwError "checked kind differs for {{n}}"
    let status ← liftCoreM <| getReducibilityStatus n
    let matcher := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let common := [("name", identity n), ("home", identity home), ("kind", toJson (kind ci)),
      ("status", toJson (reprStr status)), ("abbrev", toJson (isAbbrev ci)),
      ("instance", toJson instanceFlag), ("matcher", toJson matcher)]
    emit <| Json.mkObj (("record", .str "catalog") :: common)
    catalog := catalog + 1
    if home == owner then
      let value := ci.value? (allowOpaque := true)
      let axioms ← liftCoreM <| collectAxioms n
      emit <| Json.mkObj (("record", .str "constant") :: common ++ [
        ("type", exprData ci.type), ("levels", names ci.levelParams.toArray),
        ("value", (value.map exprData).getD .null),
        ("type_refs", names ci.type.getUsedConstants),
        ("value_refs", names ((value.map (·.getUsedConstants)).getD #[])),
        ("axioms", names axioms)])
      count := count + 1
  emit <| Json.mkObj [("record", .str "complete"), ("count", toJson count),
    ("catalog", toJson catalog), ("owner", identity owner)]
  logInfo m!"Next-bit census complete: {{count}} declarations"

end CleanupIncrement
"""
    (meta / (label + "Census.lean")).write_text(census)

for name, module in (("LegacyImport", legacy), ("OwnerImport", ensemble)):
    declarations = (
        "nextBitProb", "exists_nextBitPred", "prgAdv_nextBitDist", "Ensemble.NextBitUnpredictable",
        "Ensemble.NextBitUnpredictable.pseudorandom", "Ensemble.Pseudorandom.nextBitUnpredictable",
    )
    (meta / (name + ".lean")).write_text(
        f"import {module}\n\n" +
        "".join(f"#check TCSlib.Cryptography.{decl}\n" for decl in declarations)
    )
