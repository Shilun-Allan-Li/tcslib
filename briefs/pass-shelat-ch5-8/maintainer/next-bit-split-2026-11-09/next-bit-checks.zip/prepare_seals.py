"""Seal the finite and ensemble modules using their actual Lean import closures."""

from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:])
meta = area / "metadata"
legacy = "TCSlib.Cryptography.Asymptotic.NextBit"
ensemble = "TCSlib.Cryptography.Pseudorandom.NextBit"
finite = ensemble + ".Concrete"
review = area.parent / "gate06-combined-20261108"
tools = review / "rule10-evidence-r2/tool-inputs"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def rows(label):
    path = meta / (label + ".jsonl")
    data = [json.loads(line) for line in path.read_text().splitlines()]
    tail = data.pop()
    assert tail["record"] == "complete"
    catalog = {row["name"]["display"]: row for row in data if row["record"] == "catalog"}
    roots = [row for row in data if row["record"] == "constant"]
    assert tail["catalog"] == len(catalog) and tail["count"] == len(roots)
    return catalog, roots, tail["owner"]["display"]


bs = load(tools / "build_seals.py", "checked_seals")
controls = load(tools / "build_controls.py", "checked_controls")
adapter = load(tools / "request_payload_adapter.py", "checked_adapter")
bound = load(review / "rule10-payload-retry-r3/bound_payload.py", "checked_bound")
adapter.configure_builders(bs, controls)
seal = bs.seal_command
bs.seal_command = lambda label, req, *, end: bound.bound_payloads(seal(label, req, end=end))
base_plan = read(area.parent / "prg-defs-move-20261109/native/PLAN.json")
head_plan = read(area / "native/PLAN.json")
manifests = {}


def seal_probe(label, raw, requests, **receipt):
    probe, insertions, lines = bs.instrument(raw, bs.header(raw), label, requests)
    path = meta / (label + ".lean")
    path.write_bytes(probe)
    manifest = {"requested": requests, "probe_sha256": sha(path),
                "insertions": insertions, "line_map": lines, **receipt}
    (meta / (label + ".json")).write_text(json.dumps(manifest, indent=2) + "\n")
    manifests[label] = len(requests)


def to_request(row):
    return {
        "spelling": row["name"]["display"], "home": row["home"]["display"],
        "matcher": row["matcher"], "collector_reducibility": row["status"].rsplit(".", 1)[-1],
        "instance": row["instance"], "abbrev": row["abbrev"],
        "name_components": row["name"]["components"], "home_components": row["home"]["components"],
        "constant_kind": "def",
    }


finite_crossing = []
for label, plan, is_base in (("Base", base_plan, True), ("Finite", head_plan, False),
                              ("Ensemble", head_plan, False)):
    catalog, roots, owner = rows(label)
    module = owner.replace(".", "/")
    path = module + ".lean"
    if is_base:
        raw = subprocess.check_output(["git", "show", f"{head_plan['base']}:{path}"], cwd=root)
    else:
        raw = (root / path).read_bytes()
    assert bs.sha(raw) == plan["source_digests"][module]
    imported = set()
    pending = list(plan["graph"][module])
    while pending:
        dep = pending.pop()
        if dep not in imported:
            imported.add(dep)
            pending.extend(plan["graph"][dep])
    homes = {dep.replace("/", ".") for dep in imported}
    assert {row["home"]["display"] for row in catalog.values()} <= homes | {owner}
    requests, reducible_others = [], []
    for name, row in sorted(catalog.items()):
        if row["home"]["display"] not in homes or row["kind"] != "def" or name == "Complexity.PolyExpr.eval":
            continue
        if row["status"].endswith(".reducible") and not row["matcher"]:
            if not row["abbrev"]:
                reducible_others.append(name)
            continue
        requests.append(to_request(row))
    actual = sorted({reference["display"] for decl in roots for field in ("type_refs", "value_refs")
                     for reference in decl[field]
                     if reference["display"] in catalog
                     and catalog[reference["display"]]["home"]["display"] in homes})
    seal_probe(label + "Seal", raw, requests, path=path, owner=owner, source_sha256=bs.sha(raw),
               actual_foreign_names=actual, other_reducible_definitions=reducible_others,
               closure_homes=sorted(homes))
    if owner == ensemble:
        finite_crossing = [row["spelling"] for row in requests if row["home"] == finite]
        assert {"TCSlib.Cryptography.nextBitProb", "TCSlib.Cryptography.nextBitPred",
                "TCSlib.Cryptography.nextBitDist", "TCSlib.Cryptography.prefixOf",
                "TCSlib.Cryptography.completePrefix"} <= set(finite_crossing)

catalog, _, _ = rows("Finite")
raw = f"""import {finite}

open TCSlib.Cryptography

example {{ρ : Type}} {{ℓ : ℕ}} (i : Fin ℓ) (A : (Fin i → Bool) → ρ → Bool)
    (t : Fin ℓ → Bool) (c : ρ) :
    nextBitDist i A t c = decide (A (prefixOf i t) c = t i) :=
  rfl
""".encode()
(meta / "UnsealedControl.lean").write_bytes(raw)
request = [to_request(catalog["TCSlib.Cryptography.nextBitDist"])]
seal_probe("SealedControl", raw, request)
seal_probe("ReaderControl", raw.replace(b"  rfl\n", b"  nextBitDist_eq i A t c\n"), request)
records = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
ledger = records / "11-final-read-ledger.zip"
hashes = dict((name, checksum) for checksum, name in (line.split() for line in (records / "SHA256SUMS").read_text().splitlines()))
assert sha(ledger) == hashes[ledger.name]
with ZipFile(ledger) as pack:
    data = json.loads(pack.read("deferred-read-ledger-final-r1.json"))
assert not any(legacy in json.dumps(row) or legacy.replace(".", "/") + ".lean" == row["path"]
               for row in data["current_observations"])
(area / "SEAL-SCOPE.json").write_text(json.dumps({
    "head": head_plan["head"], "requests": manifests, "finite_definitions_sealed_in_ensemble": finite_crossing,
    "historical_ledger_sha256": hashes[ledger.name], "historical_ledger_rows_at_next_bit": 0,
}, indent=2) + "\n")
print(manifests, "finite definitions sealed in ensemble", len(finite_crossing), flush=True)
