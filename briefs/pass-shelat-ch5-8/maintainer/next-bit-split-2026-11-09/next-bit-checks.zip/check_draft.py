"""Seed an isolated development tree with the accepted dependencies."""

from hashlib import file_digest
import json
from pathlib import Path
import os
import shutil
import subprocess
import sys

area, root, campaign = (Path(arg).resolve() for arg in sys.argv[1:])
previous = area.parent / "prg-defs-move-20261109/native"
record = campaign / "briefs/pass-shelat-ch5-8/maintainer/prg-defs-move-2026-11-09/VERIFICATION.json"
run = area / "development"
tree = run / "oleans"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


plan, result, verified = read(previous / "PLAN.json"), read(previous / "RESULT.json"), read(record)
assert verified["passed"] and result["passed"] and verified["head"] == plan["head"] == result["head"]
for name in ("PLAN.json", "RESULT.json", "PRODUCTS.json"):
    assert sha(previous / name) == verified["artifact_sha256"]["native/" + name], name
base = (area / "base.txt").read_text().strip()
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip() == base
assert not subprocess.check_output(["git", "diff", "--name-only", plan["head"], base, "--", "*.lean",
                                    "lean-toolchain", "lake-manifest.json", "scripts/lean_check_tree.sh"],
                                   cwd=root)
products = read(previous / "PRODUCTS.json")
old_tree = Path(plan["tree"])
tree.mkdir(parents=True)
leaves = [
    "TCSlib/Cryptography/Pseudorandom/Generators",
    "TCSlib/Cryptography/Pseudorandom/Generators/Asymptotic/Defs",
    "TCSlib/Cryptography/Pseudorandom/Indistinguishability",
    "TCSlib/Cryptography/Pseudorandom/GeneratorFromPermutation",
    "TCSlib/Cryptography/Pseudorandom/Functions",
]
needed = set()
while leaves:
    module = leaves.pop()
    if module not in needed:
        needed.add(module)
        leaves.extend(plan["graph"][module])
for module in sorted(needed):
    row = products[module]
    assert sha(root / (module + ".lean")) == row["source_sha256"]
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    path = Path(row["path"])
    if path.is_relative_to(old_tree):
        copy(path, tree / path.relative_to(old_tree), row["sha256"])
    else:
        assert sha(path) == row["sha256"], path
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
assert not (root / ".lake/build/lib/lean").exists()
assert sha(Path(plan["toolchain"])) == plan["toolchain_sha256"]
checker = root / "scripts/lean_check_tree.sh"
assert sha(checker) == plan["checker_sha256"]
print(f"Development closure verified with {len(needed)} local objects", flush=True)
env = os.environ.copy()
for name in ("LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LEAN_OPTS", "ELAN_TOOLCHAIN", "PFR_BOOTSTRAP_CONFIG"):
    env.pop(name, None)
env["PATH"] = str(Path(plan["toolchain"]).parent) + ":/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
env["TCSLIB_OLEANS"] = str(tree)
for module in (
    "TCSlib/Cryptography/Pseudorandom/NextBit/Concrete", "TCSlib/Cryptography/Pseudorandom/NextBit",
    "TCSlib/Cryptography/Asymptotic/NextBit", "TCSlib/Cryptography/Pseudorandom",
):
    log = run / (module.replace("/", "__") + ".log")
    with log.open("x") as stream:
        rc = subprocess.run(["bash", str(checker), module], cwd=root, env=env,
                            stdout=stream, stderr=subprocess.STDOUT).returncode
    print(f"{module} status {rc}", flush=True)
    if rc:
        print(log.read_text()[-5000:])
        sys.exit(rc)
