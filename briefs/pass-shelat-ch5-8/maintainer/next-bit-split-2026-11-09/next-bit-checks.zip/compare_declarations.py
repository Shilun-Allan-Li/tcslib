"""Compare the checked declarations across both halves of the split."""

from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
legacy = "TCSlib.Cryptography.Asymptotic.NextBit"
ensemble = "TCSlib.Cryptography.Pseudorandom.NextBit"
finite = ensemble + ".Concrete"
standard = {"propext", "Classical.choice", "Quot.sound"}
prefix = "TCSlib.Cryptography."


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def decls(label, module):
    with (meta / (label + ".jsonl")).open() as stream:
        rows = [row for line in stream if (row := json.loads(line))["record"] in ("constant", "complete")]
    last = rows.pop()
    assert last["record"] == "complete" and last["count"] == len(rows)
    assert last["owner"]["display"] == module
    for row in rows:
        assert row["home"]["display"] == module
        assert {item["display"] for item in row["axioms"]} <= standard, row["name"]["display"]
    result = {key(row["name"]): row for row in rows}
    assert len(result) == len(rows)
    return result


def module_name(module):
    return tuple(("str", part) for part in module.split("."))


def suffix(name, module):
    p = (("str", "_private"),) + module_name(module)
    if name[:len(p)] == p:
        assert name[len(p)][0] == "num"
        return name[len(p)+1:]


base = decls("Base", legacy)
fin = decls("Finite", finite)
ens = decls("Ensemble", ensemble)
assert not fin.keys() & ens.keys()
head = fin | ens
promoted = {module_name(prefix + n) for n in ("ofFn_completePrefix", "ofFn_prefixOf")}
new_private = {}
for module, rows in ((finite, fin), (ensemble, ens)):
    for name in rows:
        s = suffix(name, module)
        if s is not None:
            assert s not in new_private, s
            new_private[s] = name
pairs = {}
for name in base:
    if name in head:
        pairs[name] = name
        continue
    old_tail = suffix(name, legacy)
    assert old_tail is not None, base[name]["name"]["display"]
    if old_tail in head:
        assert any(old_tail[:len(prom)] == prom for prom in promoted)
        pairs[name] = old_tail
    else:
        pairs[name] = new_private[old_tail]
assert len(set(pairs.values())) == len(pairs) == 51
added = set(head) - set(pairs.values())
assert added == {module_name(prefix + n) for n in ("nextBitPred_eq", "nextBitDist_eq")}

renamed = {name: target for name, target in pairs.items() if name != target}
hygiene = ("str", "_@")


def canonical(expr, mapping):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, label, *[canonical(part, mapping) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, mapping.get(name, name), *[canonical(part, mapping) for part in expr[2:]]]
    return [canonical(part, mapping) for part in expr]


rows = []
for name, target in pairs.items():
    a, b = base[name], head[target]
    display = a["name"]["display"]
    assert all(a[field] == b[field] for field in ("kind", "status", "abbrev", "instance", "matcher", "levels")), display
    assert {key(item) for item in a["axioms"]} == {key(item) for item in b["axioms"]}, display
    assert canonical(a["type"], renamed) == canonical(b["type"], {}), display
    type_refs = {renamed.get(key(ref), key(ref)) for ref in a["type_refs"]}
    assert type_refs == {key(ref) for ref in b["type_refs"]}, display
    values_match = canonical(a["value"], renamed) == canonical(b["value"], {})
    if a["kind"] == "def":
        assert values_match, display
    rows.append({
        "old_name": display, "new_name": b["name"]["display"], "home": b["home"]["display"],
        "type_matches": True, "value_matches": values_match,
        "axioms": sorted(item["display"] for item in b["axioms"]),
    })
assert (meta / "LegacyImport.log").read_bytes() == (meta / "OwnerImport.log").read_bytes()
changes = sorted(row["new_name"] for row in rows if not row["value_matches"])
with (area / "DECLARATIONS.json").open("x") as stream:
    json.dump({
        "matched_declarations": len(rows), "old_public_count": sum(suffix(name, legacy) is None for name in base),
        "new_readers": sorted(head[name]["name"]["display"] for name in added),
        "promoted_readers": sorted(head[name]["name"]["display"] for name in promoted),
        "type_comparison": "kernel syntax with generated binder scopes and relocated private names normalized",
        "same_legacy_and_ensemble_exports": True, "proof_term_differences": changes,
        "catalog_sha256": {name: sha(meta / (name + ".jsonl")) for name in ("Base", "Finite", "Ensemble")},
        "declarations": sorted(rows, key=lambda row: row["old_name"]),
    }, stream, indent=2)
    stream.write("\n")
print(f"Matched {len(rows)} declarations, including all types and definition values.")
print("Proof term differences:", changes)
