"""Check the two source boundaries and the native seal receipts."""

from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
area, root = (Path(arg).resolve() for arg in sys.argv[1:])
meta = area / "metadata"
source = "TCSlib/Cryptography/Pseudorandom/NextBit"
scope = json.loads((area / "SEAL-SCOPE.json").read_bytes())
native = json.loads((area / "native/RESULT.json").read_bytes())
declarations = json.loads((area / "DECLARATIONS.json").read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


assert native["passed"] and native["head"] == scope["head"] and native["fresh_native_checks"] == 61
assert declarations["matched_declarations"] == 51
assert declarations["proof_term_differences"] == [
    "TCSlib.Cryptography.Ensemble.NextBitUnpredictable.pseudorandom",
    "TCSlib.Cryptography.Ensemble.Pseudorandom.nextBitUnpredictable",
    "TCSlib.Cryptography.Ensemble.uniform_nextBitUnpredictable",
]
assert declarations["same_legacy_and_ensemble_exports"]
spec = importlib.util.spec_from_file_location(
    "import_graph", area.parent / "cleanup-incremental-20261108/tools/import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
raw = (root / (source + ".lean")).read_text()
code = graph.comments_removed(raw)
roots = [name.rsplit(".", 1)[-1] for name in scope["finite_definitions_sealed_in_ensemble"]]
names = "|".join(re.escape(name) for name in roots)
plain_read = re.compile(rf"\b(?:{names})(?=\b)(?:\.eq_\d+|\.match_\d+)?\b")
tactics = re.compile(r"\b(?:unfold|delta)\b[^\n]*|\b(?:simp(?:_all)?|dsimp|rw|erw|rwa)\b\s*(?:only\s*)?\[[^\]]*\]")
hits = [match.group() for match in tactics.finditer(code) if plain_read.search(match.group())]
# The only hits are the two ordinary arguments to the coin-equivalence theorem.
assert len(hits) == 1 and hits[0].startswith("rw [acceptProb_coins_equiv ")
assert plain_read.findall(hits[0]) == ["nextBitDist", "nextBitDist"]
assert hits[0].count("acceptProb_coins_equiv") == 2

assert code.count("simp only [nextBitProb_eq]") == 2
assert "hofn, nextBitPred_eq]" in code and "rw [nextBitDist_eq]" in code
assert not re.search(r"\b(?:sorry|admit)\b", code)
assert not re.search(r"\b(?:sorry|admit)\b", graph.comments_removed(
    (root / (source + "/Concrete.lean")).read_text()))

receipts = {}
for name in ("BaseSeal", "FiniteSeal", "EnsembleSeal", "UnsealedControl", "SealedControl", "ReaderControl"):
    log = meta / (name + ".log")
    text = log.read_text()
    rc = int((meta / (name + ".rc")).read_text())
    count = len(re.findall(r"\.lean:\d+:\d+: error:", text))
    assert rc == count == int(name == "SealedControl"), name
    if name in scope["requests"]:
        n = scope["requests"][name]
        assert text.count(f"G06-SEAL-END label={name} requested={n} verified={n}") == 1, name
    if name == "SealedControl":
        assert "rfl" in text and "nextBitDist" in text and "error:" in text
    receipts[name] = {"status": rc, "errors": count, "log_sha256": sha(log)}

base_lint, head_lint = (json.loads((area / f"campaign-lint-{side}.json").read_bytes())
                        for side in ("base", "head"))
assert {tuple(row) for row in head_lint if row[0] == "FAIL"} == {
    tuple(row) for row in base_lint if row[0] == "FAIL"
}
warning_names = lambda rows: {
    name.strip() for level, path, msg in rows if level == "WARN" and "(check 8):" in msg
    for name in msg.split("(check 8):", 1)[-1].split(",")
}
assert warning_names(base_lint) - warning_names(head_lint) == {"nextBitDist", "nextBitPred"}
assert warning_names(head_lint) <= warning_names(base_lint)
(area / "SEALS.json").write_text(json.dumps({
    **scope, "passed": True, "receipts": receipts, "explicit_reads_of_newly_foreign_finite_defs": 0,
    "new_campaign_failures": 0, "new_campaign_reader_warnings": 0,
}, indent=2) + "\n")
print("The base and both split-file seals pass. The sealed rfl control fails and the reader control passes.")
