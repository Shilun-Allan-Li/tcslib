"""Pin the next-bit split and invalidate every transitive consumer."""

from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:])
tools = area.parent / "cleanup-incremental-20261108/tools"
previous = area.parent / "prg-defs-move-20261109/native"
records = campaign / "briefs/pass-shelat-ch5-8/maintainer"
out = area / "native"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location("checked_import_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
base = (area / "base.txt").read_text().strip()
head = (area / "head.txt").read_text().strip()
legacy = "TCSlib/Cryptography/Asymptotic/NextBit"
facade = "TCSlib/Cryptography/Pseudorandom"
owner = facade + "/NextBit"
concrete = owner + "/Concrete"
new_modules = {owner, concrete}
checks = "audits/pass-shelat/Checks"
changed = {facade, legacy} | new_modules


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def git_text(*args):
    return git(*args).decode().strip()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


def write(path, obj):
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2)
        stream.write("\n")


assert git_text("rev-parse", "HEAD") == head and git_text("rev-parse", "HEAD^") == base
assert not git_text("status", "--porcelain")
assert set(git_text("diff", "--name-only", base, head).splitlines()) == {
    module + ".lean" for module in changed
}
old_plan = read(previous / "PLAN.json")
old_products = read(previous / "PRODUCTS.json")
verified = read(records / "prg-defs-move-2026-11-09/VERIFICATION.json")
result = read(previous / "RESULT.json")
assert verified["passed"] and result["passed"]
assert verified["head"] == old_plan["head"] == result["head"]
for name in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / name) == verified["artifact_sha256"]["native/" + name], name
assert not git_text("diff", "--name-only", old_plan["head"], base, "--", "*.lean",
                "lean-toolchain", "lake-manifest.json", "lakefile.lean",
                "lakefile.toml", "scripts/lean_check_tree.sh")
assert sha(Path(old_plan["toolchain"])) == old_plan["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == old_plan["checker_sha256"]

sources = {
    path[:-5]: (root / path).read_bytes()
    for path in git_text("ls-files", "--", "TCSlib", "TCSlib.lean", checks + ".lean").splitlines()
    if path.endswith(".lean")
}
assert set(sources) == set(old_plan["source_digests"]) | new_modules
source_digests = {module: sha256(raw).hexdigest() for module, raw in sources.items()}
assert sha256(git("show", f"{base}:{legacy}.lean")).hexdigest() == old_plan["source_digests"][legacy]
for module in sources.keys() - changed:
    assert source_digests[module] == old_plan["source_digests"][module], module
imports = {
    module: [name.replace(".", "/") for name in graph.imports(raw)
             if name.replace(".", "/") in sources]
    for module, raw in sources.items()
}
assert imports[owner] == [facade + "/Generators/Asymptotic/Defs", concrete]
assert imports[concrete] == ["TCSlib/Cryptography/OneWayFunctions/Basic", facade + "/GeneratorFromPermutation"]
assert imports[legacy] == [owner]
assert [dep for dep in imports[facade] if dep not in new_modules] == old_plan["graph"][facade]
assert imports[facade].count(owner) == imports[facade].count(concrete) == 1
for module in old_plan["graph"].keys() - changed:
    assert imports[module] == old_plan["graph"][module], module
order = graph.topo(imports, ["TCSlib", checks])
assert set(order) == set(old_plan["order"]) | new_modules
def closure(module):
    return set(graph.topo(imports, [module])) - {module}
finite_closure = closure(concrete)
assert not any(module.startswith(("TCSlib/Complexity", "TCSlib/Cryptography/Asymptotic"))
               for module in finite_closure), sorted(finite_closure)
old_closure = set(graph.topo(old_plan["graph"], [legacy])) - {legacy}
removed = old_closure - closure(legacy)
assert removed <= {"TCSlib/Cryptography/Asymptotic/Pseudorandom"}, removed
affected = changed.copy()
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
assert {"TCSlib", checks, owner, legacy, facade} <= affected
rebuild = [module for module in order if module in affected]
assert len(rebuild) == 61
old_tree = Path(old_plan["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
for module in order:
    if module in affected:
        continue
    row = old_products[module]
    direct = {dep: retained[dep]["object_sha256"] for dep in imports[module]}
    assert source_digests[module] == row["source_sha256"] and direct == row["direct_local"], module
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {"source_sha256": row["source_sha256"], "object_sha256": row["object_sha256"],
                        "direct_local": direct, "source": "verified_prg_tree"}
external = {}
for name, row in old_plan["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        target = tree / path.relative_to(old_tree)
        copy(path, target, row["sha256"])
        path = target
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": old_plan["head"],
    "worktree": str(root), "tree": str(tree),
    "toolchain": old_plan["toolchain"], "toolchain_sha256": old_plan["toolchain_sha256"],
    "checker_sha256": old_plan["checker_sha256"], "affected": sorted(affected), "rebuild": rebuild,
    "order": order, "retained": retained, "graph": {module: imports[module] for module in order},
    "external": external, "source_digests": source_digests,
}
write(out / "PLAN.json", plan)
write(area / "SOURCE-CHECK.json", {
    "base": base, "head": head, "old_owner": legacy, "new_owners": sorted(new_modules),
    "changed_paths": sorted(changed), "consumers_rechecked": len(rebuild),
    "finite_tcs_imports": sorted(finite_closure), "legacy_removed_empty_shims": sorted(removed),
    "unchanged_lean_paths": len(sources) - len(changed), "verified_external_objects": len(external),
    "predecessor_verification_sha256": sha(records / "prg-defs-move-2026-11-09/VERIFICATION.json"),
})
print(f"{len(retained)} retained objects, {len(external)} external objects, "
      f"{len(rebuild)} modules to check", flush=True)
