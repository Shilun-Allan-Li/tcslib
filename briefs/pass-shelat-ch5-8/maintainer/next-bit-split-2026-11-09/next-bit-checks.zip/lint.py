import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
root = Path.cwd()
spec = importlib.util.spec_from_file_location("campaign_style_lint", root/"scripts/campaign_style_lint.py")
lint = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lint)
for path in (
    "Asymptotic/NextBit.lean", "Pseudorandom.lean", "Pseudorandom/NextBit.lean",
    "Pseudorandom/NextBit/Concrete.lean", "Pseudorandom/Generators.lean",
):
    file = root / "TCSlib/Cryptography" / path
    if file.is_file():
        lint.check_file(file)
        if lint.is_facade(file):
            lint.check_facade(file)
print(json.dumps(lint.findings, indent=2))
