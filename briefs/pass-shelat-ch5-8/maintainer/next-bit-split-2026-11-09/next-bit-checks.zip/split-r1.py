"""Separate the finite and machine-level next-bit development."""

from hashlib import sha256
from pathlib import Path

crypto = Path("TCSlib/Cryptography")
legacy = crypto / "Asymptotic/NextBit.lean"
ensemble = crypto / "Pseudorandom/NextBit.lean"
concrete = crypto / "Pseudorandom/NextBit/Concrete.lean"
facade = crypto / "Pseudorandom.lean"
raw = legacy.read_bytes()
assert sha256(raw).hexdigest() == "2b3201475ebfd76ad3d043d2c0321c6069ea4337aed2943a5e08f518b1495ba0"
lines = raw.decode().splitlines(keepends=True)
assert len(lines) == 994 and not ensemble.exists() and not concrete.exists()


def span(start, end):
    return "".join(lines[start - 1:end])


def replace(text, before, after, count=1):
    assert text.count(before) == count, before
    return text.replace(before, after)


def file(imports, doc, body, opens):
    header = span(1, 5) + "".join(f"import {module}\n" for module in imports) + span(8, 12)
    return (header + "/-!\n" + doc + "\n-/\n\nnamespace TCSlib.Cryptography\n\nopen " + opens +
            "\n\n" + body.rstrip() + "\n\nend TCSlib.Cryptography\n")


finite = (span(114, 124) + span(141, 152) + span(170, 530) + span(747, 796) + span(814, 841))
finite = replace(finite, "private theorem ofFn_completePrefix", "theorem ofFn_completePrefix")
finite = replace(finite, "private theorem ofFn_prefixOf", "theorem ofFn_prefixOf")
finite = replace(finite,
    "  fun t c => xor (if D (completePrefix i t c.1) c.2 then c.1 i else !c.1 i) flip\n",
    """  fun t c => xor (if D (completePrefix i t c.1) c.2 then c.1 i else !c.1 i) flip

/-- The predictor runs `D` on the completed prefix, selects bit `i` or its negation according
to the verdict, and flips that result when `flip` is true [PS10, Algorithm 76.5]. -/
theorem nextBitPred_eq {ρ : Type*} {ℓ : ℕ} (D : (Fin ℓ → Bool) → ρ → Bool)
    (i : Fin ℓ) (flip : Bool) (t : Fin i → Bool) (c : (Fin ℓ → Bool) × ρ) :
    nextBitPred D i flip t c =
      xor (if D (completePrefix i t c.1) c.2 then c.1 i else !c.1 i) flip :=
  rfl
""")
finite = replace(finite, "  fun t c => decide (A (prefixOf i t) c = t i)\n",
    """  fun t c => decide (A (prefixOf i t) c = t i)

/-- The distinguisher accepts `t` exactly when the prediction from its prefix equals bit `i`. -/
theorem nextBitDist_eq {ρ : Type*} {ℓ : ℕ} (i : Fin ℓ) (A : (Fin i → Bool) → ρ → Bool)
    (t : Fin ℓ → Bool) (c : ρ) :
    nextBitDist i A t c = decide (A (prefixOf i t) c = t i) :=
  rfl
""")

asymptotic = (span(125, 140) + span(153, 169) + span(531, 746) +
              "/-! ### Soundness of the next-bit test -/\n\n" + span(797, 813) + span(842, 993))
asymptotic = replace(asymptotic, "hofn, nextBitPred]", "hofn, nextBitPred_eq]")
asymptotic = replace(asymptotic, "    unfold nextBitProb\n", "    simp only [nextBitProb_eq]\n", 2)
asymptotic = replace(asymptotic, "    unfold nextBitDist\n", "    rw [nextBitDist_eq]\n")

concrete_doc = """# Finite next-bit reductions

At one output length `ℓ`, a predictor receives a prefix of a sample and guesses the next bit.
The hybrids replace the rest of the sample by independent uniform bits. A distinguishing
advantage `ε` yields a position and a sign at which the predictor succeeds with probability
at least `1/2 + ε/ℓ` [PS10, Theorem 75.4]. Conversely, testing a predictor's answer against the
sampled bit gives a distinguisher with advantage equal to the predictor's absolute bias.

## Main definitions

* `TCSlib.Cryptography.nextBitProb` measures prediction success at one position.
* `TCSlib.Cryptography.prefixOf` and `TCSlib.Cryptography.completePrefix` implement prefix
  extraction and completion. Their `List.ofFn` equations connect them to string algorithms.
* `TCSlib.Cryptography.nextBitHybrid` and `TCSlib.Cryptography.nextBitHybridFlip` supply
  the intermediate samplers in the hybrid argument.
* `TCSlib.Cryptography.nextBitPred` and `TCSlib.Cryptography.nextBitDist` give the two
  reductions on finite samplers and adversaries.

## Main results

* `TCSlib.Cryptography.exists_nextBitPred` gives the quantitative hybrid bound.
* `TCSlib.Cryptography.prgAdv_eq_zero_of_length_eq_zero` handles the empty string.
* `TCSlib.Cryptography.nextBitProb_id` gives success probability `1/2` on uniform strings.
* `TCSlib.Cryptography.prgAdv_nextBitDist` gives the converse advantage identity.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.2.2: Definition 75.2, Theorem 75.4, Algorithm 76.5; §3.1.1: Lemmas 71.6 and 73.8.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.3 (Definition 3.5 and Theorems 3.1–3.2)."""
ensemble_doc = """# The next-bit characterization of pseudorandom ensembles

The next-bit test bounds the success of every non-uniform polynomial-time predictor by
one half plus a negligible function. The predictor receives `1^n` and the prefix of the
sample [PS10, Definition 75.2 and Remark 75.3]. The reductions implement the finite
predictor and distinguisher as machines. For completeness, the predictor gets the sign in
its advice and reads the position from the prefix length. Where the output length is zero,
the distinguishing advantage is zero and there is no position to choose.

## Main definitions

* `TCSlib.Cryptography.Ensemble.NextBitUnpredictable` gives the next-bit test with a single
  negligible bound for all positions.

## Main results

* `TCSlib.Cryptography.Ensemble.NextBitUnpredictable.pseudorandom` gives completeness
  of the test [PS10, Theorem 75.4].
* `TCSlib.Cryptography.Ensemble.Pseudorandom.nextBitUnpredictable` gives the converse.
* `TCSlib.Cryptography.Ensemble.uniform_nextBitUnpredictable` establishes the test for
  the uniform ensemble.

## Contents

* `Concrete` gives the finite next-bit experiments, hybrids, and advantage bounds.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.2.2: Definition 75.2, Remark 75.3, Theorem 75.4, Algorithm 76.5.)"""
shim = span(1, 5) + "import TCSlib.Cryptography.Pseudorandom.NextBit\n" + span(8, 12) + """/-!
# Next-bit compatibility import

## Main definitions

This import exposes the finite experiment and the ensemble next-bit test from
`TCSlib.Cryptography.Pseudorandom.NextBit`.

## Main results

The finite bounds and both directions of the ensemble characterization are available
through this import.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Definition 75.2 and Theorem 75.4.)
-/
"""

new_facade = facade.read_text()
new_facade = replace(new_facade,
    "import TCSlib.Cryptography.Pseudorandom.Functions\n",
    "import TCSlib.Cryptography.Pseudorandom.Functions\n"
    "import TCSlib.Cryptography.Pseudorandom.NextBit.Concrete\n"
    "import TCSlib.Cryptography.Pseudorandom.NextBit\n")
new_facade = replace(new_facade,
    "  proof in `TCSlib.Cryptography.Pseudorandom.Functions.GGM` [Gar26, Theorem 3.3].\n",
    "  proof in `TCSlib.Cryptography.Pseudorandom.Functions.GGM` [Gar26, Theorem 3.3].\n"
    "* `NextBit.Concrete` gives the finite next-bit experiment and both quantitative reductions.\n"
    "* `NextBit` implements the reductions as machines and characterizes pseudorandom ensembles.\n")
new_facade = replace(new_facade,
    "  In `TCSlib.Cryptography.Asymptotic.NextBit`,\n",
    "  In `TCSlib.Cryptography.Pseudorandom.NextBit`,\n")

outputs = {
    legacy: shim,
    concrete: file(["TCSlib.Cryptography.Pseudorandom.Generators"], concrete_doc, finite, "Finset"),
    ensemble: file(["TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs",
                    "TCSlib.Cryptography.Pseudorandom.NextBit.Concrete"],
                   ensemble_doc, asymptotic, "Complexity Turing Finset"),
    facade: new_facade,
}
for path, text in outputs.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
