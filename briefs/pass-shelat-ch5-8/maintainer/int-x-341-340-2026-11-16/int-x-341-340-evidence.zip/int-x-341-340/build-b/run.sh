#!/usr/bin/env bash
# build B (int-x-341-340): runner.py at B ac6f0a1c in the worktree, queue plan-b/queue.txt, tree dl-oleans
export PATH=$HOME/.elan/bin:$PATH
date -u +%FT%TZ > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/launched-utc.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/tools-used/review/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-int-x341 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/plan-b/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b
echo "runner rc=$?" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/runner-rc.txt
