#!/usr/bin/env bash
# int-x-341-340: int-x-331-339-338's diskwatch.sh (log free space on / every 60 s until build-b/runner-rc.txt is non-empty) plus a
# pause guard: if free space falls below 1000 MB, send SIGSTOP once to this job's own build process group (the setsid group of
# build-b/run.sh, recorded in build-b/launch.txt) and write build-b/PAUSED. Resuming (SIGCONT) is done by hand and logged.
while [ ! -s /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/runner-rc.txt ]; do
  f=$(df -B1M / | tail -1 | awk '{print $4}'); echo "$(date -u +%FT%TZ) $f MB free" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/df.log
  if [ "$f" -lt 1000 ] && [ ! -e /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/PAUSED ]; then
    g=$(awk '/^pgid/{print $2}' /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/launch.txt); kill -STOP -- -$g && echo "$(date -u +%FT%TZ) PAUSED pgid $g at $f MB free" | tee /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/PAUSED >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/df.log
  fi
  sleep 60
done
echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free (end)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-x-341-340/build-b/df.log
