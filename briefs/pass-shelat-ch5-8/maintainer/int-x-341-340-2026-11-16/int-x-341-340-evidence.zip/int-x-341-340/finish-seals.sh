#!/usr/bin/env bash
# int-x-341-340 canonical Rule 10 seals coe A and coe B on #340's owner Pairing/Assumptions at B (after the probe; before the
# restore). The collector step of pair-bdh's rule10_pbdh.sh and the coe steps of LE-gate40's rule10_b.sh, with the pair-bdh
# tools verbatim (tools-used/seal-pbdh = fill-pair-bdh's tools-used/seal). Probe subdirectory PbdhProbe as in the in-house run,
# so the probe sources can be compared byte for byte. Every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing
# written to the tree). One Lean process at a time. Probe sources are removed from the worktree afterwards.
set -eu
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-341-340; W=$SP/wt-int-x341; TREE=$SP/dl-oleans
T=$E/tools-used/seal-pbdh; G=$T/review/archived-gate10-tools; S=$E/seals-340; P=PbdhProbe
H=$(git -C $W rev-parse HEAD); [ "$H" = ac6f0a1c8b8fb8a80c9c87c5524bad5ec70769db ]
mkdir -p $SP/intx41-work/tmp; export TCSLIB_OLEANS_TREE=$TREE TMPDIR=$SP/intx41-work/tmp PATH=$HOME/.elan/bin:$PATH
MODS="TCSlib.Cryptography.Pairing.Assumptions"
echo "start $(date -u +%FT%TZ) head $H"
mkdir -p $S/order $S/probe-sources $W/$P
printf '%s\n' $MODS > $S/order/owners.txt
python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $S/order/owners.txt "fill-pair-bdh collector" $W/$P/CollectHead.lean
cp $W/$P/CollectHead.lean $S/probe-sources/CollectHead.lean.txt
printf 'PbdhProbe/CollectHead\n' > $S/order/probes.txt
python3 -I $T/runner_full.py $W $S/order/probes.txt $TREE $S/probe-runs > $S/probe-runner.out 2>&1
LOG=$S/probe-runs/mods/${P}_CollectHead.log
cd $T
python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $S/seals-coe/A $P/C SealA_ $MODS > $S/mkseals-coe-A.log
SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $S/seals-coe/B $P/C SealB_ $MODS > $S/mkseals-coe-B.log
(cd $W && ls $P/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $S/order/seal-queue.txt
(cd $W && sha256sum $P/CollectHead.lean $P/C/*.lean && git status --short --untracked-files=all) > $S/probe-files-in-worktree.txt
python3 -I $T/runner_full.py $W $S/order/seal-queue.txt $TREE $S/seal-runs > $S/seal-runner.out 2>&1 || true
TJ=$S/touched-after.json.from-pair-bdh
python3 -I $T/review/sealsum.py $S/seals-coe/A $S/seal-runs $TJ $S/seals-coe-A.tsv
python3 -I $T/review/sealsum.py $S/seals-coe/B $S/seal-runs $TJ $S/seals-coe-B.tsv
rm -r $W/$P; (cd $W && echo "after removal: $(git status --short --untracked-files=all | wc -l) status lines") >> $S/probe-files-in-worktree.txt
cat $S/mkseals-coe-*.log $S/seals-coe-*.tsv
echo "done $(date -u +%FT%TZ)"
