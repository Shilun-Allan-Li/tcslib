r"""sealcmp41.py <seals-340 dir> <pair-bdh rule10 dir> <out> (int-x-341-340, new): compare this job's coe A/B seals of
Pairing/Assumptions at B with pair-bdh's in-house coe A/B seals at 916afc25 (fill-pair-bdh-evidence.zip :: fill-pair-bdh/rule10):
the collector source and its log, each seal probe source (.lean.txt), each seal record (.json) key by key (keys whose values
differ are listed), the manifests, each seal-run log byte for byte, and the sealsum rows."""
import sys, os, json, hashlib, glob
a, b, out = sys.argv[1:4]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
rows = []; diff = []
def same(label, p, q):
    s, t = sha(p), sha(q); ok = s is not None and s == t
    rows.append(f"{'SAME' if ok else 'DIFF'} {label}: {s} vs {t}")
    if not ok: diff.append(label)
same('collector source', f'{a}/probe-sources/CollectHead.lean.txt', f'{b}/probe-sources/CollectHead.lean.txt')
same('collector log', f'{a}/probe-runs/mods/PbdhProbe_CollectHead.log', f'{b}/probe-runs/mods/PbdhProbe_CollectHead.log')
for v in 'AB':
    n = f'Seal{v}_Cryptography_Pairing_Assumptions'
    same(f'coe {v} probe source', f'{a}/seals-coe/{v}/{n}.lean.txt', f'{b}/seals-coe/{v}/{n}.lean.txt')
    x, y = json.load(open(f'{a}/seals-coe/{v}/{n}.json')), json.load(open(f'{b}/seals-coe/{v}/{n}.json'))
    ks = sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k))
    rows.append(f'coe {v} record keys that differ: {ks}' + ''.join(f'\n    {k}: {x.get(k)!r} vs {y.get(k)!r}' for k in ks if k in ('rev',)))
    if [k for k in ks if k != 'rev']: diff.append(f'coe {v} record')
    mx, my = json.load(open(f'{a}/seals-coe/{v}/manifest.json')), json.load(open(f'{b}/seals-coe/{v}/manifest.json'))
    mk = sorted(k for k in set(mx) | set(my) if mx.get(k) != my.get(k)) if isinstance(mx, dict) else (['(list)'] if mx != my else [])
    rows.append(f'coe {v} manifest keys that differ: {mk}')
    same(f'coe {v} seal-run log', f'{a}/seal-runs/mods/PbdhProbe_C_{n}.log', f'{b}/seal-runs/mods/PbdhProbe_C_{n}.log')
    same(f'coe {v} sealsum row', f'{a}/seals-coe-{v}.tsv', f'{b}/seals-coe-{v}.tsv')
rows.append('RESULT ' + ('IDENTICAL (apart from the recorded revision)' if not diff else f'DIFFERENCES {diff}'))
open(out, 'w').write('\n'.join(rows) + '\n'); print('\n'.join(rows))
