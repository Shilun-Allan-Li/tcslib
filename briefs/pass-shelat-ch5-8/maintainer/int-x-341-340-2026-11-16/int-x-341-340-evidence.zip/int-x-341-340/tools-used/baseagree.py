"""baseagree.py <repo> <base-rev> <state-init.json> <base-records.jsonl> (int-x-331-339-338, new; reproduces the one-line
checks/base-records-agree.txt of int-x-327-324-333): every state-init module's last base record must be rc 0, have the
snapshot olean hash recorded in the state, and the module's source SHA-256 at <base-rev>."""
import sys, json, hashlib, subprocess
repo, rev, st, recs = sys.argv[1:5]
state = json.load(open(st)); last = {}
for l in open(recs):
    r = json.loads(l)
    if 'module' in r: last[r['module']] = r
ok = bad = 0; badl = []
for m, s in sorted(state.items()):
    r = last.get(m)
    src = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{m}.lean'], capture_output=True).stdout
    if r and r['rc'] == 0 and r['object_sha256'] == s['olean'] and r['source_sha256'] == hashlib.sha256(src).hexdigest(): ok += 1
    else: bad += 1; badl.append(m)
print(f'state-init modules {len(state)}: base record (int-317) rc 0 with snapshot olean and {rev[:8]} source: agree {ok}, disagree {bad} {badl[:5]}')
