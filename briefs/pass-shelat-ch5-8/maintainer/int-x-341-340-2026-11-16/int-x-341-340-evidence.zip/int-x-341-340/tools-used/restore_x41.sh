#!/usr/bin/env bash
# restore_x41.sh <tree> <backup-dir> <evidence-dir> (int-x-341-340: restore_x3.sh from int-x-331-339-338 with only the order path changed to order-b):
# put the base oleans back (tree/backed-up.txt, hashes checked), delete the oleans of modules new since the snapshot
# (tree/new-oleans.txt), remove the Mathlib overlay (symlinks + the compiled NthRootLemmas olean, logged), then
# restoreplan.py --delete against tree/snapshot-pre.txt (extra files and emptied directories), and a fresh snapshot
# compared byte-for-byte with tree/snapshot-pre.txt.
set -u
T=$1; BK=$2; E=$3; L=$E/restore/restore-log.txt; mkdir -p $E/restore; : > $L
(cd $BK && sha256sum -c $E/tree/backed-up.txt) | grep -vc ': OK$' | sed 's/^/backup hash failures: /' >> $L
n=0; while read h f; do cp -p $BK/$f $T/$f; [ "$(sha256sum < $T/$f | cut -d' ' -f1)" = "$h" ] || echo "RESTORE-HASH-FAIL $f" >> $L; echo "RESTORED $f" >> $L; n=$((n+1)); done < $E/tree/backed-up.txt
echo "restored $n" >> $L
d=0; while read m; do if [ -f $T/$m.olean ]; then echo "DELETED $(sha256sum < $T/$m.olean | cut -d' ' -f1) $m.olean" >> $L; rm $T/$m.olean; d=$((d+1)); fi; done < $E/tree/new-oleans.txt
echo "deleted new oleans $d" >> $L
if [ -d $T/Mathlib ]; then echo "DELETED-MATHLIB-OVERLAY symlinks $(find $T/Mathlib -type l | wc -l) files $(find $T/Mathlib -type f | wc -l)" >> $L; find $T/Mathlib -type f -exec sha256sum {} + | sed "s|^|DELETED-MATHLIB-FILE |" >> $L; rm -r $T/Mathlib; fi
python3 -I $E/tools-used/restoreplan.py $T $E/tree/snapshot-pre.txt $E/order-b/order.txt $E/restore --delete > $E/restore/restoreplan.out
python3 -I $E/tools-used/review/snapshot.py $T $E/tree/snapshot-post.txt > $E/restore/snapshot-post.out
cat $E/restore/restoreplan.out $E/restore/snapshot-post.out
cmp $E/tree/snapshot-pre.txt $E/tree/snapshot-post.txt && echo "SNAPSHOT EQUAL" || echo "SNAPSHOT DIFFERS"
