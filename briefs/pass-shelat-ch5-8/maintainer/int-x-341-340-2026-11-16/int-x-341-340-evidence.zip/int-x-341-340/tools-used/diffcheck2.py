r"""diffcheck2.py <repo> <tip> <merged> <outdir> <head>... (int-x-341-340, new): the landing diff check of int-x-331-339-338
(landing/diff-check.txt there) as one script. Writes <outdir>/diff-tip-X.raw (git diff --raw --no-renames --no-abbrev tip merged
-- TCSlib TCSlib.lean audits), diff-prs.raw (each head's diff against merge-base(tip, head), same paths, prefixed by the head),
all-paths-tip-X.txt (git diff --name-only tip merged over the whole tree) and diff-check.txt, and checks:
  (1) the tip..merged raw diff equals the union of the PR diffs exactly (path, status, old mode, new mode, old blob, new blob);
  (2) the PR path sets are pairwise disjoint;
  (3) for each PR path, the old blob at the tip equals the old blob at that PR's merge base (no file changed on both sides);
  (4) every PR path is blob-equal (and mode-equal) at merged and at its head (deleted files absent at both);
  (5) no path of the whole-tree tip..merged diff lies outside TCSlib/, TCSlib.lean, audits/.
Prints and writes RESULT OK / FAIL."""
import sys, os, subprocess
repo, tip, merged, outd = sys.argv[1:5]; heads = sys.argv[5:]
os.makedirs(outd, exist_ok=True)
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
P = ['--', 'TCSlib', 'TCSlib.lean', 'audits']
def raw(a, b):
    rows = {}
    for l in git('diff', '--raw', '--no-renames', '--no-abbrev', a, b, *P).splitlines():
        meta, path = l.split('\t', 1); om, nm, ob, nb, st = meta[1:].split(' ')
        rows[path] = (st, om, nm, ob, nb)
    return rows
def blob(rev, path):
    r = subprocess.run(['git', '-C', repo, 'ls-tree', rev, '--', path], capture_output=True, text=True, check=True).stdout.split()
    return (r[0], r[2]) if r else None
out = []; bad = []
tx = raw(tip, merged)
open(os.path.join(outd, 'diff-tip-X.raw'), 'w').write(git('diff', '--raw', '--no-renames', '--no-abbrev', tip, merged, *P))
out.append(f'diff-check (int-x-341-340): tip={git("rev-parse", tip).strip()} merged={git("rev-parse", merged).strip()}')
union, seen, prs = {}, {}, []
with open(os.path.join(outd, 'diff-prs.raw'), 'w') as f:
    for h in heads:
        H = git('rev-parse', h).strip(); mb = git('merge-base', tip, H).strip(); d = raw(mb, H); prs.append((H, mb, d))
        out.append(f'PR head {H} merge-base(tip, head) {mb}: {len(d)} paths')
        for p, r in sorted(d.items()):
            f.write(f'{H} :{r[1]} {r[2]} {r[3]} {r[4]} {r[0]}\t{p}\n')
            if p in seen: bad.append(f'path in two PRs: {p} ({seen[p][:8]}, {H[:8]})')
            seen[p] = H; union[p] = r
out.append(f'tip..merged: {len(tx)} paths; union of PR diffs: {len(union)} paths; sum of PR path counts {sum(len(d) for _, _, d in prs)}')
for p in sorted(set(tx) | set(union)):
    if tx.get(p) != union.get(p): bad.append(f'(1) differs: {p} tip..merged {tx.get(p)} union {union.get(p)}')
for H, mb, d in prs:
    for p, r in sorted(d.items()):
        bt, bm, bh, bx = blob(tip, p), blob(mb, p), blob(H, p), blob(merged, p)
        if bt != bm: bad.append(f'(3) old blob at tip {bt} != at merge base {bm}: {p}')
        if bx != bh: bad.append(f'(4) merged {bx} != head {bh}: {p}')
allp = git('diff', '--name-only', tip, merged).splitlines()
open(os.path.join(outd, 'all-paths-tip-X.txt'), 'w').write(''.join(p + '\n' for p in allp))
outside = [p for p in allp if not (p.startswith('TCSlib/') or p == 'TCSlib.lean' or p.startswith('audits/'))]
if outside: bad.append(f'(5) paths outside TCSlib/, TCSlib.lean, audits/: {outside}')
out.append(f'whole-tree tip..merged: {len(allp)} paths; outside TCSlib/, TCSlib.lean, audits/: {len(outside)}')
out.append('checks: (1) raw diff = union exactly; (2) PR path sets pairwise disjoint; (3) old blobs at tip = at each merge base;'
           ' (4) every PR path blob- and mode-equal at merged and head; (5) nothing outside TCSlib/, TCSlib.lean, audits/')
out += [f'FAIL {b}' for b in bad]
out.append('RESULT ' + ('OK' if not bad else 'FAIL'))
open(os.path.join(outd, 'diff-check.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
