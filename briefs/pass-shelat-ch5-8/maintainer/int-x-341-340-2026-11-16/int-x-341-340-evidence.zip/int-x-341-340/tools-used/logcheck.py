r"""logcheck.py (int-x-327-324-333, new; ENOSPC follow-up) <results.jsonl> <out> <name=ref-records.jsonl>...: for each module's
last record of the run: OK-REF when some same-source rc-0 reference record has the same olean AND the same log SHA-256, sorry and
warning counts; LOGDIFF when a same-source reference has the same olean but no reference has the same log (a truncated log would
show here); OBJDIFF-ONLY when same-source references exist but none with the same olean; NOREF when no same-source reference.
Also flags any record with rc 0 whose log is 0 bytes while a same-source reference log is non-empty."""
import sys, json, os
res, out = sys.argv[1:3]; refs = {}
for a in sys.argv[3:]:
    n, f = a.split('=', 1)
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: refs.setdefault((r['module'], r['source_sha256']), []).append((n, r))
last = {}
for l in open(res):
    r = json.loads(l)
    if 'module' in r: last[r['module']] = r
E0 = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
from collections import Counter
c = Counter(); bad = []
with open(out, 'w') as o:
    for m, r in last.items():
        rs = refs.get((m, r['source_sha256']), [])
        so = [x for _, x in rs if x['object_sha256'] == r['object_sha256']]
        sl = [x for x in so if x['log_sha256'] == r['log_sha256'] and x['sorry'] == r['sorry'] and x['warnings'] == r['warnings']]
        k = 'NOREF' if not rs else 'OK-REF' if sl else 'LOGDIFF' if so else 'OBJDIFF-ONLY'
        if r['rc'] == 0 and r['log_sha256'] == E0 and any(x['log_sha256'] != E0 for _, x in rs): k += '+EMPTYLOG-VS-NONEMPTY-REF'
        c[k] += 1
        if k not in ('OK-REF', 'NOREF'): bad.append(m)
        o.write(f'{k}\t{m}\t{",".join(sorted({n for n, x in rs if x["object_sha256"] == r["object_sha256"]}))}\n')
    o.write(f'SUMMARY {dict(c)}; flagged {bad}\n')
print(open(out).read().splitlines()[-1])
