r"""mkprobe41.py <prev AxiomsX3c.lean.txt> <axioms-dir> <out> (int-x-341-340, new): the int-x-331-339-338 probe (AxiomsX3c) with
new name and owner lists. Kept byte-for-byte from AxiomsX3c: the DepTrace header (deptrace-header.lean.txt: `import TCSlib`,
`directSorry`, `closureOf`, `#admitted`) and the OWNERCLOSURE `run_cmd` block, of which only the owners list is replaced.
Names: names-yao.txt, names-t1.txt, names-gsw-core.txt, names-gsw-security.txt, names-pairing-standard.txt,
names-pairing-admitted.txt (each `#print axioms n` then `#admitted n`). Owners: owners-prev15.txt (AxiomsX3c's 15) then
owners-341.txt (#341's 70 Rule 10 owner modules)."""
import sys, os
prev, d, out = sys.argv[1:4]
src = open(prev).read()
hdr = open(os.path.join(d, 'deptrace-header.lean.txt')).read()
assert src.startswith(hdr)
i = src.index('/- `OWNERCLOSURE`'); block = src[i:]
a = block.index('  let owners : List Name := ['); b = block.index(']\n', a) + 2
rd = lambda f: [l.strip() for l in open(os.path.join(d, f)) if l.strip()]
owners = rd('owners-prev15.txt') + rd('owners-341.txt')
assert len(owners) == len(set(owners))
newlist = '  let owners : List Name := [\n' + ',\n'.join(f'    `{o}' for o in owners) + ']\n'
block = block[:a] + newlist + block[b:]
parts = [hdr, '/-! int-x-341-340 axioms probe at B ac6f0a1c (records tip ee11f2a6 x #341 355a0288 x #340 916afc25): `#print axioms`\n'
         'and the `#admitted` dependency trace (int-stmt-331-333\'s DepTrace, unmodified, as in int-x-331-339-338) of every requested\n'
         f'name, then a per-module closure census (`OWNERCLOSURE`) of {len(owners)} owner modules (int-x-331-339-338\'s 15 and #341\'s 70). -/\n']
for f, title in [('names-yao.txt', '#341 (sc-yao) results expected standard: the Yao results, RunWithHost.acc_poly, the ten otProtocol_* and hbcSecure_compose'),
                 ('names-t1.txt', '#340 (pair-bdh) T1, expected standard'),
                 ('names-gsw-core.txt', '#339 (gsw-core) targets'), ('names-gsw-security.txt', '#338 (gsw-security) targets'),
                 ('names-pairing-standard.txt', '#331 (pairing) results expected standard'),
                 ('names-pairing-admitted.txt', '#331 (pairing) admissions T2-T4 and bb1_sidSecure')]:
    ns = rd(f); parts.append(f'\n-- {title}: {len(ns)}\n')
    for n in ns: parts.append(f'#print axioms {n}\n#admitted {n}\n')
parts.append('\n' + block)
open(out, 'w').write(''.join(parts)); print(f'wrote {out}: names {sum(len(rd(f)) for f in os.listdir(d) if f.startswith("names-"))}, owners {len(owners)}')
