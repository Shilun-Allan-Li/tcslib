r"""axsum.py <probe-log> <axioms-dir> <out> (int-x-331-339-338, new): parse `#print axioms` and `#admitted` (DepTrace) output and
OWNERCLOSURE lines, and check the expectations of the int-x-331-339-338 brief against the name lists in <axioms-dir>:
names-gsw-core.txt, names-gsw-security.txt, names-pairing-standard.txt -> axioms a subset of the standard
{propext, Classical.choice, Quot.sound} and 0 direct sorryAx users in the closure; names-pairing-admitted.txt: T1-T4 -> axioms =
a standard subset plus sorryAx, and the only direct sorryAx user in its closure is the name itself; bb1_sidSecure -> the same
with direct users exactly T2, T3, T4. ("does not depend on any axioms" parses as [].)"""
import sys, re, os
log, d, out = sys.argv[1:4]
t = open(log, encoding='utf-8', errors='replace').read()
ax = {m.group(1): sorted(re.sub(r'\s+', '', m.group(2)).split(',')) for m in re.finditer(r"'([^']+)' depends on axioms: \[([^\]]*)\]", t)}
ax.update({m.group(1): [] for m in re.finditer(r"'([^']+)' does not depend on any axioms", t)})
adm = {m.group(1): (int(m.group(2)), [x for x in re.sub(r'\s+', '', m.group(4)).split(',') if x])
       for m in re.finditer(r'ADMITTED (\S+): closure (\d+); direct sorryAx (\d+): \[([^\]]*)\]', t)}
own = re.findall(r'OWNERCLOSURE (\S+): stored (\d+); union closure (\d+); direct sorryAx (\d+): \[([^\]]*)\]', t)
names = lambda f: [l.strip() for l in open(os.path.join(d, f)) if l.strip()]
STD = sorted(['propext', 'Classical.choice', 'Quot.sound']); SORRY = sorted(STD + ['sorryAx'])
IB = 'TCSlib.Cryptography.AdvancedEncryption.IdentityBased.'
T24 = sorted([IB + 'bb1_sim_real', IB + 'bb1_sim_random', IB + 'exists_bb1_distinguisher'])
rows, bad = [], []
def chk(group, n, axexp, admexp):
    a = ax.get(n); c = adm.get(n)
    ok = a is not None and set(a) <= set(STD) | ({'sorryAx'} if axexp == SORRY else set()) and (('sorryAx' in a) == (axexp == SORRY)) \
        and c is not None and sorted(c[1]) == sorted(admexp)
    if not ok: bad.append(n)
    rows.append(f"{'OK ' if ok else 'BAD'} {group:16} {n}  axioms {a}  closure {c[0] if c else '-'}  direct sorryAx {c[1] if c else '-'}")
for f, g in [('names-gsw-core.txt', 'gsw-core #339'), ('names-gsw-security.txt', 'gsw-sec #338'), ('names-pairing-standard.txt', 'pairing std #331')]:
    for n in names(f): chk(g, n, STD, [])
for n in names('names-pairing-admitted.txt'):
    chk('pairing adm #331', n, SORRY, T24 if n.endswith('.bb1_sidSecure') else [n])
with open(out, 'w') as o:
    for r in rows: o.write(r + '\n')
    for m, s, c, k, l in own: o.write(f"OWNERCLOSURE {m}: stored {s}; union closure {c}; direct sorryAx {k}: {[x for x in re.sub(r'\s+', '', l).split(',') if x]}\n")
    o.write(f"names {len(rows)} (gsw-core {len(names('names-gsw-core.txt'))}, gsw-security {len(names('names-gsw-security.txt'))}, pairing standard "
            f"{len(names('names-pairing-standard.txt'))}, pairing admitted {len(names('names-pairing-admitted.txt'))}); parsed axioms {len(ax)}, admitted {len(adm)}, ownerclosure {len(own)}; failing {bad}\n")
    o.write('RESULT ' + ('OK' if not bad and len(rows) == len(ax) == len(adm) else 'FAIL') + '\n')
print(open(out).read().splitlines()[-2]); print(open(out).read().splitlines()[-1])
