r"""sealrel2.py <repo> <sr-dir> <B> <tip> (int-x-341-340, new): seal relevance from the closures written by fullorder.py
(one root per owner) under <sr-dir>/closures-B, closures-head and closures-Mprime.
  (a) #341's owners (owners-341.txt): which modules of changed-331-339-338-modules.txt (git diff 2da7e0f3 <tip> --name-only
      -- TCSlib) lie in each owner's closure at <B>;
  (b) #340's owner (owners-340.txt): which modules changed by #339 or #338, or by #331 outside Pairing/Assumptions, lie in its
      closure at <B>; each changed module is attributed to its PR by that PR's own diff against its merge base;
  (c) per owner, the closure at <B> against the closure at the PR head (and, for #341, at M' 061ad60c, the sc-yao integration
      build on the older tip): module sets and the source blob of every common module.
Writes result-at-B.txt and closure-head-vs-B.txt in <sr-dir>."""
import sys, os, subprocess
repo, d, B, tip = sys.argv[1:5]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
rd = lambda f: [l.strip() for l in open(os.path.join(d, f)) if l.strip()]
PR = {'331': ('673a27158338437896c624df32bf5421c6ba45cf', '9e7a96481785d6cac4dea3b2e990c49ac278b060'),
      '339': ('347665bd741d367c4d2057f7d61866ff1d91c356', '839f36cca9b4af0570c014f03f19858d0a03cbfb'),
      '338': ('15d8f01a42f23aa17d8fd305c7e5edde9b602da4', 'd45d3682089cb6fd04f4d075f48a464fefaa143c')}
owner_of = {}
for k, (mb, h) in PR.items():
    for p in git('diff', '--name-only', mb, h, '--', 'TCSlib').split():
        owner_of.setdefault(p[:-5], []).append(k)
changed = rd('changed-331-339-338-modules.txt')
HEAD = {'341': '355a0288d56290e8c984228cbc1824187029e456', '340': '916afc25c21f5e52b4b01958186ad55d2f615fd1'}
MP = '061ad60cdc485e6248eeadfc2de165a227f7cd99'
cl = lambda sub, o: rd(os.path.join(sub, o.replace('/', '_') + '.txt'))
blobs = {}
def blob(rev, m):
    if (rev, m) not in blobs:
        r = git('ls-tree', rev, '--', m + '.lean').split(); blobs[(rev, m)] = r[2] if r else None
    return blobs[(rev, m)]
out = [f'seal relevance (int-x-341-340) at B {B[:8]}; tip {tip[:8]}; changed by #331/#339/#338 (git diff 2da7e0f3 {tip[:8]} --name-only -- TCSlib): {len(changed)} modules']
for m in changed: out.append(f'  changed {m}  by #{",#".join(owner_of.get(m, ["?"]))}')
unattributed = [m for m in changed if m not in owner_of]
out.append(f'  unattributed: {unattributed}')
o341 = rd('owners-341.txt'); hitA = {}
union = set()
for o in o341:
    c = set(cl('closures-B', o)); union |= c
    h = sorted(c & set(changed))
    if h: hitA[o] = h
out.append(f'(a) #341: {len(o341)} owners; union of their closures at B {len(union)} modules; owners whose closure contains a changed module: {len(hitA)}')
for o, h in hitA.items(): out.append(f'  {o}: {h}')
out.append('(a) RESULT: ' + ('NONE of the changed modules lies in any #341 owner closure' if not hitA else 'SOME (listed above)'))
o340 = rd('owners-340.txt')[0]; c340 = cl('closures-B', o340)
rel = [m for m in changed if ('339' in owner_of.get(m, []) or '338' in owner_of.get(m, []) or
                              ('331' in owner_of.get(m, []) and m != 'TCSlib/Cryptography/Pairing/Assumptions'))]
hitB = sorted(set(c340) & set(rel))
out.append(f'(b) #340 owner {o340}: closure at B {len(c340)} modules; relevant changed modules {len(rel)}; in closure: {len(hitB)}')
for m in hitB:
    out.append(f'  {m} (#{",#".join(owner_of[m])}): blob at B {blob(B, m)}, at #340 head {blob(HEAD["340"], m)}, at #331 head '
               f'{blob(PR["331"][1], m)}, at 2da7e0f3 {blob("2da7e0f3cd65ec93ed71813b7828c3b66ba18942", m)}')
out.append('(b) RESULT: ' + ('NONE' if not hitB else f'SOME: {hitB}'))
cmp = []
def compare(o, sub, rev, label):
    a, b = set(cl('closures-B', o)), set(cl(sub, o))
    diffsrc = sorted(m for m in a & b if blob(B, m) != blob(rev, m))
    s = 'SAME' if a == b and not diffsrc else 'DIFFERENT'
    cmp.append(f'{s} {o} vs {label}: B {len(a)} / {label} {len(b)}; only at B {sorted(a - b)}; only at {label} {sorted(b - a)}; '
               f'common with different source {diffsrc}')
    return s == 'SAME'
same_head = sum(compare(o, 'closures-head', HEAD['341'], '#341 head 355a0288') for o in o341)
same_mp = sum(compare(o, 'closures-Mprime', MP, "M' 061ad60c") for o in o341)
same_340 = compare(o340, 'closures-head', HEAD['340'], '#340 head 916afc25')
cmp.append(f"summary: #341 owners SAME as at head {same_head}/{len(o341)}, SAME as at M' {same_mp}/{len(o341)}; #340 owner SAME as at head: {same_340}")
open(os.path.join(d, 'closure-head-vs-B.txt'), 'w').write('\n'.join(cmp) + '\n')
out.append(cmp[-1])
open(os.path.join(d, 'result-at-B.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
