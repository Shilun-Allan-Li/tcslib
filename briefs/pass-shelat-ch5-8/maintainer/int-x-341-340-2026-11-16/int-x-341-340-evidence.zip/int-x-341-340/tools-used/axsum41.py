r"""axsum41.py <probe-log> <axioms-dir> <out> (int-x-341-340: int-x-331-339-338's axsum.py with this brief's expectations; parsing
unchanged). Name lists in <axioms-dir>:
  names-yao.txt, names-t1.txt, names-gsw-core.txt, names-gsw-security.txt, names-pairing-standard.txt -> axioms a subset of the
  standard {propext, Classical.choice, Quot.sound} and 0 direct sorryAx users in the closure;
  names-pairing-admitted.txt: T2-T4 -> axioms = a standard subset plus sorryAx, and the only direct sorryAx user in its closure is
  the name itself; bb1_sidSecure -> the same with direct users exactly T2, T3, T4.
OWNERCLOSURE expectations (owners-prev15.txt, owners-341.txt): BonehBoyenMachine -> exactly [T4]; BonehBoyenSecurity -> exactly
[T2, T3, T4]; every other owner (Pairing/Assumptions included, now that T1 is proved) -> no direct sorryAx user; all 85 present,
then OWNERCLOSURE-EOF. ("does not depend on any axioms" parses as [].)"""
import sys, re, os
log, d, out = sys.argv[1:4]
t = open(log, encoding='utf-8', errors='replace').read()
ax = {m.group(1): sorted(re.sub(r'\s+', '', m.group(2)).split(',')) for m in re.finditer(r"'([^']+)' depends on axioms: \[([^\]]*)\]", t)}
ax.update({m.group(1): [] for m in re.finditer(r"'([^']+)' does not depend on any axioms", t)})
adm = {m.group(1): (int(m.group(2)), [x for x in re.sub(r'\s+', '', m.group(4)).split(',') if x])
       for m in re.finditer(r'ADMITTED (\S+): closure (\d+); direct sorryAx (\d+): \[([^\]]*)\]', t)}
own = re.findall(r'OWNERCLOSURE (\S+): stored (\d+); union closure (\d+); direct sorryAx (\d+): \[([^\]]*)\]', t)
names = lambda f: [l.strip() for l in open(os.path.join(d, f)) if l.strip()]
STD = sorted(['propext', 'Classical.choice', 'Quot.sound']); SORRY = sorted(STD + ['sorryAx'])
IB = 'TCSlib.Cryptography.AdvancedEncryption.IdentityBased.'
T24 = sorted([IB + 'bb1_sim_real', IB + 'bb1_sim_random', IB + 'exists_bb1_distinguisher'])
rows, bad = [], []
def chk(group, n, axexp, admexp):
    a = ax.get(n); c = adm.get(n)
    ok = a is not None and set(a) <= set(STD) | ({'sorryAx'} if axexp == SORRY else set()) and (('sorryAx' in a) == (axexp == SORRY)) \
        and c is not None and sorted(c[1]) == sorted(admexp)
    if not ok: bad.append(n)
    rows.append(f"{'OK ' if ok else 'BAD'} {group:18} {n}  axioms {a}  closure {c[0] if c else '-'}  direct sorryAx {c[1] if c else '-'}")
G = [('names-yao.txt', 'sc-yao #341'), ('names-t1.txt', 'pair-bdh T1 #340'), ('names-gsw-core.txt', 'gsw-core #339'),
     ('names-gsw-security.txt', 'gsw-sec #338'), ('names-pairing-standard.txt', 'pairing std #331')]
for f, g in G:
    for n in names(f): chk(g, n, STD, [])
for n in names('names-pairing-admitted.txt'):
    chk('pairing adm #331', n, SORRY, T24 if n.endswith('.bb1_sidSecure') else [n])
owners = names('owners-prev15.txt') + names('owners-341.txt')
EXP = {'TCSlib.Cryptography.AdvancedEncryption.IdentityBased.BonehBoyenMachine': [IB + 'exists_bb1_distinguisher'],
       'TCSlib.Cryptography.AdvancedEncryption.IdentityBased.BonehBoyenSecurity': T24}
got = {m: [x for x in re.sub(r'\s+', '', l).split(',') if x] for m, s, c, k, l in own}
orows = []
for o in owners:
    ok = o in got and sorted(got[o]) == sorted(EXP.get(o, []))
    if not ok: bad.append('OWNER ' + o)
    orows.append(f"{'OK ' if ok else 'BAD'} OWNER {o}: direct sorryAx {got.get(o, 'MISSING')} (expected {EXP.get(o, [])})")
eof = 'OWNERCLOSURE-EOF' in t
with open(out, 'w') as o:
    for r in rows: o.write(r + '\n')
    for m, s, c, k, l in own: o.write(f"OWNERCLOSURE {m}: stored {s}; union closure {c}; direct sorryAx {k}: {[x for x in re.sub(r'\s+', '', l).split(',') if x]}\n")
    for r in orows: o.write(r + '\n')
    o.write(f"names {len(rows)} ({', '.join(f'{g} {len(names(f))}' for f, g in G)}, pairing admitted {len(names('names-pairing-admitted.txt'))}); "
            f"parsed axioms {len(ax)}, admitted {len(adm)}, ownerclosure {len(own)} of {len(owners)}, EOF {eof}; failing {bad}\n")
    o.write('RESULT ' + ('OK' if not bad and eof and len(rows) == len(ax) == len(adm) and len(own) == len(owners) else 'FAIL') + '\n')
print(open(out).read().splitlines()[-2]); print(open(out).read().splitlines()[-1])
