r"""namecheck.py (int-x-327-324-333, new) <repo> <out> <label=base..head>... -- <rev>...
Declaration names by decls2.py's parser (gate 07 R2-03; its decls() is copied verbatim below, unmodified): for each
label, the full names ADDED between base and head over the TCSlib/audits .lean files the PR changes; then the pairwise
intersections of the added-name sets (full name and last component). For each <rev>, every full name declared in more than
one file (a duplicate declaration would also fail the root TCSlib import)."""
import sys, re, subprocess
from itertools import combinations
KW = r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)'
def strip(src):
    src = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), src, flags=re.S)
    return re.sub(r'--[^\n]*', '', src)
def decls(src):
    lines = strip(src).split('\n')
    out, ns, i = {}, [], 0
    while i < len(lines):
        l = lines[i]
        m = re.match(r'^namespace\s+(\S+)', l)
        if m: ns.append(m.group(1)); i += 1; continue
        m = re.match(r'^end\s+(\S+)\s*$', l)
        if m and ns and ns[-1] == m.group(1): ns.pop(); i += 1; continue
        m = re.match(r'^(@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec)\s+)*' + KW +
                     r'\s+([^\s(:{\[]+)', l)
        if m and not re.search(r'\bprivate\b', l.split(m.group(3))[0]):
            name = m.group(4)
            full = name[len('_root_.'):] if name.startswith('_root_.') else '.'.join(ns + [name])
            def cut(t):
                d = 0
                for k, ch in enumerate(t):
                    if ch in '([{⟨': d += 1
                    elif ch in ')]}⟩': d -= 1
                    elif d == 0 and t.startswith(':=', k): return t[:k]
                    elif d == 0 and re.match(r'\bwhere\b', t[k:]) and (k == 0 or not t[k-1].isalnum()):
                        return t[:k]
                return None
            j, buf = i, []
            while j < len(lines):
                buf.append(lines[j])
                c = cut(' '.join(buf))
                if c is not None or (j > i and lines[j+1:j+2] and re.match(r'^\s*\|[^|\n]*=>', lines[j+1])
                                     and not re.search(r'\bmatch\b', ' '.join(buf))):
                    break
                j += 1
            t = ' '.join(buf)
            c = cut(t)
            t = c if c is not None else t
            t = re.sub(r'^@\[[^\]]*\]\s*', '', t.strip())
            out[full] = (m.group(3), i + 1, re.sub(r'\s+', ' ', t).strip())
            i = j + 1; continue
        i += 1
    return out
repo, out = sys.argv[1:3]; i = sys.argv.index('--'); prs = sys.argv[3:i]; revs = sys.argv[i + 1:]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True).stdout
show = lambda r, f: git('show', f'{r}:{f}')
o = open(out, 'w'); added = {}
for p in prs:
    lab, rng = p.split('='); b, h = rng.split('..')
    fs = [f for f in git('diff', '--name-only', b, h, '--', 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
    s = {}
    for f in fs:
        old = show(b, f); new = show(h, f)
        a, n = decls(old) if old else {}, decls(new) if new else {}
        for k in n:
            if k not in a: s[k] = f
    added[lab] = s; o.write(f'{lab} {b[:8]}..{h[:8]}: {len(fs)} files, {len(s)} added names\n')
    for k in sorted(s): o.write(f'  ADDED {lab} {k} {s[k]}\n')
for x, y in combinations(added, 2):
    full = sorted(set(added[x]) & set(added[y]))
    short = sorted({k.split('.')[-1] for k in added[x]} & {k.split('.')[-1] for k in added[y]})
    o.write(f'INTERSECT {x} {y}: full {len(full)} {full}; last-component {len(short)} {short}\n')
for r in revs:
    fs = [f for f in git('ls-tree', '-r', '--name-only', r, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
    where = {}
    for f in fs:
        for k in decls(show(r, f)): where.setdefault(k, []).append(f)
    dup = {k: v for k, v in where.items() if len(v) > 1}
    o.write(f'REV {r[:8]}: {len(fs)} files, {len(where)} names, declared in >1 file: {len(dup)}\n')
    for k in sorted(dup): o.write(f'  DUP {k} {dup[k]}\n')
o.close(); print(''.join(l for l in open(out) if not l.startswith('  ')))
