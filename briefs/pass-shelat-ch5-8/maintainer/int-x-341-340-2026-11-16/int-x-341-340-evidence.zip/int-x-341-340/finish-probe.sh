#!/usr/bin/env bash
# int-x-341-340 axioms probe at B (after finish-post-build.sh; before the seals and the restore). One Lean process (runner_full.py:
# lean -DmaxErrors=0, no -o, nothing written to the tree). The probe source is placed in the worktree and removed afterwards.
# int-x-331-339-338's finish-probe-c.sh with the probe AxiomsX41 (tools-used/mkprobe41.py) and the summary axsum41.py.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-341-340; W=$SP/wt-int-x341; TR=$SP/dl-oleans
cd $E
rm -rf $W/IntProbe; mkdir -p $W/IntProbe; cp axioms/AxiomsX41.lean.txt $W/IntProbe/AxiomsX41.lean; echo IntProbe/AxiomsX41 > axioms/probe-order.txt
(cd $W && sha256sum IntProbe/AxiomsX41.lean && git status --short --untracked-files=all) > axioms/probe-files-in-worktree.txt
export PATH=$HOME/.elan/bin:$PATH
python3 -I tools-used/runner_full.py $W axioms/probe-order.txt $TR axioms/probe-B
echo "runner_full exit $?" > axioms/probe-B/runner-exit.txt
rm -r $W/IntProbe; (cd $W && echo "after removal: $(git status --short --untracked-files=all | wc -l) status lines") >> axioms/probe-files-in-worktree.txt
python3 -I tools-used/axsum41.py axioms/probe-B/mods/IntProbe_AxiomsX41.log axioms axioms/axioms-summary.txt
