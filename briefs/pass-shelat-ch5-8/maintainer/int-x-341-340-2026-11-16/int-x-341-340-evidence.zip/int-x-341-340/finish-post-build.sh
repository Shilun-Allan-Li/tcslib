#!/usr/bin/env bash
# int-x-341-340 post-build steps (after build-b/runner-rc.txt exists; before the probe, the seals and the restore). No Lean process.
# int-x-331-339-338's finish-post-build.sh with this job's revisions, record sets and references.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/int-x-341-340; R=/home/user/tcslib; TR=$SP/dl-oleans
B=ac6f0a1c8b8fb8a80c9c87c5524bad5ec70769db; T=ee11f2a69deb4baf1491437f41098b393149bb2b
cd $E
python3 -I tools-used/permod.py build-b build-b/per-module.tsv > build-b/permod.out; cat build-b/permod.out
python3 -I tools-used/review/buildsum.py build-b/results.jsonl > build-b/buildsum.txt; head -1 build-b/buildsum.txt
cp state/state.json state/state-before-b.json
python3 -I tools-used/stateplan.py update $R $B state/state.json build-b/results.jsonl $TR | tee build-b/state-update.out
cp state/state.json state/state-after-b.json
python3 -I tools-used/stateplan.py check $R $B order-b/order.txt state/state.json $TR build-b/statecheck.txt
mkdir -p records tree-final admissions
cat state/base-records-from-int-317.jsonl build-b/results.jsonl > records/records-final.jsonl
python3 -I tools-used/treecheck_ml.py $TR order-b/order.txt records/records-final.jsonl $R $B tree-final/snapshot-B.txt > tree-final/tree-check-B.txt; cat tree-final/tree-check-B.txt
echo "zero-byte files under the tree: $(find $TR -type f -size 0 | wc -l)" | tee tree-final/zero-byte-files.txt; find $TR -type f -size 0 >> tree-final/zero-byte-files.txt
RS="base=state/base-records-from-int-317.jsonl int331=state/int331-records-final.jsonl x1=refs/int-x-327-324-333-build-x1-results.jsonl x3=refs/int-x-331-339-338-build-x-results.jsonl"
python3 -I tools-used/tipcensus.py $R $T admissions/census-T-ee11f2a6-all.txt $RS b=build-b/results.jsonl
python3 -I tools-used/tipcensus.py $R $B admissions/census-B-ac6f0a1c.txt $RS b=build-b/results.jsonl
diff <(grep -v TOTAL admissions/census-T-ee11f2a6-all.txt | sed 's/  \[.*//') <(grep -v TOTAL admissions/census-B-ac6f0a1c.txt | sed 's/  \[.*//') > admissions/census-T-vs-B.diff; grep -v '^.  0 ' admissions/census-T-vs-B.diff | head -60
REFS="x3=refs/int-x-331-339-338-build-x-results.jsonl x3final=refs/int-x-331-339-338-records-final.jsonl sctip-m=refs/sc-yao-int-tip-build-m-results.jsonl sctip-mprime=refs/sc-yao-int-tip-mprime-build-results.jsonl pbdh=refs/pair-bdh-inhouse-build-results.jsonl pbdh-dev=refs/pair-bdh-inhouse-dev-build-results.jsonl x1=refs/int-x-327-324-333-build-x1-results.jsonl int331tip=refs/int-331-tip-build-results.jsonl g40m=refs/gate40-seals-merged-build-results.jsonl gswcore=refs/gsw-core-r1-build-results.jsonl gswsec=refs/gsw-security-r1-build-results.jsonl g39-final-b=refs/g39-records-final-b.jsonl int331-records-final=state/int331-records-final.jsonl base=state/base-records-from-int-317.jsonl"
python3 -I tools-used/refunion2.py build-b/results.jsonl build-b/refunion $REFS > build-b/refunion.txt; tail -3 build-b/refunion.txt
python3 -I tools-used/logcheck.py build-b/results.jsonl build-b/logcheck.txt $REFS; tail -2 build-b/logcheck.txt
