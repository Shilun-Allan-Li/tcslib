"""Pin the stretch relocation and invalidate every transitive consumer."""

from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:])
tools = area.parent / "cleanup-incremental-20261108/tools"
previous = area.parent / "next-bit-split-20261109/native"
records = campaign / "briefs/pass-shelat-ch5-8/maintainer"
out = area / "native-r2"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location("checked_import_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
base = (area / "base.txt").read_text().strip()
head = (area / "head.txt").read_text().strip()
crypto = "TCSlib/Cryptography"
asym = crypto + "/Asymptotic"
facade = crypto + "/Pseudorandom"
prg = facade + "/Generators/Asymptotic"
stretch = prg + "/Stretch"
machine = prg + "/StretchMachine"
support = asym + "/ReductionSupport"
checks = "audits/pass-shelat/Checks"
new_modules = {stretch, machine, support}
changed = new_modules | {facade, asym, prg + "/Defs"} | {
    asym + "/" + name for name in ("HardCore", "HardCoreLemmas", "HardCorePermutation", "PRF", "PRFLemmas")
}


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def git_text(*args):
    return git(*args).decode().strip()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


def write(path, obj):
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2)
        stream.write("\n")


assert git_text("rev-parse", "HEAD") == head and git_text("rev-parse", "HEAD^") == base
assert not git_text("status", "--porcelain")
assert set(git_text("diff", "--name-only", base, head).splitlines()) == {
    module + ".lean" for module in changed
}
old_plan = read(previous / "PLAN.json")
old_products = read(previous / "PRODUCTS.json")
verified = read(records / "next-bit-split-2026-11-09/VERIFICATION.json")
result = read(previous / "RESULT.json")
assert verified["passed"] and result["passed"]
assert verified["head"] == old_plan["head"] == result["head"]
for name in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / name) == verified["artifact_sha256"]["native/" + name], name
assert not git_text("diff", "--name-only", old_plan["head"], base, "--", "*.lean",
                "lean-toolchain", "lake-manifest.json", "lakefile.lean",
                "lakefile.toml", "scripts/lean_check_tree.sh")
assert sha(Path(old_plan["toolchain"])) == old_plan["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == old_plan["checker_sha256"]

sources = {
    path[:-5]: (root / path).read_bytes()
    for path in git_text("ls-files", "--", "TCSlib", "TCSlib.lean", checks + ".lean").splitlines()
    if path.endswith(".lean")
}
assert set(sources) == set(old_plan["source_digests"]) | new_modules
source_digests = {module: sha256(raw).hexdigest() for module, raw in sources.items()}
for module in sources.keys() - changed:
    assert source_digests[module] == old_plan["source_digests"][module], module
imports = {
    module: [name.replace(".", "/") for name in graph.imports(raw)
             if name.replace(".", "/") in sources]
    for module, raw in sources.items()
}
assert imports[stretch] == [prg + "/Defs", machine]
assert imports[machine] == ["TCSlib/Complexity/Randomized/Repetition", support]
assert imports[support] == ["TCSlib/Complexity/Randomized/Closure", asym + "/Adversary",
                           crypto + "/Foundations/Negligible", crypto + "/OneWayFunctions/Basic",
                           facade + "/Generators"]
added_edges = {
    facade: {stretch, machine}, asym: {support}, asym + "/HardCore": {stretch},
    asym + "/HardCoreLemmas": {machine}, asym + "/PRF": {stretch},
    asym + "/PRFLemmas": set(), asym + "/HardCorePermutation": set(), prg + "/Defs": set(),
}
assert set(added_edges) == changed - new_modules
for module, added in added_edges.items():
    assert [dep for dep in imports[module] if dep not in added] == old_plan["graph"][module]
    assert all(imports[module].count(dep) == 1 for dep in added)
for module in old_plan["graph"].keys() - changed:
    assert imports[module] == old_plan["graph"][module], module
order = graph.topo(imports, ["TCSlib", checks])
assert set(order) == set(old_plan["order"]) | new_modules
def closure(module):
    return set(graph.topo(imports, [module])) - {module}
stretch_closure = closure(stretch)
assert not any(module.startswith(tuple(asym + "/" + name for name in ("HardCore", "PRF", "GGM")))
               or module.startswith(facade + "/Functions") for module in stretch_closure)
affected = changed.copy()
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
assert {"TCSlib", checks, facade, stretch, machine, support} <= affected
rebuild = [module for module in order if module in affected]
assert len(rebuild) == 77
old_tree = Path(old_plan["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
draft = area / "native"
draft_plan = read(draft / "PLAN.json")
assert draft_plan["base"] == base and draft_plan["head"] == (area / "head-r1.txt").read_text().strip()
draft_products = {}
for path in sorted(draft.glob("run-*/check-*.json")):
    row = read(path)
    assert row["head"] == draft_plan["head"] and sha(path.with_suffix(".log")) == row["log_sha256"]
    if row["rc"] == 0:
        draft_products[row["module"]] = row
assert len(draft_products) == 16
for module in order:
    if module in affected:
        if module not in draft_products:
            continue
        row = draft_products[module]
        direct = {dep: retained[dep]["object_sha256"] for dep in imports[module]}
        assert source_digests[module] == row["source_sha256"] and direct == row["direct_local"], module
        copy(Path(draft_plan["tree"]) / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
        retained[module] = {**row, "source": "prior_attempt_same_source_and_inputs"}
        continue
    row = old_products[module]
    direct = {dep: retained[dep]["object_sha256"] for dep in imports[module]}
    assert source_digests[module] == row["source_sha256"] and direct == row["direct_local"], module
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {"source_sha256": row["source_sha256"], "object_sha256": row["object_sha256"],
                        "direct_local": direct, "source": "verified_next_bit_tree"}
external = {}
for name, row in old_plan["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        target = tree / path.relative_to(old_tree)
        copy(path, target, row["sha256"])
        path = target
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": old_plan["head"],
    "worktree": str(root), "tree": str(tree),
    "toolchain": old_plan["toolchain"], "toolchain_sha256": old_plan["toolchain_sha256"],
    "checker_sha256": old_plan["checker_sha256"], "affected": sorted(affected), "rebuild": [module for module in rebuild if module not in retained],
    "verified_prefix": sorted(draft_products),
    "order": order, "retained": retained, "graph": {module: imports[module] for module in order},
    "external": external, "source_digests": source_digests,
}
write(out / "PLAN.json", plan)
write(area / "SOURCE-CHECK-R2.json", {
    "base": base, "head": head, "new_owners": sorted(new_modules),
    "changed_paths": sorted(changed), "consumers_rechecked": len(rebuild),
    "stretch_import_closure": sorted(stretch_closure),
    "unchanged_lean_paths": len(sources) - len(changed), "verified_external_objects": len(external),
    "predecessor_verification_sha256": sha(records / "next-bit-split-2026-11-09/VERIFICATION.json"),
})
print(f"{len(retained)} retained objects, {len(external)} external objects, "
      f"{len(draft_products)} unchanged affected checks verified and {len(plan['rebuild'])} fresh checks", flush=True)
