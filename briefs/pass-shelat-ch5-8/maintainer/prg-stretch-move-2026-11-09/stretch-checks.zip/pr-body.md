## Changes

- Put one-bit generators, polynomial stretch extension, truncation, and doubling in `Pseudorandom.Generators.Asymptotic.Stretch`. The `prg_expand` theorem combines the finite hybrid bound with the polynomial-time evaluator and reduction.
- Put the evaluator, hybrid distinguisher machine, and their run agreements in `Pseudorandom.Generators.Asymptotic.StretchMachine`.
- Extract the existing machine wrapper, preprocessing, and string lemmas into `Asymptotic.ReductionSupport`, which both the stretch and hard-core proofs can import. The stretch import graph is independent of the asymptotic hard-core construction and GGM.
- Preserve the legacy imports and Lean names. The permutation proof uses the published expansion equations, and three hard-core proofs transport coins through the wrapper's field equation. Lean checks the constructor for `owpGenPRG` against its original body by definitional equality. The permutation file reuses the shared version of its former private list lemma.

## Verification

All 77 affected modules are covered, including the library root and campaign Checks. The final commit has 52 fresh checks and 25 verified transfers with identical sources and dependency objects. The legacy and standalone imports give the same checked API. The declaration comparison confirms the types and axiom dependencies, with a separate compatibility check for generated equations.

The whole-file seals match all 14 remaining diagnostics to existing proof steps. Five move to `Stretch` and four other baseline diagnostics are resolved by the reader changes. The sensitivity control fails at the intended `rfl` step and passes through the published field equation under the same mask. The source and proof-term scans report zero foreign-definition unfolds or generated-equation reads in the owner files.

The source style check passes. The campaign linter produces two extra facade reports because it treats the finite `Generators.lean` as the facade for its same-named directory. `Pseudorandom.lean` directly exports both new stretch modules. The set of existing reader warnings is the same.
