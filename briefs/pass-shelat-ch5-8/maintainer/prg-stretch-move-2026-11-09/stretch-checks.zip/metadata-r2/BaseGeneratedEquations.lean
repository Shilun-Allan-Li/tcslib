import TCSlib.Cryptography.Asymptotic.PRF

open TCSlib.Cryptography

#check @PRG.oneBit.eq_1
#check @oneBitStep.eq_1

example (P : PermFamily) (h : ∀ n, (Fin n → Bool) → Bool) :
    owpGenPRG P h = PRG.oneBit (fun n s => Fin.snoc (P.f n s) (h n s)) :=
  owpGenPRG.eq_1 P h
