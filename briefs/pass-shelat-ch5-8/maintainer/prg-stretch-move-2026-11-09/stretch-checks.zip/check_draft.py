"""Compile the changed modules and affected prerequisites in a draft tree."""

from hashlib import file_digest, sha256
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
run = area / sys.argv[4]
tree = run / "oleans"
previous = area.parent / "next-bit-split-20261109/native"
record = campaign / "briefs/pass-shelat-ch5-8/maintainer/next-bit-split-2026-11-09/VERIFICATION.json"
tools = area.parent / "cleanup-incremental-20261108/tools"
spec = importlib.util.spec_from_file_location("checked_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


base = (area / "base.txt").read_text().strip()
previous_plan = read(previous / "PLAN.json")
result = read(previous / "RESULT.json")
verified = read(record)
assert verified["passed"] and result["passed"]
assert verified["head"] == previous_plan["head"] == result["head"]
for name in ("PLAN.json", "RESULT.json", "PRODUCTS.json"):
    assert sha(previous / name) == verified["artifact_sha256"]["native/" + name]
assert not git("diff", "--name-only", previous_plan["head"], base, "--", "*.lean",
               "lean-toolchain", "lake-manifest.json", "scripts/lean_check_tree.sh")
before = read(previous / "PRODUCTS.json")
all_paths = set(git("ls-files", "--", "TCSlib", "TCSlib.lean", "audits/pass-shelat/Checks.lean").splitlines())
all_paths.update(git("ls-files", "--others", "--exclude-standard", "--", "TCSlib").splitlines())
sources = {path[:-5]: (root / path).read_bytes() for path in all_paths if path.endswith(".lean")}
hashes = {name: sha256(source).hexdigest() for name, source in sources.items()}
changed = {name for name, digest in hashes.items() if previous_plan["source_digests"].get(name) != digest}
imports = {module: [name.replace(".", "/") for name in graph.imports(raw)
                    if name.replace(".", "/") in sources] for module, raw in sources.items()}
order = graph.topo(imports, ["TCSlib", "audits/pass-shelat/Checks"])
affected = set(changed)
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
needed = graph.topo(imports, [module for module in order if module in changed])
rebuild = [module for module in needed if module in affected]
run.mkdir()
tree.mkdir()
old_tree = Path(previous_plan["tree"])
assert not (root / ".lake/build/lib/lean").exists()
assert sha(Path(previous_plan["toolchain"])) == previous_plan["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == previous_plan["checker_sha256"]
for module in needed:
    if module not in affected:
        row = before[module]
        assert row["source_sha256"] == hashes[module]
        copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
for row in previous_plan["external"].values():
    path = Path(row["path"])
    if path.is_relative_to(old_tree):
        copy(path, tree / path.relative_to(old_tree), row["sha256"])
    else:
        assert sha(path) == row["sha256"], path
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
print(f"{len(rebuild)} draft checks, {len(affected)} modules in the full affected replay", flush=True)

env = os.environ.copy()
for name in ("LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LEAN_OPTS", "ELAN_TOOLCHAIN", "PFR_BOOTSTRAP_CONFIG"):
    env.pop(name, None)
env["PATH"] = str(Path(previous_plan["toolchain"]).parent) + ":/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
env["TCSLIB_OLEANS"] = str(tree)
rows = {}
for module in needed:
    if module not in affected:
        rows[module] = before[module]
        continue
    path = root / (module + ".lean")
    assert sha(path) == hashes[module]
    log = run / (module.replace("/", "__") + ".log")
    with log.open("x") as stream:
        rc = subprocess.run(["bash", "scripts/lean_check_tree.sh", module], cwd=root,
                            env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
    if rc:
        print(log.read_text()[-6500:])
        sys.exit(rc)
    rows[module] = {"source_sha256": sha(path), "object_sha256": sha(tree / (module + ".olean")),
                    "direct_local": {dep: rows[dep]["object_sha256"] for dep in imports[module]},
                    "log_sha256": sha(log)}
    print(f"PASS {module}", flush=True)
(run / "RECEIPT.json").write_text(json.dumps({
    "base": base, "tree": str(tree), "rebuild": rebuild, "affected": sorted(affected),
    "graph": {module: imports[module] for module in needed},
    "products": rows,
}, indent=2) + "\n")
