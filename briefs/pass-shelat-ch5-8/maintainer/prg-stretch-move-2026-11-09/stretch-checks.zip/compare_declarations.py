"""Compare the native declaration catalogs for the stretch move."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
base_meta = area / "metadata-r2"
head_meta = area / "metadata-r3"
prefix = "TCSlib.Cryptography."
asym = prefix + "Asymptotic."
standard = {"propext", "Classical.choice", "Quot.sound"}
hygiene = ("str", "_@")
removed_duplicate = "_private." + asym + "HardCorePermutation.0." + prefix + "take_ofFn_castLE"
constructor_equation = prefix + "owpGenPRG.eq_1"
old_simproc = prefix + "invProbOpt_glPad_le._simp_1_1"
new_simproc = prefix + "invProbOpt_glPad_le._simp_1_3"
lazy_eqns = {prefix + name + ".eq_1" for name in ("PRG.oneBit", "oneBitStep")}
new_eqns = {prefix + name + ".eq_1" for name in ("glPadCollInvMachine", "glPadInvMachine", "owpPredMachine")}


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def decls(label):
    rows = [json.loads(line) for line in ((base_meta if label == "Base" else head_meta) / (label + ".jsonl")).open()]
    last = rows.pop()
    assert last["record"] == "complete"
    owners = {item["display"] for item in last["owners"]}
    assert sum(row["record"] == "catalog" for row in rows) == last["catalog"]
    result = {row["name"]["display"]: row for row in rows if row["record"] == "constant"}
    assert len(result) == last["count"] == 470
    for name, row in result.items():
        assert row["home"]["display"] in owners, name
        assert {item["display"] for item in row["axioms"]} <= standard, name
    return result


def canonical(expr, mapping, alpha=False):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, () if alpha else label, *[canonical(part, mapping, alpha) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, mapping.get(name, name), *[canonical(part, mapping, alpha) for part in expr[2:]]]
    return [canonical(part, mapping, alpha) for part in expr]


base, head = decls("Base"), decls("Head")
assert base.keys() - head.keys() == lazy_eqns | {removed_duplicate, old_simproc}
assert head.keys() - base.keys() == new_eqns | {new_simproc}
pairs = {name: name for name in base.keys() & head.keys()}
pairs[old_simproc] = new_simproc
pairs[removed_duplicate] = prefix + "take_ofFn_castLE"
renamed = {key(base[a]["name"]): key(head[b]["name"]) for a, b in pairs.items() if a != b}
rows = []
errors = []
for name, target in sorted(pairs.items()):
    a, b = base[name], head[target]
    alpha = name == removed_duplicate
    for field in ("kind", "status", "abbrev", "instance", "matcher", "levels"):
        if a[field] != b[field]:
            errors.append((name, field, a[field], b[field]))
    if {key(item) for item in a["axioms"]} != {key(item) for item in b["axioms"]}:
        errors.append((name, "axioms"))
    if canonical(a["type"], renamed, alpha) != canonical(b["type"], {}, alpha):
        errors.append((name, "type"))
    type_refs = {renamed.get(key(ref), key(ref)) for ref in a["type_refs"]}
    if type_refs != {key(ref) for ref in b["type_refs"]}:
        errors.append((name, "type_refs"))
    values_match = canonical(a["definition_value"], renamed) == canonical(b["definition_value"], {})
    if a["kind"] == "def" and not values_match:
        print("Definition value differs:", name)
    rows.append({
        "old_name": name, "new_name": target, "old_home": a["home"]["display"],
        "new_home": b["home"]["display"], "kind": a["kind"],
        "definition_value_matches": values_match if a["kind"] == "def" else None,
        "axioms": sorted(item["display"] for item in b["axioms"]),
    })
assert errors == [(constructor_equation, "type"), (constructor_equation, "type_refs")], errors
assert (base_meta / "BaseGeneratedEquations.rc").read_text().strip() == "0"
assert (head_meta / "HeadGeneratedEquations.rc").read_text().strip() == "0"
assert (base_meta / "BaseGeneratedEquations.log").read_bytes() == (head_meta / "HeadGeneratedEquations.log").read_bytes()
print("The generated constructor equation accepts the original type and both lazy equations resolve with the same types.")
moved = Counter((row["old_home"], row["new_home"]) for row in rows if row["old_home"] != row["new_home"])
print("Moves:", dict(moved))
assert (head_meta / "LegacyImport.log").read_bytes() == (head_meta / "StretchImport.log").read_bytes()
assert (base_meta / "BaseCensus.rc").read_text().strip() == "0"
assert all((head_meta / (name + ".rc")).read_text().strip() == "0"
           for name in ("HeadCensus", "LegacyImport", "StretchImport", "PermutationDefinitionProbe"))
values_differ = [row["old_name"] for row in rows if row["definition_value_matches"] is False]
print("Matched", len(rows), "materialized declarations, with", sum(moved.values()), "owner changes")
print("Definition differences:", values_differ)
assert values_differ == [prefix + "owpGenPRG"]
result = {
    "base_declarations": len(base), "head_declarations": len(head), "matched_declarations": len(rows),
    "owner_changes_including_private_reuse": sum(moved.values()),
    "materialized_declarations_moved_to_new_owners": sum(
        row["old_name"] != removed_duplicate and row["old_home"] != row["new_home"]
        and row["new_home"].endswith((".Stretch", ".StretchMachine", ".ReductionSupport"))
        for row in rows),
    "generated_congruence_theorem_new_home": asym + "HardCoreLemmas",
    "definitionally_equal_generated_equation_type": constructor_equation,
    "type_comparison": "kernel syntax with binder hygiene normalized, alpha comparison for the duplicate private lemma",
    "same_legacy_and_stretch_exports": True, "definition_values_definitional_equality_checked": values_differ,
    "removed_private_duplicate": removed_duplicate, "private_duplicate_replaced_by": pairs[removed_duplicate],
    "on_demand_base_equations": sorted(lazy_eqns), "newly_materialized_equations": sorted(new_eqns),
    "generated_proof_renames": {old_simproc: new_simproc},
    "catalog_sha256": {"Base": sha(base_meta / "Base.jsonl"), "Head": sha(head_meta / "Head.jsonl")},
    "generated_equation_check_sha256": {"Base": sha(base_meta / "BaseGeneratedEquations.log"),
                                         "Head": sha(head_meta / "HeadGeneratedEquations.log")},
    "declarations": rows,
}
(area / "DECLARATIONS.json").write_text(json.dumps(result, indent=2) + "\n")
