import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch

open TCSlib.Cryptography Complexity

example (G : ∀ n, (Fin n → Bool) → (Fin (n + 1) → Bool))
    (ℓ : PolyExpr) (h : ∀ n, n < ℓ.eval n) : (PRG.expand G ℓ h).stretch = ℓ :=
  rfl
