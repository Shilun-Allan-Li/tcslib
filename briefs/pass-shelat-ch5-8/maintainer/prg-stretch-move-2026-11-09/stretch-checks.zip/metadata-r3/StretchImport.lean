import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch

#check TCSlib.Cryptography.PRG.oneBit
#check TCSlib.Cryptography.PRG.expand
#check TCSlib.Cryptography.prg_expand
#check TCSlib.Cryptography.PRG.Secure.doubling
#check TCSlib.Cryptography.exists_expandEvaluator
#check TCSlib.Cryptography.expandRedMachine_distinguisher
#check TCSlib.Cryptography.PRG.Secure.truncateTo_negligible
