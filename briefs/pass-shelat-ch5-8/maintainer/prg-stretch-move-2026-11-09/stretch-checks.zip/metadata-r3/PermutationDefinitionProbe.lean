import TCSlib.Cryptography.Asymptotic.HardCore

open TCSlib.Cryptography

example (P : PermFamily) (h : ∀ n, (Fin n → Bool) → Bool) :
    owpGenPRG P h = PRG.oneBit (fun n s => Fin.snoc (P.f n s) (h n s)) :=
  rfl
