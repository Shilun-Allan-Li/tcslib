"""Move the PRG stretch and reusable reduction support to their owners."""

from pathlib import Path

crypto = Path("TCSlib/Cryptography")
asym = crypto / "Asymptotic"
prg = crypto / "Pseudorandom/Generators/Asymptotic"
hard, helpers, prf, prf_helpers = (asym / (name + ".lean") for name in
                                  ("HardCore", "HardCoreLemmas", "PRF", "PRFLemmas"))
support = asym / "ReductionSupport.lean"
stretch, machine = prg / "Stretch.lean", prg / "StretchMachine.lean"
old = {file: file.read_text().splitlines(keepends=True) for file in (hard, helpers, prf, prf_helpers)}
assert [len(old[p]) for p in (hard, helpers, prf, prf_helpers)] == [939, 1056, 900, 439]
assert not any(path.exists() for path in (support, stretch, machine))
tick = chr(96)


def span(path, start, end):
    return "".join(old[path][start - 1:end])


def replace(text, before, after, count=1):
    assert text.count(before) == count, before
    return text.replace(before, after)


def file(imports, doc, body):
    return (span(hard, 1, 5) + "".join(f"import {module}\n" for module in imports) +
            "\nset_option maxHeartbeats 0\nset_option relaxedAutoImplicit false\n"
            "set_option autoImplicit false\n\n/-!\n" + doc.rstrip() + "\n-/\n\n" + body.rstrip() + "\n")


support_doc = """# Shared support for polynomial-time reductions

The one-call wrapper and the parameter-aware pre-processor expose their typed
coin conversions and run equations. The bit-string identities, uniform coin
reindexing, polynomial-time cuts, and negligible bounds support multiple reductions.

## Main definitions

* `Complexity.NUPPT.wrap` is a one-call reduction with pre- and post-processing.
* `Complexity.NUPPT.preComp` lets pre-processing inspect the security parameter.
* `TCSlib.Cryptography.finCastEquiv` transports bit strings along a length equality.

## Main results

* `Complexity.NUPPT.runAt_wrap` and `Complexity.NUPPT.runAt_preComp` give the
  typed run equations.
* `TCSlib.Cryptography.prgAdv_coins_equiv` reindexes uniform coins.
* `TCSlib.Cryptography.Negligible.polyExpr_mul` bounds multiplication by a
  syntactic polynomial.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.3.4, §3.3.5, §3.4.2, and §3.8.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §1.2 and Chapter 3."""
machine_doc = """# Machines for PRG stretch extension

The evaluator iterates a string implementation of the one-bit generator and emits
one bit at each round. The reduction machine constructs the hybrid string from
its input and random coins, then calls the given distinguisher once
[PS10, Lemma 80.5].

## Main definitions

* `TCSlib.Cryptography.prgIterFun` is the iterated string evaluator.
* `TCSlib.Cryptography.expandRedPre` forms a hybrid string.
* `TCSlib.Cryptography.expandRedMachine` runs the distinguisher on that string.

## Main results

* `TCSlib.Cryptography.exists_expandEvaluator` gives a polynomial-time evaluator
  and its agreement with the typed expansion.
* `TCSlib.Cryptography.expandRedMachine_distinguisher` gives the hybrid machine's
  verdict on split coins.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.3.5, Lemma 80.5.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.3.1, Theorem 3.1."""
stretch_doc = """# Asymptotic PRG stretch extension

Iterating a secure one-bit generator gives a secure generator of any polynomial
output length that exceeds the seed length at every parameter [PS10, Lemma 80.5].
The finite hybrid bound lifts to a non-uniform polynomial-time reduction through
the evaluator and hybrid machine in `StretchMachine`. Truncation to one extra bit,
expansion to `2n + 1` bits, and truncation to `2n` give the length-doubling generator
used by GGM [PS10, proof of Theorem 97.3].

## Main definitions

* `TCSlib.Cryptography.PRG.oneBit` packages the one-bit-stretch generator.
* `TCSlib.Cryptography.PRG.expand` gives the iterated generator.
* `TCSlib.Cryptography.expandRed` gives the finite hybrid reduction.
* `TCSlib.Cryptography.DoublingPRG` gives the security contract for length doubling.

## Main results

* `TCSlib.Cryptography.exists_expandRed_ge` gives the finite advantage bound.
* `TCSlib.Cryptography.prg_expand` proves secure polynomial stretch.
* `TCSlib.Cryptography.PRG.Secure.truncate` and
  `TCSlib.Cryptography.PRG.Secure.doubling` give the secure truncation and doubling results.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.3.5, Lemma 80.5, and §3.8, proof of Theorem 97.3.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.3.1, Theorem 3.1."""
hc_text = span(hard, 1, 279) + span(hard, 307, 453) + span(hard, 625, 939)
hc_text = replace(hc_text, "import TCSlib.Cryptography.OneWayFunctions.OutputLength\n",
    "import TCSlib.Cryptography.OneWayFunctions.OutputLength\n"
    "import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch\n")
hc_text = replace(hc_text,
    "  PRG.oneBit fun n s => Fin.snoc (P.f n s) (h n s)",
    "  { stretch := .add .var (.const 1)\n"
    "    G := fun n s => Fin.snoc (P.f n s) (h n s)\n"
    "    expands := fun n => Nat.lt_succ_self n }")
hc_text = replace(hc_text, "simp [owpGenPRG, PRG.oneBit]", "simp [owpGenPRG]", 2)
hc_text = replace(hc_text, span(hard, 647, 656),
    """  let G := fun (n : ℕ) (s : Fin n → Bool) => Fin.snoc (P.f n s) (h n s)
  let Q := PRG.expand G (.add ℓ (.const 1)) (fun n => Nat.lt_succ_of_le (hℓ n))
  have hlen : Q.stretch = .add ℓ (.const 1) := PRG.expand_stretch _ _ _
  have hclosed (n : ℕ) (s : Fin n → Bool) (i : Fin (Q.stretch.eval n)) :
      Q.G n s i = h n ((⇑(P.f n))^[i] s) := by
    change (PRG.expand G _ _).G n s i = _
    rw [PRG.expand_G_stretch]
    simp only [G, Fin.init_snoc, Fin.snoc_last]
  change P.iterPRG h ℓ hℓ = Q
  generalize Q = R at hlen hclosed ⊢
  cases R with
  | mk len out expands =>
    change len = .add ℓ (.const 1) at hlen
    subst len
    unfold PermFamily.iterPRG
    congr 1
    funext n s i
    exact (hclosed n s i).symm
""")
hc_text = replace(hc_text, "  exact prg_expand _ _ _ (owp_hardcore_prg P h hP hh)\n",
    """  apply prg_expand
  have hgen := owp_hardcore_prg P h hP hh
  rw [PRG.secure_iff, PRG.easy_iff] at hgen
  exact (PRG.oneBit_secure_iff _).2 hgen
""")
hc_text = replace(hc_text,
    "permutation `f` with hard-core predicate `h` [PS10, Theorem 79.4]; the expansion of a\n"
    "one-bit-stretch generator to `ℓ(n)` bits [PS10, Lemma 80.5]; the iterated generator",
    "permutation `f` with hard-core predicate `h` [PS10, Theorem 79.4]; the iterated generator")
hc_text = replace(hc_text,
    "text's conventions require (`owpPredictorSnoc`, `oneBitStep`, `expandRed`, `prgAdv_fst`) and",
    "text's conventions require (`owpPredictorSnoc`) and")
hc_text = replace(hc_text,
    "* `TCSlib.Cryptography.PRG.oneBit`, `TCSlib.Cryptography.owpGenPRG` — the one-bit-stretch",
    "* `TCSlib.Cryptography.owpGenPRG` — the one-bit-stretch")
hc_text = replace(hc_text,
    "* `TCSlib.Cryptography.oneBitStep`, `TCSlib.Cryptography.PRG.expand`,\n"
    "  `TCSlib.Cryptography.expandRed` — the expansion `G'` of [PS10, Lemma 80.5] and its reduction.\n",
    "")
hc_text = replace(hc_text,
    "* `TCSlib.Cryptography.prg_expand` [PS10, Lemma 80.5]; `TCSlib.Cryptography.exists_expandRed_ge`\n"
    "  (concrete, proved).\n* `TCSlib.Cryptography.cor_81_7` [PS10, Corollary 81.7] (proved from the two above and the\n"
    "  closed form `PermFamily.iterPRG_eq_expand`).",
    "* `TCSlib.Cryptography.cor_81_7` [PS10, Corollary 81.7] combines Theorem 79.4 with\n"
    "  `prg_expand` from `Pseudorandom.Generators.Asymptotic.Stretch` through the closed form\n"
    "  `PermFamily.iterPRG_eq_expand`.")
hc_text = replace(hc_text,
    "* `TCSlib.Cryptography.hardCore_iff`, `PRG.oneBit_stretch`, `PRG.oneBit_G`,\n"
    "  `owpPredictorSnoc_eq`, `oneBitStep_eq`, `expandRed_eq` — the unfoldings of the definitions\n"
    "  of this file (gate 03c, finding 11).",
    "* `TCSlib.Cryptography.hardCore_iff` and `owpPredictorSnoc_eq` give the defining equations.")

helpers_doc = """# Machine reductions for hard-core predicates

This file constructs the predictor used for the permutation generator and
the inverters for the Goldreich–Levin padding. The shared wrapper and the stretch
machine are available through the existing import.

## Main definitions

* `TCSlib.Cryptography.owpPredMachine` gives the predictor from a distinguisher.
* `TCSlib.Cryptography.glPadInvMachine` gives the padding inverter.

## Main results

* `TCSlib.Cryptography.owpPredMachine_predictor` identifies the machine's verdict.
* `TCSlib.Cryptography.glPadInvMachine_runAt` gives the padding inverter's run.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.3.4, Theorem 79.4, and §3.4.2–3.4.3, Theorem 87.3.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §2.5 and §3.3."""
prf_helpers_doc = """# Proof infrastructure for the GGM evaluator

The evaluator follows a path in the GGM tree on a string state containing the
current label and the remaining input. The bit-string identities connect this
implementation to the finite GGM construction. The old import also provides
PRG truncation through `Pseudorandom.Generators.Asymptotic.Stretch`.

## Main definitions

* `TCSlib.Cryptography.selHalf` selects a half of the next label.
* `TCSlib.Cryptography.ggmStep` and `TCSlib.Cryptography.ggmEval` run the tree walk.

## Main results

* `TCSlib.Cryptography.ggmEval_poly` and `TCSlib.Cryptography.ggmEval_ofFn` give
  polynomial running time and agreement with the finite evaluator.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§3.8, Theorem 97.3.)
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §3.4.2, Construction 3.3."""
prf_text = span(prf, 1, 481) + span(prf, 598, 900)
prf_text = replace(prf_text,
    "import TCSlib.Cryptography.Pseudorandom.Functions.GGM\n",
    "import TCSlib.Cryptography.Pseudorandom.Functions.GGM\n"
    "import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch\n")
prf_text = replace(prf_text,
    "* `TCSlib.Cryptography.DoublingPRG`, `PRG.truncate`, `PRG.doubling` — length-doubling",
    "* `TCSlib.Cryptography.DoublingPRG`, `PRG.truncate`, `PRG.doubling` from `Stretch` — length-doubling")
prf_text = replace(prf_text,
    "* `TCSlib.Cryptography.PRG.Secure.doubling` — every PRG yields a length-doubling PRG",
    "* `TCSlib.Cryptography.PRG.Secure.doubling` in `Stretch` — every PRG yields a length-doubling PRG")
facade = crypto / "Pseudorandom.lean"
facade_text = facade.read_text()
prefix = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic"
facade_text = replace(facade_text, f"import {prefix}.Defs\n",
                      f"import {prefix}.Defs\nimport {prefix}.StretchMachine\nimport {prefix}.Stretch\n")
facade_text = replace(facade_text, "  contract [PS10, Definition 77.1].\n",
    "  contract [PS10, Definition 77.1].\n"
    "* `Generators.Asymptotic.StretchMachine` implements the evaluator and hybrid reduction.\n"
    "* `Generators.Asymptotic.Stretch` proves secure expansion, truncation, and doubling.\n")
facade_text = replace(facade_text,
    "* **Stretch extension.** In the same module, `TCSlib.Cryptography.prg_expand` lifts",
    "* **Stretch extension.** In\n"
    "  `TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch`,\n"
    "  `TCSlib.Cryptography.prg_expand` lifts")
facade_text = replace(facade_text,
    "  In `TCSlib.Cryptography.Asymptotic.HardCoreLemmas`,\n",
    "  In `TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.StretchMachine`,\n")
facade_text = replace(facade_text,
    "  and supplies length doubling via `TCSlib.Cryptography.PRG.Secure.doubling`.\n",
    "  and uses `TCSlib.Cryptography.PRG.Secure.doubling` from `Stretch`.\n")

defs = prg / "Defs.lean"
defs_text = defs.read_text()
defs_text = replace(defs_text, "`Asymptotic/PRF.lean`",
    "`Pseudorandom.Generators.Asymptotic.Stretch`", 3)
defs_text = replace(defs_text, "`Asymptotic/PRFLemmas.lean`",
    "`Pseudorandom.Generators.Asymptotic.Stretch`")
outputs = {
    support: file(["TCSlib.Complexity.Randomized.Primitives", "TCSlib.Cryptography.Asymptotic.Adversary",
                   "TCSlib.Cryptography.Foundations.Negligible", "TCSlib.Cryptography.Pseudorandom.Generators"],
                  support_doc, span(helpers, 61, 259) + span(helpers, 507, 548) + span(prf_helpers, 71, 78) +
                  "end TCSlib.Cryptography\n\n" + span(prf_helpers, 160, 221)),
    machine: file(["TCSlib.Complexity.Randomized.Repetition", "TCSlib.Cryptography.Asymptotic.ReductionSupport"],
                  machine_doc, span(helpers, 380, 499) + "\n" + span(helpers, 549, 644)),
    stretch: file([prefix + ".Defs", prefix + ".StretchMachine"],
                  stretch_doc, "namespace TCSlib.Cryptography\n\nopen Complexity Turing Finset\n\n"
                  + span(hard, 280, 306) + span(hard, 454, 624) + span(prf_helpers, 227, 297)
                  + span(prf, 482, 597) + "end TCSlib.Cryptography\n"),
    hard: hc_text,
    helpers: file([line.removeprefix("import ").strip() for line in old[helpers] if line.startswith("import ")] +
                  [prefix + ".StretchMachine"], helpers_doc,
                  span(helpers, 229, 232) + span(helpers, 260, 378) + "\n" + span(helpers, 646, 1056)),
    prf: prf_text,
    prf_helpers: file(["TCSlib.Cryptography.Asymptotic.HardCore", "TCSlib.Cryptography.Pseudorandom.Functions.GGM"],
                      prf_helpers_doc, span(prf_helpers, 65, 70) + span(prf_helpers, 79, 157) +
                      span(prf_helpers, 298, 439)),
    facade: facade_text,
    defs: defs_text,
}
for path, text in outputs.items():
    path.write_text("\n".join(line.rstrip() for line in text.splitlines()) + "\n")
