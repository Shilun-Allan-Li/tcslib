"""Collect checked declaration types and imported definitions for the relocation."""

from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area, root = (Path(arg).resolve() for arg in sys.argv[1:3])
draft = area / sys.argv[3]
meta = area / sys.argv[4]
previous = area.parent / "next-bit-split-20261109"
base = previous / "native"
old = "TCSlib.Cryptography.Asymptotic."
prg = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic."
old_owners = [old + name for name in ("HardCore", "HardCoreLemmas", "PRF", "PRFLemmas", "HardCorePermutation")]
new_owners = old_owners + [old + "ReductionSupport", prg + "Stretch", prg + "StretchMachine"]


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


meta.mkdir()
plan = read(base / "PLAN.json")
products = read(base / "PRODUCTS.json")
old_tree = Path(plan["tree"])
baseline = meta / "base/oleans"
base_closure = set()
pending = [(old + name).replace(".", "/") for name in ("PRF", "HardCorePermutation")]
while pending:
    module = pending.pop()
    if module not in base_closure:
        base_closure.add(module)
        pending.extend(plan["graph"][module])
for module in sorted(base_closure):
    row = products[module]
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
    copy(old_tree / (module + ".olean"), baseline / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(old_tree):
        copy(src, baseline / src.relative_to(old_tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
(baseline / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

prefix = (previous / "metadata/BaseCensus.lean").read_text().split("run_cmd do\n", 1)[0]
prefix = prefix.replace("import TCSlib.Cryptography.Asymptotic.NextBit\n",
                        "import TCSlib.Cryptography.Asymptotic.PRF\n"
                        "import TCSlib.Cryptography.Asymptotic.HardCorePermutation\n")
tick = chr(96)
for label, modules in (("Base", old_owners), ("Head", new_owners)):
    owners = ", ".join(tick + name for name in modules)
    program = prefix + f"""
run_cmd do
  let owners : Array Name := #[{owners}]
  let ownerSet := owners.foldl (fun (s : NameSet) n => s.insert n) {{}}
  let env ← getEnv
  let kernel := env.checked.get
  let file ← IO.FS.Handle.mk "{meta / (label + '.jsonl')}" .write
  let emit (j : Json) : IO Unit := file.putStrLn j.compress
  for moduleName in owners do
    unless (env.getModuleIdx? moduleName).isSome do throwError "missing module {{moduleName}}"
  let mut count : Nat := 0
  let mut catalog : Nat := 0
  for (n, c) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[mi.toNat]!
    unless ({tick}TCSlib).isPrefixOf home do continue
    let some ci := kernel.find? n | throwError "missing checked constant {{n}}"
    unless kind ci == kind c do throwError "checked kind differs for {{n}}"
    let status ← liftCoreM <| getReducibilityStatus n
    let matcher := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let inst := Lean.Meta.isInstanceCore env n
    let common := [("name", identity n), ("home", identity home), ("kind", toJson (kind ci)),
      ("status", toJson (reprStr status)), ("abbrev", toJson (isAbbrev ci)),
      ("instance", toJson inst), ("matcher", toJson matcher)]
    emit <| Json.mkObj (("record", .str "catalog") :: common)
    catalog := catalog + 1
    if ownerSet.contains home then
      let value := ci.value? (allowOpaque := true)
      let axioms ← liftCoreM <| collectAxioms n
      emit <| Json.mkObj (("record", .str "constant") :: common ++ [
        ("type", exprData ci.type), ("levels", names ci.levelParams.toArray),
        ("definition_value", if ci.isDefinition then (value.map exprData).getD .null else .null),
        ("type_refs", names ci.type.getUsedConstants),
        ("value_refs", names ((value.map (·.getUsedConstants)).getD #[])),
        ("axioms", names axioms)])
      count := count + 1
  emit <| Json.mkObj [("record", .str "complete"), ("count", toJson count),
    ("catalog", toJson catalog), ("owners", names owners)]
  logInfo m!"Stretch census complete: {{count}} declarations"

end CleanupIncrement
"""
    (meta / (label + "Census.lean")).write_text(program)

(meta / "PermutationDefinitionProbe.lean").write_text("""import TCSlib.Cryptography.Asymptotic.HardCore

open TCSlib.Cryptography

example (P : PermFamily) (h : ∀ n, (Fin n → Bool) → Bool) :
    owpGenPRG P h = PRG.oneBit (fun n s => Fin.snoc (P.f n s) (h n s)) :=
  rfl
""")
print(f"Prepared census with {len(base_closure)} base dependencies", flush=True)
