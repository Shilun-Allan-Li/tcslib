#!/usr/bin/env bash
set -euo pipefail
a=$1
w=$2
m="$a/metadata-r3"
while true; do
  receipt=$(find "$a/native-r3" -maxdepth 2 -name check-0009.json -print -quit)
  if [[ -n "$receipt" ]] && python3 -I - "$receipt" <<'PY'
from pathlib import Path
import json,sys
r=json.loads(Path(sys.argv[1]).read_bytes())
assert r['rc']==0 and r['module']=='TCSlib/Cryptography/Asymptotic/PRF'
PY
  then break; fi
  if [[ -s "$a/native-r3/RESULT.json" ]] || [[ -n "$receipt" ]]; then
    echo "The PRF prerequisite receipt is unavailable or invalid" >&2
    exit 1
  fi
  sleep 5
done
python3 -I "$a/prepare_head_tree_r3.py" "$a"
lean=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$a/native-r3/PLAN.json")
tree="$m/head/oleans"
bash "$a/run_probes.sh" "$lean" "$tree" "$m/HeadCensus" "$m/PermutationDefinitionProbe" "$m/StretchImport" "$m/LegacyImport" "$m/HeadGeneratedEquations"
python3 -I "$a/prepare_seals_r3.py" "$a" "$w" Head
target="$m/head-seals"
bash "$a/run_probes.sh" "$lean" "$tree" "$target/ReductionSupportSeal" "$target/StretchMachineSeal" "$target/StretchSeal" "$target/HardCoreLemmasSeal" "$target/HardCoreSeal" "$target/HardCorePermutationSeal" "$target/PRFSeal" "$target/PRFLemmasSeal" "$target/UnsealedControl" "$target/SealedControl" "$target/ReaderControl"
