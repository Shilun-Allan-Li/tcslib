"""Recheck the docstring amendment and affected consumers against the verified move."""
from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root = (Path(s).resolve() for s in sys.argv[1:])
previous = area / "native-r2"
out = area / "native-r3"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location(
    "checked_import_graph", area.parent / "cleanup-incremental-20261108/tools/import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)

def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst

old = read(previous / "PLAN.json")
result = read(previous / "RESULT.json")
products = read(previous / "PRODUCTS.json")
head = git("rev-parse", "HEAD").decode().strip()
assert result["passed"] and result["head"] == old["head"]
assert git("rev-parse", "HEAD^").decode().strip() == old["base"]
assert not git("status", "--porcelain")
assert result["plan_sha256"] == sha(previous / "PLAN.json")
assert set(products) == set(old["order"])
changed = {s[:-5] for s in git("diff", "--name-only", old["head"], head).decode().splitlines()}
assert changed == {
    "TCSlib/Cryptography/Asymptotic/HardCore",
    "TCSlib/Cryptography/Pseudorandom/Generators/Asymptotic/Stretch",
}
affected = set(changed)
source_digests = {}
for module in old["order"]:
    if affected.intersection(old["graph"][module]):
        affected.add(module)
    path = module + ".lean"
    local = root / path
    source_digests[module] = sha(local)
    if module in changed:
        prior = git("show", f"{old['head']}:{path}").decode()
        assert graph.comments_removed(prior).split() == graph.comments_removed(local.read_text()).split(), path
    else:
        assert source_digests[module] == old["source_digests"][module], path
assert affected <= set(old["affected"])
rebuild = [module for module in old["order"] if module in affected]
verified_prefix = sorted(set(old["affected"]) - affected)
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
old_tree = Path(old["tree"]).resolve()
retained = {}
for module in old["order"]:
    if module in affected:
        continue
    row = products[module]
    assert row["source_sha256"] == source_digests[module]
    assert row["direct_local"] == {dep: retained[dep]["object_sha256"] for dep in old["graph"][module]}
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {**row, "source": "r2_verified_same_source_and_inputs"}

external = {}
for name, row in old["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        target = tree / path.relative_to(old_tree)
        copy(path, target, row["sha256"])
        path = target
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    **old, "head": head, "tree": str(tree), "rebuild": rebuild,
    "verified_prefix": verified_prefix, "retained": retained, "external": external,
    "source_digests": source_digests,
}
(out / "PLAN.json").write_text(json.dumps(plan, indent=2) + "\n")
source = read(area / "SOURCE-CHECK-R2.json")
assert source["head"] == old["head"]
source.update(head=head, comment_only_followup_paths=sorted(changed), previous_verified_head=old["head"],
              fresh_native_checks=len(rebuild), verified_affected_transfers=len(verified_prefix))
(area / "SOURCE-CHECK-R3.json").write_text(json.dumps(source, indent=2) + "\n")
print(f"{len(retained)} exact object transfers including {len(verified_prefix)} affected, "
      f"{len(rebuild)} fresh checks after the docstring amendment", flush=True)
