"""Reconcile exact-source native, lint, seal, and deferred-ledger evidence."""

from difflib import SequenceMatcher
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))
native = area / "native-r3"
prev = area / "native-r2"
prefix = "TCSlib/Cryptography/"
hardcore = prefix + "Asymptotic/HardCore.lean"
stretch = prefix + "Pseudorandom/Generators/Asymptotic/Stretch.lean"
ledger_dir = (campaign / "briefs/pass-shelat-ch5-8/maintainer"
              / "cleanup-incremental-2026-11-09/final-r1")
ledger_zip = ledger_dir / "11-final-read-ledger.zip"
changed_ids = {"SEAL-0228", "SEAL-0246", "SEAL-0247", "SEAL-0249"}
moved_ids = {"SEAL-0223", "SEAL-0224", "SEAL-0225", "SEAL-0226", "SEAL-0227"}


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def content(rev, path):
    return git("show", f"{rev}:{path}")


def revisions(dir_, expected_head):
    result = read(dir_ / "RESULT.json")
    plan = read(dir_ / "PLAN.json")
    products = read(dir_ / "PRODUCTS.json")
    assert result["passed"] and result["head"] == plan["head"] == expected_head
    assert result["base"] == plan["base"] == base
    assert result["plan_sha256"] == sha(dir_ / "PLAN.json")
    assert result["products_sha256"] == sha(dir_ / "PRODUCTS.json")
    assert result["fresh_native_checks"] + result["reused_native_checks"] == len(plan["rebuild"])
    assert len(plan["affected"]) == len(plan["rebuild"]) + len(plan["verified_prefix"]) == 77
    assert len(products) == len(plan["order"]) == 1091
    assert result["initial_retained"] == len(plan["retained"])
    assert all(products[n]["source_sha256"] == plan["source_digests"][n] for n in plan["order"])
    assert all(products[n]["direct_local"] == {
        dep: products[dep]["object_sha256"] for dep in plan["graph"][n]
    } for n in plan["order"])
    fresh = {n: products[n] for n in plan["rebuild"]}
    assert "TCSlib" in fresh and "audits/pass-shelat/Checks" in fresh
    checked = {}
    for receipt in dir_.glob("run-*/check-*.json"):
        row = read(receipt)
        assert sha(receipt.with_suffix(".log")) == row["log_sha256"], receipt
        assert row["head"] == expected_head
        if row["rc"] == 0:
            checked[row["module"]] = row
    assert set(checked) == set(fresh)
    assert all(fresh[n]["object_sha256"] == checked[n]["object_sha256"] for n in fresh)
    return plan, products, result


prev_plan, prev_products, prev_result = revisions(prev, (area / "head-r2.txt").read_text().strip())
head_plan, head_products, head_result = revisions(native, head)
assert prev_result["fresh_native_checks"] == 61 and head_result["fresh_native_checks"] == 52
assert set(head_plan["retained"]) == set(head_plan["order"]) - set(head_plan["rebuild"])
for name, row in head_plan["retained"].items():
    assert all(row[k] == prev_products[name][k] for k in ("source_sha256", "object_sha256", "direct_local"))
assert len(head_plan["external"]) == len(prev_plan["external"]) == 3810
assert {k: r["sha256"] for k, r in head_plan["external"].items()} == {
    k: r["sha256"] for k, r in prev_plan["external"].items()
}
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain")
assert not git("diff", "--check", base, head)
assert not re.search(rb'^\+\s*(?:sorry|admit)\b', git("diff", base, head), re.M)
attrs = re.findall(rb'^([-+])(\s*(?:@\[simp\]|attribute\s+\[simp\])[^\n]*)',
                   git("diff", base, head), re.M)
assert sorted(line for sign, line in attrs if sign == b"+") == sorted(
    line for sign, line in attrs if sign == b"-")
assert "0 findings in 11 files" in (area / "style-r3.log").read_text()

seal_receipts = {}
diagnostics = {}
for side, revision, directory in (
    ("base", base, area / "metadata-r2/base-seals"),
    ("head", head, area / "metadata-r3/head-seals"),
):
    diag = {}
    receipts = {}
    scope = read(directory / "SCOPE.json")
    labels = set(scope) | ({"UnsealedControl"} if side == "head" else set())
    assert {p.stem for p in directory.glob("*.rc")} == labels
    for label in sorted(labels):
        log_path = directory / (label + ".log")
        probe = directory / (label + ".lean")
        rc = int((directory / (label + ".rc")).read_text())
        log = log_path.read_text()
        manifest = read(directory / (label + ".json")) if label in scope else {}
        n = scope.get(label, 0)
        if n:
            assert n == len(manifest["requests"])
            assert sha(probe) == manifest["probe_sha256"]
            assert log.count(f"G06-SEAL-END label={label} requested={n} verified={n}") == 1
            assert len({(r["spelling"], r["home"]) for r in manifest["requests"]}) == n
        error_pattern = r"\.lean:(\d+):(\d+): error: (.*?)(?=\n(?:G06-|[^\n]*\.lean:\d+:\d+:)|\Z)"
        errs = re.findall(error_pattern, log, flags=re.S)
        assert len(errs) == len(re.findall(r"\.lean:\d+:\d+: error:", log))
        assert rc == int(bool(errs)), (side, label, rc)
        if label.endswith("Seal"):
            path = manifest["source_path"]
            source = content(revision, path)
            assert sha256(source).hexdigest() == manifest["source_sha256"]
            lines = source.decode().splitlines()
            mapping = {x["probe_line"]: x["source_line"] for x in manifest["line_map"]}
            assert sorted(mapping.values()) == list(range(1, len(lines) + 1))
            for pline, column, msg in errs:
                line = mapping[int(pline)]
                assert (path, line) not in diag
                diag[path, line] = {"column": int(column), "source": lines[line-1], "message": msg.rstrip()}
        elif label == "SealedControl":
            assert len(errs) == 1 and "rfl" in errs[0][2] and "PRG.expand" in errs[0][2]
        else:
            assert not errs
        receipts[label] = {"requests_verified": n, "errors": len(errs), "rc": rc, "log_sha256": sha(log_path),
                           "probe_sha256": sha(probe), "source_sha256": manifest.get("source_sha256")}
    seal_receipts[side] = receipts
    diagnostics[side] = diag

base_diag, head_diag = diagnostics["base"], diagnostics["head"]
assert len(base_diag) == 18 and len(head_diag) == 14
zip_digest = next(line.split()[0] for line in (ledger_dir / "SHA256SUMS").read_text().splitlines()
                  if line.endswith("  " + ledger_zip.name))
assert sha(ledger_zip) == zip_digest
with zipfile.ZipFile(ledger_zip) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
observations = ledger["current_observations"]
assert len(observations) == 813 and not ledger["needs_review"] and not ledger["partial"]
owned_paths = {
    read(p)["source_path"]
    for p in (area / "metadata-r2/base-seals").glob("*Seal.json")
}
owned = [r for r in observations if (r.get("current_owner") or r["path"]) in owned_paths]
assert all(r["channel"] == "whole-file-seal" for r in owned)
assert {(r["current_owner"], r["head_line"]) for r in owned} == set(base_diag)


def map_lines(old, new, first=1, last=None):
    a = content(base, old).decode().splitlines()[first-1:last]
    b = content(head, new).decode().splitlines()
    return {i + first + k: j + 1 + k
            for i, j, size in SequenceMatcher(None, [s.rstrip() for s in a],
                                              [s.rstrip() for s in b], autojunk=False).get_matching_blocks()
            for k in range(size)}


relocated = map_lines(hardcore, stretch, 454, 624)
same_owner = {path: map_lines(path, path) for path in owned_paths}
mapped = set()
resolution = {
    "SEAL-0228": "Compare the two generators through PRG.expand_stretch and PRG.expand_G_stretch.",
    "SEAL-0246": "Transport predictor coins through the equality read from NUPPT.coins_wrap.",
    "SEAL-0247": "Transport the padding inverter coins and use ofFn_finCastEquiv at the run boundary.",
    "SEAL-0249": "Transport the collection inverter coins and use ofFn_finCastEquiv at the run boundary.",
}
items = []
for old in sorted(owned, key=lambda row: row["id"]):
    id_, path, line = (old[field] for field in ("id", "current_owner", "head_line"))
    before = base_diag[path, line]
    assert before["source"].rstrip() == old["head_source"].rstrip(), id_
    assert before["message"].splitlines()[0] == old["head_error"].splitlines()[0], id_
    item = {"id": id_, "old_path": path, "old_line": line, "old_diagnostic": before}
    if id_ in changed_ids:
        item.update(disposition="closed_by_reader_transport", proof_change=resolution[id_])
    else:
        dest = (stretch, relocated[line]) if id_ in moved_ids else (path, same_owner[path][line])
        after = head_diag[dest]
        assert dest not in mapped and before["column"] == after["column"], id_
        assert before["source"].rstrip() == after["source"].rstrip(), id_
        norm = lambda s: re.sub(r"\?m\.\d+", "?m", s)
        assert norm(before["message"]) == norm(after["message"]), (id_, before, after)
        mapped.add(dest)
        item.update(disposition="relocated" if id_ in moved_ids else "retained_same_step",
                    new_path=dest[0], new_line=dest[1], new_diagnostic=after)
    items.append(item)
assert mapped == set(head_diag)
assert sum(r["disposition"] == "relocated" for r in items) == 5

decls = read(area / "DECLARATIONS.json")
def closure(module):
    seen, pending = set(), [module]
    while pending:
        current = pending.pop()
        if current not in seen:
            seen.add(current)
            pending.extend(head_plan["graph"][current])
    return {path.replace("/", ".") for path in seen}

legacy_closures = {path[:-5].replace("/", "."): closure(path[:-5]) for path in owned_paths}
assert all(row["new_home"] in legacy_closures[row["old_home"]] for row in decls["declarations"])
providers = {(r["old_home"], r["old_name"]): r["new_home"] for r in decls["declarations"]
             if r["old_home"] != r["new_home"] and r["kind"] == "def"}
links = []
for row in observations:
    common = row.get("common_sealed_native_references", [])
    paired = [p["head"] for p in row.get("provider_pairs", []) if isinstance(p.get("head"), dict)]
    references = sorted({(r["home"], r["spelling"]) for r in common + paired} & providers.keys())
    for old_home, name in references:
        links.append({"id": row["id"], "name": name, "old_home": old_home,
                      "new_home": providers[old_home, name],
                      "paired_provider": any(p["spelling"] == name and p["home"] == old_home for p in paired),
                      "common_native_reference": any(p["spelling"] == name and p["home"] == old_home for p in common)})
assert {row["id"] for row in links} == {"SEAL-0225", "SEAL-0226", "SEAL-0227", "SEAL-0245"}

for side, expected_show in (("base", 2), ("head", 1)):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert f"lemma-list hits: 0\n" in log
    assert f"where the seal failed: {expected_show} " in log
    assert f"(collector): 0\n" in log

old_lint, new_lint = ({tuple(r) for r in read(area / f"campaign-lint-{side}.json")} for side in ("base", "head"))
new_failures = new_lint - old_lint
expected_facade = prefix + "Pseudorandom/Generators.lean"
new_owners = {prefix + "Pseudorandom/Generators/Asymptotic/" + name for name in ("Stretch", "StretchMachine")}
false_positives = sorted(r for r in new_failures if r[0] == "FAIL")
assert set(false_positives) == {
    ("FAIL", expected_facade, f"facade does not import child module `{p.replace('/', '.')}`")
    for p in new_owners
}
assert new_owners <= set(head_plan["graph"][prefix + "Pseudorandom"])
warning_names = lambda rows: {name.strip() for level, _, msg in rows
                              if level == "WARN" and "(check 8):" in msg
                              for name in msg.split("(check 8):", 1)[-1].split(",")}
assert warning_names(old_lint) == warning_names(new_lint)
assert not any("> 1000" in r[2] for r in new_lint if r[0] == "WARN")
seals = {"base": base, "head": head, "passed": True, "baseline_diagnostics": len(base_diag),
         "head_diagnostics": len(head_diag), "new_diagnostics": 0, "resolved": sorted(changed_ids),
         "requests": seal_receipts, "raw_campaign_facade_false_positives": false_positives,
         "new_campaign_reader_warnings": 0}
save(area / "SEALS.json", seals)
save(area / "READS.json", {
    "base": base, "head": head, "ledger_head": ledger["head"], "ledger_archive_sha256": zip_digest,
    "ledger_observations_checked_for_moved_providers": len(observations),
    "diagnostics": items, "relocated_provider_links": links,
    "explicit_foreign_definition_reads_in_owner_files": {"base": 0, "head": 0},
    "foreign_generated_equation_references_in_owner_terms": {"base": 0, "head": 0},
})
print("Matched all 14 final seal diagnostics to exact proof steps and verified four repairs.")
print("Both source scans and generated-reference scans report zero foreign reads.")
