"""Copy the checked head import closure for independent census and seal probes."""

from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area = Path(sys.argv[1]).resolve()
native = area / "native-r3"
meta = area / "metadata-r3"
out = meta / "head/oleans"
plan = json.loads((native / "PLAN.json").read_bytes())
products = dict(plan["retained"])


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


for path in sorted(native.glob("run-*/check-*.json")):
    row = json.loads(path.read_bytes())
    if row["rc"] == 0:
        assert row["head"] == plan["head"] and sha(path.with_suffix(".log")) == row["log_sha256"]
        products[row["module"]] = row
roots = ["TCSlib/Cryptography/Asymptotic/PRF", "TCSlib/Cryptography/Asymptotic/HardCorePermutation"]
needed = set()
pending = roots.copy()
while pending:
    module = pending.pop()
    if module not in needed:
        needed.add(module)
        pending.extend(plan["graph"][module])
assert needed <= set(products)
out.mkdir(parents=True)
tree = Path(plan["tree"])
root = Path(plan["worktree"])


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not src.samefile(dst), dst


for module in sorted(needed):
    row = products[module]
    assert sha(root / (module + ".lean")) == plan["source_digests"][module] == row["source_sha256"]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
    copy(tree / (module + ".olean"), out / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(tree):
        copy(src, out / src.relative_to(tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
(out / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
names = ("PRG.oneBit", "PRG.expand", "prg_expand", "PRG.Secure.doubling", "exists_expandEvaluator",
         "expandRedMachine_distinguisher", "PRG.Secure.truncateTo_negligible")
for label, imports in (("StretchImport", ["Pseudorandom.Generators.Asymptotic.Stretch"]),
                       ("LegacyImport", ["Asymptotic.PRF"])):
    text = "".join("import TCSlib.Cryptography." + module + "\n" for module in imports)
    text += "\n" + "".join("#check TCSlib.Cryptography." + name + "\n" for name in names)
    (meta / (label + ".lean")).write_text(text)
print("Verified head probe closure", len(needed), flush=True)
