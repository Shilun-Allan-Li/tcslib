"""Use the wrapper's published coin-length equation across its new boundary."""

from pathlib import Path

path = Path("TCSlib/Cryptography/Asymptotic/HardCoreLemmas.lean")
source = path.read_text()


def change(before, after):
    global source
    assert source.count(before) == 1, before
    source = source.replace(before, after)


change("""  refine predProb_coins_equiv f B _ _
    (((Equiv.funUnique (Fin 1) Bool).symm.prodCongr (Equiv.refl (D.Coins n))).trans
      (Fin.appendEquiv 1 (D.coinLen n))) fun y c => ?_
""",
"""  have hcoinLen : 1 + D.coinLen n = (owpPredMachine D flip).coinLen n := by
    simp only [NUPPT.coinLen_eq, owpPredMachine, NUPPT.coins_wrap, PolyExpr.eval_add, PolyExpr.eval_const]
  refine predProb_coins_equiv f B _ _
    (((Equiv.funUnique (Fin 1) Bool).symm.prodCongr (Equiv.refl (D.Coins n))).trans
      ((Fin.appendEquiv 1 (D.coinLen n)).trans (finCastEquiv hcoinLen))) fun y c => ?_
""")
change("""  simp only [Equiv.trans_apply, Equiv.prodCongr_apply, Prod.map_apply, Equiv.coe_refl, id_eq]
  exact (ofFn_appendEquiv""",
"""  simp only [Equiv.trans_apply, Equiv.prodCongr_apply, Prod.map_apply, Equiv.coe_refl, id_eq,
    ofFn_finCastEquiv]
  exact (ofFn_appendEquiv""")
change("""      ((glPadInvMachine A 𝓕.inLen).inverter n (𝓕.inLen.eval n) (𝓕.outLen.eval n)) := by
  simp only [invProbOpt_def]
""",
"""      ((glPadInvMachine A 𝓕.inLen).inverter n (𝓕.inLen.eval n) (𝓕.outLen.eval n)) := by
  have hcoinLen : 𝓕.inLen.eval n + A.coinLen n = (glPadInvMachine A 𝓕.inLen).coinLen n := by
    simp only [NUPPT.coinLen_eq, glPadInvMachine, NUPPT.coins_wrap, PolyExpr.eval_add]
  simp only [invProbOpt_def]
""")
change("""      (Fin.appendEquiv (𝓕.inLen.eval n) (A.coinLen n))) _))
""",
"""      ((Fin.appendEquiv (𝓕.inLen.eval n) (A.coinLen n)).trans (finCastEquiv hcoinLen))) _))
""")
change("""    Equiv.prodAssoc_apply, NUPPT.inverter_eq_some_iff] at hx' hfx' ⊢
""",
"""    Equiv.prodAssoc_apply, Equiv.trans_apply, NUPPT.inverter_eq_some_iff] at hx' hfx' ⊢
""")
change("""  rw [glPadInvMachine_runAt A 𝓕.inLen n _ r c _ (ofFn_appendEquiv r c)]
""",
"""  rw [glPadInvMachine_runAt A 𝓕.inLen n _ r c _ (by rw [ofFn_finCastEquiv, ofFn_appendEquiv])]
""")
change("""    F.invProbAt (glPadCollInvMachine A m) n := by
  simp only [Collection.invProbAt_eq]
""",
"""    F.invProbAt (glPadCollInvMachine A m) n := by
  have hcoinLen : m.eval n + A.coinLen n = (glPadCollInvMachine A m).coinLen n := by
    simp only [NUPPT.coinLen_eq, glPadCollInvMachine, NUPPT.coins_wrap, PolyExpr.eval_add]
  simp only [Collection.invProbAt_eq]
""")
change("""      (Fin.appendEquiv (m.eval n) (A.coinLen n))) _))
""",
"""      ((Fin.appendEquiv (m.eval n) (A.coinLen n)).trans (finCastEquiv hcoinLen))) _))
""")
change("""  simp only [Equiv.prodCongr_apply, Prod.map_apply, Equiv.coe_refl, id_eq, Equiv.prodAssoc_apply,
    ofFn_finCastEquiv] at hx' hfx' ⊢
""",
"""  simp only [Equiv.prodCongr_apply, Prod.map_apply, Equiv.coe_refl, id_eq, Equiv.prodAssoc_apply,
    Equiv.trans_apply, ofFn_finCastEquiv] at hx' hfx' ⊢
""")
change("""  rw [glPadCollInvMachine_runAt A m n _ _ ρ c _ (ofFn_appendEquiv ρ c), hab, pairFstD_pairEncode, ha]
""",
"""  rw [glPadCollInvMachine_runAt A m n _ _ ρ c _ (by rw [ofFn_finCastEquiv, ofFn_appendEquiv]),
    hab, pairFstD_pairEncode, ha]
""")
path.write_text(source)
