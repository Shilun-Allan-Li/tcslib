"""Run the campaign's source scan and collect checked generated-equation references."""

from collections import defaultdict
import json
from pathlib import Path
import re
import subprocess
import sys

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
scanner = (campaign / "briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06"
           / "evidence-rule10-final-r1/explicit-scan-r1/scan.py")
generated = re.compile(r"^(.+)\.(eq_\d+|eq_def|eq_unfold)$")

for side, catalog_dir in (("Base", "metadata-r2"), ("Head", "metadata-r3")):
    key = side.lower()
    rev = (area / (key + ".txt")).read_text().strip()
    catalog = {}
    declarations = []
    with (area / catalog_dir / (side + ".jsonl")).open() as stream:
        for line in stream:
            record = json.loads(line)
            if record["record"] == "catalog":
                name = record["name"]["display"]
                catalog[name] = record
            elif record["record"] == "constant":
                declarations.append(record)
            elif record["record"] == "complete":
                assert len(catalog) == record["catalog"] and len(declarations) == record["count"]
    owners = sorted({row["home"]["display"] for row in declarations})
    dest = area / "read-scan" / key
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "files.txt").write_text("".join(owner.replace(".", "/") + ".lean\n" for owner in owners))
    kinds = {}
    for name, row in catalog.items():
        kind = row["kind"]
        if kind == "def":
            status = row["status"].rsplit(".", 1)[-1]
            if row["instance"]:
                kind = "def-instance"
            elif status != "semireducible":
                kind = "def-" + status
        elif kind == "theorem":
            kind = "thm"
        kinds[name] = kind
    for name, row in catalog.items():
        if row["kind"] != "def":
            continue
        # Lean generates equation names on demand even if none was requested in this closure.
        for suffix in ("eq_1", "eq_def", "eq_unfold"):
            eqn = name + "." + suffix
            if eqn not in kinds:
                kinds[eqn] = "thm"
    (dest / "constants.tsv").write_text("".join(
        f"{name}\t{kind}\t{catalog[name]['home']['display'] if name in catalog else catalog[name.rsplit('.',1)[0]]['home']['display']}\n"
        for name, kind in sorted(kinds.items())
    ))
    refs = defaultdict(list)
    for row in declarations:
        name, home = row["name"]["display"], row["home"]["display"]
        for item in row["value_refs"]:
            ref = item["display"]
            match = generated.fullmatch(ref)
            if not match:
                continue
            parent = match[1]
            if parent not in catalog or catalog[parent]["kind"] != "def":
                continue
            parent_home = catalog[parent]["home"]["display"]
            if parent_home == home:
                continue
            assert ref in catalog and catalog[ref]["kind"] == "theorem", ref
            ref_home = catalog[ref]["home"]["display"]
            refs[home].append((home, name, parent, ref, parent_home, ref_home))
    eqndir = dest / "equations"
    eqndir.mkdir(exist_ok=True)
    for owner in owners:
        (eqndir / (owner + ".eqn.txt")).write_text("".join(
            "\t".join(row) + "\n" for row in sorted(refs[owner])
        ))
    diagnostics = []
    for rc in sorted((area / catalog_dir / (key + "-seals")).glob("*Seal.rc")):
        manifest = json.loads(rc.with_suffix(".json").read_bytes())
        line_map = {x["probe_line"]: x["source_line"] for x in manifest["line_map"]}
        for line, col in re.findall(r"\.lean:(\d+):(\d+): error:", rc.with_suffix(".log").read_text()):
            diagnostics.append(f" {manifest['source_path']}:{line_map[int(line)]}:{col}: error:\n")
    (dest / "seal-errors.txt").write_text("".join(diagnostics))
    subprocess.run(["python3", "-I", str(scanner), str(root), str(dest / "files.txt"), str(dest / "constants.tsv"),
                    str(eqndir), str(dest / "seal-errors.txt"), str(dest / "scan.log"), "--rev", rev],
                   check=True)
