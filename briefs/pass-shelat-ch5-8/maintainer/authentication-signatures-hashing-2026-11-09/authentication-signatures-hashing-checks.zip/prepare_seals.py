"""Build owner seals from the checked declarations and their exact import closures."""

from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
area, root = (Path(s).resolve() for s in sys.argv[1:3])
side = sys.argv[3]
assert side in ("Base", "Head")
meta = area / "metadata"
previous = area.parent / "authentication-mac-from-prf-20261109/native"
review = area.parent / "gate06-combined-20261108"
tools = review / "rule10-evidence-r2/tool-inputs"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


bs = load(tools / "build_seals.py", "checked_seals")
controls = load(tools / "build_controls.py", "checked_controls")
adapter = load(tools / "request_payload_adapter.py", "checked_adapter")
bound = load(review / "rule10-payload-retry-r3/bound_payload.py", "checked_bound")
adapter.configure_builders(bs, controls)
seal = bs.seal_command
bs.seal_command = lambda label, req, *, end: bound.bound_payloads(seal(label, req, end=end))
candidate = read(area / "native/PLAN.json")
plan = read(previous / "PLAN.json") if side == "Base" else candidate
with (meta / (side + ".jsonl")).open() as stream:
    rows = [json.loads(line) for line in stream]
complete = rows.pop()
assert complete["record"] == "complete"
catalog = {row["name"]["display"]: row for row in rows if row["record"] == "catalog"}
decls = [row for row in rows if row["record"] == "constant"]
assert len(catalog) == complete["catalog"] and len(decls) == complete["count"]
owners = [row["display"] for row in complete["owners"]]
dest = meta / (side.lower() + "-seals")
dest.mkdir()
masks = {}


def request(row):
    return {"spelling": row["name"]["display"], "home": row["home"]["display"],
            "matcher": row["matcher"], "collector_reducibility": row["status"].rsplit(".", 1)[-1],
            "instance": row["instance"], "abbrev": row["abbrev"],
            "name_components": row["name"]["components"], "home_components": row["home"]["components"],
            "constant_kind": "def"}


def probe(label, raw, requests, **fields):
    out, inserts, lines = bs.instrument(raw, bs.header(raw), label, requests)
    path = dest / (label + ".lean")
    path.write_bytes(out)
    (dest / (label + ".json")).write_text(json.dumps({
        "label": label, "requests": requests, "insertions": inserts, "line_map": lines,
        "probe_sha256": sha(path), **fields,
    }, indent=2) + "\n")
    masks[label] = len(requests)


scope = read(area / "MOVE-SCOPE.json")
labels = {
    "Base": {"Defs": "AuthDefsSeal", "Lamport": "LamportSeal", "HashAndSign": "HashAndSignSeal", "DLHash": "DLHashSeal"},
    "Head": {"Defs": "SignatureDefsSeal", "Lamport": "LamportSeal", "HashAndSign": "HashAndSignSeal",
             "CollisionResistant": "CollisionResistantSeal", "FromDiscreteLog": "DiscreteLogSeal"},
}

for owner in owners:
    label = labels[side][owner.rsplit(".", 1)[-1]]
    module = owner.replace(".", "/")
    path = module + ".lean"
    raw = (subprocess.check_output(["git", "show", f"{candidate['base']}:{path}"], cwd=root)
           if side == "Base" else (root / path).read_bytes())
    assert bs.sha(raw) == plan["source_digests"][module]
    pending = list(plan["graph"][module])
    closure = set()
    while pending:
        dep = pending.pop()
        if dep not in closure:
            closure.add(dep)
            pending.extend(plan["graph"][dep])
    homes = {dep.replace("/", ".") for dep in closure}
    requests, reducible_other = [], []
    for name, row in sorted(catalog.items()):
        if row["kind"] != "def" or row["home"]["display"] not in homes or name == "Complexity.PolyExpr.eval":
            continue
        if row["status"].endswith(".reducible") and not row["matcher"]:
            if not row["abbrev"]:
                reducible_other.append(name)
            continue
        requests.append(request(row))
    actual = sorted({
        ref["display"] for row in decls if row["home"]["display"] == owner
        for f in ("type_refs", "value_refs") for ref in row[f]
        if ref["display"] in catalog and catalog[ref["display"]]["home"]["display"] in homes
    })
    probe(label, raw, requests, source_path=path,
          source_sha256=bs.sha(raw), actual_foreign_references=actual,
          reducible_non_abbrev=reducible_other)

if side == "Head":
    controls = {
        "Signature": (
            """import TCSlib.Cryptography.Authentication.Signatures.Defs

open Complexity TCSlib.Cryptography TCSlib.Cryptography.Games TCSlib.Cryptography.Authentication

example (S : SignatureScheme) :
    S.OneTimeSecure ↔ ∀ A : NUPPT, ∃ ε : ℕ → ℝ, Negligible ε ∧
      ∀ n, accept (S.forgeGame A 1 n) ≤ ε n := by
  rfl
""",
            "TCSlib.Cryptography.Authentication.SignatureScheme.OneTimeSecure",
            "exact S.oneTimeSecure_iff",
        ),
        "Hash": (
            """import TCSlib.Cryptography.Hashing.CollisionResistant

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Authentication

example (H : CRH) (n : ℕ) (i : List Bool) (x : Fin (H.domLen.eval n) → Bool) :
    H.hash n i x =
      padFin (H.rangeLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn x)))) := by
  rfl
""",
            "TCSlib.Cryptography.Authentication.CRH.hash",
            "exact H.hash_eq n i x",
        ),
    }
    for kind, (source, name, proof) in controls.items():
        raw = source.encode()
        (dest / (kind + "UnsealedControl.lean")).write_bytes(raw)
        requests = [request(catalog[name])]
        probe(kind + "SealedControl", raw, requests)
        probe(kind + "ReaderControl", raw.replace(b"  rfl\n", ("  " + proof + "\n").encode()), requests)
(dest / "SCOPE.json").write_text(json.dumps(masks, indent=2) + "\n")
print(side, masks, flush=True)
