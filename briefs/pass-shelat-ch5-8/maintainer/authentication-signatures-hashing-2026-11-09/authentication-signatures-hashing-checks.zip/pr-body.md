## Contract split

- Move the signature interface and forgery games into `Authentication.Signatures.Defs`.
- Move the hash family interface, compression predicate and collision game into `Hashing.CollisionResistant`. Preserve the collision game's padding, splitting and membership checks.

## Constructions and facades

- Move Lamport and hash-and-sign into `Authentication.Signatures` and the discrete-log construction into `Hashing.FromDiscreteLog`.
- Index the constructions from the authentication and hashing facades. Keep the original imports as compatibility paths.

## Verification

- All thirteen affected modules and campaign Checks pass. The contract commit's modules and their import closures match the checked head.
- The comparison matches all 214 original declarations and checks the re-emitted coin-space proof. The legacy and canonical import probes agree.
- All nine whole-file seals and both reader controls pass. The evidence records the existing admissions and the root linter's reports for modules reachable through the facades.
- The LWE/SIS comparison identifies the shared `Hashing.lean` path and records the three facade imports to retain when the branches meet.
