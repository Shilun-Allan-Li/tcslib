"""Compare checked declaration types, definition values, and legacy imports."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

sys.setrecursionlimit(30000)
area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
scope = json.loads((area / "MOVE-SCOPE.json").read_bytes())
moves = {new.replace("/", "."): old.replace("/", ".") for new, old in scope["moves"].items()}
legacy_defs = scope["legacy_defs"].replace("/", ".")
signature_defs = scope["signature_defs"].replace("/", ".")
hash_defs = scope["crh"].replace("/", ".")
namespace = "TCSlib.Cryptography.Authentication."
standard = {"propext", "Classical.choice", "Quot.sound"}
admitted = {namespace + name for name in (
    "lamport_oneTimeSecure", "hashAndSign_oneTimeSecure", "exists_oneTimeSecure_of_crh_owf", "dlHash_crh",
)}
hygiene = ("str", "_@")


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def key(name):
    return tuple(tuple(part) for part in name["components"])


def catalog(side, owners):
    rows = [json.loads(line) for line in (meta / (side + ".jsonl")).open()]
    last = rows.pop()
    assert last["record"] == "complete" and last["catalog"] == sum(r["record"] == "catalog" for r in rows)
    assert {name["display"] for name in last["owners"]} == owners
    result = {r["name"]["display"]: r for r in rows if r["record"] == "constant"}
    assert len(result) == last["count"] and {r["home"]["display"] for r in result.values()} == owners
    assert all({item["display"] for item in r["axioms"]} <= standard | {"sorryAx"} for r in result.values())
    assert {name for name, row in result.items() if any(a["display"] == "sorryAx" for a in row["axioms"])} == admitted
    return result


def suffix(r):
    name = key(r["name"])
    home = key(r["home"])
    if name[:len(home)+1] == (("str", "_private"),) + home:
        assert name[len(home)+1][0] == "num"
        return name[len(home)+2:]
    return name


def canonical(expr, names):
    if not isinstance(expr, list) or not expr:
        return expr
    tag = expr[0]
    if tag in ("forall", "lam", "let"):
        label = key(expr[1])
        if hygiene in label:
            assert ("str", "_hygCtx") in label or ("str", "_hyg") in label
            label = label[:label.index(hygiene)]
        return [tag, label, *[canonical(part, names) for part in expr[2:]]]
    if tag in ("const", "proj"):
        name = key(expr[1])
        return [tag, names.get(name, name), *[canonical(part, names) for part in expr[2:]]]
    return [canonical(part, names) for part in expr]


base = catalog("Base", set(moves.values()))
head = catalog("Head", set(moves))
assert len(base) == 214
old_aux = namespace + "SignatureScheme.forgeGame._proof_2"
new_aux = namespace + "CRH.collisionGame._proof_2"
assert set(head) - set(base) == {new_aux}, sorted(set(head) - set(base))
assert not (set(base) - set(head)), sorted(set(base) - set(head))
pairs = {name: name for name in base}

def home_for(row):
    home = row["home"]["display"]
    if home != legacy_defs:
        return next(new for new, old in moves.items() if old == home)
    name = row["name"]["display"]
    if name == namespace + "SignatureScheme" or name.startswith(namespace + "SignatureScheme."):
        return signature_defs
    assert name == namespace + "CRH" or name.startswith(namespace + "CRH."), name
    return hash_defs

def used_by(rows, name):
    return {decl for decl, row in rows.items() if any(ref["display"] == name for ref in row["value_refs"])}

signature_game = namespace + "SignatureScheme.forgeGame"
collision_game = namespace + "CRH.collisionGame"
assert used_by(base, old_aux) == {signature_game, collision_game}
assert used_by(head, old_aux) == {signature_game}
assert used_by(head, new_aux) == {collision_game}
normalize_head = {key(head[new_aux]["name"]): key(base[old_aux]["name"])}
a, b = base[old_aux], head[new_aux]
assert a["kind"] == b["kind"] == "theorem" and a["proof_value"] is not None and b["proof_value"] is not None
for field in ("type", "proof_value"):
    assert canonical(a[field], {}) == canonical(b[field], normalize_head), (new_aux, field)
assert {key(ref) for ref in a["axioms"]} == {key(ref) for ref in b["axioms"]}
errors = []
result = []
for name, target in sorted(pairs.items()):
    a, b = base[name], head[target]
    old_home, new_home = a["home"]["display"], b["home"]["display"]
    assert new_home == home_for(a), (name, old_home, new_home)
    for field in ("kind", "status", "abbrev", "instance", "matcher", "levels"):
        if a[field] != b[field]:
            errors.append((name, field))
    if {key(item) for item in a["axioms"]} != {key(item) for item in b["axioms"]}:
        errors.append((name, "axioms"))
    if canonical(a["type"], {}) != canonical(b["type"], normalize_head):
        errors.append((name, "type"))
    if {key(ref) for ref in a["type_refs"]} != {normalize_head.get(key(ref), key(ref)) for ref in b["type_refs"]}:
        errors.append((name, "type_refs"))
    if canonical(a["definition_value"], {}) != canonical(b["definition_value"], normalize_head):
        errors.append((name, "definition_value"))
    if {key(ref) for ref in a["value_refs"]} != {normalize_head.get(key(ref), key(ref)) for ref in b["value_refs"]}:
        errors.append((name, "value_refs"))
    if canonical(a["proof_value"], {}) != canonical(b["proof_value"], normalize_head):
        errors.append((name, "generated proof value"))
    result.append({"old_name": name, "new_name": target, "old_home": old_home, "new_home": new_home,
                   "kind": a["kind"], "axioms": sorted(i["display"] for i in b["axioms"])})
assert not errors, errors
base_log = (meta / "BaseLegacy.log").read_bytes()
for label in ("BaseCensus", "BaseLegacy", "HeadLegacy", "Standalone", "HeadCensus"):
    assert (meta / (label + ".rc")).read_text().strip() == "0", label
for label in ("HeadLegacy", "Standalone"):
    assert (meta / (label + ".log")).read_bytes() == base_log, label
for label, imported in (("BaseLegacy", list(scope["shims"])),
                        ("HeadLegacy", list(scope["shims"])),
                        ("Standalone", [*sorted(scope["moves"]), scope["hashing"]])):
    imports = [line for line in (meta / (label + ".lean")).read_text().splitlines() if line.startswith("import ")]
    assert imports == ["import " + module.replace("/", ".") for module in imported], label
moved = Counter(r["new_home"] for r in result if r["old_home"] != r["new_home"])
assert sum(moved.values()) == len(base) and set(moved) == set(moves)
(area / "DECLARATIONS.json").write_text(json.dumps({
    "base": (area / "base.txt").read_text().strip(), "head": (area / "head.txt").read_text().strip(),
    "matched_declarations": len(result), "relocated_declarations": sum(moved.values()),
    "new_homes": moved, "private_name_changes": 0,
    "type_and_definition_comparison": "same kernel syntax modulo generated binder scopes and the re-emitted coin-space proof",
    "axioms_match": True, "admission_dependencies": sorted(admitted), "elaborated_references_match": True, "legacy_and_new_imports_agree": True,
    "catalog_sha256": {side: sha(meta / (side + ".jsonl")) for side in ("Base", "Head")},
    "generated_auxiliary_proof": {"shared_before": old_aux, "new_local": new_aux,
                                    "type_proof_and_axioms_match": True},
    "declarations": result,
}, indent=2) + "\n")
print("All 214 declaration types, definition values, references and axiom sets match.")
print("Moved declarations:", dict(moved))
