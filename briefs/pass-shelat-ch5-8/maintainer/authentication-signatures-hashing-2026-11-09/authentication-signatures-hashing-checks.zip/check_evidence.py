"""Verify the exact source replay, declaration comparison, seals and ledger mapping."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, repo, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
native, meta = area / "native", area / "metadata"
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source, move, decls = (read(area / (name + ".json")) for name in ("SOURCE-CHECK", "MOVE-SCOPE", "DECLARATIONS"))
moves = move["moves"]
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain") and not git("diff", "--check", base, head)
assert all((r["base"], r["head"]) == (base, head) for r in (plan, result, source, decls))
assert result["passed"] and result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == 14
assert len(plan["affected"]) == source["affected_modules"] == 13
assert set(plan["rebuild"]) - set(plan["affected"]) == set(source["campaign_checks_replayed"]) == {"audits/pass-shelat/Checks"}
assert result["initial_retained"] == len(plan["retained"]) == 1105
assert len(products) == len(plan["order"]) == 1119 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert source["legacy_closure_preserved"] and source["facade_closure_preserved"]
assert source["proof_and_definition_code_preserved"] and source["relocation"] == moves
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert decls["matched_declarations"] == decls["relocated_declarations"] == 214
assert decls["elaborated_references_match"] and decls["private_name_changes"] == 0
assert decls["axioms_match"] and decls["legacy_and_new_imports_agree"]
namespace = "TCSlib.Cryptography.Authentication."
assert decls["admission_dependencies"] == sorted(namespace + name for name in (
    "lamport_oneTimeSecure", "hashAndSign_oneTimeSecure", "exists_oneTimeSecure_of_crh_owf", "dlHash_crh",
))
assert decls["generated_auxiliary_proof"]["type_proof_and_axioms_match"]

# The three contract files and their entire dependency closure are byte-identical
# at the contract commit and checked head. Bind that commit to the same checks.
contracts_commit = (area / "contracts.txt").read_text().strip()
assert source["contracts_commit"] == contracts_commit
contracts = {}
for module in source["contracts_paths"]:
    assert module in plan["rebuild"]
    required, pending = set(), [module]
    while pending:
        dep = pending.pop()
        if dep not in required:
            required.add(dep)
            pending.extend(plan["graph"][dep])
    for dep in required:
        assert sha256(git("show", f"{contracts_commit}:{dep}.lean")).hexdigest() == plan["source_digests"][dep], dep
    contracts[module] = {"checked_object_sha256": products[module]["object_sha256"],
                         "identical_source_closure_modules": len(required)}
save(area / "CONTRACTS.json", {"commit": contracts_commit, "checked_head": head, "modules": contracts})

auth, hashing = move["auth"], move["hashing"]
base_targets = {"AuthDefsSeal": auth + "/Defs", "LamportSeal": auth + "/Lamport",
                "HashAndSignSeal": auth + "/HashAndSign", "DLHashSeal": auth + "/DLHash"}
head_targets = {"SignatureDefsSeal": move["signature_defs"], "CollisionResistantSeal": move["crh"],
                "LamportSeal": auth + "/Signatures/Lamport", "HashAndSignSeal": auth + "/Signatures/HashAndSign",
                "DiscreteLogSeal": hashing + "/FromDiscreteLog"}
previous_label = {"SignatureDefsSeal": "AuthDefsSeal", "CollisionResistantSeal": "AuthDefsSeal",
                  "LamportSeal": "LamportSeal", "HashAndSignSeal": "HashAndSignSeal", "DiscreteLogSeal": "DLHashSeal"}
seal_constants = {"Signature": namespace + "SignatureScheme.OneTimeSecure", "Hash": namespace + "CRH.hash"}

seals, masks, warnings = {"base": {}, "head": {}}, {}, {}
provider_homes = {r["old_name"]: r["new_home"] for r in decls["declarations"] if r["kind"] == "def"}
for side, rev, targets in (("base", base, base_targets), ("head", head, head_targets)):
    directory = meta / (side + "-seals")
    expected_labels = set(targets)
    if side == "head":
        expected_labels.update(prefix + mode + "Control" for prefix in seal_constants for mode in ("Sealed", "Reader"))
    scope = read(directory / "SCOPE.json")
    assert set(scope) == expected_labels
    for label, module in targets.items():
        stem = directory / label
        manifest = read(stem.with_suffix(".json"))
        raw = git("show", f"{rev}:{module}.lean")
        assert manifest["source_path"] == module + ".lean"
        assert sha256(raw).hexdigest() == manifest["source_sha256"]
        assert sorted(row["source_line"] for row in manifest["line_map"]) == list(range(1, len(raw.splitlines()) + 1))
        requests = manifest["requests"]
        count = scope[label]
        assert len(requests) == len({r["spelling"] for r in requests}) == count
        assert sha(stem.with_suffix(".lean")) == manifest["probe_sha256"]
        log = stem.with_suffix(".log").read_text()
        assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
        assert stem.with_suffix(".rc").read_text().strip() == "0", (side, label)
        assert not re.search(r"\.lean:\d+:\d+: error(?:\(|:)", log)
        seals[side][label] = {
            "source_sha256": manifest["source_sha256"], "probe_sha256": manifest["probe_sha256"],
            "log_sha256": sha(stem.with_suffix(".log")), "requests": count, "diagnostics": 0,
        }
        masks[side, label] = {r["spelling"]: r for r in requests}
        warnings[side, label] = re.findall(r"\.lean:\d+:\d+: warning: ([^\n]+)", log)
for label, old_label in previous_label.items():
    prior_mask = masks["base", old_label]
    new_mask = masks["head", label]
    assert new_mask.keys() <= prior_mask.keys(), (label, sorted(new_mask.keys() - prior_mask.keys()))
    for name, request in new_mask.items():
        old_request = prior_mask[name]
        assert request["home"] == provider_homes.get(name, old_request["home"]), (label, name)
        for field in ("matcher", "collector_reducibility", "instance", "abbrev"):
            assert request[field] == old_request[field], (label, name, field)
    assert warnings["base", old_label] == warnings["head", label], label
assert warnings["base", "AuthDefsSeal"] == []
for label in set(base_targets) - {"AuthDefsSeal"}:
    assert warnings["base", label] == ["declaration uses 'sorry'"], label

controls = {}
for prefix, name in seal_constants.items():
    for mode, rc in (("Unsealed", 0), ("Sealed", 1), ("Reader", 0)):
        label = prefix + mode + "Control"
        stem = meta / "head-seals" / label
        assert stem.with_suffix(".rc").read_text().strip() == str(rc), label
        log = stem.with_suffix(".log").read_text()
        source_hash = sha(stem.with_suffix(".lean"))
        if mode != "Unsealed":
            manifest = read(stem.with_suffix(".json"))
            assert source_hash == manifest["probe_sha256"]
            assert [r["spelling"] for r in manifest["requests"]] == [name]
            assert log.count(f"G06-SEAL-END label={label} requested=1 verified=1") == 1
        errors = re.findall(r"\.lean:\d+:\d+: error(?:\([^)]*\))?: ([^\n]+)", log)
        assert len(errors) == rc, (label, errors)
        if rc:
            assert "Tactic `rfl` failed" in errors[0] and name.rsplit(".", 1)[-1] in log[log.index(errors[0]):], label
        controls[label] = {"rc": rc, "log_sha256": sha(stem.with_suffix(".log")), "source_sha256": source_hash}

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log, (side, log)
    assert "where the seal failed: 0 " in log
base_style, head_style = (
    {tuple(row) for row in read(area / f"campaign-lint-{side}.json") if row[0] != "INFO"}
    for side in ("base", "head")
)
expected_root_transitives = {
    ("FAIL", "TCSlib.lean", f"facade does not import child module `{module.replace('/', '.')}`")
    for module in moves
}
relocated_style = {}
for entry in head_style - base_style:
    level, path, message = entry
    original = moves.get(path.removesuffix(".lean"))
    if original is not None and (level, original + ".lean", message) in base_style:
        relocated_style[entry] = (level, original + ".lean", message)
assert len(relocated_style) == 1 and "lamportGen, lamportSign" in next(iter(relocated_style))[2]
assert head_style - base_style - relocated_style.keys() == expected_root_transitives

assert set(moves) <= set(plan["order"]) and "TCSlib" in checks
assert "0 findings in 11 files" in (area / "style-head.log").read_text()
assert (area / "root-style-base.log").read_bytes() == (area / "root-style-head.log").read_bytes()
save(area / "STYLE.json", {"root_transitives_confirmed_reachable": sorted(expected_root_transitives),
                            "inherited_campaign_style_findings": len(base_style & head_style) + len(relocated_style),
                            "relocated_style_reports": [{"base": old, "head": new} for new, old in sorted(relocated_style.items())],
                            "source_lint_authentication_and_hashing": 0, "root_source_lint_matches_base": True})
lwe = read(area / "LWE-SIS.json")
assert lwe["campaign_head"] == head and lwe["lwe_sis_head"] == (area / "lwe-sis.txt").read_text().strip()
assert lwe["overlap_among_new_source_paths"] == ["TCSlib/Cryptography/Hashing.lean"]
assert len(lwe["lwe_sis_leaf_sha256"]) == 8
archive_dir = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
archive = archive_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (archive_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
assert len(ledger["current_observations"]) == 813 and not ledger["partial"] and not ledger["needs_review"]
providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
             for r in decls["declarations"] if r["kind"] == "def"}
links = []
for row in ledger["current_observations"]:
    refs = {(p["home"], p["spelling"]) for p in row.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in row.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if row["channel"] == "generated-equation":
        refs.add((row["provider_home"], row["provider"]))
    if row["channel"] == "explicit-source":
        refs.add((row["head"]["provider_home"], row["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": row["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": seals,
                          "controls": controls, "new_diagnostics": 0, "warnings": {f"{side}/{label}": value for (side, label), value in warnings.items()},
                          "new_campaign_findings": 0})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                          "ledger_archive_sha256": archive_sha, "relocated_provider_links": links,
                          "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                          "generated_foreign_equation_reads": {"base": 0, "head": 0}})
print("Thirteen affected modules and campaign Checks pass. All nine owner seals report zero errors.")
print(f"Both seal and reader controls pass. Mapped {len(links)} deferred provider links.")
