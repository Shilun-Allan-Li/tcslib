"""Archive the exact signature and hashing verification and stage the records-only update."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

area, root, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
stage = area / "records"
slug = "authentication-signatures-hashing-2026-11-09"
dest = stage / slug
native = area / "native"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args, cwd=root):
    return subprocess.check_output(["git", *args], cwd=cwd)


pr = read(area / "pr-live.json")
source = read(area / "SOURCE-CHECK.json")
decls = read(area / "DECLARATIONS.json")
seals = read(area / "SEALS.json")
reads = read(area / "READS.json")
plan, result = (read(native / (name + ".json")) for name in ("PLAN", "RESULT"))
base, head = result["base"], result["head"]
assert result["passed"] and result["fresh_native_checks"] == 14
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert seals["passed"] and seals["new_diagnostics"] == 0
assert all(row["base"] == base and row["head"] == head for row in (decls, seals, reads))
assert decls["matched_declarations"] == decls["relocated_declarations"] == 214
assert pr["headRefOid"] == source["head"] == head == git("rev-parse", "HEAD").decode().strip()
assert pr["baseRefName"] == "cryptography/pass-shelat-ch2-4"
assert pr["headRefName"] == "codex/pass-shelat-signatures-hashing"
assert pr["state"] == "OPEN" and not pr["isDraft"]
assert pr["mergeStateStatus"] == "CLEAN" and pr["mergeable"] == "MERGEABLE"
assert set(row["path"] for row in pr["files"]) == {name + ".lean" for name in source["changed_paths"]}
assert git("rev-parse", "HEAD", cwd=campaign).decode().strip() == base
assert git("rev-parse", base + "~1^2").decode().strip() == source["baseline"]
assert not git("status", "--porcelain", cwd=campaign)

paths = {
    "base.txt", "head.txt", "predecessor.txt", "contracts.txt", "lwe-sis.txt", "authentication-signatures-hashing.patch",
    "prepare_replay.py", "prepare_probes.py", "prepare_seals.py", "run_probes.sh",
    "pack_review.py", "compare_declarations.py", "scan_relocation.py", "check_evidence.py", "lint.py",
    "style-head.log", "style-base.log", "campaign-lint-base.json", "campaign-lint-head.json",
    "MOVE-SCOPE.json", "SOURCE-CHECK.json", "DECLARATIONS.json", "SEALS.json", "READS.json",
    "pr-body.md", "pr-live.json", "CONTRACTS.json", "STYLE.json", "LWE-SIS.json",
    "root-style-base.log", "root-style-head.log", "native/PLAN.json", "native/PRODUCTS.json", "native/RESULT.json",
}
for pattern in ("native/run-*/*", "metadata/*", "metadata/*-seals/*", "read-scan/**/*"):
    paths.update(path.relative_to(area).as_posix() for path in area.glob(pattern) if path.is_file())
dest.mkdir(parents=True)
archive = dest / "authentication-signatures-hashing-checks.zip"
snapshots = {}
with ZipFile(archive, "x", ZIP_DEFLATED) as packed:
    for name in sorted(paths):
        packed.write(area / name, name)
    for side, revision in (("base", base), ("head", head)):
        for module in source["changed_paths"]:
            if side == "base" and module in source["new_owners"]:
                continue
            filename = module + ".lean"
            name = f"source/{side}/{filename}"
            raw = git("show", f"{revision}:{filename}")
            snapshots[name] = sha256(raw).hexdigest()
            packed.writestr(name, raw)
hashes = {name: sha(area / name) for name in sorted(paths)}
with ZipFile(archive) as packed:
    assert set(packed.namelist()) == hashes.keys() | snapshots.keys()
    for name, expected in (hashes | snapshots).items():
        with packed.open(name) as stream:
            assert file_digest(stream, "sha256").hexdigest() == expected, name
receipt = {
    "base": base, "head": head, "passed": True, "pr": pr,
    "affected_modules": len(plan["affected"]), "fresh_native_checks": result["fresh_native_checks"],
    "verified_unchanged_transfers": result["initial_retained"], "verified_external_objects": len(plan["external"]),
    "matched_declarations": decls["matched_declarations"], "relocated_declarations": decls["relocated_declarations"],
    "seal_receipts": seals["receipts"], "new_seal_diagnostics": seals["new_diagnostics"],
    "admission_dependencies": decls["admission_dependencies"],
    "relocated_provider_links": len(reads["relocated_provider_links"]),
    "artifact_sha256": hashes, "snapshot_sha256": snapshots,
    "archive": {"name": archive.name, "sha256": sha(archive)},
}
(dest / "VERIFICATION.json").write_text(json.dumps(receipt, indent=2) + "\n")
(dest / "READS.json").write_bytes((area / "READS.json").read_bytes())
number, url = pr["number"], pr["url"]
lwe = read(area / "LWE-SIS.json")
contracts = read(area / "CONTRACTS.json")
(dest / "README.md").write_text(f"""# Signature and hashing relocation

The campaign base `{base}` includes Seyoon's merge of #278. Its Lean and checker
inputs match the verified PRF-MAC head `{source['baseline']}`.

[PR #{number}]({url}) at `{head}` completes the authentication and hashing
layout in two commits. The contract commit `{contracts['commit']}` moves the
signature and collision-resistant hash interfaces and games. All three
contract files and their import closures match the checked head byte for
byte. The construction commit moves Lamport signatures, hash-and-sign and the
discrete-log hash. The authentication and hashing facades index the resulting
routes. The original import paths preserve their transitive exports.

- All thirteen affected modules and campaign Checks pass. The replay verified
  1,105 unchanged local objects and 3,810 external objects.
- All 214 original declarations match, including their definition values and
  axiom dependencies. The collision game now emits a local coin-space proof
  with the same type, body and axioms as its former shared helper. The old
  import bundle and the canonical import bundle expose the same checked types.
- All four baseline and five relocated whole-file seals pass. The controls
  block direct reduction of signature one-time security and hash evaluation
  and accept their published equations. The explicit and generated foreign
  definition read scans pass.
- The eleven authentication and hashing files pass source lint. The root
  source lint matches its baseline. The campaign linter's existing Lamport
  report follows the moved machine abbreviations. Its five additional root
  reports concern modules reachable through the facades, as verified by the
  import graph and the native root check.

The existing admissions are `lamport_oneTimeSecure`,
`hashAndSign_oneTimeSecure` and `dlHash_crh`. The
`exists_oneTimeSecure_of_crh_owf` corollary still depends on the first two.
The collision game's padding, splitting and membership tests are verbatim.

The LWE/SIS branch at `{lwe['lwe_sis_head']}` has its own eight SIS modules and
imports `Hashing.SIS` from the same facade path. When reconciling the branches,
use one `Hashing.lean` with imports of `Hashing.CollisionResistant`,
`Hashing.FromDiscreteLog` and `Hashing.SIS`. The source-path and import
comparison is archived in `LWE-SIS.json`. Future SIS consumers can use the
preserved `Authentication.CRH` contract and its collision parser.

The cleanup ledger was compared against the relocated providers.
[Ledger comparison](READS.json)

`{archive.name}` has SHA-256 `{receipt['archive']['sha256']}`.
[Verification hashes](VERIFICATION.json)

**Clear to merge — declarations, legacy imports, the affected modules and seals pass.**
""")

briefs = campaign / "briefs/pass-shelat-ch5-8"
updates = {}
handoff = briefs / "MAINTAINER-HANDOFF.md"
original = handoff.read_text()
anchor = "[PRF-MAC relocation verification](maintainer/authentication-mac-from-prf-2026-11-09/README.md)."
assert original.count(anchor) == 1
updates[handoff] = original.replace(anchor, anchor + " " + (
    f"[PR #{number}]({url}) at `{head}` completes the signature and hashing moves in two commits, "
    "with the existing namespaces and import paths preserved. All thirteen affected modules, campaign Checks "
    "and nine seals pass. The census matches 214 declarations and verifies the collision game's re-emitted "
    "coin-space proof. The LWE/SIS facade reconciliation is recorded. "
    f"It is clear for Seyoon to merge. [Signature and hashing verification](maintainer/{slug}/README.md)."
))
decision = campaign / "PassShelatChapter5-8Plan.md"
original = decision.read_text()
assert original.rstrip().splitlines()[-1].startswith("| 2026-11-09 (PST) | **#278 merged.**")
updates[decision] = original.rstrip() + "\n" + (
    f"| 2026-11-09 (PST) | **Signature and hashing moves verified.** [PR #{number}]({url}) at `{head}` "
    "relocates the signature and CRH contracts, Lamport, hash-and-sign and the discrete-log hash in two commits. "
    "The old imports are compatible. Thirteen affected modules, campaign Checks, both import probes and nine "
    "seals pass. The census matches 214 declarations. The shared hashing facade reconciliation is recorded. "
    f"[Verification](briefs/pass-shelat-ch5-8/maintainer/{slug}/README.md). Seyoon merges this slice. | record |\n"
)
cleanup = briefs / "CLEANUP-PLAN.md"
original = cleanup.read_text()
anchor = "## 3. Close the inherited seal ledger on the new layout"
assert original.count(anchor) == 1 and "### Authentication and hashing" not in original
updates[cleanup] = original.replace(anchor, f"""### Authentication and hashing

`Authentication.lean` indexes the MAC and signature constructions. `MAC/Defs`
owns the MAC interface and game, and `MAC/FromPRF` owns the PRF-based
construction. `Authentication/Encoding` supplies the shared encodings.

[PR #{number}]({url}) puts the signature interface and games in
`Authentication/Signatures/Defs`, with `Lamport` and `HashAndSign` next to
them. `Hashing.lean` indexes `Hashing/CollisionResistant` and
`Hashing/FromDiscreteLog`. The existing Lean names and compatibility
imports are preserved. Hash-and-sign consumes the CRH interface and states
the full-domain and digest-width conditions on that route.

The LWE/SIS campaign owns `Hashing/SIS`. On branch reconciliation, keep
`Hashing.CollisionResistant`, `Hashing.FromDiscreteLog` and `Hashing.SIS`
in the shared hashing facade. The Pass–shelat `Authentication.CRH` contract
and collision parser provide the future bridge's interface.
[Verification and branch comparison](maintainer/{slug}/README.md)

{anchor}""")
preimages = {}
for src, new in updates.items():
    rel = src.relative_to(campaign)
    preimages[rel.as_posix()] = sha(src)
    target = stage / "updates" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(new)
(stage / "PREIMAGES.json").write_text(json.dumps(preimages, indent=2) + "\n")
print(f"Packed {len(hashes) + len(snapshots)} verified members for PR #{number}.")
