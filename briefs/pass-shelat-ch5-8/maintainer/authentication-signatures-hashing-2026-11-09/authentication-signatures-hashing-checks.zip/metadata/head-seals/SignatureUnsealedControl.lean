import TCSlib.Cryptography.Authentication.Signatures.Defs

open Complexity TCSlib.Cryptography TCSlib.Cryptography.Games TCSlib.Cryptography.Authentication

example (S : SignatureScheme) :
    S.OneTimeSecure ↔ ∀ A : NUPPT, ∃ ε : ℕ → ℝ, Negligible ε ∧
      ∀ n, accept (S.forgeGame A 1 n) ≤ ε n := by
  rfl
