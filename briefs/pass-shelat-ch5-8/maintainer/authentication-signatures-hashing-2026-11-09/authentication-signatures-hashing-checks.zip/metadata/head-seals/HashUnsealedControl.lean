import TCSlib.Cryptography.Hashing.CollisionResistant

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Authentication

example (H : CRH) (n : ℕ) (i : List Bool) (x : Fin (H.domLen.eval n) → Bool) :
    H.hash n i x =
      padFin (H.rangeLen.eval n) (H.eval (atParam n (pairEncode i (List.ofFn x)))) := by
  rfl
