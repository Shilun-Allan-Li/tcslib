"""Compare the sealed diagnostics and checked kernel declarations."""

from hashlib import file_digest
import json
from pathlib import Path
import re
import sys

area = Path(sys.argv[1]).resolve()
meta = area / "metadata"
legacy = "TCSlib.Cryptography.Asymptotic.Pseudorandom"
owner = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs"
ensemble = "TCSlib.Cryptography.Asymptotic.Ensembles"
standard = {"Classical.choice", "propext", "Quot.sound"}


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def write(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")


def log(name):
    return (meta / (name + ".log")).read_text()


def diagnostics(text, label, canonical):
    relevant = [line for line in text.splitlines()
                if not line.startswith(("G06-", "FAIL("))]
    text = "\n".join(relevant)
    path = r"(?:[^\s:()\[\]]+/)" + re.escape(label) + r"(?=\.lean)"
    text = re.sub(path, label, text).replace(label, canonical)
    return text.strip()


def errors(text):
    return len(re.findall(r"\.lean:\d+:\d+: error:", text))


def end(text, label, n):
    assert text.count(f"G06-SEAL-END label={label} requested={n} verified={n}") == 1, label


def catalog(side, home):
    rows = [json.loads(line) for line in (meta / (side + ".jsonl")).read_text().splitlines()]
    last = rows.pop()
    assert last["record"] == "complete" and last["count"] == len(rows)
    assert last["ensembleHome"]["display"] == ensemble
    result = {}
    for row in rows:
        assert row["record"] == "constant" and row["home"]["display"] == home
        assert {item["display"] for item in row["axioms"]} <= standard
        key = tuple(tuple(part) for part in row["name"]["components"])
        assert key not in result
        row["axioms"] = sorted(row["axioms"], key=lambda item: item["display"])
        del row["home"]
        result[key] = row
    return result


old = catalog("Base", legacy)
new = catalog("Head", owner)
assert old.keys() == new.keys()
legacy_components = [["str", part] for part in legacy.split(".")]
owner_components = [["str", part] for part in owner.split(".")]


def relocate_binder_labels(expr, adjusted, path=()):
    if not isinstance(expr, list) or not expr:
        return expr
    result = [relocate_binder_labels(item, adjusted, path + (i,)) for i, item in enumerate(expr)]
    if expr[0] in ("lam", "forall", "let"):
        label = expr[1]
        components = label["components"]
        start = [i for i in range(len(components))
                 if components[i:i + len(legacy_components)] == legacy_components]
        if start:
            assert len(start) == 1
            i = start[0]
            assert ["str", "_@"] in components[:i] and ["str", "_hygCtx"] in components[i:]
            updated = {"components": components[:i] + owner_components + components[i + len(legacy_components):],
                       "display": label["display"].replace(legacy, owner, 1)}
            result[1] = updated
            adjusted.append({"path": path + (1,), "old_label": label, "new_label": updated})
    return result


label_changes = []
for key in old:
    expected = dict(old[key])
    for field in ("type", "value"):
        if expected[field] != new[key][field]:
            adjusted = []
            expected[field] = relocate_binder_labels(expected[field], adjusted)
            assert adjusted, (old[key]["name"], field)
            label_changes.append({"declaration": old[key]["name"]["display"], "field": field,
                                  "adjustments": adjusted})
    assert expected == new[key], (old[key]["name"], [k for k in expected if expected[k] != new[key][k]])
assert len({row["declaration"] for row in label_changes}) == 6
assert len(new) == 31
assert log("LegacyImport") == log("OwnerImport")
write(area / "DECLARATIONS.json", {
    "count": len(new), "old_owner": legacy, "new_owner": owner,
    "shared_ensemble_predicate_owner": ensemble,
    "compare": ["fully qualified name", "kind", "universe parameters", "kernel type", "kernel value",
                "reducibility", "instance", "matcher", "axiom dependencies"],
    "declaration_names": sorted(row["name"]["display"] for row in new.values()),
    "baseline_catalog_sha256": sha(meta / "Base.jsonl"),
    "candidate_catalog_sha256": sha(meta / "Head.jsonl"),
    "legacy_and_owner_import_match": True,
    "generated_binder_module_path_changes": label_changes,
})

original, replayed = log("CleanupSeal061-baseline"), log("CleanupSeal061")
for text in (original, replayed):
    end(text, "CleanupSeal061", 1209)
    assert errors(text) == 6
before, after = (diagnostics(text, "CleanupSeal061", "Owner") for text in (original, replayed))
assert before == after, "Owner diagnostics differ after path normalization"
assert [line for line in original.splitlines() if line.startswith("G06-")] == [
    line for line in replayed.splitlines() if line.startswith("G06-")]

baseline, candidate = log("HardCoreBase"), log("HardCoreHead")
for label, module, text in (("HardCoreBase", legacy, baseline), ("HardCoreHead", owner, candidate)):
    end(text, label, 6)
    requests = json.loads((meta / (label + ".json")).read_bytes())["requested"]
    for row in requests:
        assert row["home"] == module
        assert f"actual={row['spelling']} home={module} " in text, row["spelling"]
before = diagnostics(baseline, "HardCoreBase", "HardCore")
after = diagnostics(candidate, "HardCoreHead", "HardCore")
assert before == after, "HardCore diagnostics differ after path normalization"
unsealed, sealed = log("UnsealedControl"), log("SealedControl")
assert errors(unsealed) == 0 and errors(sealed) == 1
assert "Iff.rfl" in sealed and "Type mismatch" in sealed
end(sealed, "SealedControl", 1)
write(area / "SEALS.json", {
    "owner": {"mask_count": 1209, "matched_inherited_diagnostics": 6,
              "baseline_log_sha256": sha(meta / "CleanupSeal061-baseline.log"),
              "candidate_log_sha256": sha(meta / "CleanupSeal061.log")},
    "consumer": {"path": "TCSlib/Cryptography/Asymptotic/HardCore.lean", "mask_count": 6,
                 "matched_diagnostics": errors(candidate),
                 "baseline_log_sha256": sha(meta / "HardCoreBase.log"),
                 "candidate_log_sha256": sha(meta / "HardCoreHead.log")},
    "control": {"definition": "TCSlib.Cryptography.PRG.Secure", "unsealed_errors": 0, "sealed_errors": 1},
})
print(f"{len(new)} exact declarations; six inherited owner diagnostics; "
      f"{errors(candidate)} matching focused HardCore diagnostics; control passes")
