"""Prepare native declaration comparison and the inherited owner seal."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import sys
from zipfile import ZipFile

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:])
legacy = "TCSlib.Cryptography.Asymptotic.Pseudorandom"
owner = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs"
facade = "TCSlib.Cryptography.Pseudorandom"
ensemble = "TCSlib.Cryptography.Asymptotic.Ensembles"
current = area / "native"
prior = area.parent / "pke-pilot-elgamal-20261109"
cleanup = area.parent / "cleanup-incremental-20261108"
facade_check = area.parent / "pseudorandom-facade-20261109"
records = campaign / "briefs/pass-shelat-ch5-8/maintainer"
cleanup_record = records / "cleanup-incremental-2026-11-09/final-r1"
meta = area / "metadata"
baseline = meta / "baseline"
baseline_tree = baseline / "oleans"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


def write(path, obj):
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2)
        stream.write("\n")


plan, old_plan = read(current / "PLAN.json"), read(prior / "native/PLAN.json")
old_tree = Path(old_plan["tree"])
products = read(prior / "native/PRODUCTS.json")
previous_facade = read(records / "pseudorandom-facade-2026-11-09/VERIFICATION.json")
facade_row = next(row for row in previous_facade["checks"] if row["module"] == facade.replace(".", "/"))
assert previous_facade["passed"] and previous_facade["head"] == plan["facade_baseline"]
assert old_plan["head"] == plan["baseline"]
assert not (meta / "BaseCensus.lean").exists()
baseline_tree.mkdir(parents=True)
roots = [legacy.replace(".", "/"), facade.replace(".", "/")]
modules = set()
while roots:
    module = roots.pop()
    if module not in modules:
        modules.add(module)
        roots.extend(old_plan["graph"][module])
for module in sorted(modules):
    if module == facade.replace(".", "/"):
        src = facade_check / "r2/oleans" / (module + ".olean")
        expected = facade_row["object_sha256"]
    else:
        src = old_tree / (module + ".olean")
        expected = products[module]["object_sha256"]
        raw = root / (module + ".lean")
        actual = (root / (owner.replace(".", "/") + ".lean")) if module == legacy.replace(".", "/") else raw
        assert sha(actual) == products[module]["source_sha256"], module
    copy(src, baseline_tree / (module + ".olean"), expected)
for row in old_plan["external"].values():
    path = Path(row["path"])
    if path.is_relative_to(old_tree):
        copy(path, baseline_tree / path.relative_to(old_tree), row["sha256"])
    else:
        assert sha(path) == row["sha256"], path
assert not (baseline_tree / "PFR").exists()
(baseline_tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

prefix = (prior / "metadata/Census.lean").read_text().split("/-- The same edge relation", 1)[0]
prefix = prefix.replace("import TCSlib\n", f"import {legacy}\nimport {facade}\n")
tick = chr(96)
for side, modules_list, moved in (
    ("Base", [legacy, facade], legacy),
    ("Head", [legacy, facade, owner], owner),
):
    owners = ", ".join(tick + module for module in modules_list)
    census = prefix + f"""
run_cmd do
  let owners : Array Name := #[{owners}]
  let ownerSet := owners.foldl (fun (s : NameSet) n => s.insert n) {{}}
  let env ← getEnv
  let kernel := env.checked.get
  let file ← IO.FS.Handle.mk "{meta / (side + '.jsonl')}" .write
  let emit (j : Json) : IO Unit := file.putStrLn j.compress
  for moduleName in owners do
    unless (env.getModuleIdx? moduleName).isSome do throwError "missing module {{moduleName}}"
  let some ensIdx := env.getModuleIdxFor? {tick}TCSlib.Cryptography.Ensemble.Pseudorandom
    | throwError "missing ensemble predicate"
  let ensHome := env.header.moduleNames[ensIdx.toNat]!
  unless ensHome == {tick}{ensemble} do throwError "unexpected ensemble predicate home {{ensHome}}"
  let mut count : Nat := 0
  for (n, c) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[mi.toNat]!
    unless ownerSet.contains home do continue
    unless home == {tick}{moved} do throwError "unexpected declaration {{n}} at {{home}}"
    let some ci := kernel.find? n | throwError "missing checked constant {{n}}"
    unless kind ci == kind c do throwError "checked kind differs for {{n}}"
    let status ← liftCoreM <| getReducibilityStatus n
    let matcher := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let axioms ← liftCoreM <| collectAxioms n
    emit <| Json.mkObj [("record", .str "constant"), ("name", identity n), ("home", identity home),
      ("kind", toJson (kind ci)), ("status", toJson (reprStr status)),
      ("abbrev", toJson (isAbbrev ci)), ("instance", toJson instanceFlag), ("matcher", toJson matcher),
      ("type", exprData ci.type), ("levels", names ci.levelParams.toArray),
      ("value", (ci.value? (allowOpaque := true)).map exprData |>.getD .null),
      ("axioms", names axioms)]
    count := count + 1
  emit <| Json.mkObj [("record", .str "complete"), ("count", toJson count),
    ("ensembleHome", identity ensHome)]
  logInfo m!"PRG census complete: {{count}} declarations"

end CleanupIncrement
"""
    (meta / (side + "Census.lean")).write_text(census)

checks = [
    "PRG", "PRG.Easy", "PRG.ensemble", "PRG.Secure", "PRG.ensemble_X",
    "PRG.easy_iff", "PRG.secure_iff", "PRG.Easy.samplable", "Ensemble.pseudorandom_iff_prgAdv",
]
for name, module in (("LegacyImport", legacy), ("OwnerImport", owner)):
    (meta / (name + ".lean")).write_text(
        f"import {module}\n\n" +
        "".join(f"#check TCSlib.Cryptography.{decl}\n" for decl in checks)
    )

archive_names = ("10-final-seals.zip", "11-final-read-ledger.zip")
hashes = dict((name, checksum) for checksum, name in (
    line.split() for line in (cleanup_record / "SHA256SUMS").read_text().splitlines()
))
for name in archive_names:
    assert sha(cleanup_record / name) == hashes[name], name
log_name = "final-seal-transfer-r2-lane3/run-20261109T092410841228/CleanupSeal061.log"
with ZipFile(cleanup_record / archive_names[0]) as archive:
    seal = archive.read("seals-head-final-r1/CleanupSeal061.source.txt")
    seal_meta = archive.read("seals-head-final-r1/CleanupSeal061.json")
    original_log = archive.read(log_name)
    assert seal == (cleanup / "seals-head-final-r1/CleanupSeal061.lean").read_bytes()
    assert seal_meta == (cleanup / "seals-head-final-r1/CleanupSeal061.json").read_bytes()
seal_info = json.loads(seal_meta)
assert seal_info["owner"] == legacy
assert len(seal_info["requested"]) == 1209
assert seal_info["source_sha256"] == plan["source_digests"][owner.replace(".", "/")]
(meta / "CleanupSeal061.lean").write_bytes(seal)
(meta / "CleanupSeal061.json").write_bytes(seal_meta)
(meta / "CleanupSeal061-baseline.log").write_bytes(original_log)
assert sha(meta / "CleanupSeal061.lean") == seal_info["probe_sha256"]

with ZipFile(cleanup_record / archive_names[1]) as archive:
    data = json.loads(archive.read("deferred-read-ledger-final-r1.json"))
rows = data["current_observations"]
owned = [row for row in rows if row["path"] == legacy.replace(".", "/") + ".lean"]
assert Counter(row["channel"] for row in owned) == {"whole-file-seal": 6, "explicit-source": 1}
maps = []
for row in owned:
    if row["channel"] == "whole-file-seal":
        assert sha(meta / "CleanupSeal061-baseline.log") == row["head_log_sha256"]
        line, source_line = row["head_line"], row["head_source"]
    else:
        line, source_line = row["head"]["line"], row["head"]["source"]
    path = owner.replace(".", "/") + ".lean"
    assert (root / path).read_text().splitlines()[line - 1].rstrip() == source_line.rstrip()
    maps.append({"id": row["id"], "channel": row["channel"], "old_path": row["path"],
                 "new_path": path, "line": line, "source": source_line})
providers = []
for row in rows:
    provider_names = sorted({
        pair["head"]["spelling"] for pair in row.get("provider_pairs", [])
        if pair.get("head") and pair["head"]["home"] == legacy
    })
    if provider_names:
        providers.append({"id": row["id"], "path": row["path"], "line": row["head_line"],
                          "names": provider_names, "old_home": legacy, "new_home": owner})
assert len(providers) == 3
write(area / "READS.json", {"ledger_head": data["head"], "ledger_archive_sha256": hashes[archive_names[1]],
                           "relocated_observations": maps, "relocated_provider_links": providers})
write(meta / "BASE-INPUTS.json", {"checked_prg_base": plan["base"],
                                  "checked_facade": previous_facade["head"],
                                  "local_objects": len(modules),
                                  "seal_archive_sha256": hashes[archive_names[0]]})
print(f"Prepared {len(modules)} baseline objects, declaration census, and inherited seal", flush=True)
