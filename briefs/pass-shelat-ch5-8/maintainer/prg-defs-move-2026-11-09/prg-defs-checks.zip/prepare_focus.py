"""Prepare paired consumer seals and a control for the moved definitions."""

from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
area, root = (Path(arg).resolve() for arg in sys.argv[1:])
meta = area / "metadata"
legacy = "TCSlib.Cryptography.Asymptotic.Pseudorandom"
owner = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs"
facade = "TCSlib.Cryptography.Pseudorandom"
consumer = "TCSlib/Cryptography/Asymptotic/HardCore"
previous = area.parent / "pke-pilot-elgamal-20261109/native"
review = area.parent / "gate06-combined-20261108"
tools = review / "rule10-evidence-r2/tool-inputs"
native = area / "native"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    if dst.is_file():
        assert sha(dst) == expected, dst
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        assert sha(dst) == expected and not dst.samefile(src), dst


bs = load(tools / "build_seals.py", "checked_seals")
controls = load(tools / "build_controls.py", "checked_controls")
adapter = load(tools / "request_payload_adapter.py", "checked_adapter")
bound = load(review / "rule10-payload-retry-r3/bound_payload.py", "checked_bound")
adapter.configure_builders(bs, controls)
seal = bs.seal_command
bs.seal_command = lambda label, rows, *, end: bound.bound_payloads(seal(label, rows, end=end))

base = read(previous / "PLAN.json")
head = read(native / "PLAN.json")
base_products = read(previous / "PRODUCTS.json")
head_products = dict(head["retained"])
for path in sorted(native.glob("run-*/check-*.json")):
    row = read(path)
    if row["rc"] == 0:
        assert row["head"] == head["head"]
        assert sha(path.with_suffix(".log")) == row["log_sha256"]
        head_products[row["module"]] = row


def needed(plan, roots):
    seen = set()
    todo = list(roots)
    while todo:
        name = todo.pop()
        if name not in seen:
            seen.add(name)
            todo.extend(plan["graph"][name])
    return sorted(seen)


baseline = meta / "baseline/oleans"
candidate = meta / "candidate/oleans"
assert (meta / "BaseCensus.rc").read_text() == "0\n"
assert (meta / "CleanupSeal061.rc").read_text() == "1\n"
candidate.mkdir(parents=True)
for side, plan, products, dest, roots in (
    ("Base", base, base_products, baseline, base["graph"][consumer]),
    ("Head", head, head_products, candidate, head["graph"][consumer] +
     [legacy.replace(".", "/"), facade.replace(".", "/"), owner.replace(".", "/")]),
):
    src = Path(plan["tree"])
    for mod in needed(plan, roots):
        row = products[mod]
        assert row["source_sha256"] == plan["source_digests"][mod], mod
        assert row["direct_local"] == {
            dep: products[dep]["object_sha256"] for dep in plan["graph"][mod]
        }, mod
        copy(src / (mod + ".olean"), dest / (mod + ".olean"), row["object_sha256"])
    for row in plan["external"].values():
        path = Path(row["path"])
        if path.is_relative_to(src):
            copy(path, dest / path.relative_to(src), row["sha256"])
        else:
            assert sha(path) == row["sha256"], path
    if not (dest / "PFR").is_symlink():
        (dest / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

catalog = [json.loads(line) for line in (meta / "Base.jsonl").read_text().splitlines()]
moved = [row for row in catalog if row["record"] == "constant" and row["kind"] == "def"
         and (row["status"].endswith(".semireducible") or row["matcher"])]
assert {row["name"]["display"] for row in moved} >= {
    "TCSlib.Cryptography.PRG.Easy", "TCSlib.Cryptography.PRG.Secure", "TCSlib.Cryptography.PRG.ensemble",
}


def names_for(module):
    return sorted([{
        "spelling": row["name"]["display"], "home": module, "matcher": row["matcher"],
        "collector_reducibility": row["status"].rsplit(".", 1)[-1],
        "instance": row["instance"], "abbrev": row["abbrev"],
        "name_components": row["name"]["components"],
        "home_components": [["str", part] for part in module.split(".")], "constant_kind": "def",
    } for row in moved], key=lambda row: row["spelling"])


def instrument(raw, label, requests):
    probe, insertions, lines = bs.instrument(raw, bs.header(raw), label, requests)
    target = meta / (label + ".lean")
    target.write_bytes(probe)
    (meta / (label + ".json")).write_text(json.dumps({
        "label": label, "requested": requests, "probe_sha256": sha(target),
        "insertions": insertions, "line_map": lines,
    }, indent=2) + "\n")


source = root / (consumer + ".lean")
assert sha(source) == base["source_digests"][consumer] == head["source_digests"][consumer]
for label, module in (("HardCoreBase", legacy), ("HardCoreHead", owner)):
    instrument(source.read_bytes(), label, names_for(module))

control = f"""import {owner}

open TCSlib.Cryptography

example (P : PRG) : P.Secure ↔ P.Easy ∧ P.ensemble.Pseudorandom :=
  Iff.rfl
"""
(meta / "UnsealedControl.lean").write_text(control)
request = [row for row in names_for(owner) if row["spelling"] == "TCSlib.Cryptography.PRG.Secure"]
assert len(request) == 1
instrument(control.encode(), "SealedControl", request)
print(f"Paired HardCore seals prepared for {len(moved)} relocated definitions", flush=True)
