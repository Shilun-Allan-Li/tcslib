"""Pin the PRG relocation and invalidate every transitive consumer."""

from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:])
tools = area.parent / "cleanup-incremental-20261108/tools"
previous = area.parent / "pke-pilot-elgamal-20261109/native"
records = campaign / "briefs/pass-shelat-ch5-8/maintainer"
out = area / "native"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location("checked_import_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
base = (area / "base.txt").read_text().strip()
head = (area / "head.txt").read_text().strip()
legacy = "TCSlib/Cryptography/Asymptotic/Pseudorandom"
facade = "TCSlib/Cryptography/Pseudorandom"
owner = facade + "/Generators/Asymptotic/Defs"
checks = "audits/pass-shelat/Checks"
changed = {facade, legacy, owner}


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def git_text(*args):
    return git(*args).decode().strip()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


def write(path, obj):
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2)
        stream.write("\n")


assert git_text("rev-parse", "HEAD") == head and git_text("rev-parse", "HEAD^") == base
assert not git_text("status", "--porcelain")
assert set(git_text("diff", "--name-only", base, head).splitlines()) == {
    module + ".lean" for module in changed
}
old_plan = read(previous / "PLAN.json")
old_products = read(previous / "PRODUCTS.json")
verified = read(records / "pke-pilot-elgamal-2026-11-09/VERIFICATION.json")
facade_receipt = read(records / "pseudorandom-facade-2026-11-09/VERIFICATION.json")
result = read(previous / "RESULT.json")
assert verified["passed"] and result["passed"] and facade_receipt["passed"]
assert verified["head"] == old_plan["head"] == result["head"]
assert facade_receipt["changed_imports"] == facade_receipt["changed_lean_commands"] == 0
for name in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / name) == verified["artifact_sha256"]["native/" + name], name
assert git_text("diff", "--name-only", old_plan["head"], base, "--", "*.lean",
                "lean-toolchain", "lake-manifest.json", "lakefile.lean",
                "lakefile.toml", "scripts/lean_check_tree.sh") == facade + ".lean"
assert sha256(git("show", f"{base}:{facade}.lean")).hexdigest() == facade_receipt["source_sha256"]
assert sha(Path(old_plan["toolchain"])) == old_plan["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == old_plan["checker_sha256"]

sources = {
    path[:-5]: (root / path).read_bytes()
    for path in git_text("ls-files", "--", "TCSlib", "TCSlib.lean", checks + ".lean").splitlines()
    if path.endswith(".lean")
}
assert set(sources) == set(old_plan["source_digests"]) | {owner}
assert sources[owner] == git("show", f"{base}:{legacy}.lean")
source_digests = {module: sha256(raw).hexdigest() for module, raw in sources.items()}
assert source_digests[owner] == old_plan["source_digests"][legacy]
for module in sources.keys() - changed:
    assert source_digests[module] == old_plan["source_digests"][module], module
imports = {
    module: [name.replace(".", "/") for name in graph.imports(raw)
             if name.replace(".", "/") in sources]
    for module, raw in sources.items()
}
assert imports[owner] == old_plan["graph"][legacy]
assert imports[legacy] == [owner]
assert [dep for dep in imports[facade] if dep != owner] == old_plan["graph"][facade]
assert imports[facade].count(owner) == 1
for module in old_plan["graph"].keys() - changed:
    assert imports[module] == old_plan["graph"][module], module
order = graph.topo(imports, ["TCSlib", checks])
assert set(order) == set(old_plan["order"]) | {owner}
affected = changed.copy()
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
assert {"TCSlib", checks, owner, legacy, facade} <= affected
rebuild = [module for module in order if module in affected]
assert len(rebuild) == 73
old_tree = Path(old_plan["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
for module in order:
    if module in affected:
        continue
    row = old_products[module]
    direct = {dep: retained[dep]["object_sha256"] for dep in imports[module]}
    assert source_digests[module] == row["source_sha256"] and direct == row["direct_local"], module
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {"source_sha256": row["source_sha256"], "object_sha256": row["object_sha256"],
                        "direct_local": direct, "source": "verified_elgamal_tree"}
external = {}
for name, row in old_plan["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        target = tree / path.relative_to(old_tree)
        copy(path, target, row["sha256"])
        path = target
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": old_plan["head"],
    "facade_baseline": facade_receipt["head"], "worktree": str(root), "tree": str(tree),
    "toolchain": old_plan["toolchain"], "toolchain_sha256": old_plan["toolchain_sha256"],
    "checker_sha256": old_plan["checker_sha256"], "affected": sorted(affected), "rebuild": rebuild,
    "order": order, "retained": retained, "graph": {module: imports[module] for module in order},
    "external": external, "source_digests": source_digests,
}
write(out / "PLAN.json", plan)
write(area / "SOURCE-CHECK.json", {
    "base": base, "head": head, "old_owner": legacy, "new_owner": owner,
    "moved_source_sha256": source_digests[owner], "changed_paths": sorted(changed),
    "old_and_new_owner_source_identical": True, "consumers_rechecked": len(rebuild),
    "unchanged_lean_paths": len(sources) - len(changed), "verified_external_objects": len(external),
    "predecessor_verification_sha256": sha(records / "pke-pilot-elgamal-2026-11-09/VERIFICATION.json"),
    "facade_verification_sha256": sha(records / "pseudorandom-facade-2026-11-09/VERIFICATION.json"),
})
print(f"{len(retained)} retained objects, {len(external)} external objects, "
      f"{len(rebuild)} modules to check", flush=True)
