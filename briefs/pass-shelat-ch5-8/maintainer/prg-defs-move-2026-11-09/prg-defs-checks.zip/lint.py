from pathlib import Path
import importlib.util, json, sys

sys.dont_write_bytecode = True
root = Path.cwd()
spec = importlib.util.spec_from_file_location("campaign_style_lint", root / "scripts/campaign_style_lint.py")
lint = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lint)
paths = [
    "Asymptotic/Pseudorandom.lean",
    "Pseudorandom.lean",
    "Pseudorandom/Generators.lean",
    "Pseudorandom/Generators/Asymptotic/Defs.lean",
]
for path in paths:
    file = root / "TCSlib/Cryptography" / path
    if file.is_file():
        lint.check_file(file)
        if lint.is_facade(file):
            lint.check_facade(file)
print(json.dumps(lint.findings, indent=2))
