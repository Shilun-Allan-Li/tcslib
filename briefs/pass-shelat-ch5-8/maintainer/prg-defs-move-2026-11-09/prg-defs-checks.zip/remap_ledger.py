"""Prepare native declaration comparison and the inherited owner seal."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import sys
from zipfile import ZipFile

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:])
legacy = "TCSlib.Cryptography.Asymptotic.Pseudorandom"
owner = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs"
facade = "TCSlib.Cryptography.Pseudorandom"
ensemble = "TCSlib.Cryptography.Asymptotic.Ensembles"
current = area / "native"
prior = area.parent / "pke-pilot-elgamal-20261109"
cleanup = area.parent / "cleanup-incremental-20261108"
facade_check = area.parent / "pseudorandom-facade-20261109"
records = campaign / "briefs/pass-shelat-ch5-8/maintainer"
cleanup_record = records / "cleanup-incremental-2026-11-09/final-r1"
meta = area / "metadata"
baseline = meta / "baseline"
baseline_tree = baseline / "oleans"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


def write(path, obj):
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2)
        stream.write("\n")


archive_names = ("10-final-seals.zip", "11-final-read-ledger.zip")
hashes = dict((name, checksum) for checksum, name in (
    line.split() for line in (cleanup_record / "SHA256SUMS").read_text().splitlines()
))
for name in archive_names:
    assert sha(cleanup_record / name) == hashes[name], name
with ZipFile(cleanup_record / archive_names[1]) as archive:
    data = json.loads(archive.read("deferred-read-ledger-final-r1.json"))
rows = data["current_observations"]
owned = [row for row in rows if row["path"] == legacy.replace(".", "/") + ".lean"]
assert Counter(row["channel"] for row in owned) == {"whole-file-seal": 6, "explicit-source": 1}
maps = []
for row in owned:
    if row["channel"] == "whole-file-seal":
        assert sha(meta / "CleanupSeal061-baseline.log") == row["head_log_sha256"]
        line, source_line = row["head_line"], row["head_source"]
    else:
        line, source_line = row["head"]["line"], row["head"]["source"]
    path = owner.replace(".", "/") + ".lean"
    assert (root / path).read_text().splitlines()[line - 1].rstrip() == source_line.rstrip()
    maps.append({"id": row["id"], "channel": row["channel"], "old_path": row["path"],
                 "new_path": path, "line": line, "source": source_line})
providers = []
for row in rows:
    provider_names = sorted({
        pair["head"]["spelling"] for pair in row.get("provider_pairs", [])
        if pair.get("head") and pair["head"]["home"] == legacy
    })
    native_refs = sorted({ref["spelling"] for ref in row.get("common_sealed_native_references", []) if ref["home"] == legacy})
    if provider_names or native_refs:
        providers.append({"id": row["id"], "path": row["path"], "line": row["head_line"],
                          "paired_providers": provider_names, "native_reference_names": native_refs, "old_home": legacy, "new_home": owner})
assert len(providers) == 3
write(area / "READS.json", {"ledger_head": data["head"], "ledger_archive_sha256": hashes[archive_names[1]],
                           "relocated_observations": maps, "relocated_provider_links": providers})
