"""Move the original asymptotic PRG contract intact and update its entry points."""

from pathlib import Path

crypto = Path("TCSlib/Cryptography")
old = crypto / "Asymptotic/Pseudorandom.lean"
new = crypto / "Pseudorandom/Generators/Asymptotic/Defs.lean"
facade = crypto / "Pseudorandom.lean"
text = old.read_bytes()
start = text.index(b"import ")
assert text.count(b"structure PRG where") == 1 and not new.exists()
new.parent.mkdir(parents=True, exist_ok=True)
new.write_bytes(text)
old.write_bytes(text[:start] + b"""import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Asymptotic pseudorandomness compatibility import

## Main definitions

`TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs` defines the asymptotic
generator interface and its efficiency and security predicates.

## Main results

This import exposes the characterization of ensemble pseudorandomness by negligible
PRG advantage and the generator's security and sampling lemmas.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Definitions 74.1 and 77.1.)
-/
""")
text = facade.read_text()
edits = [
    ("import TCSlib.Cryptography.Pseudorandom.Generators\n",
     "import TCSlib.Cryptography.Pseudorandom.Generators\n"
     "import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs\n"),
    ("`TCSlib.Cryptography.prfAdv` compares a keyed oracle with a random function.\n",
     "`TCSlib.Cryptography.prfAdv` compares a keyed oracle with a random function.\n"
     "`TCSlib.Cryptography.PRG` describes a length-regular generator.\n"),
    ("  [Gar26, Definition 3.5 and Theorem 3.1].\n",
     "  [Gar26, Definition 3.5 and Theorem 3.1].\n"
     "* `Generators.Asymptotic.Defs` gives the length-regular PRG interface and security\n"
     "  contract [PS10, Definition 77.1].\n"),
    ("  supplies the shared ensemble model. `TCSlib.Cryptography.Asymptotic.Pseudorandom`\n"
     "  defines `TCSlib.Cryptography.Ensemble.Pseudorandom` and `TCSlib.Cryptography.PRG.Secure`,\n"
     "  which packages efficiency and pseudorandomness.\n",
     "  defines `TCSlib.Cryptography.Ensemble.Pseudorandom` in the shared ensemble model.\n"
     "  `TCSlib.Cryptography.Ensemble.pseudorandom_iff_prgAdv` in\n"
     "  `TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs` characterizes it by\n"
     "  negligible concrete PRG advantage. `TCSlib.Cryptography.PRG.Secure` packages efficiency\n"
     "  and pseudorandomness for a generator.\n"),
]
for before, after in edits:
    assert text.count(before) == 1, before
    text = text.replace(before, after)
facade.write_text(text)
