## Change

Move the asymptotic PRG contract into `TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs` byte-for-byte. The previous import re-exports the module for existing callers. The pseudorandomness entry point imports the new owner and points readers to the shared module that defines ensemble pseudorandomness.

## Verification

- All 73 affected modules pass the campaign's one-module checks, including the library root and Checks. The replay verifies 1,013 retained objects.
- Standalone probes for the old and new imports expose the same interface. The census matches all 31 names, types, values and axiom dependencies after accounting for the module path in generated binder labels.
- The whole-file seal verifies 1,209 masks and reproduces six inherited diagnostics. Both focused HardCore seals pass. The PRG security control passes unsealed and fails at the intended step when sealed.
- The plain style check has zero findings. The campaign linter flags the finite `Generators.lean` file as a facade because of the matching directory name. The actual facade imports the new module. The requested reverse edge would create a cycle.

The cleanup ledger records the moved diagnostics and provider references. The next source slice is the finite and asymptotic next-bit split.
