#!/usr/bin/env bash
set -euo pipefail
area=$1
tree=$2
shift 2
toolchain=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$area/native/PLAN.json")
probe="$area/metadata"
for name in "$@"; do
  /usr/bin/memory_pressure -Q > "$probe/$name.resources.txt"
  python3 -I - "$probe/$name.resources.txt" <<'PY'
from pathlib import Path
import re,sys
text=Path(sys.argv[1]).read_text()
total=int(re.search(r'system has (\d+)',text)[1])
percent=int(re.search(r'memory free percentage:\s*(\d+)%',text)[1])
assert total*(percent-1)//100 >= 4*1024**3
PY
  module="$probe/$name"
  test ! -e "$module.log"
  set +e
  env -u LEAN_PATH -u LEAN_SRC_PATH -u LEAN_SYSROOT -u LEAN_OPTS -u ELAN_TOOLCHAIN -u PFR_BOOTSTRAP_CONFIG \
    TCSLIB_OLEANS="$tree" PATH="${toolchain%/*}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
    bash scripts/lean_check_tree.sh "${module#"$PWD"/}" > "$module.log" 2>&1
  rc=$?
  set -e
  printf '%s\n' "$rc" > "$module.rc"
  case "$name" in
    CleanupSeal061|SealedControl) test "$rc" -eq 1 ;;
    HardCoreBase|HardCoreHead) test "$rc" -le 1 ;;
    *) if [ "$rc" -ne 0 ]; then tail -20 "$module.log"; exit "$rc"; fi ;;
  esac
  printf 'Checked %s (status %s)\n' "$name" "$rc"
done
