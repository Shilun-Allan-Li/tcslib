import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs

open TCSlib.Cryptography

example (P : PRG) : P.Secure ↔ P.Easy ∧ P.ensemble.Pseudorandom :=
  Iff.rfl
