#!/usr/bin/env python3
"""Bounded independent data checks of returned C audit; no native/delivered-code execution."""
from pathlib import Path
from collections import Counter
import hashlib, io, json, re, subprocess, zipfile, csv, ast
R=Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
E=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-exchange')
O=R/'.lake/ps-maintainer/gate06c-20261108/dependency-screen'
H='3f6db40e1688c4a0bb922c9575dd3bd2157a650b'; B='eee107e92a7db11f1f8c98a5c2867304f57ddc54'
REC='c81baa7712ab1b43357276ef5df138d02616c9d0'; EX='5928e06c02b382b63b9b384db89d0458b520f351'
def sh(b): return hashlib.sha256(b).hexdigest()
def show(repo,ref,path): return subprocess.check_output(['git','show',ref+':'+path],cwd=repo)
def out(name,x): (O/name).write_text(json.dumps(x,indent=2)+'\n')
report=R/'.lake/ps-maintainer/gate06c-20261108/gate06C-r1-findings.md'; rb=report.read_bytes()
inv=json.loads((O/'source-inventory.json').read_text()); smap={x['path']:x for x in inv['sources']}
cand=json.loads((O/'candidate-intersections.json').read_text())
mp='briefs/pass-shelat-ch5-8/gates/06-ch5-8-statements/06C-source-manifest.json'
mb=show(R,REC,mp); mf=json.loads(mb); assert mf['head']==H and mf['base']==B
for x in mf['files']:
 assert x['revision']==H and x['sha256']==smap[x['path']]['sha256'] and x['bytes']==smap[x['path']]['bytes'],x
primary='TCSlib/Cryptography/Composability.lean'; pending=[primary]; closure=set()
while pending:
 p=pending.pop()
 if p in closure: continue
 closure.add(p); pending.extend(i['path'] for i in smap[p]['imports'] if i['path'] is not None)
assert len(closure)==170 and {x['path'] for x in mf['files']}==closure|{'TCSlib.lean'}
for module, names in mf['module_import_edges'].items():
 path=module.replace('.','/')+'.lean'; expected=[x['module'] for x in smap[path]['imports'] if x['path'] is not None]
 assert names==expected,(module,names,expected)

# Read the two exact assigned packs, their checksums, and only the common archive as data.
packs={}; checks=[]
for d in ('06C-r1-gate','06-common-r1-gate'):
 base='outbox/gates/'+d+'/'
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',EX,base],cwd=E,text=True).splitlines()
 packs[d]={p[len(base):]:show(E,EX,p) for p in paths}
 for line in packs[d]['SHA256SUMS'].decode().splitlines():
  if not line.strip(): continue
  h,name=line.split(None,1); name=name.strip().lstrip('*'); assert name in packs[d],name
  assert sh(packs[d][name])==h,(d,name)
  checks.append({'pack':d,'name':name,'sha256':h})
assert packs['06C-r1-gate']['gate06C-source-manifest.json']==mb
for name,h in {
 'gate06C-source-bundle.md':'15dfbca8d2d255b5b31bd71393a8c87bd7b88946cd46c9a3a2ff32a65a34654b',
 'gate06C-records-bundle.md':'bbe2dd42b94e591abdb7976f19c60473d48f4000dba8962d881e73bd041be7c0'}.items(): assert sh(packs['06C-r1-gate'][name])==h
zbytes=packs['06-common-r1-gate']['gate06-common-evidence.zip']; assert sh(zbytes)=='960ab0c708c9efdd9a5ef01175889afa0b97be0984e35ace25f4001265ee0749'
z=zipfile.ZipFile(io.BytesIO(zbytes)); assert len(z.namelist())==len(set(z.namelist()))
rows=list(csv.DictReader(io.StringIO(packs['06-common-r1-gate']['ZIP-CONTENTS.tsv'].decode()),delimiter='\t'))
# Do not assume a TSV field spelling: require its three exact semantic fields.
assert set(rows[0])=={'revision','path','bytes','sha256'},set(rows[0])
assert {x['revision'] for x in rows}=={REC}
assert set(x['path'] for x in rows)==set(z.namelist())
for x in rows:
 b=z.read(x['path']); assert len(b)==int(x['bytes']) and sh(b)==x['sha256'],x['path']
assert len(rows)==3419
finalname=next(n for n in z.namelist() if n.endswith('/FINAL-SUMMARY.json'))
summary=json.loads(z.read(finalname)); assert summary['head']==H and summary['checked_base']==B
assert summary['fresh_seals']['source_failed_modules']==17
assert summary['collector']['direct_statement_admissions']==33
c_direct=[c for c in cand['candidates'] if c['prong']=='Composability']; assert len(c_direct)==13
sealsname=next(n for n in z.namelist() if n.endswith('/native-seal-runs/summary.json'))
seals=json.loads(z.read(sealsname)); assert seals['head']==H and seals['base']==B
cseals=[x for x in seals['results'] if x['module'].startswith('TCSlib.Cryptography.Composability.')]
assert len(cseals)==8
for x in cseals:
 assert x['valid_harness'] is True and x['source_failure'] is False and x['result']['error_diagnostics']==0 and x['result']['rc']==0
 logpath='briefs/'+x['log'].split('/briefs/',1)[1]; lb=z.read(logpath)
 assert sh(lb)==x['log_sha256']
 assert not re.search(rb'\.lean:\d+:\d+: error(?:\([^\n)]*\))?:',lb)
# Reuse only our independently authored lexical masker function, without running that script.
ours=ast.parse((O/'screen_dependencies.py').read_text())
ns={}; exec(compile(ast.Module(body=[n for n in ours.body if isinstance(n,ast.FunctionDef) and n.name=='mask'],type_ignores=[]),'<own lexical masker>','exec'),ns)
counts=Counter(); declarations=[]
for path in sorted(p for p in smap if p.startswith('TCSlib/Cryptography/Composability/')):
 text=show(R,H,path).decode(); masked=ns['mask'](text)
 for n,line in enumerate(masked.splitlines(),1):
  m=re.match(r'^(?:@\[[^\]]*\]\s+)*(?:(?:private|protected|noncomputable|unsafe|partial)\s+)*(def|abbrev|structure|inductive|class|theorem|lemma)\s+([^\s({\[:]+)',line)
  if m: counts[m.group(1)]+=1; declarations.append({'path':path,'line':n,'kind':m.group(1),'name':m.group(2)})
assert counts['theorem']+counts['lemma']==161,counts
assert sum(counts[k] for k in ('def','abbrev','structure','inductive','class'))==72,counts
out('c-audit-integrity-validation.json',{
 'status':'READ_ONLY_DATA_VALIDATED_NOT_NATIVE','report':str(report),'report_sha256':sh(rb),'report_bytes':len(rb),'report_lines':len(rb.splitlines()),
 'source_head':H,'base':B,'records':REC,'exchange':EX,'primary_local_closure':len(closure),'source_sections':len(mf['files']),
 'all_source_manifest_rows_match_exact_Git_inventory':True,'all_import_edges_match':True,
 'checksums_verified':checks,'archive_entry_hashes_verified':len(rows),'archive_sha256':sh(zbytes),
 'Composability_direct_sorry_targets':len(c_direct),'explicit_declaration_counts':dict(counts),'explicit_declarations':declarations,'eight_Composability_valid_source_pass_receipts':cseals,'common_summary':summary,
 'limits':['No received script imported/executed; no Lean/native/cache/app call.','No new primary-source access or independent verification of auditor finite transcriptions.','Does not independently repeat the complete mathematical proof or every source-version comparison.']})
print('DATA_VALIDATIONS_PASS', len(rows), 'archive entries;',dict(counts),'; eight Composability source-pass receipts')
