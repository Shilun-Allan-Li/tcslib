#!/usr/bin/env python3
"""Independent read-only exact-Git import screen. Never imports delivered code or runs Lean."""
from pathlib import Path
from collections import Counter, deque
import hashlib, json, re, subprocess

ROOT=Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
REF='3f6db40e1688c4a0bb922c9575dd3bd2157a650b'
ROLE=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/inputs/role-manifest.json')
OUT=ROOT/'.lake/ps-maintainer/gate06c-20261108/dependency-screen'
PRONGS=('Authentication','SecureComputation','Composability','Randomness')

def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args, data=None):
    return subprocess.check_output(['git',*args],cwd=ROOT,input=data)
def emit(name, obj):
    b=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
    (OUT/name).write_bytes(b)
    return {'path':name,'sha256':sha(b),'bytes':len(b)}

def mask(text):
    """Blank nested comments and string literals without changing offsets/newlines."""
    a=list(text); i=0; depth=0; string=False; line=False
    while i<len(text):
        if line:
            if text[i]=='\n': line=False
            else: a[i]=' '
            i+=1; continue
        if depth:
            if text.startswith('/-',i): a[i:i+2]=[' ',' ']; depth+=1; i+=2
            elif text.startswith('-/',i): a[i:i+2]=[' ',' ']; depth-=1; i+=2
            else:
                if text[i]!='\n': a[i]=' '
                i+=1
            continue
        if string:
            if text[i]=='\\' and i+1<len(text):
                a[i]=' '
                if text[i+1]!='\n': a[i+1]=' '
                i+=2
            else:
                if text[i]=='"': string=False
                if text[i]!='\n': a[i]=' '
                i+=1
            continue
        if text.startswith('--',i): a[i:i+2]=[' ',' ']; line=True; i+=2
        elif text.startswith('/-',i): a[i:i+2]=[' ',' ']; depth=1; i+=2
        elif text[i]=='"': a[i]=' '; string=True; i+=1
        else: i+=1
    assert depth==0 and not string, 'unclosed comment/string'
    return ''.join(a)

assert git('rev-parse',REF+'^{commit}').decode().strip()==REF
rolebytes=ROLE.read_bytes(); roles=json.loads(rolebytes)
assert roles['ancestor']=='1aa5506f58f77c215e56d24311ec33bd931cacf1'
rolelist=roles['roles']; rc=Counter(x['role'] for x in rolelist)
assert rc=={'CONSUMER':97,'PROVIDER_ONLY':124,'CHECK_ONLY':2},rc
assert len({x['path'] for x in rolelist})==223
scope={x['path']:x for x in rolelist if x['role'] in ('CONSUMER','PROVIDER_ONLY')}
checkonly={x['path']:x for x in rolelist if x['role']=='CHECK_ONLY'}
allpaths=[p for p in git('ls-tree','-r','--name-only',REF).decode().splitlines() if p.endswith('.lean') and (p.startswith('TCSlib/') or p=='TCSlib.lean' or p.startswith('audits/'))]
# Read only exact Git objects; current checkout bytes are deliberately irrelevant.
requests=''.join(REF+':'+p+'\n' for p in allpaths).encode()
raw=git('cat-file','--batch',data=requests); offset=0; blobs={}; blobids={}
for p in allpaths:
    j=raw.index(b'\n',offset); h=raw[offset:j].decode().split(); offset=j+1
    assert len(h)==3 and h[1]=='blob',(p,h)
    size=int(h[2]); b=raw[offset:offset+size]; offset+=size
    assert raw[offset:offset+1]==b'\n'; offset+=1
    assert hashlib.sha1(b'blob '+str(size).encode()+b'\0'+b).hexdigest()==h[0]
    blobs[p]=b; blobids[p]=h[0]
assert offset==len(raw)
module_to_path={p[:-5].replace('/','.'):p for p in allpaths}
assert len(module_to_path)==len(allpaths)
assert set(scope)|set(checkonly) <= set(allpaths)

inventory=[]; graph={}; imports_by_path={}; missing_local=[]
for p in allpaths:
    text=blobs[p].decode()
    try: masked=mask(text)
    except AssertionError as e: raise AssertionError((p,str(e))) from e
    imports=[]; header=True
    for ln,line in enumerate(masked.splitlines(),1):
        s=line.strip()
        if not s: continue
        m=re.fullmatch(r'(?:public\s+)?import\s+(.+)',s)
        if m:
            assert header, ('import after header',p,ln)
            for name in m.group(1).split():
                assert re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*',name),(p,ln,name)
                imports.append({'module':name,'line':ln,'path':module_to_path.get(name)})
                if name.startswith('TCSlib') and name not in module_to_path: missing_local.append((p,ln,name))
        elif header and (s=='prelude' or re.fullmatch(r'module(?:\s+.+)?',s)):
            pass
        else: header=False
    graph[p]=[r['path'] for r in imports if r['path'] is not None]
    imports_by_path[p]=imports
    inventory.append({'path':p,'module':p[:-5].replace('/','.'),'git_blob':blobids[p],
        'sha256':sha(blobs[p]),'bytes':len(blobs[p]),'lines':len(text.splitlines()),
        'role':scope[p]['role'] if p in scope else ('CHECK_ONLY' if p in checkonly else None),
        'imports':imports})
assert not missing_local,missing_local
# Detect any local import cycle rather than silently truncating a closure.
active=set(); done=set()
def visit(p):
    assert p not in active,('local import cycle',p)
    if p in done: return
    active.add(p)
    for q in graph[p]: visit(q)
    active.remove(p); done.add(p)
for p in allpaths: visit(p)

prongpaths=[p for p in allpaths if any(p.startswith('TCSlib/Cryptography/'+q+'/') or p=='TCSlib/Cryptography/'+q+'.lean' for q in PRONGS)]
# Direct lexical admissions are mapped to top-level theorem/lemma declarations.
# For this frozen target set every proof is exactly `:= by` + standalone `sorry`.
candidates=[]; non_theorem_admissions=[]; lexical_counts={}
declpat=re.compile(r'^(?:(?:private|protected|noncomputable|unsafe|partial)\s+)*(theorem|lemma|def|abbrev|instance|opaque|axiom)\s+([^\s({\[:]+)')
for p in prongpaths:
    text=blobs[p].decode(); masked=mask(text); lines=masked.splitlines(keepends=True)
    rawlines=text.splitlines(keepends=True); stack=[]; prev=None; hits=[]
    for n,line in enumerate(lines,1):
        if line.startswith('namespace '):
            name=line.strip().split()[1]; stack.append(('namespace',name)); continue
        if re.match(r'^(?:noncomputable\s+)?section(?:\s|$)',line):
            ss=line.strip().split(); name=ss[-1] if ss[-1]!='section' else None
            stack.append(('section',name)); continue
        if re.match(r'^end(?:\s|$)',line):
            assert stack,('unmatched end',p,n,line)
            args=line.strip().split()[1:]; kind,name=stack.pop()
            assert not args or args[0]==name,('end mismatch',p,n,args,kind,name)
            continue
        d=declpat.match(line)
        if d:
            namespaces=[x[1] for x in stack if x[0]=='namespace']
            name=d.group(2)
            fullname=name[len('_root_.'):] if name.startswith('_root_.') else '.'.join(namespaces+[name])
            prev={'kind':d.group(1),'name':fullname,'start':n,'namespace':'.'.join(namespaces)}
        for m in re.finditer(r'\b(?:sorry|admit)\b',line):
            hits.append({'line':n,'token':m.group(),'column':m.start()+1})
            assert prev is not None,(p,n,'unmapped admission')
            if prev['kind'] not in ('theorem','lemma'):
                non_theorem_admissions.append({'path':p,'line':n,'declaration':prev}); continue
            assert line.strip()=='sorry',('non-simple direct admission',p,n,line)
            block=''.join(rawlines[prev['start']-1:n])
            maskedblock=''.join(lines[prev['start']-1:n])
            assert re.search(r':=\s*by\s+sorry\s*$',maskedblock),('unexpected proof form',p,n)
            prong=next(q for q in PRONGS if '/'+q+'/' in p or p.endswith('/'+q+'.lean'))
            candidates.append({'name':prev['name'],'kind':prev['kind'],'prong':prong,'path':p,
                'source_sha256':sha(blobs[p]),'git_blob':blobids[p],'declaration_start_line':prev['start'],
                'declaration_end_line':n,'sorry_line':n,'namespace':prev['namespace'],
                'declaration_sha256':sha(block.encode()),'declaration':block})
    assert not stack,('unclosed namespace/section',p,stack)
    lexical_counts[p]=hits
assert not non_theorem_admissions,non_theorem_admissions
assert len({x['name'] for x in candidates})==len(candidates)

closures={}; stats={}
for p in sorted({x['path'] for x in candidates}):
    parent={p:None}; queue=deque([p]); seen_order=[]
    while queue:
        q=queue.popleft(); seen_order.append(q)
        for child in graph[q]:
            if child not in parent: parent[child]=q; queue.append(child)
    paths=sorted(parent); external=sorted({r['module'] for q in paths for r in imports_by_path[q] if r['path'] is None})
    intersects=[]
    for q in paths:
        if q not in scope: continue
        chain=[]; at=q
        while at is not None: chain.append(at); at=parent[at]
        intersects.append({'path':q,'role':scope[q]['role'],'source_sha256':sha(blobs[q]),
            'role_ancestor_sha256':scope[q]['source_sha256'],'shortest_import_chain':chain[::-1]})
    closureidentity=[{'path':q,'sha256':sha(blobs[q]),'git_blob':blobids[q]} for q in paths]
    cl={'owner':p,'closure_includes_owner':True,'local_source_count':len(paths),'paths':paths,
        'source_identity_sha256':sha(json.dumps(closureidentity,sort_keys=True,separators=(',',':')).encode()),
        'external_import_boundary':external,'cleanup_intersection_count':len(intersects),'intersections':intersects,
        'check_only_intersections':sorted(set(paths)&set(checkonly))}
    closures[p]=cl
for c in candidates:
    cl=closures[c['path']]; c['local_source_count']=cl['local_source_count']
    c['cleanup_intersection_count']=cl['cleanup_intersection_count']
    c['intersection_role_counts']=dict(Counter(x['role'] for x in cl['intersections']))
    c['eligible']=cl['cleanup_intersection_count']==0
    c['closure_owner_key']=c['path']
    c['shortest_blocking_import_chain']=min((x['shortest_import_chain'] for x in cl['intersections']),key=lambda x:(len(x),x),default=None)

common={'source_head':REF,'source_tree':git('rev-parse',REF+'^{tree}').decode().strip(),
 'role_manifest':str(ROLE),'role_manifest_sha256':sha(rolebytes),'role_manifest_bytes':len(rolebytes),
 'role_source_ancestor':roles['ancestor'],'roles':dict(rc),'blocked_scope_paths':len(scope),
 'method':'Exact Git source blobs; lexical direct sorry/admit scan; complete transitive local import closure including owner; ALL CONSUMER and PROVIDER_ONLY paths block eligibility. CHECK_ONLY paths retained separately. No native or declaration-level dependency check.'}
allclosurepaths=sorted({q for cl in closures.values() for q in cl['paths']})
summary={**common,'prong_source_files':len(prongpaths),'direct_sorry_targets':len(candidates),
 'candidate_owner_files':len(closures),'eligible':sum(x['eligible'] for x in candidates),
 'blocked':sum(not x['eligible'] for x in candidates),'by_prong':{},
 'all_project_lean_sources_TCSlib_and_audits':len(allpaths),'candidate_closure_union_sources':len(allclosurepaths),
 'union_scope_intersection':len(set(allclosurepaths)&set(scope)),
 'unresolved_TCSlib_imports':missing_local,'non_theorem_admissions':non_theorem_admissions,
 'proofs_started':False,'native_or_build_run':False,'current_worktree_source_used':False}
for prong in PRONGS:
    rows=[c for c in candidates if c['prong']==prong]
    summary['by_prong'][prong]={'targets':len(rows),'eligible':sum(x['eligible'] for x in rows),'blocked':sum(not x['eligible'] for x in rows),'owner_files':len({x['path'] for x in rows})}
artifacts=[]
artifacts.append(emit('source-inventory.json',{**common,'sources':inventory}))
artifacts.append(emit('candidate-intersections.json',{**common,'candidates':candidates,'closures_by_owner':closures}))
artifacts.append(emit('summary.json',summary))
artifacts.append(emit('lexical-target-inventory.json',{**common,'files':[{'path':p,'source_sha256':sha(blobs[p]),'lexical_admissions':lexical_counts[p]} for p in prongpaths]}))
(OUT/'source-paths-sha256.tsv').write_text('path\tsha256\tgit_blob\tbytes\n'+''.join(f'{x["path"]}\t{x["sha256"]}\t{x["git_blob"]}\t{x["bytes"]}\n' for x in inventory))
artifacts.append({'path':'source-paths-sha256.tsv','sha256':sha((OUT/'source-paths-sha256.tsv').read_bytes()),'bytes':(OUT/'source-paths-sha256.tsv').stat().st_size})
emit('artifacts.json',{'script_sha256':sha(Path(__file__).read_bytes()),'artifacts':artifacts})
print(json.dumps(summary,indent=2))
for p,cl in closures.items():
    print(p,'targets',sum(c['path']==p for c in candidates),'closure',cl['local_source_count'],'blocked',cl['cleanup_intersection_count'],dict(Counter(x['role'] for x in cl['intersections'])))
