## Changes

- Move the PRG pad construction, correctness proof, four-hybrid bound and single-message security proof into `Encryption.PrivateKey.FromPRG`. The declaration and proof text moves verbatim.
- Re-export the moved results through `Asymptotic.Encryption`. Point the private-key facade and the pseudorandomness construction map to `FromPRG`.

## Verification

- All 35 affected modules pass one-module-at-a-time Lean 4.25.0 checking, including the library root and campaign Checks.
- The standalone and legacy import probes agree. The declaration census matches all 24 types, definition values, elaborated references and axiom sets after normalizing four private kernel names.
- The new whole-file seal passes the same 1,229 requests as the baseline. The pad control blocks direct reduction under the seal and the published encoding equation passes.
- Source lint and the diff check pass. Campaign lint repeats the two existing reader warnings and five direct-import flags for modules reached through the `Pseudorandom.Functions` facade.
