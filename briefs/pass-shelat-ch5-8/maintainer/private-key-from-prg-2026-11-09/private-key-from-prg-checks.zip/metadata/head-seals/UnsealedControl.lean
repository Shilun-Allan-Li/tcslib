import TCSlib.Cryptography.Encryption.PrivateKey.FromPRG

open TCSlib.Cryptography

example {n L : ℕ} (h : n ≤ L) (m : Fin n → Bool) (p : Fin L → Bool) (i : Fin n) :
    padXor h m p i = xor (m i) (p (Fin.castLE h i)) := by
  rfl
