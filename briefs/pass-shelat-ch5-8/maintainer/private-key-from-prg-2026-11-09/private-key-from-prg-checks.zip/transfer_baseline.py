"""Reuse the predecessor's SHA-pinned census and seal on the identical merged Lean inputs."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area, campaign = (Path(arg).resolve() for arg in sys.argv[1:3])
previous = area.parent / "private-key-interface-20261109"
published = campaign / "briefs/pass-shelat-ch5-8/maintainer/private-key-interface-2026-11-09/VERIFICATION.json"
meta = area / "metadata"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


plan = read(area / "native/PLAN.json")
source = read(area / "SOURCE-CHECK.json")
receipt = read(published)
assert receipt["head"] == plan["baseline"] == source["baseline"]
assert sha(published) == source["predecessor_receipt_sha256"]
assert receipt["passed"]
for name in ("PLAN.json", "RESULT.json", "PRODUCTS.json"):
    name = "native/" + name
    assert sha(previous / name) == receipt["artifact_sha256"][name]
scope = read(area / "MOVE-SCOPE.json")
module = scope["legacy"]
old_plan = read(previous / "native/PLAN.json")
base_source = previous / "source" / (module + ".lean")
assert sha(base_source) == old_plan["source_digests"][module]

original = previous / "metadata/Head.jsonl"
assert sha(original) == receipt["artifact_sha256"]["metadata/Head.jsonl"]
rows = [json.loads(line) for line in original.open()]
complete = rows.pop()
assert complete["record"] == "complete" and complete["count"] == 80
dot = module.replace("/", ".")
owners = [row for row in complete["owners"] if row["display"] == dot]
assert len(owners) == 1
filtered = [row for row in rows if row["record"] == "catalog" or row["home"]["display"] == dot]
assert len(filtered) - complete["catalog"] == 24
base_census = meta / "Base.jsonl"
with base_census.open("x") as stream:
    for row in filtered + [{**complete, "count": 24, "owners": owners}]:
        stream.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

seals = meta / "base-seals"
seals.mkdir()
transferred = {}
for suffix in ("lean", "log", "rc", "json", "resources.txt"):
    stem = "EncryptionSeal." + suffix
    rel = "metadata/head-seals/" + stem
    assert sha(previous / rel) == receipt["artifact_sha256"][rel]
    shutil.copyfile(previous / rel, seals / stem)
    assert sha(seals / stem) == receipt["artifact_sha256"][rel]
    transferred[stem] = sha(seals / stem)
manifest = read(seals / "EncryptionSeal.json")
assert manifest["source_path"] == module + ".lean" and manifest["source_sha256"] == sha(base_source)
assert int((seals / "EncryptionSeal.rc").read_text()) == 0
(seals / "SCOPE.json").write_text(json.dumps({"EncryptionSeal": len(manifest["requests"])}, indent=2) + "\n")
(meta / "BASELINE.json").write_text(json.dumps({
    "merged_base": plan["base"], "verified_predecessor": plan["baseline"],
    "receipt_sha256": sha(published), "original_census_sha256": sha(original),
    "filtered_census_sha256": sha(base_census), "selected_declarations": 24,
    "whole_file_seal_sha256": transferred,
}, indent=2) + "\n")
print("Reused the 24 PRG declarations and whole-file seal from the verified #271 inputs.", flush=True)
