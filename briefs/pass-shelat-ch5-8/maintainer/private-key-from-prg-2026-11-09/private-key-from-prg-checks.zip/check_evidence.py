"""Verify the exact source replay, declaration comparison, seals and ledger mapping."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, repo, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
native, meta = area / "native", area / "metadata"
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source, move, decls = (read(area / (name + ".json")) for name in ("SOURCE-CHECK", "MOVE-SCOPE", "DECLARATIONS"))
baseline = read(meta / "BASELINE.json")
legacy, owner = move["legacy"], move["owner"]
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain") and not git("diff", "--check", base, head)
assert all((r["base"], r["head"]) == (base, head) for r in (plan, result, source, decls))
assert result["passed"] and result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == len(plan["affected"]) == 35
assert result["initial_retained"] == len(plan["retained"]) == 1068
assert len(products) == len(plan["order"]) == 1103 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert source["legacy_closure_preserved"] and source["facade_closure_preserved"]
assert source["proof_and_definition_code_preserved"] and source["relocation"] == {legacy: owner}
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert decls["matched_declarations"] == decls["relocated_declarations"] == 24
assert decls["private_name_changes"] == 4 and decls["elaborated_references_match"]
assert decls["axioms_match"] and decls["legacy_and_new_imports_agree"]
assert baseline["merged_base"] == base and baseline["verified_predecessor"] == plan["baseline"]
assert baseline["filtered_census_sha256"] == decls["catalog_sha256"]["Base"]
assert baseline["receipt_sha256"] == source["predecessor_receipt_sha256"]

seals = {}
for side, label, rev, module in (("base", "EncryptionSeal", base, legacy), ("head", "FromPRGSeal", head, owner)):
    directory = meta / (side + "-seals")
    stem = directory / label
    manifest = read(stem.with_suffix(".json"))
    raw = git("show", f"{rev}:{module}.lean")
    assert manifest["source_path"] == module + ".lean"
    assert sha256(raw).hexdigest() == manifest["source_sha256"]
    assert sorted(row["source_line"] for row in manifest["line_map"]) == list(range(1, len(raw.splitlines())+1))
    requests = manifest["requests"]
    count = read(directory / "SCOPE.json")[label]
    assert len(requests) == len({(r["home"], r["spelling"]) for r in requests}) == count == 1229
    assert sha(stem.with_suffix(".lean")) == manifest["probe_sha256"]
    log = stem.with_suffix(".log").read_text()
    assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
    assert stem.with_suffix(".rc").read_text().strip() == "0"
    assert not re.search(r"\.lean:\d+:\d+: error(?:\(|:)", log)
    seals[side] = {
        "source_sha256": manifest["source_sha256"], "probe_sha256": manifest["probe_sha256"],
        "log_sha256": sha(stem.with_suffix(".log")), "requests": count, "diagnostics": 0,
    }
    if side == "base":
        old_mask = requests
        for name, expected in baseline["whole_file_seal_sha256"].items():
            assert sha(directory / name) == expected, name
    else:
        assert requests == old_mask

controls = {}
for label, rc in (("UnsealedControl", 0), ("SealedControl", 1), ("ReaderControl", 0)):
    stem = meta / "head-seals" / label
    log = stem.with_suffix(".log").read_text()
    assert int(stem.with_suffix(".rc").read_text()) == rc
    source_hash = sha(stem.with_suffix(".lean"))
    if label != "UnsealedControl":
        manifest = read(stem.with_suffix(".json"))
        assert source_hash == manifest["probe_sha256"]
        assert [r["spelling"] for r in manifest["requests"]] == ["TCSlib.Cryptography.padXor"]
        assert log.count(f"G06-SEAL-END label={label} requested=1 verified=1") == 1
    errors = re.findall(r"\.lean:\d+:\d+: error(?:\([^)]*\))?: ([^\n]+)", log)
    assert len(errors) == rc
    if rc:
        assert "Tactic `rfl` failed" in errors[0] and "padXor" in log[log.index(errors[0]):]
    controls[label] = {"rc": rc, "log_sha256": sha(stem.with_suffix(".log")), "source_sha256": source_hash}

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log, (side, log)
    assert "where the seal failed: 0 " in log
before, after = ({tuple(row) for row in read(area / f"campaign-lint-{side}.json")} for side in ("base", "head"))
failures = {row for row in before if row[0] == "FAIL"}
assert failures == {row for row in after if row[0] == "FAIL"} and len(failures) == 5
closure = set()
pending = [move["map"]]
while pending:
    module = pending.pop()
    if module not in closure:
        closure.add(module)
        pending.extend(plan["graph"][module])
for _, filename, message in failures:
    assert filename == move["map"] + ".lean"
    found = re.fullmatch(r"facade does not import child module `([^`]+)`", message)
    assert found and found[1].replace(".", "/") in closure


def warn_names(rows):
    return sorted(name.strip() for level, _, message in rows if level == "WARN"
                  for name in message.split("(check 8):", 1)[1].split(","))


assert warn_names(before) == warn_names(after) == ["padXor", "prgPadFun"]
assert "0 findings in 4 files" in (area / "style.log").read_text()
archive_dir = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
archive = archive_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (archive_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
assert len(ledger["current_observations"]) == 813 and not ledger["partial"] and not ledger["needs_review"]
providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
             for r in decls["declarations"] if r["kind"] == "def"}
links = []
for row in ledger["current_observations"]:
    refs = {(p["home"], p["spelling"]) for p in row.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in row.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if row["channel"] == "generated-equation":
        refs.add((row["provider_home"], row["provider"]))
    if row["channel"] == "explicit-source":
        refs.add((row["head"]["provider_home"], row["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": row["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": seals,
                          "controls": controls, "new_diagnostics": 0, "new_campaign_findings": 0,
                          "inherited_facade_direct_import_flags": sorted(failures),
                          "inherited_reader_warnings": warn_names(after)})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                          "ledger_archive_sha256": archive_sha, "relocated_provider_links": links,
                          "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                          "generated_foreign_equation_reads": {"base": 0, "head": 0}})
print(f"35 affected modules pass. Both seals use the same 1,229 requests and report zero diagnostics.")
print(f"The control pair and published reader pass. Mapped {len(links)} deferred provider links.")
