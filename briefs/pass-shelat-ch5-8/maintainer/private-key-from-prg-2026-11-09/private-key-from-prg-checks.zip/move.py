"""Stage the PRG construction relocation from the exact merged source."""
import json
from pathlib import Path
import subprocess
import sys

area, repo = (Path(arg).resolve() for arg in sys.argv[1:3])
base = (area / "base.txt").read_text().strip()
crypto = "TCSlib/Cryptography/"
legacy = crypto + "Asymptotic/Encryption"
facade = crypto + "Encryption/PrivateKey"
owner = facade + "/FromPRG"
map_module = crypto + "Pseudorandom"
old_prg = crypto + "Asymptotic/Pseudorandom"
prg = crypto + "Pseudorandom/Generators/Asymptotic/Defs"
games = facade + "/EnsembleSecurity"


def show(module):
    return subprocess.check_output(["git", "show", f"{base}:{module}.lean"], cwd=repo).decode()


def dot(module):
    return module.replace("/", ".")


def replace_once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


raw = show(legacy)
new = replace_once(raw, "import " + dot(old_prg) + "\n", "import " + dot(prg) + "\n")
new = replace_once(new,
    "The scheme interface and the single-message and fixed-vector ensemble games are defined\n"
    "in `Encryption.PrivateKey.Scheme` and `Encryption.PrivateKey.EnsembleSecurity`. This\n"
    "module re-exports both through the legacy import.",
    "An efficient generator evaluator supplies the pad for each challenge message. The security\n"
    "proof switches each pseudorandom pad to a uniform pad. The two uniform-pad experiments\n"
    "agree by perfect secrecy.")
marker = "namespace TCSlib.Cryptography\n"
assert raw[raw.index(marker):] == new[new.index(marker):]
compat = raw[:raw.index("import ")] + "".join("import " + dot(module) + "\n" for module in (old_prg, owner))
compat += "\n" + raw[raw.index("set_option "):raw.index("/-!")]
compat += """/-!
# Private-key encryption compatibility import

## Main definitions

`Encryption.PrivateKey.Scheme` gives the uniform scheme interface,
`Encryption.PrivateKey.EnsembleSecurity` gives the ensemble games, and
`Encryption.PrivateKey.FromPRG` gives the pseudorandom pad construction.

## Main results

This import exposes the ensemble security results and the single-message security
proof for the PRG construction.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Definitions 24.7, 91.1 and 93.1, Algorithm 92.1 and Theorems 92.2 and 94.2.)
-/
"""
facade_text = replace_once(show(facade), "import " + dot(legacy) + "\n", "import " + dot(owner) + "\n")
facade_text = replace_once(facade_text,
    "* `Asymptotic.Encryption` gives the single-message construction from a PRG.",
    "* `Encryption.PrivateKey.FromPRG` gives the PRG pad construction and its security proof.")
map_text = replace_once(show(map_module),
    "  `TCSlib.Cryptography.Asymptotic.Encryption` via `TCSlib.Cryptography.prgScheme_singleMessageSecure`.\n",
    "  `TCSlib.Cryptography.Encryption.PrivateKey.FromPRG` via\n"
    "  `TCSlib.Cryptography.prgScheme_singleMessageSecure`.\n")
sources = {owner: new, legacy: compat, facade: facade_text, map_module: map_text}
for module, source in sources.items():
    target = area / "source" / (module + ".lean")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.encode())
(area / "MOVE-SCOPE.json").write_text(json.dumps({
    "legacy": legacy, "owner": owner, "facade": facade, "map": map_module,
    "legacy_prg": old_prg, "prg": prg, "games": games,
}, indent=2) + "\n")
print("Prepared the verbatim PRG construction and proof move, the compatibility import and two construction maps.")
