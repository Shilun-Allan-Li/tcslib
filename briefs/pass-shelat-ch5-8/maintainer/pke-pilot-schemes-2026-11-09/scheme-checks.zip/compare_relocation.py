"""Verify the two source moves and compare the actual Lean declarations."""
from collections import Counter
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

sys.setrecursionlimit(30000)
area, cleanup, published, facade = (Path(p).resolve() for p in sys.argv[1:5])


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f, 'sha256').hexdigest()


def save(name, value):
    with (area / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def identity(row):
    return tuple(map(tuple, row['components']))


def module_path(module):
    return module.replace('.', '/') + '.lean'


plan = read(area/'native/PLAN.json')
prior = read(cleanup/'native-r3/PLAN.json')
before_products = read(cleanup/'native-r3/PRODUCTS.json')
after_products = read(area/'native/PRODUCTS.json')
worktree = Path(plan['worktree'])
base, head = plan['base'], plan['head']
assert prior['head'] == read(published/'STATUS.json')['head']
assert all(prior[k] == plan[k] for k in ('checker_sha256', 'toolchain_sha256'))
assert {k:v['sha256'] for k,v in prior['external'].items()} == {
    k:v['sha256'] for k,v in plan['external'].items()}


def source(rev, path):
    return subprocess.check_output(['git','show',rev+':'+path],cwd=worktree)


digests = {p:n for n,p in (r.split(maxsplit=1) for r in
           (published/'SHA256SUMS').read_text().splitlines())}
published_inputs = {}


def verified_inputs(archive, *paths):
    path = published/archive
    assert sha(path) == digests[archive]
    with ZipFile(path) as zip:
        for rel in paths:
            with zip.open(rel) as stream:
                digest = file_digest(stream,'sha256').hexdigest()
            assert sha(cleanup/rel) == digest, rel
            published_inputs[rel] = {'archive':archive,'sha256':digest}


old_raw='census-final-r1/Head.jsonl'
old_compact='census-final-r1/Head-compact.json'
old_c3='census-final-r1/FinalPins.XxHvTdlw/HeadC3.log'
verified_inputs('08-final-census.zip',old_raw,old_compact,old_c3)
verified_inputs('07-final-native-source.zip','native-r3/PRODUCTS.json','native-r3/PLAN.json')
verified_inputs('10-final-seals.zip','controls-final-r1/MANIFEST.json','controls-final-r1/RESULT.json')

old=read(cleanup/old_compact)
new=read(area/'metadata/Head-compact.json')
owners={m['display'] for m in new['owners']}
legacy='TCSlib.Cryptography.Asymptotic.PublicKey'
scheme='TCSlib.Cryptography.Encryption.PublicKey.Scheme'
old_owners=owners-{scheme}
assert len(old_owners) == 4 and legacy in old_owners


def closure(roots, graph):
    seen, pending = set(), list(roots)
    while pending:
        m = pending.pop()
        if m not in seen:
            seen.add(m)
            pending.extend(graph[m])
    return sorted(seen)


def bind_base_modules(roots):
    paths=closure(roots,prior['graph'])
    for m in paths:
        row=before_products[m]
        digest=sha256(source(base,m+'.lean')).hexdigest()
        assert digest == row['source_sha256'] == prior['source_digests'][m], m
        assert sha(facade/'retained-tree/oleans'/(m+'.olean')) == row['object_sha256'], m
        assert row['direct_local'] == {p:before_products[p]['object_sha256'] for p in prior['graph'][m]}
    return paths


old_context=bind_base_modules(m.replace('.','/') for m in old_owners)
control_dir=cleanup/'controls-final-r1'
controls=read(control_dir/'RESULT.json')
control_manifest=read(control_dir/'MANIFEST.json')
assert controls['head']==control_manifest['head']==prior['head'] and controls['passed']
control_owner=control_manifest['owner'].replace('.','/')
control_context=bind_base_modules([control_owner])
assert control_context == closure([control_owner],plan['graph'])
for m in control_context:
    before,after=before_products[m],after_products[m]
    assert all(before[k]==after[k] for k in ('object_sha256','source_sha256','direct_local')),m
    assert sha(Path(plan['tree'])/(m+'.olean'))==after['object_sha256'], m
assert len(controls['outcomes']) == len(control_manifest['probes']) == 13
for outcome, entry in zip(controls['outcomes'],control_manifest['probes'],strict=True):
    assert all(outcome[k]==v for k,v in entry.items())
    assert outcome['rc']==entry['expected_rc'] and len(outcome['errors'])==entry['expected_errors']
    assert sha(Path(entry['module']+'.lean'))==entry['source_sha256']
    assert sha(control_dir/(entry['label']+'.log'))==outcome['log_sha256']

legacy_path=module_path(legacy)
scheme_path=module_path(scheme)
old_source=source(base,legacy_path).decode()
new_source=source(head,legacy_path).decode()
interface_source=source(head,scheme_path).decode()
assert new_source==(area/'inputs/LegacyPublicKey.lean').read_text()
assert interface_source==(area/'inputs/Scheme.lean').read_text()
spec=importlib.util.spec_from_file_location('verified_imports',cleanup/'tools/import_graph.py')
parser=importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
blocks = re.findall(r'/-- A \*\*.*?\nstructure (?:Bit)?PublicKeyScheme where\n(?: [^\n]+\n)+',
                    old_source,flags=re.S)
assert len(blocks) == 2 and all(block in interface_source for block in blocks)
remaining=old_source
for block in blocks:
    remaining=remaining.replace(block,'',1)


def commands(text):
    return [line.rstrip() for line in parser.comments_removed(text).splitlines() if line.strip()]


assert commands(remaining)==commands(new_source.replace('import '+scheme+'\n','',1))
normalize_style=lambda text:re.sub(r'\b\d+ lines \(> 1000, must split\)','inherited length',text)
assert normalize_style((area/'legacy-base-style.log').read_text()) == normalize_style(
    (area/'legacy-head-style.log').read_text())


def roots(census):
    return {identity(r['name']):r for r in census['roots'] if r['home'] in owners}


before,after=roots(old),roots(new)
assert before.keys()==after.keys() and len(after)==len(new['roots'])
assert old['axiom_names']==new['axiom_names']
roots_rehomed = {}
changed_fields={}
for key,a in before.items():
    b=after[key]
    differences={k for k in a if a[k]!=b[k]}
    assert differences <= {'home','type_sha256','definition_sha256'}, (b['name'],differences)
    if 'home' in differences:
        assert (a['home'],b['home'])==(legacy,scheme)
        assert b['name']['display'].split('.')[2] in ('PublicKeyScheme','BitPublicKeyScheme')
        roots_rehomed[key]=b['name']
    if differences-{'home'}:
        assert key in roots_rehomed, (a,b)
        changed_fields[key]=differences-{'home'}
assert len(roots_rehomed)==44


def pinned_terms(path):
    roots, catalog = {}, {}
    with path.open() as stream:
        for r in map(json.loads,stream):
            if r['record'] in ('root','catalog'):
                key=identity(r['name'])
                if key in after and r['record']=='catalog':
                    catalog[key]={k:v for k,v in r.items() if k!='home'}
                if key in changed_fields and r['record']=='root':
                    roots[key]=r
    return roots,catalog


old_terms,old_catalog=pinned_terms(cleanup/old_raw)
new_terms,new_catalog=pinned_terms(area/'metadata/Head.jsonl')
assert old_catalog==new_catalog and old_catalog.keys()==after.keys()


def compare_terms(a,b,path=()):
    if a==b:
        return []
    assert isinstance(a,list) and isinstance(b,list) and len(a)==len(b), path
    result=[]
    if a[0]==b[0] and a[0] in ('forall','lam','let') and a[1]!=b[1]:
        old_name,new_name=a[1],b[1]
        for name,home in ((old_name,legacy),(new_name,scheme)):
            parts=identity(name)
            assert parts[:2]==(('str','x'),('str','_@')) and parts[2:2+len(home.split('.'))]==tuple(
                ('str',s) for s in home.split('.')), name
            assert '_hygCtx' in name['display'] and '_hyg' in name['display']
        result.append({'path':[*path,1],'base':old_name,'head':new_name})
        a,b=[a[0],None,*a[2:]],[b[0],None,*b[2:]]
    for i,(x,y) in enumerate(zip(a,b,strict=True)):
        result.extend(compare_terms(x,y,(*path,i)))
    return result


binder_changes=[]
for key in sorted(changed_fields):
    a,b=old_terms[key],new_terms[key]
    for field in ('type','definition_value'):
        entries=compare_terms(a[field],b[field])
        assert bool(entries)==(('type_sha256' if field=='type' else 'definition_sha256') in changed_fields[key])
        if entries:
            assert len(entries)==1
            binder_changes.append({'name':a['name'],'field':field,'binder':entries[0]})
assert len(binder_changes)==8


def c3(path, selected):
    roots, pairs, controls=[],[],[]
    for line in path.read_text().splitlines():
        for label, target in (('ROOT',roots),('REF',pairs),('CONTROL',controls)):
            marker='G06-C3-'+label+' '
            if line.startswith(marker):
                fields=line[len(marker):].split(' | ')
                if label=='CONTROL' or fields[0] in selected:
                    target.append(tuple(fields))
    return roots,pairs,controls


old_roots,old_pairs,old_controls=c3(cleanup/old_c3,old_owners)
new_roots,new_pairs,new_controls=c3(area/'metadata/run/C3.log',owners)
assert not old_pairs and not new_pairs and len(new_controls)==2 and old_controls==new_controls
assert Counter((r[0],r[1]) for r in old_roots)==Counter((r['home'],r['name']['display']) for r in before.values())
assert Counter((r[0],r[1]) for r in new_roots)==Counter((r['home'],r['name']['display']) for r in after.values())
c3_log=(area/'metadata/run/C3.log').read_text()
assert f'G06-C3-END base={base} head={head} modules={len(owners)} roots={len(after)} pairs=0 ' in c3_log

save('DECLARATIONS.json',{'base':base,'head':head,'roots':len(after),
    'rehomed':[roots_rehomed[k] for k in sorted(roots_rehomed)],
    'hygienic_binders':binder_changes,'axiom_names':new['axiom_names'],
    'roots_with_sorryAx':sum('sorryAx' in row['axioms'] for row in after.values()),
    'native_axiom_controls':new['native_axiom_controls'],
    'base_context_modules':len(old_context),'verified_reused_controls':len(controls['outcomes']),
    'control_context_modules':len(control_context),'c3_controls':new_controls,
    'c3_pairs':len(new_pairs),'baseline_published_inputs':published_inputs})
print(len(after),'declarations;',len(roots_rehomed),'rehomed;',
      len(binder_changes),'hygienic binder labels;',len(controls['outcomes']),'verified retained controls')
