"""Prepare exact module reuse from the checked facade and the #248 object tree."""
from functools import cache
from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

area, worktree, cleanup, facade_review = (Path(s).resolve() for s in sys.argv[1:5])
old_native = cleanup/'native-r3'
source_tree = facade_review/'retained-tree/oleans'
out = area/'native'
tree = out/'oleans'
spec = importlib.util.spec_from_file_location('verified_imports', cleanup/'tools/import_graph.py')
graph_tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph_tools)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git',*args],cwd=worktree,text=True).strip()


def copy(source, target, expected):
    assert sha(source) == expected, source
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert sha(target) == expected and not target.samefile(source), target


base=(area/'base.txt').read_text().strip()
head=(area/'head.txt').read_text().strip()
assert git('rev-parse','HEAD') == head and git('merge-base',base,head) == base
assert not git('status','--porcelain')
previous=read(old_native/'PLAN.json')
result=read(old_native/'RESULT.json')
facade=read(facade_review/'VERIFICATION.json')
assert result['passed'] and facade['passed']
assert previous['head']==result['head']==facade['verified_cleanup_head']
assert result['products_sha256']==facade['verified_cleanup_products_sha256']==sha(old_native/'PRODUCTS.json')
assert previous['toolchain_sha256']==facade['toolchain_sha256']
assert previous['checker_sha256']==facade['checker_sha256']
assert not git('diff','--name-only',facade['head'],base,'--','*.lean','lean-toolchain',
               'lake-manifest.json','lakefile.lean','lakefile.toml','scripts/lean_check_tree.sh')
old_products=read(old_native/'PRODUCTS.json')
root, checks='TCSlib','audits/pass-shelat/Checks'
legacy='TCSlib/Cryptography/Asymptotic/PublicKey'
entry='TCSlib/Cryptography/Encryption/PublicKey'
scheme=entry+'/Scheme'
changed={legacy,entry,scheme}
assert set(git('diff','--name-only',base,head).splitlines())=={m+'.lean' for m in changed}
sources={f[:-5]:(worktree/f).read_bytes() for f in
         git('ls-files','--','TCSlib','TCSlib.lean',checks+'.lean').splitlines()
         if f.endswith('.lean')}
assert set(sources)==set(previous['source_digests']) | {entry,scheme}
from hashlib import sha256
source_digests={m:sha256(raw).hexdigest() for m,raw in sources.items()}
all_graph={m:[x.replace('.','/') for x in graph_tools.imports(raw) if x.replace('.','/') in sources]
           for m,raw in sources.items()}
old_graph={**previous['graph'],entry:[x.replace('.','/') for x in facade['facade_imports']]}
old_graph[root]=old_graph[root]+[entry]
# Reconcile the exact direct import order of the checked facade's library root.
old_root=subprocess.check_output(['git','show',base+':TCSlib.lean'],cwd=worktree)
old_graph[root]=[x.replace('.','/') for x in graph_tools.imports(old_root) if x.replace('.','/') in sources]
for m in old_graph.keys()-changed:
    assert all_graph[m]==old_graph[m],m
assert [x for x in all_graph[legacy] if x!=scheme]==old_graph[legacy]
assert [x for x in all_graph[entry] if x!=scheme]==old_graph[entry]
assert all_graph[scheme]==['TCSlib/Cryptography/Asymptotic/Adversary']
order=graph_tools.topo(all_graph,[root,checks])
assert set(order)==set(previous['order']) | {entry,scheme}


@cache
def closure(m):
    return set(all_graph[m]).union(*(closure(d) for d in all_graph[m]))


affected={m for m in sources if m in changed or closure(m)&changed}
assert affected <= set(order), sorted(affected-set(order))
assert root in affected and checks in affected
rebuilt=[m for m in order if m in affected]
base_digests=dict(previous['source_digests'])
for row in facade['checks']:
    m=row['module']
    if m in (root, checks, entry):
        base_digests[m]=row['source_sha256']
        old_products[m]={'source_sha256':row['source_sha256'],'object_sha256':row['object_sha256']}
for m, source_digest in source_digests.items():
    if m not in changed:
        assert source_digest==base_digests[m],m

out.mkdir()
retained={}
for m in order:
    if m in affected:
        continue
    row=old_products[m]
    direct={d:retained[d]['object_sha256'] for d in all_graph[m]}
    assert source_digests[m]==row['source_sha256'] and direct==row['direct_local'],m
    product=tree/(m+'.olean')
    copy(source_tree/(m+'.olean'),product,row['object_sha256'])
    retained[m]={'source_sha256':row['source_sha256'],'object_sha256':row['object_sha256'],
                 'direct_local':direct,'source':'verified_facade_import_tree'}
external={}
old_tree=Path(previous['tree'])
for name, row in previous['external'].items():
    path=Path(row['path']).resolve()
    if path.is_relative_to(old_tree):
        target=tree/path.relative_to(old_tree)
        copy(path,target,row['sha256'])
        path=target
    else:
        assert sha(path)==row['sha256'],path
    external[name]={'path':str(path),'sha256':row['sha256']}
(tree/'PFR').symlink_to('.lake/packages/PFR/PFR',target_is_directory=True)
plan={'head':head,'base':base,'baseline':facade['head'],'worktree':str(worktree),'tree':str(tree),
      'toolchain':previous['toolchain'],'toolchain_sha256':previous['toolchain_sha256'],
      'checker_sha256':previous['checker_sha256'],'order':order,'rebuild':rebuilt,'retained':retained,
      'graph':{m:all_graph[m] for m in order},'external':external,'source_digests':source_digests}
with (out/'PLAN.json').open('x') as f:
    json.dump(plan,f,indent=2)
    f.write('\n')
print(len(retained),'verified retained objects,',len(rebuilt),'fresh checks',flush=True)
print('\n'.join(rebuilt),flush=True)
