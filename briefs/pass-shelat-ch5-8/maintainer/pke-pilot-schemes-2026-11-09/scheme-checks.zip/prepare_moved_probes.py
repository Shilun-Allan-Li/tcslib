"""Isolate the newly foreign generated scheme definitions from inherited failures."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

workspace=Path.cwd()
area=Path(sys.argv[1]).resolve()
previous=area.parent/'gate06-combined-20261108'
tools=previous/'rule10-evidence-r2/tool-inputs'


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod


def read(path):
    return json.loads(path.read_bytes())


def save(path,data):
    with path.open('x') as f:
        json.dump(data,f,ensure_ascii=False,indent=2)
        f.write('\n')


bs=load(tools/'build_seals.py','reviewed_seals')
controls=load(tools/'build_controls.py','reviewed_controls')
adapter=load(tools/'request_payload_adapter.py','reviewed_adapter')
bound=load(previous/'rule10-payload-retry-r3/bound_payload.py','reviewed_payload_bound')
adapter.configure_builders(bs,controls)
seal=bs.seal_command
bs.seal_command=lambda label,rows,*,end: bound.bound_payloads(seal(label,rows,end=end))
full=area/'seals'
manifest=read(full/'MANIFEST.json')
plan=read(Path(manifest['native_plan']))
root=Path(plan['worktree'])
legacy='TCSlib.Cryptography.Asymptotic.PublicKey'
scheme='TCSlib.Cryptography.Encryption.PublicKey.Scheme'
entry=next(p for p in manifest['probes'] if p['owner']==legacy)
old_meta=read(full/(entry['label']+'.json'))
requested=[r for r in old_meta['requested'] if r['home']==scheme]
assert len(requested)==6,[r['spelling'] for r in requested]
targets=[
    ('CleanupSealMovedLegacy',legacy,entry['path']),
    ('CleanupSealMovedChecks','audits.pass-shelat.Checks','audits/pass-shelat/Checks.lean'),
]
out=area/'seals-moved'
out.mkdir()
probes=[]
for i,(label,owner,path) in enumerate(targets,1):
    raw=(root/path).read_bytes()
    assert sha256(raw).hexdigest()==plan['source_digests'][path[:-5]]
    probe,inserts,lines=bs.instrument(raw,bs.header(raw),label,requested)
    dest=out/(label+'.lean')
    dest.write_bytes(probe)
    meta={'label':label,'owner':owner,'path':path,'requested':requested,
          'source_sha256':sha256(raw).hexdigest(),'probe_sha256':sha256(probe).hexdigest(),
          'insertions':inserts,'line_map':lines}
    save(out/(label+'.json'),meta)
    probes.append({'ordinal':i,'label':label,'owner':owner,'path':path,
                   'module':dest.relative_to(workspace).with_suffix('').as_posix(),
                   'source_sha256':meta['source_sha256'],'probe_sha256':meta['probe_sha256'],
                   'requested':len(requested)})
save(out/'MANIFEST.json',{**manifest,'probes':probes})
print(len(probes),'focused relocation probes with',len(requested),'exact definition requests')
