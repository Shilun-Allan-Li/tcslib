"""Relocate the witnessed diagnostics without reopening the prior cleanup ledger."""
from collections import Counter
from difflib import SequenceMatcher
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, cleanup, published, facade = (Path(p).resolve() for p in sys.argv[1:5])


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def clean(text):
    text = re.split(r'(?m)^(?:G06-(?:SEAL|COMPONENT|MASK|CONTROL)|FAIL\(|=== Lean)',text,maxsplit=1)[0].strip()
    labels = {}
    return re.sub(r'\?([mu])\.\d+\b',lambda m:'?'+m[1]+'.'+str(
        labels.setdefault(m[0],len(labels)+1)),text)


def mask(meta):
    return {tuple(map(tuple,r['name_components'])):r for r in meta['requested']}


def source(rev, path, digest):
    raw = subprocess.check_output(['git','show',rev+':'+path],cwd=plan['worktree'])
    assert sha256(raw).hexdigest()==digest
    return raw.decode().splitlines()


def same_lines(old,new):
    return {j+d+1:i+d+1 for i,j,n in SequenceMatcher(None,old,new,autojunk=False).get_matching_blocks()
            for d in range(n)}


plan=read(area/'native/PLAN.json')
native=read(area/'native/RESULT.json')
assert native['head']==plan['head'] and native['base']==plan['base'] and native['passed']
assert native['plan_sha256']==sha(area/'native/PLAN.json')
assert native['products_sha256']==sha(area/'native/PRODUCTS.json')
checks_module='audits/pass-shelat/Checks'
checks_receipt=next(r for r in (area/'native').glob('run-*/check-*.json') if read(r)['module']==checks_module)
checks=checks_receipt.with_suffix('.log')
facade_checks=facade/'native-checks/checks.log'
checks_digest=read(checks_receipt)['log_sha256']
assert sha(checks)==checks_digest==sha(facade_checks)
full=read(area/'SEALS.json')
focus=read(area/'SEALS-MOVED.json')
assert all(row['valid_harness'] for row in full['outcomes'])
assert len(focus['outcomes'])==2 and all(row['valid_harness'] and row['rc']==0 for row in focus['outcomes'])
focus_masks=[mask(read(area/'seals-moved'/(r['label']+'.json'))) for r in focus['outcomes']]
assert focus_masks[0]==focus_masks[1] and len(focus_masks[0])==6
previous=read(cleanup/'seals-head-effective-final-r1.json')
previous_map={r['owner']:r for r in previous['outcomes']}
legacy='TCSlib.Cryptography.Asymptotic.PublicKey'
scheme='TCSlib.Cryptography.Encryption.PublicKey.Scheme'
paths={r['path'] for r in full['outcomes']}
legacy_path=legacy.replace('.','/')+'.lean'
prior=previous_map[legacy]
prior_scan='head-read-scan-final-r1/scan.log'
ledger='deferred-read-ledger-final-r1.json'

archive_digests={p:n for n,p in (l.split(maxsplit=1) for l in (published/'SHA256SUMS').read_text().splitlines())}
with ZipFile(published/'10-final-seals.zip') as seals, ZipFile(published/'11-final-read-ledger.zip') as reads:
    assert all(sha(published/f)==archive_digests[f] for f in ('10-final-seals.zip','11-final-read-ledger.zip'))
    for archive, rel in ((seals,'seals-head-effective-final-r1.json'),(reads,prior_scan),(reads,ledger)):
        assert sha256(archive.read(rel)).hexdigest()==sha(cleanup/rel),rel
    for old in previous_map.values():
        if old['path'] not in paths:
            continue
        meta_rel='seals-head-final-r1/'+old['label']+'.json'
        log_path=Path(old['log'])
        log_rel=log_path.relative_to(cleanup).as_posix()
        assert sha256(seals.read(meta_rel)).hexdigest()==sha(cleanup/meta_rel)==old['meta_sha256']
        assert sha256(seals.read(log_rel)).hexdigest()==sha(log_path)==old['log_sha256']

rows=[r for r in read(cleanup/ledger)['current_observations']
      if r['path']==legacy_path and r['channel']=='whole-file-seal']
ledger_rows={(r['head_line'],r['column'],r['head_error']):r for r in rows}
assert len(ledger_rows)==len(rows)==len(prior['errors'])==9
names={r['name']['display']:r for r in read(area/'metadata/Head-compact.json')['roots']}
carry=[]
scope=[]
for outcome in full['outcomes']:
    owner=outcome['owner']
    if owner==scheme:
        assert outcome['rc']==0 and not outcome['errors']
        continue
    old=previous_map[owner]
    old_mask=mask(read(cleanup/'seals-head-final-r1'/(old['label']+'.json')))
    new_mask=mask(read(area/'seals'/(outcome['label']+'.json')))
    additions=focus_masks[0] if owner==legacy else {}
    if owner==legacy:
        assert all(r['home']==scheme for r in additions.values())
    old_rehomed={}
    for k,r in old_mask.items():
        current=names.get(r['spelling'])
        if current and r['home']==legacy and current['home']==scheme:
            old_rehomed[k]={**r,'home':scheme,'home_components':[['str',s] for s in scheme.split('.')]}
    assert not (old_mask.keys()&additions.keys())
    assert new_mask=={**old_mask,**old_rehomed,**additions},owner
    path=outcome['path']
    old_lines=source(plan['base'],path,old['source_sha256'])
    new_lines=source(plan['head'],path,outcome['source_sha256'])
    mapped=same_lines(old_lines,new_lines)
    before=Counter((d['source_line'],d['column'],clean(d['text'])) for d in old['errors'])
    after=Counter((mapped[d['source_line']],d['column'],clean(d['text'])) for d in outcome['errors'])
    assert before==after,owner
    scope.append({'owner':owner,'base_requests':len(old_mask),'head_requests':len(new_mask),
                  'rehomed_requests':list(old_rehomed.values()),'new_requests':len(additions),
                  'inherited_diagnostics':sum(before.values())})
    for d in outcome['errors']:
        line=d['source_line']
        old_line=mapped[line]
        r=ledger_rows[(old_line,d['column'],clean(d['text']))]
        start,dstart,end=(r['head_span'][k] for k in ('start','dstart','end'))
        shift=line-old_line
        assert all(mapped[i+shift]==i for i in range(dstart,end+1))
        assert old_lines[old_line-1]==new_lines[line-1]==r['head_source']
        assert r['head_log_sha256']==old['log_sha256']
        assert r['head_actual'] and all(names[a['name']['display']]['home']==a['home']==owner and
            names[a['name']['display']]['type_sha256']==a['type_sha256'] for a in r['head_actual'])
        carry.append({'id':r['id'],'disposition':r['disposition'],'historical_owner':r['historical_owner'],
                      'current_owner':path,'declarations':r['head_actual'],'provider_pairs':r['provider_pairs'],
                      'provider_note':r.get('provider_note'),'baseline_source_sha256':old['source_sha256'],
                      'source_sha256':outcome['source_sha256'],'baseline_line':old_line,'current_line':line,
                      'current_span':{**r['head_span'],'start':start+shift,'dstart':dstart+shift,'end':end+shift},
                      'column':d['column'],'source':r['head_source'],'diagnostic':clean(d['text']),
                      'baseline_log_sha256':old['log_sha256'],'current_log_sha256':outcome['log_sha256']})
assert {r['id'] for r in carry}=={r['id'] for r in rows} and len(carry)==9


def explicit(text, path_filter):
    c1, c2, c3 = re.split(r'(?m)^## \(c[23]\)[^\n]*\n',text)
    return Counter((i,*line.split('\t')[1:]) for i,section in enumerate((c1,c2,c3),1)
                   for line in section.splitlines()
                   if any(line.startswith(p+':') or line.startswith(p[:-5].replace('/','.')+'\t')
                          for p in path_filter))


assert explicit((cleanup/prior_scan).read_text(),paths)==explicit((area/'read-scan/scan.log').read_text(),paths)==Counter()
result={'base':plan['base'],'head':plan['head'],'passed':True,
        'prior_ledger_sha256':sha(cleanup/ledger),'unchanged_checks_log_sha256':sha(checks),
        'full_seal_requests':sum(r['requested'] for r in full['outcomes']),
        'full_seals':len(full['outcomes']),'full_seal_source_passes':full['source_passes'],
        'focused_seals':len(focus['outcomes']),'focused_definitions':list(focus_masks[0].values()),
        'c1_reads':0,'c2_show_change_failures':0,'c3_reads':0,'scopes':scope,'carry_forward':carry}
with (area/'READS.json').open('x') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(len(carry),'matched diagnostics;',len(focus['outcomes']),'clean relocation probes; no C1/C2/C3 observations')
