## Public-key encryption pilot

Move `PublicKeyScheme` and `BitPublicKeyScheme` with their field docstrings
and correctness conditions into `Encryption/PublicKey/Scheme.lean`.
The new module imports only `Asymptotic.Adversary`. The existing
`Asymptotic.PublicKey` import continues to expose both structures and
their security games. The PKE facade now lists the scheme module.

## Verification

- All 10 affected modules compile, including the library root and campaign
  Checks. The replay validates 1,067 retained module objects.
- Native probes check both the new standalone import and the legacy import.
  The census checks 373 declarations and confirms that the 44
  rehomed names preserve their types, definitions and axiom dependencies,
  up to eight compiler-generated binder labels. All legacy proof commands
  are unchanged.
- Five whole-file seals and two focused relocation seals find no new
  foreign reads. All nine legacy diagnostics match the accepted cleanup
  ledger and remain open for the final seal work.
- The new module and facade pass style checks. The legacy module retains
  its recorded file-size exception.

Base `f7b436779ac047f606a7fe85d23e5ab96f553925`. Checked head `c8b779f58307e7e9ec0041f4dfdf24cf42b78f9e`.

[Approved pilot map](https://github.com/Shilun-Allan-Li/tcslib/blob/f7b436779ac047f606a7fe85d23e5ab96f553925/briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
