Adds the four Pass–shelat chapter5–8 statement prongs and PAC support to the campaign base, with public reading interfaces, composition bridges and exports. Designated security proofs remain admitted for later fills.

**Combined-source verification in progress; keep draft.** Current head `a495f3953afff46ad5dec2d29ac8a7f55bd8ae37` merges the accepted S2 target and applies all15 reviewed minor comment/sketch dispositions across13 files. This uses the existing PR branch; cleanup part2 is deferred and excluded.

All four user-dispatched statement gates are CLOSED at historical audited source `3f6db40e1688c4a0bb922c9575dd3bd2157a650b`: A0B/0M/2 minors,B0B/0M/5 minors,C0B/0M/4 minors,D0B/0M/4 minors. The applied comments preserve exact noncomment bytes. All five S2 candidate sources match accepted target `067c5d8d6dd436e62681d7dc607984c705dc80a2`; no new mathematical statement, algorithm, hypothesis, cost or admission is introduced by this update.

[Current combined-source pin and verification progress](https://github.com/Shilun-Allan-Li/tcslib/blob/bb52c8eaebe2a8cec9ad9f7cc2d3d549ca22af37/briefs/pass-shelat-ch5-8/maintainer/gate06-combined-2026-11-08/README.md) · [All audit dispositions and reviewed comment proposal](https://github.com/Shilun-Allan-Li/tcslib/tree/0ab756b8ccb7c37fedd6e5dfbc0248dc0afc984b/briefs/pass-shelat-ch5-8/gates/06-ch5-8-statements)

Fresh combined-source verification covers affected imports/exports, the campaign Checks aggregate, actual axioms and C3 census, explicit-read/source comparison, whole-file seals and controls. The59 math owners are the old54 plus five S2 candidates. The collector is being refreshed to include eligible definition-instances and instance sensitivity; exact approved notation exceptions are preserved, without excluding eval helpers. No fresh native/seal pass is yet claimed.

The historical common verification at3f reconciled467 native modules,54 valid seal harnesses (37 source passes/17 failures in110 unchanged blocks),11 controls and2881 actual axiom identities (same46 admitted-dependent, zero unexpected axioms). These remain preserved historical evidence, not verification of the current head; prior root-export elaboration was not claimed. [Historical evidence and limits](https://github.com/Shilun-Allan-Li/tcslib/blob/c81baa7712ab1b43357276ef5df138d02616c9d0/briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/FINAL-EVIDENCE.md).

Scope remains authentication; OT/garbling/honest-but-curious secure computation; private-key CPA/CCA2 and public-key CPA games; sequential ZK/quantitative3COL; extraction/learning/BPP bridges. OT retains canonical encryption, evaluator efficiency and enhanced-hard-core premises. No public-key CCA2 construction or completion of the33 substantive prong admissions is claimed. Existing inherited reads and admissions remain disclosed; cleanup is not reopened.

The user approves/merges accepted Lean into `cryptography/pass-shelat-ch2-4`; temporary branches retire after merge. No new proof fill, new branch or merge request is made.

**Not yet clear to merge — comment fixes and S2 are combined; fresh native/seal/axiom/export verification is pending.**
