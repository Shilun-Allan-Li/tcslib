#!/usr/bin/env python3
"""Own bounded static namespace/digest review; never import proposed programs."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
PREP = ROOT / '.lake/ps-maintainer/gate06-combined-20261108/rule10-prep'
OUT = Path(__file__).resolve().parent
OLD = PREP / 'assembly-draft-6'
PINS = {'old': '49160a0ee7b1c8c6cf832fb554501590fd0ed724b1bb7f439e4e7aaeffdcafa6',
        'new': '3e88ead59d2169a3300c8c53bb08b187bc6226425fd417b3ce9291c5355df995',
        'outer': '742812222eb8dfc2aca4259aad7ac6c5f875025ee7abef27839cabc3811347e4'}


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def redact_assignments(raw, names):
    nodes = [node for node in ast.parse(raw).body if isinstance(node, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id in names for t in node.targets)]
    need(len(nodes) == len(names), 'missing/ambiguous propagated hash assignment')
    lines = raw.splitlines(keepends=True)
    for node in sorted(nodes, key=lambda n: n.lineno, reverse=True):
        lines[node.lineno - 1:node.end_lineno] = [b'BINDING_ASSIGNMENT_REDACTED\n']
    return b''.join(lines)


def main():
    inputs = {}

    def read(path):
        need(path.is_file() and not path.is_symlink(), 'nonordinary input: ' + str(path))
        raw = path.read_bytes()
        inputs[str(path)] = {'sha256': digest(raw), 'bytes': len(raw)}
        return raw

    old_raw = read(OLD / 'proposal-manifest.json')
    new_raw = read(PREP / 'proposal-manifest.json')
    outer_raw = read(PREP / 'final-prep-manifest.json')
    need(digest(old_raw) == PINS['old'] and digest(new_raw) == PINS['new']
         and digest(outer_raw) == PINS['outer'], 'review manifest pin differs')
    old, new, outer = map(json.loads, (old_raw, new_raw, outer_raw))
    need(set(old['tools']) == set(new['tools']), 'tool set changed')
    results = {}
    assignments = {'prepare_gate06_final_collector.py': {'TOOL_HASHES'},
                   'prepare_gate06_final.py': {'PREPARER_SHA'},
                   'run_gate06_final_native.py': {'FIXED_SHA', 'BUILD_SHA', 'PREPARATION_SHA'}}
    direct = {'request_payload_adapter.py', 'collect_body.lean.source.txt'}
    for name in old['tools']:
        before = read(OLD / 'proposed-tools' / name)
        after = read(PREP / 'proposed-tools' / name)
        need(digest(before) == old['tools'][name]['sha256']
             and digest(after) == new['tools'][name]['sha256'], 'old/new leaf hash differs')
        if name in direct:
            need(before.count(b'Lean.isInstanceCore') == 1 and
                 before.replace(b'Lean.isInstanceCore', b'Lean.Meta.isInstanceCore') == after,
                 'namespace-only direct delta differs: ' + name)
            results[name] = 'exactly_one_namespace_qualification'
        elif name in assignments:
            need(redact_assignments(before, assignments[name]) ==
                 redact_assignments(after, assignments[name]), 'nonbinding program change: ' + name)
            results[name] = 'hash_binding_propagation_only'
        else:
            need(before == after, 'unexpected changed tool: ' + name)
            results[name] = 'byte_identical'
        need(b'Lean.isInstanceCore' not in after, 'stale instance API in generated tool')
    for name, binding in outer['files'].items():
        need(Path(name).name == name, 'unexpected outer manifest path')
        raw = read(PREP / name)
        need(digest(raw) == binding['sha256'] and len(raw) == binding['bytes'],
             'outer binding differs: ' + name)
    before = read(OLD / 'Collect.proposed.source.txt')
    after = read(PREP / 'Collect.proposed.source.txt')
    need(before.count(b'Lean.isInstanceCore') == 1 and
         before.replace(b'Lean.isInstanceCore', b'Lean.Meta.isInstanceCore') == after,
         'complete collector has extra changes')
    for name in ['scope-proposal.json', 'complete-source-identities.json']:
        need(read(OLD / name) == read(PREP / name), 'source/closure scope changed')
    for name in ['combined_payload_adapter.py', 'catalog-command.source.txt',
                 'InstancePrototype-Unsealed.source.txt', 'InstancePrototype-Sealed.source.txt']:
        raw = read(PREP / name)
        need(raw.count(b'Lean.Meta.isInstanceCore') == 1 and b'Lean.isInstanceCore' not in raw,
             'missing/stale instance API qualification: ' + name)
    body = b'''theorem instanceBody :
    (default : Turing.Cfg 0 Bool Unit []) =
      \xe2\x9f\xa8none, 0, (fun _ _ => none), (fun _ => 0), []\xe2\x9f\xa9 := rfl
'''
    for mode in ['Unsealed', 'Sealed']:
        raw = read(PREP / f'InstancePrototype-{mode}.source.txt')
        need(raw.count(body) == 1 and raw.count(b':= rfl') == 1,
             'prototype constructor body/proof count differs')
    setup = json.loads(read(PREP / 'proposed-tools/setup-summary.json'))
    tree = str(ROOT / '.lake/ps-maintainer/gate06-combined-20261108/oleans-r1')
    need(setup['olean_tree'] == tree, 'unexpected tree')
    runner = read(PREP / 'proposed-tools/run_gate06_final_native.py')
    need(('OLEANS = Path(' + repr(tree) + ')').encode() in runner, 'runner tree differs')
    need(b'len({p[\'label\'] for p in probes}) == 13' in runner and
         b'"controls": 11' not in read(PREP / 'proposed-tools/prepare_gate06_final.py'),
         'old eleven-control regression')
    lean = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean/Lean/Meta/Instances.lean')
    primary = read(lean).decode().splitlines()
    need(primary[14] == 'namespace Lean.Meta' and primary[269].startswith('def isInstanceCore '),
         'pinned primary API location differs')
    for path, binding in inputs.items():
        raw = Path(path).read_bytes()
        need(digest(raw) == binding['sha256'] and len(raw) == binding['bytes'], 'input changed during review')
    result = {'status': 'STATIC_NAMESPACE_DELTA_VALIDATED_NOT_NATIVE', 'pins': PINS,
              'program_delta': results, 'outer_leaf_bindings': len(outer['files']),
              'tree': tree, 'inputs': inputs,
              'limits': ['No proposed program imported or executed.',
                         'No native/module/owner/sensitivity result.',
                         'Old prototypes were not included in assembly-draft-6; current constructor body and qualification were checked.']}
    with (OUT / 'delta-validation.json').open('xb') as handle:
        handle.write((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps({k: v for k, v in result.items() if k != 'inputs'}))


if __name__ == '__main__':
    main()
