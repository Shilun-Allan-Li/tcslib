"""Own immutable-Git combined-source review. No native, branch or tracked-file writes."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
HERE = Path(__file__).resolve().parent
JOINT = ROOT / '.lake/ps-maintainer/gate06c-20261108/combined-comment-proposals-r2'
OLD = '3f6db40e1688c4a0bb922c9575dd3bd2157a650b'
OLD_BASE = 'eee107e92a7db11f1f8c98a5c2867304f57ddc54'
BASE = '067c5d8d6dd436e62681d7dc607984c705dc80a2'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
S2_MERGE = '1aa5506f58f77c215e56d24311ec33bd931cacf1'
S2_ACCEPTED = 'd8c4cfed793f04062e7e79b78344e5b593ff3ddc'
CLEANUP = '32b827c017bc321ea40577bc8f27131df2c35e1a'
PATCH_SHA = 'ff7cd28cb4b92d83702f3aba81718c742a7c4f3167d19f5b6becbc62c50e018d'
INPUTS = {}


def sha(b): return hashlib.sha256(b).hexdigest()
def read(path):
    b = path.read_bytes(); INPUTS[str(path)] = {'bytes': len(b), 'sha256': sha(b)}; return b
def load(path): return json.loads(read(path))
def save(name, value):
    with (HERE / name).open('x') as f: json.dump(value, f, indent=2); f.write('\n')
def git(*args):
    return subprocess.run(['git', '-C', str(ROOT), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout
def command(*args):
    r = subprocess.run(['git', '-C', str(ROOT), *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return {'args': list(args), 'rc': r.returncode, 'stdout': r.stdout.decode(), 'stderr': r.stderr.decode()}
def is_source(path):
    return path.endswith('.lean') and (path.startswith('TCSlib/') or path in ('TCSlib.lean', 'audits/pass-shelat/Checks.lean'))
def source_blobs(rev):
    rows = {}
    for raw in git('ls-tree', '-r', rev, '--', 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean').decode().splitlines():
        meta, path = raw.split('\t'); mode, kind, digest = meta.split()
        if is_source(path):
            assert mode == '100644' and kind == 'blob'; rows[path] = digest
    return rows
def sources(rev):
    result = {}
    raw = git('archive', rev, 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean')
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for item in archive:
            if item.isfile() and is_source(item.name): result[item.name] = archive.extractfile(item).read()
    return result


def comment_projection(text):
    """Remove comments; retain literal spellings exactly, including internal whitespace."""
    out = []; literals = []; i = 0
    def literal(end):
        nonlocal i
        raw = text[i:end]; out.append('\x00' + str(len(literals)) + '\x00'); literals.append(raw); i = end
    while i < len(text):
        if text.startswith('/-', i):
            depth = 1; j = i+2
            while depth:
                assert j < len(text), 'unterminated comment'
                if text.startswith('/-', j): depth += 1; j += 2
                elif text.startswith('-/', j): depth -= 1; j += 2
                else: j += 1
            out.append(' '); i = j
        elif text.startswith('--', i):
            j = text.find('\n', i); out.append(' '); i = len(text) if j < 0 else j
        elif text[i] == '«':
            j = text.find('»', i+1); assert j >= 0; literal(j+1)
        elif (m := re.match(r'r(#+)?"', text[i:])) and (i == 0 or not (text[i-1].isalnum() or text[i-1] in "_'")):
            suffix = '"' + (m[1] or ''); j = text.find(suffix, i+len(m[0])); assert j >= 0; literal(j+len(suffix))
        elif text[i] == '"':
            j = i+1
            while True:
                assert j < len(text), 'unterminated string'
                if text[j] == '\\': j += 2
                elif text[j] == '"': literal(j+1); break
                else: j += 1
        elif text[i] == "'" and (i == 0 or not (text[i-1].isalnum() or text[i-1] in "_'")) and (m := re.match(r"'(?:\\(?:u\{[0-9a-fA-F]+\}|[^\n])|[^'\\\n])'", text[i:])):
            literal(i+len(m[0]))
        else: out.append(text[i]); i += 1
    raw = ''.join(out)
    return raw, ' '.join(raw.split()), literals
def code_hash(text):
    _, code, literals = comment_projection(text)
    return sha(json.dumps([code, literals], ensure_ascii=False).encode())


def apply_plain(data, patch):
    """Strict unified-patch in-memory replay, without fuzz or whitespace substitution."""
    lines = patch.decode().splitlines(keepends=True); i = 0; result = data.copy(); history = []
    while i < len(lines):
        assert lines[i].startswith('--- a/'), (i, lines[i])
        path = lines[i][6:].removesuffix('\n'); i += 1
        assert lines[i] == '+++ b/' + path + '\n'; i += 1
        assert path in result and not Path(path).is_absolute() and '..' not in Path(path).parts
        original = result[path].decode().splitlines(keepends=True); new = []; cursor = 0; hunks = []
        while i < len(lines) and lines[i].startswith('@@ '):
            m = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i]); assert m
            a, ac, b, bc = [int(x) if x is not None else 1 for x in m.groups()]; i += 1
            oldseg = []; newseg = []
            while len(oldseg) < ac or len(newseg) < bc:
                line = lines[i]; assert line[0] in ' +-'; i += 1
                if line[0] in ' -': oldseg.append(line[1:])
                if line[0] in ' +': newseg.append(line[1:])
            assert len(oldseg) == ac and len(newseg) == bc
            start = a-1 if ac else a; assert start >= cursor and original[start:start+ac] == oldseg
            new.extend(original[cursor:start]); assert len(new) == (b-1 if bc else b)
            new.extend(newseg); cursor = start+ac; hunks.append({'old': [a, ac], 'new': [b, bc]})
        new.extend(original[cursor:]); result[path] = ''.join(new).encode()
        history.append({'path': path, 'old_sha256': sha(data[path]), 'new_sha256': sha(result[path]), 'hunks': hunks})
    return result, history


def main():
    # Pure own-utility use only; never import/run another party's validator.
    prior_dir = ROOT / '.lake/ps-maintainer/cleanup-review-2026-11-08/partial-r1/review-source-scope'
    prior_mf = load(prior_dir / 'manifest.json')
    assert sha((prior_dir / 'manifest.json').read_bytes()) == 'a9b58ac78b9149f33cf2140fb551ca5a879d39e1b09066ac908f8c43cb26c6f8'
    utility = read(prior_dir / 'validate.py')
    assert sha(utility) == next(r['sha256'] for r in prior_mf['outputs'] if r['path'] == 'validate.py')
    ast.parse(utility.decode()); own = {'__file__': str(prior_dir/'validate.py'), '__name__': 'own_lexical_definitions'}
    exec(compile(utility, str(prior_dir/'validate.py'), 'exec'), own); parse = own['parse']; plain = own['plain']
    # Literal/comment sensitivity checks, independent of the actual proposal data.
    eq = lambda a, b: code_hash(a) == code_hash(b)
    tests = {
        'nested_comments': eq('def x /- a /- b -/ c -/ := 1', 'def x /- z -/ := 1'),
        'line_comment': eq('def x := 1 -- a\n', 'def x := 1 -- b\n'),
        'string_whitespace_sensitive': not eq('def x := "a b"', 'def x := "a  b"'),
        'string_comment_text_preserved': not eq('def x := "/- a -/"', 'def x := "/- b -/"'),
        'raw_string_preserved': not eq('def x := r#"-- a"#', 'def x := r#"-- b"#'),
        'quoted_identifier_preserved': not eq('def «/- a -/» := 1', 'def «/- b -/» := 1'),
        'character_quote_preserved': eq("def x := '\\\"' /- a -/", "def x := '\\\"' /- b -/"),
        'code_change_rejected': not eq('def x := 1', 'def x := 2')}
    assert all(tests.values())
    parents = git('show', '-s', '--format=%P', HEAD).decode().split(); assert parents == [OLD, BASE]
    no_cleanup = command('merge-base', '--is-ancestor', CLEANUP, HEAD); assert no_cleanup['rc'] == 1
    assert command('merge-base', '--is-ancestor', S2_MERGE, BASE)['rc'] == 0
    joint = load(JOINT / 'validation.json'); patch = read(JOINT / 'all-minor-prose-corrections.patch')
    assert sha(patch) == PATCH_SHA and joint['patch_sha256'] == PATCH_SHA and joint['audited_source_head'] == OLD
    comment_paths = {r['path'] for r in joint['files']}; assert len(comment_paths) == 13
    old = sources(OLD); new = sources(HEAD); old_ids = source_blobs(OLD); new_ids = source_blobs(HEAD)
    base_ids = source_blobs(BASE); old_base_ids = source_blobs(OLD_BASE); s2_ids = source_blobs(S2_MERGE)
    assert set(old) == set(new) == set(old_ids) == set(new_ids)
    s2_paths = {p for p in set(old_base_ids)|set(base_ids) if old_base_ids.get(p) != base_ids.get(p)}
    assert len(s2_paths) == 5 and not s2_paths & comment_paths
    assert base_ids == s2_ids, 'current base has unreviewed library source beyond accepted S2'
    for p in s2_paths: assert new[p] == git('show', S2_ACCEPTED + ':' + p)
    expected, replay = apply_plain(old, patch)
    comment_rows = []
    for row in joint['files']:
        path = row['path']; snapshot = read(JOINT / 'src' / path)
        assert sha(old[path]) == row['original_sha256'] and sha(snapshot) == row['proposed_sha256']
        assert expected[path] == snapshot == new[path]
        before = comment_projection(old[path].decode()); after = comment_projection(snapshot.decode())
        assert before[1:] == after[1:]
        comment_rows.append({'path': path, 'old_sha256': sha(old[path]), 'new_sha256': sha(snapshot),
            'literal_aware_noncomment_code_hash': code_hash(snapshot.decode()),
            'normalized_noncomment_and_literals_identical': True,
            'exact_noncomment_projection_identical': before[0] == after[0]})
    for path in s2_paths: expected[path] = git('show', S2_ACCEPTED + ':' + path)
    assert expected == new, 'combined source has bytes beyond S2 plus 13 comments'
    update_paths = {p for p in old if old[p] != new[p]}
    assert update_paths == s2_paths | comment_paths and len(update_paths) == 18
    pr_paths = {p for p in set(base_ids)|set(new_ids) if base_ids.get(p) != new_ids.get(p)}
    audited_paths = {p for p in set(old_base_ids)|set(old_ids) if old_base_ids.get(p) != old_ids.get(p)}
    assert pr_paths == audited_paths and len(pr_paths) == 61 and comment_paths <= pr_paths
    all_pr_diff = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
    assert set(all_pr_diff) == pr_paths, 'records/non-source change on PR branch'
    whitespace = command('diff', '--check', BASE, HEAD, '--', *sorted(pr_paths)); assert whitespace['rc'] == 0
    # Derive current-base bytes through exact Git blob identity; read only changed blobs.
    base = {}
    for path, digest in base_ids.items():
        base[path] = new[path] if new_ids.get(path) == digest else git('show', BASE + ':' + path)
    module_paths = {p[:-5].replace('/', '.'): p for p in new}
    graph = {}; fingerprints = []
    for mod, path in sorted(module_paths.items()):
        _, code, _ = comment_projection(new[path].decode())
        # Imports are read from ordinary source lines; comments cannot create an import.
        code_lines = own['mask'](new[path].decode()).splitlines()
        imports = [name for line in code_lines if (m := re.match(r'^\s*(?:public\s+)?import\s+(.+)', line)) for name in m[1].split()]
        assert all(not x.startswith('TCSlib.') or x in module_paths for x in imports)
        graph[mod] = [x for x in imports if x in module_paths]
        fingerprints.append({'module': mod, 'path': path, 'sha256': sha(new[path]), 'bytes': len(new[path]), 'imports': imports})
    active = set(); done = set(); order = []
    def visit(mod):
        assert mod not in active, ('cycle', mod)
        if mod in done: return
        active.add(mod)
        for dep in graph[mod]: visit(dep)
        active.remove(mod); done.add(mod); order.append(mod)
    for mod in sorted(graph): visit(mod)
    # Changed-source API/header comparison. Accepted S2 changes stay exact d8c4cfed bytes.
    old_decls = []; new_decls = []
    for path in sorted(update_paths):
        old_decls.extend(parse(old[path].decode(), path)); new_decls.extend(parse(new[path].decode(), path))
    key = lambda d: (d['path'], d['canonical']) if d['private'] else ('PUBLIC', d['canonical'])
    om = {key(d): d for d in old_decls}; nm = {key(d): d for d in new_decls}
    assert len(om) == len(old_decls) and len(nm) == len(new_decls)
    delta = []; public_headers = []
    for k in sorted(set(om)|set(nm)):
        a = om.get(k); b = nm.get(k); flags_ = []
        if a is None: flags_.append('ADDED')
        elif b is None: flags_.append('REMOVED')
        else:
            if code_hash(a['header']) != code_hash(b['header']): flags_.append('HEADER_CODE_CHANGED')
            if code_hash(a['body']) != code_hash(b['body']): flags_.append('BODY_CODE_CHANGED')
            assert a['mods'] == b['mods'] and a['preceding_attributes'] == b['preceding_attributes'] and a['same_line_attributes'] == b['same_line_attributes']
            if not a['private']:
                assert code_hash(a['header']) == code_hash(b['header']); public_headers.append(a['canonical'])
                if a['kind'] not in ('theorem','lemma'): assert code_hash(a['body']) == code_hash(b['body'])
        if flags_:
            assert (a or b)['path'] in s2_paths
            delta.append({'key': k, 'flags': flags_, 'old': plain(a) if a else None, 'new': plain(b) if b else None,
                          'authority': 'EXACT_ALREADY_ACCEPTED_S2_SOURCE'})
    # Full lexical admissions in library/root/Checks, keeping quoted Name tokens separate.
    tok = re.compile(r"(?<![\w'])\b(sorryAx|sorry|admit|axiom)\b(?![\w'])")
    admissions = []; totals = {}
    for label, data in [('CURRENT_BASE', base), ('AUDITED_G06', old), ('COMBINED', new)]:
        for path, raw in data.items():
            projected, _, _ = comment_projection(raw.decode())
            for number, line in enumerate(projected.splitlines(), 1):
                for m in tok.finditer(line):
                    quoted = m.group(1) == 'sorryAx' and line[:m.start()].rstrip().endswith('`')
                    admissions.append({'revision': label, 'path': path, 'projected_line': number, 'token': m.group(1),
                                       'kind': 'QUOTED_NAME_METADATA' if quoted else 'LEXICAL_ADMISSION_OR_AXIOM'})
        totals[label] = dict(Counter(r['token'] for r in admissions if r['revision'] == label))
    # All Gate06 theorem admissions are retained exactly in logical code.
    math_scope = []; g06_math = []; scope_admissions = []; declaration_counts = {}
    for path in sorted(pr_paths | s2_paths):
        ds = parse(new[path].decode(), path); declaration_counts[path] = len(ds)
        if ds:
            math_scope.append(path)
            if path in pr_paths: g06_math.append(path)
            for d in ds:
                if tok.search(comment_projection(d['raw'])[0]):
                    scope_admissions.append({'path': path, 'canonical_source_name': d['canonical'], 'kind': d['kind'],
                          'private': d['private'], 'source_start': d['start'], 'source_end': d['end'],
                          'raw_sha256': d['raw_sha256'], 'code_sha256': code_hash(d['raw'])})
        if path in pr_paths:
            prev = {key(d): d for d in parse(old[path].decode(), path)}
            for d in ds:
                if tok.search(comment_projection(d['raw'])[0]): assert code_hash(prev[key(d)]['raw']) == code_hash(d['raw'])
    assert len(g06_math) == 54 and len(math_scope) == 59
    save('comment-comparison.json', {'fixtures': tests, 'files': comment_rows})
    save('joint-patch-replay.json', replay)
    save('combined-source-fingerprints.json', fingerprints)
    save('local-import-graph.json', {'edges': graph, 'topological_order': order, 'cycles': [], 'missing_local_imports': []})
    save('source-api-delta.json', delta)
    save('delta-declarations-audited.json', [plain(d) for d in old_decls]); save('delta-declarations-combined.json', [plain(d) for d in new_decls])
    save('lexical-admissions.json', {'counts': totals, 'occurrences': admissions,
          'limit': 'Lexical source census; quoted sorryAx metadata is not a direct admission or a native axiom dependency.'})
    save('census-scope.json', {'source_head': HEAD, 'Gate06_math_paths': g06_math, 'accepted_S2_paths': sorted(s2_paths),
        'combined_math_paths': math_scope, 'module_owners': [p[:-5].replace('/', '.') for p in math_scope],
        'Gate06_math_count': len(g06_math), 'combined_math_count': len(math_scope),
        'facade_root_paths': sorted(pr_paths - set(g06_math)), 'explicit_declaration_counts': declaration_counts,
        'source_admitted_declarations': scope_admissions,
        'native_actual_Name_or_axiom_identity_count': 'NOT_MEASURED; ROOT_FRESH_COLLECTOR_REQUIRED',
        'scope_requirement': 'All stored actual constants of each owner: type/value, private/generated/opaque and axiom-free included. Root/Checks remain separately required; facade/root import checks remain required.'})
    summary = {'status': 'BOUNDED_COMBINED_SOURCE_STATIC_REVIEW_NO_NATIVE_ACCEPTANCE', 'head': HEAD, 'base': BASE, 'audited_head': OLD,
        'merge_parents_exact': parents, 'source_update_paths': sorted(update_paths), 'source_update_count': len(update_paths),
        'S2_paths': sorted(s2_paths), 'comment_paths': sorted(comment_paths), 'PR_paths_vs_current_base': sorted(pr_paths),
        'PR_source_paths_count': len(pr_paths), 'no_records_or_other_PR_paths': True,
        'all13_snapshot_hashes_verified': True, 'all13_comment_code_and_literals_identical': True,
        'all5_S2_files_exact_accepted_d8c4cfed': True, 'full_library_source_equals_exact_authorized_union': True,
        'cleanup_32b_ancestor': False, 'no_cleanup_delta_incorporated': True,
        'retained_public_headers_checked': len(public_headers), 'retained_public_header_or_data_code_changes': 0,
        'code_changes_beyond_comments': dict(Counter(f for d in delta for f in d['flags'])),
        'all_code_changes_exact_accepted_S2': True, 'lexical_counts': totals,
        'combined_source_files_including_root_Checks': len(new), 'Gate06_math_census_scope': len(g06_math), 'combined_math_census_scope': len(math_scope),
        'scope_source_admitted_declarations': len(scope_admissions), 'source_import_cycles': 0, 'missing_local_imports': 0,
        'PR_source_whitespace_check': whitespace, 'cleanup_ancestry_check': no_cleanup,
        'native_or_incoming_program_execution': False, 'tracked_source_Main_exchange_Git_mutations': False, 'merge_clearance': False}
    save('summary.json', summary)
    save('input-bindings.json', [{'path': p, **v} for p,v in sorted(INPUTS.items())])
    print(json.dumps({k:v for k,v in summary.items() if not isinstance(v, (list,dict))}, indent=2))
    print('LEXICAL_COUNTS', totals)


if __name__ == '__main__': main()
