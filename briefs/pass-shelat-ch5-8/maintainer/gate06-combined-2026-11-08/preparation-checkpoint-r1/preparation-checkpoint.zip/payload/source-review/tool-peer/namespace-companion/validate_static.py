#!/usr/bin/env python3
"""Own static peer validation only: no proposed import, exec, process, or Lean."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
BASE = ROOT / '.lake/ps-maintainer/gate06-combined-20261108'
PREP = BASE / 'rule10-prep'
OUT = BASE / 'source-review/tool-peer/namespace-companion'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    need(path.is_file() and not path.is_symlink(), 'nonordinary input: ' + str(path))
    return path.read_bytes()


def assignment(tree, key):
    nodes = [node.value for node in tree.body if isinstance(node, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == key for t in node.targets)]
    need(len(nodes) == 1, 'nonunique literal assignment: ' + key)
    return ast.literal_eval(nodes[0])


def main():
    inputs = {}

    def capture(path):
        raw = read(path)
        key = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
        inputs[key] = {'sha256': sha(raw), 'bytes': len(raw)}
        return raw

    proposal = json.loads(capture(PREP / 'proposal-manifest.json'))
    assembler = capture(PREP / 'prepare_proposals.py')
    need(sha(assembler) == proposal['source_sha256'], 'proposal assembler source binding differs')
    ast.parse(assembler)
    scope = json.loads(capture(PREP / 'scope-proposal.json'))
    identities = json.loads(capture(PREP / 'complete-source-identities.json'))
    source_scope = json.loads(capture(BASE / 'source-review/census-scope.json'))
    fingerprints = json.loads(capture(BASE / 'source-review/combined-source-fingerprints.json'))
    frozen = {row['path']: row for row in fingerprints
              if row['path'] == 'TCSlib.lean' or row['path'].startswith('TCSlib/')}
    check_only = [row['path'] for row in fingerprints if row['path'] not in frozen]
    need(check_only == ['audits/pass-shelat/Checks.lean'], 'unrecognized source-review check-only input')
    graph = {row['module']: [m for m in row['imports']
                            if m == 'TCSlib' or m.startswith('TCSlib.')]
             for row in fingerprints}
    need(proposal['head'] == scope['head'] == source_scope['source_head'] == HEAD, 'wrong source head')
    need(set(scope['modules']) == set(source_scope['module_owners']), 'owner scopes differ')
    need(proposal['expected_math_owners'] == scope['math_modules'] == len(scope['modules']) == 59,
         'owner count differs')
    need(set(identities) == set(frozen), 'complete source-identity path set differs')
    for path, identity in identities.items():
        need(identity['sha256'] == frozen[path]['sha256'] and identity['bytes'] == frozen[path]['bytes'],
             'complete source identity differs: ' + path)
    for module, path in scope['modules'].items():
        need(module == path[:-5].replace('/', '.'), 'module/path differs')
        need(scope['source_sha256'][path] == frozen[path]['sha256'], 'owner fingerprint differs')
        found, stack = set(), graph[module][:]
        while stack:
            dep = stack.pop()
            if dep in found:
                continue
            need(dep in graph, 'missing local dependency: ' + dep)
            found.add(dep)
            stack.extend(graph[dep])
        need(module not in found and sorted(found) == scope['closures'][module], 'closure differs: ' + module)

    tools, trees = {}, {}
    for name, binding in proposal['tools'].items():
        raw = capture(PREP / 'proposed-tools' / name)
        need(sha(raw) == binding['sha256'] and len(raw) == binding['bytes'], 'tool binding differs: ' + name)
        tools[name] = raw
        if name.endswith('.py'):
            trees[name] = ast.parse(raw, filename=name)  # syntax only, never import/exec
    capture(PREP / 'validate_combined_census.py')
    ast.parse(read(PREP / 'validate_combined_census.py'))
    capture(PREP / 'combined_payload_adapter.py')
    need(read(PREP / 'combined_payload_adapter.py') == tools['request_payload_adapter.py'],
         'root/proposed adapter copies differ')
    setup = json.loads(capture(PREP / 'proposed-tools/setup-summary.json'))
    need(setup['head'] == HEAD, 'setup head differs')

    hashes = assignment(trees['prepare_gate06_final_collector.py'], 'TOOL_HASHES')
    need(set(hashes) == {'build_seals.py', 'build_controls.py', 'request_payload_adapter.py',
         'prepare_audit.py', 'touched.py', 'check_probe_v2.py', 'legacy_request_payload_adapter.py',
         'collect_body.lean'}, 'preparer alias set differs')
    for alias, digest in hashes.items():
        name = alias + '.source.txt' if alias.endswith('.lean') else alias
        need(digest == proposal['tools'][name]['sha256'], 'preparer alias hash differs: ' + alias)
    need(assignment(trees['prepare_gate06_final.py'], 'PREPARER_SHA') ==
         proposal['tools']['prepare_gate06_final_collector.py']['sha256'], 'preparer self binding differs')
    runner = trees['run_gate06_final_native.py']
    need(assignment(runner, 'PREPARATION_SHA') == hashes, 'runner preparer hashes differ')
    build = assignment(runner, 'BUILD_SHA')
    need(set(build) == {'build_seals.py', 'build_controls.py', 'request_payload_adapter.py'},
         'runner builder set differs')
    need(all(build[n] == proposal['tools'][n]['sha256'] for n in build), 'runner builder hashes differ')
    verify_controls = next(n for n in runner.body if isinstance(n, ast.FunctionDef)
                           and n.name == 'verify_controls')
    label_checks = [n for n in ast.walk(verify_controls) if isinstance(n, ast.Compare)
                    and isinstance(n.left, ast.Call) and isinstance(n.left.func, ast.Name)
                    and n.left.func.id == 'len' and len(n.left.args) == 1
                    and isinstance(n.left.args[0], ast.SetComp)
                    and isinstance(n.left.args[0].elt, ast.Subscript)
                    and isinstance(n.left.args[0].elt.slice, ast.Constant)
                    and n.left.args[0].elt.slice.value == 'label']
    need(len(label_checks) == 1 and len(label_checks[0].comparators) == 1
         and isinstance(label_checks[0].ops[0], ast.Eq)
         and ast.literal_eval(label_checks[0].comparators[0]) == 13,
         'runner exact 13-label cardinality guard differs')
    fixed = assignment(runner, 'FIXED_SHA')
    for path, digest in fixed.items():
        raw = capture(Path(path))
        need(sha(raw) == digest, 'runner fixed binding differs: ' + path)
    need(assignment(trees['request_payload_adapter.py'], 'LEGACY_SHA') ==
         proposal['tools']['legacy_request_payload_adapter.py']['sha256'], 'legacy adapter pin differs')

    c3_imports = [line[7:] for line in tools['C3.source.txt'].decode().splitlines()
                  if line.startswith('import ')]
    need(c3_imports == ['Lean', *scope['modules']], 'C3 direct-import list/order differs')
    body = tools['collect_body.lean.source.txt'].decode()
    substitutions = [('ts.any fun t => s == t', 'ts.any fun t => t == "*" || s == t'),
                     ('for t in ts do\n    unless ours.any', 'for t in ts do\n    if t == "*" then continue\n    unless ours.any'),
                     ('if s == t || s.endsWith', 'if t == "*" || s == t || s.endsWith')]
    axiom_log = 'logInfo m!"AXIOMS {modN} | {s} | {axs.toList}"'
    substitutions.append((axiom_log, axiom_log + '\n          logInfo m!"AXIOMSID {modN} | {n.toString} | display={s} | {axs.toList}"'))
    for old, new in substitutions:
        need(body.count(old) == 1, 'collector wildcard/actual-axiom anchor differs')
        body = body.replace(old, new)
    closure_body = assignment(trees['prepare_audit.py'], 'closure_body')
    reconstructed = '\n'.join(['import Lean', *('import ' + m for m in scope['modules']),
                                'set_option maxHeartbeats 0', body, closure_body]) + '\n'
    for module in scope['modules']:
        reconstructed += '#collect ' + module + ' ["*"]\n#axs ' + module + ' ["*"]\n'
        reconstructed += '#sealclosure ' + module + ' [' + ', '.join(scope['closures'][module]) + ']\n'
    need(reconstructed.encode() == capture(PREP / 'Collect.proposed.source.txt'),
         'proposed complete collector differs from reviewed text construction')
    for name in ['assembly-draft-4/C3-expanded-families.patch', 'C3-splitter-kind-and-output.patch']:
        capture(PREP / name)
    need(proposal['notation_exclusions_exact'] == ['Complexity.PolyExpr.eval'], 'notation omission differs')
    need(proposal['expected_controls'] == 13 and proposal['instance_filter_removed'] and
         proposal['opaque_seed_values_included'] and proposal['actual_Name_component_checks'],
         'declared new surfaces differ')
    lean = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean')
    for name in ['Lean/Declaration.lean', 'Lean/ReducibilityAttrs.lean',
                 'Lean/Meta/Instances.lean', 'Lean/Data/Json/FromToJson/Basic.lean',
                 'Lean/Util/FoldConsts.lean', 'Lean/Meta/Match/Basic.lean',
                 'Lean/Meta/Match/MatchEqs.lean', 'Lean/PrivateName.lean']:
        capture(lean / name)

    for path, binding in inputs.items():
        raw = read(ROOT / path)
        need(sha(raw) == binding['sha256'] and len(raw) == binding['bytes'], 'input changed during peer validation')
    output = {'status': 'STATIC_ONLY_NO_PROPOSED_EXECUTION', 'head': HEAD,
              'validator_sha256': sha(read(Path(__file__))),
              'owners': len(scope['modules']), 'complete_source_paths': len(frozen),
              'separate_check_only_fingerprint_paths': check_only,
              'proposed_tool_bindings': len(tools), 'python_syntax_parsed': len(trees) + 2,
              'preparation_aliases': len(hashes), 'builder_aliases': len(build),
              'c3_imports': len(c3_imports), 'inputs': inputs,
              'limits': ['No proposed module imported or executed; AST literals and JSON only.',
                         'No Lean/native/cache/build/app/Git/source mutation.',
                         'Syntax/hash/graph equality does not establish Lean elaboration or control sensitivity.']}
    target = OUT / 'validation-final.json'
    with target.open('xb') as handle:
        handle.write((json.dumps(output, indent=2) + '\n').encode())
    print(json.dumps({k: v for k, v in output.items() if k != 'inputs'}))


if __name__ == '__main__':
    main()
