"""One guarded, narrowed Mathlib cache operation; no project library build."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import resource
import subprocess
import time

W = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
AREA = Path(__file__).resolve().parent
PREP = AREA / 'native-prep'
OUT = AREA / 'cache-r1'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def ordinary_env():
    env = dict(os.environ)
    env['PATH'] = str(Path.home() / '.elan/bin') + ':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    env.pop('PFR_BOOTSTRAP_CONFIG', None)
    return env


def active_native():
    rows = []
    for line in subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True).splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) != 2:
            continue
        name = Path(parts[1]).name
        if name in {'lean', 'lake', 'leantar'} or (name == 'cache' and '/mathlib/' in parts[1]):
            rows.append({'pid': int(parts[0]), 'command': parts[1]})
    return rows


def main():
    assert not OUT.exists()
    OUT.mkdir()
    assert sha(PREP / 'NATIVE-PREP-MANIFEST.json') == '2f410bf13ab9dc4398107476a95ec5ad8ef8f3e862646daca128cdfe4497c612'
    manifest = json.loads((PREP / 'NATIVE-PREP-MANIFEST.json').read_text())
    for row in manifest['files']:
        assert sha(PREP / row['path']) == row['sha256'], row['path']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W).strip()
    roots_file = PREP / 'external-r1/narrowed-cache-roots.txt'
    assert sha(roots_file) == '82733d00784ad369f0a63dfb366161f7959d64697084faa4b9cd4c392940c3ea'
    roots = roots_file.read_text().splitlines()
    assert len(roots) == len(set(roots)) == 54
    assert all(re.fullmatch(r'Mathlib(?:\.[A-Za-z_0-9]+)+', root) for root in roots)
    mem = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True))
    pressure = subprocess.check_output(['memory_pressure', '-Q'], text=True)
    match = re.search(r'System-wide memory free percentage:\s*(\d+)%', pressure)
    assert match, pressure
    headroom = mem * int(match.group(1)) // 100
    disk = os.statvfs(W)
    free = disk.f_bavail * disk.f_frsize
    vm = subprocess.check_output(['vm_stat'], text=True)
    cache = Path(os.environ.get('XDG_CACHE_HOME', str(Path.home() / '.cache'))) / 'mathlib'
    cache_files = [p for p in cache.rglob('*') if p.is_file()] if cache.exists() else []
    preflight = {'utc': utc(), 'physical_memory_bytes': mem,
        'mac_memory_pressure_raw': pressure, 'mac_vm_stat_raw': vm,
        'estimated_mac_headroom_bytes': headroom, 'free_disk_bytes': free,
        'cache_store': str(cache), 'cache_store_exists': cache.exists(),
        'cache_archive_count_before': len(cache_files),
        'cache_archive_bytes_before': sum(p.stat().st_size for p in cache_files),
        'method_limit': 'macOS memory-pressure estimate, not a Linux cgroup reading',
        'runner_sha256': sha(Path(__file__)), 'native_plan_manifest_sha256': sha(PREP / 'NATIVE-PREP-MANIFEST.json')}
    (OUT / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')
    assert headroom >= 4 * 1024**3 and free >= 12 * 1024**3, preflight
    for sample in range(2):
        active = active_native()
        if active:
            (OUT / 'HOST-DEFERRED.json').write_text(json.dumps({'utc': utc(), 'active': active, 'native_started': False}, indent=2) + '\n')
            raise SystemExit('HOST_DEFERRED: no cache operation started')
        time.sleep(0.5)
    command = ['lake', 'exe', 'cache', 'get', *roots]
    start = utc()
    log = OUT / 'cache-get.attempt01.log'
    with log.open('xb') as stream:
        stream.write((json.dumps({'START': start, 'command': command, 'head': HEAD, 'root_count': 54}) + '\n').encode())
        stream.flush()
        proc = subprocess.Popen(command, cwd=W, env=ordinary_env(), stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        (OUT / 'cache-child.json').write_text(json.dumps({'pid': proc.pid, 'pgid': proc.pid, 'start_utc': start, 'command': command}, indent=2) + '\n')
        _, status, usage = os.wait4(proc.pid, 0)
        proc.returncode = os.waitstatus_to_exitcode(status)
        end = utc()
        stream.write((json.dumps({'END': end, 'rc': proc.returncode, 'max_rss_bytes_macos': usage.ru_maxrss}) + '\n').encode())
    packages = json.loads((PREP / 'external-r1/package-modules.json').read_text())
    missing = [row['module'] for row in packages if row['package'] != 'PFR'
               and (not Path(row['object_path']).is_file() or Path(row['object_path']).stat().st_size == 0)]
    historical = json.loads((PREP / 'external-r1/historical-mathlib-object-validation.json').read_text())
    (OUT / 'historical-input-shape.json').write_text(json.dumps({'kind': type(historical).__name__, 'keys': list(historical) if isinstance(historical, dict) else None}, indent=2) + '\n')
    result = {'start_utc': start, 'end_utc': end, 'rc': proc.returncode,
        'roots': 54, 'roots_sha256': sha(roots_file), 'log_sha256': sha(log),
        'missing_non_PFR_package_objects': missing, 'max_rss_bytes_macos': usage.ru_maxrss,
        'cache_only_not_library_build': True, 'no_manual_cache_unpack_or_object_copy': True,
        'copied_TCSlib_objects': 0, 'PFR_compiled': False,
        'passed': proc.returncode == 0 and not missing,
        'historical_146_hash_recheck': 'PENDING_BEFORE_COPY_REUSE'}
    (OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)
    assert result['passed'], 'Cache operation or required-object validation failed; retain attempt before retry'


if __name__ == '__main__':
    main()
