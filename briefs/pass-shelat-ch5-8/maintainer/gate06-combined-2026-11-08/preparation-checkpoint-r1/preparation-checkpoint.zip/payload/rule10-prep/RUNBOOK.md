# Combined Gate06 Rule10 verification proposal

**Prepared and statically reviewed; no native result is claimed here.** Freeze library source at `a495f3953afff46ad5dec2d29ac8a7f55bd8ae37`. The actual PR base is `067c5d8d6dd436e62681d7dc607984c705dc80a2`. `eee107e92a7db11f1f8c98a5c2867304f57ddc54` is the retained verification/scope ancestor, not a replacement PR base.

Use the ordinary project PATH, with no PFR-only wrapper or extra Lean flags. All native work is root-coordinated and serial through `scripts/lean_check_tree.sh`; defer while another Lean/Lake job owns the host. Old trees are read-only. The sole new tree is:

`/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/gate06-combined-20261108/oleans-r1`

The source assembler was run by the reviewer; it only read exact Git/text, generated ignored proposals, and Python-parsed source. Do not rerun it over existing outputs. Proposed tools themselves were not executed/imported by the reviewer.

## Before collection

1. Verify `proposal-manifest.json` and the peer review bind the exact final tools, the source SHA inventory, and the new tree. The current scope is exactly **old54 ∪ all5S2 = 59 math owners**, even though the actual PR diff has only 54 math owners. The 5 S2 sources equal the actual campaign target byte-for-byte; all old54 owners have identical noncomment code to `3f6…`. Facades are separate native/export context, not math-owner exclusions.
2. Finish the source-matched native prerequisite/bootstrap/affected replay. Reconcile effective objects against current source SHA, successful raw receipt, object SHA and each direct prerequisite's recorded SHA at compilation. Replay downstream importers of changed products in topological order. Root/Checks are checked only once their complete current prerequisite orders exist; carry an explicit root-unelaborated limit if root was not checked. This proposal makes no all-library pass claim.
3. The native bootstrap/PFR route belongs to the parent's reviewed native plan, not these tools. No borrowed TCS products or old-tree fallback: the new runner requires every effective required TCS object to be in `oleans-r1`. Before the collector (which precedes that runner), the root must enforce the same source/object/direct-prerequisite reconciliation. A stable object file alone does not prove current-source compilation.
4. Preserve every failed/deferred attempt in its original directory. New attempts get new directories. Never overwrite source captures, logs, JSON or first console segments.

Shell variables below are conveniences, not code already executed:

```sh
G06_COMBINED_ROOT='/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4'
G06_COMBINED_PREP="$G06_COMBINED_ROOT/.lake/ps-maintainer/gate06-combined-20261108/rule10-prep"
G06_COMBINED_TOOLS="$G06_COMBINED_PREP/proposed-tools"
G06_COMBINED_EVIDENCE="$G06_COMBINED_ROOT/.lake/ps-maintainer/gate06-combined-20261108/rule10-evidence-r1"
cd "$G06_COMBINED_ROOT"
```

## Small instance eligibility/sensitivity check

Use the two included `InstancePrototype-{Unsealed,Sealed}.source.txt` snapshots before heavy collection. They require only the current Configuration closure. Their scratch/output roots must stay separate from `rule10-r1` and `rule10-evidence-r1`, whose preparer requires fresh nonexistent roots.

```sh
mkdir .lake/ps-maintainer/gate06-combined-20261108/instance-prototypes-r1
cp "$G06_COMBINED_PREP/InstancePrototype-Unsealed.source.txt" .lake/ps-maintainer/gate06-combined-20261108/instance-prototypes-r1/InstanceUnsealed.lean
cp "$G06_COMBINED_PREP/InstancePrototype-Sealed.source.txt" .lake/ps-maintainer/gate06-combined-20261108/instance-prototypes-r1/InstanceSealed.lean
python3 -I "$G06_COMBINED_TOOLS/check_probe_v2.py" .lake/ps-maintainer/gate06-combined-20261108/instance-prototype-native-r1/Unsealed .lake/ps-maintainer/gate06-combined-20261108/instance-prototypes-r1/InstanceUnsealed CombinedInstanceUnsealed
python3 -I "$G06_COMBINED_TOOLS/check_probe_v2.py" .lake/ps-maintainer/gate06-combined-20261108/instance-prototype-native-r1/Sealed .lake/ps-maintainer/gate06-combined-20261108/instance-prototypes-r1/InstanceSealed CombinedInstanceSealed
```

Expected: unsealed rc0/fresh object/error0; sealed rc1 with exactly one error at its sole `:= rfl` proof and no catalog/setup error. Both body markers must occur. The entire default `Cfg` is compared with its constructor, so the prototype does not rely on sealing the separate `Cfg.state` projection. Only `Turing.instInhabitedCfg` is sealed in this isolated prototype. A parser/header/setup failure establishes no sensitivity. Do not suppress an unexpected result with `|| true`.

## Fresh collector and seals/controls

Prepare only, then compare the resulting `Collect.source.txt` byte-for-byte with `Collect.proposed.source.txt` (SHA `5654cc5a325f746a5d1fc7c7d3076cd0df4e46415be2866edf50e542ed110929`).

```sh
python3 -I "$G06_COMBINED_TOOLS/prepare_gate06_final_collector.py" eee107e92a7db11f1f8c98a5c2867304f57ddc54 a495f3953afff46ad5dec2d29ac8a7f55bd8ae37
python3 -I "$G06_COMBINED_TOOLS/check_probe_v2.py" "$G06_COMBINED_EVIDENCE" .lake/ps-maintainer/gate06-combined-20261108/rule10-r1/Collect collect1
```

Require rc0, zero ordinary/coded errors, source capture/hash/footer agreement, and the fresh nonempty object in the sole new tree. Verify the complete catalog/ROOT/AXIOMSID/MODULE sets. Types and all available seed values, including opaque/private/generated constants, are included. Exact current Name string and numeric components are retained. Opaque/nondefinition metadata stays in the census even where it is not a reducibility request.

```sh
python3 -I "$G06_COMBINED_TOOLS/prepare_gate06_final.py"
```

This prepares every one of the 59 whole-file seals and all **13 controls**: the existing 11 plus the instance negative pair. It imports the separately archived/hash-pinned legacy constant-AST encoder; all **8 preparation tool aliases** are captured, while the adapter separately binds the **3 builder aliases**. No native work happens in this preparation.

Read/review the resulting `final-adapter.json`, then supply its actual SHA-256:

```sh
python3 -I "$G06_COMBINED_TOOLS/run_gate06_final_native.py" run-all --adapter-sha256 ACTUAL_REVIEWED_FINAL_ADAPTER_SHA256
```

Require all59 valid harnesses and all13 sensitivity controls verified. Ordinary source failures remain failures. The runner retains them and still runs the controls; its nonzero overall return must not be rewritten as a pass. New runs never reuse historical coverage/retry ordinals.

The seal starts immediately after imports, before source options/open/namespace/anonymous commands, and is verified again at EOF. Complete original byte recovery, current line maps, actual Name components/home/status/instance/matcher metadata, requested/active/already counts and diagnostic locations are checked. The only special name omission is **exact `Complexity.PolyExpr.eval`**. `eval.match_1`, `eval._sunfold` and other helpers have no family omission. Reducible abbreviations such as `glNeed` are separately catalogued as notation; ordinary reducible non-abbrev observations require explicit disposition and never become silent source passes. Semireducible definition-instances are included.

## Fresh C3 metadata and complete axiom comparison

After source/probe/hash review, copy the bound `proposed-tools/C3.source.txt` to a fresh `rule10-r1/C3.lean` and run it through the same checker/tree:

```sh
cp "$G06_COMBINED_TOOLS/C3.source.txt" .lake/ps-maintainer/gate06-combined-20261108/rule10-r1/C3.lean
python3 -I "$G06_COMBINED_TOOLS/check_probe_v2.py" "$G06_COMBINED_EVIDENCE/c3-native-r1" .lake/ps-maintainer/gate06-combined-20261108/rule10-r1/C3 CombinedC3R1
```

Require successful native result/source/object/footer checks before consuming its log. It traverses every owned root's type/value, referenced TCS types and same-owner definition values; its non-TCS pruning is permitted only after checking the complete imported dependency graph. Each root gets its own visited set, preserving owner/ref pairs. The two existing native metadata controls remain. The added family guard is covered by 17 **static synthetic** cases; no native branch-sensitivity measurement is claimed in these preparation records.

Precisely covered families: `eq_def`, `eq_unfold`, `eq_<digits>` (theorem references to an actual foreign definition), `congr_eq_<digits>` (theorem plus actual matcher parent), and `.splitter` (actual matcher parent plus a reference of kind **defnInfo with abbrev hints**). Splitter REF rows retain family/kind/abbrev and need explicit disposition under the existing notation policy; they are not automatically violations or exclusions. Ordinary similarly named public declarations are not reclassified as generated matcher references.

Run the own read-only reconciliation helper only after provenance validation:

```sh
python3 -I "$G06_COMBINED_PREP/validate_combined_census.py" --evidence "$G06_COMBINED_EVIDENCE" --c3-log "$G06_COMBINED_EVIDENCE/c3-native-r1/CombinedC3R1.log" --reference /Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1/axioms-full.json --reference /Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/fills/shared-lemmas/s2/final/maintainer-rule10/axioms-full.json
```

Keep stdout as a new immutable review artifact. Current census/C3 root identities must agree exactly by owner and actual Name components, with matching direct type/value seed counts. Compare **every stored identity and its complete axiom set**, including standard-only changes, not only sorry-dependent names. Legacy references use their recorded unique actual-name strings; no fresh baseline-component census is claimed. Counts are computed, never forced to old2881/1292 or their sum. Every added/removed root, axiom-set change, unexpected axiom and C3 pair stays visible. No blanket46-count, zero-overall-C3 or all-standard-only assumption.

The helper is intentionally data-only: raw native provenance/source hashes must be validated separately; it does not independently re-prove every global C3 command interval or private-parent/suffix relation. Those properties are supplied by the fixed reviewed native C3 source. No standalone reconciliation output is merge clearance.

## Final reconciliation

Refresh the explicit-unfold scans/native kind catalog for all59 owners and inspect TCSlib **and Core/Mathlib** names in complete continuation lists; seals do not detect explicit foreign definition entries in tactic lists or uses of compiler-generated `f.eq_1`/`f.eq_def`. Refresh statement/definition-body/API/style checks on the current source. Preserve notation observations, generated-equation observations and old failures; no old0/0/0 is inherited.

For every failed declaration, preserve every diagnostic and compare complete header/body code, namespace/import/binding context and operative dependencies against the actual PR base `067c5d…`. Cross-link the old `3f6…` and S2 acceptance witnesses where exact. Reader-only/docstring edits are not proof edits; conversely equal raw bodies alone do not establish equal dependency context. Historical cleanup keys must normalize only recorded `_root_.` source qualifiers and match canonical identities exactly. Do not classify new/touched failures as inherited or convert an inherited observation into a passing seal. Source-base probes under combined dependencies, if used, must be labelled exactly that rather than called a rebuilt base tree.

**Not yet clear to merge — current native replay, all59 seals, all13 controls, C3/axiom/explicit-scan reconciliation and failure dispositions are pending. No new external audit/fill or proof fill is prepared here.**
