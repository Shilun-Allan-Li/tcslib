"""Own static detector classification cases; not Lean/native metadata evidence."""
from pathlib import Path
import hashlib,json,re
HERE=Path(__file__).resolve().parent

def classify(suffix,parents,refkind='theorem',refabbrev=False):
 ordinary=suffix in ('eq_def','eq_unfold') or re.fullmatch(r'eq_[0-9]+',suffix) is not None
 matcher=suffix=='splitter' or re.fullmatch(r'congr_eq_[0-9]+',suffix) is not None
 if not(ordinary or matcher):return 'none'
 for parent in parents:
  if parent['kind']!='def':continue
  if matcher and not parent['matcher']:return 'none'
  if parent['home'] is None:return 'error_parent_home'
  if not parent['home'].startswith('TCSlib.') or parent['home']=='TCSlib.Own':return 'none'
  if suffix=='splitter':
   if refkind!='def':return 'error_splitter_kind'
   if not refabbrev:return 'error_splitter_not_abbrev'
  elif refkind!='theorem':return 'error_equation_kind'
  return 'hit'
 return 'none'

def main():
 foreign={'kind':'def','matcher':False,'home':'TCSlib.Foreign'}
 match={**foreign,'matcher':True};local={**match,'home':'TCSlib.Own'}
 cases=[
  ('ordinary_eq_def','eq_def',[foreign],'theorem',False,'hit'),
  ('ordinary_eq_index','eq_17',[foreign],'theorem',False,'hit'),
  ('foreign_matcher_congruence','congr_eq_1',[match],'theorem',False,'hit'),
  ('ordinary_public_congr_name','congr_eq_1',[foreign],'theorem',False,'none'),
  ('foreign_matcher_splitter','splitter',[match],'def',True,'hit'),
  ('ordinary_public_splitter_name','splitter',[foreign],'def',True,'none'),
  ('splitter_wrong_theorem_kind','splitter',[match],'theorem',False,'error_splitter_kind'),
  ('splitter_wrong_nonabbrev_definition','splitter',[match],'def',False,'error_splitter_not_abbrev'),
  ('congruence_wrong_definition_kind','congr_eq_2',[match],'def',True,'error_equation_kind'),
  ('malformed_congruence_suffix','congr_eq_x',[match],'theorem',False,'none'),
  ('empty_congruence_suffix','congr_eq_',[match],'theorem',False,'none'),
  ('local_matcher_splitter','splitter',[local],'def',True,'none'),
  ('private_local_parent_wins','splitter',[local,match],'def',True,'none'),
  ('private_nonmatcher_parent_wins','splitter',[foreign,match],'def',True,'none'),
  ('private_wrapper_public_matcher_fallback','splitter',[{'kind':'missing','matcher':False,'home':None},match],'def',True,'hit'),
  ('ordinary_published_reader','size_node',[foreign],'theorem',False,'none'),
  ('nonTCS_matcher','splitter',[{**match,'home':'Mathlib.Foreign'}],'def',True,'none')]
 rows=[]
 for label,suffix,parents,kind,abbrev,expected in cases:
  actual=classify(suffix,parents,kind,abbrev);assert actual==expected,(label,actual,expected)
  rows.append({'case':label,'suffix':suffix,'actual_parent_candidates_in_order':parents,'reference_kind':kind,'reference_abbrev':abbrev,'expected':expected,'actual':actual})
 lean=Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean')
 refs={n:{'sha256':hashlib.sha256((lean/n).read_bytes()).hexdigest()} for n in ['Lean/Meta/Eqns.lean','Lean/Meta/Match/Basic.lean','Lean/Meta/Match/MatchEqs.lean','Lean/Declaration.lean','Lean/ReducibilityAttrs.lean','Lean/Data/Json/FromToJson/Basic.lean']}
 result={'status':'STATIC_SYNTHETIC_CLASSIFICATION_ONLY','cases':rows,'all_17_match_expected':True,'source_primary_sha256':refs,'limits':['Synthetic cases are not native Lean or real imported metadata controls.','Actual matcher-parent, ref-kind and abbrev guards execute only in the root-run fresh C3 probe.','Splitter observations retain explicit family/kind/abbrev and require notation-policy disposition, never automatic violation/exclusion.']}
 p=HERE/'static-family-controls.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('17 static family classification cases matched expected; no native run')

if __name__=='__main__':main()
