#!/usr/bin/env python3
"""Read-only reconciliation of completed combined collector/C3/seal/control data.

No process, Git, Lean, cache or evidence mutation. Output is stdout only.
Counts are computed from complete fresh actual-Name root sets, never fixed2881/1292.
Run only after root validates native source/object/prerequisite and probe provenance.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re, sys

HERE=Path(__file__).resolve().parent
HEAD='a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
BASE='eee107e92a7db11f1f8c98a5c2867304f57ddc54'
STANDARD={'propext','Classical.choice','Quot.sound'}

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def load_json(p):
 def unique(items):
  d={}
  for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
  return d
 return json.loads(p.read_bytes(),object_pairs_hook=unique)
def root_axioms(roots):
 return {(m,n):sorted(a['display'] for a in r['axioms']) for m,group in roots.items() for n,r in group.items()}
def legacy_reference(path):
 x=load_json(path);rows=x.get('rows',x.get('records'));need(isinstance(rows,list),'reference has no row array')
 out={}
 for r in rows:
  key=(r['module'],r['actual_name']);need(key not in out,'duplicate reference actual Name')
  out[key]=sorted(r['axioms'])
 return out

def c3_data(log,modules,catalog,roots):
 expected={(m,n) for m,rs in roots.items() for n in rs};seen=set();pairs=[];control=set();begins=[];ends=[];current=None;pending=0;module_roots={};module_pairs={};pruning=0
 def ident(n):
  need(n in catalog,'C3 reference/owner absent from fresh actual-Name catalog: '+n)
  return catalog[n]['name']
 for ln,line in enumerate(log.splitlines(),1):
  if 'G06-C3-' not in line:continue
  line=line[line.index('G06-C3-'):]
  if line.startswith('G06-C3-PRUNING '):
   need('checked=true' in line and pruning==0,'invalid pruning guard');pruning+=1
  elif line.startswith('G06-C3-CONTROL generated '):
   need('generated' not in control and 'expected=1 actual=1' in line and
        'reference=BoolCircuit.TreeCircuit.size.eq_def parent=BoolCircuit.TreeCircuit.size ' in line,'invalid generated-equation control');control.add('generated')
  elif line.startswith('G06-C3-CONTROL published_reader '):
   need('published_reader' not in control and 'expected=0 actual=0' in line and
        'reference=BoolCircuit.TreeCircuit.size_node' in line,'invalid published-reader control');control.add('published_reader')
  elif line.startswith('G06-C3-BEGIN '):
   need(not begins and line==f'G06-C3-BEGIN base={BASE} head={HEAD} modules={len(modules)}','wrong C3 begin pins/scope');begins.append(ln)
  elif line.startswith('G06-C3-MODULE-BEGIN '):
   mt=re.fullmatch(r'G06-C3-MODULE-BEGIN (\S+) \| roots=(\d+)',line);need(mt and current is None and pending==0,'bad module begin')
   current=mt[1];need(current in roots and current not in module_roots and int(mt[2])==len(roots[current]),'wrong/incomplete module root count');module_roots[current]=0;module_pairs[current]=0
  elif line.startswith('G06-C3-ROOT '):
   fields=line[len('G06-C3-ROOT '):].split(' | ');need(len(fields)==8 and pending==0 and current is not None,'malformed root')
   m,n=fields[:2];key=(m,n);need(m==current and key in expected and key not in seen,'unknown/duplicate C3 root')
   counts={}
   for field in fields[2:]:
    k,v=field.split('=');need(v.isdigit() and k not in counts,'bad root metric');counts[k]=int(v)
   need(set(counts)=={'type_refs','value_refs','visited','pruned','unknown_home_types','hits'},'root metric set differs')
   need(counts['type_refs']==len(roots[m][n]['type_refs']) and counts['value_refs']==len(roots[m][n]['value_refs']),'C3/collector type/value seed coverage differs')
   ident(n);seen.add(key);module_roots[m]+=1;pending=counts['hits'];owner=n
  elif line.startswith('G06-C3-REF '):
   f=line[len('G06-C3-REF '):].split(' | ');need(len(f)==9 and current is not None and pending>0,'unexpected C3 pair')
   m,n,ref,parent,parent_home,ref_home=f[:6];need(m==current and n==owner and (m,n) in seen,'pair owner/root differs')
   need(catalog[parent]['home']['display']==parent_home and catalog[ref]['home']['display']==ref_home and parent_home!=m,'foreign parent/home metadata differs')
   need(catalog[parent]['kind']=='def','C3 parent is not a definition')
   suffix=catalog[ref]['name']['components'][-1]
   need(suffix[0]=='str','non-string equation-reference suffix');suffix=suffix[1]
   family=('matcher_splitter' if suffix=='splitter' else 'matcher_congruence' if re.fullmatch(r'congr_eq_[0-9]+',suffix) else 'eq_def' if suffix=='eq_def' else 'eq_unfold' if suffix=='eq_unfold' else 'eq_index' if re.fullmatch(r'eq_[0-9]+',suffix) else None)
   need(family is not None and f[6]=='family='+family and f[7]=='kind='+catalog[ref]['kind'] and f[8]=='abbrev='+str(catalog[ref]['abbrev']).lower(),'C3 family/kind/abbrev metadata differs')
   if family=='matcher_splitter':
    need(catalog[parent]['matcher'] and catalog[ref]['kind']=='def' and catalog[ref]['abbrev'],'splitter needs actual matcher parent and abbreviation definition')
   else:
    need(catalog[ref]['kind']=='theorem','ordinary/congruence equation reference is not a theorem')
    if family=='matcher_congruence':need(catalog[parent]['matcher'],'congruence family parent is not a matcher')
   pairs.append({'module':m,'owner':ident(n),'reference':ident(ref),'parent':ident(parent),'parent_home':parent_home,'reference_home':ref_home,'family':family,'reference_kind':catalog[ref]['kind'],'reference_abbrev':catalog[ref]['abbrev'],'policy_disposition':'RETAINED_OBSERVATION_NOT_AUTOMATIC_VIOLATION_OR_EXCLUSION','log_line':ln});pending-=1;module_pairs[m]+=1
  elif line.startswith('G06-C3-MODULE-END '):
   mt=re.fullmatch(r'G06-C3-MODULE-END (\S+) \| roots=(\d+) \| pairs=(\d+)',line)
   need(mt and current==mt[1] and pending==0 and int(mt[2])==module_roots[current]==len(roots[current]) and int(mt[3])==module_pairs[current],'incomplete module ending');current=None
  elif line.startswith('G06-C3-END '):
   mt=re.fullmatch(r'G06-C3-END base=(\S+) head=(\S+) modules=(\d+) roots=(\d+) pairs=(\d+) type_extractions=(\d+) value_extractions=(\d+)',line)
   need(mt and mt[1]==BASE and mt[2]==HEAD and int(mt[3])==len(modules) and int(mt[4])==len(expected) and int(mt[5])==len(pairs),'invalid final C3 counts');ends.append(ln)
  else:raise RuntimeError('unknown C3 census/control record: '+line[:120])
 need(pruning==1 and control=={'generated','published_reader'} and len(begins)==len(ends)==1 and begins[0]<ends[0] and current is None and pending==0,'missing/out-of-order C3 completion/control')
 need(seen==expected and set(module_roots)==set(modules),'C3 root identities do not exactly equal fresh all-stored collector roots')
 pairkeys=[(p['module'],json.dumps(p['owner']['components']),json.dumps(p['reference']['components'])) for p in pairs]
 need(len(pairkeys)==len(set(pairkeys)),'duplicate owner/reference pair')
 return {'actual_roots':len(seen),'pairs':pairs,'controls':sorted(control),'exact_collector_root_components_match':True}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--evidence',type=Path,required=True);ap.add_argument('--c3-log',type=Path,required=True);ap.add_argument('--reference',action='append',type=Path,default=[]);args=ap.parse_args()
 # Only this own, reviewed definitions-only module is loaded; never a worker/helper payload.
 adapter=HERE/'proposed-tools/request_payload_adapter.py';manifest=load_json(HERE/'proposal-manifest.json')
 need(sha(adapter.read_bytes())==manifest['tools']['request_payload_adapter.py']['sha256'],'proposal adapter bytes changed')
 sys.dont_write_bytecode=True;spec=importlib.util.spec_from_file_location('own_combined_census',adapter);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
 modules=load_json(args.evidence/'modules.json');pins=load_json(args.evidence/'pins.json')
 need(pins['head']==HEAD and pins['base']==BASE and pins['actual_campaign_base']=='067c5d8d6dd436e62681d7dc607984c705dc80a2','wrong combined pins')
 need(set(modules)==set(load_json(HERE/'scope-proposal.json')['modules']),'not the exact59-owner scope')
 log=(args.evidence/'collect1.log').read_text();catalog,roots=a.catalog_and_roots(log,modules);fresh=root_axioms(roots)
 reference={};refhash={}
 for p in args.reference:
  rows=legacy_reference(p);need(not(set(reference)&set(rows)),'reference roots overlap');reference.update(rows);refhash[str(p)]=sha(p.read_bytes())
 added=sorted(set(fresh)-set(reference));removed=sorted(set(reference)-set(fresh));changed=[{'module':k[0],'actual_name':k[1],'before':reference[k],'after':fresh[k]} for k in sorted(set(fresh)&set(reference)) if fresh[k]!=reference[k]]
 unexpected=[{'module':m,'actual_name':n,'axioms':axs} for (m,n),axs in fresh.items() if set(axs)-STANDARD-{'sorryAx'}]
 admitted=[{'module':m,'actual_name':n,'axioms':axs} for (m,n),axs in fresh.items() if 'sorryAx' in axs]
 c3=c3_data(args.c3_log.read_text(),modules,catalog,roots)
 seals=load_json(args.evidence/'native-seal-runs/summary.json');controls=load_json(args.evidence/'native-control-runs/summary.json')
 need(seals['head']==controls['head']==HEAD and seals['base']==controls['base']==BASE and seals['complete'] and controls['complete'],'incomplete/wrong native epoch')
 need(seals['expected_probes']==seals['completed_probes']==len(modules) and {r['module'] for r in seals['results']}==set(modules),'incomplete owner seals')
 need(controls['expected_probes']==controls['completed_probes']==13 and controls['all_controls_verified'],'incomplete/unverified original11 plus instance pair')
 output={'status':'RECONCILED_DATA_REVIEW_REQUIRED_NOT_MERGE_CLEARANCE','head':HEAD,'verification_base':BASE,'math_owners':len(modules),'actual_roots':len(fresh),'admitted_dependent_roots':admitted,'unexpected_axioms':unexpected,'reference_files':refhash,'all_stored_reference_added':added,'all_stored_reference_removed':removed,'all_stored_axiom_set_changes':changed,'c3':c3,'source_failure_modules':sum(bool(r.get('source_failure')) for r in seals['results']),'source_error_diagnostics':seals['source_error_diagnostics'],'all_harnesses_valid':seals['all_harnesses_valid'],'controls':13,'limits':['Native receipt/source/object/direct-prerequisite provenance must be independently validated first.','Full term/closure rows and components are checked by prepared builder/runner; no fresh native execution here.','Every axiom/identity delta and C3 pair is retained; no historical/body-identity waiver or pass label.','Every source failure still needs exact full header/body + namespace/import/binding/operative-context comparison against actual PRbase and prior audit.']}
 print(json.dumps(output,indent=2))

if __name__=='__main__':main()
