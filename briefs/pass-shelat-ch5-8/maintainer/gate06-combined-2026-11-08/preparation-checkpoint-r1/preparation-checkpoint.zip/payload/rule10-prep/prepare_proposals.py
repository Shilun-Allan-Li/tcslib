#!/usr/bin/env python3
"""Own static proposal assembler; reads reviewed tools AS TEXT, never imports/executes them.

Writes only ignored proposed tools/metadata. Does not start Lean/Lake/cache or
write Git/index/refs, library, Main or exchange. Root reviews all new bytes.
"""
from pathlib import Path
import ast, hashlib, json, re, subprocess, difflib

ROOT=Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
HERE=Path(__file__).resolve().parent
OLD=ROOT/'.lake/ps-maintainer/gate06/repairs'
E=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4/briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1')
T=HERE/'proposed-tools'
EVIDENCE=ROOT/'.lake/ps-maintainer/gate06-combined-20261108/rule10-evidence-r1'
SCRATCH=Path('.lake/ps-maintainer/gate06-combined-20261108/rule10-r1')
HEAD='a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
BASE='eee107e92a7db11f1f8c98a5c2867304f57ddc54'
CAMPAIGN='067c5d8d6dd436e62681d7dc607984c705dc80a2'
G06HEAD='3f6db40e1688c4a0bb922c9575dd3bd2157a650b'
TREE=ROOT/'.lake/ps-maintainer/gate06-combined-20261108/oleans-r1'
PINS={'build_seals.py':'fae07000e8c3fda22225632ded45208e2651bab827d827639f48d46e2005347a',
 'build_controls.py':'484009543d095685b50fea244427adf4907de11bd5ef6a9e17e76fe08c60cf89',
 'request_payload_adapter.py':'ae79f1ec66e93c8bc7749a53e12e3d383feda020ad2978520a0cfa24b12eb5de',
 'prepare_audit.py':'055e652d9769044d757960586a94f4feffe78a942ca2d9555f02db9dccfa258f',
 'touched.py':'95d47b5541adcf4670120ab761890a2be899c3f1e77e367a459cac7ad96ffe97',
 'collect_body.lean.source.txt':'751aa8f8385a05690a0a0097acaff6d93e7349067b5e16a5a59662db0cafb57b',
 'check_probe_v2.py':'5048912fda9ecd1eb6dd9a238d94bfd73d55a70e9e7d2c4a2df75bfda7e9d146'}

def need(ok,m):
 if not ok: raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)
def enc(o):return (json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode()
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def replace(s,old,new,count=1):
 need(s.count(old)==count,'changed proposal anchor: '+old[:100]);return s.replace(old,new)
def assign(s,name,expr):
 ns=[n for n in ast.parse(s).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)]
 need(len(ns)==1,'nonunique assignment '+name);n=ns[0];lines=s.splitlines(keepends=True)
 return ''.join(lines[:n.lineno-1])+name+' = '+expr+'\n'+''.join(lines[n.end_lineno:])

def main():
 need(not T.exists(),'never overwrite a prior proposal')
 need(git('rev-parse','HEAD').decode().strip()==HEAD,'combined head changed')
 oldmods=json.loads((E/'modules.json').read_bytes());need(len(oldmods)==54,'old scope not54')
 need(sha((E/'modules.json').read_bytes())=='aaeebbe3c97e2447e5497ce46b0a721816232b861492fd895add6cbda0ebc0f9','old module scope changed')
 s2={'TCSlib.Cryptography.Candidates.'+n for n in ('Concrete','DiscreteLog','ElGamal','RSA','Rabin')}
 modules={m:m.replace('.','/')+'.lean' for m in sorted(set(oldmods)|s2)};need(len(modules)==59,'scope not59')
 oldraw={n:(E/'tool-inputs'/n).read_bytes() for n in PINS}
 need(all(sha(oldraw[n])==h for n,h in PINS.items()),'old reviewed tool changed')
 source={p:git('show',HEAD+':'+p) for p in modules.values()}
 for m in s2:need(source[modules[m]]==git('show',CAMPAIGN+':'+modules[m]),'S2 differs from accepted campaign')
 # Derive every local import closure independently from exact Git blobs.
 allpaths=[p for p in git('ls-tree','-r','--name-only',HEAD,'TCSlib','TCSlib.lean').decode().splitlines() if p.endswith('.lean')]
 raws={}
 requests=''.join(HEAD+':'+p+'\n' for p in allpaths).encode();batch=subprocess.check_output(['git','--no-optional-locks','cat-file','--batch'],cwd=ROOT,input=requests);at=0
 for p in allpaths:
  end=batch.index(b'\n',at); fields=batch[at:end].split();need(fields[1]==b'blob','missing Git blob');at=end+1;n=int(fields[2]);raws[p]=batch[at:at+n];at+=n+1
 # Use ONLY the independently authored previous masker function as source, not that program.
 own=ast.parse((ROOT/'.lake/ps-maintainer/gate06c-20261108/dependency-screen/screen_dependencies.py').read_text());ns={}
 exec(compile(ast.Module(body=[n for n in own.body if isinstance(n,ast.FunctionDef) and n.name=='mask'],type_ignores=[]),'<own lexical masker>','exec'),ns)
 graph={}
 for p,b in raws.items():
  code=ns['mask'](b.decode());graph[p[:-5].replace('/','.')]=[n for line in code.splitlines() if (mt:=re.fullmatch(r'\s*import\s+(.+?)\s*',line)) for n in mt[1].split() if n=='TCSlib' or n.startswith('TCSlib.')]
 closures={}
 for m in modules:
  found=set();stack=graph[m][:]
  while stack:
   d=stack.pop()
   if d in found:continue
   need(d in graph,'unresolved local import '+d);found.add(d);stack.extend(graph[d])
  need(m not in found,'cyclic import');closures[m]=sorted(found)
 changed=git('diff','--name-only',BASE,HEAD,'--','*.lean').decode().splitlines()
 math={p[:-5].replace('/','.') for p in changed if p in raws and re.search(r'^(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|nonrec)\s+)*(?:theorem|lemma|def|instance|structure|inductive|abbrev|class|opaque|axiom)\b',ns['mask'](raws[p].decode()),re.M)}
 need(math==set(modules),'dynamic actual changed math scope differs from explicit54 union5')
 metadata={'status':'PROPOSED_STATIC_NOT_NATIVE','head':HEAD,'verification_ancestor':BASE,'actual_PR_base':CAMPAIGN,'prior_audited_head':G06HEAD,
  'math_modules':len(modules),'modules':modules,'closures':closures,'changed_Lean_paths':changed,
  'S2_sources_equal_actual_campaign_base':True,'source_sha256':{p:sha(b) for p,b in source.items()},
  'direct_local_imports':{m:graph[m] for m in modules},'native_has_not_run':True,'old_tool_sha256':PINS}
 save(HERE/'scope-proposal.json',enc(metadata));save(HERE/'complete-source-identities.json',enc({p:{'sha256':sha(b),'bytes':len(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()} for p,b in sorted(raws.items())}))
 tools={n:oldraw[n].decode() for n in PINS if n!='request_payload_adapter.py'}
 body=tools.pop('collect_body.lean.source.txt')
 body=body.replace('env.constants.map₁.toList','env.constants.toList').replace('for (n, _) in','for (n, ci) in')
 body=replace(body,'    if isInstanceCore env c then continue\n','')
 body=replace(body,'ci.value?.map','(ci.value? (allowOpaque := true)).map')
 body=replace(body,'cc.value?.map','(cc.value? (allowOpaque := true)).map')
 ax='          logInfo m!"AXIOMS {modN} | {s} | {axs.toList}"'
 body=replace(body,ax,ax+'\n          logInfo m!"G06-ROOT {(G06CombinedMetadata.rootRecord modN n ci axs).compress}"')
 body=(HERE/'name-metadata.source.txt').read_text()+'\n'+body+'\n'+(HERE/'catalog-command.source.txt').read_text()
 tools['collect_body.lean.source.txt']=body
 pa=tools['prepare_audit.py'].replace('env.constants.map₁.toList','env.constants.toList')
 pa=replace(pa,'    if isInstanceCore env n then continue\n','')
 pa=replace(pa,'if n == `Complexity.PolyExpr.eval || n == `TCSlib.Cryptography.glNeed then continue','if n == `Complexity.PolyExpr.eval then continue')
 tools['prepare_audit.py']=pa
 bs=tools['build_seals.py'].replace('EXPECTED_MODULES = 51','EXPECTED_MODULES = 59').replace('51 Gate06','59 Gate06').replace('exactly 51','exactly 59');bs=replace(bs,'    "TCSlib.Cryptography.glNeed",\n','');bs=bs.replace('env.constants.map₁.toList','env.constants.toList');tools['build_seals.py']=bs
 cb=tools['build_controls.py'].replace('all 51 audited math','all 59 audited math');cb=replace(cb,'              \'    if isInstanceCore env n then throwError "G06-CONTROL-HARNESS {label}: unexpected instance {spelling}"\',\n','')
 cb=cb.replace('env.constants.map₁.toList','env.constants.toList')
 cb=replace(cb,'builder_path = root / ".lake/ps-maintainer/gate06/build_seals.py"','builder_path = Path(__file__).with_name("build_seals.py")')
 for a,b in [('"probes": 11','"probes": 13'),('"unsealed_passes": 5','"unsealed_passes": 6'),('"sealed_negative_failures": 5','"sealed_negative_failures": 6'),('"proof_error_diagnostics": 5','"proof_error_diagnostics": 6'),('len(output_manifest["probes"]) == 11','len(output_manifest["probes"]) == 13')]:cb=replace(cb,a,b,count=2 if a=='"probes": 11' else 1)
 tools['build_controls.py']=cb
 checker=tools['check_probe_v2.py']
 start=checker.index("run = r / 'briefs/");end=checker.index('clock = lambda:',start)
 checker=checker[:start]+"setup = Path(__file__).with_name('setup-summary.json')\nenv['TCSLIB_OLEANS'] = json.loads(setup.read_text())['olean_tree']\nassert json.loads(setup.read_text())['head'] == "+repr(HEAD)+"\n"+checker[end:]
 tools['check_probe_v2.py']=checker
 tools['legacy_request_payload_adapter.py']=oldraw['request_payload_adapter.py'].decode()
 tools['request_payload_adapter.py']=(HERE/'combined_payload_adapter.py').read_text()
 tools['s2_native_seal_driver.py']=(OLD/'s2_native_seal_driver.py').read_text()
 setup={'status':'CONFIGURATION_ONLY_NOT_NATIVE','head':HEAD,'olean_tree':str(TREE),'limit':'Root must reconcile every effective required native source/object/prerequisite at this combined head before collection. Tree existence is not clearance.'}

 # Retarget the already-reviewed preparer/adapter/runner, never execute them here.
 toolhash={n:sha(s.encode()) for n,s in tools.items()}
 prep=(OLD/'prepare_gate06_final_collector.py').read_text().replace('eleven','thirteen')
 paths={n:T/n for n in ('build_seals.py','build_controls.py','request_payload_adapter.py','prepare_audit.py','touched.py','check_probe_v2.py','legacy_request_payload_adapter.py')};paths['collect_body.lean']=T/'collect_body.lean.source.txt'
 hashes={n:toolhash['collect_body.lean.source.txt' if n=='collect_body.lean' else n] for n in paths}
 for name,expr in {'EVIDENCE':'Path('+repr(str(EVIDENCE))+')','SCRATCH_REL':'Path('+repr(SCRATCH.as_posix())+')','TOOL_PATHS':'{'+','.join(repr(n)+': Path('+repr(str(p))+')' for n,p in paths.items())+'}','TOOL_HASHES':repr(hashes)}.items():prep=assign(prep,name,expr)
 needle='    modules, closures, fingerprints, excluded = derive_scope(bs, library, args.base, args.head)'
 prep=replace(prep,needle,needle+'\n    need(set(modules) == '+'set('+repr(sorted(modules))+')'+', "not the complete54 plus5 combined owner scope")\n    need(args.base == '+repr(BASE)+' and args.head == '+repr(HEAD)+', "wrong combined pins")\n    pins.update(actual_campaign_base='+repr(CAMPAIGN)+', prior_audited_source='+repr(G06HEAD)+')')
 tools['prepare_gate06_final_collector.py']=prep;prepsha=sha(prep.encode())
 adapter=(OLD/'prepare_gate06_final.py').read_text().replace('eleven','thirteen').replace('\"controls\": 11','\"controls\": 13');adapter=assign(adapter,'PREPARER_SHA',repr(prepsha))
 adapter=replace(adapter,'    _, conservative, _ = bs.collector_rows(log, modules, closures)','    v3.configure_builders(bs, cb)\n    _, conservative, _ = bs.collector_rows(log, modules, closures)')
 adapter=replace(adapter,'    v3.configure_builders(bs, cb)\n    cb.load_builder','    cb.load_builder')
 adapter=replace(adapter,'== 11 and controls["seal_manifest_sha256"]','== 13 and controls["seal_manifest_sha256"]')
 tools['prepare_gate06_final.py']=adapter
 runner=(OLD/'run_gate06_final_native.py').read_text().replace('eleven','thirteen')
 oldfixed={str(T/'s2_native_seal_driver.py'):toolhash['s2_native_seal_driver.py'],str(T/'check_probe_v2.py'):toolhash['check_probe_v2.py'],str(T/'setup-summary.json'):sha(enc(setup)),str(ROOT/'scripts/lean_check_tree.sh'):sha((ROOT/'scripts/lean_check_tree.sh').read_bytes()),str(ROOT/'lean-toolchain'):sha((ROOT/'lean-toolchain').read_bytes()),str(ROOT/'lake-manifest.json'):sha((ROOT/'lake-manifest.json').read_bytes()),str(T/'prepare_gate06_final_collector.py'):prepsha,str(T/'prepare_gate06_final.py'):sha(adapter.encode())}
 buildhash={n:toolhash[n] for n in ('build_seals.py','build_controls.py','request_payload_adapter.py')}
 for name,expr in {'TOOLS':'Path('+repr(str(T))+')','OLEANS':'Path('+repr(str(TREE))+')','EVIDENCE':'Path('+repr(str(EVIDENCE))+')','SCRATCH_REL':'Path('+repr(SCRATCH.as_posix())+')','HELPERS':'Path('+repr(str(T/'s2_native_seal_driver.py'))+')','CHECKER':'Path('+repr(str(T/'check_probe_v2.py'))+')','SETUP':'Path('+repr(str(T/'setup-summary.json'))+')','PREPARER':'Path('+repr(str(T/'prepare_gate06_final_collector.py'))+')','ADAPTER':'Path('+repr(str(T/'prepare_gate06_final.py'))+')','FIXED_SHA':repr(oldfixed),'BUILD_SHA':repr(buildhash),'PREPARATION_SHA':repr(hashes),'NEGATIVES':'frozenset('+repr(sorted({'InArg','AdvInput','Uexp','AnonymousOnly','Matcher','Instance'}))+')'}.items():runner=assign(runner,name,expr)
 runner=runner.replace("== 11 == m['expected_totals']['probes']","== 13 == m['expected_totals']['probes']").replace("== 11,\n            'all eleven", "== 13,\n            'all thirteen").replace("'expected_controls': 11", "'expected_controls': 13")
 a=runner.index('    local = ROOT / \".lake/build/lib/lean\"') if '    local = ROOT / \".lake/build/lib/lean\"' in runner else runner.index("    local = ROOT / '.lake/build/lib/lean'")
 z=runner.index('    names = set(ctx.modules)',a)
 runner=runner[:a]+'    # All effective TCSlib imports must come from the one new combined tree.\n'+runner[z:]
 runner=replace(runner,"len({p['label'] for p in probes}) == 11,", "len({p['label'] for p in probes}) == 13,")
 runner=replace(runner,'    payload.configure_builders(ctx.bs, ctx.cb)','    payload.configure_builders(ctx.bs, ctx.cb)\n    ctx.payload = payload')
 runner=replace(runner,'    install, eof = v.check_installation(text, p[\'label\'], p)','    install, eof = v.check_installation(text, p[\'label\'], p)\n    ctx.payload.verify_component_log(text, p[\'label\'], p[\'requested_names\'], (\'install\', \'eof\'))')
 runner=replace(runner,'    expected_errors = int(p[\'case\'] in NEGATIVES and p[\'mode\'] == \'Sealed\')','    ctx.payload.verify_component_log(text, p[\'label\'], m[\'requested_names\'], (\'catalog-before\', \'install\', \'eof\') if p[\'full_closure_sealed\'] else (\'catalog-before\', \'catalog-after\'))\n    expected_errors = int(p[\'case\'] in NEGATIVES and p[\'mode\'] == \'Sealed\')')
 tools['run_gate06_final_native.py']=runner
 c3=(OLD/'final-c3-supplement-r2.source.txt').read_text();lines=c3.splitlines();first=next(i for i,l in enumerate(lines) if not l.startswith('import '));c3='\n'.join(['import Lean',*('import '+m for m in modules),*lines[first:]])+'\n'
 c3=c3.replace(G06HEAD,HEAD).replace('54 audited','59 audited').replace('targets.size == 54','targets.size == 59').replace('env.constants.map₁.toList','env.constants.toList')
 normal='''  unless suffix == "eq_def" || suffix == "eq_unfold" ||
      (suffix.startsWith "eq_" && (suffix.drop 3).length > 0 &&
        (suffix.drop 3).all Char.isDigit) do return none'''
 expanded='''  let ordinaryEquation := suffix == "eq_def" || suffix == "eq_unfold" ||
    (suffix.startsWith "eq_" && (suffix.drop 3).length > 0 &&
      (suffix.drop 3).all Char.isDigit)
  -- Lean4.25 Match.Basic/MatchEqs additionally reserve these two matcher families.
  let matcherEquation := suffix == "splitter" ||
    (suffix.startsWith "congr_eq_" && (suffix.drop 9).length > 0 &&
      (suffix.drop 9).all Char.isDigit)
  unless ordinaryEquation || matcherEquation do return none'''
 c3=replace(c3,normal,expanded)
 c3=replace(c3,'    if let some (.defnInfo _) := env.find? parent then',
   '    if let some (.defnInfo _) := env.find? parent then\n      if matcherEquation && !(Match.Extension.getMatcherInfo? env parent).isSome then return none')
 theorem_guard='''      let some (.thmInfo _) := env.find? ref
        | throwError "C3 equation-style reference is not a theorem: {ref} (parent {parent})"'''
 kind_guard='''      if suffix == "splitter" then
        let some (.defnInfo splitterInfo) := env.find? ref
          | throwError "C3 matcher splitter reference is not a definition: {ref}"
        match splitterInfo.hints with
        | .abbrev => pure ()
        | _ => throwError "C3 matcher splitter definition is not an abbreviation: {ref}"
      else
        let some (.thmInfo _) := env.find? ref
          | throwError "C3 equation-style reference is not a theorem: {ref} (parent {parent})"
        pure ()'''
 c3=replace(c3,theorem_guard,kind_guard)
 oldref='''        logInfo m!"G06-C3-REF {m} | {n} | {ref} | {parent} | {parentHome} | {refHome}"'''
 newref='''        let suffix := match ref with | .str _ s => s | _ => ""
        let family := if suffix == "splitter" then "matcher_splitter" else
          if suffix.startsWith "congr_eq_" then "matcher_congruence" else
          if suffix == "eq_def" then "eq_def" else
          if suffix == "eq_unfold" then "eq_unfold" else "eq_index"
        let (referenceKind, referenceAbbrev) := match env.find? ref with
          | some (.defnInfo d) => ("def", match d.hints with | .abbrev => true | _ => false)
          | some (.thmInfo _) => ("theorem", false)
          | _ => ("unexpected", false)
        logInfo m!"G06-C3-REF {m} | {n} | {ref} | {parent} | {parentHome} | {refHome} | family={family} | kind={referenceKind} | abbrev={referenceAbbrev}"'''
 c3=replace(c3,oldref,newref)
 tools['C3.source.txt']=c3
 for name,content in tools.items():
  if name.endswith('.py'):ast.parse(content,filename=name)
 save(T/'setup-summary.json',enc(setup))
 for name,content in tools.items():save(T/name,content.encode())
 diffs=[]
 for n in ('build_seals.py','build_controls.py','prepare_audit.py','check_probe_v2.py','collect_body.lean.source.txt'):
  diffs.extend(difflib.unified_diff(oldraw[n].decode().splitlines(keepends=True),tools[n].splitlines(keepends=True),fromfile='reviewed/'+n,tofile='proposed/'+n))
 save(HERE/'reviewed-tools-minimal-changes.patch',''.join(diffs).encode())
 manifest={'status':'PROPOSED_NOT_NATIVE_TESTED','head':HEAD,'verification_ancestor':BASE,'actual_campaign_base':CAMPAIGN,'expected_math_owners':59,'expected_controls':13,'notation_exclusions_exact':['Complexity.PolyExpr.eval'],'instance_filter_removed':True,'opaque_seed_values_included':True,'actual_Name_component_checks':True,'complete_owned_root_reconciliation_required':True,'source_sha256':sha(Path(__file__).read_bytes()),'tools':{n:{'sha256':sha((T/n).read_bytes()),'bytes':(T/n).stat().st_size} for n in sorted(tools)},'limits':['No proposed builder/collector/runner executed. Python syntax parsed only.','No Lean/native/cache/build/apps run.','Native readiness, collector/schema/instance-control prototype and C3 extraction still require root review/testing.','Old fixed1292/all-standard-only and OWNED5 validators are not called by generic runner.','All failures and unsupported reducible metadata remain retained observations, never waived.']}
 save(HERE/'proposal-manifest.json',enc(manifest));print(json.dumps({'status':manifest['status'],'owners':59,'controls':13,'tools':len(tools),'scope':str(HERE/'scope-proposal.json')}))

if __name__=='__main__':main()
