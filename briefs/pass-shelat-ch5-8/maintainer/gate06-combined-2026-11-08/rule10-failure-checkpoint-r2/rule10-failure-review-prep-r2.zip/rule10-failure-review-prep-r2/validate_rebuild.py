#!/usr/bin/env python3
"""Independent data-only joins; never imports or executes preflight programs.

Validates preserved historical bytes/counts, source snapshots and R2 mappings.
Header/body split hashes are byte witnesses, not Lean boundary certification.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,re,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'rule10-failure-review-prep-r1'
HEAD='a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
BASE='067c5d8d6dd436e62681d7dc607984c705dc80a2'

def need(ok,message):
 if not ok:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
def read(path):return json.loads(path.read_bytes())
def key(row):return row['file'],row['historical_source_key']
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def main():
 output=HERE/'rebuild-validation.json';need(not output.exists(),'never overwrite validation')
 pf=HERE/'preflight';op=OLD/'preflight';pm=read(pf/'preflight-manifest.json')
 need(pm['head']==HEAD and pm['actual_PRbase']==BASE,'wrong exact refs')
 for name,h in pm['files'].items():need(sha((pf/name).read_bytes())==h,'preflight JSON changed '+name)
 need(sha((HERE/'source_context.py').read_bytes())==pm['source_parser_sha256'],'parser binding differs')
 need(sha((HERE/'failure_preflight.py').read_bytes())==pm['helper_sha256'],'preparer binding differs')
 blobs=read(pf/'blob-index.json')
 for h,row in blobs.items():
  raw=(pf/row['path']).read_bytes();need((len(raw),sha(raw))==(row['bytes'],h),'blob bytes differ')
 snapshots=read(pf/'source-snapshots.json')
 need(snapshots==read(op/'source-snapshots.json'),'six source snapshot inventories changed')
 need(read(pf/'context-closures.json')==read(op/'context-closures.json'),'complete import-source closures changed')
 need(read(pf/'historical-ledger-index.json')==read(op/'historical-ledger-index.json'),'original inventory rows changed')
 unresolved_context=set()
 for context in read(pf/'operative-context-comparisons.json').values():
  for changed in context['changed_context_files']:
   for side in ('left','right'):
    for unit in changed[side+'_definition_interface_inventory']:
     if unit['header_body_boundary_status']=='UNRESOLVED':
      need(unit['header_code_sha256'] is None and unit['ordinary_body_code_sha256'] is None and unit['unverified_lexical_split'] is not None,'unresolved context split presented as verified')
      need(unit['mapping_warnings'] or unit['namespace_context_ambiguous'],'unresolved context reason lost')
      unresolved_context.add((side,changed['path'],canonical(unit['canonical_parts'])))
 old=read(op/'prior-witnesses.json');new=read(pf/'prior-witnesses.json')
 oldmap={key(r):r for r in old['historical_roots']};newmap={key(r):r for r in new['historical_roots']}
 previous_links={key(r):r for r in read(HERE/'preparation-history/before-vertical-bar-and-link-guards/preflight/prior-witnesses.json')['historical_roots']}
 need(len(oldmap)==len(newmap)==115 and set(oldmap)==set(newmap),'historical115 keys changed')
 wrong=[];resolved=[];unresolved=[];boundaries_changed=[];counts=Counter();link_counts=Counter();checked_blocks=0
 observation_fields=['epoch','role','ref','file','module','label','raw_log_sha256','native_result_sha256','probe_sha256','diagnostic','status','native_base_environment_rebuilt']
 for k,row in newmap.items():
  prior=oldmap[k]
  for f in ['file','module','historical_source_key','historical_epoch','historical_head_diagnostics','historical_base_source_diagnostics','current_outcome','failure_retained','waiver']:
   need(row[f]==prior[f],'historical root field changed '+f)
  need([[o[f] for f in observation_fields] for o in row['observations']]==[[o[f] for f in observation_fields] for o in prior['observations']],'historical raw diagnostics/capture identities changed')
  counts['head_diagnostics']+=row['historical_head_diagnostics'];counts['base_source_diagnostics']+=row['historical_base_source_diagnostics']
  oldunit=prior['current_source_comparison']['head']['unit'] if prior['current_source_comparison'] else None
  if oldunit and oldunit['canonical']!=k[1]:wrong.append({'file':k[0],'historical_source_key':k[1],'R1_incorrect_unit':oldunit['canonical']})
  comparison=row['current_source_comparison']
  if comparison is None:
   need(row['current_source_mapping_status']=='UNRESOLVED_LEXICAL_MAPPING','missing comparison silently resolved');unresolved.append({'file':k[0],'historical_source_key':k[1]});continue
  hu=comparison['head']['unit']
  need(hu['canonical']==k[1] and not hu['lexical_boundaries_need_review'],'R2 source key/envelope mismatch')
  exact=row['exact_historical_inventory_links'];spelling=row['historical_declared_spelling_candidates_not_canonical']
  need(all(r['normalized_source_key']==hu['canonical'] for r in exact),'short spelling mislabeled exact canonical')
  need(all(r['normalized_source_key']!=hu['canonical'] and r['basis']=='DECLARED_SOURCE_SPELLING_CANDIDATE_NOT_CANONICAL_IDENTITY_OR_CLOSURE' for r in spelling),'candidate falsely grants identity')
  link_id=lambda r:(r['inventory'],r['line'],r['file'],r['normalized_source_key'])
  need({link_id(r) for r in exact+spelling}=={link_id(r) for r in previous_links[k]['exact_historical_inventory_links']},'earlier spelling/inventory witness dropped')
  link_counts['exact_canonical']+=len(exact);link_counts['declared_spelling_candidates_not_canonical']+=len(spelling)
  need(row['historical_source_mapping_status']=='UNIQUE_LEXICAL_LINE_AND_SOURCE_KEY_AGREEMENT','historical ambiguity guessed')
  for observation in row['observations']:
   if observation['role']!='Head':continue
   candidates=observation['line_and_historical_source_key_matches']
   need(len(candidates)==1 and candidates[0]['unit']['canonical']==k[1],'historical line/key mismatch')
   u=candidates[0]['unit'];need(u['start_line']<=observation['diagnostic']['source_line']<=u['end_line'],'historical diagnostic outside mapped unit')
  for role in ('head','actual_base'):
   block=comparison[role]
   if block is None:continue
   unit=block['unit'];meta=snapshots[block['ref']]['sources'][block['path']]
   source=(pf/'blobs'/meta['sha256']).read_bytes().decode()
   raw=source[unit['char_start']:unit['char_end']]
   need(sha(raw.encode())==unit['raw_sha256']==block['raw_blob'],'source envelope raw recovery differs')
   need((pf/'blobs'/block['raw_blob']).read_bytes()==raw.encode(),'raw block blob differs')
   choices={len(raw),*(m.start() for m in re.finditer(r':=|\bwhere\b|\|',raw))}
   splits=[pos for pos in choices if sha(raw[:pos].encode())==unit['header_raw_sha256'] and sha(raw[pos:].encode())==unit['body_raw_sha256']]
   need(len(splits)==1,'header/body raw hashes do not partition envelope exactly')
   need(sha(canonical(unit['binding_trace']).encode())==unit['binding_trace_sha256'],'binding command trace differs')
   checked_blocks+=1
  if oldunit and oldunit['raw_sha256']!=hu['raw_sha256']:
   boundaries_changed.append({'file':k[0],'historical_source_key':k[1],'R1_range':[oldunit['start_line'],oldunit['end_line']],'R2_range':[hu['start_line'],hu['end_line']]})
  resolved.append({'file':k[0],'historical_source_key':k[1],'R2_range':[hu['start_line'],hu['end_line']],'source_only':True})
 need(counts=={'head_diagnostics':145,'base_source_diagnostics':7},'145+7 diagnostics changed')
 need({r['historical_source_key'] for r in wrong}=={'Complexity.BinArith.uHead_nil','Complexity.BinArith.uRest_nil','TCSlib.Cryptography.Candidates.primesPairEquiv_apply_val'},'unexpected R1 identity discrepancy set')
 ranges=read(pf/'legacy-recorded-raw-range-validation.json');original=read(OLD/'legacy-recorded-raw-range-validation.json')
 need(len(ranges['rows'])==ranges['recorded_ranges_verified']==230,'original range count changed')
 need([r['original_record'] for r in ranges['rows']]==original['rows'],'original range witness rows changed')
 for row in ranges['rows']:
  need(row['declaration_identity_validated_by_this_check'] is False,'raw range mislabeled identity')
  raw=(pf/'blobs'/row['exact_raw_blob']).read_bytes();o=row['original_record']
  text=(pf/'blobs'/snapshots[o['ref']]['sources'][o['file']]['sha256']).read_text()
  a,b=o['range'];need(raw==''.join(text.splitlines(keepends=True)[a-1:b]).encode() and sha(raw)==o['raw_sha256'],'exact original recorded range bytes differ')
 oldfiles=read(HERE.parent/'rule10-failure-checkpoint-r1/FILES.json')['files']
 for row in oldfiles:
  raw=(OLD/row['path']).read_bytes();need((len(raw),sha(raw))==(row['bytes'],row['sha256']),'frozen R1 source artifact changed')
 indices=read(pf/'all59-source-envelope-indices.json')
 need(len(indices)==59,'not all59 owner indices')
 index_issues={m:{role:idx['mapping_issues'] for role,idx in roles.items() if idx.get('mapping_issues')} for m,roles in indices.items()}
 missing_indices=[{'module':m,'role':role} for m,roles in indices.items() for role,idx in roles.items() if idx.get('missing_source')]
 report={'status':'NONNATIVE_REBUILD_BYTES_AND_SOURCE_KEY_JOINS_VERIFIED_NO_WAIVER','head':HEAD,'actual_PRbase':BASE,'historical_keys':115,'historical_head_diagnostics':145,'historical_base_source_diagnostics':7,
  'original_recorded_raw_ranges_verified_not_identity':230,'source_header_body_byte_partitions_verified':checked_blocks,
  'R1_incorrect_identity_mappings':wrong,'R2_resolved_historical_source_keys':len(resolved),'R2_unresolved_historical_source_keys':unresolved,
  'R1_to_R2_changed_source_envelopes':boundaries_changed,'inventory_link_counts':dict(link_counts),'earlier_inventory_link_union_preserved':True,'immutable_blobs_verified':len(blobs),'all59_index_mapping_issues':index_issues,'explicit_missing_source_indices':missing_indices,
  'all_R1_files_unchanged':len(oldfiles),'unresolved_context_inventory_units':sorted(unresolved_context),'source_parser_sha256':pm['source_parser_sha256'],'validator_sha256':sha(Path(__file__).read_bytes()),'native_run':False,'current59_outcomes':'NOT_READ_OR_PREDICTED','waiver':False,
  'limits':['Checks exact byte witnesses and metadata joins; no Lean parser/elaboration or actual Name proof.',
   'Unknown lexical context remains unresolved; complete sources/import contexts retain evidence even where no safe declaration mapping exists.',
   'Historical source key annotations are not native Name identities. No inheritance or acceptance decision.']}
 with output.open('xb') as f:f.write(encode(report))
 print(json.dumps({k:report[k] for k in ('historical_keys','historical_head_diagnostics','historical_base_source_diagnostics','original_recorded_raw_ranges_verified_not_identity','R2_resolved_historical_source_keys','R2_unresolved_historical_source_keys','immutable_blobs_verified','all_R1_files_unchanged')},indent=2))

if __name__=='__main__':main()
