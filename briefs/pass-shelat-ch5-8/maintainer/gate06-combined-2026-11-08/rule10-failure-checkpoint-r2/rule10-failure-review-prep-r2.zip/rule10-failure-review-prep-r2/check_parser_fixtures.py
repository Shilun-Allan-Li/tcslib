#!/usr/bin/env python3
"""Own lexical regressions, not Lean syntax/elaboration tests.

Imports only the reviewed sibling parser; exact Git sources are read as data.
Writes fresh JSON fixture/results files, never source or native objects.
"""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sp=importlib.util.spec_from_file_location('own_r2_source_context',HERE/'source_context.py')
sc=importlib.util.module_from_spec(sp);sp.loader.exec_module(sc)

def need(ok,message):
 if not ok:raise RuntimeError(message)
def encode(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
def named(index,parts):
 rows=[u for u in index['units'] if u['canonical_parts']==parts]
 need(len(rows)==1,'not one source declaration: '+repr(parts));return rows[0]

CASES=[
 ('inline_repeated_attributes_modifiers',[
  'namespace Fixture',
  '@[simp] theorem one : True := by trivial',
  '@[simp] @[tag (xs := [1, 2])] private theorem two : True := by trivial',
  'theorem after : True := by trivial','end Fixture'],
  [['Fixture','one'],['Fixture','two'],['Fixture','after']]),
 ('multiline_attributes_modifiers_quoted_name',[
  'namespace Fixture','@[','  simp,','  tag (xs := [1, 2]) (s := "] theorem ghost := by")',']',
  'protected','noncomputable theorem «quoted.name» : True := by trivial',
  'theorem after : True := by trivial','end Fixture'],
  [['Fixture','quoted.name'],['Fixture','after']]),
 ('strings_nested_comments_raw_strings',[
  'namespace Fixture','/- ignored /- @[simp] theorem ghost : True := by trivial -/ nested -/',
  '@[tag (s := r#"] theorem rawGhost := by"#)]',
  'theorem literal (s : String := "@[simp] theorem ghost := by") : True := by trivial',
  'theorem after : True := by trivial','end Fixture'],
  [['Fixture','literal'],['Fixture','after']]),
 ('forall_and_default_binders',[
  'namespace Fixture','@[simp] theorem defaults (n : Nat := 0)',
  '    (h : ∀ n : Nat, n = n := fun n => rfl)',
  '    (s : String := ":= where theorem ghost") :',
  '    ∀ n : Nat, n = n := by','  intro n','  rfl','end Fixture'],
  [['Fixture','defaults']]),
 ('absolute_value_not_equation_clause',[
  'namespace Fixture','theorem absType (f : Int → Int) :',
  '    |(fun x => f x) 0| = |f 0| := by','  rfl','end Fixture'],
  [['Fixture','absType']]),
 ('quoted_namespace_components_and_absolute_root',[
  'namespace «Outer.With.Dot»','@[simp] theorem «with space» : True := by trivial',
  'theorem _root_.Absolute.«x.y» : True := by trivial',
  'theorem «_root_».localName : True := by trivial','end «Outer.With.Dot»'],
  [['Outer.With.Dot','with space'],['Absolute','x.y'],['Outer.With.Dot','_root_','localName']]),
 ('multiline_modifier_and_attribute_prefix',[
  'namespace Fixture','private','@[tag (s := "def fake")]','noncomputable',
  'def value : Nat := 1','theorem after : True := by trivial','end Fixture'],
  [['Fixture','value'],['Fixture','after']]),
 ('docstrings_do_not_end_body',[
  'namespace Fixture','@[simp] theorem one : True := by',
  '  /- A body comment, with /- nested -/ structure. -/','  trivial',
  '/-- This next docstring belongs to another declaration. -/',
  '@[simp] theorem two : True := by trivial','end Fixture'],
  [['Fixture','one'],['Fixture','two']]),
 ('named_and_anonymous_priority_instances',[
  'namespace Fixture','instance (priority := 100) namedInst : Inhabited Nat := ⟨0⟩',
  'instance (priority := 50) : Inhabited Nat := ⟨0⟩','end Fixture'],
  [['Fixture','namedInst']]),
 ('declaration_universe_parameters',[
  'namespace Fixture','def value.{u} (α : Type u) := α','end Fixture'],
  [['Fixture','value']]),
]

def main():
 for n in ('parser-regression-fixtures.json','source-parser-static-checks.json'):
  need(not(HERE/n).exists(),'never overwrite fixture result')
 fixtures=[];checks=[]
 for label,lines,expected in CASES:
  text='\n'.join(lines)+'\n';idx=sc.parse(text)
  need(idx['unclosed_scope_count']==0,'unclosed fixture scope')
  for parts in expected:
   u=named(idx,parts);need(sc.mapping_safe(u),'safe fixture unresolved '+label+repr(u['mapping_warnings']))
   need(sc.sha(text[u['char_start']:u['char_end']])==u['raw_sha256'],'full source recovery differs')
  if label=='forall_and_default_binders':
   u=named(idx,['Fixture','defaults']);at=text.index(':= by\n')
   need(sc.sha(text[u['char_start']:at])==u['header_raw_sha256'],'default assignment mistaken for body')
   need(sc.sha(text[at:u['char_end']])==u['body_raw_sha256'],'forall body split differs')
  if label=='absolute_value_not_equation_clause':
   u=named(idx,['Fixture','absType']);at=text.index(':= by\n')
   need(u['body_form']=='assignment' and sc.sha(text[u['char_start']:at])==u['header_raw_sha256'],'absolute-value bar mistaken for equation clause')
   need(sc.source_key_matches(u,'_root_.Fixture.absType') and not sc.source_key_matches(u,'absType'),'short spelling treated as exact canonical key')
  if label=='multiline_attributes_modifiers_quoted_name':
   u=named(idx,['Fixture','quoted.name'])
   need(sc.source_key_matches(u,'Fixture.«quoted.name»'),'quoted key lost components')
   need(not sc.source_key_matches(u,'Fixture.quoted.name'),'quoted dot split as namespace')
   need(u['start_line']==2 and u['declaration_line']==7,'attribute/modifier prefix lost')
  fixtures.append({'label':label,'text':text,'expected_components':expected})
  checks.append({'label':label,'status':'PASS_LEXICAL_ONLY','units':[{k:u[k] for k in ('kind','canonical_parts','start_line','declaration_line','end_line','mapping_warnings')} for u in idx['units']]})
 ambiguous=[
  ('unsupported_attribute_prefix','@[simp] unknown_command\ntheorem after : True := by trivial\n'),
  ('unbalanced_attribute_prefix','@[simp\ntheorem after : True := by trivial\n'),
  ('indented_declaration','namespace Fixture\n  @[simp] theorem nested : True := by trivial\nend Fixture\n'),
  ('mutual_declarations','namespace Fixture\nmutual\ndef one : Nat := 1\ndef two : Nat := 2\nend\nend Fixture\n'),
  ('unparenthesized_type_let','theorem value : let n := 0; n = n := by rfl\n')]
 for label,text in ambiguous:
  idx=sc.parse(text);need(any(u['lexical_boundaries_need_review'] for u in idx['units']),'ambiguous fixture accepted '+label)
  if label=='unsupported_attribute_prefix':
   u=named(idx,['after']);need(u['start_line']==2 and not u['attribute_lines'],'orphan attribute folded forward')
  if label=='unbalanced_attribute_prefix':need(not sc.mapping_safe(named(idx,['after'])),'unclosed attribute enabled later identity')
  if label in {'mutual_declarations','unparenthesized_type_let'}:need(not any(sc.mapping_safe(u) for u in idx['units']),'ambiguous declaration received identity')
  fixtures.append({'label':label,'text':text,'expected':'UNRESOLVED_NO_FALLBACK'})
  checks.append({'label':label,'status':'PASS_UNRESOLVED_PRESERVED','issues':idx['mapping_issues']})
 duplicate=sc.parse('theorem same : True := by trivial\ntheorem same : True := by trivial\n')
 need(len(sc.match_unit(duplicate,duplicate['units'][0]))==2,'duplicate name silently selected')
 checks.append({'label':'duplicate_source_name_no_unique_match','status':'PASS_LEXICAL_ONLY'})
 private=[['str','_private'],['str','Owner'],['num','0'],['str','N'],['str','x']]
 need(sc.user_parts(private)==[['str','N'],['str','x']],'private source view differs')
 nonzero=[['str','_private'],['num','1'],['str','x']]
 need(sc.user_parts(nonzero)==nonzero,'nonzero private component guessed')
 need(sc.actual_key({'components':private})!=sc.actual_key({'components':sc.user_parts(private)}),'source view replaced full identity')
 checks.append({'label':'actual_numeric_private_identity_separate','status':'PASS_DATA_ONLY'})
 snapshots=json.loads((HERE.parent/'rule10-failure-review-prep-r1/preflight/source-snapshots.json').read_bytes())
 refs=['a495f3953afff46ad5dec2d29ac8a7f55bd8ae37','067c5d8d6dd436e62681d7dc607984c705dc80a2']
 actual=[
  ('TCSlib/Complexity/ClassP/BinaryArith/Loops.lean',['Complexity','BinArith','uHead_nil']),
  ('TCSlib/Complexity/ClassP/BinaryArith/Loops.lean',['Complexity','BinArith','uRest_nil']),
  ('TCSlib/Cryptography/Candidates/Concrete.lean',['TCSlib','Cryptography','Candidates','primesPairEquiv_apply_val']),
  ('TCSlib/InformationTheory/Extractors.lean',['TCSlib','InformationTheory','abs_probTrue_sub_le_statDist'])]
 for ref in refs:
  for path,parts in actual:
   raw=subprocess.check_output(['git','--no-optional-locks','show',ref+':'+path],cwd=ROOT)
   need(hashlib.sha256(raw).hexdigest()==snapshots[ref]['sources'][path]['sha256'],'actual source differs from pinned snapshot')
   text=raw.decode();idx=sc.parse(text);u=named(idx,parts)
   expected_attrs=[] if path.endswith('Extractors.lean') else [u['declaration_line']]
   need(sc.mapping_safe(u) and u['attribute_lines']==expected_attrs,'actual attribute/type boundary unresolved')
   if path.endswith('Extractors.lean'):need(u['body_form']=='assignment','actual absolute-value type treated as equations')
   need(len(sc.select_unit(idx,u['declaration_line']))==1 and sc.source_key_matches(u,'.'.join(parts)),'actual source key/line disagrees')
   envelope=text[u['char_start']:u['char_end']]
   need('theorem '+parts[-1] in envelope,'actual declaration lost')
   forbidden='decodeNat_eq' if path.endswith('Loops.lean') else 'one_div_card_primes_le'
   need(forbidden not in envelope,'old next-declaration fallback persists')
   label='actual_absolute_value_type' if path.endswith('Extractors.lean') else 'actual_inline_attribute'
   fixtures.append({'label':label,'ref':ref,'path':path,'expected_components':parts,'source_sha256':hashlib.sha256(raw).hexdigest(),'raw_envelope':envelope})
   checks.append({'label':label,'ref':ref,'path':path,'canonical_parts':parts,'status':'PASS_PINNED_SOURCE_LEXICAL_MAPPING_ONLY','unit':u})
 with (HERE/'parser-regression-fixtures.json').open('xb') as f:f.write(encode({'status':'LEXICAL_FIXTURES_NOT_LEAN_ELABORATION','fixtures':fixtures}))
 report={'status':'ALL_OWN_NONNATIVE_REGRESSIONS_PASS','source_parser_sha256':hashlib.sha256((HERE/'source_context.py').read_bytes()).hexdigest(),'fixture_program_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'check_count':len(checks),'actual_pinned_source_checks':8,'native_run':False,'limits':['Python lexical source parser only; no Lean syntax/elaboration clearance.','Source mappings are not elaborated actual Name identities.']}
 with (HERE/'source-parser-static-checks.json').open('xb') as f:f.write(encode(report))
 print(json.dumps({'checks':len(checks),'actual_source_checks':8,'native_run':False},indent=2))

if __name__=='__main__':main()
