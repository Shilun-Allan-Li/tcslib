# S2 operative context at the combined head

The 17 prior Gate06 failing owners, covering 110 historical keys, reach zero of the five S2 files at combined `a495f395`, actual base `067c5d8d`, or audited `3f6db40e`. Their full local import closures contain 147 distinct source files. Every path, source hash and ordered import vector agrees between the combined and audited heads. The stored toolchain and package pins also agree. All 17 closure code vectors differ against the actual base. S2 supplies no local source dependency delta for those 17 groups. Use the actual base context and fresh diagnostic evidence for their dispositions.

The five S2 files are byte-identical at the combined head, actual base and accepted S2 `d8c4cfed`. Their ordered import vectors also agree with `3f6db40e`. The diff from `3f6db40e` changes no import, open, namespace, option, attribute or instance-registration line. It changes local proof and definition paths. `Concrete` fills H15, `polyTimeComputable_rejectBlocksL`, with private `rbl_*` helpers and the existing repetition host. `DiscreteLog`, `ElGamal` and `RSA` retire private loops in favor of H15 and comparison or unit-test adapters. `Rabin` retires its private loop and rewrites the retained private `rabin_spOut` to a first-hit search with a padded fallback. Its adapter proofs use local `DecidablePred` and width hypotheses. Those hypotheses matter for proof elaboration even with stable global registration lines.

Across the five S2 owners, the actual-base closure paths and external import names agree with the combined head. Changed upstream source code is in `Asymptotic/Adversary` and `InformationTheory/FinDist` for all five, plus `CircuitComplexity/DAGCircuit` for `DiscreteLog` and `ElGamal`. `Authentication.DLHash` is the sole other audited owner reaching S2. It reaches `Concrete` and `DiscreteLog` at both heads where it exists, and is absent at the actual base. Its `polyTimeComputable_dlHashGenFun` uses the revised DiscreteLog sampler proof.

For later matching diagnostics, preserve the failing source owner separately from the provider whose interface is implicated. Use the recovered source line and full actual Name components. The five historical S2 source proofs agree with the actual base. Their old diagnostics suggest the following first comparisons.

| Source site | First comparison |
|---|---|
| `Concrete.lean` 340–344, `primesPairEquiv_apply_val` | The equivalence and coercion goal precedes H15. Resolve the unqualified `bitsEquiv` using actual references. `TCSlib.Cryptography.bitsEquiv` and `Randomized.bitsEquiv` share that suffix. |
| `DiscreteLog.lean` 440–445, `ExpGroupGen.FullLength.exists_fullLengthExcept` | The old argument mismatch concerns the `Negligible` binder. Keep its two follow-on diagnostics in the same historical group. |
| `RSA.lean` 2028–2029, `rsaTrapdoor_oneWay` | Compare the collection and trapdoor `OneWay` interfaces in `Asymptotic/Collections`. |
| `Rabin.lean` 1216–1219, `rabinCollection_index`, and 2942–2946, `rabinBlumTrapdoor_index` | Compare `Collection.index_eq` and the odd/Blum generator projections. Keep these as two declaration groups. |

The R2 unresolved `GI.unaryMul_poly` envelope still needs manual source and Name comparison if it recurs. These source comparisons leave current failure and inheritance dispositions open.

Scope-audit inputs are in `.lake/ps-maintainer/gate06-combined-20261108/` in the integration checkout. Preserve these exact paths for the evidence index.

- `rule10-prep/scope-proposal.json` SHA256 `82ee3711d1ae41e9934810f442218f427916f65ab88193840db32592b2ca726b`
- `rule10-failure-review-prep-r2/preflight/all59-source-envelope-indices.json` SHA256 `e261af92182c5a3ebf60313d0e359318d972b2eaf1d6f08c7f448c7c0cf0157a`
- `rule10-failure-review-prep-r2/preflight/context-closures.json` SHA256 `43f18d93b5a6c9f89ac33a53cedebfeaa62addd737f779bdac6df243369871a1`
- `rule10-failure-review-prep-r2/preflight/source-snapshots.json` SHA256 `a337959ec037377383cdea114e29101c60cca56808d620649ff83904516cf213`
- `rule10-failure-review-prep-r2/preflight/preflight-manifest.json` SHA256 `c5dd060a34db414fad7b163607487bf0c58d7d39e55a85c1d5f336cbf4a944db`, which binds the historical witnesses and operative-context comparisons
- `combined-source-commit.json` SHA256 `b8ab9238b292c2c484afc210fbce23e3fbfb97d5642e518745305f93fb0406f8`

The scope audit also used these exact paths below `/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean/`.

- `Lean/Elab/Open.lean`, `Lean/Elab/BuiltinCommand.lean`, `Lean/Elab/BuiltinTerm.lean`, and `Lean/Elab/Tactic/BuiltinTactic.lean` for activation and scope restoration
- `Lean/ScopedEnvExtension.lean`, `Lean/Data/SMap.lean`, and `Lean/Data/PersistentArray.lean` for the pending membership state and its enumeration
