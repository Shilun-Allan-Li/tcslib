"""Run three frozen probes with a separate, exact Configuration olean."""

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys

root = Path.cwd()
area = Path(__file__).resolve().parent
out = area / "instance-prototype-isolated-r2"
tree = out / "oleans"
sources = area / "instance-prototype-r2"
local = area / "native-local-resume-r1"
checker = area / "rule10-prep/proposed-tools/check_probe_v2.py"
config_module = "TCSlib/Complexity/TuringMachine/Configuration"
head = "a495f3953afff46ad5dec2d29ac8a7f55bd8ae37"
pins = {
    local / "RESULT.json": "6a019e8051ef7deceae8fec3fd9ac53698e43985c7fe9f86d4e7b1d0ab12e656",
    local / "local-records.json": "8c59fdcd4066eda738aa30422474ffb38912b4d0fb2ea514b18fb5ae033ee9dc",
    local / "external-final.json": "9ae25d17d062321af3fd766acdbb01a73cbd03a2fa92172575250910361ff0fd",
    sources / "PREPARATION.json": "0d7932bdf55b632775ae7bef9f98ca87f0150b07f4902f9b0f8d671846d43a1d",
    checker: "c685d6aa01b1b7e44115e88781d1634b3b3cdda512acc702eeba5e810f767179",
    root / "scripts/lean_check_tree.sh": "366dab40e8e8f0f13e14118e14c3d6be1bc1b36604e6c9ccdebb03bc96cdf335",
    area / "pfr-runtime-r1/config.json": "4d1a6453a3586f5263628712ad15ab734514a04bbe65e10c1c468f70bb0c8c16",
    area / "user-rulings-20261108-r1.json": "3f0730086b324c2773bcf5239eadfdb86f7c026bbbb5bf2f344283372fa7f9fa",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write(path, record):
    with path.open("x") as stream:
        stream.write(json.dumps(record, indent=2) + "\n")


def resources():
    raw = subprocess.check_output(["/usr/bin/memory_pressure", "-Q"], text=True)
    memory = int(re.search(r"system has (\d+)", raw)[1])
    free = int(re.search(r"memory free percentage:\s*(\d+)%", raw)[1])
    disk = shutil.disk_usage(root).free
    headroom = memory * max(free - 1, 0) // 100
    assert headroom >= 4 * 1024**3 and disk >= 12 * 1024**3, "Resource floor"
    return {"memory_headroom_bytes": headroom, "disk_free_bytes": disk}


def stop(signum, _frame):
    raise InterruptedError(f"Pilot signal {signum}")


assert root == area.parents[2]
record = load(local / "local-records.json")[config_module]
external = load(local / "external-final.json")
config = load(area / "pfr-runtime-r1/config.json")
prep = load(sources / "PREPARATION.json")


def validate():
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == head
    assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"])
    assert not (root / ".lake/build/lib/lean").exists()
    for path, expected in pins.items():
        assert sha(path) == expected, path
    assert sha(Path(config["real_lean"])) == config["real_lean_sha256"]
    assert sha(root / (config_module + ".lean")) == record["source_sha256"]
    assert not record["direct_local_object_sha256"]
    assert len(external) == 3810
    for name, row in external.items():
        assert sha(Path(row["object_path"])) == row["object_sha256"], name
    for name, expected in record["direct_external_object_sha256"].items():
        assert external[name]["object_sha256"] == expected, name


validate()
assert prep["head"] == head and prep["native_replay_receipt"]["sha256"] == pins[local / "RESULT.json"]
origin = area / "oleans-r1" / (config_module + ".olean")
copied = tree / (config_module + ".olean")
out.mkdir()
copied.parent.mkdir(parents=True)
shutil.copyfile(origin, copied)
assert sha(copied) == record["object_sha256"] and not copied.samefile(origin)
shutil.copyfile(checker, out / checker.name)
write(out / "setup-summary.json", {"head": head, "olean_tree": str(tree), "scope": config_module})
write(out / "START.json", {"head": head, "pid": os.getpid(), "configuration": record, "tree": str(tree),
                          "inputs": {str(p): h for p, h in pins.items()},
                          "runner_sha256": sha(Path(__file__)), "resources": resources()})
env = os.environ.copy()
for name in ("LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LEAN_OPTS", "ELAN_TOOLCHAIN", "PFR_BOOTSTRAP_CONFIG"):
    env.pop(name, None)
env["PATH"] = str(Path(config["real_lean"]).parent) + ":/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
for sig in (signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, stop)
results = []
for probe in prep["probes"]:
    resources()
    path = sources / probe["file"]
    label = path.stem
    assert sha(path) == probe["sha256"] and sha(out / checker.name) == pins[checker]
    attempt = out / label
    module = path.relative_to(root).with_suffix("").as_posix()
    command = [sys.executable, "-I", str(out / checker.name), str(attempt), module, label]
    proc = subprocess.Popen(command, env=env, start_new_session=True)
    try:
        write(out / (label + "-child.json"), {"pid": proc.pid, "pgid": proc.pid, "command": command})
        rc = proc.wait(timeout=180)
    except BaseException:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        raise
    receipt = attempt / (label + ".json")
    log = attempt / (label + ".log")
    result = load(receipt)
    assert rc == result["rc"] and result["source_unchanged"] and sha(path) == result["source_sha256"] == probe["sha256"]
    assert log.read_text().rstrip().endswith(f"END {result['end']} RC {rc}")
    results.append({"probe": label, "rc": rc, "receipt_sha256": sha(receipt), "log_sha256": sha(log)})
validate()
assert sha(origin) == sha(copied) == record["object_sha256"]
write(out / "RESULT.json", {"head": head, "inputs_revalidated": True, "native_results": results,
                            "outcomes_interpreted": False})
