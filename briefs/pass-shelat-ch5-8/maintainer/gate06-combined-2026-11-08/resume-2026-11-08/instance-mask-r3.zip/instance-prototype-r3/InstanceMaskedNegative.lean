import Lean
import TCSlib.Complexity.TuringMachine.Configuration

set_option maxHeartbeats 0

open Lean Elab Command Meta

private def targetInstance : Name := `Turing.instInhabitedCfg

-- The stock BEq InstanceEntry compares only val.
private abbrev EntryFields :=
  Array DiscrTree.Key × ExprStructEq × Nat × Option Name × Array Nat × AttributeKind

private def entryFields (e : InstanceEntry) : EntryFields :=
  (e.keys, ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)

private structure LookupSnapshot where
  tree : Array (Array DiscrTree.Key × EntryFields)
  named : Array (Name × EntryFields)
  erased : List Name
  candidates : Array EntryFields
  chosen : ExprStructEq
  chosenType : ExprStructEq
  declarationType : ExprStructEq
  declarationValue : ExprStructEq
  deriving BEq

private def snapshotLookup : CommandElabM LookupSnapshot := do
  let env ← getEnv
  let some (.defnInfo info) := env.find? targetInstance
    | throwError "INSTANCE-HARNESS: missing target definition"
  let state := instanceExtension.getState env
  let (candidates, chosen, chosenType) ← liftTermElabM do
    resetCache
    let ty ← Term.elabType (← ``(Inhabited (Turing.Cfg 0 Bool Unit ([] : List Bool))))
    let index ← getGlobalInstancesIndex
    let candidates ← index.getUnify ty
    let candidates := candidates.insertionSort fun a b => a.priority < b.priority
    let chosen ← instantiateMVars (← synthInstance ty)
    unless !chosen.hasMVar && chosen.getAppFn.isConstOf targetInstance do
      throwError "INSTANCE-HARNESS: unexpected synthesized expression"
    let chosenType ← instantiateMVars (← inferType chosen)
    return (candidates.map entryFields, ExprStructEq.mk chosen, ExprStructEq.mk chosenType)
  return {
    tree := state.discrTree.toArray.map fun (ks, e) => (ks, entryFields e)
    named := state.instanceNames.toArray.map fun (n, e) => (n, entryFields e)
    erased := state.erased.toList
    candidates, chosen, chosenType
    declarationType := ExprStructEq.mk info.type
    declarationValue := ExprStructEq.mk info.value }

private def checkSnapshot (masked : Bool) (marker : String)
    (before : Option LookupSnapshot := none) : CommandElabM Unit := do
  let env ← getEnv
  let status ← liftCoreM <| Lean.getReducibilityStatus targetInstance
  let wanted := if masked then ReducibilityStatus.irreducible else .semireducible
  unless status == wanted do
    throwError "INSTANCE-HARNESS: wrong post-attribute status"
  unless Meta.isGlobalInstance env targetInstance == !masked do
    throwError "INSTANCE-HARNESS: wrong unfolding membership"
  unless Meta.isInstanceCore env targetInstance do
    throwError "INSTANCE-HARNESS: missing typeclass registration"
  let after ← snapshotLookup
  if let some baseline := before then
    unless baseline == after do
      throwError "INSTANCE-HARNESS: lookup fields/order, synthesis, or declaration changed"
    logInfo "INSTANCE-LOOKUP-VERIFIED"
  let info ← getConstInfo targetInstance
  let defaultUnfolds ← liftTermElabM <| withTransparency .default (canUnfold info)
  let instancesUnfolds ← liftTermElabM <| withTransparency .instances (canUnfold info)
  unless defaultUnfolds == !masked && instancesUnfolds == !masked do
    throwError "INSTANCE-HARNESS: unexpected unfolding permission"
  let some targetPriority ← liftCoreM <| getInstancePriority? targetInstance
    | throwError "INSTANCE-HARNESS: missing target priority"
  logInfo m!"{marker} masked={masked} default={defaultUnfolds} instances={instancesUnfolds} tree={after.tree.size} named={after.named.size} candidates={after.candidates.size} priority={targetPriority}"

run_cmd do
  let env ← getEnv
  let some idx := env.getModuleIdxFor? targetInstance
    | throwError "INSTANCE-HARNESS: target not imported"
  unless env.header.moduleNames[idx.toNat]! == `TCSlib.Complexity.TuringMachine.Configuration do
    throwError "INSTANCE-HARNESS: wrong target home"
  let status ← liftCoreM <| Lean.getReducibilityStatus targetInstance
  unless status == .semireducible && Meta.isGlobalInstance env targetInstance &&
      Meta.isInstanceCore env targetInstance do
    throwError "INSTANCE-HARNESS: wrong baseline instance status"
  let before ← snapshotLookup
  logInfo "INSTANCE-CATALOG-VERIFIED"
  let target := mkIdent targetInstance
  elabCommand (← `(command| attribute [local irreducible] $target:ident))
  let maskExt := Meta.globalInstanceExtension
  let maskEnv ← getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "INSTANCE-HARNESS: unfolding mask requires base scope"
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      if n == targetInstance then
        throwError "INSTANCE-HARNESS: scoped unfolding payload intersects target"
  logInfo "INSTANCE-SCOPE-GUARD-VERIFIED"
  modifyEnv fun current => maskExt.modifyState current (fun s => s.erase targetInstance)
  checkSnapshot true "INSTANCE-INSTALL-VERIFIED" (some before)

section
namespace InstancePilotNested
run_cmd checkSnapshot true "INSTANCE-SCOPE-PUSH-VERIFIED"
open scoped Turing
run_cmd checkSnapshot true "INSTANCE-SCOPE-ACTIVATION-VERIFIED"
end InstancePilotNested
end
run_cmd checkSnapshot true "INSTANCE-SCOPE-POP-VERIFIED"

run_cmd logInfo "INSTANCE-BODY-BEGIN"
theorem instanceBody :
    (default : Turing.Cfg 0 Bool Unit []) =
      ⟨none, 0, (fun _ _ => none), (fun _ => 0), []⟩ := rfl
run_cmd logInfo "INSTANCE-BODY-END"

run_cmd checkSnapshot true "INSTANCE-EOF-VERIFIED"
