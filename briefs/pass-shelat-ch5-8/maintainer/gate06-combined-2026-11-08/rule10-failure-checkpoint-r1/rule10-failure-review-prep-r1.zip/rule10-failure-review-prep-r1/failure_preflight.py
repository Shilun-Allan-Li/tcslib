#!/usr/bin/env python3
"""Own NONNATIVE historical/source-context preflight. Never executes incoming code.

Writes one fresh ignored data directory. Historical failures remain observations;
current59 outcomes are unknown. Exact full-source import context is a safe
superset of all operative local dependencies, not a guessed semantic call graph.
"""
from pathlib import Path
from collections import Counter
import argparse,ast,hashlib,json,re,subprocess,sys,importlib.util
sys.dont_write_bytecode=True
_spec=importlib.util.spec_from_file_location('own_source_context',Path(__file__).with_name('source_context.py'))
sc=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(sc)
ROOT=Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
MAIN=Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
HERE=Path(__file__).resolve().parent
REL='briefs/pass-shelat-ch5-8/'
G06=MAIN/REL/'maintainer/gate06-integration-2026-11-06/evidence-rule10-final-r1'
S2=MAIN/REL/'fills/shared-lemmas/s2/final/maintainer-rule10'
HIST=MAIN/REL/'gates/07-eqlemmas/evidence-r2/r6c'
HEAD='a495f3953afff46ad5dec2d29ac8a7f55bd8ae37';BASE='067c5d8d6dd436e62681d7dc607984c705dc80a2'
AUDIT='3f6db40e1688c4a0bb922c9575dd3bd2157a650b';VERIFY='eee107e92a7db11f1f8c98a5c2867304f57ddc54'
S2HEAD='d8c4cfed793f04062e7e79b78344e5b593ff3ddc';S2BASE='34cc6518dcceb62fcac4f1cf2dcd9c4c37971c94'
REFS=[HEAD,BASE,AUDIT,VERIFY,S2HEAD,S2BASE]
ERROR=re.compile(r'(?m)^([^\n]*?\.lean):(\d+):(\d+): error(?:\(([^\n)]*)\))?:([^\n]*)')

def need(x,m):
 if not x:raise RuntimeError(m)
def enc(x):return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
def git(*args,data=None):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT,input=data)
def sha(b):return hashlib.sha256(b).hexdigest()
def js(path):
 def uniq(items):
  out={}
  for k,v in items:need(k not in out,'duplicate JSON key');out[k]=v
  return out
 return json.loads(path.read_bytes(),object_pairs_hook=uniq)

class Review:
 def __init__(self,out):
  self.out=out;self.blobs={};self.texts={};self.indices={};self.evidence=[];self.snapshots={};self.contexts={};self.history=[]
 def blob(self,raw):
  h=sha(raw);p=self.out/'blobs'/h
  if h not in self.blobs:
   p.parent.mkdir(parents=True,exist_ok=True)
   with p.open('xb') as f:f.write(raw)
   self.blobs[h]={'path':'blobs/'+h,'bytes':len(raw)}
  return h
 def capture(self,path,expected=None):
  need(path.is_file() and not path.is_symlink(),'nonordinary evidence '+str(path));raw=path.read_bytes();h=self.blob(raw);need(expected is None or h==expected,'evidence hash mismatch '+str(path))
  item={'original':str(path),'sha256':h,'bytes':len(raw),'snapshot':self.blobs[h]['path']}
  if path.is_relative_to(MAIN):
   rel=path.relative_to(MAIN).as_posix();r=subprocess.run(['git','--no-optional-locks','cat-file','-e',BASE+':'+rel],cwd=ROOT,capture_output=True)
   if r.returncode==0:
    pinned=git('show',BASE+':'+rel);need(pinned==raw,'record working bytes differ from actual PRbase '+rel);item['exact_Git_record_pin']=BASE+':'+rel
   else:item['exact_Git_record_pin']=None
  self.evidence.append(item);return raw
 def write(self,name,value):
  p=self.out/name;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(enc(value))
 def snapshots_prepare(self):
  trees={};objects=set()
  for ref in REFS:
   need(git('rev-parse',ref+'^{commit}').decode().strip()==ref,'bad full ref')
   rows={}
   for entry in git('ls-tree','-r','-z',ref,'--','TCSlib','TCSlib.lean').split(b'\0'):
    if not entry:continue
    meta,p=entry.split(b'\t',1);mode,kind,obj=meta.decode().split();path=p.decode()
    if not path.endswith('.lean'):continue
    need(kind=='blob' and mode=='100644','nonordinary source');rows[path]=obj;objects.add(obj)
   trees[ref]=rows
  raw=git('cat-file','--batch',data=('\n'.join(sorted(objects))+'\n').encode());at=0;data={}
  for obj in sorted(objects):
   end=raw.index(b'\n',at);h,k,n=raw[at:end].decode().split();at=end+1;n=int(n);b=raw[at:at+n];at+=n+1
   need(h==obj and k=='blob' and hashlib.sha1(b'blob '+str(n).encode()+b'\0'+b).hexdigest()==obj,'Git object mismatch')
   d=self.blob(b);text=b.decode();self.texts[d]=text;data[obj]={'sha256':d,'git_blob':obj,'bytes':n,'code_sha256':sc.sha(sc.code(text)),'imports':sc.imports(text)}
  for ref,paths in trees.items():
   sources={p:{**data[obj],'module':p[:-5].replace('/','.')} for p,obj in paths.items()};self.snapshots[ref]={'sources':sources,'pins':{}}
   for f in ['lean-toolchain','lake-manifest.json','lakefile.lean']:
    try:b=git('show',ref+':'+f)
    except subprocess.CalledProcessError:b=None
    self.snapshots[ref]['pins'][f]=self.blob(b) if b is not None else None
 def text(self,ref,path):
  row=self.snapshots[ref]['sources'].get(path);return self.texts[row['sha256']] if row else None
 def index(self,ref,path):
  text=self.text(ref,path)
  if text is None:return {'units':[],'missing_source':True}
  key=sc.sha(text)
  if key not in self.indices:self.indices[key]=sc.parse(text)
  return self.indices[key]
 def closure(self,ref,module):
  key=(ref,module)
  if key in self.contexts:return self.contexts[key]
  sources=self.snapshots[ref]['sources'];start=module.replace('.','/')+'.lean'
  if start not in sources:ctx={'owner_present':False,'paths':[],'external_boundary':[],'missing_local_imports':[]}
  else:
   found=set();stack=[start];external=set();missing=[]
   while stack:
    path=stack.pop()
    if path in found:continue
    found.add(path)
    for name in sources[path]['imports']:
     target=name.replace('.','/')+'.lean'
     if name=='TCSlib' or name.startswith('TCSlib.'):
      if target not in sources:missing.append({'from':path,'module':name})
      else:stack.append(target)
     else:external.add(name)
   vector=[{'path':p,'sha256':sources[p]['sha256'],'code_sha256':sources[p]['code_sha256'],'git_blob':sources[p]['git_blob']} for p in sorted(found)]
   ctx={'owner_present':True,'paths':sorted(found),'external_boundary':sorted(external),'missing_local_imports':missing,
        'raw_vector_sha256':sc.sha(sc.canonical(vector)),'code_vector_sha256':sc.sha(sc.canonical([{'path':r['path'],'code_sha256':r['code_sha256']} for r in vector]))}
  self.contexts[key]=ctx;return ctx
 def compare_context(self,module,left,right):
  a=self.closure(left,module);b=self.closure(right,module);changed=[]
  for p in sorted(set(a['paths'])|set(b['paths'])):
   aa=self.snapshots[left]['sources'].get(p);bb=self.snapshots[right]['sources'].get(p)
   if aa and bb and aa['sha256']==bb['sha256']:continue
   detail={'path':p,'left':aa,'right':bb,'code_equal':bool(aa and bb and aa['code_sha256']==bb['code_sha256'])}
   # Conservative named data/interface context comparison, including added readers and binding commands.
   ad=self.index(left,p);bd=self.index(right,p)
   def inventory(index):
    return [{'kind':u['kind'],'canonical_parts':u['canonical_parts'],'header_code_sha256':u['header_code_sha256'],
       'ordinary_body_code_sha256':u['body_code_sha256'] if u['kind'] in sc.DATA or u['kind']=='source-command' else None,
       'binding_trace_sha256':u['binding_trace_sha256']} for u in index['units']]
   ai,bi=inventory(ad),inventory(bd);detail.update(left_definition_interface_inventory=ai,right_definition_interface_inventory=bi,
       definition_interface_inventory_equal=ai==bi,lexical_index_limits={'left_indented_declaration_lines':ad.get('indented_declaration_lines',[]),'right_indented_declaration_lines':bd.get('indented_declaration_lines',[])})
   changed.append(detail)
  return {'module':module,'left_ref':left,'right_ref':right,'left':a,'right':b,'complete_import_source_context_equal':a.get('code_vector_sha256')==b.get('code_vector_sha256') and a['owner_present'] and b['owner_present'],
    'package_toolchain_source_pins_equal':self.snapshots[left]['pins']==self.snapshots[right]['pins'],'changed_context_files':changed,
    'interpretation':'Safe complete-source over-approximation of operative dependencies; any changed/unknown context stays review-required. Not an elaborated semantic call graph or native environment equivalence.'}
 def block(self,ref,path,unit):
  if unit is None:return None
  text=self.text(ref,path);raw=text[unit['char_start']:unit['char_end']].encode();need(sha(raw)==unit['raw_sha256'],'unit byte recovery mismatch')
  return {'ref':ref,'path':path,'source_sha256':self.snapshots[ref]['sources'][path]['sha256'],'raw_blob':self.blob(raw),'unit':unit}
 def pair(self,path,unit,left=BASE,right=HEAD):
  matches=sc.match_unit(self.index(left,path),unit);base=matches[0] if len(matches)==1 else None
  h=self.block(right,path,unit);b=self.block(left,path,base)
  return {'head':h,'actual_base':b,'base_match_count':len(matches),'raw_header_body_equal':bool(base and base['declaration_raw_sha256']==unit['declaration_raw_sha256']),
    'header_code_equal':bool(base and base['header_code_sha256']==unit['header_code_sha256']),'body_code_equal':bool(base and base['body_code_sha256']==unit['body_code_sha256']),
    'namespace_scope_equal':bool(base and base['namespace_parts']==unit['namespace_parts'] and base['scope_stack']==unit['scope_stack']),
    'binding_trace_equal':bool(base and base['binding_trace_sha256']==unit['binding_trace_sha256']),
    'full_preceding_code_equal':bool(base and base['complete_prefix_code_sha256']==unit['complete_prefix_code_sha256']),
    'status':'COMPARISON_DATA_ROOT_REVIEW_REQUIRED','failure_waiver':False}
 def historical(self):
  for filename in ['cleanup-b-decls.tsv','cleanup-b.tsv']:
   raw=self.capture(HIST/filename)
   for line_no,line in enumerate(raw.decode().splitlines(),1):
    f=re.split(r'\t|\\t',line)
    if filename=='cleanup-b-decls.tsv' and len(f)>=2:path,name=f[:2]
    elif filename=='cleanup-b.tsv' and len(f)>=4:path,name=f[2],re.sub(r'^(?:theorem|lemma|def|instance|structure|inductive|abbrev|class)\s+','',f[3])
    else:continue
    if not(path.startswith('TCSlib/') and path.endswith('.lean')):continue
    self.history.append({'inventory':filename,'line':line_no,'raw':line,'file':path,'verbatim_source_key':name,'normalized_source_key':name.removeprefix('_root_.'),'normalization':'leading _root_. ONLY'})
 def exact_links(self,path,unit):
  index=self.index(HEAD,path);short=unit['source_name'];unique=short and sum(u['source_name']==short for u in index['units'])==1
  canonical=unit['canonical'];variants={canonical} if canonical else set()
  if unique:variants.add(short.removeprefix('_root_.'))
  return [{**r,'basis':'PATH_AND_EXACT_CANONICAL' if r['normalized_source_key']==canonical else 'PATH_AND_EXACT_UNIQUE_DECLARED_SPELLING'} for r in self.history if r['file']==path and r['normalized_source_key'] in variants]
 def legacy_logs(self,summary_path,manifest_path,epoch):
  summary=js(summary_path);manifest=js(manifest_path);self.capture(summary_path);self.capture(manifest_path)
  probes={p['label']:p for p in manifest['probes']};out=[]
  if epoch=='S2':
   bm=js(S2/'base-seal-manifest.json');self.capture(S2/'base-seal-manifest.json');probes.update({p['label']:p for p in bm['probes']})
  for record in summary['results']:
   if not record.get('errors'):continue
   label=record['label'];probe=probes[label];role=record.get('role','Head');ref=(AUDIT if epoch=='Gate06' else S2HEAD if role=='Head' else S2BASE)
   logpath=Path(record.get('log',record.get('attempt_log')));resultpath=Path(record.get('result_path',record.get('attempt_result')))
   lb=self.capture(logpath,record['log_sha256']);rb=self.capture(resultpath,record['result_json_sha256']);need(js(resultpath)==record['result'],'embedded result differs')
   parsed=list(ERROR.finditer(lb.decode()));errors=record['errors'];need(len(parsed)==len(errors)==record['result']['error_diagnostics'],'diagnostics dropped')
   capture_path=logpath.with_name(label+'.source.txt');pb=self.capture(capture_path,record['captured_probe_sha256']);need(sha(pb)==probe['probe_sha256'],'old probe source hash differs')
   original=pb
   for add in reversed(probe['insertions']):
    at,n=add['probe_byte_offset'],add['byte_count'];need(sha(original[at:at+n])==add['sha256'],'old insertion hash mismatch');original=original[:at]+original[at+n:]
   path=record['module'].replace('.','/')+'.lean';need(original==self.text(ref,path).encode(),'old raw-source restoration is not exact Git')
   inv={r['probe_line']:r['source_line'] for r in probe['source_to_probe_lines']}
   for mt,e in zip(parsed,errors):
    need(int(mt[2])==e['probe_line'] and int(mt[3])==e['probe_column'] and (mt[4] or None)==e['error_code'] and lb.decode().count('\n',0,mt.start())+1==e['log_line'],'raw diagnostic identity differs')
    need(inv[e['probe_line']]==e['source_line'],'legacy source line map differs')
    units=sc.select_unit(self.index(ref,path),e['source_line'])
    out.append({'epoch':epoch,'role':role,'ref':ref,'file':path,'module':record['module'],'label':label,'raw_log_sha256':sha(lb),'native_result_sha256':sha(rb),'probe_sha256':sha(pb),'diagnostic':e,
       'source_envelope_candidates':[self.block(ref,path,u) for u in units],'status':'HISTORICAL_FAILED_OBSERVATION_NOT_CURRENT_RESULT','native_base_environment_rebuilt':False})
  return out

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();out=args.output.resolve()
 need(out.is_relative_to(HERE.resolve()) and not out.exists(),'output must be a NEW child of this ignored preflight directory')
 out.mkdir();r=Review(out);r.snapshots_prepare();r.historical()
 scope=js(ROOT/'.lake/ps-maintainer/gate06-combined-20261108/rule10-prep/scope-proposal.json');mods=scope['modules'];need(len(mods)==59 and scope['head']==HEAD,'wrong frozen59 scope')
 gd=G06/'failure-disposition-r1/disposition.json';sd=S2/'native-seal-runs/r1/source-failure-reconciliation.json'
 for p in [gd,gd.with_name('README.md'),gd.with_name('observations.tsv'),sd,MAIN/REL/'fills/shared-lemmas/s2/final/acceptance.md']:r.capture(p)
 prior=r.legacy_logs(G06/'native-seal-runs/summary.json',G06/'seal-manifest.json','Gate06')+r.legacy_logs(S2/'native-seal-runs/r1/summary.json',S2/'seal-manifest.json','S2')
 groups={}
 for row in prior:
  e=row['diagnostic'];key=(row['epoch'],row['file'],e['qualified_source_name']);groups.setdefault(key,[]).append(row)
 roots=[];context_pairs={};ambiguous=[]
 for (epoch,path,name),observations in sorted(groups.items()):
  headrows=[o for o in observations if o['role']=='Head'];need(headrows,'missing historical head role')
  priorunit=headrows[0]['source_envelope_candidates'];need(len(priorunit)==1,'ambiguous historical unit '+name);pu=priorunit[0]['unit']
  matches=sc.match_unit(r.index(HEAD,path),pu)
  if len(matches)!=1:ambiguous.append({'file':path,'canonical':name,'current_candidates':len(matches)})
  hu=matches[0] if len(matches)==1 else None
  module=headrows[0]['module']
  if module not in context_pairs:context_pairs[module]=r.compare_context(module,BASE,HEAD)
  roots.append({'file':path,'module':module,'historical_source_key':name,'historical_epoch':epoch,
     'historical_head_diagnostics':len(headrows),'historical_base_source_diagnostics':sum(o['role']=='Base' for o in observations),
     'observations':observations,'current_source_comparison':r.pair(path,hu) if hu else None,
     'exact_historical_inventory_links':r.exact_links(path,hu) if hu else [],'context_key':module,
     'current_outcome':'UNKNOWN_UNTIL_CURRENT59_NATIVE_SEALS','failure_retained':True,'waiver':False})
 need(len(roots)==115,'historical keys not115');need(sum(z['historical_head_diagnostics'] for z in roots)==145,'head diagnostics not145')
 need(sum(z['historical_base_source_diagnostics'] for z in roots)==7,'S2 base-source diagnostics not7')
 for module in mods:
  if module not in context_pairs:context_pairs[module]=r.compare_context(module,BASE,HEAD)
 all_owner_units={m:{'head':r.index(HEAD,p),'actual_PRbase':r.index(BASE,p)} for m,p in mods.items()}
 r.write('prior-witnesses.json',{'head':HEAD,'actual_PRbase':BASE,'historical_roots':roots,'current_mapping_ambiguities':ambiguous,'status':'ALL115_HISTORICAL_ROOT_KEYS_RETAINED_NO_CURRENT_CLASSIFICATION'})
 r.write('operative-context-comparisons.json',context_pairs)
 r.write('all59-source-envelope-indices.json',all_owner_units)
 r.write('source-snapshots.json',r.snapshots)
 r.write('historical-ledger-index.json',{'rows':r.history,'rule':'No suffix/fuzzy matching; literal _root_. qualifier only; all original rows retained.'})
 r.write('evidence-captures.json',r.evidence)
 r.write('context-closures.json',{ref:{m:r.closure(ref,m) for m in mods} for ref in REFS})
 r.write('blob-index.json',r.blobs)
 counts={'historical_root_keys':115,'Gate06_root_keys':sum(z['historical_epoch']=='Gate06' for z in roots),'S2_root_keys':sum(z['historical_epoch']=='S2' for z in roots),'historical_head_diagnostics':145,'S2_base_source_diagnostics':7,'historical_failing_raw_logs':len({o['raw_log_sha256'] for o in prior}),'current_failures':'UNKNOWN','mapping_ambiguities':ambiguous,'immutable_blob_count':len(r.blobs),'owner_scope':59,'source_context_modules':len(set().union(*(set(r.closure(HEAD,m)['paths']) for m in mods)))}
 r.write('summary.json',counts)
 manifest={'status':'NONNATIVE_PREFLIGHT_NO_CURRENT_OUTCOME','head':HEAD,'actual_PRbase':BASE,'refs':REFS,'helper_sha256':sha(Path(__file__).read_bytes()),'source_parser_sha256':sha((HERE/'source_context.py').read_bytes()),'files':{p.name:sha(p.read_bytes()) for p in sorted(out.glob('*.json'))},'limits':['All old observations retained; no current59 pass/failure prediction.','Complete transitive import-source context is conservative, not a resolved semantic operation graph.','Changed operative context/new/touched/ambiguous units stay root-review-required.','Old method skipped instances; new epoch expands coverage and does not inherit prior classifications.','Historical S2 base-source runs used head dependencies; no cold base environment is claimed.','Lexical unit/source names are not actual generated/private Lean Names; future full catalog/ROOT data must be attached without guessing.']}
 r.write('preflight-manifest.json',manifest);print(json.dumps(counts,indent=2))

if __name__=='__main__':main()
