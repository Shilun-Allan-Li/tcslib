"""Own conservative source index. No Lean execution or semantic-name resolution.

Every file/prefix/import closure remains an exact immutable context witness even
when lexical declaration mapping is ambiguous. No classification is a waiver.
"""
import hashlib,json,re
DECLS={'theorem','lemma','def','abbrev','opaque','axiom','instance','structure','inductive','class','example'}
DATA=DECLS-{'theorem','lemma','example'}
PREFIX=r'(?:(?:private|protected|noncomputable|nonrec|unsafe|partial)\s+)*'
DECL=re.compile(r'^'+PREFIX+r'(?P<kind>theorem|lemma|def|abbrev|opaque|axiom|instance|structure|inductive|class|example)\b')
COMMAND=re.compile(r'^(?:noncomputable\s+section|namespace|section|end|import|prelude|open|export|attribute|variable|variables|include|omit|set_option|local|scoped|syntax|macro|elab|initialize|builtin_initialize|mutual|notation|infix[lr]?|prefix|postfix|declare_syntax_cat|register_option|#\w+)\b')

def sha(b):return hashlib.sha256(b.encode() if isinstance(b,str) else b).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def lex(text):
    """Keep positions; distinguish comments from literal/quoted-identifier data."""
    comments=[];struct=list(text);i=0
    def blank(a,b):
        for k in range(a,b):
            if struct[k] not in '\r\n':struct[k]=' '
    while i<len(text):
        if text.startswith('--',i):
            end=text.find('\n',i);end=len(text) if end<0 else end;comments.append((i,end));blank(i,end);i=end
        elif text.startswith('/-',i):
            begin=i;depth=1;i+=2
            while i<len(text) and depth:
                if text.startswith('/-',i):depth+=1;i+=2
                elif text.startswith('-/',i):depth-=1;i+=2
                else:i+=1
            if depth:raise ValueError('unclosed nested comment')
            comments.append((begin,i));blank(begin,i)
        else:
            raw=re.match(r'r(#+)?"',text[i:]) if text[i]=='r' else None
            if raw:
                fence='"'+(raw[1] or '');end=text.find(fence,i+len(raw[0]))
                if end<0:raise ValueError('unclosed raw string')
                end+=len(fence);blank(i,end);i=end
            elif text[i] in ('"','«'):
                close='"' if text[i]=='"' else '»';end=i+1
                while end<len(text):
                    if close=='"' and text[end]=='\\':end+=2;continue
                    if text[end]==close:break
                    end+=1
                if end>=len(text):raise ValueError('unclosed string/quoted identifier')
                end+=1;blank(i,end);i=end
            elif text[i]=="'" and (c:=re.match(r"'(?:[^'\\\r\n]|\\(?:x[0-9a-fA-F]{2}|u[0-9a-fA-F]{4}|.))'",text[i:])):
                blank(i,i+len(c[0]));i+=len(c[0])
            else:i+=1
    cm=list(text)
    for a,b in comments:
        for k in range(a,b):
            if cm[k] not in '\r\n':cm[k]=' '
    return ''.join(struct),''.join(cm),comments

def code(text):
    _,_,spans=lex(text);out=[];at=0
    for a,b in spans:out.append(text[at:a]);at=b
    out.append(text[at:]);return ''.join(out)

def source_name(text):
    """A source identifier only; quotes preserve component boundaries. No numeric guessing."""
    parts=[];i=0
    while i<len(text):
        if text[i]=='«':
            j=text.find('»',i+1)
            if j<0:return None,None
            parts.append(text[i+1:j]);i=j+1
        else:
            m=re.match(r"[^\s.(){}\[\]:,;=]+",text[i:])
            if not m:break
            parts.append(m[0]);i+=len(m[0])
        if i<len(text) and text[i]=='.':i+=1;continue
        break
    if not parts:return None,None
    return text[:i],parts

def body_split(masked):
    depth=0;i=0
    while i<len(masked):
        c=masked[i]
        if c in '([{':depth+=1
        elif c in ')]}':depth=max(0,depth-1)
        elif depth==0:
            if masked.startswith(':=',i):return i,'assignment'
            if re.match(r'where\b',masked[i:]) and (i==0 or not(masked[i-1].isalnum() or masked[i-1]=='_')):return i,'where'
            if c=='|' and (i==0 or masked[i-1]=='\n' or masked[i-1].isspace()):return i,'equations'
        i+=1
    return len(masked),'bodyless_or_unparsed'

def parse(text):
    structural,cm,comments=lex(text);lines=text.splitlines(keepends=True);ml=structural.splitlines(keepends=True);cl=cm.splitlines(keepends=True)
    offsets=[];at=0
    for line in lines:offsets.append(at);at+=len(line)
    events=[];indented=[]
    for i,(line,masked) in enumerate(zip(lines,ml)):
        st=masked.rstrip('\r\n')
        if not st.strip():continue
        if st[0].isspace():
            if DECL.match(st.lstrip()):indented.append(i+1)
            continue
        d=DECL.match(st)
        if st.startswith('@['):kind='attribute-prefix'
        elif d:kind=d['kind']
        elif COMMAND.match(st):kind='source-command'
        else:continue
        events.append({'line':i+1,'kind':kind,'decl_match_end':d.end() if d else None})
    # Attribute groups belong to the following declaration; never truncate its body at a docstring.
    pending=[];folded=[]
    for ev in events:
        if ev['kind']=='attribute-prefix':pending.append(ev);continue
        ev['envelope_line']=pending[0]['line'] if pending and ev['kind'] in DECLS else ev['line']
        if pending and ev['kind'] not in DECLS:folded.extend(pending)
        ev['attribute_lines']=[p['line'] for p in pending] if ev['kind'] in DECLS else [];pending=[];folded.append(ev)
    folded.extend(pending);events=folded
    frames=[];ns=[];bindings=[];units=[]
    for k,ev in enumerate(events):
        line=ev['line'];start=ev.get('envelope_line',line);end=(events[k+1].get('envelope_line',events[k+1]['line'])-1) if k+1<len(events) else len(lines)
        while end>=line and not cl[end-1].strip():end-=1
        end=max(end,line);begin=offsets[start-1];finish=offsets[end] if end<len(offsets) else len(text)
        raw=text[begin:finish];declat=offsets[line-1];declraw=text[declat:finish];declmasked=structural[declat:finish]
        kind=ev['kind'];original=cl[line-1].strip();name=None;parts=None
        if kind in DECLS and kind!='example':
            suffix=lines[line-1][ev['decl_match_end']:].lstrip();name,parts=source_name(suffix)
            if kind=='instance' and suffix.startswith((':','(','{','[')):name=parts=None
        qparts=(parts[1:] if parts and parts[0]=='_root_' else ns+(parts or [])) if parts else None
        pos,form=body_split(declmasked) if kind in DECLS else (len(declmasked),'command')
        header=declraw[:pos];body=declraw[pos:]
        uid=f'{start}:{end}:{sha(raw)}'
        # Complete prefix binds every preceding definition/attribute/instance and lexical scope.
        prefix=text[:begin]
        unit={'id':uid,'kind':kind,'source_name':name,'canonical_parts':qparts,'canonical':'.'.join(qparts) if qparts else None,
            'start_line':start,'declaration_line':line,'end_line':end,'char_start':begin,'char_end':finish,
            'raw_sha256':sha(raw),'code_sha256':sha(code(raw)),'declaration_raw_sha256':sha(declraw),
            'header_raw_sha256':sha(header),'header_code_sha256':sha(code(header)),
            'body_raw_sha256':sha(body),'body_code_sha256':sha(code(body)),'body_form':form,
            'namespace_parts':ns[:],'scope_stack':[{'kind':f['kind'],'name':f['name']} for f in frames],
            'binding_trace_sha256':sha(canonical(bindings)),'binding_trace':bindings[:],
            'complete_prefix_raw_sha256':sha(prefix),'complete_prefix_code_sha256':sha(code(prefix)),
            'prefix_char_end':begin,'attribute_lines':ev.get('attribute_lines',[]),
            'name_basis':'SOURCE_SPELLING_NOT_ACTUAL_LEAN_NAME','lexical_boundaries_need_review':False}
        units.append(unit)
        if kind=='source-command':
            if original.startswith('namespace '):
                sn,sp=source_name(original[len('namespace '):]);frames.append({'kind':'namespace','name':sn,'oldns':ns[:],'oldbindings':bindings[:]});ns=(sp[1:] if sp and sp[0]=='_root_' else ns+(sp or []));bindings.append({'kind':'namespace','source':code(raw)})
            elif re.match(r'^(?:noncomputable\s+)?section\b',original):
                frames.append({'kind':'section','name':original,'oldns':ns[:],'oldbindings':bindings[:]});bindings.append({'kind':'section','source':code(raw)})
            elif original=='mutual':
                frames.append({'kind':'mutual','name':'mutual','oldns':ns[:],'oldbindings':bindings[:]});bindings.append({'kind':'mutual','source':code(raw)})
            elif re.match(r'^end\b',original):
                if frames:
                    f=frames.pop();ns=f['oldns'];bindings=f['oldbindings']
                else:unit['lexical_boundaries_need_review']=True
            else:bindings.append({'kind':'source-command','source':code(raw)})
    return {'units':units,'indented_declaration_lines':indented,'unclosed_scope_count':len(frames),
        'code_sha256':sha(code(text)),'raw_sha256':sha(text),'line_count':len(lines),
        'limit':'Lexical source envelopes. Full source/prefix/closure witnesses remain authoritative; no elaboration, command-effect or semantic dependency resolution.'}

def imports(text):
    st,_,_=lex(text);names=[];closed=False
    for line in st.splitlines():
        s=line.strip()
        if not s:continue
        mt=re.fullmatch(r'(?:public\s+)?import\s+(.+)',s)
        if mt:
            if closed:raise ValueError('late import')
            names.extend(mt[1].split())
        elif s=='prelude' or s=='module':continue
        else:closed=True
    return names

def select_unit(index,line):
    return [u for u in index['units'] if u['start_line']<=line<=u['end_line']]

def match_unit(index,unit):
    if unit['canonical_parts'] is None:return []
    return [u for u in index['units'] if u['kind']==unit['kind'] and u['canonical_parts']==unit['canonical_parts']]

def actual_key(identity):
    parts=identity['components']
    for tag,value in parts:
        if tag not in ('str','num') or not isinstance(value,str):raise ValueError('bad actual Name component')
        if tag=='num' and not re.fullmatch(r'0|[1-9][0-9]*',value):raise ValueError('bad numeric Name component')
    return canonical(parts)

def user_parts(parts):
    """Separate source-correspondence view, following Lean.PrivateName; never identity normalization."""
    if parts and parts[0]==['str','_private']:
        for i,(tag,value) in enumerate(parts[1:],1):
            if tag=='num':
                if value=='0' and all(t=='str' for t,v in parts[:i]):return parts[i+1:]
                break
    return parts
