"""Select one validated result per owner while retaining both native epochs."""

import argparse
from pathlib import Path
import json
import runpy

HERE = Path(__file__).resolve().parent
AREA = HERE.parent
RETRY_TOOL = HERE / "run_bounded_payload_retries.py"
RETRY_TOOL_SHA = "3e349ebc1b0b212fb56bcc2acd44912532d7bba3f3ee92633f59e5bb0944d727"
R5 = AREA / "guarded-native-r5/payload-retry-r3"
R5_SHA = "09e5c12d8d335526ccd39697854900f191459a4466fdce53a9400994e058a27e"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--retry-result-sha256", required=True)
    parser.add_argument("--retry-guard-sha256", required=True)
    args = parser.parse_args()
    import hashlib
    if hashlib.sha256(RETRY_TOOL.read_bytes()).hexdigest() != RETRY_TOOL_SHA:
        raise RuntimeError("reviewed retry tool changed")
    api = runpy.run_path(str(RETRY_TOOL))
    need, read, sha, canonical_sha = (api[name] for name in ("need", "read", "sha", "canonical_sha"))
    root, evidence, original, retry_dir = (api[name] for name in ("ROOT", "EVIDENCE", "ORIGINAL", "OUT"))
    retry_raw = read(retry_dir / "RESULT.json", args.retry_result_sha256)
    retry = json.loads(retry_raw)
    g5 = json.loads(read(R5 / "RESULT.json", args.retry_guard_sha256))
    start = json.loads(read(R5 / "start.json"))
    terminal = json.loads(read(R5 / "child-terminal.json"))
    g4 = json.loads(read(api["R4"] / "RESULT.json", retry["original_guard_sha256"]))
    summary_raw = read(original / "summary.json", retry["original_summary_sha256"])
    summary = json.loads(summary_raw)
    adapter = json.loads(read(evidence / "final-adapter.json", retry["adapter_sha256"]))
    probes = json.loads(read(evidence / "seal-manifest.json", adapter["seal_manifest_sha256"]))["probes"]
    need(retry["status"] == "BOUNDED_PAYLOAD_RETRY_COMPLETE" and retry["all_retry_harnesses_valid"] and
         retry["runner_sha256"] == RETRY_TOOL_SHA and retry["bounder_sha256"] == api["BOUNDER_SHA"],
         "bounded retries are incomplete or unverified")
    need(g4["environment_reconciled"] and g4["interrupted"] is None and g4["command_rc"] == 1 and
         g4["guard_sha256"] == api["R4_SHA"] and g4["tool_sha256"] == api["DRIVER_SHA"],
         "original survey provenance differs")
    expected_rc = int(retry["source_error_diagnostics"] != 0)
    need(g5["guard_sha256"] == R5_SHA and g5["tool_sha256"] == RETRY_TOOL_SHA and g5["environment_reconciled"] and
         g5["interrupted"] is None and g5["command_rc"] == terminal["command_rc"] == expected_rc and
         terminal["interrupted"] is None and g5["tree"] == g4["tree"] and
         g5["reviewed_local_result_sha256"] == g4["reviewed_local_result_sha256"] and
         sha(read(R5 / "launcher.log")) == terminal["launcher_log_sha256"], "retry environment receipt differs")
    need(start["command"][1:] == ["-I", str(RETRY_TOOL), "--adapter-sha256", retry["adapter_sha256"],
         "--survey-sha256", retry["original_summary_sha256"], "--survey-guard-sha256", retry["original_guard_sha256"]],
         "guard ran a different retry command")
    need(summary["head"] == retry["head"] == g4["head"] == g5["head"] == adapter["head"] and summary["complete"] and
         summary["aborted_reason"] is None and len(probes) == len(summary["results"]) ==
         summary["completed_probes"] == summary["expected_probes"] == 59, "original survey scope differs")
    retries = {a["probe"]["label"]: a for a in retry["attempts"]}
    need(len(retries) == len(retry["attempts"]) == summary["harness_failures"] == 2, "retry selection differs")
    selected = []
    failures = diagnostics = retry_diagnostics = 0
    for probe, prior in zip(probes, summary["results"], strict=True):
        label, module = probe["label"], probe["module"]
        need(prior["label"] == label and prior["module"] == module and
             json.loads(read(original / (label + ".classification.json"))) == prior, "original classification differs")
        if prior["valid_harness"]:
            need(label not in retries, "a valid original result was replaced")
            record, parent, origin = prior, original, "original"
        else:
            item = retries[label]
            replacement, record = item["probe"], item["record"]
            need(item["original_record_sha256"] == canonical_sha(prior) and record["valid_harness"] and
                 replacement["module"] == module and replacement["label"] == label and
                 replacement["source_sha256"] == probe["source_sha256"] and
                 replacement["requested_names"] == probe["requested_names"] and
                 replacement["source_to_probe_lines"] == probe["source_to_probe_lines"],
                 "bounded retry changed source, requested names or source lines")
            probe, parent, origin = replacement, retry_dir, "bounded_payload_retry"
            retry_diagnostics += len(record["errors"])
        need(record["module"] == module and record["label"] == label and record["valid_harness"] and
             json.loads(read(parent / (label + ".classification.json"))) == record, "selected classification differs")
        attempt = parent / "probes" / label
        log_path, receipt = attempt / (label + ".log"), attempt / (label + ".json")
        need(Path(record["log"]) == log_path and Path(record["result_path"]) == receipt, "selected raw paths differ")
        log = read(log_path, record["log_sha256"]).decode()
        raw = read(attempt / (label + ".source.txt"), probe["probe_sha256"])
        result = json.loads(read(receipt, record["result_json_sha256"]))
        need(result == record["result"] and result["module"] == probe["probe_module"] and
             result["source_unchanged"] and result["source_sha256"] == record["captured_probe_sha256"] == probe["probe_sha256"] and
             log.rstrip().endswith(f"END {result['end']} RC {result['rc']}") and
             result["error_diagnostics"] == len(record["errors"]) and
             (result["rc"] == 1) == record["source_failure"] == bool(record["errors"]),
             "selected native receipt differs")
        recovered = raw
        for insertion in reversed(probe["insertions"]):
            at, size = insertion["probe_byte_offset"], insertion["byte_count"]
            need(sha(recovered[at:at + size]) == insertion["sha256"], "selected insertion bytes differ")
            recovered = recovered[:at] + recovered[at + size:]
        need(recovered == read(root / probe["source"], probe["source_sha256"]), "selected source restoration differs")
        if result["rc"] == 0:
            need(result["fresh_nonempty_object"] and
                 sha(read(Path(g5["tree"]) / (result["module"] + ".olean"))) == result["object_sha256"],
                 "selected successful object differs")
        failures += int(record["source_failure"])
        diagnostics += len(record["errors"])
        selected.append({"module": module, "label": label, "origin": origin,
                         "record_sha256": canonical_sha(record), "probe_sha256": probe["probe_sha256"]})
    need(retry_diagnostics == retry["source_error_diagnostics"] and
         diagnostics == summary["source_error_diagnostics"] + retry_diagnostics,
         "selected diagnostics do not preserve all measured source failures")
    value = {
        "status": "ALL_EFFECTIVE_HARNESSES_VALID", "head": retry["head"], "actual_base": retry["actual_base"],
        "adapter_sha256": retry["adapter_sha256"], "original_summary_sha256": sha(summary_raw),
        "original_guard_sha256": retry["original_guard_sha256"], "retry_result_sha256": sha(retry_raw),
        "retry_guard_sha256": args.retry_guard_sha256, "completed_probes": len(selected),
        "source_error_diagnostics": diagnostics, "source_failure_modules": failures,
        "source_pass_modules": len(selected) - failures, "selected": selected,
        "limit": "Derived attempt selection. The original two parser failures and all current source failures retain their original outcomes.",
    }
    out = HERE / "effective-results.json"
    with out.open("x") as f:
        f.write(json.dumps(value, indent=2) + "\n")
    print(json.dumps({k: v for k, v in value.items() if k not in ("selected", "limit")}, indent=2))


if __name__ == "__main__":
    main()
