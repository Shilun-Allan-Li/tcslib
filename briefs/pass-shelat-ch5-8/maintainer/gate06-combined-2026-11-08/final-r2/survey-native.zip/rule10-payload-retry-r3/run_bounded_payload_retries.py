"""Retry only the two native parser failures with bounded harness literals."""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
AREA = HERE.parent
ROOT = AREA.parents[2]
EVIDENCE = AREA / "rule10-evidence-r2"
ORIGINAL = EVIDENCE / "native-seal-runs"
OUT = EVIDENCE / "native-payload-retry-r3"
SCRATCH = AREA / "rule10-r2/payload-retry-r3"
R4 = AREA / "guarded-native-r4/final-seals-r2"
DRIVER = AREA / "rule10-final-tools-r2/run_gate06_final_native.py"
DRIVER_SHA = "552a6b0ed67fd5458c6eec47ae1ba1e31f5495662f1021da07119353d57aaa27"
BOUNDER_SHA = "4005843390dcc54d32befe9fbfe767a0129bf0fa7053af0182508525bf0e15c0"
DIAGNOSIS_SHA = "18f8b452ecef0eef17610555c71206738c91ddb8bb92426c32cb79c20b2a282e"
R4_SHA = "dadcc7e4af099a246edf020776efda95f2784018337e3615fd89af787e75f495"


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical_sha(value):
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode())


def read(path, expected=None):
    need(path.is_file() and not path.is_symlink(), f"missing or nonordinary input {path}")
    raw = path.read_bytes()
    need(expected is None or sha(raw) == expected, f"changed input {path}")
    return raw


def load(path, expected, name):
    read(path, expected)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--adapter-sha256", required=True)
    parser.add_argument("--survey-sha256", required=True)
    parser.add_argument("--survey-guard-sha256", required=True)
    args = parser.parse_args()
    need(Path.cwd().resolve() == ROOT and not OUT.exists() and not SCRATCH.exists(), "fresh retry roots required")
    driver = load(DRIVER, DRIVER_SHA, "reviewed_g06_driver")
    bounder = load(HERE / "bound_payload.py", BOUNDER_SHA, "reviewed_payload_bounder")
    ctx = driver.load_context(args.adapter_sha256)
    ctx.inputs[str(HERE / "bound_payload.py")] = BOUNDER_SHA
    ctx.inputs[str(Path(__file__).resolve())] = sha(Path(__file__).read_bytes())

    summary_path = ORIGINAL / "summary.json"
    summary = json.loads(read(summary_path, args.survey_sha256))
    cfg_path = ORIGINAL / "configuration.json"
    cfg = json.loads(read(cfg_path, summary["configuration_sha256"]))
    guard_path = R4 / "RESULT.json"
    guard = json.loads(read(guard_path, args.survey_guard_sha256))
    need(guard["guard_sha256"] == R4_SHA and guard["tool_sha256"] == DRIVER_SHA and
         guard["environment_reconciled"] and guard["interrupted"] is None and guard["command_rc"] == 1 and
         guard["tree"] == str(driver.OLEANS), "original native survey environment is unverified")
    need(cfg["driver_sha256"] == DRIVER_SHA and cfg["adapter_sha256"] == args.adapter_sha256 and
         summary["head"] == cfg["head"] == guard["head"] == ctx.pins["head"] and
         summary["complete"] and summary["aborted_reason"] is None and
         summary["expected_probes"] == summary["completed_probes"] == len(summary["results"]) == 59,
         "original survey must be complete with the exact reviewed source")
    for path in (summary_path, cfg_path, guard_path):
        driver.capture(ctx, path)
    diagnosis = AREA / "rule10-parser-stack-diagnosis-r3.json"
    diagnosed = {x["label"]: x for x in json.loads(read(diagnosis, DIAGNOSIS_SHA))["attempts"]}
    driver.capture(ctx, diagnosis)
    original = {r["label"]: r for r in summary["results"]}
    need(list(original) == [p["label"] for p in ctx.head["probes"]], "original owner order differs")
    failed = {r["label"] for r in summary["results"] if not r.get("valid_harness")}
    need(failed == set(diagnosed) and len(failed) == summary["harness_failures"] == 2,
         "original setup failures differ from the diagnosed parser pair")

    old_seal = ctx.bs.seal_command

    def seal_command(label, rows, *, end):
        return bounder.bound_payloads(old_seal(label, rows, end=end))

    ctx.bs.seal_command = seal_command
    OUT.mkdir()
    SCRATCH.mkdir()
    attempts = []
    for p in ctx.head["probes"]:
        label = p["label"]
        if label not in failed:
            continue
        previous = original[label]
        known = diagnosed[label]
        log = read(Path(previous["log"]), known["raw_log_sha256"])
        need(previous["classification"] == "HARNESS_OR_SETUP_FAILURE" and previous["errors"] == [] and
             previous["result"]["rc"] == 1 and not previous["result"]["fresh_nonempty_object"] and
             previous["result"]["error_diagnostics"] == 0 and b"Stack overflow detected. Aborting." in log and
             b"G06-SEAL " not in log and b"G06-MASK " not in log and
             p["probe_sha256"] == known["probe_sha256"] == previous["captured_probe_sha256"],
             "selected attempt is not the observed parser failure")
        driver.capture(ctx, Path(previous["log"]))
        driver.capture(ctx, Path(previous["result_path"]))
        raw = ctx.library[p["source"]]
        generated, insertions, mapping = ctx.bs.instrument(raw, ctx.bs.header(raw), label, p["requested_names"])
        need(mapping == p["source_to_probe_lines"] and sha(generated) != p["probe_sha256"],
             "bounded retry must change only generated payloads and preserve source lines")
        new_path = SCRATCH / (label + ".lean")
        saved = OUT / (label + ".source.txt")
        probe = {**p, "probe_path": str(new_path), "saved_source": str(saved),
                 "probe_module": new_path.relative_to(ROOT).with_suffix("").as_posix(),
                 "probe_sha256": sha(generated), "insertions": insertions}
        need(not (driver.OLEANS / (probe["probe_module"] + ".olean")).exists(), "retry module object already exists")
        ctx.v.write_new(new_path, generated)
        ctx.v.write_new(saved, generated)
        ctx.v.verify_whole(ctx, probe, raw)
        ctx.v.write_new(OUT / (label + ".preparation.json"), ctx.v.json_bytes(probe))
        record, text = driver.invoke(ctx, probe, OUT)
        record.update(module=p["module"], kind="seals")
        if text is not None:
            try:
                driver.classify_seal(ctx, probe, record, text)
            except (driver.FinalDriverError, ctx.v.DriverError, KeyError, TypeError, ValueError) as exc:
                record.update(valid_harness=False, classification="HARNESS_OR_SETUP_FAILURE", harness_reason=str(exc))
        ctx.v.write_new(OUT / (label + ".classification.json"), ctx.v.json_bytes(record))
        attempts.append({"probe": probe, "record": record, "original_record_sha256": canonical_sha(previous)})
        print(f"BOUNDED PAYLOAD RETRY {label} {record['classification']}", flush=True)

    driver.assert_frozen(ctx)
    valid = len(attempts) == len(failed) and all(a["record"].get("valid_harness") for a in attempts)
    result = {"status": "BOUNDED_PAYLOAD_RETRY_COMPLETE", "head": ctx.pins["head"],
              "actual_base": ctx.pins["actual_campaign_base"], "adapter_sha256": args.adapter_sha256,
              "original_summary_sha256": args.survey_sha256, "original_guard_sha256": args.survey_guard_sha256,
              "runner_sha256": sha(Path(__file__).read_bytes()), "bounder_sha256": BOUNDER_SHA,
              "all_retry_harnesses_valid": valid, "attempts": attempts,
              "source_error_diagnostics": sum(len(a["record"].get("errors", [])) for a in attempts
                                              if a["record"].get("valid_harness"))}
    ctx.v.write_new(OUT / "RESULT.json", ctx.v.json_bytes(result))
    return 0 if valid and result["source_error_diagnostics"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
