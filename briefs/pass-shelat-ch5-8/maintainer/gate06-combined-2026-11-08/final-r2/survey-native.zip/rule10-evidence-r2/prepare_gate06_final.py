"""Prepare the R2 seal and control probes from the reviewed completed census."""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

EPOCH = Path(__file__).with_name("epoch_r2.py")
EPOCH_SHA = "cc05ae6a7162fceb71176ff9cd5ed4ff90d44d25355cf55dc415523fbc6f3d74"


def load_epoch():
    if not EPOCH.is_file() or EPOCH.is_symlink() or hashlib.sha256(EPOCH.read_bytes()).hexdigest() != EPOCH_SHA:
        raise RuntimeError("reviewed R2 epoch helper differs")
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("g06_r2_epoch", EPOCH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load reviewed R2 epoch helper")
    epoch = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(epoch)
    return epoch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bindings-sha256", required=True)
    parser.add_argument("--control-module")
    args = parser.parse_args()
    epoch = load_epoch()
    prep, data, library, snapshot = epoch.stage(args.bindings_sha256)
    root, evidence = epoch.ROOT, epoch.EVIDENCE
    pins, modules, closures = (data[name] for name in ("pins.json", "modules.json", "closures.json"))
    build_sha = {name: prep["tool_input_sha256"][name] for name in epoch.BUILDER_NAMES}
    tools = {
        name: epoch.load_pinned(evidence / "tool-inputs" / name, digest, "g06_r2_" + name[:-3])
        for name, digest in build_sha.items()
    }
    builder, controls, payload = (tools[name] for name in epoch.BUILDER_NAMES)
    epoch.need(callable(getattr(payload, "verify_mask_log", None)), "reviewed payload lacks mask receipt validator")
    builder.EXPECTED_MODULES, builder.SCRATCH_REL = len(modules), epoch.SCRATCH_REL
    epoch.bind_collector(builder)
    capture = lambda name: epoch.read(evidence / name)
    reviewed, result = epoch.verify_staged(prep, capture)
    captured = {}
    log, completion, _ = builder.completed_collector(root, evidence, captured, modules, closures)
    epoch.need(completion == result, "builder saw a different completed collector")
    payload.configure_builders(builder, controls)
    _, conservative, _ = builder.collector_rows(log, modules, closures)
    candidates = [
        module for module in sorted(modules)
        if set(controls.READERS.values()) <= set(closures[module]) and all(
            name in conservative[module] and conservative[module][name]["home"] == home and
            conservative[module][name]["matcher"] is matcher and
            conservative[module][name]["collector_reducibility"] != "irreducible"
            for name, (home, matcher) in controls.REQUIRED.items()
        )
    ]
    epoch.need(candidates, "no audited closure supports the complete controls")
    chosen = args.control_module or (controls.DEFAULT_MODULE if controls.DEFAULT_MODULE in candidates else candidates[0])
    epoch.need(chosen in candidates, "control module lacks required targets/readers")
    controls.load_builder = lambda _path: builder
    previous_argv = sys.argv[:]
    try:
        sys.argv = [str(builder.__file__), str(evidence), "--root", str(root)]
        builder.main()
        sys.argv = [str(controls.__file__), str(evidence), "--root", str(root), "--module", chosen]
        controls.main()
    finally:
        sys.argv = previous_argv
    seal_raw = capture("seal-manifest.json")
    control_raw = capture("controls-manifest.json")
    seals, control_manifest = epoch.decode(seal_raw), epoch.decode(control_raw)
    epoch.need(len(seals["probes"]) == len(modules) and {p["module"] for p in seals["probes"]} == set(modules),
               "incomplete R2 seal set")
    epoch.need(len(control_manifest["probes"]) == control_manifest["expected_totals"]["probes"] == 13 and
               control_manifest["seal_manifest_sha256"] == epoch.sha(seal_raw), "incomplete/unbound R2 controls")
    epoch.need(builder.library_snapshot(root, pins) == (library, snapshot), "library changed during preparation")
    epoch.need(epoch.verify_staged(prep, capture) == (reviewed, result), "reviewed staged inputs changed")
    for name, digest in prep["input_sha256"].items():
        epoch.need(epoch.sha(capture(name)) == digest, "source preparation input changed: " + name)
    for name, digest in prep["tool_input_sha256"].items():
        epoch.read(evidence / "tool-inputs" / prep["tool_saved_names"][name], digest)
    self_raw = Path(__file__).read_bytes()
    adapter = {
        "status": "PREPARED_NOT_RUN", "root": str(root), "evidence_directory": str(evidence),
        "base": pins["base"], "head": pins["head"], "expected_math_modules": len(modules),
        "modules": sorted(modules), "scratch_relative": epoch.SCRATCH_REL.as_posix(),
        "controls_module": chosen, "source_sha256": epoch.sha(self_raw),
        "preparer_source_sha256": EPOCH_SHA, "final_preparation_sha256": epoch.sha(capture("final-preparation.json")),
        "seal_manifest_sha256": epoch.sha(seal_raw), "controls_manifest_sha256": epoch.sha(control_raw),
        "collector_result_sha256": epoch.sha(capture("collect1.json")),
        "collector_module": epoch.COLLECTOR_MODULE, "collector_provenance": prep["collector_provenance"],
        "epoch_bindings_sha256": prep["epoch_bindings_sha256"], "tool_input_sha256": build_sha,
        "request_encoding": "constant-AST newline/tab String parsed at runtime",
        "proof_budgets_changed": False, "coverage_exclusions_added": False,
        "mask_receipt_validator": "verify_mask_log", "library_verification": snapshot,
        "runtime_verified": False,
    }
    epoch.write_new(evidence / "prepare_gate06_final.py", self_raw)
    epoch.write_new(evidence / "final-adapter.json", epoch.encoded(adapter))
    print(json.dumps({"status": adapter["status"], "modules": len(modules), "controls": 13,
                      "adapter": str(evidence / "final-adapter.json")}), flush=True)


if __name__ == "__main__":
    main()
