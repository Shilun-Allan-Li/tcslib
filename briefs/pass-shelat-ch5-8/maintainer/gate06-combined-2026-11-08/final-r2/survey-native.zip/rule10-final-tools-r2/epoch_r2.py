"""Bind the completed R2 census and reviewed mask inputs to fresh probe paths."""

from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT = Path("/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4")
AREA = ROOT / ".lake/ps-maintainer/gate06-combined-20261108"
TOOLS = AREA / "rule10-final-tools-r2"
EVIDENCE = AREA / "rule10-evidence-r2"
SCRATCH = AREA / "rule10-r2"
SCRATCH_REL = SCRATCH.relative_to(ROOT)
TREE = AREA / "oleans-r1"
R1_TOOLS = AREA / "rule10-prep/proposed-tools"
R1_EVIDENCE = AREA / "rule10-evidence-r1"
CENSUS = AREA / "collector-native-r2"
GUARD = AREA / "guarded-native-r3/collector-r2"
COLLECTOR_MODULE = ".lake/ps-maintainer/gate06-combined-20261108/rule10-r1/Collect"
HEAD = "a495f3953afff46ad5dec2d29ac8a7f55bd8ae37"
R1_PREPARATION_SHA = "e5d2c01460a9494e28749161ceace9b43a272c7bb5423a51b7e49625a3a7e00c"
SCOPE_HELPER_SHA = "c1eff53829a53005214583da1e1f328ba9ee32c9aa06c0e329d1333132fb402d"
LOCAL_RESULT_SHA = "6a019e8051ef7deceae8fec3fd9ac53698e43985c7fe9f86d4e7b1d0ab12e656"
GUARD_SHA = "6775ba1b6f7480d94930c18e036b23611dc84e5e7fbf9f55092b4f2560d5fabb"
CHECKER_SHA = "c685d6aa01b1b7e44115e88781d1634b3b3cdda512acc702eeba5e810f767179"
PAYLOAD = "request_payload_adapter.py"
PAYLOAD_SHA = "9a8fee882126a1702fd2af07c5184d303f83c9d119cd36a31badedc6cf462e94"
BUILDER_NAMES = ("build_seals.py", "build_controls.py", PAYLOAD)
SOURCE_INPUTS = {
    "pins.json", "modules.json", "closures.json", "source-fingerprints.json",
    "touched.json", "Collect.source.txt",
}
MASK_INPUTS = {
    "mask_pilot": (AREA / "mask-pilot-validation-r3.json",
                   "da7101b9cab766948a1c7fc5d3f9aaa344e0f7df0bfa02c383bda9c4817d5e0e",
                   "mask-pilot.source.txt"),
    "scope_review": (AREA / "mask-scope-review-r2.json",
                     "745039ba2cb7cce8fc97d14f72c73990f48d38a64b67fdf124137e07aa1eb197",
                     "mask-scope.source.txt"),
}
CENSUS_FILES = {
    "collect1.json": CENSUS / "collect1.json",
    "collect1.log": CENSUS / "collect1.log",
    "collect1.source.txt": CENSUS / "collect1.source.txt",
    "collect1.pid": CENSUS / "collect1.pid",
    "collector-checker.source.txt": CENSUS / "check_probe_v2.py",
    **{
        "collector-guard-r2/" + name: GUARD / name
        for name in (
            "start.json", "RESULT.json", "child.json", "child-terminal.json", "launcher.log",
            "validation-initial.json", "validation-after-idle-prelaunch.json",
            "validation-after-child.json",
        )
    },
}


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def decode(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result

    value = json.loads(raw, object_pairs_hook=unique)
    need(isinstance(value, dict), "expected JSON object")
    return value


def read(path, digest=None):
    need(path.is_file() and not path.is_symlink(), "missing/nonordinary input: " + str(path))
    raw = path.read_bytes()
    need(digest is None or sha(raw) == digest, "input hash differs: " + str(path))
    return raw


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(raw)


def load_pinned(path, digest, name):
    read(path, digest)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, "cannot load reviewed tool: " + str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bind_collector(builder):
    """Use the actual census module while the unchanged builder reads its receipt."""
    original = builder.completed_collector
    collector_scratch = Path(COLLECTOR_MODULE).parent

    def completed_collector(root, evidence, captured, modules, closures):
        probe_scratch = builder.SCRATCH_REL
        builder.SCRATCH_REL = collector_scratch
        try:
            return original(root, evidence, captured, modules, closures)
        finally:
            builder.SCRATCH_REL = probe_scratch

    builder.completed_collector = completed_collector


def bindings(raw):
    value = decode(raw)
    digest_fields = ("collector_result_sha256", "collector_guard_result_sha256", "payload_sha256")
    need(set(value) == {"status", *digest_fields, *MASK_INPUTS}, "unexpected epoch bindings schema")
    need(value["status"] == "REVIEWED_MASK_AND_COLLECTOR_INPUTS", "mask/census review is required")
    for name in digest_fields:
        need(re.fullmatch("[0-9a-f]{64}", value[name]) is not None, "bad binding digest: " + name)
    need(value["payload_sha256"] == PAYLOAD_SHA, "payload differs from reviewed mask adapter")
    for role, (path, digest, _) in MASK_INPUTS.items():
        need(value[role] == {"path": str(path), "sha256": digest}, "reviewed mask input differs: " + role)
    return value


def verify_census(captured, reviewed, expected_source):
    result = decode(captured["collect1.json"])
    guard = decode(captured["collector-guard-r2/RESULT.json"])
    start = decode(captured["collector-guard-r2/start.json"])
    terminal = decode(captured["collector-guard-r2/child-terminal.json"])
    need(sha(captured["collect1.json"]) == reviewed["collector_result_sha256"] and
         sha(captured["collector-guard-r2/RESULT.json"]) == reviewed["collector_guard_result_sha256"],
         "collector/guard differs from reviewed R2 receipt")
    need(result["label"] == "collect1" and result["module"] == COLLECTOR_MODULE and
         result["rc"] == 0 and result["end"] and result["source_unchanged"] is True and
         result["fresh_nonempty_object"] is True and result["error_diagnostics"] == 0,
         "R2 collector lacks a successful completed receipt")
    need(captured["collect1.source.txt"] == expected_source == read(ROOT / (COLLECTOR_MODULE + ".lean")) and
         sha(expected_source) == result["source_sha256"], "actual collector source differs")
    need(sha(captured["collector-checker.source.txt"]) == CHECKER_SHA, "collector checker differs")
    command = start["command"]
    need(start["label"] == "collector-r2" and len(command) == 6 and command[1:] == [
        "-I", str(R1_TOOLS / "check_probe_v2.py"), str(CENSUS), COLLECTOR_MODULE, "collect1",
    ] and start["TCSLIB_OLEANS"] == str(TREE), "R2 guard started a different collector command")
    need(guard["head"] == HEAD and guard["tree"] == str(TREE) and guard["command_rc"] == 0 and
         guard["interrupted"] is None and guard["environment_reconciled"] is True and
         guard["other_processes_signalled"] is False and guard["whole_command_retry"] is False,
         "R2 guard lacks a successful reconciled completion")
    for record in (start, guard, *(decode(captured["collector-guard-r2/validation-" + phase + ".json"])
                                  for phase in ("initial", "after-idle-prelaunch", "after-child"))):
        need(record["reviewed_local_result_sha256"] == LOCAL_RESULT_SHA and
             record["guard_sha256"] == GUARD_SHA and record["tool_sha256"] == CHECKER_SHA,
             "R2 guard provenance differs")
    need(terminal["command_rc"] == 0 and terminal["interrupted"] is None and
         terminal["launcher_log_sha256"] == sha(captured["collector-guard-r2/launcher.log"]) and
         decode(captured["collector-guard-r2/launcher.log"]) == result,
         "R2 guard child termination/log differs")
    obj = TREE / (COLLECTOR_MODULE + ".olean")
    need(obj.is_file() and not obj.is_symlink() and obj.stat().st_size > 0 and
         obj.stat().st_mtime >= datetime.fromisoformat(result["start"]).timestamp(),
         "collector object is missing, empty or stale")
    with obj.open("rb") as handle:
        digest = hashlib.file_digest(handle, "sha256").hexdigest()
    need(digest == result["object_sha256"], "collector object differs from completed receipt")
    return result


def verify_staged(prep, capture):
    """Revalidate the staged receipt, object and reviewed mask evidence."""
    raw = capture("epoch-bindings.json")
    need(sha(raw) == prep["epoch_bindings_sha256"], "epoch bindings changed")
    reviewed = bindings(raw)
    old_raw = capture("R1-final-preparation.source.txt")
    need(sha(old_raw) == prep["R1_preparation_sha256"] == R1_PREPARATION_SHA, "R1 preparation binding changed")
    old = decode(old_raw)
    tool_hashes = {**old["tool_input_sha256"], PAYLOAD: reviewed["payload_sha256"]}
    need(prep["input_sha256"] == old["input_sha256"] and prep["tool_input_sha256"] == tool_hashes,
         "source inputs or reviewed tool pins differ from the R1 basis")
    provenance = prep["collector_provenance"]
    need(provenance["native_directory"] == str(CENSUS) and provenance["guard_directory"] == str(GUARD) and
         set(provenance["captured_sha256"]) == set(CENSUS_FILES), "wrong R2 collector provenance")
    captured = {name: capture(name) for name in CENSUS_FILES}
    need({name: sha(raw) for name, raw in captured.items()} == provenance["captured_sha256"],
         "staged collector evidence changed")
    for role, (_, digest, name) in MASK_INPUTS.items():
        need(sha(capture(name)) == digest, "reviewed mask evidence changed: " + role)
    result = verify_census(captured, reviewed, capture("Collect.source.txt"))
    need(result["object_sha256"] == provenance["object_sha256"] and
         prep["collector_module"] == COLLECTOR_MODULE and prep["collector_label"] == "collect1",
         "actual collector binding changed")
    return reviewed, result


def stage(reviewed_sha):
    need(re.fullmatch("[0-9a-f]{64}", reviewed_sha) is not None, "reviewed bindings SHA256 required")
    need(not EVIDENCE.exists() and not SCRATCH.exists(), "fresh R2 evidence and probe scratch required")
    binding_raw = read(TOOLS / "epoch-bindings.json", reviewed_sha)
    reviewed = bindings(binding_raw)
    old_raw = read(R1_EVIDENCE / "final-preparation.json", R1_PREPARATION_SHA)
    old = decode(old_raw)
    need(set(old["input_sha256"]) == SOURCE_INPUTS and old["collector_module"] == COLLECTOR_MODULE and
         old["head"] == HEAD and old["preparer_source_sha256"] == SCOPE_HELPER_SHA,
         "wrong R1 preparation basis")
    source = {name: read(R1_EVIDENCE / name, digest) for name, digest in old["input_sha256"].items()}
    captured = {name: read(path) for name, path in CENSUS_FILES.items()}
    result = verify_census(captured, reviewed, source["Collect.source.txt"])
    mask = {name: read(path, digest) for path, digest, name in MASK_INPUTS.values()}
    raw_tools = {
        name: read(R1_EVIDENCE / "tool-inputs" / old["tool_saved_names"][name], digest)
        for name, digest in old["tool_input_sha256"].items()
    }
    raw_tools[PAYLOAD] = read(TOOLS / PAYLOAD, reviewed["payload_sha256"])
    tool_hashes = {name: sha(raw) for name, raw in raw_tools.items()}
    scope_helper = R1_TOOLS / "prepare_gate06_final_collector.py"
    scope = load_pinned(scope_helper, SCOPE_HELPER_SHA, "g06_r2_scope_helper")
    builder = load_pinned(R1_TOOLS / "build_seals.py", tool_hashes["build_seals.py"], "g06_r2_scope_builder")
    data = {name: decode(raw) for name, raw in source.items() if name.endswith(".json")}
    pins, modules, closures = (data[name] for name in ("pins.json", "modules.json", "closures.json"))
    library, snapshot = builder.library_snapshot(ROOT, pins)
    derived, dependencies, fingerprints, excluded = scope.derive_scope(builder, library, pins["base"], pins["head"])
    need(derived == modules and dependencies == closures and fingerprints == data["source-fingerprints.json"] and
         excluded == pins["excluded_import_option_only_files"] and snapshot == old["library_verification"] and
         len(modules) == old["expected_math_modules"] == 59, "R1 input scope differs from current frozen source")
    builder.EXPECTED_MODULES = len(modules)
    builder.validate_metadata(ROOT, pins, modules, closures, fingerprints, data["touched.json"], library)
    need(scope.collector_source(raw_tools, modules, closures) == source["Collect.source.txt"],
         "R1 collector source differs from reviewed construction")
    need(all(read(path) == captured[name] for name, path in CENSUS_FILES.items()), "census changed during staging")
    need(read(TOOLS / "epoch-bindings.json", reviewed_sha) == binding_raw and
         read(TOOLS / PAYLOAD, reviewed["payload_sha256"]) == raw_tools[PAYLOAD],
         "reviewed mask bindings changed during staging")
    prep = {
        **old, "status": "COLLECTOR_COMPLETE_INPUTS_BOUND", "evidence_directory": str(EVIDENCE),
        "scratch_relative": SCRATCH_REL.as_posix(), "tool_input_sha256": tool_hashes,
        "preparer_source_sha256": sha(Path(__file__).read_bytes()),
        "source_scope_helper_sha256": SCOPE_HELPER_SHA, "R1_preparation_sha256": R1_PREPARATION_SHA,
        "epoch_bindings_sha256": reviewed_sha,
        "collector_provenance": {
            "native_directory": str(CENSUS), "guard_directory": str(GUARD),
            "object_sha256": result["object_sha256"],
            "captured_sha256": {name: sha(raw) for name, raw in captured.items()},
        },
        "limit": "Completed guarded census bound to fresh R2 proof preparation.",
    }
    EVIDENCE.mkdir(exist_ok=False)
    for name, raw in {**source, **captured, **mask, "epoch-bindings.json": binding_raw,
                      "epoch_r2.source.txt": Path(__file__).read_bytes(),
                      "R1-final-preparation.source.txt": old_raw,
                      "prepare_gate06_final_collector.py": read(scope_helper, SCOPE_HELPER_SHA)}.items():
        write_new(EVIDENCE / name, raw)
    for name, raw in raw_tools.items():
        write_new(EVIDENCE / "tool-inputs" / prep["tool_saved_names"][name], raw)
    write_new(EVIDENCE / "final-preparation.json", encoded(prep))
    return prep, data, library, snapshot
