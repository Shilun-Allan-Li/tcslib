# Gate06 R2 seal and control preparation

R2 uses evidence in rule10-evidence-r2 and probe sources in rule10-r2. The
completed census keeps its actual rule10-r1/Collect module and existing object
in oleans-r1. The path wrapper switches the unchanged builder to that collector
path only while it checks the receipt, then restores the R2 probe path.

The six source inputs come from the pinned R1 preparation. The preparer
rederives the current library scope and checks every copied digest. Both
builders, the probe checker, the legacy request encoder and the scope helper
retain their reviewed bytes. The staged evidence includes the R2 collector
and guard receipts, reviewed mask inputs and original preparation metadata.

## Bind the completed census

After reviewing the successful collector-native-r2/collect1.json and
guarded-native-r3/collector-r2/RESULT.json, write epoch-bindings.json here using
the following fields. Substitute the actual SHA256 values for the two
completion receipts.

    {
      "status": "REVIEWED_MASK_AND_COLLECTOR_INPUTS",
      "collector_result_sha256": "COLLECT1_RESULT_SHA256",
      "collector_guard_result_sha256": "COLLECTOR_R3_GUARD_RESULT_SHA256",
      "payload_sha256": "9a8fee882126a1702fd2af07c5184d303f83c9d119cd36a31badedc6cf462e94",
      "mask_pilot": {
        "path": "/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/gate06-combined-20261108/mask-pilot-validation-r3.json",
        "sha256": "da7101b9cab766948a1c7fc5d3f9aaa344e0f7df0bfa02c383bda9c4817d5e0e"
      },
      "scope_review": {
        "path": "/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/gate06-combined-20261108/mask-scope-review-r2.json",
        "sha256": "745039ba2cb7cce8fc97d14f72c73990f48d38a64b67fdf124137e07aa1eb197"
      }
    }

Pass the reviewed bindings hash to the preparer.

    python3 -I /Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/gate06-combined-20261108/rule10-final-tools-r2/prepare_gate06_final.py --bindings-sha256 REVIEWED_BINDINGS_SHA256

The driver takes the reviewed final-adapter.json hash through
--adapter-sha256. It retains the complete request sets and thirteen controls.
It checks mask receipts at install and EOF for sealed files and controls, and
expects no mask receipts in the unsealed controls. Receipt mismatches remain
harness failures.

Root owns the fresh guard allowlist entry for the driver at SHA256
552a6b0ed67fd5458c6eec47ae1ba1e31f5495662f1021da07119353d57aaa27. The guard used
for the completed census retains its own original provenance.

After a complete R2 survey, pass the same reviewed adapter hash to
attach_current_failures.py and select a fresh sibling directory named
rule10-failure-attachments-r2 or a versioned suffix. The attacher uses the
frozen failure preflight and this R2 driver hash. It retains ambiguous
source mappings and every classified source or harness failure.

Static checks covered the source and tool pins, the actual R2 guard launch
path, path restoration on success and error, and mask receipt dispatch with
stubbed validators. Preparation and the R2 native survey remain pending.
