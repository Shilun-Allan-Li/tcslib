import Lean
import TCSlib.InformationTheory.Entropy
import TCSlib.InformationTheory.LeftoverHash

open Lean Elab Command Meta
run_cmd do
  let env ← getEnv
  for (n, ci) in env.constants.toList do
    let some idx := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[idx.toNat]!
    unless (`TCSlib).isPrefixOf home && ci.isDefinition do continue
    let status ← liftCoreM <| Lean.getReducibilityStatus n
    if status != .reducible || Lean.Meta.isMatcherCore env n then
      Lean.logInfo m!"ACTUAL-BASE-DEF {n} | {home}"
