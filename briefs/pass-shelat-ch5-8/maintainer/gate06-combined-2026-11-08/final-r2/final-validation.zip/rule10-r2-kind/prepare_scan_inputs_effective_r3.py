#!/usr/bin/env python3
"""Prepare legacy C1/C2/C3 scanner inputs from R2 and verified payload retries."""

import argparse
from collections import Counter
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
EXTRACTOR_SHA = '7ea4dc7325557291ffc15797fdc79e27824265d90692693c4c8cfac67489e10c'
C3_SHA = 'cc5fe3368699617a5dac05d1f84462c4819f0d5e487792afca1a39886ed1eb2a'
DRIVER_SHA = '552a6b0ed67fd5458c6eec47ae1ba1e31f5495662f1021da07119353d57aaa27'
R4_SHA = 'dadcc7e4af099a246edf020776efda95f2784018337e3615fd89af787e75f495'
RETRY_RUNNER_SHA = '3e349ebc1b0b212fb56bcc2acd44912532d7bba3f3ee92633f59e5bb0944d727'
R5_SHA = '09e5c12d8d335526ccd39697854900f191459a4466fdce53a9400994e058a27e'
BOUNDER_SHA = '4005843390dcc54d32befe9fbfe767a0129bf0fa7053af0182508525bf0e15c0'
DIAGNOSIS_SHA = '18f8b452ecef0eef17610555c71206738c91ddb8bb92426c32cb79c20b2a282e'
STATIC_PINS = {
    'explicit-summary.json': 'f4c2f503eaf26b73cabdc9665bec240df5c4b060709ee8c42ff462bcef8fe4c7',
    'explicit-inventory.json': '624736478af86d266e92f06cd5d0d3833d8080f085c53d2c7b3181ce63bf68bf',
    'explicit-touched-dispositions.json': '8654090f050c78f0c641ba82ea9fc90f7a92d3840c46fd488b1ca92fbce111d3',
    'explicit-inherited-tcs-debt.json': '52b61fcfe51bbe05955dde5c0a42d36ab905de5f46217069e462c58c8d29f922',
    'explicit-primary-evidence.json': '96798a580b31058a71cfafe81c035ddb31732c20e34dc82a9baf1f1f8921cac2',
}


def load_extractor():
    path = HERE / 'extract_kind.py'
    # Only this reviewed, definitions-only local helper is imported.
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest() != EXTRACTOR_SHA:
        raise RuntimeError('reviewed kind extractor changed')
    spec = importlib.util.spec_from_file_location('gate06_own_kind_extractor', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def c3_files(k, args, modules, kinds, reconciliation):
    attempt, label, guard, native_sha, guard_sha = args
    log, receipt = k.native_success(Path(attempt).resolve(), label, Path(guard).resolve(), native_sha,
                                    guard_sha, k.AREA / 'rule10-r1/C3.lean', C3_SHA)
    c3 = reconciliation['c3']
    k.need(reconciliation['head'] == k.HEAD and reconciliation['verification_base'] == k.VERIFY_BASE and
           reconciliation['math_owners'] == len(modules) and c3['actual_roots'] == reconciliation['actual_roots'] > 0 and
           c3['exact_collector_root_components_match'] is True and
           c3['controls'] == ['generated', 'published_reader'], 'incomplete or unvalidated C3 reconciliation')
    lines = [k.INFO.sub('', line, count=1) for line in log.splitlines()]
    epoch = f'base={k.VERIFY_BASE} head={k.HEAD} modules={len(modules)}'
    begin = [line for line in lines if line.startswith('G06-C3-BEGIN ')]
    end = [line for line in lines if line.startswith('G06-C3-END ')]
    prefix = f"G06-C3-END {epoch} roots={c3['actual_roots']} pairs={len(c3['pairs'])}"
    k.need(begin == ['G06-C3-BEGIN ' + epoch] and len(end) == 1 and
           re.fullmatch(re.escape(prefix) + r' type_extractions=\d+ value_extractions=\d+', end[0]),
           'native C3 epoch/count markers differ')
    raw_pairs = [(i, line) for i, line in enumerate(lines, 1) if line.startswith('G06-C3-REF ')]
    k.need(len(raw_pairs) == len(c3['pairs']), 'C3 report omitted or duplicated a native pair')
    rows = {module: [] for module in modules}
    counts = Counter()
    seen = set()
    for pair, (line_no, line) in zip(c3['pairs'], raw_pairs):
        m = pair['module']
        owner, parent, ref = (pair[key]['display'] for key in ('owner', 'parent', 'reference'))
        ph, rh = pair['parent_home'], pair['reference_home']
        kind, abbrev = pair['reference_kind'], str(pair['reference_abbrev']).lower()
        family = pair['family']
        fields = (m, owner, ref, parent, ph, rh, 'family=' + family, 'kind=' + kind, 'abbrev=' + abbrev)
        key = (m, owner, ref)
        k.need(m in rows and key not in seen and pair['log_line'] == line_no and
               line == 'G06-C3-REF ' + ' | '.join(fields), 'C3 raw pair/identity differs')
        for name, home in [(owner, m), (parent, ph), (ref, rh)]:
            k.need(name in kinds and kinds[name][1] == home, 'C3 name/home differs from fresh kind table: ' + name)
        k.need(kinds[parent][0].startswith('def') and ph != m and
               ((kind == 'theorem' and kinds[ref][0] == 'thm') or
                (family == 'matcher_splitter' and kind == 'def' and abbrev == 'true' and kinds[ref][0].startswith('def'))),
               'C3 declaration kind differs from fresh native kind table')
        seen.add(key)
        counts[m] += 1
        rows[m].append('\t'.join((m, owner, parent, ref)) + '\n')
    ends = {}
    for line in lines:
        if not line.startswith('G06-C3-MODULE-END '):
            continue
        match = re.fullmatch(r'G06-C3-MODULE-END (\S+) \| roots=(\d+) \| pairs=(\d+)', line)
        k.need(match and match[1] not in ends and int(match[2]) > 0 and int(match[3]) == counts[match[1]],
               'incomplete C3 module ending')
        ends[match[1]] = int(match[2])
    k.need(set(ends) == set(modules) and sum(ends.values()) == c3['actual_roots'], 'incomplete C3 owner scope')
    return rows, receipt


def record_sha(k, record):
    return k.sha(json.dumps(record, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


def effective_attempts(k, effective, summary, manifest, run, args):
    summary_sha, adapter_sha, _, guard_sha = args
    k.need(effective['status'] == 'ALL_EFFECTIVE_HARNESSES_VALID' and
           effective['head'] == k.HEAD and effective['actual_base'] == k.BASE and
           effective['original_summary_sha256'] == summary_sha and effective['adapter_sha256'] == adapter_sha and
           effective['original_guard_sha256'] == guard_sha and
           effective['completed_probes'] == len(effective['selected']) == len(manifest['probes']),
           'effective selection is incomplete or from a different R2 run')
    retry_run = run.parent / 'native-payload-retry-r3'
    retry_result = k.decode(k.read(retry_run / 'RESULT.json', effective['retry_result_sha256']))
    k.need(retry_result['status'] == 'BOUNDED_PAYLOAD_RETRY_COMPLETE' and
           retry_result['head'] == k.HEAD and retry_result['actual_base'] == k.BASE and
           retry_result['original_summary_sha256'] == summary_sha and retry_result['original_guard_sha256'] == guard_sha and
           retry_result['adapter_sha256'] == adapter_sha and retry_result['all_retry_harnesses_valid'] is True and
           retry_result['bounder_sha256'] == BOUNDER_SHA,
           'retry RESULT is incomplete or from a different R2 run')
    retry_guard = k.AREA / 'guarded-native-r5/payload-retry-r3'
    guard = k.decode(k.read(retry_guard / 'RESULT.json', effective['retry_guard_sha256']))
    start = k.decode(k.read(retry_guard / 'start.json'))
    terminal = k.decode(k.read(retry_guard / 'child-terminal.json'))
    k.read(retry_guard / 'launcher.log', terminal['launcher_log_sha256'])
    k.need(guard['guard_sha256'] == R5_SHA and guard['head'] == k.HEAD and
           guard['tree'] == str(k.TREE) and guard['environment_reconciled'] is True and
           guard['reviewed_local_result_sha256'] == k.LOCAL_SHA and
           guard['other_processes_signalled'] is False and guard['whole_command_retry'] is False and
           guard['interrupted'] is terminal['interrupted'] is None and
           guard['command_rc'] == terminal['command_rc'] == int(retry_result['source_error_diagnostics'] > 0) and
           guard['tool_sha256'] == start['tool_sha256'] == retry_result['runner_sha256'] == RETRY_RUNNER_SHA,
           'retry guard completion differs')
    runner = k.AREA / 'rule10-payload-retry-r3/run_bounded_payload_retries.py'
    command = start['command']
    k.need(len(command) == 9 and command[1:3] == ['-I', str(runner)] and
           dict(zip(command[3::2], command[4::2])) == {'--adapter-sha256': adapter_sha,
               '--survey-sha256': summary_sha, '--survey-guard-sha256': guard_sha},
           'R5 ran a different retry command')
    k.read(runner, RETRY_RUNNER_SHA)
    k.read(runner.with_name('bound_payload.py'), BOUNDER_SHA)
    k.read(k.AREA / 'native-rule10-guard-r5/guard_native_command_r5.py', R5_SHA)
    diagnosis = k.decode(k.read(k.AREA / 'rule10-parser-stack-diagnosis-r3.json', DIAGNOSIS_SHA))
    diagnosed = {r['label']: r for r in diagnosis['attempts']}
    retries = {row['probe']['module']: row for row in retry_result['attempts']}
    invalid = {r['module'] for r in summary['results'] if r['valid_harness'] is False}
    k.need(invalid and len(retries) == len(retry_result['attempts']) == len(invalid) == summary['harness_failures'] and
           set(retries) == invalid and
           set(diagnosed) == {r['label'] for r in summary['results'] if r['module'] in invalid} and
           summary['all_harnesses_valid'] is False,
           'retry attempt set is not exactly the invalid R2 owner set')
    attempts, prior_failures = [], []
    for old_probe, old_record, selected in zip(manifest['probes'], summary['results'], effective['selected']):
        module = old_probe['module']
        k.need(old_record['module'] == selected['module'] == module and old_record['label'] == old_probe['label'],
               'effective owner/order differs from original R2')
        probe, record, root, origin = old_probe, old_record, run, 'original'
        if module in retries:
            label = old_probe['label']
            old_attempt = run / 'probes' / label
            old_log = old_attempt / (label + '.log')
            old_result = old_attempt / (label + '.json')
            k.need(old_record['log'] == str(old_log) and old_record['result_path'] == str(old_result),
                   'original invalid attempt paths differ')
            known = diagnosed[label]
            k.need(known['raw_log_sha256'] == old_record['log_sha256'] and
                   known['probe_sha256'] == old_probe['probe_sha256'], 'original parser diagnosis binding differs')
            log = k.read(old_log, old_record['log_sha256']).decode()
            result = k.decode(k.read(old_result, old_record['result_json_sha256']))
            k.read(old_attempt / (label + '.source.txt'), old_probe['probe_sha256'])
            k.need(result == old_record['result'] and result['source_sha256'] == old_probe['probe_sha256'] and
                   result['source_unchanged'] is True and result['rc'] == old_record['launcher_returncode'] == 1 and
                   result['error_diagnostics'] == 0 and old_record['errors'] == [] and
                   result['fresh_nonempty_object'] is False and result['object_sha256'] is None and
                   'Stack overflow detected. Aborting.' in log and 'lean exited with status 134' in log and
                   not k.ERROR.search(log) and not any(marker in log for marker in
                       ('G06-COMPONENT', 'G06-SEAL', 'G06-MASK', 'G06-NAME', 'G06-HARNESS')),
                   'retry would replace a non-parser-stack R2 result')
            row = retries[module]
            k.need(row['original_record_sha256'] == record_sha(k, old_record), 'retry original record binding differs')
            prior_failures.append({'module': module, 'label': label, 'record_sha256': row['original_record_sha256'],
                                   'log': str(old_log), 'log_sha256': old_record['log_sha256'],
                                   'result_path': str(old_result), 'result_sha256': old_record['result_json_sha256'],
                                   'probe_sha256': old_probe['probe_sha256'],
                                   'disposition': 'ORIGINAL_PARSER_STACK_FAILURE_RETAINED'})
            probe, record, root, origin = row['probe'], row['record'], retry_run, 'bounded_payload_retry'
            invariant = ('ordinal', 'label', 'module', 'source', 'source_sha256', 'source_imports', 'import_closure',
                         'source_to_probe_lines', 'term_names',
                         'requested_names', 'requested_count', 'collector_active_candidate_count', 'collector_irreducible_count')
            k.need(all(probe[key] == old_probe[key] for key in invariant) and
                   probe['probe_module'] != old_probe['probe_module'] and
                   probe['probe_sha256'] != old_probe['probe_sha256'], 'retry source or request invariants differ')
        k.need(record['valid_harness'] is True and selected['origin'] == origin and
               selected['label'] == record['label'] == probe['label'] and
               selected['record_sha256'] == record_sha(k, record) and selected['probe_sha256'] == probe['probe_sha256'],
               'selected effective native classification differs')
        attempts.append((probe, record, root, origin))
    return attempts, prior_failures, retry_result['source_error_diagnostics']


def source_errors(k, args, modules, effective):
    summary_sha, adapter_sha, guard_path, guard_sha = args
    evidence = k.AREA / 'rule10-evidence-r2'
    run = evidence / 'native-seal-runs'
    guard = Path(guard_path).resolve()
    k.need(guard.is_relative_to(k.AREA / 'guarded-native-r4'), 'wrong R4 guard directory')
    receipt = k.decode(k.read(guard / 'RESULT.json', guard_sha))
    start = k.decode(k.read(guard / 'start.json'))
    terminal = k.decode(k.read(guard / 'child-terminal.json'))
    k.read(guard / 'launcher.log', terminal['launcher_log_sha256'])
    tool = k.AREA / 'rule10-final-tools-r2/run_gate06_final_native.py'
    k.need(receipt['guard_sha256'] == R4_SHA and receipt['tool_sha256'] == DRIVER_SHA and
           receipt['head'] == k.HEAD and receipt['tree'] == str(k.TREE) and receipt['environment_reconciled'] is True and
           receipt['reviewed_local_result_sha256'] == k.LOCAL_SHA and
           receipt['interrupted'] is terminal['interrupted'] is None and
           receipt['command_rc'] == terminal['command_rc'] in (0, 1), 'R4 completion receipt differs')
    command = start['command']
    k.need(len(command) == 6 and command[1:3] == ['-I', str(tool)] and command[3] in ('run-seals', 'run-all') and
           command[4:] == ['--adapter-sha256', adapter_sha], 'R4 ran a different seal command')
    summary = k.decode(k.read(run / 'summary.json', summary_sha))
    config = k.decode(k.read(run / 'configuration.json', summary['configuration_sha256']))
    k.read(run / 'driver.source.txt', DRIVER_SHA)
    adapter = k.decode(k.read(evidence / 'final-adapter.json', adapter_sha))
    manifest = k.decode(k.read(evidence / 'seal-manifest.json', adapter['seal_manifest_sha256']))
    k.need(summary['head'] == config['head'] == adapter['head'] == k.HEAD and
           summary['base'] == config['base'] == adapter['base'] == k.VERIFY_BASE and
           config['driver_sha256'] == DRIVER_SHA and config['adapter_sha256'] == adapter_sha and
           config['olean_tree'] == str(k.TREE) and config['modules'] == sorted(modules), 'seal configuration differs')
    k.need(summary['kind'] == 'seals' and summary['complete'] is True and summary['aborted_reason'] is None and
           summary['uncompleted_labels'] == [] and
           summary['expected_probes'] == summary['completed_probes'] == len(summary['results']) ==
           len(manifest['probes']) == len(modules) and
           {r['module'] for r in summary['results']} == {p['module'] for p in manifest['probes']} == set(modules),
           'C2 NOT_MEASURED: missing original whole-file attempts')
    attempts, prior_failures, retry_errors = effective_attempts(k, effective, summary, manifest, run, args)
    rows = []
    for probe, record, selected_run, origin in attempts:
        label, module = probe['label'], probe['module']
        rel = modules[module]
        k.need(re.fullmatch(r'[A-Za-z0-9_-]+', label) and record['label'] == label and record['module'] == module and
               probe['source'] == rel and record['valid_harness'] is True, 'seal attempt identity differs')
        attempt = selected_run / 'probes' / label
        log_path, result_path = attempt / (label + '.log'), attempt / (label + '.json')
        k.need(record['log'] == str(log_path) and record['result_path'] == str(result_path), 'wrong raw native attempt paths')
        log = k.read(log_path, record['log_sha256']).decode()
        result = k.decode(k.read(result_path, record['result_json_sha256']))
        captured = k.read(attempt / (label + '.source.txt'), probe['probe_sha256'])
        k.need(result == record['result'] and result['module'] == probe['probe_module'] and result['label'] == label and
               result['source_sha256'] == record['captured_probe_sha256'] == probe['probe_sha256'] and
               result['source_unchanged'] is True and result['rc'] == record['launcher_returncode'] in (0, 1),
               'seal native source/receipt differs')
        source = k.read(k.ROOT / rel, probe['source_sha256'])
        recovered = captured
        for insertion in reversed(probe['insertions']):
            offset, size = insertion['probe_byte_offset'], insertion['byte_count']
            k.need(k.sha(recovered[offset:offset + size]) == insertion['sha256'], 'seal insertion differs')
            recovered = recovered[:offset] + recovered[offset + size:]
        k.need(recovered == source, 'seal probe does not restore current original source')
        inverse = {r['probe_line']: r['source_line'] for r in probe['source_to_probe_lines']}
        k.need(len(inverse) == len(probe['source_to_probe_lines']) and
               sorted(inverse.values()) == list(range(1, len(source.splitlines()) + 1)),
               'seal source line map is incomplete')
        errors = list(k.ERROR.finditer(log))
        k.need(len(errors) == len(record['errors']) == result['error_diagnostics'] and
               bool(errors) == record['source_failure'] == (result['rc'] == 1),
               'missing/misclassified source error')
        for match, error in zip(errors, record['errors']):
            path, line, column, code, message = match.groups()
            line, column = int(line), int(column)
            k.need((k.ROOT / path.strip()).resolve() == Path(probe['probe_path']).resolve() and
                   path.strip() == error['path'] and line == error['probe_line'] and column == error['probe_column'] and
                   (code or None) == error['error_code'] and message.strip() == error['message'] and
                   log.count('\n', 0, match.start()) + 1 == error['log_line'] and
                   line in inverse and inverse[line] == error['source_line'], 'raw error/coordinate mismatch')
            rows.append({'module': module, 'file': rel, 'origin': origin, 'diagnostic': error,
                         'raw_log': str(log_path), 'raw_log_sha256': record['log_sha256'],
                         'native_result_sha256': record['result_json_sha256']})
    original_errors = sum(row['origin'] == 'original' for row in rows)
    k.need(original_errors == summary['source_error_diagnostics'] and len(rows) == effective['source_error_diagnostics'] and
           len(rows) - original_errors == retry_errors,
           'C2 original/effective source diagnostic totals differ')
    return rows, summary, prior_failures


def static_sidecars(k, kinds, modules):
    folder = k.AREA / 'source-review/final-static-r1'
    pins = {str(folder / name): digest for name, digest in STATIC_PINS.items()}
    raw = {name: k.read(folder / name, digest) for name, digest in STATIC_PINS.items()}
    summary = k.decode(raw['explicit-summary.json'])
    k.need(summary['head'] == k.HEAD and summary['base'] == k.BASE, 'prior static comparison scope differs')
    # Selected opens are a known gap of the unchanged textual resolver.
    file = 'TCSlib/Cryptography/Asymptotic/BlockEncryptor.lean'
    name = 'TCSlib.Cryptography.PrivateKeyScheme.encodeList'
    home = 'TCSlib.Cryptography.Asymptotic.Encryption'
    rows = [r for r in k.decode(raw['explicit-inherited-tcs-debt.json'])
            if r['path'] == file and r['foreign_name'] == name]
    code = k.read(k.ROOT / file).decode().splitlines()
    k.need(file in modules.values() and 'open PrivateKeyScheme (encodeList)' in code and
           len(rows) == 10 and kinds[name][0].startswith('def') and kinds[name][1] == home and
           all(r['declaration_status'] == 'SAME' and r['head'] == 'encodeList' and
               'encodeList' in code[r['line'] - 1] and r['source_failure_exclusion'] is False for r in rows),
           'selected-open source/kind correspondence needs review')
    supplement = [{**r, 'fresh_native_kind': kinds[name][0], 'fresh_native_home': home,
                   'coverage': 'SEPARATE_SELECTED_OPEN_C1_OBSERVATION'} for r in rows]
    return pins, supplement


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--catalog', nargs=2, metavar=('DIR', 'VALIDATION_SHA'), required=True)
    parser.add_argument('--c3', nargs=5, metavar=('ATTEMPT', 'LABEL', 'GUARD', 'RESULT_SHA', 'GUARD_SHA'), required=True)
    parser.add_argument('--reconciliation', nargs=2, metavar=('REPORT', 'SHA'), required=True)
    parser.add_argument('--seals', nargs=4, metavar=('SUMMARY_SHA', 'ADAPTER_SHA', 'GUARD', 'GUARD_SHA'), required=True)
    parser.add_argument('--effective-sha256', required=True)
    args = parser.parse_args()
    k = load_extractor()
    out = args.output.resolve()
    k.need(out.parent == HERE and not out.exists(), 'fresh ignored scanner-input directory required')
    modules = k.frozen_scope()
    catalog = Path(args.catalog[0]).resolve()
    k.need(catalog.parent == HERE, 'catalog output is outside kind scratch')
    native = k.decode(k.read(catalog / 'catalog-validation.json', args.catalog[1]))
    k.need(native['status'] == 'FRESH_NATIVE_KIND_TABLE_SCANNER_NOT_RUN' and native['head'] == k.HEAD and
           native['actual_PR_base'] == k.BASE and native['modules'] == sorted(modules) and native['scanner_pins'] == k.SCAN_PINS,
           'catalog validation belongs to a different epoch')
    kind_rows = [line.split('\t') for line in k.read(catalog / 'native-kinds.tsv', native['native_kinds_sha256']).decode().splitlines()]
    kinds = {name: (kind, home) for name, kind, home in kind_rows}
    constants = k.read(catalog / 'constants.tsv', native['constants_sha256'])
    k.need(len(kinds) == len(kind_rows) == native['rows'], 'kind table lost native rows')
    report_path = Path(args.reconciliation[0]).resolve()
    k.need(report_path.is_relative_to(k.AREA), 'reconciliation report must be local ignored evidence')
    reconciliation = k.decode(k.read(report_path, args.reconciliation[1]))
    equations, c3_receipt = c3_files(k, args.c3, modules, kinds, reconciliation)
    effective_path = k.AREA / 'rule10-payload-retry-r3/effective-results.json'
    effective_raw = k.read(effective_path, args.effective_sha256)
    effective = k.decode(effective_raw)
    errors, original, prior_failures = source_errors(k, args.seals, modules, effective)
    k.need(original['source_error_diagnostics'] == reconciliation['source_error_diagnostics'] and
           original['all_harnesses_valid'] == reconciliation['all_harnesses_valid'],
           'C3 census report and original R2 seal summary differ')
    static_pins, supplement = static_sidecars(k, kinds, modules)
    eqn = {f'equations/{m}.eqn.txt': ''.join(rows).encode() for m, rows in equations.items()}
    files = {'files.txt': ''.join(modules[m] + '\n' for m in sorted(modules)).encode(),
             'constants.tsv': constants, **eqn,
             'seal-source-diagnostics.json': k.encode(errors),
             'seal-source-errors.txt': ''.join(f" {r['file']}:{r['diagnostic']['source_line']}: source error\n" for r in errors).encode(),
             'effective-seal-selection.json': effective_raw,
             'retained-original-setup-failures.json': k.encode(prior_failures),
             'c1-selected-open-supplement.json': k.encode(supplement),
             'c3-all-pairs.json': k.encode(reconciliation['c3']['pairs'])}
    manifest = {
        'status': 'COMPLETE_R2_WITH_R3_PAYLOAD_RETRIES_SCANNER_NOT_RUN', 'head': k.HEAD, 'actual_PR_base': k.BASE,
        'verification_base': k.VERIFY_BASE, 'modules': modules, 'source_diagnostics': len(errors),
        'original_R2_source_diagnostics': original['source_error_diagnostics'],
        'original_R2_harness_failures_retained': len(prior_failures),
        'retry_source_diagnostics': len(errors) - original['source_error_diagnostics'],
        'effective_selection': {'path': str(effective_path), 'sha256': args.effective_sha256},
        'equation_owner_files': len(eqn), 'c3_pairs': len(reconciliation['c3']['pairs']),
        'selected_open_observations': len(supplement), 'scanner_pins': k.SCAN_PINS,
        'kind_validation_path': str(catalog / 'catalog-validation.json'), 'kind_validation_sha256': args.catalog[1],
        'c3_receipt': c3_receipt, 'reconciliation': {'path': str(report_path), 'sha256': args.reconciliation[1]},
        'seals_summary_sha256': args.seals[0], 'seals_adapter_sha256': args.seals[1],
        'seals_guard_path': args.seals[2], 'seals_guard_sha256': args.seals[3],
        'static_C1_sidecars': static_pins, 'files_sha256': {p: k.sha(b) for p, b in files.items()},
        'limits': ['R2 raw outcomes and selected-open observations are retained. No source exclusion or waiver.',
                   'C2 is a same-line textual join. C3 retains all native families and actual components in its JSON sidecar.',
                   'Prior static 54-owner classifications are separate; the five accepted S2 owners equal actual-base source.',
                   'No scanner outcome or merge clearance follows from input preparation.'],
    }
    k.need(k.frozen_scope() == modules, 'source scope changed while assembling inputs')
    out.mkdir(exist_ok=False)
    (out / 'equations').mkdir()
    for path, raw in {**files, 'manifest.json': k.encode(manifest)}.items():
        with (out / path).open('xb') as stream:
            stream.write(raw)
    print(k.encode(manifest).decode(), end='')


if __name__ == '__main__':
    main()
