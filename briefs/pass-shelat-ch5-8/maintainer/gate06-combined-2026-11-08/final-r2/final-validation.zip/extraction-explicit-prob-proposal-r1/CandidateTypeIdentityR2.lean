import Lean
import TCSlib.Cryptography.Randomness.Extraction

set_option maxHeartbeats 0
open Lean Elab Command Meta
open Complexity TCSlib.Cryptography TCSlib.InformationTheory
open scoped BigOperators

private theorem samplerLaw_apply_explicit_candidate (S : NUPPT) (n : ℕ) (x : Fin n → Bool) :
    (TCSlib.Cryptography.Randomness.samplerLaw S n).prob x =
      ∑ r ∈ (Finset.univ : Finset (S.Coins n)).filter
        (fun r => padFin n (S.runAt n [] r) = x), (Fintype.card (S.Coins n) : ℝ)⁻¹ :=
  TCSlib.Cryptography.Randomness.samplerLaw_apply S n x

run_cmd do
  let current ← getConstInfo ``TCSlib.Cryptography.Randomness.samplerLaw_apply
  let candidate ← getConstInfo ``samplerLaw_apply_explicit_candidate
  unless ExprStructEq.mk current.type == ExprStructEq.mk candidate.type do
    throwError "explicit projection type differs from existing declaration"
  logInfo "EXTRACTION-EXPLICIT-PROB-STRUCTURAL-TYPE-IDENTITY"
