import Lean
import TCSlib.Cryptography.Randomness.Extraction

set_option maxHeartbeats 0
open Lean Elab Command Meta
open Complexity TCSlib.Cryptography TCSlib.InformationTheory
open scoped BigOperators

run_cmd liftTermElabM do
  let expected ← Term.elabType (← ``(∀ (S : NUPPT) (n : ℕ) (x : Fin n → Bool),
    (TCSlib.Cryptography.Randomness.samplerLaw S n).prob x =
      ∑ r ∈ (Finset.univ : Finset (S.Coins n)).filter
        (fun r => padFin n (S.runAt n [] r) = x), (Fintype.card (S.Coins n) : ℝ)⁻¹))
  let expected ← instantiateMVars expected
  let info ← getConstInfo `TCSlib.Cryptography.Randomness.samplerLaw_apply
  unless !expected.hasMVar && ExprStructEq.mk expected == ExprStructEq.mk info.type do
    throwError "explicit projection type differs from existing declaration"
  logInfo "EXTRACTION-EXPLICIT-PROB-STRUCTURAL-TYPE-IDENTITY"
