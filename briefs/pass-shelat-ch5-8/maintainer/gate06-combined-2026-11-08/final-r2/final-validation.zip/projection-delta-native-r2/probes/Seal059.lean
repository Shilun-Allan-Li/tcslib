/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.LearningTheory.PAC.Defs
/- G06-HARNESS INSTALL G06Seal_059_TCSlib_LearningTheory_PAC_Prediction -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "G06Seal_059_TCSlib_LearningTheory_PAC_Prediction"
  let payload : String := "TCSlib.InformationTheory.FinDist.HasMinEntropy\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_1\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_inst\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.collision\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.expect\tTCSlib.InformationTheory.Samples\nTCSlib.InformationTheory.FinDist.iid\tTCSlib.InformationTheory.Samples\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.map\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.probTrue\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.prod\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.uniform\tTCSlib.InformationTheory.FinDist\nTCSlib.LearningTheory.PAC.PACLearns\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.PACLearnsUnder\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.WeakLearns\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.WeakLearnsUnder\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.accuracyProb\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.err\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.label\tTCSlib.LearningTheory.PAC.Defs"
  let expectedRequests : Nat := 19
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.InformationTheory.FinDist.HasMinEntropy\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"HasMinEntropy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.collision\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"collision\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.expect\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"expect\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"Samples\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.iid\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"iid\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"Samples\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"instCoeFunForallReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.map\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"map\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.probTrue\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"probTrue\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.prod\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"prod\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.uniform\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"uniform\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.PACLearns\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"PACLearns\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.PACLearnsUnder\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"PACLearnsUnder\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.WeakLearns\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"WeakLearns\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.WeakLearnsUnder\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"WeakLearnsUnder\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.accuracyProb\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"accuracyProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.err\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"err\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.label\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"label\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The prediction game, and its bridge to PAC learning

[PS10, §8.1] (Def 179.a of the inventory) asks whether a learner, given labelled examples of a
random concept `C_i`, can predict the label of a fresh point. Under the uniform distribution
(the reading under which the source's Theorem 179.1 works) the game is:
`i ← I`, `m` examples `s ← X^m`, coins `r ← ρ`, a fresh point `x ← X`, all uniform and
independent; the learner wins when `L(s labelled by C_i, r)(x) = C_i(x)`.

**The bridge.** The fresh point is independent of the sample, so for fixed `(i, s, r)` the
probability of a correct prediction is `1 − err_U(h, C_i)` for the hypothesis `h = L(s, r)`.
So the prediction success is `1 − E_{i,s,r}[err_U(L(s, r), C_i)]`
(`predictSuccess_eq_one_sub_expectedErr`), with no collision issue between the fresh point and
the sample. A learner that PAC-learns under the uniform distribution with accuracy `ε ≥ 0` and
confidence `δ` has expected error at most `ε + δ`: split the expectation over the accuracy event,
where the error is at most `ε`, and its complement, of probability at most `δ`, where the error is
at most `1`. Hence its prediction success is at least `1 − ε − δ`, and a learner whose prediction
advantage is at most `γ` does not satisfy `WeakLearnsUnder` under the uniform distribution at an
edge `γ'` and confidence `δ` with `γ + δ < γ' ≤ ½` (`not_weakLearnsUnder_of_predictAdv_le`).

**Use in layer 2.** Layer 2 applies this to each efficient learner, turning [PS10, Thm 179.1]
into a statement at a confidence `δ` below the gap `γ' − γ`. A weak learner of
[KV94, §4.1, p. 74] need only succeed with probability `1/q(n, size(c))`, that is, at the
confidence `δ = 1 − 1/q(n, size(c))`. Starting only from that guarantee, the required small `δ`
is obtained by amplification ([KV94, §4.2, pp. 76–77]), unless the learner is already certified
at it; amplification gives a different learner, and layer 2 must account for that learner's
sample count, running time and edge before applying the bridge.
Information-theoretically the class is learnable; the hardness is computational.

**Source notes.** [PS10] leaves the sample distribution and "a new sample" implicit; uniform
and independent is the reading (design note S3d). "Better than `½ + ε`" is the advantage
`|Pr[correct] − ½|`.

## Main definitions

* `PAC.trialDist X I ρ m`: the joint law of the concept index, the examples and the coins.
* `PAC.predictSuccess C m L`, `PAC.predictAdv C m L`: the success probability of the prediction
  game, and its advantage over `½`.
* `PAC.expectedErr C m L`: the expected uniform error of the learner's hypothesis.

## Main results

* `PAC.predictSuccess_eq_one_sub_expectedErr`: **the bridge**, success `= 1 − E[err]`.
* `PAC.expectedErr_le_of_pacLearnsUnder`, `PAC.one_sub_sub_le_predictSuccess`: PAC learning
  under the uniform distribution with accuracy `ε ≥ 0` gives expected error at most `ε + δ` and
  success at least `1 − ε − δ`.
* `PAC.sub_le_predictAdv_of_weakLearnsUnder`, `PAC.not_weakLearnsUnder_of_predictAdv_le`: the
  weak-learning condition at edge `γ' ≤ ½` and confidence `δ` gives advantage at least `γ' − δ`;
  so advantage at most `γ` rules it out when `γ + δ < γ' ≤ ½`.
* `PAC.predictSuccess_coin`: the learner that outputs its coin succeeds with probability exactly
  `½` (non-vacuity).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §8.1 (book p. 179).
* [KV94] M. Kearns, U. Vazirani, *An Introduction to Computational Learning Theory*, MIT Press,
  1994, §1.2, §4.1 (p. 74) and §4.2 (pp. 76–77).
* [SSBD14] S. Shalev-Shwartz, S. Ben-David, *Understanding Machine Learning: From Theory to
  Algorithms*, Cambridge University Press, 2014, ch. 3.
-/

namespace TCSlib.LearningTheory.PAC

open TCSlib.InformationTheory Finset

variable {X I ρ : Type*} [Fintype X] [Nonempty X] [Fintype I] [Nonempty I] [Fintype ρ]
  [Nonempty ρ]

/-! ### The game -/

variable (X I ρ) in
/-- The joint law of a trial of the prediction game: a uniform concept index, `m` uniform
independent examples and uniform coins. -/
noncomputable def trialDist (m : ℕ) : FinDist (I × ((Fin m → X) × ρ)) :=
  (FinDist.uniform I).prod (((FinDist.uniform X).iid m).prod (FinDist.uniform ρ))

/-- The trial law is the product of the uniform index, the `m` uniform examples and the uniform
coins. -/
theorem trialDist_eq (m : ℕ) :
    trialDist X I ρ m =
      (FinDist.uniform I).prod (((FinDist.uniform X).iid m).prod (FinDist.uniform ρ)) := rfl

/-- **The prediction game** [PS10, §8.1]: the probability that the learner `L`, given `m`
uniform examples labelled by a uniform concept `C_i` and uniform coins, predicts the label of a
fresh uniform point. [PS10] leaves the sample law and "a new sample" implicit. Here both are
uniform and independent, so the fresh point may coincide with an example. -/
noncomputable def predictSuccess (C : I → X → Bool) (m : ℕ)
    (L : (Fin m → X × Bool) → ρ → X → Bool) : ℝ :=
  ((trialDist X I ρ m).prod (FinDist.uniform X)).probTrue
    fun w => L (label (C w.1.1) w.1.2.1) w.1.2.2 w.2 == C w.1.1 w.2

/-- The success probability is the probability, over a trial `(i, (s, r)) ← trialDist` and an
independent uniform point `x`, of the event `L(s labelled by C_i, r)(x) = C_i(x)`. -/
theorem predictSuccess_eq (C : I → X → Bool) (m : ℕ) (L : (Fin m → X × Bool) → ρ → X → Bool) :
    predictSuccess C m L = ((trialDist X I ρ m).prod (FinDist.uniform X)).probTrue
      (fun w => L (label (C w.1.1) w.1.2.1) w.1.2.2 w.2 == C w.1.1 w.2) := rfl

/-- The **prediction advantage** `|Pr[correct] − ½|` [PS10, §8.1, proof of Thm 179.1]: "better
than `½ + ε`", read two-sidedly. An upper bound on it bounds the one-sided success. -/
noncomputable def predictAdv (C : I → X → Bool) (m : ℕ)
    (L : (Fin m → X × Bool) → ρ → X → Bool) : ℝ :=
  |predictSuccess C m L - 1 / 2|

/-- The prediction advantage is `|predictSuccess − ½|`. -/
theorem predictAdv_eq (C : I → X → Bool) (m : ℕ) (L : (Fin m → X × Bool) → ρ → X → Bool) :
    predictAdv C m L = |predictSuccess C m L - 1 / 2| := rfl

/-- The **expected error** `E_{i,s,r}[err_U(L(s labelled by C_i, r), C_i)]` of the learner's
hypothesis under the uniform distribution. -/
noncomputable def expectedErr (C : I → X → Bool) (m : ℕ)
    (L : (Fin m → X × Bool) → ρ → X → Bool) : ℝ :=
  (trialDist X I ρ m).expect
    fun t => err (FinDist.uniform X) (L (label (C t.1) t.2.1) t.2.2) (C t.1)

/-- The expected error is the expectation, over a trial `(i, (s, r)) ← trialDist`, of the
uniform error `err_U(L(s labelled by C_i, r), C_i)`. -/
theorem expectedErr_eq (C : I → X → Bool) (m : ℕ) (L : (Fin m → X × Bool) → ρ → X → Bool) :
    expectedErr C m L = (trialDist X I ρ m).expect
      (fun t => err (FinDist.uniform X) (L (label (C t.1) t.2.1) t.2.2) (C t.1)) := rfl

/-! ### The bridge -/

/-- **The bridge: prediction success is one minus the expected error.**

**Proof sketch.** Split the fresh point off the trial (`expect_prod`). For a fixed trial with
hypothesis `h`, the correct-prediction indicator is one minus the disagreement indicator, so its
expectation over the uniform fresh point is `1 − err_U(h, C_i)` (`expect_one_sub`); then take the
expectation over the trial. -/
theorem predictSuccess_eq_one_sub_expectedErr (C : I → X → Bool) (m : ℕ)
    (L : (Fin m → X × Bool) → ρ → X → Bool) :
    predictSuccess C m L = 1 - expectedErr C m L := by
  rw [predictSuccess_eq, FinDist.probTrue_eq_expect, FinDist.expect_prod, expectedErr_eq,
    ← FinDist.expect_one_sub]
  congr 1
  funext t
  dsimp only
  rw [err_eq, FinDist.probTrue_eq_expect, ← FinDist.expect_one_sub]
  congr 1
  funext x
  cases L (label (C t.1) t.2.1) t.2.2 x <;> cases C t.1 x <;> simp

/-- **PAC learning under the uniform distribution bounds the expected error** by `ε + δ`
(for `ε ≥ 0`).

**Proof sketch.** For each concept `C_i`, the error is at most `1`, and at most `ε` except with
probability at most `δ` (the hypothesis `PACLearnsUnder`), so its expectation over the examples
and coins is at most `ε + δ` (`expect_le_add_of_le_one`, `probTrue_not`); average over `i`. -/
theorem expectedErr_le_of_pacLearnsUnder {C : I → X → Bool} {m : ℕ}
    {L : (Fin m → X × Bool) → ρ → X → Bool} {ε δ : ℝ}
    (h : PACLearnsUnder (FinDist.uniform X) C m L ε δ) (hε : 0 ≤ ε) :
    expectedErr C m L ≤ ε + δ := by
  rw [expectedErr_eq, trialDist_eq, FinDist.expect_prod]
  calc _ ≤ (FinDist.uniform I).expect (fun _ => ε + δ) := FinDist.expect_le_expect _ fun i => ?_
    _ = ε + δ := FinDist.expect_const _ _
  dsimp only
  have h1 := FinDist.expect_le_add_of_le_one (((FinDist.uniform X).iid m).prod
    (FinDist.uniform ρ)) (f := fun b => err (FinDist.uniform X) (L (label (C i) b.1) b.2) (C i))
    (fun b => err_le_one _ _ _) hε
  have h2 := (pacLearnsUnder_iff (FinDist.uniform X) C m L ε δ).mp h i
  rw [accuracyProb_eq] at h2
  have h3 := FinDist.probTrue_not (((FinDist.uniform X).iid m).prod (FinDist.uniform ρ))
    (fun b => decide (err (FinDist.uniform X) (L (label (C i) b.1) b.2) (C i) ≤ ε))
  dsimp only at h1 h2 h3
  linarith

/-- **PAC learning under the uniform distribution gives prediction success at least
`1 − ε − δ`** (for `ε ≥ 0`): the bridge and `expectedErr_le_of_pacLearnsUnder`. -/
theorem one_sub_sub_le_predictSuccess {C : I → X → Bool} {m : ℕ}
    {L : (Fin m → X × Bool) → ρ → X → Bool} {ε δ : ℝ}
    (h : PACLearnsUnder (FinDist.uniform X) C m L ε δ) (hε : 0 ≤ ε) :
    1 - ε - δ ≤ predictSuccess C m L := by
  rw [predictSuccess_eq_one_sub_expectedErr]
  linarith [expectedErr_le_of_pacLearnsUnder h hε]

/-- **Weak learning under the uniform distribution gives prediction advantage at least
`γ − δ`** (for `γ ≤ ½`): success is at least `1 − (½ − γ) − δ = ½ + γ − δ`. -/
theorem sub_le_predictAdv_of_weakLearnsUnder {C : I → X → Bool} {m : ℕ}
    {L : (Fin m → X × Bool) → ρ → X → Bool} {γ δ : ℝ}
    (h : WeakLearnsUnder (FinDist.uniform X) C m L γ δ) (hγ : γ ≤ 1 / 2) :
    γ - δ ≤ predictAdv C m L := by
  have hs := one_sub_sub_le_predictSuccess ((weakLearnsUnder_iff _ _ _ _ _ _).1 h)
    (by linarith)
  rw [predictAdv_eq]
  exact le_trans (by linarith) (le_abs_self _)

/-- **Small prediction advantage rules out the weak-learning condition below the gap**: if the
learner's prediction advantage is at most `γ`, it does not satisfy `WeakLearnsUnder` under the
uniform distribution at any edge `γ' ≤ ½` and confidence `δ` with `γ + δ < γ'`. The confidence
must be below the gap: at a constant confidence such as `δ = ½`, a learner with zero prediction
advantage can satisfy `WeakLearnsUnder`.

A weak learner of [KV94, §4.1, p. 74] need only succeed with probability `1/q(n, size(c))`, that
is, at the confidence `δ = 1 − 1/q(n, size(c))`, which in general is not below the gap. Starting
only from that guarantee, the small `δ` this lemma needs is obtained by confidence amplification
([KV94, §4.2, pp. 76–77]), unless the learner is already certified at it; amplification gives a
different learner, with its own sample count, running time and edge. It is the certified edge
`γ'`, sample count `m` and prediction advantage `γ` of the learner actually used that enter
here. -/
theorem not_weakLearnsUnder_of_predictAdv_le {C : I → X → Bool} {m : ℕ}
    {L : (Fin m → X × Bool) → ρ → X → Bool} {γ γ' δ : ℝ} (hadv : predictAdv C m L ≤ γ)
    (hlt : γ + δ < γ') (hγ' : γ' ≤ 1 / 2) :
    ¬ WeakLearnsUnder (FinDist.uniform X) C m L γ' δ := fun h => by
  have := sub_le_predictAdv_of_weakLearnsUnder h hγ'
  linarith

/-! ### Non-vacuity -/

omit [Nonempty X] [Fintype I] [Nonempty I] in
/-- Against any target, the two constant hypotheses have errors summing to one, so a fair coin
between them has expected error `½`. -/
theorem expect_err_coin (D : FinDist X) (c : X → Bool) :
    (FinDist.uniform Bool).expect (fun r => err D (fun _ => r) c) = 1 / 2 := by
  have hnot : err D (fun _ => true) c = 1 - err D (fun _ => false) c := by
    simpa using err_not D (fun _ => false) c
  rw [FinDist.expect_eq, Fintype.sum_bool]
  simp only [FinDist.uniform_apply, Fintype.card_bool]
  rw [hnot]
  push_cast
  ring

/-- **The coin-flipping learner predicts with probability exactly `½`** (non-vacuity of the
game): the learner that ignores its examples and outputs its coin.

**Proof sketch.** By the bridge, the success is one minus the expected error; for every concept
and every sample, the error averaged over the coin is `½` (`expect_err_coin`). -/
theorem predictSuccess_coin (C : I → X → Bool) (m : ℕ) :
    predictSuccess C m (fun (_ : Fin m → X × Bool) (r : Bool) (_ : X) => r) = 1 / 2 := by
  rw [predictSuccess_eq_one_sub_expectedErr, expectedErr_eq, trialDist_eq, FinDist.expect_prod]
  dsimp only
  have hin : ∀ i, (((FinDist.uniform X).iid m).prod (FinDist.uniform Bool)).expect
      (fun b => err (FinDist.uniform X) (fun _ => b.2) (C i)) = 1 / 2 := by
    intro i
    rw [FinDist.expect_prod]
    dsimp only
    simp only [expect_err_coin]
    exact FinDist.expect_const _ _
  simp only [hin, FinDist.expect_const]
  norm_num

end TCSlib.LearningTheory.PAC
/- G06-HARNESS EOF-VERIFY G06Seal_059_TCSlib_LearningTheory_PAC_Prediction -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "G06Seal_059_TCSlib_LearningTheory_PAC_Prediction"
  let payload : String := "TCSlib.InformationTheory.FinDist.HasMinEntropy\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_1\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_inst\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.collision\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.expect\tTCSlib.InformationTheory.Samples\nTCSlib.InformationTheory.FinDist.iid\tTCSlib.InformationTheory.Samples\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.map\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.probTrue\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.prod\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.uniform\tTCSlib.InformationTheory.FinDist\nTCSlib.LearningTheory.PAC.PACLearns\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.PACLearnsUnder\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.WeakLearns\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.WeakLearnsUnder\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.accuracyProb\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.err\tTCSlib.LearningTheory.PAC.Defs\nTCSlib.LearningTheory.PAC.label\tTCSlib.LearningTheory.PAC.Defs"
  let expectedRequests : Nat := 19
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.InformationTheory.FinDist.HasMinEntropy\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"HasMinEntropy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.collision\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"collision\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.expect\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"expect\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"Samples\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.iid\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"iid\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"Samples\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"instCoeFunForallReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.map\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"map\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.probTrue\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"probTrue\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.prod\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"prod\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.uniform\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"uniform\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.PACLearns\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"PACLearns\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.PACLearnsUnder\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"PACLearnsUnder\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.WeakLearns\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"WeakLearns\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.WeakLearnsUnder\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"WeakLearnsUnder\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.accuracyProb\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"accuracyProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.err\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"err\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.LearningTheory.PAC.label\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"label\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"LearningTheory\"],[\"str\",\"PAC\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

