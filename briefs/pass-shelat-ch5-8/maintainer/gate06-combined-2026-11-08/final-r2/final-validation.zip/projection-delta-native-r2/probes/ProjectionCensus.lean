import Lean
import TCSlib.Complexity.CircuitComplexity.DAGCircuit
import TCSlib.Complexity.ClassP.BinaryArith.Loops
import TCSlib.Complexity.Randomized.Classes
import TCSlib.Complexity.Randomized.PolyTimeModel
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Asymptotic.BlockEncryptor
import TCSlib.Cryptography.Asymptotic.MultiMessage
import TCSlib.Cryptography.Authentication.DLHash
import TCSlib.Cryptography.Authentication.Defs
import TCSlib.Cryptography.Authentication.HashAndSign
import TCSlib.Cryptography.Authentication.Lamport
import TCSlib.Cryptography.Authentication.PRFMAC
import TCSlib.Cryptography.Candidates.Concrete
import TCSlib.Cryptography.Candidates.DiscreteLog
import TCSlib.Cryptography.Candidates.ElGamal
import TCSlib.Cryptography.Candidates.RSA
import TCSlib.Cryptography.Candidates.Rabin
import TCSlib.Cryptography.Composability.CCA2Scheme
import TCSlib.Cryptography.Composability.Defs
import TCSlib.Cryptography.Composability.NonMalleable
import TCSlib.Cryptography.Composability.PRFScheme
import TCSlib.Cryptography.Composability.PublicKey
import TCSlib.Cryptography.Composability.SequentialZK
import TCSlib.Cryptography.Composability.SimNonMalleable
import TCSlib.Cryptography.Composability.ThreeColoring
import TCSlib.Cryptography.Randomness.BPPBridge
import TCSlib.Cryptography.Randomness.Derandomization
import TCSlib.Cryptography.Randomness.Extraction
import TCSlib.Cryptography.Randomness.Learning
import TCSlib.Cryptography.SecureComputation.Compose
import TCSlib.Cryptography.SecureComputation.ComposePhases
import TCSlib.Cryptography.SecureComputation.ComposeSecurity
import TCSlib.Cryptography.SecureComputation.Defs
import TCSlib.Cryptography.SecureComputation.Garbling
import TCSlib.Cryptography.SecureComputation.GarblingSecurity
import TCSlib.Cryptography.SecureComputation.GarblingSpecial
import TCSlib.Cryptography.SecureComputation.Hybrid
import TCSlib.Cryptography.SecureComputation.ObliviousTransfer
import TCSlib.Cryptography.SecureComputation.SpecialEncryption
import TCSlib.Cryptography.SecureComputation.SpecialEncryptionSecurity
import TCSlib.Cryptography.SecureComputation.Yao
import TCSlib.Cryptography.SecureComputation.YaoReal
import TCSlib.Cryptography.ZeroKnowledge.Defs
import TCSlib.Cryptography.ZeroKnowledge.Encoding
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Efficiency
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRep
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.EfficiencyRepGI
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.Proofs
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.SoundnessRep
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphism.SoundnessRepGI
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphismZK
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphismZK.Closeness
import TCSlib.Cryptography.ZeroKnowledge.GraphIsomorphismZK.Simulator
import TCSlib.InformationTheory.Extractors
import TCSlib.InformationTheory.FinDist
import TCSlib.InformationTheory.Samples
import TCSlib.LearningTheory.PAC.Defs
import TCSlib.LearningTheory.PAC.Prediction
set_option maxHeartbeats 0
namespace G06CombinedMetadata
open Lean

def parts : Name → List (String × String)
  | .anonymous => []
  | .str p s => parts p ++ [("str", s)]
  | .num p n => parts p ++ [("num", toString n)]

def ident (n : Name) : Json := Json.mkObj [
  ("display", toJson n.toString), ("components", toJson (parts n))]

def names (ns : Array Name) : Json := Json.arr (ns.map ident)

def kind : ConstantInfo → String
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .axiomInfo _ => "axiom"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def statusString : ReducibilityStatus → String
  | .reducible => "reducible"
  | .semireducible => "semireducible"
  | .irreducible => "irreducible"

def rootRecord (moduleName n : Name) (ci : ConstantInfo) (axs : Array Name) : Json :=
  Json.mkObj [("module", ident moduleName), ("name", ident n), ("kind", toJson (kind ci)),
    ("type_refs", names ci.type.getUsedConstants),
    ("value_refs", names (((ci.value? (allowOpaque := true)).map (·.getUsedConstants)).getD #[])),
    ("axioms", names axs)]
end G06CombinedMetadata

open Lean Meta Elab Command

/-- user-facing name of a constant (private prefix removed) -/
def userStr (n : Name) : String := ((privateToUserName? n).getD n).toString

def matchesTouched (ts : List String) (n : Name) : Bool :=
  let s := userStr n
  ts.any fun t => t == "*" || s == t || s.endsWith ("." ++ t) ||
    (s.splitOn (t ++ ".")).length > 1 && (s.startsWith (t ++ ".") || (s.splitOn ("." ++ t ++ ".")).length > 1)

def isTCS (env : Environment) (c : Name) : Option Name :=
  match env.getModuleIdxFor? c with
  | some mi => let m := env.header.moduleNames[mi.toNat]!; if (`TCSlib).isPrefixOf m then some m else none
  | none => none

syntax (name := collectCmd) "#collect " ident "[" str,* "]" : command

@[command_elab collectCmd] def elabCollect : CommandElab := fun stx => do
  let modN := stx[1].getId
  let ts : List String := (stx[3].getSepArgs.map fun s => s.isStrLit?.getD "").toList
  let env ← getEnv
  let some modIdx := env.getModuleIdx? modN | throwError "no module {modN}"
  let mut ours : Array Name := #[]
  for (n, ci) in env.constants.toList do
    if env.getModuleIdxFor? n == some modIdx && matchesTouched ts n then ours := ours.push n
  -- every touched name must be found
  for t in ts do
    if t == "*" then continue
    unless ours.any (fun n => userStr n == t || (userStr n).endsWith ("." ++ t)) do
      logWarning m!"TOUCHED-NOT-FOUND {t}"
  -- wide pass: types of all constants reached; values of own-module definitions, transitively
  let mut cs : NameSet := {}
  let mut seen : NameSet := {}
  let mut stack : List Name := []
  for n in ours do
    let some ci := env.find? n | continue
    stack := stack ++ ci.type.getUsedConstants.toList ++ ((ci.value? (allowOpaque := true)).map (·.getUsedConstants.toList) |>.getD [])
  while !stack.isEmpty do
    let c := stack.head!
    stack := stack.tail!
    if seen.contains c then continue
    seen := seen.insert c
    cs := cs.insert c
    let some cc := env.find? c | continue
    stack := stack ++ cc.type.getUsedConstants.toList
    if env.getModuleIdxFor? c == some modIdx && cc.isDefinition then
      stack := stack ++ ((cc.value? (allowOpaque := true)).map (·.getUsedConstants.toList) |>.getD [])
  let mut rows : Array String := #[]
  let mut reds : Array String := #[]
  for c in cs.toList do
    let some m := isTCS env c | continue
    if m == modN then continue
    let some cinfo := env.find? c | continue
    unless cinfo.isDefinition do continue
    let isM := (Match.Extension.getMatcherInfo? env c).isSome
    let st ← liftCoreM <| getReducibilityStatus c
    if !isM && st == .reducible then
      reds := reds.push s!"REDUCIBLE {c} | {m}"
      continue
    rows := rows.push s!"SEALROW {modN} | {c} | {m} | matcher={isM} | {repr st}"
  logInfo m!"MODULE {modN}: touched {ts.length}, constants {ours.size}, reached {cs.size}"
  for r in rows.qsort (· < ·) do logInfo m!"{r}"
  for r in reds.qsort (· < ·) do logInfo m!"{r}"

syntax (name := axsCmd) "#axs " ident "[" str,* "]" : command

/-- axioms of every touched top-level declaration of a module (private ones included) -/
@[command_elab axsCmd] def elabAxs : CommandElab := fun stx => do
  let modN := stx[1].getId
  let ts : List String := (stx[3].getSepArgs.map fun s => s.isStrLit?.getD "").toList
  let env ← getEnv
  let some modIdx := env.getModuleIdx? modN | throwError "no module {modN}"
  for t in ts do
    let mut found := false
    for (n, ci) in env.constants.toList do
      if env.getModuleIdxFor? n == some modIdx then
        let s := userStr n
        if t == "*" || s == t || s.endsWith ("." ++ t) then
          found := true
          let axs ← liftCoreM <| collectAxioms n
          let axs := axs.qsort (fun a b => a.toString < b.toString)
          logInfo m!"AXIOMS {modN} | {s} | {axs.toList}"
          logInfo m!"AXIOMSID {modN} | {n.toString} | display={s} | {axs.toList}"
          logInfo m!"G06-ROOT {(G06CombinedMetadata.rootRecord modN n ci axs).compress}"
    unless found do logWarning m!"AXIOMS-NOT-FOUND {t}"

run_cmd do
  let env ← getEnv
  let mut rows : Array (Lean.Name × Lean.Name × Lean.ConstantInfo) := #[]
  for (n, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[mi.toNat]!
    unless (`TCSlib).isPrefixOf home do continue
    rows := rows.push (n, home, ci)
  logInfo m!"G06-CATALOG-BEGIN {(Lean.Json.mkObj [("count", Lean.toJson rows.size)]).compress}"
  for (n, home, ci) in rows.qsort (fun a b => Lean.Name.lt a.1 b.1) do
    let status ← liftCoreM <| Lean.getReducibilityStatus n
    let statusText := if ci.isDefinition then G06CombinedMetadata.statusString status else "not_definition"
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    let row := Lean.Json.mkObj [
      ("name", G06CombinedMetadata.ident n), ("home", G06CombinedMetadata.ident home),
      ("kind", Lean.toJson (G06CombinedMetadata.kind ci)),
      ("status", Lean.toJson statusText), ("abbrev", Lean.toJson abbrevFlag),
      ("instance", Lean.toJson (Lean.Meta.isInstanceCore env n)),
      ("matcher", Lean.toJson ((Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome))]
    logInfo m!"G06-CATALOG {row.compress}"
  logInfo m!"G06-CATALOG-END {(Lean.Json.mkObj [("count", Lean.toJson rows.size)]).compress}"


syntax (name := closureSealCmd) "#sealclosure " ident "[" ident,* "]" : command
@[command_elab closureSealCmd] def closureSeal : CommandElab := fun stx => do
  let audited := stx[1].getId
  let deps := stx[3].getSepArgs.map Syntax.getId
  let env ← getEnv
  for dep in deps do
    unless (env.getModuleIdx? dep).isSome do throwError "missing dependency {dep}"
  let mut rows : Array String := #[]
  for (n, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[mi.toNat]!
    unless deps.contains home do continue
    unless ci.isDefinition do continue
    let matcher := (Match.Extension.getMatcherInfo? env n).isSome
    let status ← liftCoreM <| getReducibilityStatus n
    if !matcher && status == .reducible then continue
    if n == `Complexity.PolyExpr.eval then continue
    rows := rows.push s!"CLOSUREROW {audited} | {n} | {home} | matcher={matcher} | {repr status}"
  for row in rows.qsort (· < ·) do logInfo m!"{row}"

#collect TCSlib.Cryptography.Randomness.Extraction ["*"]
#axs TCSlib.Cryptography.Randomness.Extraction ["*"]
#sealclosure TCSlib.Cryptography.Randomness.Extraction [TCSlib.Complexity.ClassNP.PolyTime, TCSlib.Complexity.ClassNP.PolyTimePairing, TCSlib.Complexity.ClassP.TimeConstructible, TCSlib.Complexity.Randomized.PPT, TCSlib.Complexity.Randomized.PolyExpr, TCSlib.Complexity.TuringMachine.Build.Convention, TCSlib.Complexity.TuringMachine.Build.Embed, TCSlib.Complexity.TuringMachine.Build.Loop, TCSlib.Complexity.TuringMachine.Build.Primitives, TCSlib.Complexity.TuringMachine.Build.Wrappers, TCSlib.Complexity.TuringMachine.Composition, TCSlib.Complexity.TuringMachine.Configuration, TCSlib.Complexity.TuringMachine.Deterministic, TCSlib.Complexity.TuringMachine.Encoding, TCSlib.Complexity.TuringMachine.Finite, TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction, TCSlib.Complexity.TuringMachine.Robustness.SingleTape, TCSlib.Complexity.TuringMachine.Simulation, TCSlib.Complexity.TuringMachine.StateRenaming, TCSlib.Complexity.TuringMachine.Sweep, TCSlib.Cryptography.Asymptotic.Adversary, TCSlib.Cryptography.Foundations.Experiments, TCSlib.Cryptography.Foundations.Probability, TCSlib.InformationTheory.Entropy, TCSlib.InformationTheory.Extractors, TCSlib.InformationTheory.FinDist, TCSlib.InformationTheory.LeftoverHash, TCSlib.InformationTheory.StatisticalDistance, TCSlib.InformationTheory.UniversalHashing]
#collect TCSlib.Cryptography.Randomness.Learning ["*"]
#axs TCSlib.Cryptography.Randomness.Learning ["*"]
#sealclosure TCSlib.Cryptography.Randomness.Learning [TCSlib.Complexity.CircuitComplexity.Advice, TCSlib.Complexity.CircuitComplexity.Basic, TCSlib.Complexity.CircuitComplexity.DAGCircuit, TCSlib.Complexity.CircuitComplexity.DAGFanin, TCSlib.Complexity.CircuitComplexity.DAGTransform, TCSlib.Complexity.CircuitComplexity.LayeredCircuit, TCSlib.Complexity.CircuitComplexity.LayeredDAG, TCSlib.Complexity.CircuitComplexity.LayeredPPoly, TCSlib.Complexity.CircuitComplexity.PPoly, TCSlib.Complexity.CircuitComplexity.SizeClasses, TCSlib.Complexity.CircuitComplexity.TreeDAG, TCSlib.Complexity.ClassNP.CoNP, TCSlib.Complexity.ClassNP.CounterProgPolyTime, TCSlib.Complexity.ClassNP.NP, TCSlib.Complexity.ClassNP.PClosure, TCSlib.Complexity.ClassNP.PolyTime, TCSlib.Complexity.ClassNP.PolyTimeBlockLoop, TCSlib.Complexity.ClassNP.PolyTimeBlockMajority, TCSlib.Complexity.ClassNP.PolyTimeBlockTests, TCSlib.Complexity.ClassNP.PolyTimePairing, TCSlib.Complexity.ClassNP.PolyTimePrefix, TCSlib.Complexity.ClassP.DTIME, TCSlib.Complexity.ClassP.P, TCSlib.Complexity.ClassP.TimeConstructible, TCSlib.Complexity.PolyHierarchy.Padding, TCSlib.Complexity.Randomized.Build.IterateFind, TCSlib.Complexity.Randomized.Build.IterateFindHost, TCSlib.Complexity.Randomized.Build.PairSplit, TCSlib.Complexity.Randomized.Build.StateLoop, TCSlib.Complexity.Randomized.Build.StringLoops, TCSlib.Complexity.Randomized.Build.UnaryMul, TCSlib.Complexity.Randomized.Closure, TCSlib.Complexity.Randomized.NonUniform, TCSlib.Complexity.Randomized.PPT, TCSlib.Complexity.Randomized.PolyExpr, TCSlib.Complexity.Randomized.Primitives, TCSlib.Complexity.Randomized.Repetition, TCSlib.Complexity.TuringMachine.Build.Convention, TCSlib.Complexity.TuringMachine.Build.Embed, TCSlib.Complexity.TuringMachine.Build.EmitIterBody, TCSlib.Complexity.TuringMachine.Build.EmitIterEmbed, TCSlib.Complexity.TuringMachine.Build.Loop, TCSlib.Complexity.TuringMachine.Build.ModuleHost, TCSlib.Complexity.TuringMachine.Build.Primitives, TCSlib.Complexity.TuringMachine.Build.Wrappers, TCSlib.Complexity.TuringMachine.Composition, TCSlib.Complexity.TuringMachine.Configuration, TCSlib.Complexity.TuringMachine.CounterProg, TCSlib.Complexity.TuringMachine.CounterProgInput, TCSlib.Complexity.TuringMachine.CounterProgRun, TCSlib.Complexity.TuringMachine.Deterministic, TCSlib.Complexity.TuringMachine.Encoding, TCSlib.Complexity.TuringMachine.Finite, TCSlib.Complexity.TuringMachine.Robustness.AlphabetReduction, TCSlib.Complexity.TuringMachine.Robustness.SingleTape, TCSlib.Complexity.TuringMachine.Simulation, TCSlib.Complexity.TuringMachine.StateRenaming, TCSlib.Complexity.TuringMachine.Sweep, TCSlib.Complexity.TuringMachine.UnaryTape, TCSlib.Cryptography.Asymptotic.Adversary, TCSlib.Cryptography.Asymptotic.Collections, TCSlib.Cryptography.Asymptotic.CollectionsHelpers, TCSlib.Cryptography.Asymptotic.CollectionsLemmas, TCSlib.Cryptography.Asymptotic.Ensembles, TCSlib.Cryptography.Asymptotic.EnsemblesLemmas, TCSlib.Cryptography.Asymptotic.GGMReduction, TCSlib.Cryptography.Asymptotic.GGMReductionEval, TCSlib.Cryptography.Asymptotic.GoldreichLevinDomain, TCSlib.Cryptography.Asymptotic.HardCore, TCSlib.Cryptography.Asymptotic.HardCoreCollection, TCSlib.Cryptography.Asymptotic.HardCoreGL, TCSlib.Cryptography.Asymptotic.HardCoreGLColl, TCSlib.Cryptography.Asymptotic.HardCoreGLFamily, TCSlib.Cryptography.Asymptotic.HardCoreLemmas, TCSlib.Cryptography.Asymptotic.HardCoreLoops, TCSlib.Cryptography.Asymptotic.NextBit, TCSlib.Cryptography.Asymptotic.OneWay, TCSlib.Cryptography.Asymptotic.OneWayLemmas, TCSlib.Cryptography.Asymptotic.OneWayYao, TCSlib.Cryptography.Asymptotic.PRF, TCSlib.Cryptography.Asymptotic.PRFLemmas, TCSlib.Cryptography.Asymptotic.Pseudorandom, TCSlib.Cryptography.Asymptotic.Sampling, TCSlib.Cryptography.Foundations.Experiments, TCSlib.Cryptography.Foundations.Negligible, TCSlib.Cryptography.Foundations.Probability, TCSlib.Cryptography.Games.OracleComp, TCSlib.Cryptography.HardcoreBit.Basic, TCSlib.Cryptography.HardcoreBit.GoldreichLevin, TCSlib.Cryptography.HardcoreBit.InnerProduct, TCSlib.Cryptography.HardcoreBit.PairwiseIndependence, TCSlib.Cryptography.HardcoreBit.ThreeQuarters, TCSlib.Cryptography.OneWayFunctions.Amplification, TCSlib.Cryptography.OneWayFunctions.Basic, TCSlib.Cryptography.OneWayFunctions.OutputLength, TCSlib.Cryptography.Pseudorandom.Functions.Defs, TCSlib.Cryptography.Pseudorandom.Functions.GGM, TCSlib.Cryptography.Pseudorandom.Functions.LazySampling, TCSlib.Cryptography.Pseudorandom.Functions.OracleAdversary, TCSlib.Cryptography.Pseudorandom.Functions.SubHybrids, TCSlib.Cryptography.Pseudorandom.GeneratorFromPermutation, TCSlib.Cryptography.Pseudorandom.Generators, TCSlib.Cryptography.Pseudorandom.Indistinguishability, TCSlib.InformationTheory.FinDist, TCSlib.InformationTheory.Samples, TCSlib.InformationTheory.StatisticalDistance, TCSlib.LearningTheory.PAC, TCSlib.LearningTheory.PAC.Defs, TCSlib.LearningTheory.PAC.Prediction]
#collect TCSlib.InformationTheory.Samples ["*"]
#axs TCSlib.InformationTheory.Samples ["*"]
#sealclosure TCSlib.InformationTheory.Samples [TCSlib.InformationTheory.FinDist]
#collect TCSlib.LearningTheory.PAC.Defs ["*"]
#axs TCSlib.LearningTheory.PAC.Defs ["*"]
#sealclosure TCSlib.LearningTheory.PAC.Defs [TCSlib.InformationTheory.FinDist, TCSlib.InformationTheory.Samples]
#collect TCSlib.LearningTheory.PAC.Prediction ["*"]
#axs TCSlib.LearningTheory.PAC.Prediction ["*"]
#sealclosure TCSlib.LearningTheory.PAC.Prediction [TCSlib.InformationTheory.FinDist, TCSlib.InformationTheory.Samples, TCSlib.LearningTheory.PAC.Defs]
