#!/usr/bin/env python3
"""Compare preserved diagnostic text. Read the R2 survey and preflight as data."""

import argparse
from collections import Counter, defaultdict, deque
import difflib
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
AREA = HERE.parent
ROOT = AREA.parents[2]
EVIDENCE = AREA / "rule10-evidence-r2"
RUNS = EVIDENCE / "native-seal-runs"
PREFLIGHT = AREA / "rule10-failure-review-prep-r2/preflight"
HEAD = "a495f3953afff46ad5dec2d29ac8a7f55bd8ae37"
BASE = "067c5d8d6dd436e62681d7dc607984c705dc80a2"
PREPARATION_BASE = "eee107e92a7db11f1f8c98a5c2867304f57ddc54"
PREFLIGHT_SHA = "c5dd060a34db414fad7b163607487bf0c58d7d39e55a85c1d5f336cbf4a944db"
DRIVER_SHA = "552a6b0ed67fd5458c6eec47ae1ba1e31f5495662f1021da07119353d57aaa27"
ADAPTER_SHA = "ec264e3f9b930f2c520534d245b4ff7588b15e21e818ffa1df147b510e20f4b2"
MANUAL_SHA = "20d38dc6afd6560f16c8f3222c153bead00850cd98ba2bba8c0c41cf020b8ca5"
HEADER = re.compile(r"^(.+?\.lean):(\d+):(\d+): (error|warning|info)(?:\(([^)]*)\))?:(.*)$")
MARKER = re.compile(r"^(?:G06-(?:NAME|COMPONENT|MASK|SEAL|SEAL-END) label=|END \S+ RC -?\d+$)")
FIELDS = ("path", "probe_line", "probe_column", "error_code", "message", "log_line")


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, digest=None):
    need(path.is_file() and not path.is_symlink(), f"missing/nonordinary input {path}")
    raw = path.read_bytes()
    need(digest is None or sha(raw) == digest, f"input hash differs {path}")
    return raw


def decode(raw):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            need(key not in value, f"duplicate JSON key {key}")
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=unique)


def blob(digest):
    need(re.fullmatch("[0-9a-f]{64}", digest) is not None, "bad frozen blob identity")
    return read(PREFLIGHT / "blobs" / digest, digest)


def log_errors(raw, probe_module):
    """Keep raw diagnostics and compare their text up to the next log event."""
    rel = probe_module + ".lean"
    need(not Path(rel).is_absolute() and ".." not in Path(rel).parts, "unexpected probe module path")
    aliases = {rel, "./" + rel, str(ROOT / rel)}
    alias_pattern = "|".join(re.escape(s) for s in sorted(aliases, key=len, reverse=True))
    path_token = re.compile(r"(?<![\w./-])(?:" + alias_pattern + r")(?![\w./-])")
    lines = raw.decode().splitlines(keepends=True)
    events = []
    for index, line in enumerate(lines):
        text = line.rstrip("\r\n")
        header = HEADER.fullmatch(text)
        if header or MARKER.match(text):
            events.append((index, header))
    errors = {}
    for (index, header), (stop, _) in zip(events, events[1:]):
        if header is None or header[4] != "error":
            continue
        need(header[1] in aliases, f"error belongs to different probe {header[1]}")
        continuation = "".join(lines[index + 1:stop])
        errors[index + 1] = {
            "path": header[1], "probe_line": int(header[2]), "probe_column": int(header[3]),
            "error_code": header[5] or None, "message": header[6].strip(), "log_line": index + 1,
            "raw": "".join(lines[index:stop]), "continuation": continuation,
            "normalized_message": path_token.sub("<PROBE_FILE>", header[6].strip()),
            "normalized_continuation": path_token.sub("<PROBE_FILE>", continuation.rstrip("\r\n")),
            "next_event_log_line": stop + 1,
        }
    need(not events or events[-1][1] is None or events[-1][1][4] != "error",
         "last error lacks a continuation boundary")
    return errors


def envelope(units, agreement=True):
    keys = ("canonical_parts", "start_line", "declaration_line", "end_line", "raw_sha256",
            "lexical_boundaries_need_review", "namespace_context_ambiguous", "mapping_warnings")
    candidates = [{key: unit.get(key) for key in keys} for unit in units]
    safe = (agreement and len(units) == 1 and units[0].get("canonical_parts") and
            not units[0]["lexical_boundaries_need_review"] and not units[0]["namespace_context_ambiguous"])
    return {"status": "UNIQUE_R2_SOURCE_ENVELOPE" if safe else "UNRESOLVED",
            "components": units[0]["canonical_parts"] if safe else None, "candidates": candidates}


def row(side, owner, file, ref, label, log_sha, diagnostic, errors, source_envelope):
    item = errors[diagnostic["log_line"]]
    need(all(item[key] == diagnostic[key] for key in FIELDS), f"raw diagnostic differs at {label}:{diagnostic['log_line']}")
    return {
        "id": f"{side}:{owner}:{log_sha}:{diagnostic['log_line']}", "side": side,
        "owner": owner, "file": file, "ref": ref, "label": label, "log_sha256": log_sha,
        "diagnostic": diagnostic, "envelope": source_envelope, **item,
    }


def historical(preflight, modules):
    rows, cache, seen = [], {}, defaultdict(set)
    roots = decode(read(PREFLIGHT / "prior-witnesses.json", preflight["files"]["prior-witnesses.json"]))
    for witness in roots["historical_roots"]:
        for observation in witness["observations"]:
            if observation["role"] != "Head":
                continue
            log_sha = observation["raw_log_sha256"]
            owner, file = observation["module"], observation["file"]
            need(modules[owner] == file, "historical owner/file differs")
            if log_sha not in cache:
                result = decode(blob(observation["native_result_sha256"]))
                need(result["label"] == observation["label"] and result["source_sha256"] == observation["probe_sha256"],
                     "historical native receipt differs")
                cache[log_sha] = log_errors(blob(log_sha), result["module"])
                need(len(cache[log_sha]) == result["error_diagnostics"], "historical error count differs")
            diagnostic = observation["diagnostic"]
            need(diagnostic["log_line"] not in seen[log_sha], "duplicate historical observation")
            seen[log_sha].add(diagnostic["log_line"])
            candidates = [x["unit"] for x in observation["source_envelope_candidates"]]
            agreement = observation["source_mapping_status"] == "UNIQUE_LEXICAL_LINE_AND_SOURCE_KEY_AGREEMENT"
            item = row("prior", owner, file, observation["ref"], observation["label"], log_sha,
                       diagnostic, cache[log_sha], envelope(candidates, agreement))
            item["historical_epoch"] = observation["epoch"]
            rows.append(item)
    need(len(rows) == 145 and all(seen[h] == set(errors) for h, errors in cache.items()),
         "historical head diagnostic census differs")
    return rows


def current(probes, indices, config_sha, partial_through):
    summary = None
    if partial_through is None:
        summary = decode(read(RUNS / "summary.json"))
        need(summary["complete"] and summary["aborted_reason"] is None and
             summary["completed_probes"] == summary["expected_probes"] == len(probes) and
             summary["head"] == HEAD and summary["base"] == PREPARATION_BASE and
             summary["configuration_sha256"] == config_sha, "complete R2 summary required")
        expected = {record["label"]: record for record in summary["results"]}
        need(len(summary["results"]) == len(expected) == len(probes) and
             set(expected) == {p["label"] for p in probes}, "summary scope differs")
    else:
        need(1 <= partial_through <= len(probes), "invalid partial prefix")
        probes = probes[:partial_through]
    rows, valid, harness = [], set(), []
    for probe in probes:
        label, owner = probe["label"], probe["module"]
        classification = RUNS / (label + ".classification.json")
        raw = read(classification)
        record = decode(raw)
        need(record["label"] == label and record["module"] == owner and record["kind"] == "seals",
             "classification owner/label differs")
        if summary is not None:
            need(record == expected[label], "classification differs from complete summary")
        if not record.get("valid_harness"):
            harness.append({"classification_sha256": sha(raw), "record": record})
            continue
        valid.add(owner)
        attempt = RUNS / "probes" / label
        log_path, result_path = attempt / (label + ".log"), attempt / (label + ".json")
        need(record["log"] == str(log_path) and record["result_path"] == str(result_path),
             "unexpected classified attempt path")
        result = decode(read(result_path, record["result_json_sha256"]))
        need(result == record["result"] and result["module"] == probe["probe_module"] and
             result["label"] == label and result["source_sha256"] == probe["probe_sha256"] and
             record["captured_probe_sha256"] == probe["probe_sha256"], "classified receipt/probe differs")
        errors = log_errors(read(log_path, record["log_sha256"]), result["module"])
        need(len(errors) == len(record["errors"]) == result["error_diagnostics"], "current error count differs")
        need({d["log_line"] for d in record["errors"]} == set(errors), "current raw error set differs")
        need(record["source_failure"] is bool(errors) and result["rc"] == int(bool(errors)),
             "source outcome differs from diagnostic evidence")
        inverse = {x["probe_line"]: x["source_line"] for x in probe["source_to_probe_lines"]}
        need(len(inverse) == len(probe["source_to_probe_lines"]), "ambiguous probe line map")
        for diagnostic in record["errors"]:
            source_line = diagnostic["source_line"]
            need(inverse[diagnostic["probe_line"]] == source_line and
                 diagnostic["classification"] == "SOURCE_FAILURE_REQUIRES_REVIEW", "source mapping differs")
            units = [u for u in indices[owner]["head"]["units"] if u["start_line"] <= source_line <= u["end_line"]]
            rows.append(row("R2", owner, probe["source"], HEAD, label, record["log_sha256"],
                            diagnostic, errors, envelope(units)))
    if summary is not None:
        need(len(rows) == summary["source_error_diagnostics"] and len(harness) == summary["harness_failures"],
             "complete summary counts differ")
    return rows, valid, harness


def signature(row):
    return (row["error_code"], row["normalized_message"], row["normalized_continuation"])


def site(row):
    unit = row["envelope"]["candidates"][0]
    return (row["diagnostic"]["source_line"] - unit["declaration_line"], row["probe_column"])


def change(old, new, basis):
    old_sig, new_sig = signature(old), signature(new)
    difference = "\n".join(difflib.unified_diff(
        (old_sig[1] + "\n" + old_sig[2]).splitlines(), (new_sig[1] + "\n" + new_sig[2]).splitlines(),
        fromfile="prior", tofile="R2", lineterm="",
    ))
    return {"prior": old["id"], "R2": new["id"], "basis": basis,
            "error_code_changed": old_sig[0] != new_sig[0], "message_changed": old_sig[1] != new_sig[1],
            "continuation_changed": old_sig[2] != new_sig[2], "text_diff": difference}


def compare(old, new, valid):
    groups = defaultdict(lambda: {"prior": [], "R2": []})
    unresolved = {"prior": [], "R2": []}
    pending = []
    for item in old + new:
        if item["owner"] not in valid:
            pending.append(item["id"])
        elif item["envelope"]["components"] is None:
            unresolved[item["side"]].append(item)
        else:
            groups[(item["owner"], tuple(item["envelope"]["components"]))][item["side"]].append(item)
    result = {"unchanged": [], "changed": [], "added": [], "removed": [], "ambiguous": [],
              "unresolved": {side: [r["id"] for r in rows] for side, rows in unresolved.items()},
              "not_compared": pending}
    unresolved_owners = {side: {r["owner"] for r in rows} for side, rows in unresolved.items()}
    for (owner, parts), group in sorted(groups.items()):
        old_by_text = defaultdict(deque)
        for item in group["prior"]:
            old_by_text[signature(item)].append(item)
        new_left = []
        for item in group["R2"]:
            matches = old_by_text[signature(item)]
            if matches:
                matched = next((old_row for old_row in matches if site(old_row) == site(item)), matches[0])
                matches.remove(matched)
                result["unchanged"].append({"prior": matched["id"], "R2": item["id"]})
            else:
                new_left.append(item)
        old_left = [item for matches in old_by_text.values() for item in matches]
        old_sites, new_sites = Counter(map(site, old_left)), Counter(map(site, new_left))
        unique = {site(item): item for item in old_left if old_sites[site(item)] == new_sites[site(item)] == 1}
        paired = [item for item in new_left if site(item) in unique]
        for item in paired:
            result["changed"].append(change(unique[site(item)], item, "unique envelope-relative source site"))
        old_left = [item for item in old_left if site(item) not in unique]
        new_left = [item for item in new_left if site(item) not in unique]
        if len(old_left) == len(new_left) == 1:
            result["changed"].append(change(old_left.pop(), new_left.pop(), "single residual on each side of envelope"))
        ambiguous = ((old_left and new_left) or (old_left and owner in unresolved_owners["R2"]) or
                     (new_left and owner in unresolved_owners["prior"]))
        if ambiguous:
            result["ambiguous"].append({"owner": owner, "components": parts,
                                        "prior": [r["id"] for r in old_left], "R2": [r["id"] for r in new_left]})
        else:
            result["removed"].extend(item["id"] for item in old_left)
            result["added"].extend(item["id"] for item in new_left)
    return result


def check_accounting(rows, comparison):
    accounted = Counter(comparison["added"] + comparison["removed"] + comparison["not_compared"])
    for pair in comparison["unchanged"] + comparison["changed"]:
        accounted.update((pair["prior"], pair["R2"]))
    for group in comparison["ambiguous"] + [comparison["unresolved"]]:
        accounted.update(group["prior"] + group["R2"])
    need(len(accounted) == len(rows) and accounted == Counter(item["id"] for item in rows),
         "diagnostic comparison omitted or duplicated a row")


def manual_candidates(rows, preflight):
    manual = decode(read(AREA / "unaryMul-poly-manual-boundary-r1.json", MANUAL_SHA))
    snapshots = decode(read(PREFLIGHT / "source-snapshots.json", preflight["files"]["source-snapshots.json"]))
    candidates = {"prior": [], "R2": []}
    for item in rows:
        if item["file"] != manual["source"] or item["envelope"]["status"] != "UNRESOLVED":
            continue
        evidence = manual["source_evidence"].get(item["ref"])
        if evidence is None:
            continue
        first, last = evidence["range"]
        if not first <= item["diagnostic"]["source_line"] <= last:
            continue
        source_sha = snapshots[item["ref"]]["sources"][item["file"]]["sha256"]
        source = blob(source_sha).decode().splitlines(keepends=True)
        block = "".join(source[first - 1:last])
        need(source_sha == evidence["source_sha256"] and sha(block.encode()) == evidence["raw_block_sha256"] and
             block == evidence["header"] + " := by\n" + evidence["body"], "manual candidate bytes differ")
        need(any(u["raw_sha256"] == evidence["raw_block_sha256"] and
                 ".".join(u["canonical_parts"] or ()) == manual["expected_name"]
                 for u in item["envelope"]["candidates"]), "manual candidate and generic envelope differ")
        candidates[item["side"]].append(item)
    comparison = None
    if len(candidates["prior"]) == len(candidates["R2"]) == 1:
        comparison = change(candidates["prior"][0], candidates["R2"][0], "explicit manual candidate only")
    return {"status": "MANUAL_CANDIDATE_GENERIC_RESULT_RETAINED", "input_sha256": MANUAL_SHA,
            "expected_name": manual["expected_name"], "candidate_rows": {
                side: [item["id"] for item in selected] for side, selected in candidates.items()
            }, "candidate_text_comparison": comparison}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--partial-through", type=int, help="smoke test against this completed ordinal prefix")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    need(output.parent == HERE and not output.exists(), "fresh output alongside comparison helper required")
    preflight = decode(read(PREFLIGHT / "preflight-manifest.json", PREFLIGHT_SHA))
    indices = decode(read(PREFLIGHT / "all59-source-envelope-indices.json",
                          preflight["files"]["all59-source-envelope-indices.json"]))
    cfg_raw = read(RUNS / "configuration.json")
    cfg = decode(cfg_raw)
    need(cfg["head"] == preflight["head"] == HEAD and preflight["actual_PRbase"] == BASE and
         cfg["base"] == PREPARATION_BASE and cfg["adapter_sha256"] == ADAPTER_SHA and
         cfg["evidence_directory"] == str(EVIDENCE) and cfg["driver_sha256"] == DRIVER_SHA, "unexpected R2 epoch")
    read(RUNS / "driver.source.txt", DRIVER_SHA)
    adapter = decode(read(EVIDENCE / "final-adapter.json", ADAPTER_SHA))
    modules = decode(read(EVIDENCE / "modules.json", cfg["inputs"][str(EVIDENCE / "modules.json")]))
    manifest = decode(read(EVIDENCE / "seal-manifest.json", adapter["seal_manifest_sha256"]))
    probes = manifest["probes"]
    need(len(probes) == len(modules) == len(indices) == 59 and
         [p["module"] for p in probes] == sorted(modules) == cfg["modules"] and set(indices) == set(modules) and
         [p["ordinal"] for p in probes] == list(range(1, 60)), "R2 owner scope/order differs")
    need(all(p["source"] == modules[p["module"]] and
             p["probe_module"] == cfg["scratch_relative"] + "/seals/" + p["label"] for p in probes),
         "R2 owner/probe path differs")
    old = historical(preflight, modules)
    new, valid, harness = current(probes, indices, sha(cfg_raw), args.partial_through)
    comparison = compare(old, new, valid)
    check_accounting(old + new, comparison)
    report = {
        "status": "PARTIAL_SMOKE" if args.partial_through is not None else "COMPLETE_TEXT_COMPARISON",
        "head": HEAD, "actual_PRbase": BASE, "configuration_sha256": sha(cfg_raw),
        "helper_sha256": sha(Path(__file__).read_bytes()), "partial_through": args.partial_through,
        "frozen_preflight_sha256": PREFLIGHT_SHA, "valid_compared_owners": sorted(valid),
        "prior_head_diagnostics": len(old), "current_source_diagnostics": len(new),
        "counts": {key: len(value) for key, value in comparison.items() if key != "unresolved"},
        "comparison": comparison, "unresolved_counts": {key: len(value) for key, value in comparison["unresolved"].items()},
        "unresolved_envelopes_in_all_rows": sum(item["envelope"]["status"] == "UNRESOLVED" for item in old + new),
        "manual_candidate": manual_candidates(old + new, preflight), "harness_records": harness,
        "rows": {item["id"]: item for item in old + new},
        "limits": [
            "Compares diagnostic text within verified owner and lexical source envelope.",
            "Only exact probe-file aliases and trailing continuation line terminators are normalized.",
            "Raw rows retain the header and every continuation line up to the next recognized log event.",
            "Removal means absent from the completed comparable observations. Operative dependency review remains separate.",
            "Manual candidate rows retain unresolved generic mappings and stay outside automatic comparison counts.",
        ],
    }
    with output.open("x") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps({key: report[key] for key in (
        "status", "prior_head_diagnostics", "current_source_diagnostics", "counts", "unresolved_counts"
    )}, indent=2))


if __name__ == "__main__":
    main()
