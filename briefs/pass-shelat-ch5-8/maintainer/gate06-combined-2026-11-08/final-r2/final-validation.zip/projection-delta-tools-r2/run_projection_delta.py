"""Replay the approved probability projections and their native dependent closure."""

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys

HERE = Path(__file__).resolve().parent
AREA = HERE.parent
ROOT = AREA.parents[2]
OLD = "a495f3953afff46ad5dec2d29ac8a7f55bd8ae37"
EXTRACTION = "TCSlib/Cryptography/Randomness/Extraction"
SAMPLES = "TCSlib/InformationTheory/Samples"
PATCHES = {
    EXTRACTION: ("extraction-explicit-prob-proposal-r1", "640704908689737af006e8d2c28ece74c2ae8d79b3f1a11b4e48936e344c5ee5",
                 "ExtractionExplicitProbCandidate"),
    SAMPLES: ("samples-explicit-prob-proposal-r1", "67d09a767a7d4a07fe81e17444ff904fde10deeba9a82977234405a4d39d6a72",
              "SamplesExplicitProbCandidate"),
}
HEAD = "54ee105020f24d6de08aba62a1914dbeb723d87c"
LOCAL = AREA / "native-local-resume-r1"
OLD_TREE = AREA / "oleans-r1"
OUT = AREA / "projection-delta-native-r2"
TREE = OUT / "oleans"
PROPOSAL = AREA / "extraction-explicit-prob-proposal-r1"
CHECKER = ROOT / "scripts/lean_check_tree.sh"
SAMPLES_PROPOSAL = AREA / "samples-explicit-prob-proposal-r1"
EVIDENCE = AREA / "rule10-evidence-r2"
EXPECTED_AFFECTED = {
    EXTRACTION, SAMPLES, "TCSlib/Cryptography/Randomness/Learning", "TCSlib/Cryptography/Randomness",
    "TCSlib/InformationTheory", "TCSlib/LearningTheory/PAC/Defs", "TCSlib/LearningTheory/PAC/Prediction",
    "TCSlib/LearningTheory/PAC", "TCSlib",
}
ERROR = re.compile(rb"\.lean:\d+:\d+: error(?:\([^\n)]*\))?:")
PINS = {
    LOCAL / "RESULT.json": "6a019e8051ef7deceae8fec3fd9ac53698e43985c7fe9f86d4e7b1d0ab12e656",
    LOCAL / "local-records.json": "8c59fdcd4066eda738aa30422474ffb38912b4d0fb2ea514b18fb5ae033ee9dc",
    LOCAL / "external-final.json": "9ae25d17d062321af3fd766acdbb01a73cbd03a2fa92172575250910361ff0fd",
    LOCAL / "source-start.json": "7f606ceb1c33a018ef833ee779457f0e447d334b442acab746b4a8899f82191c",
    CHECKER: "366dab40e8e8f0f13e14118e14c3d6be1bc1b36604e6c9ccdebb03bc96cdf335",
    ROOT / "lean-toolchain": "dbbf063fc415c8e718172605f23a8f86679a3c320eff6d3890cc009534452925",
    ROOT / "lake-manifest.json": "cad7de215c4cc216d03acb77cb1abfbe9f3b4062a8988b29459504f932015100",
    AREA / "pfr-runtime-r1/config.json": "4d1a6453a3586f5263628712ad15ab734514a04bbe65e10c1c468f70bb0c8c16",
    PROPOSAL / "USER-RULING-AND-CANDIDATE.json": "02bb6b29b380cd8da492ed082207bfdc7cf829e5485dabaa1400bcfdee04eb57",
    PROPOSAL / "canonical-preview/RESULT.json": "6cb543ab98632711e81f57947839103497f0a3096510fe7ba2566356f383bd99",
    PROPOSAL / "ExtractionExplicitProbCandidate.lean": "c68eab1fdda34551413ed177309889ac094b973087b11c6976c6583db9024eeb",
    SAMPLES_PROPOSAL / "USER-RULING-AND-CANDIDATE.json": "293ddce7734f8c07acf786051fb20075f45f10881abcc8a2cb73a9b1c16b6767",
    SAMPLES_PROPOSAL / "SamplesExplicitProbCandidate.lean": "c49302b2431e42122b236631c7f991a5146b9e579281d03f4de575856c5d7b04",
    EVIDENCE / "final-adapter.json": "ec264e3f9b930f2c520534d245b4ff7588b15e21e818ffa1df147b510e20f4b2",
    AREA / "rule10-r1/Collect.lean": "5654cc5a325f746a5d1fc7c7d3076cd0df4e46415be2866edf50e542ed110929",
    AREA / "rule10-r1/C3.lean": "cc5fe3368699617a5dac05d1f84462c4819f0d5e487792afca1a39886ed1eb2a",
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open("x") as f:
        f.write(json.dumps(value, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def resources():
    raw = subprocess.check_output(["/usr/bin/memory_pressure", "-Q"], text=True)
    total = int(re.search(r"system has (\d+)", raw)[1])
    free = int(re.search(r"memory free percentage:\s*(\d+)%", raw)[1])
    disk = shutil.disk_usage(ROOT).free
    headroom = total * max(free - 1, 0) // 100
    need(headroom >= 4 * 1024**3 and disk >= 12 * 1024**3, "resource floor")
    return {"memory_headroom_bytes": headroom, "disk_free_bytes": disk}


def copy_object(source, target, digest):
    need(sha(source) == digest, f"wrong prior object {source}")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    need(sha(target) == digest and not target.samefile(source), f"object copy differs {target}")


def stop(signum, _frame):
    raise InterruptedError(f"delta run interrupted by signal {signum}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--effective-sha256", required=True)
    args = parser.parse_args()
    effective_path = AREA / "rule10-payload-retry-r3/effective-results.json"
    need(sha(effective_path) == args.effective_sha256, "old effective selection hash differs")
    effective = read(effective_path)
    need(effective["status"] == "ALL_EFFECTIVE_HARNESSES_VALID" and effective["head"] == OLD and
         effective["completed_probes"] == 59 and not (AREA / "native-runner.lease.json").exists(),
         "previous verification is incomplete or still running")
    need(Path.cwd().resolve() == ROOT and not OUT.exists(), "run from the worktree with a fresh output")
    head = git("rev-parse", "HEAD")
    need(head == HEAD and git("rev-parse", "HEAD^") == OLD and
         set(git("diff-tree", "--no-commit-id", "--name-only", "-r", head).splitlines()) ==
         {module + ".lean" for module in PATCHES}, "final commit is not the two approved source edits")
    sources = read(LOCAL / "source-start.json")
    for module, (proposal, digest, _) in PATCHES.items():
        current = ROOT / (module + ".lean")
        candidate = AREA / proposal / "candidate-owner.source.txt"
        need(sha(current) == digest == sha(candidate), f"unexpected approved source bytes {module}")
        sources[module + ".lean"] = digest
    records = read(LOCAL / "local-records.json")
    external = read(LOCAL / "external-final.json")
    config = read(AREA / "pfr-runtime-r1/config.json")
    real_lean = Path(config["real_lean"])
    need(len(records) == 1075 and len(external) == 3810 and len(sources) == 1109, "prior scope differs")
    affected = set(PATCHES)
    while True:
        expanded = affected | {n for n, r in records.items() if set(r["direct_local_object_sha256"]) & affected}
        if expanded == affected:
            break
        affected = expanded
    need(affected == EXPECTED_AFFECTED, "unexpected dependent closure")
    pending = set(affected)
    replay = []
    while pending:
        ready = sorted(n for n in pending if not set(records[n]["direct_local_object_sha256"]) & pending)
        need(ready, "dependency order did not progress")
        replay.extend(ready)
        pending.difference_update(ready)

    def verify_sources():
        need(git("rev-parse", "HEAD") == head and not git("status", "--porcelain", "--untracked-files=no"),
             "source head changed or tracked files are dirty")
        need(not (ROOT / ".lake/build/lib/lean").exists(), "unexpected fallback tree")
        actual = {p.relative_to(ROOT).as_posix() for p in (ROOT / "TCSlib").rglob("*.lean")} | {"TCSlib.lean", "audits/pass-shelat/Checks.lean"}
        need(set(sources) == actual, "library source scope changed")
        for path, digest in sources.items():
            need(sha(ROOT / path) == digest, f"library source changed {path}")
        for path, digest in PINS.items():
            need(sha(path) == digest, f"pinned input changed {path}")
        need(sha(real_lean) == config["real_lean_sha256"], "Lean binary changed")
        need(sha(effective_path) == args.effective_sha256, "old selection changed")

    verify_sources()
    OUT.mkdir()
    probe_dir = OUT / "probes"
    probe_dir.mkdir()
    write(OUT / "START.json", {"head": head, "parent": OLD, "pid": os.getpid(), "tree": str(TREE),
                              "runner_sha256": sha(Path(__file__)), "utc": now(),
                              "original_effective_sha256": args.effective_sha256, "source_files": sources,
                              "resources": resources()})
    for name, row in records.items():
        copy_object(OLD_TREE / (name + ".olean"), TREE / (name + ".olean"), row["object_sha256"])
    for name, row in external.items():
        origin = Path(row["object_path"])
        if row["kind"] == "PFR_OWN_TREE":
            copy_object(origin, TREE / ".lake/packages/PFR" / (name.replace(".", "/") + ".olean"), row["object_sha256"])
        else:
            need(sha(origin) == row["object_sha256"], f"external object changed {name}")
    (TREE / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

    adapter = read(EVIDENCE / "final-adapter.json")
    manifest_path = EVIDENCE / "seal-manifest.json"
    need(sha(manifest_path) == adapter["seal_manifest_sha256"], "prior seal manifest differs")
    manifest = read(manifest_path)
    affected_seals = [p for p in manifest["probes"] if p["module"].replace(".", "/") in affected]
    need(len(affected_seals) == 5 and len(manifest["probes"]) == 59, "affected math scope differs")
    commands = ("#collect ", "#axs ", "#sealclosure ")
    owners = {p["module"] for p in affected_seals}
    collector = (AREA / "rule10-r1/Collect.lean").read_text().splitlines(keepends=True)
    delta_rows = [line for line in collector if not line.startswith(commands) or
                  any(line.startswith(prefix + module + " ") for prefix in commands for module in owners)]
    need(sum(line.startswith(commands) for line in delta_rows) == 3 * len(owners), "delta collector scope differs")
    (probe_dir / "ProjectionCensus.lean").write_text("".join(delta_rows))
    c3 = (AREA / "rule10-r1/C3.lean").read_text()
    need(c3.count(OLD) == 2, "unexpected C3 source pins")
    (probe_dir / "FinalC3.lean").write_text(c3.replace(OLD, head))
    sealed = []
    for p in affected_seals:
        module = p["module"].replace(".", "/")
        if module in PATCHES:
            proposal, digest, label = PATCHES[module]
            directory = AREA / proposal
            prepared = read(directory / "PREPARATION.json")
            raw = (directory / (label + ".lean")).read_bytes()
            insertions = prepared["seal_insertions"]
            need(sha(directory / (label + ".lean")) == prepared["candidate_probe_sha256"], "approved probe differs")
        else:
            label = p["label"]
            raw = Path(p["saved_source"]).read_bytes()
            digest, insertions = p["source_sha256"], p["insertions"]
            need(hashlib.sha256(raw).hexdigest() == p["probe_sha256"], "retained probe differs")
        recovered = raw
        for item in reversed(insertions):
            pos, count = item["probe_byte_offset"], item["byte_count"]
            need(hashlib.sha256(recovered[pos:pos + count]).hexdigest() == item["sha256"], "probe insertion differs")
            recovered = recovered[:pos] + recovered[pos + count:]
        need(recovered == (ROOT / p["source"]).read_bytes() and hashlib.sha256(recovered).hexdigest() == digest,
             "prepared probe does not restore the final source")
        target = probe_dir / f"Seal{p['ordinal']:03d}.lean"
        target.write_bytes(raw)
        sealed.append({"owner": p["module"], "ordinal": p["ordinal"], "label": label,
                       "probe": target.relative_to(ROOT).with_suffix("").as_posix(),
                       "probe_sha256": sha(target), "requested_count": p["requested_count"]})
    write(OUT / "seal-inputs.json", {"head": head, "prior_seal_manifest_sha256": sha(manifest_path), "probes": sealed})
    env = os.environ.copy()
    for name in ("LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LEAN_OPTS", "ELAN_TOOLCHAIN", "PFR_BOOTSTRAP_CONFIG"):
        env.pop(name, None)
    env["PATH"] = str(real_lean.parent) + ":/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
    env["TCSLIB_OLEANS"] = str(TREE)
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, stop)
    steps = (*replay, "audits/pass-shelat/Checks", *(r["probe"] for r in sealed),
             *((probe_dir / name).relative_to(ROOT).as_posix() for name in ("ProjectionCensus", "FinalC3")))
    results = []
    for index, name in enumerate(steps, 1):
        label = f"{index:02d}-{name.rsplit('/', 1)[-1]}"
        source = ROOT / (name + ".lean")
        digest = sha(source)
        log = OUT / (label + ".log")
        obj = TREE / (name + ".olean")
        direct = records.get(name, {}).get("direct_local_object_sha256", {})
        direct_now = {n: sha(TREE / (n + ".olean")) for n in direct}
        started = dt.datetime.now(dt.timezone.utc)
        resources()
        with log.open("xb") as stream:
            proc = subprocess.Popen(["bash", str(CHECKER), name], cwd=ROOT, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                write(OUT / (label + ".child.json"), {"pid": proc.pid, "pgid": proc.pid, "module": name})
                rc = proc.wait()
            except BaseException:
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
                raise
        ended = now()
        errors = len(ERROR.findall(log.read_bytes()))
        result = {"module": name, "source_sha256": digest, "rc": rc, "error_diagnostics": errors,
                  "started": started.isoformat(), "ended": ended, "log_sha256": sha(log),
                  "object_sha256": sha(obj) if obj.is_file() else None,
                  "direct_local_objects": direct_now, "resources": resources()}
        write(OUT / (label + ".json"), result)
        need(rc == errors == 0 and obj.is_file() and obj.stat().st_size > 0 and
             obj.stat().st_mtime >= started.timestamp() and sha(source) == digest, f"native delta step failed {name}")
        results.append(result)
        print(f"DELTA PASS {index}/{len(steps)} {name}", flush=True)

    verify_sources()
    rebuilt = {r["module"]: r["object_sha256"] for r in results if r["module"] in records}
    for name, record in records.items():
        need(sha(TREE / (name + ".olean")) == rebuilt.get(name, record["object_sha256"]), f"changed local object {name}")
    for name, row in external.items():
        path = (TREE / (name.replace(".", "/") + ".olean")
                if row["kind"] == "PFR_OWN_TREE" else Path(row["object_path"]))
        need(sha(path) == row["object_sha256"], f"changed final external object {name}")
    write(OUT / "RESULT.json", {"status": "NATIVE_PROJECTION_DELTA_CHECKS_PASSED", "head": head, "parent": OLD,
          "tree": str(TREE), "original_effective_sha256": args.effective_sha256, "rebuilt_local": sorted(rebuilt),
          "retained_local_objects": len(records) - len(rebuilt), "verified_external_objects": len(external),
          "affected_dependency_closure": sorted(affected), "affected_math_owners": sorted(owners),
          "seal_inputs_sha256": sha(OUT / "seal-inputs.json"), "results": results})


if __name__ == "__main__":
    main()
