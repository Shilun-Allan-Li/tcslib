"""Reconcile the new Lean objects, five current seals and complete root metadata."""

from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
AREA = HERE.parent
ROOT = AREA.parents[2]
DELTA = AREA / "projection-delta-native-r2"
EVIDENCE = AREA / "rule10-evidence-r2"
INPUTS = AREA / "rule10-r2-kind/scan-inputs-effective-r3"
HEAD = "54ee105020f24d6de08aba62a1914dbeb723d87c"
OLD = "a495f3953afff46ad5dec2d29ac8a7f55bd8ae37"
BASE = "067c5d8d6dd436e62681d7dc607984c705dc80a2"
TOOLS = AREA / "rule10-prep/proposed-tools"
EXPECTED_REPAIRS = {
    "TCSlib.Cryptography.Randomness.Extraction": 2,
    "TCSlib.InformationTheory.Samples": 9,
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def read(path, expected=None):
    need(expected is None or sha(path) == expected, f"changed input {path}")
    return json.loads(path.read_bytes())


def load(path, expected, name):
    need(sha(path) == expected, f"tool pin changed {path}")
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def main():
    need(git("rev-parse", "HEAD") == HEAD and git("rev-parse", "HEAD^") == OLD and not git("status", "--porcelain"),
         "final source changed")
    result_path = DELTA / "RESULT.json"
    result = read(result_path)
    tree = Path(result["tree"])
    need(result["status"] == "NATIVE_PROJECTION_DELTA_CHECKS_PASSED" and result["head"] == HEAD and
         result["parent"] == OLD and len(result["results"]) == 17 and len(result["rebuilt_local"]) == 10 and
         result["retained_local_objects"] == 1065 and result["verified_external_objects"] == 3810 and
         tree == DELTA / "oleans", "final native result scope differs")
    logs = {}
    for index, row in enumerate(result["results"], 1):
        label = f"{index:02d}-{row['module'].rsplit('/', 1)[-1]}"
        log = DELTA / (label + ".log")
        need(row["rc"] == row["error_diagnostics"] == 0 and read(DELTA / (label + ".json")) == row and
             row["log_sha256"] == sha(log) and row["source_sha256"] == sha(ROOT / (row["module"] + ".lean")) and
             row["object_sha256"] == sha(tree / (row["module"] + ".olean")), "delta native attempt changed")
        logs[row["module"]] = log
    changed_objects = set(result["affected_dependency_closure"])
    adapter = read(EVIDENCE / "final-adapter.json", "ec264e3f9b930f2c520534d245b4ff7588b15e21e818ffa1df147b510e20f4b2")
    manifest = read(EVIDENCE / "seal-manifest.json", adapter["seal_manifest_sha256"])
    modules = read(EVIDENCE / "modules.json")
    closures = read(EVIDENCE / "closures.json")
    by_owner = {p["module"]: p for p in manifest["probes"]}
    effective = read(AREA / "rule10-payload-retry-r3/effective-results.json", result["original_effective_sha256"])
    need(effective["status"] == "ALL_EFFECTIVE_HARNESSES_VALID" and effective["head"] == OLD and
         len(effective["selected"]) == len(modules) == 59, "original effective result differs")
    fresh_inputs = read(DELTA / "seal-inputs.json", result["seal_inputs_sha256"])
    fresh_owners = {p["owner"] for p in fresh_inputs["probes"]}
    need(fresh_owners == set(result["affected_math_owners"]) and len(fresh_owners) == 5 and
         {m for m in modules if {m, *closures[m]} & {n.replace("/", ".") for n in changed_objects}} == fresh_owners,
         "affected seal owner scope differs")
    retained = set(modules) - fresh_owners
    need(all(sha(ROOT / modules[m]) == by_owner[m]["source_sha256"] for m in retained), "retained sealed source changed")
    controls = read(EVIDENCE / "controls-manifest.json", adapter["controls_manifest_sha256"])
    control_summary = read(EVIDENCE / "native-control-runs/summary.json",
                           "9e578f5630408861c485875a49840ad758be05966e46910fc4bf14b1c2108d78")
    need(control_summary["all_controls_verified"] and control_summary["completed_probes"] == 13 and
         not {m.replace(".", "/") for m in controls["import_closure"] + [controls["audited_module"]]} & changed_objects,
         "retained controls have a changed source/object dependency")

    payload = load(TOOLS / "request_payload_adapter.py", "b9a8f8160b5e21a9b60025bde167583b962a8ec038d0902618e7456566bbc066", "g06_metadata")
    mask = load(AREA / "rule10-final-tools-r2/request_payload_adapter.py", "9a8fee882126a1702fd2af07c5184d303f83c9d119cd36a31badedc6cf462e94", "g06_mask")
    bs = load(TOOLS / "build_seals.py", "ecb8ff2359d36e9182b83ae318eabe4dd9d23c3dec4b0bbe8406ad9787421fb5", "g06_seals")
    helpers = load(TOOLS / "s2_native_seal_driver.py", "0c58a5d287dd1487dc5bbda47283ad4ab9e3c5fe0ba50e9c902c369df55fa7e8", "g06_probe_checks")
    census = load(AREA / "rule10-prep/validate_combined_census.py",
                  "488491b8ab717382d6ce798ce6726cbcf2994124debeac3f10d476ea908a3bab", "g06_census")
    old_log = (EVIDENCE / "collect1.log").read_text()
    new_log = next(p for m, p in logs.items() if m.endswith("/ProjectionCensus")).read_text()
    catalog, roots = payload.catalog_and_roots(old_log, modules)
    fresh_modules = {m: modules[m] for m in sorted(fresh_owners)}
    fresh_closures = {m: closures[m] for m in fresh_modules}
    new_catalog, delta_roots = payload.catalog_and_roots(new_log, fresh_modules)
    need(new_catalog == catalog, "current full TCSlib name/kind/home catalog differs")
    _, requests, _ = payload.enrich_rows(bs.collector_rows, new_log, fresh_modules, fresh_closures)
    fresh = []
    for p in fresh_inputs["probes"]:
        m, label = p["owner"], p["label"]
        old = by_owner[m]
        rows = [requests[m][n] for n in sorted(requests[m])]
        semantic_row = lambda row: {key: value for key, value in row.items() if key != "collector_log_line"}
        need([semantic_row(row) for row in rows] == [semantic_row(row) for row in old["requested_names"]] and
             len(rows) == p["requested_count"], "current native seal requests differ beyond collector log coordinates")
        log = logs[p["probe"]].read_text()
        need(p["probe_sha256"] == sha(ROOT / (p["probe"] + ".lean")) and
             "G06-HARNESS " not in log and not helpers.diagnostics(log), "final seal failed or changed")
        helpers.check_installation(log, label, old)
        mask.verify_component_log(log, label, rows, ("install", "eof"))
        mask.verify_mask_log(log, label, rows, ("install", "eof"))
        fresh.append({**p, "log_sha256": sha(logs[p["probe"]]), "source_errors": 0, "valid_harness": True})

    updated = {**roots, **delta_roots}
    need(census.root_axioms(roots) == census.root_axioms(updated), "a stored actual axiom identity or set changed")
    changed_refs = []
    for m in delta_roots:
        need(set(delta_roots[m]) == set(roots[m]), "affected declaration identity set differs")
        for n, row in delta_roots[m].items():
            old = roots[m][n]
            if any(row[key] != old[key] for key in ("type_refs", "value_refs")):
                changed_refs.append({"module": m, "name": n, "old": old, "current": row})
    census.HEAD = HEAD
    c3_log = next(p for m, p in logs.items() if m.endswith("/FinalC3"))
    c3 = census.c3_data(c3_log.read_text(), modules, catalog, updated)
    previous = read(AREA / "combined-c3-precheck-r2.json",
                    "0a2c758a3ba068ce51a73484d8aa3d33ae9cdf7aaf91f1961012235d273199f4")["c3"]
    pair_key = lambda row: {k: v for k, v in row.items() if k != "log_line"}
    need([pair_key(r) for r in c3["pairs"]] == [pair_key(r) for r in previous["pairs"]], "generated references changed")

    inputs = read(INPUTS / "manifest.json")
    diagnostics = read(INPUTS / "seal-source-diagnostics.json", inputs["files_sha256"]["seal-source-diagnostics.json"])
    dropped = [r for r in diagnostics if r["module"] in fresh_owners]
    remaining = [r for r in diagnostics if r["module"] not in fresh_owners]
    need(Counter(r["module"] for r in dropped) == EXPECTED_REPAIRS and
         len(diagnostics) == effective["source_error_diagnostics"], "retained diagnostic scope differs")
    p = DELTA / "final-seal-and-census.json"
    with p.open("x") as f:
        json.dump({"status": "FINAL_NATIVE_SCOPE_AND_CENSUS_RECONCILED",
                   "head": HEAD, "actual_base": BASE, "parent": OLD,
                   "native_delta_sha256": sha(result_path), "retained_seal_owners": sorted(retained),
                   "fresh_seals": fresh, "effective_owner_count": len(retained) + len(fresh),
                   "retained_control_count": 13, "catalog_count": len(catalog),
                   "actual_root_count": c3["actual_roots"],
                   "admitted_dependent_roots": sum("sorryAx" in axs for axs in census.root_axioms(updated).values()),
                   "all_axiom_sets_unchanged": True, "changed_root_references": changed_refs,
                   "c3": c3, "previous_diagnostics_resolved_by_new_native_passes": dropped,
                   "retained_source_diagnostics": remaining}, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print("Final owner coverage", len(retained), "retained +", len(fresh), "fresh")
    print("Final roots", c3["actual_roots"], "C3", len(c3["pairs"]), "changed root reference rows", len(changed_refs))
    print("Retained source diagnostics", len(remaining), "review SHA", sha(p))


if __name__ == "__main__":
    main()
