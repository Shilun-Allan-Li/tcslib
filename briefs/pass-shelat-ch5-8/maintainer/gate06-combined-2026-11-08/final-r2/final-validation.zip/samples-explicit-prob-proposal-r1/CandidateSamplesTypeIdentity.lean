import Lean
import TCSlib.InformationTheory.Samples

set_option maxHeartbeats 0
open Lean Elab Command
open scoped BigOperators

namespace TCSlib.InformationTheory.FinDist
variable {α : Type*} [Fintype α]

private theorem expect_eq_explicit_candidate (p : FinDist α) (f : α → ℝ) :
    p.expect f = ∑ a, p.prob a * f a :=
  expect_eq p f

private theorem iid_apply_explicit_candidate (p : FinDist α) (m : ℕ) (s : Fin m → α) :
    (p.iid m).prob s = ∏ j, p.prob (s j) :=
  iid_apply p m s

run_cmd do
  for (current, candidate) in [
      (``expect_eq, ``expect_eq_explicit_candidate),
      (``iid_apply, ``iid_apply_explicit_candidate)] do
    let current ← getConstInfo current
    let candidate ← getConstInfo candidate
    unless ExprStructEq.mk current.type == ExprStructEq.mk candidate.type do
      throwError "explicit projection type differs from {current.name}"
    logInfo m!"SAMPLES-EXPLICIT-PROB-STRUCTURAL-TYPE-IDENTITY {current.name}"

end TCSlib.InformationTheory.FinDist
