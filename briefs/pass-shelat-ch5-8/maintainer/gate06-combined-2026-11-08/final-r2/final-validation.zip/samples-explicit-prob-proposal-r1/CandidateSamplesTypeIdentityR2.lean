import Lean
import TCSlib.InformationTheory.Samples

set_option maxHeartbeats 0
open Lean Elab Command
open scoped BigOperators

namespace TCSlib.InformationTheory

open Finset

namespace FinDist

variable {α β : Type*} [Fintype α] [Fintype β]

private theorem expect_eq_explicit_candidate (p : FinDist α) (f : α → ℝ) :
    p.expect f = ∑ a, p.prob a * f a :=
  expect_eq p f

private theorem iid_apply_explicit_candidate (p : FinDist α) (m : ℕ) (s : Fin m → α) :
    (p.iid m).prob s = ∏ j, p.prob (s j) :=
  iid_apply p m s

run_cmd do
  for (current, candidate) in [
      (``expect_eq, ``expect_eq_explicit_candidate),
      (``iid_apply, ``iid_apply_explicit_candidate)] do
    let old ← getConstInfo current
    let new ← getConstInfo candidate
    unless old.levelParams.length == new.levelParams.length do
      throwError "level parameter count differs for {current}"
    let newType := new.instantiateTypeLevelParams (old.levelParams.map Level.param)
    let same := ExprStructEq.mk old.type == ExprStructEq.mk newType
    unless old.type == newType do
      throwError "explicit projection type differs from {current}"
    logInfo m!"SAMPLES-EXPLICIT-PROB-TYPE-IDENTITY name={current} structurally_equal={same}"

end FinDist

end TCSlib.InformationTheory
