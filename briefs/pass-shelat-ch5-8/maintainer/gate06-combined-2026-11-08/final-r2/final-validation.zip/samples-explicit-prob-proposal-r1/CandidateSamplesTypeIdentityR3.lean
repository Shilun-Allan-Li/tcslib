import Lean
import TCSlib.InformationTheory.Samples

set_option maxHeartbeats 0
open Lean Elab Command
open scoped BigOperators

namespace TCSlib.InformationTheory

open Finset

namespace FinDist

variable {α β : Type*} [Fintype α] [Fintype β]

private theorem expect_eq_explicit_candidate (p : FinDist α) (f : α → ℝ) :
    p.expect f = ∑ a, p.prob a * f a :=
  expect_eq p f

private theorem iid_apply_explicit_candidate (p : FinDist α) (m : ℕ) (s : Fin m → α) :
    (p.iid m).prob s = ∏ j, p.prob (s j) :=
  iid_apply p m s

-- Ignore binder labels and source annotations while retaining binder visibility.
private def kernelTypeShape : Expr → Expr
  | .forallE _ domain body info => .forallE .anonymous (kernelTypeShape domain) (kernelTypeShape body) info
  | .lam _ domain body info => .lam .anonymous (kernelTypeShape domain) (kernelTypeShape body) info
  | .letE _ type value body nondep =>
    .letE .anonymous (kernelTypeShape type) (kernelTypeShape value) (kernelTypeShape body) nondep
  | .app f a => .app (kernelTypeShape f) (kernelTypeShape a)
  | .mdata _ body => kernelTypeShape body
  | .proj s i value => .proj s i (kernelTypeShape value)
  | expr => expr

run_cmd do
  for (current, candidate) in [
      (``expect_eq, ``expect_eq_explicit_candidate),
      (``iid_apply, ``iid_apply_explicit_candidate)] do
    let old ← getConstInfo current
    let new ← getConstInfo candidate
    unless old.levelParams.length == new.levelParams.length do
      throwError "level parameter count differs for {current}"
    let newType := new.instantiateTypeLevelParams (old.levelParams.map Level.param)
    unless ExprStructEq.mk (kernelTypeShape old.type) == ExprStructEq.mk (kernelTypeShape newType) do
      throwError "explicit projection changed type or binder visibility for {current}"
    logInfo m!"SAMPLES-EXPLICIT-PROB-KERNEL-TYPE-IDENTITY name={current}"

end FinDist

end TCSlib.InformationTheory
