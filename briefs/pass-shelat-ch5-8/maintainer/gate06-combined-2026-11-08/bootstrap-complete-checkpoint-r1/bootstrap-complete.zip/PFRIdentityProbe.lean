import PFR.Mathlib.Probability.UniformOn
import PFR.ForMathlib.Entropy.Basic
import PFR.Kullback

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

open Lean Elab Command
run_elab do
  let env ← getEnv
  let expected : Array Name := #[
    `PFR.Mathlib.Data.Set.Basic,
    `PFR.Mathlib.Data.Set.Insert,
    `PFR.Mathlib.Data.Set.Card,
    `PFR.Mathlib.Probability.UniformOn,
    `PFR.Mathlib.Analysis.Convex.StdSimplex,
    `PFR.Mathlib.MeasureTheory.Measure.ProbabilityMeasure,
    `PFR.ForMathlib.CompactProb,
    `PFR.Mathlib.MeasureTheory.Constructions.Pi,
    `PFR.Mathlib.Probability.Independence.Kernel,
    `PFR.Mathlib.Probability.Independence.Basic,
    `PFR.Mathlib.Probability.IdentDistrib,
    `PFR.ForMathlib.FiniteRange.Defs,
    `PFR.ForMathlib.FiniteRange.ConditionalProbability,
    `PFR.ForMathlib.Pair,
    `PFR.ForMathlib.ConditionalIndependence,
    `PFR.Mathlib.MeasureTheory.Integral.Lebesgue.Basic,
    `PFR.Mathlib.MeasureTheory.Integral.Lebesgue.Countable,
    `PFR.Mathlib.Probability.Kernel.Disintegration,
    `PFR.Mathlib.Probability.Kernel.Composition.Comp,
    `PFR.Mathlib.MeasureTheory.Measure.Dirac,
    `PFR.Mathlib.MeasureTheory.Measure.Prod,
    `PFR.Mathlib.MeasureTheory.Measure.Real,
    `PFR.ForMathlib.Entropy.Measure,
    `PFR.Mathlib.MeasureTheory.Integral.Bochner.Set,
    `PFR.ForMathlib.Entropy.Kernel.Basic,
    `PFR.ForMathlib.Entropy.Kernel.MutualInfo,
    `PFR.ForMathlib.Uniform,
    `PFR.Mathlib.Probability.ConditionalProbability,
    `PFR.ForMathlib.Entropy.Basic,
    `PFR.Mathlib.Analysis.SpecialFunctions.NegMulLog,
    `PFR.Kullback]
  for m in expected do
    let some i := env.getModuleIdx? m | throwError "PFR-MODULE missing {m}"
    let actual := env.header.moduleNames[i.toNat]!
    unless actual == m do throwError "PFR-MODULE wrong header {m}: {actual}"
    logInfo m!"PFR-MODULE {m}: {actual}"
  for (n, wanted) in #[( ``KLDiv, `PFR.Kullback),
      (``ProbabilityTheory.entropy, `PFR.ForMathlib.Entropy.Basic),
      (``ProbabilityTheory.uniformOn_apply_singleton_of_mem, `PFR.Mathlib.Probability.UniformOn)] do
    let some i := env.getModuleIdxFor? n | throwError "PFR-OWNER missing {n}"
    let actual := env.header.moduleNames[i.toNat]!
    unless actual == wanted do throwError "PFR-OWNER wrong {n}: {actual}, expected {wanted}"
    logInfo m!"PFR-OWNER {n}: {actual}"
  let mut privateCount := 0
  for (n, _) in env.constants.map₁.toList do
    let some i := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[i.toNat]!
    unless expected.contains home do continue
    if n.toString.startsWith "_private." then
      unless n.toString.startsWith ("_private." ++ home.toString ++ ".") do
        throwError "PFR-PRIVATE wrong source root {n}, owner {home}"
      privateCount := privateCount + 1
  logInfo m!"PFR-MODULES {expected.size}; PFR-PRIVATE {privateCount}; EOF"
