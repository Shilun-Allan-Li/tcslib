import Lean
import TCSlib.Complexity.TuringMachine.Configuration
set_option maxHeartbeats 0
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let n := `Turing.instInhabitedCfg
  let some (.defnInfo _) := env.find? n | throwError "INSTANCE-HARNESS: not a definition"
  unless Lean.Meta.isInstanceCore env n do throwError "INSTANCE-HARNESS: not an instance"
  let status ← liftCoreM <| Lean.getReducibilityStatus n
  unless status == .semireducible do throwError "INSTANCE-HARNESS: not semireducible"
  let some mi := env.getModuleIdxFor? n | throwError "INSTANCE-HARNESS: not imported"
  unless env.header.moduleNames[mi.toNat]! == `TCSlib.Complexity.TuringMachine.Configuration do
    throwError "INSTANCE-HARNESS: wrong home"
  logInfo "INSTANCE-CATALOG-VERIFIED"
attribute [local irreducible] Turing.instInhabitedCfg
run_cmd logInfo "INSTANCE-BODY-BEGIN"
theorem instanceBody :
    (default : Turing.Cfg 0 Bool Unit []) =
      ⟨none, 0, (fun _ _ => none), (fun _ => 0), []⟩ := rfl
run_cmd logInfo "INSTANCE-BODY-END"
