/-
Copyright (c) 2026 Seyoon Ragavan. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Seyoon Ragavan
-/
import TCSlib.Complexity.FormulaKit.Gate
import TCSlib.Complexity.ClassNP.PolyTimeBlockLoop
import TCSlib.Complexity.ClassNP.PolyTimePairing
import TCSlib.Complexity.ClassNP.Transducer

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The machine-to-formula kit, part II: uniform emission

The emission half of item H6 of the host registry (`machine-library-design.md` §14,
"ordered emission by `exists_emitLoopTM`"): a formula given as a polynomial number of
**ordered groups**, each polynomial-time computable from the instance and its index, is
serialized by a polynomial-time machine. A reduction states its formula with the gates and
layouts of `TCSlib.Complexity.FormulaKit.Gate` and proves its emitter here, in the
`Complexity.PolyTimeComputable` closure algebra of `ClassNP/PolyTimePairing.lean` and
`ClassNP/PolyTimeBlockLoop.lean`.

## Design

* **One loop.** `polyTimeComputable_flatMap_range` is the public emitting loop
  `Complexity.polyTimeComputable_emitIter` (built on `Turing.FinTM.exists_emitLoopTM`) run on
  the state word `pairEncode x 1ⁱ`, with a saturating round index. Every other emission
  theorem here reduces to it, to the closure lemmas, or to a one-pass transducer.
* **Fragments.** Groups are concatenated as `fragment`s, serializations without the formula
  terminator (Cook-Levin's private `clFragment`); `polyTimeComputable_fragment_iff_serialize`
  moves between the two forms.
* **Templates are constants.** A gate's template is fixed for the machine; only its unary wire
  indices vary with the input (`polyTimeComputable_fragment_relabel`, the public form of
  Cook-Levin's private `clA5Template_native`). A gate whose template is chosen among finitely
  many kinds by a polynomial-time key is `polyTimeComputable_fragment_gate_select`.
* **Indices in unary.** Wires are computed by the unary index arithmetic
  (`polyTimeComputable_unary_add` and its siblings), with variable as well as constant
  operands.
* **Offsets by a transducer.** `polyTimeComputable_serialize_relabel_add` shifts every variable
  of a polynomial-time serialization by a polynomial-time offset, so a family emitted once can
  be placed at any block.

## Main definitions

* `Complexity.FormulaKit.fragment` — a serialization without its formula terminator.

## Main results

* `Complexity.FormulaKit.polyTimeComputable_flatMap_range` — ordered uniform emission.
* `Complexity.FormulaKit.polyTimeComputable_serialize_flatMap` — a formula given by ordered
  polynomial-time groups serializes in polynomial time.
* `Complexity.FormulaKit.polyTimeComputable_fragment_relabel`,
  `Complexity.FormulaKit.polyTimeComputable_fragment_gate`,
  `Complexity.FormulaKit.polyTimeComputable_fragment_gate_select` — fixed templates with
  polynomial-time wires.
* `Complexity.FormulaKit.polyTimeComputable_unary_add` and its `sub`, `mul`, `pow`, `le`,
  `div`, `mod` siblings — the unary index arithmetic of closed-form layouts.
* `Complexity.FormulaKit.polyTimeComputable_serialize_relabel_add` — offsets.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*,
  Cambridge University Press, 2009. (§2.3, the proof of Lemma 2.11, pp. 45-49: the reduction
  is computable in polynomial time; §4.2, the proof of Theorem 4.13, pp. 84-85.)
-/

namespace Complexity

namespace FormulaKit

open Std.Sat (CNF)
open Turing

/-! ### Fragments -/

/-- **A fragment**: the serialization of `φ` without its formula terminator, that is every
clause with its clause marker and clause terminator. (Cook-Levin's private `clFragment`.) -/
def fragment (φ : CNF ℕ) : List Bool :=
  φ.flatMap fun C => true :: CNF.serializeClause C

/-- A serialization is its fragment followed by the single formula terminator. -/
theorem serialize_eq_fragment (φ : CNF ℕ) : CNF.serialize φ = fragment φ ++ [false] := rfl

/-- Fragments turn the concatenation of formulas into the concatenation of words. -/
theorem fragment_append (φ ψ : CNF ℕ) : fragment (φ ++ ψ) = fragment φ ++ fragment ψ := by
  simp [fragment]

/-- Fragments of an indexed concatenation are the concatenated fragments. -/
theorem fragment_flatMap {β : Type} (xs : List β) (G : β → CNF ℕ) :
    fragment (xs.flatMap G) = xs.flatMap fun b => fragment (G b) := by
  induction xs with
  | nil => rfl
  | cons b xs ih => simp only [List.flatMap_cons, fragment_append, ih]

/-- **Fragment and serialization are interchangeable for polynomial time**: a family of
formulas has a polynomial-time fragment iff it has a polynomial-time serialization.

**Proof sketch.** Forward, append the constant terminator (`PolyTimeComputable.append`,
`Complexity.polyTimeComputable_const`, `serialize_eq_fragment`). Backward, the serialization
ends with its terminator, so the fragment is the serialization without its last bit, which a
one-pass transducer with a one-bit delay outputs (`Complexity.polyTimeComputable_transduce`). -/
theorem polyTimeComputable_fragment_iff_serialize (F : List Bool → CNF ℕ) :
    PolyTimeComputable (fun x => fragment (F x)) ↔
      PolyTimeComputable (fun x => CNF.serialize (F x)) := by
  sorry

/-! ### Ordered emission -/

/-- **Ordered uniform emission** (design §14 row H6, "ordered emission"): if the number of
rounds is polynomial-time in unary, and round `i`'s chunk is polynomial-time from the pair of
the instance and `i` in unary, then the concatenation of the chunks of rounds
`0, …, count x - 1` is polynomial-time.

**Proof sketch.** Run `Complexity.polyTimeComputable_emitIter` from the state word
`pairEncode x []`: the step appends one `1` to the second component while its length is below
`count x` and then saturates; the chunk is the given one below `count x` and empty after. Both
are polynomial-time by `Complexity.polyTimeComputable_ite`, `Complexity.polyTimeComputable_lenLe`
and the pair projections. From the initial state, saturation bounds every iterate by
`2·|x| + count x + 2`, since the aligned pairing doubles the first component. This differs from
`polyTimeComputable_emitIter`'s own orbit bound, which is over every start word: an oversized
second component or a malformed pair is handled by the saturation and the total pair
projections. Both bounds are polynomial by `PolyTimeComputable.output_length_le`, and the
iteration count `a'(n + 1)^k' + 1` is chosen at least `count x`. -/
theorem polyTimeComputable_flatMap_range (count : List Bool → ℕ)
    (chunk : List Bool → ℕ → List Bool)
    (hcount : PolyTimeComputable fun x => List.replicate (count x) true)
    (hchunk : PolyTimeComputable fun z => chunk (pairFstD z) (pairSndD z).length) :
    PolyTimeComputable fun x => (List.range (count x)).flatMap (chunk x) := by
  sorry

/-- **Uniform serialization**: a formula given as `count x` ordered groups, each group's
fragment polynomial-time from the instance and the group's index in unary, serializes in
polynomial time. (Proved from `polyTimeComputable_flatMap_range`, `fragment_flatMap` and the
constant terminator.) -/
theorem polyTimeComputable_serialize_flatMap (count : List Bool → ℕ)
    (G : List Bool → ℕ → CNF ℕ)
    (hcount : PolyTimeComputable fun x => List.replicate (count x) true)
    (hG : PolyTimeComputable fun z => fragment (G (pairFstD z) (pairSndD z).length)) :
    PolyTimeComputable fun x => CNF.serialize ((List.range (count x)).flatMap (G x)) := by
  have h := (polyTimeComputable_flatMap_range count (fun x i => fragment (G x i))
    hcount hG).append (polyTimeComputable_const [false])
  convert h using 2 with x
  rw [serialize_eq_fragment, fragment_flatMap]

/-! ### Fixed templates with polynomial-time wires -/

/-- **A fixed formula with polynomial-time wires has a polynomial-time fragment**: for a
formula `φ` fixed in advance and a wiring whose value at each variable of `φ` is
polynomial-time in unary, the fragment of `φ` relabeled by the wiring is polynomial-time.
(The public form of Cook-Levin's private `clA5Template_native`, with the wire hypothesis
needed only below `φ.numVars`.)

**Proof sketch.** Induct over the fixed clause list of `φ`. A literal `(v, b)` serializes as
the unary wire index of `v`, one more `1`, the run terminator and the fixed polarity `b`;
finite concatenation (`PolyTimeComputable.append`, `Complexity.polyTimeComputable_const`)
assembles each clause and the fragment. -/
theorem polyTimeComputable_fragment_relabel (φ : CNF ℕ) (wire : List Bool → ℕ → ℕ)
    (hw : ∀ j < φ.numVars, PolyTimeComputable fun z => List.replicate (wire z j) true) :
    PolyTimeComputable fun z => fragment (φ.relabel (wire z)) := by
  sorry

/-- **A gate with polynomial-time wires has a polynomial-time fragment**: the template is
fixed, so only the unary wire indices vary. (Proved: `polyTimeComputable_fragment_relabel`
with `template_numVars_le`.) -/
theorem polyTimeComputable_fragment_gate (ℓ : ℕ) (p : (Fin ℓ → Bool) → Bool)
    (wire : List Bool → ℕ → ℕ)
    (hw : ∀ j < ℓ, PolyTimeComputable fun z => List.replicate (wire z j) true) :
    PolyTimeComputable fun z => fragment (gate ℓ p (wire z)) :=
  polyTimeComputable_fragment_relabel (template ℓ p) wire
    (fun j hj => hw j (lt_of_lt_of_le hj (template_numVars_le ℓ p)))

/-- **Snapshot-keyed gates** (design §14 row H6): a gate whose predicate is chosen among the
predicates `pred κ` of a finite type of kinds by a polynomial-time key `kind z`, with
polynomial-time wires, has a polynomial-time fragment. This is the shape of Cook-Levin's
groups (kinds `CLTemplateKind`) and of the configuration codec's transition gates (kinds
`Complexity.ConfigCodec.GateKind`).

**Proof sketch.** The fragment is the finite case split, over `Finset.univ.toList` of the
kinds, of the fragments of the fixed gates `gate ℓ (pred κ) (wire z)`; each is
`polyTimeComputable_fragment_gate`, and the split is iterated
`Complexity.polyTimeComputable_ite` on the key tests `hkind`. -/
theorem polyTimeComputable_fragment_gate_select {κ : Type} [Fintype κ] [DecidableEq κ]
    (ℓ : ℕ) (pred : κ → (Fin ℓ → Bool) → Bool) (kind : List Bool → κ)
    (hkind : ∀ κ₀ : κ, PolyTimeComputable fun z => [decide (kind z = κ₀)])
    (wire : List Bool → ℕ → ℕ)
    (hw : ∀ j < ℓ, PolyTimeComputable fun z => List.replicate (wire z j) true) :
    PolyTimeComputable fun z => fragment (gate ℓ (pred (kind z)) (wire z)) := by
  sorry

/-! ### Unary index arithmetic

Closed-form variable indices are computed in unary, the form in which the chapter-2
serialization writes them (`Std.Sat.CNF.serializeLit`), so the index algebra of a reduction is
the closure of unary polynomial-time functions under the arithmetic its layout uses. Cook-Levin
proves the constant-coefficient cases privately (`clA5Add_native`, `clA5Sub_native`,
`clA5Times_native`, `clA5Div_native`, `clA5Mod_native`, `clA5Le_native`); the configuration
codec also multiplies and divides by quantities that grow with the input (`2s + 1`,
`(2s + 1)^i`), so the general forms are stated here. -/

/-- **Unary addition** is polynomial-time. (Proved: `List.replicate_add` and
`PolyTimeComputable.append`.) -/
theorem polyTimeComputable_unary_add {f g : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true)
    (hg : PolyTimeComputable fun x => List.replicate (g x) true) :
    PolyTimeComputable fun x => List.replicate (f x + g x) true := by
  simpa only [List.replicate_add] using hf.append hg

/-- **Unary truncated subtraction** is polynomial-time.

**Proof sketch.** Drop the first `g x` symbols of `1^(f x)`: pair the two unary words and
apply the public prefix-dropping row (`Complexity.polyTimeComputable_dropPrefixByLength`), as
Cook-Levin's private `clA5Sub_native` does. -/
theorem polyTimeComputable_unary_sub {f g : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true)
    (hg : PolyTimeComputable fun x => List.replicate (g x) true) :
    PolyTimeComputable fun x => List.replicate (f x - g x) true := by
  sorry

/-- **Unary multiplication** is polynomial-time.

**Proof sketch.** `polyTimeComputable_flatMap_range` with `f x` rounds, each emitting
`1^(g x)` (a chunk polynomial-time from the pair of the instance and the round index, by
composing `hg` with `Complexity.pairFstD`). -/
theorem polyTimeComputable_unary_mul {f g : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true)
    (hg : PolyTimeComputable fun x => List.replicate (g x) true) :
    PolyTimeComputable fun x => List.replicate (f x * g x) true := by
  sorry

/-- **Unary powers with a fixed exponent** are polynomial-time. (Proved from
`polyTimeComputable_unary_mul` by induction on the exponent.) -/
theorem polyTimeComputable_unary_pow {f : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true) (k : ℕ) :
    PolyTimeComputable fun x => List.replicate (f x ^ k) true := by
  induction k with
  | zero => simpa using polyTimeComputable_const [true]
  | succ k ih => simpa only [pow_succ] using polyTimeComputable_unary_mul ih hf

/-- **The unary comparison** `f x ≤ g x` is polynomial-time, as a one-bit verdict.

**Proof sketch.** `1^(f x) - 1^(g x)` is empty iff `f x ≤ g x`
(`polyTimeComputable_unary_sub`, then `Complexity.polyTimeComputable_isNil`), as Cook-Levin's
private `clA5Le_native` does. -/
theorem polyTimeComputable_unary_le {f g : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true)
    (hg : PolyTimeComputable fun x => List.replicate (g x) true) :
    PolyTimeComputable fun x => [decide (f x ≤ g x)] := by
  sorry

/-- **Unary division** (`f x / g x`, with `/ 0 = 0`) is polynomial-time.

**Proof sketch.** `polyTimeComputable_flatMap_range` over `f x` rounds, emitting one `1` at
round `i` iff `(i + 1) · g x ≤ f x` and `0 < g x` (`polyTimeComputable_unary_mul`,
`polyTimeComputable_unary_le`, `Complexity.polyTimeComputable_ite`); the count of such rounds
is `f x / g x`. -/
theorem polyTimeComputable_unary_div {f g : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true)
    (hg : PolyTimeComputable fun x => List.replicate (g x) true) :
    PolyTimeComputable fun x => List.replicate (f x / g x) true := by
  sorry

/-- **Unary remainder** (`f x % g x`, with `% 0` the identity) is polynomial-time.

**Proof sketch.** `f x - g x · (f x / g x)` (`Nat.mod_eq_sub_div_mul`), by
`polyTimeComputable_unary_sub`, `polyTimeComputable_unary_mul` and
`polyTimeComputable_unary_div`, as Cook-Levin's private `clA5Mod_native` does for a constant
divisor. -/
theorem polyTimeComputable_unary_mod {f g : List Bool → ℕ}
    (hf : PolyTimeComputable fun x => List.replicate (f x) true)
    (hg : PolyTimeComputable fun x => List.replicate (g x) true) :
    PolyTimeComputable fun x => List.replicate (f x % g x) true := by
  sorry

/-! ### Offsets -/

/-- **Shifting by a polynomial-time offset preserves polynomial-time serialization**: from
a polynomial-time serialization of `F x` and an offset `o x` polynomial-time in unary, the
serialization of `F x` with every variable `v` renamed `o x + v` is polynomial-time.

**Proof sketch.** A two-input transducer: copy the serialized word, and at every literal
start (a `1` read in the clause state of the public CNF grammar automaton
`Std.Sat.CNF.syntaxStep`) first copy the unary word `1^(o x)`. It runs in time linear in the
output, which is at most `(o x + 1)` times the input serialization's length. -/
theorem polyTimeComputable_serialize_relabel_add (F : List Bool → CNF ℕ)
    (o : List Bool → ℕ)
    (hF : PolyTimeComputable fun x => CNF.serialize (F x))
    (ho : PolyTimeComputable fun x => List.replicate (o x) true) :
    PolyTimeComputable fun x => CNF.serialize ((F x).relabel (o x + ·)) := by
  sorry

end FormulaKit

end Complexity
