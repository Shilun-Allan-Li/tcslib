#!/usr/bin/env python3
"""Own frozen-source static checks. Existing reviewed repository linters only; no Lean."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import importlib.util
import io
import json
import os
import re
import subprocess
import sys
import tarfile

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
OUT = Path(__file__).resolve().parent
BASE = '067c5d8d6dd436e62681d7dc607984c705dc80a2'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
PRIOR = '3f6db40e1688c4a0bb922c9575dd3bd2157a650b'
OLD_BASE = 'eee107e92a7db11f1f8c98a5c2867304f57ddc54'
INPUTS = {}


def sha(raw): return hashlib.sha256(raw).hexdigest()
def need(ok, why):
    if not ok: raise RuntimeError(why)
def read(path):
    raw = path.read_bytes(); INPUTS[str(path)] = {'sha256': sha(raw), 'bytes': len(raw)}; return raw
def save(name, data):
    path = OUT / name; path.parent.mkdir(parents=True, exist_ok=True)
    raw = data if isinstance(data, bytes) else (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as handle: handle.write(raw)
def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(ROOT), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})


def sources(rev):
    raw = git('archive', rev, '--', 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for row in archive:
            if row.isfile() and row.name.endswith('.lean'):
                need(not Path(row.name).is_absolute() and '..' not in Path(row.name).parts, 'unsafe snapshot path')
                result[row.name] = archive.extractfile(row).read()
    return result


def own_parser():
    path = ROOT / '.lake/ps-maintainer/cleanup-review-2026-11-08/partial-r1/review-source-scope/validate.py'
    manifest = json.loads(read(path.with_name('manifest.json')))
    need(sha(path.with_name('manifest.json').read_bytes()) == 'a9b58ac78b9149f33cf2140fb551ca5a879d39e1b09066ac908f8c43cb26c6f8', 'own parser manifest changed')
    raw = read(path)
    need(sha(raw) == next(x['sha256'] for x in manifest['outputs'] if x['path'] == 'validate.py'), 'own parser changed')
    tree = ast.parse(raw)
    allowed = {'mask', 'split_header', 'normalized', 'parse', 'plain'}
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in allowed or
             isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {'DECL', 'CMD'} for t in n.targets)]
    scope = {'re': re, 'sha': sha}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<own previously reviewed parser>', 'exec'), scope)
    save('tools/own-parser.source.txt', raw)
    return scope


def repository_linter(name):
    path = ROOT / 'scripts' / name
    raw = read(path); save('tools/' + name + '.source.txt', raw)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('final_static_' + name.replace('.', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    prior = sys.argv; sys.argv = [str(path)]
    try: spec.loader.exec_module(mod)
    finally: sys.argv = prior
    return mod


def normalize(message):
    return re.sub(r'\b\d+ lines', '<count> lines', re.sub(r':\d+:', ':<line>:', message))


def main():
    need(not (OUT / 'checks.json').exists() and not (OUT / 'snapshots').exists(), 'refusing prior check outputs')
    for rev in (BASE, HEAD, PRIOR, OLD_BASE):
        need(git('rev-parse', rev + '^{commit}').decode().strip() == rev, 'wrong commit')
    need(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'HEAD differs')
    changed = git('diff', '--name-only', BASE, HEAD, '--', '*.lean').decode().splitlines()
    snap = {name: sources(rev) for name, rev in [('base', BASE), ('head', HEAD), ('prior', PRIOR), ('old_base', OLD_BASE)]}
    need(all(p.startswith('TCSlib/') or p == 'TCSlib.lean' for p in changed), 'nonlibrary PR source')
    for path, raw in snap['head'].items(): need((ROOT / path).read_bytes() == raw, 'live source differs: ' + path)
    for label in ('base', 'head'):
        for path, raw in snap[label].items(): save('snapshots/' + label + '/' + path, raw)
    parser = own_parser(); parsed = {}
    for label in ('base', 'head', 'prior', 'old_base'):
        parsed[label] = {p: parser['parse'](snap[label][p].decode(), p) for p in changed if p in snap[label]}
    math = [p for p in changed if parsed['head'][p]]
    facades = [p for p in changed if not parsed['head'][p]]
    source_rows = [{'path': p, 'sha256': sha(raw), 'bytes': len(raw)} for p, raw in sorted(snap['head'].items())]
    save('source-fingerprints.json', source_rows)
    save('scope.json', {'base': BASE, 'head': HEAD, 'prior_audit': PRIOR, 'changed_lean_paths': changed,
                       'math_paths': math, 'facade_paths': facades, 'head_source_count': len(source_rows)})
    for label in parsed: save('declarations-' + label + '.json', parsed[label])
    style = repository_linter('style_lint.py')
    campaign = repository_linter('campaign_style_lint.py')
    style_rows = []
    for path in changed:
        results = {}
        for label in ('base', 'head'):
            style.ROOT = OUT / 'snapshots' / label
            results[label] = style.lint(style.ROOT / path) if path in snap[label] else []
        new = list((Counter(map(normalize, results['head'])) - Counter(map(normalize, results['base']))).elements())
        style_rows.append({'path': path, **results, 'new_normalized_keys': new})
    for label in ('base', 'head'):
        save('logs/style-' + label + '.log', ('\n'.join(x for row in style_rows for x in row[label]) + '\n').encode())
    save('style-comparison.json', style_rows)
    campaign_rows = []
    for check8b in (False, True):
        results = {}
        for label in ('base', 'head'):
            campaign.ROOT = OUT / 'snapshots' / label; campaign.CHECK8B = check8b; campaign.findings = []
            for path in changed:
                if path in snap[label]: campaign.check_file(campaign.ROOT / path)
            results[label] = list(campaign.findings)
            save('logs/campaign-' + label + ('-check8b' if check8b else '-plain') + '.log',
                 ('\n'.join(level + '\t' + path + '\t' + msg for level, path, msg in results[label]) + '\n').encode())
        keys = lambda rows: Counter((level, path, normalize(msg)) for level, path, msg in rows if level != 'INFO')
        campaign_rows.append({'check8b': check8b, **results, 'new_normalized_keys': list((keys(results['head']) - keys(results['base'])).elements())})
    save('campaign-comparison.json', campaign_rows)
    prongs = []
    for topic in ['Authentication', 'SecureComputation', 'Composability', 'Randomness']:
        for check8b in (False, True):
            campaign.ROOT = OUT / 'snapshots/head'; campaign.CHECK8B = check8b; campaign.findings = []
            paths = sorted(p for p in snap['head'] if p.startswith('TCSlib/Cryptography/' + topic + '/'))
            for path in paths:
                campaign.check_file(campaign.ROOT / path)
                if campaign.is_facade(campaign.ROOT / path): campaign.check_facade(campaign.ROOT / path)
            rows = list(campaign.findings)
            save('logs/' + topic + ('-check8b' if check8b else '-plain') + '.log',
                 ('\n'.join(level + '\t' + path + '\t' + msg for level, path, msg in rows) + '\n').encode())
            prongs.append({'topic': topic, 'check8b': check8b, 'files': paths, 'findings': rows,
                           'FAIL': sum(row[0] == 'FAIL' for row in rows)})
    save('four-prong-lint.json', prongs)
    graph = {}
    for path, raw in snap['head'].items():
        code = parser['mask'](raw.decode())
        graph[path[:-5].replace('/', '.')] = [m for line in code.splitlines()
                if (match := re.fullmatch(r'\s*import\s+(.+?)\s*', line)) for m in match[1].split()
                if m == 'TCSlib' or m.startswith('TCSlib.')]
    seen = set(); stack = ['TCSlib']; missing = []
    while stack:
        module = stack.pop()
        if module in seen: continue
        seen.add(module)
        if module not in graph: missing.append(module); continue
        stack.extend(graph[module])
    unreachable = [p for p in changed if p[:-5].replace('/', '.') not in seen]
    save('exports.json', {'root': 'TCSlib', 'reachable_count': len(seen), 'missing_imports': missing,
                          'PR_paths_unreachable_from_root': unreachable, 'all_PR_math_reachable': not unreachable,
                          'graph': graph})
    api = []
    for path in math:
        old = {(d['canonical'], d['kind']): d for d in parsed['base'].get(path, [])}
        for d in parsed['head'][path]:
            if d['private'] or d['kind'] not in {'def', 'abbrev'}: continue
            b = old.get((d['canonical'], d['kind']))
            if b and d['header_normalized'] == b['header_normalized'] and d['body_normalized'] == b['body_normalized']: continue
            leaf = d['name'].rsplit('.', 1)[-1]
            readers = [r['canonical'] for r in parsed['head'][path] if not r['private'] and r['kind'] in {'theorem', 'lemma'}
                       and (r['name'].rsplit('.', 1)[-1].lower().startswith(leaf.lower() + '_') or
                            r['name'].rsplit('.', 1)[-1].lower().endswith('_' + leaf.lower()))]
            api.append({'path': path, 'canonical': d['canonical'], 'kind': d['kind'], 'line': d['start'],
                        'header': d['header'], 'body': d['body'], 'attributes': d['preceding_attributes'],
                        'status': 'NEW' if b is None else 'CHANGED', 'reader_candidates': readers})
    save('api-inventory.json', api)
    need(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'HEAD changed')
    need(all((ROOT / p).read_bytes() == raw for p, raw in snap['head'].items()), 'live source changed')
    for path, binding in INPUTS.items(): need(sha(Path(path).read_bytes()) == binding['sha256'], 'tool/input changed')
    result = {'status': 'STATIC_CHECKS_COMPLETED_REVIEW_REQUIRED', 'base': BASE, 'head': HEAD,
              'changed_files': len(changed), 'math_files': len(math), 'facades': len(facades),
              'style_head_findings': sum(len(row['head']) for row in style_rows),
              'new_normalized_style_findings': sum(len(row['new_normalized_keys']) for row in style_rows),
              'new_normalized_campaign_findings': sum(len(row['new_normalized_keys']) for row in campaign_rows),
              'prong_FAIL_counts': [r['FAIL'] for r in prongs], 'public_def_abbrev_delta': len(api),
              'unreachable_PR_paths': unreachable, 'tool_inputs': INPUTS,
              'limits': ['Repository lint heuristics need dispositions; no prefix-based API completeness claim.',
                         'No received worker/scanner program executed; only own code and reviewed repository lint functions.',
                         'No native/Lean/cache/build or tracked-source/Git mutation.']}
    save('checks.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'tool_inputs'}))


if __name__ == '__main__': main()
