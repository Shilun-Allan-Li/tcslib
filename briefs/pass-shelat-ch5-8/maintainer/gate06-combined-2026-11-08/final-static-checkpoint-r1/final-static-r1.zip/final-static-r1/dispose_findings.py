#!/usr/bin/env python3
"""Own source-only dispositions, including four touched GI definitions; no native."""
from pathlib import Path
from collections import Counter, defaultdict
import ast
import difflib
import hashlib
import json
import re

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
OUT = Path(__file__).resolve().parent


def need(ok, why):
    if not ok: raise RuntimeError(why)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def load(name): return json.loads((OUT / name).read_bytes())
def save(name, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    with (OUT / name).open('xb') as handle: handle.write(raw)


def main():
    scope = load('scope.json'); style = load('style-comparison.json'); campaigns = load('campaign-comparison.json')
    apis = load('api-inventory.json'); heads = load('declarations-head.json'); bases = load('declarations-base.json'); prior = load('declarations-prior.json')
    ns = {'re': re, 'bisect': __import__('bisect'), 'need': need}
    code = ast.parse((OUT / 'scan_explicit.py').read_bytes())
    defs = [n for n in code.body if isinstance(n, ast.FunctionDef) and n.name in {'blank', 'closing', 'list_start', 'inventory', 'complete_declarations'}
            or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {'TACTIC', 'HEADWORD'} for t in n.targets)]
    exec(compile(ast.Module(body=defs, type_ignores=[]), '<own scanner definitions>', 'exec'), ns)
    controls = {
        'unfold_blank_comment_continuation': ('  unfold alpha\n\n  -- blanked comment\n        beta\n  exact h\n', ['alpha', 'beta']),
        'delta_blank_comment_continuation': ('delta\n\n-- comment\n    alpha\n    beta\nexact h\n', ['alpha', 'beta']),
        'numeric_nth_rw': ('nth_rw 2 [alpha,\n -- comment\n beta]', ['alpha', 'beta']),
        'nested_inline_proof': ('rw [show P from by simpa only [alpha]]', ['show', 'alpha']),
        'normal_and_raw_strings': ('def s := "simp [bad]"\ndef t := r#"rw [bad]"#\nsimp [good]', ['good']),
        'internal_question_mark': ('simp only [List.getElem?_map]', ['List.getElem?_map']),
        'direction_removal_explicit': ('simp only [-alpha, ← beta, @gamma]', ['alpha', 'beta', 'gamma']),
        'configuration': ('simp (config := { contextual := true }) only [alpha]', ['alpha'])}
    tested = {}
    for key, (raw, expected) in controls.items():
        actual = [row['head'] for row in ns['inventory'](raw)]
        need(actual == expected, 'own lexer control failed: ' + key)
        tested[key] = {'source': raw, 'expected': expected, 'actual': actual, 'passed': True, 'native': False}
    save('lexer-controls.json', tested)
    # Full top-level declaration extents, including tactic-local open commands.
    complete = {}
    for label, dataset in [('head', heads), ('base', bases)]:
        complete[label] = {path: ns['complete_declarations'](rows, (OUT / 'snapshots' / label / path).read_text())
                           for path, rows in dataset.items()}
        save('complete-declarations-' + label + '.json', complete[label])
    normalize = lambda s: re.sub(r'\b\d+ lines', '<count> lines', re.sub(r':\d+:', ':<line>:', s))
    style_dispositions = []
    for row in style:
        baseline = Counter(map(normalize, row['base']))
        for finding in row['head']:
            key = normalize(finding); old = baseline[key] > 0
            if old: baseline[key] -= 1
            style_dispositions.append({'path': row['path'], 'raw': finding, 'normalized': key,
                                       'status': 'INHERITED_RETAINED' if old else 'NEW_OPEN',
                                       'source_failure_exclusion': False})
    save('style-dispositions.json', style_dispositions)
    campaign_dispositions = []
    for run in campaigns:
        base_rows = {(level, path): msg for level, path, msg in run['base'] if '(check 8)' in msg}
        before_counter = Counter((l, p, normalize(m)) for l, p, m in run['base'] if l != 'INFO')
        for level, path, message in run['head']:
            if level == 'INFO': continue
            key = (level, path, normalize(message)); inherited = before_counter[key] > 0
            if inherited: before_counter[key] -= 1
            row = {'check8b': run['check8b'], 'level': level, 'path': path, 'raw': message,
                   'status': 'INHERITED_RETAINED' if inherited else 'NEW_MESSAGE_REQUIRES_DISPOSITION',
                   'source_failure_exclusion': False}
            if '(check 8)' in message and not inherited:
                current = set(message.split(': ', 1)[1].split(', '))
                previous_message = base_rows.get((level, path), '')
                previous = set(previous_message.split(': ', 1)[1].split(', ')) if ': ' in previous_message else set()
                row.update(newly_named_definitions=sorted(current - previous), removed_from_warning=sorted(previous - current))
                if not current - previous: row['status'] = 'AGGREGATE_WARNING_CHANGED_BY_REMOVING_BASELINE_GAPS_REMAINDER_RETAINED'
                elif current - previous <= {'lamportGen', 'lamportSign', 'HBCSecure'}:
                    row['status'] = 'HEURISTIC_MISSES_OPERATIONAL_RUN_READER_OR_ACRONYM_IFF'
                    row['reader_evidence'] = ['runAt_lamportGen', 'runAt_lamportSign'] if 'Lamport' in path else ['hbcSecure_iff']
            campaign_dispositions.append(row)
    save('campaign-dispositions.json', campaign_dispositions)
    interface_rows = []
    for row in apis:
        raw = (OUT / 'snapshots/head' / row['path']).read_text(); leaf = row['canonical'].rsplit('.', 1)[-1]
        attrs = row['attributes'] + re.findall(r'attribute\s*\[([^\]]+)\]\s*' + re.escape(leaf) + r'\b', raw)
        simps = [a for a in attrs if 'simps' in a]
        interface_rows.append({**row, 'non_simp_simps': simps,
             'status_disposition': 'OWNER_READER_SOURCE_PRESENT_SEMANTIC_SHAPE_REVIEW_SEPARATE' if row['reader_candidates'] or simps else 'EXISTING_TOUCHED_INTERFACE_GAP_RETAINED',
             'presence_is_not_completeness_proof': True})
    save('api-dispositions.json', interface_rows)
    # Four existing definitions retain their public contracts; only the shared coin accessor changed.
    four_keys = {'TCSlib.Cryptography.GI.gniGraphs', 'TCSlib.Cryptography.GI.honestH',
                 'TCSlib.Cryptography.GI.honestγ', 'TCSlib.Cryptography.giSim'}
    corpus = {}
    for source in sorted((OUT / 'snapshots/head').rglob('*.lean')):
        rel = source.relative_to(OUT / 'snapshots/head').as_posix(); raw = source.read_text()
        corpus[rel] = (raw, ns['blank'](raw))
    four = []
    for key in sorted(four_keys):
        row = next(x for x in apis if x['canonical'] == key); path = row['path']
        current = next(x for x in heads[path] if x['canonical'] == key)
        baseline = next(x for x in bases[path] if x['canonical'] == key)
        audited = next(x for x in prior[path] if x['canonical'] == key)
        need(current['header'] == baseline['header'] and current['raw'] == audited['raw'], 'four-definition contract/audited source changed')
        need(baseline['body'].replace('coinSlice', 'coinBlock') == current['body'], 'four-definition extra algorithm change')
        leaf = key.rsplit('.', 1)[-1]; refs = []
        token = re.compile(r"(?<![\w'])((?:[\w']+\.)*" + re.escape(leaf) + r")(?![\w'])")
        for rel, (raw, masked) in corpus.items():
            for match in token.finditer(masked):
                line = masked[:match.start()].count('\n') + 1
                refs.append({'path': rel, 'line': line, 'token': match[0], 'foreign_file': rel != path,
                             'source_line': raw.splitlines()[line - 1]})
        need(not any(x['foreign_file'] for x in refs), 'four-definition foreign consumer requires review')
        four.append({'canonical': key, 'path': path, 'base': baseline, 'audited': audited, 'head': current,
                     'public_header_identical_to_actual_base': True, 'raw_declaration_identical_to_audited_3f': True,
                     'only_body_change': 'coinSlice → coinBlock', 'body_replacement_occurrences': baseline['body'].count('coinSlice'),
                     'references_all_1109_sources': refs, 'foreign_source_references': 0,
                     'disposition': 'EXISTING_API_GAP_RETAINED_NO_FOREIGN_SOURCE_CONSUMER_FOUND_NOT_NATIVE_CLEARANCE'})
    save('four-gi-definitions.json', four)
    raw = load('explicit-raw-c1.json')
    log = ['# Own fresh explicit-list scan; historical native kind lookup, not fresh native metadata.',
           '# file:line\ttactic\ttoken\tforeign name\tkind\thome\towner\tstatus']
    log += ['\t'.join([r['path'] + ':' + str(r['line']), r['tactic'], r['head'], r['foreign_name'], r['foreign_kind'],
                       r['foreign_home'], r['declaration'], r['declaration_status']]) for r in raw]
    log += ['# C2 NOT_MEASURED: no fresh sealed source diagnostics supplied.', '# C3 NOT_MEASURED: no fresh proof-term collection supplied.']
    save('logs/explicit-c1.log', ('\n'.join(log) + '\n').encode())
    save('disposition-summary.json', {'style_new_open': sum(x['status'] == 'NEW_OPEN' for x in style_dispositions),
         'campaign_unresolved_messages': [x for x in campaign_dispositions if x['status'] == 'NEW_MESSAGE_REQUIRES_DISPOSITION'],
         'all_campaign_raw_observations_retained': len(campaign_dispositions),
         'four_existing_touched_definition_observations': len(four), 'four_foreign_source_references': 0,
         'NEW_def_abbrev_reader_presence': sum(x['status'] == 'NEW' and x['status_disposition'].startswith('OWNER_READER') for x in interface_rows),
         'source_failure_exclusions': 0, 'native_clearance': False})
    print(json.dumps(load('disposition-summary.json')))


if __name__ == '__main__': main()
