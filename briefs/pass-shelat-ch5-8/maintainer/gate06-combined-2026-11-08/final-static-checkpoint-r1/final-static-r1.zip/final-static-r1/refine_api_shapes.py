#!/usr/bin/env python3
"""Correct result-type colon detection in own API shape diagnostics; no Lean."""
from pathlib import Path
import json
import re

OUT = Path(__file__).resolve().parent


def goal(header):
    depth = 0
    for i, char in enumerate(header):
        if char in '([{⟨': depth += 1
        elif char in ')]}⟩': depth -= 1
        elif char == ':' and depth == 0: return header[i+1:]
    return header


def main():
    api = json.loads((OUT/'api-dispositions.json').read_bytes())
    declarations = json.loads((OUT/'declarations-head.json').read_bytes())
    result = []
    for row in api:
        parent, leaf = row['canonical'].rsplit('.', 1); readers = []
        for d in declarations[row['path']]:
            if d['private'] or d['kind'] not in {'theorem', 'lemma'}: continue
            p, n = d['canonical'].rsplit('.', 1)
            if p != parent or not (n.lower().startswith(leaf.lower()+'_') or n.lower().endswith('_'+leaf.lower())): continue
            statement = goal(d['header'])
            if '↔' in statement or re.search(r'(?<![<:>])=(?![=>])', statement):
                readers.append({'canonical': d['canonical'], 'line': d['start'], 'full_header': d['header'],
                                'result_type': statement})
        result.append({'path': row['path'], 'canonical': row['canonical'], 'definition_status': row['status'],
                       'reading_statement_shapes': readers, 'non_simp_simps': row['non_simp_simps'],
                       'source_shape_present': bool(readers or row['non_simp_simps']),
                       'semantic_completeness_not_inferred_from_name': True})
    missing = [r for r in result if r['definition_status']=='NEW' and not r['source_shape_present']]
    data = {'status': 'FULL_HEADER_SHAPE_REFINEMENT_NOT_PROOF_OR_NATIVE_CLEARANCE',
            'supersedes': 'api-source-shapes.json: last-colon helper incorrectly cut dependent forall binders',
            'new_shape_missing': missing, 'rows': result,
            'limits': ['Full headers/formulas retained, exact parent namespaces required.',
                       'Coverage of fields/cases and machine domains requires source judgment and native checks; no prefix-only proof.']}
    with (OUT/'api-source-shapes-final.json').open('x') as f:json.dump(data,f,indent=2,ensure_ascii=False);f.write('\n')
    print(json.dumps({'NEW_without_reading_statement_or_simps': [(r['canonical'],r['path']) for r in missing]}))


if __name__=='__main__': main()
