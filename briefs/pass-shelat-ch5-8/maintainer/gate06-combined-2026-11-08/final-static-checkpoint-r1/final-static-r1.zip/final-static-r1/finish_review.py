#!/usr/bin/env python3
"""Own final static dispositions; no received-program/native execution."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import re
import subprocess

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
OUT = Path(__file__).resolve().parent
BASE = '067c5d8d6dd436e62681d7dc607984c705dc80a2'
PRIOR = '3f6db40e1688c4a0bb922c9575dd3bd2157a650b'


def need(ok, why):
    if not ok: raise RuntimeError(why)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def load(name): return json.loads((OUT / name).read_bytes())
def save(name, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    with (OUT / name).open('xb') as handle: handle.write(raw)
def git(*args): return subprocess.check_output(['git', '--no-optional-locks', '-C', str(ROOT), *args])


def conclusion(header):
    depth = 0; last = -1
    for i, char in enumerate(header):
        if char in '([{⟨': depth += 1
        elif char in ')]}⟩': depth -= 1
        elif char == ':' and depth == 0: last = i
    return header[last+1:] if last >= 0 else header


def main():
    sources = {r['path']: r for r in load('source-fingerprints.json')}
    heads = load('declarations-head.json'); apis = load('api-dispositions.json')
    ns = {'re': re, 'json': json, 'sha': sha}
    syntax = ast.parse((OUT.parent / 'verify.py').read_bytes())
    nodes = [n for n in syntax.body if isinstance(n, ast.FunctionDef) and n.name in {'comment_projection', 'code_hash'}]
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<own literal-sensitive comparator>', 'exec'), ns)
    campaign = load('campaign-dispositions.json')
    for row in campaign:
        if row['path'] == 'TCSlib/LearningTheory/PAC/Defs.lean' and row['status'] == 'NEW_MESSAGE_REQUIRES_DISPOSITION':
            required = {'TCSlib.LearningTheory.PAC.pacLearns_iff', 'TCSlib.LearningTheory.PAC.pacLearnsUnder_iff'}
            actual = {d['canonical'] for d in heads[row['path']]}
            need(required <= actual, 'PAC predicate readers absent')
            row.update(status='HEURISTIC_ACRONYM_CASE_MISMATCH_READER_PRESENT',
                       reader_evidence=sorted(required), formula='PACLearnsUnder iff ∀i,1−δ≤accuracyProb; PACLearns iff ∀D,PACLearnsUnder')
    need(not [r for r in campaign if r['status'] == 'NEW_MESSAGE_REQUIRES_DISPOSITION'], 'unresolved campaign message')
    save('final-campaign-dispositions.json', campaign)
    shapes = []; unresolved = []
    for row in apis:
        parent = row['canonical'].rsplit('.', 1)[0]; leaf = row['canonical'].rsplit('.', 1)[-1]
        candidates = []
        for d in heads[row['path']]:
            if d['private'] or d['kind'] not in {'theorem', 'lemma'}: continue
            name_parent, name_leaf = d['canonical'].rsplit('.', 1)
            if name_parent != parent: continue
            if not (name_leaf.lower().startswith(leaf.lower() + '_') or name_leaf.lower().endswith('_' + leaf.lower())): continue
            goal = conclusion(d['header'])
            if '↔' in goal or re.search(r'(?<![<:>])=(?![=>])', goal):
                candidates.append({'canonical': d['canonical'], 'line': d['start'], 'conclusion': goal})
        shape = {'path': row['path'], 'canonical': row['canonical'], 'definition_status': row['status'],
                 'equation_or_iff_readers_in_exact_parent_namespace': candidates, 'non_simp_simps': row['non_simp_simps'],
                 'status': 'EQUATION_IFF_OR_FIELDS_SOURCE_SHAPE_PRESENT' if candidates or row['non_simp_simps'] else 'RETAINED_EXISTING_INTERFACE_OBSERVATION',
                 'semantic_completeness_not_inferred_from_name': True}
        if row['status'] == 'NEW' and not candidates and not row['non_simp_simps']: unresolved.append(shape)
        shapes.append(shape)
    save('api-source-shapes.json', shapes)
    # Primary evidence for all touched TCS theorem entries, independent of the name prefix.
    parity = {}; evidence_rows = []
    for row in load('explicit-touched-dispositions.json'):
        evidence = row.get('primary_evidence')
        if not isinstance(evidence, list): continue
        for entry in evidence:
            path = entry.get('path')
            if not path: continue
            p = Path(path); p = ROOT / p if not p.is_absolute() else p
            if not p.is_relative_to(ROOT / 'TCSlib'): continue
            rel = p.relative_to(ROOT).as_posix()
            if rel not in parity:
                before = git('show', PRIOR + ':' + rel)
                after = (OUT / 'snapshots/head' / rel).read_bytes()
                need(ns['code_hash'](before.decode()) == ns['code_hash'](after.decode()), 'TCS evidence code changed: ' + rel)
                parity[rel] = {'prior_sha256': sha(before), 'head_sha256': sha(after), 'complete_noncomment_code_equal': True}
            if entry.get('source_line'):
                need(any(line.strip() == entry['source_line'].strip() for line in (OUT / 'snapshots/head' / rel).read_text().splitlines()), 'primary declaration line absent')
            evidence_rows.append({'item_owner': row['declaration'], 'item_head': row['head'], 'primary': entry})
    save('tcs-primary-evidence-revalidation.json', {'source_parity': parity, 'uses': evidence_rows})
    # Direct primary-source kinds of the inherited non-TCS candidates.
    lean = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/src/lean')
    mathlib = ROOT / '.lake/packages/mathlib/Mathlib'
    primary = {
      'id': (lean/'Init/Prelude.lean', r'\bdef id\b', 'ordinary definition'),
      'Function.comp': (lean/'Init/Prelude.lean', r'\bdef Function\.comp\b', 'ordinary definition'),
      'Function.Injective': (lean/'Init/Data/Function.lean', r'^def Injective\b', 'predicate definition'),
      'Function.uncurry': (lean/'Init/Data/Function.lean', r'^def uncurry\b', 'ordinary definition'),
      'Fin.tail': (mathlib/'Data/Fin/Tuple/Basic.lean', r'^def tail\b', 'ordinary definition'),
      'finProdFinEquiv': (mathlib/'Logic/Equiv/Fin/Basic.lean', r'^def finProdFinEquiv\b', 'structure-valued definition'),
      'Fin.isValue': (lean/'Lean/Meta/Tactic/Simp/BuiltinSimprocs/Fin.lean', r'^builtin_dsimproc .* isValue\b', 'builtin dsimproc registration; native generated definition metadata')}
    core = []
    raw = load('explicit-raw-c1.json')
    for name, (path, pattern, kind) in primary.items():
        content = path.read_bytes(); matching = [(i+1, line) for i, line in enumerate(content.decode().splitlines()) if re.search(pattern, line)]
        need(len(matching) == 1, 'primary kind anchor ambiguous: ' + name)
        core.append({'name': name, 'path': str(path), 'source_sha256': sha(content), 'line': matching[0][0],
                     'source_line': matching[0][1], 'primary_source_kind': kind,
                     'retained_raw_uses': sum(r['foreign_name'] == name and not r['foreign_home'].startswith('TCSlib') for r in raw),
                     'disposition': 'INHERITED_CANDIDATE_RETAINED_NOT_A_SOURCE_FAILURE_EXCLUSION'})
    need(sum(r['retained_raw_uses'] for r in core) == 18, 'core observation count differs')
    save('core-mathlib-primary-classification.json', core)
    # Every facade's descendant reachability, preserving any baseline omissions.
    export = load('exports.json'); graph = export['graph']; facade_rows = []
    mask_scope = {}
    mask_tree = ast.parse((OUT/'tools/own-parser.source.txt').read_bytes())
    mask_nodes = [n for n in mask_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'mask']
    exec(compile(ast.Module(body=mask_nodes, type_ignores=[]), '<own linear import masker>', 'exec'), mask_scope)
    def graph_from(label):
        result = {}
        for path in (OUT/'snapshots'/label).rglob('*.lean'):
            rel = path.relative_to(OUT/'snapshots'/label).as_posix(); text = path.read_text()
            code = mask_scope['mask'](text)
            result[rel[:-5].replace('/', '.')] = [m for line in code.splitlines()
                if (match := re.fullmatch(r'\s*import\s+(.+?)\s*', line)) for m in match[1].split()
                if m == 'TCSlib' or m.startswith('TCSlib.')]
        return result
    base_graph = graph_from('base')
    def missing_children(graph, path):
        module = path[:-5].replace('/', '.'); prefix = module + '.'
        children = {m for m in graph if m.startswith(prefix)}
        visited = set(); stack = [module]
        while stack:
            m = stack.pop()
            if m in visited: continue
            visited.add(m); stack.extend(graph.get(m, []))
        return sorted(children - visited)
    for path in load('scope.json')['facade_paths']:
        before = missing_children(base_graph, path); after = missing_children(graph, path)
        facade_rows.append({'path': path, 'head_unreachable_descendants': after,
                            'base_unreachable_descendants': before, 'new_unreachable_descendants': sorted(set(after)-set(before))})
    save('facade-dispositions.json', facade_rows)
    patch = git('diff', '--no-ext-diff', '--unified=0', BASE, load('scope.json')['head'], '--', '*.lean')
    save('actual-PR-source.patch', patch)
    attrs = [line for line in patch.decode().splitlines() if line.startswith('+') and not line.startswith('+++')
             and re.search(r'(?:@\[|attribute\s*\[)[^\]]*\bsimp\b|set_option\s+(?:allowUnsafeReducibility|maxRecDepth)\b', line)]
    save('added-attribute-override-scan.json', {'new_simp_attributes_or_unsafe_recursion_overrides': attrs})
    save('final-disposition-summary.json', {'base': BASE, 'head': load('scope.json')['head'],
        'style_new_open': 0, 'campaign_unresolved_messages': 0,
        'four_existing_touched_GI_interface_observations': 4, 'four_foreign_source_references': 0,
        'NEW_def_abbrev_without_equation_iff_or_simps_shape': unresolved,
        'new_facade_unreachable_descendants': [r for r in facade_rows if r['new_unreachable_descendants']],
        'new_simp_or_unsafe_override_lines': attrs,
        'C2': 'NOT_MEASURED', 'C3': 'NOT_MEASURED', 'source_failure_exclusions': 0,
        'limits': ['Presence and source formula review do not prove arbitrary semantic API completeness.',
                   'No current native kind/seal/control/census pass inferred.']})
    print(json.dumps(load('final-disposition-summary.json')))


if __name__ == '__main__': main()
