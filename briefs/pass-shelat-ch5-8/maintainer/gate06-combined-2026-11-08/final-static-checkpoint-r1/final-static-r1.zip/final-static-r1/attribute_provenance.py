#!/usr/bin/env python3
"""Own read-only Git/gate provenance of six simp attributes; no approval inference."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
OUT = Path(__file__).resolve().parent
G = ROOT/'briefs/pass-shelat-ch5-8/gates/06-ch5-8-statements'
BASE = '067c5d8d6dd436e62681d7dc607984c705dc80a2'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
PRIOR = '3f6db40e1688c4a0bb922c9575dd3bd2157a650b'


def git(*args): return subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),*args])
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name, value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')


def main():
    heads = json.loads((OUT/'declarations-head.json').read_bytes())
    priors = json.loads((OUT/'declarations-prior.json').read_bytes())
    bases = json.loads((OUT/'declarations-base.json').read_bytes())
    gates = {
      '06B': ('findings/gate06B-r1-audit/contents/gate06B-findings.md', (347,350), (11,14), (73,87)),
      '06C': ('findings/gate06C-r1-findings.md', (337,341), (10,14), (98,112)),
      '06D': ('findings/gate06D-r1-findings.md', (106,111), (10,13), (69,82))}
    evidence = {}
    def capture(path, ranges):
        raw=path.read_bytes();lines=raw.decode().splitlines()
        return {'path':str(path),'sha256':sha(raw),'bytes':len(raw),
                'excerpts':[{'first':a,'last':b,'lines':lines[a-1:b]} for a,b in ranges]}
    for gate,(finding,where,scope,asks) in gates.items():
        evidence[gate]={'pack':capture(G/(gate+'-pack.md'),[scope,asks]),
                        'finding':capture(G/finding,[where]),
                        'resolution':capture(G/('resolutions-'+gate+'-r1.md'),[(1,10)]),
                        'scope_assessment':'Exact theorems and statements are in reviewed/gate-closed source. No quoted passage explicitly approves their global simp attribute.'}
    rows=[]
    for path,ds in heads.items():
        for d in ds:
            if d['name'] not in {'pairFstD_padCt','eval_polyLenExpr','pairFstD_privA','pairSndD_privA','pairFstD_privB','pairSndD_privB'}:continue
            gate='06C' if d['name']=='pairFstD_padCt' else '06D' if d['name']=='eval_polyLenExpr' else '06B'
            old=[x for x in bases.get(path,[]) if x['canonical']==d['canonical']]
            audited=next(x for x in priors[path] if x['canonical']==d['canonical'])
            pattern='@[simp] theorem '+d['name']
            commits=git('log','--format=%H','--reverse','-S'+pattern,BASE+'..'+HEAD,'--',path).decode().splitlines()
            assert commits and not old and d['raw']==audited['raw']
            intro=commits[0];parent=git('rev-parse',intro+'^').decode().strip()
            before=git('show',parent+':'+path) if git('ls-tree','--name-only',parent,'--',path).strip() else b''
            after=git('show',intro+':'+path)
            assert pattern.encode() not in before and pattern.encode() in after
            history=git('show','-s','--format=%H%n%P%n%an%n%ad%n%s','--date=iso-strict',intro).decode()
            rows.append({'canonical':d['canonical'],'path':path,'line':d['start'],'attribute':'simp',
                         'new_declaration_since_actual_base':True,'raw_declaration_equals_audited_3f':True,
                         'introduced_commit':intro,'introduced_parent':parent,'commit_metadata':history,
                         'introduction_source_sha256':sha(after),'gate':gate,
                         'gate_evidence':evidence[gate],
                         'explicit_attribute_approval_found':False,
                         'disposition':'ROOT_SCOPE_APPROVAL_INTERPRETATION_REQUIRED_NO_BLANKET_WAIVER',
                         'source_failure_exclusion':False})
    assert len(rows)==6
    save('simp-attribute-provenance.json',{'base':BASE,'head':HEAD,'attributes':rows,
         'policy':'policy.md §1: None carries @[simp] unless a gate approves it.',
         'conclusion':'All6 attrs were present in exact audited3f source and the named theorem statements were individually reviewed at closed gates. The packs target semantic fidelity/attribution; excerpts do not explicitly approve global attributes. Root must record any narrow interpretation; this review does not invent approval or request a blanket waiver.',
         'no_source_changes':True,'no_native_execution':True})
    print(json.dumps([{'name':r['canonical'],'intro':r['introduced_commit'],'gate':r['gate']} for r in rows]))


if __name__=='__main__':main()
