# Guarded combined-source native runner proposal

Source: `a495f3953afff46ad5dec2d29ac8a7f55bd8ae37`. Tree: the already copied own `gate06-combined-20261108/oleans-r1`. **The runner has not been executed.** Static review/data checks are recorded in `validation.json`; parent source review remains the launch step.

Run from the integration checkout, using `python3 -I`:

```
python3 -I .lake/ps-maintainer/gate06-combined-20261108/native-runtime-proposal/run_combined_native.py bootstrap
python3 -I .lake/ps-maintainer/gate06-combined-20261108/native-runtime-proposal/run_combined_native.py local
```

The two commands are separate host operations. The parent may run the reviewed tiny instance controls between them with ordinary PATH and the same own tree. They must leave the pinned library/package sources, copied local objects and bootstrap evidence unchanged.

`bootstrap` exclusively creates `native-bootstrap-r1/` and performs36 one-file checker calls:

1. An ordinary-PATH cache probe importing all383 current Mathlib roots plus `Std.Sat.CNF` and `Batteries.Data.Nat.Lemmas` (385 imports), with one required EOF marker.
2. All31 physical PFR modules in the frozen topological order. Only these31 calls prepend `pfr-runtime-r1/bin` and set `PFR_BOOTSTRAP_CONFIG`. The exact config SHA is `4d1a6453a3586f5263628712ad15ab734514a04bbe65e10c1c468f70bb0c8c16`; driver SHA is the unchanged `41fda9565be3f77462fe6f2f7b55b798c5bf34fbbc400a648f77e000eb36636d`.
3. The previously reviewed PFR identity harness on ordinary PATH: requires31 correct actual module headers, three declaration owners, matching private source prefixes (checked by the Lean harness), and its complete EOF. It is copied verbatim from its pinned source text only when this parent-reviewed runner is invoked.
4. Three unchanged copied-module reproductions, each requiring fresh native success and exactly the old expected object SHA. The146 historical direct Mathlib object hashes are rechecked **after the successful cache fetch and before any representative reproduction**, and again at completion. Substantive local replay cannot start until all36 bootstrap checks succeed.

`local` exclusively creates `native-local-r1/`, requires the complete unchanged successful bootstrap/result/log/manifest/native sequence, and performs all638 fresh local checks, including root `TCSlib` and `audits/pass-shelat/Checks`. It reconciles all1075 local source/object/direct-dependency contracts at completion. The other437 are explicitly warm G06 copies supported by the three byte reproductions; no S2 tree is borrowed and no cold full-library run is claimed.

There is no cache operation, object copying, retry or resume command. Each phase directory must be absent. A failure produces an immutable STOP/evidence record and stops before checking dependents. A later attempt requires a separately reviewed plan/directory rather than deleting or resuming this one.

Both phases validate the full34-file preparation manifest, current1109-file library/root/Checks source bytes against an in-memory HEAD archive, all reached package source hashes and present package Git pins, passed `cache-r2/RESULT.json`, original copy receipt, exact PFR configuration/entry, checker and real Lean binary. They reject an unexpected local fallback object tree, missing prerequisites, shadowed imports, or unexpected local objects. The complete external object inventory is hashed at phase boundaries; each call records direct local/external source/object hashes before and after, source/tool/checker identities, unique start/end/PID/PGID/log data, return code, error count, fresh output and macOS RSS. Source/preparation/package/whole-scope identities are revalidated before declaring the phase complete.

Each call waits for three idle host observations, enforces the macOS memory/disk floor, then monitors for another Lean/lake/leantar/cache native operation while its child runs. A collision stops only its own separately sessioned child group; another job is never signalled. All own children are awaited. SIGTERM/HUP enter the same own-child cleanup path. The atomic runner lease is removed only by its owning invocation. No source/namespace mutation, proof option override or library build is added.

`validation.json` contains14 independent static/data checks, including a fresh reviewer-only146-hash comparison after cache-r2 passed. These checks do not establish runtime process-cleanup behavior or Lean marker output: no native/probe/PFR/runner invocation was made by this author. The parent should verify `PROPOSAL-MANIFEST.json`, read the source, and coordinate the shared host before launching.

**Ready to run**
