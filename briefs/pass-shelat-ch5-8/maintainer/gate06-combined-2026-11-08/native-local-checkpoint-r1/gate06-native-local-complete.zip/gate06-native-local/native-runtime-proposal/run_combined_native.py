"""PROPOSAL ONLY. Root reviews, then invokes `bootstrap` or `local` with python3 -I.

No cache operation, copying, source change, automatic retry or resume is provided.
Only the frozen one-module checker is used. Runtime writes stay in this line's
own tree and fresh ignored phase directories. Never kill another process group.
"""
from pathlib import Path
import datetime as dt
import hashlib
import io
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

W = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
M = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
A = W / '.lake/ps-maintainer/gate06-combined-20261108'
P = A / 'native-prep'
TREE = A / 'oleans-r1'
BOOT = A / 'native-bootstrap-r1'
LOCAL = A / 'native-local-r1'
CFG = A / 'pfr-runtime-r1/config.json'
CHECKER = W / 'scripts/lean_check_tree.sh'
SELF = Path(__file__).resolve()
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
PREP_SHA = '2f410bf13ab9dc4398107476a95ec5ad8ef8f3e862646daca128cdfe4497c612'
CFG_SHA = '4d1a6453a3586f5263628712ad15ab734514a04bbe65e10c1c468f70bb0c8c16'
CHECKER_SHA = '366dab40e8e8f0f13e14118e14c3d6be1bc1b36604e6c9ccdebb03bc96cdf335'
DRIVER = M / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/environment-tools/pfr_lean.py'
DRIVER_SHA = '41fda9565be3f77462fe6f2f7b55b798c5bf34fbbc400a648f77e000eb36636d'
OWNER_PROBE = DRIVER.with_name('PFRIdentityProbe.source.txt')
OWNER_PROBE_SHA = '8b539d107e9ac09cb86825f1411e8942dd8e0386ff4d2bfc6353f74d379ae575'
LEASE = A / 'native-runner.lease.json'


def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def maybe_sha(path): return sha(path) if path.is_file() else None
def load(path): return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as stream: stream.write(json.dumps(value, indent=2) + '\n')
def append(path, value):
    with path.open('a') as stream: stream.write(json.dumps(value) + '\n')
def require(test, message):
    if not test: raise RuntimeError(message)
def git(root, *args): return subprocess.check_output(['git', '-C', str(root), *args])


def native_processes():
    result = []
    for line in subprocess.check_output(['ps', '-axo', 'pid=,pgid=,comm='], text=True).splitlines():
        fields = line.strip().split(None, 2)
        if len(fields) != 3: continue
        name = Path(fields[2]).name
        if name in {'lean', 'lake', 'leantar'} or (name == 'cache' and '/mathlib/' in fields[2]):
            result.append({'pid': int(fields[0]), 'pgid': int(fields[1]), 'command': fields[2]})
    return result


def group_members(pgid):
    result = []
    for line in subprocess.check_output(['ps', '-axo', 'pid=,pgid=,stat=,comm='], text=True).splitlines():
        fields = line.strip().split(None, 3)
        if len(fields) == 4 and int(fields[1]) == pgid and not fields[2].startswith('Z'):
            result.append({'pid': int(fields[0]), 'pgid': pgid, 'command': fields[3]})
    return result


def wait_idle(out):
    stable, notice = 0, 0.0
    while stable < 3:
        active = native_processes()
        if active:
            append(out / 'host-waits.jsonl', {'utc': now(), 'active': active, 'native_started': False})
            if time.monotonic() - notice >= 30:
                print('HOST_WAIT: another native operation is active; this check has not started', flush=True)
                notice = time.monotonic()
            stable = 0; time.sleep(5)
        else:
            stable += 1
            if stable < 3: time.sleep(0.25)


def resources():
    memory = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True))
    pressure = subprocess.check_output(['memory_pressure', '-Q'], text=True)
    match = re.search(r'memory free percentage:\s*(\d+)%', pressure)
    require(match is not None, 'Cannot interpret macOS memory pressure')
    headroom = memory * max(int(match[1])-1, 0) // 100
    disk = shutil.disk_usage(W).free
    require(headroom >= 4*1024**3 and disk >= 12*1024**3, 'E-RES: memory/disk floor')
    return {'utc': now(), 'physical_memory_bytes': memory, 'conservative_headroom_bytes': headroom,
            'disk_free_bytes': disk, 'memory_pressure_raw': pressure,
            'limit': 'macOS rounded estimate, not a Linux cgroup reading'}


class Run:
    def __init__(self, phase, out):
        self.phase, self.out, self.runner_sha = phase, out, sha(SELF)
        self.cfg = load(CFG)
        self.modules = load(P / 'plan-r1/modules.json')
        self.local = {r['module']: r for r in self.modules}
        self.copy = {r['module']: r for r in load(P / 'plan-r1/copy-plan.json')}
        self.pfr = load(P / 'external-r1/pfr-modules.json')
        self.packages = load(P / 'external-r1/package-bindings.json')
        self.providers = {r['module']: r for r in load(P / 'external-r1/package-modules.json')}
        self.core = {r['module']: r for r in load(P / 'external-r1/toolchain-leaves.json')}
        self.ext, self.records, self.attempts = {}, {}, []
        self.frozen_source = {}
        self.quick_pins()

    def ordinary_env(self):
        env = dict(os.environ)
        for key in ['LEAN_PATH', 'LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LEAN_OPTS', 'ELAN_TOOLCHAIN', 'PFR_BOOTSTRAP_CONFIG']:
            env.pop(key, None)
        env['PATH'] = str(Path(self.cfg['real_lean']).parent) + ':' + str(Path.home()/'.elan/bin') + ':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
        env['TCSLIB_OLEANS'] = str(TREE)
        return env

    def quick_pins(self):
        require(sha(SELF) == self.runner_sha and sha(CHECKER) == CHECKER_SHA, 'Runner/checker changed')
        require(sha(CFG) == CFG_SHA and sha(DRIVER) == DRIVER_SHA, 'PFR configuration/driver changed')
        require(sha(Path(self.cfg['real_lean'])) == self.cfg['real_lean_sha256'], 'Lean binary changed')
        require(git(W, 'rev-parse', 'HEAD').decode().strip() == HEAD, 'HEAD changed')
        require(not git(W, 'status', '--porcelain', '--untracked-files=no').strip(), 'Tracked source/configuration dirty')
        require(not (W / '.lake/build/lib/lean').exists(), 'Unexpected local fallback object tree')
        if hasattr(self, 'cache_sha'): require(sha(A/'cache-r2/RESULT.json') == self.cache_sha, 'Passed cache receipt changed')
        require(TREE.is_dir() and not TREE.is_symlink(), 'Expected own copied tree absent/aliased')
        require((TREE/'PFR').is_symlink() and (TREE/'PFR').resolve(strict=True) == (TREE/'.lake/packages/PFR/PFR').resolve(strict=True), 'PFR namespace alias drift')

    def validate_frozen_inputs(self):
        require(sha(P/'NATIVE-PREP-MANIFEST.json') == PREP_SHA, 'Frozen preparation manifest drift')
        manifest = load(P/'NATIVE-PREP-MANIFEST.json')
        for r in manifest['files']:
            path = P/r['path']
            require(path.resolve(strict=True).is_relative_to(P) and path.stat().st_size == r['bytes'] and sha(path) == r['sha256'], 'Preparation leaf drift: '+r['path'])
        require(self.cfg['head'] == HEAD and Path(self.cfg['tree']) == TREE and Path(self.cfg['clone']) == W, 'Wrong PFR source/tree')
        require(sha(A/'combined-source-commit.json') == load(P/'plan-r1/plan.json')['source_receipt_sha256'], 'Combined source receipt changed')
        entry = A/'pfr-runtime-r1/bin/lean'
        require(entry.read_text() == '#!/usr/bin/env bash\nexec python3 -I '+shlex.quote(str(DRIVER))+' "$@"\n', 'PFR PATH entry drift')
        require(sha(OWNER_PROBE) == OWNER_PROBE_SHA, 'Owner identity harness drift')
        self.cache_result = load(A/'cache-r2/RESULT.json')
        self.cache_sha = sha(A/'cache-r2/RESULT.json')
        require(self.cache_result['passed'] is True and self.cache_result['rc'] == 0 and self.cache_result['roots'] == 54 and not self.cache_result['missing_non_PFR_package_objects'], 'cache-r2 has not passed')
        require(self.cache_result['roots_sha256'] == sha(P/'external-r1/narrowed-cache-roots.txt') and self.cache_result['log_sha256'] == sha(A/'cache-r2/cache-get.attempt01.log'), 'Cache inputs/log drift')
        require(sha(A/'copy-r1/RESULT.json') == '743dd054fc99890e4b3656f2b1bbd99f6a41ebf3cffc69c6e8e2c3c3171ad2b2', 'Copy receipt drift')
        copied = load(A/'copy-r1/RESULT.json')
        require(copied['copied_TCSlib_objects'] == 437 and copied['tree'] == str(TREE) and not copied['original_tree_mutated'] and not copied['S2_tree_overlay'], 'Wrong copied baseline')
        require(sha(A/'copy-r1/copied.jsonl') == copied['copied_jsonl_sha256'], 'Copied rows drift')
        rows = [json.loads(s) for s in (A/'copy-r1/copied.jsonl').read_text().splitlines()]
        require(len(rows) == len(self.copy) == 437 and {r['module'] for r in rows} == set(self.copy), 'Copied set incomplete')
        for r in rows:
            expected = self.copy[r['module']]
            require(r['source_sha256'] == expected['source_sha256'] and r['object_sha256'] == expected['object_sha256'] and r['direct_local_prerequisites'] == expected['direct_local_object_sha256'], 'Copy source/dependency receipt mismatch')
        require(len(self.modules) == len(self.local) == 1075, 'Local scope not1075')
        positions = {r['module']: i for i, r in enumerate(self.modules)}
        require(all(positions[d] < positions[r['module']] for r in self.modules for d in r['local_imports']), 'Non-topological local order')
        require(len(self.pfr) == 31 and set(self.cfg['sources']) == {'.lake/packages/PFR/'+r['package_relative_source'] for r in self.pfr}, 'PFR31 source set mismatch')
        for r in self.pfr:
            require(self.cfg['sources']['.lake/packages/PFR/'+r['package_relative_source']]['sha256'] == r['source_sha256'], 'PFR source pin mismatch')
        self.quick_pins()

    def validate_sources(self):
        self.quick_pins()
        raw = git(W, 'archive', HEAD, '--', 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean')
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            files = {r.name: archive.extractfile(r).read() for r in archive if r.isfile() and r.name.endswith('.lean')}
        actual = {str(p.relative_to(W)) for p in (W/'TCSlib').rglob('*.lean')} | {'TCSlib.lean', 'audits/pass-shelat/Checks.lean'}
        require(len(files) == 1109 and set(files) == actual, 'Library source set changed')
        for rel, data in files.items(): require((W/rel).read_bytes() == data, 'Source differs from HEAD: '+rel)
        self.frozen_source = {k: hashlib.sha256(v).hexdigest() for k, v in files.items()}
        for r in self.modules: require(self.frozen_source[r['module']+'.lean'] == r['source_sha256'], 'Native source manifest mismatch')
        for row in self.packages:
            path = Path(row['path'])
            if row['status'] == 'ABSENT':
                require(not path.exists(), 'Previously absent package appeared'); continue
            require(path.resolve(strict=True) == Path(row['resolved_path']), 'Package location changed')
            require(git(path, 'rev-parse', 'HEAD').decode().strip() == row['revision'] and git(path, 'remote', 'get-url', 'origin').decode().strip() == row['url'], 'Package pin changed')
            require(not git(path, 'diff', '--name-only', row['revision'], '--').strip(), 'Tracked package dirty')
            require(not (path/'.lake/build/lib/lean/TCSlib').exists() and not (path/'.lake/build/lib/lean/TCSlib.olean').exists(), 'Package cache contains unexpected TCSlib fallback')
        for r in self.providers.values(): require(sha(Path(r['source_path'])) == r['source_sha256'], 'Reached package source drift: '+r['module'])
        require(sha(W/'lake-manifest.json') == load(P/'plan-r1/plan.json')['manifest_sha256'], 'Root package manifest drift')

    def object_path(self, module):
        if module.startswith('PFR.'): return TREE/(module.replace('.', '/')+'.olean')
        return Path((self.providers if module in self.providers else self.core)[module]['object_path'])

    def resolve_import(self, module):
        roots = [TREE] + sorted((W/'.lake/packages').glob('*/.lake/build/lib/lean')) + [Path(self.cfg['real_lean']).parent.parent/'lib/lean']
        rel = module.replace('.', '/')+'.olean'
        for root in roots:
            p = root/rel
            if p.is_file() and p.stat().st_size > 0: return p.resolve(strict=True)
        raise RuntimeError('Missing imported object: '+module)

    def ext_snapshot(self, allow_pending_pfr=False):
        result = {}
        for name in sorted(set(self.providers) | set(self.core)):
            if name.startswith('PFR.') and allow_pending_pfr: continue
            path = self.object_path(name)
            require(path.is_file() and path.stat().st_size > 0, 'Missing required external object: '+name)
            require(self.resolve_import(name) == path.resolve(strict=True), 'External object shadowed: '+name)
            result[name] = {'object_path': str(path), 'object_sha256': sha(path), 'object_bytes': path.stat().st_size,
                            'source_sha256': self.providers.get(name, {}).get('source_sha256'),
                            'kind': 'PFR_OWN_TREE' if name.startswith('PFR.') else ('PACKAGE' if name in self.providers else 'TOOLCHAIN_LEAF')}
        return result

    def historical_hashes(self):
        rows = load(P/'external-r1/historical-mathlib-object-validation.json')
        require(len(rows) == 146, 'Historical direct-root set not146')
        for r in rows: require(sha(Path(r['object_path'])) == r['sha256'], 'Historical Mathlib object changed: '+r['module'])
        return {'count': 146, 'all_match': True, 'utc': now()}

    def local_set(self):
        actual = {str(p.relative_to(TREE))[:-6] for p in (TREE/'TCSlib').rglob('*.olean')}
        if (TREE/'TCSlib.olean').is_file(): actual.add('TCSlib')
        if (TREE/'audits/pass-shelat/Checks.olean').is_file(): actual.add('audits/pass-shelat/Checks')
        require(actual == set(self.records), 'Unexpected/missing local object in own tree')
        for name, r in self.records.items():
            p = TREE/(name+'.olean')
            require(p.resolve(strict=True).is_relative_to(TREE) and sha(p) == r['object_sha256'], 'Local object drift: '+name)
            require(sha(W/(name+'.lean')) == r['source_sha256'], 'Local source drift: '+name)
            for dep, expected in r['direct_local_object_sha256'].items():
                require(dep in self.records and self.records[dep]['object_sha256'] == expected, 'Local prerequisite drift: '+name)

    def dependencies(self, local, external, verify=True):
        result = {'local': {}, 'external': {}}
        def resolution(name):
            try: return str(self.resolve_import(name))
            except RuntimeError: return None
        for name in local:
            require(name in self.records, 'No validated local prerequisite: '+name)
            r, path = self.records[name], TREE/(name+'.olean')
            item = {'object_sha256': maybe_sha(path), 'source_sha256': maybe_sha(W/(name+'.lean')), 'object_path': str(path),
                    'resolved_import_path': resolution(name.replace('/', '.'))}
            result['local'][name] = item
            if verify: require(item['object_sha256'] == r['object_sha256'] and item['source_sha256'] == r['source_sha256'] and item['resolved_import_path'] == str(path.resolve()), 'Local prerequisite changed/fell back: '+name)
        for name in external:
            require(name in self.ext, 'No checked/available external prerequisite: '+name)
            r, path = self.ext[name], self.object_path(name)
            item = dict(r, object_sha256=maybe_sha(path), resolved_import_path=resolution(name))
            if name in self.providers: item['source_sha256'] = maybe_sha(Path(self.providers[name]['source_path']))
            result['external'][name] = item
            if verify: require(item['object_sha256'] == r['object_sha256'] and item['source_sha256'] == r['source_sha256'] and item['resolved_import_path'] == str(path.resolve()), 'External prerequisite/source changed/shadowed: '+name)
        return result

    def stop_own_group(self, proc):
        # Called only for this just-started, separately sessioned child. Never
        # signal any PID/PGID found by the host inventory.
        if proc.poll() is None:
            require(os.getpgid(proc.pid) == proc.pid, 'Own child group identity changed')
        if group_members(proc.pid):
            os.killpg(proc.pid, signal.SIGTERM)
            deadline = time.monotonic()+10
            while group_members(proc.pid) and time.monotonic() < deadline: time.sleep(0.1)
            if group_members(proc.pid): os.killpg(proc.pid, signal.SIGKILL)
        proc.wait()
        require(not group_members(proc.pid), 'Own process group did not stop')

    def check(self, label, rel, source_sha, local, external, pfr=False, expected_object=None, markers=None):
        number = len(self.attempts)
        attempt = self.out/'checks'/f'{number:03d}-{label}.attempt01'
        attempt.mkdir(parents=True, exist_ok=False)
        source, obj = W/(rel+'.lean'), TREE/(rel+'.olean')
        wait_idle(self.out); self.quick_pins()
        before = self.dependencies(local, external)
        require(sha(source) == source_sha, 'Current check source drift: '+rel)
        entry_sha = sha(A/'pfr-runtime-r1/bin/lean')
        env = self.ordinary_env()
        if pfr:
            env['PATH'] = str(A/'pfr-runtime-r1/bin')+':'+env['PATH']; env['PFR_BOOTSTRAP_CONFIG'] = str(CFG)
        header = {'event': 'START', 'utc': now(), 'head': HEAD, 'label': label, 'module': rel, 'source_sha256': source_sha,
                  'checker_sha256': CHECKER_SHA, 'runner_sha256': self.runner_sha, 'pfr_config_sha256': CFG_SHA,
                  'pfr_only_PATH': pfr, 'PATH': env['PATH'], 'TCSLIB_OLEANS': str(TREE), 'dependencies_before': before,
                  'object_before_sha256': sha(obj) if obj.is_file() else None, 'resources': resources()}
        save(attempt/'start.json', header)
        require(not native_processes(), 'Host became busy after stable-idle check')
        command = ['/usr/bin/time', '-l', 'bash', 'scripts/lean_check_tree.sh', rel]
        log = attempt/'native.log'
        begun = time.monotonic(); proc = None; interrupted = None
        with log.open('xb') as stream:
            stream.write((json.dumps(header)+'\n').encode()); stream.flush()
            try:
                proc = subprocess.Popen(command, cwd=W, env=env, stdin=subprocess.DEVNULL, stdout=stream,
                                        stderr=subprocess.STDOUT, start_new_session=True)
                save(attempt/'child.json', {'pid': proc.pid, 'pgid': proc.pid, 'runner_pid': os.getpid(), 'utc': now(), 'command': command})
                last_watch = 0.0
                while proc.poll() is None:
                    if time.monotonic()-last_watch >= 1:
                        foreign = [r for r in native_processes() if r['pgid'] != proc.pid]
                        require(not foreign, 'HOST_COLLISION: another native operation started: '+json.dumps(foreign))
                        last_watch = time.monotonic()
                    time.sleep(0.1)
                rc = proc.wait()
                require(not group_members(proc.pid), 'Unexpected live descendant after checker exit')
            except BaseException as exc:
                interrupted = repr(exc)
                if proc is not None: self.stop_own_group(proc)
                rc = proc.returncode if proc is not None else None
            ended = now()
            stream.write((json.dumps({'event': 'END', 'utc': ended, 'rc': rc, 'interrupted': interrupted})+'\n').encode())
        raw = log.read_text()
        errors = len(re.findall(r'\berror(?:\([^)]*\))?:', raw))
        rss = re.search(r'^\s*(\d+)\s+maximum resident set size\s*$', raw, re.M)
        after, post_error = None, None
        try:
            after = self.dependencies(local, external, verify=False); self.quick_pins()
            require(after == before and sha(source) == source_sha and sha(A/'pfr-runtime-r1/bin/lean') == entry_sha, 'Source/tool/prerequisite changed during check')
            require(interrupted is None and rc == 0 and errors == 0 and obj.is_file() and obj.stat().st_size > 0, 'Native checker failed')
            require(rss is not None, 'Native RSS record missing')
            if expected_object: require(sha(obj) == expected_object, 'Copied representative byte comparison failed')
            if markers: markers(raw)
        except BaseException as exc: post_error = repr(exc)
        row = {'label': label, 'module': rel, 'source_sha256': source_sha, 'head': HEAD, 'start_utc': header['utc'], 'end_utc': ended,
               'elapsed_seconds': time.monotonic()-begun, 'rc': rc, 'error_diagnostics': errors, 'passed': post_error is None,
               'fresh_nonempty_object': obj.is_file() and obj.stat().st_size > 0, 'object_sha256': sha(obj) if obj.is_file() else None,
               'dependencies_before': before, 'dependencies_after': after, 'checker_sha256': CHECKER_SHA, 'runner_sha256': self.runner_sha,
               'source_sha256_before': source_sha, 'source_sha256_after': maybe_sha(source),
               'checker_sha256_after': maybe_sha(CHECKER), 'runner_sha256_after': maybe_sha(SELF), 'pfr_config_sha256_after': maybe_sha(CFG),
               'object_before_sha256': header['object_before_sha256'], 'source_unchanged': maybe_sha(source) == source_sha,
               'max_rss_bytes_macos': int(rss[1]) if rss else None, 'expected_reproduction_sha256': expected_object,
               'interrupted': interrupted, 'post_validation_error': post_error, 'log': str(log), 'log_sha256': sha(log)}
        save(attempt/'end.json', row); append(self.out/'attempts.jsonl', row); self.attempts.append(row)
        print(json.dumps({'phase': self.phase, 'checked': len(self.attempts), 'module': rel, 'passed': row['passed'], 'rc': rc}), flush=True)
        require(row['passed'], 'STOP: retain failed attempt; do not check dependents')
        return row

    def probe(self, name, raw, external, markers):
        path = self.out/(name+'.lean'); path.write_bytes(raw)
        return self.check(name, str(path.relative_to(W))[:-5], sha(path), [], external, markers=markers)

    def bootstrap(self):
        for name, r in self.copy.items():
            self.records[name] = {'source_sha256': r['source_sha256'], 'object_sha256': r['object_sha256'],
                                  'direct_local_object_sha256': r['direct_local_object_sha256'], 'origin': 'VALIDATED_COPY_PENDING_REPRODUCTIONS'}
        self.local_set()
        require(not list((TREE/'.lake/packages/PFR/PFR').rglob('*.olean')), 'PFR partial/previous native state present; no blind resume')
        self.ext = self.ext_snapshot(allow_pending_pfr=True)
        save(self.out/'external-before.json', self.ext)
        save(self.out/'historical146-after-cache.json', self.historical_hashes())
        roots = (P/'external-r1/mathlib-full-union-roots.txt').read_text().splitlines()
        require(len(roots) == len(set(roots)) == 383, 'Mathlib union not383')
        roots += ['Std.Sat.CNF', 'Batteries.Data.Nat.Lemmas']
        marker = 'G06-COMBINED-CACHE-383 EOF'
        raw = (''.join('import '+x+'\n' for x in roots)+'\n#eval IO.println "'+marker+'"\n').encode()
        self.probe('CacheProbe', raw, roots, lambda text: require(text.splitlines().count(marker) == 1, 'Cache EOF marker missing/duplicate'))
        for r in self.pfr:
            rel = '.lake/packages/PFR/'+r['package_relative_source'][:-5]
            record = self.check(r['module'].replace('.', '_'), rel, r['source_sha256'], [], r['imports'], pfr=True)
            self.ext[r['module']] = {'object_path': str(self.object_path(r['module'])), 'object_sha256': record['object_sha256'],
                                     'object_bytes': self.object_path(r['module']).stat().st_size,
                                     'source_sha256': r['source_sha256'], 'kind': 'PFR_OWN_TREE'}
        def owner_markers(text):
            pairs = re.findall(r'PFR-MODULE ([A-Za-z0-9_.]+): ([A-Za-z0-9_.]+)', text)
            require(len(pairs) == 31 and {a for a, _ in pairs} == {r['module'] for r in self.pfr} and all(a == b for a, b in pairs), 'PFR actual module headers invalid')
            owners = re.findall(r'PFR-OWNER ([A-Za-z0-9_.]+): ([A-Za-z0-9_.]+)', text)
            require(dict(owners) == {'KLDiv': 'PFR.Kullback', 'ProbabilityTheory.entropy': 'PFR.ForMathlib.Entropy.Basic',
                                    'ProbabilityTheory.uniformOn_apply_singleton_of_mem': 'PFR.Mathlib.Probability.UniformOn'} and len(owners) == 3, 'PFR declaration owners invalid')
            require(len(re.findall(r'PFR-MODULES 31; PFR-PRIVATE \d+; EOF', text)) == 1, 'PFR identity EOF absent/duplicate')
        self.probe('PFRIdentityProbe', OWNER_PROBE.read_bytes(), ['PFR.Mathlib.Probability.UniformOn', 'PFR.ForMathlib.Entropy.Basic', 'PFR.Kullback'], owner_markers)
        for r in load(P/'recommended-reproductions.json')['modules']:
            spec = self.local[r['module']]
            record = self.check('Reproduce_'+r['module'].replace('/', '_'), r['module'], spec['source_sha256'], spec['local_imports'], spec['external_imports'], expected_object=r['expected_object_sha256'])
            self.records[r['module']]['reproduced_current_phase'] = True
            self.records[r['module']]['reproduction_log_sha256'] = record['log_sha256']
        require(len(self.attempts) == 36, 'Bootstrap must contain1 cache+31 PFR+1 identity+3 reproduction checks')
        for r in self.records.values(): r['origin'] = 'VALIDATED_COPY_WITH_THREE_REPRODUCTIONS'

    def local_phase(self):
        result = load(BOOT/'RESULT.json')
        require(result['passed'] is True and result['phase'] == 'bootstrap' and result['head'] == HEAD and result['cache_result_sha256'] == self.cache_sha and result['runner_sha256'] == self.runner_sha, 'Complete same-source bootstrap required')
        manifest = load(BOOT/'FILE-MANIFEST.json')
        require(sha(BOOT/'FILE-MANIFEST.json') == result['file_manifest_sha256'], 'Bootstrap manifest changed')
        for r in manifest:
            path = BOOT/r['path']; require(path.resolve(strict=True).is_relative_to(BOOT) and path.stat().st_size == r['bytes'] and sha(path) == r['sha256'], 'Bootstrap artifact changed')
        require({str(p.relative_to(BOOT)) for p in BOOT.rglob('*') if p.is_file()} == {r['path'] for r in manifest}|{'FILE-MANIFEST.json', 'RESULT.json'}, 'Bootstrap artifact set changed')
        attempts = [json.loads(s) for s in (BOOT/'attempts.jsonl').read_text().splitlines()]
        require(len(attempts) == result['fresh_checks'] == 36 and all(r['passed'] and r['rc'] == 0 and r['error_diagnostics'] == 0 and r['fresh_nonempty_object'] and r['source_unchanged'] for r in attempts), 'Bootstrap native sequence incomplete')
        for r in attempts: require(sha(Path(r['log'])) == r['log_sha256'], 'Bootstrap native log drift')
        require([r['module'] for r in attempts[1:32]] == ['.lake/packages/PFR/'+r['package_relative_source'][:-5] for r in self.pfr], 'Bootstrap PFR31 sequence mismatch')
        require(all(r['object_sha256'] == r['expected_reproduction_sha256'] for r in attempts[-3:]), 'Bootstrap reproduction missing')
        self.ext = load(BOOT/'external-final.json'); self.records = load(BOOT/'local-records.json')
        require(self.ext_snapshot() == self.ext, 'External objects changed since bootstrap')
        self.local_set(); self.historical_hashes()
        order = (P/'plan-r1/rebuild-order.txt').read_text().splitlines()
        require(len(order) == len(set(order)) == 638 and set(order).isdisjoint(self.records) and set(order)|set(self.records) == set(self.local), 'Fresh638 partition changed')
        for name in order:
            r = self.local[name]
            record = self.check(name.replace('/', '_'), name, r['source_sha256'], r['local_imports'], r['external_imports'])
            self.records[name] = {'source_sha256': r['source_sha256'], 'object_sha256': record['object_sha256'],
                                  'direct_local_object_sha256': {d: self.records[d]['object_sha256'] for d in r['local_imports']}, 'origin': 'FRESH_CURRENT_PHASE',
                                  'direct_external_object_sha256': {d: self.ext[d]['object_sha256'] for d in r['external_imports']}}
        require(len(self.records) == 1075 and all(self.records[k]['origin'] == 'FRESH_CURRENT_PHASE' for k in ['TCSlib', 'audits/pass-shelat/Checks']), 'Root/PSChecks fresh success missing')

    def finish(self):
        expected_cache_sha = self.cache_sha
        self.validate_frozen_inputs()
        require(self.cache_sha == expected_cache_sha, 'Cache receipt changed during phase')
        self.validate_sources(); self.local_set(); self.historical_hashes()
        require(self.ext_snapshot() == self.ext, 'External object changed during phase')
        # Reconcile each final direct dependency against the current own-tree
        # object hash, including inherited-copy direct contracts.
        for name in self.records:
            r = self.local[name]; self.dependencies(r['local_imports'], r['external_imports'])
            require(set(self.records[name]['direct_local_object_sha256']) == set(r['local_imports']), 'Final direct-local contract mismatch')
            self.records[name]['direct_external_object_sha256'] = {d: self.ext[d]['object_sha256'] for d in r['external_imports']}
        save(self.out/'external-final.json', self.ext); save(self.out/'local-records.json', self.records)
        save(self.out/'source-final.json', self.frozen_source)
        files = [{'path': str(p.relative_to(self.out)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(self.out.rglob('*')) if p.is_file()]
        save(self.out/'FILE-MANIFEST.json', files)
        result = {'passed': True, 'phase': self.phase, 'head': HEAD, 'tree': str(TREE), 'finished_utc': now(),
                  'runner_sha256': self.runner_sha, 'prep_manifest_sha256': PREP_SHA, 'pfr_config_sha256': CFG_SHA,
                  'cache_result_sha256': self.cache_sha, 'fresh_checks': len(self.attempts), 'validated_local_objects': len(self.records),
                  'external_objects': len(self.ext), 'file_manifest_sha256': sha(self.out/'FILE-MANIFEST.json'),
                  'warm_G06_copy': 437, 'S2_objects_borrowed': 0, 'no_automatic_resume': True,
                  'not_a_cold_full_library_run': True}
        if self.phase == 'local': result['bootstrap_result_sha256'] = sha(BOOT/'RESULT.json')
        save(self.out/'RESULT.json', result); print(json.dumps(result, indent=2), flush=True)


def main():
    require(len(sys.argv) == 2 and sys.argv[1] in {'bootstrap', 'local'}, 'Choose bootstrap or local; no resume option')
    phase = sys.argv[1]; out = BOOT if phase == 'bootstrap' else LOCAL
    require(Path.cwd().resolve() == W and SELF.parent == A/'native-runtime-proposal', 'Wrong worktree/tool location')
    require(not out.exists(), 'Use a separately reviewed fresh attempt; never overwrite/resume a phase')
    lease = {'runner_pid': os.getpid(), 'phase': phase, 'head': HEAD, 'utc': now(), 'runner_sha256': sha(SELF)}
    def stop_signal(signum, _frame): raise InterruptedError('Runner received signal '+str(signum))
    signal.signal(signal.SIGTERM, stop_signal)
    signal.signal(signal.SIGHUP, stop_signal)
    with LEASE.open('x') as stream: stream.write(json.dumps(lease)+'\n')
    out.mkdir(); (out/'attempts.jsonl').touch(exist_ok=False)
    try:
        save(out/'START.json', lease)
        run = Run(phase, out); run.validate_frozen_inputs(); run.validate_sources()
        save(out/'source-start.json', run.frozen_source)
        save(out/'resources-start.json', resources())
        if phase == 'bootstrap': run.bootstrap()
        else: run.local_phase()
        run.finish()
    except BaseException as exc:
        save(out/'STOP.json', {'utc': now(), 'phase': phase, 'head': HEAD, 'error': repr(exc), 'traceback': traceback.format_exc(),
                              'native_dependents_not_checked': True, 'resume_supported': False})
        raise
    finally:
        require(load(LEASE) == lease, 'Own runner lease changed; do not remove another lease')
        LEASE.unlink()


if __name__ == '__main__': main()
