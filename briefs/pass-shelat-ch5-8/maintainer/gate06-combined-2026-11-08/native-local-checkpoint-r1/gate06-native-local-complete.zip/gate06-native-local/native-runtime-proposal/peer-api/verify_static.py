#!/usr/bin/env python3
"""Own static runner/data review only. Does not import or execute the runner."""
from pathlib import Path
import ast
import hashlib
import json

W = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
A = W / '.lake/ps-maintainer/gate06-combined-20261108'
P = A / 'native-prep'
OUT = A / 'native-runtime-proposal/peer-api'
RUNNER_SHA = '64b5b2ff2260a48eef55dcf77bdb5c4125459170b28c30499f60a93de7da3c95'
CACHE_SHA = '67cb2c46e781f842bc5b9d46fbe14b32681bf3f5e86e9f7d39d3ba8fb4e28db8'


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def literal(tree, key):
    rows = [n.value for n in tree.body if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == key for t in n.targets)]
    need(len(rows) == 1, 'missing/nonunique literal assignment: ' + key)
    return ast.literal_eval(rows[0])


def main():
    inputs = {}

    def read(path):
        need(path.is_file() and not path.is_symlink(), 'nonordinary metadata/tool: ' + str(path))
        raw = path.read_bytes()
        inputs[str(path)] = {'sha256': digest(raw), 'bytes': len(raw)}
        return raw

    def load(path):
        return json.loads(read(path))

    raw = read(A / 'native-runtime-proposal/run_combined_native.py')
    need(digest(raw) == RUNNER_SHA, 'runner changed')
    tree = ast.parse(raw)  # syntax only; never import/exec any proposed function
    prep = load(P / 'NATIVE-PREP-MANIFEST.json')
    need(digest(read(P / 'NATIVE-PREP-MANIFEST.json')) == literal(tree, 'PREP_SHA'), 'preparation pin differs')
    for binding in prep['files']:
        path = P / binding['path']
        need(path.resolve().is_relative_to(P), 'preparation path escapes')
        content = read(path)
        need(digest(content) == binding['sha256'] and len(content) == binding['bytes'], 'preparation leaf differs')
    cfg = load(A / 'pfr-runtime-r1/config.json')
    need(digest(read(A / 'pfr-runtime-r1/config.json')) == literal(tree, 'CFG_SHA'), 'configuration pin differs')
    checker = read(W / 'scripts/lean_check_tree.sh')
    need(digest(checker) == literal(tree, 'CHECKER_SHA') and b'rm -f "$OL/$rel.olean"' in checker,
         'checker/fresh-object guard differs')
    main_checkout = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
    driver = main_checkout / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/environment-tools/pfr_lean.py'
    need(digest(read(driver)) == literal(tree, 'DRIVER_SHA'), 'PFR driver pin differs')
    need(digest(read(driver.with_name('PFRIdentityProbe.source.txt'))) == literal(tree, 'OWNER_PROBE_SHA'),
         'PFR owner probe pin differs')
    expected_tree = A / 'oleans-r1'
    need(Path(cfg['clone']) == W and Path(cfg['tree']) == expected_tree, 'PFR source/tree differs')
    cache = load(A / 'cache-r2/RESULT.json')
    need(digest(read(A / 'cache-r2/RESULT.json')) == CACHE_SHA, 'reviewed actual cache receipt changed')
    need(cache['passed'] and cache['rc'] == 0 and cache['roots'] == 54 and
         cache['roots_sha256'] == digest(read(P / 'external-r1/narrowed-cache-roots.txt')) and
         cache['log_sha256'] == digest(read(A / 'cache-r2/cache-get.attempt01.log')),
         'cache result/log/input binding differs')
    modules = load(P / 'plan-r1/modules.json')
    copied = load(P / 'plan-r1/copy-plan.json')
    order = read(P / 'plan-r1/rebuild-order.txt').decode().splitlines()
    names = {r['module'] for r in modules}
    copy_names = {r['module'] for r in copied}
    need(len(modules) == len(names) == 1075 and len(copied) == len(copy_names) == 437 and
         len(order) == len(set(order)) == 638 and not (copy_names & set(order)) and
         names == copy_names | set(order), 'native partition differs')
    positions = {r['module']: i for i, r in enumerate(modules)}
    need(all(positions[d] < positions[r['module']] for r in modules for d in r['local_imports']),
         'local graph order differs')
    need(all(set(r['direct_local_object_sha256']) <= copy_names for r in copied), 'copy is not dependency-closed')
    reps = load(P / 'recommended-reproductions.json')['modules']
    need(len(reps) == 3 and {r['module'] for r in reps} <= copy_names, 'representative set differs')
    pfr = load(P / 'external-r1/pfr-modules.json')
    need(len(pfr) == len({r['module'] for r in pfr}) == 31 and
         set(cfg['sources']) == {'.lake/packages/PFR/' + r['package_relative_source'] for r in pfr},
         'PFR source set differs')
    pfr_positions = {r['module']: i for i, r in enumerate(pfr)}
    for row in pfr:
        source = '.lake/packages/PFR/' + row['package_relative_source']
        need(cfg['sources'][source]['sha256'] == row['source_sha256'] and
             cfg['sources'][source]['module'] == row['module'], 'PFR source identity differs')
        need(all(pfr_positions[d] < pfr_positions[row['module']] for d in row['imports']
                 if d.startswith('PFR.')), 'PFR graph order differs')
    roots = read(P / 'external-r1/mathlib-full-union-roots.txt').decode().splitlines()
    need(len(roots) == len(set(roots)) == 383, 'Mathlib root boundary differs')
    historical = load(P / 'external-r1/historical-mathlib-object-validation.json')
    need(len(historical) == len({r['module'] for r in historical}) == 146, 'historical146 identities differ')
    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)]
    starts = [n for n in calls if isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
              and n.func.value.id == 'subprocess' and n.func.attr == 'Popen']
    kills = [n for n in calls if isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
             and n.func.value.id == 'os' and n.func.attr == 'killpg']
    need(len(starts) == 1 and len(kills) == 2 and
         all(ast.unparse(n.args[0]) == 'proc.pid' for n in kills), 'unexpected native start/signal target')
    need(any(k.arg == 'start_new_session' and isinstance(k.value, ast.Constant) and k.value.value is True
             for k in starts[0].keywords), 'native child not session-isolated')
    for path, binding in inputs.items():
        content = Path(path).read_bytes()
        need(digest(content) == binding['sha256'] and len(content) == binding['bytes'], 'input changed during static review')
    result = {'status': 'OWN_STATIC_REVIEW_ONLY_RUNNER_NOT_EXECUTED', 'runner_sha256': RUNNER_SHA,
              'cache_result_sha256': CACHE_SHA, 'bootstrap_checks': 36, 'PFR_checks': 31,
              'copied': 437, 'fresh_local': 638, 'local_scope': 1075,
              'historical_hash_contract_rows': 146, 'Mathlib_probe_roots': 383,
              'actual_historical146_object_hash_recheck_by_peer': False,
              'inputs': inputs, 'limits': ['No runner/PFR adapter/incoming script imported or executed.',
                                          'No native/resource/process simulation or object hash sweep.',
                                          'Historical146 must be rechecked by runner before copy reliance.']}
    with (OUT / 'validation.json').open('xb') as handle:
        handle.write((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps({k: v for k, v in result.items() if k != 'inputs'}))


if __name__ == '__main__':
    main()
