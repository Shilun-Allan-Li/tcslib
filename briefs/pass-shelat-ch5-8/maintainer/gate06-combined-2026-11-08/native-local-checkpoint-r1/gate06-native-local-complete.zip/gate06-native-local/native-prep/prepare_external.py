"""Own read-only external dependency inventory. No cache/native/object writes."""
from pathlib import Path
import ast
import collections
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
W = HERE.parents[3]
M = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
P = HERE / 'plan-r1'
OUT = HERE / 'external-r1'
TC = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0')
G = M / 'briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-run'
SUP = M / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/external-bootstrap-r1'


def sha(b): return hashlib.sha256(b).hexdigest()
def h(p): return sha(p.read_bytes())
def git(path, *args): return subprocess.check_output(['git', '-C', str(path), *args])
def dump(name, value): (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


# Only the two pure parser functions in our already pinned own source are compiled.
parser = HERE / 'prepare_plan.py'
assert h(parser) == '290832dbf6dfc055265b5b0ce22cf6fcfb0f514d7762418f6ecb6dfb5119370e'
syntax = ast.parse(parser.read_text())
exec(compile(ast.Module(body=[x for x in syntax.body if isinstance(x, ast.FunctionDef) and x.name in ('comments_removed', 'imports')], type_ignores=[]), str(parser), 'exec'))
assert not OUT.exists()
plan = json.loads((P / 'plan.json').read_text())
assert git(W, 'rev-parse', 'HEAD').decode().strip() == plan['head']
manifest = json.loads((W / 'lake-manifest.json').read_text())
bindings, packages, blobs = [], {}, {}
for row in manifest['packages']:
    name = row['name'].removeprefix('«').removesuffix('»')
    root = W / '.lake/packages' / name
    binding = {'name': name, 'revision': row['rev'], 'url': row['url'], 'path': str(root), 'resolved_path': str(root.resolve())}
    if not root.is_dir():
        binding['status'] = 'ABSENT'
    else:
        revision = git(root, 'rev-parse', 'HEAD').decode().strip()
        url = git(root, 'remote', 'get-url', 'origin').decode().strip()
        assert revision == row['rev'] and url == row['url'], ('Package pin drift', name, revision, url)
        binding['status'] = 'PIN_MATCH'
        binding['tracked_diff_empty'] = not git(root, 'diff', '--name-only', row['rev'], '--').strip()
        assert binding['tracked_diff_empty'], ('Dirty tracked package source', name)
        packages[name] = root
        raw = git(root, 'ls-tree', '-rz', '--full-tree', row['rev'])
        index = {}
        for line in raw.split(b'\0'):
            if not line: continue
            meta, path = line.split(b'\t', 1)
            mode, typ, blob = meta.split()
            if typ == b'blob': index[path.decode()] = blob.decode()
        blobs[name] = index
    bindings.append(binding)

sources, core, order, active = {}, {}, [], set()
def locate(module):
    rel = module.replace('.', '/') + '.lean'
    found = [(name, root / rel) for name, root in packages.items() if (root / rel).is_file()]
    if found:
        assert len(found) == 1, ('Ambiguous package module', module, found)
        return found[0]
    obj = TC / 'lib/lean' / (module.replace('.', '/') + '.olean')
    if obj.is_file() and obj.stat().st_size > 0:
        return 'TOOLCHAIN', obj
    raise AssertionError(('Unresolved external source or toolchain object', module))

def visit(module):
    if module in sources or module in core: return
    assert module not in active, ('External import cycle', module)
    package, path = locate(module)
    if package == 'TOOLCHAIN':
        core[module] = {'module': module, 'object_path': str(path), 'object_bytes': path.stat().st_size,
                        'limit': 'Toolchain leaf; transitive core imports are not source-walked.'}
        return
    active.add(module)
    raw = path.read_bytes()
    rel = str(path.relative_to(packages[package]))
    blob = hashlib.sha1(('blob ' + str(len(raw)) + '\0').encode() + raw).hexdigest()
    assert blob == blobs[package].get(rel), ('Package source differs from pinned blob', module, rel)
    direct = imports(raw)
    for d in direct: visit(d)
    active.remove(module)
    obj = packages[package] / '.lake/build/lib/lean' / (module.replace('.', '/') + '.olean')
    present = obj.is_file() and obj.stat().st_size > 0
    sources[module] = {'module': module, 'package': package, 'source_path': str(path), 'package_relative_source': rel,
                       'source_sha256': sha(raw), 'git_blob': blob, 'imports': direct,
                       'object_path': str(obj), 'object_present_nonempty': present,
                       'object_bytes': obj.stat().st_size if present else None}
    order.append(module)

for module in plan['direct_external_imports']: visit(module)
direct_mathlib = [x for x in plan['direct_external_imports'] if x.startswith('Mathlib.')]
pfr_order = [x for x in order if sources[x]['package'] == 'PFR']
pfr_boundary = sorted({d for k in pfr_order for d in sources[k]['imports'] if not d.startswith('PFR.')})
assert all(x.startswith('Mathlib.') for x in pfr_boundary)
union = sorted(set(direct_mathlib) | set(pfr_boundary))
static = json.loads((SUP / 'ordered-modules.json').read_text())
assert len(pfr_order) == len(static) == 31
assert set(pfr_order) == {x['module'] for x in static}
for row in static:
    assert row['source_sha256'] == sources[row['module']]['source_sha256']
    assert row['git_blob'] == sources[row['module']]['git_blob']
assert len(pfr_boundary) == 30
recorded = json.loads((G / 'final-native-order-prep-r2.json').read_text())['mathlib_object_sha256']
old_hash_validation = []
for module, expected in recorded.items():
    row = sources[module]
    assert row['package'] == 'mathlib' and row['object_present_nonempty']
    actual = h(Path(row['object_path']))
    assert actual == expected, ('Historical direct Mathlib object drift', module)
    old_hash_validation.append({'module': module, 'sha256': actual, 'object_path': row['object_path']})
for module in union:
    row = sources[module]
    if row['object_present_nonempty']: row['object_sha256'] = h(Path(row['object_path']))
missing = [sources[x] for x in order if not sources[x]['object_present_nonempty']]
missing_nonpfr = [x for x in missing if x['package'] != 'PFR']
# This is a narrowed cache input, not an execution. Include exact direct roots
# whose transitive package-object closure contains a missing object.
missing_names = {x['module'] for x in missing_nonpfr}
def transitive(k, seen=None):
    seen = set() if seen is None else seen
    if k in seen or k in core: return seen
    seen.add(k)
    for d in sources[k]['imports']: transitive(d, seen)
    return seen
cache_roots = sorted(x for x in union if transitive(x) & missing_names)
covered = set().union(*(transitive(x) & missing_names for x in cache_roots)) if cache_roots else set()
assert covered == missing_names, ('Missing package objects outside narrowed Mathlib-root cache reach', sorted(missing_names-covered))
assert git(W, 'rev-parse', 'HEAD').decode().strip() == plan['head']
OUT.mkdir()
dump('package-bindings.json', bindings)
dump('package-modules.json', [sources[x] for x in order])
dump('toolchain-leaves.json', [core[x] for x in sorted(core)])
dump('historical-mathlib-object-validation.json', old_hash_validation)
dump('missing-package-objects.json', missing)
dump('pfr-modules.json', [sources[x] for x in pfr_order])
for name, lines in [('mathlib-direct-roots', direct_mathlib), ('pfr-mathlib-boundary-roots', pfr_boundary),
                    ('mathlib-full-union-roots', union), ('narrowed-cache-roots', cache_roots),
                    ('package-import-order', order), ('pfr-logical-order', pfr_order),
                    ('pfr-physical-order', ['.lake/packages/PFR/' + x.replace('.', '/') for x in pfr_order])]:
    (OUT / (name + '.txt')).write_text('\n'.join(lines) + ('\n' if lines else ''))
summary = {'status': 'READ_ONLY_PREPARATION_NO_CACHE_NATIVE_OR_OBJECT_COPY', 'head': plan['head'],
           'local_plan_sha256': h(P / 'plan.json'), 'preparer_sha256': h(Path(__file__)),
           'toolchain': str(TC), 'real_lean_sha256': h(TC / 'bin/lean'),
           'present_package_pins': sum(x['status'] == 'PIN_MATCH' for x in bindings),
           'absent_packages': [x['name'] for x in bindings if x['status'] == 'ABSENT'],
           'package_source_modules': len(sources), 'toolchain_direct_or_boundary_leaves': len(core),
           'package_modules_by_owner': dict(collections.Counter(x['package'] for x in sources.values())),
           'pfr_source_modules': len(pfr_order), 'pfr_mathlib_boundary_roots': len(pfr_boundary),
           'local_mathlib_direct_roots': len(direct_mathlib), 'full_mathlib_root_union': len(union),
           'historical_direct_mathlib_hashes_unchanged': len(old_hash_validation),
           'missing_package_objects': len(missing), 'missing_by_owner': dict(collections.Counter(x['package'] for x in missing)),
           'narrowed_cache_roots': len(cache_roots), 'narrowed_cache_covers_all_missing_non_pfr_objects': True,
           'required_leanapap_source_modules': sum(x['package'] == 'LeanAPAP' for x in sources.values()),
           'old_worker_environment_route_is_not_directly_invocable': True,
           'reason': 'Its own-clone containment assertion rejects this authorized maintainer worktree package symlink; use an explicitly pinned maintainer configuration, not an unsafe bypass.',
           'pfr_compile_root': str(packages['PFR'].resolve()),
           'pfr_options': ['-DautoImplicit=false', '-DrelaxedAutoImplicit=false', '-Dpp.unicode.fun=true', '-Dpp.proofs.withType=false'],
           'pfr_object_alias_relative_target': '.lake/packages/PFR/PFR',
           'path_rule': 'Wrapper PATH only for the 31 PFR checker calls; restore ordinary PATH for all TCSlib/probes/cache.',
           'limits': ['Existing package object existence is not a new native pass.',
                      'The 146 historical direct Mathlib hashes match; full historical transitive package-object hashes were not captured.',
                      'No native PFR or root/Checks check performed by this preparation.']}
dump('summary.json', summary)
print(json.dumps(summary, indent=2))
