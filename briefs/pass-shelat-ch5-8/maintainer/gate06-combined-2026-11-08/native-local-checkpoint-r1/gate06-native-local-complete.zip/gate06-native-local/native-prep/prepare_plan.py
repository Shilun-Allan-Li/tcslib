"""Own read-only source/object planning; no native execution or object copying.

Run with python3 -I.  Only a fresh plan-r1 directory beside this file is written.
Package/tool source is read as data; no received helper is imported or executed.
"""
from pathlib import Path
import datetime as dt
import hashlib
import io
import json
import re
import subprocess
import tarfile

W = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
M = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'plan-r1'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
OLD = '3f6db40e1688c4a0bb922c9575dd3bd2157a650b'
S2 = 'd8c4cfed793f04062e7e79b78344e5b593ff3ddc'
G = M / 'briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-run'
S = M / 'briefs/pass-shelat-ch5-8/fills/shared-lemmas/s2/final/maintainer-replay'
GT = M / '.lake/ps-maintainer/oleans-gate06-r1'
ST = M / '.lake/ps-maintainer/oleans-s2-final'
TOOLCHAIN = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def file_sha(p):
    return sha(p.read_bytes())


def git(*args, cwd=W):
    return subprocess.check_output(['git', *args], cwd=cwd)


def archive(rev):
    raw = git('archive', rev, '--', 'TCSlib', 'TCSlib.lean', 'audits/pass-shelat/Checks.lean')
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        return {x.name: t.extractfile(x).read() for x in t if x.isfile() and x.name.endswith('.lean')}


def comments_removed(s):
    out = []
    i = depth = 0
    while i < len(s):
        if depth:
            if s.startswith('/-', i):
                depth += 1; out.extend('  '); i += 2
            elif s.startswith('-/', i):
                depth -= 1; out.extend('  '); i += 2
            else:
                out.append('\n' if s[i] == '\n' else ' '); i += 1
        elif s.startswith('/-', i):
            depth = 1; out.extend('  '); i += 2
        elif s.startswith('--', i):
            j = s.find('\n', i)
            j = len(s) if j < 0 else j
            out.extend(' ' * (j-i)); i = j
        elif s[i] == '"':
            j = i + 1
            while j < len(s):
                if s[j] == '\\': j += 2
                elif s[j] == '"': j += 1; break
                else: j += 1
            out.extend(s[i:j]); i = j
        else:
            out.append(s[i]); i += 1
    assert depth == 0, 'Unterminated block comment'
    return ''.join(out)


def imports(b):
    result = []
    continuing = False
    for line in comments_removed(b.decode()).splitlines():
        s = line.strip()
        if not s or s in ('prelude', 'module'): continue
        m = re.fullmatch(r'(?:(?:public|meta)\s+)*import\s+(.+)', s)
        if m:
            names = m.group(1).split()
            if names[0] == 'all': names = names[1:]
            assert all(re.fullmatch(r"[A-Za-z_«][A-Za-z0-9_'.«»]*", x) for x in names), s
            result.extend(names); continuing = True
        elif continuing and re.fullmatch(r"[A-Z][A-Za-z0-9_'.]*(?:\s+[A-Z][A-Za-z0-9_'.]*)*", s):
            result.extend(s.split())
        else:
            break
    return result


def topo(graph, roots):
    order, done, active = [], set(), set()
    def visit(k):
        if k in done: return
        assert k not in active, ('Import cycle', k)
        active.add(k)
        for d in graph[k]: visit(d)
        active.remove(k); done.add(k); order.append(k)
    for r in roots: visit(r)
    return order


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


assert not OUT.exists(), 'Never overwrite an earlier plan'
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
current, old, s2 = archive(HEAD), archive(OLD), archive(S2)
assert current.keys() == old.keys(), 'Unexpected added/removed Lean paths'
assert all((W / p).read_bytes() == b for p, b in current.items())
actual_library = {str(p.relative_to(W)) for p in (W / 'TCSlib').rglob('*.lean')} | {'TCSlib.lean', 'audits/pass-shelat/Checks.lean'}
assert actual_library == set(current), 'Ignored/untracked/missing library Lean source'
receipt_path = HERE.parent / 'combined-source-commit.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['head'] == HEAD and receipt['audited_head'] == OLD
changed = sorted(p[:-5] for p in current if current[p] != old[p])
assert [x + '.lean' for x in changed] == sorted(receipt['S2_paths'] + receipt['comment_paths'])
assert all(current[p] == s2[p] for p in receipt['S2_paths'])
for p in ['lean-toolchain', 'lake-manifest.json', 'scripts/lean_check_tree.sh']:
    assert (W / p).read_bytes() == git('show', HEAD + ':' + p) == git('show', OLD + ':' + p)
im = {p[:-5]: imports(b) for p, b in current.items()}
graph = {k: [x.replace('.', '/') for x in v if x == 'TCSlib' or x.startswith('TCSlib.')] for k, v in im.items()}
assert all(d in graph for ds in graph.values() for d in ds)
reverse = {k: set() for k in graph}
for k, ds in graph.items():
    for d in ds: reverse[d].add(k)
affected = set(changed)
todo = list(changed)
while todo:
    for k in reverse[todo.pop()]:
        if k not in affected: affected.add(k); todo.append(k)
root_order = topo(graph, ['TCSlib', 'audits/pass-shelat/Checks'])
order = topo(graph, ['TCSlib', 'audits/pass-shelat/Checks'] + sorted(affected))
affected_order = [k for k in order if k in affected]

base_path = G / 'final-repair-seal-ready.json'
prep_path = G / 'final-native-order-prep-r2.json'
baseline = json.loads(base_path.read_text())
prep = json.loads(prep_path.read_text())
assert baseline['head'] == prep['head'] == OLD
assert baseline['modules'] == len(baseline['manifest']) == 467 and baseline['stale_modules'] == 0
assert all(imports(old[k + '.lean']) == v for k, v in prep['imports'].items())
assert len(prep['imports']) == 467
assert file_sha(W / 'lake-manifest.json') == prep['manifest_sha256']
assert file_sha(W / 'lean-toolchain') == prep['toolchain_sha256']
verified = {}
for k, row in baseline['manifest'].items():
    p = GT / (k + '.olean')
    assert row['module'] == k and row['rc'] == 0 and row['source_unchanged_during_check'] and row['fresh_nonempty_object']
    assert row['source_sha256'] == sha(old[k + '.lean'])
    assert p.is_file() and p.stat().st_size > 0 and file_sha(p) == row['object_sha256'], ('Baseline object drift', k)
    direct = [x.replace('.', '/') for x in imports(old[k + '.lean']) if x == 'TCSlib' or x.startswith('TCSlib.')]
    assert set(direct) == set(row['import_object_hashes']), ('Recorded direct dependencies differ', k)
    for d in direct:
        dr = baseline['manifest'][d]
        assert row['import_object_hashes'][d] == dr['object_sha256']
        assert dt.datetime.fromisoformat(dr['end']) <= dt.datetime.fromisoformat(row['start']), ('Historical temporal mismatch', k, d)
    verified[k] = {'module': k, 'source': k + '.lean', 'source_sha256': row['source_sha256'],
                   'object_path': str(p), 'object_bytes': p.stat().st_size, 'object_sha256': row['object_sha256'],
                   'direct_local_object_sha256': row['import_object_hashes'], 'attempt': row['attempt']}
safe, rejected = {}, {}
for k in topo(graph, sorted(verified)):
    if k not in verified: continue
    if sha(current[k + '.lean']) != verified[k]['source_sha256']:
        rejected[k] = 'CURRENT_SOURCE_CHANGED'
    elif any(d not in safe for d in graph[k]):
        rejected[k] = 'DIRECT_PREREQUISITE_NOT_REUSABLE'
    else:
        safe[k] = verified[k]
copy = [safe[k] for k in order if k in safe]
rebuild = [k for k in order if k not in safe]
assert set(affected) <= set(rebuild)
print('LOCAL', len(order), 'REUSE', len(copy), 'REBUILD', len(rebuild), 'AFFECTED', len(affected), flush=True)

# Accepted S2 is retained as read-only acceptance context, never overlaid.
s2summary = json.loads((S / 'summary.json').read_text())
assert s2summary['head'] == S2
s2rows = []
for p in sorted(S.glob('final-*.json')):
    row = json.loads(p.read_text())
    if 'module' not in row: continue
    k = row['module']
    assert row['head'] == S2 and row['rc'] == 0 and row['error_diagnostics'] == 0 and row['source_unchanged'] and row['fresh_nonempty_object']
    assert row['source_sha256'] == sha(s2[k + '.lean'])
    obj = ST / (k + '.olean')
    assert obj.is_file() and file_sha(obj) == row['object_sha256']
    s2rows.append({'module': k, 'record': str(p), 'record_sha256': file_sha(p), 'source_sha256': row['source_sha256'],
                   'object_path': str(obj), 'object_sha256': row['object_sha256'], 'reuse': False,
                   'limitation': 'Final check record has no check-time direct-prerequisite hashes; no blind overlay onto Gate06.'})
assert len(s2rows) == 9

OUT.mkdir()
module_rows = [{'module': k, 'source_sha256': sha(current[k + '.lean']), 'local_imports': graph[k],
                'external_imports': [x for x in im[k] if not (x == 'TCSlib' or x.startswith('TCSlib.'))]} for k in order]
dump('modules.json', module_rows)
dump('copy-plan.json', copy)
dump('baseline-validation.json', {'head': OLD, 'modules': len(verified), 'all_source_object_direct_prerequisite_hashes_match': True,
      'source': str(base_path), 'source_sha256': file_sha(base_path), 'rejected_for_current': rejected,
      'parser_comparison': {'record': str(prep_path), 'sha256': file_sha(prep_path), 'modules': 467, 'mismatches': 0},
      'limit': 'Historical prerequisite hashes were reconstructed by the earlier reconciler from latest successful records and temporal checks; not captured directly by its runner at check start.'})
dump('s2-acceptance-context.json', {'head': S2, 'object_tree': str(ST), 'summary_sha256': file_sha(S / 'summary.json'),
      'copied_tree_manifest_sha256': file_sha(S / 'copied-tree.json'), 'records': s2rows, 'objects_selected_for_copy': 0})
for name, seq in [('order', order), ('root-checks-order', root_order), ('affected-order', affected_order),
                  ('rebuild-order', rebuild), ('copy-order', [r['module'] for r in copy]), ('changed-order', [k for k in order if k in changed])]:
    (OUT / (name + '.txt')).write_text('\n'.join(seq) + '\n')
direct = sorted({x for k in order for x in im[k] if not (x == 'TCSlib' or x.startswith('TCSlib.'))})
(OUT / 'mathlib-direct-roots.txt').write_text('\n'.join(x for x in direct if x.startswith('Mathlib.')) + '\n')
dump('plan.json', {'status': 'PREPARATION_ONLY_NO_NATIVE_OR_OBJECT_COPY', 'head': HEAD, 'audited_head': OLD,
      'target_base': receipt['target_base'], 'source_receipt': str(receipt_path), 'source_receipt_sha256': file_sha(receipt_path),
      'source_file_count': len(current), 'current_sources_equal_git': True, 'root_checks_targets': ['TCSlib', 'audits/pass-shelat/Checks'],
      'root_checks_modules': len(root_order), 'complete_scope_modules': len(order), 'affected_modules': len(affected),
      'changed_sources': changed, 'extra_affected_not_root_checks': sorted(set(order) - set(root_order)),
      'baseline_object_tree': str(GT), 'validated_baseline_modules': len(verified), 'copy_modules': len(copy), 'rebuild_modules': len(rebuild),
      'new_tree_suggestion': str(HERE.parent / 'oleans-r1'), 's2_objects_copied': 0, 'baseline_mutation_performed': False,
      'native_performed': False, 'direct_external_imports': direct,
      'checker_sha256': file_sha(W / 'scripts/lean_check_tree.sh'), 'manifest_sha256': file_sha(W / 'lake-manifest.json'),
      'toolchain_sha256': file_sha(W / 'lean-toolchain'), 'preparer_sha256': file_sha(Path(__file__)),
      'external_inventory_status': 'SEPARATE_READ_ONLY_FOLLOWUP_PENDING'})
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert all((W / p).read_bytes() == b for p, b in current.items())
print('WROTE', OUT, flush=True)
