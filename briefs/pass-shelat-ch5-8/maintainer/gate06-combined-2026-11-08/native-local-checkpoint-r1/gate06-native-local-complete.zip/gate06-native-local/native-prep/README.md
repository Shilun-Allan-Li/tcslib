# Combined Gate06/S2 native preparation

Preparation only for `a495f3953afff46ad5dec2d29ac8a7f55bd8ae37`, audited Gate06 ancestor `3f6db40e1688c4a0bb922c9575dd3bd2157a650b`, target `067c5d8d6dd436e62681d7dc607984c705dc80a2`. No native/cache process, object copy, package/source mutation, or merge clearance is asserted. Cleanup source and its reused S2 worktree are excluded.

The current 1,109 tracked library/root/PSChecks Lean files equal the in-memory HEAD archive, with no extra/missing Lean file in that source set. The 18 raw-source changes are exactly the receipt's five accepted S2 files plus thirteen comment files. The five S2 sources equal accepted `d8c4cfed793f04062e7e79b78344e5b593ff3ddc` bytes. The configuration and checker bytes equal the audited Gate06 version. The receipt bytes are retained separately in `combined-source-receipt.snapshot.json`.

## Local order and source/object provenance

* `plan-r1/order.txt`: the complete 1,075-module local prerequisite closure of **`TCSlib` and `audits/pass-shelat/Checks`**, also containing every affected/downstream module. No affected orphan lies outside this root/Checks closure. The other 34 tracked Lean files are neither in that closure nor affected by the 18 changes.
* `plan-r1/modules.json`: ordered rows `{module, source_sha256, local_imports, external_imports}`; local module paths omit `.lean`, external names are dotted. `root-checks-order.txt` is identical to the complete order. The parser skips nested/continued comments and agrees exactly with all 467 historical import lists.
* `plan-r1/affected-order.txt`: all 31 changed/downstream modules, including the root and the correctly named PSChecks file. Every one is scheduled for a fresh check.
* `plan-r1/copy-plan.json`: 437 individual reusable object files from **main `.lake/ps-maintainer/oleans-gate06-r1`**, each with current source SHA, object SHA/size and exact direct-local prerequisite object hashes. Its dependency set is closed. Copy only these files into a new own tree, using regular copies, and revalidate immediately before copying. Do not copy the full 562-object historical tree: its other objects have not been selected.
* `plan-r1/rebuild-order.txt`: 638 fresh local checks (608 modules outside the old 467-module native closure plus 30 affected members of that closure). The old closure did not elaborate root `TCSlib.lean`; therefore replaying only the 31 affected modules would be incomplete.
* `recommended-reproductions.json`: three unchanged representative copied modules, with exact expected object hashes. `replay-with-reproductions-order.txt` adds them to the 638 required fresh checks, yielding a topological **641-call** proposal. Check these representatives with the normal checker and compare bytes; retain any mismatch and invalidate dependent copied objects as needed. Do not report a comparison that was not run.

The operative historical source/object/prerequisite inventory is main `briefs/pass-shelat-ch5-8/maintainer/gate06-integration-2026-11-06/evidence-run/final-repair-seal-ready.json`, SHA256 `6ac4dde18e5c441f69f76cbbf4eb6a9bf5d40beed67634ef2a95bb9719da7f93`. All 467 actual historical object hashes, old source hashes and direct-local dependency hashes match. Their recorded native times are consistent. New-source hash changes and every affected copied dependency were excluded recursively, leaving 437. Historical prerequisite hashes were reconstructed by the earlier reconciler from latest successful native records and temporal checks; its runner did not capture them directly at each check's start. That limitation is preserved in `baseline-validation.json`.

Main `.lake/ps-maintainer/oleans-s2-final` remains read-only acceptance context. Its nine final native records and actual final object hashes match the accepted source. Its copied-tree manifest is SHA256 `9363076d520217afac061f60a5ff2cc0bbe5423d40ab008be29329310f8d7fee`. These records lack check-time direct-prerequisite hashes, and the S2 environment is not assumed interchangeable with Gate06. **Zero S2 objects are selected for copying**; the five accepted S2 modules are rebuilt against the combined environment.

## External prerequisite inventory

`external-r1/package-modules.json` contains 3,637 reached package-source modules; every reached source matches its Git blob at the root manifest's pinned revision. All eleven present package heads/URLs and tracked bytes match. Four absent documentation packages are not reached. No LeanAPAP source module is needed. The 173 encountered toolchain modules are treated as installed nonempty-object leaves; their transitive core source graph is not enumerated.

The current local closure directly imports **369 Mathlib roots**. The required three PFR roots have **31 PFR source modules** and **30 direct Mathlib boundary roots**. The union is **383**, derived from this combined source, rather than the old cleanup job's 389. Exact lists are `mathlib-direct-roots.txt`, `pfr-mathlib-boundary-roots.txt`, and `mathlib-full-union-roots.txt`.

At preparation time 549 required package objects were absent: 513 Mathlib, one batteries, four proofwidgets, and all 31 PFR objects. `missing-package-objects.json` preserves every identity. `narrowed-cache-roots.txt` lists 54 Mathlib roots whose parsed import closures cover all **518 missing non-PFR objects**. A parent-owned guarded narrowed `lake exe cache get` may use those explicit 54 arguments; never an unfiltered fetch. Run an ordinary-PATH import probe of the complete 383-root union after fetching and verify required object existence. Recheck the 146 historical direct Mathlib object hashes before relying on the copied Gate06 subset: they all matched at preparation, but cache work has not been run here.

These counts are availability/provenance findings, not a new native cache or import pass. The 146 historical direct Mathlib hashes are recorded in `historical-mathlib-object-validation.json`; no full historical hash inventory of their transitive package objects was available.

## PFR31 route proposal, not run

`external-r1/pfr-modules.json` binds all 31 exact source hashes, Git blobs and imports. `pfr-physical-order.txt` is the topological physical checker order, each path beginning `.lake/packages/PFR/PFR/` and omitting `.lean`. It covers exactly the already reviewed PFR source set at revision `e1095d58b7c6f10734988816f7764f2103b9bf29`. The existing PFR/LeanAPAP package build directories are absent; no package object tree is borrowed or copied.

`prepare_pfr_maintainer.py` is an **unexecuted configuration proposal** for the authorized current worktree and the existing pinned same-chat package source. Its CLI is `python3 -I <tool> NEW_OWN_TREE FRESH_RUNTIME`. It pins the current source head, external manifest hashes, package bindings, all 31 sources, actual Lean binary, and unchanged reviewed PFR-only driver `pfr_lean.py` (SHA256 `41fda9565be3f77462fe6f2f7b55b798c5bf34fbbc400a648f77e000eb36636d`). That driver remains under main `fills/cleanup-part2/issued-r1/environment-tools/`; using it supplies only an environment adapter, no cleanup code or worker scope.

The old `prepare_pfr.py` cannot be invoked unchanged: its worker-own-clone containment assertion rejects this authorized maintainer worktree's `.lake/packages` symlink. The new explicit maintainer configuration retains all source/pin/namespace checks and permits only the already identified main PFR source directory. It creates no source alias. Its only object namespace alias is `<NEW_OWN_TREE>/PFR -> .lake/packages/PFR/PFR` within the same new object tree. The unchanged checker writes physical PFR outputs into that tree. Each PFR Lean invocation uses its real package directory as `--root` and exactly:

```
-DautoImplicit=false
-DrelaxedAutoImplicit=false
-Dpp.unicode.fun=true
-Dpp.proofs.withType=false
```

Use the wrapper PATH **only for the 31 PFR checker calls** with `PFR_BOOTSTRAP_CONFIG` pointing to the generated config. Restore ordinary PATH for cache, every TCSlib check and every probe. The previous `PFRIdentityProbe.source.txt` is available as a model for an ordinary-PATH scratch owner/identity probe; retain its original hash if used, and require complete installation/owner/EOF checks. No such probe was executed by this preparation. The parent should review the new preparer's source before invoking it.

## Parent-owned execution and reconciliation

1. Reconfirm source head/bytes, host exclusivity/resources, package pins and checker. Create a fresh own combined object tree; leave both accepted baseline trees unchanged. Rehash the 437 selected source/object/dependency records before individual regular copying; no hardlinks, shared mutations or S2 overlay.
2. Fetch only the 54 explicitly listed narrowed cache roots if still missing. Verify the 383-root ordinary-PATH import probe and old 146 direct hashes. Configure and compile the 31 PFR modules one at a time through the unchanged checker; require the ordinary-PATH PFR identity/owner probe before root dependencies.
3. Replay the 641-call proposed order (or the 638 required rebuilds plus separately recorded three copy reproductions) with ordinary PATH, `TCSLIB_OLEANS` fixed to the new tree, and only `bash scripts/lean_check_tree.sh <module>` for each check. Every direct local prerequisite must already exist in that tree at its expected hash; do not rely on an old fallback tree. Current worktree `.lake/build/lib/lean` is absent.
4. Capture head/source SHA, direct local and external object hashes **before** each call, source SHA after, actual return code/error count/fresh nonempty output and output SHA. Use unique attempt directories/logs and retain every failure; never let an older rc0 record mask a later failed attempt. A missing prerequisite is a setup failure, not a successful or skipped proof check. Stop before dependent checks on failure.
5. Reconcile all 1,075 selected source/object/direct-prerequisite identities against the latest current-phase results or the explicitly validated copied records. Root and PSChecks must themselves have fresh rc0/no-error/fresh-object results. Record the warm baseline reuse accurately; this is not a cold full-library run.

Historical `evidence-run/run.py`, `setup.py` and `reconcile_final.py` are models, not directly reusable launchers: they bind the old tree/scope, omit check-time prerequisite hashes, and reconciliation selects latest successful records. `gate06/s2_native.py` hardcodes and would mutate the accepted S2 tree. Do not run them unchanged. Parent authors and guards the actual serial launcher.

The three own preparation sources parse successfully; `validation.json` records sixteen static source/hash/graph checks. `NATIVE-PREP-MANIFEST.json` hashes the preparation artifacts without a self-hash cycle. This work changes only ignored preparation data/tools; no native/cache/object/source mutation was performed.

**Ready to run**
