"""PROPOSAL: configure the authorized maintainer PFR31 checks, no native run.

Usage: python3 -I prepare_pfr_maintainer.py NEW_OWN_TREE FRESH_RUNTIME
This explicit maintainer adaptation permits only the already-pinned same-chat
package source directory. It neither copies packages/objects nor creates a source
alias. The reviewed PFR-only driver is unchanged. Root reviews before invoking.
"""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import tomllib

W = Path('/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4')
M = Path('/Users/seyoonr/phd_experiments/tcslib_all_branches/tcslib-pass-shelat-ch2-4')
HERE = Path(__file__).resolve().parent
AREA = HERE.parent
EXTERNAL = HERE / 'external-r1'
HEAD = 'a495f3953afff46ad5dec2d29ac8a7f55bd8ae37'
PIN = 'e1095d58b7c6f10734988816f7764f2103b9bf29'
DRIVER = M / 'briefs/pass-shelat-ch5-8/fills/cleanup-part2/issued-r1/environment-tools/pfr_lean.py'
DRIVER_SHA = '41fda9565be3f77462fe6f2f7b55b798c5bf34fbbc400a648f77e000eb36636d'
REAL = Path('/Users/seyoonr/.elan/toolchains/leanprover--lean4---v4.25.0/bin/lean')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(root, *args): return subprocess.check_output(['git', '-C', str(root), *args])


def main():
    assert len(sys.argv) == 3
    tree, runtime = [Path(x).absolute() for x in sys.argv[1:]]
    assert Path.cwd().resolve() == W and git(W, 'rev-parse', 'HEAD').decode().strip() == HEAD
    assert tree.resolve().is_relative_to(AREA.resolve()) and tree.resolve() != AREA.resolve()
    assert not tree.is_symlink() and not runtime.exists() and not runtime.is_symlink()
    assert runtime.parent.resolve().is_relative_to(AREA.resolve()) and not runtime.is_relative_to(tree)
    assert sha(EXTERNAL / 'summary.json') == '72254a3921c878ef0d6897dfd377aee726f299e24737321e9808cb8bbbc306cf'
    assert sha(EXTERNAL / 'pfr-modules.json') == 'd413955ae03a8d49ccdf900012a3e9d757e8d680e59f2741469d10b31b750d58'
    assert sha(EXTERNAL / 'package-bindings.json') == '14c7153a344d0825202ed7f85def98fd825bb884147f9a713afc23f36308a22b'
    assert sha(DRIVER) == DRIVER_SHA
    assert sha(REAL) == '2974847fff2e2621502841f4c2dbac4035b4847d6060a4f2087cbc0d04005e37'
    assert (W / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.25.0'
    package = (W / '.lake/packages/PFR').resolve(strict=True)
    assert package == (M / '.lake/packages/PFR').resolve(strict=True)
    assert git(package, 'rev-parse', 'HEAD').decode().strip() == PIN
    assert (package / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.25.0'
    lakefile = package / 'lakefile.toml'
    assert lakefile.read_bytes() == git(package, 'show', PIN + ':lakefile.toml')
    options = tomllib.loads(lakefile.read_text())['leanOptions']
    assert options == {'autoImplicit': False, 'relaxedAutoImplicit': False,
                       'pp': {'unicode': {'fun': True}, 'proofs': {'withType': False}}}
    bindings = json.loads((EXTERNAL / 'package-bindings.json').read_text())
    for row in bindings:
        if row['status'] == 'ABSENT': continue
        root = Path(row['path'])
        assert root.resolve(strict=True) == Path(row['resolved_path'])
        assert git(root, 'rev-parse', 'HEAD').decode().strip() == row['revision']
        assert git(root, 'remote', 'get-url', 'origin').decode().strip() == row['url']
        assert not git(root, 'diff', '--name-only', row['revision'], '--').strip()
    sources, seen = {}, set()
    for row in json.loads((EXTERNAL / 'pfr-modules.json').read_text()):
        assert row['package'] == 'PFR'
        rel = '.lake/packages/PFR/' + row['package_relative_source']
        path = (W / rel).resolve(strict=True)
        assert path == package / row['package_relative_source'] and path.is_relative_to(package / 'PFR')
        assert sha(path) == row['source_sha256']
        assert git(package, 'rev-parse', PIN + ':' + row['package_relative_source']).decode().strip() == row['git_blob']
        assert all(d in seen if d.startswith('PFR.') else d.startswith('Mathlib.') for d in row['imports'])
        sources[rel] = {'sha256': row['source_sha256'], 'module': row['module'], 'git_blob': row['git_blob']}
        seen.add(row['module'])
    assert len(sources) == 31
    assert (EXTERNAL / 'pfr-physical-order.txt').read_text() == '\n'.join(x.removesuffix('.lean') for x in sources) + '\n'
    tree.mkdir(parents=True, exist_ok=True)
    physical = tree / '.lake/packages/PFR/PFR'
    assert physical.resolve().is_relative_to(tree.resolve())
    physical.mkdir(parents=True, exist_ok=True)
    logical = tree / 'PFR'
    if logical.exists() or logical.is_symlink():
        assert logical.is_symlink() and logical.resolve(strict=True) == physical.resolve(strict=True)
    else:
        logical.symlink_to('.lake/packages/PFR/PFR', target_is_directory=True)
    runtime.mkdir(parents=True, exist_ok=False)
    binary = runtime / 'bin'; binary.mkdir()
    config = {'clone': str(W), 'tree': str(tree.resolve()), 'real_lean': str(REAL.resolve()),
              'real_lean_sha256': sha(REAL), 'pfr_package_pin': PIN, 'pfr_lakefile_sha256': sha(lakefile),
              'sources': sources, 'driver_sha256': DRIVER_SHA, 'package_bindings': bindings,
              'object_namespace_alias': {'path': str(logical), 'relative_target': '.lake/packages/PFR/PFR'},
              'source_aliases_created': False, 'native_execution_performed': False,
              'authorized_maintainer_shared_package_root': str(package), 'head': HEAD,
              'preparer_sha256': sha(Path(__file__)), 'external_plan_sha256': sha(EXTERNAL / 'summary.json')}
    cfg = runtime / 'config.json'; cfg.write_text(json.dumps(config, indent=2) + '\n')
    entry = binary / 'lean'
    entry.write_text('#!/usr/bin/env bash\nexec python3 -I ' + shlex.quote(str(DRIVER)) + ' "$@"\n')
    entry.chmod(0o755)
    print(json.dumps({'config': str(cfg), 'config_sha256': sha(cfg), 'wrapper_bin': str(binary),
                      'sources': 31, 'native_performed': False,
                      'path_rule': 'Use this PATH only for the31 PFR calls; ordinary PATH for cache/TCSlib/probes.'}, indent=2))


if __name__ == '__main__': main()
