import TCSlib.Complexity.Randomized.SeedMajority
import TCSlib.Complexity.Randomized.QuasiPolyHierarchy

/-! Consumer probe (statement PR, seed-majority host): the last step of
`bpp_subset_dtime_subexp` read through published readers only. Given the contract, the
majority reader and a pointwise bound `2^{w n} (n+1)^e ≤ c T n`, the probabilistic-majority
language is in `DTIME T`. `DTIME`, `randProb`, `P`, `PolyTimeComputable` and `pairEncode` are
sealed; the control below reads `DTIME` through its body and must fail exactly once. -/

set_option autoImplicit false


open Complexity

open Classical in
example {V : Language Bool} (hV : V ∈ P) (w : ℕ → ℕ)
    (hw : PolyTimeComputable fun x => List.replicate (w x.length) true) (T : ℕ → ℕ)
    (hT : ∀ e : ℕ, ∃ c : ℕ, ∀ n, 2 ^ w n * (n + 1) ^ e ≤ c * T n) :
    {x : List Bool | 1 / 2 < Randomized.randProb (w x.length)
        fun r => Turing.pairEncode x r ∈ V} ∈ DTIME T := by
  obtain ⟨e, he⟩ := seedMajority_mem_DTIME hV w hw
  obtain ⟨c, hc⟩ := hT e
  have hset : {x : List Bool | 1 / 2 < Randomized.randProb (w x.length)
        fun r => Turing.pairEncode x r ∈ V} =
      {x : List Bool | 2 ^ w x.length <
        2 * (Finset.univ.filter fun u : Fin (w x.length) → Bool =>
          Turing.pairEncode x (List.ofFn u) ∈ V).card} := by
    ext x
    exact Randomized.half_lt_randProb_iff _ _
  rw [hset]
  exact Randomized.DTIME_const_mul_subset c T (DTIME.mono hc he)

-- CONTROL (must fail sealed, exactly once): builds `DTIME` membership through its body.
example (L : Language Bool) (M : Turing.FinTM Bool) (T : ℕ → ℕ)
    (h : M.DecidesInTime L fun n => 1 * T n) : L ∈ DTIME T := ⟨1, M, h⟩

#print axioms Complexity.seedMajority_mem_DTIME
#print axioms Randomized.half_lt_randProb_iff
