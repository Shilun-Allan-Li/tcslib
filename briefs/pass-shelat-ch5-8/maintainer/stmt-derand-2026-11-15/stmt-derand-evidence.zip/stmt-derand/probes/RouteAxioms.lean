import TCSlib.Complexity.TuringMachine.Build.Loop
import TCSlib.Complexity.TuringMachine.Build.ModuleHost
import TCSlib.Complexity.Randomized.Build.IterateFind
import TCSlib.Complexity.ClassNP.EXP
import TCSlib.Complexity.ClassP.BinaryArith.AddSub
import TCSlib.Complexity.ClassNP.PolyTimePairing
import TCSlib.Complexity.ClassNP.PClosure
import TCSlib.Complexity.Randomized.QuasiPolyHierarchy

/-! Route-lemma axiom probe for the seed-majority host (statement PR). Every lemma the
feasibility route names must be free of `sorryAx`. -/

#print axioms Turing.FinTM.exists_loopFindTM
#print axioms Turing.FinTM.exists_loopCfgTM
#print axioms Turing.ModuleHost.clean_install
#print axioms Turing.ModuleHost.clean_emit
#print axioms Turing.ModuleHost.host_call
#print axioms Turing.ModuleHost.host_clean
#print axioms Turing.ModuleHost.guard_add
#print axioms Turing.ModuleHost.request_budget
#print axioms Complexity.IterateFind.copy_clean
#print axioms Complexity.IterateFind.host_dispatch
#print axioms Complexity.IterateFind.host_branch
#print axioms Complexity.IterateFind.host_halt
#print axioms Complexity.IterateFind.polyTimeComputable_find
#print axioms Complexity.exists_proj_decider
#print axioms Turing.FinTM.computesFunInTime_incFixed
#print axioms Turing.FinTM.computesFunInTime_lengthBits
#print axioms Complexity.BinArith.polyTimeComputable_add
#print axioms Complexity.BinArith.polyTimeComputable_lt
#print axioms Complexity.BinArith.polyTimeComputable_beq
#print axioms Complexity.polyTimeComputable_ite
#print axioms Complexity.polyTimeComputable_of_linear
#print axioms Complexity.PolyTimeComputable.output_length_le
#print axioms Complexity.mem_P_iff_polyTimeComputable
#print axioms Complexity.preimage_mem_P
#print axioms Complexity.DTIME.mono
#print axioms Randomized.DTIME_const_mul_subset
