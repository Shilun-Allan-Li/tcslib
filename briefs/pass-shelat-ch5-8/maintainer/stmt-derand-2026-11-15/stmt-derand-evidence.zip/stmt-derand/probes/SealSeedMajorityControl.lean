/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Complexity.ClassP.P
import TCSlib.Complexity.ClassNP.PolyTime
import TCSlib.Complexity.TuringMachine.Encoding
import TCSlib.Complexity.Randomized.Classes

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

-- SEAL (whole-file): foreign definitions read only through readers
attribute [local irreducible] Randomized.randProb Complexity.DTIME Complexity.P
  Complexity.PolyTimeComputable Turing.pairEncode

/-!
# Deterministic majority over all seeds (statement phase)

The counting enumeration host: a deterministic machine that, on input `x`, runs a
polynomial-time test on `⟨x, u⟩` for **every** seed `u ∈ {0,1}^{w(|x|)}`, counts the accepting
seeds, and accepts iff more than half of them accept, in time `2^{w(n)} · poly(n)`. It is the
enumeration behind `BPP ⊆ EXP` [AB09, §7.1, p. 126] (run the machine on every random string
and count the accepting ones) and step 4 of the proof of [PS10, §8.2, Theorem 180.1] (run the
derandomized verifier on every seed of the generator and take the majority). It is a *host* in
the sense of `policy.md` §1 (*Hosts come first*): an odometer over all seeds, generic in the
leaf test `V` and in the width `w`. Its contract is stated here, ahead of its consumers, by
Seyoon's ruling of 2026-11-14; the proof is a separate fill.

**The formal reading.**
- **The test** is a language `V ∈ P` read on `Turing.pairEncode x u`, the library's two-argument
  convention (`Randomized.polyTimeModel`'s verifiers are read the same way), so that the test may
  depend on the input `x` as well as on the seed `u`.
- **The width** `w : ℕ → ℕ` depends on the input length only, and its unary word
  `x ↦ 1^{w(|x|)}` is polynomial-time computable. This makes `w` computable by the machine and
  bounds it polynomially (`Complexity.PolyTimeComputable.output_length_le`); it is otherwise
  arbitrary, so a consumer may use a non-polynomial schedule such as an integer root, or a
  piecewise one.
- **The count** is `#{u : Fin (w |x|) → Bool | ⟨x, u⟩ ∈ V}`, the numerator of
  `Randomized.randProb` (`Randomized.half_lt_randProb_iff` converts), and **majority** is the
  strict `2^{w(|x|)} < 2 · count`, so ties reject.
- **The time** is the class `DTIME (n ↦ 2^{w(n)} · (n+1)^e)` for some degree `e`: the machine
  is left existential and is read only through `DTIME`'s published readers (`DTIME.mono`,
  `Randomized.DTIME_const_mul_subset`). Membership in `DTIME` carries both halves of the
  contract: correctness (the machine decides exactly the majority language) and the time bound.

## Main results

* `Complexity.seedMajority_mem_DTIME` — the host's contract (stated; a `sorry` under the route
  below). [AB09, §7.1, p. 126]; [PS10, Theorem 180.1, step 4 of the proof]
* `Randomized.half_lt_randProb_iff` — majority as a probability:
  `1/2 < randProb m A ↔ 2^m < 2 · #{r | A r}` (proved).

## Consumers

* `TCSlib.Cryptography.Randomness.bpp_subset_dtime_subexp` ([PS10, Theorem 180.1]), with
  `V = {⟨x, u⟩ | M(x; G(u)↾m(|x|))}` and the seed schedule `w(n) = ℓ(n)` (the least `t` with
  `n ≤ t^d`); the true coins `w(n) = m(n)` below a threshold length replace the finite table.
* Prospectively, `BPP ⊆ EXP` by coin enumeration [AB09, p. 126] (`w = polyLen a k`), which
  `Randomized.mem_EXP_of_inBPP_polyTimeModel` currently obtains through Sipser–Gács.

## Design

* The nearest relative is the existential projection decider `Complexity.exists_proj_decider`
  (`ClassNP/EXP.lean`): the same odometer with an *any* verdict, a fixed width `C(n+1)^c` and
  the test on `x ++ u`. Its engine `enumMachine_contracts` and the `enumCont_*` body are
  private, it does not count, and its width is not a parameter, so it is not reused.
* The polynomial block-majority tests (`Complexity.polyTimeComputable_blockMajorityTest`) count
  over polynomially many blocks; this host counts over exponentially many seeds.
* The test is polynomial-time (`V ∈ P`), not a decider of arbitrary time `Tv` as in
  `exists_proj_decider`: both consumers have polynomial tests, and the clean-module host below
  installs polynomial-time word functions only (`Turing.ModuleHost.clean_install`).
* No head-envelope (space) clause is exposed: the contract is stated at the decision layer, as
  `exists_proj_decider` is, because its consumers need only time.

## Route for the proof (the fill)

1. *State loop.* The state word is `⟨x, ⟨i, a⟩⟩`: the binary rank `i` of the current seed and
   the binary acceptance count `a`, from `⟨x, ⟨0, 0⟩⟩`. A step tests `⟨x, word_w(i)⟩ ∈ V`,
   where `word_w(i)` is the width-`w(|x|)` binary word of `i`, adds the verdict to `a` and
   increments `i`. The loop stops when `i = 2^{w(|x|)}` and outputs `[decide (2^w < 2a)]`.
   Every piece is a polynomial-time word function of the state (`Complexity.BinArith`'s
   `add`, `lt` and `beq`, zero padding, the unary width, and `V`'s decider through
   `Complexity.mem_P_iff_polyTimeComputable`).
2. *Machine.* The result-bearing loop combinator `Turing.FinTM.exists_loopFindTM` over the
   clean-module host (`Turing.ModuleHost`, with `Complexity.IterateFind.hostTM`, `hostCtrl`,
   `hostRet`, `copyTM` and their run lemmas), exactly as in
   `Complexity.IterateFind.polyTimeComputable_find`, but with the exponential fuel
   `R(n) = 2^{w(n)}`, written as `Nat.bits (2^{w(|x|)})`
   (`w(|x|)` zeros, then a one) from the unary width. The combinator's bound is
   `c (T(n) + 1)(R(n) + 2)`, with `T` polynomial because every state word has length
   `O(n + w(n))` and `w(n) ≤ C(n+1)^c`. The admitted `loopHostTM_*` and `timedCondTM_*` specs
   are not used: `exists_loopFindTM` is proved from the private `loopHost_contracts`.
3. *Count.* The first stopping round is `2^{w(|x|)}`; there `a` counts the ranks `i < 2^w`
   whose word is accepted, which is the `Finset` count above through the bijection
   `i ↦ word_w(i)` between `[0, 2^w)` and `{0,1}^w`.
4. *Normal form.* `c (T(n) + 1)(2^{w(n)} + 2) ≤ b · 2^{w(n)} · (n+1)^e`, and `b` is absorbed by
   `DTIME`.

## References

* [AB09] S. Arora, B. Barak, *Computational Complexity: A Modern Approach*, Cambridge University
  Press, 2009, §7.1, p. 126 (`BPP ⊆ EXP` by enumerating the random strings) and Claim 2.4 (the
  enumeration argument of `NP ⊆ EXP`).
* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §8.2, Theorem 180.1 (book p. 180).
-/

namespace Randomized

open Finset

/-- **Majority as a probability.** For an event `A` on `m`-bit strings, the uniform probability
of `A` exceeds `1/2` exactly when more than half of the `2^m` strings satisfy it:
`1/2 < randProb m A ↔ 2^m < 2 · #{r : Fin m → Bool | A (List.ofFn r)}`. This converts the
counting form of `Complexity.seedMajority_mem_DTIME` into the probabilistic form of
[AB09, Def 7.3] and [PS10, Theorem 180.1]. -/
theorem half_lt_randProb_iff (m : ℕ) (A : List Bool → Prop) [DecidablePred A] :
    1 / 2 < randProb m A ↔
      2 ^ m < 2 * (univ.filter fun r : Fin m → Bool => A (List.ofFn r)).card := by
  rw [randProb_eq, lt_div_iff₀ (by positivity), ← Nat.cast_lt (α := ℚ)]
  push_cast
  constructor <;> intro h <;> linarith

end Randomized

namespace Complexity

open Turing

open Classical in
/-- **Deterministic majority over all seeds** [AB09, §7.1, p. 126]; [PS10, §8.2,
Theorem 180.1, step 4 of the proof]: for a test `V ∈ P` on paired words and a width
`w : ℕ → ℕ` whose unary word `x ↦ 1^{w(|x|)}` is polynomial-time computable, some degree `e`
puts the strict-majority language in `DTIME (n ↦ 2^{w(n)} · (n+1)^e)`:
`∃ e, {x | 2^{w(|x|)} < 2 · #{u : Fin (w |x|) → Bool | pairEncode x (List.ofFn u) ∈ V}}
∈ DTIME (fun n => 2^{w(n)} · (n+1)^e)`.
Membership in `DTIME` is the whole contract: a machine decides exactly this language
(correctness) within `c · 2^{w(n)} · (n+1)^e` steps (time). Ties (`2 · count = 2^w`) reject.

**Deviation.** The source's machine runs the test on every seed and counts; here the test is a
`P`-language on `Turing.pairEncode x u` and the count is a `Finset` count over
`Fin (w |x|) → Bool`, the numerator of `Randomized.randProb` (`Randomized.half_lt_randProb_iff`).

**Proof sketch** (the route of the module docstring).
1. Run the state loop `⟨x, ⟨i, a⟩⟩ ↦ ⟨x, ⟨i + 1, a + [⟨x, word_w(i)⟩ ∈ V]⟩⟩` from
   `⟨x, ⟨0, 0⟩⟩`, stopping at `i = 2^{w(|x|)}` with the payload `[2^w < 2a]`; each piece is a
   polynomial-time word function of the state.
2. Build the machine with the loop combinator `Turing.FinTM.exists_loopFindTM` over the
   clean-module host, as in `Complexity.IterateFind.polyTimeComputable_find`, with the fuel
   `Nat.bits (2^{w(|x|)})`; it halts within `c (T(n) + 1)(2^{w(n)} + 2)` with `T` polynomial,
   since `w(n) ≤ C (n+1)^c` (`PolyTimeComputable.output_length_le`).
3. At the stopping round, `a` is the number of accepted ranks `i < 2^w`, which equals the
   `Finset` count through the bijection `i ↦ word_w(i)` onto `{0,1}^w`.
4. Bound `c (T(n) + 1)(2^{w(n)} + 2)` by `b · 2^{w(n)} · (n+1)^e` and absorb `b` into `DTIME`. -/
theorem seedMajority_mem_DTIME {V : Language Bool} (hV : V ∈ P) (w : ℕ → ℕ)
    (hw : PolyTimeComputable fun x => List.replicate (w x.length) true) :
    ∃ e : ℕ,
      {x : List Bool | 2 ^ w x.length <
          2 * (Finset.univ.filter fun u : Fin (w x.length) → Bool =>
            pairEncode x (List.ofFn u) ∈ V).card} ∈
        DTIME fun n => 2 ^ w n * (n + 1) ^ e := by
  sorry

end Complexity

-- CONTROL (must fail sealed, exactly once): reads `randProb` through its body.
example (m : ℕ) (A : List Bool → Prop) [DecidablePred A] :
    Randomized.randProb m A =
      ((Finset.univ.filter fun r : Fin m → Bool => A (List.ofFn r)).card : ℚ) / 2 ^ m := rfl
