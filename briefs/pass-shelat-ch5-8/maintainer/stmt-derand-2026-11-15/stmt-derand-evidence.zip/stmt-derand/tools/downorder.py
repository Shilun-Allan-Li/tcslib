"""downorder.py <worktree> <changed-file> <out>: the downstream closure of the changed modules over
every module of TCSlib/**, audits/** and TCSlib.lean (by their `import` lines), in imports-first
order; a changed module is included even when nothing imports it."""
import sys, os, re
wt, chf, out = sys.argv[1:4]
changed = [l.strip() for l in open(chf) if l.strip()]
mods = {}
for top in ('TCSlib', 'audits'):
    for d, ds, fs in os.walk(os.path.join(wt, top)):
        for f in fs:
            if f.endswith('.lean'):
                p = os.path.join(d, f)
                mods[os.path.relpath(p, wt)[:-5]] = p
mods['TCSlib'] = os.path.join(wt, 'TCSlib.lean')
deps = {}
for m, p in mods.items():
    src = open(p, encoding='utf-8').read()
    deps[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', src, re.M)]
rev = {}
for m, ds in deps.items():
    for d in ds: rev.setdefault(d, set()).add(m)
closure, todo = set(changed), list(changed)
while todo:
    m = todo.pop()
    for r in rev.get(m, ()):
        if r not in closure: closure.add(r); todo.append(r)
done, order = set(), []
def visit(m, stack=()):
    if m in done: return
    if m in stack: raise SystemExit('cycle at ' + m)
    for d in sorted(deps.get(m, [])):
        if d in closure: visit(d, stack + (m,))
    done.add(m); order.append(m)
for m in sorted(closure): visit(m)
open(out, 'w').write('\n'.join(order) + '\n')
print(len(mods), 'modules scanned;', len(changed), 'changed;', len(order), 'in the downstream order')
