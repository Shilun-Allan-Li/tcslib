"""widths.py <repo> <base> <head>: for every file changed between <base> and <head>, its line
count and maximum line width (Python len, characters) at <head>; flags lines over 100 and files
over 1000 lines."""
import sys, subprocess
repo, base, head = sys.argv[1:4]
names = subprocess.run(['git', '-C', repo, 'diff', '--name-only', base, head], capture_output=True,
                       text=True, check=True).stdout.split()
bad = 0
for n in names:
    txt = subprocess.run(['git', '-C', repo, 'show', f'{head}:{n}'], capture_output=True,
                         check=True).stdout.decode('utf-8')
    lines = txt.split('\n')
    if lines and lines[-1] == '': lines = lines[:-1]
    w = max((len(l) for l in lines), default=0)
    over = [i + 1 for i, l in enumerate(lines) if len(l) > 100]
    ok = not over and len(lines) <= 1000
    bad += not ok
    print(f'{"OK " if ok else "BAD"} {n}: {len(lines)} lines, max width {w}, lines over 100: {over}')
print('RESULT', 'OK' if bad == 0 else f'{bad} BAD')
