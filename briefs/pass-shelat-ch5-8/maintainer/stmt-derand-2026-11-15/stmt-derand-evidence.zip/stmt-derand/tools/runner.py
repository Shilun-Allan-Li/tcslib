"""runner.py <worktree> <order> <tree> <logdir>
Checks modules in order, one Lean process at a time, through the worktree's
scripts/lean_check_tree.sh (byte-identical to /home/user/tcslib/scripts/lean_check_tree.sh) with
TCSLIB_OLEANS=<tree>. Per module: the full log <logdir>/mods/<module, / -> _>.log and a JSON line
in <logdir>/results.jsonl: rc; errors counted in both diagnostic forms (`error:` and `error(...)`,
G26-N1, regex below); sorry warnings with their positions; warnings; start/end UTC; seconds;
source and object SHA-256. Stops at the first failure."""
import sys, os, json, time, hashlib, subprocess, datetime, re
wt, order, tree, logdir = sys.argv[1:5]
os.makedirs(os.path.join(logdir, 'mods'), exist_ok=True)
env = dict(os.environ)
env['PATH'] = os.path.expanduser('~/.elan/bin') + ':' + env['PATH']
env['TCSLIB_OLEANS'] = tree
ERR = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
SORRY = re.compile(r"^(\S+\.lean:\d+:\d+): warning: declaration uses 'sorry'", re.M)
WARN = re.compile(r'^\S+\.lean:\d+:\d+: warning', re.M)
mods = [l.strip() for l in open(order) if l.strip()]
def sha(p):
    if not os.path.exists(p): return None
    with open(p, 'rb') as h: return hashlib.sha256(h.read()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
res = open(os.path.join(logdir, 'results.jsonl'), 'a')
for m in mods:
    lp = os.path.join(logdir, 'mods', m.replace('/', '_') + '.log')
    t0 = time.time(); s0 = now()
    with open(lp, 'wb') as out:
        p = subprocess.run(['bash', 'scripts/lean_check_tree.sh', m], cwd=wt, env=env,
                           stdout=out, stderr=subprocess.STDOUT)
    txt = open(lp, encoding='utf-8', errors='replace').read()
    rec = dict(module=m, rc=p.returncode, errors=len(ERR.findall(txt)),
               error_substr=txt.count('error'), sorry=SORRY.findall(txt),
               warnings=len(WARN.findall(txt)), start=s0, end=now(),
               seconds=round(time.time() - t0, 2), source_sha256=sha(os.path.join(wt, m + '.lean')),
               object_sha256=sha(os.path.join(tree, m + '.olean')), log_sha256=sha(lp))
    res.write(json.dumps(rec) + '\n'); res.flush()
    print(m, p.returncode, rec['errors'], len(rec['sorry']), rec['seconds'], flush=True)
    if p.returncode != 0:
        res.write(json.dumps(dict(stopped_at=m, utc=now())) + '\n'); sys.exit(1)
res.write(json.dumps(dict(done=now(), order=os.path.basename(order))) + '\n')
