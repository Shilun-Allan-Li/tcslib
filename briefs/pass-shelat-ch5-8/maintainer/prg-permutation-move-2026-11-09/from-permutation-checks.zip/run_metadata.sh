#!/usr/bin/env bash
set -euo pipefail
a=$1
w=$2
side=$3
m="$a/metadata"
lower=$(printf '%s' "$side" | tr '[:upper:]' '[:lower:]')
if [[ $side == Head ]]; then
  while true; do
    r=$(find "$a/native" -maxdepth 2 -name check-0007.json -print -quit)
    if [[ -n $r ]]; then
      python3 -I - "$r" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r["rc"]==0 and r["module"]=="TCSlib/Cryptography/Asymptotic/HardCorePermutation"
PY
      break
    fi
    sleep 4
  done
fi
python3 -I "$a/prepare_probes.py" "$a" "$side"
lean=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$a/native/PLAN.json")
tree="$m/$lower/oleans"
if [[ $side == Base ]]; then route=BaseRouteImport; else route=FromPermutationImport; fi
bash "$a/run_probes.sh" "$lean" "$tree" "$m/${side}Census" "$m/${side}LegacyHardCore" "$m/${side}LegacyPermutation" "$m/$route"
python3 -I "$a/prepare_seals.py" "$a" "$w" "$side"
target="$m/$lower-seals"
if [[ $side == Base ]]; then
  if ! python3 -I "$a/verify_baseline_seal_transfer.py" "$a"; then
    bash "$a/run_probes.sh" "$lean" "$tree" "$target/HardCoreSeal" "$target/HardCorePermutationSeal"
  fi
  bash "$a/run_probes.sh" "$lean" "$tree" "$target/HardCoreClaimsSeal"
else
  bash "$a/run_probes.sh" "$lean" "$tree" "$target/FromPermutationSeal" "$target/FunctionsSeal" \
    "$target/GoldreichLevinSeal" "$target/HardCoreClaimsSeal" "$target/UnsealedControl" "$target/SealedControl" "$target/ReaderControl"
fi
