"""Reuse the old seal runs only if the imported and instrumented inputs match."""
import json
from hashlib import file_digest
from pathlib import Path
import shutil
import sys

area = Path(sys.argv[1]).resolve()
previous = area.parent / "prg-stretch-move-20261109"
old_meta = previous / "metadata-r3/head-seals"
new_meta = area / "metadata/base-seals"
receipt = json.loads((previous / "records/prg-stretch-move-2026-11-09/VERIFICATION.json").read_bytes())
assert receipt["head"] == (area / "accepted-266.txt").read_text().strip()
verified = receipt["artifact_sha256"]


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


pending = []
for name in ("HardCoreSeal", "HardCorePermutationSeal"):
    old = old_meta / name
    new = new_meta / name
    a, b = read(old.with_suffix(".json")), read(new.with_suffix(".json"))
    assert all(a[k] == b[k] for k in ("requests", "source_path", "source_sha256", "probe_sha256", "line_map"))
    assert sha(old.with_suffix(".lean")) == sha(new.with_suffix(".lean")) == a["probe_sha256"]
    for suffix in (".json", ".lean", ".rc", ".log", ".resources.txt"):
        src, dest = old.with_suffix(suffix), new.with_suffix(suffix)
        assert sha(src) == verified[src.relative_to(previous).as_posix()], src
        if suffix not in (".json", ".lean"):
            pending.append((src, dest))
for src, dest in pending:
    shutil.copyfile(src, dest)
    assert sha(src) == sha(dest)
(new_meta / "TRANSFERS.json").write_text(json.dumps({
    "predecessor": receipt["head"],
    "method": "predecessor inputs checked by source and object digest and identical instrumented source and mask",
    "files": {dest.name: sha(dest) for src, dest in pending},
}, indent=2) + "\n")
print("Transferred both previously verified exact-source baseline seal receipts.", flush=True)
