import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
root = Path.cwd()
spec = importlib.util.spec_from_file_location("campaign_style_lint", root / "scripts/campaign_style_lint.py")
lint = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lint)
paths = [name + ".lean" for name in json.loads((Path(sys.argv[1]) / "SOURCE-CHECK.json").read_bytes())["changed_paths"]]
paths.append("TCSlib/Cryptography/Pseudorandom/Generators.lean")
for name in paths:
    file = root / name
    if file.is_file():
        lint.check_file(file)
        if lint.is_facade(file):
            lint.check_facade(file)
print(json.dumps(lint.findings, indent=2))
