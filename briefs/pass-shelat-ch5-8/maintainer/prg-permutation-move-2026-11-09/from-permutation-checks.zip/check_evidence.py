"""Verify the replay and reconcile the whole-file seals with the cleanup ledger."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))
prefix = "TCSlib/Cryptography/"
hc = prefix + "Asymptotic/HardCore"
prg = prefix + "Pseudorandom/Generators/Asymptotic/FromPermutation"
paths = campaign / "briefs/pass-shelat-ch5-8/maintainer"
prev = paths / "prg-stretch-move-2026-11-09"
ledger_dir = paths / "cleanup-incremental-2026-11-09/final-r1"
native = area / "native"
meta = area / "metadata"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def content(rev, path):
    return git("show", f"{rev}:{path}")


def normalize(text):
    return re.sub(r"\?m\.\d+", "?m", text)


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source = read(area / "SOURCE-CHECK.json")
assert result["passed"] and plan["head"] == result["head"] == source["head"] == head
assert plan["base"] == result["base"] == source["base"] == base
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == len(plan["affected"]) == 54
assert result["initial_retained"] == len(plan["retained"]) == 1040
assert len(products) == len(plan["order"]) == 1094 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checked = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checked[row["module"]] = row["object_sha256"]
assert checked == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain")
assert not git("diff", "--check", base, head)
assert "0 findings in 8 files" in (area / "style.log").read_text()
declarations = read(area / "DECLARATIONS.json")
assert declarations["head"] == head and declarations["base"] == base and declarations["axioms_match"]
assert declarations["matched_declarations"] == 151 and source["moved_proof_and_definition_source_bytes_match"]

diagnostics, receipts = {}, {}
for side, rev in (("base", base), ("head", head)):
    directory = meta / (side + "-seals")
    scope = read(directory / "SCOPE.json")
    labels = set(scope) | ({"UnsealedControl"} if side == "head" else set())
    assert {p.stem for p in directory.glob("*.rc")} == labels
    diag = {}
    receipts[side] = {}
    for label in sorted(labels):
        path = directory / label
        log = path.with_suffix(".log").read_text()
        count = scope.get(label, 0)
        manifest = read(path.with_suffix(".json")) if label in scope else {}
        if count:
            assert count == len(manifest["requests"])
            assert sha(path.with_suffix(".lean")) == manifest["probe_sha256"]
            assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
            assert len({(r["home"], r["spelling"]) for r in manifest["requests"]}) == count
        pattern = r"\.lean:(\d+):(\d+): error: (.*?)(?=\n(?:G06-|[^\n]*\.lean:\d+:\d+:)|\Z)"
        errors = re.findall(pattern, log, flags=re.S)
        assert len(errors) == len(re.findall(r"\.lean:\d+:\d+: error:", log))
        rc = int(path.with_suffix(".rc").read_text())
        assert rc == int(bool(errors))
        if label.endswith("Seal"):
            source_path = manifest["source_path"]
            raw = content(rev, source_path)
            assert sha256(raw).hexdigest() == manifest["source_sha256"]
            lines = raw.decode().splitlines()
            mapping = {r["probe_line"]: r["source_line"] for r in manifest["line_map"]}
            assert sorted(mapping.values()) == list(range(1, len(lines) + 1))
            for probe_line, col, msg in errors:
                line = mapping[int(probe_line)]
                assert (source_path, line) not in diag
                diag[source_path, line] = {"source": lines[line-1], "column": int(col), "message": msg.rstrip()}
        elif label == "SealedControl":
            assert len(errors) == 1 and "Iff.rfl" in errors[0][2] and "P.HardCore" in errors[0][2]
        else:
            assert not errors
        receipts[side][label] = {"requests_verified": count, "errors": len(errors), "rc": rc,
                                 "probe_sha256": sha(path.with_suffix(".lean")),
                                 "log_sha256": sha(path.with_suffix(".log")),
                                 "source_sha256": manifest.get("source_sha256")}
    diagnostics[side] = diag
assert len(diagnostics["base"]) == len(diagnostics["head"]) == 8
boundary = read(meta / "head-seals/FromPermutationSeal.json")["requests"]
assert any(r["spelling"] == "TCSlib.Cryptography.PermFamily.HardCore" and
           r["home"] == "TCSlib.Cryptography.Asymptotic.HardCore.Functions" for r in boundary)

prev_receipt = read(prev / "VERIFICATION.json")
assert prev_receipt["head"] == plan["baseline"] and prev_receipt["passed"]
assert sha(prev / "VERIFICATION.json") == source["predecessor_receipt_sha256"]
assert sha(prev / "READS.json") == prev_receipt["artifact_sha256"]["READS.json"]
prior = read(prev / "READS.json")
old_hc = content(base, hc + ".lean").decode()
p0, p1, p2 = (old_hc.index(tag) for tag in ("/-! ## Hard-core predicates", "/-! ## The generator",
                                          "/-! ## Goldreich–Levin for function families"))
blocks = [(p0, p1, hc + "/Functions.lean"), (p1, p2, prg + ".lean"),
          (p2, len(old_hc), hc + "/Functions.lean")]
line_map = {}
for start, end, path in blocks:
    original = old_hc[start:end]
    text = content(head, path).decode()
    assert text.count(original) == 1
    old_start = old_hc[:start].count("\n") + 1
    new_start = text[:text.index(original)].count("\n") + 1
    for offset in range(len(original.splitlines())):
        line_map[old_start + offset] = (path, new_start + offset)
rows = []
for r in prior["diagnostics"]:
    if r.get("new_path") != hc + ".lean":
        continue
    old_line = r["new_line"]
    before = diagnostics["base"][hc + ".lean", old_line]
    assert before == r["new_diagnostic"], r["id"]
    new_path, new_line = line_map[old_line]
    after = diagnostics["head"][new_path, new_line]
    assert before["source"] == after["source"] and before["column"] == after["column"], r["id"]
    assert normalize(before["message"]) == normalize(after["message"]), (r["id"], before, after)
    rows.append({"id": r["id"], "disposition": "same_proof_step_new_home", "old_path": hc + ".lean",
                 "old_line": old_line, "new_path": new_path, "new_line": new_line, "diagnostic": after})
assert {(r["new_path"], r["new_line"]) for r in rows} == diagnostics["head"].keys()
assert {(r["old_path"], r["old_line"]) for r in rows} == diagnostics["base"].keys()

archive = ledger_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (ledger_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha == prior["ledger_archive_sha256"]
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
observations = ledger["current_observations"]
assert len(observations) == 813 and not ledger["partial"] and not ledger["needs_review"]
providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"]) for r in declarations["declarations"]
             if r["old_home"] != r["new_home"] and r["kind"] == "def"}
links = []
for r in observations:
    common = r.get("common_sealed_native_references", [])
    paired = [p["head"] for p in r.get("provider_pairs", []) if isinstance(p.get("head"), dict)]
    keys = {(x["home"], x["spelling"]) for x in common + paired}
    if r["channel"] == "generated-equation":
        keys.add((r["provider_home"], r["provider"]))
    if r["channel"] == "explicit-source":
        assert not any(name in str(r["head"]) for _, name in providers), r["id"]
    for old_home, name in sorted(keys & providers.keys()):
        new_home, new_name = providers[old_home, name]
        links.append({"id": r["id"], "path": r.get("current_owner") or r["path"], "line": r.get("head_line"),
                      "old_name": name, "new_name": new_name, "old_home": old_home, "new_home": new_home,
                      "evidence": "native reference or paired provider from the deferred ledger"})
assert {r["id"] for r in links} == {"SEAL-0309", "SEAL-0310", "SEAL-0311"}

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log
    assert "where the seal failed: 0 " in log
before, after = ({tuple(r) for r in read(area / f"campaign-lint-{side}.json")} for side in ("base", "head"))
fails = sorted(r for r in after - before if r[0] == "FAIL")
assert fails == [("FAIL", prefix + "Pseudorandom/Generators.lean",
                 f"facade does not import child module `{prg.replace('/', '.')}`")]
assert prg in plan["graph"][prefix + "Pseudorandom"]
warn_names = lambda rs: {name.strip() for level, _, msg in rs if level == "WARN" and "(check 8):" in msg
                         for name in msg.split("(check 8):", 1)[-1].split(",")}
assert warn_names(before) == warn_names(after)
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": receipts,
                           "baseline_diagnostics": 8, "head_diagnostics": 8, "new_diagnostics": 0,
                           "raw_campaign_facade_false_positives": fails, "new_reader_warnings": 0})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                           "ledger_archive_sha256": archive_sha, "prior_relocation_ledger_sha256": sha(prev / "READS.json"),
                           "moved_diagnostics": rows, "relocated_provider_links": links,
                           "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                           "foreign_generated_equation_references": {"base": 0, "head": 0}})
print("All 54 affected modules pass. The 8 seal diagnostics map to the exact baseline steps and 3 provider links move.")
