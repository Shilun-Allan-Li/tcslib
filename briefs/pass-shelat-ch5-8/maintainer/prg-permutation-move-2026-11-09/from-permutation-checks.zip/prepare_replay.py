"""Verify the merged predecessor and stage the exact new import graph."""
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, root, campaign = (Path(s).resolve() for s in sys.argv[1:4])
tools = area.parent / "cleanup-incremental-20261108/tools"
previous = area.parent / "prg-stretch-move-20261109/native-r3"
published = (campaign / "briefs/pass-shelat-ch5-8/maintainer/prg-stretch-move-2026-11-09"
             / "VERIFICATION.json")
out = area / "native"
tree = out / "oleans"
spec = importlib.util.spec_from_file_location("campaign_import_graph", tools / "import_graph.py")
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
base, head = ((area / f"{side}.txt").read_text().strip() for side in ("base", "head"))
prefix = "TCSlib/Cryptography/"
asym = prefix + "Asymptotic"
hc, hp, claims = (asym + "/" + name for name in ("HardCore", "HardCorePermutation", "HardCoreClaims"))
family, gl = hc + "/Functions", hp + "/GoldreichLevin"
pseudo = prefix + "Pseudorandom"
stretch = pseudo + "/Generators/Asymptotic/Stretch"
new = stretch.rsplit("/", 1)[0] + "/FromPermutation"
checks = "audits/pass-shelat/Checks"
owners = {family, gl, new}
changed = {hc, hp, claims, asym, pseudo} | owners


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def clean_git(*args):
    return git(*args).decode().strip()


def copy(src, dst, digest):
    assert sha(src) == digest, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == digest and not dst.samefile(src), dst


def put(path, data):
    with path.open("x") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def show(revision, module):
    return git("show", f"{revision}:{module}.lean")


assert clean_git("rev-parse", "HEAD") == head and clean_git("rev-parse", "HEAD^") == base
assert not clean_git("status", "--porcelain")
assert not clean_git("diff", "--check", base, head)
assert {s[:-5] for s in clean_git("diff", "--name-only", base, head).splitlines()} == changed
old = read(previous / "PLAN.json")
products = read(previous / "PRODUCTS.json")
checked = read(previous / "RESULT.json")
receipt = read(published)
assert checked["passed"] and receipt["passed"] and checked["head"] == receipt["head"] == old["head"]
assert receipt["head"] == clean_git("rev-parse", base + "^2") == (area / "accepted-266.txt").read_text().strip()
for artifact in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / artifact) == receipt["artifact_sha256"]["native-r3/" + artifact], artifact
assert not clean_git("diff", "--name-only", old["head"], base, "--", "*.lean", "lean-toolchain",
                     "lake-manifest.json", "lakefile.lean", "lakefile.toml", "scripts/lean_check_tree.sh")
assert sha(Path(old["toolchain"])) == old["toolchain_sha256"]
assert sha(root / "scripts/lean_check_tree.sh") == old["checker_sha256"]

sources = {
    path[:-5]: (root / path).read_bytes()
    for path in clean_git("ls-files", "--", "TCSlib", "TCSlib.lean", checks + ".lean").splitlines()
    if path.endswith(".lean")
}
assert old["source_digests"].keys() | owners <= sources.keys()
digests = {module: sha256(raw).hexdigest() for module, raw in sources.items()}
for module in sources.keys() - changed:
    baseline = old["source_digests"].get(module)
    if baseline is None:
        baseline = sha256(show(base, module)).hexdigest()
    assert digests[module] == baseline, module
imports = {
    module: [name.replace(".", "/") for name in graph.imports(raw)
             if name.replace(".", "/") in sources]
    for module, raw in sources.items()
}
assert imports[family] == [n for n in old["graph"][hc] if n != stretch]
assert imports[gl] == [family] and imports[new] == [gl, stretch]
assert imports[hc] == [family, new] and imports[hp] == [claims, gl, new]
assert imports[claims] == old["graph"][claims]
assert [n for n in imports[asym] if n not in {family, gl}] == old["graph"][asym]
assert [n for n in imports[pseudo] if n != new] == old["graph"][pseudo]
for module in old["graph"].keys() - changed:
    assert imports[module] == old["graph"][module], module
order = graph.topo(imports, ["TCSlib", checks])
assert set(order) == set(old["order"]) | owners


def closure(mapping, module):
    return set(graph.topo(mapping, [module])) - {module}


for facade in (hc, hp, claims):
    assert closure(old["graph"], facade) <= closure(imports, facade), facade
narrow = closure(imports, new)
assert {family, gl, stretch} <= narrow
assert not {hc, hp, claims, pseudo, asym} & narrow
assert not any(n.startswith((asym + "/PRF", asym + "/GGM", pseudo + "/Functions")) for n in narrow)
old_hc, old_hp = show(base, hc).decode(), show(base, hp).decode()
boundary = (old_hc.index("/-! ## Hard-core predicates"), old_hc.index("/-! ## The generator"),
            old_hc.index("/-! ## Goldreich–Levin for function families"))
old_hardcore = old_hc[boundary[0]:boundary[1]] + old_hc[boundary[2]:]
old_prg = old_hc[boundary[1]:boundary[2]]
permutation_start = old_hp.index("/-! ## The balanced permutation")
end_to_end = old_hp.index("/-- **Pseudorandom generators from any one-way permutation**")
end_namespace = old_hp.index("\nend TCSlib.Cryptography\n", end_to_end)
assert old_hardcore in sources[family].decode()
assert old_hp[permutation_start:end_to_end].rstrip() in sources[gl].decode()
assert old_prg in sources[new].decode() and old_hp[end_to_end:end_namespace] in sources[new].decode()
assert graph.comments_removed(show(base, claims).decode()).split() == graph.comments_removed(sources[claims].decode()).split()
for facade in (hc, hp, asym, pseudo):
    assert all(line.startswith(("import ", "set_option "))
               for line in graph.comments_removed(sources[facade].decode()).splitlines() if line.strip())

affected = changed.copy()
for module in order:
    if affected.intersection(imports[module]):
        affected.add(module)
rebuild = [module for module in order if module in affected]
assert {"TCSlib", checks} | owners <= affected
old_tree = Path(old["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
for module in order:
    if module in affected:
        continue
    row = products[module]
    assert digests[module] == row["source_sha256"]
    assert row["direct_local"] == {dep: retained[dep]["object_sha256"] for dep in imports[module]}, module
    copy(old_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = {**row, "source": "verified_stretch_tree"}
external = {}
for name, row in old["external"].items():
    path = Path(row["path"]).resolve()
    if path.is_relative_to(old_tree):
        dest = tree / path.relative_to(old_tree)
        copy(path, dest, row["sha256"])
        path = dest
    else:
        assert sha(path) == row["sha256"], path
    external[name] = {"path": str(path), "sha256": row["sha256"]}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": old["head"], "worktree": str(root), "tree": str(tree),
    "toolchain": old["toolchain"], "toolchain_sha256": old["toolchain_sha256"],
    "checker_sha256": old["checker_sha256"], "affected": sorted(affected), "rebuild": rebuild,
    "order": order, "retained": retained, "graph": {m: imports[m] for m in order},
    "external": external, "source_digests": digests,
}
put(out / "PLAN.json", plan)
put(area / "SOURCE-CHECK.json", {
    "base": base, "head": head, "baseline": old["head"], "changed_paths": sorted(changed),
    "new_owners": sorted(owners), "moved_proof_and_definition_source_bytes_match": True,
    "old_import_closures_preserved": [hc, hp, claims],
    "from_permutation_import_closure": sorted(narrow),
    "affected_modules": len(affected), "retained_objects": len(retained),
    "external_objects": len(external), "predecessor_receipt_sha256": sha(published),
})
print(f"Sources match the verified #266 merge. {len(rebuild)} affected checks, "
      f"{len(retained)} verified transfers and {len(external)} external objects.", flush=True)
