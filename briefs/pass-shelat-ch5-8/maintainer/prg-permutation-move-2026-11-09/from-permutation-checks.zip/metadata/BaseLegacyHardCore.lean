import TCSlib.Cryptography.Asymptotic.HardCore

#check @TCSlib.Cryptography.owpGenPRG
#check @TCSlib.Cryptography.owpGenPRG_G_outEquiv
#check @TCSlib.Cryptography.owpPredictorSnoc
#check @TCSlib.Cryptography.exists_owpPredictorSnoc
#check @TCSlib.Cryptography.owp_hardcore_prg
#check @TCSlib.Cryptography.PermFamily.iterPRG
#check @TCSlib.Cryptography.cor_81_7
#check @TCSlib.Cryptography.owpGenPRG.eq_1
#check @TCSlib.Cryptography.HardCore
#check @TCSlib.Cryptography.PermFamily.hardCore_iff
#check @TCSlib.Cryptography.goldreich_levin
#check @TCSlib.Cryptography.goldreich_levin_coll
