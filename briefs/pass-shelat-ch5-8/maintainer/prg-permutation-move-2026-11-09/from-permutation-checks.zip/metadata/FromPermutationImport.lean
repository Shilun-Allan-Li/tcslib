import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.FromPermutation

#check @TCSlib.Cryptography.owpGenPRG
#check @TCSlib.Cryptography.owpGenPRG_G_outEquiv
#check @TCSlib.Cryptography.owpPredictorSnoc
#check @TCSlib.Cryptography.exists_owpPredictorSnoc
#check @TCSlib.Cryptography.owp_hardcore_prg
#check @TCSlib.Cryptography.PermFamily.iterPRG
#check @TCSlib.Cryptography.cor_81_7
#check @TCSlib.Cryptography.owpGenPRG.eq_1
#check @TCSlib.Cryptography.OneWayPermutation.glHalf
#check @TCSlib.Cryptography.exists_owp_hardCore
#check @TCSlib.Cryptography.exists_securePRG_of_owp
