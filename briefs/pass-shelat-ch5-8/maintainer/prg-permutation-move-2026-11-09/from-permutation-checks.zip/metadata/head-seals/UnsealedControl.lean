import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.FromPermutation

open TCSlib.Cryptography

example (P : PermFamily) (h : ∀ n, (Fin n → Bool) → Bool) :
    P.HardCore h ↔ HardCore P.toFunFamily (fun n x => h n (P.toFunFamily_domEquiv n x)) :=
  Iff.rfl
