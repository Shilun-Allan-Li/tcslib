## Changes

- Move the one-bit PRG, its finite prediction bound and asymptotic security proof, the iterated generator and its security proof, and `exists_securePRG_of_owp` into `Pseudorandom.Generators.Asymptotic.FromPermutation`. The declarations and their proof bodies move verbatim. The proof uses the evaluator and predictor machine in `Asymptotic.HardCoreLemmas`.
- Put the predicate and function-family Goldreich–Levin proofs in `Asymptotic.HardCore.Functions`. Put the balanced permutation and its hard-core theorem in `Asymptotic.HardCorePermutation.GoldreichLevin`. These two providers let the old `HardCore` and `HardCorePermutation` imports re-export the construction without an import cycle.
- Point the pseudorandomness map to all three security results, including the path from a one-way permutation alone.

## Verification

All 54 affected modules pass, including the library root and campaign Checks. The declaration comparison matches 151 types, definition values, and axiom sets. The two legacy import probes agree with the base, and the standalone import resolves the same route declarations.

The whole-file seals reproduce eight inherited diagnostics at their original proof steps, six in `HardCore.Functions` and two in `FromPermutation`. The control fails when `PermFamily.HardCore` is sealed and passes under the same seal with `PermFamily.hardCore_iff`. The source scan finds no explicit foreign-definition reads and the elaborated proof terms have no references to foreign generated equations.

The source style check passes. The campaign linter reports one extra facade error because it treats finite `Generators.lean` as the facade for its same-named directory. `Pseudorandom.lean` directly exports `FromPermutation`.
