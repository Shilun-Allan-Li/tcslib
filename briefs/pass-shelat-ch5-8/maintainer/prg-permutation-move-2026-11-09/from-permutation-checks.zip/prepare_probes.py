"""Copy checked imports into a private tree and generate declaration and import probes."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import sys

area, side = Path(sys.argv[1]).resolve(), sys.argv[2]
previous = area.parent / "prg-stretch-move-20261109"
native = previous / "native-r3" if side == "Base" else area / "native"
assert side in {"Base", "Head"}
meta = area / "metadata"
out = meta / side.lower() / "oleans"
plan = json.loads((native / "PLAN.json").read_bytes())
old = "TCSlib.Cryptography.Asymptotic."
prg = "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic."
hc, hp, claims = (old + name for name in ("HardCore", "HardCorePermutation", "HardCoreClaims"))
new = prg + "FromPermutation"
owners = [hc, hp, claims] if side == "Base" else [hc + ".Functions", hp + ".GoldreichLevin", claims, new]


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


if side == "Base":
    products = read(native / "PRODUCTS.json")
else:
    products = dict(plan["retained"])
    for path in sorted(native.glob("run-*/check-*.json")):
        try:
            row = read(path)
        except json.JSONDecodeError:
            continue
        if row["rc"] == 0:
            assert row["head"] == plan["head"]
            assert sha(path.with_suffix(".log")) == row["log_sha256"]
            products[row["module"]] = row
pending = [hp.replace(".", "/")]
needed = set()
while pending:
    module = pending.pop()
    if module not in needed:
        needed.add(module)
        pending.extend(plan["graph"][module])
assert needed <= products.keys(), sorted(needed - products.keys())
assert set(owner.replace(".", "/") for owner in owners) <= needed
out.mkdir(parents=True)
tree = Path(plan["tree"])
for module in sorted(needed):
    row = products[module]
    assert row["source_sha256"] == plan["source_digests"][module], module
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}, module
    copy(tree / (module + ".olean"), out / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(tree):
        copy(src, out / src.relative_to(tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
(out / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

program = (previous / "metadata-r3/HeadCensus.lean").read_text()
program = program.replace("import " + old + "PRF\n", "")
beg = program.index("  let owners : Array Name :=")
end = program.index("\n", beg)
program = program[:beg] + "  let owners : Array Name := #[" + ", ".join(chr(96) + name for name in owners) + "]" + program[end:]
start = program.index('  let file ← IO.FS.Handle.mk "')
end = program.index("\n", start)
program = program[:start] + f'  let file ← IO.FS.Handle.mk "{meta / (side + ".jsonl")}" .write' + program[end:]
program = program.replace("Stretch census complete", "Permutation route census complete")
(meta / (side + "Census.lean")).write_text(program)

prefix = "TCSlib.Cryptography."
route = ("owpGenPRG", "owpGenPRG_G_outEquiv", "owpPredictorSnoc", "exists_owpPredictorSnoc",
         "owp_hardcore_prg", "PermFamily.iterPRG", "cor_81_7", "owpGenPRG.eq_1")
hardcore_names = route + ("HardCore", "PermFamily.hardCore_iff", "goldreich_levin", "goldreich_levin_coll")
perm_names = route + ("OneWayPermutation.glHalf", "exists_owp_hardCore", "exists_securePRG_of_owp", "thm_87_3_1")
tests = [(side + "LegacyHardCore", hc, hardcore_names), (side + "LegacyPermutation", hp, perm_names)]
if side == "Head":
    tests.append(("FromPermutationImport", new, perm_names[:-1]))
else:
    tests.append(("BaseRouteImport", hp, perm_names[:-1]))
for label, imports, names in tests:
    body = "".join("#check @" + prefix + name + "\n" for name in names)
    (meta / (label + ".lean")).write_text("import " + imports + "\n\n" + body)
print(f"Copied {len(needed)} verified {side.lower()} module objects for the probes.", flush=True)
