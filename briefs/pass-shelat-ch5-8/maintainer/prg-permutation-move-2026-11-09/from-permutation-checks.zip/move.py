"""Separate the PRG construction from its Goldreich–Levin providers."""

import difflib
from pathlib import Path
import sys

root, area = (Path(arg).resolve() for arg in sys.argv[1:3])
prefix = "TCSlib/Cryptography/"
hardcore = prefix + "Asymptotic/HardCore.lean"
permutation = prefix + "Asymptotic/HardCorePermutation.lean"
functions = prefix + "Asymptotic/HardCore/Functions.lean"
balanced = prefix + "Asymptotic/HardCorePermutation/GoldreichLevin.lean"
from_perm = prefix + "Pseudorandom/Generators/Asymptotic/FromPermutation.lean"
from_perm_name = from_perm[:-5].replace("/", ".")
functions_name = functions[:-5].replace("/", ".")
balanced_name = balanced[:-5].replace("/", ".")


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


hc = (root / hardcore).read_text()
hp = (root / permutation).read_text()
license = hc.split("import ", 1)[0]
assert hp.startswith(license)
opts = hc[hc.index("set_option"):hc.index("/-!\n")]
ns = "namespace TCSlib.Cryptography\n\nopen Complexity Turing Finset\n\n"
end = "\nend TCSlib.Cryptography\n"
p0 = hc.index("/-! ## Hard-core predicates")
p1 = hc.index("/-! ## The generator")
p2 = hc.index("/-! ## Goldreich–Levin for function families")
r0 = hp.index("/-! ## The balanced permutation")
r1 = hp.index("/-- **Pseudorandom generators from any one-way permutation**")
r2 = hp.index(end, r1)
hardcore_predicates, prg_code, family_gl = hc[p0:p1], hc[p1:p2], hc[p2:]
balanced_gl, end_to_end = hp[r0:r1], hp[r1:r2]
assert hc.endswith(end) and hp.endswith(end)


def header(imports, doc):
    return license + "".join(f"import {module}\n" for module in imports) + "\n" + opts + "/-!\n" + doc.strip() + "\n-/\n\n"


old_imports = [line.removeprefix("import ") for line in hc.splitlines() if line.startswith("import ")]
assert old_imports.pop() == "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch"
family_doc = """
# Hard-core predicates and Goldreich–Levin for function families

The hard-core predicate of [PS10, Definition 78.3] combines efficient evaluation
with the hardness of predicting its bit from a function image. Goldreich–Levin
[PS10, Theorem 87.3] constructs a one-way family `g(x, r) = (f(x), r)` with the
hard-core bit `⟨x, r⟩`. The typed-family experiments use the finite reductions
of [Gar26, §2.5] and the polynomial-time machines in `Asymptotic.HardCoreLemmas`
and `Asymptotic.HardCoreGLFamily`.

**Deviation.** The prediction experiment uses the same parameter for the
domain and the adversary. The predictor returns the string `[true]` to signal
a true prediction. The inner product is hard-core for the padded family
`g` (source error 26).

## Main definitions

* `TCSlib.Cryptography.HardCore` and `TCSlib.Cryptography.PermFamily.HardCore`
  give the function and permutation forms of the hard-core predicate.
* `TCSlib.Cryptography.FunFamily.glPad`, `TCSlib.Cryptography.FunFamily.glBit`
  and `TCSlib.Cryptography.FunFamily.glInverter` give the padded family, its
  inner-product predicate and its inverter.

## Main results

* `TCSlib.Cryptography.hardCore_iff` and `TCSlib.Cryptography.PermFamily.hardCore_iff`
  characterize hard-core predicates. `TCSlib.Cryptography.not_hardCore_const`
  excludes constant predicates.
* `TCSlib.Cryptography.FunFamily.StrongOneWay.glPad` proves one-wayness.
  `TCSlib.Cryptography.FunFamily.StrongOneWay.glPad_hardCore` proves hardness of
  the inner product. `TCSlib.Cryptography.goldreich_levin` combines the two.

The concrete claims have their own proofs in `Asymptotic.HardCoreClaims`.
The collection version used in [PS10, Theorem 104.4] is in
`Asymptotic.HardCoreCollection`.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §3.3.3 and §§3.4.2–3.4.3.
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §2.5 (Theorem 2.3, Figures 2.3–2.5).
* [GL89] O. Goldreich, L. Levin, *A hard-core predicate for all one-way functions*, STOC 1989.
"""
balanced_doc = hp.split("/-!\n", 1)[1].split("\n-/\n", 1)[0]
balanced_doc = replace_once(balanced_doc,
    'is the "(OWP)" clause of [PS10, Theorem 87.3] in the form every consumer needs;\n'
    '`exists_owp_hardCore` and `exists_securePRG_of_owp` are the textbook consequences.',
    'gives the "(OWP)" clause of [PS10, Theorem 87.3]. The existence result is\n'
    '`exists_owp_hardCore`. The PRG corollary is in\n'
    '`Pseudorandom.Generators.Asymptotic.FromPermutation`.')
balanced_doc = replace_once(balanced_doc,
    '  one-way permutation yields a one-way permutation with a hard-core bit (sorried under its\n'
    '  sketch; the fill routes through `FunFamily.StrongOneWay.glPad` and\n'
    '  `FunFamily.StrongOneWay.glPad_hardCore` at parameter `⌊n/2⌋`).\n'
    '* `TCSlib.Cryptography.exists_owp_hardCore`, `TCSlib.Cryptography.exists_securePRG_of_owp`\n'
    '  [PS10, §3.4, pp. 84 and 86]: the hypothesis of Theorems 79.4, 81.7 and 126.4 from one-way\n'
    '  permutations alone; pseudorandom generators from one-way permutations.',
    '  one-way permutation yields a one-way permutation with a hard-core bit. The proof uses\n'
    '  `FunFamily.StrongOneWay.glPad` and `FunFamily.StrongOneWay.glPad_hardCore`\n'
    '  at parameter `⌊n/2⌋`.\n'
    '* `TCSlib.Cryptography.exists_owp_hardCore` [PS10, §3.4, p. 86] obtains the hard-core\n'
    '  hypothesis of Theorems 79.4, 81.7 and 126.4 from one-way permutations alone.')
prg_doc = """
# Asymptotic pseudorandom generators from one-way permutations

For a one-way permutation family `f` with hard-core predicate `h`,
[PS10, Theorem 79.4] appends `h(s)` to `f(s)` to gain one output bit.
The finite prediction bound comes from [Gar26, Theorem 3.2]. The efficient
evaluator and predictor machine are in `Asymptotic.HardCoreLemmas`.
The iterated construction in [PS10, Corollary 81.7] emits `h` at each
step along the orbit of `f` and uses the stretch theorem from `Stretch`.

To start from a one-way permutation alone, the balanced Goldreich–Levin
construction in `Asymptotic.HardCorePermutation.GoldreichLevin` supplies a
permutation with a hard-core bit at every length [PS10, Theorem 87.3].

**Deviation.** Theorem 79.4 uses the direct reduction of [Gar26, Theorem 3.2].
One call to the distinguisher with a uniformly guessed last bit gives
prediction probability `1/2 + ε` at distinguishing advantage `ε`.
Corollary 81.7 outputs `ℓ(n) + 1` bits indexed from zero and assumes
`n ≤ ℓ(n)` (source error 38).

## Main definitions

* `TCSlib.Cryptography.owpGenPRG` is the one-bit extension `s ↦ f(s) ‖ h(s)`.
* `TCSlib.Cryptography.owpPredictorSnoc` uses a distinguisher for that extension
  to predict the last bit.
* `TCSlib.Cryptography.PermFamily.iterPRG` emits `h` along the permutation orbit.

## Main results

* `TCSlib.Cryptography.owp_hardcore_prg` proves security of the one-bit extension.
* `TCSlib.Cryptography.cor_81_7` proves security of the iterated generator by
  applying `prg_expand` to the one-bit generator.
* `TCSlib.Cryptography.exists_securePRG_of_owp` composes the balanced
  Goldreich–Levin theorem with the one-bit extension.

Shamir's generator [PS10, §3.3.2, inventory Constr-77.a] motivates this
construction. Uniformity under an iterate of a permutation (Claim-78.a)
is an instance of `uprob_comp_equiv`. For Claim-78.b, the concrete example
in `HardcoreBit/NoFixedBit.lean` reveals the bits of the position while each
fixed input bit has prediction advantage `1/(2(n + 1))`.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §§3.3.2–3.3.5 and §§3.4.2–3.4.3.
* [Gar26] S. Garg, *A Course in Theory of Cryptography*, lecture notes, UC Berkeley,
  draft of 22 January 2026, §2.5 and §3.3 (Theorem 3.2).
"""
compat_family = """
# Hard-core predicates and the permutation-to-PRG route

This compatibility import brings the function-family form of Goldreich–Levin
and the asymptotic PRG construction into scope [PS10, Theorems 79.4 and 87.3].

## Contents

* `HardCore.Functions` defines hard-core predicates and proves Goldreich–Levin
  for function families.
* `Pseudorandom.Generators.Asymptotic.FromPermutation` defines and verifies
  the one-bit and iterated PRG constructions.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §§3.3–3.4.
"""
compat_permutation = """
# Hard-core bits from one-way permutations

This compatibility import keeps the balanced Goldreich–Levin result, the
concrete claims and the resulting PRG existence theorem in scope.

## Contents

* `HardCorePermutation.GoldreichLevin` supplies the balanced permutation
  and hard-core bit [PS10, Theorem 87.3].
* `HardCoreClaims` gives the concrete claims in the Goldreich–Levin proof.
* `Pseudorandom.Generators.Asymptotic.FromPermutation` proves that one-way
  permutations imply secure pseudorandom generators [PS10, §3.4, p. 84].

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed.,
  January 2010, §3.4.
"""
out = {
    hardcore: header([functions_name, from_perm_name], compat_family).rstrip() + "\n",
    permutation: header(["TCSlib.Cryptography.Asymptotic.HardCoreClaims", balanced_name, from_perm_name],
                        compat_permutation).rstrip() + "\n",
    functions: header(old_imports, family_doc) + ns + hardcore_predicates + family_gl,
    balanced: header([functions_name], balanced_doc) + ns + balanced_gl.rstrip() + "\n" + end,
    from_perm: header([balanced_name, "TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Stretch"],
                      prg_doc) + ns + prg_code + "/-! ## From any one-way permutation -/\n\n" + end_to_end + end,
}
for path, old in ((functions, hardcore_predicates + family_gl), (balanced, balanced_gl.rstrip()),
                  (from_perm, prg_code), (from_perm, end_to_end)):
    assert old in out[path]

asym = prefix + "Asymptotic.lean"
text = (root / asym).read_text()
text = replace_once(text,
    "import TCSlib.Cryptography.Asymptotic.HardCore\nimport TCSlib.Cryptography.Asymptotic.HardCorePermutation\n",
    "import " + functions_name + "\nimport TCSlib.Cryptography.Asymptotic.HardCore\n"
    "import " + balanced_name + "\nimport TCSlib.Cryptography.Asymptotic.HardCorePermutation\n")
text = replace_once(text,
    "* `HardCore` — hard-core predicates, the PRG from a one-way permutation, expansion and\n"
    "  Goldreich–Levin [PS10, Definition 78.3, Theorems 79.4, 87.3, Lemma 80.5, Corollary 81.7].\n"
    "* `HardCorePermutation` — the balanced Goldreich–Levin permutation `PermFamily.glHalf`:\n"
    "  one-way permutations have a hard-core bit, PRGs from any one-way permutation\n"
    '  [PS10, Theorem 87.3 "(OWP)", §3.4 pp. 84, 86; run-3 audit P4-1].',
    "* `HardCore` preserves the hard-core and permutation-to-PRG import.\n"
    "* `HardCore.Functions` defines hard-core predicates and proves Goldreich–Levin for\n"
    "  function families [PS10, Definition 78.3 and Theorem 87.3].\n"
    "* `HardCorePermutation` preserves the balanced permutation and PRG existence import.\n"
    "* `HardCorePermutation.GoldreichLevin` proves the balanced permutation has a hard-core bit\n"
    '  [PS10, Theorem 87.3 "(OWP)"].')
out[asym] = text

claims = prefix + "Asymptotic/HardCoreClaims.lean"
out[claims] = replace_once((root / claims).read_text(),
    "`FunFamily.glInverter` of `TCSlib.Cryptography.Asymptotic.HardCore`), through the bridges",
    "`FunFamily.glInverter` in `TCSlib.Cryptography.Asymptotic.HardCore.Functions`), through the bridges")

facade = prefix + "Pseudorandom.lean"
text = (root / facade).read_text()
line = "import TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.Defs\n"
text = replace_once(text, line, line + "import " + from_perm_name + "\n")
line = "* `Generators.Asymptotic.StretchMachine` implements the evaluator and hybrid reduction.\n"
text = replace_once(text, line, "* `Generators.Asymptotic.FromPermutation` builds secure generators from one-way permutations.\n" + line)
text = replace_once(text,
    "* **One-way permutation to PRG.** In `TCSlib.Cryptography.Asymptotic.HardCore`,\n"
    "  `TCSlib.Cryptography.owp_hardcore_prg` packages a secure one-bit-stretch generator\n"
    "  from a one-way permutation family and its hard-core predicate [PS10, Theorem 79.4].",
    "* **One-way permutation to PRG.** In\n"
    "  `TCSlib.Cryptography.Pseudorandom.Generators.Asymptotic.FromPermutation`,\n"
    "  `TCSlib.Cryptography.owp_hardcore_prg` proves security of `s ↦ f(s) ‖ h(s)` given a\n"
    "  hard-core predicate [PS10, Theorem 79.4]. `TCSlib.Cryptography.cor_81_7` applies\n"
    "  stretch extension to get the iterated generator.\n"
    "  `TCSlib.Cryptography.exists_securePRG_of_owp` starts from a one-way permutation\n"
    "  alone by using the balanced Goldreich–Levin construction [PS10, Theorem 87.3].")
out[facade] = text

patch = []
for path, new in sorted(out.items()):
    exists = (root / path).is_file()
    old = (root / path).read_text() if exists else ""
    assert old != new and new.endswith("\n")
    patch.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                     fromfile="a/" + path if exists else "/dev/null",
                                     tofile="b/" + path))
    print(f"{len(new.splitlines()):4} {path}")
(area / "move.patch").write_text("".join(patch))
