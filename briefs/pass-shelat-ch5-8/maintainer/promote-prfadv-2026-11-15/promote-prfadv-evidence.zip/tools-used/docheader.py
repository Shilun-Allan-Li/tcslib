"""docheader.py <repo> <rev-a> <rev-b> <file> <name>...: for each theorem name, compare between the two revisions
(1) its doc comment (the `/-- ... -/` block right above the keyword line) and (2) the text from the keyword line to
the first top-level `:=`, byte for byte; also print each body (text after that `:=` up to the next blank line)."""
import sys, re, subprocess
repo, ra, rb, f = sys.argv[1:5]; names = sys.argv[5:]
show = lambda r: subprocess.run(['git', '-C', repo, 'show', f'{r}:{f}'], capture_output=True, check=True).stdout.decode()
def parts(src, n):
    m = re.search(r'^theorem ' + re.escape(n) + r'\b', src, re.M); k = m.start()
    d = src.rfind('/--', 0, k); doc = src[d:k]
    assert doc.rstrip().endswith('-/') and '-/' not in doc.rstrip()[:-2], n
    rest = src[k:]; dep = 0
    for i, c in enumerate(rest):
        if c in '([{⟨': dep += 1
        elif c in ')]}⟩': dep -= 1
        elif dep == 0 and rest.startswith(':=', i): break
    body = rest[i:].split('\n\n', 1)[0]
    return doc, rest[:i], body
A, B = show(ra), show(rb); ok = True
for n in names:
    da, ha, ba = parts(A, n); db, hb, bb = parts(B, n)
    print(f'{n}: docstring identical {da == db}; header (keyword .. top-level :=) identical {ha == hb}')
    print(f'  {ra[:8]} body: {ba!r}'); print(f'  {rb[:8]} body: {bb!r}')
    ok &= da == db and ha == hb
print('RESULT', 'OK' if ok else 'FAIL')
