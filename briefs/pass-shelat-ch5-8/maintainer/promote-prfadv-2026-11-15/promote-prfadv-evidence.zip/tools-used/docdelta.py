"""docdelta.py <repo> <rev-a> <rev-b> <file> <name>...: for each theorem, its doc comment at both revisions and a
character-level account of the change: the longest common prefix and suffix, and the removed / inserted middle."""
import sys, re, subprocess
repo, ra, rb, f = sys.argv[1:5]; names = sys.argv[5:]
show = lambda r: subprocess.run(['git', '-C', repo, 'show', f'{r}:{f}'], capture_output=True, check=True).stdout.decode()
def doc(src, n):
    k = re.search(r'^theorem ' + re.escape(n) + r'\b', src, re.M).start(); d = src.rfind('/--', 0, k); return src[d:k]
A, B = show(ra), show(rb)
for n in names:
    a, b = doc(A, n), doc(B, n); i = 0
    while i < min(len(a), len(b)) and a[i] == b[i]: i += 1
    j = 0
    while j < min(len(a), len(b)) - i and a[-1 - j] == b[-1 - j]: j += 1
    print(f'{n}: common prefix {i} chars, common suffix {j} chars')
    print(f'  removed: {a[i:len(a) - j]!r}'); print(f'  inserted: {b[i:len(b) - j]!r}')
