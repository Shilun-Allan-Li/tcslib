"""downstat.py <repo-root> <module> [<probe-module>...]: source-level reverse closure of <module>
over TCSlib/** (root TCSlib.lean included) and audits/**: the modules that transitively import it;
and, of those, how many do NOT already have <probe-module> in their closure."""
import sys, os, re
root, mod, probes = sys.argv[1], sys.argv[2], sys.argv[3:]
mods = []
for base in ('TCSlib', 'audits'):
    for d, ds, fs in os.walk(os.path.join(root, base)):
        for f in fs:
            if f.endswith('.lean'): mods.append(os.path.relpath(os.path.join(d, f), root)[:-5].replace('/', '.'))
mods.append('TCSlib')
def path(m): return os.path.join(root, *m.split('.')) + '.lean'
imp = {}
for m in mods:
    imp[m] = [x for x in re.findall(r'^(?:public\s+)?import\s+(\S+)', open(path(m), encoding='utf-8').read(), re.M) if x in set(mods) or os.path.exists(path(x))]
memo = {}
def clo(m):
    if m in memo: return memo[m]
    seen, st = set(), [m]
    while st:
        x = st.pop()
        for y in imp.get(x, []):
            if y not in seen: seen.add(y); st.append(y)
    memo[m] = seen; return seen
down = sorted(m for m in mods if mod in clo(m))
print(f'downstream of {mod}: {len(down)} modules')
for p in probes:
    lack = [m for m in down if p not in clo(m) and m != p]
    print(f'  of these, without {p} in closure: {len(lack)}', lack[:12])
