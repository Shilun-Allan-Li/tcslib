"""impcheck.py <repo-root> <module> <target>: is <target> in the transitive import closure of <module>
(source-level, project modules only)? Also: does <target>'s closure contain <module> (cycle)?"""
import sys, os, re
root, mod, tgt = sys.argv[1:4]
def path(m): return os.path.join(root, *m.split('.')) + '.lean'
def imports(m):
    p = path(m)
    if not os.path.exists(p): return None
    out = []
    for line in open(p, encoding='utf-8'):
        s = line.strip()
        mm = re.match(r'^(?:public\s+)?import\s+(\S+)', s)
        if mm: out.append(mm.group(1))
        elif s and not s.startswith(('--', '/-', '-/', 'module', 'prelude')) and not s.startswith('Copyright') and not s.startswith('Released') and not s.startswith('Authors'):
            if s.startswith(('set_option', 'namespace', 'open', '/-!', 'section', 'noncomputable', 'theorem', 'def')): break
    return out
def closure(m):
    seen, stack, parent = set(), [m], {m: None}
    while stack:
        x = stack.pop()
        for y in imports(x) or []:
            if (y.startswith('TCSlib') or y.startswith('audits')) and y not in seen and os.path.exists(path(y)):
                seen.add(y); parent[y] = x; stack.append(y)
    return seen, parent
c, par = closure(mod)
print(f'closure({mod}): {len(c)} project modules')
print(f'{tgt} in closure: {tgt in c}')
if tgt in c:
    chain = [tgt]
    while par[chain[-1]] is not None: chain.append(par[chain[-1]])
    print('import chain: ' + ' <- '.join(chain))
c2, _ = closure(tgt)
print(f'closure({tgt}): {len(c2)} project modules; {mod} in it (cycle): {mod in c2}')
