"""refcmp.py <results.jsonl> <ref.jsonl>...: for each module of the run, the reference records with the same module and
source SHA-256 (any of the given files). Reports: no same-source reference; sorry or warning counts differing from it;
and whether the object SHA-256 equals some same-source reference (olean byte-identical) or not."""
import sys, json, collections
run = [json.loads(l) for l in open(sys.argv[1])]; run = [r for r in run if 'module' in r]
ref = collections.defaultdict(list)
for f in sys.argv[2:]:
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: ref[(r['module'], r['source_sha256'])].append(r)
noref, cnt, same, diff = [], [], [], []
for r in run:
    rs = ref.get((r['module'], r['source_sha256']))
    if not rs: noref.append(r['module']); continue
    if not any(x['sorry'] == r['sorry'] and x['warnings'] == r['warnings'] for x in rs): cnt.append((r['module'], r['sorry'], r['warnings'], [(x['sorry'], x['warnings']) for x in rs]))
    (same if any(x['object_sha256'] == r['object_sha256'] for x in rs) else diff).append(r['module'])
print(f'modules {len(run)}; with same-source reference {len(run) - len(noref)}; no reference {len(noref)}: {noref}')
print(f'sorry/warning count differs from every same-source reference: {len(cnt)} {cnt}')
print(f'olean byte-identical to a same-source reference: {len(same)}; different: {len(diff)}')
for m in diff: print('  olean differs:', m)
print('sorry by module:', {r['module']: r['sorry'] for r in run if r['sorry']})
