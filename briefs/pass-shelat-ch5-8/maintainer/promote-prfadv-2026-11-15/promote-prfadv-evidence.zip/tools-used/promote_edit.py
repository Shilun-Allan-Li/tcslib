"""promote_edit.py <worktree>: DL-44 F-01 promotion, exact replacements (each old string occurs once).
Defs.lean: import Games.Bridges.Experiments, Main-results bullet, new theorem
TCSlib.Cryptography.prfAdv_eq_expect after prfAdv_nonneg. Reduction.lean: ETTGame.prfAdv_eq_expect
re-derived from it (proof only; one sentence added to its docstring)."""
import sys, os
wt = sys.argv[1]
def edit(rel, R):
    f = os.path.join(wt, rel); s = open(f, encoding='utf-8').read()
    for a, b in R:
        c = s.count(a); assert c == 1, (rel, c, a[:70]); s = s.replace(a, b)
    open(f, 'w', encoding='utf-8').write(s); print(rel, len(R), 'replacements')
edit('TCSlib/Cryptography/Pseudorandom/Functions/Defs.lean', [
('''import TCSlib.Cryptography.Pseudorandom.Functions.OracleAdversary
import Mathlib.Data.Fintype.Pi
''', '''import TCSlib.Cryptography.Pseudorandom.Functions.OracleAdversary
import TCSlib.Cryptography.Games.Bridges.Experiments
import Mathlib.Data.Fintype.Pi
'''),
('''* `prfAdv_eq`: the advantage written out as a difference of two probabilities.
* `prfAdv_nonneg`.
''', '''* `prfAdv_eq`: the advantage written out as a difference of two probabilities.
* `prfAdv_nonneg`.
* `prfAdv_eq_expect`: the advantage as the gap between two nested expectations of the
  game-hopping layer (`Games.ProbComp.expect`), keys or function table outside, coins inside.
'''),
('''  rw [prfAdv_def, distAdv_def]
  exact abs_nonneg _

''', '''  rw [prfAdv_def, distAdv_def]
  exact abs_nonneg _

section Expect

open Games ProbComp

/-- **The PRF advantage as expectations**: for a keyed family `F : K → I → O` and an oracle
adversary `A` with coins in `ρ`, all finite and nonempty,
`prfAdv F A = |𝔼_k 𝔼_c [A(c)^{F k} = 1] − 𝔼_R 𝔼_c [A(c)^R = 1]|`, where `k` is a uniform key,
`R` a uniform random function `I → O` and `c` uniform coins ([Gar26, Definition 3.9] in the
expectation form of the game-hopping layer).

**Proof sketch.** Unfold to the distinguishing advantage of `oracleDist A` (`prfAdv_def`,
`distAdv_def`). Each acceptance probability is the acceptance of the game that samples the seed
(the key, resp. the function table) and then the coins (`Bridge.acceptProb_eq`, `accept_eq`,
`Bridge.acceptGame_eq`); `prob_bind` and `prob_pure` turn the game into the nested expectation,
and `oracleDist_apply`, `randomFunction_apply` read off the verdict. -/
theorem prfAdv_eq_expect {K ρ : Type} [Fintype K] [Nonempty K] [Fintype I] [DecidableEq I]
    [Fintype O] [Nonempty O] [Fintype ρ] [Nonempty ρ] (F : K → I → O)
    (A : OracleAdversary ρ I O) :
    prfAdv F A =
      |expect (sample K)
          (fun k => expect (sample ρ) fun c => if (A c).eval (F k) = true then (1 : ℝ) else 0) -
        expect (sample (I → O))
          (fun R => expect (sample ρ) fun c => if (A c).eval R = true then (1 : ℝ) else 0)| := by
  rw [prfAdv_def, distAdv_def, Bridge.acceptProb_eq, Bridge.acceptProb_eq, accept_eq, accept_eq,
    Bridge.acceptGame_eq, Bridge.acceptGame_eq, prob_bind, prob_bind]
  congr 2
  · refine congrArg _ (funext fun k => ?_)
    simp only [prob_bind, prob_pure, oracleDist_apply]
  · refine congrArg _ (funext fun R => ?_)
    simp only [prob_bind, prob_pure, oracleDist_apply, randomFunction_apply]

end Expect

'''),
])
edit('TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Reduction.lean', [
('''`prfAdv F A' = |𝔼_k 𝔼_c [A'(c)^{F k} = 1] − 𝔼_R 𝔼_c [A'(c)^R = 1]|`.

**Proof sketch.** `prfAdv_def`, `distAdv_def`;''', '''`prfAdv F A' = |𝔼_k 𝔼_c [A'(c)^{F k} = 1] − 𝔼_R 𝔼_c [A'(c)^R = 1]|`.

This is the published `TCSlib.Cryptography.prfAdv_eq_expect` at `K = I = O = {0,1}^m`.

**Proof sketch.** `prfAdv_def`, `distAdv_def`;'''),
('''          (fun R => expect (sample ρ) fun c => if (A' c).eval R = true then (1 : ℝ) else 0)| := by
  rw [prfAdv_def, distAdv_def, Bridge.acceptProb_eq, Bridge.acceptProb_eq, accept_eq, accept_eq,
    Bridge.acceptGame_eq, Bridge.acceptGame_eq, prob_bind, prob_bind]
  congr 2
  · refine congrArg _ (funext fun k => ?_)
    simp only [prob_bind, prob_pure, oracleDist_apply]
  · refine congrArg _ (funext fun R => ?_)
    simp only [prob_bind, prob_pure, oracleDist_apply, randomFunction_apply]
''', '''          (fun R => expect (sample ρ) fun c => if (A' c).eval R = true then (1 : ℝ) else 0)| :=
  TCSlib.Cryptography.prfAdv_eq_expect Fm A'
'''),
])
