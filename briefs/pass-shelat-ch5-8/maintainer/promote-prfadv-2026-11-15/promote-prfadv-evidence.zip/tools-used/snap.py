"""snap.py <tree> <out>: SHA-256 of every file under <tree>, sorted, '<sha>  <rel>' (treecheck.py format)."""
import sys, os, hashlib
tree, out = sys.argv[1:3]
files = {}
for d, ds, fs in os.walk(tree):
    for f in fs:
        p = os.path.join(d, f); files[os.path.relpath(p, tree)] = hashlib.sha256(open(p, 'rb').read()).hexdigest()
empty = sorted(os.path.relpath(d, tree) for d, ds, fs in os.walk(tree) if not ds and not fs)
with open(out, 'w') as o:
    for f in sorted(files): o.write(f'{files[f]}  {f}\n')
print(len(files), 'files; empty dirs', len(empty), empty[:5])
