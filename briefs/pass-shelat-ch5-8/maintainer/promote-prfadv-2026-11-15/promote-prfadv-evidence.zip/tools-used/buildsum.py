"""buildsum.py <results.jsonl> [<ref-records.jsonl>...]: per-run summary (modules, rc, errors, sorry, warnings by module)
and, with reference records (last record per module wins, in the given order), the modules whose source or object
SHA-256 differs from the reference."""
import sys, json
rs = [json.loads(l) for l in open(sys.argv[1])]; ms = [r for r in rs if 'module' in r]
ref = {}
for f in sys.argv[2:]:
    for l in open(f):
        r = json.loads(l)
        if 'module' in r: ref[r['module']] = r
print(f"modules {len(ms)}; rc0 {sum(r['rc'] == 0 for r in ms)}; errors {sum(r['errors'] for r in ms)}; errors_diag {sum(r['errors_diag'] for r in ms)}; sorry {sum(r['sorry'] for r in ms)}; done {any('done' in r for r in rs)}; stopped {[r for r in rs if 'stopped_at' in r]}")
print('warnings:', {r['module'].split('/')[-1] if '/' in r['module'] else r['module']: r['warnings'] for r in ms if r['warnings']})
if ref:
    for r in ms:
        x = ref.get(r['module'])
        if x is None: print('NOREF', r['module']); continue
        s = 'src-same' if x['source_sha256'] == r['source_sha256'] else 'src-DIFF'
        o = 'obj-same' if x['object_sha256'] == r['object_sha256'] else 'obj-DIFF'
        if s != 'src-same' or o != 'obj-same': print(s, o, r['module'])
