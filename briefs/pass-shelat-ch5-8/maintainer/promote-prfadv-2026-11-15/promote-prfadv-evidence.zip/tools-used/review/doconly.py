"""doconly.py <repo> <rev> <file>...: the working-tree file and <rev>'s file are equal after deleting every
`/-- ... -/` doc comment, and they have the same number of doc comments (each change lies inside one)."""
import sys, re, subprocess
repo, rev = sys.argv[1:3]; ok = True
for f in sys.argv[3:]:
    a = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, check=True).stdout.decode()
    b = open(f'{repo}/{f}', encoding='utf-8').read()
    da, db = re.findall(r'/--.*?-/', a, re.S), re.findall(r'/--.*?-/', b, re.S)
    ca, cb = re.sub(r'/--.*?-/', '', a, flags=re.S), re.sub(r'/--.*?-/', '', b, flags=re.S)
    same = ca == cb and len(da) == len(db)
    nchg = sum(x != y for x, y in zip(da, db))
    ok &= same
    print(f"{'DOC-ONLY' if same else 'CODE-CHANGED'}\t{f}\tdocstrings {len(da)}->{len(db)}\tchanged docstrings {nchg}")
print('RESULT', 'OK' if ok else 'FAIL')
