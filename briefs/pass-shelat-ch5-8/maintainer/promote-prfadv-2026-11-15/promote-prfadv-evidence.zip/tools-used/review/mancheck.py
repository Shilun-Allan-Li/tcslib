"""mancheck.py <dir> <manifest relative to dir> : verify a sha256sum-style manifest with exact path-set equality.
Paths in the manifest are relative to <dir>; the delivered set is every file under <dir> except the manifest
itself (and, for the top level, files under subdirs that carry their own manifest are still counted)."""
import sys, os, hashlib
d, man = sys.argv[1], sys.argv[2]
ent = {}
for line in open(os.path.join(d, man), encoding='utf-8'):
    line = line.rstrip('\n')
    if not line: continue
    h, p = line[:64], line[66:]
    if p.startswith('./'): p = p[2:]  # learning-r1: normalize a leading ./ (counted below)
    if line[64:66] not in ('  ', ' *'): print('BADSEP', line)
    if p in ent: print('DUP', p)
    ent[p] = h
deliv = set()
for root, _, fs in os.walk(d):
    for f in fs:
        rel = os.path.relpath(os.path.join(root, f), d)
        if rel != man: deliv.add(rel)
bad = 0
for p, h in sorted(ent.items()):
    fp = os.path.join(d, p)
    if not os.path.isfile(fp): continue
    if hashlib.sha256(open(fp, 'rb').read()).hexdigest() != h: print('MISMATCH', p); bad += 1
mnd = sorted(set(ent) - deliv); dnm = sorted(deliv - set(ent))
print(f'manifest {len(ent)} delivered {len(deliv)} hash-mismatch {bad}')
print('in manifest not delivered:', *mnd, sep='\n  ')
print('delivered not in manifest:', *dnm, sep='\n  ')
sys.exit(1 if bad or mnd or dnm else 0)
