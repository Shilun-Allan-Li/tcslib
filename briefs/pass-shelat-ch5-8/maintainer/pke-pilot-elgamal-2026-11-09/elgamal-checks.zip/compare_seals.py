"""Compare the ElGamal seal coverage and remap the inherited explicit reads."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import sys

area,previous,campaign=(Path(s).resolve() for s in sys.argv[1:4])


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


plan=read(area/'native/PLAN.json')
decl=read(area/'DECLARATIONS.json')
source=read(area/'SOURCE-CHECK.json')
assert all(r['base']==plan['base'] and r['head']==plan['head'] for r in (decl,source))
legacy=source['base_path']
new=source['head_path']
old_owner=legacy[:-5].replace('/','.')
new_owner=new[:-5].replace('/','.')
record=campaign/'briefs/pass-shelat-ch5-8/maintainer/pke-pilot-ddh-2026-11-09/VERIFICATION.json'
receipt=read(record)
assert receipt['passed'] and receipt['head']==plan['baseline']
for rel in ('SEALS.json','READS.json','read-scan/scan.log'):
    assert sha(previous/rel)==receipt['artifact_sha256'][rel]
prior=next(r for r in read(previous/'SEALS.json')['outcomes'] if r['owner']==old_owner)
current,=read(area/'SEALS.json')['outcomes']
assert current['owner']==new_owner
assert current['source_sha256']==prior['source_sha256']==source['source_sha256']['base:'+legacy]
assert all(r['valid_harness'] and r['rc']==0 and not r['errors'] for r in (prior,current))


def mask(folder,row):
    meta=folder/(row['label']+'.json')
    assert sha(meta)==row['meta_sha256'] and sha(Path(row['log']))==row['log_sha256']
    data=read(meta)
    return {tuple(map(tuple,r['name_components'])):r for r in data['requested']}


old_mask=mask(previous/'seals',prior)
new_mask=mask(area/'seals',current)
assert old_mask==new_mask
ledger_only='--ledger-only' in sys.argv
focused=None if ledger_only else read(area/'SEALS-MOVED.json')
if focused is not None:
    probe,=focused['outcomes']
    assert probe['path']=='audits/pass-shelat/Checks.lean'
    assert probe['valid_harness'] and probe['rc']==0 and not probe['errors']
    actual=mask(area/'seals-moved',probe)
    wanted={}
    with (area/'metadata/Head.jsonl').open() as stream:
        for row in map(json.loads,stream):
            if row['record']!='catalog' or row['home']['display']!=new_owner or row['kind']!='def':
                continue
            status=row['status'].rsplit('.',1)[-1]
            if status!='reducible' or row['matcher']:
                wanted[tuple(map(tuple,row['name']['components']))]=row
    assert wanted.keys()==actual.keys() and len(actual)==probe['requested']


def explicit(path,source_path):
    c1,c2,c3=re.split(r'(?m)^## \(c[23]\)[^\n]*\n',path.read_text())
    assert not any(line.startswith(source_path+':') or line.startswith(source_path[:-5].replace('/','.')+'\t')
                   for section in (c2,c3) for line in section.splitlines())
    rows={}
    for line in c1.splitlines():
        if line.startswith(source_path+':'):
            site,*fields=line.split('\t')
            assert len(fields)==7 and tuple(fields) not in rows,line
            rows[tuple(fields)]=site
    return rows


a=explicit(previous/'read-scan/scan.log',legacy)
b=explicit(area/'read-scan/scan.log',new)
assert a.keys()==b.keys() and len(a)==4
retained=[]
for r in read(previous/'READS.json')['inherited_explicit_reads']:
    key=tuple(r['scan_fields'])
    assert a[key]==r['current_site']
    _,line=a[key].rsplit(':',1)
    assert b[key]==f'{new}:{line}'
    retained.append({**r,'prior_site':a[key],'current_site':b[key]})
assert len(retained)==len(a)

def campaign_warnings(file):
    lines=file.read_text().splitlines()
    assert any('style_lint: 0 FAIL' in l for l in lines)
    return sorted(tuple(l.split(maxsplit=2)[1:]) for l in lines if l.startswith('WARN '))

a_warn=campaign_warnings(area/'style-campaign-base.log')
b_warn=campaign_warnings(area/'style-campaign-head.log')
assert a_warn==[(legacy if path==new else path,body) for path,body in b_warn]
plain=[]
for name in ('style-base.log','style-final.log'):
    log=(area/name).read_text()
    rows=[line for line in log.splitlines() if ' (> 1000, must split)' in line]
    assert len(rows)==1 and '1 findings in ' in log
    plain.append(rows[0].replace(new,legacy))
assert plain[0]==plain[1]
if ledger_only:
    print('Whole-file seal passed;',len(new_mask),'matching requests;',len(retained),'exact explicit-read relocations')
    sys.exit(0)
out={'base':plan['base'],'head':plan['head'],'passed':True,'whole_file_seals':1,
     'requests':len(new_mask),'focused_seals':1,'focused_requests':focused['outcomes'][0]['requested'],
     'source_errors':0,'new_reads':0,'inherited_explicit_reads':retained,
     'previous_read_sha256':sha(previous/'READS.json')}
with (area/'READS.json').open('x') as f:
    json.dump(out,f,ensure_ascii=False,indent=2)
    f.write('\n')
print('Whole-file and focused Checks seals pass;',len(retained),'inherited core reads mapped')
