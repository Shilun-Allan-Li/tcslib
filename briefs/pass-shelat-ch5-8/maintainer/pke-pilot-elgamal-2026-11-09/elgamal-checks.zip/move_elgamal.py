"""Move the ElGamal implementation byte-for-byte and preserve the original import."""
from pathlib import Path
import sys

crypto=Path(sys.argv[1])/'TCSlib/Cryptography'
legacy=crypto/'Candidates/ElGamal.lean'
new=crypto/'Encryption/PublicKey/ElGamal.lean'
candidates=crypto/'Candidates.lean'
facade=crypto/'Encryption/PublicKey.lean'
prefix='TCSlib.Cryptography.'
leaf=prefix+'Encryption.PublicKey.ElGamal'
base=legacy.read_bytes()
assert not new.exists()
new.write_bytes(base)
text=base.decode()
copyright=text[:text.index('import ')]
options=text[text.index('set_option'):text.index('/-!\n#')]
legacy.write_text(copyright+f'import {leaf}\n\n'+options+'''/-!
# ElGamal compatibility import

## Main definitions

This import exposes the group-message scheme from
`TCSlib.Cryptography.Encryption.PublicKey.ElGamal` and its safe-prime DDH assumption.

## Main results

The construction module gives `elGamal_correct` and `elGamal_secure`.
The fully qualified declaration names are available through this import.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Algorithm 106.2 and Theorem 107.3.)
-/
''')

def replace_once(path, before, after):
    text=path.read_text()
    assert text.count(before)==1,before
    path.write_text(text.replace(before,after,1))

replace_once(facade,'import '+prefix+'Candidates.ElGamal\n','import '+leaf+'\n')
replace_once(facade,'* `Candidates.ElGamal` gives the group-message scheme',
    '* `ElGamal` gives the group-message scheme')
replace_once(candidates,
    '''* `ElGamal` gives El Gamal encryption and its security theorem [PS10, Algorithm 106.2,
  Theorem 107.3].
''',
    '''* `ElGamal` re-exports the construction in `Encryption.PublicKey.ElGamal`
  [PS10, Algorithm 106.2 and Theorem 107.3].
''')
assert new.read_bytes()==base
