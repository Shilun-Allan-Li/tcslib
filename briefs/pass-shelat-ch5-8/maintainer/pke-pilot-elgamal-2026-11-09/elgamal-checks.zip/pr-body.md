## Public-key encryption pilot

Move ElGamal's group-message scheme, machines, correctness proof, and
DDH security reduction byte-for-byte into
`TCSlib.Cryptography.Encryption.PublicKey.ElGamal`. The old
`Candidates.ElGamal` import re-exports the implementation. The PKE
facade links to its new owner.

The original 1,835-line implementation moves together because the
algorithms and reduction share private polynomial-time arithmetic and
typed coin conversions. The inherited size finding moves with it.

## Verification

- All 6 affected modules pass, including both facades, the library root
  and campaign Checks. The replay verifies 1,079 retained objects.
- Both standalone imports pass. The census maps all 180 declarations to
  the new owner and accounts for 91 private names scoped to their file.
- The whole-file seal and the focused Checks seal pass. The 4 inherited
  core reads have the same line numbers in the relocated source.

Base `be34dc52367e5c4190d2aae5547d3260a75b85eb`. Checked head `85feea8b82fdef6117a6819900ec66f09e7e93bd`.

[Approved pilot map](https://github.com/Shilun-Allan-Li/tcslib/blob/be34dc52367e5c4190d2aae5547d3260a75b85eb/briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
