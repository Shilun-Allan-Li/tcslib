"""Seal newly foreign definitions in isolation from the inherited read debt."""
import importlib.util
import json
from pathlib import Path
import sys

workspace=Path.cwd()
area=Path(sys.argv[1]).resolve()
previous=area.parent/'gate06-combined-20261108'
tools=previous/'rule10-evidence-r2/tool-inputs'


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod


def read(path):
    return json.loads(path.read_bytes())


def write(path,data):
    with path.open('x') as stream:
        json.dump(data,stream,ensure_ascii=False,indent=2)
        stream.write('\n')


bs=load(tools/'build_seals.py','reviewed_seals')
controls=load(tools/'build_controls.py','reviewed_controls')
adapter=load(tools/'request_payload_adapter.py','reviewed_adapter')
bound=load(previous/'rule10-payload-retry-r3/bound_payload.py','reviewed_payload_bound')
adapter.configure_builders(bs,controls)
seal=bs.seal_command
bs.seal_command=lambda label,rows,*,end: bound.bound_payloads(seal(label,rows,end=end))
full=area/'seals'
manifest=read(full/'MANIFEST.json')
plan=read(Path(manifest['native_plan']))
root=Path(plan['worktree'])
owner='TCSlib.Cryptography.Encryption.PublicKey.ElGamal'
path='audits/pass-shelat/Checks.lean'
seen,pending=set(),[path[:-5]]
while pending:
    mod=pending.pop()
    if mod not in seen:
        seen.add(mod)
        pending.extend(plan['graph'][mod])
assert owner.replace('.','/') in seen
requested=[]
with (area/'metadata/Head.jsonl').open() as stream:
    for row in map(json.loads,stream):
        if row['record']!='catalog' or row['home']['display']!=owner or row['kind']!='def':
            continue
        status=row['status'].rsplit('.',1)[-1]
        if status=='reducible' and not row['matcher']:
            continue
        requested.append({'spelling':row['name']['display'],'home':owner,'matcher':row['matcher'],
                          'collector_reducibility':status,'instance':row['instance'],'abbrev':row['abbrev'],
                          'name_components':row['name']['components'],'home_components':row['home']['components'],
                          'constant_kind':'def'})
requested.sort(key=lambda row:row['spelling'])
assert 'TCSlib.Cryptography.Candidates.elGamal' in {r['spelling'] for r in requested}
assert len({adapter.name_key(r) for r in [
    {'components':v['name_components'],'display':v['spelling']} for v in requested]})==len(requested)
raw=(root/path).read_bytes()
assert bs.sha(raw)==plan['source_digests'][path[:-5]]
out=area/'seals-moved'
out.mkdir()
label='CleanupSealMovedChecks'
probe,insertions,lines=bs.instrument(raw,bs.header(raw),label,requested)
target=out/(label+'.lean')
target.write_bytes(probe)
entry={'label':label,'owner':'audits.pass-shelat.Checks','path':path,
       'source_sha256':bs.sha(raw),'probe_sha256':bs.sha(probe)}
write(out/(label+'.json'),{**entry,'requested':requested,'insertions':insertions,'line_map':lines})
write(out/'MANIFEST.json',{**manifest,'probes':[{**entry,'ordinal':1,'requested':len(requested),
    'module':target.relative_to(workspace).with_suffix('').as_posix()}]})
print(len(requested),'relocated definitions in the focused Checks probe')
