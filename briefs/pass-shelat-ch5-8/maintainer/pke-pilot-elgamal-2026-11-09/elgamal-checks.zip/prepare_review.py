"""Prepare the ElGamal relocation review and D-0 records."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

area=Path(sys.argv[1]).resolve()
mode=sys.argv[2]


def read(rel):
    return json.loads((area/rel).read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


native,source,decl,reads=map(read,('native/RESULT.json','SOURCE-CHECK.json','DECLARATIONS.json','READS.json'))
base,head=native['base'],native['head']
assert all(r['base']==base and r['head']==head for r in (source,decl,reads))
assert native['passed'] and reads['passed'] and decl['new_declarations']==0 and reads['new_reads']==0
n=decl['count']
private=len(decl['private_name_changes'])
fresh=native['fresh_native_checks']
retained=native['initial_retained']
inherited=len(reads['inherited_explicit_reads'])
length=source['source_lines']
repo='https://github.com/Shilun-Allan-Li/tcslib'
plan_doc='briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md'
review='pke-pilot-elgamal-2026-11-09'
review_doc=f'briefs/pass-shelat-ch5-8/maintainer/{review}/README.md'
if mode=='pr':
    (area/'pr-body.md').write_text(f"""## Public-key encryption pilot

Move ElGamal's group-message scheme, machines, correctness proof, and
DDH security reduction byte-for-byte into
`TCSlib.Cryptography.Encryption.PublicKey.ElGamal`. The old
`Candidates.ElGamal` import re-exports the implementation. The PKE
facade links to its new owner.

The original {length:,}-line implementation moves together because the
algorithms and reduction share private polynomial-time arithmetic and
typed coin conversions. The inherited size finding moves with it.

## Verification

- All {fresh} affected modules pass, including both facades, the library root
  and campaign Checks. The replay verifies {retained:,} retained objects.
- Both standalone imports pass. The census maps all {n} declarations to
  the new owner and accounts for {private} private names scoped to their file.
- The whole-file seal and the focused Checks seal pass. The {inherited} inherited
  core reads have the same line numbers in the relocated source.

Base `{base}`. Checked head `{head}`.

[Approved pilot map]({repo}/blob/{base}/{plan_doc})
""")
elif mode=='records':
    campaign=Path(sys.argv[3])
    pr=read('pr-live.json')
    assert pr['headRefOid']==head and pr['baseRefName']=='cryptography/pass-shelat-ch2-4'
    assert pr['state']=='OPEN' and not pr['isDraft'] and pr['mergeable']=='MERGEABLE'
    assert re.fullmatch(re.escape(repo)+r'/pull/\d+',pr['url'])
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=campaign,text=True).strip()==base
    assert {x['path'] for x in pr['files']}=={source['base_path'],source['head_path'],
        'TCSlib/Cryptography/Candidates.lean','TCSlib/Cryptography/Encryption/PublicKey.lean'}
    number,url=pr['number'],pr['url']
    stage=area/'records'
    evidence=stage/'evidence'
    evidence.mkdir(parents=True)
    archive=area/'elgamal-checks.zip'
    digest=sha(archive)
    for f in (archive.name,'pr-live.json'):
        shutil.copyfile(area/f,evidence/f)
    files=['native/'+p for p in ('PLAN.json','PRODUCTS.json','RESULT.json')]
    files+=['SOURCE-CHECK.json','DECLARATIONS.json','SEALS.json','SEALS-MOVED.json',
            'READS.json','read-scan/scan.log','pr-live.json']
    payload={'base':base,'head':head,'passed':True,'pr':number,'pr_url':url,
        'native':{'fresh':fresh,'retained':retained,'total':fresh+retained},
        'declarations':{'count':n,'rehomed':len(decl['rehomed']),'private_name_changes':private,'new':0},
        'seals':{'whole_file':reads['whole_file_seals'],'focused':reads['focused_seals'],
                 'requests':reads['requests'],'focused_requests':reads['focused_requests'],
                 'diagnostics':0,'inherited_explicit_reads':inherited,'new_reads':0,
                 'verified_retained_controls':decl['reused_sensitivity_controls']},
        'artifact_sha256':{f:sha(area/f) for f in files},
        'archive':{'name':archive.name,'sha256':digest,'bytes':archive.stat().st_size}}
    (evidence/'VERIFICATION.json').write_text(json.dumps(payload,indent=2)+'\n')
    (evidence/'README.md').write_text(f"""# ElGamal in public-key encryption

Seyoon merged the [DDH extraction #261]({repo}/pull/261) at `{base}`.
[PR #{number}]({url}) moves the ElGamal construction, correctness theorem,
and DDH security reduction at `{head}`. The
[approved PKE pilot](../cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
places the reusable assumption in `Candidates.DDH`.

The new PKE module is byte-for-byte identical to the old implementation.
The legacy candidate import re-exports it. The public-key facade imports
the new module directly.

- All {fresh} affected modules compile, including the library root and
  campaign Checks. The replay verifies {retained:,} retained objects. The
  Checks object and output match the accepted #261 baseline.
- Both standalone import probes pass. The census matches all {n} declaration
  types, definitions, reference sets and axiom dependencies. It accounts for
  {private} private names and compiler-generated binder labels at the new home.
- The whole-file seal repeats the previous {reads['requests']:,} requests and passes.
  The focused Checks seal covers {reads['focused_requests']} relocated definitions.
  The thirteen sensitivity controls transfer through identical checked
  closures, and the generated-equation collector reruns both controls.
- The source scan maps the {inherited} inherited core reads to the new path with
  the same line numbers. `READS.json` records the original ledger IDs and both
  module locations.
- The {length:,}-line module carries the inherited file-size finding and
  reader warnings. Keeping the body together preserves the private arithmetic
  used by both `dlc_poly_egEncParts` and `dlc_poly_ddhInput`, including
  `dlc_numPoly_egCanon` and `dlc_poly_natToList_powMulMod`. It also keeps the
  typed coin conversions in `dlc_challenge_eq` beside the construction fields
  they read. A separate split can establish those interfaces during the
  final layout and seal cleanup.

`VERIFICATION.json` binds the evidence to the checked source.
`elgamal-checks.zip` has SHA-256 `{digest}`.

**Clear to merge — the ElGamal move and legacy import pass.**
""")
    handoff=campaign/'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md'
    lines=handoff.read_text().splitlines(keepends=True)
    i,=(i for i,l in enumerate(lines) if l.startswith('| Cleanup and reorganization | '))
    pre,marker,_=lines[i].partition('[DDH extraction PR #261]')
    assert marker
    lines[i]=pre+f"""Seyoon merged the [DDH extraction #261]({repo}/pull/261) at `{base}`. [ElGamal relocation PR #{number}]({url}) at `{head}` is clear for Seyoon to merge. The construction and both proofs move verbatim, and the legacy import passes. The inherited size finding and four explicit reads are recorded. See the [ElGamal review](maintainer/{review}/README.md), [DDH review](maintainer/pke-pilot-ddh-2026-11-09/README.md) and [pilot map](maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md). Efficiency still needs the recorded issue-time probes. |
"""
    (stage/'MAINTAINER-HANDOFF.md').write_text(''.join(lines))
    log=(campaign/'PassShelatChapter5-8Plan.md').read_text()
    assert log.endswith('\n') and '#260 merged and the DDH extraction verified' in log.splitlines()[-1]
    row=f"""| 2026-11-09 (PST) | **#261 merged and the ElGamal construction move verified.** Seyoon merged #261 at `{base}`. [PR #{number}]({url}) at `{head}` moves the {length:,}-line construction and correctness and security proofs byte-for-byte. The legacy import passes. The {fresh} affected modules and both seals pass. The census maps all {n} declarations to their new home. The inherited size finding has a recorded private-proof boundary justification, and the four inherited reads map to the new path. [Verification]({review_doc}). Seyoon merges this slice. | record |
"""
    (stage/'PassShelatChapter5-8Plan.md').write_text(log+row)
    print(review,digest)
else:
    raise ValueError(mode)
