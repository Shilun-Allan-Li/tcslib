import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-! Unsealed controls: the two Part C examples of `StmtB1Probe.lean` without the seal (must pass). -/

namespace StmtB1Control

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.SecureComputation

/-- Control 1: reading `sliceEnc` through its body under the seal. -/
example {L : ℕ → ℕ} (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L n) → Bool))
    (n o : ℕ) (k r : Fin n → Bool) (m : List Bool) :
    sliceEnc G n o k r m =
      spEncStr (fun _ => (List.ofFn (G n k r)).drop o) (List.ofFn k) m (List.ofFn r) := rfl

/-- Control 2: reading `spEncStr` through its body under the seal. -/
example (E : List Bool → List Bool) (k m r : List Bool) :
    spEncStr E k m r = pairEncode r ((E (pairEncode k r)).take r.length ++
      List.zipWith xor m ((E (pairEncode k r)).drop r.length)) := rfl

end StmtB1Control
