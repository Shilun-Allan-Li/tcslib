import TCSlib.Cryptography.SecureComputation.SpecialEncryptionMulti
import TCSlib.Cryptography.SecureComputation.GarblingSpecial

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-! Statement-PR probe for B1 (evidence only, not part of the PR).
Part A: the bridges and the corollary re-elaborated with every definition they read sealed.
Part B: the frozen derivation and the Yao step-3 instantiation (unsealed, as consumers see them).
Part C: two sealed controls that must fail (they read a sealed definition through its body).
Part D: axioms. -/

namespace StmtB1Probe

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.SecureComputation

section SealedA

attribute [local irreducible] TCSlib.Cryptography.SecureComputation.spEncStr
  TCSlib.Cryptography.SecureComputation.specialScheme
  TCSlib.Cryptography.SecureComputation.sliceEnc
  TCSlib.Cryptography.SecureComputation.sliceMultiEncDist
  TCSlib.Cryptography.SecureComputation.SliceMultiMessageSecure
  TCSlib.Cryptography.PrivateKeyScheme.multiEncDist
  TCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure
  TCSlib.Cryptography.PrivateKeyScheme.encodeList
  TCSlib.Cryptography.distAdv TCSlib.Cryptography.acceptProb
  Complexity.NUPPT.coinsCongr Complexity.NUPPT.coinsEquiv_ofPolyTimeUniform
  Complexity.NUPPT.coinsEquivPoly Complexity.NUPPT.runAt Complexity.NUPPT.coinLen
  Complexity.NUPPT.ofPolyTimeUniform Complexity.NUPPT.distinguisherL
  Complexity.PolyExpr.eval Turing.pairEncode

/-- Probe copy. -/
theorem p_sliceEnc_eq_spEncStr {L : ℕ → ℕ}
    {G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L n) → Bool)} {E : List Bool → List Bool}
    (hGE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G n s x))
    (n o : ℕ) (k r : Fin n → Bool) (m : List Bool) :
    sliceEnc G n o k r m = spEncStr (fun z => (E z).drop o) (List.ofFn k) m (List.ofFn r) := by
  rw [sliceEnc_eq, spEncStr_eq, spEncStr_eq, hGE]

/-- Masking with a longer pad uses only its first `|m|` bits. -/
private theorem zipWith_xor_append_of_le : ∀ (m p b : List Bool), m.length ≤ p.length →
    List.zipWith xor m (p ++ b) = List.zipWith xor m p
  | [], _, _, _ => by simp
  | _ :: _, [], _, h => by simp at h
  | a :: m, c :: p, b, h => by
    simp only [List.cons_append, List.zipWith_cons_cons, List.cons.injEq, true_and]
    exact zipWith_xor_append_of_le m p b (by simpa using h)

/-- **The inner layer as a slice of `G₁ ‖ G₂`**: if `⟦G_k(r)⟧ = ⟦G₁_k(r)⟧ ++ ⟦G₂_k(r)⟧` and `E₁`
evaluates `G₁` (`2n`-bit outputs), then for `|m| ≤ n` the slice from offset `0` is the
`G₁`-ciphertext: `sliceEnc G n 0 k r m = spEncStr E₁ ⟦k⟧ m ⟦r⟧`. -/
theorem p_sliceEnc_append_left {L L₂ : ℕ → ℕ}
    {G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L n) → Bool)}
    {G₁ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool)}
    {G₂ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L₂ n) → Bool)} {E₁ : List Bool → List Bool}
    (hG : ∀ n (s x : Fin n → Bool),
      List.ofFn (G n s x) = List.ofFn (G₁ n s x) ++ List.ofFn (G₂ n s x))
    (hGE₁ : ∀ n (s x : Fin n → Bool), E₁ (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G₁ n s x))
    (n : ℕ) (k r : Fin n → Bool) {m : List Bool} (hm : m.length ≤ n) :
    sliceEnc G n 0 k r m = spEncStr E₁ (List.ofFn k) m (List.ofFn r) := by
  have h₁ : (List.ofFn (G₁ n k r)).length = n + n := List.length_ofFn
  rw [sliceEnc_eq, spEncStr_eq, spEncStr_eq, hGE₁, List.drop_zero, hG, List.length_ofFn,
    List.take_append_of_le_length (by omega), List.drop_append_of_le_length (by omega),
    zipWith_xor_append_of_le _ _ _ (by rw [List.length_drop]; omega)]

/-- **The outer layer as a slice of `G₁ ‖ G₂`**: if `⟦G_k(r)⟧ = ⟦G₁_k(r)⟧ ++ ⟦G₂_k(r)⟧` with `G₁`
of `2n`-bit outputs and `E₂` evaluates `G₂`, the slice from offset `2n` is the `G₂`-ciphertext:
`sliceEnc G n (n + n) k r m = spEncStr E₂ ⟦k⟧ m ⟦r⟧`, for every message `m`. -/
theorem p_sliceEnc_append_right {L L₂ : ℕ → ℕ}
    {G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L n) → Bool)}
    {G₁ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool)}
    {G₂ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L₂ n) → Bool)} {E₂ : List Bool → List Bool}
    (hG : ∀ n (s x : Fin n → Bool),
      List.ofFn (G n s x) = List.ofFn (G₁ n s x) ++ List.ofFn (G₂ n s x))
    (hGE₂ : ∀ n (s x : Fin n → Bool), E₂ (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G₂ n s x))
    (n : ℕ) (k r : Fin n → Bool) (m : List Bool) :
    sliceEnc G n (n + n) k r m = spEncStr E₂ (List.ofFn k) m (List.ofFn r) := by
  rw [sliceEnc_eq, spEncStr_eq, spEncStr_eq, hGE₂, hG, List.drop_left' List.length_ofFn]


section Corollary

variable (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hGE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (G n s x))

/-- The key generator of `specialScheme` outputs its coins: `Gen(1^n; rg) = ⟦rg⟧`. -/
private theorem specialScheme_gen_runAt (n : ℕ) :
    ∀ rg : (specialScheme G E hE hGE).gen.Coins n,
      (specialScheme G E hE hGE).gen.runAt n [] rg = List.ofFn rg := by
  rw [specialScheme_gen]
  intro rg
  exact runAt_coinKey .var n rg

/-- The encryption machine of `specialScheme` is `spEncStr` with its coins as the nonce. -/
private theorem specialScheme_enc_runAt (n : ℕ) :
    ∀ (k m : List Bool) (re : (specialScheme G E hE hGE).enc.Coins n),
      (specialScheme G E hE hGE).enc.runAt n (pairEncode k m) re =
        spEncStr E k m (List.ofFn re) := by
  rw [specialScheme_enc]
  intro k m re
  exact runAt_spEnc hE .var n k m re

/-- The key coins of `specialScheme` as an `n`-bit key, keeping the string. -/
private noncomputable def specialKeyEq (n : ℕ) :
    (specialScheme G E hE hGE).gen.Coins n ≃ (Fin n → Bool) :=
  (NUPPT.coinsCongr (by rw [specialScheme_gen]) n).trans
    ((NUPPT.coinsEquiv_ofPolyTimeUniform polyTimeComputable_pairSndD .var n).trans
      (Equiv.arrowCongr (finCongr (PolyExpr.eval_var n)) (Equiv.refl Bool)))

/-- `⟦specialKeyEq n rg⟧ = ⟦rg⟧`. -/
private theorem ofFn_specialKeyEq (n : ℕ) (rg : (specialScheme G E hE hGE).gen.Coins n) :
    List.ofFn (specialKeyEq G E hE hGE n rg) = List.ofFn rg := by
  rw [specialKeyEq, Equiv.trans_apply, Equiv.trans_apply, ofFn_arrowCongr_finCongr,
    NUPPT.coinsEquiv_ofPolyTimeUniform_ofFn, NUPPT.coinsCongr_ofFn]

/-- The encryption coins of `specialScheme` as an `n`-bit nonce, keeping the string. -/
private noncomputable def specialNonceEq (n : ℕ) :
    (specialScheme G E hE hGE).enc.Coins n ≃ (Fin n → Bool) :=
  (NUPPT.coinsCongr (by rw [specialScheme_enc]) n).trans
    ((NUPPT.coinsEquiv_ofPolyTimeUniform (polyTimeComputable_spEncFun hE) .var n).trans
      (Equiv.arrowCongr (finCongr (PolyExpr.eval_var n)) (Equiv.refl Bool)))

/-- `⟦specialNonceEq n re⟧ = ⟦re⟧`. -/
private theorem ofFn_specialNonceEq (n : ℕ) (re : (specialScheme G E hE hGE).enc.Coins n) :
    List.ofFn (specialNonceEq G E hE hGE n re) = List.ofFn re := by
  rw [specialNonceEq, Equiv.trans_apply, Equiv.trans_apply, ofFn_arrowCongr_finCongr,
    NUPPT.coinsEquiv_ofPolyTimeUniform_ofFn, NUPPT.coinsCongr_ofFn]

/-- **The frozen Claim 157.a (i) from the joint lemma** [PS10, §6.2.2, Definition 93.1]: if the
length-doubling family `G` is slice multi-message secure, then `specialScheme G E hE hGE` is
multi-message secure. With `sliceMultiMessageSecure_of_prfOut` this gives
`specialScheme_multiMessageSecure`.

**Proof sketch.** Take every slice to be `(0, n)`; it fits, as `0 + n + n ≤ 2n`. Relabel the
coins of `Gen` and `Enc` as an `n`-bit key and `n`-bit nonces, keeping their strings. Under this
bijection the scheme's multi-message sampler is the slice sampler pointwise: `Gen` outputs its
coins (`runAt_coinKey`), `Enc` is `spEncStr E` (`runAt_spEnc`), and a slice from offset `0` is
`spEncStr E` (`sliceEnc_eq_spEncStr`). Acceptance probabilities are invariant under relabelling
the seed (`acceptProb_comp_equiv`), so the slice bound applies verbatim. -/
theorem p_specialScheme_multiMessageSecure_of_joint (h : SliceMultiMessageSecure G) :
    (specialScheme G E hE hGE).MultiMessageSecure := by
  rw [PrivateKeyScheme.multiMessageSecure_iff]
  intro D q
  obtain ⟨ε, hε, hb⟩ := (sliceMultiMessageSecure_iff G).mp h D q
  refine ⟨ε, hε, fun n m m' => ?_⟩
  let e : (specialScheme G E hE hGE).gen.Coins n ×
      (Fin (q.eval n + 1) → (specialScheme G E hE hGE).enc.Coins n) ≃
      (Fin n → Bool) × (Fin (q.eval n + 1) → Fin n → Bool) :=
    (specialKeyEq G E hE hGE n).prodCongr
      (Equiv.piCongrRight fun _ => specialNonceEq G E hE hGE n)
  have hX : ∀ v : Fin (q.eval n + 1) → Fin n → Bool,
      (specialScheme G E hE hGE).multiEncDist n (q.eval n) v =
        fun t => sliceMultiEncDist G n (q.eval n) (fun _ => 0) (fun _ => n) v (e t) := by
    intro v
    funext t
    rw [PrivateKeyScheme.multiEncDist_apply, sliceMultiEncDist_apply]
    refine congrArg PrivateKeyScheme.encodeList (congrArg List.ofFn (funext fun i => ?_))
    rw [specialScheme_gen_runAt, specialScheme_enc_runAt, sliceEnc_eq_spEncStr hGE]
    simp only [e, Equiv.prodCongr_apply, Prod.map_fst, Prod.map_snd, Equiv.piCongrRight_apply,
      Pi.map_apply, List.drop_zero, ofFn_specialKeyEq, ofFn_specialNonceEq]
  rw [distAdv_def, hX m, hX m', acceptProb_comp_equiv, acceptProb_comp_equiv, ← distAdv_def]
  exact hb n (fun _ => 0) (fun _ => n) (fun _ => by show 0 + n + n ≤ n + n; omega) m m'

end Corollary

end SealedA

/-! Part B -/

/-- The frozen Claim 157.a (i) as the composite of the two new results. -/
theorem frozen_from_joint (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool))
    (E : List Bool → List Bool) (hE : PolyTimeComputable E)
    (hGE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G n s x))
    (hG : PRFOut (.add .var .var) G) :
    (specialScheme G E hE hGE).MultiMessageSecure :=
  specialScheme_multiMessageSecure_of_joint G E hE hGE (sliceMultiMessageSecure_of_prfOut hG)

/-- Yao step 3: with exactly the hypotheses of `yaoHybrid_simulators`, the joint family is slice
multi-message secure, its `(0, n)` slices are the `G₁`-ciphertexts and its `(2n, 4n+2)` slices
the `G₂`-ciphertexts, and both slice shapes fit. -/
theorem yao_step3_instance
    (G₁ : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (n + n) → Bool))
    (G₂ : ∀ n, (Fin n → Bool) → (Fin n → Bool) →
      (Fin ((PolyExpr.add .var innerLen).eval n) → Bool))
    (E₁ E₂ : List Bool → List Bool)
    (hGE₁ : ∀ n (s x : Fin n → Bool), E₁ (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G₁ n s x))
    (hGE₂ : ∀ n (s x : Fin n → Bool), E₂ (pairEncode (List.ofFn s) (List.ofFn x)) =
      List.ofFn (G₂ n s x))
    (hG₁₂ : PRFOut (.add (.add .var .var) (.add .var innerLen))
      (fun n s x => Fin.append (G₁ n s x) (G₂ n s x))) :
    SliceMultiMessageSecure (L := fun n => (PolyExpr.add (.add .var .var) (.add .var innerLen)).eval n)
        (fun n s x => Fin.append (G₁ n s x) (G₂ n s x)) ∧
      (∀ n (k r : Fin n → Bool) (m : List Bool), m.length ≤ n →
        sliceEnc (L := fun n => (PolyExpr.add (.add .var .var) (.add .var innerLen)).eval n)
          (fun n s x => Fin.append (G₁ n s x) (G₂ n s x)) n 0 k r m =
            spEncStr E₁ (List.ofFn k) m (List.ofFn r)) ∧
      (∀ n (k r : Fin n → Bool) (m : List Bool),
        sliceEnc (L := fun n => (PolyExpr.add (.add .var .var) (.add .var innerLen)).eval n)
          (fun n s x => Fin.append (G₁ n s x) (G₂ n s x)) n (n + n) k r m =
            spEncStr E₂ (List.ofFn k) m (List.ofFn r)) ∧
      (∀ n, 0 + n + n ≤ (PolyExpr.add (.add .var .var) (.add .var innerLen)).eval n) ∧
      (∀ n, (n + n) + n + innerLen.eval n =
        (PolyExpr.add (.add .var .var) (.add .var innerLen)).eval n) := by
  have hG : ∀ n (s x : Fin n → Bool),
      List.ofFn ((fun n s x => Fin.append (G₁ n s x) (G₂ n s x) :
        ∀ n, (Fin n → Bool) → (Fin n → Bool) →
          (Fin ((PolyExpr.add (.add .var .var) (.add .var innerLen)).eval n) → Bool)) n s x) =
        List.ofFn (G₁ n s x) ++ List.ofFn (G₂ n s x) :=
    fun n s x => List.ofFn_fin_append (G₁ n s x) (G₂ n s x)
  refine ⟨sliceMultiMessageSecure_of_prfOut hG₁₂, fun n k r m hm =>
    sliceEnc_append_left hG hGE₁ n k r hm, fun n k r m => sliceEnc_append_right hG hGE₂ n k r m,
    fun n => ?_, fun n => ?_⟩
  · simp only [PolyExpr.eval_add, PolyExpr.eval_var]; omega
  · simp only [PolyExpr.eval_add, PolyExpr.eval_var]; omega

/-! Part C: sealed controls (each must fail exactly once). -/

section SealedC

attribute [local irreducible] TCSlib.Cryptography.SecureComputation.spEncStr
  TCSlib.Cryptography.SecureComputation.specialScheme
  TCSlib.Cryptography.SecureComputation.sliceEnc
  TCSlib.Cryptography.SecureComputation.sliceMultiEncDist
  TCSlib.Cryptography.SecureComputation.SliceMultiMessageSecure
  TCSlib.Cryptography.PrivateKeyScheme.multiEncDist
  TCSlib.Cryptography.PrivateKeyScheme.MultiMessageSecure
  TCSlib.Cryptography.PrivateKeyScheme.encodeList
  TCSlib.Cryptography.distAdv TCSlib.Cryptography.acceptProb
  Complexity.NUPPT.coinsCongr Complexity.NUPPT.coinsEquiv_ofPolyTimeUniform
  Complexity.NUPPT.coinsEquivPoly Complexity.NUPPT.runAt Complexity.NUPPT.coinLen
  Complexity.NUPPT.ofPolyTimeUniform Complexity.NUPPT.distinguisherL
  Complexity.PolyExpr.eval Turing.pairEncode

/-- Control 1: reading `sliceEnc` through its body under the seal. -/
example {L : ℕ → ℕ} (G : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin (L n) → Bool))
    (n o : ℕ) (k r : Fin n → Bool) (m : List Bool) :
    sliceEnc G n o k r m =
      spEncStr (fun _ => (List.ofFn (G n k r)).drop o) (List.ofFn k) m (List.ofFn r) := rfl

/-- Control 2: reading `spEncStr` through its body under the seal. -/
example (E : List Bool → List Bool) (k m r : List Bool) :
    spEncStr E k m r = pairEncode r ((E (pairEncode k r)).take r.length ++
      List.zipWith xor m ((E (pairEncode k r)).drop r.length)) := rfl

end SealedC

end StmtB1Probe

/-! Part D -/

#print axioms TCSlib.Cryptography.SecureComputation.sliceMultiMessageSecure_of_prfOut
#print axioms TCSlib.Cryptography.SecureComputation.specialScheme_multiMessageSecure_of_joint
#print axioms TCSlib.Cryptography.SecureComputation.sliceEnc_eq
#print axioms TCSlib.Cryptography.SecureComputation.sliceEnc_eq_spEncStr
#print axioms TCSlib.Cryptography.SecureComputation.sliceEnc_append_left
#print axioms TCSlib.Cryptography.SecureComputation.sliceEnc_append_right
#print axioms TCSlib.Cryptography.SecureComputation.sliceMultiEncDist_apply
#print axioms TCSlib.Cryptography.SecureComputation.sliceMultiMessageSecure_iff
#print axioms StmtB1Probe.p_specialScheme_multiMessageSecure_of_joint
#print axioms StmtB1Probe.frozen_from_joint
#print axioms StmtB1Probe.yao_step3_instance
