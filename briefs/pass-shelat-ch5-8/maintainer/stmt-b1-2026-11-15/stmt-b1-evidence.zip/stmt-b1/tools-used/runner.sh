#!/usr/bin/env bash
# runner.sh <worktree> <order-file> <log-dir> <summary.tsv>: check each module in order with
# scripts/lean_check_tree.sh into $TCSLIB_OLEANS; stop at the first failure.
set -u
WT=$1; ORD=$2; LD=$3; SUM=$4
export PATH=$HOME/.elan/bin:$PATH
mkdir -p "$LD"; : > "$SUM"
cd "$WT" || exit 2
while read -r m; do
  [ -z "$m" ] && continue
  lf="$LD/$(echo "$m" | tr / _).log"
  t0=$(date +%s)
  bash scripts/lean_check_tree.sh "$m" > "$lf" 2>&1; rc=$?
  t1=$(date +%s)
  ne=$(grep -c "error" "$lf"); ns=$(grep -c "declaration uses 'sorry'" "$lf")
  printf '%s\t%s\t%s\t%s\t%s\n' "$m" "$rc" "$ne" "$ns" "$((t1-t0))" >> "$SUM"
  [ "$rc" -ne 0 ] && { echo "STOP at $m rc=$rc"; exit 1; }
done < "$ORD"
echo "ALL OK $(wc -l < "$SUM")"
