## B1 statement: joint, length-generic multi-message security of special encryption

Draft maintainer statement PR (ruling B1, Seyoon, 2026-11-14). It states, sorried, the joint
multi-message lemma that step 3 of `yaoHybrid_simulators` needs, and proves that the frozen
`specialScheme_multiMessageSecure` is its corollary. Statement gate before any fill; the proof
belongs to `sc-garble` (U1) and uses the ℓ-output PRF machinery of `prf-long` (ruling B3).

Branch `stmt/pass-shelat-b1-multimsg`, one commit on `cryptography/pass-shelat-ch2-4` at
`013119f006af40d03b88b0fc2d9b453cf0a9b348`. No frozen file is changed.

### Changes

- New module `TCSlib/Cryptography/SecureComputation/SpecialEncryptionMulti.lean` (325 lines):
  - `sliceEnc` (Algorithm 157.2 with the pad `G_k(r)_{≥o}`), `sliceMultiEncDist`
    (`q + 1` slice ciphertexts under one key), `SliceMultiMessageSecure`, with readers
    `sliceEnc_eq`, `sliceMultiEncDist_apply`, `sliceMultiMessageSecure_iff` (all `rfl`/`Iff.rfl`);
  - **`sliceMultiMessageSecure_of_prfOut`** (stated, `sorry` under a sketch): every `PRFOut ℓ G`
    is slice multi-message secure;
  - `specialScheme_multiMessageSecure_of_joint` (proved): `SliceMultiMessageSecure G →
    (specialScheme G E hE hGE).MultiMessageSecure`;
  - `sliceEnc_eq_spEncStr`, `sliceEnc_append_left`, `sliceEnc_append_right` (proved): slices of
    `G₁ ‖ G₂` at offsets `0` and `2n` are the `G₁`- and `G₂`-ciphertexts of `nestedSpecial`.
- Facade `SecureComputation.lean`: imports the module, `## Contents` line added (#305).

### Checks

- 63 modules (every module downstream of the change since the olean base, through root
  `TCSlib` and `audits/pass-shelat/Checks`) rc 0; the only new `sorry` warning is
  `sliceMultiMessageSecure_of_prfOut`.
- Lint `TCSlib/Cryptography`: 92 FAIL / 101 WARN, FAIL and WARN lines identical to the tip.
- Axioms: `sliceMultiMessageSecure_of_prfOut` has `sorryAx` (intended); the corollary and the
  bridges are standard.
- Seal probe: the bridges and the corollary re-elaborate with every definition they read
  sealed; two sealed controls fail, and pass unsealed.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA
