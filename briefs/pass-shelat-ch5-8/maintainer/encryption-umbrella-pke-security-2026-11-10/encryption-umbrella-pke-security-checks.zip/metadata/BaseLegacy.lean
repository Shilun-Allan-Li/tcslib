import TCSlib.Cryptography.Composability.PublicKey
import TCSlib.Cryptography.Composability.NonMalleable
import TCSlib.Cryptography.Composability.SimNonMalleable

#check @TCSlib.Cryptography.TrapdoorCollection.tdpBitScheme_padded_cpa
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmCodec_timeout
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmGame_eq
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.NMSecure_iff
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2
#check @TCSlib.Cryptography.Composability.MsgSampler
#check @TCSlib.Cryptography.Composability.MsgSampler.draw_eq
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.snmReal_eq
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.SimNMSecure_iff
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.nmSecure_of_simNMSecure
#check @TCSlib.Cryptography.Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa
