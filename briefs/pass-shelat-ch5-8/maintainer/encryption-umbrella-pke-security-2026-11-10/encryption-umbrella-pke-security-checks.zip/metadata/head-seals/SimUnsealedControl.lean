import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation

open Complexity TCSlib.Cryptography TCSlib.Cryptography.Composability

example (M : MsgSampler) (ℓ n : ℕ) (a : Fin (M.paramLen.eval n) → Bool)
    (ρ : M.samp.Coins n) :
    M.draw ℓ n a ρ = padFin ℓ (M.samp.runAt n (List.ofFn a) ρ) := by
  rfl
