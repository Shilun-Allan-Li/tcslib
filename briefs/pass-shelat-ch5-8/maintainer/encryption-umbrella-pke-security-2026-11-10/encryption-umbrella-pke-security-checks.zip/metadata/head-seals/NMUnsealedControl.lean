import TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Indistinguishability

open Complexity TCSlib.Cryptography.Games TCSlib.Cryptography.Composability

example (S : FixedLengthPKScheme) (n ℓ : ℕ) :
    (S.nmCodec n ℓ).timeout = zeroBits (ℓ * S.ctLen.eval n) := by
  rfl
