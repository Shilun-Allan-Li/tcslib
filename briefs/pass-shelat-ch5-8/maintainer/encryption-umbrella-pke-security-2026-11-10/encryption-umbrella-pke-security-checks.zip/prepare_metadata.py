"""Copy exact checked imports for the standalone and baseline probes."""
from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, campaign, graph_file = (Path(arg).resolve() for arg in sys.argv[1:4])
side = sys.argv[4]
assert side in {"Base", "Head"}
spec = importlib.util.spec_from_file_location("checked_import_graph", graph_file)
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
meta = area / "metadata"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def copy(src, dst, digest):
    assert sha(src) == digest, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == digest and not dst.samefile(src), dst


scope = read(area / "MOVE-SCOPE.json")
owners = list(scope["moves"])
legacy = list(scope["moves"].values())
native = area / "native"
plan = read(native / "PLAN.json")
base = read(area / "BASE-IMPORTS.json")
assert base["head"] == plan["base"]
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=campaign, text=True).strip() == plan["base"]
products = dict(plan["retained"])
for check in sorted(native.glob("run-*/check-*.json")):
    try:
        row = read(check)
    except json.JSONDecodeError:
        continue
    if row["rc"] == 0:
        assert row["head"] == plan["head"] and sha(check.with_suffix(".log")) == row["log_sha256"]
        products[row["module"]] = row

base_side = side == "Base"
needed_graph = base["graph"] if base_side else plan["graph"]
needed_digests = base["source_digests"] if base_side else plan["source_digests"]
roots = legacy if base_side else legacy + owners
needed = graph.topo(needed_graph, roots)
rebuild = set(legacy) if base_side else set()
assert set(needed) - rebuild <= products.keys(), sorted(set(needed) - rebuild - products.keys())
assert "TCSlib" not in needed and not {scope["umbrella"], scope["public_key"]} & set(needed)

out = meta / side.lower()
out.mkdir()
tree = out / "oleans"
parent_tree = Path(plan["tree"])
retained = {}
for module in needed:
    if module in rebuild:
        continue
    row = products[module]
    assert row["source_sha256"] == needed_digests[module], module
    assert row["direct_local"] == {dep: retained[dep]["object_sha256"] for dep in needed_graph[module]}, module
    copy(parent_tree / (module + ".olean"), tree / (module + ".olean"), row["object_sha256"])
    retained[module] = row

external = {}
for name, row in plan["external"].items():
    src = Path(row["path"])
    dst = src
    if src.is_relative_to(parent_tree):
        dst = tree / src.relative_to(parent_tree)
        copy(src, dst, row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
    external[name] = {**row, "path": str(dst)}
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
if base_side:
    before = {
        "base": plan["base"], "head": plan["base"], "baseline": plan["head"],
        "worktree": str(campaign), "tree": str(tree), "toolchain": plan["toolchain"],
        "toolchain_sha256": plan["toolchain_sha256"], "checker_sha256": plan["checker_sha256"],
        "affected": sorted(rebuild), "rebuild": [m for m in needed if m in rebuild],
        "order": needed, "retained": retained, "graph": {m: needed_graph[m] for m in needed},
        "external": external, "source_digests": {m: needed_digests[m] for m in needed},
    }
    (out / "PLAN.json").write_text(json.dumps(before, indent=2) + "\n")

def imports(modules):
    return "".join("import " + m.replace("/", ".") + "\n" for m in modules)

template = area.parent / "ggm-move-20261109/metadata/HeadCensus.lean"
program = template.read_text()
providers = legacy if base_side else owners
program, count = re.subn(r"^import TCSlib\.Cryptography\.Asymptotic\.PRF\n", imports(providers), program, flags=re.M)
assert count == 1
owner_text = ", ".join(chr(96) + module.replace("/", ".") for module in providers)
program, count = re.subn(r"(?m)^  let owners : Array Name := .*", "  let owners : Array Name := #[" + owner_text + "]", program)
assert count == 1
program, count = re.subn(r'(?m)^  let file ← IO.FS.Handle.mk ".*" \.write$',
                         f'  let file ← IO.FS.Handle.mk "{meta / (side + ".jsonl")}" .write', program)
assert count == 1
program = program.replace("GGM declaration census complete", "Public-key security declaration census complete")
(meta / (side + "Census.lean")).write_text(program)
prefix = "TCSlib.Cryptography."
names = [
    "TrapdoorCollection.tdpBitScheme_padded_cpa",
    "Composability.FixedLengthPKScheme.nmCodec_timeout",
    "Composability.FixedLengthPKScheme.nmGame_eq",
    "Composability.FixedLengthPKScheme.NMSecure_iff",
    "Composability.FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2",
    "Composability.MsgSampler",
    "Composability.MsgSampler.draw_eq",
    "Composability.FixedLengthPKScheme.snmReal_eq",
    "Composability.FixedLengthPKScheme.SimNMSecure_iff",
    "Composability.FixedLengthPKScheme.nmSecure_of_simNMSecure",
    "Composability.FixedLengthPKScheme.simNMSecure_cpa_iff_nmSecure_cpa",
]

def probe(label, provider):
    body = imports(provider) + "\n" + "".join("#check @" + prefix + name + "\n" for name in names)
    (meta / (label + ".lean")).write_text(body)

probe(side + "Legacy", legacy)
if not base_side:
    probe("Standalone", owners)
print(f"{side}: staged {len(retained)} verified modules and {len(rebuild)} baseline checks.", flush=True)
