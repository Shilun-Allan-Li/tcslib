"""Pin the combined source and reuse only unchanged dependency objects."""
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
area, worktree, campaign, previous, graph_script = (Path(arg).resolve() for arg in sys.argv[1:])
spec = importlib.util.spec_from_file_location("checked_import_graph", graph_script)
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root)


def ref(root, revision):
    return git(root, "rev-parse", revision).decode().strip()


def put(path, value):
    with path.open("x") as file:
        json.dump(value, file, indent=2, ensure_ascii=False)
        file.write("\n")


def copy(src, dst, digest):
    assert sha(src) == digest, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == digest and not dst.samefile(src), dst


def local_sources(root):
    names = git(root, "ls-files", "-z", "--", "TCSlib", "TCSlib.lean", checks + ".lean")
    return {name[:-5]: (root / name).read_bytes() for name in names.decode().split("\0") if name.endswith(".lean")}


def import_tables(raw):
    full = {name: [d.replace(".", "/") for d in graph.imports(data)] for name, data in raw.items()}
    local = {name: [d for d in deps if d in raw] for name, deps in full.items()}
    return full, local


def code_lines(raw):
    return [line for line in graph.comments_removed(raw.decode()).splitlines() if line.strip()]


base, head, prior = ((area / f"{name}.txt").read_text().strip() for name in ("base", "head", "predecessor"))
scope = read(area / "MOVE-SCOPE.json")
moves = scope["moves"]
owners = set(moves)
shims = set(moves.values())
umbrella, public, comp = (scope[key] for key in ("umbrella", "public_key", "composability"))
changed = owners | shims | {umbrella, public} | set(scope["doc_only"])
checks = "audits/pass-shelat/Checks"
out = area / "native"
tree = out / "oleans"
old = read(previous / "PLAN.json")
products = read(previous / "PRODUCTS.json")
checked = read(previous / "RESULT.json")
receipt_path = (campaign / "briefs/pass-shelat-ch5-8/maintainer/authentication-signatures-hashing-2026-11-09"
                / "VERIFICATION.json")
receipt = read(receipt_path)
assert ref(worktree, "HEAD") == head and ref(worktree, "HEAD^") == base == ref(campaign, "HEAD")
assert ref(campaign, "HEAD~2^2") == prior
assert all(not git(root, "status", "--porcelain") for root in (campaign, worktree))
assert not git(worktree, "diff", "--check", base, head)
assert {p[:-5] for p in git(worktree, "diff", "--name-only", base, head).decode().splitlines()} == changed
assert len(changed) == 11 and len(owners) == len(shims) == 3
assert prior == old["head"] == checked["head"] == receipt["head"]
assert checked["passed"] and receipt["passed"]
for artifact in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
    assert sha(previous / artifact) == receipt["artifact_sha256"]["native/" + artifact], artifact
assert not git(worktree, "diff", "--name-only", prior, head, "--", "lean-toolchain",
               "lake-manifest.json", "lakefile.lean", "lakefile.toml", "scripts/lean_check_tree.sh")
lean = Path(old["toolchain"])
assert sha(lean) == old["toolchain_sha256"]
assert sha(worktree / "scripts/lean_check_tree.sh") == old["checker_sha256"]

base_raw = local_sources(campaign)
sources = local_sources(worktree)
assert sources.keys() == base_raw.keys() | owners
assert all(sources[name] == base_raw[name] for name in base_raw if name not in changed)
assert all(sources[name] == (area / "source" / (name + ".lean")).read_bytes() for name in changed)
for owner, legacy in moves.items():
    marker = b"set_option maxHeartbeats"
    assert sources[owner].split(marker, 1)[1] == base_raw[legacy].split(marker, 1)[1], owner
    assert all(line.startswith(("import ", "set_option ")) for line in code_lines(sources[legacy])), legacy
for name in scope["doc_only"]:
    assert code_lines(sources[name]) == code_lines(base_raw[name]), name

_, base_imports = import_tables(base_raw)
full, imports = import_tables(sources)
for owner, deps in scope["owners_imports"].items():
    assert full[owner] == deps, owner
for owner, legacy in moves.items():
    assert imports[legacy] == base_imports[legacy] + [owner], legacy
    narrow = set(graph.topo(imports, [owner]))
    assert not narrow & (shims | {umbrella, public, comp, "TCSlib", checks}), owner
    assert narrow - owners <= set(graph.topo(base_imports, [legacy])) - {legacy}, owner
assert imports[public] == base_imports[public] + list(moves)
assert [dep for dep in imports[umbrella] if dep != umbrella + "/PrivateKey"] == base_imports[umbrella]
assert all(imports[m] == base_imports[m] for m in base_raw if m not in changed)
for module in (*sorted(shims), comp, public, umbrella, "TCSlib"):
    before = set(graph.topo(base_imports, [module]))
    added = {owner for owner, legacy in moves.items() if legacy in before}
    if module in (public, umbrella, "TCSlib"):
        added |= owners
    if module == umbrella:
        added.update(graph.topo(base_imports, [umbrella + "/PrivateKey"]))
    assert set(graph.topo(imports, [module])) == before | added, module

# Check the three old and new import routes early. Finish with the full root
# and campaign aggregate so the exact combined tree also gets replayed.
order = graph.topo(imports, [*moves.values(), *moves, "TCSlib", checks])
base_order = graph.topo(base_imports, ["TCSlib", checks])
assert set(order) == set(base_order) | owners
digests = {name: sha256(raw).hexdigest() for name, raw in sources.items()}
base_digests = {name: sha256(raw).hexdigest() for name, raw in base_raw.items()}

def descendants(start, import_map, sorted_modules):
    affected = set(start)
    for name in sorted_modules:
        if affected.intersection(import_map[name]):
            affected.add(name)
    return affected

integrated = {m for m in base_order if base_digests[m] != old["source_digests"].get(m)}
layout_affected = descendants(changed, imports, order)
fresh = descendants({m for m in order if digests[m] != old["source_digests"].get(m)}, imports, order) | {checks}
assert fresh == layout_affected | descendants(integrated, imports, order) | {checks}
rebuild = [name for name in order if name in fresh]

# First identify every available package object and check direct import roots.
# Existing package hashes are kept pinned, with the newly cached roots added.
old_tree = Path(old["tree"]).resolve()
assert old_tree == (previous / "oleans").resolve()
package_objects = {}
for folder in sorted(worktree.glob(".lake/packages/*/.lake/build/lib/lean")):
    for obj in folder.rglob("*.olean"):
        name = ".".join(obj.relative_to(folder).with_suffix("").parts)
        package_objects.setdefault(name, obj.resolve())
external = {}
external_copies = []
for name, item in old["external"].items():
    obj = Path(item["path"]).resolve()
    if obj.is_relative_to(old_tree):
        dest = tree / obj.relative_to(old_tree)
        external_copies.append((obj, dest, item["sha256"]))
    else:
        assert sha(obj) == item["sha256"], obj
        dest = obj
    external[name] = {"path": str(dest), "sha256": item["sha256"]}
added_package_names = sorted(package_objects.keys() - external.keys())
for name in added_package_names:
    obj = package_objects[name]
    external[name] = {"path": str(obj), "sha256": sha(obj)}
sysroot = lean.parent.parent / "lib/lean"
missing = sorted({dep for name in order for dep in full[name] if dep not in sources
                  and dep.replace("/", ".") not in external and not (sysroot / (dep + ".olean")).is_file()})
assert not missing, missing

assert shutil.disk_usage(area).free >= 12 * 1024**3
out.mkdir()
retained = {}
for name in order:
    if name in fresh:
        continue
    row = products[name]
    assert digests[name] == row["source_sha256"], name
    assert row["direct_local"] == {dep: retained[dep]["object_sha256"] for dep in imports[name]}, name
    copy(old_tree / (name + ".olean"), tree / (name + ".olean"), row["object_sha256"])
    retained[name] = {**row, "source": "verified_signature_and_hashing_tree"}
for src, dest, digest in external_copies:
    copy(src, dest, digest)
(tree / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
plan = {
    "base": base, "head": head, "baseline": prior, "worktree": str(worktree), "tree": str(tree),
    "toolchain": str(lean), "toolchain_sha256": old["toolchain_sha256"], "checker_sha256": old["checker_sha256"],
    "affected": sorted(layout_affected), "rebuild": rebuild, "order": order, "retained": retained,
    "graph": {name: imports[name] for name in order}, "external": external, "source_digests": digests,
}
put(out / "PLAN.json", plan)
put(area / "BASE-IMPORTS.json", {"head": base, "graph": base_imports, "source_digests": base_digests})
put(area / "SOURCE-CHECK.json", {
    "base": base, "head": head, "baseline": prior, "changed_paths": sorted(changed),
    "new_owners": sorted(owners), "relocation": moves,
    "legacy_closure_preserved": True, "facade_closure_preserved": True,
    "proof_and_definition_code_preserved": True, "comment_only_paths": scope["doc_only"],
    "affected_modules": len(layout_affected), "campaign_checks_replayed": [checks],
    "retarget_source_modules": sorted(integrated),
    "retarget_affected_modules": len(descendants(integrated, base_imports, base_order)),
    "retained_objects": len(retained), "external_objects": len(external),
    "added_package_objects": len(added_package_names), "predecessor_receipt_sha256": sha(receipt_path),
})
print(f"{len(layout_affected)} layout-affected modules, {len(rebuild)} total fresh checks with lattice integration, "
      f"{len(retained)} verified transfers and {len(external)} external objects.", flush=True)
