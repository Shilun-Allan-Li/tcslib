## Layout

- Give the encryption umbrella both private-key routes and the public-key construction map.
- Add documentation backlinks from the RSA and Rabin candidates to the shared trapdoor route.
- Move the trapdoor CPA corollary and the two non-malleability developments to their public-key owners. Keep the three original imports as compatibility paths.

## Verification

- The exact combined branch passes 318 fresh checks, including all 14 layout-affected modules, the library root and campaign Checks. The replay verifies 855 unchanged local objects.
- The original modules were compiled with the same checked dependencies. The comparison matches all 108 declaration types, definition values, references and axiom sets. The legacy, standalone and umbrella probes pass.
- All six whole-file seals and both reader controls pass. The explicit and generated read scans report zero foreign definition reads. The records account for the pre-existing candidate size warnings and the umbrella linter's three transitive-import reports.

The existing CPA bridge and three non-malleability admissions are recorded with their derived dependencies.
