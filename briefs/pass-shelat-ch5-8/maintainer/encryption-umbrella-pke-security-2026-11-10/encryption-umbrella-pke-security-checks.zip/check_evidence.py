"""Verify the exact source replay, declaration comparison, seals and ledger mapping."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, repo, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
native, meta = area / "native", area / "metadata"
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source, move, decls = (read(area / (name + ".json")) for name in ("SOURCE-CHECK", "MOVE-SCOPE", "DECLARATIONS"))
moves = move["moves"]
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain") and not git("diff", "--check", base, head)
assert all((r["base"], r["head"]) == (base, head) for r in (plan, result, source, decls))
assert result["passed"] and result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == 318
assert len(plan["affected"]) == source["affected_modules"] == 14
assert set(source["campaign_checks_replayed"]) == {"audits/pass-shelat/Checks"}
assert set(plan["affected"]) | {"audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert len(source["retarget_source_modules"]) == 58 and source["retarget_affected_modules"] == 315
assert result["initial_retained"] == len(plan["retained"]) == 855
assert len(products) == len(plan["order"]) == 1173 and len(plan["external"]) == 3815
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert source["legacy_closure_preserved"] and source["facade_closure_preserved"]
assert source["proof_and_definition_code_preserved"] and source["relocation"] == moves
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert decls["matched_declarations"] == decls["relocated_declarations"] == 108
assert decls["elaborated_references_match"] and decls["private_name_changes"] == 6
renamed = [row for row in decls["declarations"] if row["old_name"] != row["new_name"]]
assert len(renamed) == 6
old_home = "TCSlib.Cryptography.Composability.SimNonMalleable"
new_home = "TCSlib.Cryptography.Encryption.PublicKey.NonMalleability.Simulation"
expected_auxiliaries = {
    f"TCSlib.Cryptography.Composability.FixedLengthPKScheme.snmImpl.match_{matcher}.{auxiliary}"
    for matcher in (1, 3) for auxiliary in ("eq_1", "eq_2", "splitter")
}
assert {row["old_name"] for row in renamed} == {f"_private.{old_home}.0.{name}" for name in expected_auxiliaries}
assert all(row["old_home"] == old_home and row["new_home"] == new_home
           and row["new_name"] == row["old_name"].replace(f"_private.{old_home}.0.", f"_private.{new_home}.0.", 1)
           for row in renamed)
assert decls["axioms_match"] and decls["legacy_and_new_imports_agree"]
security = "TCSlib.Cryptography.Composability.FixedLengthPKScheme."
assert decls["admission_dependencies"] == sorted([
    "TCSlib.Cryptography.TrapdoorCollection.tdpBitScheme_padded_cpa",
    *[security + name for name in ("indSecure_cca2_iff_nmSecure_cca2", "nmSecure_of_simNMSecure",
                                   "simNMSecure_of_nmSecure_cpa", "simNMSecure_cpa_iff_nmSecure_cpa")],
])
assert set(source["comment_only_paths"]) == {
    move["composability"], "TCSlib/Cryptography/Candidates/RSA", "TCSlib/Cryptography/Candidates/Rabin",
}

baseline = meta / "base"
base_plan, base_result, base_products = (read(baseline / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
assert base_plan["head"] == base_result["head"] == base
assert base_result["passed"] and base_result["fresh_native_checks"] == 3
assert base_result["plan_sha256"] == sha(baseline / "PLAN.json")
assert base_result["products_sha256"] == sha(baseline / "PRODUCTS.json")
assert set(base_plan["rebuild"]) == set(moves.values())
assert set(base_products) == set(base_plan["order"])
for module, row in base_products.items():
    assert row["source_sha256"] == base_plan["source_digests"][module]
    assert row["direct_local"] == {dep: base_products[dep]["object_sha256"] for dep in base_plan["graph"][module]}
    if module not in moves.values():
        assert row["object_sha256"] == products[module]["object_sha256"], module
        assert row["source_sha256"] == products[module]["source_sha256"], module
base_fresh = {}
for receipt in baseline.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == base and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    base_fresh[row["module"]] = row["object_sha256"]
assert base_fresh == {module: base_products[module]["object_sha256"] for module in moves.values()}

seals, masks, warnings = {"base": {}, "head": {}}, {}, {}
provider_homes = {r["old_name"]: r["new_home"] for r in decls["declarations"] if r["kind"] == "def"}
controls_to_run = {"NM": security + "nmCodec", "Sim": "TCSlib.Cryptography.Composability.MsgSampler.draw"}
for side, rev, modules in (("base", base, moves.values()), ("head", head, moves)):
    directory = meta / (side + "-seals")
    scope = read(directory / "SCOPE.json")
    labels = {module.rsplit("/", 1)[-1] + "Seal" for module in modules}
    if side == "head":
        labels |= {prefix + mode + "Control" for prefix in controls_to_run for mode in ("Sealed", "Reader")}
    assert labels == set(scope), (side, set(scope), labels)
    for module in modules:
        label = module.rsplit("/", 1)[-1] + "Seal"
        stem = directory / label
        manifest = read(stem.with_suffix(".json"))
        raw = git("show", f"{rev}:{module}.lean")
        assert manifest["source_path"] == module + ".lean"
        assert sha256(raw).hexdigest() == manifest["source_sha256"]
        assert sorted(row["source_line"] for row in manifest["line_map"]) == list(range(1, len(raw.splitlines())+1))
        requests = manifest["requests"]
        count = scope[label]
        assert len(requests) == len({r["spelling"] for r in requests}) == count
        assert sha(stem.with_suffix(".lean")) == manifest["probe_sha256"]
        log = stem.with_suffix(".log").read_text()
        assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
        assert stem.with_suffix(".rc").read_text().strip() == "0", (side, module)
        assert not re.search(r"\.lean:\d+:\d+: error(?:\(|:)", log)
        seals[side][module] = {
            "source_sha256": manifest["source_sha256"], "probe_sha256": manifest["probe_sha256"],
            "log_sha256": sha(stem.with_suffix(".log")), "requests": count, "diagnostics": 0,
        }
        masks[side, module] = {r["spelling"]: r for r in requests}
        warnings[side, module] = re.findall(r"\.lean:\d+:\d+: warning: ([^\n]+)", log)
for new, old in moves.items():
    before, after = masks["base", old], masks["head", new]
    assert after.keys() <= before.keys(), (new, sorted(after.keys() - before.keys()))
    for name, item in after.items():
        prior = before[name]
        assert item["home"] == provider_homes.get(name, prior["home"]), (name, item, prior)
        for field in ("instance", "abbrev", "matcher", "collector_reducibility"):
            assert item[field] == prior[field], (new, name, field)
    assert warnings["base", old] == warnings["head", new], (old, new)

controls = {}
for prefix, name in controls_to_run.items():
    for mode, rc in (("Unsealed", 0), ("Sealed", 1), ("Reader", 0)):
        label = prefix + mode + "Control"
        stem = meta / "head-seals" / label
        assert stem.with_suffix(".rc").read_text().strip() == str(rc), label
        log = stem.with_suffix(".log").read_text()
        source_hash = sha(stem.with_suffix(".lean"))
        if mode != "Unsealed":
            manifest = read(stem.with_suffix(".json"))
            assert source_hash == manifest["probe_sha256"]
            assert [r["spelling"] for r in manifest["requests"]] == [name]
            assert log.count(f"G06-SEAL-END label={label} requested=1 verified=1") == 1
        errors = re.findall(r"\.lean:\d+:\d+: error(?:\([^)]*\))?: ([^\n]+)", log)
        assert len(errors) == rc, (label, errors)
        if rc:
            assert "Tactic `rfl` failed" in errors[0] and name.rsplit(".", 1)[-1] in log[log.index(errors[0]):], label
        controls[label] = {"rc": rc, "log_sha256": sha(stem.with_suffix(".log")), "source_sha256": source_hash}

assert (meta / "Umbrella.rc").read_text().strip() == "0"
umbrella_probe = (meta / "Umbrella.lean").read_text().splitlines()
assert [line for line in umbrella_probe if line.startswith("import ")] == ["import TCSlib.Cryptography.Encryption"]
assert sum(line.startswith("#check ") for line in umbrella_probe) == 8
for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log, (side, log)
    assert "where the seal failed: 0 " in log
candidate_paths = {name + ".lean" for name in source["comment_only_paths"] if "/Candidates/" in name}
source_sizes, campaign_sizes = {}, {}
styles = {}
for side in ("base", "head"):
    style = (area / f"style-{side}.log").read_text()
    expected_count = 8 if side == "base" else 11
    assert f"2 findings in {expected_count} files" in style
    source_sizes[side] = {name: int(length) for name, length in re.findall(
        r"(?m)^([^:\n]+): (\d+) lines \(> 1000, must split\)$", style)}
    assert source_sizes[side].keys() == candidate_paths
    styles[side], campaign_sizes[side] = set(), {}
    for level, path, message in read(area / f"campaign-lint-{side}.json"):
        if level == "INFO":
            continue
        size = re.fullmatch(r"(\d+) lines > 1000: policy requires a split or a recorded justification \(escalation/decision log\)", message)
        if size and path in candidate_paths:
            assert level == "WARN"
            campaign_sizes[side][path] = int(size[1])
        else:
            styles[side].add((level, path, message))
    assert campaign_sizes[side].keys() == candidate_paths
for lengths in (source_sizes, campaign_sizes):
    assert all(lengths["head"][path] == lengths["base"][path] + 6 for path in candidate_paths)
expected_transitive_reports = {
    ("FAIL", move["umbrella"] + ".lean", f"facade does not import child module `{name.replace('/', '.')}`")
    for name in moves
}
assert styles["head"] - styles["base"] == expected_transitive_reports, styles["head"] - styles["base"]
assert set(moves) <= set(plan["order"]) and move["umbrella"] in checks
assert set(moves) <= set(plan["graph"][move["public_key"]])
assert move["public_key"] in plan["graph"][move["umbrella"]]
save(area / "STYLE.json", {
    "existing_candidate_size_reports": source_sizes, "candidate_comment_lines_added": 6,
    "facade_reports_for_verified_transitive_imports": sorted(expected_transitive_reports),
    "new_other_source_findings": 0,
})
archive_dir = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
archive = archive_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (archive_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
assert len(ledger["current_observations"]) == 813 and not ledger["partial"] and not ledger["needs_review"]
providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
             for r in decls["declarations"] if r["kind"] == "def"}
links = []
for row in ledger["current_observations"]:
    refs = {(p["home"], p["spelling"]) for p in row.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in row.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if row["channel"] == "generated-equation":
        refs.add((row["provider_home"], row["provider"]))
    if row["channel"] == "explicit-source":
        refs.add((row["head"]["provider_home"], row["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": row["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": seals,
                          "controls": controls, "new_diagnostics": 0, "warnings": {f"{side}/{module}": value for (side, module), value in warnings.items()},
                          "new_campaign_findings": 0})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                          "ledger_archive_sha256": archive_sha, "relocated_provider_links": links,
                          "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                          "generated_foreign_equation_reads": {"base": 0, "head": 0}})
print("The combined replay and umbrella probe pass. All six owner seals report zero errors.")
print(f"Both seal and reader controls pass. Mapped {len(links)} deferred provider links.")
