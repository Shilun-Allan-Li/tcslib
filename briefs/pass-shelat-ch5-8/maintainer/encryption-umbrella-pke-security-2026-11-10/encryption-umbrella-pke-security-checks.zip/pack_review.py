"""Archive the exact encryption map and public-key security verification and stage the records-only update."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

area, root, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
stage = area / "records"
slug = "encryption-umbrella-pke-security-2026-11-10"
dest = stage / slug
native = area / "native"


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args, cwd=root):
    return subprocess.check_output(["git", *args], cwd=cwd)


pr = read(area / "pr-live.json")
source = read(area / "SOURCE-CHECK.json")
decls = read(area / "DECLARATIONS.json")
seals = read(area / "SEALS.json")
reads = read(area / "READS.json")
plan, result = (read(native / (name + ".json")) for name in ("PLAN", "RESULT"))
base, head = result["base"], result["head"]
assert result["passed"] and result["fresh_native_checks"] == 318
assert result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert seals["passed"] and seals["new_diagnostics"] == 0
assert all(row["base"] == base and row["head"] == head for row in (decls, seals, reads))
assert decls["matched_declarations"] == decls["relocated_declarations"] == 108
assert pr["headRefOid"] == source["head"] == head == git("rev-parse", "HEAD").decode().strip()
assert pr["baseRefName"] == "cryptography/pass-shelat-ch2-4"
assert pr["headRefName"] == "codex/pass-shelat-encryption-umbrella-pke-security"
assert pr["state"] == "OPEN" and not pr["isDraft"]
assert pr["mergeStateStatus"] == "CLEAN" and pr["mergeable"] == "MERGEABLE"
assert set(row["path"] for row in pr["files"]) == {name + ".lean" for name in source["changed_paths"]}
assert git("rev-parse", "HEAD", cwd=campaign).decode().strip() == base
assert git("rev-parse", base + "~2^2").decode().strip() == source["baseline"]
assert not git("status", "--porcelain", cwd=campaign)

paths = {
    "base.txt", "head.txt", "predecessor.txt", "encryption-umbrella-pke-security.patch", "BASE-IMPORTS.json", "STYLE.json",
    "prepare_replay.py", "prepare_metadata.py", "prepare_seals.py", "run_probes.sh",
    "pack_review.py", "compare_declarations.py", "scan_relocation.py", "check_evidence.py", "lint.py",
    "style-head.log", "style-base.log", "campaign-lint-base.json", "campaign-lint-head.json",
    "MOVE-SCOPE.json", "SOURCE-CHECK.json", "DECLARATIONS.json", "SEALS.json", "READS.json",
    "pr-body.md", "pr-live.json", "native/PLAN.json", "native/PRODUCTS.json", "native/RESULT.json",
}
for pattern in ("native/run-*/*", "metadata/*", "metadata/*-seals/*", "metadata/base/*.json",
                "metadata/base/run-*/*", "read-scan/**/*"):
    paths.update(path.relative_to(area).as_posix() for path in area.glob(pattern) if path.is_file())
dest.mkdir(parents=True)
archive = dest / "encryption-umbrella-pke-security-checks.zip"
snapshots = {}
with ZipFile(archive, "x", ZIP_DEFLATED) as packed:
    for name in sorted(paths):
        packed.write(area / name, name)
    for side, revision in (("base", base), ("head", head)):
        for module in source["changed_paths"]:
            if side == "base" and module in source["new_owners"]:
                continue
            filename = module + ".lean"
            name = f"source/{side}/{filename}"
            raw = git("show", f"{revision}:{filename}")
            snapshots[name] = sha256(raw).hexdigest()
            packed.writestr(name, raw)
hashes = {name: sha(area / name) for name in sorted(paths)}
with ZipFile(archive) as packed:
    assert set(packed.namelist()) == hashes.keys() | snapshots.keys()
    for name, expected in (hashes | snapshots).items():
        with packed.open(name) as stream:
            assert file_digest(stream, "sha256").hexdigest() == expected, name
receipt = {
    "base": base, "head": head, "passed": True, "pr": pr,
    "affected_modules": len(plan["affected"]), "fresh_native_checks": result["fresh_native_checks"],
    "verified_unchanged_transfers": result["initial_retained"], "verified_external_objects": len(plan["external"]),
    "matched_declarations": decls["matched_declarations"], "relocated_declarations": decls["relocated_declarations"],
    "seal_receipts": seals["receipts"], "new_seal_diagnostics": seals["new_diagnostics"],
    "retarget_affected_modules": source["retarget_affected_modules"],
    "baseline_owner_checks": read(area / "metadata/base/RESULT.json")["fresh_native_checks"],
    "umbrella_probe_sha256": sha(area / "metadata/Umbrella.log"),
    "admission_dependencies": decls["admission_dependencies"],
    "relocated_provider_links": len(reads["relocated_provider_links"]),
    "artifact_sha256": hashes, "snapshot_sha256": snapshots,
    "archive": {"name": archive.name, "sha256": sha(archive)},
}
(dest / "VERIFICATION.json").write_text(json.dumps(receipt, indent=2) + "\n")
(dest / "READS.json").write_bytes((area / "READS.json").read_bytes())
number, url = pr["number"], pr["url"]
(dest / "README.md").write_text(f"""# Encryption map and public-key security relocation

[PR #{number}]({url}) at `{head}` updates the encryption umbrella and links
from the RSA and Rabin documentation to the shared public-key route. It
moves the trapdoor CPA corollary to `Encryption.PublicKey.TrapdoorCPA`
and the two non-malleability formulations to
`Encryption.PublicKey.NonMalleability.Indistinguishability` and
`Encryption.PublicKey.NonMalleability.Simulation`. The three original
`Composability` imports preserve their transitive exports. The moved
declarations and proof text are verbatim, and the RSA and Rabin edits
are comment-only.

The base `{base}` includes the lattice integration in PR #280.
The replay verifies 855 unchanged objects from the checked signature and
hashing head `{source['baseline']}` and runs 318 fresh checks on the
combined source, including all 14 layout-affected modules, the library
root and campaign Checks. The original three owner files were compiled
on the exact base with identical dependency objects.

- All 108 declaration types, definition values, references and axiom sets
  match, with six compiler-private matcher helpers tracked to their new
  owner. The legacy and standalone import probes agree. The umbrella
  probe reaches both private-key routes, the public-key Regev route
  and the relocated security results.
- All six whole-file seals and both reader controls pass. The explicit
  and generated scans found zero foreign definition reads in the moved
  files.
- The existing RSA and Rabin size findings account for the six new comment
  lines in each file. The umbrella linter reports three leaf imports
  that the verified public-key facade supplies transitively. The actual
  umbrella import probe verifies that reachability.

The CPA corollary depends on the admitted `SingleBitSecure.padded_cpa`
bridge. The non-malleability modules retain three direct admissions,
and the simulation-based CPA equivalence uses two of them. All five
declaration dependencies are listed in `DECLARATIONS.json` in the archive.

The cleanup ledger was compared against the relocated providers.
[Ledger comparison](READS.json)

`{archive.name}` has SHA-256 `{receipt['archive']['sha256']}`.
[Verification hashes](VERIFICATION.json)

**Clear to merge — the combined replay, public import probes and six seals pass.**
""")

briefs = campaign / "briefs/pass-shelat-ch5-8"
updates = {}
handoff = briefs / "MAINTAINER-HANDOFF.md"
original = handoff.read_text()
anchor = "[Signature and hashing verification](maintainer/authentication-signatures-hashing-2026-11-09/README.md)."
assert original.count(anchor) == 1
updates[handoff] = original.replace(anchor, anchor + " " + (
    f"[PR #{number}]({url}) at `{head}` covers the encryption umbrella, RSA and Rabin backlinks, "
    "and the trapdoor CPA and both public-key non-malleability relocations in one review. The #280 "
    "combined source passes 318 fresh checks, including all 14 affected modules and campaign Checks. "
    "The census matches all 108 declarations, the three import probes agree with their expected exports, "
    f"and six seals pass. It is clear for Seyoon to merge. [Encryption verification](maintainer/{slug}/README.md)."
))
decision = campaign / "PassShelatChapter5-8Plan.md"
original = decision.read_text()
assert original.rstrip().splitlines()[-1].startswith("| 2026-11-10 (PST) | **#279 merge verified.**")
updates[decision] = original.rstrip() + "\n" + (
    f"| 2026-11-10 (PST) | **Encryption umbrella and public-key security moves verified.** [PR #{number}]({url}) "
    f"at `{head}` adds the private-key entry and RSA/Rabin backlinks, and moves the trapdoor CPA corollary "
    "and both non-malleability formulations. All 318 combined-source checks and six seals pass, "
    f"and the census matches all 108 declarations. [Verification](briefs/pass-shelat-ch5-8/maintainer/{slug}/README.md). "
    "Seyoon merges this slice. | record |\n"
)
cleanup = briefs / "CLEANUP-PLAN.md"
original = cleanup.read_text()
anchor = "### Authentication and hashing"
assert original.count(anchor) == 1 and "### Encryption umbrella and public-key security" not in original
updates[cleanup] = original.replace(anchor, f"""### Encryption umbrella and public-key security

[PR #{number}]({url}) indexes the Pass–shelat and Regev private-key routes
and the public-key constructions in `Encryption.lean`. The RSA and Rabin
candidate documentation links to the shared trapdoor construction. The
CPA corollary lives in `PublicKey/TrapdoorCPA`, and the two non-malleability
formulations live in `PublicKey/NonMalleability`. The old imports supply
the previous exports.
[Verification](maintainer/{slug}/README.md)

{anchor}""")
preimages = {}
for src, new in updates.items():
    rel = src.relative_to(campaign)
    preimages[rel.as_posix()] = sha(src)
    target = stage / "updates" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(new)
(stage / "PREIMAGES.json").write_text(json.dumps(preimages, indent=2) + "\n")
print(f"Packed {len(hashes) + len(snapshots)} verified members for PR #{number}.")
