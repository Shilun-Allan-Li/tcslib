import TCSlib.Cryptography.Authentication.PRFMAC

#check @TCSlib.Cryptography.Authentication.prfTagFun
#check @TCSlib.Cryptography.Authentication.prfTagFun_eq
#check @TCSlib.Cryptography.Authentication.prfVerFun
#check @TCSlib.Cryptography.Authentication.prfVerFun_eq
#check @TCSlib.Cryptography.Authentication.polyTimeComputable_prfTagFun
#check @TCSlib.Cryptography.Authentication.polyTimeComputable_prfVerFun
#check @TCSlib.Cryptography.Authentication.prfMAC
#check @TCSlib.Cryptography.Authentication.prfMAC_msgLen
#check @TCSlib.Cryptography.Authentication.prfMAC_tagLen
#check @TCSlib.Cryptography.Authentication.prfMAC_gen
#check @TCSlib.Cryptography.Authentication.prfMAC_tag
#check @TCSlib.Cryptography.Authentication.prfMAC_ver
#check @TCSlib.Cryptography.Authentication.prfMAC_secure
