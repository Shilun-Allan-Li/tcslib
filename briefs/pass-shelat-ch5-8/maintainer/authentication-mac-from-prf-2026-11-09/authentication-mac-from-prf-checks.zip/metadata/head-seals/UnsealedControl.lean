import TCSlib.Cryptography.Authentication.MAC.FromPRF

open Complexity Turing TCSlib.Cryptography.Authentication

variable (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (F n s x))

example : (prfMAC F E hE hFE).msgLen = .var := by
  rfl
