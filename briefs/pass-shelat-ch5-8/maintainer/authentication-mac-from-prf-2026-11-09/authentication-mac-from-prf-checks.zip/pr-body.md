## Summary

- Move the PRF-based MAC, its correctness proof and its security statement verbatim to `Authentication.MAC.FromPRF`.
- Use the MAC and PRF contracts directly in the standalone module and reuse `runAt_coinKey` for correctness.
- Keep `Authentication.PRFMAC` as a compatibility import. The authentication facade retains it for its existing transitive exports.

## Verification

- All four affected modules and the campaign Checks aggregate pass.
- The legacy and standalone imports agree. The comparison matches all 17 declaration types, definition values, elaborated references and axiom sets.
- Both whole-file seals, the message-length reader control, the explicit and generated read scans, and both style lints pass.

The existing `prfMAC_secure` proof is admitted.
