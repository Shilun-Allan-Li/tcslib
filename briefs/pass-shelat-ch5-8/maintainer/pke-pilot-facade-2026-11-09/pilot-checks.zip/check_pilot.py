"""Check the facade and route references against the verified #248 import products."""
from functools import cache
from hashlib import file_digest
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

workspace = Path.cwd()
area, worktree, verified = (Path(p).resolve() for p in sys.argv[1:4])
tree = area / 'retained-tree/oleans'
root_module = 'TCSlib'
facade_module = 'TCSlib/Cryptography/Encryption/PublicKey'
checks_module = 'audits/pass-shelat/Checks'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=worktree, text=True).strip()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def resource_floor():
    assert shutil.disk_usage(tree).free >= 12 * 1024 ** 3
    memory = subprocess.check_output(['/usr/bin/memory_pressure', '-Q'], text=True)
    total = int(re.search(r'system has (\d+)', memory)[1])
    free = int(re.search(r'memory free percentage:\s*(\d+)%', memory)[1])
    assert total * (free - 1) // 100 >= 4 * 1024 ** 3
    return free


base = (area / 'base.txt').read_text().strip()
head = (area / 'head.txt').read_text().strip()
assert git('rev-parse', 'HEAD') == head
assert git('merge-base', base, head) == base and not git('status', '--porcelain')
assert git('diff', '--name-status', base, head).splitlines() == [
    'M\tTCSlib.lean', 'A\t' + facade_module + '.lean',
]
baseline = json.loads((verified / 'RESULT.json').read_bytes())
plan = json.loads((verified / 'PLAN.json').read_bytes())
products_file = verified / 'PRODUCTS.json'
products = json.loads(products_file.read_bytes())
assert baseline['passed'] and baseline['head'] == plan['head']
assert digest(products_file) == baseline['products_sha256'] == digest(area / 'retained-tree/PRODUCTS.json')
assert not git('diff', '--name-only', plan['head'], base, '--', '*.lean', 'lean-toolchain',
               'lake-manifest.json', 'lakefile.lean', 'scripts/lean_check_tree.sh')
assert len(products) == 1075
for name, record in products.items():
    if name != root_module:
        assert digest(worktree / (name + '.lean')) == record['source_sha256'], name

root = (worktree / 'TCSlib.lean').read_bytes()
old_root = subprocess.check_output(['git', 'show', base + ':TCSlib.lean'], cwd=worktree)
export = b'import TCSlib.Cryptography.Encryption.PublicKey\n'
assert root.count(export) == 1 and root.replace(export, b'') == old_root
facade = (worktree / (facade_module + '.lean')).read_text()
commands = [line.strip() for line in re.sub(r'/-.*?-/', '', facade, flags=re.S).splitlines() if line.strip()]
imported = [line.removeprefix('import ') for line in commands if line.startswith('import ')]
assert len(imported) == 5 and len(set(imported)) == len(imported)
assert commands == ['import ' + name for name in imported] + [
    'set_option maxHeartbeats 0', 'set_option relaxedAutoImplicit false', 'set_option autoImplicit false',
]
graph = plan['graph']


@cache
def closure(module):
    return set(graph[module]).union(*(closure(dep) for dep in graph[module]))


assert all(module.replace('.', '/') in closure(root_module) for module in imported)
references = sorted(set(re.findall(r'`(TCSlib\.[\w.]+)`', facade)))
assert len(references) >= 15
probe = area / 'inputs/RouteProbe.lean'
with probe.open('x') as stream:
    stream.write(export.decode())
    stream.write(''.join(f'#check {name}\n' for name in references))

for directory in (workspace, worktree):
    assert not (directory / '.lake/build/lib/lean').exists()
    assert digest(directory / 'scripts/lean_check_tree.sh') == plan['checker_sha256']
assert digest(Path(plan['toolchain'])) == plan['toolchain_sha256']
env = os.environ.copy()
for key in ('LEAN_PATH', 'LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LEAN_OPTS', 'ELAN_TOOLCHAIN', 'PFR_BOOTSTRAP_CONFIG'):
    env.pop(key, None)
env['PATH'] = str(Path(plan['toolchain']).parent) + ':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['TCSLIB_OLEANS'] = str(tree)
outputs = []
logs = area / 'native-checks'
logs.mkdir()
with (tree / '.pke-pilot.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for label, directory, module in (
        ('facade', worktree, facade_module),
        ('routes', workspace, probe.relative_to(workspace).with_suffix('').as_posix()),
        ('root', worktree, root_module),
        ('checks', worktree, checks_module),
    ):
        free = resource_floor()
        log = logs / (label + '.log')
        with log.open('xb') as stream:
            checked = subprocess.run(['bash', 'scripts/lean_check_tree.sh', module], cwd=directory,
                                     env=env, stdout=stream, stderr=subprocess.STDOUT)
        if checked.returncode:
            print(log.read_text()[-6000:], flush=True)
            raise SystemExit(checked.returncode)
        source = directory / (module + '.lean')
        obj = tree / (module + '.olean')
        outputs.append({'label': label, 'module': module, 'rc': checked.returncode,
                        'source_sha256': digest(source), 'object_sha256': digest(obj),
                        'log_sha256': digest(log), 'memory_free_percent_before': free})
        print('PASS', label, module, flush=True)
assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
save(area / 'VERIFICATION.json', {
    'base': base, 'head': head, 'verified_cleanup_head': plan['head'],
    'verified_cleanup_products_sha256': baseline['products_sha256'],
    'unchanged_source_bindings_checked': len(products) - 1,
    'external_products': len(plan['external']),
    'toolchain_sha256': plan['toolchain_sha256'], 'checker_sha256': plan['checker_sha256'],
    'facade_imports': imported, 'all_imports_in_old_root_closure': True,
    'new_root_import': facade_module.replace('/', '.'), 'new_declarations': 0,
    'checked_route_references': references, 'checks': outputs, 'passed': True,
})
