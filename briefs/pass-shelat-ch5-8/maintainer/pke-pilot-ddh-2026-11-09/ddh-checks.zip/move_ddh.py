"""Extract the safe-prime group facts and reusable DDH experiments."""
from pathlib import Path
import sys

crypto=Path(sys.argv[1])/'TCSlib/Cryptography'
elgamal=crypto/'Candidates/ElGamal.lean'
ddh=crypto/'Candidates/DDH.lean'
candidates=crypto/'Candidates.lean'
pke=crypto/'Encryption/PublicKey.lean'
old=elgamal.read_text()
namespace='namespace TCSlib.Cryptography.Candidates\n'
opening='/-! ## The group `G_q` of a safe prime'
next_section='/-! ## Public-key schemes with a key-dependent message space -/'
assert old.count(next_section)==1
start=old.index(namespace)
begin=old.index(opening)
cut=old.index(next_section)
assert start<begin<cut
header=old[:old.index('/-!\n#')]
scope=old[start:begin]
ref=old[old.index('## References\n'):start].rstrip()
ddh_doc=f'''/-!
# Decisional Diffie–Hellman for safe primes

The experiments use the order-`q` subgroup of `Z_p^*` for a safe prime
`p = 2q + 1` [PS10, Assumption 105.1 and p. 106]. The seed is the instance
generator's coin string together with two or three independent
`n · n`-bit blocks. Rejection sampling reads the exponent from each block.
The real and random experiments therefore have the same instance law.
Their tuple encoding has length `15n + 14` at a well-formed instance.

## Main definitions

* `TCSlib.Cryptography.Candidates.ddhTuple` encodes the instance and three powers.
* `TCSlib.Cryptography.Candidates.ddhExpo` reads an exponent from a block of coins.
* `TCSlib.Cryptography.Candidates.ddhReal` and `ddhRandom` give the real and random
  ensembles. `TCSlib.Cryptography.Candidates.DDHAssumption` asserts their
  computational indistinguishability.

## Main results

* `TCSlib.Cryptography.Candidates.card_QR_safe` and `zpowers_eq_QR` give the
  order and generators of the subgroup of squares.
* `TCSlib.Cryptography.Candidates.statClose_sq_generator` bounds the difference
  between sampling a square and sampling a generator.
* `TCSlib.Cryptography.Candidates.ddhExpo_statClose` bounds the distance from
  the exponent sampler to the uniform law.
* `ddhReal_σ`, `ddhRandom_σ`, `ddhReal_X` and `ddhRandom_X` expose the seed
  types and sample formulas.

{ref}

'''
readers="""/-- The DDH tuple is the instance paired with the three encoded powers. -/
theorem ddhTuple_eq (i : List Bool) (a b c : ZMod (expOrd i)) :
    ddhTuple i a b c = pairEncode i (pairEncode (expF i a) (pairEncode (expF i b) (expF i c))) := rfl

/-- The DDH exponent is the rejection sampler's result, with fallback zero, cast to the
exponent group. -/
theorem ddhExpo_eq (n : ℕ) (i : List Bool) (b : Fin (n * n) → Bool) :
    ddhExpo n i b =
      (((sampleBelowL (expOrd i) (Nat.size (expOrd i)) n n (List.ofFn b)).getD 0 : ℕ) :
        ZMod (expOrd i)) := rfl

/-- The real experiment uses the generator's coins and two independent exponent blocks. -/
theorem ddhReal_σ (G : SafePrimeGen) (n : ℕ) :
    (ddhReal G).σ n = (G.gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool))) := rfl

/-- The random experiment uses the generator's coins and three independent exponent blocks. -/
theorem ddhRandom_σ (G : SafePrimeGen) (n : ℕ) :
    (ddhRandom G).σ n =
      (G.gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool) × (Fin (n * n) → Bool))) := rfl

/-- The real sample uses the product of the two sampled exponents in its third power. -/
theorem ddhReal_X (G : SafePrimeGen) (n : ℕ)
    (z : G.gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool))) :
    (ddhReal G).X n (cast (ddhReal_σ G n).symm z) =
      padFin (ddhLen.eval n) (ddhTuple (G.gen.runAt n [] z.1)
        (ddhExpo n (G.gen.runAt n [] z.1) z.2.1) (ddhExpo n (G.gen.runAt n [] z.1) z.2.2)
        (ddhExpo n (G.gen.runAt n [] z.1) z.2.1 * ddhExpo n (G.gen.runAt n [] z.1) z.2.2)) := rfl

/-- The random sample uses an independent third sampled exponent. -/
theorem ddhRandom_X (G : SafePrimeGen) (n : ℕ)
    (z : G.gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool) × (Fin (n * n) → Bool))) :
    (ddhRandom G).X n (cast (ddhRandom_σ G n).symm z) =
      padFin (ddhLen.eval n) (ddhTuple (G.gen.runAt n [] z.1)
        (ddhExpo n (G.gen.runAt n [] z.1) z.2.1) (ddhExpo n (G.gen.runAt n [] z.1) z.2.2.1)
        (ddhExpo n (G.gen.runAt n [] z.1) z.2.2.2)) := rfl
"""
ddh.write_text(header+ddh_doc+scope+old[begin:cut]+readers+'\nend TCSlib.Cryptography.Candidates\n')

def replace_once(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after,1)

legacy=old[:begin]+old[cut:]
old_imports=old[old.index('import '):old.index('set_option')]
legacy=replace_once(legacy,old_imports,'import TCSlib.Cryptography.Candidates.DDH\n\n')
legacy=replace_once(legacy,'# The DDH assumption and El Gamal encryption','# El Gamal encryption')
legacy=replace_once(legacy,
'''* `TCSlib.Cryptography.Candidates.ddhTuple`, `ddhLen`, `ddhExpo`, `ddhReal`, `ddhRandom`,
  `TCSlib.Cryptography.Candidates.DDHAssumption` — [PS10, Assumption 105.1].
''','')
legacy=replace_once(legacy,
'''* `TCSlib.Cryptography.Candidates.card_QR_safe`, `mem_QR_iff_pow_eq_one`,
  `orderOf_eq_of_mem_QR`, `zpowers_eq_QR`, `eq_QR_of_card`, `card_sqrt_safe`,
  `pushesUniform_sqTo_safe` — the group facts of p. 106 (NT-105.a, proved).
* `TCSlib.Cryptography.Candidates.uprob_sq_eq_one`, `statClose_of_uprob_ne`,
  `statClose_sq_generator` — the generator-versus-square term `1/q` (Claim-107.a).
* `TCSlib.Cryptography.Candidates.ddhExpo_statClose` — the DDH exponents are within `(1/2)^n`
  of uniform at a generated instance (D10).
''','')
legacy=replace_once(legacy,
'''proof as an exercise"].

**Instances and the two generators.**''','''proof as an exercise"]. The group facts and assumption live in
`TCSlib.Cryptography.Candidates.DDH`.

**Instances and the two generators.**''')
elgamal.write_text(legacy)
text=replace_once(candidates.read_text(),'import TCSlib.Cryptography.Candidates.ElGamal\n',
    'import TCSlib.Cryptography.Candidates.DDH\nimport TCSlib.Cryptography.Candidates.ElGamal\n')
text=replace_once(text,
'''* `ElGamal` — the DDH assumption and El Gamal encryption [PS10, Assumption 105.1,
  Algorithm 106.2, Theorem 107.3].
''',
'''* `DDH` gives the safe-prime group facts and decisional Diffie–Hellman experiments
  [PS10, Assumption 105.1].
* `ElGamal` gives El Gamal encryption and its security theorem [PS10, Algorithm 106.2,
  Theorem 107.3].
''')
candidates.write_text(text)
text=replace_once(pke.read_text(),'import TCSlib.Cryptography.Candidates.ElGamal\n',
    'import TCSlib.Cryptography.Candidates.DDH\nimport TCSlib.Cryptography.Candidates.ElGamal\n')
text=replace_once(text,'* `Candidates.ElGamal` gives the group-message scheme',
    '* `Candidates.DDH` defines the reusable safe-prime DDH assumption.\n'
    '* `Candidates.ElGamal` gives the group-message scheme')
pke.write_text(text)
