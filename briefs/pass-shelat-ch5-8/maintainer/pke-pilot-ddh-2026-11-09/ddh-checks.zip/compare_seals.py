"""Check the exact DDH seal delta and keep the earlier explicit-read ledger."""
from collections import Counter
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile

area,cleanup,campaign=(Path(p).resolve() for p in sys.argv[1:4])
records=campaign/'briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1'


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


plan=read(area/'native/PLAN.json')
source=read(area/'SOURCE-CHECK.json')
decl=read(area/'DECLARATIONS.json')
assert all(r['base']==plan['base'] and r['head']==plan['head'] for r in (source,decl))
legacy='TCSlib.Cryptography.Candidates.ElGamal'
ddh='TCSlib.Cryptography.Candidates.DDH'
legacy_path=legacy.replace('.','/')+'.lean'
ddh_path=ddh.replace('.','/')+'.lean'
older='seals-head-effective-final-r1.json'
old_scan='head-read-scan-final-r1/scan.log'
ledger='deferred-read-ledger-final-r1.json'
baseline=next(r for r in read(cleanup/older)['outcomes'] if r['owner']==legacy)
assert baseline['valid_harness'] and baseline['rc']==0 and not baseline['errors']
assert baseline['source_sha256']==source['source_sha256']['base:'+legacy_path]
old_mask_rel='seals-head-final-r1/'+baseline['label']+'.json'
raw_log=Path(baseline['log']).relative_to(cleanup).as_posix()
pins={p:h for h,p in (line.split(maxsplit=1) for line in (records/'SHA256SUMS').read_text().splitlines())}
for archive,files in (('10-final-seals.zip',(older,old_mask_rel,raw_log)),('11-final-read-ledger.zip',(old_scan,ledger))):
    assert sha(records/archive)==pins[archive]
    with ZipFile(records/archive) as backup:
        for file in files:
            assert sha(cleanup/file)==sha256(backup.read(file)).hexdigest(),file
assert sha(cleanup/old_mask_rel)==baseline['meta_sha256'] and sha(cleanup/raw_log)==baseline['log_sha256']
full=read(area/'SEALS.json')
out={r['owner']:r for r in full['outcomes']}
assert set(out)=={ddh,legacy} and full['source_errors']==0
assert all(r['valid_harness'] and r['rc']==0 and not r['errors'] for r in out.values())


def mask(folder,row):
    file=folder/(row['label']+'.json')
    assert sha(file)==row['meta_sha256'] and sha(Path(row['log']))==row['log_sha256']
    data=read(file)
    return {r['spelling']:r for r in data['requested']}


previous={r['spelling']:r for r in read(cleanup/old_mask_rel)['requested']}
ddh_mask=mask(area/'seals',out[ddh])
elgamal_mask=mask(area/'seals',out[legacy])
assert ddh_mask==previous
new_mask={k:v for k,v in elgamal_mask.items() if v['home']==ddh}
assert not new_mask.keys()&previous.keys()
assert elgamal_mask=={**previous,**new_mask},(elgamal_mask.keys()-previous.keys()-new_mask.keys(),
                                             previous.keys()-elgamal_mask.keys())
assert {'ddhLen','ddhTuple','ddhExpo','ddhReal','ddhRandom','DDHAssumption'}<={k.rsplit('.',1)[-1] for k in new_mask}
ledger_only='--ledger-only' in sys.argv
focused=None if ledger_only else read(area/'SEALS-MOVED.json')
if focused is not None:
    r,=focused['outcomes']
    assert r['valid_harness'] and r['rc']==0 and not r['errors']
    assert r['path']=='audits/pass-shelat/Checks.lean' and mask(area/'seals-moved',r)==new_mask


def explicit(path,paths):
    c1,c2,c3=re.split(r'(?m)^## \(c[23]\)[^\n]*\n',path.read_text())
    assert not any(line.startswith(p+':') or line.startswith(p[:-5].replace('/','.')+'\t')
                   for section in (c2,c3) for line in section.splitlines() for p in paths)
    rows={}
    for line in c1.splitlines():
        if not any(line.startswith(p+':') for p in paths):
            continue
        site,*fields=line.split('\t')
        assert len(fields)==7,line
        key=tuple(fields)
        assert key not in rows,key
        rows[key]=site
    return rows


a=explicit(cleanup/old_scan,{legacy_path})
b=explicit(area/'read-scan/scan.log',{legacy_path,ddh_path})
assert a.keys()==b.keys() and len(a)==4,(a.keys()-b.keys(),b.keys()-a.keys())
rows=[r for r in read(cleanup/ledger)['current_observations'] if r['path']==legacy_path]
assert len(rows)==4 and all(r['channel']=='explicit-source' for r in rows)
carry=[]
for r in rows:
    # The historical ledger stores the exact seven scanner columns.
    h=r['head']
    key=(*[h[k] for k in ('tactic','item','kind','provider','provider_home','scanner_owner')],h['source'].strip())
    assert a[key]==f'{legacy_path}:{h["line"]}'
    current_path,line=b[key].rsplit(':',1)
    assert (area/'lint/head'/current_path).read_text().splitlines()[int(line)-1]==h['source']
    carry.append({'id':r['id'],'baseline_site':a[key],'current_site':b[key],'scan_fields':key,'baseline':r})
assert len({r['current_site'] for r in carry})==4
plain=(area/'style-final.log').read_text()
assert '1 findings in 4 files' in plain and '(> 1000, must split)' in plain
assert 'style_lint: 0 FAIL' in (area/'style-campaign-head.log').read_text()


def warning_names(path):
    names=[]
    for l in path.read_text().splitlines():
        m=re.search(r'lemma beside them \(check 8\): (.*)',l)
        if m:
            names.extend(m[1].split(', '))
    return Counter(names)


assert not warning_names(area/'style-campaign-head.log')-warning_names(area/'style-campaign-base.log')
if ledger_only:
    print('Two clean seals;',len(new_mask),'DDH requests;',len(carry),'matched inherited explicit reads')
    sys.exit(0)
out={'base':plan['base'],'head':plan['head'],'passed':True,'whole_file_seals':len(full['outcomes']),
     'requests':full['outcomes'][0]['requested']+full['outcomes'][1]['requested'],
     'focused_seals':len(focused['outcomes']),'ddh_definition_requests':list(new_mask.values()),
     'source_errors':0,'inherited_explicit_reads':carry,'new_reads':0,'predecessor_ledger_sha256':sha(cleanup/ledger)}
with (area/'READS.json').open('x') as f:
    json.dump(out,f,ensure_ascii=False,indent=2)
    f.write('\n')
print('Two clean seals and a clean focused Checks seal;',len(carry),'matched explicit reads')
