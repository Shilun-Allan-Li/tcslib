"""Verify public types, original definitions, and the scoped private seed transports."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys
from zipfile import ZipFile

sys.setrecursionlimit(30000)
area,prior,cleanup,campaign=(Path(p).resolve() for p in sys.argv[1:5])
native=area/'native'


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def identity(name):
    return tuple(map(tuple,name['components']))


plan=read(native/'PLAN.json')
result=read(native/'RESULT.json')
before_plan=read(prior/'native-final/PLAN.json')
before_products=read(prior/'native-final/PRODUCTS.json')
after_products=read(native/'PRODUCTS.json')
assert result['passed'] and result['head']==plan['head'] and result['base']==plan['base']
assert result['plan_sha256']==sha(native/'PLAN.json') and result['products_sha256']==sha(native/'PRODUCTS.json')
assert plan['baseline']==before_plan['head']
assert all(plan[k]==before_plan[k] for k in ('toolchain_sha256','checker_sha256'))
assert {k:r['sha256'] for k,r in plan['external'].items()}=={k:r['sha256'] for k,r in before_plan['external'].items()}
old_plan=read(cleanup/'native-r3/PLAN.json')
old_products=read(cleanup/'native-r3/PRODUCTS.json')
records=campaign/'briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1'
assert old_plan['head']==read(records/'STATUS.json')['head']
assert all(old_plan[k]==plan[k] for k in ('toolchain_sha256','checker_sha256'))
assert {k:r['sha256'] for k,r in old_plan['external'].items()}=={k:r['sha256'] for k,r in plan['external'].items()}
pins={p:h for h,p in (s.split(maxsplit=1) for s in (records/'SHA256SUMS').read_text().splitlines())}
raw='census-final-r1/Head.jsonl'
compact='census-final-r1/Head-compact.json'
old_c3='census-final-r1/FinalPins.XxHvTdlw/HeadC3.log'
old_inputs={}
for archive,names in (('08-final-census.zip',(raw,compact,old_c3)),
                      ('07-final-native-source.zip',('native-r3/PLAN.json','native-r3/PRODUCTS.json'))):
    assert sha(records/archive)==pins[archive]
    with ZipFile(records/archive) as backup:
        for rel in names:
            with backup.open(rel) as f:
                h=file_digest(f,'sha256').hexdigest()
            assert sha(cleanup/rel)==h
            old_inputs[rel]=h

prefix='TCSlib.Cryptography.Candidates.'
legacy=prefix+'ElGamal'
ddh=prefix+'DDH'
pending=[legacy.replace('.','/')]
context=set()
while pending:
    m=pending.pop()
    if m not in context:
        context.add(m)
        assert old_plan['graph'][m]==before_plan['graph'][m]
        assert all(old_products[m][k]==before_products[m][k] for k in ('source_sha256','object_sha256','direct_local'))
        assert sha(Path(before_plan['tree'])/(m+'.olean'))==before_products[m]['object_sha256']
        pending.extend(before_plan['graph'][m])
source=read(area/'SOURCE-CHECK.json')
legacy_path=legacy.replace('.','/')+'.lean'
assert source['base']==plan['base'] and source['head']==plan['head']
assert source['source_sha256']['base:'+legacy_path]==old_plan['source_digests'][legacy_path[:-5]]
a=read(cleanup/compact)
b=read(area/'metadata/Head-compact.json')
old={identity(r['name']):r for r in a['roots'] if r['home']==legacy}
new={identity(r['name']):r for r in b['roots']}
assert len(old)==220 and len(new)==len(b['roots'])==len(old)+6
assert {r['display'] for r in b['owners']}=={legacy,ddh}
old_private=tuple(('str',p) for p in ('_private.'+legacy).split('.'))
new_private=tuple(('str',p) for p in ('_private.'+ddh).split('.'))
pairs={}
for key,row in old.items():
    if key in new:
        pairs[key]=key
    else:
        assert key[:len(old_private)]==old_private and key[len(old_private)][0]=='num',row['name']
        pairs[key]=new_private+key[len(old_private):]
assert len(set(pairs.values()))==len(old)
assert set(pairs.values())<=new.keys()
extras=[new[k] for k in new.keys()-pairs.values()]
assert {r['name']['display'] for r in extras}=={prefix+n for n in source['readers']}
assert all(r['home']==ddh and r['kind']=='theorem' and 'sorryAx' not in r['axioms'] for r in extras)
assert {a for r in extras for a in r['axioms']}<={a for r in old.values() for a in r['axioms']}

renames={old[k]['name']['display']:new[v]['name']['display'] for k,v in pairs.items() if k!=v}
private_proofs={'.'+prefix+n for n in source['private_changes']}
changed_types={'.'+prefix+n for n in ('dlc_hyb1_point','dlc_rand_accept','dlc_hyb3_point')}
seed_readers={prefix+n for n in ('ddhReal_σ','ddhRandom_σ')}
type_transport_refs={'Eq','Eq.symm','cast','TCSlib.Cryptography.Ensemble.σ'}|seed_readers
moves=[]
terms={}
ref_changes=[]
for k,v in pairs.items():
    x,y=old[k],new[v]
    display=y['name']['display']
    assert all(x[f]==y[f] for f in ('kind','universes','axioms')),display
    if x['home']!=y['home']:
        assert (x['home'],y['home'])==(legacy,ddh)
        moves.append({'base_name':x['name'],'head_name':y['name'],'base_home':legacy,'head_home':ddh})
    for field in ('type_refs','value_refs'):
        before={renames.get(ref,ref) for ref in x[field]}
        after=set(y[field])
        if before==after:
            continue
        if field=='type_refs':
            assert display.endswith(tuple(changed_types)) and before<=after and after-before<=type_transport_refs,(display,after-before)
        else:
            assert display.endswith(tuple(private_proofs)),(display,before-after,after-before)
        ref_changes.append({'name':display,'field':field,'added':sorted(after-before),'removed':sorted(before-after)})
    fields=[f for f,h in (('type','type_sha256'),('definition_value','definition_sha256')) if x[h]!=y[h]]
    if fields:
        terms[k]=fields


def extract(path,roots,selected):
    terms,catalog={},{}
    with path.open() as f:
        for r in map(json.loads,f):
            if r['record'] not in ('root','catalog'):
                continue
            k=identity(r['name'])
            if r['record']=='root' and k in selected:
                terms[k]=r
            if r['record']=='catalog' and k in roots:
                catalog[k]={f:r[f] for f in ('kind','status','abbrev','instance','matcher')}
    assert terms.keys()==selected and catalog.keys()==roots
    return terms,catalog


a_raw,a_catalog=extract(cleanup/raw,old.keys(),terms.keys())
b_raw,b_catalog=extract(area/'metadata/Head.jsonl',new.keys(),{pairs[k] for k in terms})
assert all(a_catalog[k]==b_catalog[v] for k,v in pairs.items())


def app_spine(expr):
    args=[]
    while isinstance(expr,list) and expr and expr[0]=='app':
        args.append(expr[2])
        expr=expr[1]
    return expr,list(reversed(args))


def head_name(expr):
    return expr[1]['display'] if isinstance(expr,list) and expr and expr[0]=='const' else None


def canonical(expr,mapping,casts,found,path=()):
    if not isinstance(expr,list) or not expr:
        return expr
    if casts and expr[0]=='app':
        head,args=app_spine(expr)
        if head_name(head)=='cast' and len(args)==4:
            proof,pargs=app_spine(args[2])
            if head_name(proof)=='Eq.symm' and pargs:
                reader,rargs=app_spine(pargs[-1])
                if head_name(reader) in seed_readers:
                    assert len(rargs)==2
                    found.append({'path':path,'seed_equation':head_name(reader)})
                    return canonical(args[3],mapping,casts,found,path)
    if expr[0] in ('forall','lam','let'):
        name=identity(expr[1])
        scope=('str','_@')
        if scope in name:
            assert ('str','_hyg') in name or ('str','_hygCtx') in name
            name=name[:name.index(scope)]
        return [expr[0],name,*[canonical(x,mapping,casts,found,path+(i,)) for i,x in enumerate(expr[2:],2)]]
    if expr[0] in ('const','proj'):
        name=identity(expr[1])
        return [expr[0],mapping.get(name,name),
                *[canonical(x,mapping,casts,found,path+(i,)) for i,x in enumerate(expr[2:],2)]]
    return [canonical(x,mapping,casts,found,path+(i,)) for i,x in enumerate(expr)]


adjusted=[]
for k,fields in sorted(terms.items()):
    v=pairs[k]
    display=new[v]['name']['display']
    for field in fields:
        casts=[]
        allow=field=='type' and display.endswith(tuple(changed_types))
        before=canonical(a_raw[k][field],pairs,False,[])
        after=canonical(b_raw[v][field],{},allow,casts)
        assert before==after,(display,field,casts)
        assert bool(casts)==allow,(display,casts)
        adjusted.append({'name':new[v]['name'],'field':field,'seed_casts':casts})
assert sum(len(r['seed_casts']) for r in adjusted)==4


def c3(path,homes):
    roots,pairs,controls=[],[],[]
    for line in path.read_text().splitlines():
        for label,dest in (('ROOT',roots),('REF',pairs),('CONTROL',controls)):
            marker='G06-C3-'+label+' '
            if line.startswith(marker):
                fields=line[len(marker):].split(' | ')
                if label=='CONTROL' or fields[0] in homes:
                    dest.append(tuple(fields))
    return roots,pairs,controls


for path,rows in ((cleanup/old_c3,old),(area/'metadata/run/C3.log',new)):
    roots,refs,c3_controls=c3(path,{r['home'] for r in rows.values()})
    assert not refs,refs
    assert Counter((r[0],r[1]) for r in roots)==Counter((r['home'],r['name']['display']) for r in rows.values())
    assert len(c3_controls)==2 and 'expected=1 actual=1' in c3_controls[0][0] and 'expected=0 actual=0' in c3_controls[1][0]
assert f'G06-C3-END base={plan["base"]} head={plan["head"]} modules=2 roots={len(new)} pairs=0 ' in (
    area/'metadata/run/C3.log').read_text()
checks='audits/pass-shelat/Checks'
assert all(before_products[checks][k]==after_products[checks][k] for k in ('source_sha256','object_sha256','log_sha256'))

control_root=cleanup/'controls-final-r1'
controls=read(control_root/'RESULT.json')
manifest=read(control_root/'MANIFEST.json')
assert controls['passed'] and len(controls['outcomes'])==13
pending=[manifest['owner'].replace('.','/')]
seen=set()
while pending:
    m=pending.pop()
    if m in seen:
        continue
    seen.add(m)
    assert before_plan['graph'][m]==plan['graph'][m]
    assert all(before_products[m][k]==after_products[m][k] for k in ('object_sha256','source_sha256','direct_local'))
    assert sha(Path(plan['tree'])/(m+'.olean'))==after_products[m]['object_sha256']
    pending.extend(plan['graph'][m])
for p,r in zip(manifest['probes'],controls['outcomes'],strict=True):
    assert all(r[k]==v for k,v in p.items()) and r['rc']==p['expected_rc'] and len(r['errors'])==p['expected_errors']
    assert sha(Path(r['module']+'.lean'))==r['source_sha256'] and sha(control_root/(r['label']+'.log'))==r['log_sha256']

out={'base':plan['base'],'head':plan['head'],'existing':len(old),'total':len(new),'rehomed':moves,
     'private_name_changes':renames,'readers':extras,'normalized_terms':adjusted,'reference_changes':ref_changes,
     'axioms':sorted({a for r in new.values() for a in r['axioms']}),
     'checks_log_sha256':after_products[checks]['log_sha256'],'original_context_modules':len(context),
     'reused_sensitivity_controls':len(controls['outcomes']),'control_context_modules':len(seen),
     'c3_controls':c3_controls,'published_baseline_inputs':old_inputs}
with (area/'DECLARATIONS.json').open('x') as f:
    json.dump(out,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(len(old),'existing declarations;',len(moves),'moves;',len(extras),'reader equations;',
      len(renames),'private names;',len(adjusted),'normalized expressions;',len(ref_changes),'reference differences')
