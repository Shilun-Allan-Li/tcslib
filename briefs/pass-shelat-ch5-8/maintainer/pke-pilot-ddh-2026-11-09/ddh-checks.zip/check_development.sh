#!/usr/bin/env bash
set -euo pipefail
s=$1
p=$2
wt=$3
tag=$4
shift 4
lean_bin=$(python3 -I -c 'import json,sys; from pathlib import Path; print(Path(json.load(open(sys.argv[1]))["toolchain"]).parent)' "$p/native-final/PLAN.json")
cd "$wt"
for m in "$@"; do
  /usr/bin/memory_pressure -Q > "$s/development-logs/$m-$tag.resources.txt"
  python3 -I - "$s/development-logs/$m-$tag.resources.txt" "$s" <<'PY'
import re,shutil,sys
from pathlib import Path
text=Path(sys.argv[1]).read_text()
total=int(re.search(r'system has (\d+)',text)[1])
percent=int(re.search(r'memory free percentage:\s*(\d+)%',text)[1])
assert total*(percent-1)//100 >= 4*1024**3
assert shutil.disk_usage(sys.argv[2]).free >= 12*1024**3
PY
  env -u LEAN_PATH -u LEAN_SRC_PATH -u LEAN_SYSROOT -u LEAN_OPTS -u ELAN_TOOLCHAIN -u PFR_BOOTSTRAP_CONFIG \
    TCSLIB_OLEANS="$s/development-tree/oleans" PATH="$lean_bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
    bash scripts/lean_check_tree.sh "TCSlib/Cryptography/Candidates/$m" > "$s/development-logs/$m-$tag.log" 2>&1 ||
      { tail -n 80 "$s/development-logs/$m-$tag.log"; exit 1; }
  shasum -a 256 "TCSlib/Cryptography/Candidates/$m.lean" "$s/development-logs/$m-$tag.log"
  printf 'PASS %s\n' "$m"
done
