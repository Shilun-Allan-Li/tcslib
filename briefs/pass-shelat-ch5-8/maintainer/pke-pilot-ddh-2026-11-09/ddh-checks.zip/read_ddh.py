"""Use the published DDH equations in the existing ElGamal reduction."""
from pathlib import Path
import sys

root=Path(sys.argv[1])
file=root/'TCSlib/Cryptography/Candidates/ElGamal.lean'
text=file.read_text()


def replace(old,new,count=1):
    global text
    assert text.count(old)==count,old
    text=text.replace(old,new,count)


# The two pointwise hybrid comparisons read concrete seed tuples through casts.
replace('((ddhReal (egGroupGen H G)).X n (dlc_grpEquiv H G n (r, u₁), (u₂, u₃)))',
        '''((ddhReal (egGroupGen H G)).X n
          (cast (ddhReal_σ (egGroupGen H G) n).symm (dlc_grpEquiv H G n (r, u₁), (u₂, u₃))))''',2)
replace('((ddhRandom (egGroupGen H G)).X n (r, (u₁, (u₂, u₃))))',
        '''((ddhRandom (egGroupGen H G)).X n
          (cast (ddhRandom_σ (egGroupGen H G) n).symm (r, (u₁, (u₂, u₃)))))''',3)
replace('  dsimp only [ddhReal]\n','  rw [ddhReal_X]\n  dsimp only\n')
replace('  dsimp only [ddhRandom]\n','  rw [ddhRandom_X]\n  dsimp only\n')
replace('  unfold dlc_ddhInput dlc_tuplePk ddhTuple\n',
        '  unfold dlc_ddhInput dlc_tuplePk\n  rw [ddhTuple_eq]\n',2)
replace('    unfold ddhExpo\n','    rw [ddhExpo_eq]\n')

# Transport the seed equivalences only at their DDH codomain.
replace('''  let E₂ : (G.gen.Coins n × (Fin (n * n) → Bool)) × ((Fin (n * n) → Bool) ×
      ((Fin (n * n) → Bool) × (M.Coins n × D.Coins n))) ≃
      (ddhReal (egGroupGen H G)).σ n × Db.Coins n :=
''','''  let E₂seed : (G.gen.Coins n × (Fin (n * n) → Bool)) × ((Fin (n * n) → Bool) ×
      ((Fin (n * n) → Bool) × (M.Coins n × D.Coins n))) ≃
      ((egGroupGen H G).gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool))) ×
        Db.Coins n :=
''')
replace('  rw [acceptProb_def, acceptProb_def, ← uprob_comp_equiv E₁, ← uprob_comp_equiv E₂]',
        '''  let E₂ := E₂seed.trans
    ((Equiv.cast (ddhReal_σ (egGroupGen H G) n).symm).prodCongr (Equiv.refl _))
  rw [acceptProb_def, acceptProb_def, ← uprob_comp_equiv E₁, ← uprob_comp_equiv E₂]''')
replace('''  let E : ∀ {Db : NUPPT}, (M.Coins n × D.Coins n ≃ Db.Coins n) →
      ((((egGroupGen H G).gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool))) ×
        (M.Coins n × D.Coins n)) × (Fin (n * n) → Bool)) ≃
      (ddhRandom (egGroupGen H G)).σ n × Db.Coins n := fun e =>
''','''  let Eseed : ∀ {Db : NUPPT}, (M.Coins n × D.Coins n ≃ Db.Coins n) →
      ((((egGroupGen H G).gen.Coins n × ((Fin (n * n) → Bool) × (Fin (n * n) → Bool))) ×
        (M.Coins n × D.Coins n)) × (Fin (n * n) → Bool)) ≃
      ((egGroupGen H G).gen.Coins n ×
        ((Fin (n * n) → Bool) × (Fin (n * n) → Bool) × (Fin (n * n) → Bool))) × Db.Coins n := fun e =>
''')
replace('  rw [acceptProb_def, acceptProb_def, ← uprob_comp_equiv (E e₀), ← uprob_comp_equiv (E e₁),',
        '''  let E {Db : NUPPT} (e : M.Coins n × D.Coins n ≃ Db.Coins n) :=
    (Eseed (Db := Db) e).trans
      ((Equiv.cast (ddhRandom_σ (egGroupGen H G) n).symm).prodCongr (Equiv.refl _))
  rw [acceptProb_def, acceptProb_def, ← uprob_comp_equiv (E e₀), ← uprob_comp_equiv (E e₁),''')
replace('`dlc_encEquiv`, and `E₂`, built from `dlc_grpEquiv` and `e`). Off',
        '`dlc_encEquiv`, and `E₂`, built from `dlc_grpEquiv`, `e` and the seed equation\n'
        '`ddhReal_σ`). Off')
replace('(`acceptProb_def`, `uprob_comp_equiv` with `E e_b`), split them off (`uprob_prod`), and bound the',
        '(`acceptProb_def`, `uprob_comp_equiv` with `E e_b` using `ddhRandom_σ`), split them off\n'
        '(`uprob_prod`), and bound the')
file.write_text(text)
