"""Prepare the DDH relocation PR and records from the verified artifacts."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

area=Path(sys.argv[1]).resolve()
mode=sys.argv[2]

def read(rel):
    return json.loads((area/rel).read_bytes())

def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()

native,source,decl,reads=map(read,('native/RESULT.json','SOURCE-CHECK.json','DECLARATIONS.json','READS.json'))
base,head=native['base'],native['head']
assert all(r['base']==base and r['head']==head for r in (source,decl,reads))
assert native['passed'] and reads['passed'] and reads['new_reads']==0
n=decl['existing']
moved=len(decl['rehomed'])
private=len(decl['private_name_changes'])
readers=len(decl['readers'])
private_proofs=len(source['private_changes'])
fresh=native['fresh_native_checks']
retained=native['initial_retained']
inherited=len(reads['inherited_explicit_reads'])
repo='https://github.com/Shilun-Allan-Li/tcslib'
plan_doc='briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md'
review='pke-pilot-ddh-2026-11-09'
review_doc=f'briefs/pass-shelat-ch5-8/maintainer/{review}/README.md'
if mode=='pr':
    (area/'pr-body.md').write_text(f"""## Public-key encryption pilot

Move the safe-prime group facts, DDH experiments, and `DDHAssumption` to
`Candidates.DDH`. Both facades point to the new owner. The original
`Candidates.ElGamal` import still exposes the assumption and construction.

The {readers} new equations expose the encoded tuple, exponent sampler, seed
types, and sample formulas. The ElGamal reduction uses them in {private_proofs}
private proof steps. The public security statement, algorithms and
experiment definitions match the base.

## Verification

- All {fresh} affected modules pass, including both facades, the library root
  and campaign Checks. The replay verifies {retained:,} retained objects.
- Both standalone imports pass. The census matches all {n} existing
  declarations and records {moved} moves and {private} generated private names.
  Four seed casts account for the three private theorem type changes.
- Both whole-file seals and the focused Checks seal pass. The explicit
  scan reproduces the {inherited} inherited core reads, which are mapped in the
  cleanup ledger.
- The legacy construction file decreases from {source['legacy_lines']['base']:,} to
  {source['legacy_lines']['head']:,} lines. This slice keeps the private
  arithmetic and construction proofs together for a separate relocation.

Base `{base}`. Checked head `{head}`.

[Approved pilot map]({repo}/blob/{base}/{plan_doc})
""")
elif mode=='records':
    campaign=Path(sys.argv[3])
    pr=read('pr-live.json')
    assert pr['headRefOid']==head and pr['baseRefName']=='cryptography/pass-shelat-ch2-4'
    assert pr['state']=='OPEN' and not pr['isDraft'] and pr['mergeable']=='MERGEABLE'
    assert re.fullmatch(re.escape(repo)+r'/pull/\d+',pr['url'])
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=campaign,text=True).strip()==base
    assert {x['path'] for x in pr['files']}=={p+'.lean' for p in (
        'TCSlib/Cryptography/Candidates','TCSlib/Cryptography/Candidates/DDH',
        'TCSlib/Cryptography/Candidates/ElGamal','TCSlib/Cryptography/Encryption/PublicKey')}
    number,url=pr['number'],pr['url']
    stage=area/'records'
    evidence=stage/'evidence'
    evidence.mkdir(parents=True)
    archive=area/'ddh-checks.zip'
    digest=sha(archive)
    for f in (archive.name,'pr-live.json'):
        shutil.copyfile(area/f,evidence/f)
    files=['native/'+p for p in ('PLAN.json','PRODUCTS.json','RESULT.json')]
    files+=['SOURCE-CHECK.json','DECLARATIONS.json','SEALS.json','SEALS-MOVED.json',
            'READS.json','read-scan/scan.log','pr-live.json']
    payload={'base':base,'head':head,'passed':True,'pr':number,'pr_url':url,
        'native':{'fresh':fresh,'retained':retained,'total':fresh+retained},
        'declarations':{'existing':n,'rehomed':moved,'private_name_changes':private,
                        'private_proof_changes':private_proofs,'new_readers':readers},
        'seals':{'whole_file':reads['whole_file_seals'],'focused':reads['focused_seals'],
                 'requests':reads['requests'],'diagnostics':0,'inherited_explicit_reads':inherited,
                 'new_reads':0,'verified_retained_controls':decl['reused_sensitivity_controls']},
        'artifact_sha256':{f:sha(area/f) for f in files},
        'archive':{'name':archive.name,'sha256':digest,'bytes':archive.stat().st_size}}
    (evidence/'VERIFICATION.json').write_text(json.dumps(payload,indent=2)+'\n')
    rows=''.join(f'| {r["id"]} | {r["baseline_site"].rsplit(":",1)[1]} | '
                 f'{r["current_site"].rsplit(":",1)[1]} |\n' for r in reads['inherited_explicit_reads'])
    (evidence/'README.md').write_text(f"""# Reusable safe-prime DDH experiments

Seyoon merged the [trapdoor relocation #260]({repo}/pull/260) at `{base}`.
[PR #{number}]({url}) starts the ElGamal slice of the
[approved PKE pilot](../cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
at `{head}`.

`Candidates.DDH` owns the safe-prime group facts, exponent sampler,
and real and random experiments. The construction continues to import
this module through its original path. The {readers} reader equations let the
reduction transport seeds and read samples without unfolding the
experiments. The source check binds the verbatim move and isolates the
changes to {private_proofs} private proofs. The existing `eval_ddhLen` simp rule moves
with its definition.

- All {fresh} affected modules compile, including the library root and
  campaign Checks. The replay verifies {retained:,} retained objects.
  Checks output and object bytes match the verified #260 baseline.
- The standalone DDH and ElGamal probes pass. The census checks all
  {n} existing declarations and records {moved} moved declarations.
  The comparison accounts for {private} generated private names and
  the casts in three private theorem types. Public types, definitions,
  and axiom dependencies match.
- The two whole-file seals pass with {reads['requests']:,} requests. The focused
  Checks seal passes with the relocated DDH definitions sealed. The
  thirteen sensitivity controls transfer through identical closures,
  and the generated-equation collector reruns its two controls.
- Campaign lint reports zero failures. The old construction file drops
  from {source['legacy_lines']['base']:,} to {source['legacy_lines']['head']:,} lines.
  This review keeps the construction and reduction's private arithmetic
  support together. The construction move is a separate review.

The source scan reproduces the {inherited} inherited core reads in the original
ElGamal module. The following rows give their current positions.

| Ledger ID | Baseline line | Current line |
|---|---:|---:|
{rows}
`VERIFICATION.json` pins the review. `ddh-checks.zip` contains the
source, probe receipts and ledger. Its SHA-256 is `{digest}`.

**Clear to merge — the DDH move and the published-reader boundary pass.**
""")
    handoff=campaign/'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md'
    lines=handoff.read_text().splitlines(keepends=True)
    i,=(i for i,l in enumerate(lines) if l.startswith('| Cleanup and reorganization | '))
    pre,marker,_=lines[i].partition('[Trapdoor relocation PR #260]')
    assert marker
    lines[i]=pre+f"""Seyoon merged the [trapdoor relocation #260]({repo}/pull/260) at `{base}`. [DDH extraction PR #{number}]({url}) at `{head}` is clear for Seyoon to merge. The reusable assumption has its own module and the ElGamal reduction reads through published equations. The four inherited explicit reads are mapped. See the [DDH review](maintainer/{review}/README.md), [trapdoor ledger](maintainer/pke-pilot-trapdoor-2026-11-09/README.md) and [pilot map](maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md). The construction move follows this merge. Efficiency still needs the recorded issue-time probes. |
"""
    (stage/'MAINTAINER-HANDOFF.md').write_text(''.join(lines))
    log=(campaign/'PassShelatChapter5-8Plan.md').read_text()
    assert log.endswith('\n') and '#259 merged and the trapdoor PKE move verified' in log.splitlines()[-1]
    row=f"""| 2026-11-09 (PST) | **#260 merged and the DDH extraction verified.** Seyoon merged #260 at `{base}`. [PR #{number}]({url}) at `{head}` separates the safe-prime DDH assumption from the ElGamal construction. Six published equations support the five private proof adaptations. The {fresh} affected modules pass and the census matches {n} original declarations. The whole-file and focused Checks seals pass. The four inherited explicit reads are mapped. [Verification]({review_doc}). The construction relocation follows Seyoon’s merge. | record |
"""
    (stage/'PassShelatChapter5-8Plan.md').write_text(log+row)
    print(review,digest)
else:
    raise ValueError(mode)
