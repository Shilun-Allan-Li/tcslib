"""Build a pinned replay plan by invalidating the exact transitive consumers."""
from functools import cache
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

area, root, previous, campaign, graph_source = map(lambda s: Path(s).resolve(), sys.argv[1:6])
out = area/sys.argv[6]
tree = out/'oleans'
spec = importlib.util.spec_from_file_location('reviewed_import_graph',graph_source)
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).strip()


def copy(src,dest,digest):
    assert sha(src)==digest, src
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dest)
    assert sha(dest)==digest and not dest.samefile(src), dest


base=(area/'base.txt').read_text().strip()
head=(area/'head.txt').read_text().strip()
assert git('rev-parse','HEAD')==head and git('merge-base',base,head)==base
assert not git('status','--porcelain')
verify_path=campaign/'briefs/pass-shelat-ch5-8/maintainer/pke-pilot-trapdoor-2026-11-09/VERIFICATION.json'
verified=read(verify_path)
old=read(previous/'PLAN.json')
result=read(previous/'RESULT.json')
previous_head=(area/'predecessor.txt').read_text().strip()
assert verified['passed'] and result['passed'] and result['head']==old['head']==verified['head']==previous_head
for file in ('PLAN.json','PRODUCTS.json','RESULT.json'):
    assert sha(previous/file)==verified['artifact_sha256']['native-final/'+file],file
assert not git('diff','--name-only',previous_head,base,'--','*.lean','lean-toolchain',
               'scripts/lean_check_tree.sh','lakefile.lean','lakefile.toml','lake-manifest.json')
old_products=read(previous/'PRODUCTS.json')
entry='TCSlib/Cryptography/Encryption/PublicKey'
legacy='TCSlib/Cryptography/Candidates/ElGamal'
ddh='TCSlib/Cryptography/Candidates/DDH'
new={ddh}
changed={legacy,entry,'TCSlib/Cryptography/Candidates'}|new
assert set(git('diff','--name-only',base,head).splitlines())=={p+'.lean' for p in changed}
library,checks='TCSlib','audits/pass-shelat/Checks'
sources={f[:-5]:(root/f).read_bytes() for f in git('ls-files','--','TCSlib','TCSlib.lean',checks+'.lean').splitlines()
         if f.endswith('.lean')}
assert set(sources)==set(old['source_digests'])|new
source_digests={p:sha256(raw).hexdigest() for p,raw in sources.items()}
for name,digest in source_digests.items():
    if name not in changed:
        assert digest==old['source_digests'][name],name
imports={p:[i.replace('.','/') for i in graph.imports(raw) if i.replace('.','/') in sources] for p,raw in sources.items()}
assert all(imports[p]==old['graph'][p] for p in old['graph'].keys()-changed)
order=graph.topo(imports,[library,checks])
assert set(order)==set(old['order'])|new


@cache
def closure(m):
    return set(imports[m]).union(*(closure(p) for p in imports[m]))


affected={m for m in sources if m in changed or closure(m)&changed}
assert affected<=set(order) and {library,checks}<=affected
pending=list(old['graph'][legacy])
original=set()
while pending:
    module=pending.pop()
    if module not in original:
        original.add(module)
        pending.extend(old['graph'][module])
assert original==closure(ddh)
assert original==closure(legacy)-new
rebuild=[m for m in order if m in affected]
old_tree=Path(old['tree']).resolve()
assert shutil.disk_usage(area).free >= 15*1024**3
out.mkdir()
retained={}
for m in order:
    if m in rebuild:
        continue
    row=old_products[m]
    direct={p:retained[p]['object_sha256'] for p in imports[m]}
    assert source_digests[m]==row['source_sha256'] and direct==row['direct_local'],m
    copy(old_tree/(m+'.olean'),tree/(m+'.olean'),row['object_sha256'])
    retained[m]={'source_sha256':row['source_sha256'],'object_sha256':row['object_sha256'],
                 'direct_local':direct,'source':'verified_trapdoor_tree'}
external={}
for name,row in old['external'].items():
    path=Path(row['path']).resolve()
    if path.is_relative_to(old_tree):
        target=tree/path.relative_to(old_tree)
        copy(path,target,row['sha256'])
        path=target
    else:
        assert sha(path)==row['sha256'],path
    external[name]={'path':str(path),'sha256':row['sha256']}
(tree/'PFR').symlink_to('.lake/packages/PFR/PFR',target_is_directory=True)
plan={'base':base,'head':head,'baseline':previous_head,'worktree':str(root),'tree':str(tree),
      'toolchain':old['toolchain'],'toolchain_sha256':old['toolchain_sha256'],'checker_sha256':old['checker_sha256'],
       'affected':sorted(affected),'rebuild':rebuild,'order':order,'retained':retained,'graph':{m:imports[m] for m in order},
      'external':external,'source_digests':source_digests,'previous_verification_sha256':sha(verify_path)}
with (out/'PLAN.json').open('x') as stream:
    json.dump(plan,stream,indent=2)
    stream.write('\n')
print(len(retained),'retained objects;',len(rebuild),'fresh modules',flush=True)
print('\n'.join(rebuild),flush=True)
