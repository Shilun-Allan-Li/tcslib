## Public-key encryption pilot

Move the safe-prime group facts, DDH experiments, and `DDHAssumption` to
`Candidates.DDH`. Both facades point to the new owner. The original
`Candidates.ElGamal` import still exposes the assumption and construction.

The 6 new equations expose the encoded tuple, exponent sampler, seed
types, and sample formulas. The ElGamal reduction uses them in 5
private proof steps. The public security statement, algorithms and
experiment definitions match the base.

## Verification

- All 6 affected modules pass, including both facades, the library root
  and campaign Checks. The replay verifies 1,078 retained objects.
- Both standalone imports pass. The census matches all 220 existing
  declarations and records 40 moves and 8 generated private names.
  Four seed casts account for the three private theorem type changes.
- Both whole-file seals and the focused Checks seal pass. The explicit
  scan reproduces the 4 inherited core reads, which are mapped in the
  cleanup ledger.
- The legacy construction file decreases from 2,134 to
  1,835 lines. This slice keeps the private
  arithmetic and construction proofs together for a separate relocation.

Base `1db060a35c028f61afb4b9013d29bfd12e7e46b5`. Checked head `482e2342b05103f602e9216f89c55427b89e3c42`.

[Approved pilot map](https://github.com/Shilun-Allan-Li/tcslib/blob/1db060a35c028f61afb4b9013d29bfd12e7e46b5/briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1/PKE-PILOT.md)
