import Lean
import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open Lean Meta Elab Command

namespace CleanupIncrement

def parts : Name → List (String × String)
  | .anonymous => []
  | .str p s => parts p ++ [("str", s)]
  | .num p n => parts p ++ [("num", toString n)]

def identity (n : Name) : Json :=
  Json.mkObj [("display", toJson n.toString), ("components", toJson (parts n))]

def names (ns : Array Name) : Json := Json.arr (ns.map identity)

def kind : ConstantInfo → String
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .axiomInfo _ => "axiom"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def isAbbrev : ConstantInfo → Bool
  | .defnInfo d => match d.hints with
    | .abbrev => true
    | _ => false
  | _ => false

/-- Compare exact kernel type structure, retaining binder labels and annotations of visibility. -/
partial def exprData : Expr → Json
  | .bvar i => .arr #[.str "bvar", toJson i]
  | .fvar id => .arr #[.str "fvar", identity id.name]
  | .mvar id => .arr #[.str "mvar", identity id.name]
  | .sort l => .arr #[.str "sort", toJson (reprStr l)]
  | .const n ls => .arr #[.str "const", identity n, toJson (ls.map reprStr)]
  | .app f a => .arr #[.str "app", exprData f, exprData a]
  | .lam n t b info => .arr #[.str "lam", identity n, exprData t, exprData b, toJson (reprStr info)]
  | .forallE n t b info =>
      .arr #[.str "forall", identity n, exprData t, exprData b, toJson (reprStr info)]
  | .letE n t v b nd => .arr #[.str "let", identity n, exprData t, exprData v, exprData b, toJson nd]
  | .lit l => .arr #[.str "lit", toJson (reprStr l)]
  | .mdata _ e => exprData e
  | .proj t i e => .arr #[.str "proj", identity t, toJson i, exprData e]




run_cmd do
  let owners : Array Name := #[`TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF]
  let ownerSet := owners.foldl (fun (s : NameSet) n => s.insert n) {}
  let env ← getEnv
  let kernel := env.checked.get
  let file ← IO.FS.Handle.mk "/Users/seyoonr/.codex/worktrees/ps-gate06-integration/tcslib-pass-shelat-ch2-4/.lake/ps-maintainer/private-key-oracle-from-prf-20261109/metadata/Head.jsonl" .write
  let emit (j : Json) : IO Unit := file.putStrLn j.compress
  for moduleName in owners do
    unless (env.getModuleIdx? moduleName).isSome do throwError "missing module {moduleName}"
  let mut count : Nat := 0
  let mut catalog : Nat := 0
  for (n, c) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    let home := env.header.moduleNames[mi.toNat]!
    unless (`TCSlib).isPrefixOf home do continue
    let some ci := kernel.find? n | throwError "missing checked constant {n}"
    unless kind ci == kind c do throwError "checked kind differs for {n}"
    let status ← liftCoreM <| getReducibilityStatus n
    let matcher := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let inst := Lean.Meta.isInstanceCore env n
    let common := [("name", identity n), ("home", identity home), ("kind", toJson (kind ci)),
      ("status", toJson (reprStr status)), ("abbrev", toJson (isAbbrev ci)),
      ("instance", toJson inst), ("matcher", toJson matcher)]
    emit <| Json.mkObj (("record", .str "catalog") :: common)
    catalog := catalog + 1
    if ownerSet.contains home then
      let value := ci.value? (allowOpaque := true)
      let axioms ← liftCoreM <| collectAxioms n
      emit <| Json.mkObj (("record", .str "constant") :: common ++ [
        ("type", exprData ci.type), ("levels", names ci.levelParams.toArray),
        ("definition_value", if ci.isDefinition then (value.map exprData).getD .null else .null),
        ("type_refs", names ci.type.getUsedConstants),
        ("value_refs", names ((value.map (·.getUsedConstants)).getD #[])),
        ("axioms", names axioms)])
      count := count + 1
  emit <| Json.mkObj [("record", .str "complete"), ("count", toJson count),
    ("catalog", toJson catalog), ("owners", names owners)]
  logInfo m!"Fixed-length PRF wrapper declaration census complete: {count} declarations"

end CleanupIncrement
