import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Composability

variable (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (F n s x))

example : (prfFixedScheme F E hE hFE).toPrivateKeyScheme = prfScheme F E hE hFE := by
  rfl
