import TCSlib.Cryptography.Encryption.PrivateKey.OracleFromPRF

#check @TCSlib.Cryptography.Composability.prfFixedScheme
#check @TCSlib.Cryptography.Composability.prfFixedScheme_toPrivateKeyScheme
#check @TCSlib.Cryptography.Composability.prfFixedScheme_ctLen
#check @TCSlib.Cryptography.Composability.prfFixedScheme_gen
#check @TCSlib.Cryptography.Composability.prfFixedScheme_enc
#check @TCSlib.Cryptography.Composability.prfFixedScheme_dec
#check @TCSlib.Cryptography.Composability.prfFixedScheme_cpa
#check @TCSlib.Cryptography.Composability.prfFixedScheme_cca1
#check @TCSlib.Cryptography.Composability.prfFixedScheme_not_cca2
#check @TCSlib.Cryptography.Composability.not_prfFixedScheme_cca2
#check @TCSlib.Cryptography.prfScheme_multiMessageSecure
#check @TCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure
