"""Bind the comparison and import probes to verified trees and import closures."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import sys

area, side = Path(sys.argv[1]).resolve(), sys.argv[2]
assert side in {"Base", "Head"}
meta = area / "metadata"
previous = area.parent / "private-key-oracle-security-20261109" / "native"
native = previous if side == "Base" else area / "native"
template = area.parent / "ggm-move-20261109" / "metadata" / "HeadCensus.lean"
scope = json.loads((area / "MOVE-SCOPE.json").read_bytes())
legacy, owner = (scope[name] for name in ("legacy", "owner"))


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


plan = read(native / "PLAN.json")
if side == "Base":
    predecessor = Path(sys.argv[3]) / "briefs/pass-shelat-ch5-8/maintainer/private-key-oracle-security-2026-11-09"
    receipt = read(predecessor / "VERIFICATION.json")
    assert plan["head"] == receipt["head"] == (area / "accepted-274.txt").read_text().strip()
    for name in ("PLAN.json", "PRODUCTS.json", "RESULT.json"):
        assert sha(native / name) == receipt["artifact_sha256"]["native/" + name], name
    products = read(native / "PRODUCTS.json")
else:
    products = dict(plan["retained"])
    for check in sorted(native.glob("run-*/check-*.json")):
        try:
            row = read(check)
        except json.JSONDecodeError:
            continue
        if row["rc"] == 0:
            assert row["head"] == plan["head"] and sha(check.with_suffix(".log")) == row["log_sha256"]
            products[row["module"]] = row

pending = [legacy]
needed = set()
while pending:
    module = pending.pop()
    if module not in needed:
        needed.add(module)
        pending.extend(plan["graph"][module])
owners = [legacy] if side == "Base" else [owner]
assert set(owners) <= needed
assert needed <= products.keys(), sorted(needed - products.keys())
assert scope["facade"] not in needed and "TCSlib" not in needed
out = meta / side.lower() / "oleans"
out.mkdir(parents=True)
tree = Path(plan["tree"])


def copy(src, dst, expected):
    assert sha(src) == expected, src
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    assert sha(dst) == expected and not dst.samefile(src), dst


for module in sorted(needed):
    row = products[module]
    assert row["source_sha256"] == plan["source_digests"][module], module
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}, module
    copy(tree / (module + ".olean"), out / (module + ".olean"), row["object_sha256"])
for row in plan["external"].values():
    src = Path(row["path"])
    if src.is_relative_to(tree):
        copy(src, out / src.relative_to(tree), row["sha256"])
    else:
        assert sha(src) == row["sha256"], src
(out / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)

program = template.read_text()
imported = legacy if side == "Base" else owner
program, count = re.subn(r"^import TCSlib\.Cryptography\.Asymptotic\.PRF$", "import " + imported.replace("/", "."), program, flags=re.M)
assert count == 1
owner_text = ", ".join(chr(96) + module.replace("/", ".") for module in owners)
program, count = re.subn(r"(?m)^  let owners : Array Name := .*", "  let owners : Array Name := #[" + owner_text + "]", program)
assert count == 1
program, count = re.subn(r'(?m)^  let file ← IO.FS.Handle.mk ".*" \.write$', f'  let file ← IO.FS.Handle.mk "{meta / (side + ".jsonl")}" .write', program)
assert count == 1
program = program.replace("GGM declaration census complete", "Fixed-length PRF wrapper declaration census complete")
(meta / (side + "Census.lean")).write_text(program)

prefix = "TCSlib.Cryptography."
names = tuple("Composability." + name for name in (
    "prfFixedScheme", "prfFixedScheme_toPrivateKeyScheme", "prfFixedScheme_ctLen", "prfFixedScheme_gen",
    "prfFixedScheme_enc", "prfFixedScheme_dec", "prfFixedScheme_cpa", "prfFixedScheme_cca1",
    "prfFixedScheme_not_cca2", "not_prfFixedScheme_cca2",
)) + ("prfScheme_multiMessageSecure", "Composability.FixedLengthScheme.INDSecure")


def probe(label, provider, names):
    text = "import " + provider.replace("/", ".") + "\n\n"
    text += "".join("#check @" + prefix + name + "\n" for name in names)
    (meta / (label + ".lean")).write_text(text)


probe(side + "Legacy", legacy, names)
if side == "Head":
    probe("Standalone", owner, names)
print(f"Copied {len(needed)} verified {side.lower()} module objects.", flush=True)
