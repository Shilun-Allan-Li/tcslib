## Changes

- Move the fixed-length PRF wrapper, its length proof and the CPA, CCA1 and CCA2 claims verbatim into `Encryption.PrivateKey.OracleFromPRF`.
- Re-export the declarations through `Composability.PRFScheme`. The private-key facade imports the new owner directly.
- Preserve the three admitted proofs and the derived negation's dependence on the admitted CCA2 counterexample.

## Verification

- All five affected modules and the separate campaign Checks replay pass with Lean 4.25.0. The standalone and legacy imports agree.
- The census matches all 14 types, definition values, references and axiom sets.
- Both whole-file seals pass with the same three admission warnings. The control blocks direct reduction of the wrapper and accepts the published projection equation.
- Source lint, campaign lint and the diff check pass.
