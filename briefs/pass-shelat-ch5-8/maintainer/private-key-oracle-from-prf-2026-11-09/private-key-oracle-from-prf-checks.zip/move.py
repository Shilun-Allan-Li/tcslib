"""Stage the fixed-length PRF wrapper and its claims from the exact merged source."""
import json
from pathlib import Path
import subprocess
import sys

area, repo = (Path(arg).resolve() for arg in sys.argv[1:3])
base = (area / "base.txt").read_text().strip()
crypto = "TCSlib/Cryptography/"
legacy = crypto + "Composability/PRFScheme"
facade = crypto + "Encryption/PrivateKey"
owner = facade + "/OracleFromPRF"
legacy_games = crypto + "Composability/Defs"
legacy_prf = crypto + "Asymptotic/MultiMessage"
games, prf = facade + "/OracleSecurity", facade + "/FromPRF"
marker = "namespace TCSlib.Cryptography.Composability\n"


def show(module):
    return subprocess.check_output(["git", "show", f"{base}:{module}.lean"], cwd=repo).decode()


def import_line(module):
    return "import " + module.replace("/", ".") + "\n"


def replace_once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


raw = show(legacy)
wrapper = replace_once(raw, import_line(legacy_games), import_line(games))
wrapper = replace_once(wrapper, import_line(legacy_prf), import_line(prf))
assert wrapper[wrapper.index(marker):] == raw[raw.index(marker):]
compat = raw[:raw.index("import ")] + "".join(import_line(module) for module in (legacy_games, legacy_prf, owner))
compat += "\n" + raw[raw.index("set_option "):raw.index("/-!")]
compat += """/-!
# Fixed-length PRF encryption compatibility import

## Main definitions

`Encryption.PrivateKey.OracleFromPRF` wraps the PRF encryption scheme with its fixed
ciphertext length. The declarations live in `TCSlib.Cryptography.Composability`.

## Main results

This import exposes the CPA and CCA1 statements, the CCA2 counterexample statement
and the negation derived from it.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (Algorithm 99.1, Theorem 168.2 and §7.1.3.)
-/
"""
facade_text = replace_once(show(facade), import_line(legacy), import_line(owner))
facade_text = replace_once(facade_text,
    "* `Composability.PRFScheme` gives the fixed-length version of the PRF scheme.",
    "* `Encryption.PrivateKey.OracleFromPRF` gives the fixed-length PRF scheme and its oracle claims.")
sources = {owner: wrapper, legacy: compat, facade: facade_text}
for module, text in sources.items():
    path = area / "source" / (module + ".lean")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
(area / "MOVE-SCOPE.json").write_text(json.dumps({
    "legacy": legacy, "owner": owner, "facade": facade, "legacy_games": legacy_games,
    "legacy_prf": legacy_prf, "games": games, "prf": prf,
}, indent=2) + "\n")
print("Prepared the verbatim wrapper and claim relocation, compatibility import and facade update.")
