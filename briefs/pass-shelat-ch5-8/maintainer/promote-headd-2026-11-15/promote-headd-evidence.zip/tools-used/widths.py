"""widths.py <repo> <rev>... -- <file>...: per file and revision, line count, max width (Python len) and lines > 100."""
import sys, subprocess
a = sys.argv[1:]; k = a.index('--'); repo, revs, files = a[0], a[1:k], a[k + 1:]
for f in files:
    for r in revs:
        s = subprocess.run(['git', '-C', repo, 'show', f'{r}:{f}'], capture_output=True, check=True).stdout.decode('utf-8')
        ls = s.split('\n'); ls = ls[:-1] if ls and ls[-1] == '' else ls
        print(f'{f} {r[:8]} {len(ls)} lines; max width {max(map(len, ls))} chars; lines > 100: {[(i + 1, len(l)) for i, l in enumerate(ls) if len(l) > 100]}')
