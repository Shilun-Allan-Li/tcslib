"""downcount.py <repo> <rev> <module>...: number of modules (TCSlib/audits) transitively importing each module."""
import sys, re, subprocess
repo, rev, mods = sys.argv[1], sys.argv[2], sys.argv[3:]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
files = [f[:-5] for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'TCSlib.lean', 'audits').split() if f.endswith('.lean')]
rdep = {}
for m in files:
    for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M):
        if i.split('.')[0] in ('TCSlib', 'audits'): rdep.setdefault(i.replace('.', '/'), set()).add(m)
for x in mods:
    down, todo = set(), [x]
    while todo:
        m = todo.pop()
        if m in down: continue
        down.add(m); todo.extend(rdep.get(m, ()))
    print(x, len(down))
