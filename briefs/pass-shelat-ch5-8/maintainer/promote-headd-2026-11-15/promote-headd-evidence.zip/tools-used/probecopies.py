"""probecopies.py <worktree> <prefix> <evidence-rule10>: every <prefix>/**/*.lean in the worktree must equal one copy
<name>.lean.txt in the evidence (probe-sources/, seals*/{A,B}/, controls-*/), matched by subdir role."""
import sys, os, glob, hashlib
wt, pre, r = sys.argv[1:4]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
role = {'S': ['seals/A', 'seals/B'], 'C': ['seals-coe/A', 'seals-coe/B'], 'KS': ['controls-strict'], 'K': ['controls-coe'], '': ['probe-sources']}
ok = n = 0
for p in sorted(glob.glob(os.path.join(wt, pre, '**', '*.lean'), recursive=True)):
    rel = os.path.relpath(p, os.path.join(wt, pre)); sub = os.path.dirname(rel); base = os.path.basename(rel)
    cands = [os.path.join(r, d, base + '.txt') for d in role[sub] if os.path.exists(os.path.join(r, d, base + '.txt'))]
    same = len(cands) == 1 and sha(cands[0]) == sha(p); n += 1; ok += same
    print('EQUAL' if same else 'DIFF', os.path.join(pre, rel), sha(p))
print(f'{ok}/{n} worktree probe sources byte-equal to their evidence copies')
