"""headd_edit.py <worktree>: Gate 29 G29-02 promotion (Seyoon 2026-11-15), exact replacements (each old string
occurs once). Foundations/BitLists.lean: Main-results bullet and the new generic theorem
TCSlib.Cryptography.headD_drop_ofFn after headD_drop. Lamport/MachineSpec.lean:
Authentication.LamportFill.headD_drop_ofFn re-derived from it (proof only; one sentence added to its docstring)."""
import sys, os
wt = sys.argv[1]
def edit(rel, R):
    f = os.path.join(wt, rel); s = open(f, encoding='utf-8').read()
    for a, b in R:
        c = s.count(a); assert c == 1, (rel, c, a[:70]); s = s.replace(a, b)
    open(f, 'w', encoding='utf-8').write(s); print(rel, len(R), 'replacements')
edit('TCSlib/Cryptography/Foundations/BitLists.lean', [
('''* `TCSlib.Cryptography.headD_drop`: the head of a suffix is an entry.
''', '''* `TCSlib.Cryptography.headD_drop`: the head of a suffix is an entry.
* `TCSlib.Cryptography.headD_drop_ofFn`: the head of a suffix of a tuple's list is the tuple's
  entry at that index.
'''),
('''theorem headD_drop {α : Type*} (l : List α) (i : ℕ) (d : α) : (l.drop i).headD d = l.getD i d := by
  rw [List.headD_eq_head?, List.head?_drop, List.getD_eq_getElem?_getD]

''', '''theorem headD_drop {α : Type*} (l : List α) (i : ℕ) (d : α) : (l.drop i).headD d = l.getD i d := by
  rw [List.headD_eq_head?, List.head?_drop, List.getD_eq_getElem?_getD]

/-- The head of the suffix of a tuple's list at an index is the tuple's entry there: for
`f : Fin n → α`, `i : Fin n` and any default `d`, `((List.ofFn f).drop i.val).headD d = f i`
(for bit vectors, `d = false` reads the `i`-th bit of the string `List.ofFn f`).

**Proof sketch.** By `headD_drop` the left side is the entry `(List.ofFn f).getD i d`; since
`i < n` it is the in-range entry `f i` (`List.getElem?_ofFn`). -/
theorem headD_drop_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) (d : α) :
    ((List.ofFn f).drop i.val).headD d = f i := by
  simp only [headD_drop, List.getD_eq_getElem?_getD, List.getElem?_ofFn, dif_pos i.isLt,
    Option.getD_some]

'''),
])
edit('TCSlib/Cryptography/Authentication/Signatures/Lamport/MachineSpec.lean', [
('''/-- The selected bit of a serialized message is its typed bit at that position: `((List.ofFn m).drop
i.val).headD false = m i`. -/
theorem headD_drop_ofFn {n : ℕ} (m : Fin n → Bool) (i : Fin n) :
    ((List.ofFn m).drop i.val).headD false = m i := by
  simp only [headD_drop, List.getD_eq_getElem?_getD, List.getElem?_ofFn,
    dif_pos i.isLt, Option.getD_some]
''', '''/-- The selected bit of a serialized message is its typed bit at that position: `((List.ofFn m).drop
i.val).headD false = m i`.

This is the published `TCSlib.Cryptography.headD_drop_ofFn` at `α = Bool` and `d = false`. -/
theorem headD_drop_ofFn {n : ℕ} (m : Fin n → Bool) (i : Fin n) :
    ((List.ofFn m).drop i.val).headD false = m i :=
  TCSlib.Cryptography.headD_drop_ofFn m i false
'''),
])
