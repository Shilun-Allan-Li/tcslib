"""Verify the exact source replay, declaration comparison, seals and ledger mapping."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

area, repo, campaign = (Path(arg).resolve() for arg in sys.argv[1:4])
native, meta = area / "native", area / "metadata"
base, head = ((area / (side + ".txt")).read_text().strip() for side in ("base", "head"))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


plan, result, products = (read(native / (name + ".json")) for name in ("PLAN", "RESULT", "PRODUCTS"))
source, move, decls = (read(area / (name + ".json")) for name in ("SOURCE-CHECK", "MOVE-SCOPE", "DECLARATIONS"))
legacy, owner = move["legacy"], move["owner"]
assert git("rev-parse", "HEAD").decode().strip() == head
assert not git("status", "--porcelain") and not git("diff", "--check", base, head)
assert all((r["base"], r["head"]) == (base, head) for r in (plan, result, source, decls))
assert result["passed"] and result["plan_sha256"] == sha(native / "PLAN.json")
assert result["products_sha256"] == sha(native / "PRODUCTS.json")
assert result["fresh_native_checks"] == len(plan["rebuild"]) == 13
assert len(plan["affected"]) == source["affected_modules"] == 12
assert set(plan["rebuild"]) - set(plan["affected"]) == set(source["campaign_checks_replayed"]) == {"audits/pass-shelat/Checks"}
assert result["initial_retained"] == len(plan["retained"]) == 1095
assert len(products) == len(plan["order"]) == 1108 and len(plan["external"]) == 3810
assert {"TCSlib", "audits/pass-shelat/Checks"} <= set(plan["rebuild"])
assert source["legacy_closure_preserved"] and source["facade_closure_preserved"]
assert source["proof_and_definition_code_preserved"] and source["relocation"] == {legacy: owner}
for module, row in products.items():
    assert row["source_sha256"] == plan["source_digests"][module]
    assert row["direct_local"] == {dep: products[dep]["object_sha256"] for dep in plan["graph"][module]}
checks = {}
for receipt in native.glob("run-*/check-*.json"):
    row = read(receipt)
    assert row["head"] == head and row["rc"] == 0
    assert sha(receipt.with_suffix(".log")) == row["log_sha256"]
    checks[row["module"]] = row["object_sha256"]
assert checks == {module: products[module]["object_sha256"] for module in plan["rebuild"]}
assert decls["matched_declarations"] == decls["relocated_declarations"] == 110
assert decls["private_name_changes"] == 11 and decls["elaborated_references_match"]
assert len(decls["generated_universe_scope_changes"]) == 2
assert decls["axioms_match"] and decls["legacy_and_new_imports_agree"]

seals, masks, warnings = {}, {}, {}
pairs = {
    (r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
    for r in decls["declarations"] if r["kind"] == "def"
}
focus_labels = {"PRFSchemeSeal", "CCA2SchemeSeal", "PublicKeyOracleSeal", "NonMalleableSeal", "SimNonMalleableSeal"}
for side, rev in (("base", base), ("head", head)):
    for lane in ("seals", "focus"):
        tag = side + "-" + lane
        directory = meta / tag
        scope = read(directory / "SCOPE.json")
        labels = {label for label in scope if label.endswith("Seal")}
        expected = focus_labels if lane == "focus" else {"DefsSeal" if side == "base" else "OracleSecuritySeal"}
        assert labels == expected
        seals[tag], masks[tag], warnings[tag] = {}, {}, {}
        for label in sorted(labels):
            stem = directory / label
            manifest = read(stem.with_suffix(".json"))
            filename = manifest["source_path"]
            raw = git("show", f"{rev}:{filename}")
            assert sha256(raw).hexdigest() == manifest["source_sha256"]
            assert sorted(row["source_line"] for row in manifest["line_map"]) == list(range(1, len(raw.splitlines())+1))
            requested = {(r["home"], r["spelling"]) for r in manifest["requests"]}
            count = scope[label]
            assert len(requested) == len(manifest["requests"]) == count
            assert sha(stem.with_suffix(".lean")) == manifest["probe_sha256"]
            log = stem.with_suffix(".log").read_text()
            assert log.count(f"G06-SEAL-END label={label} requested={count} verified={count}") == 1
            assert stem.with_suffix(".rc").read_text().strip() == "0", (tag, label)
            assert not re.search(r"\.lean:\d+:\d+: error(?:\(|:)", log)
            warnings[tag][label] = re.findall(r"\.lean:\d+:\d+: warning: ([^\n]*)", log)
            seals[tag][label] = {
                "source_path": filename, "source_sha256": manifest["source_sha256"],
                "probe_sha256": manifest["probe_sha256"], "log_sha256": sha(stem.with_suffix(".log")),
                "requests": count, "diagnostics": 0,
            }
            masks[tag][label] = requested
assert len(masks["base-seals"]["DefsSeal"]) == 1314
assert len(masks["head-seals"]["OracleSecuritySeal"]) == 678
assert masks["head-seals"]["OracleSecuritySeal"] <= masks["base-seals"]["DefsSeal"]
assert seals["base-seals"]["DefsSeal"]["source_path"] == legacy + ".lean"
assert seals["head-seals"]["OracleSecuritySeal"]["source_path"] == owner + ".lean"
assert warnings["base-focus"] == warnings["head-focus"]
for label in focus_labels:
    left, right = (seals[side + "-focus"][label] for side in ("base", "head"))
    assert left["source_path"] == right["source_path"]
    if label == "PublicKeyOracleSeal":
        assert left["source_path"] == move["pke"] + ".lean"
        assert left["source_sha256"] != right["source_sha256"]
    else:
        assert left["source_sha256"] == right["source_sha256"]
    base_mask, head_mask = (masks[side + "-focus"][label] for side in ("base", "head"))
    assert len(base_mask) == len(head_mask) == 25
    assert {pairs[row] for row in base_mask} == head_mask

controls = {}
for label, rc in (("UnsealedControl", 0), ("SealedControl", 1), ("ReaderControl", 0)):
    stem = meta / "head-seals" / label
    log = stem.with_suffix(".log").read_text()
    assert int(stem.with_suffix(".rc").read_text()) == rc
    source_hash = sha(stem.with_suffix(".lean"))
    if label != "UnsealedControl":
        manifest = read(stem.with_suffix(".json"))
        assert source_hash == manifest["probe_sha256"]
        assert [r["spelling"] for r in manifest["requests"]] == ["TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen"]
        assert log.count(f"G06-SEAL-END label={label} requested=1 verified=1") == 1
    errors = re.findall(r"\.lean:\d+:\d+: error(?:\([^)]*\))?: ([^\n]+)", log)
    assert len(errors) == rc
    if rc:
        assert "Tactic `rfl` failed" in errors[0] and "decOpen" in log[log.index(errors[0]):]
    controls[label] = {"rc": rc, "log_sha256": sha(stem.with_suffix(".log")), "source_sha256": source_hash}

for side in ("base", "head"):
    log = (area / "read-scan" / side / "scan.log").read_text()
    assert "lemma-list hits: 0\n" in log and "(collector): 0\n" in log, (side, log)
    assert "where the seal failed: 0 " in log
for side in ("base", "head"):
    assert all(row[0] == "INFO" for row in read(area / f"campaign-lint-{side}.json"))
assert "0 findings in 4 files" in (area / "style-head.log").read_text()
archive_dir = campaign / "briefs/pass-shelat-ch5-8/maintainer/cleanup-incremental-2026-11-09/final-r1"
archive = archive_dir / "11-final-read-ledger.zip"
archive_sha = next(line.split()[0] for line in (archive_dir / "SHA256SUMS").read_text().splitlines()
                   if line.endswith("  " + archive.name))
assert sha(archive) == archive_sha
with ZipFile(archive) as zipped:
    ledger = json.loads(zipped.read("deferred-read-ledger-final-r1.json"))
assert len(ledger["current_observations"]) == 813 and not ledger["partial"] and not ledger["needs_review"]
providers = {(r["old_home"], r["old_name"]): (r["new_home"], r["new_name"])
             for r in decls["declarations"] if r["kind"] == "def"}
links = []
for row in ledger["current_observations"]:
    refs = {(p["home"], p["spelling"]) for p in row.get("common_sealed_native_references", [])}
    refs.update((p["head"]["home"], p["head"]["spelling"]) for p in row.get("provider_pairs", [])
                if isinstance(p.get("head"), dict))
    if row["channel"] == "generated-equation":
        refs.add((row["provider_home"], row["provider"]))
    if row["channel"] == "explicit-source":
        refs.add((row["head"]["provider_home"], row["head"]["provider"]))
    for old_home, old_name in sorted(refs & providers.keys()):
        new_home, new_name = providers[old_home, old_name]
        links.append({"id": row["id"], "old_home": old_home, "old_name": old_name,
                      "new_home": new_home, "new_name": new_name})
save(area / "SEALS.json", {"base": base, "head": head, "passed": True, "receipts": seals,
                          "controls": controls, "new_diagnostics": 0, "downstream_consumers": len(focus_labels),
                          "focused_warnings": warnings["head-focus"], "new_campaign_findings": 0})
save(area / "READS.json", {"base": base, "head": head, "ledger_head": ledger["head"],
                          "ledger_archive_sha256": archive_sha, "relocated_provider_links": links,
                          "explicit_foreign_definition_reads": {"base": 0, "head": 0},
                          "generated_foreign_equation_reads": {"base": 0, "head": 0}})
print("12 affected modules and campaign Checks pass. Both owner seals and five pairs of consumer seals pass.")
print(f"The control pair and published reader pass. Mapped {len(links)} deferred provider links.")
