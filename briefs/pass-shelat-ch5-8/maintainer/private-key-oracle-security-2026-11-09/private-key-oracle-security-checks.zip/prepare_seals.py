"""Build owner seals from the checked declarations and their exact import closures."""

from hashlib import file_digest
import importlib.util
import json
from pathlib import Path
import subprocess
import shutil
import sys

sys.dont_write_bytecode = True
area, root = (Path(s).resolve() for s in sys.argv[1:3])
side = sys.argv[3]
assert side in ("Base", "Head")
meta = area / "metadata"
previous = area.parent / "private-key-from-prf-20261109/native"
review = area.parent / "gate06-combined-20261108"
tools = review / "rule10-evidence-r2/tool-inputs"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


bs = load(tools / "build_seals.py", "checked_seals")
controls = load(tools / "build_controls.py", "checked_controls")
adapter = load(tools / "request_payload_adapter.py", "checked_adapter")
bound = load(review / "rule10-payload-retry-r3/bound_payload.py", "checked_bound")
adapter.configure_builders(bs, controls)
seal = bs.seal_command
bs.seal_command = lambda label, req, *, end: bound.bound_payloads(seal(label, req, end=end))
candidate = read(area / "native/PLAN.json")
plan = read(previous / "PLAN.json") if side == "Base" else candidate
with (meta / (side + ".jsonl")).open() as stream:
    rows = [json.loads(line) for line in stream]
complete = rows.pop()
assert complete["record"] == "complete"
catalog = {row["name"]["display"]: row for row in rows if row["record"] == "catalog"}
decls = [row for row in rows if row["record"] == "constant"]
assert len(catalog) == complete["catalog"] and len(decls) == complete["count"]
owners = [row["display"] for row in complete["owners"]]
focused = "--focus" in sys.argv[4:]
dest = meta / (side.lower() + ("-focus" if focused else "-seals"))
dest.mkdir()
masks = {}


def request(row):
    return {"spelling": row["name"]["display"], "home": row["home"]["display"],
            "matcher": row["matcher"], "collector_reducibility": row["status"].rsplit(".", 1)[-1],
            "instance": row["instance"], "abbrev": row["abbrev"],
            "name_components": row["name"]["components"], "home_components": row["home"]["components"],
            "constant_kind": "def"}


def probe(label, raw, requests, **fields):
    out, inserts, lines = bs.instrument(raw, bs.header(raw), label, requests)
    path = dest / (label + ".lean")
    path.write_bytes(out)
    (dest / (label + ".json")).write_text(json.dumps({
        "label": label, "requests": requests, "insertions": inserts, "line_map": lines,
        "probe_sha256": sha(path), **fields,
    }, indent=2) + "\n")
    masks[label] = len(requests)


if focused:
    prefix = "TCSlib/Cryptography/"
    targets = {
        "PRFSchemeSeal": prefix + "Composability/PRFScheme",
        "CCA2SchemeSeal": prefix + "Composability/CCA2Scheme",
        "PublicKeyOracleSeal": prefix + "Encryption/PublicKey/OracleSecurity",
        "NonMalleableSeal": prefix + "Composability/NonMalleable",
        "SimNonMalleableSeal": prefix + "Composability/SimNonMalleable",
    }
    defs = [r for r in decls if r["kind"] == "def"
            and (not r["status"].endswith(".reducible") or r["matcher"])]
    requests = [request(r) for r in sorted(defs, key=lambda r: r["name"]["display"])]
    assert requests
    needed = set()
    for label, module in targets.items():
        path = module + ".lean"
        before = subprocess.check_output(["git", "show", f"{candidate['base']}:{path}"], cwd=root)
        raw = before if side == "Base" else (root / path).read_bytes()
        assert bs.sha(raw) == plan["source_digests"][module], module
        if label != "PublicKeyOracleSeal":
            assert before == raw, module
        closure = set()
        pending = list(plan["graph"][module])
        while pending:
            dep = pending.pop()
            if dep not in closure:
                closure.add(dep)
                pending.extend(plan["graph"][dep])
        assert {r["home"].replace(".", "/") for r in requests} <= closure, module
        needed.update(closure)
        probe(label, raw, requests, source_path=path, source_sha256=bs.sha(raw))
    source_lane = previous if side == "Base" else area / "native"
    products = read(source_lane / "PRODUCTS.json")
    assert needed <= products.keys()
    tree, out = Path(plan["tree"]), dest / "oleans"
    out.mkdir()
    for dep in sorted(needed):
        row = products[dep]
        assert row["source_sha256"] == plan["source_digests"][dep]
        assert row["direct_local"] == {p: products[p]["object_sha256"] for p in plan["graph"][dep]}
        src, dst = (directory / (dep + ".olean") for directory in (tree, out))
        dst.parent.mkdir(parents=True, exist_ok=True)
        assert sha(src) == row["object_sha256"]
        shutil.copyfile(src, dst)
        assert sha(dst) == row["object_sha256"] and not dst.samefile(src)
    for row in plan["external"].values():
        src = Path(row["path"])
        assert sha(src) == row["sha256"]
        if src.is_relative_to(tree):
            dst = out / src.relative_to(tree)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
            assert sha(dst) == row["sha256"]
    (out / "PFR").symlink_to(".lake/packages/PFR/PFR", target_is_directory=True)
    (dest / "SCOPE.json").write_text(json.dumps(masks, indent=2) + "\n")
    print(side, masks, f"using {len(needed)} verified import objects", flush=True)
    sys.exit()

for owner in owners:
    module = owner.replace(".", "/")
    path = module + ".lean"
    raw = (subprocess.check_output(["git", "show", f"{candidate['base']}:{path}"], cwd=root)
           if side == "Base" else (root / path).read_bytes())
    assert bs.sha(raw) == plan["source_digests"][module]
    pending = list(plan["graph"][module])
    closure = set()
    while pending:
        dep = pending.pop()
        if dep not in closure:
            closure.add(dep)
            pending.extend(plan["graph"][dep])
    homes = {dep.replace("/", ".") for dep in closure}
    requests, reducible_other = [], []
    for name, row in sorted(catalog.items()):
        if row["kind"] != "def" or row["home"]["display"] not in homes or name == "Complexity.PolyExpr.eval":
            continue
        if row["status"].endswith(".reducible") and not row["matcher"]:
            if not row["abbrev"]:
                reducible_other.append(name)
            continue
        requests.append(request(row))
    actual = sorted({
        ref["display"] for row in decls if row["home"]["display"] == owner
        for f in ("type_refs", "value_refs") for ref in row[f]
        if ref["display"] in catalog and catalog[ref["display"]]["home"]["display"] in homes
    })
    probe(owner.rsplit(".", 1)[-1] + "Seal", raw, requests, source_path=path,
          source_sha256=bs.sha(raw), actual_foreign_references=actual,
          reducible_non_abbrev=reducible_other)

if side == "Head":
    control = """import TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity

open TCSlib.Cryptography.Composability

example (challenged : Bool) : FixedLengthScheme.decOpen .cpa challenged = false := by
  rfl
""".encode()
    (dest / "UnsealedControl.lean").write_bytes(control)
    requests = [request(catalog["TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen"])]
    probe("SealedControl", control, requests)
    probe("ReaderControl", control.replace(b"  rfl\n", b"  exact FixedLengthScheme.decOpen_cpa challenged\n"), requests)
(dest / "SCOPE.json").write_text(json.dumps(masks, indent=2) + "\n")
print(side, masks, flush=True)
