"""Stage the exact generic oracle game relocation and its import facade."""
import json
from pathlib import Path
import subprocess
import sys

area, repo = (Path(arg).resolve() for arg in sys.argv[1:3])
base = (area / "base.txt").read_text().strip()
crypto = "TCSlib/Cryptography/"
legacy = crypto + "Composability/Defs"
facade = crypto + "Encryption/PrivateKey"
owner = facade + "/OracleSecurity"
pke = crypto + "Encryption/PublicKey/OracleSecurity"
legacy_encryption = crypto + "Asymptotic/Encryption"
scheme = facade + "/Scheme"
negligible = crypto + "Foundations/Negligible"
marker = "namespace TCSlib.Cryptography.Composability\n"


def show(module):
    return subprocess.check_output(["git", "show", f"{base}:{module}.lean"], cwd=repo).decode()


def dot(module):
    return module.replace("/", ".")


def import_line(module):
    return "import " + dot(module) + "\n"


def replace_once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


raw = show(legacy)
game = replace_once(raw, import_line(legacy_encryption), import_line(scheme) + import_line(negligible))
assert game[game.index(marker):] == raw[raw.index(marker):]
compat = raw[:raw.index("import ")] + import_line(legacy_encryption) + import_line(owner)
compat += "\n" + raw[raw.index("set_option "):raw.index("/-!")]
compat += """/-!
# Private-key oracle security compatibility import

## Main definitions

`Encryption.PrivateKey.OracleSecurity` defines the fixed-length scheme interface and the
CPA, CCA1 and CCA2 experiments. The declarations live in `TCSlib.Cryptography.Composability`.

## Main results

This import exposes the oracle equations, the challenge refusal rule and the security
predicate for each attack model.

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010.
  (§7.1.1, Definition 168.1.)
-/
"""
facade_text = replace_once(show(facade), import_line(legacy), import_line(owner))
facade_text = replace_once(facade_text,
    "* `Composability.Defs` gives the fixed-length interface and adaptive oracle games.",
    "* `Encryption.PrivateKey.OracleSecurity` gives the fixed-length interface and adaptive oracle games.")
pke_text = replace_once(show(pke),
    "**Its encoding.** As for Definition 168.1 (`Composability/Defs.lean`): one machine, here run on\n"
    "the input `pk`, plays both phases against two bit-string oracles, `Dec` and `Challenge`. The\n"
    "oracles' state is the challenge, once asked, and it gates `Dec` by phase (`decOpen`).\n",
    "**Its encoding.** As in the private-key game (`Encryption/PrivateKey/OracleSecurity.lean`), one\n"
    "machine plays both phases. It takes `pk` and queries the bit-string oracles `Dec` and `Challenge`.\n"
    "The oracle state records the challenge and uses it to gate `Dec` by phase (`decOpen`).\n")
sources = {owner: game, legacy: compat, facade: facade_text, pke: pke_text}
for module, text in sources.items():
    target = area / "source" / (module + ".lean")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(text.encode())
(area / "MOVE-SCOPE.json").write_text(json.dumps({
    "legacy": legacy, "owner": owner, "facade": facade, "pke": pke,
    "legacy_encryption": legacy_encryption, "scheme": scheme, "negligible": negligible,
}, indent=2) + "\n")
print("Prepared the unchanged oracle declarations, the compatibility import and both entry-point references.")
