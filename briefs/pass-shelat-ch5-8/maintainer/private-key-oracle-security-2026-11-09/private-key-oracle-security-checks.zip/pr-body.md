## Changes

- Move `FixedLengthScheme`, the attack modes and the generic CPA, CCA1 and CCA2 experiments into `Encryption.PrivateKey.OracleSecurity`. The declarations and proof text move verbatim.
- Keep `Composability.Defs` as a compatibility import. The new module imports the scheme interface and game support directly.
- Point the private-key facade and the public-key game’s documentation to the new owner.

## Verification

- All 12 affected modules and the separate campaign Checks replay pass with Lean 4.25.0. The standalone and legacy import probes agree.
- The census matches the types, definition values, elaborated references and axiom sets of all 110 declarations. It accounts for 11 private names and two generated universe binder scopes.
- Both owner seals and the focused seals on five downstream consumers pass. The control blocks direct reduction of `decOpen` and accepts its published CPA equation.
- Source lint, campaign lint and the diff check pass.
