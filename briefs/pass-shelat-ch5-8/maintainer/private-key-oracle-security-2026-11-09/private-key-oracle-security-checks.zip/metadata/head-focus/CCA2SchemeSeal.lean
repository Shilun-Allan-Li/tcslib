/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Composability.Defs
import TCSlib.Cryptography.Asymptotic.CollectionsHelpers
import TCSlib.Cryptography.Asymptotic.PRF
import Mathlib.Tactic.Simps.Basic
/- G06-HARNESS INSTALL CCA2SchemeSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "CCA2SchemeSeal"
  let payload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.Attack.ofNat\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.instDecidableEqAttack\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity"
  let expectedRequests : Nat := 25
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack.ofNat\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"ofNat\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"INDSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"encryptAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"outLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"splitHalf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.instDecidableEqAttack\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"instDecidableEqAttack\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\ttrue\tfalse\tfalse\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# A CCA2-secure private-key scheme (statement phase)

[PS10, Algorithm 169.3] and Theorem 170.4. For a PRF family `{f_k}`:
- `Gen′(1^n)` samples keys `k₁ ← U_n` and `k₂ ← U_{2n}`;
- `Enc′_{k₁,k₂}(m)` samples `r ← U_n`, sets `c₁ = m ⊕ f_{k₁}(r)`, and outputs
  `(r, c₁, f_{k₂}(r ‖ c₁))`;
- `Dec′_{k₁,k₂}(r, c₁, t)` outputs `⊥` unless `f_{k₂}(r ‖ c₁) = t`, and `c₁ ⊕ f_{k₁}(r)` otherwise.

It is the §3.9 scheme with its whole ciphertext `(r, c₁)` tagged under a second key: encrypt, then
authenticate. The tag defeats the mauling attack on the §3.9 scheme (Claim 169.a).

**Source notes: what the tag covers.**
- The algorithm box outputs `(r, c₁, f_{k₂}(c))`, with `c` undefined, while `Dec′` tests
  `f_{k₂}(c₁)`. The proof tags `c₁ ← Enc_{s₁}(m)`, which there names the whole §3.9 ciphertext.
  So the tag covers `(r, c₁)`.
- **Tagging `c₁` alone would not be CCA2-secure.** For positive `n`, choose challenge messages
  `0^n` and `1^n`, obtain `(r*, c₁*, t*)`, and obtain an encryption
  `(r₁, f_{k₁}(r₁), t₁)` of `0^n`. In this short-tag variant the query
  `(r*, f_{k₁}(r₁), t₁)` has a valid tag. If it equals the challenge, do not query it and count
  that branch as attack failure; otherwise its answer `f_{k₁}(r₁) ⊕ f_{k₁}(r*)` reveals the pad
  `f_{k₁}(r*)` and hence `m_b`. Equality can occur, in particular when `r₁ = r*` and `m_b = 0^n`.
  In the random-pad hybrid, nonce equality and accidental masked-message equality have total
  probability at most `2 / 2^n`; the real PRF setting adds a negligible reduction error.
  The attack is therefore overwhelmingly successful, rather than unconditionally query-distinct.
- The input `r ‖ c₁` has `2n` bits. The source's families are length-preserving on `|s|`-bit
  keys, so the tag key `k₂` has `2n` bits and the tag `2n` bits. One family `F` serves both keys,
  at parameters `n` and `2n` (the source names two families, `f` and `g`).
- `Dec′` is specified on well-formed triples. Here total pair projections and the two length
  guards enforce malformed rejection for generated keys when `n > 0`: both ciphertext pair layers
  must parse, and evaluator agreement then forces the valid tag to have `2n` bits. The evaluator
  `E` agrees with `F` only on `⟨s, x⟩` with `|s| = |x|`. At `n = 0`, failed projections can all be
  empty: the malformed four-bit word `0000`, for example, decrypts to the valid empty message.
  This finite-prefix behavior is retained; the malformed-rejection claim is only for positive
  parameters. There is only one plaintext at zero, so this does not change the security statement.

**The encoding.** The key is `⟨k₁, k₂⟩`; `Gen′` reads its `3n` coins as `k₁` (the first `n`)
followed by `k₂`. A ciphertext is `⟨r, ⟨c₁, t⟩⟩`, of `6n + 4` bits.

## Main definitions

* `Composability.ccaGenFun`, `ccaEncFun`, `ccaDecFun`: the three algorithms as string functions.
* `Composability.ccaScheme`: Algorithm 169.3 as a `FixedLengthScheme`, with correctness and the
  ciphertext length proved.

## Main results

* `Composability.ccaScheme_cca2` (Thm 170.4, stated; a `sorry` under the source's sketch).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §7.1.3, Algorithm 169.3 and Theorem 170.4 (book pp. 169–171).
-/

namespace TCSlib.Cryptography.Composability

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games

/-! ### The algorithms as string functions -/

/-- `Gen′` on the layout `⟨⟨⟨1^n, y⟩, α⟩, ρ⟩` with `3n` coins `ρ`: the key `⟨k₁, k₂⟩`, where
`k₁` is the first `n` coins and `k₂` the rest. -/
def ccaGenFun (z : List Bool) : List Bool :=
  pairEncode ((NUPPT.inCoins z).take (NUPPT.inParam z).length)
    ((NUPPT.inCoins z).drop (NUPPT.inParam z).length)

/-- The raw generator pairs the input coins before and after the parameter length:
`⟨ρ.take n, ρ.drop n⟩`. -/
theorem ccaGenFun_eq (z : List Bool) :
    ccaGenFun z =
      pairEncode ((NUPPT.inCoins z).take (NUPPT.inParam z).length)
        ((NUPPT.inCoins z).drop (NUPPT.inParam z).length) := rfl

/-- The first ciphertext part `c₁ = m ⊕ E(⟨k₁, r⟩)` of `Enc′`, on the layout
`⟨⟨⟨1^n, ⟨⟨k₁, k₂⟩, m⟩⟩, α⟩, r⟩`. -/
def ccaMaskFun (E : List Bool → List Bool) (z : List Bool) : List Bool :=
  List.zipWith xor (pairSndD (NUPPT.inArg z))
    (E (pairEncode (pairFstD (pairFstD (NUPPT.inArg z))) (NUPPT.inCoins z)))

/-- The raw ciphertext mask is the decoded message XOR the evaluator's output on the first
key and the input coins [PS10, Algorithm 169.3]. -/
theorem ccaMaskFun_eq (E : List Bool → List Bool) (z : List Bool) :
    ccaMaskFun E z =
      List.zipWith xor (pairSndD (NUPPT.inArg z))
        (E (pairEncode (pairFstD (pairFstD (NUPPT.inArg z))) (NUPPT.inCoins z))) := rfl

/-- `Enc′` on the layout `⟨⟨⟨1^n, ⟨⟨k₁, k₂⟩, m⟩⟩, α⟩, r⟩`: the ciphertext
`⟨r, ⟨c₁, E(⟨k₂, r ++ c₁⟩)⟩⟩` with `c₁ = m ⊕ E(⟨k₁, r⟩)`. -/
def ccaEncFun (E : List Bool → List Bool) (z : List Bool) : List Bool :=
  pairEncode (NUPPT.inCoins z)
    (pairEncode (ccaMaskFun E z)
      (E (pairEncode (pairSndD (pairFstD (NUPPT.inArg z)))
        (NUPPT.inCoins z ++ ccaMaskFun E z))))

/-- Raw encryption returns the nonce, the masked message, and the tag of their concatenation
under the second key [PS10, Algorithm 169.3]. -/
theorem ccaEncFun_eq (E : List Bool → List Bool) (z : List Bool) :
    ccaEncFun E z =
      pairEncode (NUPPT.inCoins z)
        (pairEncode (ccaMaskFun E z)
          (E (pairEncode (pairSndD (pairFstD (NUPPT.inArg z)))
            (NUPPT.inCoins z ++ ccaMaskFun E z)))) := rfl

/-- The test of `Dec′` on the layout `⟨⟨⟨1^n, ⟨⟨k₁, k₂⟩, ⟨r, ⟨c₁, t⟩⟩⟩⟩, α⟩, r'⟩`: `r` and `c₁`
have `n` bits, and the tag is valid, `E(⟨k₂, r ++ c₁⟩) = t`. -/
def ccaDecOK (E : List Bool → List Bool) (z : List Bool) : Bool :=
  decide ((pairFstD (pairSndD (NUPPT.inArg z))).length = (NUPPT.inParam z).length) &&
    decide ((pairFstD (pairSndD (pairSndD (NUPPT.inArg z)))).length =
      (NUPPT.inParam z).length) &&
    decide (E (pairEncode (pairSndD (pairFstD (NUPPT.inArg z)))
        (pairFstD (pairSndD (NUPPT.inArg z)) ++ pairFstD (pairSndD (pairSndD (NUPPT.inArg z))))) =
      pairSndD (pairSndD (pairSndD (NUPPT.inArg z))))

/-- The raw decryption guard conjoins the two parameter-length checks with equality of the
computed and supplied tags [PS10, Algorithm 169.3]. -/
theorem ccaDecOK_eq (E : List Bool → List Bool) (z : List Bool) :
    ccaDecOK E z = (
      decide ((pairFstD (pairSndD (NUPPT.inArg z))).length = (NUPPT.inParam z).length) &&
        decide ((pairFstD (pairSndD (pairSndD (NUPPT.inArg z)))).length =
          (NUPPT.inParam z).length) &&
        decide (E (pairEncode (pairSndD (pairFstD (NUPPT.inArg z)))
            (pairFstD (pairSndD (NUPPT.inArg z)) ++
              pairFstD (pairSndD (pairSndD (NUPPT.inArg z))))) =
          pairSndD (pairSndD (pairSndD (NUPPT.inArg z))))) := rfl

/-- `Dec′` on the layout `⟨⟨⟨1^n, ⟨⟨k₁, k₂⟩, ⟨r, ⟨c₁, t⟩⟩⟩⟩, α⟩, r'⟩`: `c₁ ⊕ E(⟨k₁, r⟩)` when
the test passes, and otherwise `⊥`, here `1^{n+1}`, which decodes to no `n`-bit message. -/
def ccaDecFun (E : List Bool → List Bool) (z : List Bool) : List Bool :=
  if ccaDecOK E z then
    List.zipWith xor (pairFstD (pairSndD (pairSndD (NUPPT.inArg z))))
      (E (pairEncode (pairFstD (pairFstD (NUPPT.inArg z))) (pairFstD (pairSndD (NUPPT.inArg z)))))
  else true :: NUPPT.inParam z

/-- Raw decryption XORs the first ciphertext component with the first-key pad when
`ccaDecOK` holds, and returns `true :: NUPPT.inParam z` otherwise [PS10, Algorithm 169.3]. -/
theorem ccaDecFun_eq (E : List Bool → List Bool) (z : List Bool) :
    ccaDecFun E z =
      if ccaDecOK E z then
        List.zipWith xor (pairFstD (pairSndD (pairSndD (NUPPT.inArg z))))
          (E (pairEncode (pairFstD (pairFstD (NUPPT.inArg z)))
            (pairFstD (pairSndD (NUPPT.inArg z)))))
      else true :: NUPPT.inParam z := rfl

/-! ### Efficiency -/

/-- `Gen′` is polynomial-time: a split of the coins at `n` (`polyTimeComputable_pairTakePoly`). -/
theorem polyTimeComputable_ccaGenFun : PolyTimeComputable ccaGenFun := by
  have hp := NUPPT.polyTimeComputable_inParam.pairEncode NUPPT.polyTimeComputable_inCoins
  convert ((polyTimeComputable_pairTakePoly .var).comp hp).pairEncode
    ((polyTimeComputable_pairDropPoly .var).comp hp) using 1
  funext z
  simp [ccaGenFun, Function.comp_apply]

/-- The mask `c₁` is polynomial-time when `E` is. -/
theorem polyTimeComputable_ccaMaskFun {E : List Bool → List Bool} (hE : PolyTimeComputable E) :
    PolyTimeComputable (ccaMaskFun E) := by
  have h := polyTimeComputable_pairXor.comp
    ((polyTimeComputable_pairSndD.comp NUPPT.polyTimeComputable_inArg).pairEncode
      (hE.comp (((polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD).comp
        NUPPT.polyTimeComputable_inArg).pairEncode NUPPT.polyTimeComputable_inCoins)))
  convert h using 1
  funext z
  simp [ccaMaskFun, Function.comp_apply]

/-- `Enc′` is polynomial-time when `E` is. -/
theorem polyTimeComputable_ccaEncFun {E : List Bool → List Bool} (hE : PolyTimeComputable E) :
    PolyTimeComputable (ccaEncFun E) := by
  have hm := polyTimeComputable_ccaMaskFun hE
  have h := NUPPT.polyTimeComputable_inCoins.pairEncode (hm.pairEncode
    (hE.comp (((polyTimeComputable_pairSndD.comp polyTimeComputable_pairFstD).comp
      NUPPT.polyTimeComputable_inArg).pairEncode (NUPPT.polyTimeComputable_inCoins.append hm))))
  convert h using 1

/-- The test of `Dec′` is polynomial-time when `E` is: two length comparisons and one equality
(`polyTimeComputable_lenEq`, `polyTimeComputable_pairEq`).

**Proof sketch.** Project the nonce, encrypted message, tag and second key from the layout.
Two polynomial-time length comparisons check that the nonce and encrypted message each have
`n` bits. Append these two words and evaluate the tag under the second key, using composition
with the polynomial-time evaluator. A word-equality test compares this result with the supplied
tag; Boolean conjunction combines that test with the two length checks. -/
theorem polyTimeComputable_ccaDecOK {E : List Bool → List Bool} (hE : PolyTimeComputable E) :
    PolyTimeComputable (fun z => [ccaDecOK E z]) := by
  have hl : ∀ g : List Bool → List Bool, PolyTimeComputable g →
      PolyTimeComputable (fun z => [decide ((g z).length = (NUPPT.inParam z).length)]) := by
    intro g hg
    convert polyTimeComputable_lenEq.comp (hg.pairEncode NUPPT.polyTimeComputable_inParam)
      using 1
    funext z
    simp [Function.comp_apply]
  have hArg := NUPPT.polyTimeComputable_inArg
  have hc₁ : PolyTimeComputable fun z => pairFstD (pairSndD (pairSndD (NUPPT.inArg z))) :=
    ((polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD).comp
      polyTimeComputable_pairSndD).comp hArg
  have hc₂ : PolyTimeComputable fun z => pairSndD (pairSndD (pairSndD (NUPPT.inArg z))) :=
    ((polyTimeComputable_pairSndD.comp polyTimeComputable_pairSndD).comp
      polyTimeComputable_pairSndD).comp hArg
  have hr : PolyTimeComputable fun z => pairFstD (pairSndD (NUPPT.inArg z)) :=
    (polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD).comp hArg
  have htag : PolyTimeComputable fun z =>
      [decide (E (pairEncode (pairSndD (pairFstD (NUPPT.inArg z)))
          (pairFstD (pairSndD (NUPPT.inArg z)) ++
            pairFstD (pairSndD (pairSndD (NUPPT.inArg z))))) =
        pairSndD (pairSndD (pairSndD (NUPPT.inArg z))))] := by
    convert polyTimeComputable_pairEq.comp ((hE.comp
      (((polyTimeComputable_pairSndD.comp polyTimeComputable_pairFstD).comp hArg).pairEncode
        (hr.append hc₁))).pairEncode hc₂) using 1
    funext z
    simp [Function.comp_apply]
  exact polyTimeComputable_and (polyTimeComputable_and (hl _ hr) (hl _ hc₁)) htag

/-- `Dec′` is polynomial-time when `E` is. -/
theorem polyTimeComputable_ccaDecFun {E : List Bool → List Bool} (hE : PolyTimeComputable E) :
    PolyTimeComputable (ccaDecFun E) := by
  refine polyTimeComputable_ite (polyTimeComputable_ccaDecOK hE) ?_
    ((polyTimeComputable_const [true]).append NUPPT.polyTimeComputable_inParam)
  have hArg := NUPPT.polyTimeComputable_inArg
  have h := polyTimeComputable_pairXor.comp
    ((((polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD).comp
      polyTimeComputable_pairSndD).comp hArg).pairEncode
      (hE.comp (((polyTimeComputable_pairFstD.comp polyTimeComputable_pairFstD).comp
        hArg).pairEncode ((polyTimeComputable_pairFstD.comp polyTimeComputable_pairSndD).comp
          hArg))))
  convert h using 1
  funext z
  simp [Function.comp_apply]

/-! ### The machines -/

section Machines

variable {E : List Bool → List Bool} (hE : PolyTimeComputable E)

/-- The machine `Gen′`, with `3n` coins. -/
noncomputable abbrev ccaGen : NUPPT :=
  NUPPT.ofPolyTimeUniform polyTimeComputable_ccaGenFun (.mul (.const 3) .var)

/-- The machine `Enc′`, with `n` coins. -/
noncomputable abbrev ccaEnc : NUPPT :=
  NUPPT.ofPolyTimeUniform (polyTimeComputable_ccaEncFun hE) .var

/-- The machine `Dec′`, deterministic. -/
noncomputable abbrev ccaDec : NUPPT :=
  NUPPT.ofPolyTimeUniform (polyTimeComputable_ccaDecFun hE) (.const 0)

/-- `Gen′` splits its `3n` coins at `n`. -/
theorem runAt_ccaGen (n : ℕ) (ρ : ccaGen.Coins n) :
    ccaGen.runAt n [] ρ = pairEncode ((List.ofFn ρ).take n) ((List.ofFn ρ).drop n) := by
  rw [NUPPT.runAt_eq, NUPPT.runAtL_ofPolyTimeUniform]
  simp [ccaGenFun, NUPPT.inCoins_eq, NUPPT.inParam_eq, NUPPT.advInput_eq]

/-- `Enc′` on `⟨⟨k₁, k₂⟩, m⟩` with coins `r` is `⟨r, ⟨c₁, E(⟨k₂, r ++ c₁⟩)⟩⟩`,
`c₁ = m ⊕ E(⟨k₁, r⟩)`. -/
theorem runAt_ccaEnc (n : ℕ) (k₁ k₂ m : List Bool) (r : (ccaEnc hE).Coins n) :
    (ccaEnc hE).runAt n (pairEncode (pairEncode k₁ k₂) m) r =
      pairEncode (List.ofFn r)
        (pairEncode (List.zipWith xor m (E (pairEncode k₁ (List.ofFn r))))
          (E (pairEncode k₂
            (List.ofFn r ++ List.zipWith xor m (E (pairEncode k₁ (List.ofFn r))))))) := by
  rw [NUPPT.runAt_eq, NUPPT.runAtL_ofPolyTimeUniform]
  simp [ccaEncFun, ccaMaskFun, NUPPT.inArg_eq, NUPPT.inCoins_eq, NUPPT.advInput_eq]

/-- `Dec′` on `⟨⟨k₁, k₂⟩, ⟨r, ⟨c₁, t⟩⟩⟩` with `n`-bit `r` and `c₁` and a valid tag is
`c₁ ⊕ E(⟨k₁, r⟩)`. -/
theorem runAt_ccaDec (n : ℕ) (k₁ k₂ r c₁ t : List Bool) (hr : r.length = n)
    (hc₁ : c₁.length = n) (htag : E (pairEncode k₂ (r ++ c₁)) = t) (r' : (ccaDec hE).Coins n) :
    (ccaDec hE).runAt n (pairEncode (pairEncode k₁ k₂) (pairEncode r (pairEncode c₁ t))) r' =
      List.zipWith xor c₁ (E (pairEncode k₁ r)) := by
  rw [NUPPT.runAt_eq, NUPPT.runAtL_ofPolyTimeUniform]
  simp [ccaDecFun, ccaDecOK, NUPPT.inArg_eq, NUPPT.inParam_eq, NUPPT.advInput_eq,
    hr, hc₁, htag]

end Machines

/-! ### The scheme -/

variable (F : ∀ n, (Fin n → Bool) → (Fin n → Bool) → (Fin n → Bool))
  (E : List Bool → List Bool) (hE : PolyTimeComputable E)
  (hFE : ∀ n (s x : Fin n → Bool), E (pairEncode (List.ofFn s) (List.ofFn x)) =
    List.ofFn (F n s x))

include hFE in
/-- On two `n`-bit strings, `E` returns `n` bits (it agrees with `F`). -/
theorem length_eval_of_length {n : ℕ} {a b : List Bool} (ha : a.length = n)
    (hb : b.length = n) : (E (pairEncode a b)).length = n := by
  have hA : List.ofFn (padFin n a) = a := by
    simpa only [ha, Nat.sub_self, List.replicate_zero, List.append_nil] using
      (Collection.ofFn_padFin_of_le (ℓ := n) ha.le)
  have hB : List.ofFn (padFin n b) = b := by
    simpa only [hb, Nat.sub_self, List.replicate_zero, List.append_nil] using
      (Collection.ofFn_padFin_of_le (ℓ := n) hb.le)
  rw [← hA, ← hB, hFE, List.length_ofFn]

/-- XOR-ing twice with the same pad, at least as long as the message, is the identity. -/
private theorem zipWith_xor_xor_self' : ∀ (m p : List Bool), m.length ≤ p.length →
    List.zipWith xor (List.zipWith xor m p) p = m
  | [], _, _ => by simp
  | _ :: _, [], h => by simp at h
  | a :: m, b :: p, h => by
    simp only [List.zipWith_cons_cons, List.cons.injEq]
    exact ⟨by cases a <;> cases b <;> rfl, zipWith_xor_xor_self' m p (by simpa using h)⟩

/-- **`π′`** [PS10, Algorithm 169.3], for a family `F` with evaluator `E`: the §3.9 scheme under
the `n`-bit key `k₁`, its ciphertext `(r, c₁)` tagged with `f_{k₂}(r ‖ c₁)` under the `2n`-bit key
`k₂`. Ciphertexts have `6n + 4` bits. -/
noncomputable def ccaScheme : FixedLengthScheme where
  gen := ccaGen
  enc := ccaEnc hE
  dec := ccaDec hE
  gen_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  enc_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  dec_uniform := NUPPT.ofPolyTimeUniform_uniform _ _
  correct := by
    intro n m rg re rd
    have hρ : (List.ofFn rg).length = 3 * n := by
      rw [List.length_ofFn, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform,
        PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
    have hk₁ : ((List.ofFn rg).take n).length = n := by simp [hρ]; omega
    have hr : (List.ofFn re).length = n := by
      rw [List.length_ofFn, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform,
        PolyExpr.eval_var]
    have hp := length_eval_of_length F E hFE hk₁ hr
    have hc₁ : (List.zipWith xor (List.ofFn m) (E (pairEncode ((List.ofFn rg).take n)
        (List.ofFn re)))).length = n := by simp [hp]
    rw [runAt_ccaGen, runAt_ccaEnc, runAt_ccaDec hE n _ _ _ _ _ hr hc₁ rfl,
      zipWith_xor_xor_self' _ _ (by simp [hp]), decodeFin_ofFn]
  ctLen := .add (.mul (.const 6) .var) (.const 4)
  enc_length := by
    intro n rg m r
    show ((ccaEnc hE).runAt n (pairEncode (ccaGen.runAt n [] rg) (List.ofFn m)) r).length = _
    have hρ : (List.ofFn rg).length = 3 * n := by
      rw [List.length_ofFn, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform,
        PolyExpr.eval_mul, PolyExpr.eval_const, PolyExpr.eval_var]
    have hk₁ : ((List.ofFn rg).take n).length = n := by simp [hρ]; omega
    have hk₂ : ((List.ofFn rg).drop n).length = 2 * n := by simp [hρ]; omega
    have hr : (List.ofFn r).length = n := by
      rw [List.length_ofFn, NUPPT.coinLen_eq, NUPPT.coins_ofPolyTimeUniform,
        PolyExpr.eval_var]
    have hp := length_eval_of_length F E hFE hk₁ hr
    have hc₁ : (List.zipWith xor (List.ofFn m) (E (pairEncode ((List.ofFn rg).take n)
        (List.ofFn r)))).length = n := by simp [hp]
    have hrc : (List.ofFn r ++ List.zipWith xor (List.ofFn m) (E (pairEncode
        ((List.ofFn rg).take n) (List.ofFn r)))).length = 2 * n := by
      rw [List.length_append, hr, hc₁]; ring
    have ht := length_eval_of_length F E hFE hk₂ hrc
    rw [runAt_ccaGen, runAt_ccaEnc]
    simp only [length_pairEncode, hr, hc₁, ht, PolyExpr.eval_add, PolyExpr.eval_mul,
      PolyExpr.eval_const, PolyExpr.eval_var]
    omega

attribute [simps (config := { isSimp := false }) gen enc dec ctLen] ccaScheme

/-- **Theorem 170.4: `π′` is CCA2-secure** [PS10, Theorem 170.4] when `F` is a pseudorandom
function family.

**Proof sketch** (the source's, made explicit).
1. Replace `f_{k₂}` by a random function `RF` on `2n` bits: by PRF security at parameter `2n`,
   the advantage changes by a negligible amount. The reduction samples `k₁` itself and answers
   `Enc′` and `Dec′` with its oracle in place of `f_{k₂}`. T2
   (`Games.exists_interactiveHandlerMachine`) implements the forwarding handler with `k₁`
   in its seed, the input-free companion supplies its machine input, and T4
   (`Games.exists_toOracleAdversary_of_bitCodec`) provides the oracle adversary at length
   `2n`.
2. For positive `n`, call a `Dec′` query `(r, c₁, t)` *fresh* if `(r, c₁)` is not the
   ciphertext part of an earlier `Enc′` or challenge answer. Compare with a game that always
   rejects fresh-pair queries. Couple both games with the same tapes and `RF`: they agree until
   the first fresh-pair query with a valid tag. In the always-reject game, prior rejected guesses
   reveal no value of `RF` at such a pair. Each guess therefore hits that unrevealed uniform
   `2n`-bit value with probability at most `2^{-2n}`, even if the pair was queried before. The union bound
   gives a first-discrepancy probability at most `q(n)/2^{2n}` in each bit-game. This does not
   assert the same conditional probability after failed guesses in the original game.
   A nonfresh valid-tag query is an earlier answer itself: canonical parsing and the tag's
   dependence on `(r, c₁)` make it the refused challenge or an encryption of a chosen message.
3. The always-reject game is simulated by a CPA adversary against the §3.9 scheme under `k₁`:
   `Enc′` answers come from the CPA encryption oracle, tagged by a lazily sampled `RF`; `Dec′`
   answers come from the table of earlier answers, or are `⊥`. Up to fixed constant factors
   when combining the two bit-games, the advantage is bounded by the CPA advantage
   (`prfFixedScheme_cpa`), the first-discrepancy term `q(n)/2^{2n}`, and the PRF advantage.
   Each is negligible; the zero-parameter behavior described above changes no asymptotic claim.

The source's simulator tags with fresh uniform strings rather than a lazily sampled `RF`. The two
differ only when two answers share `(r, c₁)`, a collision of the `n`-bit `r`, of probability at
most `q(n)²/2^n`. -/
theorem ccaScheme_cca2 (hF : PRF F) : (ccaScheme F E hE hFE).INDSecure .cca2 := by
  sorry

end TCSlib.Cryptography.Composability
/- G06-HARNESS EOF-VERIFY CCA2SchemeSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "CCA2SchemeSeal"
  let payload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.Attack.ofNat\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\nTCSlib.Cryptography.Composability.instDecidableEqAttack\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\tTCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity"
  let expectedRequests : Nat := 25
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack.ofNat\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"ofNat\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"INDSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"encryptAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"outLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"splitHalf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.instDecidableEqAttack\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"instDecidableEqAttack\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\ttrue\tfalse\tfalse\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Encryption\"],[\"str\",\"PrivateKey\"],[\"str\",\"OracleSecurity\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

