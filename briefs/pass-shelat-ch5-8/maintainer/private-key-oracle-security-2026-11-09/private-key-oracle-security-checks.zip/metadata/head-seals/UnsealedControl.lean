import TCSlib.Cryptography.Encryption.PrivateKey.OracleSecurity

open TCSlib.Cryptography.Composability

example (challenged : Bool) : FixedLengthScheme.decOpen .cpa challenged = false := by
  rfl
