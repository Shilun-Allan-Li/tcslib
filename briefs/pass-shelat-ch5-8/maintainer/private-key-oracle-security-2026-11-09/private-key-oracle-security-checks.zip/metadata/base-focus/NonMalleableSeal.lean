/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import TCSlib.Cryptography.Composability.PublicKey
/- G06-HARNESS INSTALL NonMalleableSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "NonMalleableSeal"
  let payload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.Attack.ofNat\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.instDecidableEqAttack\tTCSlib.Cryptography.Composability.Defs\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\tTCSlib.Cryptography.Composability.Defs\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\tTCSlib.Cryptography.Composability.Defs\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\tTCSlib.Cryptography.Composability.Defs"
  let expectedRequests : Nat := 25
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack.ofNat\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"ofNat\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"INDSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"encryptAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"outLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"splitHalf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.instDecidableEqAttack\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"instDecidableEqAttack\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\ttrue\tfalse\tfalse\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Non-malleable encryption (statement phase)

[PS10, Definition 172.6] and Theorem 175.9, over the public-key experiment of Definition 171.5
(`Composability/PublicKey.lean`).

**The experiment** `NM_b(Π, A, n)`: `(pk, sk) ← Gen(1^n)`; `(m₀, m₁, state) ← A^{O₁}(1^n, pk)`;
`c ← Enc_pk(m_b)`; `(c'₁, …, c'_ℓ) ← A^{O₂}(c, state)`; output `(m'₁, …, m'_ℓ)` with
`m'_i = ⊥` if `c'_i = c` and `m'_i = Dec_sk(c'_i)` otherwise. The scheme is non-malleable when,
for every adversary `A` and distinguisher `D`, `D` tells `NM_0` from `NM_1` with negligible
advantage.

**Its encoding.** The oracles and the phases are those of Definition 171.5 (`indImpl`). The
adversary's final output is `ℓ(n)` ciphertexts of `ctLen(n)` bits. Each decryption is encoded as
`Dec`'s oracle answers are (`decAnswer`): a validity flag and the message, all-`false` for `⊥`.
`D` receives their concatenation.

**Source notes.**
- The definition writes private-key notation (`k ← Gen(1^n)`, `Dec_k`) for a public-key scheme;
  the public-key reading is taken (inventory Def-172.6).
- The source leaves the oracles `O₁, O₂` open; they are parametrized by the attack, as in
  Definition 171.5. Theorem 175.9's "CCA2 non-malleability" is the CCA2 instance.
- The adversary chooses `m₀, m₁`, so the definition's closing "for all `m₀, m₁ ∈ {0,1}^n`" is
  dropped. At CPA this is [PSV06, Definition 3], by the source's authors (ruling of 2026-11-05):
  the adversary picks `m₀, m₁` after seeing `pk`, `D` sees only the decryptions, and a copy of
  the challenge and an invalid ciphertext both decrypt to `⊥`.
- [PSV07, Definition 3] (IND-NME′) allows many challenges and distinguishes `COPY` from
  an invalid ciphertext's `⊥`; it is not literally the many-message form of this encoding.
  For the one-challenge security comparison, the complementary-pair copy-flag export argument
  is in the maintainer's sketch of `FixedLengthPKScheme.simNMSecure_of_nmSecure_cpa`
  (`SimNonMalleable.lean`). It separates `L = msgLen(n) = 0`, when the two experiments
  coincide, from `L > 0`, when the complementary plaintexts differ and their encrypted pair
  exports each copy flag. This is a security comparison of the one-challenge conventions;
  no many-challenge bridge is claimed here.
- Definition 173.7 and Theorem 174.8 follow [PSV07] (same ruling), in
  `Composability/SimNonMalleable.lean`.

## Main definitions

* `FixedLengthPKScheme.nmGame`, `FixedLengthPKScheme.NMSecure`: [PS10, Definition 172.6].

## Main results

* `FixedLengthPKScheme.indSecure_cca2_iff_nmSecure_cca2` (Thm 175.9, stated; a `sorry` under the
  source's sketch).

## References

* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  §7.1.5 and §7.1.7, Definition 172.6 and Theorem 175.9 (book pp. 172–175).
* [PSV06] R. Pass, a. shelat, V. Vaikuntanathan, *Construction of a non-malleable encryption
  scheme from any semantically secure one*, CRYPTO 2006, LNCS 4117, pp. 271–289: Definition 3.
* [PSV07] R. Pass, a. shelat, V. Vaikuntanathan, *Relations among notions of non-malleability for
  encryption*, ASIACRYPT 2007, LNCS 4833, pp. 519–535: Definition 3.
-/

namespace TCSlib.Cryptography.Composability

open Complexity Turing TCSlib.Cryptography TCSlib.Cryptography.Games

namespace FixedLengthPKScheme

variable (S : FixedLengthPKScheme)

/-- The codec of the adversary: the oracles of Definition 171.5, and a final output of `ℓ`
ciphertexts. -/
def nmCodec (n ℓ : ℕ) : MachineCodec (S.indSpec n) (Fin (ℓ * S.ctLen.eval n) → Bool) :=
  bitCodec (S.inLens n) (S.outLens n) (ℓ * S.ctLen.eval n)

/-- The non-malleability codec uses `decodeBitMove` with the scheme's oracle lengths and an
output of `ℓ * ctLen(n)` bits. -/
theorem nmCodec_decodeMove (n ℓ : ℕ) (w : List Bool) :
    (S.nmCodec n ℓ).decodeMove w =
      decodeBitMove (S.inLens n) (S.outLens n) (ℓ * S.ctLen.eval n) w :=
  bitCodec_decodeMove (S.inLens n) (S.outLens n) (ℓ * S.ctLen.eval n) w

/-- The non-malleability codec encodes a log entry `(i, x, y)` as `⟨1^i, ⟨x, y⟩⟩`. -/
theorem nmCodec_encodeEntry (n ℓ : ℕ)
    (e : Σ i, (S.indSpec n).dom i × (S.indSpec n).rng i) :
    (S.nmCodec n ℓ).encodeEntry e =
      pairEncode (List.replicate e.1 true) (pairEncode (List.ofFn e.2.1) (List.ofFn e.2.2)) :=
  bitCodec_encodeEntry (S.inLens n) (S.outLens n) (ℓ * S.ctLen.eval n) e

/-- When its query budget expires, the non-malleability codec returns `zeroBits (ℓ * ctLen(n))`.
-/
theorem nmCodec_timeout (n ℓ : ℕ) :
    (S.nmCodec n ℓ).timeout = zeroBits (ℓ * S.ctLen.eval n) :=
  bitCodec_timeout (S.inLens n) (S.outLens n) (ℓ * S.ctLen.eval n)

/-- The `i`-th of the `ℓ` ciphertexts in the adversary's output. -/
def nthCt {n ℓ : ℕ} (w : Fin (ℓ * S.ctLen.eval n) → Bool) (i : Fin ℓ) :
    Fin (S.ctLen.eval n) → Bool :=
  fun j => w (finProdFinEquiv (i, j))

/-- Ciphertext `i` is the block whose bit `j` is output bit `finProdFinEquiv (i, j)`. -/
theorem nthCt_eq {n ℓ : ℕ} (w : Fin (ℓ * S.ctLen.eval n) → Bool) (i : Fin ℓ) :
    S.nthCt w i = fun j => w (finProdFinEquiv (i, j)) := rfl

/-- The decryption `m'` of an output ciphertext `c'` against the recorded challenge `s`: `⊥` if
`c'` is the challenge, and `Dec_sk(c')` otherwise, encoded as `Dec`'s oracle answers are. -/
def nmDecrypt {n : ℕ} (sk : List Bool) (s : Option (Fin (S.ctLen.eval n) → Bool))
    (c' : Fin (S.ctLen.eval n) → Bool) : Fin (S.msgLen.eval n + 1) → Bool :=
  if s = some c' then zeroBits _
  else FixedLengthScheme.decAnswer (decodeFin _ (S.dec (pairEncode sk (List.ofFn c'))))

/-- An output ciphertext decrypts to all-false bits when it copies the challenge, and to the
encoded decryption answer otherwise [PS10, Definition 172.6]. -/
theorem nmDecrypt_eq {n : ℕ} (sk : List Bool) (s : Option (Fin (S.ctLen.eval n) → Bool))
    (c' : Fin (S.ctLen.eval n) → Bool) :
    S.nmDecrypt sk s c' =
      if s = some c' then zeroBits (S.msgLen.eval n + 1)
      else FixedLengthScheme.decAnswer
        (decodeFin (S.msgLen.eval n) (S.dec (pairEncode sk (List.ofFn c')))) := rfl

/-- The output of `NM_b`: the concatenated decryptions of the adversary's `ℓ` ciphertexts. -/
def nmOutput {n ℓ : ℕ} (sk : List Bool) (s : Option (Fin (S.ctLen.eval n) → Bool))
    (w : Fin (ℓ * S.ctLen.eval n) → Bool) : List Bool :=
  (List.ofFn fun i : Fin ℓ => List.ofFn (S.nmDecrypt sk s (S.nthCt w i))).flatten

/-- The non-malleability output flattens the encoded decryptions of all `ℓ` output blocks. -/
theorem nmOutput_eq {n ℓ : ℕ} (sk : List Bool)
    (s : Option (Fin (S.ctLen.eval n) → Bool)) (w : Fin (ℓ * S.ctLen.eval n) → Bool) :
    S.nmOutput sk s w =
      (List.ofFn fun i : Fin ℓ => List.ofFn (S.nmDecrypt sk s (S.nthCt w i))).flatten := rfl

/-- **The experiment `NM_b(Π, A, n)`** [PS10, Definition 172.6] for the attack `atk`, with query
budget `q` and `ℓ` output ciphertexts, followed by the distinguisher `D`: sample the keys and the
coins, run `A` on `pk` against the oracles of Definition 171.5, decrypt its output (`⊥` on a copy
of the challenge), and output `D`'s verdict on the decryptions. -/
noncomputable def nmGame (atk : Attack) (A : NUPPT) (q ℓ : ℕ) (D : NUPPT) (b : Bool) (n : ℕ) :
    ProbComp Bool :=
  (ProbComp.sample (S.gen.Coins n)).bind fun rg =>
  (ProbComp.sample (A.Coins n)).bind fun r =>
  (ProbComp.sample (D.Coins n)).bind fun ρ =>
  (simulate (S.indImpl atk b n (pairFstD (S.gen.runAt n [] rg)) (pairSndD (S.gen.runAt n [] rg)))
      (A.toCompOn (S.nmCodec n ℓ) n q (pairFstD (S.gen.runAt n [] rg)) r) none).bind
    fun res =>
      .pure (D.distinguisherL n (S.nmOutput (pairSndD (S.gen.runAt n [] rg)) res.2 res.1) ρ)

/-- The non-malleability experiment samples keys and both machines' coins, runs the adversary
against the IND oracles, and applies the distinguisher to its decrypted output
[PS10, Definition 172.6]. -/
theorem nmGame_eq (atk : Attack) (A : NUPPT) (q ℓ : ℕ) (D : NUPPT) (b : Bool) (n : ℕ) :
    S.nmGame atk A q ℓ D b n =
      (ProbComp.sample (S.gen.Coins n)).bind (fun rg =>
      (ProbComp.sample (A.Coins n)).bind fun r =>
      (ProbComp.sample (D.Coins n)).bind fun ρ =>
      (simulate
          (S.indImpl atk b n (pairFstD (S.gen.runAt n [] rg)) (pairSndD (S.gen.runAt n [] rg)))
          (A.toCompOn (S.nmCodec n ℓ) n q (pairFstD (S.gen.runAt n [] rg)) r) none).bind
        fun res =>
          .pure (D.distinguisherL n (S.nmOutput (pairSndD (S.gen.runAt n [] rg)) res.2 res.1) ρ)) :=
  rfl

/-- **Non-malleability** [PS10, Definition 172.6] under the attack `atk`: for every non-uniform
PPT adversary `A`, every polynomial query budget `q` and number `ℓ` of output ciphertexts, and
every non-uniform PPT distinguisher `D`, `D`'s advantage between `NM_0` and `NM_1` is
negligible. -/
def NMSecure (atk : Attack) : Prop :=
  ∀ (A : NUPPT) (q ℓ : PolyExpr) (D : NUPPT), ∃ ε : ℕ → ℝ, Negligible ε ∧
    ∀ n, advantage (S.nmGame atk A (q.eval n) (ℓ.eval n) D false n)
      (S.nmGame atk A (q.eval n) (ℓ.eval n) D true n) ≤ ε n

/-- Non-malleability holds exactly when every adversary, polynomial query and output budgets,
and distinguisher have a negligible bound on the two games' advantage
[PS10, Definition 172.6]. -/
theorem NMSecure_iff (atk : Attack) :
    S.NMSecure atk ↔
      ∀ (A : NUPPT) (q ℓ : PolyExpr) (D : NUPPT), ∃ ε : ℕ → ℝ, Negligible ε ∧
        ∀ n, advantage (S.nmGame atk A (q.eval n) (ℓ.eval n) D false n)
          (S.nmGame atk A (q.eval n) (ℓ.eval n) D true n) ≤ ε n := Iff.rfl

/-- A copy of the challenge decrypts to `⊥`. -/
theorem nmDecrypt_challenge {n : ℕ} (sk : List Bool) (c : Fin (S.ctLen.eval n) → Bool) :
    S.nmDecrypt sk (some c) c = zeroBits _ := by
  simp [nmDecrypt]

/-- **Theorem 175.9: under CCA2, secrecy and non-malleability coincide** [PS10, Theorem 175.9].

**Proof sketch** (the source's, made explicit).
1. (⇒) Given an NM adversary `A` with `ℓ` ciphertexts and a distinguisher `D`, the IND
   adversary runs `A`, then asks CCA2's `Dec` for each of `A`'s ciphertexts. `Dec` refuses the
   challenge with the same `⊥` that `NM` assigns to its copies (`indImpl_dec_cca2_challenge`,
   `nmDecrypt_challenge`), so the answers are exactly `NM_b`'s output. It runs `D` on them and
   outputs `D`'s verdict. T2 (`Games.exists_interactiveHandlerMachine`) supplies
   `advIn = pk`, forwards decryption queries, and uses `finCall = ℓ` in finalization before
   running `D`, for total budget `q + ℓ`. Advice is carried through `z` and the public
   `exists_withAdvice`/`exists_comp` closure lemmas. The advantage is unchanged.
2. (⇐) Given an IND adversary `A` with guess `g`, the NM adversary runs `A` and outputs fresh
   encryptions of `g^{msgLen}` and `(¬g)^{msgLen}` (it holds `pk`). The two plaintexts differ, so
   by correctness at most one of the two ciphertexts is the challenge. The distinguisher reads
   `g` from the first if it decrypts, and from the second otherwise. Same advantage; at
   `msgLen(n) = 0` there is nothing to distinguish.

The source's sketch argues the contrapositives: an NM break yields a related ciphertext that
`Dec` decrypts, and an IND break lets the adversary decrypt and re-encrypt a related message. -/
theorem indSecure_cca2_iff_nmSecure_cca2 : S.INDSecure .cca2 ↔ S.NMSecure .cca2 := by
  sorry

end FixedLengthPKScheme

end TCSlib.Cryptography.Composability
/- G06-HARNESS EOF-VERIFY NonMalleableSeal -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "NonMalleableSeal"
  let payload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.Attack.ofNat\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\tTCSlib.Cryptography.Composability.Defs\nTCSlib.Cryptography.Composability.instDecidableEqAttack\tTCSlib.Cryptography.Composability.Defs\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\tTCSlib.Cryptography.Composability.Defs\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\tTCSlib.Cryptography.Composability.Defs\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\tTCSlib.Cryptography.Composability.Defs"
  let expectedRequests : Nat := 25
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Composability.Attack._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.Attack.ofNat\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Attack\"],[\"str\",\"ofNat\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.INDSecure\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"INDSecure\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decAnswer.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decAnswer\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.encryptAt\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"encryptAt\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.inLens.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"inLens\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indCodec\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indCodec\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indGame\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indGame\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\ttrue\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.Composability.FixedLengthScheme.outLens\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"outLens\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.FixedLengthScheme.splitHalf\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"splitHalf\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Composability.instDecidableEqAttack\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"instDecidableEqAttack\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\ttrue\tfalse\tfalse\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.decOpen.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"decOpen\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_1.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_1\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue\n_private.TCSlib.Cryptography.Composability.Defs.0.TCSlib.Cryptography.Composability.FixedLengthScheme.indImpl.match_3.splitter\t[[\"str\",\"_private\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"],[\"num\",\"0\"],[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"FixedLengthScheme\"],[\"str\",\"indImpl\"],[\"str\",\"match_3\"],[\"str\",\"splitter\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Composability\"],[\"str\",\"Defs\"]]\tfalse\tfalse\ttrue"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

