#!/usr/bin/env bash
set -euo pipefail
area=$1
repo=$2
side=$3
deadline=$((SECONDS+180))
until [ -f "$area/native/RESULT.json" ] && [ -f "$area/metadata/${side}Census.rc" ]; do
    test "$SECONDS" -lt "$deadline"
    sleep 2
done
test "$(cat "$area/metadata/${side}Census.rc")" = 0
cmp scripts/lean_check_tree.sh "$repo/scripts/lean_check_tree.sh"
toolchain="$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["toolchain"])' "$area/native/PLAN.json")"
python3 -I "$area/prepare_seals.py" "$area" "$repo" "$side" --focus
lower="$(printf '%s' "$side" | tr '[:upper:]' '[:lower:]')"
target="$area/metadata/$lower-focus"
probes=()
for src in "$target"/*Seal.lean; do
    probes+=("${src%.lean}")
done
bash "$area/run_probes.sh" "$toolchain" "$target/oleans" "${probes[@]}"
