import sys, zipfile, os, hashlib
d=sys.argv[1]
tot_bad=0
for f in sorted(os.listdir(d)):
    if not f.endswith('.zip'): continue
    z=zipfile.ZipFile(os.path.join(d,f))
    ent={}
    for l in open(os.path.join(d,f[:-4]+'.entries.txt'),encoding='utf-8'):
        p,s,h=l.rstrip('\n').split('\t'); ent[p]=(int(s),h)
    infos=[i for i in z.infolist() if not i.filename.endswith('/')]
    bad=[]
    for i in infos:
        e=ent.get(i.filename)
        if e is None: bad.append(('extra',i.filename)); continue
        h=hashlib.sha256()
        with z.open(i) as fh:
            for b in iter(lambda: fh.read(1<<20), b''): h.update(b)
        if e!=(i.file_size,h.hexdigest()): bad.append(('mismatch',i.filename))
    missing=set(ent)-{i.filename for i in infos}
    tot_bad+=len(bad)+len(missing)
    print(f, 'entries',len(infos),'list',len(ent),'bad',len(bad),'missing',len(missing), bad[:3])
print('TOTAL_BAD',tot_bad)
