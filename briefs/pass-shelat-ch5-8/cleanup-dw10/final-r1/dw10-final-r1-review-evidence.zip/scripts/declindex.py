import subprocess,re,sys,json
repo,base,out=sys.argv[1:4]
files=subprocess.run(['git','-C',repo,'ls-tree','-r','--name-only',base,'TCSlib'],capture_output=True,text=True).stdout.split()
files=[f for f in files if f.endswith('.lean')]
DECL=re.compile(r'^\s*(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|partial|unsafe|nonrec)\s+)*(theorem|lemma|def|abbrev|instance|structure|class|inductive|opaque|axiom)\s+([^\s:({\[⦃]+)')
NS=re.compile(r'^\s*namespace\s+(\S+)'); END=re.compile(r'^\s*end\s+(\S+)'); SEC=re.compile(r'^\s*(?:noncomputable\s+)?section\b\s*(\S*)')
idx={}
p=subprocess.Popen(['git','-C',repo,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for f in files:
    p.stdin.write(f'{base}:{f}\n'.encode()); p.stdin.flush()
    hdr=p.stdout.readline().split(); n=int(hdr[2]); data=p.stdout.read(n); p.stdout.read(1)
    stack=[]
    for i,l in enumerate(data.decode('utf-8','replace').splitlines(),1):
        m=NS.match(l)
        if m: stack.append(('ns',m.group(1))); continue
        m=SEC.match(l)
        if m and not l.strip().startswith('sectionX'): stack.append(('sec',m.group(1))); continue
        m=END.match(l) or (re.match(r'^\s*end\s*$',l) and None)
        if re.match(r'^\s*end\b',l):
            if stack: stack.pop()
            continue
        m=DECL.match(l)
        if m:
            nm=m.group(2)
            ns='.'.join(x for k,x in stack if k=='ns')
            full=nm[6:] if nm.startswith('_root_.') else (ns+'.'+nm if ns else nm)
            idx.setdefault(full,[]).append((f,i,m.group(1)))
json.dump(idx,open(out,'w'))
print(len(files),len(idx))
