import csv,sys,json,random,subprocess,collections as C,re
E,invf,repo,out=sys.argv[1:5]
base='f472accd5e000a53d0fbe02b5414435429ce4a70'
inv=list(csv.DictReader(open(invf,encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
se=[json.loads(l) for l in open(E+'/seal-errors.jsonl')]
bydecl=C.defaultdict(list)
for x in se: bydecl[(x['path'],x['declaration'])].append(x)
scan=C.defaultdict(list)
for r in csv.DictReader(open(E+'/scan.tsv',encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE):
    if r['foreign']=='yes': scan[(r['path'],r['declaration'])].append(r)
random.seed(20261117)
def pick(cond,n):
    c=[r for r in inv if cond(r)]; return random.sample(c,min(n,len(c)))
S=[]
S+=pick(lambda r:r['class']=='STAGE2' and r['fix'].startswith('use') and r['channel']=='seal',9)
S+=pick(lambda r:r['class']=='STAGE2' and r['fix'].startswith('use') and r['channel']=='unfold',4)
S+=pick(lambda r:r['class']=='STAGE2' and r['fix'].startswith('add'),8)
S+=pick(lambda r:r['class']=='STAGE2' and r['fix'].split()[0] in('bridge','proof-only','proof-only:','restate','prove','give','reader'),3)
S+=pick(lambda r:r['pending']=='#347',1)
S+=pick(lambda r:r['class']=='STAGE2-PROVIDER-READER',4)
S+=pick(lambda r:r['class']=='SEAL-B-ONLY',5)
S+=pick(lambda r:r['class'].startswith('STRICT-ONLY'),4)
S+=pick(lambda r:r['class']=='STATEMENT',3)
S+=pick(lambda r:r['status']=='FIXED_SINCE' and r['change'].startswith('moved'),2)
S+=pick(lambda r:r['status']=='FIXED_SINCE' and not r['change'].startswith('moved'),2)
S+=pick(lambda r:r['status']=='CHANGED' and r['class']!='-',2)
srcs={}
def src(p):
    if p not in srcs: srcs[p]=subprocess.run(['git','-C',repo,'show',f'{base}:{p}'],capture_output=True).stdout.decode().splitlines()
    return srcs[p]
o=open(out,'w')
for r in S:
    o.write(f"\n=== {r['item_id']} [{r['class']}] {r['status']} {r['base_path'][7:]} :: {r['declaration']}\n")
    o.write(f"counts sA/sB/cA/cB {r['strict_A']}/{r['strict_B']}/{r['coe_A']}/{r['coe_B']} scan={r['scan'][:150]} stmt={r['statement_level']} change={r['change'][:150]}\nrecord={r['record'][:250]}\nFIX={r['fix'][:600]}\n")
    errs=bydecl.get((r['base_path'],r['declaration']),[])
    vs=sorted(errs,key=lambda x:(['coe-A','strict-A','coe-B','strict-B'].index(x['variant']),x['source_line']))
    shown=set()
    for x in vs[:3]:
        if x['source_line'] in shown: continue
        shown.add(x['source_line'])
        msg=x['message'].split('\n')
        o.write(f" ERR {x['variant']} l.{x['source_line']}:{x['col']} cascade={x['cascade']} prov={x['providers'][:5]} :: {' / '.join(msg[:4])[:400]}\n")
        s=src(r['base_path']); L=x['source_line']
        for k in range(max(1,L-2),min(len(s),L+1)+1): o.write(f"   {k}: {s[k-1][:200]}\n")
    for sc in scan.get((r['base_path'],r['declaration']),[])[:2]:
        L=int(sc['line']); s=src(r['base_path'])
        o.write(f" SCAN l.{L} {sc['tactic']} {sc['item']} ({sc['home']})\n   {L}: {s[L-1][:200]}\n")
o.close()
print(len(S))
