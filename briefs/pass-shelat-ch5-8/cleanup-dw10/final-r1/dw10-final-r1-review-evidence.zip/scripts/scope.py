import csv,sys,collections as C
inv,I=sys.argv[1:3]
rows={r['item_id']:r for r in csv.DictReader(open(inv,encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE)}
def rd(f): return list(csv.DictReader(open(f'{I}/{f}',encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
m=C.Counter(); bp=C.Counter(); ex=[]
for r in rd('ledger-historical.tsv'):
    i=f'H:{r["row"]}'; v=rows[i]; m[('H',r['scope'],r['base_match'],v['status'])]+=1
    if r['base_path'] not in ('',v['base_path']): bp['H']+=1; ex.append((i,r['base_path'],v['base_path'],v['change'][:80]))
for r in rd('ledger-current.tsv'):
    v=rows[r['id']]; m[('C',r['scope'],r['base_match'],v['status'])]+=1
    if r['base_path'] not in ('',v['base_path']): bp['C']+=1; ex.append((r['id'],r['base_path'],v['base_path'],v['change'][:80]))
for r in rd('provider-pairs.tsv'):
    i=('EFF72:' if r['set'].startswith('eff') else 'LEV52:')+r['id']; v=rows[i]; m[('P',r['set'],r['scope'],v['status'])]+=1
cnt=C.Counter()
for r in rd('named-findings.tsv'):
    cnt[r['finding']]+=1; i=f"{r['finding']}:{cnt[r['finding']]}"; v=rows[i]
    m[('N',r['finding'],r['scope'],v['status'])]+=1
    if v['declaration']!=r['declaration']: ex.append(('NAMEDDECL',i,r['declaration'],v['declaration']))
for k in sorted(m): print(k,m[k])
print('base_path differs',bp); print(ex[:20])
