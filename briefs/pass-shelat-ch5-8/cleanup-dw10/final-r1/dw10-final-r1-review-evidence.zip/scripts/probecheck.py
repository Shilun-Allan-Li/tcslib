import zipfile,sys,json,hashlib,subprocess,collections as C,csv
E,repo,base=sys.argv[1:4]
recs=json.load(open(E+'/seals/dedup.json'))
zs=[zipfile.ZipFile(E+f'/zip/seals-records.part0{i}.zip') for i in (1,2)]
idx={}
for z in zs:
    for n in z.namelist(): idx[n]=z
def src(path):
    return subprocess.run(['git','-C',repo,'show',f'{base}:{path}'],capture_output=True,check=True).stdout
cache={}
bad=C.Counter(); ex=[]
probe_by_mod={}
keys=set()
for r in recs: keys|=set(r)
print(sorted(keys))
for r in recs:
    v=r['variant']; lab=r['label']
    cands=[n for n in idx if n.startswith(f'seals/records/{v}/{r["batch"]}/{lab}.lean.txt')]
    if len(cands)!=1: bad['noprobe']+=1; ex.append(('noprobe',v,lab)); continue
    b=idx[cands[0]].read(cands[0])
    h=hashlib.sha256(b).hexdigest()
    if h!=r['probe_sha256']: bad['sha']+=1; ex.append(('sha',v,lab))
    probe_by_mod[r['probe_module']]=b
    p=r['path']
    if p not in cache: cache[p]=src(p).decode().splitlines()
    S=cache[p]; P=b.decode().splitlines()
    i=0; extra=[]
    for j,l in enumerate(P):
        if i<len(S) and l==S[i]: i+=1
        else: extra.append(j)
    if i!=len(S): bad['srcmissing']+=1; ex.append(('srcmiss',v,lab,len(S)-i))
    r['_b']=b
# dedup equality
for r in recs:
    d=r.get('dedup_with') or r.get('deduplicated_with')
    if d and d!='-':
        o=probe_by_mod.get(d)
        if o is None: bad['dedup_target_missing']+=1; continue
        nb=r['_b'].replace(b'SealB_',b'SealA_'); no=o.replace(b'SealB_',b'SealA_')
        if nb!=no: bad['dedup_differs']+=1; ex.append(('dd',r['probe_module'],d))
        else: bad['dedup_ok']+=1
print(dict(bad)); print(ex[:10])
