import csv, sys, collections as C
inv=sys.argv[1]; I=sys.argv[2]
rows=list(csv.DictReader(open(inv,encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
print('rows',len(rows), 'ncols', set(len(r) for r in rows))
ids=[r['item_id'] for r in rows]; print('dup ids', [k for k,v in C.Counter(ids).items() if v>1][:5])
def rd(f): return list(csv.DictReader(open(f'{I}/{f}',encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
H=rd('ledger-historical.tsv'); Cu=rd('ledger-current.tsv'); P=rd('provider-pairs.tsv'); N=rd('named-findings.tsv')
print('inputs',len(H),len(Cu),len(P),len(N))
exp=set(f'H:{r["row"]}' for r in H)|set(r['id'] for r in Cu)
pp=set()
for r in P:
    pref='EFF72' if r['set'].startswith('eff') else 'LEV52'; pp.add(f'{pref}:{r["id"]}')
print('pp distinct',len(pp))
exp|=pp
nf=C.Counter(r['finding'] for r in N); print('named',nf)
invset=set(ids)
nonnew=[i for i in ids if not i.startswith('NEW:')]
print('non-new rows',len(nonnew))
print('expected-not-in-inv',sorted(exp-invset)[:10], len(exp-invset))
extra=[i for i in nonnew if i not in exp and not i.split(':')[0] in ('SG-F07','SY-F07','C-F02')]
print('extra non-new not expected',extra[:10],len(extra))
print(C.Counter(i.split(':')[0] if ':' in i else i.split('-')[0] for i in ids))
print('status by source'); t=C.Counter((r['source'],r['status']) for r in rows)
for k in sorted(t): print(' ',k,t[k])
print('class x tier'); t=C.Counter((r['tier'],r['class']) for r in rows if r['status'] not in ('HANDED-OFF','FIXED_SINCE'))
for k in sorted(t): print(' ',k,t[k])
print('class all',C.Counter(r['class'] for r in rows))
print('status for class -:',C.Counter(r['status'] for r in rows if r['class']=='-'))
print('pending',C.Counter(r['pending'] for r in rows)); print('known',C.Counter(r['known_record'] for r in rows))
print('stmt_level',C.Counter((r['statement_level'],r['class']) for r in rows if r['statement_level']=='yes'))
print('channel',C.Counter((r['source'],r['channel']) for r in rows))
# provider pair: same SEAL id status?
st={r['item_id']:r['status'] for r in rows}
mm=[(i,st[i],st.get(i.split(':')[1])) for i in ids if i.startswith(('EFF72','LEV52')) and st[i]!=st.get(i.split(':')[1])]
print('pair status != SEAL id status',mm[:10],len(mm))
