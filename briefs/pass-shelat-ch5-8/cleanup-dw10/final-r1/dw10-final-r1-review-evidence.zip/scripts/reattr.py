import zipfile,sys,json,re,subprocess,collections as C,csv
E,repo,base,out=sys.argv[1:5]
recs=json.load(open(E+'/seals/dedup.json'))
zs=[zipfile.ZipFile(E+f'/zip/seals-records.part0{i}.zip') for i in (1,2)]
idx={n:z for z in zs for n in z.namelist()}
zr=zipfile.ZipFile(E+'/zip/seals-runs.part01.zip')
R=re.compile(r'^(\S+)\.lean:(\d+):(\d+): error[:(]')
DECL=re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|partial|unsafe|nonrec)\s+)*(theorem|lemma|def|abbrev|instance|structure|class|inductive|opaque|example)\b\s*([^\s:({\[⦃]*)')
srcs={}
def src(p):
    if p not in srcs: srcs[p]=subprocess.run(['git','-C',repo,'show',f'{base}:{p}'],capture_output=True,check=True).stdout.decode().splitlines()
    return srcs[p]
def decl_at(S,line):
    for i in range(line-1,-1,-1):
        m=DECL.match(S[i])
        if m: return m.group(2) or '<anon>', i+1
    return None,None
res=[]
runs={}
for r in recs:
    if r['run_module']!=r['probe_module']: continue
    runs[r['run_module']]=r
for m,r in runs.items():
    logn='seals/runs/mods/'+m.replace('/','_')+'.log'
    t=zr.read(logn).decode('utf-8','replace').splitlines()
    errs=[(int(mm.group(2)),int(mm.group(3))) for l in t for mm in [R.match(l)] if mm]
    if not errs: continue
    pn=[n for n in idx if n.startswith(f'seals/records/{r["variant"]}/{r["batch"]}/{r["label"]}.lean.txt')][0]
    P=idx[pn].read(pn).decode().splitlines(); S=src(r['path'])
    mp={}; i=0
    for j,l in enumerate(P,1):
        if i<len(S) and l==S[i]: i+=1; mp[j]=i
    for (pl,col) in errs:
        sl=mp.get(pl)
        d,dl=decl_at(S,sl) if sl else (None,None)
        res.append(dict(run=m,variant=r['variant'],path=r['path'],probe_line=pl,source_line=sl,decl=d,decl_line=dl))
json.dump(res,open(out,'w'))
# compare with seal-errors.jsonl (run_module, probe_line)
se=[json.loads(l) for l in open(E+'/seal-errors.jsonl')]
key=C.Counter((x['run_module'],x['probe_line'],x['col']) for x in se)
mine=C.Counter((x['run'],x['probe_line'],None) for x in res)
print('my errors',len(res),'theirs',len(se))
sed={}
for x in se: sed.setdefault((x['run_module'],x['probe_line']),[]).append(x)
agree=C.Counter(); ex=[]
for x in res:
    ys=sed.get((x['run'],x['probe_line']))
    if not ys: agree['missing']+=1; ex.append(('miss',x)); continue
    y=ys[0]
    if y['source_line']!=x['source_line']: agree['srcline_diff']+=1; ex.append(('sl',x,y['source_line']))
    dn=(y['declaration'] or '').split('.')[-1]
    if x['decl'] and (x['decl'].split('.')[-1]==dn): agree['decl_ok']+=1
    else: agree['decl_diff']+=1; ex.append(('decl',x['path'][7:],x['source_line'],x['decl'],y['declaration']))
print(dict(agree))
for e in ex[:40]: print(e)
