import json,sys,subprocess,re,collections as C,csv
E,repo,invf=sys.argv[1:4]
base='f472accd5e000a53d0fbe02b5414435429ce4a70'
se=[json.loads(l) for l in open(E+'/seal-errors.jsonl')]
inv=list(csv.DictReader(open(invf,encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
DECL=re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|partial|unsafe|nonrec)\s+)*(theorem|lemma|def|abbrev|instance|structure|class|inductive|opaque|example)\b')
srcs={}
def S(p):
    if p not in srcs: srcs[p]=subprocess.run(['git','-C',repo,'show',f'{base}:{p}'],capture_output=True).stdout.decode().splitlines()
    return srcs[p]
def header(s,line):
    # find decl start at or before line (skip docstring-at-start case)
    st=None
    l0=line
    if s[line-1].lstrip().startswith(('/--','@[')):
        for i in range(line-1,min(line+40,len(s))):
            if DECL.match(s[i]): st=i+1; break
    if st is None:
        for i in range(line-1,-1,-1):
            if DECL.match(s[i]): st=i+1; break
    if st is None: return None
    kind=DECL.match(s[st-1]).group(1)
    # header end: first ':=' or ' where' or '|' at line start after st (outside comments, naive)
    depth=0
    for j in range(st-1,min(st+80,len(s))):
        t=s[j]
        if j>st-1 and re.match(r'^\s*\|',t) and depth==0: return (st,j+1,0,kind)
        i=0
        while i<len(t):
            c=t[i]
            if t.startswith('--',i): break
            if c in '([{⟨⦃': depth+=1
            elif c in ')]}⟩⦄': depth-=1
            elif depth==0 and t.startswith(':=',i): return (st,j+1,i,kind)
            elif depth==0 and re.match(r'where\b',t[i:]) and (i==0 or not (t[i-1].isalnum() or t[i-1] in "_.'")): return (st,j+1,i,kind)
            i+=1
    return (st,None,None,kind)
res=C.Counter(); stmt_rows=C.defaultdict(set)
for x in se:
    if x['source_line'] is None or x['declaration'].startswith('<'): continue
    s=S(x['path']); h=header(s,x['source_line'])
    if not h or h[1] is None: res['nohdr']+=1; continue
    st,he,hc,kind=h
    L=x['source_line']; col=x['col']
    inhdr = (L < he) or (L==he and col < hc)
    if L>=st and inhdr and not s[L-1].lstrip().startswith(('/--','@[')):
        stmt_rows[(x['path'],x['declaration'])].add((x['variant'],x['cascade']))
        res[('in-header',x['variant'],kind)]+=1
    elif s[L-1].lstrip().startswith(('/--','@[')): res[('at-docstring',x['variant'])]+=1
    else: res['body']+=1
for k,v in sorted(res.items(),key=str): print(k,v)
byk={}
for r in inv:
    if r['channel']=='seal': byk.setdefault((r['base_path'],r['declaration']),[]).append(r)
print('\n(path,decl) with header errors:',len(stmt_rows))
for k,vs in sorted(stmt_rows.items()):
    rows=byk.get(k,[])
    cl=sorted(set((r['class'],r['statement_level']) for r in rows))
    print(k[0][7:],k[1].split('.')[-1],sorted(vs),cl,[r['item_id'] for r in rows][:4])
