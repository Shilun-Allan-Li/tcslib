import csv,sys,json,re,collections as C
invf,E,I,idxf,outdir=sys.argv[1:6]
inv=list(csv.DictReader(open(invf,encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
idx=json.load(open(idxf))
own={l.split('\t')[0]:l.split('\t')[1] for l in open(I+'/owners.txt') if not l.startswith('#') and l.strip()}
lo=set(l.strip().split('\t')[0] for l in open(I+'/list-only.txt') if l.strip() and not l.startswith('#'))
sd={}
for r in csv.DictReader(open(E+'/seal-decls.tsv',encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE):
    sd[(r['path'],r['declaration'],r['variant'])]=r
ops={r['key']:r for r in csv.DictReader(open(E+'/review/open-items.tsv',encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE)}
notes={}
for f in ('overrides-lead.tsv','overrides-sub-A.tsv','overrides-sub-B.tsv','overrides-lead-delta.tsv'):
    for r in csv.DictReader(open(E+'/review/'+f,encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE):
        if r['key'] in ops: notes[ops[r['key']]['item_id']]=r['note']
# maintainer corrections (review findings)
CORR={
 'H:127':("add TCSlib.Cryptography.FunFamily.ofString_inLen ((ofString f p).inLen = .var, by rfl) in TCSlib/Cryptography/Asymptotic/OneWay.lean next to ofString_inLen_eval; then prove family_inLen by unfold family (own-file definition, not sealed) and ofString_inLen","DW10-F05"),
 'SEAL-0298':("add TCSlib.Cryptography.FunFamily.ofString_inLen ((ofString f p).inLen = .var, by rfl) in TCSlib/Cryptography/Asymptotic/OneWay.lean next to ofString_inLen_eval; then prove family_inLen by unfold family (own-file definition, not sealed) and ofString_inLen","DW10-F05"),
 'C3-0004':("add Complexity.polyTimeComputable_iterateFind_elim (hypotheses of polyTimeComputable_iterateFind; conclusion PolyTimeComputable fun x => ((List.range (R.eval x.length + 1)).find? (fun i => acc (g^[i] x))).elim [] (fun i => out (g^[i] x))) in TCSlib/Complexity/Randomized/Repetition.lean; then PolyTimeComputable.congr and a case split on the local match (as for the GGM/Reduction rows)","DW10-F06"),
}
TENT=re.compile(r'to be identified|to be confirmed|most likely|candidate:',re.I)
ID=r"[A-Za-z_][\w'!?₀-₉]*(?:\.[A-Za-z_][\w'!?₀-₉]*)*"
PATHRE=re.compile(r'(TCSlib/[\w/]+\.lean|(?<![\w/])(?:[A-Z][\w]*/)+[A-Z][\w]*\.lean)')
allfiles=set(f for v in idx.values() for f,_,_ in v)
def normpath(p):
    if p.startswith('TCSlib/'): return p
    c=[f for f in allfiles if f.endswith('/'+p)]
    return c[0] if len(c)==1 else '?'+p
def tier(p): return own.get(p,'HANDED' if p in lo else ('NONE' if p.startswith('?') else 'NOT-OWNER'))
suf=C.defaultdict(set)
for k in idx:
    ps=k.split('.')
    for i in range(len(ps)): suf['.'.join(ps[i:])].add(k)
def resolve_def(name):
    # strip trailing _suffix pieces until a def is found
    n=name
    while True:
        for k in sorted(suf.get(n,())):
            for f,l,kind in idx[k]:
                if kind in('def','abbrev','structure','inductive','class','instance'): return k,f
        if '_' not in n.split('.')[-1]: return None,None
        n=n.rsplit('_',1)[0]
def balanced(s,i):
    d=0
    for j in range(i,len(s)):
        if s[j]=='(': d+=1
        elif s[j]==')':
            d-=1
            if d==0: return s[i+1:j],j+1
    return s[i+1:],len(s)
def parse_adds(fix):
    out=[]
    for m in re.finditer(r'\badd\b',fix):
        seg=fix[m.end():]
        # stop at ';' at depth 0 or ' use ' or ' then '
        d=0; end=len(seg)
        for j,c in enumerate(seg):
            if c=='(': d+=1
            elif c==')': d-=1
            elif c==';' and d==0: end=j; break
        seg=seg[:end]
        pm=PATHRE.search(seg); home=normpath(pm.group(1)) if pm else None
        nx=re.search(r'next to ('+ID+')',seg)
        pos=0; names=[]; last=None
        while pos<len(seg):
            mm=re.match(r'\s*(?:and|,|also|plus)?\s*(?:a body-form next reader|a body-form|the field equations|the)?\s*('+ID+r'|_[\w\']+)',seg[pos:])
            if not mm: break
            tok=mm.group(1); pos+=mm.end()
            if tok in('in','next','to','there','for','then','with','or','to','the','a') : break
            if tok.startswith('_') and last: tok=last.rsplit('_',1)[0]+tok
            if not re.search(r'[_.]',tok) or tok.endswith('.lean'): break
            st=''
            mm2=re.match(r'\s*\(',seg[pos:])
            if mm2:
                st,j=balanced(seg,pos+mm2.end()-1); pos=j
            names.append((tok,st.strip())); last=tok
        for tok,st in names:
            h=home
            if h is None and nx:
                k,f=resolve_def(nx.group(1)); h=f
            if h is None:
                k,f=resolve_def(tok); h=f
            out.append((tok,st,h))
    return out
def fullname(tok,decl):
    if tok in idx: return tok
    for pre in ('TCSlib.Cryptography.','Complexity.','Turing.','TCSlib.InformationTheory.'):
        if (pre+tok) in idx: return pre+tok
    k,f=resolve_def(tok)
    if k:
        ns=k.rsplit('.',1)[0]
        last=tok.split('.')[-1]
        # keep the namespace path the token gives, anchored at the def's namespace
        return ns+'.'+last
    return tok
def kind(r,fix):
    f=fix.lstrip()
    if r['class']=='STAGE2-PROVIDER-READER': return 'ADD-PROVIDER-READER'
    if f.startswith('bridge') or 'prove ' in f and '= GI.' in f or 'transport' in f: return 'BRIDGE-SHADOW (W6)'
    if re.search(r'\badd\b',f): return 'ADD-READER'
    if f.startswith('use') or f.startswith('l.') and 'use' in f: return 'USE-PUBLISHED'
    return 'PROOF-ONLY'
def read_of(r):
    if r['channel']=='seal':
        x=sd.get((r['base_path'],r['declaration'],'coe-A'))
        if x: return f"coe-A l.{x['first_error_source_line']}: {x['message_class']}; providers {x['providers'] or '-'}"
        return r['record']
    return r['scan']
rows=[]; readers=C.OrderedDict()
for r in inv:
    if r['class'] not in('STAGE2','STAGE2-PROVIDER-READER'): continue
    if r['pending']=='#347': continue
    fix,corr=CORR.get(r['item_id'],(r['fix'],'-'))
    k=kind(r,fix)
    adds=parse_adds(fix) if k!='USE-PUBLISHED' else []
    conf='needs-check' if (TENT.search(fix) or 'check' in notes.get(r['item_id'],'').lower()) else 'settled'
    rd_names=[]; rd_home=[]; rd_stmt=[]
    if 'case equations of Turing.pairDecode' in fix:
        adds=[('Turing.pairDecode_cons_cons (case equations: false::false::r, true::true::r, false::true::r, [b], true::false::r; names fixed in Stage 2)', 'pairDecode (false :: false :: r) = (pairDecode r).map (fun p => (false :: p.1, p.2)); the same for true :: true; pairDecode (false :: true :: r) = some ([], r); pairDecode [b] = none; pairDecode (true :: false :: r) = none', 'TCSlib/Complexity/TuringMachine/Encoding.lean')]
    for tok,st,h in adds:
        fn=fullname(tok,r['declaration']) if not tok.startswith('Turing.pairDecode_cons_cons') else tok
        if fn.startswith('Ensemble.'): fn='TCSlib.Cryptography.'+fn
        if fn in idx and any(kd=='theorem' for _,_,kd in idx[fn]): continue  # already published: mentioned for use
        rd_names.append(fn); rd_home.append(h or '?'); rd_stmt.append(st or '-')
        key=fn
        e=readers.setdefault(key,dict(reader=fn,home=h or '?',statement=st or '-',items=[],files=set(),kinds=set(),w6=False))
        if e['statement']=='-' and st: e['statement']=st
        if e['home'] in('?',None) and h: e['home']=h
        e['items'].append(r['item_id']); e['files'].add(r['base_path']); e['kinds'].add(k)
        if k.startswith('BRIDGE') or '.GI.' in fn or 'ColProofs' in fn or 'ColSimMachine' in fn or 'GIZK' in fn: e['w6']=True
    owner=r['base_path']
    rows.append(dict(owner_file=owner,owner_tier=r['tier'],area='/'.join(owner.split('/')[1:3]),item_id=r['item_id'],source=r['source'],channel=r['channel'],
        declaration=r['declaration'],status=r['status'],failing_read=read_of(r).replace('\t',' '),fix_kind=k,
        new_readers=' ; '.join(rd_names) or '-',reader_homes=' ; '.join(rd_home) or '-',reader_statements=' ; '.join(rd_stmt) or '-',
        fix=fix.replace('\t',' '),fix_confidence=conf,w6_dependent='yes' if k.startswith('BRIDGE') or any(('.GI.' in n or 'ColProofs' in n or 'ColSimMachine' in n or 'GIZK.' in n) for n in rd_names) else 'no',
        maintainer_correction=corr,known_record=r['known_record'],work_unit=f"{owner}|{r['declaration']}|{r['channel']}"))
rows.sort(key=lambda x:(x['owner_file'],x['declaration'],x['channel'],x['item_id']))
cols=list(rows[0].keys())
with open(outdir+'/stage2-seal-items.tsv','w',encoding='utf-8') as f:
    f.write('\t'.join(cols)+'\n')
    for x in rows: f.write('\t'.join(str(x[c]) for c in cols)+'\n')
rc=['reader','home','home_tier','q1_flag','statement','statement_complete','w6_dependent','fix_kinds','owner_files','n_items','item_ids']
with open(outdir+'/stage2-readers.tsv','w',encoding='utf-8') as f:
    f.write('\t'.join(rc)+'\n')
    for e in sorted(readers.values(),key=lambda e:(e['home'],e['reader'])):
        t=tier(e['home'])
        q1='PROVIDER (Complexity library outside the campaign; Q1: Seyoon decides placement)' if t in('HANDED','NOT-OWNER') and ('Complexity/' in e['home']) else ('CHECK-HOME' if t not in('T1','T2') else '-')
        inc=re.search(r'^-$|<|defining equations|the unfolded|as the |match the|^= ',e['statement'])
        f.write('\t'.join([e['reader'],e['home'],t,q1,e['statement'].replace('\t',' '),'no' if inc else 'yes','yes' if e['w6'] else 'no',','.join(sorted(e['kinds'])),' ; '.join(sorted(p[7:] for p in e['files'])),str(len(e['items'])),','.join(e['items'])])+'\n')
print('items',len(rows),'readers',len(readers))
print(C.Counter(x['fix_kind'] for x in rows)); print(C.Counter(x['fix_confidence'] for x in rows)); print(C.Counter(x['w6_dependent'] for x in rows))
print('ADD rows with no reader parsed',[x['item_id'] for x in rows if x['fix_kind'] in('ADD-READER','ADD-PROVIDER-READER','BRIDGE-SHADOW (W6)') and x['new_readers']=='-'])
print('work units',len(set(x['work_unit'] for x in rows)),'files',len(set(x['owner_file'] for x in rows)))
