import zipfile,sys,json,re,csv,collections as C,hashlib
E=sys.argv[1]
z=zipfile.ZipFile(E+'/zip/seals-runs.part01.zip')
R1=re.compile(r'^\S+\.lean:\d+:\d+: error:'); R2=re.compile(r'^\S+\.lean:\d+:\d+: error\(')
RANY=re.compile(r'^\S+\.lean:\d+:\d+: error[:(]')
res=C.defaultdict(list)
for n in z.namelist():
    if n.endswith('.jsonl'):
        for l in z.read(n).decode().splitlines():
            if l.strip():
                d=json.loads(l)
                if 'module' in d: res[d['module']].append((n,d))
dups={m:v for m,v in res.items() if len(v)>1}
print('modules in results',len(res),'with >1 result',len(dups))
for m,v in dups.items(): print(' DUP',m,[(n,d['rc'],d['errors'],d['log_sha256'][:12],d['start']) for n,d in v])
logs={}
for n in z.namelist():
    if n.startswith('seals/runs/mods/') and n.endswith('.log'):
        t=z.read(n).decode('utf-8','replace'); ls=t.splitlines()
        e1=sum(1 for l in ls if R1.match(l)); e2=sum(1 for l in ls if R2.match(l)); ea=sum(1 for l in ls if RANY.match(l))
        inst=[(int(a),int(b)) for a,b in re.findall(r'G06-MASK label=\S+ phase=install requested=(\d+) verified=(\d+)',t)]
        eof=[(int(a),int(b)) for a,b in re.findall(r'G06-MASK label=\S+ phase=eof requested=(\d+) verified=(\d+)',t)]
        end=len(re.findall(r'G06-SEAL-END',t))
        mod=n[len('seals/runs/mods/'):-4].replace('_','/',2)  # DW10Probe/C/...
        logs[mod]=dict(e1=e1,e2=e2,ea=ea,inst=inst,eof=eof,end=end,sha=hashlib.sha256(t.encode('utf-8','surrogateescape')).hexdigest(),raw=hashlib.sha256(z.read(n)).hexdigest())
print('logs',len(logs))
rows=list(csv.DictReader(open(E+'/seals.tsv',encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
print('seal rows',len(rows),C.Counter(r['variant'] for r in rows))
bad=C.Counter(); probs=[]
runmods=set()
for r in rows:
    m=r['run_module']; runmods.add(m)
    L=logs.get(m)
    if L is None: bad['nolog']+=1; probs.append(('nolog',m)); continue
    rr=res.get(m)
    if not rr: bad['nores']+=1; continue
    rc=rr[-1][1]['rc']
    if str(rc)!=r['rc']: bad['rc']+=1; probs.append(('rc',m,rc,r['rc']))
    if L['ea']!=int(r['errors']): bad['err']+=1; probs.append(('err',m,L['ea'],r['errors']))
    if rr[-1][1]['errors']!=L['ea']: bad['res_vs_log']+=1
    if rr[-1][1]['log_sha256']!=L['raw']: bad['logsha']+=1; probs.append(('logsha',m))
    req=int(r['requests'])
    si=sum(a for a,b in L['inst']); sv=sum(b for a,b in L['inst']); ei=sum(a for a,b in L['eof']); ev=sum(b for a,b in L['eof'])
    if not (si==sv==req==ei==ev): bad['insteof']+=1; probs.append(('ie',m,req,si,sv,ei,ev))
    if len(L['inst'])!=len(L['eof']): bad['parts']+=1
    if (rc==0) != (L['ea']==0): bad['rc_err_incons']+=1; probs.append(('rcerr',m,rc,L['ea']))
    if r['dedup_with']!='-' and r['dedup_with']!=m: bad['dedupmismatch']+=1
print('unused logs',len(set(logs)-runmods), list(set(logs)-runmods)[:3])
print('bad',dict(bad)); print(probs[:15])
tot=C.Counter(); fo=C.Counter()
for r in rows:
    tot[r['variant']]+=int(r['errors']); fo[r['variant']]+= int(r['errors'])>0
print('errors per variant',dict(tot),'failing owners',dict(fo))
print('runs',len(runmods),'dedup rows',sum(1 for r in rows if r['dedup_with']!='-'))
print('req sum/max',{v:(sum(int(r['requests']) for r in rows if r['variant']==v),max(int(r['requests']) for r in rows if r['variant']==v)) for v in tot})
print('errforms total e1,e2',sum(L['e1'] for L in logs.values()),sum(L['e2'] for L in logs.values()))
own=C.Counter(r['path'] for r in rows); print('owners',len(own),set(own.values()))
json.dump({m:{k:v for k,v in L.items() if k in('ea','e1','e2')} for m,L in logs.items()},open(sys.argv[2],'w'))
