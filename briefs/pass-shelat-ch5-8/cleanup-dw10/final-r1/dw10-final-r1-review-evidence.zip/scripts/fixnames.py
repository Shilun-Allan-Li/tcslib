import csv,sys,json,re,collections as C
inv=list(csv.DictReader(open(sys.argv[1],encoding='utf-8'),delimiter='\t',quoting=csv.QUOTE_NONE))
idx=json.load(open(sys.argv[2]))
rd=json.load(open(sys.argv[3]))  # readers.json: def -> [[thm,home]]
known=set(idx)
for v in rd.values():
    for t,h in v: known.add(t)
suf=C.defaultdict(set)
for k in known:
    parts=k.split('.')
    for i in range(len(parts)): suf['.'.join(parts[i:])].add(k)
ID=re.compile(r"(?<![\w.'])([A-Za-z_][\w'!?₀-₉]*(?:\.[A-Za-z_][\w'!?₀-₉]*)+)")
def resolve(n):
    n=n.rstrip('.')
    return suf.get(n,set())
op=[r for r in inv if r['class'] in('STAGE2','STAGE2-PROVIDER-READER')]
use_missing=C.Counter(); add_exists=C.defaultdict(set); usecount=0
for r in op:
    f=r['fix']
    # split into clauses by ';'
    for cl in re.split(r';',f):
        cl=cl.strip()
        verb='use' if re.match(r'^(use|with the published|published)',cl) else ('add' if re.search(r'\badd\b',cl) else 'other')
        if verb=='use':
            for n in ID.findall(cl):
                if n.endswith('.lean') or '/' in n or n.split('.')[-1] in('lean',): continue
                if n.startswith(('TCSlib/','Complexity/')): continue
                usecount+=1
                if not resolve(n): use_missing[n]+=1
        if verb=='add':
            m=re.search(r'\badd\b(.*?)(?:\(|\bin\b|\bnext to\b|$)',cl)
            seg=m.group(1) if m else ''
            for n in ID.findall(seg):
                if resolve(n): add_exists[n].add(r['item_id'])
print('use-names checked',usecount,'unresolved distinct',len(use_missing))
for n,c in use_missing.most_common(): print('  USE?',n,c)
print('add names that already exist',len(add_exists))
for n,s in add_exists.items(): print('  ADD-EXISTS',n,sorted(resolve(n))[:3],sorted(s)[:6])
