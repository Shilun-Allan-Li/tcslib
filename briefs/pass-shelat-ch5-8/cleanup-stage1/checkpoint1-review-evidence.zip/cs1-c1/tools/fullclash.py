import sys,re,subprocess,collections
R=sys.argv[1]; alld=sys.argv[2]; newn=[l.strip() for l in open(sys.argv[3])]
shorts=set(n.split('.')[-1] for n in newn)
pat=re.compile(r'^\s*(@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec|partial|unsafe|scoped)\s+)*(theorem|lemma|def|abbrev|structure|inductive|instance|class|alias|opaque|axiom)\s+([^\s(:{\[]+)')
files=set()
for l in open(alld,encoding='utf-8'):
    _,path,ln,rest=l.split(':',3); m=pat.match(rest)
    if m and m.group(4).split('.')[-1] in shorts: files.add(path)
full=collections.defaultdict(list)
for f in sorted(files):
    src=subprocess.run(['git','-C','/home/user/tcslib','show',f'{R}:{f}'],capture_output=True,text=True).stdout
    src=re.sub(r'/-.*?-/',lambda m:'\n'*m.group(0).count('\n'),src,flags=re.S)
    ns=[]; stack=[]
    for i,l in enumerate(src.split('\n'),1):
        m=re.match(r'^namespace\s+(\S+)',l)
        if m: stack.append(('ns',m.group(1))); continue
        m=re.match(r'^section\b\s*(\S*)',l)
        if m: stack.append(('sec',m.group(1))); continue
        m=re.match(r'^end\b\s*(\S*)\s*$',l)
        if m and stack: stack.pop(); continue
        m=pat.match(l)
        if m:
            nm=m.group(4)
            if nm.split('.')[-1] not in shorts: continue
            pre='.'.join(x[1] for x in stack if x[0]=='ns')
            fn=nm[7:] if nm.startswith('_root_.') else (pre+'.'+nm if pre else nm)
            full[fn].append(f'{f}:{i}')
hit=[n for n in newn if n in full]
print('exact full-name clashes:',len(hit)); [print(' ',n,full[n]) for n in hit]
print('scanned files',len(files),'decls with new short names',sum(len(v) for v in full.values()))
