import sys,re
exec(open(sys.argv[4]).read().split("rows = [")[0].replace("brief, tsv, root = sys.argv[1:4]","brief, tsv, root = sys.argv[1:4]"))
rows=[l.rstrip('\n').split('\t') for l in open(tsv,encoding='utf-8')]
added={r[2]:r for r in rows if r[0]=='ADDED'}
same=0;diff=[]
for kind,name,lines in chunks:
    short=name[7:] if name.startswith('_root_.') else name
    full=[n for n in added if n==short or n.endswith('.'+short)][0]
    path,ln=added[full][1].rsplit(':',1);src=open(f'{root}/{path}',encoding='utf-8').read().split('\n')
    h=src[int(ln)-1:int(ln)-1+len(lines)]
    # compare line by line, stripping only the trailing ' := by' etc on the last header line
    a=[l.rstrip() for l in lines]; b=[l.rstrip() for l in h]
    b[-1]=re.sub(r'\s*:=.*$','',b[-1]) if not a[-1].rstrip().endswith(':=') and ':=' not in a[-1] else b[-1]
    if a==b: same+=1
    else: diff.append((full,[(x,y) for x,y in zip(a,b) if x!=y][:2]))
print('line-exact',same,'of',len(chunks))
for d in diff: print(d)
