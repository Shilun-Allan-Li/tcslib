import sys,collections
G=collections.defaultdict(list)
for l in open(sys.argv[1]):
    _,path,imp=l.rstrip('\n').split(':',2)
    mod=path[:-5].replace('/','.')
    G[mod].append(imp.split()[1])
def clo(m):
    seen=set();st=[m]
    while st:
        x=st.pop()
        for y in G.get(x,[]):
            if y not in seen: seen.add(y);st.append(y)
    return seen
cmd=sys.argv[2]
if cmd=='in':
    a,b=sys.argv[3],sys.argv[4]; print(a,'imports*',b,':',b in clo(a))
