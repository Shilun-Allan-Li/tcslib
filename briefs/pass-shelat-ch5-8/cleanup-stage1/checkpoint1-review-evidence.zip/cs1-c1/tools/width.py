import sys,os
root=sys.argv[1]; files=open(sys.argv[2]).read().split()
for f in files:
    L=open(os.path.join(root,f),encoding='utf-8').read().split('\n')
    if L and L[-1]=='': L=L[:-1]
    over=[(i+1,len(l)) for i,l in enumerate(L) if len(l)>100]
    print(f, len(L), max(len(l) for l in L), over[:5])
