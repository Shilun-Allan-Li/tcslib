import sys,re,collections
idx=collections.defaultdict(list)
pat=re.compile(r'^\s*(@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec|partial|unsafe|scoped)\s+)*(theorem|lemma|def|abbrev|structure|inductive|instance|class|alias|opaque|axiom)\s+([^\s(:{\[]+)')
for l in open(sys.argv[1],encoding='utf-8'):
    _,path,ln,rest=l.split(':',3)
    m=pat.match(rest)
    if not m: continue
    nm=m.group(4)
    if m.group(3)=='instance' and nm.startswith('['): continue
    idx[nm.split('.')[-1]].append(f'{path}:{ln}:{"private " if "private" in (m.group(2) or "") else ""}{nm}')
tot=0
for r in open(sys.argv[2],encoding='utf-8'):
    f=r.rstrip('\n').split('\t'); full=f[2]; short=full.split('.')[-1]; prot=f[4].startswith('protected')
    hits=idx.get(short,[])
    flag='OK'
    if hits and not prot: flag='UNPROTECTED-WITH-HITS'
    if not hits and prot: flag='protected-fresh'
    print(flag, 'P' if prot else '-', full, len(hits), '; '.join(hits[:4]))
