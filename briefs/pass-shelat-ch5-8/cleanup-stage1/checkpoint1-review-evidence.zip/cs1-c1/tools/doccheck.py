import sys,re
rows=[l.rstrip('\n').split('\t') for l in open(sys.argv[1],encoding='utf-8')]
root=sys.argv[2]
cache={}
for r in sorted(rows,key=lambda r:r[1]):
    path,ln=r[1].rsplit(':',1); ln=int(ln)
    src=cache.setdefault(path,open(f'{root}/{path}',encoding='utf-8').read().split('\n'))
    # docstring directly above
    j=ln-2
    if not src[j].rstrip().endswith('-/'): print('NODOC',r[2]); continue
    k=j
    while not src[k].lstrip().startswith('/--'): k-=1
    doc='\n'.join(src[k:j+1])
    glue='Framework glue' in doc or 'framework glue' in doc
    tag=re.findall(r'\[PS10[^\]]*\]',doc)
    # body length: from decl line to next blank line
    e=ln-1
    while e<len(src) and src[e].strip(): e+=1
    body=src[ln-1:e]
    # proof lines: lines after the header's := 
    txt='\n'.join(body); 
    n=len(body)
    sketch='**Proof sketch.**' in doc
    formula='`' in doc
    print(f"{'GLUE' if glue else 'TAG ' if tag else 'NONE'} sk={'Y' if sketch else '-'} decl_lines={n:3d} {r[2]} {tag if not glue else ''}")
