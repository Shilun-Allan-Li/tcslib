"""stmtcmp.py brief.md decls2.tsv headroot: compare every brief Lean declaration (header, and for
definitions also the body) with the head source, whitespace-normalized; also report exact
(byte) equality of the header lines modulo indentation-free line breaks."""
import sys, re
brief, tsv, root = sys.argv[1:4]
KW = r'(?:(?:protected|private|noncomputable)\s+)*(theorem|lemma|def|abbrev)\s+(\S+)'
txt = open(brief, encoding='utf-8').read()
blocks = re.findall(r'```lean\n(.*?)```', txt, flags=re.S)
chunks = []
for b in blocks:
    cur = None
    for line in b.split('\n'):
        line = re.sub(r'\s+--.*$', '', line)
        if line.startswith('--'): continue
        m = re.match(KW, line)
        if m:
            if cur: chunks.append(cur)
            cur = [m.group(1), m.group(2), [line]]
        elif cur is not None and line.strip():
            cur[2].append(line)
    if cur: chunks.append(cur)
def norm(s): return re.sub(r'\s+', ' ', s).strip()
def cut(t):
    d = 0
    for k, ch in enumerate(t):
        if ch in '([{⟨': d += 1
        elif ch in ')]}⟩': d -= 1
        elif d == 0 and t.startswith(':=', k): return t[:k], t[k:]
    return t, ''
rows = [l.rstrip('\n').split('\t') for l in open(tsv, encoding='utf-8')]
added = {r[2]: r for r in rows if r[0] == 'ADDED'}
used = set(); ok = 0; bad = 0
for kind, name, lines in chunks:
    short = name[len('_root_.'):] if name.startswith('_root_.') else name
    cands = [n for n in added if n == short or n.endswith('.' + short)]
    if len(cands) != 1:
        print('NOMATCH', name, cands); bad += 1; continue
    full = cands[0]; used.add(full)
    path, ln = added[full][1].rsplit(':', 1); ln = int(ln)
    src = open(f'{root}/{path}', encoding='utf-8').read().split('\n')
    # head text from the declaration line to the next blank line
    j = ln - 1; h = []
    while j < len(src) and src[j].strip():
        h.append(src[j]); j += 1
    bt = ' '.join(lines); ht = ' '.join(h)
    bh, bb = cut(bt); hh, hb = cut(ht)
    if kind in ('def', 'abbrev'):
        # body: brief body if given, else none pinned; arms after header
        if norm(bt) == norm(ht) or (norm(bh) == norm(hh) and not bb and '|' not in bt):
            ok += 1; print('OK ', full, '(def, body', 'pinned)' if bb or '|' in bt else 'not pinned)')
        else:
            bad += 1; print('DIFF', full, '\n  brief:', norm(bt), '\n  head :', norm(ht))
    else:
        if norm(bh) == norm(hh):
            ok += 1; print('OK ', full)
        else:
            bad += 1; print('DIFF', full, '\n  brief:', norm(bh), '\n  head :', norm(hh))
print('chunks', len(chunks), 'ok', ok, 'bad', bad, 'unmatched added', sorted(set(added) - used))
