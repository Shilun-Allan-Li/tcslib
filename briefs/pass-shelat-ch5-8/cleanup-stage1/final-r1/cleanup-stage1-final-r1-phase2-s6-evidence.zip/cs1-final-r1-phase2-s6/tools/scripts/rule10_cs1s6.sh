#!/usr/bin/env bash
# rule10_cs1s6.sh <outdir>  (cleanup-stage1 phase 2 re-replay on snapshot #6). The head branch of phase 2's
# rule10_cs1p2.sh, narrowed to the checks this job asks for: the collector, canonical coe-A seals (mkseals_coe.py) on the
# 21 owners, and the axioms probe (mkaxioms.py with phase 2's name/import lists). Recipe seal tools read only; probes run
# through runner_full_gated.py (= recipe runner_full.py + a pre-probe slot/disk gate): lean -DmaxErrors=0, no -o.
# Probe prefix and collector title kept as phase 2's (CS1P2H, "cs1 phase 2 collector (head)") so the probe sources
# compare byte for byte with phase 2's.
#   REV = TS2 13fc8060 (tip 6f138550 x #347 x #355) on $SP/olean-replay-cs1-s6; BASE = tip 6f138550.
set -u
OUT=$1
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; W0=$SP/cs1s6; P2=$SP/cs1p2
T=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/seal; G=$T/review/archived-gate10-tools
TIP=6f13855029e918d4a0c19d17efbc35eedbb902f8; REV=13fc8060d5b8d08a8f9e80244242118acaa679e2
TREE=$SP/olean-replay-cs1-s6; WT=$W0/W; P=CS1P2H; BASE=$TIP
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$W0/tmp GIT_DIR=/home/user/tcslib/.git
OWN17="TCSlib.Complexity.Randomized.Build.IterateFindHost TCSlib.Complexity.Randomized.PPT
 TCSlib.Cryptography.Asymptotic.Adversary TCSlib.Cryptography.Asymptotic.Sampling
 TCSlib.Cryptography.Authentication.Encoding TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity
 TCSlib.Cryptography.Encryption.PublicKey.Trapdoor TCSlib.Cryptography.Foundations.BitLists
 TCSlib.Cryptography.Games.Bridges.Experiments TCSlib.Cryptography.Games.Efficiency.Strings
 TCSlib.Cryptography.Games.Machines TCSlib.Cryptography.Pseudorandom.Functions.Asymptotic.Defs
 TCSlib.Cryptography.ZeroKnowledge.EncodingMachines TCSlib.Cryptography.ZeroKnowledge.Interaction
 TCSlib.InformationTheory.Entropy TCSlib.InformationTheory.FinDist TCSlib.InformationTheory.Samples"
OWN347="TCSlib.Complexity.TuringMachine.Build.ModuleHost TCSlib.Complexity.Randomized.Build.IterateFind"
OWNERS="$OWN17 TCSlib.Cryptography.Games.Tapes TCSlib.Cryptography.ZeroKnowledge.InteractionWords $OWN347"
mkdir -p $OUT/order $OUT/probe-sources $OUT/statements
echo "start $(date -u +%FT%TZ) rev=$REV tree=$TREE"
rm -rf $WT/$P; mkdir -p $WT/$P
FILES=$(printf '%s\n' $OWNERS | sed 's|\.|/|g; s|$|.lean|')
for f in $FILES; do [ "$(git hash-object $WT/$f)" = "$(git rev-parse $REV:$f)" ] || { echo "worktree differs: $f"; exit 1; }; done
# 1. collector
printf '%s\n' $OWNERS > $OUT/order/owners.txt
python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $OUT/order/owners.txt "cs1 phase 2 collector (head)" $WT/$P/Collect.lean
cp $WT/$P/Collect.lean $OUT/probe-sources/Collect.lean.txt
echo $P/Collect > $OUT/order/collect.txt
python3 -I $W0/scripts/runner_full_gated.py $WT $OUT/order/collect.txt $TREE $OUT/collect-runs > $OUT/collect-runner.out 2>&1
LOG=$OUT/collect-runs/mods/${P}_Collect.log
grep -q '^CAT-COUNT' $LOG || { echo "collector failed"; tail -20 $LOG; exit 1; }
echo "collector $(date -u +%FT%TZ)"
# 2. canonical coe-A seals
python3 -I $T/review/mkseals_coe.py $G $LOG $WT $REV $OUT/seals-coe/A $P/C SealA_ $OWNERS > $OUT/mkseals-coe-A.log
# 3. axioms probe (phase 2's generator and lists, read only)
python3 -I $P2/scripts/mkaxioms.py $P2/ref/imports-s1.txt $P2/ref/imports-dw5.txt --names $P2/ref/names-s1.txt $P2/ref/names-dw5.txt \
  --owners $OUT/order/owners.txt --out $WT/$P/Axioms.lean > $OUT/mkaxioms.log
cp $WT/$P/Axioms.lean $OUT/probe-sources/Axioms.lean.txt
(cd $WT && { ls $P/Axioms.lean; ls $P/C/*.lean; } | sed 's/\.lean$//') > $OUT/order/seal-axioms-queue.txt
echo "queue $(wc -l < $OUT/order/seal-axioms-queue.txt) probes $(date -u +%FT%TZ)"
python3 -I $W0/scripts/runner_full_gated.py $WT $OUT/order/seal-axioms-queue.txt $TREE $OUT/seal-runs > $OUT/seal-runner.out 2>&1 || true
# 4. summaries
python3 -I $T/review/touched.py /home/user/tcslib $BASE $REV $OUT/statements/touched.json $FILES > $OUT/statements/touched.tsv
python3 -I $T/review/sealsum.py $OUT/seals-coe/A $OUT/seal-runs $OUT/statements/touched.json $OUT/seals-coe-A.tsv
cat $OUT/mkseals-coe-A.log $OUT/mkaxioms.log; cut -c1-250 $OUT/seals-coe-A.tsv
echo "PHASE-DONE $(date -u +%FT%TZ)"
