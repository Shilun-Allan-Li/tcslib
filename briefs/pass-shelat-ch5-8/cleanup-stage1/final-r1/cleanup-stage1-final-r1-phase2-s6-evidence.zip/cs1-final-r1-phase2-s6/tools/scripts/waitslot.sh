#!/usr/bin/env bash
# waitslot.sh <log>: block while >= 3 lean processes run host-wide (poll 30 s); refuse if free disk < 1500 MB.
L=${1:-/dev/null}
while :; do
  f=$(df -B1M / | tail -1 | awk '{print $4}')
  if [ "$f" -lt 1500 ]; then echo "$(date -u +%FT%TZ) LOW-DISK $f MB: not starting" >> $L; exit 2; fi
  n=$(pgrep -c -x lean); if [ "$n" -lt 3 ]; then echo "$(date -u +%FT%TZ) slot ok (lean $n, $f MB)" >> $L; exit 0; fi
  echo "$(date -u +%FT%TZ) wait (lean $n)" >> $L; sleep 30
done
