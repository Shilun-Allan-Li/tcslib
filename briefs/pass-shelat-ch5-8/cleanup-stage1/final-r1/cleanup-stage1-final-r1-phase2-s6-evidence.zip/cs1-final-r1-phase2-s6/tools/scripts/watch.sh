#!/usr/bin/env bash
# cs1s6 watcher: every 30 s log free disk and the host-wide Lean count. Disk < 1500 MB: stop this job's runner and its lean.
B=$1
while [ ! -s $B/runner.exit ]; do
  f=$(df -B1M / | tail -1 | awk '{print $4}')
  cp=$(cut -d' ' -f1 $B/current.pid 2>/dev/null); lp=$(pgrep -P "$cp" -x lean 2>/dev/null | head -1)
  n=$(pgrep -c -x lean)
  echo "$(date -u +%FT%TZ) $f MB free; lean procs $n; ours $lp" >> $B/watch.log
  if [ "$f" -lt 1500 ]; then echo "$(date -u +%FT%TZ) LOW-DISK STOP ($f MB)" >> $B/watch.log
    kill $(cat $B/runner.pid) 2>/dev/null; [ -n "$lp" ] && kill $lp 2>/dev/null; break; fi
  sleep 30
done
echo "$(date -u +%FT%TZ) $(df -B1M / | tail -1 | awk '{print $4}') MB free (end)" >> $B/watch.log
