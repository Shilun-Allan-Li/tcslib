"""axsum_cs1s6.py <Axioms.log> <names-s1> <names-dw5> <touched.json> [<phase-2 Axioms.log>]: phase 2's axsum.out lines
(Stage 1's 69 and #347's 27 `#print axioms` results, standard-only check and split; the census of every constant homed in
an owner; sorryAx; errors; touched-declaration coverage), plus a comparison of the #print and census sets with phase 2's log."""
import sys, re, json, collections
log, n1, n2, tj = sys.argv[1:5]; ref = sys.argv[5] if len(sys.argv) > 5 else None
STD = {'propext', 'Classical.choice', 'Quot.sound'}
def parse(p):
    t = open(p, encoding='utf-8', errors='replace').read(); pa = {}
    for m in re.finditer(r"^'([^']+)' depends on axioms: \[([^\]]*)\]", t, re.M | re.S):
        pa[m.group(1)] = tuple(sorted(x.strip() for x in m.group(2).replace('\n', ' ').split(',') if x.strip()))
    for m in re.finditer(r"^'([^']+)' does not depend on any axioms", t, re.M): pa[m.group(1)] = ()
    cen = {}
    for l in t.splitlines():
        if l.startswith('C\t'):
            _, c, home, kind, axs = l.split('\t'); cen[c] = (home, kind, tuple(sorted(x.strip() for x in axs.strip('[]').split(',') if x.strip())))
    cc = re.search(r'^C-COUNT (\d+)', t, re.M)
    return t, pa, cen, int(cc.group(1)) if cc else None
t, pa, cen, cc = parse(log)
for lab, f in (('Stage 1 (69)', n1), ('DW-5/#347 (27)', n2)):
    ns = [l.strip() for l in open(f) if l.strip()]
    miss = [n for n in ns if n not in pa]; nonstd = {n: pa[n] for n in ns if n in pa and set(pa[n]) - STD}
    print(f'{lab} printed {sum(1 for n in ns if n in pa)} missing {miss} nonstandard {nonstd}')
    print('  split', dict(collections.Counter(pa[n] for n in ns if n in pa)))
nonstd = {c: v for c, v in cen.items() if set(v[2]) - STD}
owners = sorted({v[0] for v in cen.values()})
print(f'census constants {len(cen)} C-COUNT {cc} owners {len(owners)} ; nonstandard {len(nonstd)}')
errs = len(re.findall(r'^\S+\.lean:\d+:\d+: error', t, re.M))
print(f'sorryAx anywhere in log: {"sorryAx" in t} ; errors: {errs}')
J = json.load(open(tj))['files']; td = [d['name'] for f in J.values() for d in f['declarations'] if d.get('touched')]
nf = [n for n in td if n not in cen]
print(f'touched declarations {len(td)} ; in census {len(td) - len(nf)} ; not found {nf}')
if ref:
    _, pa0, cen0, cc0 = parse(ref)
    print(f'vs phase 2 log: #print results identical {pa == pa0} ({len(pa)} vs {len(pa0)}); census identical {cen == cen0} ({len(cen)} vs {len(cen0)})')
    for c in sorted(set(cen) ^ set(cen0)): print('  census only in', 'TS2' if c in cen else 'TS1', c)
    for c in sorted(c for c in set(cen) & set(cen0) if cen[c] != cen0[c]): print('  census differs', c, cen0[c], '->', cen[c])
