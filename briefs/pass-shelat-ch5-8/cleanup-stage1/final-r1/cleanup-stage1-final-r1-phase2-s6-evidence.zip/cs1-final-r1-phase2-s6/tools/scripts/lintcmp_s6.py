"""lintcmp_s6.py <s6-lint-dir> <phase2-lint-dir>: FAIL/WARN multisets (line numbers dropped), phase 2's lintcmp.py method.
Pairs: tip-now -> TS2 (the delta of #347+#355 on snapshot #6's Lean), phase-2 tip -> tip-now and phase-2 TS1 -> TS2
(both = #357's effect alone, if the delta is unchanged)."""
import sys, re, collections
d6, d5 = sys.argv[1:3]
def rd(p): return collections.Counter(re.sub(r':\d+', '', x.rstrip()) for x in open(p, encoding='utf-8') if x.startswith(('FAIL', 'WARN')))
fw = lambda c: f'{sum(1 for x in c.elements() if x.startswith("FAIL"))}/{sum(1 for x in c.elements() if x.startswith("WARN"))}'
deltas = {}
for a in ('Cryptography', 'InformationTheory', 'Complexity'):
    S = {'p2tip': rd(f'{d5}/campaign-TCSlib_{a}-tip.txt'), 'p2ts1': rd(f'{d5}/campaign-TCSlib_{a}-ts1.txt'),
         'tip': rd(f'{d6}/campaign-TCSlib_{a}-tip.txt'), 'ts2': rd(f'{d6}/campaign-TCSlib_{a}-ts2.txt')}
    print(f'{a}: FAIL/WARN phase-2 tip {fw(S["p2tip"])}, phase-2 TS1 {fw(S["p2ts1"])}, tip-now {fw(S["tip"])}, TS2 {fw(S["ts2"])}')
    for x, y in (('tip', 'ts2'), ('p2tip', 'p2ts1'), ('p2tip', 'tip'), ('p2ts1', 'ts2')):
        gone, new = S[x] - S[y], S[y] - S[x]
        deltas[(a, x, y)] = (gone, new)
        print(f'  {x} -> {y}: removed {sum(gone.values())}; new {sum(new.values())}')
        for z in sorted(gone.elements()): print('    removed:', z[:300])
        for z in sorted(new.elements()): print('    NEW:', z[:300])
    print(f'  delta(tip-now -> TS2) == delta(phase-2 tip -> TS1): {deltas[(a, "tip", "ts2")] == deltas[(a, "p2tip", "p2ts1")]}')
    print(f'  #357 effect equal on both sides (p2tip->tip == p2ts1->ts2): {deltas[(a, "p2tip", "tip")] == deltas[(a, "p2ts1", "ts2")]}')
for s, t in (('tip', 'tip'), ('ts2', 'ts1')):
    a = open(f'{d6}/style_lint-{s}.txt', encoding='utf-8').read(); b = open(f'{d5}/style_lint-{t}.txt', encoding='utf-8').read()
    print(f'style_lint {s} (s6) == phase-2 {t}: {a == b}')
