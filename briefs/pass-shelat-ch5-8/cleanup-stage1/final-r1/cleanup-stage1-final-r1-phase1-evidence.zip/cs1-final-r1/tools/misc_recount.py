"""misc_recount.py EVID FULLDIFF DECLS2: recount the explicit-unfold scan, axioms, StmtDump and lint line sets."""
import sys, json, re, collections
ev, fd, dt = sys.argv[1:4]
added = collections.defaultdict(set); cur = None
for l in open(fd, encoding='utf-8'):
    if l.startswith('+++ b/'): cur = l[6:].strip()
    elif l.startswith('@@'):
        m = re.match(r'@@ -\S+ \+(\d+)(?:,(\d+))?', l); s = int(m.group(1)); n = int(m.group(2) or 1)
        added[cur].update(range(s, s + n))
print('== explicit-unfold scan')
for side in ('base', 'head'):
    ex = json.load(open(f'{ev}/rule10/{side}/scan/explicit.json'))['items']
    innew = [i for i in ex if i['line'] in added.get(i['file'], ())] if side == 'head' else []
    fo = [i for i in ex if i['classification'].startswith('FOREIGN')]
    print(f"{side}: items {len(ex)}, in new declarations {len(innew)} (status {dict(collections.Counter(i['declaration_status'] for i in ex))}), "
          f"classes in new {dict(collections.Counter(i['classification'] for i in innew))}, foreign {len(fo)}, foreign in new {sum(1 for i in innew if i['classification'].startswith('FOREIGN'))}")
    print('  foreign multiset', sorted(collections.Counter((i['file'].split('/')[-1], i['declaration'].split('.')[-1], i['tactic'], i['item'], i['classification']) for i in fo).items()))
    print('  owned-definition items in new declarations', [(i['declaration'], i['item']) for i in innew if i['classification'] == 'OWNED_DEFINITION'])
print('== axioms')
t = open(f'{ev}/statements/Axioms.log', encoding='utf-8').read()
names = re.findall(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)", re.sub(r'\n\s+', ' ', t))
ax = collections.Counter()
for n, a in names: ax[tuple(sorted(x.strip() for x in a.split(',') if x.strip()))] += 1
dec = [l.split('\t')[2] for l in open(dt)]
print('prints', len(names), 'missing', sorted(set(dec) - set(n for n, _ in names)), 'sorryAx' in t, dict(ax))
s = open(f'{ev}/statements/StmtDump.log', encoding='utf-8').read()
print('StmtDump', re.findall(r'STMT-COUNT \d+', s), 'errors', len(re.findall(r'error[:(]', s)))
print('== campaign lint line sets (line numbers dropped)')
for a in ('Cryptography', 'InformationTheory', 'Complexity'):
    L = {}
    for side in ('base', 'head'):
        L[side] = collections.Counter(re.sub(r':\d+', '', x.rstrip()) for x in open(f'{ev}/lint/campaign-TCSlib_{a}-{side}.txt', encoding='utf-8') if x.startswith(('FAIL', 'WARN')))
    c = lambda side, k: sum(v for x, v in L[side].items() if x.startswith(k))
    print(f"{a}: base FAIL {c('base','FAIL')} WARN {c('base','WARN')} -> head FAIL {c('head','FAIL')} WARN {c('head','WARN')}; new lines {sorted((L['head']-L['base']).keys())}; removed {sorted((L['base']-L['head']).keys())}")
