import sys, subprocess
root, base = sys.argv[1], sys.argv[2]
files = subprocess.run(['git','-C',root,'diff','--name-only',base,'HEAD'],capture_output=True,text=True).stdout.split()
addmax = 0
added = [l[1:] for l in open(sys.argv[3],encoding='utf-8').read().split('\n') if l.startswith('+') and not l.startswith('+++')]
over = [l for l in added if len(l) > 100]
print('added lines', len(added), 'max width', max(len(l) for l in added), 'over100', len(over))
for f in files:
    head = open(f'{root}/{f}',encoding='utf-8').read().split('\n')
    if head and head[-1]=='': head=head[:-1]
    b = subprocess.run(['git','-C',root,'show',f'{base}:{f}'],capture_output=True,text=True)
    bl = b.stdout.split('\n')[:-1] if b.returncode==0 else []
    print(f"{f}\t{len(bl) if b.returncode==0 else 'new'}\t{len(head)}\tmaxw_head={max(len(x) for x in head)}\tmaxw_base={max((len(x) for x in bl), default=0)}")
