"""ctlrecount.py HEADDIR: recount paired controls (strict K S, coe K) from raw logs."""
import sys, json, re, hashlib
H = sys.argv[1]
ERR = re.compile(r'^\S+\.lean:(\d+):\d+: error[:(]')
runs = {}
for l in open(f'{H}/seal-runs/results.jsonl'):
    r = json.loads(l)
    if 'module' in r: runs[r['module']] = r
tot = {}
for var in ('strict','coe'):
    plan = json.load(open(f'{H}/controls-{var}/controls-plan.json'))
    neg_ok = neg_n = pos_bad = stray = unsealed_err = probes = mis = 0; pairs = 0
    for p in plan:
        probes += 1
        src = open(f"{H}/controls-{var}/{p['label']}.lean.txt",'rb').read()
        run = runs[p['module']]
        log = open(f"{H}/seal-runs/mods/{p['module'].replace('/','_')}.log",'rb').read()
        if hashlib.sha256(src).hexdigest() != run['source_sha256'] or hashlib.sha256(log).hexdigest() != run['log_sha256']: mis += 1
        errl = [int(m.group(1)) for m in (ERR.match(x) for x in log.decode('utf-8','replace').split('\n')) if m]
        used = set()
        for c in p['controls']:
            n = sum(1 for e in errl if c['start_line'] <= e <= c['end_line'])
            used |= {e for e in errl if c['start_line'] <= e <= c['end_line']}
            if p['sealed']:
                if c['negative']:
                    neg_n += 1; pairs += 1
                    if n == 1: neg_ok += 1
                else:
                    if n: pos_bad += 1
            else:
                if n: unsealed_err += 1
        stray += len([e for e in errl if e not in used])
        if p['sealed'] and 'install' not in log.decode('utf-8','replace'): mis += 1
    print(f"{var}: probes {probes}, sealed negatives failing exactly once {neg_ok}/{neg_n}, positives failing {pos_bad}, unsealed controls with errors {unsealed_err}, stray errors {stray}, hash mismatches {mis}")
