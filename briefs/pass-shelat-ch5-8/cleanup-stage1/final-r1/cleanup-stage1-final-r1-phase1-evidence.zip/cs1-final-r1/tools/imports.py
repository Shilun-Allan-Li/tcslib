"""imports.py REPO TREE OUT.json: module -> TCSlib/audits imports, read from git objects of TREE."""
import sys, subprocess, json, re
repo, tree, out = sys.argv[1:4]
ls = subprocess.run(['git','-C',repo,'ls-tree','-r',tree],capture_output=True,text=True).stdout.splitlines()
files = {}
for l in ls:
    meta,p = l.split('\t',1)
    if p.endswith('.lean'): files[p] = meta.split()[2]
inp = '\n'.join(files.values())+'\n'
cat = subprocess.run(['git','-C',repo,'cat-file','--batch'],input=inp.encode(),capture_output=True).stdout
res = {}; i = 0; paths = list(files.keys())
for p in paths:
    j = cat.index(b'\n', i); hdr = cat[i:j].split(); n = int(hdr[2]); body = cat[j+1:j+1+n].decode('utf-8','replace'); i = j+1+n+1
    imps = []
    for line in body.split('\n'):
        m = re.match(r'^import\s+(\S+)', line)
        if m: imps.append(m.group(1).replace('.','/'))
        elif line.strip() and not line.startswith(('import','/-','--','module','prelude')) and not line.startswith(' ') and imps: pass
    res[p[:-5]] = imps
json.dump(res, open(out,'w'))
print(len(res))
