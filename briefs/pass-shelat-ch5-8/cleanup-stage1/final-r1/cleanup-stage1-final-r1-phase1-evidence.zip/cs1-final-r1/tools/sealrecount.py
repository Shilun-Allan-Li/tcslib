"""sealrecount.py REPO RULE10DIR: recount seals (base, head; strict/coe; A/B) from raw logs and probe sources."""
import sys, json, re, os, hashlib, subprocess, glob
repo, R = sys.argv[1:3]
ERR = re.compile(r'^(\S+\.lean):(\d+):\d+: error[:(]')
TREES = {'base': '01cc6259480ccc9372181cd4d18d4511c87aa048', 'head': '985dd3125d8fd588cf2c8faa31ced8dee88407ab'}
DECL = re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|nonrec|partial)\s+)*(theorem|lemma|def|abbrev|instance|structure|inductive|class)\s+(\S+)')
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(tree, path):
    r = subprocess.run(['git','-C',repo,'show',f'{tree}:{path}'],capture_output=True)
    return r.stdout if r.returncode==0 else None
def enclosing(src_lines, ln):
    for k in range(ln-1, -1, -1):
        m = DECL.match(src_lines[k])
        if m: return m.group(2)
    return '?'
out = {}
for side in ('base','head'):
    runs = {}
    for l in open(f'{R}/{side}/seal-runs/results.jsonl'):
        r = json.loads(l)
        if 'module' in r: runs[r['module']] = r
    for var, sub, tag in (('sA','seals/A','S'),('sB','seals/B','S'),('cA','seals-coe/A','C'),('cB','seals-coe/B','C')):
        for jf in sorted(glob.glob(f'{R}/{side}/{sub}/Seal*.json')):
            d = json.load(open(jf)); lab = d['label']
            probe = open(jf[:-5]+'.lean.txt','rb').read()
            ok_probe = sha(probe) == d['probe_sha256']
            # strip insertions
            ins = sorted(d['insertions'], key=lambda i: i['probe_byte_offset'])
            rec = b''; pos = 0
            for i in ins:
                rec += probe[pos:i['probe_byte_offset']]; pos = i['probe_byte_offset'] + i['byte_count']
            rec += probe[pos:]
            src = blob(TREES[side], d['source'])
            ok_src = src is not None and rec == src and sha(src) == d['source_sha256']
            rk = f"S1R10{'H' if side=='head' else 'B'}/{tag}/{lab}"
            run = runs.get(rk)
            logp = f"{R}/{side}/seal-runs/mods/{rk.replace('/','_')}.log"
            log = open(logp,'rb').read()
            ok_log = run is not None and sha(log) == run['log_sha256'] and run['source_sha256'] == d['probe_sha256']
            txt = log.decode('utf-8','replace').split('\n')
            errs = [ERR.match(x) for x in txt]; errs = [m for m in errs if m]
            inst = re.search(rf'G06-MASK label={lab} phase=install requested=(\d+) verified=(\d+)', log.decode('utf-8','replace'))
            eof = re.search(rf'G06-MASK label={lab} phase=eof requested=(\d+) verified=(\d+)', log.decode('utf-8','replace'))
            n = d['requested']
            ok_mask = bool(inst and eof and int(inst.group(1))==int(inst.group(2))==n and int(eof.group(1))==int(eof.group(2))==n)
            # attribute errors
            p2s = {}
            for e in d['source_to_probe_lines']: p2s[e['probe_line']] = e['source_line']
            sl = src.decode('utf-8').split('\n') if src else []
            fails = []
            for m in errs:
                s = p2s.get(int(m.group(2)))
                fails.append(enclosing(sl, s) if s else f'harness:{m.group(2)}')
            names = sorted(r['spelling'] for r in d['rows'])
            out[(side,var,d['module'])] = dict(req=n, errs=len(errs), rc=run['rc'] if run else None, fails=sorted(set(fails)), nfails=len(fails),
                ok=(ok_probe, ok_src, ok_log, ok_mask), rows=names, recerr=run['errors'] if run else None)
json.dump({'|'.join(k): v for k,v in out.items()}, open(sys.argv[3],'w'), indent=0)
bad = [k for k,v in out.items() if not all(v['ok']) or v['errs']!=v['recerr']]
print('records', len(out), 'integrity failures', bad)
owners = sorted(set(k[2] for k in out))
print(f"{'owner':58s} side  sA/sB/cA/cB requests     errors")
for o in owners:
    for side in ('base','head'):
        if (side,'sA',o) not in out: continue
        rq = '/'.join(str(out[(side,v,o)]['req']) for v in ('sA','sB','cA','cB'))
        er = '/'.join(str(out[(side,v,o)]['errs']) for v in ('sA','sB','cA','cB'))
        print(f"{o:58s} {side}  {rq:22s} {er}")
print('\nstrict-minus-coe request names per owner (head, A):')
for o in owners:
    if ('head','sA',o) in out:
        dif = sorted(set(out[('head','sA',o)]['rows']) - set(out[('head','cA',o)]['rows']))
        dB = sorted(set(out[('head','sB',o)]['rows']) - set(out[('head','sA',o)]['rows']))
        print(f"  {o}: sA-cA={dif} sB-sA={dB}")
print('\nfailing declarations (head vs base):')
for o in owners:
    for v in ('sA','sB','cA','cB'):
        h = out.get(('head',v,o)); b = out.get(('base',v,o))
        if (h and h['errs']) or (b and b['errs']):
            print(f"  {o} {v}: base {b['fails'] if b else '-'} ({b['nfails'] if b else '-'}) | head {h['fails']} ({h['nfails']})")
print('\nrequest rows added/removed head vs base (A strict):')
for o in owners:
    b = out.get(('base','sA',o)); h = out[('head','sA',o)]
    if b: 
        add = sorted(set(h['rows'])-set(b['rows'])); rem = sorted(set(b['rows'])-set(h['rows']))
        if add or rem: print(f"  {o}: +{add} -{rem}")
