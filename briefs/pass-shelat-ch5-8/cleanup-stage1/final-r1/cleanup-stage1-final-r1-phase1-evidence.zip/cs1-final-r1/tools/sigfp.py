import sys, subprocess, base64, hashlib, struct
def fp(commit):
    raw = subprocess.run(['git','cat-file','-p',commit],capture_output=True,text=True).stdout
    lines = raw.split('\n'); sig=[]; on=False
    for l in lines:
        if l.startswith('gpgsig '): on=True; l=l[len('gpgsig '):]
        elif on and l.startswith(' '): l=l[1:]
        elif on: break
        if on: sig.append(l)
    if not sig: return 'unsigned'
    b = base64.b64decode(''.join(x for x in sig if not x.startswith('-----')))
    # SSHSIG: magic(6) + uint32 version + string pubkey ...
    off = 6+4
    n = struct.unpack('>I', b[off:off+4])[0]; pk = b[off+4:off+4+n]
    return 'SHA256:'+base64.b64encode(hashlib.sha256(pk).digest()).decode().rstrip('=')
for c in sys.argv[1:]:
    print(c[:12], fp(c))
