"""rowlines.py REPO TREE ISSUEBASE TSV: print the source line at every path:line of the Stage 2 table."""
import sys, re, subprocess
repo, tree, ib, tsv = sys.argv[1:5]
cache = {}
def get(rev, p):
    k = (rev, p)
    if k not in cache:
        r = subprocess.run(['git','-C',repo,'show',f'{rev}:{p}'],capture_output=True,text=True)
        cache[k] = r.stdout.split('\n') if r.returncode == 0 else None
    return cache[k]
rows = [l.rstrip('\n').split('\t') for l in open(tsv, encoding='utf-8')][1:]
for n, r in enumerate(rows, 2):
    cell = r[0]
    # split on ';' into path groups
    for grp in cell.split(';'):
        grp = grp.strip()
        m = re.match(r'(\S+\.lean):(.*)', grp)
        if not m: print(f'{n}\t?\t{grp}'); continue
        p, lines = m.group(1), m.group(2)
        full = p if p.startswith('TCSlib/') else 'TCSlib/Cryptography/' + p
        rev = ib if 'IterateFind' in p else tree
        src = get(rev, full)
        for ln in re.findall(r'(\d+)', lines.split('(')[0]):
            ln = int(ln)
            t = src[ln-1].strip() if src and ln <= len(src) else '<<MISSING>>'
            print(f'{n}\t{full.replace("TCSlib/Cryptography/","")}:{ln}\t{t[:150]}')
