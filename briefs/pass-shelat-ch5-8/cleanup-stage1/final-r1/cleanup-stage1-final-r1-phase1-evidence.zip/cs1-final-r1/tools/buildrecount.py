"""buildrecount.py REPO EVID ISSUED: recount the bootstrap and sweep from raw logs; bind sources to git trees."""
import sys, json, re, os, subprocess, hashlib
repo, ev, iss = sys.argv[1:4]
ERR = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]')
ERR2 = re.compile(r'error:|error\(')
SOR = re.compile(r"^\S+\.lean:\d+:\d+: warning: declaration uses 'sorry'")
def treefiles(tree):
    out = subprocess.run(['git','-C',repo,'ls-tree','-r',tree,'--','TCSlib','audits'],capture_output=True,text=True).stdout
    d={}
    for l in out.splitlines():
        meta,p=l.split('\t',1); d[p]=meta.split()[2]
    return d
def blobsha(blob):
    return hashlib.sha256(subprocess.run(['git','-C',repo,'cat-file','blob',blob],capture_output=True).stdout).hexdigest()
def logname(m): return m.replace('/','__')+'.log'
def recount(path):
    t=open(path,encoding='utf-8',errors='replace').read().split('\n')
    return sum(1 for l in t if ERR.match(l)), sum(1 for l in t if ERR2.search(l)), sum(1 for l in t if SOR.match(l)), [l for l in t if SOR.match(l)]
def run(name, d, tree, expected, sorries_expected=None):
    rows=[json.loads(l) for l in open(f'{d}/results.jsonl')]
    mods=[r['module'] for r in rows]
    tf=treefiles(tree)
    print(f'== {name}: records {len(rows)}, unique {len(set(mods))}, expected {len(expected)}, list-equal-in-order {mods==expected}, set-equal {set(mods)==set(expected)}')
    bad=0; nz=0; e1=e2=0; ssum=0; persorry={}; unbound=0; srcmis=0
    for r in rows:
        m=r['module']; lp=f"{d}/{logname(m)}"
        a,b,s,sl=recount(lp)
        if (a,b,s)!=(r['errors'],r['error_lines'],r['sorry']): bad+=1; print('  MISMATCH',m,(a,b,s),(r['errors'],r['error_lines'],r['sorry']))
        if r['rc']!=0: nz+=1
        e1+=a; e2+=b; ssum+=s
        if s: persorry[m]=s
        blob=tf.get(m+'.lean')
        h=blobsha(blob) if blob else None
        if h!=r['src_sha256']: srcmis+=1; print('  SRC≠TREE',m)
        if not r.get('bound') or r['src_sha256']!=r.get('head_sha256'): unbound+=1
    print(f'  rc!=0: {nz}; errors (regex) {e1}; error lines {e2}; sorry warnings {ssum} in {len(persorry)} modules; record/recount mismatches {bad}; source≠tree {srcmis}; unbound {unbound}')
    if sorries_expected is not None:
        print('  sorry per module = base-sorries:', persorry==sorries_expected, '' if persorry==sorries_expected else (persorry, sorries_expected))
    return rows, persorry
order=[l.strip() for l in open(f'{iss}/order.txt') if l.strip()]
bs={}
for l in open(f'{iss}/base-sorries.txt'):
    if l.startswith('TOTAL') or not l.strip(): continue
    m,n,_=l.split(':',2); bs[m.strip()]=int(n)
boot,_=run('bootstrap', f'{ev}/build/bootstrap', '01cc6259480ccc9372181cd4d18d4511c87aa048', order, bs)
# issued SOURCE-SHA256SUMS
src={}
for l in open(f'{iss}/SOURCE-SHA256SUMS'):
    h,p=l.split(None,1); src[p.strip()]=h
print('  bootstrap src = SOURCE-SHA256SUMS:', all(src.get(r['module']+'.lean')==r['src_sha256'] for r in boot), len(src))
down=[l.split('\t')[3].strip() for l in open(f'{iss}/closures.txt') if l.startswith('DOWN\t')]
pos={m:i for i,m in enumerate(order)}
exp=sorted(down,key=lambda m:pos[m])
# insert new modules
def ins(lst,after,new):
    i=lst.index(after); lst.insert(i+1,new)
exp2=list(exp)
ins(exp2,'TCSlib/Cryptography/Games/Hopping','TCSlib/Cryptography/Games/Tapes') if 'TCSlib/Cryptography/Games/Hopping' in exp2 else None
print('  Hopping in DOWN:', 'TCSlib/Cryptography/Games/Hopping' in down, ' Interaction in DOWN:', 'TCSlib/Cryptography/ZeroKnowledge/Interaction' in down)
sw,swsorry=run('sweep', f'{ev}/build/sweep', '985dd3125d8fd588cf2c8faa31ced8dee88407ab', down+['TCSlib/Cryptography/Games/Tapes','TCSlib/Cryptography/ZeroKnowledge/InteractionWords'])
print('  sweep sorry modules', swsorry, ' expected (base-sorries ∩ sweep):', {m:n for m,n in bs.items() if m in set(r['module'] for r in sw)})
# order consistency: sweep order is a subsequence of order with new modules
seq=[r['module'] for r in sw]
po=[pos.get(m) for m in seq if m in pos]
print('  sweep order monotone in order.txt:', all(a<b for a,b in zip(po,po[1:])))
# timing comparison
bt={r['module']:r['secs'] for r in boot}
ratio=[(r['secs']/bt[r['module']]) for r in sw if r['module'] in bt and bt[r['module']]>5]
ratio.sort()
print(f'  sweep/bootstrap time ratio over {len(ratio)} modules (bootstrap>5s): min {ratio[0]:.2f} median {ratio[len(ratio)//2]:.2f} max {ratio[-1]:.2f}')
print('  total secs bootstrap', round(sum(bt.values())), 'sweep', round(sum(r['secs'] for r in sw)))
