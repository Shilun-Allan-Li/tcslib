"""down.py IMPORTS.json CHANGEDFILE [extra roots...]: root closure, downstream of changed (incl.), upstream closure of that."""
import json, sys
imp=json.load(open(sys.argv[1])); changed=[l.strip() for l in open(sys.argv[2]) if l.strip()]
roots=['TCSlib']+sys.argv[3:]
def clo(starts):
    seen=set(); st=list(starts)
    while st:
        m=st.pop()
        if m in seen or m not in imp: continue
        seen.add(m); st.extend(imp[m])
    return seen
C=clo(roots)
rev={}
for m in C:
    for d in imp[m]:
        rev.setdefault(d,set()).add(m)
down=set(); st=[c for c in changed if c in C]
while st:
    m=st.pop()
    if m in down: continue
    down.add(m); st.extend(rev.get(m,()))
up=clo(down)
print('closure', len(C), 'changed-in-closure', len([c for c in changed if c in C]), 'down (incl. roots)', len(down), 'down excl TCSlib', len(down-{'TCSlib'}), 'upstream-closure of down', len(up), 'excl TCSlib', len(up-{'TCSlib'}))
print('roots in down:', [r for r in roots if r in down])
if len(sys.argv)>3 or True:
    open(sys.argv[2]+'.down','w').write('\n'.join(sorted(down))+'\n')
