import sys, re
rows=[l.rstrip('\n').split('\t') for l in open(sys.argv[1],encoding='utf-8')]
root=sys.argv[2]
cache={}
DECL=re.compile(r'^\s*(?:/--|@\[|(?:protected |private |noncomputable )*(?:theorem|lemma|def|abbrev|instance|structure|end |section|namespace|open |variable|attribute|#))')
for r in rows:
    path,ln=r[1].rsplit(':',1); ln=int(ln)
    L=cache.setdefault(path,open(f'{root}/{path}',encoding='utf-8').read().split('\n'))
    i=ln-1
    # docstring above
    j=i-1; doc=[]
    while j>=0 and not L[j].strip().startswith('/--'):
        doc.append(L[j]); j-=1
        if i-j>80: break
    if j>=0: doc.append(L[j])
    doc='\n'.join(reversed(doc))
    # header end: first line containing ':=' at depth... approximate: first line with ':= by' or ending ':=' or ' :=' or '|' start
    k=i; 
    while k<len(L) and not re.search(r':=\s*(by)?\s*$|:= by|:=\s*\S| where\s*$',L[k]) and not L[k+1].lstrip().startswith('|'): k+=1
    # proof end: next blank line followed by decl/doc or next decl start
    e=k+1
    while e<len(L) and not (L[e].strip()=='' or DECL.match(L[e])): e+=1
    plen=e-k  # lines from := line to end (inclusive of := line)
    sk='**Proof sketch.**' in doc
    glue='Framework glue' in doc; tag='[PS10' in doc
    flag='NEEDS-SKETCH' if plen>=15 and not sk else ''
    print(f"{plen:3d}\tsk={'Y' if sk else '-'}\t{'glue' if glue else ''}{'tag' if tag else ''}\t{r[2]}\t{flag}")
