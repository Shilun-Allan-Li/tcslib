import Mathlib.Data.ZMod.Basic
import Mathlib.GroupTheory.OrderOfElement
example {p : ℕ} [Fact p.Prime] : NeZero p := inferInstance
example {M : Type*} [Group M] [Fintype M] {p : ℕ}
    [Fact p.Prime] (hM : Fintype.card M = p) {g : M} (hg : g ≠ 1) :
    Function.Bijective fun a : ZMod p => g ^ a.val := by
  have ho : orderOf g = p := orderOf_eq_prime (by rw [← hM]; exact pow_card_eq_one) hg
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨fun a b hab => ZMod.val_injective p ?_, by rw [ZMod.card, hM]⟩
  exact pow_injOn_Iio_orderOf (ho ▸ ZMod.val_lt a) (ho ▸ ZMod.val_lt b) hab
