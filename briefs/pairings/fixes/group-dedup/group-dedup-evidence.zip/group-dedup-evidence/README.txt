group-dedup evidence (both commits of PR #365)
commit 1 6fc5f49456507dab5901045356ea40acf42bdd67 -> run-commit1/
commit 2 5eaddd171bceccee917929e7f319ff9202994c59 -> run-commit2/ (head; diff vs tip: run-commit2/group-dedup.diff.txt; commit-2 diff: run-commit2/commit2.diff.txt)
base 5aed99076d2bd4e5d6f831aed88739fc3ce475b6; records tip at push of commit 2: bfa1f5a4da9ca01876b2536968811084fe53d3dd (records only vs base)
