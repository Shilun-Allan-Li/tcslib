import TCSlib.Cryptography.AdvancedEncryption.IdentityBased.BonehBoyenSecurity
import TCSlib.Cryptography.KeyExchange.Joux
import Lean

/-! Axioms probe (grpfix, DW-11 follow-up; not for landing). (1) The axioms of the generic lemma
`pow_val_bijective_of_prime_card` and of the five touched lemmas of `Pairing/Group.lean` (commit 2 adds `pow_val_mul_GT`), and of `bb1_sidSecure` and
Joux's security theorem `jouxKeyIndist_of_dbdhAssumption`. (2) A census of every stored constant of `Pairing.Group`.
(3) `#sorry_trace` (the elaborator of the bb1-sim phase-2 probe `AxiomsBsf.lean`, verbatim) of `bb1_sidSecure` and
`jouxKeyIndist_of_dbdhAssumption`, and a sorry control at the end that must be NONSTANDARD and its own trace's one
direct `sorryAx` user. On the base tree the first name does not exist; that line then reports MISSING. -/

open Lean Elab Command

elab "#sorry_trace " n:ident : command => do
  let env ← getEnv
  let root := n.getId
  let mut seen : NameSet := {}
  let mut stack : Array Name := #[root]
  let mut hits : Array Name := #[]
  let mut fuel := 1000000
  while fuel > 0 && stack.size > 0 do
    fuel := fuel - 1
    let c := stack.back!
    stack := stack.pop
    if seen.contains c then continue
    seen := seen.insert c
    match env.find? c with
    | none => pure ()
    | some ci =>
      let refs := ci.getUsedConstantsAsSet
      if refs.contains ``sorryAx then hits := hits.push c
      for r in refs do
        unless seen.contains r do stack := stack.push r
  logInfo m!"TRACE {root}: closure {seen.size}; direct sorryAx users: {hits.qsort Name.lt}"

def stdAx : List Name := [``propext, ``Classical.choice, ``Quot.sound]

run_cmd do
  let env ← getEnv
  let names : List Name := [`TCSlib.Cryptography.Pairing.pow_val_bijective_of_prime_card, `TCSlib.Cryptography.Pairing.BilinearGroup.pow_val_bijective, `TCSlib.Cryptography.Pairing.BilinearGroup.pow_val_bijective_of_ne_one, `TCSlib.Cryptography.Pairing.BilinearGroup.pow_val_add, `TCSlib.Cryptography.Pairing.BilinearGroup.pow_val_mul, `TCSlib.Cryptography.Pairing.BilinearGroup.pow_val_mul_GT, `TCSlib.Cryptography.AdvancedEncryption.IdentityBased.bb1_sidSecure, `TCSlib.Cryptography.KeyExchange.jouxKeyIndist_of_dbdhAssumption]
  let mut bad : Nat := 0
  for n in names do
    unless env.contains n do
      logInfo m!"AXIOMS MISSING {n}"
      continue
    let axs ← Lean.collectAxioms n
    let std := axs.all (stdAx.contains ·)
    unless std do bad := bad + 1
    logInfo m!"AXIOMS {if std then "STANDARD" else "NONSTANDARD"} {n}: {axs.qsort Name.lt}"
  logInfo m!"AXIOMS-LIST {names.length} constants, {bad} non-standard"

run_cmd do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.Pairing.Group]
  for m in mods do
    let some idx := env.getModuleIdx? m | logInfo m!"CENSUS MISSING MODULE {m}"
    let mut total := 0
    let mut bad : Array Name := #[]
    for (n, _) in env.constants.map₁.toList do
      if env.getModuleIdxFor? n == some idx then
        total := total + 1
        let axs ← Lean.collectAxioms n
        unless axs.all (stdAx.contains ·) do bad := bad.push n
    logInfo m!"CENSUS {m}: {total} stored constants, {bad.size} non-standard {bad}"

#sorry_trace TCSlib.Cryptography.AdvancedEncryption.IdentityBased.bb1_sidSecure
#sorry_trace TCSlib.Cryptography.KeyExchange.jouxKeyIndist_of_dbdhAssumption
#sorry_trace TCSlib.Cryptography.Pairing.pow_val_bijective_of_prime_card

-- sorry control: the trace and the axiom check must both see it.
theorem grpSorryControl : (1 : ℕ) = 1 := sorry
#sorry_trace grpSorryControl
run_cmd do
  let axs ← Lean.collectAxioms ``grpSorryControl
  logInfo m!"CONTROL AXIOMS {if axs.all (stdAx.contains ·) then "STANDARD" else "NONSTANDARD"} grpSorryControl: {axs.qsort Name.lt}"
