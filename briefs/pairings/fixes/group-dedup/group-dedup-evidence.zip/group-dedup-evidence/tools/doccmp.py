"""doccmp.py <repo> <base> <head> <path>: compares every doc comment (/-- -/ and /-! -/) of <path> at <base> and <head>,
in order; prints the ones only at one side. Read-only."""
import sys, re, subprocess
repo, base, head, path = sys.argv[1:5]
src = lambda r: subprocess.run(['git', '-C', repo, 'show', f'{r}:{path}'], capture_output=True, text=True, check=True).stdout
docs = lambda s: re.findall(r'/-[-!].*?-/', s, re.S)
b, h = docs(src(base)), docs(src(head))
onlyb = [d for d in b if d not in h]; onlyh = [d for d in h if d not in b]
print(f'docs base {len(b)} head {len(h)}; only-base {len(onlyb)}; only-head {len(onlyh)}; base order kept {[d for d in h if d in b] == b}')
for d in onlyb: print('ONLY-BASE', d[:120].replace('\n', ' '))
for d in onlyh: print('ONLY-HEAD', d[:120].replace('\n', ' '))
