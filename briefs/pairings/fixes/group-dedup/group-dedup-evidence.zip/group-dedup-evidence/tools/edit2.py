import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
reps = [
("""* `BilinearGroup.pow_val_bijective_of_ne_one` — `a ↦ g^a` is a bijection `Z_p → G` for `g ∈ G^*`.
""",
"""* `BilinearGroup.pow_val_bijective_of_ne_one` — `a ↦ g^a` is a bijection `Z_p → G` for `g ∈ G^*`.
* `pow_val_bijective_of_prime_card` — `a ↦ g^a` is a bijection `Z_p → M` for `g ≠ 1` in any finite
  group `M` of prime order `p` (the generic form of the two bijections above).
"""),
("""    y ^ (a * b).val = y ^ (a.val * b.val) := by
  rw [ZMod.val_mul, ← Nat.mod_add_div (a.val * b.val) B.order, pow_add, pow_mul, B.pow_order_GT,
    one_pow, mul_one, Nat.mod_add_div]
""",
"""    y ^ (a * b).val = y ^ (a.val * b.val) := by
  rw [ZMod.val_mul, ← pow_mod_card y (a.val * b.val), B.card_GT]
"""),
]
for old, new in reps:
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
print("ok")
