#!/usr/bin/env bash
# rule10_grp.sh <base|head> <phase>... (grpfix): LE-g48's rule10_g48.sh (statements, collect, sealcoeA phases) re-pointed at
# Pairing/Group.lean: owner TCSlib.Cryptography.Pairing.Group, base 5aed9907 (export basex, tree olean-replay-cs1-s6, read only:
# every probe goes through runner_full_gated.py, `lean` without -o, so nothing is written to a tree) and head 6fc5f494 (export
# wtx, tree olean-replay-grpfix). Tools: bsp2/tools/seal (unmodified). Probe prefix GRP. One Lean process; slot gate 30 s.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G0=$SP/grpfix-work; E=$G0/run; T=$SP/bsp2/tools/seal; A=$T/review/archived-gate10-tools
BASE=5aed99076d2bd4e5d6f831aed88739fc3ce475b6; HEADC=6fc5f49456507dab5901045356ea40acf42bdd67
side=$1; shift
case $side in
base) W=$G0/basex; TREE=$SP/olean-replay-cs1-s6; H=$BASE;;
head) W=$G0/wtx; TREE=$SP/olean-replay-grpfix; H=$HEADC;;
*) echo "side?"; exit 2;;
esac
export GIT_DIR=/home/user/tcslib/.git TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH
OWN=TCSlib.Cryptography.Pairing.Group; FILES=TCSlib/Cryptography/Pairing/Group.lean
P=GRP; R=$E/rule10/$side; TJ=$E/statements/touched.json
gate() { while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean $1" >> $E/slot-waits.txt; sleep 30; done
         echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $side $1" >> $E/slot-log.txt; }
mkdir -p $E/tmp $E/statements $R/order $R/probe-sources $W/$P
for ph in "$@"; do
echo "phase $ph side $side start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
statements)
  python3 -I $T/review/touched.py /home/user/tcslib $BASE $HEADC $TJ $FILES > $E/statements/touched.tsv 2>&1; echo "touched rc=$?";;
collect)
  printf '%s\n' $OWN > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "grpfix Group.lean collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  gate collect; python3 -I $T/runner_full_gated.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
sealcoeA)
  LOG=$R/probe-runs/mods/${P}_CollectHead.log
  ( cd $T && python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/seals-coe/A $P/C SealA_ $OWN > $R/mkseals-coe-A.log ); echo "mkseals_coe rc=$?"
  (cd $W && ls $P/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
  for f in $W/$P/C/*.lean; do cp $f $R/probe-sources/$(basename $f).txt; done
  gate seal; python3 -I $T/runner_full_gated.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1; echo "seal runner rc=$?"
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv; echo "sealsum rc=$?"
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
esac
echo "phase $ph side $side done $(date -u +%FT%TZ)"
done
