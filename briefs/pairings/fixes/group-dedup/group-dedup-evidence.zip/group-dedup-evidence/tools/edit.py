import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
reps = [
("""attribute [instance] BilinearGroup.commGroupG BilinearGroup.commGroupGT BilinearGroup.fintypeG
  BilinearGroup.fintypeGT BilinearGroup.decEqG BilinearGroup.decEqGT

namespace BilinearGroup
""",
"""attribute [instance] BilinearGroup.commGroupG BilinearGroup.commGroupGT BilinearGroup.fintypeG
  BilinearGroup.fintypeGT BilinearGroup.decEqG BilinearGroup.decEqGT

/-- **`a ↦ g^a` is a bijection `Z_p → M`** for every `g ≠ 1` in a finite group `M` of prime order
`p`: if `|M| = p` is prime and `g ≠ 1`, then `Function.Bijective fun a : ZMod p => g ^ a.val`.
The one statement behind `BilinearGroup.pow_val_bijective` (on `G_T`) and
`BilinearGroup.pow_val_bijective_of_ne_one` (on `G`).

Glue lemma, with no counterpart in [BB04]: elementary group theory, assembled from Mathlib
(`orderOf_eq_prime`, `pow_injOn_Iio_orderOf`). Mathlib's closest statement,
`IsCyclic.unique_zpow_zmod`, gives the unique exponent in `ZMod (Fintype.card M)` of each element
for a generator `g`, not this bijectivity on `ZMod p`.

**Proof sketch.** By Lagrange, `g^p = 1`, so `g ≠ 1` has order exactly `p`. Hence `n ↦ g^n` is
injective on `{0, …, p - 1}`, which contains every `a.val`, so `a ↦ g^{a.val}` is injective on
`Z_p`. Both sides have `p` elements, so it is a bijection. -/
theorem pow_val_bijective_of_prime_card {M : Type*} [Group M] [Fintype M] {p : ℕ}
    [Fact p.Prime] (hM : Fintype.card M = p) {g : M} (hg : g ≠ 1) :
    Function.Bijective fun a : ZMod p => g ^ a.val := by
  haveI : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  have ho : orderOf g = p := orderOf_eq_prime (by rw [← hM]; exact pow_card_eq_one) hg
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨fun a b hab => ZMod.val_injective p ?_, by rw [ZMod.card, hM]⟩
  exact pow_injOn_Iio_orderOf (ho ▸ ZMod.val_lt a) (ho ▸ ZMod.val_lt b) hab

namespace BilinearGroup
"""),
("""theorem pow_val_mul (x : B.G) (a b : ZMod B.order) : x ^ (a * b).val = x ^ (a.val * b.val) := by
  rw [ZMod.val_mul, ← Nat.mod_add_div (a.val * b.val) B.order, pow_add, pow_mul, B.pow_order,
    one_pow, mul_one, Nat.mod_add_div]
""",
"""theorem pow_val_mul (x : B.G) (a b : ZMod B.order) : x ^ (a * b).val = x ^ (a.val * b.val) := by
  rw [ZMod.val_mul, ← pow_mod_card x (a.val * b.val), B.card_G]
"""),
("""    Function.Bijective fun a : ZMod B.order => B.pair x x ^ a.val := by
  have ho : orderOf (B.pair x x) = B.order :=
    orderOf_eq_prime (B.pow_order_GT _) (B.pair_ne_one hx)
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨fun a b hab => ZMod.val_injective _ ?_, by rw [ZMod.card, B.card_GT]⟩
  have h := pow_eq_pow_iff_modEq.1 hab
  rw [ho] at h
  exact Nat.ModEq.eq_of_lt_of_lt h (ZMod.val_lt a) (ZMod.val_lt b)
""",
"""    Function.Bijective fun a : ZMod B.order => B.pair x x ^ a.val := by
  exact pow_val_bijective_of_prime_card B.card_GT (B.pair_ne_one hx)
"""),
("""    x ^ (a + b).val = x ^ a.val * x ^ b.val := by
  rw [ZMod.val_add, ← pow_add, ← Nat.mod_add_div (a.val + b.val) B.order, pow_add, pow_mul,
    B.pow_order, one_pow, mul_one, Nat.mod_add_div]
""",
"""    x ^ (a + b).val = x ^ a.val * x ^ b.val := by
  rw [ZMod.val_add, ← pow_add, ← pow_mod_card x (a.val + b.val), B.card_G]
"""),
("""    Function.Bijective fun a : ZMod B.order => g ^ a.val := by
  have ho : orderOf g = B.order := orderOf_eq_prime (B.pow_order _) hg
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨fun a b hab => ZMod.val_injective _ ?_, by rw [ZMod.card, B.card_G]⟩
  have h := pow_eq_pow_iff_modEq.1 hab
  rw [ho] at h
  exact Nat.ModEq.eq_of_lt_of_lt h (ZMod.val_lt a) (ZMod.val_lt b)
""",
"""    Function.Bijective fun a : ZMod B.order => g ^ a.val := by
  exact pow_val_bijective_of_prime_card B.card_G hg
"""),
]
for old, new in reps:
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
print("ok")
