r"""censusderive.py <repo> <ref-rev> <ref-census.txt> <rev> <out> <name=records.jsonl>... (grpfix, new): admissions census at <rev>
when the older record sets behind <ref-census.txt> (a tipcensus.py output at <ref-rev>) are no longer on disk. For each
TCSlib/audits module at <rev>: if an rc-0 record of the given sets matches its source SHA-256 at <rev>, its `sorry` count
comes from that record (source 'rec'); otherwise, if its source blob at <rev> equals the blob at <ref-rev>, the count is the
reference census row (source 'ref'); otherwise it is UNRESOLVED. Also prints, for every module with both a record and a
reference row of equal source, whether they agree. Read-only."""
import sys, json, hashlib, subprocess, re
repo, refrev, refc, rev, out = sys.argv[1:6]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout
def mods(r): return {f[:-5] for f in git('ls-tree', '-r', '--name-only', r, 'TCSlib', 'TCSlib.lean', 'audits').decode().split() if f.endswith('.lean')}
def blobs(r):
    d = {}
    for l in git('ls-tree', '-r', r, 'TCSlib', 'TCSlib.lean', 'audits').decode().splitlines():
        meta, p = l.split('\t'); 
        if p.endswith('.lean'): d[p[:-5]] = meta.split()[2]
    return d
ref = {}
for l in open(refc):
    m = re.match(r'^\s*(\d+) (\S+)  \[', l)
    if m: ref[m.group(2)] = int(m.group(1))
    elif l.startswith('NOREC '): ref[l.split()[1]] = None
recs = {}
for a in sys.argv[6:]:
    n, f = a.split('=', 1)
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: recs.setdefault((r['module'], r['source_sha256']), {}).setdefault(r['sorry'], set()).add(n)
B, BR = blobs(rev), blobs(refrev)
tot = 0; unres = []; norec = []; agree = disagree = 0; srcs = {'rec': 0, 'ref': 0}
with open(out, 'w') as o:
    for m in sorted(B):
        h = hashlib.sha256(git('show', f'{rev}:{m}.lean')).hexdigest(); d = recs.get((m, h))
        same = BR.get(m) == B[m]
        if d:
            c = min(d); src = 'rec'
            if same and ref.get(m) is not None:
                if ref[m] == c: agree += 1
                else: disagree += 1; o.write(f'DISAGREE {m} rec {c} ref {ref[m]}\n')
        elif same and m in ref:
            c = ref[m]; src = 'ref'
            if c is None: norec.append(m); o.write(f'NOREC {m}\n'); continue
        else:
            unres.append(m); o.write(f'UNRESOLVED {m}\n'); continue
        srcs[src] += 1; tot += c
        o.write(f'{c:3d} {m}  [{src}]\n')
    o.write(f'TOTAL {tot} sorry warnings over {srcs["rec"] + srcs["ref"]} modules (record {srcs["rec"]}, reference row {srcs["ref"]}); '
            f'no record {len(norec)}; unresolved {len(unres)} {unres}; record/reference agree {agree}, disagree {disagree}\n')
print(open(out).read().splitlines()[-1])
