"""ctl_recount.py <evidence-dir> <series>: per-control recount of the paired controls from the raw
logs. For each variant (controls-coe, controls-strict) and probe of its controls-plan.json, the log's
errors (both forms) are attributed to controls by the plan's line ranges. Expected: in a sealed probe
each negative fails exactly once and each positive passes; an unsealed probe has no error; no error
outside a control range. Reviewer's tool (bb1-sim-statements r1, phase 1)."""
import json
import os
import re
import sys

ev, series = sys.argv[1:3]
ERR = re.compile(r'^\S+\.lean:(\d+):\d+: error[:(]', re.M)
base = os.path.join(ev, 'rule10', series)
allok = True
for var in ('controls-coe', 'controls-strict'):
    plan = json.load(open(os.path.join(base, var, 'controls-plan.json')))
    neg_fail = neg_tot = pos_tot = pos_fail = unsealed_err = stray = 0
    for p in plan:
        log = os.path.join(base, 'seal-runs', 'mods', p['module'].replace('/', '_') + '.log')
        lines = [int(x) for x in ERR.findall(open(log, errors='replace').read())]
        counts = {c['control']: 0 for c in p['controls']}
        for ln in lines:
            hit = [c for c in p['controls'] if c['start_line'] <= ln <= c['end_line']]
            if hit:
                counts[hit[0]['control']] += 1
            else:
                stray += 1
        for c in p['controls']:
            n = counts[c['control']]
            if p['sealed']:
                if c['negative']:
                    neg_tot += 1
                    neg_fail += n == 1
                    allok &= n == 1
                else:
                    pos_tot += 1
                    pos_fail += n != 0
                    allok &= n == 0
            else:
                unsealed_err += n
                allok &= n == 0
        print(f'  {var} {p["label"]} ({p["module"].split("/")[1]}, sealed {p["sealed"]}): errors '
              f'{len(lines)}; ' + ', '.join(f'{k} {v}' for k, v in counts.items()))
    allok &= stray == 0
    print(f'{var}: probes {len(plan)}; sealed negatives failing exactly once {neg_fail}/{neg_tot}; '
          f'sealed positives failing {pos_fail}/{pos_tot}; unsealed errors {unsealed_err}; stray '
          f'errors {stray}')
print(f'{series}: ALL_OK {allok}')
