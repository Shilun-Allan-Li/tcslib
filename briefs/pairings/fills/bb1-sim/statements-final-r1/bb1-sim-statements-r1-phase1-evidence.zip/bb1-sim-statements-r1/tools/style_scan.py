"""style_scan.py <repo> <rev> <file>...: widths, sizes and forbidden tokens of files at <rev>
(read from git, no export). Reviewer's tool, bb1-sim-statements r1 phase 1."""
import re
import subprocess
import sys

repo, rev, files = sys.argv[1], sys.argv[2], sys.argv[3:]
PATTERNS = {
    'micro-sign U+00B5': re.compile('µ'),
    'tab': re.compile('\t'),
    'trailing-space': re.compile(r'[ ]+$'),
    '@[simp': re.compile(r'@\[simp'),
    'attribute [': re.compile(r'^\s*attribute\s*\['),
    'sorry': re.compile(r'\bsorry\b'),
    'admit': re.compile(r'\badmit\b'),
    'native_decide': re.compile(r'native_decide'),
    'axiom decl': re.compile(r'^\s*axiom\s'),
    'adversary rule (ci)': re.compile(r'adversary rule', re.I),
    '[BGZ09, rule': re.compile(r'\[BGZ09,\s*rule'),
    'location placeholder': re.compile('⟨location|to pin'),
    'open (top-level)': re.compile(r'^open\s'),
}
for f in files:
    text = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True,
                          check=True).stdout.decode()
    lines = text.split('\n')
    if lines and lines[-1] == '':
        lines = lines[:-1]
    widths = [len(l) for l in lines]
    over = [i + 1 for i, w in enumerate(widths) if w > 100]
    print(f'{f}: lines {len(lines)}, max width {max(widths)}, over-100 {over or "none"}, '
          f'ends-with-newline {text.endswith(chr(10))}')
    for name, pat in PATTERNS.items():
        hits = [i + 1 for i, l in enumerate(lines) if pat.search(l)]
        if hits:
            print(f'  {name}: lines {hits}')
