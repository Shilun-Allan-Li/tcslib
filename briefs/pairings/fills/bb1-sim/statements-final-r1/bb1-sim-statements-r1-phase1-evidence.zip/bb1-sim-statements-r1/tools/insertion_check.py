"""insertion_check.py <repo> <base-rev> <head-rev> <file> <anchor>[,<anchor>...] [--controls]

Reviewer's pure-insertion check (bb1-sim-statements r1, phase 1). Reads both versions from git.
PASS iff (a) every difflib opcode between base and head is `equal` or `insert`, (b) the insert
positions, each widened over the range a block can slide across identical neighbouring lines,
cover exactly the expected anchors (one block per anchor, "after base line N"), and (c) deleting
the inserted lines from the head restores the base byte for byte (SHA-256 compared).
--controls runs five mutations of the head (changed character in a base line, deleted base line,
extra line elsewhere, first block moved down 3 lines, unchanged) and reports each result.
"""
import difflib
import hashlib
import subprocess
import sys


def show(repo, rev, path):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True,
                          check=True).stdout.decode()


def check(base_text, head_text, anchors, verbose=True):
    base = base_text.split('\n')
    head = head_text.split('\n')
    sm = difflib.SequenceMatcher(a=base, b=head, autojunk=False)
    ops = [op for op in sm.get_opcodes() if op[0] != 'equal']
    bad = [op for op in ops if op[0] != 'insert']
    blocks = []
    keep = [True] * len(head)
    for tag, i1, i2, j1, j2 in ops:
        if tag != 'insert':
            continue
        block = head[j1:j2]
        lo = hi = i1
        b = list(block)
        while lo > 0 and b[-1] == base[lo - 1]:
            b = [base[lo - 1]] + b[:-1]
            lo -= 1
        b = list(block)
        while hi < len(base) and b[0] == base[hi]:
            b = b[1:] + [base[hi]]
            hi += 1
        blocks.append((lo, hi, j1 + 1, j2, len(block)))
        for j in range(j1, j2):
            keep[j] = False
    restored = '\n'.join(h for h, k in zip(head, keep) if k)
    restore_ok = hashlib.sha256(restored.encode()).hexdigest() == \
        hashlib.sha256(base_text.encode()).hexdigest()
    anchor_ok = len(blocks) == len(anchors) and all(
        lo <= a <= hi for (lo, hi, *_), a in zip(blocks, sorted(anchors)))
    ok = not bad and anchor_ok and restore_ok
    if verbose:
        for (lo, hi, h1, h2, n), a in zip(blocks, sorted(anchors) + [None] * len(blocks)):
            print(f'  block: {n} lines, head lines {h1}-{h2}, after base line {lo}'
                  f'{"" if lo == hi else f"..{hi} (slides over identical lines)"}; expected anchor '
                  f'{a}: {"OK" if a is not None and lo <= a <= hi else "MISMATCH"}')
        for op in bad:
            print(f'  non-insert opcode: {op}')
        print(f'  restore after removing the blocks: {"byte-identical" if restore_ok else "DIFFERS"}')
    return ok, len(bad)


def main():
    repo, brev, hrev, path, anchors = sys.argv[1:6]
    anchors = [int(a) for a in anchors.split(',')]
    base_text = show(repo, brev, path)
    head_text = show(repo, hrev, path)
    print(f'{path}: base {brev[:12]} sha256 {hashlib.sha256(base_text.encode()).hexdigest()} '
          f'({base_text.count(chr(10))} lines)')
    print(f'{path}: head {hrev[:12]} sha256 {hashlib.sha256(head_text.encode()).hexdigest()} '
          f'({head_text.count(chr(10))} lines)')
    ok, _ = check(base_text, head_text, anchors)
    print(f'RESULT {"PASS" if ok else "FAIL"}')
    if '--controls' in sys.argv:
        head = head_text.split('\n')
        base = base_text.split('\n')
        sm = difflib.SequenceMatcher(a=base, b=head, autojunk=False)
        first = [op for op in sm.get_opcodes() if op[0] == 'insert'][0]
        eq_line = next(j2 - 1 for tag, i1, i2, j1, j2 in sm.get_opcodes()
                       if tag == 'equal' and j2 - j1 > 5)
        m1 = list(head)
        m1[eq_line] = (m1[eq_line][:-1] + ('X' if m1[eq_line][-1:] != 'X' else 'Y')) \
            if m1[eq_line] else 'X'
        m2 = list(head)
        del m2[eq_line]
        m3 = list(head)
        m3.insert(eq_line, '-- extra line')
        tag, i1, i2, j1, j2 = first
        blk = head[j1:j2]
        rest = head[:j1] + head[j2:]
        m4 = rest[:j1 + 3] + blk + rest[j1 + 3:]
        controls = [('changed character in a base line', m1, 'FAIL'),
                    ('deleted base line', m2, 'FAIL'),
                    ('extra line elsewhere', m3, 'FAIL'),
                    ('first block moved down 3 lines', m4, 'FAIL'),
                    ('unchanged', head, 'PASS')]
        allok = True
        for name, m, want in controls:
            ok, nbad = check(base_text, '\n'.join(m), anchors, verbose=False)
            got = 'PASS' if ok else 'FAIL'
            allok &= got == want
            print(f'  control {name}: {got} (non-insert opcodes {nbad}); expected {want}: '
                  f'{"OK" if got == want else "WRONG"}')
        print(f'CONTROLS {"ALL_OK" if allok else "NOT_OK"}')


if __name__ == '__main__':
    main()
