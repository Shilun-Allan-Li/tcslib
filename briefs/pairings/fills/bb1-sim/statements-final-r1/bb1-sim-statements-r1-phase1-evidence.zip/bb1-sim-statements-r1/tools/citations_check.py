"""citations_check.py <repo> <rev> <file>...: every bracketed source citation ([BGZ09, ...],
[Sho04, ...]) in the given files at <rev>, by declaration, against the approved strings of
review dw8-final-r1 section 4 (the bb1-sim brief's table); the F4 note verbatim (whitespace
normalized) in expect_simulate_rel; the module References lines verbatim; no "adversary rule" and no
"[BGZ09, rule". Reviewer's tool (bb1-sim-statements r1, phase 1)."""
import re
import subprocess
import sys

APPROVED = {'[BGZ09, §4.1, lemma (=⟦⟧)]', '[BGZ09, §4.2, ⊨_φ]', '[BGZ09, §4.1, Def. 5]',
            '[BGZ09, §5.2, Lemma 1]', '[BGZ09, §3.4]', '[Sho04, §1.1, bridging steps]',
            '[Sho04, §4.2, Game 2]'}
F4 = ('[BGZ09] states no rule for adversary calls with a relational invariant. This lemma '
      'generalizes its `(=⟦⟧)` and `⊨_φ` (§4.1–§4.2) to oracle simulations whose states are '
      'related by an invariant, in the arbitrary-context style of §5.2.')
REFS = ['* [BGZ09] G. Barthe, B. Grégoire, S. Zanella Béguelin, *Formal Certification of Code-Based',
        '  Cryptographic Proofs*, POPL 2009.',
        '* [Sho04] V. Shoup, *Sequences of Games: A Tool for Taming Complexity in Security Proofs*,',
        '  Cryptology ePrint Archive 2004/332, revision of 18 January 2006.']
CITE = re.compile(r'\[(?:BGZ09|Sho04)[^\]]*\]')
DECL = re.compile(r'^(?:private\s+)?(?:theorem|lemma|def|abbrev)\s+(\S+)', re.M)
repo, rev, files = sys.argv[1], sys.argv[2], sys.argv[3:]
ok = True
for f in files:
    t = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True,
                       check=True).stdout.decode()
    decls = [(m.start(), m.group(1)) for m in DECL.finditer(t)]
    def owner(pos):
        for start, name in decls:
            if start > pos:
                return name
        return '(after last declaration)'
    print(f'== {f}')
    for m in CITE.finditer(t):
        s = m.group(0)
        bare = s in ('[BGZ09]', '[Sho04]')
        good = s in APPROVED or bare
        ok &= good
        print(f'  {owner(m.start())}: {s} -> {"approved" if s in APPROVED else "bare tag" if bare else "NOT APPROVED"}')
    if 'adversary rule' in t.lower() or re.search(r'\[BGZ09,\s*rule', t):
        ok = False
        print('  FORBIDDEN wording present')
    else:
        print('  no "adversary rule", no "[BGZ09, rule"')
    flat = ' '.join(t.split())
    if 'expect_simulate_rel' in t and f.endswith('Relational.lean'):
        has = ('**Deviation:** ' + F4) in flat
        ok &= has
        print(f'  F4 note verbatim after **Deviation:** : {has}')
        refs = all(l in t.split('\n') for l in REFS)
        ok &= refs
        print(f'  module References lines verbatim: {refs}')
print('RESULT', 'PASS' if ok else 'FAIL')
