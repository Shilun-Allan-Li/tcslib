"""Verify a delivery's SHA256SUMS manifests by streaming blobs from git (no export).

Usage: python3 -I manifest_check.py <repo> <rev> <prefix> <manifest-relpath> [<manifest-relpath> ...]

For each manifest (path relative to <prefix>), the manifest's directory is the base of its
entries. Reports per-manifest: entries, OK, BAD, MISSING, and the path-set comparison against
the files delivered under that directory (excluding the manifest itself).
"""
import hashlib
import subprocess
import sys


def main():
    repo, rev, prefix = sys.argv[1:4]
    manifests = sys.argv[4:]
    prefix = prefix.rstrip('/') + '/'
    ls = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', '--full-tree', rev, prefix],
                        capture_output=True, check=True).stdout.decode()
    blobs = {}
    for line in ls.splitlines():
        meta, path = line.split('\t', 1)
        mode, typ, oid = meta.split()
        blobs[path[len(prefix):]] = oid
    cat = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE)
    shas = {}

    def sha_of(oid):
        cat.stdin.write((oid + '\n').encode())
        cat.stdin.flush()
        header = cat.stdout.readline().split()
        size = int(header[2])
        h = hashlib.sha256()
        left = size
        while left:
            chunk = cat.stdout.read(min(left, 1 << 20))
            h.update(chunk)
            left -= len(chunk)
        cat.stdout.read(1)
        return h.hexdigest()

    for rel, oid in sorted(blobs.items()):
        shas[rel] = sha_of(oid)
    print(f'delivered files under {prefix}: {len(blobs)}')
    allok = True
    for man in manifests:
        base = man.rsplit('/', 1)[0] + '/' if '/' in man else ''
        text = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{prefix}{man}'],
                              capture_output=True, check=True).stdout.decode()
        entries = {}
        dup = 0
        dotslash = 0
        for line in text.splitlines():
            if not line.strip():
                continue
            digest, path = line.split(None, 1)
            path = path.lstrip('*')
            if path.startswith('./'):
                dotslash += 1
            if path in entries:
                dup += 1
            entries[path] = digest
        ok = bad = missing = 0
        bads = []
        for path, digest in entries.items():
            full = base + path
            if full not in shas:
                missing += 1
                bads.append(('MISSING', full))
            elif shas[full] == digest:
                ok += 1
            else:
                bad += 1
                bads.append(('BAD', full))
        delivered = {p[len(base):] for p in shas if p.startswith(base) and p != man}
        extra = sorted(delivered - set(entries))
        absent = sorted(set(entries) - delivered)
        status = (bad == 0 and missing == 0 and not extra and not absent and dup == 0
                  and dotslash == 0)
        allok &= status
        print(f'manifest {man}: entries {len(entries)}, OK {ok}, BAD {bad}, MISSING {missing}, '
              f'duplicates {dup}, leading-./ {dotslash}; delivered under {base or "./"} '
              f'(excluding manifest) {len(delivered)}; extra {len(extra)}; absent {len(absent)}; '
              f'{"PASS" if status else "FAIL"}')
        for kind, p in bads[:20]:
            print(f'  {kind} {p}')
        for p in extra[:20]:
            print(f'  EXTRA {p}')
        for p in absent[:20]:
            print(f'  ABSENT {p}')
    cat.stdin.close()
    cat.wait()
    if len(sys.argv) > 4:
        print('ALL_PASS' if allok else 'SOME_FAIL')
    return shas


if __name__ == '__main__':
    main()
