"""seal_recount.py <evidence-dir> <seal-src-dir> <log-dir> <log-prefix> <head-src-root>

For each seal source <seal-src-dir>/{A,B}/Seal{A,B}_<owner>.lean.txt: (1) the probe equals the head
source of its owner plus inserted harness blocks only (`import Lean`, `/- G06-HARNESS ...` blocks; a blank line at EOF);
(2) its log <log-dir>/<log-prefix>Seal{A,B}_<owner>.log carries the install MASK, the EOF MASK and
`G06-SEAL-END requested=N verified=N`; (3) its errors (both forms) are attributed to the declaration
containing the error line. Reviewer's tool (bb1-sim-statements r1, phase 1)."""
import difflib
import os
import re
import sys

ev, srcdir, logdir, prefix, headroot = sys.argv[1:6]
ERR = re.compile(r'^\S+\.lean:(\d+):\d+: error[:(]', re.M)
DECL = re.compile(r'^(?:private\s+|protected\s+|noncomputable\s+)*(?:theorem|lemma|def|abbrev|instance|structure)\s+(\S+)')
for var in ('A', 'B'):
    d = os.path.join(ev, srcdir, var)
    for fn in sorted(os.listdir(d)):
        if not fn.endswith('.lean.txt'):
            continue
        base = fn[:-len('.lean.txt')]
        owner = base.split('_', 1)[1]
        head = os.path.join(headroot, 'TCSlib', owner.replace('_', '/') + '.lean')
        seal = open(os.path.join(d, fn)).read().split('\n')
        hsrc = open(head).read().split('\n')
        ops = difflib.SequenceMatcher(a=hsrc, b=seal, autojunk=False).get_opcodes()
        bad = [o for o in ops if o[0] not in ('equal', 'insert')]
        ins = [seal[o[3]] for o in ops if o[0] == 'insert']
        harness_only = not bad and all(l == 'import Lean' or l.startswith('/- G06-HARNESS')
                                       for l in ins if l != '')
        log = open(os.path.join(ev, logdir, prefix + base + '.log'), errors='replace').read()
        mi = re.search(r'G06-MASK label=\S+ phase=install requested=(\d+) verified=(\d+)', log)
        me = re.search(r'G06-MASK label=\S+ phase=eof requested=(\d+) verified=(\d+)', log)
        se = re.search(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', log)
        errs = [int(m.group(1)) for m in ERR.finditer(log)]
        decls = []
        for ln in errs:
            name = '?'
            for i in range(ln - 1, -1, -1):
                m = DECL.match(seal[i])
                if m:
                    name = m.group(1)
                    break
            decls.append(f'{name}@{ln}')
        print(f'{srcdir}/{var} {base}: probe = head + harness only: {harness_only} '
              f'(inserted blocks {sum(1 for o in ops if o[0] == "insert")}); install '
              f'{mi.groups() if mi else None}; eof {me.groups() if me else None}; end '
              f'{se.groups() if se else None}; errors {len(errs)} {decls}')
