"""sweepbind.py <repo> <evidence-dir> <run-dir> <rev> [<expected-module-list-file>] [--warn-vs <run-dir>]

Binds every record of a delivered sweep to the blob of its module at <rev> (source_sha256), compares
the module set with an expected list, and (with --warn-vs) compares each module's warning lines
(file:line:col: warning ...) with the same module's log in another run (the bootstrap), reporting
modules whose warning sets differ. Reviewer's tool (bb1-sim-statements r1, phase 1)."""
import hashlib
import json
import os
import re
import subprocess
import sys

args = [a for a in sys.argv[1:]]
warn_vs = None
if '--warn-vs' in args:
    i = args.index('--warn-vs')
    warn_vs = args[i + 1]
    del args[i:i + 2]
repo, ev, d, rev = args[:4]
expected = args[4] if len(args) > 4 else None
recs = [json.loads(l) for l in open(os.path.join(ev, d, 'results.jsonl')) if l.strip()]
mods = [r for r in recs if 'module' in r]
bound = unbound = 0
bad = []
for r in mods:
    path = r['module'] + '.lean'
    blob = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True)
    if blob.returncode != 0:
        bad.append(f'{r["module"]}: not in {rev}')
        unbound += 1
        continue
    if hashlib.sha256(blob.stdout).hexdigest() == r.get('source_sha256'):
        bound += 1
    else:
        unbound += 1
        bad.append(f'{r["module"]}: source_sha256 differs from {rev}')
print(f'{d}: {len(mods)} records; bound to {rev}: {bound}; not bound: {unbound}')
for b in bad[:20]:
    print('  ' + b)
if expected:
    exp = [l.strip() for l in open(expected) if l.strip()]
    got = [r['module'] for r in mods]
    print(f'  expected set {len(exp)}; equal: {sorted(set(exp)) == sorted(set(got))}; '
          f'missing {sorted(set(exp) - set(got))[:10]}; extra {sorted(set(got) - set(exp))[:10]}; '
          f'duplicates {len(got) - len(set(got))}')
if warn_vs:
    W = re.compile(r'^\S+\.lean:\d+:\d+: warning.*$', re.M)
    diffs = 0
    for r in mods:
        n = r['module'].replace('/', '_') + '.log'
        a = os.path.join(ev, d, 'mods', n)
        b = os.path.join(ev, warn_vs, 'mods', n)
        if not os.path.exists(b):
            continue
        wa = sorted(W.findall(open(a, errors='replace').read()))
        wb = sorted(W.findall(open(b, errors='replace').read()))
        if wa != wb:
            diffs += 1
            print(f'  warnings differ from {warn_vs}: {r["module"]}: {len(wb)} -> {len(wa)}')
            for x in sorted(set(wa) - set(wb))[:6]:
                print(f'    + {x[:160]}')
            for x in sorted(set(wb) - set(wa))[:6]:
                print(f'    - {x[:160]}')
    print(f'  modules whose warning lines differ from {warn_vs}: {diffs}')
