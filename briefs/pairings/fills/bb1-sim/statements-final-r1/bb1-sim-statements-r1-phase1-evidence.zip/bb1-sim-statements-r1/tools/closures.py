"""closures.py <repo> <rev-or-tree> <module>...: downstream closure (the module and every module
importing it, transitively) of each given module, from the `import` lines of TCSlib/**.lean,
TCSlib.lean and audits/**.lean at <rev-or-tree>, read from git (no export). Prints counts and,
with --list, the modules. Reviewer's tool (bb1-sim-statements r1, phase 1)."""
import re
import subprocess
import sys

repo, rev = sys.argv[1], sys.argv[2]
mods = [m for m in sys.argv[3:] if not m.startswith('--')]
ls = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', '--full-tree', rev, '--', 'TCSlib',
                     'TCSlib.lean', 'audits'], capture_output=True, check=True).stdout.decode()
entries = []
for line in ls.splitlines():
    meta, path = line.split('\t', 1)
    if path.endswith('.lean'):
        entries.append((meta.split()[2], path))
cat = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE,
                       stdout=subprocess.PIPE)
imp = re.compile(r'^import\s+(\S+)')
graph = {}
for oid, path in entries:
    cat.stdin.write((oid + '\n').encode())
    cat.stdin.flush()
    size = int(cat.stdout.readline().split()[2])
    text = cat.stdout.read(size).decode()
    cat.stdout.read(1)
    mod = path[:-5]
    deps = []
    for l in text.splitlines():
        m = imp.match(l)
        if m:
            deps.append(m.group(1).replace('.', '/'))
    graph[mod] = deps
rdeps = {}
for m, ds in graph.items():
    for d in ds:
        rdeps.setdefault(d, set()).add(m)
print(f'{rev}: {len(graph)} Lean files under TCSlib/, TCSlib.lean, audits/')
for target in mods:
    seen = {target}
    stack = [target]
    while stack:
        x = stack.pop()
        for y in rdeps.get(x, ()):
            if y not in seen:
                seen.add(y)
                stack.append(y)
    non_root = sorted(m for m in seen if m != 'TCSlib' and not m.startswith('audits/'))
    audits = sorted(m for m in seen if m.startswith('audits/'))
    print(f'DOWN {target}: {len(seen)} modules (root included: {"TCSlib" in seen}; '
          f'audits: {len(audits)}; non-root TCSlib modules: {len(non_root)})')
    if '--list' in sys.argv:
        for m in sorted(seen):
            print(f'  {m}')
