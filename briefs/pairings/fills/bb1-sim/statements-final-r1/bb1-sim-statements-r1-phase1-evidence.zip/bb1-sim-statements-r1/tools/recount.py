"""recount.py <evidence-dir> [<run-dir>...]: recount every run directory (a results.jsonl with
mods/*.log, or runs/ beside it) of a delivered evidence tree from the raw logs.

Per run: records, rc != 0, `error:` and `error(` diagnostics (^\\S+\\.lean:\\d+:\\d+: error[:(]),
the substring "error", `declaration uses 'sorry'` warnings, other warnings, the log SHA-256 against
the record's log_sha256, and the record's own error/sorry counts against the recount.
Reviewer's tool (bb1-sim-statements r1, phase 1); reads only files already verified against the
delivery manifests."""
import hashlib
import json
import os
import re
import sys

ERR_COLON = re.compile(r'^\S+\.lean:\d+:\d+: error:', re.M)
ERR_PAREN = re.compile(r'^\S+\.lean:\d+:\d+: error\(', re.M)
WARN = re.compile(r'^\S+\.lean:\d+:\d+: warning', re.M)
SORRY = re.compile(r"declaration uses 'sorry'")

ev = sys.argv[1]
dirs = sys.argv[2:]
if not dirs:
    for root, _, files in os.walk(ev):
        if 'results.jsonl' in files:
            dirs.append(os.path.relpath(root, ev))
    dirs.sort()
grand = {'runs': 0, 'mods': 0, 'rc': 0, 'e1': 0, 'e2': 0, 'logmis': 0, 'recmis': 0}
for d in dirs:
    recs = [json.loads(l) for l in open(os.path.join(ev, d, 'results.jsonl')) if l.strip()]
    mods = [r for r in recs if 'module' in r]
    done = [r for r in recs if 'done' in r]
    rc = e1 = e2 = sub = so = w = logmis = recmis = missing = 0
    per = []
    for r in mods:
        lp = os.path.join(ev, d, 'mods', r['module'].replace('/', '_') + '.log')
        if not os.path.exists(lp):
            missing += 1
            continue
        data = open(lp, 'rb').read()
        t = data.decode(errors='replace')
        a, b = len(ERR_COLON.findall(t)), len(ERR_PAREN.findall(t))
        s = len(SORRY.findall(t))
        ww = len(WARN.findall(t)) - s
        rc += r.get('rc', 0) != 0
        e1 += a
        e2 += b
        sub += t.count('error')
        so += s
        w += ww
        if 'log_sha256' in r and hashlib.sha256(data).hexdigest() != r['log_sha256']:
            logmis += 1
        if r.get('errors') is not None and r['errors'] != a + b:
            recmis += 1
        if 'sorry' in r and r['sorry'] != s:
            recmis += 1
        per.append((r['module'], r.get('rc'), a, b, s, ww))
    print(f'{d}: records {len(mods)} (done-marker {len(done)}), missing logs {missing}, rc!=0 {rc}, '
          f'error: {e1}, error( {e2}, "error" substrings {sub}, sorry warnings {so}, other warnings '
          f'{w}, log-sha mismatches {logmis}, record/recount mismatches {recmis}')
    for m, r_, a, b, s, ww in per:
        if r_ != 0 or a or b or ww:
            print(f'    {m}: rc {r_}, error: {a}, error( {b}, sorry {s}, other warnings {ww}')
    grand['runs'] += 1
    grand['mods'] += len(mods)
    grand['rc'] += rc
    grand['e1'] += e1
    grand['e2'] += e2
    grand['logmis'] += logmis
    grand['recmis'] += recmis
print('TOTAL', grand)
