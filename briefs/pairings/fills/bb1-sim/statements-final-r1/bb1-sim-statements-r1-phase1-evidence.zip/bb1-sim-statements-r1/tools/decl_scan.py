"""decl_scan.py <file> <name>...: for each named theorem: docstring present, a backticked formula in
it, a `**Proof sketch.**`, proof length (lines from the declaration line to the line before the next
blank-line-separated item), and whether the body is `sorry`. Reviewer's tool (phase 1)."""
import re
import sys

lines = open(sys.argv[1]).read().split('\n')
for name in sys.argv[2:]:
    i = next(k for k, l in enumerate(lines) if re.match(rf'^theorem {re.escape(name)}\b', l))
    j = i
    while j + 1 < len(lines) and lines[j + 1].strip() != '':
        j += 1
    k = i - 1
    doc = []
    if lines[k].rstrip().endswith('-/'):
        while not lines[k].startswith('/--'):
            doc.insert(0, lines[k])
            k -= 1
        doc.insert(0, lines[k])
    d = '\n'.join(doc)
    body = '\n'.join(lines[i:j + 1])
    print(f'{name}: docstring {bool(doc)} ({len(doc)} lines), formula {"`" in d}, sketch '
          f'{"**Proof sketch.**" in d}, declaration+proof lines {j - i + 1}, sorry body '
          f'{bool(re.search(r"\bsorry\b", body))}')
