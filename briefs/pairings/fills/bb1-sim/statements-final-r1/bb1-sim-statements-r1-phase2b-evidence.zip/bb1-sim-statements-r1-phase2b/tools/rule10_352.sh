#!/usr/bin/env bash
# rule10_352.sh <phase>... (bb1-sim statements phase 2b, maintainer, 2026-11-17): phase 2's tools/rule10_bb1s.sh, series
# `group` only, re-pointed for the #352 re-replay on olean snapshot #3. Changes from rule10_bb1s.sh:
# (1) worktree: the git-archive export of REV = merge-tree(records tip c0752b2e x 92dea4f8) = tree 3029d8c3 (GIT_DIR points at
#     the repo, so `git show <REV>:<path>` reads the shared object store); H is that tree id, not a commit;
# (2) olean tree: $SP/olean-replay-352 (this job's replay output);
# (3) touched.json against the records tip c0752b2e (Lean-equal to snapshot #3's T cf7d28f7);
# (4) evidence under $SP/bb1p2b/ev; seal tools: this job's copy of olean-advance-a6d01b1b/tools-used/seal plus the worker's
#     rule10_b.sh and mkctl_bb1s.py, byte-identical to phase 2's tools/seal (diff -r: no differences).
# Every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing is written to the tree). One Lean process.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
E=$SP/bb1p2b/ev; T=$SP/bb1p2b/tools/seal; G=$T/review/archived-gate10-tools
B=c0752b2e6442ca4985644195acc5d25cf83d85d0
PM=TCSlib.Cryptography.Pairing
W=$SP/bb1p2b/wt-rev; TREE=$SP/olean-replay-352; NAME=group; H=3029d8c36c00fd3a4ce27e864a2b43b46309d27f
MODS="$PM.Group $PM.Assumptions"
FILES="TCSlib/Cryptography/Pairing/Group.lean TCSlib/Cryptography/Pairing/Assumptions.lean"
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$SP/bb1p2b/tmp PATH=$HOME/.elan/bin:$PATH
PP=StmtSeal
mkdir -p $R/order $R/probe-sources $W/$PP $E/statements
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
touched)
  python3 -I $T/review/touched.py /home/user/tcslib $B $H $TJ $FILES > $E/statements/touched-$NAME.tsv; echo "touched rc=$?";;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-sim phase 2b group collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
seals)
  R10DIR=$R TOUCHED=$TJ bash $T/rule10_b.sh $T $W $E $PP $H $T/review/mkctl_bb1s.py $MODS > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
scan)
  S=$E/scan/$NAME; mkdir -p $S
  SF=$(git diff --name-only $B $H -- 'TCSlib/*.lean' | grep '/')
  echo $SF > $S/files.txt
  SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W $TJ $S/items-head.json $W/$PP/ScanKindsHead.lean $SF > $S/scan1.out 2>&1
  cp $W/$PP/ScanKindsHead.lean $S/ScanKindsHead.lean.txt
  echo $PP/ScanKindsHead > $S/order.txt
  python3 -I $T/runner_full.py $W $S/order.txt $TREE $S/runs > $S/scan-runner.out 2>&1
  python3 -I $T/scan2.py $S/items-head.json $S/runs/mods/${PP}_ScanKindsHead.log $S/explicit-head.json > $S/scan2-head.log 2>&1; echo "scan2 rc=$?";;
probes)
  D=$E/probes/$NAME; mkdir -p $D $W/Bb1sProbe; : > $D/order.txt
  for p in $PROBES; do cp $SP/bb1p2b/probe-src/$p.lean $W/Bb1sProbe/$p.lean; cp $SP/bb1p2b/probe-src/$p.lean $D/$p.lean.txt; echo Bb1sProbe/$p >> $D/order.txt; done
  python3 -I $T/runner_full.py $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
