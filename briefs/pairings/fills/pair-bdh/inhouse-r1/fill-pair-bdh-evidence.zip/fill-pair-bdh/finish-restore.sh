#!/usr/bin/env bash
# finish-restore.sh (fill-pair-bdh): restore $SP/dl-oleans to the base snapshot 457ba704... after the build and probes
# (gate40-seals-merged's finish-restore.sh with this job's paths). Make sure no Lean process of this job is running first.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/fill-pair-bdh
T=$SP/dl-oleans; BK=$SP/pbdh-work/bk
mkdir -p $E/restore
python3 -I $E/tools-used/restoreplan.py $T $E/tree/snapshot-pre.txt $E/order/order.txt $E/restore/pre-restore-delta | tee $E/restore/pre-restore-delta.out
ln -sfn tools-used $E/tools
bash $E/tools-used/restore_derand.sh $T $BK $E
rm $E/tools
python3 -I $E/tools-used/restoreplan.py $T $E/tree/snapshot-pre.txt $E/order/order.txt $E/restore/restoreplan-check | tee $E/restore/restoreplan-check.out
python3 -I $E/tools-used/snapshot.py $T $E/restore/snapshot-verify.txt | tee $E/restore/snapshot-verify.out
cmp $E/tree/snapshot-pre.txt $E/restore/snapshot-verify.txt && echo "SECOND SNAPSHOT EQUAL" | tee -a $E/restore/snapshot-verify.out
sha256sum $E/tree/snapshot-pre.txt $E/tree/snapshot-post.txt $E/restore/snapshot-verify.txt
# then, if SNAPSHOT EQUAL and restoreplan extra 0 / changed 0 / missing 0: rm -r $BK
