#!/usr/bin/env bash
# rule10_pbdh.sh (fill-pair-bdh): LE-gate40's rule10_g40.sh / gate40-seals-merged's rule10_g40m.sh on the fill head, with the
# changed owner only (Pairing/Assumptions). Changes: worktree = the git worktree of fill/pair-bdh, probe subdir PbdhProbe;
# the collector is mkcollect.py over the one owner; the axioms probes ran before (axioms/); the controls generator is
# mkctl_pbdh.py (mkctl_g40.py plus nine rows, header); the explicit-unfold scan's file list is the fill's own diff
# `git diff --name-only 9e7a9648 <H> -- 'TCSlib/*.lean'`. Every probe through runner_full.py (lean -DmaxErrors=0, no -o:
# nothing written to the tree). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
TREE=$SP/dl-oleans; E=$SP/dl-review/fill-pair-bdh; W=$SP/wt-fill-pair-bdh; T=$E/tools-used/seal; R=$E/rule10
B=9e7a96481785d6cac4dea3b2e990c49ac278b060; H=$(git -C $W rev-parse HEAD)
export TCSLIB_OLEANS_TREE=$TREE TMPDIR=$SP/pbdh-work/tmp
echo "start $(date -u +%FT%TZ) head $H"
MODS="TCSlib.Cryptography.Pairing.Assumptions"
mkdir -p $R/order $R/probe-sources $E/scan $W/PbdhProbe
# 1. collector
printf '%s\n' $MODS > $R/order/owners.txt
python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "fill-pair-bdh collector" $W/PbdhProbe/CollectHead.lean
cp $W/PbdhProbe/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
printf 'PbdhProbe/CollectHead\n' > $R/order/probes.txt
python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1
echo "phase1 $(date -u +%FT%TZ)"
# 2. seals and controls (rule10_b.sh unmodified)
bash $T/rule10_b.sh $T $W $E PbdhProbe $H $T/review/mkctl_pbdh.py $MODS > $R/rule10-driver.out 2>&1; rc=$?
echo "phase2 $(date -u +%FT%TZ) rule10_b rc=$rc"
# 3. explicit-unfold scan
FILES=$(git -C $W diff --name-only $B $H -- 'TCSlib/*.lean' | grep '/')
echo $FILES > $E/scan/files.txt
SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $T/review/archived-gate10-tools/scan_explicit.py $W \
  $E/statements/touched-after.json $E/scan/items-head.json $W/PbdhProbe/ScanKindsHead.lean $FILES > $E/scan/scan1.out 2>&1
cp $W/PbdhProbe/ScanKindsHead.lean $R/probe-sources/ScanKindsHead.lean.txt
echo PbdhProbe/ScanKindsHead > $R/order/scan.txt
python3 -I $T/runner_full.py $W $R/order/scan.txt $TREE $E/scan/runs > $E/scan/scan-runner.out 2>&1
python3 -I $T/scan2.py $E/scan/items-head.json $E/scan/runs/mods/PbdhProbe_ScanKindsHead.log \
  $E/scan/explicit-head.json > $E/scan/scan2-head.log 2>&1
echo "PHASE3-DONE $(date -u +%FT%TZ)"
