#!/usr/bin/env bash
# run-build.sh (fill-pair-bdh): build plan/queue.txt (36 modules of the 110-module head closure) on dl-oleans through
# scripts/lean_check_tree.sh (runner.py, stops on first failure). TMPDIR keeps lean_check_tree.sh's mktemp log inside $SP.
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/fill-pair-bdh
export TMPDIR=$SP/pbdh-work/tmp
cd $E
echo "start $(date -u +%FT%TZ)"
python3 -I tools-used/review/runner.py $SP/wt-fill-pair-bdh plan/queue.txt $SP/dl-oleans build
echo "runner exit $? $(date -u +%FT%TZ)"
