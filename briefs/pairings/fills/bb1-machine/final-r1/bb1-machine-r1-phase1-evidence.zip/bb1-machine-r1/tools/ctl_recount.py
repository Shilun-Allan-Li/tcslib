"""Independent recount of the bb1-machine paired controls from raw logs (phase 1, no Lean).

Usage: python3 -I ctl_recount.py <repo> <delivery-rev>

For each variant (coe: probes K_*, sources controls-coe/; strict: KS_*, controls-strict/), each
control probe source is parsed for `theorem|example|lemma ctl*` blocks; every error line of the
raw log (`<file>:<line>:<col>: error[:(]`) is attributed to the enclosing control. The result
is compared with ctlcheck-<variant>.json: per control, errors equal; negatives sealed exactly 1;
positives 0; unsealed probes 0; no stray error outside a control. Reader rows are listed per
probe.
"""
import json
import re
import subprocess
import sys
from collections import defaultdict

P = 'inbox/fills/bb1-machine/evidence/'
ERRLINE = re.compile(r'^\S+\.lean:(\d+):\d+: error[:(]', re.M)
CTL = re.compile(r'^(?:private\s+)?(?:theorem|lemma|example|def)\s+(ctl\w*)', re.M)
READERS = ['ctlOracleZero', 'ctlOracleOne', 'ctlOracleTwo', 'ctlEncPP', 'ctlEncSK',
           'ctlMsgSpace', 'ctlSimCt']


def show(repo, rev, path):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True)
    return r.stdout.decode() if r.returncode == 0 else None


def main():
    repo, rev = sys.argv[1:3]
    for var, pre, sdir in (('coe', 'K', 'controls-coe'), ('strict', 'KS', 'controls-strict')):
        cc = json.loads(show(repo, rev, P + f'rule10/ctlcheck-{var}.json'))
        tot = defaultdict(int)
        mism = []
        reader_sites = defaultdict(list)
        for pr in cc['probes']:
            label = pr['label']
            src = show(repo, rev, P + f'rule10/{sdir}/{label}.lean.txt')
            log = show(repo, rev, P + f'rule10/seal-runs/mods/Bb1mProbe_{pre}_{label}.log')
            if src is None or log is None:
                mism.append(f'missing {label}')
                continue
            starts = [(src[:m.start()].count('\n') + 1, m.group(1)) for m in CTL.finditer(src)]
            harness_end = src.find('/- G06-HARNESS EOF-VERIFY')
            harness_end_line = src[:harness_end].count('\n') + 1 if harness_end >= 0 else 10**9
            errs = defaultdict(int)
            stray = 0
            for m in ERRLINE.finditer(log):
                ln = int(m.group(1))
                owner = None
                for s, name in starts:
                    if s <= ln:
                        owner = name
                if owner is None or ln >= harness_end_line:
                    stray += 1
                else:
                    errs[owner] += 1
            sealed = pr['sealed']
            for c in pr['controls']:
                name = c['control']
                got = errs.get(name, 0)
                exp = (1 if c['negative'] else 0) if sealed else 0
                if got != c['errors']:
                    mism.append(f'{label}:{name} json {c["errors"]} recount {got}')
                ok = got == c['expected']
                tot['controls'] += 1
                tot['neg_sealed'] += c['negative'] and sealed
                tot['neg_sealed_once'] += c['negative'] and sealed and got == 1
                tot['pos_sealed_pass'] += (not c['negative']) and sealed and got == 0
                tot['pos_sealed'] += (not c['negative']) and sealed
                tot['unsealed_errors'] += (not sealed) * got
                tot['expected_mismatch'] += not ok
                tot['std_expect_mismatch'] += got != exp
                if name in READERS or name.replace('Reader', '') in READERS:
                    reader_sites[name].append(label.split('IdentityBased_')[-1] + ('/S' if sealed else '/U'))
            tot['stray'] += stray
            tot['errors'] += sum(errs.values()) + stray
            tot['probes'] += 1
        print(f'[{var}] json all_ok {cc["all_ok"]}; ' + ', '.join(f'{k} {v}' for k, v in tot.items())
              + f'; json-vs-recount mismatches {len(mism)} {mism[:5]}')
        for r in READERS:
            sites = sorted(set(reader_sites.get(r, [])))
            pos = sorted(set(reader_sites.get(r + 'Reader', [])))
            print(f'   {r}: negative in {sites}; positive in {pos}')


if __name__ == '__main__':
    main()
