"""Reviewer's text-level declaration scan (phase 1, no Lean).

Usage: python3 -I decls_scan.py <repo> <base-rev> <head-rev> <file> [<file> ...]

For each file, at base and head: lists top-level declarations (theorem/lemma/def/abbrev/
instance/structure, with modifiers), their full names (namespace-resolved by `namespace`/`end`
tracking), visibility, docstring presence, whether the docstring has `**Proof sketch.**`,
and the proof length (lines from the line holding `:=` that ends the header to the last
non-blank line before the next top-level item). Reports, per file: ADDED, REMOVED and
CHANGED (normalized header + docstring-before-sketch differs), and the sketch rule hits
(proof >= 15 lines and no sketch) at base and head.
"""
import re
import subprocess
import sys

DECL = re.compile(r'^((?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|nonrec|partial|'
                  r'unsafe)\s+)*)(theorem|lemma|def|abbrev|instance|structure|inductive|'
                  r'class)\s+([^\s(:{\[]+)')
TOP = re.compile(r'^(/--|/-!|@\[|private |protected |noncomputable |theorem |lemma |def |abbrev |'
                 r'instance |structure |inductive |class |end |namespace |section |variable |'
                 r'open |attribute |set_option |#|example )')


def show(repo, rev, path):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True)
    return r.stdout.decode() if r.returncode == 0 else None


def scan(text):
    lines = text.split('\n')
    ns = []
    out = {}
    i = 0
    doc_start = None
    while i < len(lines):
        l = lines[i]
        m = re.match(r'^namespace\s+(\S+)', l)
        if m:
            ns.append(m.group(1))
        m = re.match(r'^end\s+(\S+)', l)
        if m and ns and ns[-1] == m.group(1):
            ns.pop()
        if l.startswith('/--'):
            doc_start = i
            j = i
            while '-/' not in lines[j]:
                j += 1
            i = j + 1
            continue
        m = DECL.match(l)
        if m:
            mods, kind, name = m.group(1), m.group(2), m.group(3)
            full = name if name.startswith('_root_.') else '.'.join(ns + [name])
            doc = '\n'.join(lines[doc_start:i]) if doc_start is not None else ''
            # header ends at first line containing ':=' or ' where' (top level) or '|'
            j = i
            while j < len(lines) and ':=' not in lines[j] and not lines[j].rstrip().endswith(
                    ' where') and not (j > i and lines[j].lstrip().startswith('|')):
                j += 1
            header = '\n'.join(lines[i:j + 1])
            k = j + 1
            while k < len(lines) and not (lines[k] and not lines[k][0].isspace()
                                           and TOP.match(lines[k])):
                k += 1
            last = k - 1
            while last > j and not lines[last].strip():
                last -= 1
            plen = last - j + 1
            out[full] = {
                'line': i + 1, 'kind': kind, 'private': 'private' in mods,
                'simp': '@[simp' in mods, 'doc': bool(doc), 'sketch': '**Proof sketch.**' in doc,
                'doc_pre': doc.split('**Proof sketch.**')[0],
                'header': ' '.join(header.split()), 'plen': plen,
            }
            doc_start = None
            i = k
            continue
        if l.strip() and not l.startswith('--'):
            doc_start = None if not l.startswith('/--') else doc_start
        i += 1
    return out


def main():
    repo, base, head = sys.argv[1:4]
    tot = {'ADDED': 0, 'REMOVED': 0, 'CHANGED': 0}
    for f in sys.argv[4:]:
        b = scan(show(repo, base, f) or '')
        h = scan(show(repo, head, f) or '')
        short = f.split('IdentityBased/')[-1]
        added = [n for n in h if n not in b]
        removed = [n for n in b if n not in h]
        changed = [n for n in h if n in b and (h[n]['header'] != b[n]['header']
                                                or h[n]['doc_pre'] != b[n]['doc_pre'])]
        bodychg = [n for n in h if n in b and n not in changed and h[n]['plen'] != b[n]['plen']]
        print(f'== {short}: base {len(b)} decls, head {len(h)}; ADDED {len(added)}, REMOVED '
              f'{len(removed)}, CHANGED {len(changed)}; body-length changed {bodychg}')
        tot['ADDED'] += len(added)
        tot['REMOVED'] += len(removed)
        tot['CHANGED'] += len(changed)
        for n in added:
            d = h[n]
            print(f'  ADDED {n} ({d["kind"]}, line {d["line"]}, '
                  f'{"private" if d["private"] else "public"}, doc {d["doc"]}, sketch '
                  f'{d["sketch"]}, proof {d["plen"]} lines, simp {d["simp"]})')
        for n in removed:
            print(f'  REMOVED {n}')
        for n in changed:
            print(f'  CHANGED {n}')
        hb = sorted(n for n, d in b.items() if d['plen'] >= 15 and not d['sketch'])
        hh = sorted(n for n, d in h.items() if d['plen'] >= 15 and not d['sketch'])
        nodoc = sorted(n for n, d in h.items() if not d['doc'] and not d['private'])
        print(f'  sketch-rule hits base {hb}; head {hh}')
        print(f'  public without docstring at head: {nodoc}')
    print(f'TOTAL {tot}')


if __name__ == '__main__':
    main()
