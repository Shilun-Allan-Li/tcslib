"""Reviewer's explicit-unfold scan (source reading, phase 1, no Lean).

Usage: python3 -I unfold_scan.py <worktree> <mathlib-src-root> <core-src-root> <file> [<file> ...]

Collects every identifier inside the selector lists of `rw`, `rwa`, `simp`, `simp only`, `dsimp`,
`simp_rw`, `unfold`, `delta` and `simp ... at`, plus the targets of `show`/`change` keywords
(counted only), in the given files. Each identifier is classified by searching declarations in
TCSlib (worktree), Mathlib/Batteries and core sources: THEOREM (theorem/lemma, incl. `@[simps]`
generated `*_eq`-style names found as theorems), DEFINITION (def/abbrev/structure/instance),
LOCAL (bound in the proof: `h…`, `e`, etc.), or UNRESOLVED. Reports every non-THEOREM item.
"""
import os
import re
import sys
from collections import Counter, defaultdict

SEL = re.compile(r'\b(rw|rwa|simp only|simp|dsimp only|dsimp|simp_rw|unfold|delta)\s*\[([^\]]*)\]',
                 re.S)
UNF = re.compile(r'\b(unfold|delta)\s+([A-Za-z_][\w.\']*(?:\s+[A-Za-z_][\w.\']*)*)')


def index(roots):
    idx = defaultdict(set)
    pat = re.compile(r'^\s*(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|nonrec|partial|'
                     r'unsafe)\s+)*(theorem|lemma|def|abbrev|structure|instance|class|inductive)\s+'
                     r'([^\s(:{\[]+)', re.M)
    for root in roots:
        for dp, _, fs in os.walk(root):
            for f in fs:
                if f.endswith('.lean'):
                    try:
                        t = open(os.path.join(dp, f), encoding='utf-8', errors='replace').read()
                    except OSError:
                        continue
                    for m in pat.finditer(t):
                        short = m.group(2).split('.')[-1]
                        idx[short].add(m.group(1))
    return idx


def main():
    wt, ml, core = sys.argv[1:4]
    files = sys.argv[4:]
    idx = index([os.path.join(wt, 'TCSlib'), ml, core])
    tot = Counter()
    rows = []
    for f in files:
        t = open(os.path.join(wt, f), encoding='utf-8').read()
        t = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), t, flags=re.S)
        t = re.sub(r'--[^\n]*', '', t)
        locs = set(re.findall(r'(?:have|obtain|intro|rintro|fun|choose|rcases|set|let)\s+'
                              r'[⟨(]?\s*([A-Za-z_][\w\']*)', t))
        locs |= set(re.findall(r'⟨\s*([A-Za-z_][\w\']*)', t))
        locs |= set(re.findall(r',\s*([A-Za-z_][\w\']*)\s*⟩', t))
        for m in SEL.finditer(t):
            line = t[:m.start()].count('\n') + 1
            for item in m.group(2).split(','):
                item = item.strip().lstrip('←').strip()
                item = re.split(r'\s', item)[0] if item else item
                if not item:
                    continue
                name = item.split('.')[-1]
                kinds = idx.get(name, set())
                if item in locs or name in locs or re.fullmatch(r'h\w*|e|this', item):
                    cls = 'LOCAL'
                elif kinds and kinds <= {'theorem', 'lemma'}:
                    cls = 'THEOREM'
                elif kinds & {'theorem', 'lemma'}:
                    cls = 'THEOREM?MIXED'
                elif kinds:
                    cls = 'DEFINITION'
                else:
                    cls = 'UNRESOLVED'
                tot[cls] += 1
                if cls != 'THEOREM':
                    rows.append((f.split('IdentityBased/')[-1], line, m.group(1), item, cls,
                                 sorted(kinds)))
        for m in UNF.finditer(t):
            tot['UNFOLD_CMD'] += 1
            rows.append((f, t[:m.start()].count('\n') + 1, m.group(1), m.group(2), 'UNFOLD', []))
        tot['change'] += len(re.findall(r'\bchange\b', t))
        tot['show'] += len(re.findall(r'\bshow\b', t))
        tot['rfl'] += len(re.findall(r'\brfl\b', t))
        tot['decide'] += len(re.findall(r'\bdecide\b', t))
    print('totals:', dict(tot))
    for r in rows:
        print('  ', r)


if __name__ == '__main__':
    main()
