"""Recount the bb1-machine worker's evidence from its raw logs (phase 1, no Lean).

Usage: python3 -I recount.py <repo> <delivery-rev> <head-rev> <base-rev>

Streams every file from git (no export). For each run directory (a `results.jsonl` plus
`mods/*.log`), it recounts per log: `error:` and `error(` diagnostics
(`^\\S+\\.lean:\\d+:\\d+: error[:(]`), the substring `error`, `declaration uses 'sorry'`
warnings, other warnings, and checks the log's SHA-256 against the record. Sweep records are
bound to the head blobs (source_sha256). Seal probes are checked to be the head source plus
the harness (install block and EOF-verify block), with `import Lean` added; their logs must
carry `G06-SEAL-END ... requested=N verified=N`. Control logs: errors per probe are compared
with the controls plan (expected failing negatives).
"""
import hashlib
import json
import re
import subprocess
import sys
from collections import defaultdict

ERR = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
ERR_COLON = re.compile(r'^\S+\.lean:\d+:\d+: error:', re.M)
ERR_PAREN = re.compile(r'^\S+\.lean:\d+:\d+: error\(', re.M)
WARN = re.compile(r'^\S+\.lean:\d+:\d+: warning', re.M)
SORRY = re.compile(r"declaration uses 'sorry'")
P = 'inbox/fills/bb1-machine/evidence/'
IB = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/'


class Git:
    def __init__(self, repo):
        self.repo = repo
        self.cat = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'],
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE)

    def ls(self, rev, prefix):
        out = subprocess.run(['git', '-C', self.repo, 'ls-tree', '-r', rev, prefix],
                             capture_output=True, check=True).stdout.decode()
        return {l.split('\t', 1)[1]: l.split()[2] for l in out.splitlines()}

    def blob(self, spec):
        self.cat.stdin.write((spec + '\n').encode())
        self.cat.stdin.flush()
        hdr = self.cat.stdout.readline().split()
        if hdr[1] == b'missing':
            return None
        n = int(hdr[2])
        data = b''
        while len(data) < n:
            data += self.cat.stdout.read(n - len(data))
        self.cat.stdout.read(1)
        return data


def sha(b):
    return hashlib.sha256(b).hexdigest()


def run_dir(g, rev, d, files, label, head=None, head_rev=None):
    rj = files.get(P + d + '/results.jsonl')
    if not rj:
        print(f'[{label}] no results.jsonl at {d}')
        return {}
    recs = [json.loads(l) for l in g.blob(rj).decode().splitlines() if l.strip()]
    mods = [r for r in recs if 'module' in r]
    out = {}
    tot = defaultdict(int)
    mism = []
    for r in mods:
        name = r['module'].replace('/', '_')
        lp = P + d + '/mods/' + name + '.log'
        data = g.blob(files[lp]) if lp in files else None
        if data is None:
            mism.append(f'missing log {name}')
            continue
        t = data.decode(errors='replace')
        e1, e2 = len(ERR_COLON.findall(t)), len(ERR_PAREN.findall(t))
        sub = t.count('error')
        so = len(SORRY.findall(t))
        w = len(WARN.findall(t))
        if sha(data) != r.get('log_sha256'):
            mism.append(f'log sha {name}')
        if r.get('rc') != 0:
            mism.append(f'rc {name} {r.get("rc")}')
        if r.get('errors') != e1 + e2:
            mism.append(f'errors {name} rec {r.get("errors")} recount {e1 + e2}')
        if head_rev and r['module'].startswith('TCSlib/'):
            src = g.blob(f'{head_rev}:{r["module"]}.lean')
            if src is None or sha(src) != r.get('source_sha256'):
                mism.append(f'source binding {r["module"]}')
        out[r['module']] = {'rc': r.get('rc'), 'e:': e1, 'e(': e2, 'sub': sub, 'sorry': so,
                            'warn': w, 'text': t, 'rec': r}
        tot['logs'] += 1
        tot['rc!=0'] += r.get('rc') != 0
        tot['error:'] += e1
        tot['error('] += e2
        tot['substr'] += sub
        tot['sorry'] += so
    done = [r for r in recs if 'done' in r]
    print(f'[{label}] {d}: records {len(mods)}, done-record {bool(done)}, ' +
          ', '.join(f'{k} {v}' for k, v in tot.items()) +
          f'; mismatches {len(mism)}' + (f': {mism[:8]}' if mism else ''))
    return out


def main():
    repo, drev, head, base = sys.argv[1:5]
    g = Git(repo)
    files = g.ls(drev, P)
    print(f'delivery {drev}; evidence files {len(files)}')

    # 1. sweep
    sw = run_dir(g, drev, 'build/sweep-cp1', files, 'sweep', head_rev=head)
    order = g.blob(files[P + 'build/order-final.txt']).decode().split()
    print(f'  sweep order-final {len(order)} modules; covered {len(set(order) & set(sw))}; '
          f'Oracles in order {any(m.endswith("BonehBoyenMachine/Oracles") for m in order)}')
    per = {m: v['sorry'] for m, v in sw.items() if v['sorry']}
    print(f'  sorry warnings {sum(per.values())} in {len(per)} modules; '
          f'BonehBoyenMachine {per.get(IB + "BonehBoyenMachine", 0)}; '
          f'Assumptions {per.get("TCSlib/Cryptography/Pairing/Assumptions", 0)}; '
          f'BonehBoyenSecurity {per.get(IB + "BonehBoyenSecurity", 0)}')
    for m in ('BonehBoyenMachine/Oracles', 'BonehBoyenMachine', 'Defs', 'BonehBoyen',
              'BonehBoyenSecurity'):
        v = sw.get(IB + m)
        if v:
            print(f'  {m}: rc {v["rc"]} warnings {v["warn"]} sorry {v["sorry"]} '
                  f'log bytes {len(v["text"])}')
    for k in ('TCSlib/Cryptography/AdvancedEncryption/IdentityBased',
              'TCSlib/Cryptography/AdvancedEncryption'):
        print(f'  facade {k}: {"present rc " + str(sw[k]["rc"]) if k in sw else "ABSENT"}')
    run_dir(g, drev, 'build/bootstrap-readers', files, 'bootstrap')

    # 2. seals at the head
    seals = run_dir(g, drev, 'rule10/seal-runs', files, 'seal-runs')
    owners = ['Defs', 'BonehBoyen', 'BonehBoyenMachine_Draws', 'BonehBoyenMachine_Words',
              'BonehBoyenMachine_Handler', 'BonehBoyenMachine_Reduction',
              'BonehBoyenMachine_Oracles', 'BonehBoyenMachine']
    srcpath = {o: IB + o.replace('_', '/') + '.lean' for o in owners}
    print('  seal table (variant/owner: requested=verified, errors, install+eof, probe=src+harness)')
    for var, sub, dd in (('strict-A', 'S', 'seals/A'), ('strict-B', 'S', 'seals/B'),
                         ('coe-A', 'C', 'seals-coe/A'), ('coe-B', 'C', 'seals-coe/B')):
        row = []
        for o in owners:
            ab = var[-1]
            mod = f'Bb1mProbe/{sub}/Seal{ab}_Cryptography_AdvancedEncryption_IdentityBased_{o}'
            v = seals.get(mod)
            if not v:
                row.append(f'{o}:MISSING')
                continue
            t = v['text']
            m = re.search(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', t)
            inst = 'phase=install' in t
            eof = 'phase=eof' in t
            probe = g.blob(files.get(P + f'rule10/{dd}/Seal{ab}_Cryptography_AdvancedEncryption_'
                                     f'IdentityBased_{o}.lean.txt', 'x'))
            src = g.blob(f'{head}:{srcpath[o]}')
            ok_probe = False
            if probe and src:
                pt, st = probe.decode(), src.decode()
                lines = st.splitlines(keepends=True)
                last_imp = max(i for i, l in enumerate(lines) if l.startswith('import '))
                rest = ''.join(lines[last_imp + 1:])
                imps = ''.join(lines[:last_imp + 1])
                pre = pt.split('/- G06-HARNESS INSTALL')[0]
                ok_probe = (pt.count(rest) == 1 and pre.replace('import Lean\n', '', 1) == imps
                            and pt.index(rest) + len(rest) == pt.index('/- G06-HARNESS EOF-VERIFY'))
            req = f'{m.group(1)}={m.group(2)}' if m else 'NO-END'
            row.append(f'{o}:{req},e{v["e:"] + v["e("]},{int(inst)}{int(eof)},'
                       f'{"P" if ok_probe else "p?"}')
        print(f'   {var}: ' + ' | '.join(row))

    # 3. controls
    for var, sub, plan in (('coe', 'K', 'rule10/controls-coe/controls-plan.json'),
                           ('strict', 'KS', 'rule10/controls-strict/controls-plan.json')):
        pl = json.loads(g.blob(files[P + plan]).decode())
        ctl = {m: v for m, v in seals.items() if m.startswith(f'Bb1mProbe/{sub}/')}
        sealed = {m: v for m, v in ctl.items() if '/ControlS_' in m}
        unsealed = {m: v for m, v in ctl.items() if '/ControlU_' in m}
        es = sum(v['e:'] + v['e('] for v in sealed.values())
        eu = sum(v['e:'] + v['e('] for v in unsealed.values())
        # expected: one error per negative in each sealed probe
        neg_lines = defaultdict(int)
        for m, v in sealed.items():
            for line in ERR.findall(v['text']):
                pass
        print(f'  [controls-{var}] probes {len(ctl)} (sealed {len(sealed)}, unsealed '
              f'{len(unsealed)}); sealed errors {es}; unsealed errors {eu}; plan keys '
              f'{list(pl)[:6] if isinstance(pl, dict) else type(pl).__name__}')
    for var in ('coe', 'strict'):
        j = json.loads(g.blob(files[P + f'rule10/ctlcheck-{var}.json']).decode())
        keys = list(j)[:12] if isinstance(j, dict) else type(j).__name__
        print(f'  ctlcheck-{var}.json keys {keys}; ALL_OK {j.get("ALL_OK") if isinstance(j, dict) else "?"}')

    # 4. pretest, base seals, axioms, scan, collector
    run_dir(g, drev, 'rule10/pretest/runs', files, 'pretest')
    bs = run_dir(g, drev, 'rule10-base/seal-runs', files, 'base-seals')
    for m, v in sorted(bs.items()):
        mm = re.search(r'G06-SEAL-END label=\S+ requested=(\d+) verified=(\d+)', v['text'])
        print(f'   {m.split("/")[-2]}/{m.split("/")[-1].split("_IdentityBased_")[-1]} '
              f'{"/".join(m.split("/")[1:2])}: '
              f'{mm.group(1) + "=" + mm.group(2) if mm else "NO-END"} e{v["e:"] + v["e("]}')
    ax = run_dir(g, drev, 'axioms/runs', files, 'axioms')
    for m, v in ax.items():
        t = v['text']
        print(f'   axioms log: {len(t)} bytes; sorryAx mentions {t.count("sorryAx")}')
        for line in t.splitlines():
            if ("exists_bb1_distinguisher" in line or 'bb1_sidSecure' in line or
                    'onSpec' in line or 'ofFn_bb1' in line or 'msgSpace_iff' in line or
                    'abs_expect_bb1Sim' in line or 'SORRIED' in line.upper() or
                    'census' in line.lower() or 'nonstandard' in line.lower()):
                print('     ' + line[:220])
    run_dir(g, drev, 'scan/runs', files, 'scan-kinds')
    run_dir(g, drev, 'rule10/probe-runs', files, 'collector')
    run_dir(g, drev, 'logs/cache-probe', files, 'cache-probe')


if __name__ == '__main__':
    main()
