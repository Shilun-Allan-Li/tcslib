"""closcmp.py <repo> <module> <rev>...: the local import closure of <module> at each rev (downorder.py's parsing), and
whether the closures agree in module set and in every source blob across the revs."""
import sys, re, subprocess
repo, root, revs = sys.argv[1], sys.argv[2], sys.argv[3:]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
res = {}
for rev in revs:
    seen, todo = {}, [root]
    while todo:
        m = todo.pop()
        if m in seen: continue
        seen[m] = git('rev-parse', f'{rev}:{m}.lean').strip()
        todo += [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M) if local(i)]
    res[rev] = seen
    print(f'{rev[:8]}: closure {len(seen)}')
base = revs[0]
for rev in revs[1:]:
    a, b = res[base], res[rev]
    diff = sorted(m for m in set(a) | set(b) if a.get(m) != b.get(m))
    print(f'{base[:8]} vs {rev[:8]}: {"EQUAL" if not diff else "DIFFER " + str(diff)}')
