#!/usr/bin/env bash
# run-build-346c.sh: replay of #346 on snapshot #4 (tree 2ec72515 = tip ca129d64 x 89a18a82) on olean-replay-346c (cp -al of
# snapshot #4 at 463f2244), plan/queue.txt (12 modules), one Lean process, through scripts/lean_check_tree.sh.
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/wt-M4
export PATH=$HOME/.elan/bin:$PATH TMPDIR=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/tmp
echo "start $(date -u +%FT%TZ)" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/build/runner.start
df -m / | tail -1 > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/build/df-launch.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/tools/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/wt-M4 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-346c /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/build
echo "runner exit $? $(date -u +%FT%TZ)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/build/runner.exit
df -m / | tail -1 >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2c/build/runner.exit
