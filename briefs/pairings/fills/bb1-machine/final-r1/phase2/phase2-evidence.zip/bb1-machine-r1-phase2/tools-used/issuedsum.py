"""issuedsum.py <repo> <rev> <root-module> <census.txt>...: sum tipcensus.py per-module counts over the local import closure
of <root-module> at <rev> (the issued order of the bb1-machine fill is the closure of BonehBoyenSecurity), per census."""
import sys, re, subprocess
repo, rev, root = sys.argv[1:4]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
seen, todo = set(), [root]
while todo:
    m = todo.pop()
    if m in seen: continue
    seen.add(m)
    todo += [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M) if i.split('.')[0] in ('TCSlib', 'audits')]
print(f'closure of {root} at {rev[:8]}: {len(seen)} modules')
for c in sys.argv[4:]:
    tot, n, nz = 0, 0, []
    for l in open(c):
        p = l.split()
        if len(p) >= 2 and p[0].isdigit() and p[1] in seen:
            tot += int(p[0]); n += 1
            if int(p[0]): nz.append(f'{p[1].replace("TCSlib/", "")}:{p[0]}')
    print(f'{c.split("/")[-1]}: {tot} over {n} modules; nonzero {len(nz)}: {nz}')
