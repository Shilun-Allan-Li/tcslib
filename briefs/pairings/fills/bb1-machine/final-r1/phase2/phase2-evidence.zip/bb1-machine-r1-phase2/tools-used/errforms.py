"""errforms.py <rundir> <out>: per probe of a runner_full.py run, from the raw log: rc, `error:` count, `error(` count, the
record's combined count, and whether the log hash equals the record. Totals by probe family (Seal/ControlS/ControlU)."""
import sys, os, re, json, hashlib
rd, out = sys.argv[1:3]; last = {}
for l in open(os.path.join(rd, 'results.jsonl')):
    r = json.loads(l)
    if 'module' in r: last[r['module']] = r
rows = []
for m, r in sorted(last.items()):
    b = open(os.path.join(rd, 'mods', m.replace('/', '_') + '.log'), 'rb').read(); t = b.decode('utf-8', 'replace')
    c = len(re.findall(r'^\S+\.lean:\d+:\d+: error:', t, re.M)); p = len(re.findall(r'^\S+\.lean:\d+:\d+: error\(', t, re.M))
    rows.append((m, r['rc'], c, p, r['errors'], hashlib.sha256(b).hexdigest() == r['log_sha256']))
fam = {}
with open(out, 'w') as f:
    f.write('probe\trc\terror:\terror(\trecord\tloghash\n')
    for x in rows:
        f.write('\t'.join(map(str, x)) + '\n')
        k = x[0].split('/')[-1].split('_')[0]; a = fam.setdefault(k, [0, 0, 0, 0, 0]); a[0] += 1; a[1] += x[1] != 0; a[2] += x[2]; a[3] += x[3]; a[4] += (x[2] + x[3] != x[4]) or not x[5]
    for k, a in sorted(fam.items()): f.write(f'TOTAL {k}: probes {a[0]}; rc!=0 {a[1]}; error: {a[2]}; error( {a[3]}; mismatches {a[4]}\n')
print(open(out).read().split('TOTAL', 1)[1].join(['TOTAL', '']) if False else ''.join(l + '\n' for l in open(out).read().splitlines() if l.startswith('TOTAL')))
