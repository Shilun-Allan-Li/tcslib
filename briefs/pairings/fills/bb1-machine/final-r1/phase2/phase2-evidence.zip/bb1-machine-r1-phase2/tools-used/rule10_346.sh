#!/usr/bin/env bash
# (2026-11-17, snapshot #3 rerun: TREE_OVERRIDE and TIP_OVERRIDE select the olean tree and the tip; defaults unchanged.)
# rule10_346.sh <tree-id> <worktree> <evidence-dir> <phase...> (bb1-machine phase 2, maintainer): the worker's
# drivers/rule10_final.sh adapted to the olean snapshot procedure. Changes: the worktree is a `git archive` export of
# the prospective merge tree (no .git; GIT_DIR points at the repo so `git -C <wt> show <tree>:<path>` reads the shared
# object store); the olean tree is olean-replay-346; the seal tools are the maintainer's copies (tools-used/seal, the
# same bytes as the worker's except runner_full.py, which is the maintainer's); new phases `statements` (touched.py,
# tip vs tree), `axioms` (probe-src/Axioms346.lean) and `oracles` (BM-F03: the seven reader controls in Oracles-owned
# probes, strict and coe, A and B, sealed and unsealed, via mkctl_bb1m_oracles.py). Every probe through runner_full.py
# (lean -DmaxErrors=0, no -o: nothing is written to the tree). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
H=$1; W=$2; E=$3; shift 3
TREE=${TREE_OVERRIDE:-$SP/olean-replay-346}; T=$SP/p346/tools/seal; R=$E/rule10
TIP=${TIP_OVERRIDE:-ff0c255217caaefe1cd5c77d753e256cb8d54b13}
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=${TMPDIR_OVERRIDE:-$SP/p346/p2/tmp} PATH=$HOME/.elan/bin:$PATH
PX=TCSlib.Cryptography.AdvancedEncryption.IdentityBased
MODS="$PX.Defs $PX.BonehBoyen $PX.BonehBoyenMachine.Draws $PX.BonehBoyenMachine.Words $PX.BonehBoyenMachine.Handler $PX.BonehBoyenMachine.Reduction $PX.BonehBoyenMachine.Oracles $PX.BonehBoyenMachine"
G=$T/review/archived-gate10-tools
mkdir -p $R/order $R/probe-sources $E/scan $E/statements $E/axioms $W/Bb1mProbe
FILES=$(git diff --name-only $TIP $H -- 'TCSlib/*.lean' | grep IdentityBased/ | grep -v BonehBoyenSecurity)
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) tree $H"
case $ph in
statements)
  echo $FILES > $E/statements/files.txt
  python3 -I $T/review/touched.py /home/user/tcslib $TIP $H $E/statements/touched-after.json $FILES > $E/statements/touched-after.tsv 2>&1; echo "touched rc=$?";;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-machine phase 2 collector" $W/Bb1mProbe/CollectHead.lean
  cp $W/Bb1mProbe/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf 'Bb1mProbe/CollectHead\n' > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
axioms)
  cp $SP/p346/p2/probe-src/Axioms346.lean $W/Bb1mProbe/Axioms346.lean
  echo Bb1mProbe/Axioms346 > $E/axioms/order.txt
  python3 -I $T/runner_full.py $W $E/axioms/order.txt $TREE $E/axioms/runs > $E/axioms/runner.out 2>&1; echo "axioms rc=$?";;
seals)
  bash $T/rule10_b.sh $T $W $E Bb1mProbe $H $T/review/mkctl_bb1m_readers.py $MODS > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
oracles)
  O=$R/oracles-ctl; mkdir -p $O
  CTL_OWNER=$PX.BonehBoyenMachine.Oracles python3 -I $T/review/mkctl_bb1m_oracles.py $G $R/seals-flat $W Bb1mProbe/KSO $O/strict > $O/mkctl-strict.log
  CTL_OWNER=$PX.BonehBoyenMachine.Oracles python3 -I $T/review/mkctl_bb1m_oracles.py $G $R/seals-coe-flat $W Bb1mProbe/KO $O/coe > $O/mkctl-coe.log
  (cd $W && ls Bb1mProbe/KO/*.lean Bb1mProbe/KSO/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $O/queue.txt
  python3 -I $T/runner_full.py $W $O/queue.txt $TREE $O/runs > $O/runner.out 2>&1
  python3 -I $T/review/ctlcheck2.py $O/strict/controls-plan.json $O/runs $O/ctlcheck-strict.json > $O/ctlcheck-strict.log 2>&1
  python3 -I $T/review/ctlcheck2.py $O/coe/controls-plan.json $O/runs $O/ctlcheck-coe.json > $O/ctlcheck-coe.log 2>&1
  tail -n 1 $O/ctlcheck-strict.log $O/ctlcheck-coe.log;;
scan)
  echo $FILES > $E/scan/files.txt
  SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W \
    $E/statements/touched-after.json $E/scan/items-head.json $W/Bb1mProbe/ScanKindsHead.lean $FILES > $E/scan/scan1.out 2>&1
  cp $W/Bb1mProbe/ScanKindsHead.lean $R/probe-sources/ScanKindsHead.lean.txt
  echo Bb1mProbe/ScanKindsHead > $R/order/scan.txt
  python3 -I $T/runner_full.py $W $R/order/scan.txt $TREE $E/scan/runs > $E/scan/scan-runner.out 2>&1
  python3 -I $T/scan2.py $E/scan/items-head.json $E/scan/runs/mods/Bb1mProbe_ScanKindsHead.log \
    $E/scan/explicit-head.json > $E/scan/scan2-head.log 2>&1; echo "scan2 rc=$?";;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
