#!/usr/bin/env bash
# rule10_x.sh <phase...> (bb1-machine phase 2, maintainer): Lean checks on the cross-build X = tip x #346 x #340
# (tree b90b966b) after its replay on olean-replay-346. Phases: `axioms` (probe-src/Axioms346.lean); `assumptions`
# (#340's owner Pairing/Assumptions: canonical coe A/B, exactly int-x-341-340's finish-seals.sh steps with the pair-bdh
# tools, which are byte-equal to tools-used/seal; probe subdirectory PbdhProbe); `owners` (strict and coe, A and B, of the
# five #346 owners whose import closure contains Pairing/Assumptions: Words, Handler, Reduction, Oracles,
# BonehBoyenMachine). The tree lives in a scratch object directory (GIT_OBJECT_DIRECTORY with the repo's objects as
# alternate). Every probe through runner_full.py (lean -DmaxErrors=0, no -o). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
H=b90b966bc40a20e3f806cdc2379178c201b1b262; W=$SP/p346/wt-X; E=$SP/p346/p2/x; TREE=$SP/olean-replay-346
T=$SP/p346/tools/seal; G=$T/review/archived-gate10-tools
export GIT_DIR=/home/user/tcslib/.git GIT_OBJECT_DIRECTORY=$SP/p346/objs GIT_ALTERNATE_OBJECT_DIRECTORIES=/home/user/tcslib/.git/objects
export TCSLIB_OLEANS_TREE=$TREE TMPDIR=$SP/p346/p2/tmp PATH=$HOME/.elan/bin:$PATH
PX=TCSlib.Cryptography.AdvancedEncryption.IdentityBased
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) tree $H"
case $ph in
axioms)
  mkdir -p $E/axioms $W/Bb1mProbe; cp $SP/p346/p2/probe-src/Axioms346.lean $W/Bb1mProbe/Axioms346.lean
  echo Bb1mProbe/Axioms346 > $E/axioms/order.txt
  python3 -I $T/runner_full.py $W $E/axioms/order.txt $TREE $E/axioms/runs > $E/axioms/runner.out 2>&1; echo "axioms rc=$?";;
assumptions)
  S=$E/seals-340; P=PbdhProbe; MODS="TCSlib.Cryptography.Pairing.Assumptions"
  mkdir -p $S/order $S/probe-sources $W/$P
  printf '%s\n' $MODS > $S/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $S/order/owners.txt "fill-pair-bdh collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $S/probe-sources/CollectHead.lean.txt
  printf 'PbdhProbe/CollectHead\n' > $S/order/probes.txt
  python3 -I $T/runner_full.py $W $S/order/probes.txt $TREE $S/probe-runs > $S/probe-runner.out 2>&1
  LOG=$S/probe-runs/mods/${P}_CollectHead.log
  (cd $T && python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $S/seals-coe/A $P/C SealA_ $MODS > $S/mkseals-coe-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $S/seals-coe/B $P/C SealB_ $MODS > $S/mkseals-coe-B.log)
  (cd $W && ls $P/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $S/order/seal-queue.txt
  python3 -I $T/runner_full.py $W $S/order/seal-queue.txt $TREE $S/seal-runs > $S/seal-runner.out 2>&1 || true
  TJ=$SP/p346/intx/int-x-341-340/seals-340/touched-after.json.from-pair-bdh
  python3 -I $T/review/sealsum.py $S/seals-coe/A $S/seal-runs $TJ $S/seals-coe-A.tsv
  python3 -I $T/review/sealsum.py $S/seals-coe/B $S/seal-runs $TJ $S/seals-coe-B.tsv
  cat $S/mkseals-coe-*.log $S/seals-coe-*.tsv;;
owners)
  R=$E/rule10; P=Bb1mProbeX
  MODS="$PX.BonehBoyenMachine.Words $PX.BonehBoyenMachine.Handler $PX.BonehBoyenMachine.Reduction $PX.BonehBoyenMachine.Oracles $PX.BonehBoyenMachine"
  mkdir -p $R/order $R/probe-sources $W/$P
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-machine phase 2 collector (X)" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1
  LOG=$R/probe-runs/mods/${P}_CollectHead.log
  (cd $T && python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/A $P/S SealA_ $MODS > $R/mkseals-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/B $P/S SealB_ $MODS > $R/mkseals-B.log
   python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $P/C SealA_ $MODS > $R/mkseals-coe-A.log
   SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/B $P/C SealB_ $MODS > $R/mkseals-coe-B.log)
  (cd $W && ls $P/C/*.lean $P/S/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
  python3 -I $T/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1 || true
  TJ=$SP/p346/p2/statements/touched-after.json
  for v in seals/A seals/B seals-coe/A seals-coe/B; do
    python3 -I $T/review/sealsum.py $R/$v $R/seal-runs $TJ $R/$(echo $v | tr / -).tsv; done
  cat $R/mkseals-*.log $R/seals*.tsv;;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
