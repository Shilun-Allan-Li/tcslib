#!/usr/bin/env bash
# run-build-x.sh: advance olean-replay-346 from M (278c549c, state checked) to the cross-build X = tip x #346 x #340
# (tree b90b966b): x/plan/queue.txt (13 modules: Pairing/Assumptions and its downstream), one Lean process, through
# scripts/lean_check_tree.sh of the export wt-X.
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/wt-X
export PATH=$HOME/.elan/bin:$PATH TMPDIR=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/tmp
echo "start $(date -u +%FT%TZ)" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/x/build/runner.start
df -m / | tail -1 > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/x/build/df-launch.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/tools/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/wt-X /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/x/plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-346 /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/x/build
echo "runner exit $? $(date -u +%FT%TZ)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/x/build/runner.exit
df -m / | tail -1 >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/p346/p2/x/build/runner.exit
