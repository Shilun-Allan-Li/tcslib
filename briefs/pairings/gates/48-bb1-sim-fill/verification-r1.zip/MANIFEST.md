# verification-r1.zip · Gate 48 (bb1-sim gate) round 1

Every entry except `SHA256SUMS` is listed in `SHA256SUMS`. Nothing here was produced by a new Lean run: `phase1/` and
`phase2/` are the maintainer review's recorded evidence, copied byte for byte; `checks/` are git-object reads made at
staging; `records/` are byte copies or marked extracts of records at the pin.

| Path | What | Origin |
|---|---|---|
| `POINTERS.md` | evidence not copied whole, with sizes and SHA-256 | this staging |
| `checks/series.txt` | pins, Lean-equality of the base with `3f540c22`, the records-only pin delta, the PR diff and its 5 commits | `git` at staging |
| `checks/pins.txt` | the reader pins at base and head and the approved blocks' hashes | `git` at staging |
| `checks/mergetrees.txt` | `git merge-tree --write-tree` of the head with the pin, #347, #355 and the local 6a branches; 3-way simulations | `tools/mergetrees48.sh` |
| `checks/tags.txt` | source tags on the added lines and per file at the head | `git` at staging |
| `checks/dl57.txt` | DL-57's declarations at the head (`git grep`) | `git` at staging |
| `checks/tools/` | the staging scripts | this staging |
| `phase1/` | the phase-1 (static) review evidence, whole; its own manifest is `phase1/SHA256SUMS.original` | `bb1-sim-fill-final-r1-phase1-evidence.zip` |
| `phase2/` | the phase-2 (Lean, snapshot #5) evidence, all but 7 large raw files; `phase2/SHA256SUMS.original` is its manifest | `bb1-sim-fill-final-r1-phase2-evidence.zip` |
| `phase2/phase2.md`, `PROVENANCE.txt` | the phase-2 report and its provenance | phase 2 |
| `phase2/landing/` | the `git am` reproduction, the cherry-picks, the signature key per commit, LE-bsf1 as applied | phase 2 |
| `phase2/static/` | decls2 vs the tip (69/0/0) and its summary, the reader insertion check (12 controls), the frozen check (8 controls), hygiene | phase 2 |
| `phase2/replay/` | orders, plan queue, build results and per-module records, state checks, link counts, snapshot #5 rehashes, output map | phase 2 |
| `phase2/admissions/` | the census at the tip and the head and their diff (196 → 192) | phase 2 |
| `phase2/axioms/` | the probe source `AxiomsBsf.lean.txt` and its log (76 constants, census 325, traces, sorry control) | phase 2 |
| `phase2/rule10/` | the seal tables and `mkseals` logs (36), the control plans and `ctlcheck` results (strict, coe), the driver logs, `attempt1/`, `omitted-SHA256SUMS` | phase 2 |
| `phase2/scan/` | the explicit-unfold scan summary (527 items, 0 foreign), the file list, `omitted-SHA256SUMS` | phase 2 |
| `phase2/lint/` | `campaign_style_lint` at tip and head and their diffs, `style_lint`, `sk15` | phase 2 |
| `phase2/statements/` | the declaration-level comparison of the 9 files, tip → head | phase 2 |
| `phase2/tools/` | the phase-2 drivers and adapted tools | phase 2 |
| `records/briefs/pairings/fills/bb1-sim/…` | design r1, rulings, checkpoint-1 review, the final review (phase 1 + phase-2 verdict), phase2.md, evidence sums, the issued brief, README, sums and the two approved reader blocks | records at the pin |
| `records/briefs/pairings/gates/44-pairing-fills/findings-r{1,2}.md` | Gate 44's findings (precedent for G44-01..03) | records at the pin |
| `records/policy.md` | the repository standards | records at the pin |
| `records/decision-log-pairings.md` | the plan's decision-log rows from the bb1-sim design note to #357 | extract at the pin |
| `records/duplication-ledger-DL55-57.md`, `records/cleanup-stages-stage2.md` | DL-55..DL-57 and cleanup Stage 2 | extracts at the pin |
| `pr/pr357-rest-fields.json` | PR #357's REST fields at staging (head, base, counts, body SHA-256) | GitHub REST |
