# Reviewer's recount of a delivered build directory (bb1-sim final review).
# usage: python3 -I recount_build.py <repo> <tree-ish> <build-dir>
# For each results.jsonl row: rc, errors, sorry; binds source_sha256 to `git cat-file blob` of
# <tree-ish>:<module>.lean; re-hashes the module log in mods/ against log_sha256 and re-counts
# errors in both forms (^\S+\.lean:\d+:\d+: error[:(]) and `declaration uses 'sorry'` warnings.
import hashlib, json, os, re, subprocess, sys
repo, tree, d = sys.argv[1:4]
ERR = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
SOR = re.compile(r"declaration uses 'sorry'")
rows = [json.loads(l) for l in open(os.path.join(d, 'results.jsonl')) if l.strip()]
mods = [r for r in rows if 'module' in r]
ls = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', tree], capture_output=True, text=True).stdout
blob = {l.split('\t')[1]: l.split()[2] for l in ls.splitlines()}
bound = rcbad = errs = logerr = logsor = logbad = nolog = 0
sorry_mods = {}
for r in mods:
    m = r['module']
    p = m + '.lean'
    src = subprocess.run(['git', '-C', repo, 'cat-file', 'blob', blob[p]], capture_output=True).stdout \
        if p in blob else b''
    ok = hashlib.sha256(src).hexdigest() == r.get('source_sha256')
    bound += ok
    if not ok:
        print('UNBOUND', m)
    rcbad += r['rc'] != 0
    errs += r.get('errors', 0)
    if r.get('sorry'):
        sorry_mods[m] = r['sorry']
    lp = os.path.join(d, 'mods', m.replace('/', '_') + '.log')
    if os.path.exists(lp):
        b = open(lp, 'rb').read()
        if 'log_sha256' in r and hashlib.sha256(b).hexdigest() != r['log_sha256']:
            logbad += 1
            print('LOGHASH-MISMATCH', m)
        t = b.decode('utf-8', 'replace')
        logerr += len(ERR.findall(t))
        logsor += len(SOR.findall(t))
    else:
        nolog += 1
print(f'{d}: modules {len(mods)} rc!=0 {rcbad} errors(json) {errs} errors(logs, both forms) {logerr} '
      f'sorry-warnings(logs) {logsor} sorry(json) {sum(sorry_mods.values())} in {len(sorry_mods)} '
      f'modules; bound {bound}/{len(mods)}; log-hash mismatches {logbad}; missing logs {nolog}')
for m, n in sorted(sorry_mods.items()):
    print('  sorry', m, n)
