# Reviewer's independent recount of the delivered paired controls (bb1-sim final review).
# usage: python3 -I recount_controls.py <rule10/head dir> <controls-subdir: controls-strict|controls-coe>
# For each ControlS_* (sealed) and ControlU_* (unsealed) probe source in <subdir>, find the
# `theorem|example|lemma ctl*` declarations and their line ranges, read the raw log of the run
# (control-runs/mods/<probe module>.log; the module is found by the probe label in
# control-runs/results.jsonl), and attribute every error line (both forms) to a declaration.
# Expected: sealed negatives (ctlX) exactly 1 error, sealed positives (ctlXReader) 0, unsealed 0,
# and no error outside a ctl declaration (stray).
import glob, json, os, re, sys
d, sub = sys.argv[1], sys.argv[2]
ERR = re.compile(r'^(\S+\.lean):(\d+):\d+: error[:(]', re.M)
DECL = re.compile(r'^(?:theorem|example|lemma|def)\s+(ctl[A-Za-z0-9_]*)')
import hashlib
runs = {}
for l in open(os.path.join(d, 'control-runs', 'results.jsonl')):
    if l.strip():
        r = json.loads(l)
        if 'module' in r:
            runs[r['source_sha256']] = r   # bind each run to its probe source by hash
tot = {'neg': 0, 'neg_ok': 0, 'pos': 0, 'pos_ok': 0, 'unsealed_bad': 0, 'stray': 0, 'probes': 0,
       'missing': 0}
rows_names = set()
for src in sorted(glob.glob(os.path.join(d, sub, 'Control*.lean.txt'))):
    label = os.path.basename(src)[:-len('.lean.txt')]
    L = open(src, encoding='utf-8').read().split('\n')
    starts = [(i + 1, m.group(1)) for i, l in enumerate(L) for m in [DECL.match(l)] if m]
    r = runs.get(hashlib.sha256(open(src, 'rb').read()).hexdigest())
    if r is None:
        tot['missing'] += 1
        print('NO-RUN', label)
        continue
    lp = os.path.join(d, 'control-runs', 'mods', r['module'].replace('/', '_') + '.log')
    log = open(lp, encoding='utf-8', errors='replace').read()
    cnt = {n: 0 for _, n in starts}
    stray = 0
    for m in ERR.finditer(log):
        ln = int(m.group(2))
        owner = None
        for s, n in starts:
            if s <= ln:
                owner = n
        if owner is None:
            stray += 1
        else:
            cnt[owner] += 1
    sealed = label.startswith('ControlS')
    tot['probes'] += 1
    tot['stray'] += stray
    for n, c in cnt.items():
        rows_names.add(n)
        if not sealed:
            tot['unsealed_bad'] += c != 0
        elif n.endswith('Reader'):
            tot['pos'] += 1
            tot['pos_ok'] += c == 0
        else:
            tot['neg'] += 1
            tot['neg_ok'] += c == 1
            if c != 1:
                print('NEG-NOT-ONCE', label, n, c)
    if sealed and stray:
        print('STRAY', label, stray)
    if not sealed and (r['rc'] != 0 or any(cnt.values())):
        print('UNSEALED-FAIL', label, r['rc'])
print(sub, tot, 'run dirs', sorted({runs[k]['module'].split('/')[1] for k in runs}))
print('row names', len(rows_names), sorted({n[:-6] if n.endswith('Reader') else n for n in rows_names}))
