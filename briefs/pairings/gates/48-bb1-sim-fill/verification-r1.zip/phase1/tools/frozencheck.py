# Reviewer's independent frozen-header check (bb1-sim final review).
# usage: python3 -I frozencheck.py <repo> <patch-base> <head> [--controls]
# H1: the four targets' headers (keyword through `:= by`) are byte-identical base vs head.
# H2: their statement prose (docstring up to `**Proof sketch.**`) is byte-identical.
# H3: `prob_simulate_rel` and `bb1_sidSecure` (docstring, header and proof) are identical whole.
# H4: each file is identical after masking the target bodies, the target sketch paragraphs,
#     the permitted helper `import` lines (BonehBoyenSecurity only) and the `## Contents`
#     section (BonehBoyenSecurity only).
import re, subprocess, sys
repo, base, head = sys.argv[1:4]
REL = 'TCSlib/Cryptography/Games/Relational.lean'
BBS = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity.lean'
TARGETS = {REL: ['expect_simulate_rel', 'expect_sample_rel'], BBS: ['bb1_sim_real', 'bb1_sim_random']}
WHOLE = {REL: ['prob_simulate_rel'], BBS: ['bb1_sidSecure']}
HELPER_IMPORT = re.compile(r'^import TCSlib\.Cryptography\.AdvancedEncryption\.IdentityBased\.'
                           r'BonehBoyenSecurity\.[A-Za-z]+$')
def show(rev, f):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True,
                          text=True, check=True).stdout
def decl_span(L, name):
    """(doc_start, header_start, header_end (line with ':= by'), end) for theorem `name`."""
    hs = next(i for i, l in enumerate(L) if re.match(r'^theorem %s\b' % re.escape(name), l))
    ds = hs - 1
    while not L[ds].startswith('/--'):
        ds -= 1
    he = hs
    while not L[he].rstrip().endswith(':= by'):
        he += 1
    e = he + 1
    while e < len(L) and L[e].strip() != '' and not L[e].startswith('/--') and \
            not L[e].startswith('end '):
        e += 1
    return ds, hs, he, e
def parts(t, f):
    L = t.split('\n')
    out = {}
    for n in TARGETS[f]:
        ds, hs, he, e = decl_span(L, n)
        doc = L[ds:hs]
        k = next((j for j, l in enumerate(doc) if '**Proof sketch.**' in l), len(doc))
        prose = '\n'.join(doc[:k]) + '\n' + (doc[k].split('**Proof sketch.**')[0] if k < len(doc) else '')
        out[('H1', n)] = '\n'.join(L[hs:he + 1])
        out[('H2', n)] = prose
    for n in WHOLE[f]:
        ds, hs, he, e = decl_span(L, n)
        out[('H3', n)] = '\n'.join(L[ds:e])
    return out
def mask(t, f):
    L = t.split('\n')
    spans = []
    for n in TARGETS[f]:
        ds, hs, he, e = decl_span(L, n)
        k = next((j for j in range(ds, hs) if '**Proof sketch.**' in L[j]), None)
        if k is not None:
            spans.append((k, hs, f'<SKETCH {n}>', L[k].split('**Proof sketch.**')[0]))
        spans.append((he + 1, e, f'<BODY {n}>', None))
    for a, b, tag, keep in sorted(spans, reverse=True):
        L[a:b] = ([keep] if keep is not None else []) + [tag]
    if f == BBS:
        L = [l for l in L if not HELPER_IMPORT.match(l)]
        if '## Contents' in L:
            a = L.index('## Contents')
            b = next(j for j in range(a + 1, len(L)) if L[j].startswith('## ') or L[j].startswith('-/'))
            del L[a:b]
    return '\n'.join(L)
def check(f, tb, th):
    res = []
    pb, ph = parts(tb, f), parts(th, f)
    for k in pb:
        res.append((f'{k[0]} {k[1]}', pb[k] == ph.get(k)))
    res.append((f'H4 {f.split("/")[-1]}', mask(tb, f) == mask(th, f)))
    return res
allok = True
texts = {f: (show(base, f), show(head, f)) for f in (REL, BBS)}
for f, (tb, th) in texts.items():
    for k, v in check(f, tb, th):
        print(('PASS ' if v else 'FAIL ') + k)
        allok &= v
print('RESULT', 'PASS' if allok else 'FAIL')
if '--controls' in sys.argv:
    tb, th = texts[BBS]
    rb, rh = texts[REL]
    C = []
    # 1 a sketch edit that spills into the statement prose (T2's prose before **Proof sketch.**)
    C.append(('sketch-spills-into-prose', BBS,
              th.replace('**Proof sketch.** Read `Setup`', 'except here. **Proof sketch.** Read `Setup`', 1)))
    # 2 a one-character header change (T3)
    C.append(('one-char-header', BBS, th.replace('(A : NUPPT) (q : ℕ) (κ : ℕ) :', '(A : NUPPT) (q : ℕ) (κ : ℕ)  :', 1)))
    # 3 an unpermitted import
    C.append(('unpermitted-import', BBS, th.replace('import TCSlib.Cryptography.Pairing.Assumptions\n',
              'import TCSlib.Cryptography.Pairing.Assumptions\nimport Mathlib.Tactic\n', 1)))
    # 4 an edit to bb1_sidSecure (its proof)
    L = th.split('\n'); ds, hs, he, e = decl_span(L, 'bb1_sidSecure'); L[e - 1] = L[e - 1] + ' '
    C.append(('edit-bb1_sidSecure', BBS, '\n'.join(L)))
    # 5 a module-docstring edit outside ## Contents
    C.append(('docstring-outside-contents', BBS, th.replace('## Main results', '## Main  results', 1)))
    # 6 an edit to prob_simulate_rel
    L = rh.split('\n'); ds, hs, he, e = decl_span(L, 'prob_simulate_rel'); L[hs] = L[hs] + ' '
    C.append(('edit-prob_simulate_rel', REL, '\n'.join(L)))
    # 7 a statement-prose edit in a Relational target (expect_sample_rel's docstring, before its sketch)
    L = rh.split('\n'); ds, hs, he, e = decl_span(L, 'expect_sample_rel'); L[ds] = L[ds].replace('/--', '/-- X', 1)
    C.append(('prose-edit-Relational', REL, '\n'.join(L)))
    # 8 a one-character header change in a Relational target
    C.append(('header-edit-Relational', REL, rh.replace(
        'expect (simulate impl₀ c s) G₀ = expect (simulate impl₁ c t) G₁ := by',
        'expect (simulate impl₀ c s) G₀ = expect (simulate impl₁ c t) G₁  := by', 1)))
    ok = True
    for name, f, mut in C:
        tbase = texts[f][0]
        changed = mut != texts[f][1]
        r = check(f, tbase, mut)
        failed = not all(v for _, v in r)
        print('CONTROL', name, 'mutated' if changed else 'NOT-MUTATED',
              'FAIL(expected)' if failed else 'PASS(UNEXPECTED)', [k for k, v in r if not v])
        ok &= failed and changed
    r = check(BBS, tb, th) + check(REL, rb, rh)
    print('CONTROL unchanged-head', 'PASS(expected)' if all(v for _, v in r) else 'FAIL(UNEXPECTED)')
    ok &= all(v for _, v in r)
    print('ALL_CONTROLS_OK', ok)
