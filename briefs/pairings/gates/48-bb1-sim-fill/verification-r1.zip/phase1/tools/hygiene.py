# Reviewer's hygiene scan (bb1-sim final review).
# usage: python3 -I hygiene.py <worktree> <file>...
# Prints per file: lines, lines >100 chars (Python len), @[simp], attribute lines, micro sign
# (U+00B5), sorry/admit/native_decide/axiom tokens outside comments; then per declaration with a
# docstring in the helper files: whether the docstring has a formula (a backticked span with
# '=', '≤', '<', '↔', '≃' or ':'), a tag ('[BB04') or a glue note ('Glue'/'glue'), and, for
# proofs of >= 15 lines, whether the docstring has '**Proof sketch.**'.
import re, sys, os
WT = sys.argv[1]
DECL = re.compile(r'^(?:private |protected |noncomputable |@\[[^\]]*\] )*'
                  r'(theorem|lemma|def|abbrev|structure|instance|inductive|class)\s+([^\s(:{\[]+)')
def strip_comments(t):
    t = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), t, flags=re.S)
    return re.sub(r'--[^\n]*', '', t)
for f in sys.argv[2:]:
    t = open(os.path.join(WT, f), encoding='utf-8').read()
    L = t.split('\n')
    n = t.count('\n')
    wide = [i + 1 for i, l in enumerate(L) if len(l) > 100]
    simp = [i + 1 for i, l in enumerate(L) if '@[simp' in l]
    attr = [i + 1 for i, l in enumerate(L) if l.lstrip().startswith('attribute')]
    micro = t.count('µ')
    code = strip_comments(t)
    toks = {k: len(re.findall(r'\b%s\b' % k, code)) for k in ('sorry', 'admit', 'native_decide', 'axiom')}
    print(f'{f} lines {n} wide {wide} simp {simp} attr {attr} micro {micro} tokens {toks}')
    if '/BonehBoyenSecurity' not in f and 'Relational' not in f:
        continue
    # declarations
    starts = [(i, m.group(1), m.group(2)) for i, l in enumerate(L) for m in [DECL.match(l)] if m]
    for k, (i, kind, name) in enumerate(starts):
        # docstring immediately above (allow `open ... in` / attribute lines between)
        j = i - 1
        while j >= 0 and (L[j].startswith('open ') or L[j].strip() == ''):
            if L[j].strip() == '':
                break
            j -= 1
        doc = ''
        if j >= 0 and L[j].rstrip().endswith('-/'):
            e = j
            while e >= 0 and not L[e].lstrip().startswith('/--'):
                e -= 1
            doc = '\n'.join(L[e:j + 1]) if e >= 0 else ''
        # end of declaration: next decl start or a docstring/section line
        end = starts[k + 1][0] if k + 1 < len(starts) else len(L)
        body = L[i:end]
        # trim trailing docstring of next decl and blank lines
        while body and (body[-1].strip() == '' or body[-1].startswith('open ')):
            body.pop()
        bl = [x for x in body]
        # cut at the start of the next docstring if any
        for q, x in enumerate(bl):
            if q > 0 and (x.lstrip().startswith('/--') or x.startswith('/-!') or
                          x.startswith('end ') or x.startswith('section') or
                          x.startswith('variable') or x.startswith('namespace')):
                bl = bl[:q]
                break
        while bl and bl[-1].strip() == '':
            bl.pop()
        nlines = len(bl)
        formula = bool(re.search(r'`[^`]*(=|≤|<|↔|≃|:)[^`]*`', doc))
        tag = '[BB04' in doc
        glue = bool(re.search(r'\b[Gg]lue\b', doc))
        sketch = '**Proof sketch.**' in doc
        flags = []
        if not doc:
            flags.append('NO-DOCSTRING')
        if doc and not formula:
            flags.append('no-formula')
        if doc and not (tag or glue):
            flags.append('no-tag/glue')
        if kind in ('theorem', 'lemma') and nlines >= 15 and not sketch:
            flags.append('NO-SKETCH(>=15)')
        print(f'  {os.path.basename(f)}:{i + 1} {kind} {name} lines={nlines} '
              f'formula={formula} tag={tag} glue={glue} sketch={sketch} '
              f'{" ".join(flags) if flags else "ok"}')
