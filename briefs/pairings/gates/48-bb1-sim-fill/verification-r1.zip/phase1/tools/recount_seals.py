# Reviewer's recount of the delivered canonical seals (bb1-sim final review).
# usage: python3 -I recount_seals.py <repo> <tree-ish> <rule10-side-dir>
# For every seal JSON under <dir>/seals/{A,B} (strict) and <dir>/seals-coe/{A,B} (coe):
#   * the owner's source_sha256 is bound to <tree-ish>:<source>;
#   * the probe source (<label>.lean.txt beside the JSON) hashes to probe_sha256;
#   * the run record in <dir>/seal-runs/results.jsonl for probe_module: rc, errors;
#   * the raw log (seal-runs/mods/<probe_module with / -> _>.log): log_sha256 and a recount
#     of errors in both forms.
import glob, hashlib, json, os, re, subprocess, sys
repo, tree, d = sys.argv[1:4]
ERR = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
H = lambda b: hashlib.sha256(b).hexdigest()
runs = {}
for l in open(os.path.join(d, 'seal-runs', 'results.jsonl')):
    if l.strip():
        r = json.loads(l)
        if 'module' in r:
            runs[r['module']] = r   # last record wins
rows = []
bad = 0
for variant in ('seals', 'seals-coe'):
    for js in sorted([p for p in glob.glob(os.path.join(d, variant, '[AB]', 'Seal*.json'))]):
        j = json.load(open(js))
        src = subprocess.run(['git', '-C', repo, 'show', f'{tree}:{j["source"]}'],
                             capture_output=True).stdout
        bound = H(src) == j['source_sha256']
        ptxt = js[:-5] + '.lean.txt'
        pok = os.path.exists(ptxt) and H(open(ptxt, 'rb').read()) == j['probe_sha256']
        r = runs.get(j['probe_module'])
        lp = os.path.join(d, 'seal-runs', 'mods', j['probe_module'].replace('/', '_') + '.log')
        lb = open(lp, 'rb').read() if os.path.exists(lp) else None
        lok = lb is not None and r is not None and H(lb) == r.get('log_sha256')
        nerr = len(ERR.findall(lb.decode('utf-8', 'replace'))) if lb is not None else -1
        ok = bound and pok and r is not None and r['rc'] == 0 and r['errors'] == 0 and lok and nerr == 0
        bad += not ok
        rows.append((variant, j['label'], j['requested'], bound, pok, r and r['rc'],
                     r and r['errors'], lok, nerr, ok))
for row in rows:
    print('\t'.join(str(x) for x in row))
print(f'{d}: seals {len(rows)}; not OK {bad}')
