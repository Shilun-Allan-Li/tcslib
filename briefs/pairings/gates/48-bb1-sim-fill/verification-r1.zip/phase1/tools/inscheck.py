# Reviewer's independent reader-insertion check (bb1-sim; from the checkpoint-1 review, unchanged logic; reused at the final).
# usage: python3 -I inscheck.py <repo-worktree-at-head> <pack-readers-dir> [--controls]
import hashlib, subprocess, sys, os
WT, RD = sys.argv[1], sys.argv[2]
P = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/'
SPEC = [(P+'Defs.lean', 'Defs-block.lean.txt', 430,
         '4e220eadd4bf71ea62372bc371a3e2062b9f213acc696dbb66994c1f64069dfd',
         '97ecb6e02413d18fce255949ed4b3e777c8f653a59f0792b575be3ff24a6a9a0', 563),
        (P+'BonehBoyen.lean', 'BonehBoyen-block.lean.txt', 412,
         'da875140806706f26c4cdbb5cf765f522144f3a5a885c5156a58b8c611cd25f4',
         '88454d6fb0fa2c81419b189dbc633609357ee39b35ccbe90c810a0ad10891c26', 760)]
BASE = '72c0498a77dd0aadf8cc2a2e71cb450d754f8f5c'
H = lambda b: hashlib.sha256(b).hexdigest()
def check(name, head, base, block, anchor, hb, hh, n):
    ok = []
    ok.append(('base-hash', H(base) == hb))
    ok.append(('head-hash', H(head) == hh))
    ok.append(('head-lines', head.count(b'\n') == n))
    bl = base.splitlines(keepends=True)
    expect = b''.join(bl[:anchor]) + b'\n' + block + b''.join(bl[anchor:])
    ok.append(('pure-insertion-bytes', head == expect))
    hl = head.splitlines(keepends=True)
    blk = block.splitlines(keepends=True)
    removed = b''.join(hl[:anchor] + hl[anchor + 1 + len(blk):])
    ok.append(('removal-restores-base', removed == base))
    ok.append(('blank-before-block', hl[anchor] == b'\n' if len(hl) > anchor else False))
    return ok
allok = True
for f, blkf, anchor, hb, hh, n in SPEC:
    head = open(os.path.join(WT, f), 'rb').read()
    base = subprocess.run(['git', '-C', WT, 'show', f'{BASE}:{f}'], capture_output=True).stdout
    block = open(os.path.join(RD, blkf), 'rb').read()
    print(f, 'block', H(block)[:8], 'head', H(head)[:8])
    for k, v in check(f, head, base, block, anchor, hb, hh, n):
        print(' ', k, 'PASS' if v else 'FAIL'); allok &= v
    if '--controls' in sys.argv:
        hl = head.splitlines(keepends=True)
        blk = block.splitlines(keepends=True)
        s = anchor + 1
        muts = {}
        x = list(hl); i = s + 3; x[i] = x[i].replace(b'(', b'[', 1) if b'(' in x[i] else x[i] + b' '; muts['one-char-in-reader'] = x
        x = list(hl); x.insert(10, b'-- extra\n'); muts['extra-line-elsewhere'] = x
        x = list(hl); x.insert(s + len(blk), b'\n'); muts['extra-blank-after-block'] = x
        x = list(hl); del x[s:s + 5]; muts['reader-lines-deleted'] = x
        x = list(hl); seg = x[s:s + 5]; del x[s:s + 5]; x[s + 5:s + 5] = seg; muts['reader-lines-moved'] = x
        x = list(hl); j = next(k for k in range(s, s + len(blk)) if hl[k].startswith(b'/--')); x[j] = x[j].replace(b'/--', b'/-- X', 1); muts['docstring-edited'] = x
        for mname, m in muts.items():
            r = check(f, b''.join(m), base, block, anchor, hb, hh, n)
            print('  CONTROL', mname, 'FAIL(expected)' if not all(v for _, v in r) else 'PASS(UNEXPECTED)')
            allok &= not all(v for _, v in r)
print('RESULT', 'PASS' if allok else 'FAIL')
