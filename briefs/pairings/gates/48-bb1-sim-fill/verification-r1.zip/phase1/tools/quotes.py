# Reviewer's quotation check (bb1-sim final review): every "..." quotation inside a [BB04, ...]
# tag of the helper files and the T2/T3 docstrings, split at ellipses, must occur in the DW-7
# transcription (backticks, LaTeX commands, sub/superscript marks and whitespace removed;
# Greek letters mapped).
# usage: python3 -I quotes.py <transcription.md> <file>...
import re, sys, unicodedata
GREEK = {'alpha': 'α', 'beta': 'β', 'epsilon': 'ε'}
def norm(s):
    s = re.sub(r'\\(alpha|beta|epsilon)(?![A-Za-z])', lambda m: GREEK[m.group(1)], s)
    s = re.sub(r'\\(mathcal|mathrm|mathbb|tilde|left|right|,|\s)', '', s)
    s = s.replace('\u0303', '')
    s = s.replace('`', '').replace('$', '').replace('\\', '')
    s = re.sub(r'[_^{}]', '', s)
    s = s.replace('−', '-').replace('’', "'")
    return re.sub(r'\s+', '', s)  # whitespace-insensitive
tr = norm(open(sys.argv[1], encoding='utf-8').read())
for f in sys.argv[2:]:
    t = open(f, encoding='utf-8').read()
    for m in re.finditer(r'\[BB04,[^"\]]*"([^"]+)"', t):
        q = m.group(1)
        frags = [x for x in (norm(p) for p in q.split('…')) if x]
        res = [(fr, fr in tr) for fr in frags]
        print(f.split('/')[-1], 'OK' if all(r for _, r in res) else 'MISSING', '|', q.replace('\n', ' ')[:110],
              '' if all(r for _, r in res) else [fr for fr, r in res if not r])
