# Drafts the proposed landing edit LE-bsf1 (docstrings + the F03 reader) in a scratch worktree.
# usage: python3 -I mk_le.py <worktree at c35595ae>
import re, sys, os
WT = sys.argv[1]
P = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity/'
NOTES = {
 'Lazy.lean': {
  'bb1SimLazyChal_fresh': 'Glue: a case reader of `bb1SimLazyChal`.',
  'bb1SimLazyChal_of_not': 'Glue: a case reader of `bb1SimLazyChal`.',
  'bb1SimImpl_zero_coins': 'Glue: a case fact of `bb1SimImpl` for the eager step.',
  'bb1SimImpl_one_coins': 'Glue: a case fact of `bb1SimImpl` for the eager step.',
  'bb1SimLazy_zero': 'Glue: a case reader of `bb1SimLazy`.',
  'bb1SimLazy_one': 'Glue: a case reader of `bb1SimLazy`.',
  'bb1SimLazy_two_fresh': 'Glue: a case reader of `bb1SimLazy`.',
  'bb1SimLazy_two_of_not': 'Glue: a case reader of `bb1SimLazy`.',
  'bb1SimImpl_two_of_not': 'Glue: a case fact of `bb1SimImpl` for the eager step.',
  'bb1SimImpl_two_fresh_allOutputs': 'Glue: a case fact of `bb1SimImpl` for the eager step.',
  'bb1SimImpl_allOutputs_of_ne_two': 'Glue: a case fact of `bb1SimImpl` for the eager step.',
 },
 'Real.lean': {
  'bb1RealAt_none': 'Glue: a case reader of `bb1RealAt`.',
  'bb1RealAt_some': 'Glue: a case reader of `bb1RealAt`.',
  'bb1RealLazy_zero_none': 'Glue: a case reader of `bb1RealLazy`.',
  'bb1RealLazy_none_of_ne': 'Glue: a case reader of `bb1RealLazy`.',
  'bb1RealLazy_some': 'Glue: a case reader of `bb1RealLazy`.',
  'sidImpl_allOutputs_some': 'Glue: a case fact of `IBEScheme.sidImpl`, from its readers.',
  'sidImpl_none_of_ne': 'Glue: a case fact of `IBEScheme.sidImpl`, from its readers.',
 },
 'Coupling.lean': {
  'relM_iff': 'Glue: the reader of `RelM`.',
 },
}
def wrap_append(lines, idx, note):
    """Append `note` to the docstring line lines[idx] (which may end with ' -/'), wrapping at 100."""
    l = lines[idx]
    end = l.endswith(' -/') or l.endswith('-/')
    body = l[:-3].rstrip() if l.endswith(' -/') else (l[:-2].rstrip() if l.endswith('-/') else l)
    tail = ' -/' if end else ''
    cand = body + ' ' + note + tail
    if len(cand) <= 100:
        lines[idx] = cand
        return
    words = note.split(' ')
    cur = body
    out = []
    for w in words:
        if len(cur + ' ' + w) <= 100:
            cur = cur + ' ' + w
        else:
            out.append(cur)
            cur = w
    if len(cur + tail) > 100:
        out.append(cur); cur = ''
        tail = tail.strip()
    out.append((cur + tail) if cur else tail)
    lines[idx:idx + 1] = out
for f, notes in NOTES.items():
    path = os.path.join(WT, P + f)
    L = open(path, encoding='utf-8').read().split('\n')
    for name, note in notes.items():
        hs = next(i for i, l in enumerate(L) if re.match(r'^theorem %s\b' % re.escape(name), l))
        ds = hs - 1
        while not L[ds].startswith('/--'):
            ds -= 1
        sk = next((j for j in range(ds, hs) if '**Proof sketch.**' in L[j]), None)
        if sk is not None:
            idx = sk - 2          # last line of the statement paragraph (a blank line precedes)
            assert L[sk - 1].strip() == '', (f, name)
        else:
            idx = hs - 1
            assert L[idx].rstrip().endswith('-/'), (f, name)
        wrap_append(L, idx, note)
    open(path, 'w', encoding='utf-8').write('\n'.join(L))
# Lazy: bb1SimLazy_eq formula + glue
path = os.path.join(WT, P + 'Lazy.lean')
t = open(path, encoding='utf-8').read()
old = "/-- `bb1SimLazy` is `oracleImpl` of `bb1SimInit`, `bb1SimKeyQ` and `bb1SimLazyChal`. -/"
new = ("/-- `bb1SimLazy` is `oracleImpl` of `bb1SimInit`, `bb1SimKeyQ` and `bb1SimLazyChal`:\n"
       "`bb1SimLazy … zt = oracleImpl κ (bb1SimInit …) (bb1SimKeyQ …) (bb1SimLazyChal … zt)`. Glue: the\n"
       "reader of `bb1SimLazy`. -/")
assert t.count(old) == 1; t = t.replace(old, new); open(path, 'w', encoding='utf-8').write(t)
# Real: BB1RealState docstring, its reader, and the two §2.1 tags
path = os.path.join(WT, P + 'Real.lean')
t = open(path, encoding='utf-8').read()
old = ("/-- The real game's state with the parameter `h` recorded beside the committed identity, and\n"
       "the recorded challenge. -/\n"
       "abbrev BB1RealState (κ : ℕ) (d : List Bool) : Type :=\n"
       "  Option ((Fin ((bb1Scheme G ℓ).idLen.eval κ) → Bool) × (G.group κ d).G) ×\n"
       "    Option (Fin ((bb1Scheme G ℓ).ctLen.eval κ) → Bool)\n")
new = ("/-- The real game's state with the parameter `h` recorded beside the committed identity, and\n"
       "the recorded challenge: `Option ((Fin idLen → Bool) × G) × Option (Fin ctLen → Bool)`. Glue:\n"
       "the state of `bb1RealAt` and `bb1RealLazy`. -/\n"
       "abbrev BB1RealState (κ : ℕ) (d : List Bool) : Type :=\n"
       "  Option ((Fin ((bb1Scheme G ℓ).idLen.eval κ) → Bool) × (G.group κ d).G) ×\n"
       "    Option (Fin ((bb1Scheme G ℓ).ctLen.eval κ) → Bool)\n"
       "\n"
       "/-- `BB1RealState G ℓ κ d` is the optional pair of the committed identity and the recorded `h`,\n"
       "with the optional recorded challenge: `BB1RealState G ℓ κ d =\n"
       "Option ((Fin idLen → Bool) × G) × Option (Fin ctLen → Bool)`. Glue: the reader of\n"
       "`BB1RealState` (policy §1). -/\n"
       "theorem bb1RealState_eq (κ : ℕ) (d : List Bool) :\n"
       "    BB1RealState G ℓ κ d =\n"
       "      (Option ((Fin ((bb1Scheme G ℓ).idLen.eval κ) → Bool) × (G.group κ d).G) ×\n"
       "        Option (Fin ((bb1Scheme G ℓ).ctLen.eval κ) → Bool)) := rfl\n")
assert t.count(old) == 1; t = t.replace(old, new)
old = "/-- **The game's oracles with `h` recorded** [BB04, §2.1]: with hidden bit `b`, on the\n"
new = ("/-- **The game's oracles with `h` recorded** (a variant of the game of [BB04, §2.1], with `h`\n"
       "recorded beside the committed identity): with hidden bit `b`, on the\n")
assert t.count(old) == 1; t = t.replace(old, new)
old = "/-- **The game's oracles with `h` drawn at the first `Init`** [BB04, §2.1]: the first `Init`\n"
new = ("/-- **The game's oracles with `h` drawn at the first `Init`** (a variant of the game of\n"
       "[BB04, §2.1], with `h` drawn late): the first `Init`\n")
assert t.count(old) == 1; t = t.replace(old, new)
open(path, 'w', encoding='utf-8').write(t)
print('drafted')
