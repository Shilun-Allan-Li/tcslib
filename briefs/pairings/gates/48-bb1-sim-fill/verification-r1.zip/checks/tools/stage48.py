"""stage48.py <repo> <g48-dir> (Gate 48, the bb1-sim gate, maintainer staging; no Lean, no lake): builds from git
objects and the two recorded evidence ZIPs (already extracted under <g48-dir>/ev1, ev2):
  out/pr357.diff.txt, out/pr357-description.md, out/source-head-r1.json, out/sources-r1.zip,
  vstage/ (the verification tree: checks/, records/, phase1/, phase2/, pr/), which mkverif48 zips.
Nothing is re-run: the checks here are git-object reads (diffs, hashes, merge-tree, line counts)."""
import sys, os, json, hashlib, subprocess, zipfile, shutil, re

repo, g = sys.argv[1:3]
TIP = 'e1d39836ed4a69a34914c35f4c73c71de853dcc6'      # PR base, records tip at PR opening
PIN = 'e6cdf4d4eed898acd71d48bd60082140eb076cfe'      # records pin (origin/cryptography/pass-shelat-ch2-4 at staging)
HEAD = '7a98ba0140ce6334bef1f2a8d39c6dfceb6ccaff'     # PR #357 head
M346 = '3f540c22360c869069a0fba684e23ce6f3cb20db'     # #346 merge, olean snapshot #5's tree
CODE = ['TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean', 'lake-manifest.json', 'lean-toolchain']
IB = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/'
OUT, VS = os.path.join(g, 'out'), os.path.join(g, 'vstage')
P1 = os.path.join(g, 'ev1', 'bb1-sim-fill-final-r1-phase1-evidence')
P2 = os.path.join(g, 'ev2', 'bb1-sim-fill-final-r1-phase2')
R = os.path.join(repo, 'briefs/pairings/fills/bb1-sim')
for d in (OUT, VS):
    if os.path.exists(d): shutil.rmtree(d)
    os.makedirs(d)

def git(*a, text=True):
    return subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True, text=text).stdout
def show(rev, p): return git('show', f'{rev}:{p}', text=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def put(rel, data):
    p = os.path.join(VS, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb').write(data if isinstance(data, bytes) else data.encode())

files9 = git('diff', '--name-only', TIP, HEAD).split()
assert len(files9) == 9, files9

# 1. the PR diff (two-dot from the merge base, checked equal to the three-dot view)
d2 = git('diff', TIP, HEAD, text=False); d3 = git('diff', f'{TIP}...{HEAD}', text=False)
assert d2 == d3 and git('merge-base', TIP, HEAD).strip() == TIP
open(os.path.join(OUT, 'pr357.diff.txt'), 'wb').write(d2)
shutil.copy(os.path.join(g, 'pr', 'body.md'), os.path.join(OUT, 'pr357-description.md'))

# 2. source-head-r1.json
info = {}
for f in files9:
    b = show(HEAD, f); ls = b.decode().split('\n')
    if ls and ls[-1] == '': ls = ls[:-1]
    w = [len(l) for l in ls]
    st = 'A' if subprocess.run(['git', '-C', repo, 'cat-file', '-e', f'{TIP}:{f}'], capture_output=True).returncode else 'M'
    info[f] = {'status': st, 'blob': git('rev-parse', f'{HEAD}:{f}').strip(), 'sha256': sha(b), 'lines': len(ls),
               'lines_at_base': (len(show(TIP, f).decode().rstrip('\n').split('\n')) if st == 'M' else None),
               'sha256_at_base': (sha(show(TIP, f)) if st == 'M' else None),
               'max_width': max(w), 'over_100': sum(x > 100 for x in w),
               'tabs': sum('\t' in l for l in ls), 'trailing_space': sum(l != l.rstrip(' ') for l in ls)}
commits = []
for c in git('rev-list', '--reverse', f'{TIP}..{HEAD}').split():
    raw = git('cat-file', '-p', c)
    commits.append({'commit': c, 'parent': git('rev-parse', f'{c}^').strip(),
                    'subject': git('log', '-1', '--format=%s', c).strip(),
                    'author': git('log', '-1', '--format=%an <%ae> %aI', c).strip(),
                    'committer_date': git('log', '-1', '--format=%cI', c).strip(),
                    'gpgsig': raw.count('\ngpgsig ') + raw.startswith('gpgsig '),
                    'files': git('diff', '--name-only', f'{c}^', c).split()})
sh = {'pr': 357, 'head': HEAD, 'base_branch': 'cryptography/pass-shelat-ch2-4', 'base': TIP,
      'base_lean_equal_to': M346, 'records_pin': PIN, 'pin_tree_x_head': git('merge-tree', '--write-tree', PIN, HEAD).strip(),
      'diff_stat': git('diff', '--shortstat', TIP, HEAD).strip(), 'pr357_diff_sha256': sha(d2),
      'commits': commits, 'files': info}
open(os.path.join(OUT, 'source-head-r1.json'), 'w').write(json.dumps(sh, indent=1, sort_keys=True, ensure_ascii=False) + '\n')

# 3. checks/ (git-object reads only)
L = []
L.append(f'# series and pins (git objects; no Lean)\n')
L.append(f'records pin {PIN}: {git("log", "-1", "--format=%s", PIN).strip()}')
L.append(f'PR base {TIP}: {git("log", "-1", "--format=%s", TIP).strip()}')
L.append(f'merge-base(pin, head) = {git("merge-base", PIN, HEAD).strip()}')
L.append(f'pin descends from base: {subprocess.run(["git", "-C", repo, "merge-base", "--is-ancestor", TIP, PIN]).returncode == 0}')
L.append(f'records commits base..pin: ' + ' '.join(git('rev-list', f'{TIP}..{PIN}').split()))
L.append(f'code paths changed base..pin ({" ".join(CODE)}): {len(git("diff", "--name-only", TIP, PIN, "--", *CODE).split())}')
L.append(f'code paths changed {M346[:8]} (#346 merge, snapshot #5)..base: {len(git("diff", "--name-only", M346, TIP, "--", *CODE).split())}')
L.append(f'pin x head merge-tree: {sh["pin_tree_x_head"]}; paths changed vs pin: '
         + ' '.join(git('diff', '--name-only', PIN, sh['pin_tree_x_head']).split()))
L.append(f'\ngit diff base head == git diff base...head: True; sha256 {sha(d2)}; {sh["diff_stat"]}')
L.append(git('diff', '--numstat', TIP, HEAD))
L.append('commits (base..head):')
for c in commits:
    L.append(f'  {c["commit"]} parent {c["parent"][:8]} gpgsig={c["gpgsig"]} author {c["author"]} committed {c["committer_date"]}')
    L.append(f'    {c["subject"]}')
    L.append(f'    files: {" ".join(x.replace(IB, "IB/") for x in c["files"])}')
L.append('\nThe signing key of each commit is read from its signature blob in phase 2 (phase2/landing/sigfp.log); this')
L.append('staging checks only that every commit carries a gpgsig header (no ssh-keygen verify on this host).')
put('checks/series.txt', '\n'.join(L) + '\n')

P = ['# reader pins and approved blocks (git objects)\n']
for f, pin in (('Defs.lean', '97ecb6e02413d18fce255949ed4b3e777c8f653a59f0792b575be3ff24a6a9a0'),
               ('BonehBoyen.lean', '88454d6fb0fa2c81419b189dbc633609357ee39b35ccbe90c810a0ad10891c26')):
    hb, bb = show(HEAD, IB + f), show(TIP, IB + f)
    P.append(f'{f}: base {sha(bb)} ({bb.count(b"\n")} lines); head {sha(hb)} ({hb.count(b"\n")} lines); ruled pin {pin}: {sha(hb) == pin}')
for b in ('Defs-block.lean.txt', 'BonehBoyen-block.lean.txt'):
    x = show(PIN, f'briefs/pairings/fills/bb1-sim/issued-fill-r1/readers/{b}')
    P.append(f'approved block {b} (issued-fill-r1/readers at the pin): {sha(x)} ({x.count(b"\n")} lines)')
P.append('\nThe pure-insertion check with its 12 controls is phase 2\'s inscheck_tip.py: phase2/static/inscheck-tip.out.')
put('checks/pins.txt', '\n'.join(P) + '\n')

T = ['# source tags (git objects): tags on lines the PR adds, and per file at the head\n', 'added lines (git diff base head; tags on one line only, so a tag broken across two lines is not counted here):']
tagre = re.compile(r'\[[A-Z][A-Za-z]+[0-9]{2}[^\]\n]*\]')
add = [l for l in d2.decode().split('\n') if l.startswith('+') and not l.startswith('+++')]
from collections import Counter
for t, n in sorted(Counter(t for l in add for t in tagre.findall(l)).items(), key=lambda x: (-x[1], x[0])): T.append(f'  {n:3d} {t}')
T.append(f'  added lines with "Glue:": {sum("Glue:" in l for l in add)}')
for f in files9:
    T.append(f'{f}:')
    for t, n in sorted(Counter(tagre.findall(show(HEAD, f).decode())).items(), key=lambda x: (-x[1], x[0])): T.append(f'  {n:3d} {t}')
put('checks/tags.txt', '\n'.join(T) + '\n')

D = ['# DL-57 twins at the head (git grep)\n', git('grep', '-n', r"sidSpec_rng_one\|sidSpec_rng_two\|sidSpec_dom_\|zeroBits_eq_cast", HEAD, '--', 'TCSlib')]
put('checks/dl57.txt', '\n'.join(D))

# 4. records/ (bytes at the pin)
recs = ['briefs/pairings/fills/bb1-sim/rulings.md', 'briefs/pairings/fills/bb1-sim/design-r1.md',
        'briefs/pairings/fills/bb1-sim/fill-checkpoint1-review.md',
        'briefs/pairings/fills/bb1-sim/fill-final-r1/review.md', 'briefs/pairings/fills/bb1-sim/fill-final-r1/phase2.md',
        'briefs/pairings/fills/bb1-sim/fill-final-r1/evidence-SHA256SUMS',
        'briefs/pairings/fills/bb1-sim/issued-fill-r1/README.md', 'briefs/pairings/fills/bb1-sim/issued-fill-r1/brief.md',
        'briefs/pairings/fills/bb1-sim/issued-fill-r1/SHA256SUMS',
        'briefs/pairings/fills/bb1-sim/issued-fill-r1/readers/Defs-block.lean.txt',
        'briefs/pairings/fills/bb1-sim/issued-fill-r1/readers/BonehBoyen-block.lean.txt',
        'briefs/pairings/gates/44-pairing-fills/findings-r1.md', 'briefs/pairings/gates/44-pairing-fills/findings-r2.md',
        'policy.md']
for p in recs: put('records/' + p, show(PIN, p))
plan = show(PIN, 'PairingCryptographyPlan.md').decode().split('\n')
hdr = [i for i, l in enumerate(plan) if l.startswith('| Date | Decision / evidence |')][0]
rows = [i for i, l in enumerate(plan) if l.startswith('| 2026-11-1')]
first = [i for i in rows if 'bb1-sim design note r1' in plan[i]][0]; last = rows[-1]
put('records/decision-log-pairings.md',
    f'# Decision-log extract: PairingCryptographyPlan.md at {PIN}, the table header (lines {hdr+1}-{hdr+2}) and rows '
    f'{first+1}-{last+1} (bb1-sim design note r1 to #357)\n\n' + '\n'.join(plan[hdr:hdr+2] + plan[first:last+1]) + '\n')
led = show(PIN, 'briefs/pass-shelat-ch5-8/duplication-ledger.md').decode().split('\n')
lh = [i for i, l in enumerate(led) if l.startswith('| DL-') or l.startswith('| ID')][:1]
lrows = [i for i, l in enumerate(led) if re.match(r'\| DL-5[5-7] ', l)]
th = [i for i in range(lrows[0], -1, -1) if led[i].startswith('|---')][0] - 1
put('records/duplication-ledger-DL55-57.md',
    f'# Extract: briefs/pass-shelat-ch5-8/duplication-ledger.md at {PIN}, table header (lines {th+1}-{th+2}) and rows '
    f'DL-55 to DL-57 (lines {lrows[0]+1}-{lrows[-1]+1}). As at the pin, these rows have five cells under the four-column header '
    f'of the table that holds them.\n\n' + '\n'.join(led[th:th+2] + [led[i] for i in lrows]) + '\n')
cs = show(PIN, 'briefs/pass-shelat-ch5-8/cleanup-stages.md').decode().split('\n')
s2 = [i for i, l in enumerate(cs) if l.startswith('## Stage 2')][0]
e2 = [i for i in range(s2 + 1, len(cs)) if cs[i].startswith('## ')][0]
put('records/cleanup-stages-stage2.md',
    f'# Extract: briefs/pass-shelat-ch5-8/cleanup-stages.md at {PIN}, lines {s2+1}-{e2} (Stage 2)\n\n' + '\n'.join(cs[s2:e2]) + '\n')

# 5. phase1/ (whole) and phase2/ (all but the large raw scan/state/plan files; the original SHA256SUMS kept)
for root, base in ((P1, 'phase1'), (P2, 'phase2')):
    for r, _, fs in os.walk(root):
        for f in fs:
            src = os.path.join(r, f); rel = os.path.relpath(src, root)
            if base == 'phase2' and rel in ('scan/items-head.json', 'scan/explicit-head.json', 'scan/ScanKindsHead.lean.txt',
                                            'replay/plan/keys.tsv', 'replay/state/state-init-3f540c22.json.gz',
                                            'replay/state/state-after.json.gz', 'axioms/runs/current.pid'):
                continue
            if rel == 'SHA256SUMS': rel = 'SHA256SUMS.original'
            put(f'{base}/{rel}', open(src, 'rb').read())

# 6. pr/ fields (REST, read at staging)
rest = json.load(open(os.path.join(g, 'pr', 'pr357-rest.json')))
keep = {k: rest[k] for k in ('number', 'title', 'state', 'draft', 'created_at', 'updated_at', 'additions', 'deletions',
                              'changed_files', 'commits', 'merged', 'mergeable_state')}
keep['head'] = {'ref': rest['head']['ref'], 'sha': rest['head']['sha']}
keep['base'] = {'ref': rest['base']['ref'], 'sha': rest['base']['sha']}
keep['body_sha256'] = sha(rest['body'].encode())
put('pr/pr357-rest-fields.json', json.dumps(keep, indent=1, sort_keys=True, ensure_ascii=False) + '\n')

# 7. sources-r1.zip
ents = []
for f in files9: ents.append((f'head-7a98ba01/{f}', show(HEAD, f), f'{HEAD}:{f}'))
for f in files9:
    if info[f]['status'] == 'M': ents.append((f'base-e1d39836/{f}', show(TIP, f), f'{TIP}:{f}'))
ctx = ['TCSlib/Cryptography/Games/Simulate.lean', 'TCSlib/Cryptography/Games/Probability.lean',
       'TCSlib/Cryptography/Games/Hopping.lean', 'TCSlib/Cryptography/Games/Bridges/Experiments.lean',
       'TCSlib/Cryptography/Games/Machines.lean', 'TCSlib/Cryptography/Asymptotic/Sampling.lean',
       'TCSlib/Cryptography/Encryption/PrivateKey/OracleSecurity.lean', 'TCSlib/Cryptography/Pairing/Group.lean',
       'TCSlib/Cryptography/Pairing/Assumptions.lean', IB + 'BonehBoyenMachine.lean', IB + 'BonehBoyenMachine/Oracles.lean']
for f in ctx:
    assert git('rev-parse', f'{HEAD}:{f}') == git('rev-parse', f'{TIP}:{f}')
    ents.append((f'context-7a98ba01/{f}', show(HEAD, f), f'{HEAD}:{f} (blob-equal at the base)'))
for p in ('boneh-boyen-2004-selective-id-ibe.md', 'boneh-boyen-2004-selective-id-ibe.raw.md',
          'barthe-gregoire-zanella-2009-certified-proofs.md', 'shoup-2004-sequences-of-games.md'):
    ents.append((f'references/{p}', show(PIN, f'blueprint/src/references/{p}'), f'{PIN}:blueprint/src/references/{p}'))
readme = ['# Gate 48 source bundle', '', 'Every entry is read from git objects; SHA-256 of the bytes and the origin `rev:path`.', '',
          f'- `head-7a98ba01/`: the 9 files PR #357 changes, at its head `{HEAD}`.',
          f'- `base-e1d39836/`: the 4 of them that exist at the base (records tip `{TIP}`, Lean-equal to `{M346}`).',
          '- `context-7a98ba01/`: the TCSlib modules the 9 files import directly that the PR does not change, plus T4\'s',
          '  `BonehBoyenMachine/Oracles.lean` (the private twins of DL-57); each is blob-equal at the base and the head.',
          '- `references/`: the DW-7 BB04 transcription (`.md` and `.raw.md`) that the new tags cite, and the [BGZ09] and [Sho04]',
          '  transcriptions cited by `Games/Relational.lean`\'s frozen docstrings (#351, context only).', '',
          '| Entry | SHA-256 | Origin |', '|---|---|---|']
readme += [f'| `{n}` | `{sha(b)}` | `{o}` |' for n, b, o in ents]
with zipfile.ZipFile(os.path.join(OUT, 'sources-r1.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in [('README.md', ('\n'.join(readme) + '\n').encode())] + [(n, b) for n, b, _ in ents]:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16; z.writestr(zi, b)
print('files9', len(files9), 'sources entries', len(ents) + 1)
