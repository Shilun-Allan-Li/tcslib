#!/usr/bin/env bash
# mergetrees48.sh <repo> <out> (Gate 48 staging; no Lean): git merge-tree --write-tree of #357's head with the open PR
# heads and the local 6a landing branches; shared paths by side since the merge base, and #357's own 9 files. Writes only
# unreferenced objects (the two commit-tree merges below are temporary and unreferenced).
set -u
R=$1; OUT=$2; H=7a98ba0140ce6334bef1f2a8d39c6dfceb6ccaff; BASE=e1d39836ed4a69a34914c35f4c73c71de853dcc6
PIN=e6cdf4d4eed898acd71d48bd60082140eb076cfe
g() { git -C "$R" "$@"; }
export GIT_AUTHOR_NAME=stage GIT_AUTHOR_EMAIL=stage@invalid GIT_COMMITTER_NAME=stage GIT_COMMITTER_EMAIL=stage@invalid
export GIT_AUTHOR_DATE=2026-11-17T00:00:00Z GIT_COMMITTER_DATE=2026-11-17T00:00:00Z
OWN=$(mktemp); g diff --name-only $BASE $H | sort > $OWN
{
echo "# merge-tree of #357 head $H (git $(git --version | cut -d' ' -f3))"
echo "#357's own paths (base $BASE): $(wc -l < $OWN)"
echo
for spec in "records pin|origin/cryptography/pass-shelat-ch2-4|$PIN" \
            "#347 cleanup/dw5-derand-readers|origin/cleanup/dw5-derand-readers|daa6e173cdd94cad1475b9a96eca613bce53ba61" \
            "#355 land/cleanup-stage1|origin/land/cleanup-stage1|d3c7cb00092ad5913904654d922f30fc7d5fce4a" \
            "6a land/gsw-6a-o1 (local, unpushed, no PR)|land/gsw-6a-o1|a616adcac0760ab56b1b0a2a4869f4763843f9ab" \
            "6a land/gsw-6a-statements (local, unpushed, no PR)|land/gsw-6a-statements|73aedcdaaaffef7e69ab012d9b9195f150bae68d"; do
  IFS='|' read -r name ref want <<< "$spec"
  got=$(g rev-parse "$ref"); echo "== $name: $ref = $got (expected $want: $([ "$got" = "$want" ] && echo ok || echo MISMATCH))"
  B=$(g merge-base $H $got); T=$(g merge-tree --write-tree --name-only $H $got); rc=$?
  echo "   merge-base $B; rc=$rc; tree $(echo "$T" | head -1)"; [ $rc -ne 0 ] && echo "$T" | sed 's/^/   /'
  S=$(mktemp); g diff --name-only $B $got | sort > $S
  echo "   paths changed by the other side since the merge base: $(wc -l < $S)"
  echo "   shared with #357's side since the merge base: $(comm -12 <(g diff --name-only $B $H | sort) $S | tr '\n' ' ')"
  echo "   shared with #357's own 9 paths: $(comm -12 $OWN $S | wc -l)"
  rm -f $S
done
echo
echo "== origin refs matching land/gsw-6a-*: $(g ls-remote origin 'refs/heads/land/gsw-6a-*' | wc -l) (git ls-remote at staging)"
echo
echo "== three-way simulations: (records pin x other) x #357"
for o in daa6e173cdd94cad1475b9a96eca613bce53ba61 d3c7cb00092ad5913904654d922f30fc7d5fce4a; do
  T1=$(g merge-tree --write-tree $PIN $o); r1=$?
  C1=$(g commit-tree $T1 -p $PIN -p $o -m tmp < /dev/null)
  T2=$(g merge-tree --write-tree $C1 $H); r2=$?
  n=0; for f in $(cat $OWN); do [ "$(g rev-parse $T2:$f)" = "$(g rev-parse $H:$f)" ] || n=$((n+1)); done
  echo "   pin x ${o:0:8}: rc=$r1 tree $T1; then x #357: rc=$r2 tree $T2; paths changed vs the first merge: $(g diff --name-only $C1 $T2 | wc -l); #357 files not blob-equal to the head: $n"
done
echo
echo "== Games.lean at the pin, #357 and #355 (the one path shared since 2da7e0f3; #357 itself does not touch it)"
echo "   pin $(g rev-parse $PIN:TCSlib/Cryptography/Games.lean)  #357 $(g rev-parse $H:TCSlib/Cryptography/Games.lean)  #355 $(g rev-parse d3c7cb00:TCSlib/Cryptography/Games.lean)"
} > "$OUT"
rm -f $OWN
