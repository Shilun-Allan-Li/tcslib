"""mkverif48.py <repo> <stage-dir> <out.zip> (Gate 48, maintainer; no Lean): write POINTERS.md and MANIFEST.md into
<stage-dir>, copy this tool and the staging tools into checks/tools/, then zip <stage-dir> deterministically (sorted paths,
fixed timestamps, mode 0644) after writing <stage-dir>/SHA256SUMS over every other file (Gate 44's mkverif44 layout)."""
import sys, os, zipfile, hashlib, subprocess, shutil
repo, st, outz = sys.argv[1:4]
PIN = 'e6cdf4d4eed898acd71d48bd60082140eb076cfe'
sha = lambda b: hashlib.sha256(b).hexdigest()
show = lambda p: subprocess.run(['git', '-C', repo, 'show', f'{PIN}:{p}'], capture_output=True, check=True).stdout
here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(st, 'checks/tools'), exist_ok=True)
for t in ('stage48.py', 'mergetrees48.sh', 'mkverif48.py', 'mkbundle48.py'):
    if os.path.exists(os.path.join(here, t)): shutil.copy(os.path.join(here, t), os.path.join(st, 'checks/tools', t))

zips = ['briefs/pairings/fills/bb1-sim/fill-final-r1/bb1-sim-fill-final-r1-phase1-evidence.zip',
        'briefs/pairings/fills/bb1-sim/fill-final-r1/bb1-sim-fill-final-r1-phase2-evidence.zip',
        'briefs/pairings/fills/bb1-sim/fill-checkpoint1-review-evidence.zip',
        'briefs/pairings/fills/bb1-sim/statements-final-r1/bb1-sim-statements-r1-phase1-evidence.zip',
        'briefs/pairings/fills/bb1-sim/statements-final-r1/bb1-sim-statements-r1-phase2-evidence.zip',
        'briefs/pairings/fills/bb1-sim/statements-final-r1/bb1-sim-statements-r1-phase2b-evidence.zip']
P = ['# Pointers: evidence not copied whole into this ZIP', '',
     f'Records ZIPs at the records pin `{PIN}` (size in bytes and SHA-256 of the git blob):', '',
     '| Path | Bytes | SHA-256 | Here |', '|---|---:|---|---|']
here_note = {zips[0]: 'whole, extracted under `phase1/`', zips[1]: 'extracted under `phase2/`, all but 7 large raw files (below)',
             zips[2]: 'not copied (checkpoint 1)', zips[3]: 'not copied (#351/#352 statements, out of scope)',
             zips[4]: 'not copied (#351/#352 statements, out of scope)', zips[5]: 'not copied (#352 re-replay, out of scope)'}
for z in zips:
    b = show(z); P.append(f'| `{z}` | {len(b)} | `{sha(b)}` | {here_note[z]} |')
P += ['', 'Left out of `phase2/` (each is listed with its SHA-256 in `phase2/SHA256SUMS.original`):',
      '`scan/items-head.json`, `scan/explicit-head.json`, `scan/ScanKindsHead.lean.txt` (the scan\'s raw item lists and kinds probe;',
      'the summary `scan/scan2-head.log` is here), `replay/plan/keys.tsv`, `replay/state/state-init-3f540c22.json.gz`,',
      '`replay/state/state-after.json.gz` (the state plan and records; the `check*.out` and `update.out` results are here) and',
      '`axioms/runs/current.pid`. Verify the rest with `cd phase2 && sha256sum -c --ignore-missing SHA256SUMS.original`.', '',
      'Not in any ZIP: the raw seal records, control sources and probe logs of phase 2 (about 140 MB). Their SHA-256 are in',
      '`phase2/rule10/omitted-SHA256SUMS` (seals and controls) and `phase2/scan/omitted-SHA256SUMS` (scan runs); the files are',
      'on the maintainer host only. The summaries derived from them (`rule10/seals-*.tsv`, `mkseals-*.log`, `seal-runs/results.jsonl`,',
      '`ctlcheck-*.json`/`.log`, `controls-plan-*.json`) are here.', '',
      'The worker delivery (the patches, `src/`, the worker\'s own seals, base seals, controls and logs) is on the exchange at',
      '`2467bc3befdad8472b1f359337bf3a203e3651e1`, `inbox/fills/bb1-sim/` (1426 files): `SHA256SUMS`',
      '`78cf67002642f411fcf794005cbc25c0cd75b76dceaaffc3d4636b435d1b63f7`, `evidence/SHA256SUMS`',
      '`0269eda5b7298fe922beed327957032709b9174523ef2e8f97eb9181c4dc5f9a`, `REPORT.md`',
      '`5b2e592f4058398c685df6072f7fd4bab3072cb78f879ea52ec62a6ca2b330d3`. The 16 base seals the phase-1 review recounted are',
      'there (phase 2 did not re-run them).']
open(os.path.join(st, 'POINTERS.md'), 'w').write('\n'.join(P) + '\n')

M = ['# verification-r1.zip · Gate 48 (bb1-sim gate) round 1', '',
     'Every entry except `SHA256SUMS` is listed in `SHA256SUMS`. Nothing here was produced by a new Lean run: `phase1/` and',
     '`phase2/` are the maintainer review\'s recorded evidence, copied byte for byte; `checks/` are git-object reads made at',
     'staging; `records/` are byte copies or marked extracts of records at the pin.', '',
     '| Path | What | Origin |', '|---|---|---|',
     '| `POINTERS.md` | evidence not copied whole, with sizes and SHA-256 | this staging |',
     '| `checks/series.txt` | pins, Lean-equality of the base with `3f540c22`, the records-only pin delta, the PR diff and its 5 commits | `git` at staging |',
     '| `checks/pins.txt` | the reader pins at base and head and the approved blocks\' hashes | `git` at staging |',
     '| `checks/mergetrees.txt` | `git merge-tree --write-tree` of the head with the pin, #347, #355 and the local 6a branches; 3-way simulations | `tools/mergetrees48.sh` |',
     '| `checks/tags.txt` | source tags on the added lines and per file at the head | `git` at staging |',
     '| `checks/dl57.txt` | DL-57\'s declarations at the head (`git grep`) | `git` at staging |',
     '| `checks/tools/` | the staging scripts | this staging |',
     '| `phase1/` | the phase-1 (static) review evidence, whole; its own manifest is `phase1/SHA256SUMS.original` | `bb1-sim-fill-final-r1-phase1-evidence.zip` |',
     '| `phase2/` | the phase-2 (Lean, snapshot #5) evidence, all but 7 large raw files; `phase2/SHA256SUMS.original` is its manifest | `bb1-sim-fill-final-r1-phase2-evidence.zip` |',
     '| `phase2/phase2.md`, `PROVENANCE.txt` | the phase-2 report and its provenance | phase 2 |',
     '| `phase2/landing/` | the `git am` reproduction, the cherry-picks, the signature key per commit, LE-bsf1 as applied | phase 2 |',
     '| `phase2/static/` | decls2 vs the tip (69/0/0) and its summary, the reader insertion check (12 controls), the frozen check (8 controls), hygiene | phase 2 |',
     '| `phase2/replay/` | orders, plan queue, build results and per-module records, state checks, link counts, snapshot #5 rehashes, output map | phase 2 |',
     '| `phase2/admissions/` | the census at the tip and the head and their diff (196 → 192) | phase 2 |',
     '| `phase2/axioms/` | the probe source `AxiomsBsf.lean.txt` and its log (76 constants, census 325, traces, sorry control) | phase 2 |',
     '| `phase2/rule10/` | the seal tables and `mkseals` logs (36), the control plans and `ctlcheck` results (strict, coe), the driver logs, `attempt1/`, `omitted-SHA256SUMS` | phase 2 |',
     '| `phase2/scan/` | the explicit-unfold scan summary (527 items, 0 foreign), the file list, `omitted-SHA256SUMS` | phase 2 |',
     '| `phase2/lint/` | `campaign_style_lint` at tip and head and their diffs, `style_lint`, `sk15` | phase 2 |',
     '| `phase2/statements/` | the declaration-level comparison of the 9 files, tip → head | phase 2 |',
     '| `phase2/tools/` | the phase-2 drivers and adapted tools | phase 2 |',
     '| `records/briefs/pairings/fills/bb1-sim/…` | design r1, rulings, checkpoint-1 review, the final review (phase 1 + phase-2 verdict), phase2.md, evidence sums, the issued brief, README, sums and the two approved reader blocks | records at the pin |',
     '| `records/briefs/pairings/gates/44-pairing-fills/findings-r{1,2}.md` | Gate 44\'s findings (precedent for G44-01..03) | records at the pin |',
     '| `records/policy.md` | the repository standards | records at the pin |',
     '| `records/decision-log-pairings.md` | the plan\'s decision-log rows from the bb1-sim design note to #357 | extract at the pin |',
     '| `records/duplication-ledger-DL55-57.md`, `records/cleanup-stages-stage2.md` | DL-55..DL-57 and cleanup Stage 2 | extracts at the pin |',
     '| `pr/pr357-rest-fields.json` | PR #357\'s REST fields at staging (head, base, counts, body SHA-256) | GitHub REST |']
open(os.path.join(st, 'MANIFEST.md'), 'w').write('\n'.join(M) + '\n')

files = sorted(os.path.relpath(os.path.join(r, f), st) for r, _, fs in os.walk(st) for f in fs)
files = [f for f in files if f != 'SHA256SUMS' and '__pycache__' not in f]
with open(os.path.join(st, 'SHA256SUMS'), 'w') as o:
    for f in files: o.write(f'{sha(open(os.path.join(st, f), "rb").read())}  {f}\n')
with zipfile.ZipFile(outz, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in files + ['SHA256SUMS']:
        zi = zipfile.ZipInfo(f, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16; z.writestr(zi, open(os.path.join(st, f), 'rb').read())
print(f'{len(files) + 1} entries; SHA256SUMS {sha(open(os.path.join(st, "SHA256SUMS"), "rb").read())}')
