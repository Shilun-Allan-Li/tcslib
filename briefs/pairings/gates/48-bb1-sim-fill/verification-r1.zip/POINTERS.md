# Pointers: evidence not copied whole into this ZIP

Records ZIPs at the records pin `e6cdf4d4eed898acd71d48bd60082140eb076cfe` (size in bytes and SHA-256 of the git blob):

| Path | Bytes | SHA-256 | Here |
|---|---:|---|---|
| `briefs/pairings/fills/bb1-sim/fill-final-r1/bb1-sim-fill-final-r1-phase1-evidence.zip` | 38840 | `f74bcbde5cf84a189b1d9950bb09a05683fe57732405e122b7ac38636ce2035c` | whole, extracted under `phase1/` |
| `briefs/pairings/fills/bb1-sim/fill-final-r1/bb1-sim-fill-final-r1-phase2-evidence.zip` | 734436 | `3843d02aaf73206b58df80875bfaa4d95bc0aa4fdd5d074a44403c81d6af792a` | extracted under `phase2/`, all but 7 large raw files (below) |
| `briefs/pairings/fills/bb1-sim/fill-checkpoint1-review-evidence.zip` | 9832 | `b0821ac0ffe8a4b078e9ef41b0c66f07ad2d3d49cf90a11b6e8a90178f2f2b61` | not copied (checkpoint 1) |
| `briefs/pairings/fills/bb1-sim/statements-final-r1/bb1-sim-statements-r1-phase1-evidence.zip` | 87443 | `6e4cbadd51e8478fb9093172e42dc6fd4da7b1a1e8ed1408047d9c60bb86c960` | not copied (#351/#352 statements, out of scope) |
| `briefs/pairings/fills/bb1-sim/statements-final-r1/bb1-sim-statements-r1-phase2-evidence.zip` | 4048148 | `411338e9dcd84d815d12899795599631d64e5f48d5698ac149fc3d3821e5eed8` | not copied (#351/#352 statements, out of scope) |
| `briefs/pairings/fills/bb1-sim/statements-final-r1/bb1-sim-statements-r1-phase2b-evidence.zip` | 2024807 | `13483b25d6e04e79806314e449421d8fc35cfb50470f045a1b83a85c98b13d09` | not copied (#352 re-replay, out of scope) |

Left out of `phase2/` (each is listed with its SHA-256 in `phase2/SHA256SUMS.original`):
`scan/items-head.json`, `scan/explicit-head.json`, `scan/ScanKindsHead.lean.txt` (the scan's raw item lists and kinds probe;
the summary `scan/scan2-head.log` is here), `replay/plan/keys.tsv`, `replay/state/state-init-3f540c22.json.gz`,
`replay/state/state-after.json.gz` (the state plan and records; the `check*.out` and `update.out` results are here) and
`axioms/runs/current.pid`. Verify the rest with `cd phase2 && sha256sum -c --ignore-missing SHA256SUMS.original`.

Not in any ZIP: the raw seal records, control sources and probe logs of phase 2 (about 140 MB). Their SHA-256 are in
`phase2/rule10/omitted-SHA256SUMS` (seals and controls) and `phase2/scan/omitted-SHA256SUMS` (scan runs); the files are
on the maintainer host only. The summaries derived from them (`rule10/seals-*.tsv`, `mkseals-*.log`, `seal-runs/results.jsonl`,
`ctlcheck-*.json`/`.log`, `controls-plan-*.json`) are here.

The worker delivery (the patches, `src/`, the worker's own seals, base seals, controls and logs) is on the exchange at
`2467bc3befdad8472b1f359337bf3a203e3651e1`, `inbox/fills/bb1-sim/` (1426 files): `SHA256SUMS`
`78cf67002642f411fcf794005cbc25c0cd75b76dceaaffc3d4636b435d1b63f7`, `evidence/SHA256SUMS`
`0269eda5b7298fe922beed327957032709b9174523ef2e8f97eb9181c4dc5f9a`, `REPORT.md`
`5b2e592f4058398c685df6072f7fd4bab3072cb78f879ea52ec62a6ca2b330d3`. The 16 base seals the phase-1 review recounted are
there (phase 2 did not re-run them).
