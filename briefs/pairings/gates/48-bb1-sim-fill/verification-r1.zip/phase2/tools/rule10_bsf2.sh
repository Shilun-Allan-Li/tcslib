#!/usr/bin/env bash
# rule10_bsf2.sh <phase...> (bb1-sim T2/T3 fill, phase 2, maintainer): Lean checks on the landing head
# land/pairings-bb1-sim 7a98ba01 (records tip e1d39836 + the worker's 4 commits + LE-bsf1) after its replay on
# $SP/olean-replay-bb1sim. Composed from Gate 44's rule10_g44.sh and the delivered rule10_bb1sim.sh. The seal harness is
# Gate 44's tools/seal (unmodified) plus: review/mkctl_bsf2.py (the delivered mkctl_bb1sim.py plus the bb1RealState_eq
# entries), runner_full_gated.py and rule10_b_gated.sh (runner_full.py / rule10_b.sh with a host Lean-slot gate only).
# Phases:
#   statements  touched.py, records tip vs landing head, over the 9 changed files
#   collect     collector over the 9 owners
#   seals       rule10_b_gated.sh with mkctl_bsf2.py: strict and coe seals A and B on the 9 owners, paired controls
#   scan        explicit-unfold scan over the 9 files (scan1_g40.py, scan2.py)
#   axioms      probe-src/AxiomsBsf.lean (the delivered Axioms.lean.txt + bb1RealState_eq + a sorry control)
# Every probe through runner_full_gated.py (lean -DmaxErrors=0, no -o: nothing is written to the olean tree). One Lean
# process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/bsp2; W=$G/wt; E=$G/run; TREE=$SP/olean-replay-bb1sim; T=$G/tools/seal; A=$T/review/archived-gate10-tools
H=7a98ba0140ce6334bef1f2a8d39c6dfceb6ccaff; TIP=e1d39836ed4a69a34914c35f4c73c71de853dcc6
# read-only: the seal tools run `git -C <wt> show <rev>:<path>`, and the export is not a repository (attempt 1 failed there)
export GIT_DIR=/home/user/tcslib/.git
export TCSLIB_OLEANS_TREE=$TREE TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH
GM=TCSlib.Cryptography.Games; IM=TCSlib.Cryptography.AdvancedEncryption.IdentityBased
OWN9="$GM.Relational $IM.Defs $IM.BonehBoyen $IM.BonehBoyenSecurity $IM.BonehBoyenSecurity.Lazy $IM.BonehBoyenSecurity.Real $IM.BonehBoyenSecurity.Coupling $IM.BonehBoyenSecurity.Random $IM.BonehBoyenSecurity.Chain"
FILES=$(git -C /home/user/tcslib diff --name-only $TIP $H -- 'TCSlib/*.lean')
P=BSF2; R=$E/rule10
mkdir -p $E/tmp $E/statements $E/axioms $E/scan $R/order $R/probe-sources $W/$P
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) head $H"
case $ph in
statements)
  echo $FILES > $E/statements/files.txt
  python3 -I $T/review/touched.py /home/user/tcslib $TIP $H $E/statements/touched-after.json $FILES > $E/statements/touched-after.tsv 2>&1; echo "touched rc=$?";;
collect)
  printf '%s\n' $OWN9 > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-sim phase 2 collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full_gated.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
seals)
  bash $T/rule10_b_gated.sh $T $W $E $P $H $T/review/mkctl_bsf2.py $OWN9 > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
scan)
  echo $FILES > $E/scan/files.txt
  SCAN_IMPORTS="$OWN9" python3 -I $T/scan1_g40.py $A/scan_explicit.py $W \
    $E/statements/touched-after.json $E/scan/items-head.json $W/$P/ScanKindsHead.lean $FILES > $E/scan/scan1.out 2>&1
  cp $W/$P/ScanKindsHead.lean $E/scan/ScanKindsHead.lean.txt
  echo $P/ScanKindsHead > $E/scan/order.txt
  python3 -I $T/runner_full_gated.py $W $E/scan/order.txt $TREE $E/scan/runs > $E/scan/scan-runner.out 2>&1
  python3 -I $T/scan2.py $E/scan/items-head.json $E/scan/runs/mods/${P}_ScanKindsHead.log \
    $E/scan/explicit-head.json > $E/scan/scan2-head.log 2>&1; echo "scan2 rc=$?";;
axioms)
  cp $G/probe-src/AxiomsBsf.lean $W/$P/AxiomsBsf.lean
  echo $P/AxiomsBsf > $E/axioms/order.txt
  python3 -I $T/runner_full_gated.py $W $E/axioms/order.txt $TREE $E/axioms/runs > $E/axioms/runner.out 2>&1; echo "axioms rc=$?";;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
