import sys, base64, hashlib, struct, subprocess
def fp(commit):
    raw = subprocess.run(['git', 'cat-file', 'commit', commit], capture_output=True).stdout.split(b'\n')
    sig = []; ins = False
    for l in raw:
        if l.startswith(b'gpgsig '): ins = True; sig.append(l[7:]); continue
        if ins and l.startswith(b' '): sig.append(l[1:]); continue
        ins = False
    if not sig: return 'unsigned'
    b = base64.b64decode(b''.join(x for x in sig if not x.startswith(b'-----')))
    assert b[:6] == b'SSHSIG'
    n = struct.unpack('>I', b[10:14])[0]; pk = b[14:14 + n]
    kt = pk[4:4 + struct.unpack('>I', pk[:4])[0]].decode()
    return kt + ' SHA256:' + base64.b64encode(hashlib.sha256(pk).digest()).decode().rstrip('=')
for c in sys.argv[1:]: print(c, fp(c))
