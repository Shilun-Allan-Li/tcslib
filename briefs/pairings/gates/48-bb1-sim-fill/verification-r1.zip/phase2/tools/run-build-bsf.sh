#!/usr/bin/env bash
# run-build-bsf.sh: bb1-sim fill phase 2, landing head 7a98ba0140ce6334bef1f2a8d39c6dfceb6ccaff (records tip e1d39836 + the
# worker's 4 commits cherry-picked + LE-bsf1) on $SP/olean-replay-bb1sim (cp -al of snapshot #5), plan/queue.txt (19 modules),
# through the recipe's runner.py (unmodified), one module per call, so that before each module the host's Lean slot count is
# checked (wait while 3 or more lean processes run; this job is one of at most 3).
set -u
B=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/bsp2; OUT=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-bb1sim
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$B/run/tmp
echo "start $(date -u +%FT%TZ)" > $B/run/build/runner.start; df -m / | tail -1 > $B/run/build/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $B/run/build/slot-waits.txt; sleep 20; done
  echo "$m" > $B/run/build/one/order.txt
  python3 -I $B/tools/runner.py $B/wt $B/run/build/one/order.txt $OUT $B/run/build < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $B/run/build/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $B/run/build/runner.exit; exit 2; }
done < $B/run/plan/queue.txt
echo "runner exit 0 $(date -u +%FT%TZ)" >> $B/run/build/runner.exit; df -m / | tail -1 >> $B/run/build/runner.exit
