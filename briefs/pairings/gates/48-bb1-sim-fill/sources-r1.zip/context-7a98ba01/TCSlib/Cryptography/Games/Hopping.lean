/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.Games.Simulate
import TCSlib.Cryptography.Games.Advantage

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Game hopping

The steps of a game-based security proof, proved once:
- **the difference lemma**: two events that agree unless a "bad" event happens differ in
  probability by at most the probability of the bad event;
- **identical until bad**: two oracle implementations that give the same law to good successors
  until a flag in their state is raised, and never lower it, give simulations whose outputs differ
  in probability by at most the probability that the flag is raised;
- **a collision bound**: one fresh uniform sample lands in a list of at most `q` values fixed
  before it with probability at most `q / |T|`. The adaptive repeated-nonce event of
  [PS10, Thm 168.2] (later nonces hitting an earlier one) is a union of such steps; its lemma is
  scheduled with the statement phase.

The hybrid argument itself is `advantage_hybrid` (`TCSlib.Cryptography.Games.Advantage`).

## Main definitions

* `Games.OracleComp.AllOutputs P c` (in `TCSlib.Cryptography.Games.OracleComp`): every possible
  output of `c` satisfies `P`.

## Main results

* `ProbComp.prob_eq_one_of_allOutputs`, `ProbComp.expect_mono_of_allOutputs`,
  `ProbComp.expect_congr_of_allOutputs`: reasoning on the possible outputs only.
* `ProbComp.abs_prob_sub_le_of_agree`: the difference lemma [Sho04, §1.1, Lemma 1].
* `ProbComp.prob_mem_le`: the collision bound; `ProbComp.expect_sample_mem_le`, its form for a
  uniform sample and a fixed list.
* `ProbComp.expect_simulate_congr`: implementations with the same laws simulate alike.
* `ProbComp.prob_bad_le`: the per-query potential bound `Pr[bad] ≤ q · (size + q) · δ`.
* `Games.prob_eq_until_bad`, `Games.identical_until_bad`, `Games.identical_until_bad_init`: the
  code-based fundamental lemma [BR06], in semantic form, from a fixed or a sampled initial
  state; `Games.hagree_of_eq` recovers the syntactic hypothesis; `Games.expect_eq_until_bad`, the
  expectation form for functions of the output and the final state.
* `Games.expect_simulate_eager`: one-shot coins may be drawn in advance.

## References

* [BR06] M. Bellare, P. Rogaway, *The security of triple encryption and a framework for
  code-based game-playing proofs*, EUROCRYPT 2006; full version IACR ePrint 2004/331 (the
  fundamental lemma of game playing).
* [Sho04] V. Shoup, *Sequences of games: a tool for taming complexity in security proofs*,
  IACR ePrint 2004/332, revision of 18 January 2006 (https://www.shoup.net/papers/games.pdf),
  §1.1, Lemma 1 (the difference lemma).
* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes, 3rd ed., January 2010,
  Thm 168.2 (proof sketch: the bad events of the CPA analysis).
* [VCVio] D. Tuma and the VCVio contributors, *VCVio: machine-checked cryptographic proofs in
  Lean*, https://github.com/dtumad/VCV-io, commit 9054989327a7185ff19ef9ff0f119cccea479501
  (2026-11-04), Apache License 2.0. Design adapted (no code transcribed): oracle specifications
  indexed by a type of oracle names (`VCVio/OracleComp/OracleSpec.lean`), oracle computations as
  a free monad over them (`OracleComp.lean`, `OracleQuery.lean`), probabilistic computations as
  computations over the uniform-selection oracles (`OracleComp/ProbComp/Basic.lean`), and
  simulation of oracles by stateful handlers with query logging and composition (`SimSemantics/`,
  `SimSemantics/QueryImpl/Compose.lean`, `QueryTracking/LoggingOracle`).
-/

namespace TCSlib.Cryptography.Games

open Finset

variable {ι : Type} {α β σ : Type}

namespace ProbComp

/-- An event splits by a second event: `Pr[A] = Pr[A ∧ ¬F] + Pr[A ∧ F]`. -/
theorem prob_split (c : ProbComp α) (A F : α → Prop) :
    prob c A = prob c (fun a => A a ∧ ¬ F a) + prob c (fun a => A a ∧ F a) := by
  classical
  rw [prob_eq_expect, prob_eq_expect, prob_eq_expect, ← expect_add]
  congr 1
  funext a
  by_cases hA : A a <;> by_cases hF : F a <;> simp [hA, hF]

/-- If every possible output of `c` satisfies `P`, and `f ≤ g` at every output satisfying `P`,
then the expectation of `f` over `c` is at most that of `g`. -/
theorem expect_mono_of_allOutputs {c : ProbComp α} {P : α → Prop} (hc : c.AllOutputs P)
    {f g : α → ℝ} (h : ∀ a, P a → f a ≤ g a) : expect c f ≤ expect c g := by
  induction c with
  | pure a =>
    rw [expect_pure, expect_pure]
    exact h a (OracleComp.allOutputs_pure.1 hc)
  | query m x k ih =>
    simp only [expect_query]
    exact mul_le_mul_of_nonneg_left
      (sum_le_sum fun j _ => ih j (OracleComp.allOutputs_query.1 hc j)) (by positivity)

/-- Two functions that agree on every possible output have the same expectation: if
`c.AllOutputs P` and `f a = g a` whenever `P a`, then `𝔼_c f = 𝔼_c g` (`expect_mono_of_allOutputs`
both ways). -/
theorem expect_congr_of_allOutputs {c : ProbComp α} {P : α → Prop} (hc : c.AllOutputs P)
    {f g : α → ℝ} (h : ∀ a, P a → f a = g a) : expect c f = expect c g :=
  le_antisymm (expect_mono_of_allOutputs hc fun a ha => (h a ha).le)
    (expect_mono_of_allOutputs hc fun a ha => (h a ha).ge)

/-- An event holding at every possible output has probability one. -/
theorem prob_eq_one_of_allOutputs {c : ProbComp α} {p : α → Prop} (hc : c.AllOutputs p) :
    prob c p = 1 := by
  classical
  refine le_antisymm (prob_le_one c p) ?_
  rw [prob_eq_expect]
  calc (1 : ℝ) = expect c (fun _ => 1) := (expect_const c 1).symm
    _ ≤ _ := expect_mono_of_allOutputs hc fun a ha => by simp [ha]

/-- An event failing at every possible output has probability zero. -/
theorem prob_eq_zero_of_allOutputs {c : ProbComp α} {p : α → Prop}
    (hc : c.AllOutputs fun a => ¬ p a) : prob c p = 0 := by
  have h := prob_not c p
  rw [prob_eq_one_of_allOutputs hc] at h
  linarith

/-- **The difference lemma:** if the events `A` and `B` agree at every output where `F` fails,
their probabilities differ by at most the probability of `F`. [Sho04, §1.1, Lemma 1]

**Proof sketch.** Pointwise, the indicators of `A` and `B` differ by at most the indicator of
`F`; take expectations in both directions (linearity and monotonicity). -/
theorem abs_prob_sub_le_of_agree (c : ProbComp α) {A B F : α → Prop}
    (h : ∀ a, ¬ F a → (A a ↔ B a)) : |prob c A - prob c B| ≤ prob c F := by
  classical
  have key : ∀ (A B : α → Prop), (∀ a, ¬ F a → (A a ↔ B a)) →
      prob c A ≤ prob c B + prob c F := by
    intro A B hAB
    rw [prob_eq_expect, prob_eq_expect, prob_eq_expect, ← expect_add]
    exact expect_mono c fun a => by
      by_cases hF : F a
      · by_cases hA : A a <;> by_cases hB : B a <;> simp [hA, hB, hF]
      · have := hAB a hF
        by_cases hA : A a
        · simp [hA, this.1 hA, hF]
        · simp [hA, hF]; split_ifs <;> norm_num
  rw [abs_le]
  constructor
  · linarith [key B A fun a ha => (h a ha).symm]
  · linarith [key A B h]

/-- **The collision bound:** if every possible output list has length at most `q`, one fresh
uniform element of `T`, drawn after the list, lies in it with probability at most `q / |T|`.
A standard union-bound fact behind the bad events of [PS10, Thm 168.2]'s proof sketch; the
adaptive repeated-nonce event is a union of such steps.

**Proof sketch.** By total probability over the list, it suffices that a fixed list `L` of length
at most `q` is hit with probability `#{t ∈ L} / |T| ≤ q / |T|`; average over the possible lists
with `expect_mono_of_allOutputs`. -/
theorem prob_mem_le {T : Type} [Fintype T] [Nonempty T] [DecidableEq T] (c : ProbComp (List T))
    {q : ℕ} (hc : c.AllOutputs fun L => L.length ≤ q) :
    prob (c.bind fun L => (sample T).bind fun t => .pure (L, t)) (fun p => p.2 ∈ p.1) ≤
      q / Fintype.card T := by
  have hT : (0 : ℝ) < Fintype.card T := by exact_mod_cast Fintype.card_pos
  rw [prob_bind]
  calc expect c (fun L => prob ((sample T).bind fun t => .pure (L, t)) (fun p => p.2 ∈ p.1))
      ≤ expect c (fun _ => (q : ℝ) / Fintype.card T) := by
        refine expect_mono_of_allOutputs hc fun L hL => ?_
        rw [prob_bind, expect_sample]
        have hsum : ∑ t : T, prob (OracleComp.pure (L, t)) (fun p : List T × T => p.2 ∈ p.1) =
            (L.toFinset.card : ℝ) := by
          simp only [prob_pure, Finset.sum_boole]
          congr 2
          ext t
          simp
        rw [hsum, inv_mul_eq_div]
        refine div_le_div_of_nonneg_right ?_ hT.le
        exact_mod_cast (List.toFinset_card_le L).trans hL
    _ = q / Fintype.card T := expect_const c _

end ProbComp

/-- From a bad state, every possible final state of the simulation is bad, when the
implementation never leaves a bad state. -/
theorem simulate_allOutputs_bad {spec : OracleSpec ι} {impl : QueryImpl spec σ unifSpec}
    (bad : σ → Prop) (hstick : ∀ i x s, bad s → (impl i x s).AllOutputs fun ys => bad ys.2)
    (c : OracleComp spec α) {s : σ} (hs : bad s) :
    (simulate impl c s).AllOutputs fun r => bad r.2 := by
  induction c generalizing s with
  | pure a =>
    rw [simulate_pure, OracleComp.allOutputs_pure]
    exact hs
  | query i x k ih =>
    rw [simulate_query]
    exact OracleComp.AllOutputs.bind (hstick i x s hs) fun ys hys => ih ys.1 hys

/-- **Equal until bad, in expectation, for functions of the output and the final state.** Let two
implementations give, from every good state, the same law to good successors, and let each keep
bad states bad. Then from a good state, for every function `G` of the output and the final state,
`𝔼[G · 1_{good}]` is the same under both simulations:
`𝔼[fun r => if bad r.2 then 0 else G r] (simulate impl₀ c s) =
𝔼[fun r => if bad r.2 then 0 else G r] (simulate impl₁ c s)`.

**Proof sketch.** Induction on the computation. From a bad successor the continuation's value is
`0` on both sides (`simulate_allOutputs_bad`); from a good one the two values agree by induction;
so both expectations only see the values at good successors, which `hagree` equates. -/
theorem expect_eq_until_bad {spec : OracleSpec ι} {impl₀ impl₁ : QueryImpl spec σ unifSpec}
    (bad : σ → Prop) [DecidablePred bad]
    (hagree : ∀ i x s, ¬ bad s → ∀ g : spec.rng i × σ → ℝ,
      ProbComp.expect (impl₀ i x s) (fun ys => if bad ys.2 then 0 else g ys) =
        ProbComp.expect (impl₁ i x s) (fun ys => if bad ys.2 then 0 else g ys))
    (hstick₀ : ∀ i x s, bad s → (impl₀ i x s).AllOutputs fun ys => bad ys.2)
    (hstick₁ : ∀ i x s, bad s → (impl₁ i x s).AllOutputs fun ys => bad ys.2)
    (c : OracleComp spec α) (G : α × σ → ℝ) {s : σ} (hs : ¬ bad s) :
    ProbComp.expect (simulate impl₀ c s) (fun r => if bad r.2 then 0 else G r) =
      ProbComp.expect (simulate impl₁ c s) (fun r => if bad r.2 then 0 else G r) := by
  induction c generalizing s with
  | pure a => rw [simulate_pure, simulate_pure]
  | query i x k ih =>
    simp only [simulate_query, ProbComp.expect_bind]
    have hz : ∀ (impl : QueryImpl spec σ unifSpec),
        (∀ i x s, bad s → (impl i x s).AllOutputs fun ys => bad ys.2) →
        ∀ ys : spec.rng i × σ, bad ys.2 →
          ProbComp.expect (simulate impl (k ys.1) ys.2) (fun r => if bad r.2 then 0 else G r) =
            0 := by
      intro impl hst ys hb
      rw [ProbComp.expect_congr_of_allOutputs (simulate_allOutputs_bad bad hst _ hb)
        (g := fun _ => 0) fun r hr => if_pos hr, ProbComp.expect_const]
    have h0 : ∀ ys : spec.rng i × σ,
        ProbComp.expect (simulate impl₀ (k ys.1) ys.2) (fun r => if bad r.2 then 0 else G r) =
          if bad ys.2 then 0 else
            ProbComp.expect (simulate impl₁ (k ys.1) ys.2)
              (fun r => if bad r.2 then 0 else G r) := by
      intro ys
      by_cases hb : bad ys.2
      · rw [if_pos hb, hz impl₀ hstick₀ ys hb]
      · rw [if_neg hb, ih ys.1 hb]
    have h1 : ∀ ys : spec.rng i × σ,
        ProbComp.expect (simulate impl₁ (k ys.1) ys.2) (fun r => if bad r.2 then 0 else G r) =
          if bad ys.2 then 0 else
            ProbComp.expect (simulate impl₁ (k ys.1) ys.2)
              (fun r => if bad r.2 then 0 else G r) := by
      intro ys
      by_cases hb : bad ys.2
      · rw [if_pos hb, hz impl₁ hstick₁ ys hb]
      · rw [if_neg hb]
    rw [funext h0, hagree i x s hs, ← funext h1]

/-- **Equal until bad:** let two implementations give, from every good state, the same law to good
successors (they may differ arbitrarily on bad successors, including in the call that makes the
state bad), and let each keep bad states bad. Then, from a good state, the two simulations give
the same probability to "`Q` holds and the final state is good", and the same probability to "the
final state is bad".

**Proof sketch.** Both are expectations of functions that vanish on bad final states:
"`Q` and good" is `𝔼[if bad then 0 else 1_Q]`, and "bad" is `1 − 𝔼[if bad then 0 else 1]`
(`prob_not`). Both are equal under the two simulations by `expect_eq_until_bad`. -/
theorem prob_eq_until_bad {spec : OracleSpec ι} {impl₀ impl₁ : QueryImpl spec σ unifSpec}
    (bad : σ → Prop) [DecidablePred bad]
    (hagree : ∀ i x s, ¬ bad s → ∀ g : spec.rng i × σ → ℝ,
      ProbComp.expect (impl₀ i x s) (fun ys => if bad ys.2 then 0 else g ys) =
        ProbComp.expect (impl₁ i x s) (fun ys => if bad ys.2 then 0 else g ys))
    (hstick₀ : ∀ i x s, bad s → (impl₀ i x s).AllOutputs fun ys => bad ys.2)
    (hstick₁ : ∀ i x s, bad s → (impl₁ i x s).AllOutputs fun ys => bad ys.2)
    (c : OracleComp spec α) (Q : α → Prop) {s : σ} (hs : ¬ bad s) :
    ProbComp.prob (simulate impl₀ c s) (fun r => Q r.1 ∧ ¬ bad r.2) =
        ProbComp.prob (simulate impl₁ c s) (fun r => Q r.1 ∧ ¬ bad r.2) ∧
      ProbComp.prob (simulate impl₀ c s) (fun r => bad r.2) =
        ProbComp.prob (simulate impl₁ c s) (fun r => bad r.2) := by
  classical
  have hgood : ∀ c' : ProbComp (α × σ), ProbComp.prob c' (fun r => Q r.1 ∧ ¬ bad r.2) =
      ProbComp.expect c' (fun r => if bad r.2 then 0 else if Q r.1 then 1 else 0) := by
    intro c'
    rw [ProbComp.prob_eq_expect]
    congr 1
    funext r
    by_cases hb : bad r.2 <;> by_cases hq : Q r.1 <;> simp [hb, hq]
  have hbad : ∀ c' : ProbComp (α × σ), ProbComp.prob c' (fun r => bad r.2) =
      1 - ProbComp.expect c' (fun r => if bad r.2 then 0 else 1) := by
    intro c'
    have h := ProbComp.prob_not c' (fun r => bad r.2)
    have e : ProbComp.prob c' (fun r => ¬ bad r.2) =
        ProbComp.expect c' (fun r => if bad r.2 then 0 else 1) := by
      rw [ProbComp.prob_eq_expect]
      congr 1
      funext r
      by_cases hb : bad r.2 <;> simp [hb]
    linarith
  refine ⟨?_, ?_⟩
  · rw [hgood, hgood]
    exact expect_eq_until_bad bad hagree hstick₀ hstick₁ c _ hs
  · rw [hbad, hbad, expect_eq_until_bad bad hagree hstick₀ hstick₁ c (fun _ => 1) hs]

/-- **Identical until bad** (the code-based fundamental lemma): let two implementations of the
same oracles give, from every good state, the same law to good successors, and let each keep `bad`
once it holds (every possible new state of a bad state is bad). Then, from a good state, for any
computation `c` and event `p` on its output, the probabilities of `p` under the two simulations
differ by at most the probability that the first simulation ends in a bad state.
[BR06] (the fundamental lemma)

**Deviation:** [BR06] assumes the two games' code is syntactically identical up to `bad ← true`.
Here the hypothesis is semantic: from a good state the two implementations give the same law to
good successors, and may differ arbitrarily on bad ones, including in the call that raises the
flag. Stickiness is required; without it the bound fails.

**Proof sketch.**
1. *Sticky:* from a bad state, every possible final state of either simulation is bad
   (`simulate_allOutputs_bad`).
2. *Equal until bad:* `prob_eq_until_bad`.
3. Write each probability of `p` as "`p` and good" plus at most "bad", and conclude with the
   difference lemma's arithmetic. -/
theorem identical_until_bad {spec : OracleSpec ι}
    {impl₀ impl₁ : QueryImpl spec σ unifSpec} (bad : σ → Prop) [DecidablePred bad]
    (hagree : ∀ i x s, ¬ bad s → ∀ g : spec.rng i × σ → ℝ,
      ProbComp.expect (impl₀ i x s) (fun ys => if bad ys.2 then 0 else g ys) =
        ProbComp.expect (impl₁ i x s) (fun ys => if bad ys.2 then 0 else g ys))
    (hstick₀ : ∀ i x s, bad s → (impl₀ i x s).AllOutputs fun ys => bad ys.2)
    (hstick₁ : ∀ i x s, bad s → (impl₁ i x s).AllOutputs fun ys => bad ys.2)
    (c : OracleComp spec α) (p : α → Prop) {s : σ} (hs : ¬ bad s) :
    |ProbComp.prob (simulate impl₀ c s) (fun r => p r.1) -
        ProbComp.prob (simulate impl₁ c s) (fun r => p r.1)| ≤
      ProbComp.prob (simulate impl₀ c s) (fun r => bad r.2) := by
  obtain ⟨h1, h2⟩ := prob_eq_until_bad bad hagree hstick₀ hstick₁ c p hs
  rw [ProbComp.prob_split (simulate impl₀ c s) (fun r => p r.1) (fun r => bad r.2),
    ProbComp.prob_split (simulate impl₁ c s) (fun r => p r.1) (fun r => bad r.2), h1]
  have a0 := ProbComp.prob_nonneg (simulate impl₀ c s) (fun r => p r.1 ∧ bad r.2)
  have a1 := ProbComp.prob_nonneg (simulate impl₁ c s) (fun r => p r.1 ∧ bad r.2)
  have b0 := ProbComp.prob_mono (simulate impl₀ c s) (p := fun r => p r.1 ∧ bad r.2)
    (q := fun r => bad r.2) fun r h => h.2
  have b1 := ProbComp.prob_mono (simulate impl₁ c s) (p := fun r => p r.1 ∧ bad r.2)
    (q := fun r => bad r.2) fun r h => h.2
  rw [abs_le]
  constructor <;> linarith

/-- Equal implementations on good states give the same law to good successors: the hypothesis of
`identical_until_bad` in its syntactic form. -/
theorem hagree_of_eq {spec : OracleSpec ι} {impl₀ impl₁ : QueryImpl spec σ unifSpec}
    (bad : σ → Prop) [DecidablePred bad] (h : ∀ i x s, ¬ bad s → impl₀ i x s = impl₁ i x s) :
    ∀ i x s, ¬ bad s → ∀ g : spec.rng i × σ → ℝ,
      ProbComp.expect (impl₀ i x s) (fun ys => if bad ys.2 then 0 else g ys) =
        ProbComp.expect (impl₁ i x s) (fun ys => if bad ys.2 then 0 else g ys) :=
  fun i x s hs _ => by rw [h i x s hs]

/-- **Identical until bad, from a sampled initial state:** if every possible initial state is
good, the bound of `identical_until_bad` holds for the games that first sample the state.

**Proof sketch.** Total probability over the initial state, the pointwise bound at every possible
(good) initial state (`identical_until_bad`), and monotonicity and linearity of expectation. -/
theorem identical_until_bad_init {spec : OracleSpec ι}
    {impl₀ impl₁ : QueryImpl spec σ unifSpec} (bad : σ → Prop) [DecidablePred bad]
    (hagree : ∀ i x s, ¬ bad s → ∀ g : spec.rng i × σ → ℝ,
      ProbComp.expect (impl₀ i x s) (fun ys => if bad ys.2 then 0 else g ys) =
        ProbComp.expect (impl₁ i x s) (fun ys => if bad ys.2 then 0 else g ys))
    (hstick₀ : ∀ i x s, bad s → (impl₀ i x s).AllOutputs fun ys => bad ys.2)
    (hstick₁ : ∀ i x s, bad s → (impl₁ i x s).AllOutputs fun ys => bad ys.2)
    (c : OracleComp spec α) (p : α → Prop) (init : ProbComp σ)
    (hinit : init.AllOutputs fun s => ¬ bad s) :
    |ProbComp.prob (init.bind fun s => simulate impl₀ c s) (fun r => p r.1) -
        ProbComp.prob (init.bind fun s => simulate impl₁ c s) (fun r => p r.1)| ≤
      ProbComp.prob (init.bind fun s => simulate impl₀ c s) (fun r => bad r.2) := by
  rw [ProbComp.prob_bind, ProbComp.prob_bind, ProbComp.prob_bind]
  have key := fun s (hs : ¬ bad s) =>
    abs_le.1 (identical_until_bad bad hagree hstick₀ hstick₁ c p hs)
  have u := ProbComp.expect_mono_of_allOutputs hinit
    (f := fun s => ProbComp.prob (simulate impl₀ c s) (fun r => p r.1))
    (g := fun s => ProbComp.prob (simulate impl₁ c s) (fun r => p r.1) +
      ProbComp.prob (simulate impl₀ c s) (fun r => bad r.2))
    (fun s hs => by linarith [(key s hs).2])
  have v := ProbComp.expect_mono_of_allOutputs hinit
    (f := fun s => ProbComp.prob (simulate impl₁ c s) (fun r => p r.1))
    (g := fun s => ProbComp.prob (simulate impl₀ c s) (fun r => p r.1) +
      ProbComp.prob (simulate impl₀ c s) (fun r => bad r.2))
    (fun s hs => by linarith [(key s hs).1])
  rw [ProbComp.expect_add] at u v
  rw [abs_le]
  constructor <;> linarith

namespace ProbComp

/-! ### Simulation congruence and a bad-event potential -/

/-- **Implementations with the same laws simulate alike:** if every call of `impl₀` and `impl₁`
has the same expectation of every function `g` of the answer and the new state, the simulations
of every computation have the same expectation of every function `G` of the output and the final
state: `𝔼[G] (simulate impl₀ c s) = 𝔼[G] (simulate impl₁ c s)`.

**Proof sketch.** Induction on `c`; at a query, both sides are the expectation over the call of the
continuation's expectation (`simulate_query`, `expect_bind`), equal by induction and the
hypothesis. -/
theorem expect_simulate_congr {ι : Type} {spec : OracleSpec ι} {σ α : Type}
    (impl₀ impl₁ : QueryImpl spec σ unifSpec)
    (h : ∀ i x s (g : spec.rng i × σ → ℝ), expect (impl₀ i x s) g = expect (impl₁ i x s) g)
    (c : OracleComp spec α) (s : σ) (G : α × σ → ℝ) :
    expect (simulate impl₀ c s) G = expect (simulate impl₁ c s) G := by
  induction c generalizing s with
  | pure a => rw [simulate_pure, simulate_pure]
  | query i x k ih =>
    rw [simulate_query, simulate_query, expect_bind, expect_bind, h]
    exact congrArg _ (funext fun p => ih p.1 p.2)

/-- **A bad event raised a little at each query:** if from a good state each query raises `bad`
with probability at most `(sz s + 1) · δ` and grows the size `sz` by at most one, then from a good
state `s` a computation making at most `m` queries ends in a bad state with probability at most
`m · (sz s + m) · δ`: `Pr[bad (simulate impl c s).2] ≤ m · (sz s + m) · δ`.

**Proof sketch.** Induction on the computation. At a query, a bad successor contributes at most
its probability; a good successor `s'` has `sz s' ≤ sz s + 1` and, by induction, contributes at
most `(m - 1) · (sz s + m) · δ`. Add `(sz s + 1) · δ ≤ (sz s + m) · δ`. -/
theorem prob_bad_le {ι : Type} {spec : OracleSpec ι} {σ : Type} {impl : QueryImpl spec σ unifSpec}
    (bad : σ → Prop) [DecidablePred bad]
    (sz : σ → ℕ) {δ : ℝ} (hδ : 0 ≤ δ)
    (hstep : ∀ i x s, ¬ bad s → prob (impl i x s) (fun ys => bad ys.2) ≤ (sz s + 1) * δ)
    (hgrow : ∀ i x s, (impl i x s).AllOutputs fun ys => sz ys.2 ≤ sz s + 1)
    {α : Type} (c : OracleComp spec α) (m : ℕ) (hc : c.CostBoundedBy (fun _ => 1) m) (s : σ)
    (hs : ¬ bad s) :
    prob (simulate impl c s) (fun r => bad r.2) ≤ m * (sz s + m) * δ := by
  induction c generalizing m s with
  | pure a =>
    rw [simulate_pure, prob_pure, if_neg hs]
    exact mul_nonneg (by positivity) hδ
  | query i x k ih =>
    obtain ⟨hm, hk⟩ := (OracleComp.costBoundedBy_query _ _ _ _ _).1 hc
    have hm1 : 1 ≤ m := hm
    obtain ⟨m', rfl⟩ : ∃ m', m = m' + 1 := ⟨m - 1, by omega⟩
    have hk' : ∀ y, (k y).CostBoundedBy (fun _ => 1) m' := fun y => by
      simpa using hk y
    have hm0 : (0 : ℝ) ≤ m' := Nat.cast_nonneg m'
    set K : ℝ := m' * (sz s + (m' + 1)) * δ with hK
    have hK0 : 0 ≤ K := mul_nonneg (by positivity) hδ
    rw [simulate_query, prob_bind]
    calc expect (impl i x s) (fun ys => prob (simulate impl (k ys.1) ys.2) (fun r => bad r.2))
        ≤ expect (impl i x s) (fun ys => (if bad ys.2 then (1 : ℝ) else 0) + K) := by
          refine expect_mono_of_allOutputs (hgrow i x s) fun ys hys => ?_
          by_cases hb : bad ys.2
          · rw [if_pos hb]
            have h1 := prob_le_one (simulate impl (k ys.1) ys.2) (fun r => bad r.2)
            linarith
          · rw [if_neg hb, zero_add]
            refine (ih ys.1 m' (hk' ys.1) ys.2 hb).trans ?_
            have hys' : (sz ys.2 : ℝ) ≤ sz s + 1 := by exact_mod_cast hys
            exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (by linarith) hm0) hδ
      _ = prob (impl i x s) (fun ys => bad ys.2) + K := by
          rw [expect_add (impl i x s) (fun ys => if bad ys.2 then (1 : ℝ) else 0) (fun _ => K),
            expect_const, prob_eq_expect]
      _ ≤ ((m' + 1 : ℕ) : ℝ) * (sz s + ((m' + 1 : ℕ) : ℝ)) * δ := by
          have h3 := hstep i x s hs
          have h4 : ((sz s : ℝ) + 1) * δ ≤ (sz s + (m' + 1)) * δ :=
            mul_le_mul_of_nonneg_right (by linarith) hδ
          have e : ((m' : ℝ) + 1) * (sz s + (m' + 1)) * δ = K + (sz s + (m' + 1)) * δ := by
            rw [hK]; ring
          push_cast
          linarith

/-- **Hitting a list with a uniform sample:** a uniform element of `T` lies in a list `L` with
probability at most `|L| / |T|`: `𝔼_{t ← T} [t ∈ L] ≤ |L| / |T|` (`prob_mem_le` for a fixed
list). -/
theorem expect_sample_mem_le {T : Type} [Fintype T] [Nonempty T] [DecidableEq T] (L : List T) :
    expect (sample T) (fun t => if t ∈ L then (1 : ℝ) else 0) ≤ L.length / Fintype.card T := by
  have h := prob_mem_le (OracleComp.pure L : ProbComp (List T)) (q := L.length)
    (OracleComp.allOutputs_pure.2 le_rfl)
  rw [prob_bind, expect_pure, prob_bind] at h
  refine Eq.trans_le ?_ h
  refine congrArg _ (funext fun t => ?_)
  rw [prob_pure]

end ProbComp

/-! ### One-shot coins drawn in advance -/

section Eager

variable {spec : OracleSpec ι} {T : Type} [Fintype T] [Nonempty T]

/-- From a used state, an implementation that agrees with `O` there simulates like `O`. -/
private theorem simulate_eq_of_used (O O' : QueryImpl spec σ unifSpec) (used : σ → Prop)
    (hused : ∀ i x s, used s → O' i x s = O i x s)
    (hstick : ∀ i x s, used s → (O i x s).AllOutputs fun p => used p.2)
    (c : OracleComp spec α) {s : σ} (hs : used s) : simulate O' c s = simulate O c s := by
  induction c generalizing s with
  | pure a => rw [simulate_pure, simulate_pure]
  | query i x k ih =>
    rw [simulate_query, simulate_query, hused i x s hs]
    exact OracleComp.bind_congr_of_allOutputs (hstick i x s hs) fun p hp => ih p.1 hp

/-- **One-shot coins drawn in advance.** Let `O` be an implementation and `OE t` its variants with
coins `t ∈ T` fixed in advance, and let `used` mark the states after the coins are spent:
- from a used state, `OE t` is `O`, and `O` keeps the state used;
- from an unused state, a call either does not use the coins (`OE t` is `O` for every `t`, and the
  state stays unused), or it is the one that spends them (`O` samples `t` and runs `OE t`, and
  every successor is used).

Then from an unused state, `O`'s simulation has the law of `OE t`'s, averaged over `t`:
`𝔼[G(simulate O c s)] = 𝔼_{t ← T} 𝔼[G(simulate (OE t) c s)]`.

**Proof sketch.** Induction on `c`. From used states the two simulations coincide
(`simulate_eq_of_used`). At a query from an unused state: in the first case, rewrite the call,
apply the induction hypothesis at the (unused) successors and exchange the expectations
(`ProbComp.expect_expect_sample`); in the second, expand `O`'s sample and conclude from the
coincidence at the (used) successors. -/
theorem expect_simulate_eager (O : QueryImpl spec σ unifSpec) (OE : T → QueryImpl spec σ unifSpec)
    (used : σ → Prop) (hused : ∀ t i x s, used s → OE t i x s = O i x s)
    (hstick : ∀ i x s, used s → (O i x s).AllOutputs fun p => used p.2)
    (hfresh : ∀ i x s, ¬ used s →
      (∀ t, OE t i x s = O i x s ∧ (O i x s).AllOutputs fun p => ¬ used p.2) ∨
      (O i x s = (ProbComp.sample T).bind (fun t => OE t i x s) ∧
        ∀ t, (OE t i x s).AllOutputs fun p => used p.2))
    (c : OracleComp spec α) (G : α × σ → ℝ) {s : σ} (hs : ¬ used s) :
    ProbComp.expect (simulate O c s) G =
      ProbComp.expect (ProbComp.sample T) fun t => ProbComp.expect (simulate (OE t) c s) G := by
  induction c generalizing s with
  | pure a =>
    simp only [simulate_pure, ProbComp.expect_pure]
    exact (ProbComp.expect_const _ _).symm
  | query i x k ih =>
    simp only [simulate_query, ProbComp.expect_bind]
    rcases hfresh i x s hs with h | ⟨h, hu⟩
    · have hO : ∀ t, OE t i x s = O i x s := fun t => (h t).1
      have hun : (O i x s).AllOutputs fun p => ¬ used p.2 :=
        (h (Classical.arbitrary T)).2
      simp only [hO]
      rw [ProbComp.expect_congr_of_allOutputs hun fun p hp => ih p.1 hp,
        ProbComp.expect_expect_sample]
    · rw [h, ProbComp.expect_bind]
      refine congrArg _ (funext fun t => ?_)
      refine ProbComp.expect_congr_of_allOutputs (hu t) fun p hp => ?_
      rw [simulate_eq_of_used O (OE t) used (hused t) hstick _ hp]

end Eager

end TCSlib.Cryptography.Games
