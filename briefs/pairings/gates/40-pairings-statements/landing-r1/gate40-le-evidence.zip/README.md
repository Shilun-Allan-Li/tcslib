# LE-gate40: landing edit on PR #331 (pairing statements), Gate 40 answer and Rule 10 seal evidence

Maintainer job, 2026-11-16 UTC. `$SP` = `/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad`;
paths below are relative to this directory. Rules: python3 -I; Lean 4.25.0; no lake command; one Lean process at a time,
only on `$SP/dl-oleans` (assigned by the maintainer, exclusive; `dl-oleans-2` not touched); nothing pushed.

## Commits (worktree `$SP/wt-gate40`, branch `stmt/pairings`, on 110c2f9db810d243693b9a5e8976a5ad205f1bab)

- `3f9c49e573fe56ac72c33a3f960f4229a29a9a5e` "Pairing statements: LE-gate40 (encoding injectivity, doc fixes)" (SSH-signed).
- `70c1f44432a41bcdb6f6d8602d957d2fc68ce0da` "Pairing statements: LE-gate40, reduce the destructured key and ciphertext"
  (SSH-signed; the first build of `BonehBoyen` failed twice, `build/closure-attempt1/`; fix: `dsimp only at h`).
- Diff vs 110c2f9d: `checks/le-gate40.diff`, `checks/diffstat.txt` (5 files, +189/-28).

## Edits

- **G40-01** `Defs.lean`: `IBEScheme` gains `encPP_inj`, `encSK_inj`, `encCT_inj` (injectivity on reachable objects, nested
  `AllOutputs`); structure docstring Deviation and module docstring extended. `BonehBoyen.lean`: new section `Encodings` with
  `bb1_encPP_inj`, `bb1_encSK_inj`, `bb1_encCT_inj` (each with a `**Proof sketch.**`), the three `bb1Scheme` fields, docstrings.
  No downstream breakage (no other `IBEScheme` instance; Security/Machine compile unchanged).
- **G40-03/04** `BonehBoyenMachine.lean` (T4 docstring only), `Assumptions.lean` (T1 docstring only), `Group.lean` (module,
  `BilinearGroup` and `bilinear_pow` docstrings only). **G40-05** `BonehBoyen.lean`: `**Proof sketch.**` markers.

## Results

| Check | Result | Evidence |
|---|---|---|
| Statements | vs 110c2f9d: 3 ADDED (the BB1 lemmas), nothing CHANGED/REMOVED by `decls2.py`; T1–T4 and `bb1_sidSecure` unchanged; `IBEScheme` gains 3 fields (touched as CHANGED) | `statements/` |
| Build (`lean_check_tree.sh`, 20-module closure, 8 base + 12 pairing) | 20/20 rc 0, 0 `error:`, 0 `error(`; sorry warnings only T1 (Assumptions 1), T4 (Machine 1), T2/T3 (Security 2) | `build/closure/summary.txt`, `build/source-binding.txt` (20/20 sources = `git show 70c1f444`) |
| Root `TCSlib` | not rebuilt (approved: disk) | — |
| Axiom census | 384 constants (r2: 372; +12 new, 0 removed, 0 changed axiom sets); `sorryAx` only in T1–T4 and `bb1_sidSecure`; the new fields, lemmas and `bb1Scheme` standard only | `axioms/` |
| Strip-verify (doc-only files) | Group, Assumptions, BonehBoyenMachine: code-identical with `/--`/`/-!` comments stripped | `checks/strip-verify.txt` |
| Widths | no line > 100 in the 13 PR files; 9 added lines 96–98 | `checks/widths.txt` |
| Seals (term-collected, closure-complete, 10 owners × strict A/B, coe A/B) | 40/40 rc 0, 0 errors, install + EOF records | `rule10/seals-*.tsv`, `rule10/seal-runs/` |
| Paired controls (attempt 2) | strict 18 probes, coe 18 probes: ALL_OK True both (43 sealed negatives each fail exactly once; readers pass; unsealed all pass) | `rule10/ctlcheck-*.log`, `rule10/control-runs-r2/` |
| Explicit-unfold scan | 164 items: 116 THEOREM, 40 LOCAL_OR_UNRESOLVED (local hypotheses, dot-notation theorems/fields), 8 OWNED_DEFINITION (same-file `sidImpl`, `bb1SimKeyQ`, `bb1SimChal`), 0 foreign | `scan/` |
| Lint | 92 FAIL / 103 WARN vs tip 92 / 101: only the two pre-existing check-8 acronym false positives | `lint/` |
| Tree | restored: 8 backups back (hash-checked), 12 new oleans deleted, 4 dirs pruned; SNAPSHOT EQUAL `457ba704…a15f` | `tree/` |

Control attempt 1 (`rule10/controls-attempt1/`, runs in `rule10/seal-runs/`): every row behaved as designed except the
`sidImpl` row, whose restated equation needed `inLens`/`outLens` unfolded to typecheck under the seal (both theorems failed
twice); restated through `type_of% (S.sidImpl_init_none …)` in attempt 2 (`tools/review/mkctl_g40.py` header). The first
background run of `tools/rule10_g40.sh` was stopped by the 30-minute background limit after 41 of 76 seal/control probes; the
rest ran from `tools/rule10_resume_g40.sh` (same runner, appended records). The `jouxMsg` control row is not exercised: no
sealed owner other than Joux itself has `jouxMsg` in its request set.

Tools: `tools/` (the sc-compose/gate36 tool set, unmodified, plus `mkctl_g40.py`, `scan1_g40.py` (kinds probe imports the
scanned modules instead of root `TCSlib`), `doconly_g40.py`, `ladder_g40.sh`, `build_g40.sh`, `rule10_g40.sh`,
`rule10_resume_g40.sh`, `controls_r2_g40.sh`). Probe sources: `rule10/seals*/`, `rule10/controls*/`, `rule10/probe-sources/`;
the 79 probe files were removed from the worktree after use (`rule10/probe-files-in-worktree.txt`). `SHA256SUMS` lists every
other file here.
