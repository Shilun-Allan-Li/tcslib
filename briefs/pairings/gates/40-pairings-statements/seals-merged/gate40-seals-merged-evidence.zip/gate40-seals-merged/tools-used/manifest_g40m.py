r"""manifest_g40m.py <repo> <rev> <worktree> <evidence-dir> <out.json> <out.tsv>: (gate40-seals-merged) bind every probe of
the run to its bytes. For each seal record (rule10/seals{,-coe}/{A,B}/Seal*.json): the owner source path, the SHA-256 of
`git show <rev>:<path>` (must equal the record's source_sha256 and the export's file), the record's probe_sha256 (must equal
the stored copy <label>.lean.txt and the runner's source_sha256 for the probe module), the run log SHA-256 (must equal the
runner record), rc, and the error count in both forms (`^\S+\.lean:\d+:\d+: error:` and `... error(`), plus the raw line
counts of the substrings `error:` and `error(` (grep -c style), and the seal install/EOF records. Controls (controls-*/
controls-plan.json), the collector, the axioms probe and the scan kinds probe are bound the same way to their stored copies."""
import sys, os, re, json, glob, hashlib, subprocess
repo, rev, wt, E, outj, outt = sys.argv[1:7]
sha = lambda b: hashlib.sha256(b).hexdigest()
R = os.path.join(E, 'rule10')
def results(d):
    res = {}
    for l in open(os.path.join(d, 'results.jsonl')):
        x = json.loads(l)
        if 'module' in x: res[x['module']] = x
    return res
def logstats(d, m, label=None):
    lp = os.path.join(d, 'mods', m.replace('/', '_') + '.log'); b = open(lp, 'rb').read(); t = b.decode('utf-8', 'replace')
    o = dict(log_sha256=sha(b), err_colon=len(re.findall(r'^\S+\.lean:\d+:\d+: error:', t, re.M)),
             err_paren=len(re.findall(r'^\S+\.lean:\d+:\d+: error\(', t, re.M)),
             lines_with_error_colon=sum(1 for l in t.splitlines() if 'error:' in l),
             lines_with_error_paren=sum(1 for l in t.splitlines() if 'error(' in l))
    if label:
        o['install_record'] = ('G06-SEAL label=' + label) in t; o['eof_record'] = ('G06-SEAL-END label=' + label) in t
    return o
rows, bad = [], []
seal_res = results(os.path.join(R, 'seal-runs'))
for vd in ['seals/A', 'seals/B', 'seals-coe/A', 'seals-coe/B']:
    for p in sorted(glob.glob(os.path.join(R, vd, 'Seal*.json'))):
        r = json.load(open(p)); m = r['probe_module']
        src = subprocess.run(['git', '-C', repo, 'show', f"{rev}:{r['source']}"], capture_output=True, check=True).stdout
        exp = open(os.path.join(wt, r['source']), 'rb').read()
        stored = open(os.path.join(R, vd, r['label'] + '.lean.txt'), 'rb').read()
        rr = seal_res.get(m)
        o = dict(kind='seal', variant=vd.replace('seals-coe', 'coe').replace('seals', 'strict'), label=r['label'], module=r['module'],
                 probe_module=m, source=r['source'], rev=r['rev'], source_sha256=sha(src), probe_sha256=r['probe_sha256'],
                 requested=r['requested'], rc=rr['rc'] if rr else None, runner_errors=rr['errors'] if rr else None)
        checks = dict(record_source=r['source_sha256'] == sha(src), export_source=sha(exp) == sha(src), rev=r['rev'] == rev,
                      stored_probe=sha(stored) == r['probe_sha256'], runner_probe=bool(rr) and rr['source_sha256'] == r['probe_sha256'])
        if rr:
            o.update(logstats(os.path.join(R, 'seal-runs'), m, r['label'])); checks['runner_log'] = o['log_sha256'] == rr['log_sha256']
            checks['forms_sum'] = o['err_colon'] + o['err_paren'] == rr['errors']
        o['checks'] = checks
        if not all(checks.values()): bad.append((r['label'], vd, checks))
        rows.append(o)
for h in ['strict', 'coe']:
    cd = os.path.join(R, f'controls-{h}')
    for c in json.load(open(os.path.join(cd, 'controls-plan.json'))):
        m = c['module']; lab = m.split('/')[-1]
        f = os.path.join(cd, lab + '.lean.txt'); stored = open(f, 'rb').read() if os.path.exists(f) else None
        rr = seal_res.get(m)
        o = dict(kind='control', variant=h, label=lab, owner=c['owner'], sealed=c['sealed'], probe_module=m,
                 probe_sha256=sha(stored) if stored else None, rc=rr['rc'] if rr else None, runner_errors=rr['errors'] if rr else None)
        checks = dict(stored_probe=stored is not None, runner_probe=bool(rr) and stored is not None and rr['source_sha256'] == sha(stored))
        if rr:
            o.update(logstats(os.path.join(R, 'seal-runs'), m, c['label'] if c['sealed'] else None)); checks['runner_log'] = o['log_sha256'] == rr['log_sha256']
            checks['forms_sum'] = o['err_colon'] + o['err_paren'] == rr['errors']
        o['checks'] = checks
        if not all(checks.values()): bad.append((lab, h, checks))
        rows.append(o)
for d, m, f in [(os.path.join(R, 'probe-runs'), 'G40Probe/CollectHead', 'CollectHead.lean.txt'),
                (os.path.join(R, 'probe-runs'), 'G40Probe/AxiomsHead', 'AxiomsHead.lean.txt'),
                (os.path.join(E, 'scan', 'runs'), 'G40Probe/ScanKindsHead', 'ScanKindsHead.lean.txt')]:
    stored = open(os.path.join(R, 'probe-sources', f), 'rb').read(); rr = results(d).get(m)
    o = dict(kind='probe', label=m.split('/')[-1], probe_module=m, probe_sha256=sha(stored), rc=rr['rc'] if rr else None,
             runner_errors=rr['errors'] if rr else None)
    checks = dict(runner_probe=bool(rr) and rr['source_sha256'] == sha(stored))
    if rr: o.update(logstats(d, m)); checks['runner_log'] = o['log_sha256'] == rr['log_sha256']
    o['checks'] = checks
    if not all(checks.values()): bad.append((m, 'probe', checks))
    rows.append(o)
json.dump(dict(rev=rev, probes=rows, binding_failures=bad), open(outj, 'w'), indent=1)
with open(outt, 'w') as f:
    f.write('kind\tvariant\tlabel\tprobe_module\tsource\tsource_sha256\tprobe_sha256\tlog_sha256\trequested\trc\terr_colon\terr_paren\tinstall\teof\tbinding\n')
    for o in rows:
        f.write('\t'.join(str(o.get(k, '-')) for k in ('kind', 'variant', 'label', 'probe_module', 'source', 'source_sha256', 'probe_sha256',
                'log_sha256', 'requested', 'rc', 'err_colon', 'err_paren', 'install_record', 'eof_record')) + '\t' + ('OK' if all(o['checks'].values()) else 'FAIL') + '\n')
print(f"{len(rows)} probes bound; seals {sum(1 for o in rows if o['kind'] == 'seal')}, controls {sum(1 for o in rows if o['kind'] == 'control')}, probes {sum(1 for o in rows if o['kind'] == 'probe')}; binding failures {len(bad)} {bad[:3]}")
