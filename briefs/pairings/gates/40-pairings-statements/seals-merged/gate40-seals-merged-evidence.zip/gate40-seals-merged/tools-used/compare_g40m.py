r"""compare_g40m.py <old-evidence-dir> <new-evidence-dir> <outdir>: (gate40-seals-merged) LE-gate40 (70c1f444 closure) vs
this run (9e7a9648 merged closure). Per seal (strict/coe x A/B x 10 owners): requested old/new, the request rows added and
removed (by spelling, grouped by home module), term names / in-closure / excluded, stored constants, closure modules,
source SHA-256 equality, rc / error count / install / EOF / failing declarations from the sealsum tables. Per control
probe: ok, rc and the per-control error counts from ctlcheck2. Explicit-unfold scan: summary by class and the item-level
diff on (file, line, tactic, item, head, declaration, classification, resolved). Read-only on both inputs."""
import sys, os, json, glob, collections
old, new, outd = sys.argv[1:4]; os.makedirs(outd, exist_ok=True)
def tsv(p):
    d = {}
    for l in open(p):
        x = l.rstrip('\n').split('\t'); d[x[0]] = dict(requested=int(x[1]), rc=int(x[2]), errors=int(x[3]), install=int(x[4]), eof=int(x[5]), failing=x[6])
    return d
summ, det = [], []
for vd, tv in [('seals/A', 'seals-A.tsv'), ('seals/B', 'seals-B.tsv'), ('seals-coe/A', 'seals-coe-A.tsv'), ('seals-coe/B', 'seals-coe-B.tsv')]:
    to, tn = tsv(os.path.join(old, 'rule10', tv)), tsv(os.path.join(new, 'rule10', tv))
    var = vd.replace('seals-coe', 'coe').replace('seals', 'strict')
    for p in sorted(glob.glob(os.path.join(new, 'rule10', vd, 'Seal*.json'))):
        rn = json.load(open(p)); lab = rn['label']; ro = json.load(open(os.path.join(old, 'rule10', vd, lab + '.json')))
        so = {r['spelling']: r for r in ro['rows']}; sn = {r['spelling']: r for r in rn['rows']}
        add = sorted(set(sn) - set(so)); rem = sorted(set(so) - set(sn))
        chg = sorted(s for s in set(so) & set(sn) if so[s] != sn[s])
        xo, xn = to[lab], tn[lab]
        summ.append([var, lab, ro['requested'], rn['requested'], rn['requested'] - ro['requested'], len(add), len(rem), len(chg),
                     f"{ro['term_names']}/{rn['term_names']}", f"{len(ro['term_excluded'])}/{len(rn['term_excluded'])}",
                     f"{ro['stored_constants']}/{rn['stored_constants']}", f"{ro['closure_modules']}/{rn['closure_modules']}",
                     'same' if ro['source_sha256'] == rn['source_sha256'] else 'DIFFERS',
                     f"{xo['rc']}/{xn['rc']}", f"{xo['errors']}/{xn['errors']}", f"{xo['install']}{xo['eof']}/{xn['install']}{xn['eof']}",
                     f"{xo['failing'] or '-'}/{xn['failing'] or '-'}"])
        tr_o = {k: sorted(v) for k, v in ro['term_readers'].items()}; tr_n = {k: sorted(v) for k, v in rn['term_readers'].items()}
        det.append(dict(variant=var, label=lab, added_by_home=dict(collections.Counter(sn[s]['home'] for s in add)),
                        removed_by_home=dict(collections.Counter(so[s]['home'] for s in rem)), added=add, removed=rem, changed=chg,
                        term_readers_equal=tr_o == tr_n, term_excluded_old=ro['term_excluded'], term_excluded_new=rn['term_excluded'],
                        closure_modules_old=ro['closure_modules'], closure_modules_new=rn['closure_modules']))
H = ['variant', 'label', 'req_old', 'req_new', 'delta', 'rows_added', 'rows_removed', 'rows_changed', 'terms o/n', 'term_excluded o/n',
     'stored o/n', 'closure o/n', 'source', 'rc o/n', 'errors o/n', 'install+eof o/n', 'failing o/n']
with open(os.path.join(outd, 'seals-vs-le-gate40.tsv'), 'w') as f:
    f.write('\t'.join(H) + '\n'); [f.write('\t'.join(map(str, r)) + '\n') for r in summ]
json.dump(det, open(os.path.join(outd, 'seal-rows-vs-le-gate40.json'), 'w'), indent=1)
lines = []
for h in ['strict', 'coe']:
    co = {p['label']: p for p in json.load(open(os.path.join(old, 'rule10', f'ctlcheck-{h}.json')))['probes']}
    jn = json.load(open(os.path.join(new, 'rule10', f'ctlcheck-{h}.json')))
    lines.append(f"controls {h}: all_ok old {json.load(open(os.path.join(old, 'rule10', f'ctlcheck-{h}.json')))['all_ok']} new {jn['all_ok']}; probes old {len(co)} new {len(jn['probes'])}")
    newlabs = {p['label'] for p in jn['probes']}
    spare = {l[:len('ControlS_A_')]: l for l in co if l not in newlabs}  # old labels not regenerated (chooser moved)
    for p in jn['probes']:
        o = co.get(p['label'])
        if o is None and p['label'][:len('ControlS_A_')] in spare:
            o = co[spare[p['label'][:len('ControlS_A_')]]]
            lines.append(f"  PAIRED new {p['label']} with old {o['label']} (covering-subset chooser: fewest requests containing the row targets)")
        e = lambda q: [(c['control'], c['errors'], c['expected']) for c in q['controls']]
        same = o is not None and e(o) == e(p) and o['rc'] == p['rc'] and o['ok'] == p['ok']
        lines.append(f"  {'SAME' if same else 'DIFF'} {p['label']} ok {o['ok'] if o else '-'}/{p['ok']} rc {o['rc'] if o else '-'}/{p['rc']} req {o['requested'] if o else '-'}/{p['requested']} {e(p)}" + ('' if same else f" OLD {e(o) if o else None}"))
so = json.load(open(os.path.join(old, 'scan', 'explicit-head.json'))); sn = json.load(open(os.path.join(new, 'scan', 'explicit-head.json')))
key = lambda o: (o['file'], o['line'], o['tactic'], o['item'], o['head'], o['declaration'], o['classification'], o['resolved'])
ko, kn = collections.Counter(map(key, so['items'])), collections.Counter(map(key, sn['items']))
lines.append(f"scan: items old {so['summary']['items']} new {sn['summary']['items']}; by_class old {so['summary']['by_class']} new {sn['summary']['by_class']}; foreign old {so['summary']['foreign_items']} new {sn['summary']['foreign_items']}")
lines.append(f"scan item-level: only-old {sum((ko - kn).values())}, only-new {sum((kn - ko).values())}")
for k in sorted((ko - kn).elements()): lines.append(f'  ONLY-OLD {k}')
for k in sorted((kn - ko).elements()): lines.append(f'  ONLY-NEW {k}')
open(os.path.join(outd, 'controls-scan-vs-le-gate40.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join('\t'.join(map(str, r)) for r in [H] + summ)); print('\n'.join(lines))
