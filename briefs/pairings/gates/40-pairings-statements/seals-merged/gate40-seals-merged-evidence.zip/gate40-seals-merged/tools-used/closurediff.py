r"""closurediff.py <repo> <old-rev> <new-rev> <out.txt> <owner>...: (gate40-seals-merged) per owner, its transitive local
import closure (owner excluded, `^import\s+(\S+)` as fullorder.py) at both revs, and the closure modules whose source blob
differs, is new, or is gone. Read-only git (ls-tree/show)."""
import sys, re, subprocess
repo, old, new, out = sys.argv[1:5]; owners = sys.argv[5:]
def blobs(rev):
    t = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', rev, '--', 'TCSlib', 'audits'], capture_output=True, text=True, check=True).stdout
    return {l.split('\t')[1][:-5]: l.split()[2] for l in t.splitlines() if l.endswith('.lean')}
def closure(rev, B, m):
    seen, st = set(), [m]
    while st:
        x = st.pop()
        src = subprocess.run(['git', '-C', repo, 'cat-file', 'blob', B[x]], capture_output=True, text=True, check=True).stdout
        for i in re.findall(r'^import\s+(\S+)', src, re.M):
            if i.split('.')[0] in ('TCSlib', 'audits'):
                p = i.replace('.', '/')
                if p not in seen: seen.add(p); st.append(p)
    return seen
BO, BN = blobs(old), blobs(new)
with open(out, 'w') as f:
    for o in owners:
        co, cn = closure(old, BO, o), closure(new, BN, o)
        ch = sorted(m for m in co & cn if BO[m] != BN[m]); ad = sorted(cn - co); gone = sorted(co - cn)
        f.write(f'OWNER {o}: closure {len(co)} -> {len(cn)}; changed {len(ch)}; added {len(ad)}; removed {len(gone)}; owner blob {"same" if BO.get(o) == BN.get(o) else "DIFFERS"}\n')
        for m in ch: f.write(f'  CHANGED {m} {BO[m][:12]} -> {BN[m][:12]}\n')
        for m in ad: f.write(f'  ADDED {m}\n')
        for m in gone: f.write(f'  REMOVED {m}\n')
print(open(out).read())
