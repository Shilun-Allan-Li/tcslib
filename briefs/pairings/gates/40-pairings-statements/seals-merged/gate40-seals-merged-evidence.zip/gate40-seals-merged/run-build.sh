#!/usr/bin/env bash
# run-build.sh (gate40-seals-merged): build plan/queue.txt (41 modules of the 109-module head closure) on dl-oleans through
# scripts/lean_check_tree.sh (runner.py, stops on first failure). TMPDIR keeps lean_check_tree.sh's mktemp log inside $SP.
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/gate40-seals-merged
export TMPDIR=$SP/g40m-work/tmp
cd $E
echo "start $(date -u +%FT%TZ)"
python3 -I tools-used/review/runner.py $SP/wt-g40m plan/queue.txt $SP/dl-oleans build
echo "runner exit $? $(date -u +%FT%TZ)"
