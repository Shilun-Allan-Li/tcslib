#!/usr/bin/env bash
# finish-post-build.sh (int-331-tip): run after build/ completes with "runner exit 0". One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; EV=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-331-tip; P=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/ev-i331tip/int-stmt-331-333; H=39d42e235a62b7085ffc19b01f371015c20d7795; TIP=673a27158338437896c624df32bf5421c6ba45cf
T=$SP/dl-oleans; W=$SP/wt-i331tip; R=/home/user/tcslib; cd $EV
python3 -I tools-used/stateplan.py update $R $H state/state.json build/results.jsonl $T
python3 -I tools-used/stateplan.py check $R $H order/order.txt state/state.json $T state/statecheck.txt
python3 -I tools-used/permod.py build build/per-module.tsv checks/pr331-modules.txt
# incident re-check (disk-full 08:59:5x-09:00:2x): re-run the modules that ran in the window; oleans must reproduce
python3 -I tools-used/review/runner.py $W checks/incident-recheck-order.txt $T build-recheck
python3 -I tools-used/permod.py build-recheck build-recheck/per-module.tsv
mkdir -p records; cat $P/state/base-records-from-int-317.jsonl build/results.jsonl build-recheck/results.jsonl > records/records-final.jsonl
mkdir -p tree-final; python3 -I tools-used/treecheck_ml.py $T order/order.txt records/records-final.jsonl $R $H tree-final/snapshot-final.txt | tee tree-final/treecheck.out
# axioms probe (writes PlProbe/ olean into the tree; deleted by restore)
python3 -I tools-used/review/runner.py $W axioms/probe-order.txt $T axioms/probe-run
mkdir -p admissions
for x in tip:$TIP head:$H; do python3 -I tools-used/tipcensus.py $R ${x#*:} admissions/census-${x%%:*}.txt base=$P/state/base-records-from-int-317.jsonl intall=$P/state/int-all-open-records-final.jsonl int331333=$P/records/records-final.jsonl this=build/results.jsonl; done
