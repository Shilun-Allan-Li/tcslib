#!/usr/bin/env bash
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-331-tip
echo "start $(date -u +%FT%TZ)"
python3 -I tools-used/review/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/wt-i331tip plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans build
echo "runner exit $? $(date -u +%FT%TZ)"
