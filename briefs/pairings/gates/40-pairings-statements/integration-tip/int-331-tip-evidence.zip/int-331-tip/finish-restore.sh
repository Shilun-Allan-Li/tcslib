#!/usr/bin/env bash
# finish-restore.sh (int-331-tip): restore /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-oleans to the base snapshot 457ba704... after the build/probes.
# Make sure no Lean process of this job is running first (cat /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-331-tip/build/current.pid; ps).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; EV=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/dl-review/int-331-tip; T=$SP/dl-oleans; BK=$SP/dl-i331tip-backup
ln -sfn tools-used/review $EV/tools
bash $EV/tools-used/restore_derand.sh $T $BK $EV
rm $EV/tools
python3 -I $EV/tools-used/restoreplan.py $T $EV/tree/snapshot-pre.txt $EV/order/order.txt $EV/restore/restoreplan-check | tee $EV/restore/restoreplan-check.out
sha256sum $EV/tree/snapshot-pre.txt $EV/tree/snapshot-post.txt
# then, if SNAPSHOT EQUAL and restoreplan extra 0 / changed 0 / missing 0: rm -r $BK
