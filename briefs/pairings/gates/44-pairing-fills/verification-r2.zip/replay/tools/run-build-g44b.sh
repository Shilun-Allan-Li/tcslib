#!/usr/bin/env bash
# run-build-g44b.sh: Gate 44 round 2 replay, T44' = records tip 4f4a7592 x #340 916afc25 x (#346 + LE-g44 98cb0e52) (tree
# bee027f0) on $SP/olean-replay-g44b (cp -al of $SP/olean-replay-g44, the T44 replay output), plan/queue.txt (10 modules: the
# three LE-g44 files and their downstream), one Lean process at a time, through scripts/lean_check_tree.sh (runner.py, the
# snapshot recipe's, unmodified; as copied in $SP/g44/tools).
cd /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/wt
export PATH=$HOME/.elan/bin:$PATH TMPDIR=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/tmp
echo "start $(date -u +%FT%TZ)" > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/build/runner.start
df -m / | tail -1 > /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/build/df-launch.txt
python3 -I /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/tools/runner.py /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/wt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/plan/queue.txt /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/olean-replay-g44b /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/build
echo "runner exit $? $(date -u +%FT%TZ)" >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/build/runner.exit
df -m / | tail -1 >> /tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad/g44r2/run/build/runner.exit
