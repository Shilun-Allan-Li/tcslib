# Gate 44 round 2 · verification archive

`SHA256SUMS` lists every other entry. `$SP` is `/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad`,
and the job directory is `$SP/g44r2`. Pins:
- T44′ = `bee027f0903d531b3a43511cea16bfa123210291`, from the records tip `4f4a7592a54cf82fa04f96b83645d7936672614c`,
  #340 `916afc25c21f5e52b4b01958186ad55d2f615fd1` and #346 + LE-g44 `98cb0e521a94e94c304c78348fb5d3033435a3ed`;
- round 1's T44 = `33681cb8ed893a897ca2028d5ada70ca29237978`.

| Path | What | Provenance |
|---|---|---|
| `checks/series-r2.txt` | records pin, LE-g44 commit and signature (with tamper control), #346's new diff | `checks/tools/chk44r2.py`, git objects only |
| `checks/le-r2.txt` | LE-g44 comment-only: stripped texts byte-identical, three mutation controls per file, widths | same |
| `checks/mergetrees-r2.txt` | T44′ in three merge orders; T44′ vs tip (9 files, blob-equal to the heads); T44 vs T44′ (3 files) | same |
| `checks/headers-r2.txt` | blob equality T44 = T44′ for T1/T2/T3/T4/consumer files and the cited library file | same |
| `checks/sources-r2.txt` | tags of the three files, References keys, the Theorem 52.3 context check, the cited declarations | same |
| `checks/T44p.diff.txt` | `git diff` records tip → T44′ over the code paths (the 9 files) | same |
| `checks/g44-03-controls.txt` | G44-03 recount of round 1's `Assumptions` control logs (`$SP/g44/run/asm/rule10/`) | shell recount (`grep -c`), round 1's raw logs |
| `checks/tools/` | `chk44r2.py`, `gitlib.py` (round 1's), `commentstrip.py`, `mksrc44r2.py` | written for this round |
| `landing/mergetrees-r2.txt` | the scratch merge commits and trees (`git merge-tree --write-tree`) | maintainer job log |
| `replay/tree/`, `replay/order/`, `replay/plan/`, `replay/state/` | the `cp -al` copy of `$SP/olean-replay-g44`, the T44′ export, downorder/fullorder (vs T44), the plan (10 build / 1417 reuse) on a copy of round 1's state (`copied.sha256`), the state update | round 1's tools, unmodified (`replay/tools/tools-*.sha256`) |
| `replay/build/` | `results.jsonl`, `per-module.tsv`, `permod.out`, the 10 module logs, `statecheck*` (1427 RESULT OK) | `run-build-g44b.sh` → `runner.py` → `scripts/lean_check_tree.sh` |
| `replay/checks/` | link counts and the olean comparison with round 1's T44 oleans; snapshot #4 rehash before, after and final (0/0/0); round 1's map rechecks; the deletion record of `$SP/olean-replay-g44` | `snapmap.py`, `mapnoml.py`, `stat`, `cmp` |
| `replay/output-map/` | the map of `$SP/olean-replay-g44b` without Mathlib (`fca1b6a3…`) and its comparison | `mapnoml.py` |
| `replay/admissions/` | `tipcensus.py` at T44 and T44′ (196 each, per-module identical) and the record sets | round 1's tool |
| `replay/axioms/` | `Axioms44.lean` (round 1's probe), its run record and log, `axsum.txt` | `runner_full.py` |
| `replay/lint/` | `campaign_style_lint.py --check8b` at T44′, non-INFO comparison with round 1's T44 run, INFO diff, `style_lint.py` and `sk15` on the three files | `scripts/` at T44′ |
| `rule10/statements/` | `touched.py`, records tip → T44′, over the 9 files | round 1's harness |
| `rule10/collector/` | the collector over #346's eight owners: probe source, run record, log (byte-identical to round 1's) | `rule10_g44b.sh collect` |
| `rule10/seal/` | coe-A seal records, probe sources, run records and logs for `Draws`, `Words`, `Handler`, `BonehBoyenMachine`; `seals-coe-A.tsv`; `error-forms-seal-runs.txt`; `sealcarry.txt` (comparison with round 1's records) | `rule10_g44b.sh coeA`, `sealcarry.py` |
| `records/` | `findings-r1.md`, `resolutions-r1.md`, `dispatch-r1.md`, `SHA256SUMS-r1`; the plan's Gate 44 rows, ledger rows DL-55/DL-56 and § Stage 2 at the pin; `corrections/` the two REPORTs and the review as filed in the staging commit, with `corrections.diff` against the pin | records branch |
| `pr/pr-rest-fields-r2.json` | #340 and #346 REST fields and bodies at staging (05:58 UTC) | `gh api` |
