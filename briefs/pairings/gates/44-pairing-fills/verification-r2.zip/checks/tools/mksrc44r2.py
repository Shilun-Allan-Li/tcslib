"""mksrc44r2.py <repo> <outdir> (Gate 44 round 2, maintainer; no Lean): source-head-r2.json and sources-r2.zip from git objects.
source-head-r2.json: the pins, and for each of the 9 files of the two PRs at T44' its status against the records tip, PR, blob,
SHA-256, line count, line count at T44, max width (characters) and over-100 count, and whether it changed since round 1.
sources-r2.zip: the three LE-g44 files at LE-g44 and at its parent 89a18a82; `Candidates/DiscreteLog.lean` at T44' (the cited
library construction); the [PS10] section 2.8 lines (Theorem 52.3) as in round 1. The source closure is round 1's
(`sources-r1.zip`, T44-33681cb8/): T44' differs from T44 only in the three LE-g44 files. README.md lists origins and SHA-256."""
import sys, os, json, zipfile, hashlib, subprocess
repo, out = sys.argv[1:3]
TIP = '4f4a7592a54cf82fa04f96b83645d7936672614c'; H340 = '916afc25c21f5e52b4b01958186ad55d2f615fd1'
H346 = '89a18a8225be1b76166af12a15179da291747783'; LE = '98cb0e521a94e94c304c78348fb5d3033435a3ed'
T44 = '33681cb8ed893a897ca2028d5ada70ca29237978'; T44P = 'bee027f0903d531b3a43511cea16bfa123210291'
PIN = sys.argv[3] if len(sys.argv) > 3 else TIP
ASM = 'TCSlib/Cryptography/Pairing/Assumptions.lean'; BBM = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine/'
DL = 'TCSlib/Cryptography/Candidates/DiscreteLog.lean'
LEF = [BBM + 'Draws.lean', BBM + 'Words.lean', BBM + 'Handler.lean']
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout
show = lambda r, p: git('show', f'{r}:{p}')
sha = lambda b: hashlib.sha256(b).hexdigest()
files = {}
for l in git('diff', '--name-status', TIP, T44P, '--', 'TCSlib').decode().split('\n'):
    if not l: continue
    st, p = l.split('\t'); b = show(T44P, p); t = b.decode().split('\n'); t0 = show(T44, p).decode()
    files[p] = dict(status=st, pr=340 if p == ASM else 346, blob=git('rev-parse', f'{T44P}:{p}').decode().strip(), sha256=sha(b),
                    lines=b.count(b'\n'), lines_at_T44=t0.count('\n'), max_width=max(map(len, t)), over_100=sum(len(x) > 100 for x in t),
                    changed_since_round_1=sha(b) != sha(t0.encode()))
j = dict(T44p_tree=T44P, T44_tree_round_1=T44, records_tip=TIP, records_pin=PIN, pr340_head=H340, pr346_head=LE,
         pr346_head_round_1=H346, le_g44=LE, pr346_merge_base='7291f6b237fec75add1549c0992c174442180488',
         pr340_merge_base='9e7a96481785d6cac4dea3b2e990c49ac278b060', files=files)
open(os.path.join(out, 'source-head-r2.json'), 'w').write(json.dumps(j, indent=1, sort_keys=True) + '\n')
ents = []
for p in LEF:
    ents.append((f'pr346-head-98cb0e52/{p}', show(LE, p), f'{LE}:{p}'))
    ents.append((f'pr346-round1-89a18a82/{p}', show(H346, p), f'{H346}:{p}'))
ents.append((f'T44p-bee027f0/{DL}', show(T44P, DL), f'{T44P}:{DL}'))
src = show(TIP, 'blueprint/src/references/pass-shelat-2010-ch2.raw.md').decode().split('\n')
ents.append(('references/pass-shelat-2010-ch2.raw.lines1338-1420.md', ('\n'.join(src[1337:1420]) + '\n').encode(),
             f'{TIP}:blueprint/src/references/pass-shelat-2010-ch2.raw.md lines 1338-1420 (section 2.8, Theorem 52.3)'))
readme = ['# Gate 44 round 2 source bundle', '', 'Every entry is read from git objects; SHA-256 of the bytes and the origin `rev:path`.', '',
          f'- `pr346-head-98cb0e52/`, `pr346-round1-89a18a82/`: the three files LE-g44 changes, at LE-g44 (= T44\'s blobs) and at its parent.',
          f'- `T44p-bee027f0/`: `Candidates/DiscreteLog.lean`, home of `sampleBelowL` (line 578) and `statClose_sampleBelowL` (line 618), which LE-g44 cites; the same blob at T44, at 89a18a82 and at the records tip.',
          '- `references/`: [PS10] section 2.8 (Theorem 52.3), the lines round 1 bundled.',
          '- The source closure is round 1\'s `sources-r1.zip` (`T44-33681cb8/`); T44\' differs from T44 only in the three LE-g44 files.', '',
          '| Entry | SHA-256 | Origin |', '|---|---|---|']
readme += [f'| `{n}` | `{sha(b)}` | `{o}` |' for n, b, o in ents]
with zipfile.ZipFile(os.path.join(out, 'sources-r2.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in [('README.md', ('\n'.join(readme) + '\n').encode())] + [(n, b) for n, b, _ in ents]:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
        z.writestr(zi, b)
print(len(ents) + 1, 'entries;', sum(v['changed_since_round_1'] for v in files.values()), 'files changed since round 1')
