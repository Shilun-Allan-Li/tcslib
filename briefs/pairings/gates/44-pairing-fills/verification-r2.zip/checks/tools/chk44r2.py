"""chk44r2.py <repo> <outdir> (Gate 44 round 2 pack re-checks, maintainer; no Lean): pins, the LE-g44 commit and its SSH
signature, the LE-g44 diff and its comment-strip identity (with controls), the new #346 diff, the merge trees T44', the
T44 -> T44' code delta, the frozen headers, and the source tags and library citations of the changed files, from git
objects only. T44 and T44' live in scratch object directories: run with GIT_OBJECT_DIRECTORY=<objs> and
GIT_ALTERNATE_OBJECT_DIRECTORIES=<repo>/.git/objects:<round-1 objs>. ssh_sig is round 1's (chk44.py), unmodified."""
import sys, os, re, base64, hashlib, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo
from commentstrip import strip
repo, out = sys.argv[1:3]; os.makedirs(out, exist_ok=True)
R = Repo(repo)
TIP = '4f4a7592a54cf82fa04f96b83645d7936672614c'; TIP1 = '1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821'
PIN1 = '8f888790b7e40f9e0529967e29a05a72c5ee8ba3'
H340 = '916afc25c21f5e52b4b01958186ad55d2f615fd1'; H346 = '89a18a8225be1b76166af12a15179da291747783'
LE = '98cb0e521a94e94c304c78348fb5d3033435a3ed'; MB346 = '7291f6b237fec75add1549c0992c174442180488'
T44 = '33681cb8ed893a897ca2028d5ada70ca29237978'; T44P = 'bee027f0903d531b3a43511cea16bfa123210291'
CODE = ['TCSlib', 'TCSlib.lean', 'audits', 'scripts', 'lakefile.lean', 'lake-manifest.json', 'lean-toolchain']
IB = 'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/'; BBM = IB + 'BonehBoyenMachine/'
ASM = 'TCSlib/Cryptography/Pairing/Assumptions.lean'; DL = 'TCSlib/Cryptography/Candidates/DiscreteLog.lean'
LEF = [BBM + 'Draws.lean', BBM + 'Words.lean', BBM + 'Handler.lean']
sha = lambda b: hashlib.sha256(b).hexdigest()

def ssh_sig(commit, tamper=False):
    raw = R.gitb('cat-file', 'commit', commit)
    if tamper: raw = raw.replace(b'\ncommitter ', b'\ncommitter  ', 1)
    lines = raw.split(b'\n'); sig, rest, i = [], [], 0
    while i < len(lines):
        l = lines[i]
        if l == b'': rest.extend(lines[i:]); break
        if l.startswith(b'gpgsig '):
            sig.append(l[7:]); i += 1
            while i < len(lines) and lines[i].startswith(b' '): sig.append(lines[i][1:]); i += 1
            continue
        rest.append(l); i += 1
    if not sig: return dict(n=0)
    payload = b'\n'.join(rest)
    blob = base64.b64decode(''.join(x for x in b'\n'.join(sig).decode().splitlines() if not x.startswith('-----')))
    def rd(b, k):
        n = int.from_bytes(b[k:k + 4], 'big'); return b[k + 4:k + 4 + n], k + 4 + n
    assert blob[:6] == b'SSHSIG'
    k = 10
    pub, k = rd(blob, k); ns, k = rd(blob, k); _, k = rd(blob, k); halg, k = rd(blob, k); sigblob, k = rd(blob, k)
    fp = 'SHA256:' + base64.b64encode(hashlib.sha256(pub).digest()).decode().rstrip('=')
    ktype, kk = rd(pub, 0); st, kk2 = rd(sigblob, 0); sigraw, _ = rd(sigblob, kk2)
    h = hashlib.sha512(payload).digest() if halg == b'sha512' else hashlib.sha256(payload).digest()
    s = lambda x: len(x).to_bytes(4, 'big') + x
    signed = b'SSHSIG' + s(ns) + s(b'') + s(halg) + s(h); ok = None
    if ktype == b'ssh-ed25519':
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            keyraw, _ = rd(pub, kk); Ed25519PublicKey.from_public_bytes(keyraw).verify(sigraw, signed); ok = True
        except ImportError: ok = None
        except Exception: ok = False
    return dict(n=sum(1 for l in lines if l.startswith(b'gpgsig ')), fp=fp, ns=ns.decode(), ktype=ktype.decode(), ok=ok)

def cinfo(c):
    f = R.git('show', '-s', '--format=%H%x00%P%x00%an <%ae>%x00%aI%x00%cn <%ce>%x00%cI%x00%s', c).stdout
    return dict(zip(['hash', 'parents', 'author', 'adate', 'committer', 'cdate', 'subject'], f.rstrip('\n').split('\x00')))

def W(name, lines):
    open(os.path.join(out, name), 'w').write('\n'.join(lines) + '\n')

def blobsha(rev, p):
    b = R.blob(rev, p); return sha(b) if b is not None else None

# ---- series ----
L = []
tipsig = ssh_sig(TIP)
L.append(f'records tip {TIP}: {cinfo(TIP)["subject"]}')
L.append(f'  signature: gpgsig {tipsig.get("n")}, {tipsig.get("ktype")} {tipsig.get("fp")}, ns={tipsig.get("ns")}, verified {tipsig.get("ok")}')
L.append(f'  descends from round 1\'s pin {PIN1[:8]}: {R.git("merge-base", "--is-ancestor", PIN1, TIP, check=False).returncode == 0}; '
         f'from the replay tip {TIP1[:8]}: {R.git("merge-base", "--is-ancestor", TIP1, TIP, check=False).returncode == 0}')
L.append(f'  code paths changed {TIP1[:8]}..tip: {len(R.git("diff", "--name-only", TIP1, TIP, "--", *CODE).stdout.split())}; '
         f'records commits {TIP1[:8]}..tip: {len(R.git("rev-list", f"{TIP1}..{TIP}").stdout.split())}')
for h in R.git('rev-list', '--reverse', f'{PIN1}..{TIP}').stdout.split():
    L.append(f'    {h[:12]} {cinfo(h)["subject"]}')
i = cinfo(LE); s = ssh_sig(LE)
L.append('')
L.append(f'LE-g44 {LE}: parents {i["parents"]} (= #346 round-1 head {H346[:8]}: {i["parents"] == H346})')
L.append(f'  author {i["author"]} {i["adate"]}; committer {i["committer"]}; gpgsig {s.get("n")} {s.get("ktype","")} {s.get("fp","")} '
         f'ns={s.get("ns","")} verified={s.get("ok")}; same key as the records tip: {s.get("fp") == tipsig.get("fp")}')
L.append(f'  subject: {i["subject"]}')
msg = R.git('show', '-s', '--format=%B', LE).stdout.rstrip('\n').split('\n')
L.append(f'  message ends with the two required trailer lines (Co-Authored-By, Claude-Session): '
         f'{msg[-2].startswith("Co-Authored-By: ") and msg[-1].startswith("Claude-Session: https://claude.ai/code/session_")}')
for f in R.git('show', '--format=', '--numstat', LE).stdout.strip().split('\n'): L.append(f'    {f}')
L.append(f'  signature control: LE-g44 with one byte added to its committer line verifies: {ssh_sig(LE, tamper=True).get("ok")} (expected False)')
L.append(f'  remote #346 branch land/pairings-bb1-machine at staging: {H346} (LE-g44 not pushed; the maintainer pushes it)')
mb = R.git('merge-base', TIP, LE).stdout.strip()
cs = R.git('rev-list', '--reverse', f'{mb}..{LE}').stdout.split()
L.append(f'#346 new head {LE[:8]}: merge base with the tip {mb} (= round 1\'s {MB346[:8]}: {mb == MB346}); commits {len(cs)}; '
         f'merges {sum(1 for c in cs if len(cinfo(c)["parents"].split()) > 1)}')
d3 = R.git('diff', f'{TIP}...{LE}').stdout; d2 = R.git('diff', f'{mb}..{LE}').stdout
L.append(f'  git diff {mb[:8]}..{LE[:8]} = git diff tip...head (three-dot, GitHub view) byte for byte: {d2 == d3}; '
         f'{len(d2.encode())} bytes, sha256 {sha(d2.encode())}')
L.append('  ' + R.git('diff', '--shortstat', f'{mb}..{LE}').stdout.strip())
open(os.path.join(out, 'pr346-r2.diff.txt'), 'w').write(d2)
dl = R.git('diff', f'{H346}..{LE}').stdout
open(os.path.join(out, 'le-g44.diff.txt'), 'w').write(dl)
L.append(f'  le-g44.diff.txt = git diff {H346[:8]}..{LE[:8]}: {len(dl.encode())} bytes, sha256 {sha(dl.encode())}; '
         + R.git('diff', '--shortstat', f'{H346}..{LE}').stdout.strip())
W('series-r2.txt', L)

# ---- LE-g44: comments only ----
L = ['LE-g44 is comment-only: every comment removed (line comments, nested block comments incl. /-- and /-!, string',
     'literals honoured; commentstrip.py), each file at the parent 89a18a82 and at LE-g44 98cb0e52 is byte-identical.', '']
okall = True
for p in LEF:
    a = R.blob(H346, p).decode(); b = R.blob(LE, p).decode()
    sa, ca = strip(a); sb, cb = strip(b); eq = sa == sb; okall &= eq
    L.append(f'{p}')
    L.append(f'  blob {R.rp(f"{H346}:{p}")[:12]} -> {R.rp(f"{LE}:{p}")[:12]}; lines {a.count(chr(10))} -> {b.count(chr(10))}; '
             f'max width (characters) {max(map(len, a.split(chr(10))))} -> {max(map(len, b.split(chr(10))))}; '
             f'tabs {b.count(chr(9))}; trailing spaces {sum(l != l.rstrip() for l in b.split(chr(10)))}')
    L.append(f'  stripped sha256 {sha(sa.encode())} -> {sha(sb.encode())}; comment characters {ca} -> {cb}; CODE-EQUAL {eq}')
    k = sb.find(':=')
    for name, mut in (('a space after the first `:=` of the code', sb[:k] + ':= ' + sb[k + 2:]),
                      ('one code line duplicated', sb.replace('\n', '\n' + sb.split('\n')[-2] + '\n', 1)),
                      ('`theorem` -> `lemma` at the first theorem', sb.replace('theorem ', 'lemma ', 1))):
        caught = mut != sa; okall &= caught
        L.append(f'  control ({name}): {"caught" if caught else "NOT CAUGHT"}')
    # every changed line is inside a comment: the hunks' old/new line sets differ only in comment text
    hun = R.git('diff', '-U0', H346, LE, '--', p).stdout
    L.append(f'  hunks: {len(re.findall(r"^@@", hun, re.M))}; '
             f'+{len(re.findall(r"^[+](?![+][+])", hun, re.M))} / -{len(re.findall(r"^-(?!--)", hun, re.M))} lines')
L.append(f'other paths changed by LE-g44: {sorted(set(R.git("diff", "--name-only", H346, LE).stdout.split()) - set(LEF))}')
L.append(f'RESULT {"OK" if okall else "FAIL"}')
W('le-r2.txt', L)

# ---- merge trees ----
L = []
def mt(a, b):
    r = R.git('merge-tree', '--write-tree', a, b, check=False); return r.stdout.split('\n')[0], r.returncode
t1, r1 = mt(TIP, H340); t2, r2 = mt(TIP, LE)
L.append(f'tip x #340: tree {t1} rc {r1}; tip x #346 (LE-g44 head): tree {t2} rc {r2}')
L.append(f"T44' = (tip x #340) x #346' = (tip x #346') x #340 = (tip x #340) x (tip x #346'): {T44P} "
         f'(scratch commits; all three orders give this tree, landing/mergetrees-r2.txt)')
dl = R.git('diff', '--name-status', TIP, T44P, '--', *CODE).stdout.strip().split('\n')
L.append(f"T44' vs tip, code paths: {len(dl)}; all paths: {len(R.git('diff', '--name-only', TIP, T44P).stdout.split())}")
for x in dl:
    st, p = x.split('\t'); hp = H340 if p == ASM else LE
    L.append(f"  {st} {p}: T44' blob {R.rp(f'{T44P}:{p}')[:12]} = {hp[:8]} blob: {R.rp(f'{T44P}:{p}') == R.rp(f'{hp}:{p}')}")
dd = R.git('diff', '--name-status', T44, T44P, '--', *CODE).stdout.strip().split('\n')
L.append(f"T44 (round 1) vs T44', code paths: {len(dd)} {dd}")
L.append(f"T44 vs T44', non-code paths: records only ({len(R.git('diff', '--name-only', T44, T44P).stdout.split()) - len(dd)} paths, "
         f"all under briefs/ or the plan files: {all(p.startswith('briefs/') or p.endswith('Plan.md') for p in set(R.git('diff', '--name-only', T44, T44P).stdout.split()) - set(x.split(chr(9))[1] for x in dd))})")
for p in LEF:
    sa, _ = strip(R.blob(T44, p).decode()); sb, _ = strip(R.blob(T44P, p).decode())
    L.append(f"  {p}: T44 -> T44' CODE-EQUAL after comment stripping {sa == sb}")
dT = R.git('diff', TIP, T44P, '--', *CODE).stdout
open(os.path.join(out, 'T44p.diff.txt'), 'w').write(dT)
L.append(f"T44p.diff.txt = git diff tip T44' over code paths: {len(dT.encode())} bytes, sha256 {sha(dT.encode())}")
dTT = R.git('diff', T44, T44P, '--', *CODE).stdout
L.append(f"git diff T44 T44' over code paths = le-g44.diff.txt byte for byte: {dTT == R.git('diff', H346, LE).stdout}")
W('mergetrees-r2.txt', L)

# ---- frozen headers (blob level) and unchanged files ----
L = []
for p in [ASM, IB + 'BonehBoyenMachine.lean', IB + 'BonehBoyenSecurity.lean', IB + 'Defs.lean', IB + 'BonehBoyen.lean',
          BBM + 'Reduction.lean', BBM + 'Oracles.lean', DL, 'TCSlib.lean']:
    L.append(f"{p}: T44 = T44' blob {R.rp(f'{T44}:{p}') == R.rp(f'{T44P}:{p}')}")
L.append('T1, T4, T2, T3 and bb1_sidSecure live in the first three files, so their headers, statement prose and bodies are '
         'byte-identical to round 1.')
W('headers-r2.txt', L)

# ---- source tags and the library citation ----
TAG = re.compile(r'\[((?:[A-Z][A-Za-z]*\d\d[a-z]?)(?:, [A-Z][A-Za-z]*\d\d[a-z]?)*)(?:, ([^\]]*))?\]')
L = ['source tags [KEY..., locator] per LE-g44 file at 89a18a82 and at LE-g44; NEW / GONE = pairs added / removed']
for p in LEF:
    def tags(rev):
        t = R.blob(rev, p).decode(); return [(m.group(1), (m.group(2) or '').strip()) for m in TAG.finditer(t)]
    a, b = tags(H346), tags(LE)
    refs = re.search(r'## References\n(.*?)(?:\n-/|\n## )', R.blob(LE, p).decode(), re.S)
    keys = sorted(set(re.findall(r'^\* \[([A-Za-z]+\d\d[a-z]?)\]', refs.group(1), re.M))) if refs else []
    used = sorted(set(k for kk, _ in b for k in kk.split(', ')))
    L.append(f'{p}: tags {len(a)} -> {len(b)}; keys used {used}; ## References entries {keys}; used keys without an entry: '
             f'{sorted(set(used) - set(keys))}')
    for k, loc in sorted(set(b) - set(a)): L.append(f'  NEW  [{k}{", " + loc if loc else ""}]')
    for k, loc in sorted(set(a) - set(b)): L.append(f'  GONE [{k}{", " + loc if loc else ""}]')
    t = R.blob(LE, p).decode()
    L.append(f'  "Theorem 52.3" occurrences {R.blob(H346, p).decode().count("Theorem 52.3")} -> {t.count("Theorem 52.3")}; '
             f'each now marked context: {all("ontext" in t[max(0, m.start() - 160):m.end() + 160] for m in re.finditer("Theorem 52.3", t))}')
    L.append(f'  names `Candidates.sampleBelowL` {t.count("Candidates.sampleBelowL")}, `Candidates.statClose_sampleBelowL` '
             f'{t.count("Candidates.statClose_sampleBelowL")}, `Cryptography/Candidates/DiscreteLog.lean` '
             f'{t.count("Cryptography/Candidates/DiscreteLog.lean")}')
L.append('')
src = R.blob(T44P, DL).decode().split('\n')
ns = [l for l in src if l.startswith('namespace ')]
L.append(f"{DL} at T44' (blob {R.rp(f'{T44P}:{DL}')[:12]}, = 89a18a82's and the tip's: "
         f"{R.rp(f'{T44P}:{DL}') == R.rp(f'{H346}:{DL}') == R.rp(f'{TIP}:{DL}')}); namespaces {ns}")
for name in ('def sampleBelowL', 'theorem statClose_sampleBelowL'):
    k = next(j for j, l in enumerate(src) if l.startswith(name))
    s0 = k
    while not src[s0].startswith('/--'): s0 -= 1
    e = k
    while ':=' not in src[e]: e += 1
    L.append(f'  {name.split()[1]} at line {k + 1} (docstring from line {s0 + 1}); header:')
    L += ['    ' + x for x in src[k:e + 1]]
W('sources-r2.txt', L)
print('ok')
