"""commentstrip.py <repo> <revA> <revB> <path>...: for each Lean file, remove every comment
(line comments `--` to end of line, and block comments `/- ... -/` with nesting, which covers `/--`
doc comments and `/-!` module docs), honouring string literals, and compare the stripped texts of
<revA>:<path> and <revB>:<path> byte for byte. Prints per file the SHA-256 of both stripped texts,
the comment character counts and EQUAL/DIFFER; exit 1 on any DIFFER.
Controls: `--control` additionally mutates one code character of each revB file and requires DIFFER."""
import sys, subprocess, hashlib

def strip(s):
    out = []; i = 0; n = len(s); depth = 0; com = 0
    while i < n:
        if depth:
            if s.startswith('/-', i): depth += 1; i += 2; com += 2; continue
            if s.startswith('-/', i): depth -= 1; i += 2; com += 2; continue
            i += 1; com += 1; continue
        c = s[i]
        if c == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1; continue
        if s.startswith('/-', i): depth = 1; i += 2; com += 2; continue
        if s.startswith('--', i):
            j = s.find('\n', i)
            j = n if j < 0 else j
            com += j - i; i = j; continue
        out.append(c); i += 1
    assert depth == 0, 'unterminated block comment'
    return ''.join(out), com

def show(repo, rev, path):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], check=True,
                          capture_output=True).stdout.decode('utf-8')

def main():
    args = sys.argv[1:]
    control = '--control' in args
    args = [a for a in args if a != '--control']
    repo, a, b, paths = args[0], args[1], args[2], args[3:]
    bad = 0
    for p in paths:
        sa, ca = strip(show(repo, a, p)); sb, cb = strip(show(repo, b, p))
        ha = hashlib.sha256(sa.encode()).hexdigest(); hb = hashlib.sha256(sb.encode()).hexdigest()
        eq = sa == sb
        bad += not eq
        print(f'{p}\tstripped {a[:8]} {ha}\tstripped {b[:8]} {hb}\tcomment-chars {ca}->{cb}\t'
              + ('EQUAL' if eq else 'DIFFER'))
        if control:
            k = sb.find(':=')
            mut = sb[:k] + ':= ' + sb[k + 2:]
            print(f'  control (one space added after the first `:=` of the code): '
                  + ('DIFFER (caught)' if mut != sa else 'EQUAL (NOT CAUGHT)'))
            bad += mut == sa
    print('RESULT', 'OK' if bad == 0 else 'FAIL')
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
