#!/usr/bin/env bash
# rule10_g44b.sh <phase...> (Gate 44 round 2, maintainer): Lean checks on T44' = records tip 4f4a7592 x #340 916afc25 x
# (#346 + LE-g44 98cb0e52) (tree bee027f0) after its replay on $SP/olean-replay-g44b. Composed from round 1's rule10_g44.sh
# (phases statements and own), restricted to what LE-g44 (comments only) needs: the canonical coe-A seal on the three changed
# owners (BBM/Draws, BBM/Words, BBM/Handler) and on IB/BonehBoyenMachine. The seal harness (tools/seal) is round 1's,
# unmodified. Phases:
#   statements  touched.py, records tip vs T44', over the 9 files of the two PRs
#   collect     collector over #346's 8 owners (as round 1's phase own)
#   coeA        mkseals_coe.py (seal A, coe exclusion) for the 4 owners, run through runner_full.py, sealsum.py
# Every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing is written to the olean tree). One Lean process at a time.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/g44r2; W=$G/wt; E=$G/run/seal; TREE=$SP/olean-replay-g44b; T=$G/tools/seal; A=$T/review/archived-gate10-tools
H=bee027f0903d531b3a43511cea16bfa123210291; TIP=4f4a7592a54cf82fa04f96b83645d7936672614c
export GIT_DIR=/home/user/tcslib/.git GIT_OBJECT_DIRECTORY=$G/objs GIT_ALTERNATE_OBJECT_DIRECTORIES=/home/user/tcslib/.git/objects:$SP/g44/objs
export TMPDIR=$G/run/tmp PATH=$HOME/.elan/bin:$PATH
PX=TCSlib.Cryptography.AdvancedEncryption.IdentityBased
OWN8="$PX.Defs $PX.BonehBoyen $PX.BonehBoyenMachine.Draws $PX.BonehBoyenMachine.Words $PX.BonehBoyenMachine.Handler $PX.BonehBoyenMachine.Reduction $PX.BonehBoyenMachine.Oracles $PX.BonehBoyenMachine"
OWN4="$PX.BonehBoyenMachine.Draws $PX.BonehBoyenMachine.Words $PX.BonehBoyenMachine.Handler $PX.BonehBoyenMachine"
FILES=$(git diff --name-only 1d1a9bb3aa4d5d28c7c9a2343cb322a39da07821 33681cb8ed893a897ca2028d5ada70ca29237978 -- 'TCSlib/*.lean')
P=G44Y; R=$E/rule10
mkdir -p $E/statements $R/order $R/probe-sources $W/$P
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) tree $H"
case $ph in
statements)
  echo $FILES > $E/statements/files.txt
  python3 -I $T/review/touched.py /home/user/tcslib $TIP $H $E/statements/touched-after.json $FILES > $E/statements/touched-after.tsv 2>&1; echo "touched rc=$?";;
collect)
  printf '%s\n' $OWN8 > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-machine phase 2 collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${P}_CollectHead.log
  (cd $T && python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/seals-coe/A $P/C SealA_ $OWN4 > $R/mkseals-coe-A.log)
  (cd $W && ls $P/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
  python3 -I $T/runner_full.py $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1 || true
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $E/statements/touched-after.json $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
