"""sealcarry.py <round-1 own/rule10 dir> <round-2 seal dir> <repo> <T44> <T44'> <out> (Gate 44 round 2, maintainer): for the
four owners re-sealed coe A at T44' (BBM/Draws, BBM/Words, BBM/Handler, IB/BonehBoyenMachine), compare the round-2 seal
record with round 1's coe-A record of the same owner (Draws: round 1's request-set record under rel/, not run in round 1;
the other three: round 1's run records). Checked per owner:
  - the request rows, the term readers, the excluded terms and the counts are identical;
  - the harness insertions are identical in kind, size and SHA-256 (only their offsets move with the source);
  - removing the insertions from each probe gives the owner's source at its tree (T44 for round 1, T44' for round 2)
    byte for byte;
  - the two probes are identical after comment stripping (commentstrip.py), so the seal elaborates the same code.
Needs GIT_OBJECT_DIRECTORY / GIT_ALTERNATE_OBJECT_DIRECTORIES reaching both trees."""
import sys, os, json, hashlib, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from commentstrip import strip
r1, r2, repo, t1, t2, out = sys.argv[1:7]
sha = lambda b: hashlib.sha256(b).hexdigest()
P = 'SealA_Cryptography_AdvancedEncryption_IdentityBased_BonehBoyenMachine'
OWN = [(P + '_Draws', 'rel/seals-coe/A'), (P + '_Words', 'seals-coe/A'), (P + '_Handler', 'seals-coe/A'), (P, 'seals-coe/A')]
def recover(probe, rec):
    b = probe
    for ins in sorted(rec['insertions'], key=lambda x: -x['probe_byte_offset']):
        seg = b[ins['probe_byte_offset']:ins['probe_byte_offset'] + ins['byte_count']]
        assert sha(seg) == ins['sha256'], ins['kind']
        b = b[:ins['probe_byte_offset']] + b[ins['probe_byte_offset'] + ins['byte_count']:]
    return b
L = []; ok = True
for lab, sub in OWN:
    a = json.load(open(os.path.join(r1, sub, lab + '.json'))); b = json.load(open(os.path.join(r2, 'seals-coe/A', lab + '.json')))
    pa = open(os.path.join(r1, sub, lab + '.lean.txt'), 'rb').read(); pb = open(os.path.join(r2, 'seals-coe/A', lab + '.lean.txt'), 'rb').read()
    src = lambda t, p: subprocess.run(['git', '-C', repo, 'show', f'{t}:{p}'], capture_output=True, check=True).stdout
    sa, sb = src(t1, a['source']), src(t2, b['source'])
    ins = lambda r: [(x['kind'], x['byte_count'], x['sha256']) for x in r['insertions']]
    checks = {
        'rows identical': a['rows'] == b['rows'],
        'requested equal': a['requested'] == b['requested'],
        'term readers identical': a['term_readers'] == b['term_readers'],
        'excluded terms identical': a['term_excluded'] == b['term_excluded'],
        'insertions identical (kind, size, sha256)': ins(a) == ins(b),
        'round-1 probe minus insertions = T44 source': recover(pa, a) == sa,
        "round-2 probe minus insertions = T44' source": recover(pb, b) == sb,
        'record probe_sha256 = probe file (both)': sha(pa) == a['probe_sha256'] and sha(pb) == b['probe_sha256'],
        'record source_sha256 = tree blob (both)': sha(sa) == a['source_sha256'] and sha(sb) == b['source_sha256'],
        'probes identical after comment stripping': strip(pa.decode())[0] == strip(pb.decode())[0],
    }
    ok &= all(checks.values())
    L.append(f'{lab}: requests {a["requested"]} -> {b["requested"]}; probe {a["probe_sha256"][:16]} -> {b["probe_sha256"][:16]}; '
             f'source {a["source_sha256"][:16]} -> {b["source_sha256"][:16]}; round-1 record {sub}')
    L += [f'  {k}: {v}' for k, v in checks.items()]
L.append(f'RESULT {"OK" if ok else "FAIL"}')
open(out, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))
