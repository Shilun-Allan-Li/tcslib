# Stage 2 plan r1 extract (DW-11 rows and Q5): briefs/pass-shelat-ch5-8/cleanup-stage2/plan-r1.md at b31b77f7f4127d9c6c6c0d6a1390de0dc8d71d43, lines 296-302, 364, 399-403 (verbatim)

W6 retirement can be split out (W6-GI alone is about 700 lines) as a predecessor job on the same files.

### 2.3 Waves and merge order

1. **Wave 0.**
   - DW-11's gate is dispatched now (Q5).
   - J0 is in-house, on the tip after the snapshot-#7 adoption.
| **DW-11** (combined small gate: #351, #352) | #351 `Games/Probability.lean` (`ProbComp.abs_expect_sub_le_expect`), `Games/Relational.lean`; #352 `Pairing/Group.lean` | J0 adds `mul_prob_le_expect` to `Games/Probability.lean` and re-points `Pairing/Assumptions` (DL-55). J4 re-points the ETT averaging copy onto #351's lemma | DW-11 must clear before J0 merges and before J4 is issued (a DW-11 landing edit to `Games/Probability` would otherwise race J0 or J4). Recommended: fold J0 into DW-11 as its third member (Q5a). |
- **Q5. DW-11 timing.**
  - **(a) Recommended:** dispatch DW-11 now and add J0 to it as a third small member. J0 touches #351's file
    (`Games/Probability`) and is additive. J0 merges when DW-11 clears, and J4 is issued after that.
  - (b) Dispatch DW-11 now, separately; J0 gets its own small gate.
  - (c) DW-11 after Stage 2. Not recommended: J0 and J4 edit #351's file, and J4 re-points onto #351's lemma.
