# Olean snapshot register extract: briefs/pass-shelat-ch5-8/maintainer/snapshots.md at b31b77f7f4127d9c6c6c0d6a1390de0dc8d71d43, lines 16-26 (verbatim)

## Entries

| # | T (records commit) | Map SHA-256 | Modules (files) | Date (UTC) | Status |
|---|---|---|---|---|---|
| 0 | `eff2dcd0a63f0c371118a17c67b9a5dfc046f4e9` (old base) | none: snapshot manifest `457ba704d26757307f14131aa534929ffd70d30a732b0c744b104ca3fc96a15f` | 1199 (1230) | before 2026-11-16 | retired; manifest kept as `$SP/dl-oleans-2.snapshot-457ba704….txt` |
| 1 | `cd6070091380f2270568af850e3dda1081ca802e` | `73fac35ee25818653bdee00cf1a4d3b521ec1bdf4be4682109091502b7b57f84` | 1353 (1384) | 2026-11-16 23:42 | superseded; oleans deleted at adoption of #2; map and manifest kept |
| 2 | `a6d01b1bd1a92e2ac0be9999689467fea7e4e77b` (merge of #341) | `954934494925e1c32d2fca23fe3250e5ae838f63b57a71ff0ad54c7ff039c111` | 1421 (1452) | 2026-11-17 00:21 | superseded; oleans deleted at adoption of #3; map and manifest kept |
| 3 | `cf7d28f7159b46033e8b8ae170954f9575e5d145` (merge of #351) | `e9dfbfddfd6ca253f9fd5ee6c3efe868f8614083794312c89d32032564fea53d` | 1422 (1453) | 2026-11-17 03:02 | superseded; oleans deleted at adoption of #4; map and manifest kept; evidence `olean-snapshot-3-adopt/` |
| 4 | `463f224414ab7615e54104be353bfcda9dfceda7` (merge of #352) | `6607620d725049c90b34a51a2ab891f1520fd0f576aaf3f9d51301222cee41e7` | 1422 (1453) | 2026-11-17 | superseded; oleans deleted at adoption of #5; evidence `olean-snapshot-4-adopt/` |
| 5 | `3f540c22360c869069a0fba684e23ce6f3cb20db` (merges of #340, #346) | `fca1b6a308ac1585fb5897fae95e8294b54be55e160119e4eca1702692b41ef9` | 1427 (1458) | 2026-11-17 | superseded; oleans deleted at adoption of #6; map and manifest kept; evidence `olean-snapshot-5-adopt/` |
| 6 | `8060f6b767da9e43d1c1f6d32c55b97758b80bd8` (merge of #357) | `0858dccbee016da1da450f2b2ca0d1f5094ee42646b9496d5278f2b45cb07caf` | 1432 (1463) | 2026-11-17 | **current**; evidence `olean-snapshot-6-adopt/` |
