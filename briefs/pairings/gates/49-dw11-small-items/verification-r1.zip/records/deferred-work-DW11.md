# Deferred-work extract (header and DW-11): briefs/pass-shelat-ch5-8/deferred-work.md at b31b77f7f4127d9c6c6c0d6a1390de0dc8d71d43, lines 7-8, 19 (verbatim)

| # | Item | Ruled | Source | Scope and starting point | Status |
|---|---|---|---|---|---|
| DW-11 | **Combined small-items gate** | Seyoon, 2026-11-17 | #351 and #352 (bb1-sim Games statements and group helpers) were merged on the maintainer review ("merge now, audit later") | One gate, later, auditing #351, #352 and any other similarly small merged changes together, instead of separate gates. #351 and #352 leave the bb1-sim gate (Q8), which keeps the reader insertions and the T2/T3 fill. Add further small items here as they arise. | Open (collecting: #351, #352) |
