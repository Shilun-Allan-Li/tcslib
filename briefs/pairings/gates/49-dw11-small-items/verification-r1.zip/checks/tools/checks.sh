#!/bin/bash
# Gate 49 staging: git-object checks (no Lean). Usage: checks.sh <repo> <outdir> <records-tip>
set -u
R=$1; O=$2; TIP=$3
cd "$R"
L=( -- '*.lean' lean-toolchain lake-manifest.json lakefile.lean )
{
echo "# series.txt: commits, parents, trees, signatures (git objects; read-only)"
echo "records tip at staging (before this pack): $TIP"
for c in 176cfd4a42ac3300d9b84f9045f7abcd0f52ef13 02000ad432b9d88e45ee109d3290c4be816a05b8 dfacac356ff1225aca4c900d81bbf2cabce7b499 cf7d28f7159b46033e8b8ae170954f9575e5d145 2cca41bc4f4828c18c26cce7da7ca718cc00c2ac 92dea4f8126747ea7e816984349b9dbb789f0065 463f224414ab7615e54104be353bfcda9dfceda7 5aed99076d2bd4e5d6f831aed88739fc3ce475b6 6fc5f49456507dab5901045356ea40acf42bdd67 5eaddd171bceccee917929e7f319ff9202994c59; do
  echo; echo "== $(git rev-parse $c)"
  git cat-file -p $c | sed -n '/^gpgsig/q;p' | grep -E '^(tree|parent|author|committer) '
  if git cat-file -p $c | grep -q '^gpgsig '; then
    if git cat-file -p $c | grep -q 'BEGIN SSH SIGNATURE'; then echo "gpgsig: SSH"; else echo "gpgsig: PGP"; fi
  else echo "gpgsig: none"; fi
  echo "subject: $(git log -1 --format=%s $c)"
  git diff-tree --no-commit-id --numstat -r --root -m --first-parent $c
done
echo
echo "== ancestry"
echo "merge-base(dfacac35, 92dea4f8) = $(git merge-base dfacac35 92dea4f8)"
echo "merge-base(4bc5bac4, dfacac35) = $(git merge-base 4bc5bac4 dfacac35)  (REST base.sha of #351/#352 is 4bc5bac4)"
echo "#351 commits on 176cfd4a: $(git rev-list --count 176cfd4a..dfacac35); #352: $(git rev-list --count 176cfd4a..92dea4f8); #365 on 5aed9907: $(git rev-list --count 5aed9907..5eaddd17)"
for a in cf7d28f7 463f2244 5aed9907; do echo "is $a ancestor of tip $TIP: $(git merge-base --is-ancestor $a $TIP && echo yes || echo no)"; done
} > "$O/series.txt"

{
echo "# lean-equality.txt: merge commits against the replayed trees (paths: *.lean lean-toolchain lake-manifest.json lakefile.lean)"
echo "## #351 merge cf7d28f7 vs phase-2 R1 prospective tree c6d3bed3 (adopted as snapshot #3):"
git diff --name-only cf7d28f7 c6d3bed311a83f217428576b08065b5743003ec1 "${L[@]}"; echo "(end; empty = equal)"
echo "## #351 merge cf7d28f7 vs PR head dfacac35:"
git diff --name-only cf7d28f7 dfacac35 "${L[@]}"; echo "(end)"
echo "## #352 merge 463f2244 vs phase-2b REV 3029d8c3 (adopted as snapshot #4):"
git diff --name-only 463f2244 3029d8c36c00fd3a4ce27e864a2b43b46309d27f "${L[@]}"; echo "(end; empty = equal)"
echo "## #352 merge 463f2244 vs cf7d28f7 (should be Group.lean only):"
git diff --stat cf7d28f7 463f2244 "${L[@]}"; echo "(end)"
echo "## #351 first-parent diff equals the PR view (176cfd4a..dfacac35)? (compare patch bodies without index lines)"
cmp <(git diff cf7d28f7^1 cf7d28f7 | grep -v '^index ') <(git diff 176cfd4a dfacac35 | grep -v '^index ') && echo "EQUAL" || echo "DIFFERENT"
cmp <(git diff cf7d28f7^1 cf7d28f7) <(git diff 176cfd4a dfacac35) && echo "EQUAL incl. index lines" || echo "index lines differ"
echo "## #352 first-parent diff equals the PR view (176cfd4a..92dea4f8)?"
cmp <(git diff 463f2244^1 463f2244 | grep -v '^index ') <(git diff 176cfd4a 92dea4f8 | grep -v '^index ') && echo "EQUAL" || echo "DIFFERENT"
cmp <(git diff 463f2244^1 463f2244) <(git diff 176cfd4a 92dea4f8) && echo "EQUAL incl. index lines" || echo "index lines differ"
echo "## base Lean of #365 (5aed9907) vs the tip $TIP:"
git diff --name-only 5aed9907 $TIP "${L[@]}"; echo "(end; empty = records-only since the base)"
echo "## changes to the audited files from the merges to the tip (out of scope; shown for context):"
git diff --stat 463f2244 $TIP -- TCSlib/Cryptography/Games.lean TCSlib/Cryptography/Games/Probability.lean TCSlib/Cryptography/Games/Relational.lean TCSlib/Cryptography/Pairing/Group.lean
git log --format='%h %s' 463f2244..$TIP -- TCSlib/Cryptography/Games.lean TCSlib/Cryptography/Games/Probability.lean TCSlib/Cryptography/Games/Relational.lean TCSlib/Cryptography/Pairing/Group.lean
} > "$O/lean-equality.txt"

{
echo "# mergetrees.txt: git merge-tree --write-tree (git $(git --version | awk '{print $3}'))"
for other in $TIP; do
 t=$(git merge-tree --write-tree $other 5eaddd17); rc=$?
 echo "#365 head 5eaddd17 x $other: rc=$rc tree=$(echo "$t" | head -1)"
 echo "  diff tip..merged (all paths):"; git diff --stat $other $(echo "$t"|head -1) | sed 's/^/    /'
 echo "  merged vs head over Lean paths:"; git diff --name-only $(echo "$t"|head -1) 5eaddd17 "${L[@]}" | sed 's/^/    /'; echo "    (end; empty = Lean-equal to the head)"
done
} > "$O/mergetrees.txt"

{
echo "# pr365-proof-only.txt: every line #365 removes, and the added lines (git diff 5aed9907 5eaddd17)"
echo "## removed lines:"; git diff -U0 5aed9907 5eaddd17 | grep '^-' | grep -v '^---'
echo "## added lines:"; git diff -U0 5aed9907 5eaddd17 | grep '^+' | grep -v '^+++'
echo "## hunks:"; git diff -U0 5aed9907 5eaddd17 | grep '^@@'
} > "$O/pr365-lines.txt"
