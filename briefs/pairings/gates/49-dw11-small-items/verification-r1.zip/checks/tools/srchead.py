"""Gate 49 staging: source-head-r1.json (pins, commits, per-file hashes, line counts and widths). Usage: srchead.py <repo> <tip> <out>"""
import hashlib, json, subprocess, sys
R, TIP, OUT = sys.argv[1:4]
def g(*a):
    return subprocess.run(['git', '-C', R, *a], check=True, capture_output=True).stdout
def blob(rev, p):
    try:
        return g('show', f'{rev}:{p}')
    except subprocess.CalledProcessError:
        return None
def stats(b):
    if b is None:
        return None
    t = b.decode('utf-8'); L = t.split('\n')
    if L and L[-1] == '': L = L[:-1]
    return {'sha256': hashlib.sha256(b).hexdigest(), 'lines': len(L), 'max_width': max((len(x) for x in L), default=0),
            'over_100': sum(len(x) > 100 for x in L), 'tabs': sum('\t' in x for x in L),
            'trailing_space': sum(x != x.rstrip(' ') for x in L)}
def commit(c):
    raw = g('cat-file', '-p', c).decode()
    hdr = raw.split('\n\n', 1)[0]
    parents = [l.split()[1] for l in hdr.split('\n') if l.startswith('parent ')]
    files = g('diff-tree', '--no-commit-id', '--name-only', '-r', '-m', '--first-parent', c).decode().split()
    return {'commit': g('rev-parse', c).decode().strip(), 'parents': parents,
            'tree': [l.split()[1] for l in hdr.split('\n') if l.startswith('tree ')][0],
            'author': g('log', '-1', '--format=%an <%ae> %aI', c).decode().strip(),
            'committer_date': g('log', '-1', '--format=%cI', c).decode().strip(),
            'signature': ('SSH' if 'BEGIN SSH SIGNATURE' in raw else 'PGP' if 'BEGIN PGP SIGNATURE' in raw else 'none'),
            'subject': g('log', '-1', '--format=%s', c).decode().strip(), 'files': files}
C = 'TCSlib/Cryptography/'
prs = {
 '351': {'state': 'merged', 'merge_base': '176cfd4a42ac3300d9b84f9045f7abcd0f52ef13', 'head': 'dfacac356ff1225aca4c900d81bbf2cabce7b499',
         'merge': 'cf7d28f7159b46033e8b8ae170954f9575e5d145', 'commits': ['02000ad432b9d88e45ee109d3290c4be816a05b8', 'dfacac356ff1225aca4c900d81bbf2cabce7b499'],
         'files': [C + 'Games.lean', C + 'Games/Probability.lean', C + 'Games/Relational.lean'],
         'replayed_tree': 'c6d3bed311a83f217428576b08065b5743003ec1', 'snapshot': '#3 (map e9dfbfddfd6ca253f9fd5ee6c3efe868f8614083794312c89d32032564fea53d)'},
 '352': {'state': 'merged', 'merge_base': '176cfd4a42ac3300d9b84f9045f7abcd0f52ef13', 'head': '92dea4f8126747ea7e816984349b9dbb789f0065',
         'merge': '463f224414ab7615e54104be353bfcda9dfceda7', 'commits': ['2cca41bc4f4828c18c26cce7da7ca718cc00c2ac', '92dea4f8126747ea7e816984349b9dbb789f0065'],
         'files': [C + 'Pairing/Group.lean'],
         'replayed_tree': '3029d8c36c00fd3a4ce27e864a2b43b46309d27f', 'snapshot': '#4 (map 6607620d725049c90b34a51a2ab891f1520fd0f576aaf3f9d51301222cee41e7)'},
 '365': {'state': 'open (draft)', 'merge_base': '5aed99076d2bd4e5d6f831aed88739fc3ce475b6', 'head': '5eaddd171bceccee917929e7f319ff9202994c59',
         'merge': None, 'commits': ['6fc5f49456507dab5901045356ea40acf42bdd67', '5eaddd171bceccee917929e7f319ff9202994c59'],
         'files': [C + 'Pairing/Group.lean'],
         'replayed_tree': '5eaddd17 (head tree 9710ac7d)', 'snapshot': 'replay olean-replay-grpfix on a copy of olean-replay-cs1-s6 (map 286777672d4e61f1be0ba98fca72b01d8cd9aa281eb811d100d7fe499679c49c)'},
}
out = {'records_tip_before_pack': TIP, 'records_pin': 'the commit that files briefs/pairings/gates/49-dw11-small-items/ (named in dispatch-r1.md)',
       'mathlib': '029db123ddaa7f8fd0d18cea3b1b33bf84dacd1e', 'prs': {}}
for n, d in prs.items():
    e = dict(d)
    e['commits'] = [commit(c) for c in d['commits']]
    if d['merge']:
        e['merge_commit'] = commit(d['merge'])
    e['file_stats'] = {p: {'base': stats(blob(d['merge_base'], p)), 'head': stats(blob(d['head'], p))} for p in d['files']}
    out['prs'][n] = e
json.dump(out, open(OUT, 'w'), indent=1, sort_keys=True, ensure_ascii=False)
open(OUT, 'a').write('\n')
print('ok')
