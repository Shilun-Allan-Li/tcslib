"""extract.py <repo> <rev> <path> <out> <title> <ranges...>: write the given 1-based inclusive line ranges (a-b) of a git blob, with a header naming them."""
import subprocess, sys
R, REV, P, OUT, TITLE = sys.argv[1:6]
t = subprocess.run(['git', '-C', R, 'show', f'{REV}:{P}'], check=True, capture_output=True).stdout.decode('utf-8').split('\n')
rs = [tuple(int(x) for x in r.split('-')) if '-' in r else (int(r), int(r)) for r in sys.argv[6:]]
desc = ', '.join(f'{a}-{b}' if a != b else f'{a}' for a, b in rs)
with open(OUT, 'w', encoding='utf-8') as f:
    f.write(f'# {TITLE}: {P} at {REV}, lines {desc} (verbatim)\n\n')
    for a, b in rs:
        f.write('\n'.join(t[a - 1:b]) + '\n')
