"""Deterministic ZIP of a directory (sorted entries, fixed timestamp 2026-11-17 00:00, mode 0644).
Usage: python3 -I mkzip.py <srcdir> <out.zip>"""
import os, sys, zipfile
src, out = sys.argv[1], sys.argv[2]
names = []
for root, dirs, files in os.walk(src):
    dirs.sort()
    for f in sorted(files):
        p = os.path.join(root, f)
        names.append(os.path.relpath(p, src))
names.sort()
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, (2026, 11, 17, 0, 0, 0))
        zi.external_attr = 0o644 << 16
        zi.compress_type = zipfile.ZIP_DEFLATED
        with open(os.path.join(src, n), 'rb') as fh:
            z.writestr(zi, fh.read())
print(out, len(names), 'entries')
