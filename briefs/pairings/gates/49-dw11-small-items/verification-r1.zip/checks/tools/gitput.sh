#!/bin/bash
# gitput.sh <repo> <rev> <path> <destroot> [destpath]: write the blob <rev>:<path> under <destroot>; print "sha256  dest  origin"
R=$1; REV=$2; P=$3; D=$4; DP=${5:-$P}
mkdir -p "$(dirname "$D/$DP")"
git -C "$R" show "$REV:$P" > "$D/$DP" || exit 1
echo "$(sha256sum "$D/$DP" | cut -d' ' -f1)  $DP  git $(git -C "$R" rev-parse --short=12 $REV):$P (blob $(git -C "$R" rev-parse --short=12 "$REV:$P"))"
