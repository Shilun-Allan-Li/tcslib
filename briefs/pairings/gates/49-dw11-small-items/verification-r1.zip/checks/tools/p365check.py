"""Gate 49 staging: is #365 proof-only apart from the one new lemma and its module-docstring line?

Usage: python3 -I p365check.py <base Group.lean> <head Group.lean>
Masks every declaration body (from the line that ends with ':= by' or ':=' to the next blank line), then requires
that the masked head equals the masked base plus pure insertions, that the insertions are exactly the new lemma's block
and the two module-docstring lines, and lists the declarations whose bodies changed. Runs two negative controls
(a header character and a docstring character changed in the head) that must FAIL.
"""
import difflib, re, sys

DECL = re.compile(r'^(protected |private )?(theorem|lemma|def|abbrev|instance|structure)\s+(\S+)')
EXPECTED_BODIES = {'pow_val_mul', 'pow_val_mul_GT', 'pow_val_bijective', 'pow_val_add', 'pow_val_bijective_of_ne_one'}
NEW = 'pow_val_bijective_of_prime_card'


def mask(lines):
    out, bodies, i, cur = [], {}, 0, None
    while i < len(lines):
        ln = lines[i]
        m = DECL.match(ln)
        if m:
            cur = m.group(3)
        out.append(ln)
        s = ln.rstrip()
        if cur and (s.endswith(':= by') or s.endswith(':=')) and not s.lstrip().startswith('--'):
            j = i + 1
            body = []
            while j < len(lines) and lines[j].strip() != '':
                body.append(lines[j]); j += 1
            out.append(f'  <BODY {cur}>')
            bodies[cur] = body
            cur = None
            i = j
            continue
        i += 1
    return out, bodies


def check(base, head, verbose=True):
    mb, bb = mask(base)
    mh, bh = mask(head)
    ok = True
    ins = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, mb, mh, autojunk=False).get_opcodes():
        if tag == 'equal':
            continue
        if tag != 'insert':
            ok = False
            if verbose:
                print(f'  NON-INSERT {tag} base {i1+1}-{i2} head-masked {j1+1}-{j2}:', mb[i1:i2], mh[j1:j2])
            continue
        ins.append(mh[j1:j2])
    flat = [l for blk in ins for l in blk]
    newdecl = [l for l in flat if DECL.match(l)]
    if [DECL.match(l).group(3) for l in newdecl] != [NEW]:
        ok = False
        if verbose:
            print('  inserted declarations:', newdecl)
    changed = sorted(k for k in bb if k in bh and bb[k] != bh[k])
    if set(changed) != EXPECTED_BODIES:
        ok = False
    if set(bb) - set(bh):
        ok = False
    if verbose:
        print(f'  insert blocks: {len(ins)}; inserted lines: {len(flat)}')
        for blk in ins:
            print('   ---'); [print('   +', l) for l in blk]
        print('  bodies changed:', changed)
        print('  declarations removed:', sorted(set(bb) - set(bh)))
    return ok


base = open(sys.argv[1], encoding='utf-8').read().split('\n')
head = open(sys.argv[2], encoding='utf-8').read().split('\n')
print('HEAD:'); r = check(base, head); print('RESULT', 'PASS' if r else 'FAIL')
hdr = [i for i, l in enumerate(head) if l.startswith('theorem pow_val_mul_GT')][0]
c1 = list(head); c1[hdr] = c1[hdr].replace('(y : B.GT)', '(z : B.GT)')
doc = [i for i, l in enumerate(head) if 'Exponents of `G_T` act through' in l][0]
c2 = list(head); c2[doc] = c2[doc].replace('act through', 'acts through')
for name, c in [('control header char', c1), ('control docstring char', c2)]:
    r = check(base, c, verbose=False)
    print(name, 'FAIL (as required)' if not r else 'PASS (CONTROL BROKEN)')
