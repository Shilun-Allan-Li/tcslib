#!/bin/bash
# Gate 49 staging: name and statement-shape greps for the declarations of #351, #352 and #365.
# Usage: dupsweep.sh <repo> <tip> <head365>. Mathlib source: <repo>/.lake/packages/mathlib (rev printed).
R=$1; TIP=$2; H=$3; ML=$R/.lake/packages/mathlib
cd "$R"
echo "# dup-sweep.txt (staging greps; the judgement is in pack-r1.md, question 5)"
echo "tip: $TIP   #365 head: $H   Mathlib: $(git -C $ML rev-parse HEAD)   (lake-manifest inputRev: $(grep -A3 '"name": "mathlib"' lake-manifest.json | grep inputRev | tr -d ' ,'))"
N='pow_val_add|pow_val_neg|pow_val_bijective_of_ne_one|pow_val_bijective_of_prime_card|abs_expect_sub_le_expect|expect_simulate_rel|prob_simulate_rel|expect_sample_rel'
echo; echo "## 1. exact names, declarations at the tip and at the #365 head (TCSlib/, audits/)"
for r in $TIP $H; do echo "-- $r"; git grep -n -w -E "$N" $r -- '*.lean' | grep -E '(theorem|lemma|def|abbrev) ' | sed "s|^$r:||"; done
echo; echo "## 2. exact names in Mathlib (expect none)"
grep -rn -w -E "$N" $ML/Mathlib | sed "s|$ML/||"; echo "(end)"
echo; echo "## 3. averaging-bound shapes in TCSlib at the tip"
git grep -n -E "theorem [A-Za-z_.']*(abs_expect|expect_abs|abs_uexp)[A-Za-z_.']*" $TIP -- 'TCSlib/*.lean' | sed "s|^$TIP:||"
echo; echo "## 4. simulation lemmas in Games/ and the ETT tools at the tip (relational/abstraction relatives)"
git grep -n -E "^(private |protected )?theorem [A-Za-z_.']*simulate[A-Za-z_.']*" $TIP -- TCSlib/Cryptography/Games TCSlib/Cryptography/Encryption/PrivateKey/EncryptThenTag/Tools.lean | sed "s|^$TIP:||"
echo; echo "## 5. one-sample couplings: (sample _).bind fun _ => .pure in statements at the tip"
git grep -n -E "\(sample [A-Za-z_ ]+\)\.bind fun [a-z]+ => (\.pure|pure)" $TIP -- 'TCSlib/*.lean' | sed "s|^$TIP:||"
echo; echo "## 6. bijections ZMod -> group, exponent laws (TCSlib at the #365 head)"
git grep -n -E "Bijective fun [a-z]+ : ZMod|theorem expo_bijective|orderOf_eq_prime|pow_mod_card|pow_injOn_Iio_orderOf|Nat\.mod_add_div" $H -- 'TCSlib/Cryptography/*.lean' | sed "s|^$H:||"
echo; echo "## 7. Mathlib relatives (declaration lines)"
grep -rn -E "(theorem|lemma|def) (IsCyclic\.unique_zpow_zmod|zmodCyclicMulEquiv|mulEquivOfPrimeCardEq|finEquivPowers|finEquivZPowers|pow_injOn_Iio_orderOf|pow_mod_card|pow_mod_natCard|pow_mod_orderOf|orderOf_eq_prime|pow_card_eq_one|zmodEquivZPowers|pow_eq_pow_iff_modEq)\b" $ML/Mathlib | sed "s|$ML/||"
echo; echo "## 8. Mathlib: any statement 'Bijective fun _ : ZMod _ => _ ^ _.val' (expect none)"
grep -rn -E "Bijective +\(?fun [a-z]+ : ZMod" $ML/Mathlib | sed "s|$ML/||"; echo "(end)"
echo; echo "## 9. Mathlib: ZMod-indexed exponent statements '^ (_ + _).val', '^ (-_).val' (expect none)"
grep -rn -E "\^ \(\(?-?[a-z]+( \+ [a-z]+)?\)?\)\.val" $ML/Mathlib | grep -E "theorem|lemma" | sed "s|$ML/||"; echo "(end)"
