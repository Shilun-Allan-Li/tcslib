# POINTERS · what is not copied

- **Raw logs inside the evidence ZIPs** are copied whole (the ZIPs are nested unchanged); nothing was dropped from them.
- **The olean trees** (snapshot #2–#6, the replay outputs `olean-replay-bb1sim-games`, `olean-replay-352`,
  `olean-replay-grpfix`) are on the maintainer host only; their maps' SHA-256 are in the snapshot register extract, the
  adoption folders and #365's `run-commit2/output-map/map.out`.
- **Later gates' packs** (Gate 44, 47, 48) are not copied; only their findings files are, under `records/`.
- **Mathlib** is cited at `029db123ddaa7f8fd0d18cea3b1b33bf84dacd1e` (`lake-manifest.json`); the two files holding the
  nearest relatives are in `sources-r1.zip` (`mathlib-029db123/`).
