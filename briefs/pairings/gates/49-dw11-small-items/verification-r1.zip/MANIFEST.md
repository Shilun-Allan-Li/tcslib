# verification-r1.zip · Gate 49 (DW-11: #351, #352, #365) round 1

Provenance of every entry. `SHA256SUMS` (this directory) lists every entry other than itself; verify with
`sha256sum -c SHA256SUMS` from a fresh extract. Nothing here was produced by a Lean run at staging: the evidence ZIPs are
the maintainer reviews' recorded evidence, copied byte for byte from the records; `checks/` are git-object reads made at
staging with the scripts in `checks/tools/`.

- **`evidence/statements-final-r1/`** (records `briefs/pairings/fills/bb1-sim/statements-final-r1/`, at the records tip
  `b31b77f7` before this pack; unchanged at the pin):
  - `bb1-sim-statements-r1-phase1-evidence.zip` (`6e4cbadd…`): the phase-1 review of #351's and #352's worker series
    (static checks, statements vs design §2.2, decls2, citations, Mathlib relatives, the worker's evidence recounted).
  - `bb1-sim-statements-r1-phase2-evidence.zip` (`411338e9…`): phase 2, the merged-tree replays R1 (#351 head
    `dfacac35`) and R2 (#352 head `92dea4f8`) on snapshot #2, axioms, Rule 10 (seals, controls, scan), lint, the
    cross-build P2-7.
  - `bb1-sim-statements-r1-phase2b-evidence.zip` (`13483b25…`): phase 2b, #352's re-replay on snapshot #3 (REV
    `3029d8c3`).
  - `evidence-SHA256SUMS`: the records' own sums of the three ZIPs.
- **`evidence/group-dedup/group-dedup-evidence.zip`** (`48d787d4…`; records `briefs/pairings/fixes/group-dedup/`): #365's
  evidence for both commits (`README.txt` maps `run-commit1/`, `run-commit2/`; inner `SHA256SUMS`).
- **`snapshots/olean-snapshot-3-adopt/`, `snapshots/olean-snapshot-4-adopt/`** (records
  `briefs/pass-shelat-ch5-8/maintainer/`): the adoptions of the #351 and #352 replays as olean snapshots #3 and #4
  (README, empty `step3-diff.txt`, `basecheck.out`, maps, files manifests, state init, rehash outputs).
- **`checks/`** (staging, git objects only): `series.txt` (commits, parents, trees, signature kind, numstat),
  `lean-equality.txt` (merges vs replayed trees, PR views vs merge diffs, base equalities), `mergetrees.txt` (#365 with
  the tip and the open PRs), `pr365-lines.txt` and `pr365-proof-only.txt` (#365 is proof-only apart from the new lemma;
  two negative controls), `dup-sweep.txt` (name and shape greps over TCSlib and Mathlib `029db123`); `tools/` holds the
  scripts (`checks.sh`, `dupsweep.sh`, `p365check.py`, `srchead.py`, `extract.py`, `gitput.sh`, `mkzip.py`).
- **`records/`** (at the tip `b31b77f7`, unchanged at the pin): the two statement reviews (`review.md`, `phase2.md`) and
  `phase2b-352.md`; #365's `report.md`; the bb1-sim `rulings.md`, `design-r1.md` and issued statement brief
  (`issued-stmt-r1/brief.md`); `policy.md`; Gate 44's, Gate 47's and Gate 48's findings (the G44-01 and G48-01
  precedents; what later gates said about these files); and extracts with a header naming file and lines: the decision
  log (`decision-log-pairings.md`), the duplication ledger (DL-40), the deferred-work register (DW-11), the cleanup
  Stage 2 rulings and plan lines on DW-11, and the snapshot register.
- **`pr/`**: the REST fields of #351, #352 and #365 at staging (`gh api repos/…/pulls/N`; #365's `merge_commit_sha` is
  GitHub's test merge and moves).
