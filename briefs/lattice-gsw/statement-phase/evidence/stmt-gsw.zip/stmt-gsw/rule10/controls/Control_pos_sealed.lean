import TCSlib.Cryptography.AdvancedEncryption
import TCSlib.Cryptography.Hashing.SIS
set_option autoImplicit false
attribute [local irreducible] TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Encrypts
attribute [local irreducible] TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.gadget
attribute [local irreducible] TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt
attribute [local irreducible] TCSlib.Cryptography.Hashing.SIS.hashColumns
attribute [local irreducible] BoolCircuit.DAGCircuit.depth
open TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW TCSlib.Cryptography
open TCSlib.Cryptography.Encryption.PublicKey
-- positive controls: the same facts through the published readers (5 examples)
example (P : Parameters) (t : Fin (P.lwe.dimension + 1) → ZMod P.lwe.modulus) (x : ℤ) (β : ℕ)
    (C : Ciphertext P) : Encrypts P t x β C ↔ ∃ e : Fin P.columns → ℤ, (∀ j, (e j).natAbs ≤ β) ∧
      Matrix.vecMul t C = (x : ZMod P.lwe.modulus) • Matrix.vecMul t (gadget P) +
        fun j => (e j : ZMod P.lwe.modulus) := encrypts_iff P t x β C
example (P : Parameters) (i : Fin (P.lwe.dimension + 1)) (j : Fin P.columns) :
    gadget P i j = ((TrapdoorFunctions.Lossy.gadget P.width (P.lwe.dimension + 1) j i : ℤ) :
      ZMod P.lwe.modulus) := gadget_apply P i j
example (P : Parameters) (s : Fin P.lwe.dimension → ZMod P.lwe.modulus) (C : Ciphertext P) :
    decrypt P s C =
      Regev.decrypt P.lwe s (Fin.init (decryptColumn P C), decryptColumn P C (Fin.last _)) :=
  decrypt_eq P s C
example (P : SIS.Parameters) (N : ℕ) (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus))
    (R : Matrix (Fin P.columns) (Fin N) Bool) (i : Fin P.dimension) (j : Fin N) :
    Hashing.SIS.hashColumns P N A R i j = Hashing.SIS.hash P A (fun c => R c j) i :=
  Hashing.SIS.hashColumns_apply P N A R i j
example {n : ℕ} (C : BoolCircuit.DAGCircuit n) : C.depth = C.depthAt C.output :=
  BoolCircuit.DAGCircuit.depth_eq C
