#!/usr/bin/env bash
# one.sh <module> <logdir>: back up and check one module of the GSW worktree (ladder of length one); print the log.
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
echo $1 > $SP/stmt2/gsw/one-order.txt
$SP/stmt2/tools/ladder.sh $SP/wt-stmt-gsw $SP/stmt2/gsw/one-order.txt $2 | grep -v '^BACKUP OK'
grep -v "declaration uses 'sorry'" $2/$1.log | head -${3:-60}
