#!/usr/bin/env bash
# ladder.sh <worktree> <order-file> <logdir>: back up, then check each module in order with the
# worktree's scripts/lean_check_tree.sh on $SP/dl-oleans-2, one process at a time; stop on failure.
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
export PATH=$HOME/.elan/bin:$PATH TCSLIB_OLEANS=$SP/dl-oleans-2
WT=$1; ORD=$2; LOG=$3; mkdir -p $LOG
cd $WT || exit 9
while read -r m; do
  [ -z "$m" ] && continue
  python3 -I $SP/stmt2/tools/backup.py $TCSLIB_OLEANS $SP/stmt2/bk $SP/stmt2/tree/snapshot-pre.txt $m || exit 8
  p=${m//.//}; s=$(date +%s)
  bash scripts/lean_check_tree.sh $p > $LOG/$m.log 2>&1; rc=$?
  echo "$m rc=$rc errors=$(grep -c 'error:' $LOG/$m.log) sorry=$(grep -c "declaration uses 'sorry'" $LOG/$m.log) warnings=$(grep -c 'warning:' $LOG/$m.log) secs=$(( $(date +%s)-s ))" | tee -a $LOG/summary.txt
  [ $rc -ne 0 ] && exit $rc
done < $ORD
exit 0
