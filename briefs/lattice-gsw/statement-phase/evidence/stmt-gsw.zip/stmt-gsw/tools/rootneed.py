"""rootneed.py <worktree> <olean-tree> <tree-rev>: for the root `TCSlib` import closure at the
worktree's files, list modules whose olean is missing, whose source changed since <tree-rev>, and
the downstream closure of both (what a root build would have to rebuild)."""
import sys, os, re, subprocess
wt, tree, rev = sys.argv[1:]
def src(m):
    p = os.path.join(wt, m.replace('.', '/') + '.lean')
    return open(p, encoding='utf-8').read() if os.path.exists(p) else None
seen, order, imps = set(), [], {}
def visit(m):
    if m in seen: return
    seen.add(m); s = src(m)
    if s is None: print('NOSRC', m, file=sys.stderr); return
    imps[m] = [i for i in re.findall(r'^import\s+(\S+)', s, re.M) if i.split('.')[0] == 'TCSlib']
    for i in imps[m]: visit(i)
    order.append(m)
visit('TCSlib')
changed = set(subprocess.run(['git','-C',wt,'diff','--name-only',rev,'HEAD','--','TCSlib','TCSlib.lean'],
   capture_output=True,text=True).stdout.split())
# also uncommitted/untracked
changed |= set(subprocess.run(['git','-C',wt,'status','--porcelain','--untracked-files=all'],capture_output=True,text=True).stdout.replace('?? ','').replace(' M ','').split())
missing = {m for m in order if not os.path.exists(os.path.join(tree, m.replace('.','/')+'.olean'))}
chg = {m for m in order if m.replace('.','/')+'.lean' in changed}
need = set(missing | chg)
for m in order:
    if any(i in need for i in imps[m]): need.add(m)
print('closure', len(order), 'missing', len(missing), 'changed', len(chg), 'need', len(need))
for m in order:
    if m in need: print(('M' if m in missing else '-')+('C' if m in chg else '-'), m)
