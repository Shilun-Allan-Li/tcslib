#!/usr/bin/env bash
# runseal.sh <worktree> <probe-dir> <summary>: run every probe in <probe-dir> with lean -DmaxErrors=0 against
# $SP/dl-oleans-2 plus the lake packages, no -o (nothing written to the tree), one process at a time.
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
cd $1; export PATH=$HOME/.elan/bin:$PATH; LP=$SP/dl-oleans-2
for d in .lake/packages/*/.lake/build/lib/lean; do LP="$LP:$d"; done
: > $3
for f in $2/*.lean; do LEAN_PATH=$LP lean -DmaxErrors=0 $f > $f.log 2>&1; rc=$?
  echo "$(basename $f) rc=$rc errors=$(grep -cE '^\S+\.lean:[0-9]+:[0-9]+: error' $f.log) unknown=$(grep -c 'Unknown constant' $f.log) sorry=$(grep -c "declaration uses 'sorry'" $f.log)" >> $3; done
cat $3
