## LE-g50d (Gate 50 G50-01, docs only, 2026-11-18)
**Why.** Gate 50 round 1 cleared this PR with one minor, **G50-01**: some prose still described the admitted state and missing readers. Seyoon ruled that it is fixed before merging, by a docs-only landing edit under a documentation exception for the frozen prose (decision log, 2026-11-18).

**What.** `bae0d84d35bedd876bcbd7af80c0a333db766237` (tree `fbba5d383d28edf509b68b30199ca276940033ca`), signed, on `597fb736`. It touches comments and docstrings only: 6 files, +19/−14.
- `BranchingPrograms/Defs:32`, `Eval:35`, `Barrington:32`: the "Main results" sentence now reads "targets proved in the fill phase, gsw-6a-fills", replacing "targets admitted with `sorry`".
- `NANDForm:61` (module note) and the `toNANDForm` docstring (`:455`): "While N2 is admitted, `sorryAx` reaches …" becomes "N2 is proved, so no admission reaches …".
- Also found by the sweep and fixed the same way:
  - The N2 (`nandGadget_correct`) sketch said "the fill needs a reader for `GadgetCorrect`, which has none". It now names the owner-side reader `gadgetCorrect_iff` that the proof uses.
  - `NANDLayering`, N12 (`layerGates_acyclic`): "`GatesAcyclic` has no published reader" is now past tense (statement phase), and the note adds that the fill reads it through `gatesAcyclic_iff`.
- `FormulaArith/Combinators:303`, `:329` (sketches of `neg_eval` and `depth_neg`): they named the readers as missing. They now name `Lit.eval_eq` and `TreeCircuit.depth_lit`.
- `Barrington`, `barrington_length_pos_aux`: the docstring now ends "Glue for C13 and C14."
- **Sweep.** I searched all 23 changed files for "admit", "sorry", "missing", "no (published) reader", "has none", "issue base", "census", "not yet" and "while … admitted". Every other hit is still true. Examples: `NANDLayering`'s "no admission reaches `layerNAND`", `NC1`/`BarringtonConverse`'s "proved", "fixed at the statement phase", and the `ComputationalModels` RAM line, which is not 6a.

**Code identity.** I stripped comments from each of the 6 files at `597fb736` and at `bae0d84d`: line comments, nested block comments and docstrings, keeping string and char literals. The stripped code is **byte-identical** in all 6. The tool is LE-g45b's `commentstrip45b.py` with the per-file controls moved to JSON (`commentstrip50.py`).
- Each file has 3 mutation controls: a space after the first code `:=`, a code-token change, and a code line commented out. All **18/18 are caught**.
- Each file also has a docstring-word negative control, which stays equal (6/6).

**Short re-replay.** Never with `lake build`. One Lean process at a time, slot-gated (0 other `lean` seen) and disk-gated.
- **Tree:** `olean-replay-6a-land9` is a `cp -al` of `olean-replay-6a-land8` (map `963ddeb4…`; state check at `597fb736` OK at the start).
- **Build:** the downstream of the 6 files, **20 modules** (the plan's queue equals `downorder`'s down set). The other 1,427 modules were reused.
  - **rc 0, 0 `error:`/`error(`, 0 sorry, 0 warnings.** All 20 logs are byte-equal to the earlier runs' logs.
  - **State check** at `bae0d84d` over 1,447 modules: **RESULT OK**, both after the build and at the end.
  - **Links:** the 20 rebuilt oleans have link count 1, and the 1,427 reused ones are the parent's inodes.
- **Output map** (Mathlib excluded): 1,478 entries, SHA-256 **`9bb4a0d093a772f4fd809289ea14e576b445d206016dc1aab26c55065996e838`**, stable at the end.
  - Against `-land8`: 1,472 equal, and exactly the **6 edited modules** changed (docstrings are stored in oleans). The 14 rebuilt downstream oleans are byte-equal.
- **Rehash:** the parent tree and snapshot #8 (`28677767…`) both rehash **0/0/0** at the start, after the build and at the end. Snapshot #8 was checked again after `-land8` was deleted.
- **Admissions:** 0 in the 13 6a modules. Library: **192 in 44 modules**, byte-equal to LE-g50's scan.
- **Axioms:** the `AxiomsLand` probe source is unchanged, and **its log is byte-identical to LE-g50's** (`39b9c301…`). `axcheck` output is byte-equal: 98 targets OK, 853 constants, 0 TRACE lines, no `sorryAx`.
- **decls2** against `555f0fe1`: **289 ADDED / 1 REMOVED / 0 CHANGED**, equal to LE-g50's output up to shifted line numbers. `touched.py` against `cd8b4765` gives the same declarations and statuses.
- **Lint:**
  - `campaign_style_lint --check8b`, Complexity: 25 FAIL / 390 WARN, with FAIL/WARN lines byte-equal to LE-g50's. Only INFO size lines change (Barrington 895 → 897, NANDLayering 948 → 949, …).
  - `Cryptography`: byte-equal.
  - `style_lint` on the changed files: byte-equal.
  - No added line is over 100 characters.
- **Seal spot check:** canonical coe-A on the edited owner `NANDForm`, after the unchanged 22-owner collector.
  - The collector source and log are byte-identical to LE-g50's.
  - The seal has 180 requests and 0 errors, and its run log is byte-identical.
  - The requests, rows, stored constants and term sets are identical. Only `rev`, the source/probe hashes and one EOF insertion offset differ (−8 bytes of docstring).

Evidence: `briefs/lattice-gsw/phase6/fills-final-r1/le-g50d-evidence.zip` (inner `SHA256SUMS`).

