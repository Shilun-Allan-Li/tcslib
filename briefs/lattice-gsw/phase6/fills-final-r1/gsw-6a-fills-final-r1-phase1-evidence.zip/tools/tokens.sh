#!/usr/bin/env bash
# tokens.sh <repo> <base> <head> <paths-file>: forbidden-token counts per owned file at head and on added lines
cd "$1"; B=$2; H=$3
for f in $(cat "$4"); do
  s=$(git show $H:$f)
  printf '%s sorry=%s admit=%s native_decide=%s axiom=%s attr=%s set_option=%s\n' "$f" \
    "$(grep -cw sorry <<<"$s")" "$(grep -cw admit <<<"$s")" "$(grep -c native_decide <<<"$s")" \
    "$(grep -cE '^\s*axiom ' <<<"$s")" "$(grep -c '@\[' <<<"$s")" "$(grep -c set_option <<<"$s")"
done
echo "ADDED-LINE HITS:"
git diff $B $H | grep -E '^\+' | grep -nE 'set_option|@\[|sorry|admit|native_decide|maxHeartbeats|\baxiom\b' | head -40
