"""sizes.py <repo> <base> <head> <file>...: lines and max width (Python len) at base and head."""
import sys, subprocess
repo, b, h, files = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:]
tot = 0
for f in files:
    r = []
    for rev in (b, h):
        s = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, check=True).stdout.decode()
        L = s.split('\n')[:-1] if s.endswith('\n') else s.split('\n')
        r.append((len(L), max(len(l) for l in L), sum(len(l) > 100 for l in L)))
    tot += r[1][0] - r[0][0]
    print(f'{f}\tbase={r[0][0]}\thead={r[1][0]}\tfill=+{r[1][0]-r[0][0]}\tmaxw={r[1][1]}\tover100={r[1][2]}')
print(f'TOTAL fill +{tot}')
