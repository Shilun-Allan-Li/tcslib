"""sealcount.py <evidence-dir> <repo> <site=rev>...: recount the worker's Rule 10 seals from raw files.
Per site (rule10/<site>) and variant (A, B, coeA, coeB), per seal: the probe text (seals-*/X.lean.txt)
hashes to probe_sha256; removing the recorded insertions (each hash-checked) gives back the source of
<rev>:<source> byte for byte; the raw log hashes to results.jsonl's log_sha256; errors in both forms are
recounted; the log carries G06-SEAL, both G06-MASK lines and G06-SEAL-END with verified=requested."""
import sys, os, re, json, hashlib, subprocess, glob
E, repo = sys.argv[1], sys.argv[2]
ERR1 = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
ERR2 = re.compile(r'error', re.I)
sha = lambda b: hashlib.sha256(b).hexdigest()
for spec in sys.argv[3:]:
    site, rev = spec.split('=')
    for var in ('A', 'B', 'coeA', 'coeB'):
        sd = f'{E}/rule10/{site}/seals-{var}'
        res = {}
        for l in open(f'{E}/rule10/{site}/run-{var}/results.jsonl'):
            r = json.loads(l)
            if 'module' in r: res[os.path.basename(r['module'])] = r
        for jf in sorted(glob.glob(f'{sd}/Seal*.json')):
            j = json.load(open(jf)); lab = j['label']
            probe = open(jf[:-5] + '.lean.txt', 'rb').read()
            src = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{j["source"]}'],
                                 capture_output=True, check=True).stdout
            p = probe
            insok = True
            for ins in sorted(j['insertions'], key=lambda x: -x['probe_byte_offset']):
                o, n = ins['probe_byte_offset'], ins['byte_count']
                insok &= sha(p[o:o + n]) == ins['sha256']
                p = p[:o] + p[o + n:]
            r = res.get(lab)
            logs = glob.glob(f'{E}/rule10/{site}/run-{var}/mods/*_{lab}.log')
            log = open(logs[0], 'rb').read() if logs else b''
            t = log.decode('utf-8', 'replace')
            req = j['requested']
            marks = (f'G06-SEAL label={lab} requested={req}' in t and
                     f'G06-SEAL-END label={lab} requested={req} verified={req}' in t and
                     f'phase=install requested={req} verified={req}' in t and
                     f'phase=eof requested={req} verified={req}' in t)
            ok = (sha(probe) == j['probe_sha256'] and insok and p == src and sha(src) == j['source_sha256']
                  and r is not None and r['rc'] == 0 and r['errors'] == 0 and r['log_sha256'] == sha(log)
                  and r['source_sha256'] == j['probe_sha256'] and not ERR1.findall(t)
                  and not ERR2.findall(t) and marks)
            print(f'{site}\t{var}\t{lab.split("_", 1)[1]}\trequested={req}\trc={r and r["rc"]}\t'
                  f'err1={len(ERR1.findall(t))}\terr2={len(ERR2.findall(t))}\tsrc_bound={p == src}\t'
                  f'markers={marks}\t{"OK" if ok else "BAD"}')
