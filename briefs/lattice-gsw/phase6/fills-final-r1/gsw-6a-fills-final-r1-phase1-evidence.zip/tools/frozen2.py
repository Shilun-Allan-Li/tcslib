"""frozen2.py (maintainer, gsw-6a-fills phase-1 review): an independent frozen check.

usage: frozen2.py <repo> <base> <head> <targets.txt> [--control]

Per owned file, base and head are normalised (a line holding `**Proof sketch.**` is split right after
that token; a line holding `:= by` is split right after it; a `-/` preceded by text is split onto its own
line).  Allowed regions:
  base: each target's sketch paragraph (after `**Proof sketch.**` to before the docstring's `-/`) and its
        proof body (after `:= by` up to the next column-0 line other than termination_by/decreasing_by);
  head: the same regions of the same target (found by its base header line, byte-equal), plus every
        column-0 `private theorem|lemma|def` block whose name is not private at the base (with the
        docstring above it and its body), plus `import Mathlib.` lines.
difflib aligns base and head lines; every deleted base line must lie in an allowed base region and every
inserted head line in an allowed head region.  Everything else is printed as VIOLATION, for review (the
module-docstring sentences and the G6A-F07 line are expected there and judged by hand).
--control: also runs, per file, a one-character header edit and a prose edit (must give violations)."""
import sys, re, subprocess, difflib

repo, base, head, targf = sys.argv[1:5]
CONTROL = '--control' in sys.argv
DECL = re.compile(r'^(?:@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec)\s+)*'
                  r'(theorem|lemma|def|abbrev|instance|structure|inductive|class)\s+(\S+)')
CONT = re.compile(r'^(termination_by|decreasing_by)\b')


def show(rev, f):
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True,
                          check=True).stdout.decode('utf-8')


def norm(text):
    out = []
    for l in text.split('\n'):
        parts = [l]
        for tok in ('**Proof sketch.**', ':= by'):
            np = []
            for p in parts:
                k = p.find(tok)
                if k >= 0 and p[k + len(tok):].strip():
                    np += [p[:k + len(tok)], p[k + len(tok):]]
                else:
                    np.append(p)
            parts = np
        np = []
        for p in parts:
            k = p.rfind('-/')
            if k > 0 and p[:k].strip() and p.rstrip().endswith('-/'):
                np += [p[:k], p[k:]]
            else:
                np.append(p)
        out += np
    return out


def block_end(L, i):
    j = i + 1
    while j < len(L):
        l = L[j]
        if l and not l[0].isspace() and not CONT.match(l):
            break
        j += 1
    return j


def doc_start(L, i):
    k = i - 1
    while k >= 0 and L[k].strip() == '':
        k -= 1
    if k >= 0 and L[k].rstrip().endswith('-/'):
        while k >= 0 and not L[k].lstrip().startswith('/--'):
            k -= 1
        return k
    return i


def target_regions(L, hi):
    """allowed line indices for the target whose header line index is hi."""
    allowed = set()
    a = doc_start(L, hi)
    for k in range(a, hi):
        if L[k].endswith('**Proof sketch.**'):
            e = k + 1
            while e < hi and L[e].strip() != '-/' and not L[e].lstrip().startswith('-/'):
                e += 1
            allowed |= set(range(k + 1, e))
            break
    k = hi
    while k < len(L) and not L[k].endswith(':= by'):
        k += 1
    e = block_end(L, k)
    allowed |= set(range(k + 1, e))
    return allowed


def check(f, B, H, hdrs, quiet=False):
    bpriv = {m.group(3) for l in B if (m := DECL.match(l)) and 'private' in (m.group(1) or '')}
    ab, ah = set(), set()
    for h in hdrs:
        ib = B.index(h)
        ab |= target_regions(B, ib)
        if h not in H:
            if not quiet:
                print(f'  MISSING-AT-HEAD {h}')
            continue
        ah |= target_regions(H, H.index(h))
    helpers = []
    for i, l in enumerate(H):
        m = DECL.match(l)
        if m and 'private' in (m.group(1) or '') and m.group(3) not in bpriv:
            a, e = doc_start(H, i), block_end(H, i)
            ah |= set(range(a, e))
            helpers.append((m.group(3), i + 1, e - a))
        if l.startswith('import Mathlib.'):
            ah.add(i)
    v = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, B, H, autojunk=False).get_opcodes():
        if op == 'equal':
            continue
        for i in range(i1, i2):
            if i not in ab and B[i].strip():
                v.append(f'  VIOLATION base-{i+1} - {B[i]}')
        for j in range(j1, j2):
            if j not in ah and H[j].strip():
                v.append(f'  VIOLATION head-{j+1} + {H[j]}')
    if not quiet:
        for x in v:
            print(x)
    return v, helpers


tg = {}
for l in open(targf, encoding='utf-8'):
    p = l.rstrip('\n').split('\t')
    if len(p) < 4 or ':' not in p[2] or p[0] == 'unit':
        continue
    f, ln = p[2].rsplit(':', 1)
    tg.setdefault(f, []).append((int(ln), p[3]))
tot = 0
for f, ts in tg.items():
    B, H = norm(show(base, f)), norm(show(head, f))
    raw = show(base, f).split('\n')
    hdrs = []
    for ln, name in ts:
        h = raw[ln - 1]
        hdrs.append(norm(h)[0])
        assert name.split('.')[-1] in h, (f, ln, name, h)
    print(f'== {f}: targets={len(ts)}')
    v, helpers = check(f, B, H, hdrs)
    for n, ln, sz in helpers:
        print(f'  HELPER {n} head-line {ln} block-lines {sz}')
    print(f'  RESULT violations={len(v)} helpers={len(helpers)}')
    tot += len(v)
    if CONTROL:
        for kind in ('header', 'prose'):
            H2 = list(H)
            hi = H2.index(hdrs[0])
            if kind == 'header':
                H2[hi] = H2[hi][:-1] + 'X'
            else:
                k = hi
                while not H2[k].endswith('**Proof sketch.**'):
                    k -= 1
                k -= 1
                while not H2[k].strip():
                    k -= 1
                H2[k] = H2[k][:-1] + 'X'
            v2, _ = check(f, B, H2, hdrs, quiet=True)
            print(f'  CONTROL {kind}: violations={len(v2)} ({"OK" if len(v2) > len(v) else "BAD"})')
print(f'TOTAL violations={tot}')
