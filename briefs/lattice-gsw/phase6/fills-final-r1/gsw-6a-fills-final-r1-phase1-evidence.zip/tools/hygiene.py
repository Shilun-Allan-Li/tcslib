"""hygiene.py <dir> <file>...: per declaration of the owned files: docstring present, for private
helpers a backtick formula and 'Glue.', and for blocks of >= 20 lines (header to end) a
'**Proof sketch.**'.  Also lists source tags ([Bar89...]) in private helper docstrings."""
import sys, re
d, files = sys.argv[1], sys.argv[2:]
DECL = re.compile(r'^(?:@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec)\s+)*(theorem|lemma|def|abbrev|instance|structure)\s+(\S+)')
bad = 0
for f in files:
    L = open(f'{d}/{f}', encoding='utf-8').read().split('\n')
    for i, l in enumerate(L):
        m = DECL.match(l)
        if not m: continue
        j = i + 1
        while j < len(L) and not (L[j] and not L[j][0].isspace() and not L[j].startswith(('termination_by', 'decreasing_by'))):
            j += 1
        e = j
        while L[e - 1].strip() == '': e -= 1
        k = i - 1
        doc = ''
        if k >= 0 and L[k].rstrip().endswith('-/'):
            s = k
            while s >= 0 and not L[s].startswith('/--'): s -= 1
            doc = '\n'.join(L[s:k + 1])
        priv = 'private' in (m.group(1) or '')
        n = e - i
        issues = []
        if not doc: issues.append('NO-DOC')
        if priv and doc and '`' not in doc: issues.append('NO-FORMULA')
        if priv and doc and 'Glue.' not in doc: issues.append('NO-GLUE')
        if priv and re.search(r'\[(Bar89|BV11|BV14|AB09)', doc): issues.append('TAG-ON-HELPER')
        if n >= 20 and '**Proof sketch.**' not in doc: issues.append(f'NO-SKETCH({n})')
        if issues:
            bad += 1
            print(f'{f.split("/")[-1]}:{i+1}\t{m.group(3)}\t{"private" if priv else "public"}\tlines={n}\t{" ".join(issues)}')
print(f'RESULT issues={bad}')
