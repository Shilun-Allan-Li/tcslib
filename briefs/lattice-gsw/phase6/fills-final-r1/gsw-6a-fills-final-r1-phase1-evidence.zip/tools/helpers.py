"""helpers.py <dir> <file>...: print every column-0 private theorem/lemma/def of each file (path:line, statement)."""
import sys, re
d, files = sys.argv[1], sys.argv[2:]
for f in files:
    L = open(f'{d}/{f}', encoding='utf-8').read().split('\n')
    for i, l in enumerate(L):
        if re.match(r'^private (theorem|lemma|def)\s', l):
            j, buf = i, []
            while j < len(L):
                buf.append(L[j].strip())
                if ':=' in L[j] or L[j].rstrip().endswith(' where') or (j > i and re.match(r'^\s*\|', L[j+1] if j+1 < len(L) else '')):
                    break
                j += 1
            print(f'{f.split("/")[-1]}:{i+1}\t' + ' '.join(buf))
