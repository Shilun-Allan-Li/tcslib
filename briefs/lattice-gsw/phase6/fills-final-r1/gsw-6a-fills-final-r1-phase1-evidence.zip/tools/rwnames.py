"""rwnames.py <repo> <rev> <file>...: every name passed to simp/rw/unfold/delta/dsimp/simp_rw/erw/
nth_rewrite/simp_all/field_simp/norm_num/omega-free rewriting tactics in the owned files at <rev>
(comments stripped), with the owning file's own declarations marked.  Output: name<TAB>count<TAB>files."""
import sys, re, subprocess, collections
repo, rev, files = sys.argv[1], sys.argv[2], sys.argv[3:]
TAC = re.compile(r'\b(simp only|simp_all only|simp_all|simp|dsimp only|dsimp|simp_rw|rwa|rw|erw|'
                 r'nth_rewrite \d+|nth_rw \d+|field_simp|norm_num|unfold|delta|simpa only|simpa)\s*(\[)?')
out = collections.defaultdict(set)
cnt = collections.Counter()
for f in files:
    s = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, check=True).stdout.decode()
    s = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), s, flags=re.S)
    s = re.sub(r'--[^\n]*', '', s)
    for m in TAC.finditer(s):
        k = m.end()
        if m.group(2):
            d, j = 1, k
            while j < len(s) and d:
                d += {'[': 1, ']': -1}.get(s[j], 0); j += 1
            body = s[k:j - 1]
        elif m.group(1) in ('unfold', 'delta'):
            body = s[k:s.find('\n', k)]
        else:
            continue
        depth, cur, parts = 0, '', []
        for ch in body:
            if ch in '([{⟨': depth += 1
            if ch in ')]}⟩': depth -= 1
            if ch == ',' and depth == 0: parts.append(cur); cur = ''
            else: cur += ch
        parts.append(cur)
        for p in parts:
            p = p.strip().lstrip('←').strip()
            mm = re.match(r'^@?([A-Za-z_][\w.\'!?₀-₉]*)', p)
            if mm and not p.startswith('show') and mm.group(1) not in ('at', '*'):
                n = mm.group(1)
                out[n].add(f.split('/')[-1][:-5]); cnt[n] += 1
for n in sorted(out):
    print(f'{n}\t{cnt[n]}\t{",".join(sorted(out[n]))}')
