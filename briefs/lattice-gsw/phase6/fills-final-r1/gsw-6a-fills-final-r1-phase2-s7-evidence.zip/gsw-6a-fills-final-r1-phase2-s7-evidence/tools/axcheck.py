"""axcheck.py <census.log> <targets-scan.txt> <out>: (gsw-6a-fills phase 2) checks the AxiomsLand probe log.
targets-scan.txt: sorryscan.py output at #359 d154c883 (`module: n: name, ...`), plus TreeCircuit.const_eval.
For each target, the unique census DECL of its module whose name equals or ends with `.<name>` must have axioms within
{propext, Classical.choice, Quot.sound}. Also: every census constant's axioms within that set (no sorryAx anywhere), no
TRACE line, and every `#print axioms` result of the probe's tail."""
import sys, re
log, scan, out = sys.argv[1:4]
STD = {'propext', 'Classical.choice', 'Quot.sound'}
t = open(log, encoding='utf-8', errors='replace').read()
decl = {}
allax = []
for m in re.finditer(r'^(DECL|AUX)\t(\S+)\t(\S+)\t\[(.*)\]$', t, re.M):
    ax = {x.strip() for x in m.group(4).split(',') if x.strip()}
    allax.append((m.group(1), m.group(2), m.group(3), ax))
    decl.setdefault(m.group(2), []).append((m.group(3), ax))
traces = re.findall(r'^TRACE\t.*$', t, re.M)
targets = []
for l in open(scan):
    m = re.match(r'^(\S+): \d+: (.*)$', l.strip())
    if m:
        for n in m.group(2).split(', '): targets.append((m.group(1).replace('/', '.'), n))
targets.append(('TCSlib.Complexity.CircuitComplexity.FormulaArith.Combinators', 'TreeCircuit.const_eval'))
lines = []; bad = 0
for mod, n in targets:
    c = [(d, ax) for d, ax in decl.get(mod, []) if d == n or d.endswith('.' + n)]
    if len(c) != 1:
        lines.append(f'AMBIGUOUS/MISSING\t{mod}\t{n}\t{[d for d, _ in c]}'); bad += 1; continue
    d, ax = c[0]; ok = ax <= STD; bad += not ok
    lines.append(f'{"OK" if ok else "BAD"}\t{d}\t{sorted(ax)}')
nonstd = [(k, mo, n, sorted(ax)) for k, mo, n, ax in allax if not ax <= STD]
pa = re.findall(r"^'([^']+)' (depends on axioms: \[[^\]]*\]|does not depend on any axioms)", t, re.M)
with open(out, 'w') as f:
    f.write('\n'.join(lines) + '\n')
    f.write(f'TARGETS {len(targets)} bad {bad}\n')
    f.write(f'CENSUS constants {len(allax)}; non-standard {len(nonstd)} {nonstd[:20]}; TRACE lines {len(traces)}\n')
    for n, a in pa: f.write(f'PRINT {n} :: {a}\n')
print(open(out).read().split('\n')[-len(pa)-4:] and '\n'.join(open(out).read().split('\n')[len(lines):]))
