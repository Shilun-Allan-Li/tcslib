#!/usr/bin/env bash
# rule10_land7.sh <series> <phase>... (6a landing branch, re-replay on olean snapshot #7, maintainer, 2026-11-17):
# phase 2's rule10_land.sh re-pointed to the final merged head 93ae671e (log/head2.txt, export wtx2) and the #7 replay tree. Changes: X=$SP/g6aland7,
# TREE=$SP/olean-replay-6a-land7; touched.json regenerated against the records tip 555f0fe1 (snapshot #7's Lean + #365's
# Group.lean; its files part equals phase 2's). Probe prefixes, owners, tools and gating are unchanged, so probe sources
# compare byte for byte with phase 2's.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/g6aland7; E=$X; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RUN="bash $SP/g6aland/tools/gated_full.sh"
C=TCSlib.Complexity.CircuitComplexity; BPm=TCSlib.Complexity.BranchingPrograms
LANDMODS="$BPm.Defs $BPm.Eval $BPm.Barrington $BPm.BarringtonConverse $BPm.NC1 $BPm $C.FormulaArith.Combinators $C.FormulaArith.CarrySave $C.FormulaArith.Compare $C.FormulaArith.ModSum $C.FormulaArith $C.NANDForm $C.NANDLayering $C.Basic $C.Adder $C.TreeDAG $C.DAGCircuit $C.DAGTransform $C.TreeNCAC $C.Hierarchy $C TCSlib.ComputationalModels"
PP=G6aSeal; H=$(cat $X/log/head2.txt); W=$X/wtx2; TREE=$SP/olean-replay-6a-land7
case $1 in
land) NAME=land; MODS=$LANDMODS; TJ=$E/statements/touched-land.json;;
root) NAME=root; MODS=TCSlib; PP=G6aRoot; TJ=$E/statements/touched-land.json;;
*) echo "unknown series $1"; exit 2;;
esac
shift
R=$E/rule10/$NAME
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$X/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP $X/tmp
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6a landing $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  $RUN $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
controls)
  rm -rf $W/$PP/K; python3 -I $X/tools/mkctl_g6aland.py $G $R/seals-coe/A $W $PP/K $R/controls-coe > $R/mkctl-coe.log
  (cd $W && ls $PP/K/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/control-queue.txt
  $RUN $W $R/order/control-queue.txt $TREE $R/control-runs > $R/control-runner.out 2>&1
  python3 -I $T/review/ctlcheck2.py $R/controls-coe/controls-plan.json $R/control-runs $R/ctlcheck-coe.json > $R/ctlcheck-coe.log || true
  cat $R/mkctl-coe.log $R/ctlcheck-coe.log;;
scan)
  S=$E/scan/$NAME; mkdir -p $S
  SF=$(cat $X/decls2/changed-files.txt | grep '/')
  echo $SF > $S/files.txt
  SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W $TJ $S/items-head.json $W/$PP/ScanKindsHead.lean $SF > $S/scan1.out 2>&1
  cp $W/$PP/ScanKindsHead.lean $S/ScanKindsHead.lean.txt
  echo $PP/ScanKindsHead > $S/order.txt
  $RUN $W $S/order.txt $TREE $S/runs > $S/scan-runner.out 2>&1
  python3 -I $T/scan2.py $S/items-head.json $S/runs/mods/${PP}_ScanKindsHead.log $S/explicit-head.json > $S/scan2-head.log 2>&1; echo "scan2 rc=$?";;
probes)
  D=$E/probes/$NAME; mkdir -p $D $W/G6aProbe; : > $D/order.txt
  for p in $PROBES; do cp $PSRC/$p.lean $W/G6aProbe/$p.lean; cp $PSRC/$p.lean $D/$p.lean.txt; echo G6aProbe/$p >> $D/order.txt; done
  $RUN $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
