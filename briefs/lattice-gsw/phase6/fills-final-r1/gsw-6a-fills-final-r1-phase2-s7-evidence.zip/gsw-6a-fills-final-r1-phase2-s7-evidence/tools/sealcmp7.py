"""sealcmp7.py <new rule10 dir> <old rule10 dir> (6a land re-replay on #7): per coe-A record of the 22 owners, compares
the new run with phase 2's: request sets (rows[].spelling), every other record field except rev, the probe source, rc
and error lines, the failing declarations (sealsum TSV) and the whole probe log; lists the fields that differ."""
import sys, os, json, re, hashlib
N, O = sys.argv[1:3]
h = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
def tsv(d):
    r = {}
    for l in open(os.path.join(d, 'seals-coe-A.tsv')):
        f = l.rstrip('\n').split('\t'); r[f[0]] = f
    return r
def res(d):
    r = {}
    for l in open(os.path.join(d, 'seal-runs', 'results.jsonl')):
        x = json.loads(l)
        if 'module' in x: r[x['module'].split('/')[-1]] = x
    return r
tn, to, rn, ro = tsv(N), tsv(O), res(N), res(O)
labels = sorted(f[:-5] for f in os.listdir(os.path.join(N, 'seals-coe/A')) if f.endswith('.json') and f != 'manifest.json')
same_all = 0
for L in labels:
    a = json.load(open(f'{N}/seals-coe/A/{L}.json')); b = json.load(open(f'{O}/seals-coe/A/{L}.json'))
    diff = sorted(k for k in set(a) | set(b) if k != 'rev' and a.get(k) != b.get(k))
    sa = {r['spelling'] for r in a['rows']}; sb = {r['spelling'] for r in b['rows']}
    src = h(f'{N}/seals-coe/A/{L}.lean.txt') == h(f'{O}/seals-coe/A/{L}.lean.txt')
    lg = f'G6aSeal_ZC_{L}.log'
    ln, lo = f'{N}/seal-runs/mods/{lg}', f'{O}/seal-runs/mods/{lg}'
    logeq = h(ln) == h(lo)
    en = re.findall(r'^\S+: error.*$', open(ln, errors='replace').read(), re.M)
    eo = re.findall(r'^\S+: error.*$', open(lo, errors='replace').read(), re.M)
    fail = tn[L][1:] == to[L][1:]
    ok = not diff and sa == sb and src and logeq and en == eo and fail and rn[L]['rc'] == ro[L]['rc']
    same_all += ok
    print(f"{L}: requests {len(sa)} set-equal {sa == sb} (+{sorted(sa - sb)[:5]} -{sorted(sb - sa)[:5]}); fields differing (besides rev) {diff}; "
          f"probe source equal {src}; rc {rn[L]['rc']}/{ro[L]['rc']}; error lines {len(en)} equal {en == eo}; sealsum row equal {fail}; probe log byte-equal {logeq}")
print(f'compared {len(labels)}; identical in every respect but rev: {same_all}')
