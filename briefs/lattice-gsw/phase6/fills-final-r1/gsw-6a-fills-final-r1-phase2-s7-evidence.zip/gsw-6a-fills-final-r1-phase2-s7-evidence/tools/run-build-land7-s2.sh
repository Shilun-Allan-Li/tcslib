#!/usr/bin/env bash
# run-build-land7-s2.sh [queue]: run-build-land7.sh for stage 2 (the second merge 93ae671e: #365's Group.lean
# downstream), with export wtx2 and logdir s2/build; same tree $SP/olean-replay-6a-land7, runner, slot and disk gates.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
B=$SP/g6aland7; OUT=$SP/olean-replay-6a-land7; RUNNER=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/runner.py
Q=${1:-$B/s2/plan/queue.txt}; E=$B/s2/build; WX=$B/wtx2
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$B/tmp
mkdir -p $E/one $B/tmp
echo "start $(date -u +%FT%TZ) queue $Q" >> $E/runner.start; df -m / | tail -1 >> $E/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $E/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $E/slot-log.txt
  echo "$m" > $E/one/order.txt
  python3 -I $RUNNER $WX $E/one/order.txt $OUT $E < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $E/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $E/runner.exit; exit 2; }
done < $Q
echo "runner exit 0 $(date -u +%FT%TZ)" >> $E/runner.exit; df -m / | tail -1 >> $E/runner.exit
