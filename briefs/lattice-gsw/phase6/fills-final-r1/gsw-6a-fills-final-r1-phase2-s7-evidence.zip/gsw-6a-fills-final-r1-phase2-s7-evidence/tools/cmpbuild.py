"""cmpbuild.py <keys-vs-s6.tsv> <new-tree> <old-tree> <new-logdir> <old-logdir> <out.tsv> (6a land re-replay on #7):
for each rebuilt module, compares the new olean and module log byte-wise with the #6 run's (phase 2), and reports the
counts by closure-key class (same key at e4d77a5e as at ccca6f80 / different key)."""
import sys, os, hashlib, json, collections
kf, nt, ot, nl, ol, out = sys.argv[1:7]
h = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
def last(d):
    r = {}
    for l in open(os.path.join(d, 'results.jsonl')):
        x = json.loads(l)
        if 'module' in x: r[x['module']] = x
    return r
NR, OR = last(nl), last(ol)
cnt = collections.Counter(); rows = []
for l in open(kf):
    m, cls = l.rstrip('\n').split('\t')
    lg = m.replace('/', '_') + '.log'
    oe = h(f'{nt}/{m}.olean') == h(f'{ot}/{m}.olean')
    le = h(f'{nl}/mods/{lg}') == h(f'{ol}/mods/{lg}')
    w = (NR[m]['warnings'], NR[m]['sorry'], OR.get(m, {}).get('warnings'), OR.get(m, {}).get('sorry'))
    cnt[(cls, oe, le)] += 1; rows.append((m, cls, oe, le) + w)
with open(out, 'w') as o:
    o.write('module\tkey\tolean_equal\tlog_equal\twarn_new\tsorry_new\twarn_s6\tsorry_s6\n')
    for r in rows: o.write('\t'.join(map(str, r)) + '\n')
for k, v in sorted(cnt.items()): print(f'key {k[0]} olean_equal {k[1]} log_equal {k[2]}: {v}')
same = [r for r in rows if r[1] == 'same']
print('same-key modules', len(same), 'olean byte-equal', sum(r[2] for r in same), 'log byte-equal', sum(r[3] for r in same))
dw = [r for r in rows if r[1] == 'diff' and (r[4], r[5]) != (r[6], r[7])]
print('diff-key modules whose warning/sorry counts differ from the #6 run:', len(dw), [r[0] + f' {r[4]}/{r[5]} vs {r[6]}/{r[7]}' for r in dw])
