"""frontload.py <wtx> <queue> <seeds> <out>: reorder an imports-first queue so that the queue modules in the upstream
closure of <seeds> come first (in queue order), then the rest (in queue order). Checks the result is imports-first
over the queue (every local import that is in the queue appears earlier) and is a permutation of the queue."""
import sys, re, os
wtx, q, seeds, out = sys.argv[1:5]
Q = [l.strip() for l in open(q) if l.strip()]; QS = set(Q)
imps = {}
def I(m):
    if m not in imps:
        s = open(os.path.join(wtx, m + '.lean'), encoding='utf-8').read()
        imps[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', s, re.M) if i.split('.')[0] in ('TCSlib', 'audits')]
    return imps[m]
up = set(); st = [l.strip() for l in open(seeds) if l.strip()]
while st:
    m = st.pop()
    if m in up: continue
    up.add(m); st.extend(I(m))
first = [m for m in Q if m in up]; rest = [m for m in Q if m not in up]
R = first + rest
assert sorted(R) == sorted(Q)
pos = {m: i for i, m in enumerate(R)}
for m in R:
    for i in I(m):
        if i in QS: assert pos[i] < pos[m], (m, i)
open(out, 'w').write(''.join(m + '\n' for m in R))
print(f'queue {len(Q)}; front {len(first)}; rest {len(rest)}; imports-first OK')
