"""dupsweep.py <wtx> <helpers.txt> <mathlib-root>... : quick duplication sweep (maintainer, gsw-6a-fills phase 2).
For each private helper (file:line:decl) and each extra name given on PROMOTED (env, space-separated full names):
(1) name hits: declarations of the same short name elsewhere in TCSlib/ and audits/ of <wtx> (any namespace, private or
not), and in the given Mathlib/Batteries/core roots (`theorem|lemma|def <name>` with any namespace prefix);
(2) duplicate bodies: helpers whose normalized text (docstring excluded, whitespace collapsed, short name kept) is
identical to another helper's. Prints one TSV row per helper: file, short name, tcslib hits, library hits, same-body."""
import sys, os, re
wtx, hf = sys.argv[1], sys.argv[2]; roots = sys.argv[3:]
rows = []
for l in open(hf):
    f, ln, rest = l.rstrip('\n').split(':', 2)
    m = re.match(r'private (?:theorem|lemma|def|abbrev)\s+(\S+)', rest)
    rows.append((f, int(ln), m.group(1)))
for n in os.environ.get('PROMOTED', '').split():
    rows.append(('PROMOTED', 0, n))
def short(n): return n.split('.')[-1]
decl = re.compile(r'^\s*(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|nonrec)\s+)*(?:theorem|lemma|def|abbrev)\s+(\S+)', re.M)
tc = {}
for base in ('TCSlib', 'audits'):
    for r, ds, fs in os.walk(os.path.join(wtx, base)):
        for x in fs:
            if x.endswith('.lean'):
                p = os.path.join(r, x); s = open(p, encoding='utf-8').read()
                for m in decl.finditer(s):
                    tc.setdefault(short(m.group(1)), []).append(os.path.relpath(p, wtx) + ':' + str(s.count('\n', 0, m.start()) + 1))
lib = {}
want = {short(n) for _, _, n in rows}
for root in roots:
    for r, ds, fs in os.walk(root):
        if '.lake' in r.split(os.sep)[len(root.split(os.sep)):]: continue
        for x in fs:
            if x.endswith('.lean'):
                p = os.path.join(r, x)
                try: s = open(p, encoding='utf-8').read()
                except Exception: continue
                for m in decl.finditer(s):
                    k = short(m.group(1))
                    if k in want: lib.setdefault(k, []).append(p + ':' + str(s.count('\n', 0, m.start()) + 1))
def body(f, ln):
    L = open(os.path.join(wtx, f), encoding='utf-8').read().split('\n'); i = ln - 1; out = [L[i]]; i += 1
    while i < len(L) and not re.match(r'^(/--|@\[|private |theorem |lemma |def |abbrev |end |namespace |section |open |variable |noncomputable |instance |/-!)', L[i]):
        out.append(L[i]); i += 1
    return ' '.join(' '.join(out).split())
bodies = {}
for f, ln, n in rows:
    if f != 'PROMOTED': bodies.setdefault(body(f, ln), []).append(f'{f}:{n}')
print('file\thelper\ttcslib_other_decls_same_short_name\tlibrary_decls_same_short_name\tsame_body_as')
for f, ln, n in rows:
    k = short(n)
    own = f'{f}:{ln}' if f != 'PROMOTED' else None
    th = [h for h in tc.get(k, []) if h != own]
    sb = [] if f == 'PROMOTED' else [x for x in bodies[body(f, ln)] if x != f'{f}:{n}']
    print(f'{f}\t{n}\t{";".join(th) or "-"}\t{";".join(lib.get(k, [])) or "-"}\t{";".join(sb) or "-"}')
