# splitle.py <combined.diff> <outdir>: split the recorded landing-edits-proposed.diff into one file per (LE, path),
# named <le>__<basename>.diff, by the '# LE-gfN' comment headers and 'diff --git' lines. Prints the index.
import sys, os, re
src, out = sys.argv[1], sys.argv[2]
le = None; cur = None; chunks = {}
order = []
for line in open(src, encoding='utf-8').read().split('\n')[:-1]:
    m = re.match(r'^# (LE-gf\d)\b', line)
    if m:
        le = m.group(1); cur = None; continue
    if line.startswith('#'):
        continue
    m = re.match(r'^diff --git a/(\S+) b/', line)
    if m:
        cur = (le, m.group(1)); order.append(cur); chunks[cur] = []
    chunks[cur].append(line)
for k in order:
    fn = os.path.join(out, '%s__%s.diff' % (k[0], os.path.basename(k[1])))
    open(fn, 'w', encoding='utf-8').write('\n'.join(chunks[k]) + '\n')
    print(k[0], k[1], len(chunks[k]), fn)
