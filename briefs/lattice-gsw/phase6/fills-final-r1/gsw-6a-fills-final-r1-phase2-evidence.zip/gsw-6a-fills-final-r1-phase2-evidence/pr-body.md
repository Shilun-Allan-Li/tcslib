The **GSW phase 6a fills**: all **98** 6a targets are proved. That is 97 admitted targets proved by the fills, plus `const_eval`, which LE-g45 already proved. They cover branching programs, both directions of Barrington's theorem, the NC¹ corollary, the DAG-to-NAND conversion and its layering, and formula arithmetic. The work is the in-house units U1–U3, U8 and U6 and the external `gsw-6a-fills` delivery (U4, U5, U7, U9, U10, U11), with the four ruled landing edits. Every 6a file has **0 `sorry`**.

**Stacks #358, #359 and #360 and contains them.** The branch starts at the records tip `036d8239` (Lean-equal to olean snapshot #6, T `8060f6b7`). It merges #358 (`a616adca`), #359 (`d154c883`, with LE-g45/LE-g45b) and #360 (`cc05f76c`) as signed `--no-ff` merges, and then adds 16 commits. Merging #358, #359 and #360 first shrinks this diff to those 16 commits; GitHub then shows only the fills and the landing edits.

**Head:** `ccca6f804552f72b400c09e7a3bd694371bdf568`. All 19 commits on the first-parent line are signed (`gpgsig`). The new 6a files are under `Complexity/`.

## Commits by unit
1. Merges: `49f88fef` #358, `76efe1ba` #359, `32ec2ef5` #360.
2. **#360 addendum 2 (LE-gf3, part 1)**, `40c7215c`: four public lemmas, promoted from the fills' private copies (statements and proofs are the worker's, verbatim). Each docstring has the formula and "Glue.". The names are clash-free in TCSlib, audits, Mathlib, Batteries and core.
   - `Basic.lean`: `TreeCircuit.maxDepth_le_of_forall`, `TreeCircuit.maxFaninL_le_of_forall`.
   - `Adder.lean`: `prefixVal_eq_of_false`, `prefixVal_testBit`.
3. **In-house units**, landed as content commits, not merges (the in-house branches' merges of #359/#360 are not carried):
   - `c7fb15ee` **U1/U2**: `Defs` and `Eval` (C1–C8, 16 declarations), with the blobs of `fill/gsw-6a-u1-u2` `f31382a5`.
   - `bec8eefd` **U3**: `Barrington` (C9–C16, 11). The in-house diff is applied by a three-way merge onto #359's file, so LE-g45/45b's docstrings are kept. The merge is clean and line-for-line equal to the in-house diff.
   - `2ddada22` **U8**: `Combinators` (F1–F3, 23), from `fill/gsw-6a-u8-u6` `b65668a9` by a three-way merge onto #359. The one conflict was `const_eval`'s body, and **LE-g45's proof** (from `eval_node_nil`) was kept. Every other line of the in-house diff applies unchanged.
   - `e0d3e537` **U6**: `NANDForm` (N1–N6, 6), with the blob of `b65668a9`.
4. **External units** (exchange `60703442`, worker head `bb7efa82` on base `05999162`), cherry-picked with `-S`. The worker's messages and authorship are kept unchanged. Its own session trailers were kept and no maintainer trailer was added. `git range-diff 05999162..bb7efa82` against these 7 commits is **7/7 `=`**. The 7 patches reproduce `bb7efa82` hash for hash on `mkbase.sh`'s base.
   - U4 `e2b7020c` (C17–C21) and `2f38e2b9` (helper sketch), `BarringtonConverse`;
   - U5 `80de2e4e`, `NC1` (C22–C25);
   - U9 `72bfcab0`, `CarrySave` (F5–F6);
   - U10 `1bf78b47`, `Compare` (F7–F8);
   - U11 `153811f1`, `ModSum` (F9–F10);
   - U7 `bf8aef14`, `NANDLayering` (N7–N13).
5. **Landing edits**, as separate signed commits. They are the recorded `landing-edits-proposed.diff` (SHA-256 `01c07a11…`) verbatim; the 8 edited files equal `bb7efa82` with that diff applied.
   - `91e2f807` **LE-gf1** (GF-F01, ruling GF-W4 A). C23/C24 use Mathlib's `Nat.pow_log_le_add_one` instead of re-deriving it (+5/−8).
   - `c1a444f2` **LE-gf3, part 2** (GF-F02, ruling GF-W1 A). It deletes the 14 private copies (BarringtonConverse 2, CarrySave 3, Compare 6, ModSum 3) and makes CarrySave's `depth_getD_le`/`maxFanin_getD_le` public. The uses are qualified (+36/−168).
   - `22636300` **LE-gf2** (GF-F04, ruling GF-W2 A, Seyoon's freeze exception). One sentence of the frozen `layerNAND` docstring is updated (+3/−2).
   - `ccca6f80` **LE-gf4** (GF-F03, ruling GF-W5 A). F9 uses `Finset.sum_le_card_nsmul` (+6/−6). **It compiles, so it is kept.**

## Rulings applied (2026-11-17)
- GF-W1: repaid at landing by LE-gf3, with no ledger row.
- GF-W2: LE-gf2.
- GF-W3: `NANDLayering` is accepted at 947 lines. It is 948 after LE-gf2's rewrap, still under 1,000.
- GF-W4/W5: LE-gf1 and LE-gf4.

## Checks
All checks were run on olean snapshot #6, never with `lake build`. The full record is `briefs/lattice-gsw/phase6/fills-final-r1/phase2.md`.
- **Replay:** a `cp -al` copy of snapshot #6 (`olean-replay-6a-land`), with the Mathlib overlay (3346 symlinks, NthRootLemmas `c0a9cff0…`). The 6 new Mathlib imports (4 external, 2 in-house) resolve. The whole downstream of the 23 changed files was built: **564 modules** (551 existing and 13 new), one Lean process at a time.
  - Result: **rc 0 and 0 errors** (`error:` and `error(`) for all 564.
  - State check over the full 1,445-module order: **RESULT OK**.
  - All 564 rebuilt oleans have link count 1, with hashes equal to their records.
  - Snapshot #6 rehash before and after: 0/0/0.
  - Warnings are SAME as the baseline logs in 540 modules. The other 24 have no baseline log of the same source, and all 24 have 0 warnings.
  - The 15 orphan modules outside the root closure (RazborovSmolensky, LMN concentration) are not in the snapshot and were not built. None of the six new or now-public names occurs anywhere in TCSlib outside its home, so no clash can reach them.
- **Admissions:**
  - **0 `sorry`** in all 13 6a modules (0 warnings of any kind).
  - Library-wide: **192 in 44 modules, equal to snapshot #6 module by module** (syntactic scan at `8060f6b7` and at the head). The per-module `sorry` warnings of the 564 rebuilt modules equal the scan (103), and the reused modules hold the other 89.
- **Axioms:**
  - All 98 targets: `propext`/`Classical.choice`/`Quot.sound` only.
  - The census of the 13 modules and TreeNCAC: 859 constants, 0 non-standard, and **0 `sorryAx` traces**.
  - `layerNAND`, `layerNAND_gates`, `layerNAND_output`, `toNANDForm`, `const_eval`, `eval_node_nil` and the six new public lemmas: standard only (`prefixVal_eq_of_false`: `propext` only).
- **decls2** against the tip: **289 ADDED, 1 REMOVED, 0 CHANGED.**
  - ADDED = #358/#359 (268) + #360 (15) + the 6 public lemmas.
  - The REMOVED entry is `eval_node_nil` leaving `Hierarchy`; it is re-added in `Combinators` (LE-g45's move).
  - decls2 strips comments, so LE-gf2 does not show as CHANGED.
  - Merge-tree head minus the #360 merge: exactly the 6 ADDED.
- **Rule 10:**
  - **Canonical coe-A** on the 22 changed owners (the 13 6a modules, Basic, Adder, TreeDAG, DAGCircuit, DAGTransform, TreeNCAC, Hierarchy, the CircuitComplexity facade, ComputationalModels): every 6a owner has 0 errors. The failures are only the pre-existing ones, with the same declarations as the recorded runs: Adder 3, DAGTransform 11, TreeNCAC 2, Hierarchy 2, TreeDAG 25. **0 new failures.**
  - Request sets equal the worker's final-head records for BarringtonConverse, CarrySave, Compare, ModSum and NANDLayering. NC1 has +1 (`barrington_recognizes.match_1_1`, from in-house U3).
  - Root coe-A: 14,098 requests, 0 errors (14,074 on #5).
  - **Paired controls** for the 4 promoted and the 2 newly public lemmas: ALL_OK, with 6 sealed negatives failing exactly once and every positive passing. Attempt 1 had a control-statement defect in the two getD positives, which left `U` implicit; it is kept on record.
  - Explicit-unfold scan of the changed files: **0 new foreign** against the tip, and 3 removed (by O1 and LE-g45).
- **Lint:** `campaign_style_lint --check8b` gives 25 FAIL / 390 WARN at both tip and head, with equal FAIL sets. The only WARN changes are shorter check-8 lists from #360's readers. `style_lint` on the changed files: findings equal the tip's. 0 added lines over 100 characters.
- **Duplication sweep:** the 6 public lemmas and the 75 remaining private helpers in the 6a files were searched by name in TCSlib, audits, Mathlib, Batteries and core, and by body. No duplicate was found. The name hits are glue over Mathlib (`IsFiveCycle.*`) or Barrington's program-level lift of Defs' `Instr.isPermutation_ofPerm`.

## Disclosed
- In-house frozen docstrings are now stale. They are left as frozen, for a docstring follow-up like LE-g45b:
  - `Defs:32`, `Eval:35`, `Barrington:32` say "targets admitted with `sorry`";
  - `NANDForm:61` and `:455` say "While N2 is admitted, `sorryAx` reaches `toNANDForm`".
- `NANDLayering` is 948 lines (GF-W3 accepted 947; LE-gf2 rewraps one line).
- LE-gf3's size: the review's summary said +68/−154, but the recorded diff applies as +72/−168 (addendum +36, part 2 +36/−168).
- The in-house units had no external review before this PR. Their phase-2 checks are the ones above.
- **Base:** this branch is on tip `036d8239`. #347/#355 have since merged (tip `acd66709`). `git merge-tree` with it is clean and shares no file, but 3 tip-changed modules are in this branch's rebuilt set (`Cryptography/Games`, `ZeroKnowledge`, `Encryption/PublicKey/Trapdoor`). Rebasing onto the new tip and re-replaying on snapshot #7 is a follow-up before merge.
- The replay output `olean-replay-6a-land` is **not adoptable** after #347/#355; its map (Mathlib excluded) is 1476 entries, `5f48b3e4…`.

Gate: to be staged (Codex)

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA
