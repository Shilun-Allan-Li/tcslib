import TCSlib.Complexity.BranchingPrograms.Defs
import TCSlib.Complexity.BranchingPrograms.Eval
import TCSlib.Complexity.BranchingPrograms.Barrington
import TCSlib.Complexity.BranchingPrograms.BarringtonConverse
import TCSlib.Complexity.BranchingPrograms.NC1
import TCSlib.Complexity.BranchingPrograms
import TCSlib.Complexity.CircuitComplexity.FormulaArith.Combinators
import TCSlib.Complexity.CircuitComplexity.FormulaArith.CarrySave
import TCSlib.Complexity.CircuitComplexity.FormulaArith.Compare
import TCSlib.Complexity.CircuitComplexity.FormulaArith.ModSum
import TCSlib.Complexity.CircuitComplexity.FormulaArith
import TCSlib.Complexity.CircuitComplexity.NANDForm
import TCSlib.Complexity.CircuitComplexity.NANDLayering
import TCSlib.Complexity.CircuitComplexity.TreeNCAC
import TCSlib.Complexity.CircuitComplexity.Basic
import TCSlib.Complexity.CircuitComplexity.Adder
import TCSlib.Complexity.CircuitComplexity.Hierarchy
open Lean Elab Command

/-! gsw-6a-fills phase 2 (maintainer), landing branch land/gsw-6a-fills: the statement-phase axiom census
(AxiomsStmt.lean, body unchanged: every constant of the 13 6a modules and TreeNCAC with its axioms, and a `sorryAx`
dependency trace), followed by the axioms of the LE-gf3 public lemmas, the `layerNAND` family, `toNANDForm`,
`const_eval` and `eval_node_nil`. -/

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [
    `TCSlib.Complexity.BranchingPrograms.Defs,
    `TCSlib.Complexity.BranchingPrograms.Eval,
    `TCSlib.Complexity.BranchingPrograms.Barrington,
    `TCSlib.Complexity.BranchingPrograms.BarringtonConverse,
    `TCSlib.Complexity.BranchingPrograms.NC1,
    `TCSlib.Complexity.BranchingPrograms,
    `TCSlib.Complexity.CircuitComplexity.FormulaArith.Combinators,
    `TCSlib.Complexity.CircuitComplexity.FormulaArith.CarrySave,
    `TCSlib.Complexity.CircuitComplexity.FormulaArith.Compare,
    `TCSlib.Complexity.CircuitComplexity.FormulaArith.ModSum,
    `TCSlib.Complexity.CircuitComplexity.FormulaArith,
    `TCSlib.Complexity.CircuitComplexity.NANDForm,
    `TCSlib.Complexity.CircuitComplexity.NANDLayering,
    `TCSlib.Complexity.CircuitComplexity.TreeNCAC]
  let names := env.header.moduleNames
  let idxs := mods.filterMap env.getModuleIdx?
  let inMods (n : Name) : Bool := match env.getModuleIdxFor? n with
    | some i => idxs.contains i | none => false
  -- constants of the modules whose own type or value mentions `sorryAx` directly
  let mut direct : Std.HashSet Name := {}
  for (n, c) in env.constants.toList do
    if inMods n then
      let v := (c.value? (allowOpaque := true)).getD (mkConst `True)
      if (c.type.getUsedConstants ++ v.getUsedConstants).contains ``sorryAx then
        direct := direct.insert n
  let mut out : Array String := #[]
  for (n, c) in env.constants.toList do
    let some i := env.getModuleIdxFor? n | continue
    if idxs.contains i then
      let axs ← liftCoreM (Lean.collectAxioms n)
      let tag := if n.isInternal then "AUX" else "DECL"
      let axl := axs.qsort (·.toString < ·.toString) |>.toList
      out := out.push s!"{tag}\t{names[i.toNat]!}\t{n}\t{axl}"
      if axs.contains ``sorryAx then
        -- walk the closure inside the modules
        let mut seen : Std.HashSet Name := {}
        let mut stack : Array Name := #[n]
        let mut via : Array Name := #[]
        while !stack.isEmpty do
          let m := stack.back!
          stack := stack.pop
          if seen.contains m then continue
          seen := seen.insert m
          if direct.contains m then via := via.push m
          let some cm := env.find? m | continue
          let v := (cm.value? (allowOpaque := true)).getD (mkConst `True)
          for d in cm.type.getUsedConstants ++ v.getUsedConstants do
            if inMods d && !seen.contains d then stack := stack.push d
        let vl := via.qsort (·.toString < ·.toString) |>.toList
        out := out.push s!"TRACE\t{n}\tvia {vl}"
  for l in out.qsort (· < ·) do
    IO.println l

#print axioms BoolCircuit.TreeCircuit.maxDepth_le_of_forall
#print axioms BoolCircuit.TreeCircuit.maxFaninL_le_of_forall
#print axioms BoolCircuit.prefixVal_eq_of_false
#print axioms BoolCircuit.prefixVal_testBit
#print axioms BoolCircuit.FormulaArith.depth_getD_le
#print axioms BoolCircuit.FormulaArith.maxFanin_getD_le
#print axioms BoolCircuit.DAGCircuit.layerNAND
#print axioms BoolCircuit.DAGCircuit.layerNAND_gates
#print axioms BoolCircuit.DAGCircuit.layerNAND_output
#print axioms BoolCircuit.DAGCircuit.toNANDForm
#print axioms BoolCircuit.TreeCircuit.const_eval
#print axioms BoolCircuit.eval_node_nil
#check @BoolCircuit.TreeCircuit.maxDepth_le_of_forall
#check @BoolCircuit.TreeCircuit.maxFaninL_le_of_forall
#check @BoolCircuit.prefixVal_eq_of_false
#check @BoolCircuit.prefixVal_testBit
#check @BoolCircuit.FormulaArith.depth_getD_le
#check @BoolCircuit.FormulaArith.maxFanin_getD_le
