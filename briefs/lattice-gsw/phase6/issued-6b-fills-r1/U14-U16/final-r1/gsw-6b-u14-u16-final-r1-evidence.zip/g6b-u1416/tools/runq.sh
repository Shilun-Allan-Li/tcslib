#!/usr/bin/env bash
# g6b-u1416 phase 2 (the g6b-u1213 runq.sh, slot log moved): run a queue one module at a time through the recipe's runner.py
# (or runner_full.py), checking before EACH Lean start that the host has at most 2 other Lean processes
# (`pgrep -fc "bin/lean "`, so this job's start keeps the machine at <= 3) and at least 2,000 MB free; waits while full,
# stops on low disk. rc is read from the module's own record.
# Usage: runq.sh <runner.py|runner_full.py> <worktree> <queue> <tree> <logdir> <stop-on-fail 0|1>
set -u
RUN=$1; W=$2; Q=$3; TREE=$4; LOG=$5; STOP=$6
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
SLOT=$SP/g6b-u1416/logs/slot.log
mkdir -p "$LOG"
while read -r m; do
  [ -z "$m" ] && continue
  while :; do
    n=$(pgrep -fc "bin/lean ")
    free=$(df -BM --output=avail / | tail -1 | tr -dc 0-9)
    if [ "$free" -lt 2000 ]; then echo "DISK-STOP ${free}M before $m $(date -u +%FT%TZ)" | tee -a "$SLOT"; exit 3; fi
    [ "$n" -le 2 ] && break
    echo "wait slots=$n before $m $(date -u +%FT%TZ)" >> "$SLOT"; sleep 30
  done
  echo "start $m slots=$n disk=${free}M $(date -u +%FT%TZ)" >> "$SLOT"
  printf '%s\n' "$m" > "$LOG/one.txt"
  python3 -I "$RUN" "$W" "$LOG/one.txt" "$TREE" "$LOG" >> "$LOG/runner.out" 2>&1
  rc=$(python3 -I -c 'import sys,json
r=[json.loads(l) for l in open(sys.argv[1]) if l.strip()]
r=[x for x in r if x.get("module")==sys.argv[2]]
print(r[-1]["rc"] if r else "none")' "$LOG/results.jsonl" "$m")
  echo "end $m rc=$rc $(date -u +%FT%TZ)" >> "$SLOT"
  if [ "$rc" != "0" ] && [ "$STOP" = "1" ]; then echo "STOP at $m rc=$rc" >> "$SLOT"; exit 1; fi
done < "$Q"
echo "QUEUE-DONE $Q $(date -u +%FT%TZ)" >> "$SLOT"
