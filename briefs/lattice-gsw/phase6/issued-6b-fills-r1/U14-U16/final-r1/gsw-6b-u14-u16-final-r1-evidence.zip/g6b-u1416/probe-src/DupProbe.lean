import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Leveled

/-! g6b-u1416 phase 2: duplication probes. `exact?` on the inline facts and the private helper of the fill, each
stated with exactly the hypotheses its use has (Gate 53 G53-01: a probe without them proves nothing), to see whether a
published Mathlib or TCSlib lemma states them. An `exact?` failure is the expected "no lemma" answer; a hit that is a
computation (`rfl`/`decide`) or a composition of cited lemmas is not a restatement. Evidence only. -/

set_option maxHeartbeats 400000

open TCSlib.Cryptography TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW

-- D1 (G13 `four_pow_clog_le`, inner step `h2`): for `y ≥ 1`, `2 ^ ⌈log₂ y⌉ ≤ 2 * y`.
example (y : ℕ) (hy : 1 ≤ y) : 2 ^ Nat.clog 2 y ≤ 2 * y := by exact?

-- D2 (G13 `four_pow_clog_le`, its statement): for `y ≥ 1`, `4 ^ ⌈log₂ y⌉ ≤ 4 * y ^ 2`.
example (y : ℕ) (hy : 1 ≤ y) : 4 ^ Nat.clog 2 y ≤ 4 * y ^ 2 := by exact?

-- D3 (the general form of D1): `b ^ clog b y ≤ b * y` for `1 < b`, `1 ≤ y`.
example (b y : ℕ) (hb : 1 < b) (hy : 1 ≤ y) : b ^ Nat.clog b y ≤ b * y := by exact?

-- D4 (L3 `hm`): the message of a NOT literal, `(!b).toNat = 1 - b.toNat` in `ℤ`.
example (b : Bool) : (((!b).toNat : ℕ) : ℤ) = 1 - ((b.toNat : ℕ) : ℤ) := by exact?

-- D5 (G12 `hs`): an LWE sample is `(A, noisyValues A s e)` of its seed.
example (P : LWE.Parameters) (χ : LWE.Noise)
    (r : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      ((Fin P.dimension → ZMod P.modulus) × (Fin P.samples → χ.Coins))) :
    LWE.sample P χ r = (r.1, LWE.noisyValues P r.1 r.2.1 (fun i => χ.sample (r.2.2 i))) := by exact?

-- D6 (`encrypts_bootGate` `hG`): the gadget decrypts to `true` under every key.
example (P : Parameters) (s : Secret P) : decrypt P s (gadget P) = true := by exact?

-- D7 (G12 `hle`): a noise bound is at most its bootstrapped noise (`N ≥ 1` by the instance).
example (P : Parameters) (β : ℕ) : β ≤ bootNoise P β := by exact?
