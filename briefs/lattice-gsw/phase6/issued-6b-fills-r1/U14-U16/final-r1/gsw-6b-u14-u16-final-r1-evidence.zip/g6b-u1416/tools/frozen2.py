"""Independent frozen check: normalise the head file back to the base by (1) replacing each
target's proof body by the base body, (2) replacing each target's sketch region (from
'**Proof sketch.**' to the docstring end) by the base region, (3) deleting `private` declarations
(docstring + body) that do not exist at base, (4) replacing the module admission sentence by the
base one.  Reports headers and statement prose compared exactly, then whether the normalised head
equals the base byte for byte.  Usage: frozen.py BASE HEAD TARGETS(comma) BASESENT HEADSENT
g6b-u1416 extension (frozen2.py): optional ALLOWED-PUBLIC-NAME and MAINLINES-FILE.  (5) the one allowed new
public theorem (docstring + body, one separating blank line) is deleted, and must sit directly after the
target named first in TARGETS-order 'AFTER' (6th arg form NAME@AFTER@BEFORE); (6) the exact lines of
MAINLINES-FILE, which must occur once, consecutively, are deleted from the module docstring."""
import re, sys
def load(p): return open(p, encoding='utf-8').read().split('\n')
def decl_start(L, name):
    pat = re.compile(r'^(?:theorem|lemma) ' + re.escape(name) + r'(\s|$)')
    hits = [i for i, l in enumerate(L) if pat.match(l)]
    assert len(hits) == 1, (name, hits)
    return hits[0]
def header_end(L, s):
    i = s
    while not L[i].rstrip().endswith(':= by'): i += 1
    return i
def body_end(L, h):  # exclusive
    i = h + 1
    while i < len(L) and L[i].strip() != '' and not L[i].startswith('end '): i += 1
    return i
def doc_start(L, s):
    i = s - 1
    while not L[i].startswith('/--'): i -= 1
    return i
def sketch_line(L, d, s):
    for i in range(d, s):
        if '**Proof sketch.**' in L[i]: return i
    return None
def parts(L, name):
    s = decl_start(L, name); h = header_end(L, s); e = body_end(L, h); d = doc_start(L, s)
    k = sketch_line(L, d, s)
    pre = L[d:k] + [L[k].split('**Proof sketch.**')[0]] if k is not None else L[d:s]
    skt = ([L[k][len(L[k].split('**Proof sketch.**')[0]):]] + L[k+1:s]) if k is not None else []
    return dict(s=s, h=h, e=e, d=d, k=k, header=L[s:h+1], prose=pre, sketch=skt, body=L[h+1:e])
base, head = load(sys.argv[1]), load(sys.argv[2])
targets = sys.argv[3].split(',')
bsent, hsent = sys.argv[4], sys.argv[5]
ok = True
H = list(head)
# process targets bottom-up in the head so indices stay valid
info = []
for t in targets:
    pb, ph = parts(base, t), parts(H, t)
    hdr = pb['header'] == ph['header']; pro = pb['prose'] == ph['prose']
    print(f'{t}: header {"IDENTICAL" if hdr else "DIFFERS"} ({len(pb["header"])} lines); '
          f'prose {"IDENTICAL" if pro else "DIFFERS"}; sketch {"same" if pb["sketch"]==ph["sketch"] else "refreshed"}; '
          f'base body {pb["body"]}; head body {len(ph["body"])} lines')
    ok &= hdr and pro
for t in sorted(targets, key=lambda t: -parts(H, t)['s']):
    pb, ph = parts(base, t), parts(H, t)
    H[ph['h']+1:ph['e']] = pb['body']
    if ph['k'] is not None:
        pre_k = H[ph['k']].split('**Proof sketch.**')[0]
        bk = pb['sketch']
        H[ph['k']:ph['s']] = [pre_k + bk[0]] + bk[1:]
# delete private decls absent at base
i = 0; removed = []
while i < len(H):
    m = re.match(r'^private (?:theorem|lemma|def) (\S+)', H[i])
    if m and not any(re.match(r'^private (?:theorem|lemma|def) ' + re.escape(m.group(1)) + r'\b', l) for l in base):
        d = doc_start(H, i); e = body_end(H, header_end(H, i))
        # also drop one separating blank line before the docstring
        if H[d-1].strip() == '': d -= 1
        removed.append((m.group(1), e - d)); del H[d:e]; continue
    i += 1
print('private declarations removed (new):', removed)
if len(sys.argv) > 6:
    name, after, before = sys.argv[6].split('@')
    hits = [i for i, l in enumerate(H) if re.match(r'^theorem ' + re.escape(name) + r'(\s|$)', l)]
    assert len(hits) == 1, ('public', name, hits)
    i = hits[0]; d = doc_start(H, i); e = body_end(H, header_end(H, i))
    pa = parts(H, after); pb_ = parts(H, before)
    placed = pa['e'] == d - 1 and H[d-1].strip() == '' and pb_['d'] == e + 1 and H[e].strip() == ''
    print(f'allowed public {name}: {e - d} lines (docstring + declaration); directly after {after} and before {before}:', placed)
    ok &= placed
    if H[d-1].strip() == '': d -= 1
    del H[d:e]
if len(sys.argv) > 7:
    ml = open(sys.argv[7], encoding='utf-8').read().rstrip('\n').split('\n')
    idx = [i for i in range(len(H)) if H[i:i+len(ml)] == ml]
    print('main-results lines found:', len(idx))
    assert len(idx) == 1
    del H[idx[0]:idx[0]+len(ml)]
txt = '\n'.join(H)
n = txt.count(hsent)
assert n == 1, ('head sentence count', n)
txt = txt.replace(hsent, bsent)
eq = txt == '\n'.join(base)
print('normalised head == base:', eq)
if not eq:
    import difflib
    for l in difflib.unified_diff('\n'.join(base).split('\n'), txt.split('\n'), lineterm='', n=1): print(l)
print('RESULT', 'PASS' if ok and eq else 'FAIL')
