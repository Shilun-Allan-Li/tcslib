import os, sys, collections
def check(root, man, base=''):
    rows=[l.rstrip('\n') for l in open(os.path.join(root,man),encoding='utf-8') if l.strip()]
    paths=[r.split('  ',1)[1] if '  ' in r else r.split(' *',1)[1] for r in rows]
    dup=[p for p,c in collections.Counter(paths).items() if c>1]
    lead=[p for p in paths if p.startswith('./')]
    files=set()
    for dp,dn,fn in os.walk(root):
        for f in fn:
            files.add(os.path.relpath(os.path.join(dp,f),root))
    ps=set(paths)
    print(f'{root} {man}: rows={len(rows)} files={len(files)} dup={len(dup)} leading./={len(lead)} selflisted={man in ps}')
    print('  missing-from-manifest:', sorted(files-ps-{man})[:20])
    print('  listed-not-present:', sorted(ps-files)[:20])
for u in sys.argv[1:]:
    check(u,'SHA256SUMS'); check(os.path.join(u,'evidence'),'SHA256SUMS')
