#!/usr/bin/env bash
# g6b-u1213 phase 2: one unit alone on snapshot #11: cp -al copy, Mathlib overlay (symlinks; the NthRootLemmas olean
# hard-linked from this job's stack tree, where mathlibextra.sh built it as c0a9cff0...), plan at the unit head, build
# through runq.sh, accept (permod, stateplan update/check, link counts). Usage: alone.sh <name> <head>
set -eu
N=$1; H=$2
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/g6b-u1213; T=$G/recipe/olean-advance-a6d01b1b/tools-used; W=$G/wt; R=/home/user/tcslib; B=bff0567b6c4b6b724c8fd20ff3ef92258eb3fc9d
OUT=$G/olean-replay-$N; A=$G/alone/$N; mkdir -p $A
test ! -e $OUT
git -C $W checkout -q --detach $H; test "$(git -C $W rev-parse HEAD)" = "$H"
cp -al $SP/olean-snapshot $OUT
bash $T/mloverlay.sh $OUT > $A/mloverlay.log
X=Mathlib/Analysis/SpecialFunctions/Pow/NthRootLemmas.olean; ln $G/olean-replay/$X $OUT/$X; sha256sum $OUT/$X > $A/nthroot.sha256
python3 -I $T/downorder.py $R $H $B $A/order > $A/downorder.log
python3 -I $T/fullorder.py $R $H $A/full-order.txt > $A/fullorder.log
python3 -I $T/stateplan.py init $R $B $SP/olean-snapshot.files-bff0567b.txt $A/state.json > $A/init.log
python3 -I $T/stateplan.py plan $R $H $A/full-order.txt $A/state.json $A/plan > $A/plan.log
bash $G/tools/runq.sh $T/runner.py $W $A/plan/queue.txt $OUT $A/build 1
python3 -I $T/permod.py $A/build $A/build/permod.tsv > $A/permod.log 2>&1
python3 -I $T/stateplan.py update $R $H $A/state.json $A/build/results.jsonl $OUT > $A/update.log
python3 -I $T/stateplan.py check $R $H $A/full-order.txt $A/state.json $OUT $A/check.txt > $A/check.log
(cd $OUT && find . -name '*.olean' -type f -links 1 | sort) > $A/links1.txt
(cd $OUT && find . -name '*.olean' -type f -links 1 | sort | xargs sha256sum) > $A/rebuilt-oleans.sha256
python3 -I $G/tools/admissions.py /home/user/tcslib/briefs/lattice-gsw/phase6/issued-6b-fills-r1/base-sorries.txt $A/build $W > $A/admissions.txt
cat $A/downorder.log $A/plan.log; tail -1 $A/permod.log; cat $A/update.log; tail -1 $A/check.log; echo "links1 $(wc -l < $A/links1.txt)"; head -4 $A/admissions.txt
