"""mkctl.py <sealed-probe.lean> <head-source.lean> <pairs.tsv> <out-sealed.lean> <out-open.lean>: g6b-u1213 liveness
pairs appended to the canonical coe-A sealed copy of an owner (sealed) and to the owner's head source (open).
pairs.tsv: <definition>\t<reader> (full names). Per pair: NEG reads the body (`by intros; first | exact rfl | exact
Iff.rfl` on the reader's statement), POS goes through the reader. Prints the NEG/POS line numbers of both files."""
import sys
sealed, src, pairs, outs, outo = sys.argv[1:6]
P = [l.rstrip('\n').split('\t') for l in open(pairs) if l.strip() and not l.startswith('#')]
for base, out, tag in ((sealed, outs, 'sealed'), (src, outo, 'open')):
    L = open(base, encoding='utf-8').read().rstrip('\n').split('\n')
    L += ['', 'set_option linter.unusedTactic false', 'set_option linter.unreachableTactic false', '']
    for i, (d, r) in enumerate(P, 1):
        L.append(f'section G6bCtl{i}')
        L.append(f'example : type_of% @{r} := by intros; first | exact rfl | exact Iff.rfl'); neg = len(L)
        L.append(f'example : type_of% @{r} := @{r}'); pos = len(L)
        L.append(f'end G6bCtl{i}')
        print(f'{tag}\t{i}\t{d}\t{r}\tNEG {neg}\tPOS {pos}')
    open(out, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
