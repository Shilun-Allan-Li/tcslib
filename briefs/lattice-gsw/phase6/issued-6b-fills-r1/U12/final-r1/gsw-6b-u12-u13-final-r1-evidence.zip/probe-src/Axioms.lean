import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Branching
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.DecryptFormula
open Lean Elab Command

/-! g6b-u1213 phase 2: axiom census of every constant stored by `GSW/Branching` (U12) and `GSW/DecryptFormula` (U13)
(the recipe's `AxiomProbe.r2.lean` form), the nine targets by name, and a `sorry` control. -/

theorem g6bSorryControl : (1 : Nat) = 2 := sorry

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Branching,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.DecryptFormula]
  let pfx := `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW
  let targets : List Name := [`Encrypts.select, `encrypts_homEvalPBP, `encrypts_homEvalFormula,
    `vecMul_secretVector_eq_sum, `decryptFormula_eval, `nandFormula_eval, `depth_nandFormula_le,
    `maxFanin_nandFormula_le, `decDepth_le].map (pfx ++ ·)
  let idxs := mods.filterMap env.getModuleIdx?
  IO.println s!"OWNERS\t{mods.length}\t{idxs.length}"
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        let mi := (env.header.moduleNames[i.toNat]!).toString
        out := out.push s!"{tag}\t{mi.splitOn "." |>.getLast!}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    | none => pure ()
  for n in targets do
    if env.contains n then
      let axs ← liftCoreM (Lean.collectAxioms n)
      out := out.push s!"TARGET\t-\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    else
      out := out.push s!"MISSING\t-\t{n}\t-"
  for l in out.qsort (· < ·) do
    IO.println l
  let c ← liftCoreM (Lean.collectAxioms `g6bSorryControl)
  IO.println s!"CONTROL\tg6bSorryControl\t{c.toList}"

#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Encrypts.select
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypts_homEvalPBP
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypts_homEvalFormula
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.vecMul_secretVector_eq_sum
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decryptFormula_eval
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.nandFormula_eval
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.depth_nandFormula_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.maxFanin_nandFormula_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decDepth_le
