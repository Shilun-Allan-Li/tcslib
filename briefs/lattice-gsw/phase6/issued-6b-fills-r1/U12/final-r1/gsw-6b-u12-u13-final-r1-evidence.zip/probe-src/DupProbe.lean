import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Branching
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.DecryptFormula

/-! g6b-u1213 phase 2: duplication probes. `exact?` on the inline facts of the two fills, to see whether a published
Mathlib or TCSlib lemma states them (an `exact?` failure is the expected "no lemma" answer; a hit that is only a
computation or a composition of the cited lemmas is not a restatement). Evidence only. -/

set_option maxHeartbeats 400000

open TCSlib.Cryptography

-- D1 (U12, G2 `hm`): a `Pi.single _ 1` coordinate as the `toNat` of a `decide`.
example {w : ℕ} (a i : Fin w) :
    (((Pi.single a 1 : Fin w → ℕ) i : ℕ) : ℤ) = ((decide (a = i)).toNat : ℤ) := by exact?

-- D2 (U12, G2 `hι`): an instruction of a permutation program is a permutation instruction.
example {w n : ℕ} (B : BranchingProgram w n) (hB : B.IsPermutation) (ι : BranchingProgram.Instr w n)
    (h : ι ∈ B.instrs) : ι.IsPermutation := by exact?

-- D3 (U13, G6 `hval`): the representative of a Boolean-weighted sum in `ZMod q`.
example {n q : ℕ} (b : Fin n → Bool) (a : Fin n → ZMod q) :
    (∑ i, ((b i).toNat : ZMod q) * a i).val = (∑ i, (b i).toNat * (a i).val) % q := by exact?

-- D4 (U13, G6 `hlh`, `hhq`): the decoding interval lies in `[0, q]`.
example (P : LWE.Parameters) : LWE.BitEncoding.decodeLo P ≤ LWE.BitEncoding.decodeHi P := by exact?
example (P : LWE.Parameters) : LWE.BitEncoding.decodeHi P ≤ P.modulus := by exact?
