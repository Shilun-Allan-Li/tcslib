import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.PolyRatio
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Asymptotic

/-! g6b-u1517-1819 phase 2 (U18+U19): duplication probes, `exact?` on the public helper, the private glue and the inline
facts of the fill, each stated with exactly the hypotheses (and instance arguments) its use has (Gate 53 G53-01). Run at
**B6** (a tree whose `PolyRatio`/`Asymptotic` oleans are B6's, so the helper does not exist yet: E1 asks whether another
lemma already states it) and again at the U18+U19 head (E1 must then find the helper itself: positive control). K3 is a
positive control (`Nat.lt_two_pow_self`). An `exact?` failure on E1-E6 at B6 is the expected "no lemma" answer. -/

set_option maxHeartbeats 400000

open TCSlib.Cryptography TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW

-- E1 (the public helper `Parameters.ofFamily_columns_le`, its statement exactly).
example (F : TCSlib.Cryptography.LWE.Family) (κ : ℕ) :
    (Parameters.ofFamily F κ).columns ≤ (F.dimensionBound.eval κ + 1) * F.residueBits.eval κ := by
  exact?

-- E2 (G16 `hlog`, first half): `⌈log₂ n⌉ ≤ n`.
example (n : ℕ) : Nat.clog 2 n ≤ n := by exact?

-- E3 (G17 leveled `hin`, and U14-U16's G12): a noise bound is at most its bootstrapped noise.
example (P : Parameters) (β : ℕ) : β ≤ bootNoise P β := by exact?

-- E4 (the private glue `two_mul_width_lt_of_ratio`, its arithmetic core): `8·y < q` and `q ≥ 2` give `2·y < ⌊q/2⌋`.
example (q y : ℕ) (h : 8 * y < q) (h2 : 2 ≤ q) : 2 * y < q / 2 := by exact?

-- E5 (A1, A3 `h0`): the distinguishing advantage is nonnegative.
example {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) : 0 ≤ distAdv X Y D := by exact?

-- E6 (A3 `ha₀`, `ha₁`): the DLWE advantage is nonnegative.
example (P : TCSlib.Cryptography.LWE.Parameters) (χ : TCSlib.Cryptography.LWE.Noise) {ρ : Type}
    [Fintype ρ] [Nonempty ρ]
    (D : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      (Fin P.samples → ZMod P.modulus)) → ρ → Bool) :
    0 ≤ TCSlib.Cryptography.LWE.decisionAdvantage P χ D := by exact?

-- K3 (positive control; G16): `n < 2 ^ n`.
example (n : ℕ) : n < 2 ^ n := by exact?
