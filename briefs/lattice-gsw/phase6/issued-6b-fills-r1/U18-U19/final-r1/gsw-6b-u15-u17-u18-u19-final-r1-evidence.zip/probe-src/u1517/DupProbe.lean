import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Circular
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.LeveledSecurity

/-! g6b-u1517-1819 phase 2 (U15+U17): duplication probes. `exact?` on the inline facts and private helpers of the fill,
each stated with exactly the hypotheses (and instance arguments) its use has (Gate 53 G53-01), to see whether a published
Mathlib or TCSlib lemma states them. K1 and K2 are positive controls: `exact?` must find the reused lemma. An `exact?`
failure on D1-D5 is the expected "no lemma" answer. Evidence only. -/

set_option maxHeartbeats 400000

open TCSlib.Cryptography TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW
open TCSlib.Cryptography.Encryption.PublicKey

-- K1 (positive control; G15, L5): an ignored second seed factor, the shape `acceptProb_fst` states.
example {σ τ γ ρ : Type*} [Fintype σ] [Fintype τ] [Fintype ρ] [Nonempty σ] [Nonempty τ] [Nonempty ρ]
    (X : σ → γ) (D : γ → ρ → Bool) :
    acceptProb (fun z : σ × τ => X z.1) D = acceptProb X D := by exact?

-- K2 (positive control; L4's averaging): pointwise `c`-close functions have `c`-close averages.
example {α : Type*} [Fintype α] (f g : α → ℝ) (c : ℝ) (hc : 0 ≤ c) (h : ∀ a, |f a - g a| ≤ c) :
    |uexp f - uexp g| ≤ c := by exact?

-- D1 (L4, uniform-key helper `hc`): the leftover-hash error is nonnegative.
example (P : TCSlib.Cryptography.LWE.Parameters) : 0 ≤ Regev.extractionError P := by exact?

-- D2 (L5, private `leveledView_eq_levelHybrid`).
example (P : Parameters) (χ : TCSlib.Cryptography.LWE.Noise) (L : ℕ) (μ : Bool) :
    leveledView P χ L μ = levelHybrid P χ L μ L := by exact?

-- D3 (L4, per-seed step of the uniform-key helper): two bits under a uniform key, one test.
example (P : Parameters) {ρ : Type*} [Fintype ρ] [Nonempty ρ] (m₁ m₂ : Bool)
    (T : PublicKey P × Ciphertext P → ρ → Bool) :
    |acceptProb (uniformKeyView P m₁) T - acceptProb (uniformKeyView P m₂) T| ≤
      2 * (P.columns * Regev.extractionError P.lwe) := by exact?

-- D4 (L4, private `abs_acceptProb_id_levelReduction_sub_le`, its statement).
example (P : Parameters) (χ : TCSlib.Cryptography.LWE.Noise) (L : ℕ) (μ : Bool) (e : Fin L)
    (j : Fin P.columns) {ρ : Type*} [Fintype ρ] [Nonempty ρ] (D : LeveledView P L → ρ → Bool) :
    |acceptProb (id : PublicKey P → PublicKey P) (levelReduction P χ L μ e j true D) -
        acceptProb (id : PublicKey P → PublicKey P) (levelReduction P χ L μ e j false D)| ≤
      2 * (P.columns * Regev.extractionError P.lwe) := by exact?

-- D5 (L5, private `acceptProb_levelHybrid_zero_realView`, its statement).
example (P : Parameters) (χ : TCSlib.Cryptography.LWE.Noise) (L : ℕ) (μ : Bool) {ρ : Type*}
    [Fintype ρ] [Nonempty ρ] (D : LeveledView P L → ρ → Bool) :
    acceptProb (levelHybrid P χ L μ 0) D = acceptProb (realView P χ μ) (challengeDist P χ L D) := by
  exact?
