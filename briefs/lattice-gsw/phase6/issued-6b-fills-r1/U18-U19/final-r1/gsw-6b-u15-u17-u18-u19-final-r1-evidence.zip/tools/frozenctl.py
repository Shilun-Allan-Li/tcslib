"""frozenctl.py <frozen-dir> <frozen3.py>: g6b-u1517-1819 controls of the frozen check. Each control mutates one owned
head file by an exact one-occurrence substitution (the allowed helper itself is removed wholesale by frozen3, so its
statement is checked against the brief by helperstmt.py, not here) and re-runs frozen3.py with the file's real arguments; expected: every
mutation FAILs (RESULT FAIL or an abort), the unmutated heads PASS, each base against itself PASSes."""
import sys, subprocess, os
D, T = sys.argv[1:3]
args = {
 'Circular': ['distAdv_fheView_noEvk_le', '/-! ### Target G15 -/', '/-! ### Target G15 -/'],
 'LeveledSecurity': ['distAdv_levelHybrid_le,distAdv_leveledView_le', 'Both are admitted statement-phase targets.', 'Both are proved here.'],
 'PolyRatio': ['bootRatio_le_poly,decrypt_fheEval_of_ratio,decrypt_leveledEval_of_ratio', 'All three are admitted statement-phase targets.', 'All three are proved here.',
               'Parameters.ofFamily_columns_le@LINE:        F.samplesBound := rfl@LINE:/-! ### Targets G16–G17 -/', os.path.join(D, 'polyratio-mainlines.txt')],
 'Asymptotic': ['indCPA_of_dlweAssumption,leveledINDCPA_of_dlweAssumption', 'Both are admitted statement-phase targets.', 'Both are proved here.'],
}
C = [  # (file, tag, old, new)
 ('Circular', 'header', '    [Nonempty ρ] (μ₀ μ₁ : Bool) (D : PublicKey P × Ciphertext P → ρ → Bool) :', '    [Nonempty ρ] (μ₀ μ₁ : Bool) (D : PublicKey P × Ciphertext P → ρ → Bool)  :'),
 ('Circular', 'prose', 'a restatement (G45-01)', 'a restatement (G45-02)'),
 ('Circular', 'defbody', '    encrypt P (Regev.keygen P.lwe χ r.1).1 μ r.2.2)\n\n/-- `fheView P χ μ r`', '    encrypt P (Regev.keygen P.lwe χ r.1).1 (!μ) r.2.2)\n\n/-- `fheView P χ μ r`'),
 ('Circular', 'reader', 'This reader is r3\'s G14 (Q-6B-1 A).', 'This reader is r3\'s G14 (Q-6B-1 B).'),
 ('Circular', 'import', 'import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security\n', 'import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security\nimport Mathlib.Data.Nat.Log\n'),
 ('Circular', 'public', '\nend TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW', '\ntheorem g6bCtlPublic : True := trivial\n\nend TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW'),
 ('LeveledSecurity', 'header', '      ∑ j : Fin P.columns, levelTerm P χ L μ e j D := by', '      ∑ j : Fin P.columns, levelTerm P χ L μ e j D + 0 := by'),
 ('LeveledSecurity', 'prose', 'level key `e + 1`, already replaced in `H_{e+1}` (top-down order).', 'level key `e + 1`, already replaced in `H_{e+1}` (top-down  order).'),
 ('LeveledSecurity', 'defbody', '    encrypt P (Regev.keygen P.lwe χ (r.1 0)).1 μ r.2.2)\n\n/-- `leveledView P χ L μ r`', '    encrypt P (Regev.keygen P.lwe χ (r.1 0)).1 (!μ) r.2.2)\n\n/-- `leveledView P χ L μ r`'),
 ('LeveledSecurity', 'reader', '`levelTerm P χ L μ e j D` is the sum of the two DLWE advantages', '`levelTerm P χ L μ e j D` is the sum of both DLWE advantages'),
 ('LeveledSecurity', 'privdef-moved-public', 'private def levelPosHybrid', 'def levelPosHybrid'),
 ('PolyRatio', 'header', '      (pBoot F).eval κ * B κ := by', '      (pBoot F).eval κ * (B κ) := by'),
 ('PolyRatio', 'defbody', '        F.samplesBound := rfl', '        F.samplesBound  := rfl'),
 ('PolyRatio', 'mainresults', '  G16 and the asymptotic forms of `GSW/Asymptotic.lean`).', '  G16 and the asymptotic forms of `GSW/Asymptotic.lean`, and more).'),
 ('Asymptotic', 'header-heff', '(heff : ReductionEfficient F)', '(heff : True)'),
 ('Asymptotic', 'prose', 'Both are proved here. Ruling Q-6B-1 A', 'Both are proved here. Ruling Q-6B-1 B'),
 ('Asymptotic', 'deleted-target', 'theorem leveledINDCPA_of_dlweAssumption', 'theorem leveledINDCPA_of_dlweAssumption2'),
]
def run(base, head, a):
    p = subprocess.run(['python3', '-I', T, base, head] + a, capture_output=True, text=True)
    out = (p.stdout + p.stderr).strip().split('\n')
    res = [l for l in out if l.startswith('RESULT')]
    return res[-1] if res else 'ABORT ' + out[-1][:120]
ok = True
for f in args:
    r = run(f'{D}/{f}.base.lean', f'{D}/{f}.head.lean', args[f]); print(f'{f} head: {r}'); ok &= r == 'RESULT PASS'
    b = open(f'{D}/{f}.base.lean').read()
    # base against itself: the head sentence/public/mainlines do not exist at base, so only the target checks apply
    a0 = [args[f][0], args[f][1], args[f][1]]
    r = run(f'{D}/{f}.base.lean', f'{D}/{f}.base.lean', a0); print(f'{f} base-vs-base: {r}'); ok &= r == 'RESULT PASS'
for f, tag, old, new in C:
    h = open(f'{D}/{f}.head.lean', encoding='utf-8').read()
    n = h.count(old); assert n == 1, (f, tag, n)
    p = f'{D}/ctl/{f}.{tag}.lean'; os.makedirs(f'{D}/ctl', exist_ok=True)
    open(p, 'w', encoding='utf-8').write(h.replace(old, new))
    r = run(f'{D}/{f}.base.lean', p, args[f]); good = r != 'RESULT PASS'; ok &= good
    print(f'CONTROL {f} {tag}: {r} -> {"FAILS as expected" if good else "UNEXPECTED PASS"}')
print('ALL_OK' if ok else 'NOT_OK')
