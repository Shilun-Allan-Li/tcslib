#!/usr/bin/env bash
# g6b-u1517-1819: run the canonical coe-A (A) and seal-B (B) probes of one unit (already written by mkseals_coe.py into
# the worktree's G6bProbe/C) one at a time through runq.sh + runner_full.py, then sealsum.py.
# Usage: seals.sh <unit> <tree> <head> <owner-short>...
set -u
U=$1; TR=$2; H=$3; shift 3
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/g6b-u1517-1819; W=$G/wt; S=$G/recipe/olean-advance-a6d01b1b/tools-used
export TMPDIR=$G/tmp; mkdir -p $TMPDIR
test "$(git -C $W rev-parse HEAD)" = "$H" || { echo "worktree not at $H"; exit 1; }
for V in A B; do
  R=$G/seal/$U/runs-$V; mkdir -p $R; : > $R/queue.txt; echo '{"files":{}}' > $R/touched-empty.json
  for o in "$@"; do echo G6bProbe/C/Seal${V}_Cryptography_AdvancedEncryption_Homomorphic_GSW_$o >> $R/queue.txt; done
  bash $G/tools/runq.sh $S/runner_full.py $W $R/queue.txt $TR $R 0
  python3 -I $S/seal/review/sealsum.py $G/seal/$U/$V $R $R/touched-empty.json $G/seal/$U/seals-coe-$V.tsv
  cat $G/seal/$U/seals-coe-$V.tsv; grep -h "G06-SEAL" $R/mods/*.log
done
