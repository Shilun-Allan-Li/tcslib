#!/usr/bin/env bash
# g6b-u1517-1819: reproduce a delivery's patches by git am on B6 in the scratch worktree with COMMITS.tsv's
# author/committer data (unsigned); compare each hash and src/ with the head. Usage: repro.sh <deliv-dir>
set -u
D=$1; SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; W=$SP/g6b-u1517-1819/wt
B=bff0567b6c4b6b724c8fd20ff3ef92258eb3fc9d
git -C $W checkout -q --detach $B
i=0
for p in $(ls $D/patches/*.patch | sort); do
  i=$((i+1)); row=$(sed -n "$((i+1))p" $D/patches/COMMITS.tsv)
  IFS=$'\t' read -r h an ae ad cn ce cd sg <<< "$row"
  GIT_COMMITTER_NAME="$cn" GIT_COMMITTER_EMAIL="$ce" GIT_COMMITTER_DATE="$cd" git -C $W -c commit.gpgsign=false am -q --committer-date-is-author-date $p 2>&1 || { echo "am failed $p"; exit 1; }
  got=$(git -C $W rev-parse HEAD); echo "patch $i $(basename $p) expect $h got $got $([ $h = $got ] && echo MATCH || echo MISMATCH)"
done
echo "gpgsig head: $(git -C $W cat-file -p HEAD | grep -c gpgsig)"
for f in $(cd $D/src && find . -type f | sed 's|^\./||'); do cmp -s $D/src/$f $W/$f && echo "src $f == head" || echo "src $f DIFFERS"; done
git -C $W diff --stat $B HEAD
for c in $(git -C $W rev-list --reverse $B..HEAD); do echo "$(git -C $W rev-parse --short=8 $c) touches: $(git -C $W diff-tree --no-commit-id --name-only -r $c | tr '\n' ' ')"; done
