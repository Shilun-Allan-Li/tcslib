"""helperstmt.py <brief.md> <head PolyRatio.lean>: the allowed helper's header (keyword through the statement) at the head
equals the brief's fenced statement byte for byte (the head adds only ` := by`)."""
import sys, re
b = open(sys.argv[1], encoding='utf-8').read(); h = open(sys.argv[2], encoding='utf-8').read().split('\n')
m = re.search(r'```lean\n(theorem Parameters\.ofFamily_columns_le.*?)\n```', b, re.S); brief = m.group(1).split('\n')
i = [k for k, l in enumerate(h) if l.startswith('theorem Parameters.ofFamily_columns_le')]; assert len(i) == 1
head = h[i[0]:i[0] + len(brief)]
ok = head[:-1] == brief[:-1] and head[-1] == brief[-1] + ' := by'
print('brief:', *brief, sep='\n  '); print('head:', *head, sep='\n  '); print('RESULT', 'PASS' if ok else 'FAIL')
