## Scope

This is the owner-side reader PR approved by Seyoon under ruling **Q3 A** (6a review finding G6A-F03, 2026-11-17; overnight ruling 2026-11-17). It is one signed commit of **pure insertions** into five frozen owners. Each insertion is one reader placed beside the definition it reads. The 6a fill sketches (F1–F3, F7, C13, C17, C22–C24, N2, N12) cite these readers, and the reader census of the 6a statement delivery lists them as MISSING. The PR is independent of #358 and #359, and it should land before the 6a fills are issued.

- Base: `cryptography/pass-shelat-ch2-4` at `8c5875fa268a622e4e166da5f7a992715097c2c7`. This tip is Lean-equal to olean snapshot #5's T, `3f540c22`.
- Head: `land/gsw-6a-readers` at `3ea428fd8b99ffe33cdfb8dbe8068d0eb000d032`, tree `5d1f4768`. The commit is SSH-signed with key `SHA256:32dP45eS…2wc`, the same key as the tip.
- Diff: 5 files, **+69 / −0**.

## Readers (file:line at the head)

| Owner | Reader | Statement | Proof |
|---|---|---|---|
| `Basic.lean:114` | `BoolCircuit.Lit.eval_eq` | `l.eval x = if l.sign then x l.idx else !x l.idx` | `rfl` |
| `Basic.lean:217` | `BoolCircuit.TreeCircuit.depth_lit` | `(lit l).depth = 0` | `simp [TreeCircuit.depth]` |
| `Basic.lean:221` | `BoolCircuit.TreeCircuit.size_lit` | `(lit l).size = 1` | `simp [TreeCircuit.size]` |
| `Basic.lean:225` | `BoolCircuit.TreeCircuit.maxFanin_lit` | `(lit l).maxFanin = 0` | `simp [TreeCircuit.maxFanin]` |
| `Adder.lean:382` | `BoolCircuit.carryBit_zero` | `carryBit A B 0 = false` | `rfl` |
| `Adder.lean:386` | `BoolCircuit.carryBit_succ` | `carryBit A B (i + 1) = ((A i && B i) \|\| ((A i ^^ B i) && carryBit A B i))` | `rfl` |
| `DAGCircuit.lean:400` | `BoolCircuit.gatesAcyclic_iff` | `GatesAcyclic n gs ↔ ∀ (i : ℕ) (h : i < gs.length), ∀ a ∈ (gs[i]).args, a < n + i` | `Iff.rfl` |
| `DAGCircuit.lean:519` | `BoolCircuit.DAGCircuit.isWellFormed_iff` | `C.IsWellFormed ↔ ∀ g ∈ C.gates, g.args.Nodup ∧ (g.kind = .not → g.args.length = 1)` | `Iff.rfl` |
| `DAGTransform.lean:76` | `BoolCircuit.gadgetCorrect_iff` | `GadgetCorrect n c Q P emit ↔ ∀ g gs, GatesAcyclic n gs → (∀ a ∈ g.args, a < n + gs.length) → Q g.kind g.args.length → GadgetSpec n c (g.args.length + 2) P g gs (emit g gs)` | `Iff.rfl` |
| `TreeNCAC.lean:118` | `BoolCircuit.TreeCircuitFamily.isPolySize_iff` | `C.IsPolySize ↔ ∃ a k, ∀ n, (C.circuit n).size ≤ a * (n + 1) ^ k` | `Iff.rfl` |
| `TreeNCAC.lean:127` | `BoolCircuit.TreeCircuitFamily.hasFaninTwo_iff` | `C.HasFaninTwo ↔ ∀ n, (C.circuit n).maxFanin ≤ 2` | `Iff.rfl` |
| `TreeNCAC.lean:136` | `BoolCircuit.TreeCircuitFamily.hasPolylogDepth_iff` | `C.HasPolylogDepth d ↔ ∃ b, ∀ n, (C.circuit n).depth ≤ b * (Nat.log 2 n + 1) ^ d` | `Iff.rfl` |
| `TreeNCAC.lean:152` | `Language.inTreeNC_iff` | `L.InTreeNC d ↔ ∃ C, C.HasFaninTwo ∧ C.IsPolySize ∧ C.HasPolylogDepth d ∧ C.language = L` | `Iff.rfl` |

- **Docstrings:** every reader has a docstring of the form "Reader of `X`: `formula`.  Glue.", the style of the 6a statement files' readers. No source tag is given, because each reader is definitional glue.
- **Binders** follow the precedents beside each definition:
  - `gatesAcyclic_iff` has implicit binders, like `gatesAcyclic_cons`.
  - `isWellFormed_iff` and the family readers take the section variable `C` explicitly, like `isFaninTwo_iff`.
  - `Language.inTreeNC_iff (d) (L)` is explicit, like `Language.inPPoly_iff` and `inPBP_iff`.
  - `gadgetCorrect_iff` has implicit binders.
- **No reader is `@[simp]`.** A probe confirms this, so no existing `simp` call changes behaviour.
- **One change from the census's "all `rfl`":** `TreeCircuit.depth`, `size` and `maxFanin` are defined by well-founded recursion, so they are `@[irreducible]` and `rfl` fails on them. A probe confirmed the failure. The three literal readers are therefore proved from the definitions' own equations by `simp [TreeCircuit.depth]` and so on, the same way the sibling reader `eval_lit` is proved. They use only the standard axioms, as `depth_node` does.

## Pure-insertion property

- `git diff` has **0 removed lines**. For each file, deleting the inserted lines (located from the hunk positions) from the head blob gives the base blob **byte for byte** (SHA-256 compared, 5/5).
- At the declaration level (`touched.py`, base → head), 13 declarations are ADDED, 0 REMOVED, and every other declaration is UNCHANGED, with one tool artifact. `Lit.eval` is reported CHANGED only because the comment banner that followed it ("Section 2") now falls inside `Lit.eval_eq`'s span. Its own lines are unchanged.

## Checks (snapshot replay procedure, `snapshots.md`; no `lake build`, no cache get)

- **Downstream:** the 5 changed owners have **566 downstream modules** (551 in the root/Checks closure). That is above the ~150 threshold, so the full downstream replay was **not run, and is deferred**.
  - Instead, a sub-replay built the owners' import closure restricted to the changed modules and their dependents, in dependency order: `Basic`, `DAGCircuit`, `Adder`, `TreeDAG`, `DAGTransform` and `TreeNCAC`.
  - `TreeDAG` sits between the owners, so it was rebuilt too.
  - The sub-replay ran in `olean-replay-6a-readers`, a `cp -al` copy of snapshot #5.
- **Build: 6/6 rc 0**, with 0 `error:`/`error(`, 0 warnings and 0 `sorry`.
  - Every rebuilt olean has link count 1.
  - `TreeDAG`'s rebuilt olean is byte-identical to the snapshot's.
  - The state check over the owners' closure (7 modules) gives **RESULT OK**. Over the full closure, exactly the 545 deferred downstream modules are stale, as expected.
- **Snapshot #5** rehashes **0/0/0** (1458 files) before and after the run.
- **Axioms:**
  - `Lit.eval_eq`, `carryBit_zero`/`_succ`, `gatesAcyclic_iff`, `isWellFormed_iff` and `gadgetCorrect_iff` use **no axioms**.
  - The 3 literal readers and the 4 `TreeNCAC` readers use `[propext, Classical.choice, Quot.sound]`. For the `TreeNCAC` readers, these come from the well-founded definitions named in their statements: `IsPolySize`, `HasFaninTwo`, `HasPolylogDepth`, `InTreeNC` and `TreeCircuit.depth` themselves print the same three axioms.
- **Rule 10, canonical coe-A whole-file seals** of the 5 owners, at base (snapshot) and head (replay):

  | Owner | Requests (base = head) | Errors (base = head) |
  |---|---|---|
  | `Basic` | 0 | 0 |
  | `DAGCircuit` | 0 | 0 |
  | `Adder` | 58 | 3 |
  | `DAGTransform` | 174 | 11 |
  | `TreeNCAC` | 94 | 4 |

  - The request rows and the exclusions are equal at base and head. Stored constants grow by exactly the 13 readers.
  - Seal logs are **identical at base and head modulo line positions**.
  - Every failure is pre-existing and none is in a new reader:
    - `Adder`: `adderCircuit`, `adderCircuit_isFaninTwo`, `bitsVal_eq_logProg_bitsVal`.
    - `DAGTransform`: the `rewrite` family.
    - `TreeNCAC`: `maxDepth_map_le` and `maxFaninL_map_le` (G6A-F05), plus `maxFaninL_pairUp` and `sumSize_pairUp`. O1 (#358) repairs the last two and moves them.
- **Lint:**
  - `campaign_style_lint TCSlib/Complexity --check8b` gives 25 FAIL / 390 WARN at both base and head, and the FAIL lines are identical.
  - The only changes are fewer names on four check-8 WARN lines: `carryBit`; both `IsWellFormed` entries (the lint matches by name); `GadgetCorrect`; the three family predicates.
  - `style_lint` on the 5 changed files gives 0 findings, the same as at base.
- **Name clashes:** none of the 13 full names exists anywhere in `TCSlib/` or `audits/` (private included) at the tip, at #358, #359, #357, #347 or #355. The only declarations sharing a last component are other namespaces' `eval_eq` (`DAGGate`, `DAGCircuit`, GSW, and `BranchingProgram.Instr` on #359).

## Merge-tree (`git merge-tree --write-tree` of the head with each)

| PR | Head | Result | Paths shared with this PR |
|---|---|---|---|
| #358 | `a616adca` | clean | `TreeNCAC.lean` |
| #359 | `73aedcda` | clean | `TreeNCAC.lean` |
| #357 | `7a98ba01` | clean | none |
| #347 | `daa6e173` | clean | none |
| #355 | `d3c7cb00` | clean | none |

For #358 and #359, the merged `TreeNCAC.lean` is identical in both merges. It was cross-built together with each PR's `FormulaArith/Combinators.lean` on a throwaway copy of the replay: **rc 0, 0 errors**. The only warnings are #359's 24 `sorry` warnings, which are its own admitted targets.

## Audit

Audited with the 6a fills' gate or the next small-items gate, as Seyoon decides.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA
