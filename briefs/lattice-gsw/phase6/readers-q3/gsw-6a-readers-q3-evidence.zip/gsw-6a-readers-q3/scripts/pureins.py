"""pureins.py <repo> <base> <head>: for every file changed base->head, check the change is pure insertion: the diff has
no '-' lines, and deleting the inserted lines (by `git diff -U0` hunk positions) from the head blob gives the base blob
byte for byte (SHA-256 compared). Prints one row per file and RESULT."""
import sys, subprocess, re, hashlib
repo, base, head = sys.argv[1:4]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, check=True).stdout
ok = True
for f in git('diff', '--name-only', base, head).decode().split():
    d = git('diff', '-U0', base, head, '--', f).decode('utf-8')
    minus = [l for l in d.splitlines() if l.startswith('-') and not l.startswith('---')]
    ins = set()
    for m in re.finditer(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@', d, re.M):
        s, c = int(m.group(1)), int(m.group(2) or 1)
        ins.update(range(s, s + c))
    hb = git('show', f'{head}:{f}'); bb = git('show', f'{base}:{f}')
    lines = hb.split(b'\n')
    rest = b'\n'.join(l for i, l in enumerate(lines, 1) if i not in ins)
    eq = hashlib.sha256(rest).hexdigest() == hashlib.sha256(bb).hexdigest()
    ok &= eq and not minus
    print(f'{f}\tinserted {len(ins)}\tremoved {len(minus)}\thead-minus-insertions == base: {eq}\tbase sha256 {hashlib.sha256(bb).hexdigest()}')
print('RESULT', 'OK' if ok else 'FAIL')
