#!/usr/bin/env bash
# slotrun.sh <runner.py> <worktree> <order> <tree> <logdir>: run the modules of <order> one at a time through
# <runner.py> (a one-line order file per module), waiting (30 s polls) while 3 or more `lean` processes run on the
# machine (slot rule). Logs each wait and start to <logdir>/slots.log. Stops at the first failing module.
set -u
RUN=$1; W=$2; ORD=$3; TREE=$4; LD=$5; mkdir -p $LD/one
while read -r m; do
  [ -z "$m" ] && continue
  while c=$(pgrep -c -x lean); [ "$c" -ge 3 ]; do echo "$(date -u +%FT%TZ) wait lean=$c before $m" >> $LD/slots.log; sleep 30; done
  echo "$(date -u +%FT%TZ) start $m (lean running: $(pgrep -c -x lean))" >> $LD/slots.log
  echo "$m" > $LD/one/order.txt
  python3 -I $RUN $W $LD/one/order.txt $TREE $LD || { echo "$(date -u +%FT%TZ) FAIL $m" >> $LD/slots.log; exit 1; }
done < $ORD
echo "$(date -u +%FT%TZ) done" >> $LD/slots.log
