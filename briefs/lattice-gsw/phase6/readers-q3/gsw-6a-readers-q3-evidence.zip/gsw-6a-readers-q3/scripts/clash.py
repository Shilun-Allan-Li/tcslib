"""clash.py <repo> <outfile> <rev>...: for each rev, index every keyword-line declaration of every TCSlib/ and
audits/ .lean file (private included; namespace-tracked, nameclash.py's KW regex), then list every declaration that
shares the LAST name component with one of the 13 new reader names, with its full name, and flag EXACT full-name
clashes. Files are read with git show (no checkout)."""
import sys, re, subprocess
repo, out, revs = sys.argv[1], sys.argv[2], sys.argv[3:]
NEW = ['BoolCircuit.Lit.eval_eq', 'BoolCircuit.TreeCircuit.depth_lit', 'BoolCircuit.TreeCircuit.size_lit',
       'BoolCircuit.TreeCircuit.maxFanin_lit', 'BoolCircuit.carryBit_zero', 'BoolCircuit.carryBit_succ',
       'BoolCircuit.gatesAcyclic_iff', 'BoolCircuit.DAGCircuit.isWellFormed_iff', 'BoolCircuit.gadgetCorrect_iff',
       'BoolCircuit.TreeCircuitFamily.isPolySize_iff', 'BoolCircuit.TreeCircuitFamily.hasFaninTwo_iff',
       'BoolCircuit.TreeCircuitFamily.hasPolylogDepth_iff', 'Language.inTreeNC_iff']
short = {n.split('.')[-1] for n in NEW}
KW = re.compile(r'^\s*(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*(?:theorem|lemma|def|abbrev|structure|inductive|instance|class|opaque|axiom|alias)\s+([^\s(:{\[]+)')
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout
o = open(out, 'w'); total_exact = 0
for rev in revs:
    files = [f for f in git('ls-tree', '-r', '--name-only', rev, 'TCSlib', 'audits').split() if f.endswith('.lean')]
    hits = []; exact = 0
    for f in files:
        ns = []
        for i, l in enumerate(git('show', f'{rev}:{f}').splitlines()):
            m = re.match(r'^namespace\s+(\S+)', l)
            if m: ns.append(m.group(1)); continue
            m = re.match(r'^end\s+(\S+)\s*$', l)
            if m and ns and ns[-1] == m.group(1): ns.pop(); continue
            m = KW.match(l)
            if m:
                n = m.group(1)
                if n.split('.')[-1] not in short: continue
                full = n[7:] if n.startswith('_root_.') else '.'.join(ns + [n])
                hits.append((full, f, i + 1, full in NEW))
    exact = sum(h[3] for h in hits); total_exact += exact
    o.write(f'== rev {rev}: {len(files)} files; same-last-component declarations {len(hits)}; EXACT {exact}\n')
    for h in hits: o.write(f'{"EXACT " if h[3] else ""}{h[0]}\t{h[1]}:{h[2]}\n')
o.write(f'TOTAL EXACT {total_exact}\n'); print(open(out).read())
