"""insert.py <worktree>: the GSW 6a Q3 owner-side readers, as pure insertions after exact anchor lines."""
import sys, os
wt = sys.argv[1]
D = 'TCSlib/Complexity/CircuitComplexity/'
# (file, anchor line (exact, must occur once), text inserted right after it)
INS = [
 (D + 'Basic.lean', '  if l.sign then x l.idx else !x l.idx\n',
  '\n/-- Reader of `Lit.eval`: `l.eval x = if l.sign then x l.idx else !x l.idx`.  Glue. -/\n'
  'theorem Lit.eval_eq (l : Lit n) (x : Fin n → Bool) :\n'
  '    l.eval x = if l.sign then x l.idx else !x l.idx := rfl\n'),
 (D + 'Basic.lean', '  cs.foldr (fun c acc => max c.maxFanin acc) 0\n',
  '\n/-- Reader of `TreeCircuit.depth` on a leaf: `(lit l).depth = 0`.  Glue. -/\n'
  'theorem TreeCircuit.depth_lit (l : Lit n) : (TreeCircuit.lit l).depth = 0 := @@DEPTH@@\n'
  '\n/-- Reader of `TreeCircuit.size` on a leaf: `(lit l).size = 1`.  Glue. -/\n'
  'theorem TreeCircuit.size_lit (l : Lit n) : (TreeCircuit.lit l).size = 1 := @@SIZE@@\n'
  '\n/-- Reader of `TreeCircuit.maxFanin` on a leaf: `(lit l).maxFanin = 0`.  Glue. -/\n'
  'theorem TreeCircuit.maxFanin_lit (l : Lit n) : (TreeCircuit.lit l).maxFanin = 0 := @@MAXFANIN@@\n'),
 (D + 'Adder.lean', '  | i + 1 => (A i && B i) || ((A i ^^ B i) && carryBit A B i)\n',
  '\n/-- Reader of `carryBit` at position `0`: `carryBit A B 0 = false`.  Glue. -/\n'
  'theorem carryBit_zero (A B : ℕ → Bool) : carryBit A B 0 = false := rfl\n'
  '\n/-- Reader of `carryBit` at position `i + 1`:\n'
  '`carryBit A B (i + 1) = ((A i && B i) || ((A i ^^ B i) && carryBit A B i))`.  Glue. -/\n'
  'theorem carryBit_succ (A B : ℕ → Bool) (i : ℕ) :\n'
  '    carryBit A B (i + 1) = ((A i && B i) || ((A i ^^ B i) && carryBit A B i)) := rfl\n'),
 (D + 'DAGCircuit.lean', '  ∀ (i : ℕ) (h : i < gs.length), ∀ a ∈ (gs[i]).args, a < n + i\n',
  '\n/-- Reader of `GatesAcyclic`:\n'
  '`GatesAcyclic n gs ↔ ∀ (i : ℕ) (h : i < gs.length), ∀ a ∈ (gs[i]).args, a < n + i`.  Glue. -/\n'
  'theorem gatesAcyclic_iff {n : ℕ} {gs : List DAGGate} :\n'
  '    GatesAcyclic n gs ↔ ∀ (i : ℕ) (h : i < gs.length), ∀ a ∈ (gs[i]).args, a < n + i :=\n'
  '  Iff.rfl\n'),
 (D + 'DAGCircuit.lean', '  ∀ g ∈ C.gates, g.args.Nodup ∧ (g.kind = .not → g.args.length = 1)\n',
  '\n/-- Reader of `IsWellFormed`:\n'
  '`C.IsWellFormed ↔ ∀ g ∈ C.gates, g.args.Nodup ∧ (g.kind = .not → g.args.length = 1)`.  Glue. -/\n'
  'theorem isWellFormed_iff :\n'
  '    C.IsWellFormed ↔ ∀ g ∈ C.gates, g.args.Nodup ∧ (g.kind = .not → g.args.length = 1) :=\n'
  '  Iff.rfl\n'),
 (D + 'DAGTransform.lean', '    GadgetSpec n c (g.args.length + 2) P g gs (emit g gs)\n',
  '\n/-- Reader of `GadgetCorrect`: `GadgetCorrect n c Q P emit ↔ ∀ g gs, GatesAcyclic n gs →\n'
  '(∀ a ∈ g.args, a < n + gs.length) → Q g.kind g.args.length →\n'
  'GadgetSpec n c (g.args.length + 2) P g gs (emit g gs)`.  Glue. -/\n'
  'theorem gadgetCorrect_iff {c : ℕ} {Q : GateKind → ℕ → Prop} {P : DAGGate → Prop}\n'
  '    {emit : DAGGate → List DAGGate → List DAGGate × ℕ} :\n'
  '    GadgetCorrect n c Q P emit ↔\n'
  '      ∀ g gs, GatesAcyclic n gs → (∀ a ∈ g.args, a < n + gs.length) → Q g.kind g.args.length →\n'
  '        GadgetSpec n c (g.args.length + 2) P g gs (emit g gs) :=\n'
  '  Iff.rfl\n'),
 (D + 'TreeNCAC.lean', '  ∃ a k : ℕ, ∀ n, (C.circuit n).size ≤ a * (n + 1) ^ k\n',
  '\n/-- Reader of `IsPolySize`: `C.IsPolySize ↔ ∃ a k, ∀ n, (C.circuit n).size ≤ a * (n + 1) ^ k`.\n'
  'Glue. -/\n'
  'theorem isPolySize_iff :\n'
  '    C.IsPolySize ↔ ∃ a k : ℕ, ∀ n, (C.circuit n).size ≤ a * (n + 1) ^ k :=\n'
  '  Iff.rfl\n'),
 (D + 'TreeNCAC.lean', '  ∀ n, (C.circuit n).maxFanin ≤ 2\n',
  '\n/-- Reader of `HasFaninTwo`: `C.HasFaninTwo ↔ ∀ n, (C.circuit n).maxFanin ≤ 2`.  Glue. -/\n'
  'theorem hasFaninTwo_iff : C.HasFaninTwo ↔ ∀ n, (C.circuit n).maxFanin ≤ 2 :=\n'
  '  Iff.rfl\n'),
 (D + 'TreeNCAC.lean', '  ∃ b : ℕ, ∀ n, (C.circuit n).depth ≤ b * (Nat.log 2 n + 1) ^ d\n',
  '\n/-- Reader of `HasPolylogDepth`:\n'
  '`C.HasPolylogDepth d ↔ ∃ b, ∀ n, (C.circuit n).depth ≤ b * (Nat.log 2 n + 1) ^ d`.  Glue. -/\n'
  'theorem hasPolylogDepth_iff (d : ℕ) :\n'
  '    C.HasPolylogDepth d ↔ ∃ b : ℕ, ∀ n, (C.circuit n).depth ≤ b * (Nat.log 2 n + 1) ^ d :=\n'
  '  Iff.rfl\n'),
 (D + 'TreeNCAC.lean', '    C.HasFaninTwo ∧ C.IsPolySize ∧ C.HasPolylogDepth d ∧ C.language = L\n',
  '\n/-- Reader of `Language.InTreeNC`: `L.InTreeNC d ↔ ∃ C : TreeCircuitFamily, C.HasFaninTwo ∧\n'
  'C.IsPolySize ∧ C.HasPolylogDepth d ∧ C.language = L`.  Glue. -/\n'
  'theorem Language.inTreeNC_iff (d : ℕ) (L : Language Bool) :\n'
  '    L.InTreeNC d ↔ ∃ C : BoolCircuit.TreeCircuitFamily,\n'
  '      C.HasFaninTwo ∧ C.IsPolySize ∧ C.HasPolylogDepth d ∧ C.language = L :=\n'
  '  Iff.rfl\n'),
]
PROOFS = dict(DEPTH=os.environ.get('P_DEPTH', 'rfl'), SIZE=os.environ.get('P_SIZE', 'rfl'),
              MAXFANIN=os.environ.get('P_MAXFANIN', 'rfl'))
for f in sorted({i[0] for i in INS}):
    p = os.path.join(wt, f); s = open(p, encoding='utf-8').read()
    for (ff, anchor, text) in INS:
        if ff != f: continue
        for k, v in PROOFS.items(): text = text.replace('@@' + k + '@@', v)
        c = s.count(anchor)
        if c != 1: sys.exit(f'{f}: anchor occurs {c} times: {anchor!r}')
        s = s.replace(anchor, anchor + text)
    open(p, 'w', encoding='utf-8').write(s)
    print('edited', f)
