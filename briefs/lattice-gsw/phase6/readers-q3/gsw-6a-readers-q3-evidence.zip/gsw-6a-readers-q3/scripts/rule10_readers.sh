#!/usr/bin/env bash
# rule10_readers.sh <series> <phase>... (gsw-6a owner-side readers PR, 2026-11-17): the re-replay's rule10_g6a5.sh
# (g6a-r5/scripts) re-pointed to this PR. Changes: (1) series base (wt-base at the records tip, tree = snapshot #5, read
# only: runner_full never writes) and head (wt at the PR head, tree = olean-replay-6a-readers); owners = the 5 changed
# modules. (2) touched-<series>.json: touched.py base->head (head) and base->base (base). (3) phases collect, coeA only.
# (4) runner_full_slots.py (runner_full.py + the slot wait) instead of runner_full.py; SEAL_CHUNK=1000; seal tools
# unchanged (g6a-p2/tools/seal).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/g6a-readers; E=$X/ev; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RF=$X/scripts/runner_full_slots.py
B=$(cat $E/base.txt); HD=$(cat $E/head.txt)
C=TCSlib.Complexity.CircuitComplexity
MODS="$C.Basic $C.DAGCircuit $C.Adder $C.DAGTransform $C.TreeNCAC"
FILES="TCSlib/Complexity/CircuitComplexity/Basic.lean TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean TCSlib/Complexity/CircuitComplexity/Adder.lean TCSlib/Complexity/CircuitComplexity/DAGTransform.lean TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean"
PP=G6aRdSeal
case $1 in
base) W=$X/wt-base; TREE=$SP/olean-snapshot; NAME=base; H=$B;;
head) W=$X/wt; TREE=$SP/olean-replay-6a-readers; NAME=head; H=$HD;;
*) echo "unknown series $1"; exit 2;;
esac
shift
R=$E/rule10/$NAME; TJ=$E/rule10/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TMPDIR=$X/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP $TMPDIR
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
touched)
  python3 -I $T/review/touched.py /home/user/tcslib $B $H $TJ $FILES > $E/rule10/touched-$NAME.tsv;;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6a readers $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  python3 -I $RF $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  python3 -I $RF $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
