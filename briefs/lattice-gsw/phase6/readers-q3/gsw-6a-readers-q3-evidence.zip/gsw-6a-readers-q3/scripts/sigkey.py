"""sigkey.py <repo> <commit>...: SSHSIG public-key fingerprint (SHA256, base64 unpadded, as ssh-keygen -l) of each commit's
gpgsig header; no verification of the signature itself (no ssh-keygen on this host)."""
import sys, subprocess, base64, hashlib, struct
repo = sys.argv[1]
for c in sys.argv[2:]:
    raw = subprocess.run(['git', '-C', repo, 'cat-file', '-p', c], capture_output=True, text=True, check=True).stdout
    if '-----BEGIN SSH SIGNATURE-----' not in raw: print(c, 'NO SSH SIGNATURE'); continue
    body = raw.split('-----BEGIN SSH SIGNATURE-----', 1)[1].split('-----END SSH SIGNATURE-----', 1)[0]
    blob = base64.b64decode(''.join(l.strip() for l in body.splitlines()))
    assert blob[:6] == b'SSHSIG'; i = 10
    n = struct.unpack('>I', blob[i:i + 4])[0]; pk = blob[i + 4:i + 4 + n]; i += 4 + n
    n = struct.unpack('>I', blob[i:i + 4])[0]; ns = blob[i + 4:i + 4 + n]
    kt = pk[4:4 + struct.unpack('>I', pk[:4])[0]].decode()
    fp = base64.b64encode(hashlib.sha256(pk).digest()).decode().rstrip('=')
    print(c, 'SSHSIG', kt, 'namespace=' + ns.decode(), 'SHA256:' + fp)
