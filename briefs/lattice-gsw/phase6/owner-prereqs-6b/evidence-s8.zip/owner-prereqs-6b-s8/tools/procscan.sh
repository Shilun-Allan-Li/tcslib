#!/usr/bin/env bash
# procscan.sh <dir>: lists processes (other than this script's own tree) whose cwd, open fds or cmdline reference <dir>.
D=$1; me=$$
for p in /proc/[0-9]*; do pid=${p#/proc/}; [ "$pid" = "$me" ] && continue
  pp=$(awk '{print $4}' $p/stat 2>/dev/null); [ "$pp" = "$me" ] && continue
  { readlink $p/cwd; ls -l $p/fd 2>/dev/null; } 2>/dev/null | grep -qF "$D" && echo "uses: $pid $(tr '\0' ' ' < $p/cmdline 2>/dev/null | cut -c1-150)"
  tr '\0' '\n' < $p/cmdline 2>/dev/null | grep -qxF -e "$D" -e "$D/" && echo "arg: $pid"
done; echo scan-done
