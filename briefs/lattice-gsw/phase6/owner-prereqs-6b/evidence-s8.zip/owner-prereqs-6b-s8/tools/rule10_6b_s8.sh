#!/usr/bin/env bash
# rule10_6b_s8.sh <head> <phase>... (gsw-6b owner prerequisites, re-replay on snapshot #8): the #7 run's rule10_6b.sh with
# only the paths and revs re-pointed. Owners GSW.Scheme and Encryption.PublicKey.EnsembleSecurity; base = snapshot #8's
# T 2dd2e60e (statements only), head = R = merge-tree(tip, 1953898b) = ab098201 (export wtx, tree olean-replay-6b-prereq8).
# Every probe goes through gated_full.sh (runner_full.py, `lean` without -o, nothing written to a tree; slot check before
# each probe, wait while 3 or more lean processes run). Tools: g6a-p2/tools/seal (unmodified).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G0=$SP/g6bprereq8; E=$G0; T=$SP/g6a-p2/tools/seal; A=$T/review/archived-gate10-tools; RUN="bash $G0/tools/gated_full.sh"
BASE=2dd2e60ed0cdd4681a7bd12fe4a86825e98db664; HEADC=ab098201a13ad10829914bfbc6bedcbb2fe52e9e
side=$1; shift
case $side in
head) W=$G0/wtx; TREE=$SP/olean-replay-6b-prereq8; H=$HEADC;;
*) echo "side?"; exit 2;;
esac
export GIT_DIR=/home/user/tcslib/.git TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
OWN="TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Scheme TCSlib.Cryptography.Encryption.PublicKey.EnsembleSecurity"
FILES="TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean"
P=G6bPre; R=$E/rule10/$side; TJ=$E/statements/touched.json
mkdir -p $E/tmp $E/statements $R/order $R/probe-sources $W/$P
for ph in "$@"; do
echo "phase $ph side $side start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
statements)
  python3 -I $T/review/touched.py /home/user/tcslib $BASE $HEADC $TJ $FILES > $E/statements/touched.tsv 2>&1; echo "touched rc=$?";;
collect)
  printf '%s\n' $OWN > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6b owner prerequisites collector" $W/$P/CollectHead.lean
  cp $W/$P/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$P/CollectHead\n" > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
sealcoeA)
  LOG=$R/probe-runs/mods/${P}_CollectHead.log
  ( cd $T && python3 -I $T/review/mkseals_coe.py $A $LOG $W $H $R/seals-coe/A $P/C SealA_ $OWN > $R/mkseals-coe-A.log ); echo "mkseals_coe rc=$?"
  (cd $W && ls $P/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-queue.txt
  for f in $W/$P/C/*.lean; do cp $f $R/probe-sources/$(basename $f).txt; done
  $RUN $W $R/order/seal-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1; echo "seal runner rc=$?"
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv; echo "sealsum rc=$?"
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
esac
echo "phase $ph side $side done $(date -u +%FT%TZ)"
done
