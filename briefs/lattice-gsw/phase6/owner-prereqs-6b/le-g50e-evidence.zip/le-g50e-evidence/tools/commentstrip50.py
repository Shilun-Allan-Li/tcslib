"""commentstrip50.py <repo> <revA> <revB|DIR:<worktree>> <controls.json> <path>...  (LE-g50d/LE-g50e)
LE-g45b's commentstrip45b.py with the per-file controls read from a JSON file instead of a built-in table; the
strip() function is copied verbatim (removes `--` line comments and nested `/- ... -/` block comments, which
covers `/--` docstrings and `/-!` module docs, honouring string and char literals).  Compares the stripped texts
of <revA>:<path> and <revB>:<path> (or the worktree file) byte for byte.
Mutation controls on each revB file, each must give DIFFER: M1 one space after the first code `:=`;
M2 one code-token substitution (JSON "m2": [old, new], occurring once); M3 one code line commented out
(JSON "m3": line, occurring once).  Negative control N1 (JSON "n1": [old, new], a docstring/comment
word change, occurring once) must stay EQUAL.  Exit 1 on any DIFFER, uncaught mutation or failed N1."""
import sys, subprocess, hashlib, os, json

IDCH = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.!?\'')

def strip(s):
    out = []; i = 0; n = len(s); depth = 0; com = 0
    while i < n:
        if depth:
            if s.startswith('/-', i): depth += 1; i += 2; com += 2; continue
            if s.startswith('-/', i): depth -= 1; i += 2; com += 2; continue
            i += 1; com += 1; continue
        c = s[i]
        if c == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1; continue
        if c == "'" and (i == 0 or s[i - 1] not in IDCH and not s[i - 1].isalnum()):
            if i + 2 < n and s[i + 1] != '\\' and s[i + 2] == "'":
                out.append(s[i:i + 3]); i += 3; continue
            if i + 3 < n and s[i + 1] == '\\' and s[i + 3] == "'":
                out.append(s[i:i + 4]); i += 4; continue
        if s.startswith('/-', i): depth = 1; i += 2; com += 2; continue
        if s.startswith('--', i):
            j = s.find('\n', i)
            j = n if j < 0 else j
            com += j - i; i = j; continue
        out.append(c); i += 1
    assert depth == 0, 'unterminated block comment'
    return ''.join(out), com

def show(repo, rev, path):
    if rev.startswith('DIR:'):
        return open(os.path.join(rev[4:], path), encoding='utf-8').read()
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], check=True,
                          capture_output=True).stdout.decode('utf-8')

def h(t): return hashlib.sha256(t.encode()).hexdigest()

def main():
    repo, a, b, cj, paths = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5:]
    CTL = json.load(open(cj, encoding='utf-8'))
    bad = 0
    for p in paths:
        ra, rb = show(repo, a, p), show(repo, b, p)
        sa, ca = strip(ra); sb, cb = strip(rb)
        eq = sa == sb; bad += not eq
        print(f'{p}\n  raw {a[:12]} {h(ra)}\n  raw {b[:12]} {h(rb)}\n  raw texts '
              + ('equal' if ra == rb else 'differ')
              + f'\n  stripped {a[:12]} {h(sa)}\n  stripped {b[:12]} {h(sb)}\n'
              f'  comment-chars {ca} -> {cb}; code-chars {len(sa)} -> {len(sb)}\n  RESULT '
              + ('EQUAL' if eq else 'DIFFER'))
        c = CTL[p]; (m2o, m2n), m3, (n1o, n1n) = c['m2'], c['m3'], c['n1']
        for x in (m2o, m3, n1o):
            if rb.count(x) != 1:
                print(f'  CONTROL SETUP FAIL: {x!r} occurs {rb.count(x)} times'); bad += 1
        sk = sb.find(':=')
        m1 = sb[:sk] + ':= ' + sb[sk + 2:]
        m2 = strip(rb.replace(m2o, m2n))[0]
        m3t = strip(rb.replace(m3, '-- ' + m3))[0]
        n1 = strip(rb.replace(n1o, n1n))[0]
        for tag, desc, t in (('M1', 'space after first code `:=`', m1),
                             ('M2', f'code token {m2o.strip()!r} -> {m2n.strip()!r}', m2),
                             ('M3', f'code line commented out: {m3.strip()!r}', m3t)):
            caught = t != sa
            bad += not caught
            print(f'  control {tag} ({desc}): ' + ('DIFFER (caught)' if caught else 'EQUAL (NOT CAUGHT)'))
        ok = n1 == sa
        bad += not ok
        print(f'  negative control N1 (comment text {n1o!r} -> {n1n!r}): '
              + ('EQUAL (as required)' if ok else 'DIFFER (FALSE POSITIVE)'))
    print('RESULT', 'OK' if bad == 0 else 'FAIL')
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
