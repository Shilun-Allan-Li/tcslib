## Why

Seyoon ruled **Q-C1** on 2026-11-17 (decision log `LatticeCryptographyPlan.md`). It resolves finding **G6B-C1-F03** of `briefs/lattice-gsw/phase6/checkpoint1-6b-review.md`:

- **The G6 fill needs a lemma that is private.** The fill of `decryptFormula_eval` needs the step `c_last − ⟨s, c_init⟩ = ⟨t, decryptColumn P C⟩`, where `t = (−s, 1)`. That step exists only inside the private `decrypt_eq_decode_errorSum`. A 6b file must not copy private material across files (the GF-F02 pattern).
- **The ruling.** The lemma becomes an owner-side public lemma in `GSW/Scheme.lean`. It lands with the `hybridPlant` reader before the 6b fills.
- **The reader census.** The 6b reader census (`briefs/lattice-gsw/phase6/issued-6b-r1/census.txt`) lists `hybridPlant` as `MISSING`. The statement job adds `decrypt_eq_decode_dotProduct` to the census as MISSING too.

## Changes

There are two signed commits on the records tip `55f553715f280be36827ad86a94c93db39ec56c3` (Lean-equal to the T of snapshot #7, `a1fa7b65`): `1953898b18a33ab2cd533820c5754a1aacffeb44` (the change below, +33/−12) and the docs-only landing edit **LE-g50e** `052e2b05fa947ce0f46024e928a5f7083e23b8dc` (see "LE-g50e" below). The head is `052e2b05` (tree `1ac25be17e119929acaf40364cac6f42cf274811`).

1. **`GSW/Scheme.lean`**
   - New public lemma `decrypt_eq_decode_dotProduct (P) (s) (C) : decrypt P s C = LWE.BitEncoding.decode P.lwe (secretVector P s ⬝ᵥ decryptColumn P C)`.
     - It sits right after `decrypt_eq`.
     - Its docstring states the formula, cites [GSW13, §3.1, `Dec`; BV14, §3.1, `NCCrypt.Dec`] like the file's other docstrings, and has a proof sketch.
     - It is step 1 (`hsplit`) of the private `decrypt_eq_decode_errorSum`, promoted.
   - Only the **proof body** of `decrypt_eq_decode_errorSum` changes: `hsplit` is replaced by `rw [decrypt_eq_decode_dotProduct, decryptColumn_eq]`, and the redundant `rw [decrypt_eq, Regev.decrypt_eq]; dsimp only; rw [hsplit, …]` becomes `rw […]`. Its statement and docstring are unchanged.
2. **`Encryption/PublicKey/EnsembleSecurity.lean`**
   - New definitional reader `hybridPlant_eq … (pc) (r) : hybridPlant E m m' j D pc r = D (pc.1, fun i => if i < j then … else if i = j then pc.2 else …) r.2 := rfl`.
   - It sits beside `hybridPlant` and follows the file's reader style (`pkEncDist_eq`).

The brief gave `PrivateKey/EnsembleSecurity.lean`. `hybridPlant` is actually in `PublicKey/EnsembleSecurity.lean:110`, which is also the path the census gives.

**Search for existing equivalents.** No equivalent of either lemma exists:

- Neither name occurs in `TCSlib/` or `audits/` at the tip, on `land/gsw-6a-fills` (#366, `ccca6f80`), or in the 6b statement delivery (exchange `1e0647b9`, `src/`, `src-o2/` and both patch series). Both files are identical on #366, and the 6b delivery does not touch them.
- The residual step occurs nowhere else in TCSlib. It needs GSW's `secretVector` and `decryptColumn`, so it cannot be in Mathlib.
- The `hybridPlant` reader has no counterpart either. `distAdv_tuple_le_sum` in `Hybrid.lean` inlines the lambda and has no reader.

## Checks (replay on snapshot #7, at `1953898b`)

| Check | Result |
|---|---|
| Copy | `cp -al` of snapshot #7 → `olean-replay-6b-prereq`; Mathlib overlay with 3346 symlinks; NthRootLemmas `c0a9cff0…` (lean rc 0) |
| Export | `git archive` of the head, checked blob for blob: 1586 files, 0/0/0 |
| Plan | 2 changed files, 67 downstream modules. Build 67, reuse 1367, full order 1434 |
| Build | One module at a time through `runner.py`, with the slot gate before each module (0 waits). `Scheme` was moved first; the queue is a permutation of the plan |
| Result | 67 modules: rc≠0 0, `error:` 0, `error(` 0, sorry 0. The 1 warning is the existing unused simp argument in `MAC/FromPRF.lean:129`, which earlier replays also report |
| State | `stateplan update` took 67 modules; `check` over 1434 modules gives **RESULT OK** |
| Links | All 67 rebuilt oleans have link count 1 and match their records |
| Snapshot #7 | Rehash **0/0/0** before the build, after it and at the end (map `5105c514…`) |
| Output map | 1465 entries, `6247b348…`. Only `Scheme` and `EnsembleSecurity` differ from #7 |
| Admissions | **192 in 44 modules** at both the tip and the head, identical per module. The 67 rebuilt modules have 0 |
| Axioms | `decrypt_eq_decode_dotProduct`: `propext`, `Classical.choice`, `Quot.sound`. `hybridPlant_eq`: none. Private `decrypt_eq_decode_errorSum`: standard (exactly one constant matched). `decrypt_of_encrypts`, `_dyadic`, `decrypt_keygen_encrypt` and `distAdv_multi_le_sum`: standard. No `sorryAx`. Both readers are applied once in the probe |
| decls2 (`fa81981a`) | **2 ADDED, 0 CHANGED, 0 REMOVED** |
| touched | 2 ADDED, 1 CHANGED (the private `decrypt_eq_decode_errorSum`, proof body only), every other declaration UNCHANGED |
| Coe-A seals, base vs head | `Scheme`: 101 requests, 0 errors on both sides. `EnsembleSecurity`: 1268 requests, 6 errors on both sides, in the same 4 declarations (`bitwiseEncFun_poly`, `bitwise_enc_runAtL`, `singleBitSecure_iff`, `Secure.multiMessageSecure`). Those failures are at the base already. **0 new failures**, and install and EOF records are present everywhere |
| Lint | `campaign_style_lint --check8b` on `TCSlib/Cryptography`: 92 FAIL / 103 WARN at both the base and the head, with the same FAIL set. The one changed WARN is check 8 for `EnsembleSecurity`, which drops `hybridPlant` (4 → 3 defs without a reader). `style_lint` finds 0 problems in both files. No new lines are over 100 characters |
| Slots | At most one Lean process of this job at a time, with a check before each one. 0 waits |

## Re-replay on snapshot #8 (at `1953898b`)

After #365 was adopted as olean snapshot #8 (T `2dd2e60e`), the PR was re-replayed on #8. Record: `briefs/lattice-gsw/phase6/owner-prereqs-6b/evidence-s8.zip`. G50-03 replaced it: its inner `SHA256SUMS` no longer lists itself, and the archive is now `d3373171…`, was `e97aed58…`; see `evidence-s8-CORRECTION.md` beside it.

- **Merge tree:** R = `git merge-tree --write-tree` of the tip `cd8b4765` and `1953898b` = **`ab098201a13ad10829914bfbc6bedcbb2fe52e9e`**, clean. Its Lean is #8's plus exactly the two files.
- **Tree:** `olean-replay-6b-prereq8` = `cp -al` of snapshot #8, with the Mathlib overlay.
- **Build:** the same 67 modules, **rc 0, 0 errors, 0 sorry**. The 1 warning is the existing one in `MAC/FromPRF`.
- **State check** over 1,434 modules: **RESULT OK**. The 67 rebuilt oleans have link count 1. Snapshot #8 rehashes **0/0/0**.
- **Same as the #7 run:** all 67 oleans and logs are byte-equal to it.
- **Output map:** `5a88ccf5…`. Against #8, only `Scheme` and `EnsembleSecurity` differ.
- **Checks:** admissions 192. The axiom log is byte-equal to the #7 run's. The coe-A seals are byte-equal to the #7 run's apart from `rev`.

## LE-g50e (Gate 50 G50-02, docs only, 2026-11-18)

**Why.** Gate 50 round 1 cleared this PR with three minors. **G50-02** asked for two docstring changes:
- the explicit equation and a glue classification on `hybridPlant_eq`;
- the sketches that describe the residual step should name `decrypt_eq_decode_dotProduct`.

Seyoon ruled that this is fixed before merging, by a docs-only landing edit (decision log, 2026-11-18).

**What.** `052e2b05fa947ce0f46024e928a5f7083e23b8dc` (tree `1ac25be1…`), signed, on `1953898b`. Comments and docstrings only: 2 files, +9/−5.
- `EnsembleSecurity`, `hybridPlant_eq`: the docstring now states `hybridPlant E m m' j D pc r = D (pc.1, fun i => if i < j then E pc.1 (m' i) (r.1 i) else if i = j then pc.2 else E pc.1 (m i) (r.1 i)) r.2`, followed by "Glue (the reader of `hybridPlant`)".
- `GSW/Scheme`: the sketches of the private `decrypt_eq_decode_errorSum` and of `decrypt_of_encrypts` now name `decrypt_eq_decode_dotProduct` for the residual step, "decryption decodes `⟨t, v⟩`".

**Code identity.** I stripped comments from both files at `1953898b` and at `052e2b05` (`commentstrip50.py`, LE-g45b's stripper). The stripped code is **byte-identical**. All 3 mutation controls per file are caught (6/6), and both negative controls stay equal.

**Short re-replay.** Never with `lake build`; one Lean process at a time, with the slot and disk gates.
- **Merge tree:** R′ = `git merge-tree --write-tree cd8b4765 052e2b05` = **`7f0cb8d8991ff78b4407648cb8e4dd411702ba7e`**, clean.
  - It differs from R = `ab098201` in exactly the two files.
  - The current tip `610ecdbf` gives a Lean-equal merge.
- **Tree:** `olean-replay-6b-prereq9` = `cp -al` of `olean-replay-6b-prereq8`. The state check at `ab098201` was OK at the start.
- **Build:** the same **67 modules**, in the #8 run's order. **rc 0, 0 `error:`/`error(`, 0 sorry.** The 1 warning is the existing `MAC/FromPRF` one.
  - All 67 logs are byte-equal to the #8 run's.
  - The state check at `7f0cb8d8` over 1,434 modules gives **RESULT OK** after the build and again at the end.
  - The 67 rebuilt oleans have link count 1, and the reused ones are the parent's inodes.
- **Output map** (Mathlib excluded): 1,465 entries, SHA-256 **`3316e2527910cb83fa54ba8840c9b7410f95c3fe2e4c46ac53b90c340a53943e`**.
  - Against `-prereq8`, only `Scheme` and `EnsembleSecurity` changed, because oleans store docstrings. The other 65 rebuilt oleans are byte-equal.
- **Rehash:** the parent tree and snapshot #8 (`28677767…`) both rehash **0/0/0** at the start and at the end, and #8 again after `-prereq8` was deleted.
- **Admissions:** **192 in 44 modules**, byte-equal to the #8 run's.
- **Axioms:** the probe is unchanged, and **its log is byte-identical to the #8 run's** (`290a49d5…`). All 7 checked constants are standard, and there is no `sorryAx`.
- **decls2** against `55f55371`: **2 ADDED, 0 CHANGED, 0 REMOVED**. This equals the #7 run's output except that `hybridPlant_eq` moves from line 119 to 121.
- **touched** against #8's T: `decrypt_of_encrypts` is now CHANGED, for its docstring only.
- **Lint:** `campaign_style_lint --check8b` on `TCSlib/Cryptography` gives 92 FAIL / 103 WARN, with FAIL/WARN lines equal to the #7 run's.
  - Only INFO size lines change (Scheme 375 → 377, EnsembleSecurity 492 → 494, plus #365's `Group.lean`).
  - `style_lint` finds 0 problems.
  - No added line is over 100 characters.
- **Seals:** canonical coe-A on both owners.
  - The collector source and log, and `seals-coe-A.tsv`, are byte-identical to the #8 run's.
  - `Scheme`: 101 requests, 0 errors, seal log byte-identical.
  - `EnsembleSecurity`: 1,268 requests and the same 6 pre-existing errors in the same 4 declarations. Its log differs only in the 2-line shift of error positions.
  - The request sets and rows are identical.

Evidence: `briefs/lattice-gsw/phase6/owner-prereqs-6b/le-g50e-evidence.zip` (inner `SHA256SUMS`).

## Gating

**Gate 50 (Codex), round 1: CLEAR** (`briefs/lattice-gsw/gates/50-gsw-6a-fills/findings-r1.md`; #368: 0 blockers, 0 majors, 3 minors). Seyoon folded #368 into Gate 50 with #366 (decision log, 2026-11-17). The minors are addressed:
- G50-02 by LE-g50e;
- G50-03 by the replacement `evidence-s8.zip`;
- G50-04 by this description.

**Adoption:** `olean-replay-6b-prereq9` is the candidate only at a merge whose Lean equals R′ `7f0cb8d8`. `olean-replay-6b-prereq8` was deleted after `-prereq9` verified.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA