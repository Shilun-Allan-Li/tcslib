"""names.py <repo> <rev> [--files f...]: full declaration names (namespaces resolved, private
included) of every TCSlib/*.lean file at <rev> (git objects), or of the listed working files."""
import re, subprocess, sys
KW = r'(theorem|lemma|def|abbrev|structure|inductive|instance|class|opaque|axiom)'
def strip(s):
    s = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), s, flags=re.S)
    return re.sub(r'--[^\n]*', '', s)
def names(src):
    out, ns = [], []
    for l in strip(src).split('\n'):
        m = re.match(r'^\s*namespace\s+(\S+)', l)
        if m: ns.append(m.group(1)); continue
        m = re.match(r'^\s*end\s+(\S+)\s*$', l)
        if m and ns and ns[-1] == m.group(1): ns.pop(); continue
        m = re.match(r'^\s*(@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*' + KW + r'\s+([^\s(:{\[]+)', l)
        if m and m.group(3) != 'instance':
            n = m.group(4)
            if n.startswith('_root_.'): full = n[7:]
            else: full = '.'.join(ns + [n]) if ns else n
            out.append((full, 'private' in (m.group(2) or '')))
    return out
repo, rev = sys.argv[1], sys.argv[2]
if '--files' in sys.argv:
    for f in sys.argv[sys.argv.index('--files') + 1:]:
        for n, p in names(open(f, encoding='utf8').read()): print(f'{n}\t{p}\t{f}')
else:
    fl = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', '--name-only', rev, 'TCSlib'],
                        capture_output=True, text=True).stdout.split()
    for f in fl:
        if not f.endswith('.lean'): continue
        src = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, text=True).stdout
        for n, p in names(src): print(f'{n}\t{p}\t{f}')
