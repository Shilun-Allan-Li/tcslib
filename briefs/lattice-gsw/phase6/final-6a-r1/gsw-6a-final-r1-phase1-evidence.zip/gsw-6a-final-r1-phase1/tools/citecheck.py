"""citecheck.py <refdir> <lean files...>: every [TAG, ..., pNNN-bNNN ...] anchor must exist in the
tag's ingest; every quotation "..." after an anchor is searched (whitespace/markup normalized) in
the ingest's .md and .raw.md. Prints one line per citation."""
import re, sys, os, unicodedata
refdir, files = sys.argv[1], sys.argv[2:]
ING = {'Bar89': 'barrington-1989-bounded-width-bp', 'BV14': 'brakerski-vaikuntanathan-2014-fhe',
       'BV11': 'brakerski-vaikuntanathan-2011-fhe', 'AP14': 'alperin-sheriff-peikert-2014-bootstrapping'}
def norm(s):
    s = unicodedata.normalize('NFKC', s)
    s = re.sub(r'[`$*_\\{}]', '', s)
    s = s.replace('“', '"').replace('”', '"').replace('’', "'")
    s = re.sub(r'\s+', ' ', s)
    return s.strip().lower()
texts, anchors = {}, {}
for t, base in ING.items():
    txt = ''
    for ext in ('.md', '.raw.md'):
        p = os.path.join(refdir, base + ext)
        if os.path.exists(p): txt += open(p, encoding='utf8').read() + '\n'
    texts[t] = norm(txt)
    anchors[t] = set(re.findall(r'p\d{3}-b\d{3}', txt))
tags = set()
for f in files:
    src = open(f, encoding='utf8').read()
    for m in re.finditer(r'\[(Bar89|BV14|BV11|AP14|Gen09|AB09)([^\]]*)\]', src, re.S):
        tag0, body0 = m.group(1), m.group(2)
        line = src.count('\n', 0, m.start()) + 1
        segs = [(tag0, body0.split(';')[0])]
        for seg in body0.split(';')[1:]:
            mm = re.match(r'\s*(Bar89|BV14|BV11|AP14|Gen09|AB09)\b(.*)', seg, re.S)
            segs.append((mm.group(1), mm.group(2)) if mm else (segs[-1][0], seg))
        for tag, body in segs:
          tags.add(tag)
          for a in re.findall(r'p\d{3}-b\d{3}', body):
            ok = a in anchors.get(tag, set())
            print(f'ANCHOR\t{"OK" if ok else "MISSING"}\t{tag}\t{a}\t{os.path.basename(f)}:{line}')
          for q in re.findall(r'"([^"]+)"', body):
              qn = norm(q)
              if tag not in texts: print(f'QUOTE\tNOTAG\t{tag}\t{q}'); continue
              ok = qn in texts[tag]
              if not ok:
                  # allow sic / ellipsis split
                  parts = [p.strip() for p in re.split(r'…|\.\.\.', qn) if p.strip()]
                  ok2 = all(p in texts[tag] for p in parts)
                  st = 'PARTS' if ok2 else 'NOTFOUND'
              else: st = 'OK'
              print(f'QUOTE\t{st}\t{tag}\t{q[:90]}\t{os.path.basename(f)}:{line}')
print('TAGS', sorted(tags))
