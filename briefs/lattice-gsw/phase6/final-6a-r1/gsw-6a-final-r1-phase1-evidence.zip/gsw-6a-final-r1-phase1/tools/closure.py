"""closure.py <repo> <rev-or-tree> <down|up> <module>...: modules downstream of (down) or in the import
closure of (up) the given modules, read from git objects (TCSlib, audits, briefs excluded for up)."""
import subprocess, sys, collections
repo, rev, mode, targets = sys.argv[1], sys.argv[2], sys.argv[3], set(sys.argv[4:])
out = subprocess.run(['git', '-C', repo, 'grep', '-E', '^import ', rev, '--', '*.lean'],
                     capture_output=True, text=True).stdout
imps = collections.defaultdict(set); mods=set()
for line in out.splitlines():
    _, path, rest = line.split(':', 2)
    if path.startswith('briefs/'): continue
    m = path[:-5].replace('/', '.'); mods.add(m)
    i = rest.split()[1]
    if not i.startswith('Mathlib') and not i.startswith('Batteries') and not i.startswith('Aesop'): imps[m].add(i)
if mode == 'up':
    seen, st = set(targets), list(targets)
    while st:
        m = st.pop()
        for d in imps[m]:
            if d not in seen: seen.add(d); st.append(d)
else:
    rv = collections.defaultdict(set)
    for m, ims in imps.items():
        for i in ims: rv[i].add(m)
    seen, st = set(), list(targets)
    while st:
        m = st.pop()
        for d in rv[m]:
            if d not in seen: seen.add(d); st.append(d)
for m in sorted(seen): print(m)
