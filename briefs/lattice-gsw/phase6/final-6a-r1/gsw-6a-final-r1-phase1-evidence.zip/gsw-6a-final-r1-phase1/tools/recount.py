"""recount.py <delivery-dir> <repro-worktree> <base-sorries>: maintainer recount of the gsw-6a final
delivery's evidence (manifests, closure binding, root sweep logs, admissions, seals, controls, axioms)."""
import sys, os, re, hashlib, collections, glob
D, R, BS = sys.argv[1:4]
E = os.path.join(D, 'evidence')
def files(root):
    out = set()
    for d, _, fs in os.walk(root):
        for f in fs: out.add(os.path.relpath(os.path.join(d, f), root))
    return out
def manifest(p):
    return {l.split(None, 1)[1].strip(): l.split()[0] for l in open(p) if l.strip()}
allf = files(D); top = manifest(os.path.join(D, 'SHA256SUMS')); ev = manifest(os.path.join(E, 'SHA256SUMS'))
evf = {p[9:] for p in allf if p.startswith('evidence/')}
badh = [p for p, h in top.items() if hashlib.sha256(open(os.path.join(D, p), 'rb').read()).hexdigest() != h]
print(f'MANIFEST top {len(top)} files {len(allf)} missing {sorted(allf - set(top) - {"SHA256SUMS"})} extra {sorted(set(top) - allf)} badhash {badh}')
print(f'MANIFEST evidence {len(ev)} files {len(evf)} missing {sorted(evf - set(ev) - {"SHA256SUMS"})} extra {sorted(set(ev) - evf)}')
err = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
# closure binding
bad = 0
for l in open(f'{E}/build/final-closure/summary.txt'):
    p = l.rstrip('\n').split('\t'); m = p[0]; sha = p[-1].split('=')[1]
    h = hashlib.sha256(open(f'{R}/{m}.lean', 'rb').read()).hexdigest()
    t = open(f'{E}/build/final-closure/mods/{m.replace("/", ".")}.log', encoding='utf8').read()
    ok = h == sha and p[1] == 'rc=0' and f'errors={len(err.findall(t))}' in p and f"sorry={t.count(chr(39)+'sorry'+chr(39))}" in p
    bad += not ok
print(f'CLOSURE 19 modules bound to reproduced head: bad={bad}')
rows = [l.rstrip('\n').split('\t') for l in open(f'{E}/build/root/summary-all.tsv')]
order = [l.strip() for l in open(f'{E}/build/order-final.txt') if l.strip()]
print(f'SWEEP rows {len(rows)} unique {len({r[1] for r in rows})} set==order-final {set(order) == {r[1] for r in rows}} parts {dict(collections.Counter(r[0] for r in rows))}')
print(f'SWEEP nonzero rc/errors {[r[1] for r in rows if r[2] != "rc=0" or r[3] != "errors=0"]}')
badlog = []
for r in rows:
    if r[0] == 'prefix': continue
    d = {'bootstrap': 'bootstrap/mods', 'closure': 'final-closure/mods', 'root': 'root/mods'}[r[0]]
    t = open(f'{E}/build/{d}/{r[1].replace("/", ".")}.log', encoding='utf8', errors='replace').read()
    if f'errors={len(err.findall(t))}' not in r or f"sorry={t.count(chr(39)+'sorry'+chr(39))}" not in r: badlog.append(r[1])
print(f'SWEEP logs recounted {sum(1 for r in rows if r[0] != "prefix")} mismatches {badlog}')
sor = {r[1]: int(r[4].split('=')[1]) for r in rows}
base = {}
for l in open(BS):
    if l.count(':') < 2 or l.startswith('#'): continue
    m, c, _ = l.split(':', 2); base[m.strip()] = int(c)
new = {}
for f in glob.glob(f'{R}/TCSlib/Complexity/**/*.lean', recursive=True):
    m = os.path.relpath(f, R)[:-5]
    if m in sor and m not in base:
        src = open(f, encoding='utf8').read()
        src = re.sub(r'/-.*?-/', '', src, flags=re.S); src = re.sub(r'--[^\n]*', '', src)
        k = len(re.findall(r'\bsorry\b', src))
        if k: new[m] = k
mism = [(m, sor[m], base.get(m, 0) + new.get(m, 0)) for m in sor if sor[m] != base.get(m, 0) + new.get(m, 0)]
print(f'ADMISSIONS root warnings {sum(sor.values())} = base {sum(base.values())} ({len(base)} modules) + source-level targets {sum(new.values())} ({len(new)} modules); mismatches {mism}')
for v in ['A', 'B', 'coeA', 'coeB']:
    out = []
    for f in sorted(glob.glob(f'{E}/rule10/final/run-{v}/mods/*.log')) + sorted(glob.glob(f'{E}/rule10/final/run-chunked-{v}/mods/*.log')) + sorted(glob.glob(f'{E}/rule10/final-root/run-{v}/mods/*.log')):
        t = open(f, encoding='utf8', errors='replace').read()
        rv = re.findall(r'requested=(\d+) verified=(\d+)', t)
        out.append((os.path.basename(f).split('Seal' + v + '_')[-1][:-4], len(err.findall(t)), 'stack overflow' in t.lower(), sorted({int(a) for a, b in rv if a == b}), all(a == b for a, b in rv)))
    print(f'SEALS {v}: ' + '; '.join(f'{n} err={e}{" OVERFLOW" if o else ""} req={r}' for n, e, o, r, _ in out))
print('CONTROLS', dict(collections.Counter(l.rstrip().split('\t')[-1] for l in open(f'{E}/rule10/controls/summary.txt'))))
L = [l.rstrip('\n').split('\t') for l in open(f'{E}/stmt/AxiomProbe.log') if l.startswith(('DECL', 'AUX', 'TRACE'))]
dc = [l for l in L if l[0] in ('DECL', 'AUX')]
nonstd = [l[2] for l in dc if set(re.findall(r'[\w.]+', l[3])) - {'propext', 'Classical.choice', 'Quot.sound', 'sorryAx'}]
sx = [l[2] for l in dc if 'sorryAx' in l[3]]
tr = {l[1]: re.findall(r"[\w.']+", l[2].replace('via', '')) for l in L if l[0] == 'TRACE'}
other = {k: v for k, v in tr.items() if v != [k]}
print(f'AXIOMS constants {len(dc)} nonstandard {nonstd} sorryAx {len(sx)} (aux {sum(1 for l in dc if "sorryAx" in l[3] and l[0] == "AUX")}); self-only traces {len(tr) - len(other)}')
for k, v in sorted(other.items()): print(f'TRACE {k} via {[x for x in v if x != k]}')
