"""f05cmp.py <touched-base.json> <touched-head.json> <base-records-dir> <base-rundir> <head-records-dir> <head-rundir> <label>
(gsw-6a phase 2, G6A-F05): for one TreeNCAC seal probe, the failing declarations at the tip (base) and at a head, each
error's message (the lines after `error:` up to the next diagnostic or the seal's G06- records, with probe line numbers removed) and the source text
of the failing declarations at both revs (touched.json spans of the rev's source, via git show). Prints whether the two failures common to both are
byte-identical in declaration text and error message."""
import sys, json, re, os, subprocess
tb, th, rb, db, rh, dh, label = sys.argv[1:8]
def errs(recdir, rundir, tj):
    r = json.load(open(os.path.join(recdir, label + '.json')))
    log = open(os.path.join(rundir, 'mods', r['probe_module'].replace('/', '_') + '.log'), encoding='utf-8').read()
    p2s = {d['probe_line']: d['source_line'] for d in r['source_to_probe_lines']}
    T = json.load(open(tj)); decls = T['files'][r['source']]['declarations']
    src = subprocess.run(['git', '-C', '/home/user/tcslib', 'show', f"{T['head']}:{r['source']}"], capture_output=True, text=True, check=True).stdout.split('\n')
    txt = lambda d: '\n'.join(x.rstrip() for x in src[d['start'] - 1:d['end']]).strip('\n')
    out = {}
    blocks = re.split(r'(?m)^(?=\S+\.lean:\d+:\d+: )', log)
    for b in blocks:
        m = re.match(r'^\S+\.lean:(\d+):\d+: error[:(]', b)
        if not m: continue
        s = p2s.get(int(m.group(1)))
        d = next((x for x in decls if s and x['start'] <= s <= x['end']), None)
        msg = re.split(r'(?m)^G06-', re.sub(r'^\S+\.lean:\d+:\d+: ', '', b))[0].strip()  # drop the seal's EOF records
        out.setdefault(d['name'] if d else f'?{s}', []).append((msg, txt(d) if d else None))
    return out
a, b = errs(rb, db, tb), errs(rh, dh, th)
print('base failing:', sorted(a)); print('head failing:', sorted(b))
for n in sorted(set(a) & set(b)):
    print(f'{n}: errors base {len(a[n])} head {len(b[n])}; message identical {[x[0] for x in a[n]] == [x[0] for x in b[n]]}; '
          f'declaration text identical {a[n][0][1] == b[n][0][1]}')
for n in sorted(set(a) - set(b)): print(f'{n}: fails only at the base (O1 repair)')
for n in sorted(set(b) - set(a)): print(f'{n}: fails only at the head  <-- NEW')
