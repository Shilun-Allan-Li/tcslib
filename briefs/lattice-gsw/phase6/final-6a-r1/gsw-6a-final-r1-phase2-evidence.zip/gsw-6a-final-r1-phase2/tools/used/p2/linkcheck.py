"""linkcheck.py <olean-dir> <results.jsonl> <out>: for every module of a runner.py run (rc 0, last record), the .olean's
link count and SHA-256 (must equal the record's object_sha256); prints counts of link count 1 / >1 and mismatches. Also
counts the files of <olean-dir> (excluding Mathlib/) by link count."""
import sys, os, json, hashlib, collections
d, res, out = sys.argv[1:4]
last = {}
for l in open(res):
    r = json.loads(l)
    if 'module' in r: last[r['module']] = r
rows = []; c = collections.Counter(); bad = []
for m, r in sorted(last.items()):
    p = os.path.join(d, m + '.olean'); st = os.stat(p); h = hashlib.sha256(open(p, 'rb').read()).hexdigest()
    c['links1' if st.st_nlink == 1 else 'links>1'] += 1
    if h != r['object_sha256']: bad.append(m)
    rows.append(f'{st.st_nlink}\t{h}\t{m}')
tot = collections.Counter()
for root, ds, fs in os.walk(d):
    if os.path.relpath(root, d).split(os.sep)[0] == 'Mathlib': continue
    for f in fs:
        p = os.path.join(root, f)
        if not os.path.islink(p): tot[os.stat(p).st_nlink] += 1
open(out, 'w').write('\n'.join(rows) + f'\nrebuilt {len(last)}: {dict(c)}; object hash != record: {bad}\nall non-Mathlib files by link count: {dict(sorted(tot.items()))}\n')
print(f'rebuilt {len(last)}: {dict(c)}; object hash != record: {len(bad)}; all non-Mathlib files by link count: {dict(sorted(tot.items()))}')
