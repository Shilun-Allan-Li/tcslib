#!/usr/bin/env bash
# rule10_bb1s.sh <series> <phase>... (bb1-sim statements phase 2, maintainer, 2026-11-17): the worker's
# drivers/rule10_stmt.sh adapted to the olean snapshot procedure (as rule10_346.sh did for #346). Changes:
# (1) worktrees are `git archive` exports (no .git; GIT_DIR points at the repo so `git -C <wt> show <rev>:<path>` reads
#     the shared object store) of the landing heads, and of the records tip for the base;
# (2) olean trees: games -> olean-replay-bb1sim-games (R1), group -> olean-replay-bb1sim-group (R2), base -> a cp -al
#     copy of the snapshot plus the Mathlib overlay (olean-base-tip, read only by the probes, discarded after);
# (3) touched.json is computed against the records tip 176cfd4a (Lean-equal to snapshot #2's T), not the issue base;
# (4) the base series seals Probability, Group AND Assumptions (the control carrier), at the tip;
# (5) seal tools: the maintainer copies (olean-advance-a6d01b1b/tools-used/seal; runner_full.py without flock, lake
#     packages from /home/user/tcslib), plus the worker's rule10_b.sh (R10DIR/TOUCHED) and mkctl_bb1s.py, unchanged.
# Every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing is written to the tree). One Lean process.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
E=$SP/bb1p2/ev; T=$SP/bb1p2/tools/seal; G=$T/review/archived-gate10-tools
B=176cfd4a42ac3300d9b84f9045f7abcd0f52ef13
GM=TCSlib.Cryptography.Games; PM=TCSlib.Cryptography.Pairing
case $1 in
games) W=$SP/bb1p2/wt-games; TREE=$SP/olean-replay-bb1sim-games; NAME=games; H=dfacac356ff1225aca4c900d81bbf2cabce7b499
    MODS="$GM.Relational $GM.Probability"
    FILES="TCSlib/Cryptography/Games/Relational.lean TCSlib/Cryptography/Games/Probability.lean TCSlib/Cryptography/Games.lean";;
group) W=$SP/bb1p2/wt-group; TREE=$SP/olean-replay-bb1sim-group; NAME=group; H=92dea4f8126747ea7e816984349b9dbb789f0065
    MODS="$PM.Group $PM.Assumptions"
    FILES="TCSlib/Cryptography/Pairing/Group.lean TCSlib/Cryptography/Pairing/Assumptions.lean";;
base) W=$SP/bb1p2/wt-tip; TREE=$SP/bb1p2/olean-base-tip; NAME=base; H=$B
    MODS="$GM.Probability $PM.Group $PM.Assumptions"
    FILES="TCSlib/Cryptography/Games/Probability.lean TCSlib/Cryptography/Pairing/Group.lean TCSlib/Cryptography/Pairing/Assumptions.lean";;
esac
shift
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$SP/bb1p2/tmp PATH=$HOME/.elan/bin:$PATH
PP=StmtSeal
mkdir -p $R/order $R/probe-sources $W/$PP $E/statements
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
touched)
  python3 -I $T/review/touched.py /home/user/tcslib $B $H $TJ $FILES > $E/statements/touched-$NAME.tsv; echo "touched rc=$?";;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "bb1-sim phase 2 $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
seals)
  R10DIR=$R TOUCHED=$TJ bash $T/rule10_b.sh $T $W $E $PP $H $T/review/mkctl_bb1s.py $MODS > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
baseseals)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/A $PP/ZS SealA_ $MODS > $R/mkseals-A.log
  SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/B $PP/ZS SealB_ $MODS > $R/mkseals-B.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/B $PP/ZC SealB_ $MODS > $R/mkseals-coe-B.log
  (cd $W && ls $PP/ZS/*.lean $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  python3 -I $T/runner_full.py $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  for v in seals/A seals/B seals-coe/A seals-coe/B; do
    python3 -I $T/review/sealsum.py $R/$v $R/seal-runs $TJ $R/$(echo $v | tr / -).tsv; done
  cat $R/mkseals-*.log; cat $R/seals-*.tsv;;
scan)
  S=$E/scan/$NAME; mkdir -p $S
  SF=$(git diff --name-only $B $H -- 'TCSlib/*.lean' | grep '/')
  echo $SF > $S/files.txt
  SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W $TJ $S/items-head.json $W/$PP/ScanKindsHead.lean $SF > $S/scan1.out 2>&1
  cp $W/$PP/ScanKindsHead.lean $S/ScanKindsHead.lean.txt
  echo $PP/ScanKindsHead > $S/order.txt
  python3 -I $T/runner_full.py $W $S/order.txt $TREE $S/runs > $S/scan-runner.out 2>&1
  python3 -I $T/scan2.py $S/items-head.json $S/runs/mods/${PP}_ScanKindsHead.log $S/explicit-head.json > $S/scan2-head.log 2>&1; echo "scan2 rc=$?";;
probes)
  # $PROBES: space-separated probe basenames from $SP/bb1p2/probe-src, copied under $W/Bb1sProbe/
  D=$E/probes/$NAME; mkdir -p $D $W/Bb1sProbe; : > $D/order.txt
  for p in $PROBES; do cp $SP/bb1p2/probe-src/$p.lean $W/Bb1sProbe/$p.lean; cp $SP/bb1p2/probe-src/$p.lean $D/$p.lean.txt; echo Bb1sProbe/$p >> $D/order.txt; done
  python3 -I $T/runner_full.py $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
