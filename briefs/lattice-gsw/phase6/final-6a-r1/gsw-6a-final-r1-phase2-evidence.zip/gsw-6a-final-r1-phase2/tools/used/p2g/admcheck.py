"""admcheck.py <repo> <tip-rev> <replay-logdir> <touched.json> <rowmap.txt|-> <out> [drop-name ...]  (gsw-6a phase 2,
maintainer): admissions of a replay against the records tip, per rebuilt module, and the exact-target check.
- head: the `declaration uses 'sorry'` warnings of the module's replay log (last runner record; `^<file>:<l>:<c>: warning:
  declaration uses 'sorry'`), each mapped to its declaration through touched.json's spans (full names).
- tip: 0 if the module is absent at <tip-rev>; otherwise the count of `sorry`/`admit` tokens in its source at <tip-rev>
  (a module whose source has no such token cannot emit the warning). A nonzero token count is reported as UNRESOLVED.
- targets: the rowmap.txt rows with status `sorry` (the delivered target list), minus the names given as drop-name; each
  head admission must be one of them in the same file, and every one of them must be admitted exactly once.
Modules not rebuilt have the same closure key, hence the same source, at tip and head (stateplan), so contribute 0."""
import sys, json, re, os, subprocess
repo, tip, ld, tj, rowmap, out = sys.argv[1:7]; drop = set(sys.argv[7:])
touched = json.load(open(tj))['files']
last = {}
for l in open(os.path.join(ld, 'results.jsonl')):
    r = json.loads(l)
    if 'module' in r: last[r['module']] = r
W = re.compile(r"^(\S+\.lean):(\d+):\d+: warning: declaration uses 'sorry'", re.M)
rows, adm, tot_h, tot_t, unres = [], [], 0, 0, []
for m, r in sorted(last.items()):
    log = open(os.path.join(ld, 'mods', m.replace('/', '_') + '.log'), encoding='utf-8', errors='replace').read()
    hits = [(f, int(n)) for f, n in W.findall(log)]
    assert len(hits) == r['sorry'], (m, len(hits), r['sorry'])
    for f, n in hits:
        ds = [d['name'] for d in touched.get(f, {}).get('declarations', []) if d['start'] <= n <= d['end']]
        adm.append((f, n, ds[0] if ds else f'?line{n}'))
    p = subprocess.run(['git', '-C', repo, 'show', f'{tip}:{m}.lean'], capture_output=True)
    if p.returncode != 0: t, how = 0, 'absent at tip'
    else:
        k = len(re.findall(r'\b(sorry|admit)\b', p.stdout.decode('utf-8', 'replace')))
        t, how = (0, 'tip source: 0 sorry/admit tokens') if k == 0 else (None, f'UNRESOLVED: {k} tokens at tip')
        if t is None: unres.append(m)
    tot_h += r['sorry']; tot_t += t or 0
    rows.append(f"{m}\thead {r['sorry']}\ttip {t}\tdelta {r['sorry'] - (t or 0)}\t{how}")
res = [f'# admissions against tip {tip}: rebuilt {len(rows)}; head {tot_h}; tip {tot_t}; delta {tot_h - tot_t}; unresolved {unres}'] + rows
tg = set()
if rowmap != '-':
    for l in open(rowmap, encoding='utf-8'):
        x = l.rstrip('\n').split('\t')
        if len(x) >= 5 and x[3] == 'sorry' and x[1] not in drop: tg.add((x[4], x[1]))
    got = {}
    for f, n, d in adm:
        key = next(((tf, ts) for (tf, ts) in tg if tf == f and (d == ts or d.endswith('.' + ts))), None)
        got.setdefault(key, []).append((f, n, d))
    extra = got.get(None, []); multi = {k: v for k, v in got.items() if k and len(v) > 1}; missing = sorted(tg - set(got))
    res.append(f'# exact-target check: targets {len(tg)} (delivered {len(tg) + len([1 for _ in drop])} minus dropped {sorted(drop)}); '
               f'admitted {len(adm)}; matched {len([k for k in got if k])}; not a target {len(extra)} {extra}; '
               f'twice {multi}; target not admitted {missing}; RESULT {"EXACT" if not extra and not multi and not missing and len(adm) == len(tg) else "MISMATCH"}')
res += [f'ADMISSION\t{f}:{n}\t{d}' for f, n, d in adm]
open(out, 'w').write('\n'.join(res) + '\n')
print(res[0]); [print(x) for x in res[1:] if x.startswith('# exact')]
