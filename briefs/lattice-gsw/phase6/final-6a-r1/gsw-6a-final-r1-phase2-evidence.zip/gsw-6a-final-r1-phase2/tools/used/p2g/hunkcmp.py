"""hunkcmp.py <proposed.diff> <commit.diff>: per-file hunk comparison of two unified diffs (gsw-6a phase 2, maintainer).
Splits each diff by file (the b/ path of the +++ line, prefix stripped), drops the diff/index/---/+++ header lines and
the function-context text after a hunk header's closing @@, then compares the per-file hunk bodies byte for byte."""
import sys, re
def parse(p):
    files, cur = {}, None
    for l in open(p, 'rb').read().decode('utf-8').split('\n'):
        if l.startswith('+++ '):
            cur = re.sub(r'^b/', '', l[4:].split('\t')[0]); files[cur] = []; continue
        if l.startswith(('diff ', 'index ', '--- ')) or cur is None: continue
        m = re.match(r'^(@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@)', l)
        files[cur].append(m.group(1) if m else l)
    return {k: '\n'.join(v).rstrip('\n') for k, v in files.items()}
a, b = parse(sys.argv[1]), parse(sys.argv[2])
print('files proposed', sorted(a)); print('files commit  ', sorted(b))
ok = sorted(a) == sorted(b)
for f in sorted(set(a) | set(b)):
    same = a.get(f) == b.get(f); ok &= same
    print(f'{"SAME" if same else "DIFF"} {f} hunks {a.get(f, "").count(chr(10) + "@@") + a.get(f, "").startswith("@@")}')
print('RESULT', 'IDENTICAL' if ok else 'DIFFERENT')
