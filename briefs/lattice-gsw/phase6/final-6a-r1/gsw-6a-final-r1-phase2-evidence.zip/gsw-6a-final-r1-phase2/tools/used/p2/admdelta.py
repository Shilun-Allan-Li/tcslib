"""admdelta.py <repo> <tip-rev> <replay-results.jsonl> <out> <name=baseline-results.jsonl>...: admissions delta of a replay
against the tip. For every module rebuilt by the replay: its `declaration uses 'sorry'` count at the head (the replay record)
and at the tip (a baseline record whose source_sha256 equals the module's source at <tip-rev>; `absent` if the module does
not exist at the tip). Modules not rebuilt have identical closure keys, hence identical sources, at tip and head (stateplan),
so they contribute 0. Prints the per-module nonzero deltas and the total."""
import sys, json, hashlib, subprocess
repo, tip, res, out = sys.argv[1:5]
idx = {}
for a in sys.argv[5:]:
    n, f = a.split('=', 1)
    for l in open(f):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: idx.setdefault((r['module'], r['source_sha256']), (n, r['sorry']))
last = {}
for l in open(res):
    r = json.loads(l)
    if 'module' in r: last[r['module']] = r
rows = []; tot = 0; miss = []
for m, r in sorted(last.items()):
    p = subprocess.run(['git', '-C', repo, 'show', f'{tip}:{m}.lean'], capture_output=True)
    if p.returncode != 0: t, src = 0, 'absent at tip'
    else:
        h = hashlib.sha256(p.stdout).hexdigest(); hit = idx.get((m, h))
        if hit is None: miss.append(m); t, src = None, 'NO TIP RECORD'
        else: t, src = hit[1], hit[0]
    d = r['sorry'] - (t or 0); tot += d
    rows.append(f'{m}\thead {r["sorry"]}\ttip {t}\tdelta {d}\t{src}')
open(out, 'w').write('\n'.join(rows) + f'\nTOTAL delta {tot} over {len(rows)} rebuilt modules; no tip record: {miss}\n')
for x in rows:
    if '\tdelta 0\t' not in x or 'NO TIP' in x: print(x)
print(f'TOTAL delta {tot} over {len(rows)} rebuilt modules; no tip record: {miss}')
