r"""warncmp.py <replay-logdir> <out.tsv> <name=baseline-logdir>... : for every module of the replay (last record per
module), compare its warning header lines (^\S+\.lean:\d+:\d+: warning…, the whole line) with those of the baseline
build log of the SAME source (record with equal source_sha256 in a baseline results.jsonl; first baseline set listed
wins). Status: SAME (identical ordered lists), DIFF, NEWSRC (no baseline record of that source; listed with its own
warning lines). Prints counts."""
import sys, json, re, os
rd, out = sys.argv[1:3]
WL = re.compile(r'^\S+\.lean:\d+:\d+: warning.*$', re.M)
def last(d):
    x = {}
    for l in open(os.path.join(d, 'results.jsonl')):
        r = json.loads(l)
        if 'module' in r and r['rc'] == 0: x[r['module']] = r
    return x
def wl(d, m):
    return WL.findall(open(os.path.join(d, 'mods', m.replace('/', '_') + '.log'), encoding='utf-8', errors='replace').read())
bases = []
for a in sys.argv[3:]:
    n, d = a.split('=', 1); bases.append((n, d, {(r['module'], r['source_sha256']): r for r in last(d).values()}))
rows = []; cnt = {}
for m, r in sorted(last(rd).items()):
    mine = wl(rd, m); hit = None
    for n, d, idx in bases:
        if (m, r['source_sha256']) in idx: hit = (n, d); break
    if hit is None:
        st = 'NEWSRC'; det = ' | '.join(mine)
    else:
        theirs = wl(hit[1], m); st = 'SAME' if theirs == mine else 'DIFF'
        det = hit[0] + ('' if st == 'SAME' else ' | mine: ' + ' | '.join(mine) + ' || base: ' + ' | '.join(theirs))
    cnt[st] = cnt.get(st, 0) + 1
    rows.append(f'{st}\t{m}\t{len(mine)}\t{r["sorry"]}\t{det}')
open(out, 'w').write('status\tmodule\twarning_lines\tsorry\tdetail\n' + '\n'.join(rows) + '\n')
print(' '.join(f'{k} {v}' for k, v in sorted(cnt.items())), 'over', len(rows), 'modules')
for x in rows:
    if not x.startswith('SAME'): print(x[:600])
