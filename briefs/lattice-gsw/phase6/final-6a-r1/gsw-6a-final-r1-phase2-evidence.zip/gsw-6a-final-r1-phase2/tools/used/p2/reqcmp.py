"""reqcmp.py <head-rule10-dir> <base-rule10-dir> <owner-suffix>... : for each owner (label suffix, e.g.
Cryptography_Games_Probability) and each variant (seals/A, seals/B, seals-coe/A, seals-coe/B; the base uses the same
directory names), compare the request name sets (rows[].spelling) of the head and base seal records; also print strict A
minus coe A per owner, and the install/EOF verification fields when present. Owners missing on one side are reported."""
import sys, json, os, glob
hd, bd = sys.argv[1:3]
def rec(d, v, owner):
    for p in glob.glob(os.path.join(d, v, f'Seal{v[-1]}_{owner}.json')): return json.load(open(p))
    return None
for owner in sys.argv[3:]:
    for v in ('seals/A', 'seals/B', 'seals-coe/A', 'seals-coe/B'):
        h, b = rec(hd, v, owner), rec(bd, v, owner)
        if not h or not b: print(f'{owner} {v}: head {"present" if h else "MISSING"}, base {"present" if b else "MISSING"}'); continue
        hs, bs = {r['spelling'] for r in h['rows']}, {r['spelling'] for r in b['rows']}
        print(f'{owner} {v}: head {len(hs)} requests, base {len(bs)}; equal name sets: {hs == bs}'
              + ('' if hs == bs else f'; head-only {sorted(hs - bs)}; base-only {sorted(bs - hs)}'))
    sa, ca = rec(hd, 'seals/A', owner), rec(hd, 'seals-coe/A', owner)
    if sa and ca: print(f'{owner} head strict A minus coe A: {sorted({r["spelling"] for r in sa["rows"]} - {r["spelling"] for r in ca["rows"]})}')
