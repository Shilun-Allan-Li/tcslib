"""sigkey.py <repo> <commit>...: for each commit, extract the gpgsig SSHSIG armor and print the SHA256 fingerprint of the
embedded public key (key identity only; no cryptographic verification: ssh-keygen is not installed and the local
signing-key .pub file is empty)."""
import sys, subprocess, base64, struct, hashlib
repo = sys.argv[1]
fp = lambda b: 'SHA256:' + base64.b64encode(hashlib.sha256(b).digest()).decode().rstrip('=')
for c in sys.argv[2:]:
    raw = subprocess.run(['git', '-C', repo, 'cat-file', 'commit', c], capture_output=True, text=True, check=True).stdout
    lines = raw.split('\n'); sig = []; on = False
    for l in lines:
        if l.startswith('gpgsig '): on = True; l = l[7:]
        elif on and l.startswith(' '): l = l[1:]
        elif on: break
        if on: sig.append(l)
    if not sig: print(c, 'UNSIGNED'); continue
    body = base64.b64decode(''.join(x for x in sig if not x.startswith('-----')))
    assert body[:6] == b'SSHSIG'
    n = struct.unpack('>I', body[10:14])[0]; key = body[14:14 + n]
    print(c, 'SSHSIG key', fp(key))
