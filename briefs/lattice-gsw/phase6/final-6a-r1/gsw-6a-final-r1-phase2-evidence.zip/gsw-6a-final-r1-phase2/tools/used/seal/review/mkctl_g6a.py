"""mkctl_g6a.py (gsw-6a statements, phase 2, maintainer, 2026-11-17): mkctl_bb1s.py with the harness unchanged
(assemble, the covering-subset choice of seal records, the plan format, SEAL_CHUNK) and the rows B replaced by the
6a rows; namespace G6aControls. Each row is a negative (the rfl/Iff.rfl unfolding of a definition, which must fail
exactly once under an owner's seal whose request set contains the definition) and a positive (its published reader,
which must pass). The ten rows of the delivery's own paired controls (evidence/rule10/controls, one per new owner:
BranchingProgram.yield, evalWith, sigma1, topDepth; DAGGate.IsNAND; litInput; TreeCircuit.balanced;
FormulaArith.val, bitAt, modSumDepth), with the delivery's statements verbatim, plus two rows for O1's extra Rule 10
repairs (G6A-F02): TreeCircuit.sumSize and TreeCircuit.maxFaninL on the empty list, read through sumSize_nil and
maxFaninL_nil. A row whose definition is in no sealed request set is not exercised. Previous header (mkctl_bb1s.py)
follows.
mkctl_bb1s.py (bb1-sim-statements, Claude lead, 2026-11-16): mkctl_bb1m_readers.py with the harness unchanged
(assemble, the covering-subset choice of seal records, the plan format, namespace PairingControls) and one row added
for the changed owner Games/Probability: Games.ProbComp.expect (negative: `expect (pure a) g = g a` by `rfl`, the
unfolding the published reader replaces; positive: `ProbComp.expect_pure a g`). The changed owner Pairing/Group is
covered by the inherited rows BilinearGen.inst (ctlInst, positive inst_eq) and BilinearGen.desc (ctlDesc, positive
desc_eq). Relational defines nothing: no row. Every inherited row is kept verbatim (rows whose target is in no sealed
request set are not exercised). Previous header (mkctl_bb1m_readers.py) follows.
mkctl_bb1m_readers.py (fill bb1-machine, Claude lead, 2026-11-16): mkctl_bb1m.py with the harness unchanged
(assemble, the covering-subset choice of seal records, the plan format, namespace PairingControls) and seven rows
added, one per approved reader, each a negative (the unfolding the reader replaces, stated in a consumer's context:
the reader's own statement, `type_of%` of the reader, proved by the owner's own proof term) and a positive (the
reader): IBEScheme.oracleImpl (oracleImpl_zero_onSpec, oracleImpl_one_onSpec, oracleImpl_two_onSpec; negative
`(OracleComp.bind_pure _).symm`), bb1Scheme (ofFn_bb1Scheme_encPP and ofFn_bb1Scheme_encSK, negative `rfl`;
bb1Scheme_msgSpace_iff, negative `exists_congr fun _ => List.ofFn_inj.symm`) and bb1SimCt (ofFn_bb1SimCt, negative
`by rw [padFin_ofFn]; rfl`). The fill adds no new definition, so no helper-definition row is added. The covering
subset picks, per target and variant, the sealed owner with the fewest requests containing it (a consumer of
Defs/BonehBoyen, where these definitions are foreign). Previous header (mkctl_bb1m.py) follows.
mkctl_bb1m.py (fill-bb1-machine, unit bb1-machine, T4): mkctl_pbdh.py with the harness unchanged (assemble, the
covering-subset choice of seal records, the plan format, namespace PairingControls) and thirteen rows added for
definitions foreign to the sealed owners of this fill (the helper modules under BonehBoyenMachine/ and the owned
BonehBoyenMachine.lean) that their proofs read only through published readers: IBEScheme.inLens (inLens_zero),
IBEScheme.outLens (outLens_two), Pairing.tupleStr (tupleStr_eq), BB1.idToZ (idToZ_eq), Games.PolyHandler.input
(input_eq), ETTGame.tapeImpl (tapeImpl_apply), and the helper definitions BB1Machine.qLen (qLen_zero), BB1Machine.draw
(draw_eq; Draws, foreign to Words/Handler/Reduction), BB1Machine.sJ, BB1Machine.kT, BB1Machine.blkS, BB1Machine.uS
(sJ_eq, kT_eq, blkS_eq, uS_eq; Words, foreign to Handler/Reduction) and BB1Machine.handler (handler_seedLen; Handler,
foreign to Reduction); each negative the rfl unfolding, each positive the reader (stated as `type_of%` of the reader
where the statement is long, as in the sidImpl row). The pbdh rows are kept verbatim (rows whose target is in no
sealed request set are not exercised).
Previous header (mkctl_pbdh.py) follows.
mkctl_pbdh.py (fill-pair-bdh, unit pair-bdh, T1): mkctl_g40.py with the harness unchanged (assemble, the covering-subset
choice of seal records, the plan format, namespace PairingControls) and nine rows added to B for definitions foreign to
the sealed owner Pairing/Assumptions that the T1 proof reads only through their published readers: NUPPT.distinguisherL
(distinguisherL_eq), NUPPT.runAtL (runAtL_eq), NUPPT.layout (layout_eq), NUPPT.ofPolyTime (coins_ofPolyTime),
NUPPT.advInput (advInput_eq), Games.accept (accept_eq), uprob (uprob_def), BilinearGen.OrderAtLeastExcept
(orderAtLeastExcept_iff), BilinearGen.inst (inst_eq); each negative the rfl/Iff.rfl unfolding, each positive the reader.
The LE-gate40 rows are kept verbatim (rows whose target is in no sealed request set are not exercised).
Previous header (mkctl_g40.py) follows.
mkctl_g40.py (LE-gate40, pairing statements PR #331): mkctl_g36.py with the harness unchanged
(assemble, the covering-subset choice of seal records, the plan format) and the rows B replaced by
pairing rows, each a negative rfl/Iff.rfl unfolding of a definition foreign to some sealed owner
and a positive through its published reader: PolyExpr.eval (B only), padFin (padFin_def),
OracleComp.AllOutputs (allOutputs_pure), BilinearGen.desc (desc_eq), BilinearGen.DBDHAssumption
(dbdhAssumption_iff), IBEScheme.Correct (correct_iff), IBEScheme.sidImpl (sidImpl_init_none),
BB1.F (F_eq), KeyExchange.jouxMsg (jouxMsg_eq); namespace PairingControls.
Attempt 2: the sidImpl row is stated as `type_of% (S.sidImpl_init_none …)`; attempt 1 restated the
equation, whose oracle-0 query and answer types only check by unfolding `inLens`/`outLens` (sealed
foreign definitions of the control file), so both of its theorems failed twice under the seal (a
control-statement defect, not a module finding; rule10/controls-attempt1/).
Previous header (mkctl_g36.py) follows.
mkctl_g36.py (LE-gate36): mkctl_sg.py unchanged except one added row B[PrivateKeyScheme.encodeList]
(negative: the rfl unfolding on a cons; positive: the published reader PrivateKeyScheme.encodeList_cons), the definition
under the G36-01 lemma `length_le_length_encodeList`. Previously mkctl_sg.py (sc-garble review): mkctl_scot.py with sc-garble rows (PolyExpr.eval, the FinDist CoeFun instance,
DAGCircuit.IsFaninTwo (the approved reader), spEncStr, sliceEnc, Good, and the helper definitions sliceMask (Pad),
SliceReduction.slicePost (SliceParser) and SpecialWrongKey.prefixTest (WrongKey), foreign to their later consumers;
each negative the rfl/Iff.rfl unfolding, each positive its published reader) and namespace ScGarbleControls.
Attempt 2: per-row `open … in` prefixes (the IsFaninTwo row opens only BoolCircuit, the Good row BoolCircuit and
SecureComputation), because Turing is not in Garbling's import closure (attempt 1: unknown namespace in the Garbling probes).
Previously mkctl_scot.py (sc-ot review): mkctl_learning.py with sc-ot rows (PolyExpr.eval, the FinDist CoeFun
instance, NUPPT.layout, Strategy.encodeMsgs, otFunctionality, and the helper definitions OT.mask, OT.simSeg, OT.inA2,
OT.bobView, OT.hcBit, foreign to the later helpers and the owned file; each negative the rfl unfolding, each positive
its published reader) and namespace ScGarbleControls. Previously: mkctl_learning.py (learning-r1 review): mkctl_lamport.py with learning rows (PolyExpr.eval, FinDist.uniform, the FinDist
CoeFun instance, PAC.label, uprob, acceptProb, and the helper definitions LearnPRF.firstBit, tupleWord, learnerFn,
foreign to the later helpers and the owned file) and namespace LearningControls. Previously: mkctl_lamport.py (lamport review): mkctl_dlcrh.py with lamport rows (padFin, PolyExpr.eval, ProbComp.expect, ProbComp.sample, OracleComp.bind (the three names of the patch-4 opacity block), LamportFill.secretWord, LamportFill.signatureBlock, LamportMachine.u). Previously: mkctl_dlcrh.py (dl-crh review): mkctl_extnosrc.py with dl-crh rows (padFin, PolyExpr.eval, Authentication.splitBits, Candidates.expSampleRaw (new reader expSampleRaw_eq), FromDiscreteLog.modularDifference, FromDiscreteLog.residueFinEquiv). Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
G = 'TCSlib.Cryptography.Games'
P = 'TCSlib.Cryptography.Pairing'
IB = 'TCSlib.Cryptography.AdvancedEncryption.IdentityBased'
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
def drow(name, stmt, neg, reader):
    return row(name, f"theorem {name} {stmt} :=\n  {neg}\n", f"theorem {name}Reader {stmt} :=\n  {reader}\n")
BP = 'BranchingProgram'; TC = 'BoolCircuit.TreeCircuit'; FA = 'BoolCircuit.FormulaArith'
B = {
 BP + '.yield': drow("ctlYield",
   "(B : BranchingProgram 3 2) (x : Fin 2 → Bool) : B.yield x = B.instrs.foldl (fun f ι => ι.eval x ∘ f) id",
   "rfl", "BranchingProgram.yield_eq B x"),
 BP + '.evalWith': drow("ctlEvalWith",
   "(B : BranchingProgram 3 2) (x : Fin 2 → Bool) (V : Fin 3 → ℕ) : B.evalWith (fun b (u v : ℕ) => if b then v else u) x V = B.instrs.foldl (fun U ι => ι.stepWith (fun b (u v : ℕ) => if b then v else u) x U) V",
   "rfl", "BranchingProgram.evalWith_eq _ x B V"),
 BP + '.sigma1': drow("ctlSigma1", ": BranchingProgram.sigma1 = List.formPerm [0, 1, 2, 3, 4]",
   "rfl", "BranchingProgram.sigma1_eq"),
 BP + '.topDepth': drow("ctlTopDepth",
   "(w : ℕ) : BranchingProgram.topDepth w = w * Nat.clog 2 w + Nat.clog 2 w + 3",
   "rfl", "BranchingProgram.topDepth_eq w"),
 'BoolCircuit.DAGGate.IsNAND': drow("ctlIsNAND",
   "(g : BoolCircuit.DAGGate) : g.IsNAND ↔ g.kind = .not ∧ g.args.length ≤ 2",
   "Iff.rfl", "BoolCircuit.DAGGate.isNAND_iff g"),
 'BoolCircuit.litInput': drow("ctlLitInput",
   "(x : Fin 2 → Bool) : BoolCircuit.litInput x = Fin.append x fun i => !x i",
   "rfl", "BoolCircuit.litInput_eq x"),
 TC + '.balanced': drow("ctlBalanced",
   "(b : Bool) : BoolCircuit.TreeCircuit.balanced b ([] : List (BoolCircuit.TreeCircuit 2)) = .node b []",
   "rfl", "BoolCircuit.TreeCircuit.balanced_nil b"),
 FA + '.val': drow("ctlVal",
   "(x : Fin 2 → Bool) (U : List (BoolCircuit.TreeCircuit 2)) : BoolCircuit.FormulaArith.val x U = BoolCircuit.bitsVal (U.map fun c => c.eval x)",
   "rfl", "BoolCircuit.FormulaArith.val_eq x U"),
 FA + '.bitAt': drow("ctlBitAt",
   "(x : Fin 2 → Bool) (U : List (BoolCircuit.TreeCircuit 2)) (j : ℕ) : BoolCircuit.FormulaArith.bitAt x U j = (U.map fun c => c.eval x).getD j false",
   "rfl", "BoolCircuit.FormulaArith.bitAt_eq x U j"),
 FA + '.modSumDepth': drow("ctlModSumDepth",
   "(M q : ℕ) : BoolCircuit.FormulaArith.modSumDepth M q = 4 * BoolCircuit.FormulaArith.csaLevels M + Nat.clog 2 M + 2 * Nat.clog 2 (Nat.clog 2 M + Nat.clog 2 q + 1) + 10",
   "rfl", "BoolCircuit.FormulaArith.modSumDepth_eq M q"),
 TC + '.sumSize': drow("ctlSumSizeNil",
   ": BoolCircuit.TreeCircuit.sumSize ([] : List (BoolCircuit.TreeCircuit 2)) = 0",
   "rfl", "BoolCircuit.TreeCircuit.sumSize_nil"),
 TC + '.maxFaninL': drow("ctlMaxFaninLNil",
   ": BoolCircuit.TreeCircuit.maxFaninL ([] : List (BoolCircuit.TreeCircuit 2)) = 0",
   "rfl", "BoolCircuit.TreeCircuit.maxFaninL_nil"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace G6aControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end G6aControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
