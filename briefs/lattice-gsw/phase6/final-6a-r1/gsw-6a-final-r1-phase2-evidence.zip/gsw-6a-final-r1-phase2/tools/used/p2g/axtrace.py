"""axtrace.py <axioms-probe-log> <adm-file> <out> (gsw-6a phase 2): summarize the delivery-form axiom census of R2.
DECL/AUX lines: module, constant, axioms; TRACE lines: constant, via [direct sorryAx constants of the modules].
Checks: (1) every axiom outside propext/Classical.choice/Quot.sound is sorryAx; (2) the sorryAx constants are exactly the
admitted targets (ADMISSION lines of admcheck.py's output, mapped by full name) plus the listed dependents; (3) each target's
trace is itself only; (4) each dependent's trace; (5) no AUX constant has sorryAx."""
import sys, re, collections
log, adm, out = sys.argv[1:4]
STD = {'propext', 'Classical.choice', 'Quot.sound'}
rows, trace = [], {}
for l in open(log, encoding='utf-8'):
    x = l.rstrip('\n').split('\t')
    if x[0] in ('DECL', 'AUX'):
        axs = [a.strip() for a in x[3].strip('[]').split(',') if a.strip()]
        rows.append((x[0], x[1], x[2], axs))
    elif x[0] == 'TRACE':
        trace[x[1]] = [a.strip() for a in x[2][len('via '):].strip('[]').split(',') if a.strip()]
targets = {l.rstrip('\n').split('\t')[2] for l in open(adm) if l.startswith('ADMISSION')}
nonstd = [(k, m, c, [a for a in axs if a not in STD]) for k, m, c, axs in rows if set(axs) - STD]
bad_ax = [r for r in nonstd if r[3] != ['sorryAx']]
sorry = {c for k, m, c, axs in rows if 'sorryAx' in axs}
aux_sorry = [c for k, m, c, axs in rows if k == 'AUX' and 'sorryAx' in axs]
deps = sorted(sorry - targets)
lines = [f'constants {len(rows)} (DECL {sum(1 for r in rows if r[0] == "DECL")}, AUX {sum(1 for r in rows if r[0] == "AUX")}); '
         f'by module {dict(collections.Counter(r[1].split(".")[-1] for r in rows))}',
         f'axiom sets: {dict(collections.Counter(str(sorted(r[3])) for r in rows))}',
         f'non-standard axioms other than sorryAx: {bad_ax}',
         f'sorryAx constants {len(sorry)}; admitted targets {len(targets)}; targets with sorryAx {len(sorry & targets)}; '
         f'targets without sorryAx {sorted(targets - sorry)}; AUX with sorryAx {aux_sorry}',
         f'non-target sorryAx constants ({len(deps)}): {deps}',
         f'targets whose trace is not exactly itself: {[(t, trace.get(t)) for t in sorted(targets) if trace.get(t) != [t]]}']
for d in deps: lines.append(f'TRACE {d} via {trace.get(d)}')
open(out, 'w').write('\n'.join(lines) + '\n'); print('\n'.join(lines))
