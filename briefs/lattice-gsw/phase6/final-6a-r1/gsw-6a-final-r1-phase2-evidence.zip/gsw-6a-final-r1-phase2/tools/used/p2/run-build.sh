#!/usr/bin/env bash
# run-build.sh <worktree> <queue> <olean-out> <logdir> (bb1-sim phase 2): snapshots.md job recipe step 4: runner.py (the
# advance's tools-used/runner.py, unmodified copy) through scripts/lean_check_tree.sh with TCSLIB_OLEANS=<olean-out>; one Lean
# process; stops at the first failure.
set -u
W=$1; Q=$2; OUT=$3; L=$4; SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
cd $W; export PATH=$HOME/.elan/bin:$PATH TMPDIR=$SP/bb1p2/tmp; mkdir -p $L
echo "start $(date -u +%FT%TZ)" > $L/runner.start; df -m / | tail -1 > $L/df-launch.txt
python3 -I $SP/bb1p2/tools/runner.py $W $Q $OUT $L
echo "runner exit $? $(date -u +%FT%TZ)" > $L/runner.exit; df -m / | tail -1 >> $L/df-launch.txt
