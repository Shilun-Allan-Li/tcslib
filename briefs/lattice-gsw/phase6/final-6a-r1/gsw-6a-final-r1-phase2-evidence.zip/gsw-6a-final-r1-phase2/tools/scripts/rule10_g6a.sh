#!/usr/bin/env bash
# rule10_g6a.sh <series> <phase>... (gsw-6a statements phase 2, maintainer, 2026-11-17): the bb1-sim phase-2 driver
# tools/rule10_bb1s.sh (and its phase-2b form rule10_352.sh) re-pointed to this job. Changes:
# (1) series: o1 (R1: land/gsw-6a-o1 export, tree olean-replay-6a-o1, owners = O1's four changed modules),
#     stmt (R2: land/gsw-6a-statements export, tree olean-replay-6a-stmt, owners = the 16 new or changed files),
#     root (owner = root TCSlib, coe-A only: phase rootcoeA; tree olean-r2-probe = a cp -al copy of the R2 output, so that
#     it runs beside the stmt series on a tree of its own; probes write nothing), base (records tip export, tree olean-base-tip = a
#     cp -al copy of the snapshot plus the Mathlib overlay, read only by the probes; owner TreeNCAC, for G6A-F05);
# (2) touched.json against the records tip 84d144b5 (Lean-equal to snapshot #4's T 463f2244);
# (3) controls: tools/seal/review/mkctl_g6a.py (the 6a rows; harness unchanged);
# (4) SEAL_CHUNK=1000 for every seal and control (the request sets of CircuitComplexity, ComputationalModels and the
#     root exceed 1,000 rows; the facade overflows Lean's stack unchunked, G6A-F10); smaller sets are unaffected;
# (5) mkseals_ab.py/mkseals_coe.py carry the delivery's one-line 'Root' label fix (byte-identical to its xr copies).
# Every probe through runner_full.py (lean -DmaxErrors=0, no -o: nothing is written to the tree). One Lean process
# per call; the caller runs at most two calls at once, on different trees.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
E=$SP/g6a-p2/ev; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools
B=84d144b565bd7a983a05d5b8dda87442bdaec1a4
C=TCSlib.Complexity.CircuitComplexity; BPm=TCSlib.Complexity.BranchingPrograms
O1MODS="$C.FormulaArith.Combinators $C.FormulaArith $C.TreeNCAC $C"
STMTMODS="$BPm.Defs $BPm.Eval $BPm.Barrington $BPm.BarringtonConverse $BPm.NC1 $BPm $C.FormulaArith.Combinators $C.FormulaArith.CarrySave $C.FormulaArith.Compare $C.FormulaArith.ModSum $C.FormulaArith $C.NANDForm $C.NANDLayering $C.TreeNCAC $C TCSlib.ComputationalModels"
files() { for m in "$@"; do echo -n "$(echo $m | tr . /).lean "; done; }
case $1 in
o1) W=$SP/g6a-p2/wt-o1; TREE=$SP/olean-replay-6a-o1; NAME=o1; H=a57dcf77a06455145181a26f9163abc5944157b4; MODS=$O1MODS;;
stmt) W=$SP/g6a-p2/wt-stmt; TREE=$SP/olean-replay-6a-stmt; NAME=stmt; H=66036926bcbffa9caf44f9e9469ca63bc555c374; MODS=$STMTMODS;;
root) W=$SP/g6a-p2/wt-stmt; TREE=$SP/g6a-p2/olean-r2-probe; NAME=root; H=66036926bcbffa9caf44f9e9469ca63bc555c374; MODS=TCSlib;;
base) W=$SP/g6a-p2/wt-tip; TREE=$SP/g6a-p2/olean-base-tip; NAME=base; H=$B; MODS=$C.TreeNCAC;;
esac
FILES=$(files $MODS)
shift
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$SP/g6a-p2/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
PP=G6aSeal
mkdir -p $R/order $R/probe-sources $W/$PP $E/statements
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
touched)
  python3 -I $T/review/touched.py /home/user/tcslib $B $H $TJ $FILES > $E/statements/touched-$NAME.tsv; echo "touched rc=$?";;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6a phase 2 $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
seals)
  R10DIR=$R TOUCHED=$TJ bash $T/rule10_b.sh $T $W $E $PP $H $T/review/mkctl_g6a.py $MODS > $R/rule10-driver.out 2>&1; echo "rule10_b rc=$?";;
baseseals)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/A $PP/ZS SealA_ $MODS > $R/mkseals-A.log
  SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/B $PP/ZS SealB_ $MODS > $R/mkseals-B.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/B $PP/ZC SealB_ $MODS > $R/mkseals-coe-B.log
  (cd $W && ls $PP/ZS/*.lean $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  python3 -I $T/runner_full.py $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  for v in seals/A seals/B seals-coe/A seals-coe/B; do
    python3 -I $T/review/sealsum.py $R/$v $R/seal-runs $TJ $R/$(echo $v | tr / -).tsv; done
  cat $R/mkseals-*.log; cat $R/seals-*.tsv;;
rootcoeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/RC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/RC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  python3 -I $T/runner_full.py $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
scan)
  S=$E/scan/$NAME; mkdir -p $S
  SF=$(git diff --name-only $B $H -- 'TCSlib/*.lean' | grep '/')
  [ $NAME = base ] && SF=$FILES  # base: the tip itself (B = H), scan the owner's file
  echo $SF > $S/files.txt
  SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W $TJ $S/items-head.json $W/$PP/ScanKindsHead.lean $SF > $S/scan1.out 2>&1
  cp $W/$PP/ScanKindsHead.lean $S/ScanKindsHead.lean.txt
  echo $PP/ScanKindsHead > $S/order.txt
  python3 -I $T/runner_full.py $W $S/order.txt $TREE $S/runs > $S/scan-runner.out 2>&1
  python3 -I $T/scan2.py $S/items-head.json $S/runs/mods/${PP}_ScanKindsHead.log $S/explicit-head.json > $S/scan2-head.log 2>&1; echo "scan2 rc=$?";;
probes)
  # $PROBES: space-separated probe basenames from $SP/g6a-p2/probe-src, copied under $W/G6aProbe/
  D=$E/probes/$NAME; mkdir -p $D $W/G6aProbe; : > $D/order.txt
  for p in $PROBES; do cp $SP/g6a-p2/probe-src/$p.lean $W/G6aProbe/$p.lean; cp $SP/g6a-p2/probe-src/$p.lean $D/$p.lean.txt; echo G6aProbe/$p >> $D/order.txt; done
  python3 -I $T/runner_full.py $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
