#!/usr/bin/env bash
# run-build-s6.sh <series r1|r2> (gsw-6a re-replay on snapshot #6): LE-g45b's run-build-g45b.sh with this job's paths and
# the series as a parameter. r1: export of R1' (tip x #358) on $SP/olean-replay-6a-o1-s6; r2: export of R2' (tip x #358 x
# #359) on $SP/olean-replay-6a-stmt-s6. <series>/plan/queue.txt through the recipe's runner.py (unmodified), one module per
# call; before each module the host's Lean slot count is checked (wait, polling 30 s, while 3 or more lean processes run);
# stop if free disk falls under 1.5 GB.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
B=$SP/g6a-s6; S=$1; RUNNER=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/runner.py
case $S in r1) OUT=$SP/olean-replay-6a-o1-s6;; r2) OUT=$SP/olean-replay-6a-stmt-s6;; *) echo "series?"; exit 2;; esac
E=$B/$S; WX=$B/wtx-$S
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$B/tmp
mkdir -p $E/build/one $B/tmp
echo "start $(date -u +%FT%TZ)" > $E/build/runner.start; df -m / | tail -1 > $E/build/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $E/build/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $E/build/slot-log.txt
  echo "$m" > $E/build/one/order.txt
  python3 -I $RUNNER $WX $E/build/one/order.txt $OUT $E/build < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $E/build/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $E/build/runner.exit; exit 2; }
done < $E/plan/queue.txt
echo "runner exit 0 $(date -u +%FT%TZ)" >> $E/build/runner.exit; df -m / | tail -1 >> $E/build/runner.exit
