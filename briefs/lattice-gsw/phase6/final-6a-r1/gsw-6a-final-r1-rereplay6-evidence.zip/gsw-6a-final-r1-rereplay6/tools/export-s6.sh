#!/usr/bin/env bash
# export-s6.sh <tree-or-rev> <dir> <out> (gsw-6a re-replay on snapshot #6): export the Lean paths of a merge tree (the set
# LE-g45/LE-g45b used: TCSlib TCSlib.lean audits scripts lakefile.lean lake-manifest.json lean-toolchain), symlink
# .lake/packages to the repo's, and check the export blob for blob (g6a-p2 exportcheck.py, unmodified).
set -u
REV=$1; D=$2; OUT=$3; R=/home/user/tcslib; SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
PATHS="TCSlib TCSlib.lean audits scripts lakefile.lean lake-manifest.json lean-toolchain"
[ -e "$D" ] && { echo "exists: $D"; exit 1; }
mkdir -p "$D/.lake" && git -C $R archive --format=tar $REV -- $PATHS | tar -x -C "$D" && ln -s $R/.lake/packages "$D/.lake/packages"
python3 -I $SP/g6a-p2/tools/p2/exportcheck.py $R $REV "$D" $PATHS > $OUT
tail -1 $OUT; du -sm "$D" | cut -f1 | sed 's/^/MB /'
