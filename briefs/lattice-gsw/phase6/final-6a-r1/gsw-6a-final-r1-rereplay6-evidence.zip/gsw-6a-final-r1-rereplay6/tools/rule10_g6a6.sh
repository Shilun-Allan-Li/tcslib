#!/usr/bin/env bash
# rule10_g6a6.sh <series> <phase>... (gsw-6a re-replay on olean snapshot #6, maintainer, 2026-11-17): the snapshot-#5
# re-replay's rule10_g6a5.sh re-pointed to the merge trees and snapshot #6. Changes:
# (1) series: o1 (export of R1' = tip x #358, tree f7247ea3, on olean-replay-6a-o1-s6; owners = O1's four files),
#     stmt (export of R2' = tip x #358 x #359, tree 901bf528, on olean-replay-6a-stmt-s6; the same 16 owners as #5),
#     root (R2', owner TCSlib, probe prefix G6aRoot), hier (R2', owner Hierarchy, which LE-g45 changed; compared with
#     LE-g45's head record; probe prefix G6aHier). <rev> is the merge tree (mkseals_coe reads `git show <tree>:<path>`).
# (2) touched.json against the records tip 6f138550 (Lean-equal to snapshot #6's T 8060f6b7).
# (3) phases: collect, coeA, probes ($PROBES from $PSRC). Every Lean process goes through LE-g45's gated_full.sh
#     (unchanged; o1 series and probes) or gated_full_s6.sh (the same plus a disk guard; stmt, hier, root after the
#     disk incident, log/aborted-1): slot check before each probe, wait while 3 or more lean processes run.
# (4) SEAL_CHUNK=1000, tools unchanged (g6a-p2/tools).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/g6a-s6; E=$X; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RUN="bash $X/tools/gated_full_s6.sh"
C=TCSlib.Complexity.CircuitComplexity; BPm=TCSlib.Complexity.BranchingPrograms
O1MODS="$C.FormulaArith.Combinators $C.FormulaArith $C.TreeNCAC $C"
STMTMODS="$BPm.Defs $BPm.Eval $BPm.Barrington $BPm.BarringtonConverse $BPm.NC1 $BPm $C.FormulaArith.Combinators $C.FormulaArith.CarrySave $C.FormulaArith.Compare $C.FormulaArith.ModSum $C.FormulaArith $C.NANDForm $C.NANDLayering $C.TreeNCAC $C TCSlib.ComputationalModels"
PP=G6aSeal; R1T=f7247ea3edff8d96fb53ff1912cabd792f780743; R2T=901bf528f11571286883c52f2515f83c281dcc82
case $1 in
o1) W=$X/wtx-r1; TREE=$SP/olean-replay-6a-o1-s6; NAME=o1; H=$R1T; MODS=$O1MODS; TJ=$E/statements/touched-o1.json;;
stmt) W=$X/wtx-r2; TREE=$SP/olean-replay-6a-stmt-s6; NAME=stmt; H=$R2T; MODS=$STMTMODS; TJ=$E/statements/touched-stmt.json;;
root) W=$X/wtx-r2; TREE=$SP/olean-replay-6a-stmt-s6; NAME=root; H=$R2T; MODS=TCSlib; PP=G6aRoot; TJ=$E/statements/touched-root.json;;
hier) W=$X/wtx-r2; TREE=$SP/olean-replay-6a-stmt-s6; NAME=hier; H=$R2T; MODS=$C.Hierarchy; PP=G6aHier; TJ=$E/statements/touched-stmt.json;;
*) echo "unknown series $1"; exit 2;;
esac
shift
R=$E/rule10/$NAME
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$X/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP $X/tmp
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6a re-replay #6 $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  $RUN $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
probes)
  D=$E/probes/$NAME; mkdir -p $D $W/G6aProbe; : > $D/order.txt
  for p in $PROBES; do cp $PSRC/$p.lean $W/G6aProbe/$p.lean; cp $PSRC/$p.lean $D/$p.lean.txt; echo G6aProbe/$p >> $D/order.txt; done
  $RUN $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
