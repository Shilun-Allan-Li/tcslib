Owner-side PR **O1** of GSW phase 6a (P6-Q6): the section of `TreeNCAC.lean` that simulates an unbounded gate by a balanced binary tree moves into the new `Complexity/CircuitComplexity/FormulaArith/Combinators.lean`, with the facade `FormulaArith.lean`. `TreeNCAC.combine` becomes the public `BoolCircuit.TreeCircuit.balanced`. The 6a statement PR is stacked on this one.

**Head:** `a616adcac0760ab56b1b0a2a4869f4763843f9ab`, a maintainer-signed cherry-pick of the worker's `413e9aa4` (delivery `inbox/fills/gsw-6a-statements/` at exchange `d7a9adb5`), re-cut onto the records tip `e1d39836` after #340 and #346 merged (phase 2's head was `a57dcf77`; range-diff 1/1 `=`). The tree `a461632b` equals `git merge-tree` of the tip and `413e9aa4`. Four files change:
- `FormulaArith/Combinators.lean` (new, 246 lines) and the facade `FormulaArith.lean` (new, 23 lines);
- `TreeNCAC.lean` (537 → 359 lines): it imports `Combinators`, and `toBinary` and its proofs call `balanced` and its lemmas; every statement of the file is unchanged;
- `CircuitComplexity.lean`: one import and its contents line.

## Public API
- `TreeCircuit.balanced b cs` with `balanced_eval`, `maxFanin_balanced_le` (`≤ max 2 (maxFaninL cs)`), `depth_balanced_le` (`≤ maxDepth cs + ⌈log₂ |cs|⌉ + 1`), `size_balanced_le` (`≤ sumSize cs + |cs| + 1`), and the readers `balanced_nil` and `balanced_singleton` (`rfl`). All are proved and have formula docstrings; `pairUp`, `combineFuel` and their lemmas stay private.
- The moved proofs are unchanged except five Rule 10 repairs, ruled as accepted (6a Q2): the three brief-named reads of `TreeCircuit.eval` now go through `eval_node_true`/`eval_node_false`, and the nil cases of `sumSize_pairUp` and `maxFaninL_pairUp` go through `sumSize_nil` and `maxFaninL_nil`.

## Checks (maintainer, this head on the tip, from olean snapshot #5; `briefs/lattice-gsw/phase6/final-6a-r1/phase2.md`, R1 and "Re-replay on snapshot #5")
- **Build** (re-replay on snapshot #5, T `3f540c22`): 9/9 modules rebuild with rc 0 and 0 errors (`Combinators`, `FormulaArith`, `TreeNCAC`, `NCAC`, `Parity`, `Hierarchy`, `CircuitComplexity`, `ComputationalModels`, root); the state check gives 1429/1429 (1424 on #4, plus the 5 modules #340/#346 added).
- **Admissions:** +0 against the tip (unchanged from #4).
- **Axioms:** O1's 141 constants use standard axioms only; the probe log is byte-identical to the #4 run.
- **Rule 10:**
  - canonical coe-A seals, re-run on #5: `Combinators` 174 and `FormulaArith` 194 requests with 0 errors, and the `CircuitComplexity` facade 3659 (chunked) with 0 errors; request sets and outcomes equal the #4 run;
  - `TreeNCAC` (194) fails twice, at the private `maxDepth_map_le` and `maxFaninL_map_le`; both failures are byte-identical at the tip, where the file fails 4 times (the other two are the nil cases this PR repairs). This is pre-existing (G6A-F05), for clean-up part 2;
  - the strict A/B and coe-B seals, the paired controls (ALL_OK in both harnesses, including rows for `sumSize`/`maxFaninL` that exercise the two extra repairs) and the explicit-unfold scan (0 foreign unfolds in `Combinators`, `FormulaArith` and the facade; `TreeNCAC` keeps 4 pre-existing ones, it had 7 at the tip) are carried forward from #4: every owner's import closure is byte-identical at both heads (equal closure keys), and the coe-A re-run reproduces the #4 request sets and probes.
- **Lint:** the `campaign_style_lint --check8b` FAIL/WARN line sets equal the tip's; `style_lint` gives 0 findings in the new files (both byte-identical to #4).
- **#340 and #346** are merged into the base; neither shares a file with this PR or a module with its closure except the import-only root, which rebuilds cleanly.

## Review and merge order
- **Verdict:** **ACCEPT** (`briefs/lattice-gsw/phase6/final-6a-r1/review.md`, phase 1 and phase 2). **Gate 45 (Codex) audits both** this PR and the stacked statement PR.
- **Merge order:** this PR merges **first**. Then the 6a statement PR, which is stacked on this branch, is retargeted to `cryptography/pass-shelat-ch2-4`.
- **Snapshot:** on merge, if the merge commit's Lean paths equal tree `a461632b`, the replay output `olean-replay-6a-o1` is adopted as the next olean snapshot.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA
