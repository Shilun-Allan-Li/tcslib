r"""sealcmp.py <new-records-dir> <old-records-dir> <new-tsv> <old-tsv> <out> (gsw-6a re-replay #5): per owner, compare the coe-A
seal record of the re-replay with phase 2's: requested count, request name set (rows[].spelling), probe SHA-256, source
SHA-256, closure module count; and the sealsum outcome (every tsv column). Prints a summary."""
import sys, json, glob, os, csv
nd, od, nt, ot, out = sys.argv[1:6]
def recs(d):
    r = {}
    for p in glob.glob(os.path.join(d, 'Seal*.json')):
        if os.path.basename(p) == 'manifest.json': continue
        x = json.load(open(p)); r[x['label']] = x
    return r
def tsv(p):
    rows = list(csv.reader(open(p), delimiter='\t'))
    return [], {r[0]: r for r in rows if r}
N, O = recs(nd), recs(od); nh, NT = tsv(nt); oh, OT = tsv(ot)
lines = [f'# new {nd}', f'# old {od}', '# tsv columns (sealsum, no header): label, requested, rc, errors, install, eof, failing declarations']
same_all = True
for lab in sorted(set(N) | set(O)):
    a, b = N.get(lab), O.get(lab)
    if a is None or b is None: lines.append(f'{lab}\tMISSING new={a is not None} old={b is not None}'); same_all = False; continue
    sa = {r['spelling'] for r in a['rows']}; sb = {r['spelling'] for r in b['rows']}
    f = dict(requested=(a['requested'], b['requested']), names_equal=sa == sb, probe_sha_equal=a['probe_sha256'] == b['probe_sha256'],
             source_sha_equal=a['source_sha256'] == b['source_sha256'], closure_modules=(a['closure_modules'], b['closure_modules']))
    ok = f['names_equal'] and f['probe_sha_equal'] and f['source_sha_equal'] and a['requested'] == b['requested']
    lines.append(f'{lab}\t{"SAME" if ok else "DIFF"}\t' + '\t'.join(f'{k}={v}' for k, v in f.items()))
    if not f['names_equal']:
        lines.append(f'  only-new {len(sa - sb)}: {sorted(sa - sb)[:400]}')
        lines.append(f'  only-old {len(sb - sa)}: {sorted(sb - sa)[:400]}')
    same_all &= ok
# outcome rows: compare every column
skip = set()  # sealsum rows carry no run-specific column
for k in sorted(set(NT) | set(OT)):
    a, b = NT.get(k), OT.get(k)
    if a is None or b is None: lines.append(f'tsv {k}\tMISSING'); same_all = False; continue
    da = [v for i, v in enumerate(a) if i not in skip]; db = [v for i, v in enumerate(b) if i not in skip]
    lines.append(f'tsv {k}\t{"SAME" if da == db else "DIFF"}\t{da}' + ('' if da == db else f'\told {db}'))
    same_all &= da == db
lines.append(f'# RESULT {"ALL SAME" if same_all else "DIFFERENCES"}')
open(out, 'w').write('\n'.join(lines) + '\n'); print('\n'.join(l[:300] for l in lines))
