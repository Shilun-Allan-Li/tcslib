r"""ownerkeys.py <repo> <old-rev> <new-rev> <module>... (gsw-6a re-replay #5): for each module (path form, no .lean), its
import-closure key at <old-rev> and at <new-rev>, computed exactly as stateplan.py's Keys (sha256 of path, source SHA-256 and
the sorted keys of its local imports; local = TCSlib.* / audits.*; Mathlib fixed). Equal keys mean the module's whole local
source closure is byte-identical at both revs. Also prints the closure size. Prints one TSV row per module and a summary."""
import sys, re, hashlib, subprocess
sha = lambda b: hashlib.sha256(b).hexdigest()
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
class Keys:
    def __init__(self, repo, rev):
        self.repo, self.rev, self.k, self.src = repo, rev, {}, {}
    def source(self, m):
        if m not in self.src:
            p = subprocess.run(['git', '-C', self.repo, 'show', f'{self.rev}:{m}.lean'], capture_output=True)
            self.src[m] = p.stdout if p.returncode == 0 else None
        return self.src[m]
    def imports(self, m):
        s = self.source(m)
        return [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', s.decode('utf-8', 'replace'), re.M) if local(i)]
    def key(self, m):
        if m in self.k: return self.k[m]
        s = self.source(m)
        if s is None: self.k[m] = None; return None
        ks = sorted(f'{i}={self.key(i)}' for i in self.imports(m))
        self.k[m] = sha(('\n'.join([m, sha(s)] + ks)).encode())
        return self.k[m]
    def closure(self, m, seen=None):
        seen = set() if seen is None else seen
        if m in seen: return seen
        seen.add(m)
        for i in self.imports(m): self.closure(i, seen)
        return seen
sys.setrecursionlimit(100000)
repo, old, new = sys.argv[1:4]; A, B = Keys(repo, old), Keys(repo, new); eq = 0; mods = sys.argv[4:]
print(f'# old {old} new {new}')
for m in mods:
    a, b = A.key(m), B.key(m); ca, cb = A.closure(m), B.closure(m); eq += a == b
    print(f'{m}\t{"EQUAL" if a == b else "DIFF"}\tclosure {len(ca)}/{len(cb)}\t{a}\t{b}')
    if a != b: print('  only-old', sorted(ca - cb)[:20], 'only-new', sorted(cb - ca)[:20])
print(f'# {eq}/{len(mods)} equal')
