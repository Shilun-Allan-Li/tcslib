r"""rootreq.py <new-coeA-dir> <old-coeA-dir> <repo> <out> (gsw-6a re-replay #5): root coe-A request set of the #5 run against
the #4 run (phase 2): names only in either, the home modules of the added names, whether each is homed in a Lean file that
#340/#346 changed (84d144b5..e1d39836), and whether the rows of the common names are identical."""
import sys, json, glob, collections, subprocess
def rec(d):
    for p in glob.glob(d + '/Seal*.json'): return json.load(open(p))
a, b = rec(sys.argv[1]), rec(sys.argv[2]); repo, out = sys.argv[3], sys.argv[4]
sa = {r['spelling']: r for r in a['rows']}; sb = {r['spelling']: r for r in b['rows']}
on = sorted(set(sa) - set(sb)); oo = sorted(set(sb) - set(sa))
homes = collections.Counter(sa[n]['home'] for n in on)
ch = subprocess.run(['git', '-C', repo, 'diff', '--name-only', '84d144b565bd7a983a05d5b8dda87442bdaec1a4', 'e1d39836ed4a69a34914c35f4c73c71de853dcc6', '--', '*.lean'], capture_output=True, text=True).stdout.split()
chm = {f[:-5].replace('/', '.') for f in ch}
L = [f'root coe-A requests: #5 run {a["requested"]}, #4 run {b["requested"]}; closure modules {a["closure_modules"]} / {b["closure_modules"]}',
     f'only #4: {len(oo)} {oo}', f'only #5: {len(on)}, by home module: {dict(sorted(homes.items()))}',
     f'#340/#346 Lean files (84d144b5..e1d39836): {sorted(chm)}',
     f'every only-#5 name has its home in a #340/#346 file: {all(sa[n]["home"] in chm for n in on)}',
     f'names common to both runs: {len(set(sa) & set(sb))}; their rows identical: {all(sa[n] == sb[n] for n in set(sa) & set(sb))}']
L += [f'  + {n}\t{sa[n]["home"]}' for n in on]
open(out, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L[:6]))
