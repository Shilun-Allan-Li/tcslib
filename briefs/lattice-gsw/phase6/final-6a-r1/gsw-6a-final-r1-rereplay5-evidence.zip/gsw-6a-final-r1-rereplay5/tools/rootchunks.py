r"""rootchunks.py <seal-log> <out> (gsw-6a re-replay #5): the chunk records of a chunked seal probe log. Install records =
`G06-MASK ... phase=install requested=N verified=M`; EOF records = `G06-MASK ... phase=eof` and `G06-SEAL-END`; per record
requested must equal verified. Also counts error lines (`^\S+\.lean:\d+:\d+: error[:(]`) and G06-NAME rows."""
import sys, re
log, out = sys.argv[1:3]; t = open(log, encoding='utf-8', errors='replace').read()
kv = lambda l: dict(re.findall(r'(\w+)=(\S+)', l))
ins = [kv(l) for l in t.splitlines() if l.startswith('G06-MASK') and 'phase=install' in l]
eof = [kv(l) for l in t.splitlines() if l.startswith('G06-MASK') and 'phase=eof' in l]
end = [kv(l) for l in t.splitlines() if l.startswith('G06-SEAL-END')]
seal = [kv(l) for l in t.splitlines() if l.startswith('G06-SEAL ')]
s = lambda rs, k: sum(int(r[k]) for r in rs)
eq = lambda rs: all(r['requested'] == r['verified'] for r in rs)
errs = len(re.findall(r'^\S+\.lean:\d+:\d+: error[:(]', t, re.M))
names = sum(1 for l in t.splitlines() if l.startswith('G06-NAME'))
L = [f'install records {len(ins)} requested sum {s(ins, "requested")} verified sum {s(ins, "verified")} all requested==verified {eq(ins)}',
     f'EOF records (MASK phase=eof) {len(eof)} requested sum {s(eof, "requested")} verified sum {s(eof, "verified")} all equal {eq(eof)}',
     f'SEAL-END records {len(end)} requested sum {s(end, "requested")} verified sum {s(end, "verified")} all equal {eq(end)}',
     f'SEAL records {len(seal)} requested sum {s(seal, "requested")} verified sum {s(seal, "verified")} all equal {eq(seal)}',
     f'G06-NAME rows {names}', f'error lines {errs}']
L += [f'  {r["label"]}  requested={r["requested"]} verified={r["verified"]}' for r in end]
open(out, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))
