r"""clashcmp.py <clash-dir> (gsw-6a re-replay #5): phase 1's clash check over names.py outputs. Reads names-tip.tsv,
names-head.tsv (name, private, file) and changed.txt; new names = names in changed files at the head that the same file
does not declare at the tip; reports new names whose full name the tip declares in another file (and whether all of those
are O1's moves out of TreeNCAC, whose tip copies the head removes), and new names declared more than once at the head."""
import sys, collections
C = sys.argv[1]
rd = lambda p: [l.rstrip('\n').split('\t') for l in open(p) if l.strip()]
tip, head = rd(f'{C}/names-tip.tsv'), rd(f'{C}/names-head.tsv'); ch = set(l.strip() for l in open(f'{C}/changed.txt'))
tipset = {(n, f) for n, p, f in tip}; tipby = collections.defaultdict(set)
for n, p, f in tip: tipby[n].add(f)
new = [(n, p, f) for n, p, f in head if f in ch and (n, f) not in tipset]
headcount = collections.Counter(n for n, p, f in head)
clash = [(n, f, sorted(tipby[n])) for n, p, f in new if tipby.get(n) and f not in tipby[n]]
TN = 'TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean'
o1 = [c for c in clash if all(g == TN for g in c[2])]
other = [c for c in clash if c not in o1]
moved_ok = all(not any(n == m and g == TN for m, q, g in head) for n, f, _ in o1)
dups = sorted({n for n, p, f in new if headcount[n] > 1})
out = [f'tip e1d39836 declared names {len(tip)}; head 73aedcda declared names {len(head)}; changed Lean files {len(ch)}',
       f'new names in the changed files {len(new)} (private {sum(p == "True" for n, p, f in new)})',
       f'same full name at the tip in another file: {len(clash)}; of which O1 moves from TreeNCAC {len(o1)} (tip copies removed at head: {moved_ok}); other {len(other)} {other}',
       f'names declared more than once at the head among the new names: {dups}']
open(f'{C}/clash-result.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
