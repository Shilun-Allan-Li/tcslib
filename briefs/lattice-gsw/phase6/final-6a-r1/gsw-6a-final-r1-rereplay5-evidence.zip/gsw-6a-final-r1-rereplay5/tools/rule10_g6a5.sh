#!/usr/bin/env bash
# rule10_g6a5.sh <series> <phase>... (gsw-6a re-replay on olean snapshot #5, maintainer, 2026-11-17): phase 2's
# rule10_g6a.sh (g6a-p2/scripts) re-pointed to the re-cut heads and snapshot #5. Changes:
# (1) series: o1 (wt-o1 at a616adca, tree olean-replay-6a-o1, owners = O1's four changed modules),
#     stmt (wt-stmt at 73aedcda, tree olean-replay-6a-stmt, owners = the 16 new or changed files),
#     root (wt-stmt, tree olean-replay-6a-stmt, owner = root TCSlib; probe prefix G6aRoot so that its collector does not
#     share a path with the stmt collector). One Lean process at a time on this machine (slot rule), so the root series
#     runs on the R2 tree itself; runner_full.py never writes to the tree (no -o).
# (2) touched.json against the records tip e1d39836 (Lean-equal to snapshot #5's T 3f540c22).
# (3) phases: collect, coeA (canonical coe-A seals only, for every series; phase 2's rootcoeA generalized), probes.
#     Strict A/B, coe B and controls are carried forward (phase2.md "Re-replay on snapshot #5").
# (4) SEAL_CHUNK=1000, tools unchanged (g6a-p2/tools).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/g6a-r5; E=$X/ev; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools
B=e1d39836ed4a69a34914c35f4c73c71de853dcc6
C=TCSlib.Complexity.CircuitComplexity; BPm=TCSlib.Complexity.BranchingPrograms
O1MODS="$C.FormulaArith.Combinators $C.FormulaArith $C.TreeNCAC $C"
STMTMODS="$BPm.Defs $BPm.Eval $BPm.Barrington $BPm.BarringtonConverse $BPm.NC1 $BPm $C.FormulaArith.Combinators $C.FormulaArith.CarrySave $C.FormulaArith.Compare $C.FormulaArith.ModSum $C.FormulaArith $C.NANDForm $C.NANDLayering $C.TreeNCAC $C TCSlib.ComputationalModels"
PP=G6aSeal
case $1 in
o1) W=$X/wt-o1; TREE=$SP/olean-replay-6a-o1; NAME=o1; H=a616adcac0760ab56b1b0a2a4869f4763843f9ab; MODS=$O1MODS;;
stmt) W=$X/wt-stmt; TREE=$SP/olean-replay-6a-stmt; NAME=stmt; H=73aedcdaaaffef7e69ab012d9b9195f150bae68d; MODS=$STMTMODS;;
root) W=$X/wt-stmt; TREE=$SP/olean-replay-6a-stmt; NAME=root; H=73aedcdaaaffef7e69ab012d9b9195f150bae68d; MODS=TCSlib; PP=G6aRoot;;
*) echo "unknown series $1"; exit 2;;
esac
shift
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$X/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6a re-replay #5 $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  python3 -I $T/runner_full.py $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  python3 -I $T/runner_full.py $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
probes)
  # $PROBES: probe basenames from $SP/g6a-p2/probe-src (phase 2's, unchanged), copied under $W/G6aProbe/
  D=$E/probes/$NAME; mkdir -p $D $W/G6aProbe; : > $D/order.txt
  for p in $PROBES; do cp $SP/g6a-p2/probe-src/$p.lean $W/G6aProbe/$p.lean; cp $SP/g6a-p2/probe-src/$p.lean $D/$p.lean.txt; echo G6aProbe/$p >> $D/order.txt; done
  python3 -I $T/runner_full.py $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
