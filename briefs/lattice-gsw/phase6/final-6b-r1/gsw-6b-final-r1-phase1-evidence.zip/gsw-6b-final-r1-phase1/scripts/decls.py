import re,sys
# list declarations (kind name) in Lean files, comments stripped
def strip(s):
    out=[];i=0;depth=0;n=len(s)
    while i<n:
        if s.startswith('/-',i): depth+=1;i+=2;continue
        if depth and s.startswith('-/',i): depth-=1;i+=2;continue
        if depth: 
            out.append('\n' if s[i]=='\n' else ' ');i+=1;continue
        if s.startswith('--',i):
            j=s.find('\n',i); j=n if j<0 else j; out.append(' '*(j-i)); i=j; continue
        out.append(s[i]);i+=1
    return ''.join(out)
pat=re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:private\s+|protected\s+|noncomputable\s+)*(def|theorem|lemma|abbrev|instance|structure|inductive|class)\s+([^\s:({\[]+)?',re.M)
for f in sys.argv[1:]:
    s=strip(open(f,encoding='utf-8').read())
    lines=s.split('\n')
    for m in pat.finditer(s):
        ln=s.count('\n',0,m.start())+1
        # sorry in body: until next decl
        print(f"{f.split('/')[-1]}\t{ln}\t{m.group(1)}\t{m.group(2)}")
