"""Every pNNN-bNNN anchor inside a [TAG, ...] citation (TAG; TAG2 ... groups split on ';') exists
in that tag's ingest at the base."""
import sys, re
W = sys.argv[1]; files = sys.argv[2:]
ing = {'BV14': 'brakerski-vaikuntanathan-2014-fhe', 'BV11': 'brakerski-vaikuntanathan-2011-fhe',
       'AP14': 'alperin-sheriff-peikert-2014-bootstrapping', 'GSW13': 'gentry-sahai-waters-2013-fhe',
       'Pei16': 'peikert2016-lattice-survey', 'Bar89': 'barrington-1989-bounded-width-bp'}
anchors = {t: set(re.findall(r'p\d{3}-b\d{3}', open(f'{W}/ref-{n}.md', encoding='utf-8').read())) for t, n in ing.items()}
tot = bad = 0; tags = set()
for f in files:
    s = re.sub(r'\s+', ' ', open(f, encoding='utf-8').read())
    for m in re.finditer(r'\[((?:BV14|BV11|AP14|GSW13|Pei16|Bar89|Gen09)[^\[\]]*)\]', s):
        cur = None
        for part in m.group(1).split(';'):
            part = part.strip(); t = part.split(',')[0].strip()
            if t in anchors or t == 'Gen09': cur = t
            else: tags.add(t); t = cur
            if t not in anchors: continue
            for a in re.findall(r'p\d{3}-b\d{3}', part):
                tot += 1
                if a not in anchors[t]: bad += 1; print('MISSING', f.split('/')[-1], t, a)
print('anchors checked', tot, 'missing', bad, 'other tags', tags)
