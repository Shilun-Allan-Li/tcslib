"""Recount Rule 10 seals from raw logs: per run dir and log, errors (both forms), install
and eof records requested=verified."""
import sys, re, os, glob
for root in sys.argv[1:]:
    for v in ['A', 'B', 'coeA', 'coeB']:
        logs = sorted(glob.glob(f'{root}/seal/run-{v}/mods/*.log'))
        tot = 0; bad = []; req = 0
        for f in logs:
            t = open(f, encoding='utf-8', errors='replace').read()
            e1 = len(re.findall(r'^\S+\.lean:\d+:\d+: error[:(]', t, re.M)); e2 = len(re.findall(r'^error[:(]|: error:', t, re.M))
            ends = re.findall(r'G06-SEAL-END label=(\S+) requested=(\d+) verified=(\d+)', t)
            inst = re.findall(r'G06-MASK label=\S+ phase=install requested=(\d+) verified=(\d+)', t)
            eof = re.findall(r'G06-MASK label=\S+ phase=eof requested=(\d+) verified=(\d+)', t)
            ok = e1 == 0 and e2 == 0 and len(ends) == 1 and ends[0][1] == ends[0][2] and eof and all(a == b for a, b in eof) and all(a == b for a, b in inst)
            if not ok: bad.append((os.path.basename(f)[-60:], e1, e2, ends, inst[:1], eof[:1]))
            if ends: req += int(ends[0][1])
            tot += 1
        print(f'{os.path.basename(root)} {v}: logs={tot} requests={req} bad={len(bad)}', bad[:3])
