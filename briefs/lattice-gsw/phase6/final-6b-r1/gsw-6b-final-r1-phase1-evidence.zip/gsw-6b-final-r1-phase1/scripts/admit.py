"""Admissions recount from the bound build logs: sorry warnings -> (module, declaration name at the
warning position in the final source), against base-sorries.txt plus the 24 6b targets."""
import sys, re, subprocess, collections
E, repo, H, basef = sys.argv[1:5]
rows = [l.split('\t') for l in open(f'{E}/root-final/summary.txt', encoding='utf-8') if not l.startswith(('#', 'module'))]
got = collections.defaultdict(list)
w = re.compile(r'^(\S+\.lean):(\d+):(\d+): warning: declaration uses .sorry.', re.M)
for r in rows:
    m, summ = r[0], r[1].split('/')[0]
    t = open(f"{E}/{summ}/mods/{m.replace('/', '_')}.log", encoding='utf-8', errors='replace').read()
    hits = w.findall(t)
    if not hits: continue
    src = subprocess.run(['git', '-C', repo, 'show', f'{H}:{m}.lean'], capture_output=True).stdout.decode().split('\n')
    for f, ln, col in hits:
        tok = re.match(r"[^\s(:{\[]+", src[int(ln)-1][int(col):])
        got[m].append(tok.group(0) if tok else f'?{ln}')
exp = collections.defaultdict(list)
for l in (x for x in open(basef, encoding="utf-8") if re.match(r"^TCSlib\S*: \d+: ", x)):
    mod, n, names = l.rstrip('\n').split(': ', 2)
    exp[mod] += [x.strip() for x in names.split(',')]
tg = {'Branching': ['Encrypts.select','encrypts_homEvalPBP','encrypts_homEvalFormula'],
 'DecryptFormula': ['vecMul_secretVector_eq_sum','decryptFormula_eval','nandFormula_eval','depth_nandFormula_le','maxFanin_nandFormula_le','decDepth_le'],
 'Bootstrap': ['encrypts_bootNAND','decrypt_fheEval','decrypt_fheEvalCircuit','decrypt_keygen_fheEvalCircuit','bootNoise_le'],
 'Circular': ['distAdv_fheView_noEvk_le'], 'Leveled': ['encrypts_leveledEval','decrypt_keygen_leveledEvalCircuit'],
 'LeveledSecurity': ['distAdv_levelHybrid_le','distAdv_leveledView_le'],
 'PolyRatio': ['bootRatio_le_poly','decrypt_fheEval_of_ratio','decrypt_leveledEval_of_ratio'],
 'Asymptotic': ['indCPA_of_dlweAssumption','leveledINDCPA_of_dlweAssumption']}
for k, v in tg.items(): exp['TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/' + k] += v
diff = [m for m in set(got) | set(exp) if sorted(got[m]) != sorted(exp[m])]
print('got', sum(map(len, got.values())), 'in', len(got), '; expected', sum(map(len, exp.values())), 'in', len(exp), '; differing modules', len(diff))
for m in diff[:10]: print(' ', m, sorted(got[m]), sorted(exp[m]))
