#!/usr/bin/env bash
# Reproduce both series by git am with COMMITS.tsv committer data, unsigned.
set -eu
R=$1; D=$2
cd "$R"
git sparse-checkout set --no-cone '/TCSlib/Cryptography/LWE.lean' '/TCSlib/Cryptography/LWE/' '/TCSlib/Cryptography/AdvancedEncryption/Homomorphic.lean' '/TCSlib/Cryptography/AdvancedEncryption/Homomorphic/'
git checkout -q --detach 3e51b5f28900db6190f1eb2e6d207d27ee15d541
for s in o2 stmt; do
  i=0
  for p in "$D"/patches/$s/0*.patch; do
    i=$((i+1))
    row=$(sed -n "$((i+1))p" "$D"/patches/$s/COMMITS.tsv)
    IFS=$'\t' read -r h an ae ad cn ce cd sg <<<"$row"
    GIT_COMMITTER_NAME="$cn" GIT_COMMITTER_EMAIL="$ce" GIT_COMMITTER_DATE="$cd" \
      git -c commit.gpgsign=false am -q --keep-cr "$p"
    got=$(git rev-parse HEAD)
    echo "$s $i expect $h got $got $([ "$got" = "$h" ] && echo OK || echo MISMATCH) sig=$(git cat-file -p HEAD | grep -c gpgsig || true)"
  done
done
