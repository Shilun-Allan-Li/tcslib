import re,sys
sys.path.insert(0,'')
exec(open(sys.argv[1]).read().split('pat=re.compile')[0])  # get strip()
pat=re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:private\s+|protected\s+|noncomputable\s+)*(def|theorem|lemma|abbrev|instance|structure|inductive|class|example)\s+([^\s:({\[]+)?',re.M)
for f in sys.argv[2:]:
    s=strip(open(f,encoding='utf-8').read())
    ms=list(pat.finditer(s))
    for k,m in enumerate(ms):
        end=ms[k+1].start() if k+1<len(ms) else len(s)
        body=s[m.start():end]
        c=len(re.findall(r'\bsorry\b',body))
        if c: print(f"{f.split('/')[-1]}\t{m.group(2)}\t{c}")
    for w in ['native_decide','admit','axiom ','@[simp','attribute [','show ','delta','change ','unfold','set_option']:
        n=s.count(w)
        if n and w not in('unfold','set_option'): print(f"{f.split('/')[-1]}\tHYGIENE {w!r} {n}")
