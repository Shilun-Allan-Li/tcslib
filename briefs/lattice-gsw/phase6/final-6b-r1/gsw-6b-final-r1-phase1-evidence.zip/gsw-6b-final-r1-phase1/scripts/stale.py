"""Staleness check of the binding: no module bound to an earlier build (bootstrap at the base,
root at the pre-review head) has, in its import closure at the final head, a module whose source
at that earlier build differs from the final head's."""
import sys, re, subprocess, hashlib
E, repo, H, B = sys.argv[1:5]
def blob(rev, path):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True)
    return r.stdout if r.returncode == 0 else None
rows = [l.split('\t') for l in open(f'{E}/root-final/summary.txt', encoding='utf-8') if not l.startswith(('#', 'module'))]
bound = {r[0]: r[1].split('/')[0] for r in rows}
final = {m: blob(H, m + '.lean') for m in bound}
fsha = {m: hashlib.sha256(b).hexdigest() for m, b in final.items()}
rootsha = {}
for l in open(f'{E}/root/summary.tsv', encoding='utf-8'):
    x = l.rstrip('\n').split('\t'); rootsha[x[0]] = x[-1]
changed = set()
for m in bound:
    if m in rootsha:
        if rootsha[m] != fsha[m]: changed.add(m)
    else:
        if blob(B, m + '.lean') != final[m]: changed.add(m)   # prefix/new: base vs final
imp = {m: [x.replace('.', '/') for x in re.findall(r'^import\s+(TCSlib\S*)', b.decode('utf-8', 'replace'), re.M)] for m, b in final.items()}
memo = {}
def clo(m):
    if m in memo: return memo[m]
    s = set()
    for d in imp.get(m, []):
        s.add(d); s |= clo(d)
    memo[m] = s; return s
sys.setrecursionlimit(20000)
print('changed since earlier build:', sorted(changed))
bad = [(m, sorted(clo(m) & changed)[:3]) for m, src in bound.items() if src != 'sweep-final-r2' and clo(m) & changed]
print('earlier-bound modules with a changed dependency:', len(bad), bad[:5])
sw = [m for m, src in bound.items() if src == 'sweep-final-r2']
need = sorted(m for m in bound if (clo(m) & changed) or m in changed)
print('need rebuild', len(need), 'in sweep', len(sw), 'missing', sorted(set(need) - set(sw)))
