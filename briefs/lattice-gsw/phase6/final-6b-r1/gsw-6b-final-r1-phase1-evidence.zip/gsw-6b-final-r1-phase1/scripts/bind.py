"""Recount the root-final binding: every module's last build log rc/errors (both forms), sorry
warnings, and source hash vs the final head blob; then check that every module built at an
earlier head has no changed module in its import closure at the final head."""
import sys, re, subprocess, hashlib, os, collections
E, repo, H = sys.argv[1], sys.argv[2], sys.argv[3]
heads = {'bootstrap': '3e51b5f28900db6190f1eb2e6d207d27ee15d541',
         'root': open(f'{E}/root/HEAD.txt').read().strip(),
         'sweep-final-r2': open(f'{E}/sweep-final-r2/HEAD.txt').read().strip()}
def git(*a, inp=None):
    return subprocess.run(['git', '-C', repo, *a], input=inp, capture_output=True, check=True).stdout
def blob(rev, path):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], capture_output=True)
    return r.stdout if r.returncode == 0 else None
rows = [l.split('\t') for l in open(f'{E}/root-final/summary.txt', encoding='utf-8') if not l.startswith(('#', 'module'))]
e1 = re.compile(r'^\S+\.lean:\d+:\d+: error[:(]', re.M)
e2 = re.compile(r'^error[:(]|: error:', re.M)
sw = re.compile(r'declaration uses .sorry.')
bad = 0; nsorry = 0; src = {}; built_at = {}
for r in rows:
    m, summ = r[0], r[1].split('/')[0]
    b = blob(H, m + '.lean'); src[m] = b
    if b is None: print('NO SOURCE', m); bad += 1; continue
    h = hashlib.sha256(b).hexdigest()
    srow = [x.split('\t') for x in open(f'{E}/{summ}/summary.tsv', encoding='utf-8') if x.split('\t')[0] == m]
    if len(srow) < 1: print('NO SUMMARY ROW', m, summ); bad += 1; continue
    s = srow[-1]
    if s[-1].strip() != h or s[1] != 'rc=0': print('HASH/RC', m, summ, s[1]); bad += 1
    log = f"{E}/{summ}/mods/{m.replace('/', '_')}.log"
    if not os.path.exists(log): print('NO LOG', m, summ); bad += 1; continue
    t = open(log, encoding='utf-8', errors='replace').read()
    if e1.search(t) or e2.search(t): print('ERRORS', m); bad += 1
    nsorry += len(sw.findall(t))
    built_at[m] = heads[summ]
print('modules', len(rows), 'bad', bad, 'sorry warnings in logs', nsorry)
# changed modules: source at build head != final
changed = set()
for m, rev in built_at.items():
    if rev != H and blob(rev, m + '.lean') != src[m]: changed.add(m)
print('built at earlier head with different source:', sorted(changed))
imp = {}
for m, b in src.items():
    imp[m] = [x.replace('.', '/') for x in re.findall(r'^import\s+(TCSlib\S*)', b.decode('utf-8', 'replace'), re.M)]
# modules whose source differs between build head and final for any module in its closure
def closure(m, seen):
    for d in imp.get(m, []):
        if d not in seen: seen.add(d); closure(d, seen)
    return seen
sys.setrecursionlimit(10000)
stale = []
for m, rev in built_at.items():
    if rev == H: continue
    for d in closure(m, set()):
        if d not in built_at: continue
        # dependency source at m's build head vs final
        if blob(rev, d + '.lean') != src[d]: stale.append((m, d)); break
print('stale (built earlier, a dependency changed since):', stale[:10], len(stale))
