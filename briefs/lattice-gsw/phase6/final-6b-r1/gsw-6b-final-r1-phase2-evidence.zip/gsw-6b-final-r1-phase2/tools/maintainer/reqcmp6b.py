"""reqcmp6b.py <ours-rule10-dir> <delivery-rule10-run-dir>...: per owner and variant (seals/A, seals/B, seals-coe/A,
seals-coe/B against the delivery's seals-A, -B, -coeA, -coeB), the request sets (`rows[].spelling`) compared:
counts, names only here, names only in the delivery. Then the union of the extra names grouped by home module."""
import sys, json, os, glob, collections
ours = sys.argv[1]; dels = sys.argv[2:]
V = [('seals/A', 'seals-A'), ('seals/B', 'seals-B'), ('seals-coe/A', 'seals-coeA'), ('seals-coe/B', 'seals-coeB')]
extra_all = collections.Counter(); miss_all = set(); home = {}
for ov, dv in V:
    for p in sorted(glob.glob(os.path.join(ours, ov, 'Seal*.json'))):
        lab = os.path.basename(p)
        dp = [os.path.join(d, 'seal', dv, lab) for d in dels if os.path.exists(os.path.join(d, 'seal', dv, lab))]
        a = json.load(open(p)); A = {r['spelling'] for r in a['rows']}
        for r in a['rows']: home[r['spelling']] = r.get('home', r.get('module', '?'))
        if not dp: print(f'{ov}\t{lab}\t{len(A)}\tNOREF'); continue
        b = json.load(open(dp[0])); Bs = {r['spelling'] for r in b['rows']}
        ex = sorted(A - Bs); mi = sorted(Bs - A); extra_all.update(ex); miss_all |= set(mi)
        print(f'{ov}\t{lab[:-5]}\tours {len(A)}\tdelivery {len(Bs)}\tonly-ours {len(ex)}\tonly-delivery {len(mi)}')
print('names only in the delivery (any owner/variant):', sorted(miss_all))
byhome = collections.Counter(home.get(n, '?') for n in extra_all)
print('extra names by home module:', dict(byhome))
for n in sorted(extra_all): print('EXTRA', n, home.get(n, '?'))
