#!/usr/bin/env bash
# rule10_g6b.sh <series> <phase>... (gsw-6b landing phase 2, maintainer, 2026-11-18): rule10_g6a.sh (gsw-6a statements
# phase 2) re-pointed to this job. Changes:
# (1) series: o2 (R1: export wtx-r1 of land/gsw-6b-o2, tree olean-replay-6b-o2, owner LWE.BitEncoding),
#     stmt (R2: export wtx-r2 of land/gsw-6b-statements, tree olean-replay-6b-stmt, owners = the 9 new modules, the two
#     facades and LWE.BitEncoding), root (owner = root TCSlib on R2, coe-A only: phase rootcoeA);
# (2) touched.json against the records tip 38123ccb (Lean-equal to snapshot #10's T cf6a2266);
# (3) controls: mkctl_g6b.py (the delivery's ten paired-control rows; harness unchanged);
# (4) every probe through LE-g45's gated_full.sh (runner_full.py, lean -DmaxErrors=0, no -o: nothing is written to a
#     tree; slot check before each probe, wait while 3 or more lean processes run); rule10_b.sh's single runner pass is
#     replaced by the same gated runner (RUNNER override below), one Lean process at a time;
# (5) phase delivered: the delivery's own control sources (evidence/rule10/r2/{final,final-bitenc}/controls/src),
#     byte-unchanged, run on the series tree.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/g6b-p2; E=$X; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RUN="bash $SP/s10-work/tools/gated_full.sh"
B=38123ccbebef878cd25dd2d2761de1b40ba7e421
GSW=TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW; LW=TCSlib.Cryptography.LWE
O2MODS="$LW.BitEncoding"
STMTMODS="$LW.BitEncoding $LW.Ratio $GSW.Branching $GSW.DecryptFormula $GSW.Bootstrap $GSW.Circular $GSW.Leveled $GSW.LeveledSecurity $GSW.PolyRatio $GSW.Asymptotic $GSW $LW"
DV=$X/deliv/inbox/fills/gsw-6b-statements/evidence/rule10/r2
files() { for m in "$@"; do echo -n "$(echo $m | tr . /).lean "; done; }
case $1 in
o2) W=$X/wtx-r1; TREE=$SP/olean-replay-6b-o2; NAME=o2; H=$(cat $X/log/head-o2.txt); MODS=$O2MODS; DCTL="o2";;
stmt) W=$X/wtx-r2; TREE=$SP/olean-replay-6b-stmt; NAME=stmt; H=$(cat $X/log/head-stmt.txt); MODS=$STMTMODS; DCTL="final final-bitenc";;
root) W=$X/wtx-r2; TREE=$SP/olean-replay-6b-stmt; NAME=root; H=$(cat $X/log/head-stmt.txt); MODS=TCSlib; DCTL="";;
*) echo "series?"; exit 2;;
esac
FILES=$(files $MODS)
shift
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json; [ $NAME = root ] && TJ=$E/statements/touched-stmt.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$X/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
PP=G6bSeal
mkdir -p $R/order $R/probe-sources $W/$PP $E/statements $X/tmp
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
touched)
  python3 -I $T/review/touched.py /home/user/tcslib $B $H $TJ $FILES > $E/statements/touched-$NAME.tsv; echo "touched rc=$?";;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "gsw-6b landing phase 2 $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
mkseals)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  ( cd $T && python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/A $PP/S SealA_ $MODS > $R/mkseals-A.log
    SEAL_EVAL=1 python3 -I $T/review/mkseals_ab.py $G $LOG $W $H $R/seals/B $PP/S SealB_ $MODS > $R/mkseals-B.log
    python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/C SealA_ $MODS > $R/mkseals-coe-A.log
    SEAL_EVAL=1 python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/B $PP/C SealB_ $MODS > $R/mkseals-coe-B.log )
  mkdir -p $R/seals-flat $R/seals-coe-flat
  for v in A B; do cp $R/seals/$v/Seal*.json $R/seals-flat/; cp $R/seals-coe/$v/Seal*.json $R/seals-coe-flat/; done
  ( cd $T && python3 -I $X/tools/mkctl_g6b.py $G $R/seals-flat $W $PP/KS $R/controls-strict > $R/mkctl-strict.log
    python3 -I $X/tools/mkctl_g6b.py $G $R/seals-coe-flat $W $PP/K $R/controls-coe > $R/mkctl-coe.log )
  (cd $W && ls $PP/C/*.lean $PP/K/*.lean $PP/KS/*.lean $PP/S/*.lean 2>/dev/null | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seal-control-queue.txt
  wc -l < $R/order/seal-control-queue.txt; cat $R/mkseals-*.log $R/mkctl-*.log;;
runseals)
  $RUN $W $R/order/seal-control-queue.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1; echo "seal runner rc=$?";;
sum)
  for v in seals/A seals/B seals-coe/A seals-coe/B; do python3 -I $T/review/sealsum.py $R/$v $R/seal-runs $TJ $R/$(echo $v | tr / -).tsv; done
  python3 -I $T/review/ctlcheck2.py $R/controls-strict/controls-plan.json $R/seal-runs $R/ctlcheck-strict.json > $R/ctlcheck-strict.log || true
  python3 -I $T/review/ctlcheck2.py $R/controls-coe/controls-plan.json $R/seal-runs $R/ctlcheck-coe.json > $R/ctlcheck-coe.log || true
  cat $R/seals-*.tsv; for f in $R/ctlcheck-strict.log $R/ctlcheck-coe.log; do tail -n 1 $f; done;;
rootcoeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  ( cd $T && python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/RC SealA_ $MODS > $R/mkseals-coe-A.log )
  (cd $W && ls $PP/RC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  $RUN $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
scan)
  S=$E/scan/$NAME; mkdir -p $S
  SF=$(git diff --name-only $B $H -- 'TCSlib/*.lean' | grep '/')
  echo $SF > $S/files.txt
  ( cd $T && SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W $TJ $S/items-head.json $W/$PP/ScanKindsHead.lean $SF > $S/scan1.out 2>&1 )
  cp $W/$PP/ScanKindsHead.lean $S/ScanKindsHead.lean.txt
  echo $PP/ScanKindsHead > $S/order.txt
  $RUN $W $S/order.txt $TREE $S/runs > $S/scan-runner.out 2>&1
  python3 -I $T/scan2.py $S/items-head.json $S/runs/mods/${PP}_ScanKindsHead.log $S/explicit-head.json > $S/scan2-head.log 2>&1; echo "scan2 rc=$?";;
delivered)
  D=$E/rule10/delivered-$NAME; mkdir -p $D $W/G6bDCtl; : > $D/order.txt
  for d in $DCTL; do for f in $DV/$d/controls/src/*.lean; do b=$(basename $f .lean); cp $f $W/G6bDCtl/$b.lean; sha256sum $f >> $D/sources.sha256; echo G6bDCtl/$b >> $D/order.txt; done; done
  LC_ALL=C sort -u -o $D/order.txt $D/order.txt; wc -l < $D/order.txt
  $RUN $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "delivered controls rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
