"""dctlcheck.py <rundir> <srcdir>: outcomes of the delivery's own paired controls, run unchanged on a replay tree.
Unsealed (Ctl_*_unsealed): rc 0, 0 errors. Sealed negative (*_neg_sealed): exactly 1 error, located inside the
`example` (from its line to the end of the file's example block). Sealed positive (*_pos_sealed): 0 errors. Every sealed
probe: one install and one EOF `requested = verified` record (G06-MASK phase=install / phase=eof, equal counts) and one
G06-SEAL-END. Prints one row per control and ALL_OK."""
import sys, os, re, json
rd, sd = sys.argv[1:3]
res = {}
for l in open(os.path.join(rd, 'results.jsonl')):
    x = json.loads(l)
    if 'module' in x: res[x['module'].split('/')[-1]] = x
ok_all = True
E = re.compile(r'^\S+\.lean:(\d+):\d+: error')
for lab in sorted(res):
    x = res[lab]; log = open(os.path.join(rd, 'mods', x['module'].replace('/', '_') + '.log'), encoding='utf-8', errors='replace').read()
    src = open(os.path.join(sd, lab + '.lean'), encoding='utf-8').read().split('\n')
    ex = [i + 1 for i, l in enumerate(src) if l.startswith('example')]
    errs = [int(m.group(1)) for m in map(E.match, log.split('\n')) if m]
    sealed = lab.endswith('_sealed'); neg = '_neg_' in lab
    inst = re.findall(r'G06-MASK label=\S+ phase=install requested=(\d+) verified=(\d+)', log)
    eof = re.findall(r'G06-MASK label=\S+ phase=eof requested=(\d+) verified=(\d+)', log)
    end = len(re.findall(r'G06-SEAL-END', log))
    rec_ok = (not sealed) or (len(inst) >= 1 and len(eof) >= 1 and all(a == b for a, b in inst + eof) and end >= 1)
    exp = 1 if (sealed and neg) else 0
    in_ex = all(ex and e >= ex[0] for e in errs)
    ok = len(errs) == exp and in_ex and rec_ok and (x['rc'] == 0 if exp == 0 else True)
    ok_all &= ok
    req = sum(int(a) for a, _ in inst) if inst else '-'
    print(f'{lab}\trc {x["rc"]}\terrors {len(errs)}\texpected {exp}\tin_example {in_ex}\tinstall/eof {len(inst)}/{len(eof)} req {req}\t{"OK" if ok else "FAIL"}')
print('controls', len(res), 'ALL_OK', ok_all)
