"""stripdiff.py <commentstrip50.py> <repo> <revA> <revB> <path>: unified diff of the comment-stripped texts of a file at
two revisions (strip() of commentstrip50.py, loaded as a module), blank-line runs collapsed."""
import sys, subprocess, difflib, importlib.util, re
cs, repo, a, b, p = sys.argv[1:6]
src = open(cs, encoding='utf-8').read(); src = src[:src.index('\nif __name__')] if '\nif __name__' in src else src
ns = {}
spec = importlib.util.spec_from_loader('cs50', loader=None); m = importlib.util.module_from_spec(spec)
# take only the definitions up to the CLI part: strip() is a top-level function
code = re.split(r'\n(?=repo,|args =|if len\(sys.argv\))', src)[0]
exec(compile(code, cs, 'exec'), m.__dict__)
get = lambda r: subprocess.run(['git', '-C', repo, 'show', f'{r}:{p}'], capture_output=True, check=True).stdout.decode('utf-8')
norm = lambda t: [l.rstrip() for l in re.sub(r'\n\s*\n+', '\n', m.strip(t)[0]).split('\n') if l.strip()]
for l in difflib.unified_diff(norm(get(a)), norm(get(b)), a, b, lineterm='', n=1): print(l)
