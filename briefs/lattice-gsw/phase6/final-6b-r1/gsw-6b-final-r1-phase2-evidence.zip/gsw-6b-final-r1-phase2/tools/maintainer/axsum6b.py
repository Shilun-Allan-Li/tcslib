"""axsum6b.py <probe.log> <targets.tsv> [<reference.log>]: summary of the delivery's AxiomProbe output. Each DECL/AUX line's
axioms must be within {propext, Classical.choice, Quot.sound} or sorryAx; the set of constants with sorryAx must be the
24 targets (short names from targets.tsv, matched as the final name component(s)); each TRACE must name only the
constant itself. Named checks: the five O2 declarations and fheEvalCircuit/leveledEvalCircuit and their _eq standard.
With a reference log: line-level comparison (equal / only here / only in reference)."""
import sys, re
log, tf = sys.argv[1:3]; ref = sys.argv[3] if len(sys.argv) > 3 else None
STD = {'propext', 'Classical.choice', 'Quot.sound'}
G = 'TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.'; B = 'TCSlib.Cryptography.LWE.BitEncoding.'
L = [l for l in open(log, encoding='utf-8').read().split('\n') if re.match(r'^(DECL|AUX|TRACE)\t', l)]
ax = {}; tr = {}
for l in L:
    p = l.split('\t')
    if p[0] in ('DECL', 'AUX'): ax[p[2]] = (p[0], [x.strip() for x in p[3].strip('[]').split(',') if x.strip()])
    else: tr[p[1]] = p[2]
nonstd = sorted(n for n, (_, a) in ax.items() if set(a) - STD - {'sorryAx'})
sor = sorted(n for n, (_, a) in ax.items() if 'sorryAx' in a)
T = [l.rstrip('\n').split('\t')[1] for l in open(tf) if l.strip()]
tq = sorted(G + t for t in T)
print(f'constants {len(ax)} (DECL {sum(1 for v in ax.values() if v[0]=="DECL")}, AUX {sum(1 for v in ax.values() if v[0]=="AUX")})')
print(f'non-standard axioms other than sorryAx: {len(nonstd)} {nonstd}')
print(f'sorryAx in {len(sor)}; equal to the 24 targets: {sor == tq}; extra {sorted(set(sor)-set(tq))}; missing {sorted(set(tq)-set(sor))}')
selfonly = [n for n in sor if tr.get(n) == f'via [{n}@{n.rsplit(".",1)[0] if False else ""}]']
bad_tr = []
for n in sor:
    v = tr.get(n, ''); names = re.findall(r'([^\s\[\],@]+)@', v)
    if names != [n]: bad_tr.append((n, v))
print(f'traces: {len(tr)}; each target traces only itself: {not bad_tr and len(tr) == len(sor)} {bad_tr[:3]}')
for n in [B + x for x in ('decodeLo', 'decodeHi', 'decodeLo_eq', 'decodeHi_eq', 'decode_iff_mem_Ico')] + \
         [G + x for x in ('fheEvalCircuit', 'fheEvalCircuit_eq', 'leveledEvalCircuit', 'leveledEvalCircuit_eq', 'Parameters.neZero_columns')]:
    if n in ax: print(f'NAMED\t{n}\t{ax[n][1]}\t{"standard" if set(ax[n][1]) <= STD else "NOT STANDARD"}')
if ref:
    R = [l for l in open(ref, encoding='utf-8').read().split('\n') if re.match(r'^(DECL|AUX|TRACE)\t', l)]
    a, b = set(L), set(R)
    print(f'vs reference: equal lines {len(a & b)}; only here {len(a - b)}; only in reference {len(b - a)}')
    for x in sorted(a - b): print('  HERE\t' + x[:220])
    for x in sorted(b - a): print('  REF\t' + x[:220])
