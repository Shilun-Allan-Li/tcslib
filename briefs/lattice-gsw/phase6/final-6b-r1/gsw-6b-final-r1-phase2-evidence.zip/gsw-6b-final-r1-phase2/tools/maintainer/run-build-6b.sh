#!/usr/bin/env bash
# run-build-6b.sh <r1|r2> (gsw-6b landing phase 2): run-build-s10.sh with B, OUT and the export re-pointed.
# r1: export wtx-r1 of land/gsw-6b-o2 on $SP/olean-replay-6b-o2 (cp -al of snapshot #10 + overlay);
# r2: export wtx-r2 of land/gsw-6b-statements on $SP/olean-replay-6b-stmt (cp -al of R1).
# <rN>/plan/queue.txt (imports-first) through the recipe's runner.py (unmodified), one module per call; slot gate before
# each module (wait while 3 or more lean processes run); stop if free disk < 1.5 GB.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
N=$1; B=$SP/g6b-p2/$N; RUNNER=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/runner.py
case $N in r1) OUT=$SP/olean-replay-6b-o2;; r2) OUT=$SP/olean-replay-6b-stmt;; *) echo "series?"; exit 2;; esac
Q=$B/plan/queue.txt; E=$B/build; WX=$SP/g6b-p2/wtx-$N
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$SP/g6b-p2/tmp
mkdir -p $E/one $SP/g6b-p2/tmp
echo "start $(date -u +%FT%TZ) queue $Q" >> $E/runner.start; df -m / | tail -1 >> $E/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $E/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $E/slot-log.txt
  echo "$m" > $E/one/order.txt
  python3 -I $RUNNER $WX $E/one/order.txt $OUT $E < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $E/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $E/runner.exit; exit 2; }
done < $Q
echo "runner exit 0 $(date -u +%FT%TZ)" >> $E/runner.exit; df -m / | tail -1 >> $E/runner.exit
