"""dctlprune.py <in.lean> <out.lean> <name>...: the delivery's sealed control with the named request entries removed from
its `payload` and `componentPayload` string literals, and
each block's `expectedRequests` lowered by the entries dropped from that block's payload (entries are separated by the escape `\\n`, fields by `\\t`; an entry
is dropped when its first field equals a given name). Nothing else changes. Prints the entries dropped per literal.
Used only for names absent at the replay tip (closure drift since the delivery's base)."""
import sys, re
src, out, names = sys.argv[1], sys.argv[2], set(sys.argv[3:])
s = open(src, encoding='utf-8').read(); dropped = []
def fix(m):
    head, body = m.group(1), m.group(2)
    parts = body.split('\\n'); keep = [p for p in parts if p.split('\\t')[0] not in names]
    dropped.append(len(parts) - len(keep)); return head + '\\n'.join(keep) + '"'
s2 = re.sub(r'(let (?:payload|componentPayload) : String := ")((?:[^"\\]|\\.)*)"', fix, s)
# each `let expectedRequests : Nat := N` follows its block's `payload` literal: lower N by that literal's drop count
pay = [d for d, kind in zip(dropped, re.findall(r'let (payload|componentPayload) : String :=', s)) if kind == 'payload']
it = iter(pay); fixed = []
def fixn(m):
    d = next(it); fixed.append((int(m.group(1)), int(m.group(1)) - d)); return f'let expectedRequests : Nat := {int(m.group(1)) - d}'
s2 = re.sub(r'let expectedRequests : Nat := (\d+)', fixn, s2)
open(out, 'w', encoding='utf-8').write(s2); print(src.split('/')[-1], 'dropped per literal', dropped, 'expectedRequests', fixed)
