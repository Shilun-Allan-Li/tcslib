"""mkctl_gsw.py (gsw-core r1 review): mkctl_seqzk.py with GSW rows (PolyExpr.eval, the FinDist CoeFun instance, the owned files' gadget, lift, mul, Encrypts, secretVector (foreign to the later owned files), the plan G8 type-level definitions Regev.augmented, LWE.sample, Lossy.gadget, BitEncoding.codepoint, Randomized.blocksEquiv, and DAGGate.eval, DAGCircuit.depthAt, acceptProb; each negative the rfl/definitional read, each positive its published reader) and namespace GswControls. Previously:
mkctl_seqzk.py (seq-zk review): mkctl_canon.py with seq-zk rows (PolyExpr.eval, the FinDist CoeFun instance,
ZK / ZK_iff, StatZK / the approved StatZK_iff, Protocol.seqRep / its simps reader seqRep_verifierFirst, Composability.prefixProver (Phases helper) / prefixProver_coins) and namespace
GswControls. Previously:
mkctl_canon.py (canonizer review): mkctl_scot.py with canonizer rows (PolyExpr.eval, the FinDist CoeFun instance,
Turing.unaryFin, Turing.oneTapeFormat and Turing.oneTapeMachineFormat with the two pre-approved readers as positives) and
namespace GswControls. Previously: mkctl_scot.py (sc-ot review): mkctl_learning.py with sc-ot rows (PolyExpr.eval, the FinDist CoeFun
instance, NUPPT.layout, Strategy.encodeMsgs, otFunctionality, and the helper definitions OT.mask, OT.simSeg, OT.inA2,
OT.bobView, OT.hcBit, foreign to the later helpers and the owned file; each negative the rfl unfolding, each positive
its published reader) and namespace ScOtControls. Previously: mkctl_learning.py (learning-r1 review): mkctl_lamport.py with learning rows (PolyExpr.eval, FinDist.uniform, the FinDist
CoeFun instance, PAC.label, uprob, acceptProb, and the helper definitions LearnPRF.firstBit, tupleWord, learnerFn,
foreign to the later helpers and the owned file) and namespace LearningControls. Previously: mkctl_lamport.py (lamport review): mkctl_dlcrh.py with lamport rows (padFin, PolyExpr.eval, ProbComp.expect, ProbComp.sample, OracleComp.bind (the three names of the patch-4 opacity block), LamportFill.secretWord, LamportFill.signatureBlock, LamportMachine.u). Previously: mkctl_dlcrh.py (dl-crh review): mkctl_extnosrc.py with dl-crh rows (padFin, PolyExpr.eval, Authentication.splitBits, Candidates.expSampleRaw (new reader expSampleRaw_eq), FromDiscreteLog.modularDifference, FromDiscreteLog.residueFinEquiv). Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
FD = 'TCSlib.InformationTheory.FinDist'
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
G = 'TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW'
OG = 'open TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW in\n'
B = {
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 FD + '.instCoeFunForallReal': row("ctlCoe",
   f"theorem ctlCoe {{α : Type}} [Fintype α] (p : {FD} α) (a : α) : p a = p.prob a := rfl\n",
   f"theorem ctlCoeReader {{α : Type}} [Fintype α] (f : α → ℝ) (h₁ : ∀ a, 0 ≤ f a) (h₂ : ∑ a, f a = 1) (a : α) :\n    (⟨f, h₁, h₂⟩ : {FD} α) a = f a := {FD}.coe_mk f h₁ h₂ a\n"),
 G + '.gadget': row("ctlGadget",
   OG + "theorem ctlGadget (P : Parameters) (i : Fin (P.lwe.dimension + 1)) (j : Fin P.columns) :\n    gadget P i j = ((TCSlib.Cryptography.TrapdoorFunctions.Lossy.gadget P.width (P.lwe.dimension + 1) j i : ℤ) :\n      ZMod P.lwe.modulus) := rfl\n",
   OG + "theorem ctlGadgetReader (P : Parameters) (i : Fin (P.lwe.dimension + 1)) (j : Fin P.columns) :\n    gadget P i j = ((TCSlib.Cryptography.TrapdoorFunctions.Lossy.gadget P.width (P.lwe.dimension + 1) j i : ℤ) :\n      ZMod P.lwe.modulus) := gadget_apply P i j\n"),
 G + '.lift': row("ctlLift",
   OG + "theorem ctlLift (P : Parameters) {κ ι : Type} (X : Matrix κ ι Bool) (i : κ) (j : ι) :\n    lift P X i j = ((X i j).toNat : ZMod P.lwe.modulus) := rfl\n",
   OG + "theorem ctlLiftReader (P : Parameters) {κ ι : Type} (X : Matrix κ ι Bool) (i : κ) (j : ι) :\n    lift P X i j = ((X i j).toNat : ZMod P.lwe.modulus) := lift_apply P X i j\n"),
 G + '.mul': row("ctlMul",
   OG + "theorem ctlMul (P : Parameters) (C₁ C₂ : Ciphertext P) :\n    mul P C₁ C₂ = C₁ * lift P (decompose P C₂) := rfl\n",
   OG + "theorem ctlMulReader (P : Parameters) (C₁ C₂ : Ciphertext P) :\n    mul P C₁ C₂ = C₁ * lift P (decompose P C₂) := mul_eq P C₁ C₂\n"),
 G + '.Encrypts': row("ctlEncrypts",
   OG + "theorem ctlEncrypts (P : Parameters) (t : Fin (P.lwe.dimension + 1) → ZMod P.lwe.modulus)\n    (C : Ciphertext P) (h : Encrypts P t 0 0 C) : ∃ e : Fin P.columns → ℤ, (∀ j, (e j).natAbs ≤ 0) ∧\n      Matrix.vecMul t C = ((0 : ℤ) : ZMod P.lwe.modulus) • Matrix.vecMul t (gadget P) +\n        fun j => (e j : ZMod P.lwe.modulus) := h\n",
   OG + "theorem ctlEncryptsReader (P : Parameters) (t : Fin (P.lwe.dimension + 1) → ZMod P.lwe.modulus)\n    (C : Ciphertext P) (h : Encrypts P t 0 0 C) : ∃ e : Fin P.columns → ℤ, (∀ j, (e j).natAbs ≤ 0) ∧\n      Matrix.vecMul t C = ((0 : ℤ) : ZMod P.lwe.modulus) • Matrix.vecMul t (gadget P) +\n        fun j => (e j : ZMod P.lwe.modulus) := (encrypts_iff P t 0 0 C).mp h\n"),
 G + '.secretVector': row("ctlSecretVector",
   OG + "theorem ctlSecretVector (P : Parameters) (s : Fin P.lwe.dimension → ZMod P.lwe.modulus) :\n    secretVector P s = Fin.snoc (α := fun _ => ZMod P.lwe.modulus) (-s) 1 := rfl\n",
   OG + "theorem ctlSecretVectorReader (P : Parameters) (s : Fin P.lwe.dimension → ZMod P.lwe.modulus) :\n    secretVector P s = Fin.snoc (α := fun _ => ZMod P.lwe.modulus) (-s) 1 := secretVector_eq P s\n"),
 'TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented': row("ctlAugmented",
   "theorem ctlAugmented (P : TCSlib.Cryptography.LWE.Parameters)\n    (pk : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) × (Fin P.samples → ZMod P.modulus)) :\n    TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented P pk = Fin.snoc pk.1.transpose pk.2 := rfl\n",
   "theorem ctlAugmentedReader (P : TCSlib.Cryptography.LWE.Parameters)\n    (pk : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) × (Fin P.samples → ZMod P.modulus)) :\n    TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented P pk = Fin.snoc pk.1.transpose pk.2 :=\n  TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented_eq P pk\n"),
 'TCSlib.Cryptography.LWE.sample': row("ctlSample",
   "theorem ctlSample (P : TCSlib.Cryptography.LWE.Parameters) (χ : TCSlib.Cryptography.LWE.Noise)\n    (r : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n      ((Fin P.dimension → ZMod P.modulus) × (Fin P.samples → χ.Coins))) :\n    (TCSlib.Cryptography.LWE.sample P χ r).1 = r.1 := rfl\n",
   "theorem ctlSampleReader (P : TCSlib.Cryptography.LWE.Parameters) (χ : TCSlib.Cryptography.LWE.Noise)\n    (r : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n      ((Fin P.dimension → ZMod P.modulus) × (Fin P.samples → χ.Coins))) :\n    (TCSlib.Cryptography.LWE.sample P χ r).1 = r.1 := TCSlib.Cryptography.LWE.sample_fst P χ r\n"),
 'TCSlib.Cryptography.TrapdoorFunctions.Lossy.gadget': row("ctlLossyGadget",
   "theorem ctlLossyGadget (b w : ℕ) (i : Fin (w * b)) (j : Fin w) :\n    TCSlib.Cryptography.TrapdoorFunctions.Lossy.gadget b w i j =\n      (let jk : Fin w × Fin b := finProdFinEquiv.symm i\n       if jk.1 = j then 2 ^ (jk.2 : ℕ) else 0) := rfl\n",
   "theorem ctlLossyGadgetReader (b w : ℕ) (i : Fin (w * b)) (j : Fin w) :\n    TCSlib.Cryptography.TrapdoorFunctions.Lossy.gadget b w i j =\n      (let jk : Fin w × Fin b := finProdFinEquiv.symm i\n       if jk.1 = j then 2 ^ (jk.2 : ℕ) else 0) :=\n  TCSlib.Cryptography.TrapdoorFunctions.Lossy.gadget_eq b w i j\n"),
 'TCSlib.Cryptography.LWE.BitEncoding.codepoint': row("ctlCodepoint",
   "theorem ctlCodepoint (P : TCSlib.Cryptography.LWE.Parameters) (b : Bool) :\n    TCSlib.Cryptography.LWE.BitEncoding.codepoint P b =\n      if b then ((P.modulus / 2 : ℕ) : ZMod P.modulus) else 0 := rfl\n",
   "theorem ctlCodepointReader (P : TCSlib.Cryptography.LWE.Parameters) (b : Bool) :\n    TCSlib.Cryptography.LWE.BitEncoding.codepoint P b =\n      if b then ((P.modulus / 2 : ℕ) : ZMod P.modulus) else 0 :=\n  TCSlib.Cryptography.LWE.BitEncoding.codepoint_eq P b\n"),
 'Randomized.blocksEquiv': row("ctlBlocksEquiv",
   "theorem ctlBlocksEquiv (n b : ℕ) : Randomized.blocksEquiv n b =\n    ((Equiv.arrowCongr finProdFinEquiv.symm (Equiv.refl Bool)).trans\n      (Equiv.curry _ _ _)).trans (Equiv.arrowCongr (Equiv.refl _) (Randomized.bitsEquiv b)) := rfl\n",
   "theorem ctlBlocksEquivReader {n b : ℕ} (r : Fin (n * b) → Bool) (i : Fin n) :\n    (Randomized.blocksEquiv n b r i : ℕ) = Randomized.blockVal b (List.ofFn r) i :=\n  Randomized.blocksEquiv_apply r i\n"),
 'BoolCircuit.DAGGate.eval': row("ctlDagEval",
   "theorem ctlDagEval (args : List ℕ) (vals : List Bool) :\n    BoolCircuit.DAGGate.eval ⟨.and, args⟩ vals = args.all fun a => vals.getD a false := rfl\n",
   "theorem ctlDagEvalReader (args : List ℕ) (vals : List Bool) :\n    BoolCircuit.DAGGate.eval ⟨.and, args⟩ vals = args.all fun a => vals.getD a false :=\n  (BoolCircuit.DAGGate.eval_eq _ _).trans rfl\n"),
 'BoolCircuit.DAGCircuit.depthAt': row("ctlDepthAt",
   "theorem ctlDepthAt {k : ℕ} (C : BoolCircuit.DAGCircuit k) (v : ℕ) : C.depthAt v = C.depths.getD v 0 := rfl\n",
   "theorem ctlDepthAtReader {k : ℕ} (C : BoolCircuit.DAGCircuit k) (v : ℕ) : C.depthAt v = C.depths.getD v 0 :=\n  C.depthAt_eq v\n"),
 'TCSlib.Cryptography.acceptProb': row("ctlAcceptProb",
   "theorem ctlAcceptProb {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :\n    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true := rfl\n",
   "theorem ctlAcceptProbReader {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :\n    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true :=\n  TCSlib.Cryptography.acceptProb_def X D\n"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace GswControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end GswControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
