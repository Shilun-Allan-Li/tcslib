#!/usr/bin/env python3
"""Maintainer frozen-statement check (gsw-core r1 review); independent of the delivery's tool.

Usage: python3 -I frozen.py <base.lean> <final.lean> <targets-comma-separated>

Splits each file into top-level items (commands at column 0 outside comments; a docstring and
any `... in` prefix lines attach to the next command).  Rules checked:
  * every base item reappears in final, in the same relative order (key = kind + name, or the
    normalized text for anonymous commands);
  * a target (base body `sorry`): header byte-identical (everything up to the top-level `:=`,
    `where` or first column-0 `|`), docstring byte-identical up to `**Proof sketch.**`,
    and the sketch marker still present; the body may change;
  * every other base item: byte-identical as a whole (docstring, header, body);
  * final-only items are listed (ADDED) with their modifiers.
Prints one line per difference and a summary `DIFFS=<n> REMOVED=<n> ORDER=<n> ADDED=<n>`.
"""
import re
import sys

CMD = re.compile(
    r'^(@\[|private\b|protected\b|noncomputable\b|partial\b|unsafe\b|theorem\b|lemma\b|def\b|'
    r'abbrev\b|structure\b|class\b|instance\b|inductive\b|example\b|attribute\b|notation\b|'
    r'local\b|scoped\b|include\b|omit\b|macro\b|syntax\b|mutual\b|alias\b|import\b|'
    r'set_option\b|namespace\b|section\b|end\b|open\b|variable\b|universe\b|#|initialize\b|'
    r'opaque\b|axiom\b|irreducible_def\b|export\b)')
DECL_KW = ('theorem', 'lemma', 'def', 'abbrev', 'structure', 'class', 'instance', 'inductive',
           'example', 'opaque', 'axiom', 'irreducible_def')


def split_items(text):
    lines = text.split('\n')
    items = []  # list of (kind, lines)
    depth = 0  # block comment nesting
    cur = None
    pending = []  # docstring / `in` prefix lines waiting for their command
    for ln in lines:
        start_depth = depth
        # update comment depth (ignores strings; adequate for these files)
        i = 0
        while i < len(ln):
            if ln.startswith('/-', i):
                depth += 1
                i += 2
            elif ln.startswith('-/', i) and depth > 0:
                depth -= 1
                i += 2
            elif ln.startswith('--', i) and depth == 0:
                break
            else:
                i += 1
        if start_depth > 0:
            # inside a comment that started earlier
            (pending if cur is None else cur[1]).append(ln)
            if pending and cur is None and depth == 0 and pending[0].startswith('/-!'):
                items.append(('moddoc', pending))
                pending = []
            if pending and cur is None and depth == 0 and pending[0].startswith('/-') and \
                    not pending[0].startswith('/--') and not pending[0].startswith('/-!'):
                items.append(('comment', pending))
                pending = []
            continue
        if ln.startswith('/--'):
            if cur is not None:
                items.append(cur)
                cur = None
            pending.append(ln)
            continue
        if ln.startswith('/-!') or (ln.startswith('/-') and not ln.startswith('/--')):
            if cur is not None:
                items.append(cur)
                cur = None
            pending.append(ln)
            if depth == 0:
                items.append(('moddoc' if ln.startswith('/-!') else 'comment', pending))
                pending = []
            continue
        if ln.startswith('--'):
            if cur is not None:
                items.append(cur)
                cur = None
            items.append(('linecomment', [ln]))
            continue
        if CMD.match(ln):
            if cur is not None:
                items.append(cur)
                cur = None
            if re.search(r'\bin\s*$', ln) and re.match(r'^(open|set_option|include|omit)\b', ln):
                pending.append(ln)
                continue
            cur = ('cmd', pending + [ln])
            pending = []
            continue
        # continuation or blank
        if cur is not None:
            cur[1].append(ln)
        elif ln.strip() == '':
            continue
        else:
            pending.append(ln)
    if cur is not None:
        items.append(cur)
    if pending:
        items.append(('dangling', pending))
    out = []
    for kind, ls in items:
        while ls and ls[-1].strip() == '':
            ls = ls[:-1]
        out.append((kind, '\n'.join(ls)))
    return out


def decl_info(body):
    """Return (docstring, prefix_lines, header, proof, keyword, name) for a cmd item."""
    m = re.match(r'(/--.*?-/\n)', body, re.S)
    doc = m.group(1) if m else ''
    rest = body[len(doc):]
    # strip `... in` prefix lines
    pre = ''
    while True:
        m2 = re.match(r'((?:open|set_option|include|omit)\b[^\n]*\bin\s*\n)', rest)
        if not m2:
            break
        pre += m2.group(1)
        rest = rest[len(m2.group(1)):]
    s = rest
    s2 = re.sub(r'^(@\[[^\]]*\]\s*)+', '', s)
    toks = s2.split()
    kw = None
    name = None
    for j, t in enumerate(toks):
        if t in DECL_KW:
            kw = t
            if j + 1 < len(toks) and t not in ('example',):
                name = toks[j + 1]
            break
    if kw is None:
        return doc, pre, rest, '', None, None
    # header: up to first top-level `:=` / ` where` / column-0 `|`
    depthb = 0
    hdr_end = len(rest)
    i = 0
    while i < len(rest):
        c = rest[i]
        if c in '([{⟨':
            depthb += 1
        elif c in ')]}⟩':
            depthb -= 1
        elif depthb == 0:
            if rest.startswith(':=', i):
                hdr_end = i
                break
            if re.match(r'\swhere\b', rest[i - 1:i + 6] if i > 0 else '') and \
                    rest.startswith('where', i):
                hdr_end = i
                break
            if c == '|' and i > 0 and rest[i - 1] == '\n':
                hdr_end = i
                break
        i += 1
    return doc, pre, rest[:hdr_end], rest[hdr_end:], kw, name


def key_of(kind, body):
    if kind != 'cmd':
        return (kind, body)
    doc, pre, hdr, proof, kw, name = decl_info(body)
    if kw is None:
        return ('cmd', body[len(doc):])
    if name is None:
        return (kw, hdr)
    return (kw, name)


def main():
    base_p, fin_p, targets_s = sys.argv[1], sys.argv[2], sys.argv[3]
    targets = set(t for t in targets_s.split(',') if t)
    base = split_items(open(base_p, encoding='utf-8').read())
    fin = split_items(open(fin_p, encoding='utf-8').read())
    bkeys = [key_of(k, b) for k, b in base]
    fkeys = [key_of(k, b) for k, b in fin]
    fidx = {}
    for j, k in enumerate(fkeys):
        fidx.setdefault(k, []).append(j)
    diffs = removed = order = 0
    last = -1
    matched = set()
    seen_targets = set()
    for i, (k, (kind, body)) in enumerate(zip(bkeys, base)):
        cands = [j for j in fidx.get(k, []) if j not in matched]
        if not cands:
            removed += 1
            print(f'REMOVED base item {i}: {k[0]} {str(k[1])[:80]!r}')
            continue
        j = cands[0]
        matched.add(j)
        if j < last:
            order += 1
            print(f'ORDER base item {i} ({k[0]} {str(k[1])[:60]!r}) at final {j} < {last}')
        last = max(last, j)
        fbody = fin[j][1]
        name = k[1] if kind == 'cmd' else None
        short = name.split('.')[-1] if isinstance(name, str) else None
        is_target = kind == 'cmd' and isinstance(name, str) and (name in targets or
                                                                 short in targets and
                                                                 name in targets)
        if kind == 'cmd' and isinstance(name, str) and name in targets:
            seen_targets.add(name)
            bd, bpre, bh, bproof, _, _ = decl_info(body)
            fd, fpre, fh, fproof, _, _ = decl_info(fbody)
            if not re.fullmatch(r':=\s*by\s*\n\s*sorry\s*', bproof):
                print(f'NOTE target {name}: base body is not `:= by sorry`: {bproof!r}')
            if bpre != fpre:
                diffs += 1
                print(f'DIFF target {name}: `in` prefix differs')
            if bh != fh:
                diffs += 1
                print(f'DIFF target {name}: header differs\n  base: {bh!r}\n  final: {fh!r}')
            mk = '**Proof sketch.**'
            if mk not in bd:
                print(f'NOTE target {name}: base docstring has no sketch marker')
                if bd != fd:
                    diffs += 1
                    print(f'DIFF target {name}: docstring differs (no marker)')
            else:
                bp = bd[:bd.index(mk)]
                if mk not in fd:
                    diffs += 1
                    print(f'DIFF target {name}: final docstring lost the sketch marker')
                elif fd[:fd.index(mk)] != bp:
                    diffs += 1
                    print(f'DIFF target {name}: prose before sketch differs')
            if 'sorry' in re.sub(r'--[^\n]*', '', fproof):
                print(f'NOTE target {name}: final body still contains `sorry`')
        else:
            if body != fbody:
                diffs += 1
                print(f'DIFF non-target item {i} ({k[0]} {str(k[1])[:60]!r}) changed')
    added = 0
    for j, (kind, body) in enumerate(fin):
        if j in matched:
            continue
        added += 1
        k = fkeys[j]
        first = [ln for ln in body.split('\n') if not ln.startswith('/--') and
                 ln.strip() and not ln.startswith(' ')]
        mods = 'private' if re.search(r'^private\b', body, re.M) else 'PUBLIC'
        print(f'ADDED final item {j}: {k[0]} {str(k[1])[:70]!r} [{mods}]')
    missing_t = sorted(t for t in targets if t not in seen_targets)
    for t in missing_t:
        print(f'NOTE target not found among items of this file: {t}')
    print(f'ITEMS base={len(base)} final={len(fin)} targets_seen={len(seen_targets)}')
    print(f'DIFFS={diffs} REMOVED={removed} ORDER={order} ADDED={added}')


if __name__ == '__main__':
    main()
