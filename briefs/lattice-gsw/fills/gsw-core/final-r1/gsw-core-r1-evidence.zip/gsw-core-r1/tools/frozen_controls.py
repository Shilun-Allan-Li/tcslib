#!/usr/bin/env python3
"""Controls for frozen.py: mutate final copies, expect exact difference counts.

Usage: python3 -I frozen_controls.py <statements dir> <base-sorries.txt> <workdir>
"""
import os
import re
import subprocess
import sys

sd, bs, wd = sys.argv[1], sys.argv[2], sys.argv[3]
here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(wd, exist_ok=True)
targets = {}
for ln in open(bs, encoding='utf-8'):
    m = re.match(r'.*/GSW/(\w+): \d+: (.*)', ln.strip())
    if m:
        targets[m.group(1)] = m.group(2).replace(' ', '')


def run(f, text):
    p = os.path.join(wd, f + '.lean')
    open(p, 'w', encoding='utf-8').write(text)
    out = subprocess.run([sys.executable, '-I', os.path.join(here, 'frozen.py'),
                          os.path.join(sd, 'base', f + '.lean'), p, targets[f]],
                         capture_output=True, text=True).stdout
    s = re.search(r'DIFFS=(\d+) REMOVED=(\d+) ORDER=(\d+) ADDED=(\d+)', out)
    return tuple(int(x) for x in s.groups()), out


def once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


controls = []
fin = {f: open(os.path.join(sd, 'final', f + '.lean'), encoding='utf-8').read()
       for f in ('Gadget', 'Noise', 'Scheme', 'Symmetric', 'Eval')}
# C1: one-character change in a target header (Noise, Encrypts.mul: `β₂` binder -> `β₃`)
t = fin['Noise']
i = t.index('theorem Encrypts.mul {')
j = t.index(':=', i)
hdr = t[i:j]
new_hdr = hdr.replace('x₁.natAbs * β₂', 'x₁.natAbs * β₁', 1)
assert new_hdr != hdr
controls.append(('C1 one-char target header (Noise Encrypts.mul)', 'Noise',
                 t[:i] + new_hdr + t[j:], (1, 0, 0, 0)))
# C2: delete a reader (Noise mul_eq, with its docstring)
i2 = t.index('theorem mul_eq ')
s2 = t.rindex('/--', 0, i2)
e2 = t.index('/--', i2)
controls.append(('C2 deleted reader (Noise mul_eq)', 'Noise',
                 t[:s2] + t[e2:], (0, 1, 0, 0)))
# C3: prose before a target's sketch altered by one character (Gadget errorSum_decomposeVec_le)
g = fin['Gadget']
i = g.index('theorem errorSum_decomposeVec_le')
k = g.rindex('/--', 0, i)
ps = g.index('**Proof sketch.**', k)
seg = g[k:ps]
pos = seg.index(' ', 5)
controls.append(('C3 prose-before-sketch one char (Gadget errorSum_decomposeVec_le)', 'Gadget',
                 g[:k] + seg[:pos] + '  ' + seg[pos + 1:] + g[ps:], (1, 0, 0, 0)))
# C4: definition body changed (Gadget `gadget` def body: one character)
i = g.index('def gadget ')
j = g.index(':=', i)
controls.append(('C4 definition body (Gadget gadget)', 'Gadget',
                 g[:j + 2] + ' ' + g[j + 2:], (1, 0, 0, 0)))
# C5: swap two readers (Eval homNot_eq <-> homOr def block order): move `homOr` def+reader before homNot
e = fin['Eval']
a = e.index('/--', e.rindex('\n\n', 0, e.index('def homNot ')))
b = e.index('/--', e.index('theorem homNot_eq'))
c = e.index('/--', e.index('theorem homOr_eq'))
controls.append(('C5 order swap (Eval homNot block <-> homOr block)', 'Eval',
                 e[:a] + e[b:c] + e[a:b] + e[c:], None))
# C6: `variable` line altered (Noise)
vl = re.search(r'^variable .*$', t, re.M).group(0)
controls.append(('C6 variable line altered (Noise)', 'Noise', once(t, vl, vl + ' '), (0, 1, 0, 1)))
# C7: public declaration added (Symmetric)
s = fin['Symmetric']
endl = 'end TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW'
controls.append(('C7 added public theorem (Symmetric)', 'Symmetric',
                 once(s, endl, 'theorem ctlAdded : True := trivial\n\n' + endl), (0, 0, 0, 2)))
# C8: target body and sketch changed only (allowed): expect 0 differences
sc = fin['Scheme']
i = sc.index('theorem decrypt_keygen_encrypt')
k = sc.rindex('/--', 0, i)
ps = sc.index('**Proof sketch.**', k)
controls.append(('C8 allowed edit: target sketch text (Scheme decrypt_keygen_encrypt)', 'Scheme',
                 sc[:ps + 17] + ' CTL' + sc[ps + 17:], (0, 0, 0, 2)))
# C9: import line deleted (Scheme)
controls.append(('C9 import deleted (Scheme)', 'Scheme',
                 once(sc, 'import Mathlib.Data.Fin.Tuple.Basic\n', ''), (0, 1, 0, 2)))

ok = True
for name, f, text, exp in controls:
    got, out = run(f, text)
    if exp is None:
        good = got[2] >= 1 and got[0] == 0 and got[1] == 0
        exps = 'ORDER>=1, DIFFS=0, REMOVED=0'
    else:
        good = got == exp
        exps = 'DIFFS=%d REMOVED=%d ORDER=%d ADDED=%d' % exp
    ok &= good
    print(f'{"PASS" if good else "FAIL"} {name}: got DIFFS={got[0]} REMOVED={got[1]} '
          f'ORDER={got[2]} ADDED={got[3]}; expected {exps}')
    for ln in out.splitlines():
        if not ln.startswith(('ITEMS', 'DIFFS=')):
            print('    ' + ln[:150])
print('CONTROLS', 'ALL_PASS' if ok else 'SOME_FAIL')
