#!/usr/bin/env python3
"""Maintainer explicit-unfold scan (gsw-core r1 review).

Usage: python3 -I unfold_scan.py <tcslib-root> <mathlib-root> <batteries-root> <lean-src-root>
                                  <owned file>...

For every selector list of `simp`/`simp only`/`simpa`/`simp_all`/`dsimp`/`rw`/`rwa`/`erw`/
`rewrite`/`nth_rw`/`nth_rewrite`/`simp_rw`/`unfold`/`delta`/`field_simp`/`norm_num` in the owned
files, every token is classified against a source index of declarations (last name component):
  THEOREM  - declared only as theorem/lemma somewhere (a lemma: fine);
  OWN-DEF  - a def/abbrev/structure/... of the same owned file (allowed: own definitions);
  FOREIGN  - a TCSlib def of another file, including another owned file (Rule 10 violation);
  LIBDEF   - a core/Batteries/Mathlib definition (forbidden as a selector);
  AMBIG    - the name is both a definition and a theorem somewhere; resolved by full name when
             possible, otherwise listed for reading;
  LOCAL    - not declared anywhere (a hypothesis or local `have`).
Also lists every `change`/`show`/`unfold`/`delta` line for manual reading.
"""
import os
import re
import sys

DEF_RE = re.compile(r'^\s*(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|partial|unsafe|'
                    r'nonrec)\s+)*(def|abbrev|structure|inductive|class|instance|opaque|'
                    r'irreducible_def)\s+([^\s(:{\[]+)', re.M)
THM_RE = re.compile(r'^\s*(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|nonrec)\s+)*'
                    r'(theorem|lemma)\s+([^\s(:{\[]+)', re.M)
NS_RE = re.compile(r'^(namespace|end)\s+(\S+)', re.M)
TAC = r'(?:simp only|simp_all only|simp_all|simpa only|simpa|simp|dsimp only|dsimp|rwa|rw|erw|' \
      r'rewrite|nth_rw \d+|nth_rewrite \d+|simp_rw|unfold|delta|field_simp|norm_num)'


def index(roots):
    defs, thms = {}, {}
    for root in roots:
        for dp, _, fs in os.walk(root):
            for f in fs:
                if not f.endswith('.lean'):
                    continue
                p = os.path.join(dp, f)
                try:
                    t = open(p, encoding='utf-8').read()
                except Exception:
                    continue
                # namespaces for full names (approximate: flat stack by position)
                events = sorted([(m.start(), m.group(1), m.group(2)) for m in NS_RE.finditer(t)])
                def full_at(pos, name):
                    st = []
                    for (s, kind, n) in events:
                        if s > pos:
                            break
                        if kind == 'namespace':
                            st.append(n)
                        elif st and st[-1] == n:
                            st.pop()
                        elif st and st[-1].endswith('.' + n):
                            st.pop()
                    if name.startswith('_root_.'):
                        return name[7:]
                    return '.'.join(st + [name])
                for m in DEF_RE.finditer(t):
                    n = m.group(2)
                    full = full_at(m.start(), n)
                    defs.setdefault(n.split('.')[-1], set()).add((full, p, m.group(1)))
                for m in THM_RE.finditer(t):
                    n = m.group(2)
                    full = full_at(m.start(), n)
                    thms.setdefault(n.split('.')[-1], set()).add((full, p))
    return defs, thms


def selectors(text):
    out = []
    for m in re.finditer(r'\b' + TAC + r'\b(\s*\[)', text):
        i = m.end(1)
        depth = 1
        j = i
        while j < len(text) and depth:
            if text[j] == '[':
                depth += 1
            elif text[j] == ']':
                depth -= 1
            j += 1
        body = text[i:j - 1]
        line = text.count('\n', 0, m.start()) + 1
        for tok in re.split(r',(?![^()]*\))', body):
            tok = tok.strip().lstrip('←').strip()
            tok = re.sub(r'^(?:\(|←\s*)', '', tok)
            mm = re.match(r"[^\s()]+", tok)
            if mm:
                out.append((line, m.group(0).split('[')[0].strip(), mm.group(0), tok))
    for m in re.finditer(r'\b(unfold|delta)\s+([^\n\[]+)', text):
        line = text.count('\n', 0, m.start()) + 1
        for tok in m.group(2).split():
            if tok in ('at', '⊢'):
                break
            out.append((line, m.group(1), tok, tok))
    return out


def main():
    tcs, ml, bat, core = sys.argv[1:5]
    files = sys.argv[5:]
    tdefs, tthms = index([os.path.join(tcs, 'TCSlib')])
    ldefs, lthms = index([ml, bat, core])
    total = {}
    for f in files:
        text = open(f, encoding='utf-8').read()
        own = {m.group(2).split('.')[-1] for m in DEF_RE.finditer(text)}
        print(f'=== {f}')
        for line, tac, tok, raw in selectors(text):
            last = tok.split('.')[-1]
            if '@' in tok:
                last = tok.lstrip('@').split('.')[-1]
            td = tdefs.get(last, set())
            tt = tthms.get(last, set())
            ld = ldefs.get(last, set())
            lt = lthms.get(last, set())
            fulls_d = {x[0] for x in td | ld}
            fulls_t = {x[0] for x in tt | lt}
            def suffix_hit(fulls):
                return any(fn == tok or fn.endswith('.' + tok) for fn in fulls)
            if last in own and not (tt or lt) and not suffix_hit(fulls_t):
                cls = 'OWN-DEF'
            elif (td or ld) and not (tt or lt):
                cls = 'FOREIGN' if td else 'LIBDEF'
            elif (td or ld) and (tt or lt):
                if suffix_hit(fulls_t) and not suffix_hit(fulls_d):
                    cls = 'THEOREM'
                elif suffix_hit(fulls_d) and not suffix_hit(fulls_t):
                    cls = ('OWN-DEF' if last in own else 'FOREIGN') if td else 'LIBDEF'
                elif '.' not in tok and last in own:
                    cls = 'AMBIG-OWN'
                else:
                    cls = 'AMBIG'
            elif tt or lt:
                cls = 'THEOREM'
            else:
                cls = 'LOCAL'
            total[cls] = total.get(cls, 0) + 1
            if cls != 'THEOREM':
                where = sorted(x[0] for x in td | ld)[:4]
                print(f'  {f.split("/")[-1]}:{line} {tac} {tok} -> {cls} {where if where else ""}')
        for i, ln in enumerate(text.split('\n'), 1):
            if re.search(r'\b(change|show)\b', ln) and not ln.lstrip().startswith(('--', '/-')):
                print(f'  CHANGE/SHOW {f.split("/")[-1]}:{i}: {ln.strip()}')
    print('SUMMARY', ' '.join(f'{k}={v}' for k, v in sorted(total.items())))


if __name__ == '__main__':
    main()
