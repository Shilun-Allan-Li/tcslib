"""newwide.py <repo> <base-rev> <worktree> <file>...: lines over 100 characters (Python len) in the
worktree file whose exact text does not occur over 100 characters in the base file (new wide lines),
plus the count of base wide lines kept."""
import sys, subprocess
repo, base, wt = sys.argv[1:4]
tot = 0
for f in sys.argv[4:]:
    r = subprocess.run(['git', '-C', repo, 'show', f'{base}:{f}'], capture_output=True)
    bl = r.stdout.decode('utf-8').split('\n') if r.returncode == 0 else []
    bw = {l for l in bl if len(l) > 100}
    hl = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    new = [(i + 1, len(l)) for i, l in enumerate(hl) if len(l) > 100 and l not in bw]
    kept = sum(1 for l in hl if len(l) > 100 and l in bw)
    print(f'{f}\tbase-wide {len(bw)}\thead-wide-kept {kept}\tnew-wide {len(new)}\t{new}')
    tot += len(new)
print('RESULT new wide lines', tot)
