"""ledoc_scot.py <worktree>: the sc-ot landing edit LE-doc, as exact unique replacements inside
docstrings (formulas for the 50 new public declarations that docaudit flagged NO-FORMULA; the frozen
target otProtocol_polyTime keeps its base prose). Each old string must occur exactly once."""
import sys
wt = sys.argv[1]
D = 'TCSlib/Cryptography/SecureComputation/'
OT = D + 'ObliviousTransfer.lean'
EF = D + 'ObliviousTransfer/Efficiency.lean'
PR = D + 'ObliviousTransfer/Predictor.lean'
SH = D + 'ObliviousTransfer/Shape.lean'
SI = D + 'ObliviousTransfer/Simulators.lean'
VA = D + 'ObliviousTransfer/ViewA.lean'
VB = D + 'ObliviousTransfer/ViewB.lean'
E = [
 # ObliviousTransfer.lean (new declarations only)
 (OT, "uses `Gen`'s coins and Bob two sampler blocks, and it has five messages, Alice first. -/",
      "uses `Gen`'s coins and Bob two sampler blocks, and it has five messages, Alice first:\n"
      "`OT.IsOT T H (otProtocol T H)`. -/"),
 (OT, "`coinSeg`, `simIdx`, `simSample`). -/\ntheorem otSimA_isSimA",
      "`coinSeg`, `simIdx`, `simSample`): `OT.IsSimA T (otSimA T)`. -/\ntheorem otSimA_isSimA"),
 (OT, "`simSample`). -/\ntheorem otSimB_isSimB",
      "`simSample`): `OT.IsSimB T H (otSimB T hH)`. -/\ntheorem otSimB_isSimB"),
 # Efficiency.lean
 (EF, "/-- The second projection of the empty word is empty (`length_pairSndD_le`). -/",
      "/-- The second projection of the empty word is empty, `pairSndD [] = []`\n"
      "(`length_pairSndD_le`). -/"),
 (EF, "/-- `Gen`'s output on the raw layout `z`: `Gen(inParam z; inCoins z)` with empty argument. -/",
      "/-- `Gen`'s output on the raw layout `z`: `Gen(inParam z; inCoins z)` with empty argument,\n"
      "`genRaw T z = Gen.output (layout (inParam z) [] [] (inCoins z))`. -/"),
 (EF, "/-- `genRaw` is polynomial-time. -/",
      "/-- `genRaw` is polynomial-time: `PolyTimeComputable (genRaw T)`. -/"),
 (EF, "/-- The raw mask is polynomial-time in `z` for polynomial-time `yj` and `bt`.\n",
      "/-- The raw mask is polynomial-time in `z` for polynomial-time `yj` and `bt`:\n"
      "`PolyTimeComputable (fun z => maskRaw T H z (Y z) (B z))` for polynomial-time `H`, `Y`, `B`.\n"),
 (EF, "`polyTimeComputable_tail`). -/\ntheorem polyTimeComputable_senderRaw",
      "`polyTimeComputable_tail`): `PolyTimeComputable (senderRaw T H)` for polynomial-time `H`. -/\n"
      "theorem polyTimeComputable_senderRaw"),
 (EF, "/-- `Gen`'s output on the layout of an activation at `1^{|x|}` is `Gen(1^{|x|}; r)`. -/",
      "/-- `Gen`'s output on the layout of an activation at `1^{|x|}` is `Gen(1^{|x|}; r)`:\n"
      "`genRaw T (layout 1^n a [] r) = Gen.runAtL n [] r`. -/"),
 (EF, "/-- `y.getD 0 false` is the head bit. -/",
      "/-- `y.getD 0 false` is the head bit: `y.getD 0 false = y.headD false`. -/"),
 (EF, "/-- `y.getD 1 false` is the head bit of `y.drop 1`. -/",
      "/-- `y.getD 1 false` is the head bit of `y.drop 1`:\n"
      "`y.getD 1 false = (y.drop 1).headD false`. -/"),
 (EF, "`⟨⟨advInput |x| ⟨⟨x, y⟩, encodeMsgs hist⟩, []⟩, r⟩` it returns `senderNext T H x y r hist`.\n",
      "`⟨⟨advInput |x| ⟨⟨x, y⟩, encodeMsgs hist⟩, []⟩, r⟩` it returns `senderNext T H x y r hist`:\n"
      "`senderRaw T H ⟨⟨advInput |x| ⟨⟨x, y⟩, encodeMsgs hist⟩, []⟩, r⟩ =\n"
      "senderNext T H x y r hist`.\n"),
 (EF, "/-- Bob's raw element on the raw layout `z`: the sampler on the coins after the first block. -/",
      "/-- Bob's raw element on the raw layout `z`: the sampler on the coins after the first block,\n"
      "`rawRaw T z = Sample(inParam z, fst w; (inCoins z).drop coins_Sample(n))` with\n"
      "`w = snd (inArg z)`. -/"),
 (EF, "projection of the second message, by the choice bit `b`. -/\ndef outRaw",
      "projection of the second message, by the choice bit `b`:\n"
      "`outRaw T H z = zipWith xor (H ⟨fst w, knownRaw T z⟩) z_b` with `w = snd (inArg z)`. -/\n"
      "def outRaw"),
 (EF, "/-- Bob's ordered pair on the raw layout `z`: `⟨w', eval ⟨i, w⟩⟩` if `b`, else\n"
      "`⟨eval ⟨i, w⟩, w'⟩`. -/",
      "/-- Bob's ordered pair on the raw layout `z`: `⟨w', eval ⟨i, w⟩⟩` if `b`, else\n"
      "`⟨eval ⟨i, w⟩, w'⟩`, with `w = knownRaw T z`, `w' = rawRaw T z`, `i = fst (snd (inArg z))` and\n"
      "`b = (snd (fst (inArg z))).headD false`. -/"),
 (EF, "`⟨eval ⟨fst w, knownRaw⟩, rawRaw⟩`. -/",
      "`⟨eval ⟨fst w, knownRaw⟩, rawRaw⟩`, i.e. `pairRaw T z = if b then ⟨rawRaw T z, eval ⟨fst w,\n"
      "knownRaw T z⟩⟩ else ⟨eval ⟨fst w, knownRaw T z⟩, rawRaw T z⟩` with `w = snd (inArg z)`. -/"),
 (EF, "pairing, and branches on the choice bit and three emptiness tests (`polyTimeComputable_ite`).\n",
      "pairing, and branches on the choice bit and three emptiness tests (`polyTimeComputable_ite`):\n"
      "`PolyTimeComputable (receiverRaw T H)` for polynomial-time `H`.\n"),
 (EF, "/-- On the layout of an activation, `knownRaw` is the sampler on the first coin block. -/",
      "/-- On the layout of an activation, `knownRaw` is the sampler on the first coin block:\n"
      "`knownRaw T (layout 1^n ⟨u, encodeMsgs hist⟩ [] r) =\n"
      "Sample.runAtL n (hist.headD []) (r.take coins_Sample(n))`. -/"),
 (EF, "/-- On the layout of an activation, `rawRaw` is the sampler on the second coin block. -/",
      "/-- On the layout of an activation, `rawRaw` is the sampler on the second coin block:\n"
      "`rawRaw T (layout 1^n ⟨u, encodeMsgs hist⟩ [] r) =\n"
      "Sample.runAtL n (hist.headD []) (r.drop coins_Sample(n))`. -/"),
 (EF, "`⟨⟨advInput |x| ⟨⟨x, z⟩, encodeMsgs hist⟩, []⟩, r⟩` it returns `receiverNext T H x z r hist`.\n",
      "`⟨⟨advInput |x| ⟨⟨x, z⟩, encodeMsgs hist⟩, []⟩, r⟩` it returns `receiverNext T H x z r hist`:\n"
      "`receiverRaw T H ⟨⟨advInput |x| ⟨⟨x, z⟩, encodeMsgs hist⟩, []⟩, r⟩ =\n"
      "receiverNext T H x z r hist`.\n"),
 (EF, "polynomially bounded (`exists_messages_le`). -/",
      "polynomially bounded (`exists_messages_le`): `IsOT T H π → otFunctionality.PolyTime π`. -/"),
 # Predictor.lean
 (PR, "branch on the fixed bit `b`). -/",
      "branch on the fixed bit `b`): `PolyTimeComputable (fun z =>\n"
      "bobView H (U z) b a₀ a₁ (I z) (S z) (W z) ((B z).headD false))`. -/"),
 (PR, "coins after the first `coins_Sample(n)`. -/",
      "coins after the first `coins_Sample(n)`: `viewDistRaw T H D b a₀ a₁ z = D.output (layout\n"
      "(inParam z) (viewRaw T H b a₀ a₁ z) (inAdvice z) ((inCoins z).drop coins_Sample(n)))`. -/"),
 (PR, "`PolyTimeComputable.append`).\n",
      "`PolyTimeComputable.append`): `PolyTimeComputable (viewDistRaw T H D b a₀ a₁)`.\n"),
 (PR, "coins `coins_Sample + coins_D`. -/",
      "coins `coins_Sample + coins_D`: `viewDist T hH D b a₀ a₁ = NUPPT.ofPolyTime\n"
      "(polyTimeComputable_viewDistRaw T hH D b a₀ a₁) (.add T.sample.coins D.coins) D.adv D.advice\n"
      "D.advice_length`. -/"),
 (PR, "/-- The coin polynomial of `D'` is `coins_Sample + coins_D`. -/",
      "/-- The coin polynomial of `D'` is `coins_Sample + coins_D`:\n"
      "`(viewDist T hH D b a₀ a₁).coins = .add T.sample.coins D.coins`. -/"),
 (PR, "/-- **`D'`'s coins** as a sampler block and `D`'s coins. -/",
      "/-- **`D'`'s coins** as a sampler block and `D`'s coins:\n"
      "`(viewDist T hH D b a₀ a₁).Coins n ≃ T.sample.Coins n × D.Coins n` (`splitLen`). -/"),
 # Shape.lean
 (SH, "/-- The defining equation of `senderNext`: `[]` ↦ `i`, `[m]` ↦ the two masks, else `[]`. -/",
      "/-- The defining equation of `senderNext`: `[]` ↦ `i`, `[m]` ↦ the two masks, else `[]`, i.e.\n"
      "`senderNext T H x y r hist = if |hist| = 0 then i else if |hist| = 1 then\n"
      "⟨mask (fst m) y₀, mask (snd m) y₁⟩ else []` with `i = fst Gen(1^{|x|}; r)` and\n"
      "`m = hist.headD []`. -/"),
 (SH, "/-- The defining equation of `receiverNext`: `[i]` ↦ the ordered pair, two messages ↦ `[]`,\n"
      "else `H ⟨i, w⟩ ⊕ z_b`. -/",
      "/-- The defining equation of `receiverNext`: `[i]` ↦ the ordered pair, two messages ↦ `[]`,\n"
      "else `H ⟨i, w⟩ ⊕ z_b`, i.e. `receiverNext T H x z r hist = if |hist| = 1 then P else\n"
      "if |hist| = 2 then [] else H ⟨i, w⟩ ⊕ z_b` with `P` the pair `⟨f_i(w), w'⟩` (or `⟨w', f_i(w)⟩`\n"
      "when `b`), `i = hist.headD []` and `z_b` read off `hist.getD 1 []`. -/"),
 (SH, "/-- The defining property of `IsOT`: `IsOT T H π` iff the six field equations hold. -/",
      "/-- The defining property of `IsOT`: `IsOT T H π` iff the six field equations hold,\n"
      "`IsOT T H π ↔ P.next = senderNext T H ∧ V.next = receiverNext T H ∧ P.coins = coins_Gen ∧\n"
      "V.coins = coins_Sample + coins_Sample ∧ rounds = 5 ∧ verifierFirst = false`. -/"),
 (SH, "/-- Bob's first message is the ordered pair `⟨f_i(w), w'⟩` (or `⟨w', f_i(w)⟩` when `b`). -/",
      "/-- Bob's first message is the ordered pair `⟨f_i(w), w'⟩` (or `⟨w', f_i(w)⟩` when `b`):\n"
      "`receiverNext T H x z r [i] = if b then ⟨w', eval ⟨i, w⟩⟩ else ⟨eval ⟨i, w⟩, w'⟩` with\n"
      "`w = Sample(1^{|x|}, i; r.take coins_Sample)`, `w' = Sample(1^{|x|}, i; r.drop coins_Sample)`\n"
      "and `b = z.headD false`. -/"),
 # Simulators.lean
 (SI, "/-- The simulated index (the body of `simIdx`): `fst Gen(inParam z; simSeg 0 coins_Gen z)`. -/",
      "/-- The simulated index (the body of `simIdx`):\n"
      "`simIndex T z = fst Gen(inParam z; simSeg 0 coins_Gen z)`. -/"),
 (SI, "/-- A simulated sample after `p(n)` coins (the body of `simSample`):\n"
      "`Sample(inParam z, simIndex z; simSeg p coins_Sample z)`. -/",
      "/-- A simulated sample after `p(n)` coins (the body of `simSample`):\n"
      "`simSampled T p z = Sample(inParam z, simIndex z; simSeg p coins_Sample z)`. -/"),
 (SI, "`⟨⟨1^n, ⟨a₁, a₂⟩⟩, ⟨r_Gen, [⟨y₁, y₂⟩, []]⟩⟩` with two simulated samples `y₁, y₂`. -/",
      "`simAView T z = ⟨⟨1^n, ⟨a₁, a₂⟩⟩, ⟨r_Gen, [⟨y₁, y₂⟩, []]⟩⟩` with two simulated samples\n"
      "`y₁, y₂`. -/"),
 (SI, "/-- `S_B`'s pair `(z₁, z₂)` (the body of `otSimZ`): `z_b` from `simZbit`, `z_{1−b}` one coin. -/",
      "/-- `S_B`'s pair `(z₁, z₂)` (the body of `otSimZ`): `z_b` from `simZbit`, `z_{1−b}` one coin,\n"
      "`simZpair T H z = ⟨c, z_b⟩` if the choice bit is set, else `⟨z_b, c⟩`. -/"),
 (SI, "`⟨⟨1^n, [b]⟩, ⟨r_B, [i, ⟨z₁, z₂⟩, []]⟩⟩`. -/",
      "`simBView T H z = ⟨⟨1^n, [b]⟩, ⟨r_B, [i, ⟨z₁, z₂⟩, []]⟩⟩`. -/"),
 (SI, "/-- On a tape starting with `Gen`'s coins `r`, the simulated index is `index n r`. -/",
      "/-- On a tape starting with `Gen`'s coins `r`, the simulated index is `index n r`:\n"
      "`simIndex T (layout 1^n y [] (ofFn r ++ B)) = T.index n r`. -/"),
 (SI, "/-- Alice's OT input length is `2` (`otFunctionality_inA`). -/",
      "/-- Alice's OT input length is `2`, `otFunctionality.inA.eval n = 2` (`otFunctionality_inA`). -/"),
 (SI, "/-- Bob's OT input length is `1` (`otFunctionality_inB`). -/",
      "/-- Bob's OT input length is `1`, `otFunctionality.inB.eval n = 1` (`otFunctionality_inB`). -/"),
 (SI, "/-- The defining equation of `inA2`. -/",
      "/-- The defining equation of `inA2`: `inA2 a j = a (Fin.cast (inA_eval n).symm j)`. -/"),
 (SI, "/-- The defining equation of `inB1`. -/",
      "/-- The defining equation of `inB1`: `inB1 b j = b (Fin.cast (inB_eval n).symm j)`. -/"),
 (SI, "/-- Bob's choice string is the one-bit list `[inB1 b 0]`. -/",
      "/-- Bob's choice string is the one-bit list `[inB1 b 0]`: `List.ofFn b = [inB1 b 0]`. -/"),
 # ViewA.lean
 (VA, "uniform, every distinguisher's advantage between Alice's real and ideal samplers is at most\n"
      "`2δ(n)`.\n",
      "uniform, every distinguisher's advantage between Alice's real and ideal samplers is at most\n"
      "`2δ(n)`: `distAdv (realA π n a b) (idealA S n a b) (D.distinguisherL n) ≤ 2 * δ n`.\n"),
 # ViewB.lean
 (VB, "/-- **A finite sum of negligible functions is negligible** (`Negligible.add` by induction on the\n"
      "finite set). -/",
      "/-- **A finite sum of negligible functions is negligible** (`Negligible.add` by induction on the\n"
      "finite set): `(∀ i ∈ s, Negligible (f i)) → Negligible (fun n => ∑ i ∈ s, f i n)`. -/"),
 (VB, "/-- Alice's input string is the two-bit list `[a₀, a₁]`. -/",
      "/-- Alice's input string is the two-bit list `[a₀, a₁]`:\n"
      "`List.ofFn (inA2 a) = [inA2 a 0, inA2 a 1]`. -/"),
 (VB, "`distinguisherL_viewDist`, and the reordering `(s₂, (s₁, ρ)) ↦ ((s₁, s₂), ρ)`). -/",
      "`distinguisherL_viewDist`, and the reordering `(s₂, (s₁, ρ)) ↦ ((s₁, s₂), ρ)`):\n"
      "`acceptProb (fun x => (x, g x)) (fun yc ρ => D'.distinguisherL n ⟨i, ⟨ofFn yc.1, [yc.2]⟩⟩ ρ) =\n"
      "accB T H D n b a₀ a₁ r g` with `D' = viewDist T hH D b a₀ a₁` and `i = T.index n r`. -/"),
 (VB, "`1/2 + (accB … r B − accB … r ¬B) / 2` (`uprob_tdpPredictor`, `uprob_signedPredictor_false`,\n"
      "`acceptProb_viewDist`). -/",
      "`1/2 + (accB … r B − accB … r ¬B) / 2` (`uprob_tdpPredictor`, `uprob_signedPredictor_false`,\n"
      "`acceptProb_viewDist`): `uprob (fun z => P.distinguisherL n ⟨T.index n r, ofFn z.1⟩ z.2 = B z.1) =\n"
      "1 / 2 + (accB T H D n b a₀ a₁ r B - accB T H D n b a₀ a₁ r (fun s => !B s)) / 2` with\n"
      "`P = tdpPredictor (viewDist T hH D b a₀ a₁) false` and `B = hcBit T h n r`. -/"),
 (VB, "`hcBit T h n r s'` with probability `1/2 − (accB … r B − accB … r ¬B) / 2`. -/",
      "`hcBit T h n r s'` with probability `1/2 − (accB … r B − accB … r ¬B) / 2`:\n"
      "`uprob (fun z => P.distinguisherL n ⟨T.index n r, ofFn z.1⟩ z.2 = B z.1) =\n"
      "1 / 2 - (accB T H D n b a₀ a₁ r B - accB T H D n b a₀ a₁ r (fun s => !B s)) / 2` with\n"
      "`P = tdpPredictor (viewDist T hH D b a₀ a₁) true` and `B = hcBit T h n r`. -/"),
 (VB, "`|ε_false| + |ε_true|`.\n",
      "`|ε_false| + |ε_true|`:\n"
      "`distAdv (realB π n a b) (idealB S n a b) (D.distinguisherL n) ≤ |εf| + |εt|` under `hf`, `ht`.\n"),
 (VB, "a negligible `ε` bounding both advantages for all `n` and all inputs.\n",
      "a negligible `ε` bounding both advantages for all `n` and all inputs:\n"
      "`∀ D, ∃ ε, Negligible ε ∧ ∀ n x y, distAdv (realA π n x y) (idealA SA n x y) (D.distinguisherL n)\n"
      "≤ ε n ∧ distAdv (realB π n x y) (idealB SB n x y) (D.distinguisherL n) ≤ ε n`.\n"),
]
n = 0
for f, a, b in E:
    p = f'{wt}/{f}'
    s = open(p, encoding='utf-8').read()
    assert s.count(a) == 1, (f, s.count(a), a[:60])
    open(p, 'w', encoding='utf-8').write(s.replace(a, b))
    n += 1
print('LE-doc replacements applied:', n)
