"""fullsealmap.py <record.json> <log> <touched.json> <inserted-after-line>: map the error lines of a full-file seal probe
(one line inserted after probe line N) back to source declarations through the record's source_to_probe_lines and the
touched.json spans. Prints the error count and the failing declarations."""
import sys, json, re, collections
rec, log, tj, ins = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
r = json.load(open(rec)); m = r['source_to_probe_lines']
p2s = {}
for e in m:
    if isinstance(e, dict): s, p = e['source_line'], e['probe_line']
    else: s, p = e
    p2s[p + (1 if p > ins else 0)] = s
spans = [(d['start'], d['end'], d['name']) for d in json.load(open(tj))['files'][r['source']]['declarations']]
errs = [int(x) for x in re.findall(r'^\S+\.lean:(\d+):\d+: error', open(log, encoding='utf-8').read(), re.M)]
c = collections.Counter()
for p in errs:
    s = p2s.get(p)
    n = next((nm for a, b, nm in spans if s is not None and a <= s <= b), f'UNMAPPED(probe {p})')
    c[n] += 1
print('errors', len(errs), 'declarations', len(c))
for n in sorted(c): print(f'{c[n]}\t{n}')
