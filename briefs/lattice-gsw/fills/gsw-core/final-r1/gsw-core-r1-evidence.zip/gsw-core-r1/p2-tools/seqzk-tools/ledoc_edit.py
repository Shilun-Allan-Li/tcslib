"""ledoc_edit.py <worktree>: learning-r1 landing edit LE-doc. Docstring-only formula additions for the 17
new public declarations whose docstring has no backticked formula (statements/docaudit.tsv). Each
replacement is exact and must occur once; every old and new string lies inside a `/-- ... -/` docstring.
Run from a clean checkout of the landing head."""
import sys, os
wt = sys.argv[1]
D = 'TCSlib/Cryptography/Randomness/Learning/'
R = [
 (D + 'Sample.lean',
  "`⟨⟨ρ_j, g(ρ_j)⟩, []⟩` (as in `MultiMsg.exists_queryChain_nuppt`). -/",
  "`⟨⟨ρ_j, g(ρ_j)⟩, []⟩` (as in `MultiMsg.exists_queryChain_nuppt`):\n"
  "`tupleWord ρ g = (List.ofFn fun j => ⟨⟨⟦ρ j⟧, ⟦g (ρ j)⟧⟩, []⟩).flatten`. -/"),
 (D + 'Sample.lean',
  "example of the pair. -/\ndef relabel",
  "example of the pair:\n"
  "`relabel w = ⟨⟨pairFstD (pairFstD w), [(pairSndD (pairFstD w)).headD false]⟩, []⟩`. -/\ndef relabel"),
 (D + 'Sample.lean',
  "/-- Relabelling is polynomial-time. -/",
  "/-- Relabelling is polynomial-time: `PolyTimeComputable relabel`, for\n"
  "`relabel : List Bool → List Bool`. -/"),
 (D + 'Sample.lean',
  "/-- The length `m(n) · (6n + 6)` of the first `m(n)` blocks. -/",
  "/-- The length `m(n) · (6n + 6)` of the first `m(n)` blocks:\n"
  "`sampleLen m = m · histBlockLen` as a `PolyExpr`. -/"),
 (D + 'Sample.lean',
  "`s.take (sampleLen m (|u|))` (the function of `Complexity.polyTimeComputable_blockMap`). -/",
  "`s.take (sampleLen m (|u|))` (the function of `Complexity.polyTimeComputable_blockMap`):\n"
  "`sampleOf m ⟨u, s⟩ = (range (|s'| / b)).flatMap fun i => relabel ((s'.drop (i * b)).take b)`,\n"
  "with `s' = s.take ((sampleLen m).eval |u|)` and `b = histBlockLen.eval |u|`. -/"),
 (D + 'Sample.lean',
  "/-- `sampleOf m z` is the block map of `relabel` over the first `sampleLen m` bits. -/",
  "/-- `sampleOf m z` is the block map of `relabel` over the first `sampleLen m` bits:\n"
  "`sampleOf m ⟨u, s⟩ = (range (|s'| / b)).flatMap fun i => relabel ((s'.drop (i * b)).take b)`,\n"
  "with `s' = s.take ((sampleLen m).eval |u|)` and `b = histBlockLen.eval |u|`. -/"),
 (D + 'Sample.lean',
  "/-- The last block's pair `⟨x, y⟩` on `⟨u, s⟩`: `pairFstD (s.drop (sampleLen m (|u|)))`. -/",
  "/-- The last block's pair `⟨x, y⟩` on `⟨u, s⟩`:\n"
  "`lastPair m ⟨u, s⟩ = pairFstD (s.drop ((sampleLen m).eval |u|))`. -/"),
 (D + 'Sample.lean',
  "blocks and the point `x` of the last block. -/",
  "blocks and the point `x` of the last block: `learnIn m z = ⟨sampleOf m z, pairFstD (lastPair m z)⟩`.\n-/"),
 (D + 'Sample.lean',
  "/-- **The last label** on `⟨1^n, s⟩`: the first bit of the answer of the last block. -/",
  "/-- **The last label** on `⟨1^n, s⟩`: the first bit of the answer of the last block,\n"
  "`lastLabel m z = (pairSndD (lastPair m z)).headD false`. -/"),
 (D + 'Sample.lean',
  "/-- The last block's pair is polynomial-time (`polyTimeComputable_pairDropPoly`). -/",
  "/-- The last block's pair is polynomial-time (`polyTimeComputable_pairDropPoly`):\n"
  "`PolyTimeComputable (lastPair m)`, for `lastPair m : List Bool → List Bool`. -/"),
 (D + 'Sample.lean',
  "(`polyTimeComputable_pairTakePoly`), paired with the last point. -/",
  "(`polyTimeComputable_pairTakePoly`), paired with the last point: `PolyTimeComputable (learnIn m)`,\n"
  "for `learnIn m : List Bool → List Bool`. -/"),
 (D + 'Sample.lean',
  "/-- The last label, as a one-bit output, is polynomial-time. -/",
  "/-- The last label, as a one-bit output, is polynomial-time:\n"
  "`PolyTimeComputable fun z => [lastLabel m z]`, for `z ↦ [lastLabel m z] : List Bool → List Bool`. -/"),
 (D + 'Sample.lean',
  "the last point `⟦ρ_m⟧`.\n",
  "the last point `⟦ρ_m⟧`:\n"
  "`learnIn m ⟨1^n, tupleWord ρ g⟩ =\n"
  "⟨(ofFn j ↦ ⟨⟦ρ_j⟧, [firstBit (g ρ_j)]⟩).foldr pairEncode [], ⟦ρ_m⟧⟩` (`j < m(n)`).\n"),
 (D + 'Sample.lean',
  "bit of the last answer, `firstBit (g ρ_m)`. -/",
  "bit of the last answer: `lastLabel m ⟨1^n, tupleWord ρ g⟩ = firstBit (g ρ_m)`. -/"),
 (D + 'Distinguisher.lean',
  "`polyTimeComputable_lastLabel`). -/",
  "`polyTimeComputable_lastLabel`): `PolyTimeComputable (verdictFun m)`, for\n"
  "`verdictFun m : List Bool → List Bool`. -/"),
 (D + 'Law.lean',
  "/-- **Examples and a fresh point as one tuple:** `((k, (s, r)), x) ↦ (k, (snoc s x, r))`. -/",
  "/-- **Examples and a fresh point as one tuple:** `((k, (s, r)), x) ↦ (k, (snoc s x, r))`, an\n"
  "equivalence `(K × ((Fin m → X) × ρ)) × X ≃ K × ((Fin (m + 1) → X) × ρ)`. -/"),
 (D + 'Random.lean',
  "/-- `flipAt hn x` is an involution. -/",
  "/-- `flipAt hn x` is an involution: `flipAt hn x (flipAt hn x R) = R`. -/"),
]
src = {}
for f, a, b in R:
    p = os.path.join(wt, f)
    s = src.setdefault(f, open(p, encoding='utf-8').read())
    assert s.count(a) == 1, (f, a, s.count(a))
    src[f] = s.replace(a, b)
for f, s in src.items():
    open(os.path.join(wt, f), 'w', encoding='utf-8').write(s)
    print('edited', f)
print('replacements', len(R))
