"""gitmancheck.py <repo> <commit> <prefix/> <manifest path relative to prefix> [exclude-self]
(seq-zk review) mancheck.py without extraction: the delivered file set is `git ls-tree -r <commit> <prefix>`
(paths relative to <prefix>), every blob is streamed through `git cat-file --batch` and hashed with SHA-256, and the
`<sha256>  <path>` manifest (read from the same commit) must match with exact path-set equality ('./' stripped).
With exclude-self, the manifest file itself is excluded from the delivered set. Prints BAD/MISSING/EXTRA/DUP lines and
a RESULT line; with OUT=<file> in the environment also writes `<sha256>  <path>` for every delivered file."""
import sys, os, subprocess, hashlib
repo, commit, prefix, man = sys.argv[1:5]; excl = len(sys.argv) > 5
if not prefix.endswith('/'): prefix += '/'
ls = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', '-z', commit, prefix], capture_output=True, check=True).stdout
files = {}
for ent in ls.split(b'\0'):
    if not ent: continue
    meta, path = ent.split(b'\t', 1); mode, typ, oid = meta.split()
    files[path.decode()[len(prefix):]] = oid.decode()
p = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
def blob(oid):
    p.stdin.write(oid.encode() + b'\n'); p.stdin.flush()
    hdr = p.stdout.readline().split(); n = int(hdr[2]); data = p.stdout.read(n); p.stdout.read(1); return data
have = {k: hashlib.sha256(blob(v)).hexdigest() for k, v in sorted(files.items())}
mbase = os.path.dirname(man); mbase = mbase + '/' if mbase else ''
ent = {}
for l in blob(files[man]).decode('utf-8').split('\n'):
    if not l: continue
    h, q = l.split('  ', 1); q = q[2:] if q.startswith('./') else q
    if q in ent: print('DUP', q)
    ent[mbase + q] = h
deliv = {k for k in have if k.startswith(mbase)}
if excl: deliv.discard(man)
ok = bad = 0
for q, h in sorted(ent.items()):
    if q not in have: print('MISSING', q); bad += 1
    elif have[q] == h: ok += 1
    else: print('BAD', q); bad += 1
extra = sorted(deliv - set(ent))
for q in extra: print('EXTRA', q)
if os.environ.get('OUT'):
    with open(os.environ['OUT'], 'w') as o:
        for k in sorted(have): o.write(f'{have[k]}  {k}\n')
print(f'manifest {man}: entries {len(ent)} delivered {len(deliv)} ok {ok} bad/missing {bad} extra {len(extra)}')
print('RESULT', 'OK' if bad == 0 and not extra else 'FAIL')
