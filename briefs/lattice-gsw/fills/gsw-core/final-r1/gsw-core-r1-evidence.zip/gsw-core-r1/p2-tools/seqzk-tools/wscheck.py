"""wscheck.py <repo> <old-rev> <file>...: the working-tree file and <old-rev>'s file have the same
whitespace-separated token sequence (so the change is whitespace-only: line breaks and indentation),
and reports changed line counts and max width (Python len)."""
import sys, subprocess
repo, rev, files = sys.argv[1], sys.argv[2], sys.argv[3:]
ok = True
for f in files:
    a = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True, check=True).stdout.decode('utf-8')
    b = open(f'{repo}/{f}', encoding='utf-8').read()
    same = a.split() == b.split(); ok &= same
    print(f"{'TOKENS-IDENTICAL' if same else 'TOKENS-DIFFER'}\t{f}\tlines {a.count(chr(10))}->{b.count(chr(10))}\tmaxwidth {max(map(len, b.split(chr(10))))}")
print('RESULT', 'WHITESPACE-ONLY' if ok else 'NOT-WHITESPACE-ONLY')
