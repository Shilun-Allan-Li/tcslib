"""closurecmp.py <repo> <rev> <ref-rev> <module>...: (derand review) the local import closure of each module at <rev>
(imports parsed as in downorder.py) and, per closure module, whether its source blob at <rev> equals the one at
<ref-rev> (the olean tree's base). A module whose closure is all EQUAL can be probed on the <ref-rev> tree."""
import sys, re, subprocess
repo, rev, ref = sys.argv[1:4]; mods = sys.argv[4:]
git = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True).stdout
blob = lambda r, m: git('rev-parse', f'{r}:{m}.lean').strip()
imps = {}
def get(m):
    if m not in imps:
        imps[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', git('show', f'{rev}:{m}.lean'), re.M)
                   if i.split('.')[0] in ('TCSlib', 'audits')]
    return imps[m]
for m in mods:
    seen, todo = set(), list(get(m))
    while todo:
        x = todo.pop()
        if x in seen: continue
        seen.add(x); todo += get(x)
    diff = sorted(x for x in seen if blob(rev, x) != blob(ref, x))
    print(f'{m}: closure {len(seen)}; differing from ref {len(diff)} {diff}')
