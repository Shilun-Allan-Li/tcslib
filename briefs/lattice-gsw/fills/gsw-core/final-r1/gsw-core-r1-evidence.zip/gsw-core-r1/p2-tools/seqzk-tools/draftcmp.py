"""draftcmp.py <brief.md> <worktree> <file>...: for every `theorem`/`def` in the brief's ```lean blocks, the
delivered header (frozencheck.decls, head worktree) with whitespace normalized, compared with the draft
(normalized; a draft with `…` is compared only up to the `…`, and a draft ending in `:=` body compares the
header only). Prints MATCH / DIFF (with both) / MISSING."""
import sys, re, importlib.util
spec = importlib.util.spec_from_file_location('fc', __file__.replace('draftcmp.py', 'frozencheck_lib.py'))
brief, wt, files = sys.argv[1], sys.argv[2], sys.argv[3:]
src = open(brief, encoding='utf-8').read()
blocks = re.findall(r'```lean\n(.*?)```', src, re.S)
drafts = []
for b in blocks:
    b = '\n'.join(l for l in b.split('\n') if not l.lstrip().startswith('--'))
    for m in re.finditer(r'^(theorem|def)\s+(\S+)(.*?)(?=^(?:theorem|def|namespace)\s|\Z)', b, re.S | re.M):
        drafts.append((m.group(1), m.group(2), (m.group(1) + ' ' + m.group(2) + m.group(3))))
fc = importlib.util.module_from_spec(spec); spec.loader.exec_module(fc)
heads = {}
for f in files:
    for d in fc.decls(open(f'{wt}/{f}', encoding='utf-8').read()):
        heads.setdefault(d['name'].split('.')[-1], []).append((f, d))
norm = lambda s: re.sub(r'\s+', ' ', s).strip()
for kind, name, text in drafts:
    short = name.split('.')[-1]
    if short not in heads: print('MISSING', name); continue
    f, d = heads[short][0]
    h = d['header']; h = h[h.index(kind):] if kind in h else h
    dm = fc.code_mask(text); dt = text[:fc.header_end(text, dm, 0, len(text))]
    dn, hn = norm(dt), norm(h)
    if '…' in dn:
        pre = dn.split('…')[0].strip()
        post = dn.split('…', 1)[1].strip()
        post = post[1:].strip() if post.startswith(':') else post
        ok_post = (not post) or post.startswith('(the defining') or hn.endswith(post)
        st = ('MATCH-PREFIX+CONCL' if post and not post.startswith('(the') else 'MATCH-PREFIX') if hn.startswith(pre) and ok_post else 'DIFF'
    else:
        st = 'MATCH' if dn == hn else 'DIFF'
        # the brief abbreviates explicit binders as bare names (`m D`): compare with the delivered binder
        # names in place of their typed binders
        if st == 'DIFF' and re.search(r'\) (m|m D|D|m m\' D) :', dn):
            hb = re.sub(r'\((\w+(?: \w+\')?(?: \w+)?) : [^()]*(?:\([^()]*(?:\([^()]*\)[^()]*)*\)[^()]*)*\)', lambda x: x.group(1), hn)
            db = re.sub(r'\((\w+(?: \w+\')?(?: \w+)?) : [^()]*(?:\([^()]*(?:\([^()]*\)[^()]*)*\)[^()]*)*\)', lambda x: x.group(1), dn)
            st = 'MATCH-ELIDED' if hb == db else 'DIFF'
    print(f'{st}\t{d["name"]}\t{f.split("/")[-1]}:{d["line"]}')
    if st == 'DIFF': print('   draft:    ', dn); print('   delivered:', hn)
