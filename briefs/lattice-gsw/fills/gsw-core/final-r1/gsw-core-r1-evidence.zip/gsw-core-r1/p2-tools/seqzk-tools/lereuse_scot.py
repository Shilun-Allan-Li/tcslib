"""lereuse_scot.py <worktree>: the sc-ot landing edit LE-reuse (proof only). OT.pairSndD_nil' is the
public Complexity.BinArith.iterate_pairSndD_nil (ClassP/BinaryArith/Words.lean, already in the closure
of ObliviousTransfer/Efficiency.lean) at i = 1; the docstring's provenance parenthesis follows."""
import sys
wt = sys.argv[1]
F = 'TCSlib/Cryptography/SecureComputation/ObliviousTransfer/Efficiency.lean'
E = [("""`pairSndD [] = []`
(`length_pairSndD_le`). -/
theorem pairSndD_nil' : pairSndD ([] : List Bool) = [] :=
  List.eq_nil_of_length_eq_zero (Nat.le_zero.1 (length_pairSndD_le []))""",
      """`pairSndD [] = []`
(`BinArith.iterate_pairSndD_nil` at `1`). -/
theorem pairSndD_nil' : pairSndD ([] : List Bool) = [] :=
  BinArith.iterate_pairSndD_nil 1""")]
p = f'{wt}/{F}'; s = open(p, encoding='utf-8').read()
for a, b in E:
    assert s.count(a) == 1
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s)
print('LE-reuse applied')
