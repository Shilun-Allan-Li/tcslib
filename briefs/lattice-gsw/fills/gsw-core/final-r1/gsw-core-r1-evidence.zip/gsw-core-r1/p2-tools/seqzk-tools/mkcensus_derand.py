"""mkcensus_derand.py (derand review: mkcensus_canon.py with the derand endpoints: the three targets,
polyTimeComputable_find and its consumer polyTimeComputable_iterateFind on both sides, and on the head side
E1-E3, SR-01 inBPP_iff and the main helper results; extra imports via argv[5])
mkcensus_canon.py (canonizer review: mkcensus_scot.py with the canonizer endpoints: the target, exists_polyCanonizer,
computesFunInTime_appendBit, the four conditional headlines and on the head side the helper results and the two readers;
previously mkcensus_scot.py, sc-ot review: mkcensus_prflong.py with the sc-ot endpoints: the two targets, their consumers
otProtocol_hbcSecure and yaoProtocol_hbcSecure, and on the head side the main helper results; previously mkcensus_prflong.py, prf-long review: mkcensus_prfmac.py with the endpoints of the prf-long brief: the D1-D4 main results,
the re-derived n-bit results, and the five downstream consumers; previously mkcensus_prfmac.py, from the lamport review's copy)
mkcensus.py <side: head|base> <modules file> <namemap> <out.lean>: a census probe module.
For every stored constant whose home module is one of <modules>: normalized name (private prefix
stripped), home, kind, type hash after renaming every constant to its normalized name (and, on the
base side, through the name map old -> new), reducibility, simp, instance, protected, axioms.
Also #print axioms of the campaign endpoints."""
import sys, re
side, modsf, nmap, out = sys.argv[1:5]
mods = [l.strip().replace('/', '.') for l in open(modsf) if l.strip()]
pairs = []
for l in open(nmap):
    l = l.strip()
    if not l or l.startswith('#'): continue
    a, b = [x.strip() for x in l.split('->')]
    if a == '-' or a == b: continue
    a = re.sub(r'^_private\.[^ ]*?\.0\.', '', a)
    pairs.append((a, b))
D = 'TCSlib.Cryptography.Randomness.Derand.'
endpoints = ['Complexity.exists_seedMajorityTM', 'Complexity.seedMajority_mem_DTIME',
    'TCSlib.Cryptography.Randomness.bpp_subset_dtime_subexp',
    'Complexity.IterateFind.polyTimeComputable_find', 'Complexity.polyTimeComputable_iterateFind'] + ([
    'Complexity.IterateFind.computesFunInTime_find', 'Turing.FinTM.decidesInTime_iff',
    'Complexity.mem_DTIME_iff', 'Randomized.inBPP_iff', 'Complexity.SeedMajority.exists_countingTM',
    'Complexity.SeedMajority.envelope_of_computesInTime', D + 'exists_seed_majority',
    D + 'exists_coin_gap_threshold', D + 'exists_verifier_gap_bound', D + 'exists_secure_cover',
    D + 'seed_time_le_subexp', D + 'polyTimeComputable_ceilRoot', D + 'eff_mapCoins']
    if side == 'head' else [])  # derand review
extra = [l.strip() for l in open(sys.argv[5])] if len(sys.argv) > 5 else []  # extra imports (endpoint modules)
L = ['import Lean'] + [f'import {m}' for m in mods + [x for x in extra if x not in mods]] + ['',
     f'/-! derand review census probe ({side} side). -/', '', 'set_option maxHeartbeats 0',
     'set_option maxRecDepth 65536', '', 'open Lean Elab Command', '']
L += [f'#print axioms {e}' for e in endpoints] + ['']
L.append('def owners : List Name := [' + ',\n  '.join('`' + m for m in mods) + ']')
L.append('def nameMap : Std.HashMap String String := Std.HashMap.ofList [' +
         (',\n  '.join(f'("{a}", "{b}")' for a, b in pairs) if side == 'base' else '') + ']')
L.append(r'''
def normName (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

def abbrevOf : ConstantInfo → String
  | .defnInfo d => (match d.hints with | .abbrev => "abbrev" | _ => "-")
  | _ => "-"

def renameE (e : Expr) : Expr := e.replace fun x => match x with
  | .const n ls =>
    let s := normName n
    some (.const (Name.mkSimple ((nameMap[s]?).getD s)) ls)
  | _ => none

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let mut n := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless owners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    let abbr := abbrevOf ci
    IO.println s!"C\t{normName c}\t{c.isInternal || (Lean.privateToUserName? c).isSome}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{kindOf ci}\t{(renameE ci.type).hash}\t{red}\t{abbr}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{isProtected env c}\t{axs.toList}"
    n := n + 1
  IO.println s!"C-COUNT {n}"
''')
open(out, 'w').write('\n'.join(L) + '\n')
