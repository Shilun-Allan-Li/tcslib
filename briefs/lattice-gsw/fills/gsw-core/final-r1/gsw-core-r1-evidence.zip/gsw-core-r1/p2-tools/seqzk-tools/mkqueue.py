"""mkqueue.py <order.txt> <subset.txt> <out>: <order.txt> (imports-first) restricted to <subset.txt>."""
import sys
o = [l.strip() for l in open(sys.argv[1]) if l.strip()]; s = {l.strip() for l in open(sys.argv[2]) if l.strip()}
q = [m for m in o if m in s]; assert set(q) == s, s - set(q)
open(sys.argv[3], 'w').write(''.join(m + '\n' for m in q)); print(len(q))
