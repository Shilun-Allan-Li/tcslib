"""mancheck.py <dir> <manifest relative to dir> [exclude-self]: verify a `<sha256>  <path>` manifest
against the files under <dir> with exact path-set equality (paths relative to <dir>, no './').
If exclude-self is given, the manifest file itself is excluded from the delivered set. Prints
OK/BAD/MISSING/EXTRA lines and a RESULT line."""
import sys, os, hashlib
d, man = sys.argv[1], sys.argv[2]
excl = len(sys.argv) > 3
mp = os.path.join(d, man); base = os.path.dirname(mp)
ent = {}
for l in open(mp, encoding='utf-8'):
    l = l.rstrip('\n')
    if not l: continue
    h, p = l.split('  ', 1)
    p = p[2:] if p.startswith('./') else p
    if p in ent: print('DUP', p)
    ent[p] = h
have = set()
for r, ds, fs in os.walk(base):
    for f in fs:
        have.add(os.path.relpath(os.path.join(r, f), base))
if excl: have.discard(os.path.basename(man))
ok = bad = 0
for p, h in sorted(ent.items()):
    fp = os.path.join(base, p)
    if not os.path.isfile(fp): print('MISSING', p); bad += 1; continue
    if hashlib.sha256(open(fp, 'rb').read()).hexdigest() == h: ok += 1
    else: print('BAD', p); bad += 1
extra = sorted(have - set(ent))
for p in extra: print('EXTRA', p)
print(f'manifest {man}: entries {len(ent)} delivered {len(have)} ok {ok} bad/missing {bad} extra {len(extra)}')
print('RESULT', 'OK' if bad == 0 and not extra else 'FAIL')
