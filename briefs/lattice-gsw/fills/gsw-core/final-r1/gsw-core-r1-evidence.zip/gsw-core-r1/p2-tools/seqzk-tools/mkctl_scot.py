"""mkctl_scot.py (sc-ot review): mkctl_learning.py with sc-ot rows (PolyExpr.eval, the FinDist CoeFun
instance, NUPPT.layout, Strategy.encodeMsgs, otFunctionality, and the helper definitions OT.mask, OT.simSeg, OT.inA2,
OT.bobView, OT.hcBit, foreign to the later helpers and the owned file; each negative the rfl unfolding, each positive
its published reader) and namespace ScOtControls. Previously: mkctl_learning.py (learning-r1 review): mkctl_lamport.py with learning rows (PolyExpr.eval, FinDist.uniform, the FinDist
CoeFun instance, PAC.label, uprob, acceptProb, and the helper definitions LearnPRF.firstBit, tupleWord, learnerFn,
foreign to the later helpers and the owned file) and namespace LearningControls. Previously: mkctl_lamport.py (lamport review): mkctl_dlcrh.py with lamport rows (padFin, PolyExpr.eval, ProbComp.expect, ProbComp.sample, OracleComp.bind (the three names of the patch-4 opacity block), LamportFill.secretWord, LamportFill.signatureBlock, LamportMachine.u). Previously: mkctl_dlcrh.py (dl-crh review): mkctl_extnosrc.py with dl-crh rows (padFin, PolyExpr.eval, Authentication.splitBits, Candidates.expSampleRaw (new reader expSampleRaw_eq), FromDiscreteLog.modularDifference, FromDiscreteLog.residueFinEquiv). Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
FD = 'TCSlib.InformationTheory.FinDist'
SC = 'TCSlib.Cryptography.SecureComputation'
PE = 'Turing.pairEncode'
TC = 'TCSlib.Cryptography.TrapdoorCollection'
NU = 'Complexity.NUPPT'
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
MASKR = (f"{SC}.OT.mask T H n i t yj a =\n    List.zipWith xor (H ({PE} i (T.inv.runAtL n ({PE} t yj)\n"
         f"      (List.replicate (T.inv.coins.eval n) true)))) [a]")
BOBR = (f"{SC}.OT.bobView H u b a₀ a₁ i s w β =\n    {PE} ({PE} ({PE} u [b]) ({PE} s ({PE} i ({PE}\n"
        f"      (if b then {PE} [xor β a₀] (List.zipWith xor (H ({PE} i w)) [a₁])\n"
        f"        else {PE} (List.zipWith xor (H ({PE} i w)) [a₀]) [xor β a₁])\n      ({PE} [] []))))) []")
HCR = (f"{SC}.OT.hcBit T h n r s = h (T.index n r) ((T.perm (T.index n r)).symm\n"
       f"      ((T.decD (T.index n r) (T.sample.runAt n (T.index n r) s)).getD default))")
SEGR = (f"{SC}.OT.simSeg p q z =\n    (({NU}.inCoins z).drop (p.eval ({NU}.inParam z).length)).take\n"
        f"      (q.eval ({NU}.inParam z).length)")
B = {
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 FD + '.instCoeFunForallReal': row("ctlCoe",
   f"theorem ctlCoe {{α : Type}} [Fintype α] (p : {FD} α) (a : α) : p a = p.prob a := rfl\n",
   f"theorem ctlCoeReader {{α : Type}} [Fintype α] (f : α → ℝ) (h₁ : ∀ a, 0 ≤ f a) (h₂ : ∑ a, f a = 1) (a : α) :\n    (⟨f, h₁, h₂⟩ : {FD} α) a = f a := {FD}.coe_mk f h₁ h₂ a\n"),
 NU + '.layout': row("ctlLayout",
   f"theorem ctlLayout (u y α r : List Bool) :\n    {NU}.layout u y α r = {PE} ({PE} ({PE} u y) α) r := rfl\n",
   f"theorem ctlLayoutReader (u y α r : List Bool) :\n    {NU}.layout u y α r = {PE} ({PE} ({PE} u y) α) r := {NU}.layout_eq u y α r\n"),
 'TCSlib.Cryptography.Strategy.encodeMsgs': row("ctlEncodeMsgs",
   "theorem ctlEncodeMsgs : TCSlib.Cryptography.Strategy.encodeMsgs [] = [] := rfl\n",
   "theorem ctlEncodeMsgsReader : TCSlib.Cryptography.Strategy.encodeMsgs [] = [] :=\n  TCSlib.Cryptography.Strategy.encodeMsgs_nil\n"),
 SC + '.otFunctionality': row("ctlOtFun",
   f"theorem ctlOtFun : {SC}.otFunctionality.inA = .const 2 := rfl\n",
   f"theorem ctlOtFunReader : {SC}.otFunctionality.inA = .const 2 := {SC}.otFunctionality_inA\n"),
 SC + '.OT.mask': row("ctlMask",
   f"theorem ctlMask (T : {TC}) (H : List Bool → List Bool) (n : ℕ) (i t yj : List Bool) (a : Bool) :\n    {MASKR} := rfl\n",
   f"theorem ctlMaskReader (T : {TC}) (H : List Bool → List Bool) (n : ℕ) (i t yj : List Bool)\n    (a : Bool) :\n    {MASKR} :=\n  {SC}.OT.mask_eq T H n i t yj a\n"),
 SC + '.OT.simSeg': row("ctlSimSeg",
   f"theorem ctlSimSeg (p q : Complexity.PolyExpr) (z : List Bool) :\n    {SEGR} := rfl\n",
   f"theorem ctlSimSegReader (p q : Complexity.PolyExpr) (z : List Bool) :\n    {SEGR} :=\n  {SC}.OT.simSeg_eq p q z\n"),
 SC + '.OT.inA2': row("ctlInA2",
   f"theorem ctlInA2 {{n : ℕ}} (a : Fin ({SC}.otFunctionality.inA.eval n) → Bool) (j : Fin 2) :\n    {SC}.OT.inA2 a j = a (Fin.cast ({SC}.OT.inA_eval n).symm j) := rfl\n",
   f"theorem ctlInA2Reader {{n : ℕ}} (a : Fin ({SC}.otFunctionality.inA.eval n) → Bool) (j : Fin 2) :\n    {SC}.OT.inA2 a j = a (Fin.cast ({SC}.OT.inA_eval n).symm j) := {SC}.OT.inA2_apply a j\n"),
 SC + '.OT.bobView': row("ctlBobView",
   f"theorem ctlBobView (H : List Bool → List Bool) (u : List Bool) (b a₀ a₁ : Bool) (i s w : List Bool)\n    (β : Bool) :\n    {BOBR} := rfl\n",
   f"theorem ctlBobViewReader (H : List Bool → List Bool) (u : List Bool) (b a₀ a₁ : Bool)\n    (i s w : List Bool) (β : Bool) :\n    {BOBR} :=\n  {SC}.OT.bobView_eq H u b a₀ a₁ i s w β\n"),
 SC + '.OT.hcBit': row("ctlHcBit",
   f"theorem ctlHcBit (T : {TC}) (h : ∀ i, T.D i → Bool) (n : ℕ) (r : T.gen.Coins n)\n    (s : T.sample.Coins n) :\n    {HCR} := rfl\n",
   f"theorem ctlHcBitReader (T : {TC}) (h : ∀ i, T.D i → Bool) (n : ℕ) (r : T.gen.Coins n)\n    (s : T.sample.Coins n) :\n    {HCR} :=\n  {SC}.OT.hcBit_eq T h n r s\n"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace ScOtControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end ScOtControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
