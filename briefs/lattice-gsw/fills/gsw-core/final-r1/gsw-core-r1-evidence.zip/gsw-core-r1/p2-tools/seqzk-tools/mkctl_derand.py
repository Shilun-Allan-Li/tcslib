"""mkctl_derand.py (derand review): mkctl_canon.py with derand rows (PolyExpr.eval, the FinDist CoeFun instance,
Complexity.DTIME / mem_DTIME_iff (E2), Turing.FinTM.DecidesInTime / decidesInTime_iff (E3), Randomized.InBPP / inBPP_iff (SR-01),
Turing.ModuleHost.hostTM / the simps reader hostTM_k (the field E1 reads), and the helper definitions SeedMajority.word and
Derand.ceilRoot with their _eq readers) and namespace DerandControls. Previously:
mkctl_canon.py (canonizer review): mkctl_scot.py with canonizer rows (PolyExpr.eval, the FinDist CoeFun instance,
Turing.unaryFin, Turing.oneTapeFormat and Turing.oneTapeMachineFormat with the two pre-approved readers as positives) and
namespace DerandControls. Previously: mkctl_scot.py (sc-ot review): mkctl_learning.py with sc-ot rows (PolyExpr.eval, the FinDist CoeFun
instance, NUPPT.layout, Strategy.encodeMsgs, otFunctionality, and the helper definitions OT.mask, OT.simSeg, OT.inA2,
OT.bobView, OT.hcBit, foreign to the later helpers and the owned file; each negative the rfl unfolding, each positive
its published reader) and namespace ScOtControls. Previously: mkctl_learning.py (learning-r1 review): mkctl_lamport.py with learning rows (PolyExpr.eval, FinDist.uniform, the FinDist
CoeFun instance, PAC.label, uprob, acceptProb, and the helper definitions LearnPRF.firstBit, tupleWord, learnerFn,
foreign to the later helpers and the owned file) and namespace LearningControls. Previously: mkctl_lamport.py (lamport review): mkctl_dlcrh.py with lamport rows (padFin, PolyExpr.eval, ProbComp.expect, ProbComp.sample, OracleComp.bind (the three names of the patch-4 opacity block), LamportFill.secretWord, LamportFill.signatureBlock, LamportMachine.u). Previously: mkctl_dlcrh.py (dl-crh review): mkctl_extnosrc.py with dl-crh rows (padFin, PolyExpr.eval, Authentication.splitBits, Candidates.expSampleRaw (new reader expSampleRaw_eq), FromDiscreteLog.modularDifference, FromDiscreteLog.residueFinEquiv). Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
FD = 'TCSlib.InformationTheory.FinDist'
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
B = {
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 FD + '.instCoeFunForallReal': row("ctlCoe",
   f"theorem ctlCoe {{α : Type}} [Fintype α] (p : {FD} α) (a : α) : p a = p.prob a := rfl\n",
   f"theorem ctlCoeReader {{α : Type}} [Fintype α] (f : α → ℝ) (h₁ : ∀ a, 0 ≤ f a) (h₂ : ∑ a, f a = 1) (a : α) :\n    (⟨f, h₁, h₂⟩ : {FD} α) a = f a := {FD}.coe_mk f h₁ h₂ a\n"),
 'Complexity.DTIME': row("ctlDTIME",
   "theorem ctlDTIME {T : ℕ → ℕ} {L : Language Bool} :\n    L ∈ Complexity.DTIME T ↔ ∃ (c : ℕ) (M : Turing.FinTM Bool), M.DecidesInTime L fun n => c * T n :=\n  Iff.rfl\n",
   "theorem ctlDTIMEReader {T : ℕ → ℕ} {L : Language Bool} :\n    L ∈ Complexity.DTIME T ↔ ∃ (c : ℕ) (M : Turing.FinTM Bool), M.DecidesInTime L fun n => c * T n :=\n  Complexity.mem_DTIME_iff\n"),
 'Turing.FinTM.DecidesInTime': row("ctlDecides",
   "theorem ctlDecides (M : Turing.FinTM Bool) (L : Language Bool) (T : ℕ → ℕ) :\n    M.DecidesInTime L T ↔ ∀ x : List Bool,\n      M.ComputesInTime x [Turing.MultiTapeTM.indicator (L : Set (List Bool)) x] (T x.length) :=\n  Iff.rfl\n",
   "theorem ctlDecidesReader (M : Turing.FinTM Bool) (L : Language Bool) (T : ℕ → ℕ) :\n    M.DecidesInTime L T ↔ ∀ x : List Bool,\n      M.ComputesInTime x [Turing.MultiTapeTM.indicator (L : Set (List Bool)) x] (T x.length) :=\n  Turing.FinTM.decidesInTime_iff M L T\n"),
 'Randomized.InBPP': row("ctlInBPP",
   "theorem ctlInBPP (E : Randomized.VerifierModel) (L : Language Bool) :\n    Randomized.InBPP E L ↔ ∃ (M : List Bool → List Bool → Bool) (a k : ℕ),\n      E.Eff (Randomized.boolVerifier M) ∧ ∀ x : List Bool,\n        (x ∈ L → 2/3 ≤ Randomized.randProb (Randomized.polyLen a k x.length) fun r => M x r = true) ∧\n        (x ∉ L → 2/3 ≤ Randomized.randProb (Randomized.polyLen a k x.length) fun r => M x r = false) :=\n  Iff.rfl\n",
   "theorem ctlInBPPReader (E : Randomized.VerifierModel) (L : Language Bool) :\n    Randomized.InBPP E L ↔ ∃ (M : List Bool → List Bool → Bool) (a k : ℕ),\n      E.Eff (Randomized.boolVerifier M) ∧ ∀ x : List Bool,\n        (x ∈ L → 2/3 ≤ Randomized.randProb (Randomized.polyLen a k x.length) fun r => M x r = true) ∧\n        (x ∉ L → 2/3 ≤ Randomized.randProb (Randomized.polyLen a k x.length) fun r => M x r = false) :=\n  Randomized.inBPP_iff E L\n"),
 'Turing.ModuleHost.hostTM': row("ctlHostK",
   "theorem ctlHostK {C : Type} [Fintype C] [DecidableEq C] {n : ℕ} (M : Fin n → Turing.FinTM Bool) (K : ℕ)\n    (hk : ∀ i, (M i).k ≤ K)\n    (ctrl : C → Option Bool → (Fin K → Option Bool) → Turing.Action K Bool (Turing.ModuleHost.State C M))\n    (ret : Fin n → Turing.ModuleHost.State C M) (q₀ : Turing.ModuleHost.State C M) :\n    (Turing.ModuleHost.hostTM M K hk ctrl ret q₀).k = K := rfl\n",
   "theorem ctlHostKReader {C : Type} [Fintype C] [DecidableEq C] {n : ℕ} (M : Fin n → Turing.FinTM Bool) (K : ℕ)\n    (hk : ∀ i, (M i).k ≤ K)\n    (ctrl : C → Option Bool → (Fin K → Option Bool) → Turing.Action K Bool (Turing.ModuleHost.State C M))\n    (ret : Fin n → Turing.ModuleHost.State C M) (q₀ : Turing.ModuleHost.State C M) :\n    (Turing.ModuleHost.hostTM M K hk ctrl ret q₀).k = K := by\n  rw [Turing.ModuleHost.hostTM_k]\n"),
 'Complexity.SeedMajority.word': row("ctlWord",
   "theorem ctlWord (m i : ℕ) : Complexity.SeedMajority.word m i = (Nat.bits i ++ Nat.bits (2 ^ m)).take m := rfl\n",
   "theorem ctlWordReader (m i : ℕ) : Complexity.SeedMajority.word m i = (Nat.bits i ++ Nat.bits (2 ^ m)).take m :=\n  Complexity.SeedMajority.word_eq m i\n"),
 'TCSlib.Cryptography.Randomness.Derand.ceilRoot': row("ctlCeilRoot",
   "theorem ctlCeilRoot (d n : ℕ) :\n    TCSlib.Cryptography.Randomness.Derand.ceilRoot d n = if n = 0 then 0 else Nat.nthRoot d (n - 1) + 1 := rfl\n",
   "theorem ctlCeilRootReader (d n : ℕ) :\n    TCSlib.Cryptography.Randomness.Derand.ceilRoot d n = if n = 0 then 0 else Nat.nthRoot d (n - 1) + 1 :=\n  TCSlib.Cryptography.Randomness.Derand.ceilRoot_eq d n\n"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace DerandControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end DerandControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
