"""legate34.py <file>: (LE-gate34, G34-01) re-derive OT.getD_zero_eq and OT.getD_one_eq' from the public
TCSlib.Cryptography.headD_drop (proof bodies only; the headers up to `:=` are untouched) and insert one sentence naming
headD_drop into each docstring (pure insertions before the closing `-/`). Each replacement must match exactly once."""
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
R = [
 ("/-- `y.getD 0 false` is the head bit: `y.getD 0 false = y.headD false`. -/\n"
  "theorem getD_zero_eq (y : List Bool) : y.getD 0 false = y.headD false := by\n"
  "  cases y <;> rfl\n",
  "/-- `y.getD 0 false` is the head bit: `y.getD 0 false = y.headD false`.\n"
  "It is the public `TCSlib.Cryptography.headD_drop` at `i = 0`, reversed. -/\n"
  "theorem getD_zero_eq (y : List Bool) : y.getD 0 false = y.headD false := by\n"
  "  simpa only [List.drop_zero] using\n"
  "    (TCSlib.Cryptography.headD_drop y 0 false).symm\n"),
 ("`y.getD 1 false = (y.drop 1).headD false`. -/\n"
  "theorem getD_one_eq' (y : List Bool) : y.getD 1 false = (y.drop 1).headD false := by\n"
  "  rcases y with _ | ⟨a, _ | ⟨b, t⟩⟩ <;> rfl\n",
  "`y.getD 1 false = (y.drop 1).headD false`.\n"
  "It is the public `TCSlib.Cryptography.headD_drop` at `i = 1`, reversed. -/\n"
  "theorem getD_one_eq' (y : List Bool) : y.getD 1 false = (y.drop 1).headD false :=\n"
  "  (TCSlib.Cryptography.headD_drop y 1 false).symm\n"),
]
for a, b in R:
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s); print('applied', len(R))
