"""widths.py <worktree> <file>...: line count, max width (Python len, no newline) and every line over
100 characters of each file."""
import sys, os
wt = sys.argv[1]; over_total = 0
for f in sys.argv[2:]:
    ls = open(os.path.join(wt, f), encoding='utf-8').read().split('\n')
    if ls and ls[-1] == '': ls = ls[:-1]
    over = [(i + 1, len(l)) for i, l in enumerate(ls) if len(l) > 100]
    over_total += len(over)
    print(f'{f}\tlines {len(ls)}\tmax {max(map(len, ls))}\tover100 {len(over)}\t{"FILE>=1000" if len(ls) >= 1000 else ""}')
    for i, n in over: print(f'  {f}:{i}\t{n}')
print('RESULT', 'OK' if over_total == 0 else f'{over_total} over-width lines')
