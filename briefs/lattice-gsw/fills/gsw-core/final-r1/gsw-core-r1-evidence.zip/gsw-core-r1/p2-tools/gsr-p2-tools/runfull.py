r"""runfull.py <worktree> <order> <tree> <logdir> (gate34-le): runner.py's record format, but each probe module
<m> (a .lean file under <worktree>) is run with tools/probefull.sh (lean -DmaxErrors=0, no -o: nothing is written to
<tree>), one Lean process at a time. Errors counted in both forms (G26-N1); rc is the `lean rc=` line."""
import sys, os, json, time, hashlib, subprocess, datetime, re
wt, order, tree, logdir = sys.argv[1:5]
here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(logdir, 'mods'), exist_ok=True)
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
res = open(os.path.join(logdir, 'results.jsonl'), 'a')
for m in [l.strip() for l in open(order) if l.strip()]:
    lp = os.path.join(logdir, 'mods', m.replace('/', '_') + '.log'); t0 = time.time(); s0 = now()
    with open(lp, 'wb') as out:
        p = subprocess.Popen(['nice', '-n', '10', 'bash', os.path.join(here, 'probefull.sh'), tree, m + '.lean', wt],
                             stdout=out, stderr=subprocess.STDOUT)
        with open(os.path.join(logdir, 'current.pid'), 'w') as f: f.write(f'{p.pid} {m}\n')
        _, status, ru = os.wait4(p.pid, 0)
    txt = open(lp, encoding='utf-8', errors='replace').read()
    mm = re.findall(r'^lean rc=(\d+)$', txt, re.M); rc = int(mm[-1]) if mm else -1
    res.write(json.dumps(dict(module=m, rc=rc, errors=len(re.findall(r'^\S+\.lean:\d+:\d+: error[:(]', txt, re.M)),
              error_substr=txt.count('error'), warnings=len(re.findall(r'warning:', txt)), start=s0, end=now(),
              seconds=round(time.time() - t0, 2), maxrss_kb=ru.ru_maxrss, source_sha256=sha(os.path.join(wt, m + '.lean')),
              log_sha256=sha(lp))) + '\n'); res.flush()
res.write(json.dumps(dict(done=now(), order=order)) + '\n')
