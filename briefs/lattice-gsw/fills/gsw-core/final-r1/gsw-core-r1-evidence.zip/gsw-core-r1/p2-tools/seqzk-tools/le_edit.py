"""le_edit.py <worktree> <tag>: the prf-long landing edits, as exact unique replacements.
LE-doc: formulas in three docstrings of FromPRF/ReductionMachine.lean (postOffsetOut, postQueryOut,
polyTimeComputable_postFunOut). LE-ws: restore the blank line after prfEncReal_apply in FromPRF/Hybrid.lean."""
import sys
wt, tag = sys.argv[1:3]
RM = 'TCSlib/Cryptography/Encryption/PrivateKey/FromPRF/ReductionMachine.lean'
HY = 'TCSlib/Cryptography/Encryption/PrivateKey/FromPRF/Hybrid.lean'
EDITS = {'doc': [
 (RM, """/-- The unary offset `1^{k·n}` of the next point at answer width `ℓ(n)`: the block map emitting
`1^{|x|}` for the query `x` of each block of length `histBlockLenOut ℓ`. -/""",
      """/-- The unary offset `1^{k·n}` of the next point at answer width `ℓ(n)`: the block map emitting
`1^{|x|}` for the query `x` of each block of length `histBlockLenOut ℓ`,
`postOffsetOut ℓ z = blockMapFun (histBlockLenOut ℓ) (fun blk => 1^{|fst (fst blk)|})
⟨inParam z, postHist z⟩`. -/"""),
 (RM, """/-- The query move `⟨[false], ρ_k⟩` at answer width `ℓ(n)`: the `n`-bit block of the points
after the first `k·n` (`postOffsetOut ℓ`). -/""",
      """/-- The query move `⟨[false], ρ_k⟩` at answer width `ℓ(n)`: the `n`-bit block of the points
after the first `k·n` (`postOffsetOut ℓ`), `postQueryOut ℓ z = ⟨[false], takePolyFun var
⟨inParam z, dropPolyFun var ⟨postOffsetOut ℓ z, postPoints z⟩⟩⟩`. -/"""),
 (RM, """/-- `postFunOut ℓ` is polynomial-time.

**Proof sketch.** As `polyTimeComputable_postFun`""",
      """/-- `postFunOut ℓ` is polynomial-time: `PolyTimeComputable (postFunOut ℓ)`.

**Proof sketch.** As `polyTimeComputable_postFun`"""),
], 'ws': [
 (HY, """  exact prfEncRealOut_apply F m z j
/-- The ciphertext tuple""", """  exact prfEncRealOut_apply F m z j

/-- The ciphertext tuple"""),
]}
for f, a, b in EDITS[tag]:
    p = f'{wt}/{f}'; s = open(p, encoding='utf-8').read()
    assert s.count(a) == 1, (f, a[:40])
    open(p, 'w', encoding='utf-8').write(s.replace(a, b))
    print('EDIT', tag, f, 'ok')
