"""topcmds.py <repo> <base> <head> <file>...: column-0 lines starting with set_option/open/variable/namespace/
section/end/attribute/import/noncomputable section/universe at base and head; reports base lines missing at head
(multiset) and head lines added. In-proof `set_option ... in` lines are indented and not counted."""
import sys, subprocess, collections, re
repo, b, h = sys.argv[1:4]
P = re.compile(r'^(set_option|open|variable|namespace|section|end|attribute|import|noncomputable section|universe)\b')
def show(rev, f):
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{f}'], capture_output=True)
    return r.stdout.decode() if r.returncode == 0 else ''
tot = 0
for f in sys.argv[4:]:
    cb = collections.Counter(l for l in show(b, f).split('\n') if P.match(l))
    ch = collections.Counter(l for l in show(h, f).split('\n') if P.match(l))
    miss = cb - ch; add = ch - cb
    print(f'{f}\tbase {sum(cb.values())}\thead {sum(ch.values())}\tmissing {dict(miss)}\tadded {dict(add)}')
    tot += sum(miss.values())
print('RESULT base top-level commands missing at head:', tot)
