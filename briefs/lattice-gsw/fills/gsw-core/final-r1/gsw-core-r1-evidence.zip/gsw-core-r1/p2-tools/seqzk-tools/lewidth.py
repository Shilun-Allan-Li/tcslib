R = {
'Experiment.lean': [
("        ProbComp.expect (ProbComp.sample ρ) fun r => if RedSuccess g adv (g x) T r p then 1 else 0) :=",
 "        ProbComp.expect (ProbComp.sample ρ) fun r =>\n          if RedSuccess g adv (g x) T r p then 1 else 0) :="),
],
'Machine.lean': [
("  TCSlib.Cryptography.takeLen_poly u_poly (TCSlib.Cryptography.dropLen_poly (offset_poly _) tape_poly)",
 "  TCSlib.Cryptography.takeLen_poly u_poly\n    (TCSlib.Cryptography.dropLen_poly (offset_poly _) tape_poly)"),
#REVERTED ("  ((tape v).drop ((offset (.mul (.const 2) .var) v).length + (u v).length)).take (u v).length\n",
 "  ((tape v).drop ((offset (.mul (.const 2) .var) v).length +\n    (u v).length)).take (u v).length\n"),
("    ((tape v).drop ((offset (.mul (.const 2) .var) v).length + (u v).length)).take (u v).length := rfl",
 "    ((tape v).drop ((offset (.mul (.const 2) .var) v).length +\n      (u v).length)).take (u v).length := rfl"),
("  refine (((TCSlib.Cryptography.takeLen_poly (offset_poly W) (honestPk_poly hG)).append (replacement_poly hE)).append\n    (TCSlib.Cryptography.dropLen_poly ((offset_poly W).append (width_poly W)) (honestPk_poly hG))).congr ?_",
 "  refine (((TCSlib.Cryptography.takeLen_poly (offset_poly W) (honestPk_poly hG)).append\n      (replacement_poly hE)).append\n    (TCSlib.Cryptography.dropLen_poly ((offset_poly W).append (width_poly W))\n      (honestPk_poly hG))).congr ?_"),
("  have hq := polyTimeComputable_headD.comp (TCSlib.Cryptography.dropLen_poly (pos_poly.comp context_poly) message_poly)",
 "  have hq := polyTimeComputable_headD.comp\n    (TCSlib.Cryptography.dropLen_poly (pos_poly.comp context_poly) message_poly)"),
],
'MachineSpec.lean': [
("  have hrow := hcoin (B := 2 * n) (fun j : Fin n => List.ofFn (T (j, false)) ++ List.ofFn (T (j, true)))",
 "  have hrow := hcoin (B := 2 * n)\n    (fun j : Fin n => List.ofFn (T (j, false)) ++ List.ofFn (T (j, true)))", 2),
("  simp only [LamportMachine.context_eq, pairFstD_pairEncode, pairSndD_pairEncode, List.headD_cons, Bool.false_eq_true,",
 "  simp only [LamportMachine.context_eq, pairFstD_pairEncode, pairSndD_pairEncode, List.headD_cons,\n    Bool.false_eq_true,"),
],
'Realization.lean': [
("          hm, if_false, decide_false, Bool.false_or, OracleComp.pure_bind, ha, simulate_pure] using habort)",
 "          hm, if_false, decide_false, Bool.false_or, OracleComp.pure_bind, ha, simulate_pure]\n          using habort)"),
],
}
for f, reps in R.items():
    s = open(f, encoding='utf-8').read()
    for r in reps:
        old, new = r[0], r[1]; cnt = r[2] if len(r) > 2 else 1
        assert s.count(old) == cnt, (f, old[:40], s.count(old))
        s = s.replace(old, new)
    open(f, 'w', encoding='utf-8').write(s)
print('ok')
