"""sizewidth.py <worktree> <file>...: line count and lines over 100 characters (Python len) per file."""
import sys
wt = sys.argv[1]
for f in sys.argv[2:]:
    ls = open(f'{wt}/{f}', encoding='utf-8').read().split('\n')
    if ls and ls[-1] == '': ls = ls[:-1]
    over = [(i + 1, len(l)) for i, l in enumerate(ls) if len(l) > 100]
    print(f'{f}\tlines {len(ls)}\tmax-width {max(map(len, ls))}\tover-100 {len(over)} {over}')
