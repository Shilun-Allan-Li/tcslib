"""mkctl_prfmac.py (prf-mac review): mkctl_lamport.py with prf-mac rows (padFin, PolyExpr.eval, ProbComp.expect, InteractiveHandler.rAns, NMSim.chunkMap, ETTGame.ovr, MAC.forgerCodec, PRFMAC.fnImpl, FnForge, queried, macBudget, blocks, macHandler). Previously: mkctl_lamport.py (lamport review): mkctl_dlcrh.py with lamport rows (padFin, PolyExpr.eval, ProbComp.expect, ProbComp.sample, OracleComp.bind (the three names of the patch-4 opacity block), LamportFill.secretWord, LamportFill.signatureBlock, LamportMachine.u). Previously: mkctl_dlcrh.py (dl-crh review): mkctl_extnosrc.py with dl-crh rows (padFin, PolyExpr.eval, Authentication.splitBits, Candidates.expSampleRaw (new reader expSampleRaw_eq), FromDiscreteLog.modularDifference, FromDiscreteLog.residueFinEquiv). Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
G = 'TCSlib.Cryptography.Games'
IH = G + '.InteractiveHandler'
NMS = 'TCSlib.Cryptography.Composability.NMSim'
ETT = 'TCSlib.Cryptography.Composability.ETTGame'
AU = 'TCSlib.Cryptography.Authentication'
PM = AU + '.PRFMAC'
BS = f"({G}.bitSpec (fun _ : Fin 1 => a) (fun _ => b))"
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
B = {
 'TCSlib.Cryptography.padFin': row("ctlPadFin",
   "theorem ctlPadFin (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := rfl\n",
   "theorem ctlPadFinReader (l : ℕ) (w : List Bool) (i : Fin l) :\n    TCSlib.Cryptography.padFin l w i = w.getD i false := TCSlib.Cryptography.padFin_apply l w i\n"),
 'Complexity.PolyExpr.eval': row("ctlEval",
   "theorem ctlEval (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 := rfl\n",
   "theorem ctlEvalReader (n : ℕ) : (Complexity.PolyExpr.const 2).eval n = 2 :=\n  Complexity.PolyExpr.eval_const 2 n\n"),
 G + '.ProbComp.expect': row("ctlExpect",
   f"theorem ctlExpect (a : Bool) (g : Bool → ℝ) :\n    {G}.ProbComp.expect (.pure a) g = g a := rfl\n",
   f"theorem ctlExpectReader (a : Bool) (g : Bool → ℝ) :\n    {G}.ProbComp.expect (.pure a) g = g a := {G}.ProbComp.expect_pure a g\n"),
 IH + '.rAns': row("ctlRAns",
   f"theorem ctlRAns (w : List Bool) : {IH}.rAns w =\n    Complexity.pairSndD (Complexity.pairSndD (Complexity.pairFstD ({IH}.rL w))) := rfl\n",
   f"theorem ctlRAnsReader (w : List Bool) : {IH}.rAns w =\n    Complexity.pairSndD (Complexity.pairSndD (Complexity.pairFstD ({IH}.rL w))) := {IH}.rAns_eq w\n"),
 NMS + '.chunkMap': row("ctlChunkMap",
   f"theorem ctlChunkMap (c : Complexity.PolyExpr) (f : List Bool → List Bool → List Bool) (x : List Bool) :\n    {NMS}.chunkMap c f x = (List.range (x.length + 1)).flatMap\n      fun i => {NMS}.chunkEmit c f (({NMS}.chunkStep c)^[i] x) := rfl\n",
   f"theorem ctlChunkMapReader (c : Complexity.PolyExpr) (f : List Bool → List Bool → List Bool) (x : List Bool) :\n    {NMS}.chunkMap c f x = (List.range (x.length + 1)).flatMap\n      fun i => {NMS}.chunkEmit c f (({NMS}.chunkStep c)^[i] x) :=\n  {NMS}.chunkMap_eq c f x\n"),
 ETT + '.ovr': row("ctlOvr",
   f"theorem ctlOvr (R : Bool → Bool) : {ETT}.ovr ([] : List (Bool × Bool)) R = R := rfl\n",
   f"theorem ctlOvrReader (R : Bool → Bool) : {ETT}.ovr ([] : List (Bool × Bool)) R = R :=\n  {ETT}.ovr_nil R\n"),
 AU + '.MAC.forgerCodec': row("ctlForgerCodec",
   f"theorem ctlForgerCodec (M : {AU}.MAC) (n : ℕ) :\n    (M.forgerCodec n).timeout = {G}.zeroBits (M.msgLen.eval n + M.tagLen.eval n) := rfl\n",
   f"theorem ctlForgerCodecReader (M : {AU}.MAC) (n : ℕ) :\n    (M.forgerCodec n).timeout = {G}.zeroBits (M.msgLen.eval n + M.tagLen.eval n) :=\n  M.forgerCodec_timeout n\n"),
 PM + '.fnImpl': row("ctlFnImpl",
   f"theorem ctlFnImpl {{a b : ℕ}} (f : (Fin a → Bool) → (Fin b → Bool)) :\n    {PM}.fnImpl f = {G}.QueryImpl.ofComp fun _ m => .pure (f m) := rfl\n",
   f"theorem ctlFnImplReader {{a b : ℕ}} (f : (Fin a → Bool) → (Fin b → Bool)) :\n    {PM}.fnImpl f = {G}.QueryImpl.ofComp fun _ m => .pure (f m) := {PM}.fnImpl_eq f\n"),
 PM + '.FnForge': row("ctlFnForge",
   f"theorem ctlFnForge {{a b : ℕ}} (f : (Fin a → Bool) → (Fin b → Bool)) (w : Fin (a + b) → Bool)\n    (log : {G}.QueryLog {BS}) :\n    {PM}.FnForge f w log ↔ f ({AU}.splitBits w).1 = ({AU}.splitBits w).2 ∧\n      ∀ e ∈ log, e.2.1 ≠ ({AU}.splitBits w).1 := Iff.rfl\n",
   f"theorem ctlFnForgeReader {{a b : ℕ}} (f : (Fin a → Bool) → (Fin b → Bool)) (w : Fin (a + b) → Bool)\n    (log : {G}.QueryLog {BS}) :\n    {PM}.FnForge f w log ↔ f ({AU}.splitBits w).1 = ({AU}.splitBits w).2 ∧\n      ∀ e ∈ log, e.2.1 ≠ ({AU}.splitBits w).1 := {PM}.fnForge_iff f w log\n"),
 PM + '.queried': row("ctlQueried",
   f"theorem ctlQueried {{a b : ℕ}} (log : {G}.QueryLog {BS}) :\n    {PM}.queried log = (log.map fun e => e.2.1).reverse := rfl\n",
   f"theorem ctlQueriedReader {{a b : ℕ}} (log : {G}.QueryLog {BS}) :\n    {PM}.queried log = (log.map fun e => e.2.1).reverse := {PM}.queried_eq log\n"),
 PM + '.macBudget': row("ctlMacBudget",
   f"theorem ctlMacBudget (q : Complexity.PolyExpr) (n : ℕ) : ({PM}.macBudget q).eval n =\n    q.eval n * (Complexity.PolyExpr.const 1).eval n + (Complexity.PolyExpr.const 1).eval n := rfl\n",
   f"theorem ctlMacBudgetReader (q : Complexity.PolyExpr) (n : ℕ) : ({PM}.macBudget q).eval n =\n    q.eval n * (Complexity.PolyExpr.const 1).eval n + (Complexity.PolyExpr.const 1).eval n :=\n  {PM}.macBudget_eval q n\n"),
 PM + '.blocks': row("ctlBlocks",
   f"theorem ctlBlocks {{a : ℕ}} (L : List (Fin a → Bool)) :\n    {PM}.blocks L = (L.map fun m => true :: List.ofFn m).flatten := rfl\n",
   f"theorem ctlBlocksReader {{a : ℕ}} (L : List (Fin a → Bool)) :\n    {PM}.blocks L = (L.map fun m => true :: List.ofFn m).flatten := {PM}.blocks_eq L\n"),
 PM + '.macHandler': row("ctlMacHandler",
   f"theorem ctlMacHandler (q l t : Complexity.PolyExpr) :\n    ({PM}.macHandler q l t).perCall = .const 1 := rfl\n",
   f"theorem ctlMacHandlerReader (q l t : Complexity.PolyExpr) :\n    ({PM}.macHandler q l t).perCall = .const 1 := {PM}.macHandler_perCall q l t\n"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace PrfMacControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end PrfMacControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
