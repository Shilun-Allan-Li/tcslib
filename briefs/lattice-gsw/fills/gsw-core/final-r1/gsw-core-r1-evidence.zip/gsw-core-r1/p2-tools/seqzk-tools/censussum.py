"""censussum.py <census log>: summary of the C rows of a census probe (count by module, axiom union,
sorryAx, simp, instance, reducible, abbrev, private, internal)."""
import sys, collections, ast
rows = [l.rstrip('\n').split('\t') for l in open(sys.argv[1], encoding='utf-8') if l.startswith('C\t')]
by = collections.Counter(r[4] for r in rows); ax = set()
for r in rows: ax |= set(x.strip() for x in r[12].strip('[]').split(',') if x.strip())
print('stored constants', len(rows)); print('by module', dict(by))
print('axiom union', sorted(ax)); print('sorryAx:', [r[1] for r in rows if 'sorryAx' in r[12]])
print('internal/aux', sum(r[2] == 'true' for r in rows), 'private', sum(r[3] == 'true' for r in rows))
for k, i, v in (('simp', 9, 'true'), ('instance', 10, 'true'), ('reducible', 7, 'reducible'), ('abbrev', 8, 'abbrev')):
    print(k + ':', [r[1] for r in rows if r[i] == v])
