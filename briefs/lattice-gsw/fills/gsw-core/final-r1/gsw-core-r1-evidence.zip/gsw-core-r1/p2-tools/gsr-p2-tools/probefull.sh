#!/usr/bin/env bash
# probefull.sh (canonizer review: probe.sh with -DmaxErrors=0, so a whole-file seal probe is not cut at 100 errors) <tree> <file.lean> [cwd]: run `lean` on a file against <tree> plus the lake packages
# (the LEAN_PATH of scripts/lean_check_tree.sh), with no -o, so nothing is written to <tree>.
set -u
LP="$1"; for d in /home/user/tcslib/.lake/packages/*/.lake/build/lib/lean; do [ -d "$d" ] && LP="$LP:$d"; done
export LEAN_PATH="$LP"; export PATH="$HOME/.elan/bin:$PATH"
cd "${3:-.}"
lean -DmaxErrors=0 "$2"; echo "lean rc=$?"
