/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Gadget
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The GSW noise invariant and its homomorphic operations

## Main definitions

* `Encrypts P t x β C`: `tᵗ C = x · tᵗ G + eᵗ (mod q)` for an integer error vector `e` with
  every entry of magnitude at most `β`. This is the key-agnostic invariant of [AP14,
  Definitions 3.2–3.3] with an explicit worst-case bound.
* `mul`: `C₁ ⊡ C₂ = C₁ · G⁻¹(C₂)`; `nand`: `G − C₁ ⊡ C₂`; `chain`: the right-associative
  product `C₁ ⊡ (C₂ ⊡ (⋯ ⊡ acc))`.

## Main results

* `encrypts_gadget`, `encrypts_zero`: `G` encrypts `1` and `0` encrypts `0`, both noiseless.
* `Encrypts.add`, `.neg`, `.sub`, `.sum`, `.mono`: additive closure.
* `Encrypts.mul`: **asymmetric** multiplication: the left operand's noise is multiplied by
  `N` (a bound on `‖G⁻¹(C₂)‖`), the right operand's only by `|x₁|`.
* `Encrypts.mul_bit`, `Encrypts.mul_le`: the bit-message and symmetric `(N+1)·max` corollaries.
* `Encrypts.nand`: NAND of two bit encryptions with noise `N·β₁ + β₂ ≤ (N+1)·max`.
* `encrypts_chain`: a right-associative chain of `k` bit encryptions times an accumulator has
  noise `β_acc + k·N·β`, additive in `k`.

## References

* [AP14] J. Alperin-Sheriff, C. Peikert, *Faster Bootstrapping with Polynomial Error*,
  CRYPTO 2014; ePrint 2014/094 version dated 13 June 2014, Section 3.2 (operations),
  Definitions 3.2–3.3, Lemma 3.5, Corollary 3.6.
* [Pei16] C. Peikert, *A Decade of Lattice Cryptography*, author version dated
  17 February 2016, Section 6.1.3, Equations (6.1.5)–(6.1.6).
* [GSW13] C. Gentry, A. Sahai, B. Waters, CRYPTO 2013; author version dated 8 June 2013,
  Sections 1.3.1, 1.3.3, 3.3 (`Add`, `Mult`, `NAND`) and 3.4.
* [BV14] Z. Brakerski, V. Vaikuntanathan, *Lattice-Based FHE as Secure as PKE*, ITCS 2014;
  ePrint 2013/541, Claims 3.4.1–3.4.2.

**Convention and deviations.** Ciphertexts and keys follow [AP14, Section 3.2] and
[Pei16, Section 6.1.3]: `t` is a *left* approximate singular vector, `tᵗ C ≈ x · tᵗ G`, and
multiplication is `C₁ · G⁻¹(C₂)`. Its error is `e₁ᵗ G⁻¹(C₂) + x₁ e₂ᵗ` [AP14, Lemma 3.5]: the
**left** operand's error is expanded, the **right** operand's is scaled by the left message.
[GSW13] and [BV14] use the transposed convention (`C · v ≈ μ v`, square `{0,1}` ciphertexts
after `Flatten`), in which `C₁ · C₂` has error `μ₂ e₁ + C₁ e₂` [GSW13, Section 3.3]: there the
*right* operand's error is expanded. The two conventions are mirror images; a chain with
additive noise puts fresh ciphertexts on the left here, on the right in [BV14, Claim 3.4.2].
Noise bounds are worst-case (`ℓ∞`, `ℕ`-valued), not [AP14]'s subgaussian parameters, so a
`k`-fold chain grows like `k·N·β` rather than `√k`. [GSW13]'s NAND is `I_N − C₁·C₂` after
`Flatten`; here it is `G − C₁·G⁻¹(C₂)`, with the same `(N+1)·B` bound [GSW13, Section 3.4].
-/

namespace TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW

/-- Homomorphic multiplication `C₁ ⊡ C₂ = C₁ · G⁻¹(C₂)` [AP14, Section 3.2; Pei16,
Equation (6.1.6)]. Deterministic, right operand decomposed. -/
def mul (P : Parameters) (C₁ C₂ : Ciphertext P) : Ciphertext P :=
  C₁ * lift P (decompose P C₂)

/-- `mul P C₁ C₂` is `C₁` times the lifted binary decomposition of `C₂`. -/
theorem mul_eq (P : Parameters) (C₁ C₂ : Ciphertext P) :
    mul P C₁ C₂ = C₁ * lift P (decompose P C₂) := rfl

/-- Homomorphic NAND `G − C₁ ⊡ C₂` [GSW13, Section 3.3, `NAND`, gadget form; Pei16,
Section 6.1.3, "`(x₁ NAND x₂) = 1 − x₁x₂`"]. -/
def nand (P : Parameters) (C₁ C₂ : Ciphertext P) : Ciphertext P :=
  gadget P - mul P C₁ C₂

/-- `nand P C₁ C₂` is the gadget minus the homomorphic product. -/
theorem nand_eq (P : Parameters) (C₁ C₂ : Ciphertext P) :
    nand P C₁ C₂ = gadget P - mul P C₁ C₂ := rfl

/-- The right-associative product chain `C₁ ⊡ (C₂ ⊡ (⋯ ⊡ (Cₖ ⊡ acc)))` [AP14, Corollary 3.6,
with `acc = G`; Pei16, Section 6.1.3, "Bootstrapping": right-associative chains]. -/
def chain (P : Parameters) (Cs : List (Ciphertext P)) (acc : Ciphertext P) : Ciphertext P :=
  Cs.foldr (mul P) acc

/-- The empty chain is its accumulator. -/
theorem chain_nil (P : Parameters) (acc : Ciphertext P) : chain P [] acc = acc := rfl

/-- A nonempty chain multiplies its head on the left of the remaining chain. -/
theorem chain_cons (P : Parameters) (C : Ciphertext P) (Cs : List (Ciphertext P))
    (acc : Ciphertext P) : chain P (C :: Cs) acc = mul P C (chain P Cs acc) := rfl

/-- **The GSW noise invariant.** `C` encrypts the integer `x` under the key vector `t` with
noise at most `β`: there is an integer error vector `e`, every entry of magnitude at most
`β`, with `tᵗ C = x · tᵗ G + eᵗ` modulo `q` [AP14, Definitions 3.2–3.3; Pei16, Section 6.1.3,
`sᵗ A ≈ x · sᵗ G`; BV14, Definition 3.1, transposed]. The predicate does not fix how `C` was
produced, so it is shared by public-key, secret-key and evaluated ciphertexts. -/
def Encrypts (P : Parameters) (t : Fin (P.lwe.dimension + 1) → ZMod P.lwe.modulus) (x : ℤ)
    (β : ℕ) (C : Ciphertext P) : Prop :=
  ∃ e : Fin P.columns → ℤ, (∀ j, (e j).natAbs ≤ β) ∧
    Matrix.vecMul t C = (x : ZMod P.lwe.modulus) • Matrix.vecMul t (gadget P) +
      fun j => (e j : ZMod P.lwe.modulus)

/-- `Encrypts P t x β C` holds exactly when some `β`-bounded integer error vector `e` gives
`tᵗ C = x · tᵗ G + e`. -/
theorem encrypts_iff (P : Parameters) (t : Fin (P.lwe.dimension + 1) → ZMod P.lwe.modulus)
    (x : ℤ) (β : ℕ) (C : Ciphertext P) :
    Encrypts P t x β C ↔ ∃ e : Fin P.columns → ℤ, (∀ j, (e j).natAbs ≤ β) ∧
      Matrix.vecMul t C = (x : ZMod P.lwe.modulus) • Matrix.vecMul t (gadget P) +
        fun j => (e j : ZMod P.lwe.modulus) := Iff.rfl

section Closure

variable (P : Parameters) {t : Fin (P.lwe.dimension + 1) → ZMod P.lwe.modulus}

/-- The gadget encrypts `1` with zero noise [AP14, Section 3.3, "`μG` … has error 0"].

**Proof sketch.** Through `encrypts_iff`, take `e = 0`; coordinatewise `1 • v + 0 = v`. -/
theorem encrypts_gadget : Encrypts P t 1 0 (gadget P) := by
  rw [encrypts_iff]
  refine ⟨0, fun j => (Int.natAbs_zero).le, ?_⟩
  ext j
  simp only [Pi.add_apply, Pi.zero_apply, Int.cast_one, one_smul, Int.cast_zero, add_zero]

/-- The zero matrix encrypts `0` with zero noise [AP14, Section 3.3].

**Proof sketch.** Through `encrypts_iff`, take `e = 0`; coordinatewise
`Matrix.vecMul_zero` and `zero_smul`. -/
theorem encrypts_zero : Encrypts P t 0 0 0 := by
  rw [encrypts_iff]
  refine ⟨0, fun j => (Int.natAbs_zero).le, ?_⟩
  ext j
  simp only [Matrix.vecMul_zero, Pi.add_apply, Pi.zero_apply, Int.cast_zero, zero_smul,
    add_zero]

/-- Weakening the noise bound preserves the invariant.

**Proof sketch.** Reuse the witness; `le_trans` on each entry. -/
theorem Encrypts.mono {x : ℤ} {β β' : ℕ} {C : Ciphertext P} (h : Encrypts P t x β C)
    (hβ : β ≤ β') : Encrypts P t x β' C := by
  obtain ⟨e, he, hC⟩ := (encrypts_iff P t x β C).mp h
  exact (encrypts_iff P t x β' C).mpr ⟨e, fun j => (he j).trans hβ, hC⟩

/-- Homomorphic addition adds messages and noise bounds [AP14, Lemma 3.5, first claim;
GSW13, Section 3.3, `Add`; BV14, Claim 3.4.1].

**Proof sketch.** Witness `e₁ + e₂`; `Int.natAbs_add_le` bounds the entries.
`Matrix.vecMul_add` splits `tᵗ(C₁+C₂)`, the two invariants are substituted, and coordinatewise
`Int.cast_add` and ring arithmetic regroup `x₁ v + e₁ + x₂ v + e₂ = (x₁+x₂) v + (e₁+e₂)`. -/
theorem Encrypts.add {x₁ x₂ : ℤ} {β₁ β₂ : ℕ} {C₁ C₂ : Ciphertext P}
    (h₁ : Encrypts P t x₁ β₁ C₁) (h₂ : Encrypts P t x₂ β₂ C₂) :
    Encrypts P t (x₁ + x₂) (β₁ + β₂) (C₁ + C₂) := by
  obtain ⟨e₁, he₁, hC₁⟩ := (encrypts_iff P t x₁ β₁ C₁).mp h₁
  obtain ⟨e₂, he₂, hC₂⟩ := (encrypts_iff P t x₂ β₂ C₂).mp h₂
  refine (encrypts_iff P t _ _ _).mpr ⟨e₁ + e₂, fun j =>
    (Int.natAbs_add_le (e₁ j) (e₂ j)).trans (Nat.add_le_add (he₁ j) (he₂ j)), ?_⟩
  rw [Matrix.vecMul_add, hC₁, hC₂]
  ext j
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, Int.cast_add]
  ring

/-- Negation negates the message and keeps the noise bound.

**Proof sketch.** Witness `-e`, bounded by `Int.natAbs_neg`. `Matrix.vecMul_neg` and the
invariant give `-(x v + e)`, which is `(-x) v + (-e)` coordinatewise (`Int.cast_neg`, ring). -/
theorem Encrypts.neg {x : ℤ} {β : ℕ} {C : Ciphertext P} (h : Encrypts P t x β C) :
    Encrypts P t (-x) β (-C) := by
  obtain ⟨e, he, hC⟩ := (encrypts_iff P t x β C).mp h
  refine (encrypts_iff P t _ _ _).mpr ⟨-e, fun j => (Int.natAbs_neg (e j)).le.trans (he j), ?_⟩
  rw [Matrix.vecMul_neg, hC]
  ext j
  simp only [Pi.add_apply, Pi.neg_apply, Pi.smul_apply, smul_eq_mul, Int.cast_neg]
  ring

/-- Subtraction subtracts messages and adds noise bounds.

**Proof sketch.** `sub_eq_add_neg`, then `Encrypts.add` and `Encrypts.neg`. -/
theorem Encrypts.sub {x₁ x₂ : ℤ} {β₁ β₂ : ℕ} {C₁ C₂ : Ciphertext P}
    (h₁ : Encrypts P t x₁ β₁ C₁) (h₂ : Encrypts P t x₂ β₂ C₂) :
    Encrypts P t (x₁ - x₂) (β₁ + β₂) (C₁ - C₂) := by
  rw [sub_eq_add_neg x₁, sub_eq_add_neg C₁]
  exact Encrypts.add P h₁ (Encrypts.neg P h₂)

/-- A finite sum of encryptions encrypts the sum of the messages with the sum of the noise
bounds [AP14, Section 4.1, Equation (4.1), the outer homomorphic sum].

**Proof sketch.** `Finset.induction_on`; the empty sum is `encrypts_zero`, and each insertion
is `Encrypts.add`. -/
theorem Encrypts.sum {ι : Type*} (s : Finset ι) (x : ι → ℤ) (β : ι → ℕ)
    (C : ι → Ciphertext P) (h : ∀ i ∈ s, Encrypts P t (x i) (β i) (C i)) :
    Encrypts P t (∑ i ∈ s, x i) (∑ i ∈ s, β i) (∑ i ∈ s, C i) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    rw [Finset.sum_empty, Finset.sum_empty, Finset.sum_empty]
    exact encrypts_zero P
  | insert a s ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha, Finset.sum_insert ha]
    exact Encrypts.add P (h a (Finset.mem_insert_self a s))
      (ih fun i hi => h i (Finset.mem_insert_of_mem hi))

/-- **Asymmetric homomorphic multiplication** [AP14, Lemma 3.5; Pei16, Equation (6.1.6);
BV14, Claim 3.4.2, mirrored]. If `C₁` encrypts `x₁` with noise `β₁` and `C₂` encrypts `x₂`
with noise `β₂`, then `C₁ ⊡ C₂` encrypts `x₁x₂` with noise at most `N·β₁ + |x₁|·β₂`. The left
operand's noise is multiplied by `N`, the number of `{0,1}` entries in a column of `G⁻¹(C₂)`;
the right operand's is multiplied only by the left message.

**Proof sketch.** The witness is `j ↦ (∑ᵢ e₁ i · X i j) + x₁ · e₂ j` with
`X = lift (G⁻¹ C₂)`. Bound: by `Int.natAbs_add_le`, the first summand is a binary subset sum
of `N` entries bounded by `β₁`, bounded by `N·β₁` via `LWE.binaryErrorSum_bound`; the second
has magnitude `|x₁|·|e₂ j| ≤ |x₁|·β₂` (`Int.natAbs_mul`). Invariant: `Matrix.vecMul_vecMul`
rewrites `tᵗ (C₁ X)` as `(tᵗ C₁) X`; substituting `h₁` and distributing
(`Matrix.add_vecMul`, `Matrix.smul_vecMul`) gives `x₁ tᵗ(G X) + e₁ᵗ X`. By
`gadget_mul_decompose`, `G X = C₂`, so the first term is `x₁ (x₂ tᵗG + e₂ᵗ)` by `h₂`. Finally
`e₁ᵗ X` is, coordinatewise, the residue of the integer sum `∑ᵢ e₁ i · X i j` (`lift_apply`,
`Int.cast_sum`), and ring arithmetic in each coordinate closes the identity. -/
theorem Encrypts.mul {x₁ x₂ : ℤ} {β₁ β₂ : ℕ} {C₁ C₂ : Ciphertext P}
    (h₁ : Encrypts P t x₁ β₁ C₁) (h₂ : Encrypts P t x₂ β₂ C₂) :
    Encrypts P t (x₁ * x₂) (P.columns * β₁ + x₁.natAbs * β₂) (mul P C₁ C₂) := by
  obtain ⟨e₁, he₁, hC₁⟩ := (encrypts_iff P t x₁ β₁ C₁).mp h₁
  obtain ⟨e₂, he₂, hC₂⟩ := (encrypts_iff P t x₂ β₂ C₂).mp h₂
  refine (encrypts_iff P t _ _ _).mpr
    ⟨fun j => (∑ i, e₁ i * ((decompose P C₂ i j).toNat : ℤ)) + x₁ * e₂ j, fun j => ?_, ?_⟩
  · -- Step 1: the binary subset sum and the scaled right error.
    refine (Int.natAbs_add_le _ _).trans (Nat.add_le_add ?_ ?_)
    · exact LWE.binaryErrorSum_bound e₁ (fun i => decompose P C₂ i j) β₁ he₁
    · rw [Int.natAbs_mul]
      exact Nat.mul_le_mul_left _ (he₂ j)
  · -- Step 2: `tᵗ (C₁ X) = (x₁ tᵗG + e₁ᵗ) X = x₁ tᵗ (G X) + e₁ᵗ X` and `G X = C₂`.
    rw [mul_eq, ← Matrix.vecMul_vecMul, hC₁, Matrix.add_vecMul, Matrix.smul_vecMul,
      Matrix.vecMul_vecMul, gadget_mul_decompose, hC₂]
    -- Step 3: read `e₁ᵗ X` coordinatewise as the residue of an integer sum.
    have hX : Matrix.vecMul (fun i => (e₁ i : ZMod P.lwe.modulus)) (lift P (decompose P C₂)) =
        fun j => ((∑ i, e₁ i * ((decompose P C₂ i j).toNat : ℤ) : ℤ) : ZMod P.lwe.modulus) := by
      ext j
      change ∑ i, (e₁ i : ZMod P.lwe.modulus) * lift P (decompose P C₂) i j = _
      simp only [lift_apply, Int.cast_sum, Int.cast_mul, Int.cast_natCast]
    rw [hX]
    ext j
    simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, Int.cast_add, Int.cast_mul]
    ring

/-- For a bit message on the left, multiplication has noise `N·β₁ + β₂` [GSW13, Section 3.3,
`Mult`; Pei16, Section 6.1.3].

**Proof sketch.** `Encrypts.mul` and `Encrypts.mono`, since `(b.toNat : ℤ).natAbs = b.toNat ≤ 1`
(`Int.natAbs_natCast`, `Bool.toNat_le`). -/
theorem Encrypts.mul_bit {b : Bool} {x₂ : ℤ} {β₁ β₂ : ℕ} {C₁ C₂ : Ciphertext P}
    (h₁ : Encrypts P t (b.toNat : ℤ) β₁ C₁) (h₂ : Encrypts P t x₂ β₂ C₂) :
    Encrypts P t ((b.toNat : ℤ) * x₂) (P.columns * β₁ + β₂) (GSW.mul P C₁ C₂) := by
  refine Encrypts.mono P (Encrypts.mul P h₁ h₂) (Nat.add_le_add_left ?_ _)
  rw [Int.natAbs_natCast]
  exact (Nat.mul_le_mul_right β₂ (Bool.toNat_le b)).trans (Nat.one_mul β₂).le

/-- Symmetric corollary: two bit-message operands with noise at most `β` give a product with
noise at most `(N+1)·β` [GSW13, Section 3.4; Pei16, Section 6.1.3].

**Proof sketch.** `Encrypts.mul_bit` and `N·β + β = (N+1)·β`; the message
`(b₁ && b₂).toNat = b₁.toNat · b₂.toNat` by cases on the bits. -/
theorem Encrypts.mul_le {b₁ b₂ : Bool} {β : ℕ} {C₁ C₂ : Ciphertext P}
    (h₁ : Encrypts P t (b₁.toNat : ℤ) β C₁) (h₂ : Encrypts P t (b₂.toNat : ℤ) β C₂) :
    Encrypts P t ((b₁ && b₂).toNat : ℤ) ((P.columns + 1) * β) (GSW.mul P C₁ C₂) := by
  have hm : ((b₁ && b₂).toNat : ℤ) = (b₁.toNat : ℤ) * (b₂.toNat : ℤ) := by
    cases b₁ <;> cases b₂ <;> rfl
  rw [hm, Nat.succ_mul]
  exact Encrypts.mul_bit P h₁ h₂

/-- **Homomorphic NAND** [GSW13, Sections 3.3–3.4, `NAND`, "the error is increased by a
factor of at most `N + 1`"; Pei16, Section 6.1.3]. Bit encryptions with noise `β₁`, `β₂` give
an encryption of `NAND(b₁,b₂)` with noise at most `N·β₁ + β₂`.

**Proof sketch.** `encrypts_gadget`, `Encrypts.mul_bit`, `Encrypts.sub` give noise
`0 + (N·β₁ + β₂)`, which `Encrypts.mono` drops to `N·β₁ + β₂`; the message `1 − b₁b₂` equals
`(!(b₁ && b₂)).toNat` by cases on the bits. -/
theorem Encrypts.nand {b₁ b₂ : Bool} {β₁ β₂ : ℕ} {C₁ C₂ : Ciphertext P}
    (h₁ : Encrypts P t (b₁.toNat : ℤ) β₁ C₁) (h₂ : Encrypts P t (b₂.toNat : ℤ) β₂ C₂) :
    Encrypts P t ((!(b₁ && b₂)).toNat : ℤ) (P.columns * β₁ + β₂) (nand P C₁ C₂) := by
  have hm : ((!(b₁ && b₂)).toNat : ℤ) = 1 - (b₁.toNat : ℤ) * (b₂.toNat : ℤ) := by
    cases b₁ <;> cases b₂ <;> rfl
  rw [hm, nand_eq]
  exact Encrypts.mono P (Encrypts.sub P (encrypts_gadget P) (Encrypts.mul_bit P h₁ h₂))
    (Nat.zero_add _).le

/-- **Product chains grow additively** [AP14, Corollary 3.6, worst-case form; Pei16,
Section 6.1.3, "any polynomial-length chain of homomorphic bit-multiplications on fresh
ciphertexts, if done in a right-associative manner, incurs only polynomial error growth";
BV14, Claim 3.4.2 and the proof of Lemma 3.6, mirrored]. If every `Cᵢ` encrypts the bit `bᵢ`
with noise at most `β` and `acc` encrypts `x` with noise `β₀`, then
`C₁ ⊡ (⋯ ⊡ (Cₖ ⊡ acc))` encrypts `(∏ bᵢ)·x` with noise at most `β₀ + k·N·β`.

**Proof sketch.** Induction on the `List.Forall₂` hypothesis. The empty chain is the
accumulator, and the empty conjunction is `true`, whose `toNat` is `1`. The step is
`Encrypts.mul_bit` with the head on the left: noise `N·β + (previous)`, message
`b · ((∏ rest) · x)`; the message of the cons is `(b && ∏ rest) · x`, which is that product
because `Bool.toNat` turns `&&` into multiplication (cases on the bits), and the noise
`β₀ + (k+1)·N·β` equals `N·β + (β₀ + k·N·β)` by ring arithmetic. -/
theorem encrypts_chain {bs : List Bool} {Cs : List (Ciphertext P)} {β β₀ : ℕ} {x : ℤ}
    {acc : Ciphertext P}
    (hs : List.Forall₂ (fun b C => Encrypts P t (b.toNat : ℤ) β C) bs Cs)
    (hacc : Encrypts P t x β₀ acc) :
    Encrypts P t (((bs.all id).toNat : ℤ) * x) (β₀ + Cs.length * (P.columns * β))
      (chain P Cs acc) := by
  have hand : ∀ a c : Bool, ((a && c).toNat : ℤ) = (a.toNat : ℤ) * (c.toNat : ℤ) := by
    intro a c
    cases a <;> cases c <;> rfl
  induction hs with
  | nil =>
    -- Step 1: the empty chain is the accumulator, with message `1 · x`.
    rw [chain_nil, List.all_nil, Bool.toNat_true, Nat.cast_one, one_mul, List.length_nil,
      zero_mul, add_zero]
    exact hacc
  | @cons b C bs Cs hbC _ ih =>
    -- Step 2: multiply the head on the left of the shorter chain (`Encrypts.mul_bit`).
    rw [chain_cons, List.all_cons, hand, id_eq, mul_assoc, List.length_cons]
    have hn : β₀ + (Cs.length + 1) * (P.columns * β) =
        P.columns * β + (β₀ + Cs.length * (P.columns * β)) := by ring
    rw [hn]
    exact Encrypts.mul_bit P hbC ih

end Closure

end TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW
