#!/usr/bin/env bash
# run-build.sh (gsw-core r1 review, Phase 2): Mathlib overlay + NthRootLemmas extra, then the 650-module build queue of the
# merged tree 76fae5c8 (tip 4941b511 x d4ebb0be) into $SP/dl-oleans. One Lean process at a time (runner.py is serial).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
R=$SP/dl-review/gsw-core-r1; P=$R/p2; TL=$R/p2-tools/gsr-p2-tools/int-stmt-tools; T=$SP/dl-oleans; X=$SP/wt-gswcore-p2
cd $P
echo "start $(date -u +%FT%TZ)"
# 1. Mathlib overlay (symlinks to the shared pinned Mathlib build; removed at restore)
bash $TL/mloverlay.sh $T > checks-overlay-count.txt 2>&1; echo "overlay $(cat checks-overlay-count.txt)"
# 2. NthRootLemmas: pinned source copied byte-equal into the export, built through lean_check_tree.sh
M=Mathlib/Analysis/SpecialFunctions/Pow/NthRootLemmas
mkdir -p $X/$(dirname $M); cp /home/user/tcslib/.lake/packages/mathlib/$M.lean $X/$M.lean
sha256sum /home/user/tcslib/.lake/packages/mathlib/$M.lean $X/$M.lean > mathlib-extra-source.txt
git -C /home/user/tcslib/.lake/packages/mathlib rev-parse HEAD >> mathlib-extra-source.txt
echo $M > mathlib-extra-order.txt
python3 -I $TL/review/runner.py $X mathlib-extra-order.txt $T build-mathlib-extra; echo "extra runner exit $?"
# 3. the build queue
python3 -I $TL/review/runner.py $X plan/queue.txt $T build
echo "runner exit $? $(date -u +%FT%TZ)"
