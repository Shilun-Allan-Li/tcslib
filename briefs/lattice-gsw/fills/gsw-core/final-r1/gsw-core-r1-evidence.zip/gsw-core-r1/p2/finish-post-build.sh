#!/usr/bin/env bash
# finish-post-build.sh (gsw-core r1 review, Phase 2). Run after build/ shows "runner exit 0" in build-runner.out.
# One Lean process at a time on $SP/dl-oleans; probes run with runfull.py (lean -DmaxErrors=0, no -o: nothing written
# to the tree). Never lake, never a cache get. Nothing is written under /home/user/tcslib (git is read-only here).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
R=$SP/dl-review/gsw-core-r1; P=$R/p2; TL=$R/p2-tools/gsr-p2-tools/int-stmt-tools; TZ=$R/p2-tools/seqzk-tools
AT=$TZ/archived-gate10-tools; T=$SP/dl-oleans; X=$SP/wt-gswcore-p2; REPO=/home/user/tcslib
MT=76fae5c89bce2097cf32b536edfdec6544a49bcb; TIP=4941b5119c82431452face78071bd4376ee3e427
B0=486f44f8414c20a2d21e452c44de8b8c8d8513a0
cd $P; mkdir -p checks state-out records tree-final admissions
echo "finish start $(date -u +%FT%TZ)"
# 1. state, per-module table, whole-tree check
python3 -I $TL/stateplan.py update $REPO $MT state.json build/results.jsonl $T
python3 -I $TL/stateplan.py check $REPO $MT order/order.txt state.json $T state-out/statecheck.txt
python3 -I $TL/permod.py build build/per-module.tsv > checks/permod.out 2>&1
cat ref/base-records-from-int-317.jsonl build-mathlib-extra/results.jsonl build/results.jsonl > records/records-final.jsonl
python3 -I $TL/treecheck_ml.py $T order/order.txt records/records-final.jsonl $REPO $MT tree-final/snapshot-final.txt \
  | tee tree-final/treecheck.out
# 2. admissions census (tip and merged)
python3 -I $TL/tipcensus.py $REPO $TIP admissions/census-tip.txt base=ref/base-records-from-int-317.jsonl \
  int331333=ref/int-stmt-331-333-records-final.jsonl this=build/results.jsonl
python3 -I $TL/tipcensus.py $REPO $MT admissions/census-merged.txt base=ref/base-records-from-int-317.jsonl \
  int331333=ref/int-stmt-331-333-records-final.jsonl this=build/results.jsonl
diff admissions/census-tip.txt admissions/census-merged.txt > admissions/census-tip-vs-merged.diff
# 3. probes: axioms census + trace, GC-05 (sealed and unsealed), collector
printf '%s\n' GcProbe/GcCensus GcProbe/GcMatcher GcProbe/GcMatcherU GcProbe/GcCollect > probe-order.txt
python3 -I $TZ/runfull.py $X probe-order.txt $T probe-runs
# 4. seals from the collector log: strict A/B (mkseals_ab) and coe A/B (mkseals_coe), probes under GcSeal/ and GcSealCoe/
CL=probe-runs/mods/GcProbe_GcCollect.log
OWN="TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Gadget TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Noise TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Scheme TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Symmetric TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Eval"
export GIT_DIR=$REPO/.git
python3 -I $TZ/mkseals_ab.py $AT $CL $X $MT seals/A GcSeal SealA_ $OWN
SEAL_EVAL=1 python3 -I $TZ/mkseals_ab.py $AT $CL $X $MT seals/B GcSeal SealB_ $OWN
python3 -I $TZ/mkseals_coe.py $AT $CL $X $MT seals-coe/A GcSealCoe SealA_ $OWN
SEAL_EVAL=1 python3 -I $TZ/mkseals_coe.py $AT $CL $X $MT seals-coe/B GcSealCoe SealB_ $OWN
unset GIT_DIR
# 5. controls: canonical (coe seal records) and strict
python3 -I $R/tools/mkctl_gsw.py $AT seals-coe/A $X GcCtl controls/A
python3 -I $R/tools/mkctl_gsw.py $AT seals-coe/B $X GcCtl controls/B
python3 -I $R/tools/mkctl_gsw.py $AT seals/A $X GcCtlStrict controls-strict/A
python3 -I $R/tools/mkctl_gsw.py $AT seals/B $X GcCtlStrict controls-strict/B
# 6. run every seal and control probe
( cd $X && ls GcSeal/*.lean GcSealCoe/*.lean | sed 's/\.lean$//' ) > seal-order.txt
python3 -I $TZ/runfull.py $X seal-order.txt $T seal-runs
( cd $X && ls GcCtl/*.lean GcCtlStrict/*.lean | sed 's/\.lean$//' ) > control-order.txt
python3 -I $TZ/runfull.py $X control-order.txt $T control-runs
echo "finish end $(date -u +%FT%TZ)"
