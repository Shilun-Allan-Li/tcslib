import Lean
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Gadget
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Noise
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Scheme
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Symmetric
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Eval

/-! gsw-core r1 maintainer review: axioms census and dependency trace (probe, not library code).
`#print axioms` of the 29 targets; then, for every stored constant of the five owned modules, a `C` row
(normalized name, private flag, home, kind, reducibility, simp, instance, axioms) and, for the 29 targets and the
3 private helpers, a `T` row with the size of the constant closure and every constant in it whose own type or value
mentions `sorryAx` directly. -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

open TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW

#print axioms digits_decomposeVec
#print axioms gadget_mulVec_decomposeVec
#print axioms gadget_mul_decompose
#print axioms decomposeVec_block_eq_false
#print axioms errorSum_decomposeVec_le
#print axioms encrypts_gadget
#print axioms encrypts_zero
#print axioms Encrypts.mono
#print axioms Encrypts.add
#print axioms Encrypts.neg
#print axioms Encrypts.sub
#print axioms Encrypts.sum
#print axioms Encrypts.mul
#print axioms Encrypts.mul_bit
#print axioms Encrypts.mul_le
#print axioms Encrypts.nand
#print axioms encrypts_chain
#print axioms vecMul_secretVector_augmented
#print axioms encrypts_encrypt
#print axioms encrypts_keygen_encrypt
#print axioms decrypt_of_encrypts
#print axioms decrypt_of_encrypts_dyadic
#print axioms decrypt_keygen_encrypt
#print axioms encrypts_symEncrypt
#print axioms distAdv_symEncrypt_le
#print axioms homAnd_encrypts
#print axioms homGate_encrypts
#print axioms eval_encrypts
#print axioms decrypt_keygen_eval

open Lean Elab Command

def gcOwners : List Name := [
  `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Gadget,
  `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Noise,
  `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Scheme,
  `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Symmetric,
  `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Eval]

def gcTraced : List String := [
  "digits_decomposeVec", "gadget_mulVec_decomposeVec", "gadget_mul_decompose",
  "decomposeVec_block_eq_false", "errorSum_decomposeVec_le", "encrypts_gadget", "encrypts_zero",
  "Encrypts.mono", "Encrypts.add", "Encrypts.neg", "Encrypts.sub", "Encrypts.sum", "Encrypts.mul",
  "Encrypts.mul_bit", "Encrypts.mul_le", "Encrypts.nand", "encrypts_chain",
  "vecMul_secretVector_augmented", "encrypts_encrypt", "encrypts_keygen_encrypt", "decrypt_of_encrypts",
  "decrypt_of_encrypts_dyadic", "decrypt_keygen_encrypt", "encrypts_symEncrypt", "distAdv_symEncrypt_le",
  "homAnd_encrypts", "homGate_encrypts", "eval_encrypts", "decrypt_keygen_eval",
  "halfVector_eq_zero_of_ne_last", "decrypt_eq_decode_errorSum", "exists_equiv_symEncrypt"]

def gcNorm (n : Name) : String := ((Lean.privateToUserName? n).getD n).toString

def gcKind : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "def" | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let simps := Lean.Meta.simpExtension.getState env
  let pre := "TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW."
  let mut n := 0
  let mut traced := 0
  for (c, ci) in env.constants.toList do
    let some mi := env.getModuleIdxFor? c | continue
    let home := names[mi.toNat]!
    unless gcOwners.contains home do continue
    let axs ← liftCoreM (Lean.collectAxioms c)
    let axs := (axs.map (·.toString)).qsort (· < ·)
    let red := match Lean.getReducibilityStatusCore env c with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    IO.println s!"C\t{gcNorm c}\t{(Lean.privateToUserName? c).isSome}\t{home}\t{gcKind ci}\t{red}\t{simps.isLemma (.decl c)}\t{Lean.Meta.isInstanceCore env c}\t{axs.toList}"
    n := n + 1
    let short := (gcNorm c).replace pre ""
    if gcTraced.contains short then
      let mut seen : NameSet := {}
      let mut stack : Array Name := #[c]
      let mut direct : Array String := #[]
      while h : stack.size > 0 do
        let d := stack.back
        stack := stack.pop
        if seen.contains d then continue
        seen := seen.insert d
        if let some di := env.find? d then
          let us := di.type.getUsedConstants ++ (di.value?.map (·.getUsedConstants)).getD #[]
          if us.contains ``sorryAx then direct := direct.push d.toString
          for u in us do stack := stack.push u
      IO.println s!"T\t{short}\tclosure={seen.size}\tsorried={direct.toList}"
      traced := traced + 1
  IO.println s!"C-COUNT {n} T-COUNT {traced}"
