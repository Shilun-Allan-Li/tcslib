import Lean
import TCSlib.Complexity.CircuitComplexity.DAGCircuit

/-! gsw-core r1 maintainer review, finding GC-05, UNSEALED companion of GcMatcher.lean (no attribute installed;
every example must pass). Original header:
1. Which matcher `BoolCircuit.DAGGate.eval` and the statement of its reader `DAGGate.eval_eq` use, with its home module
   and reducibility.
2. Seal that matcher (`attribute [local irreducible]`) and test whether a `match` of the published reader still
   reduces on a constructor (expected to pass if sealing matchers does not block iota reduction): tags GC05-A1..A3.
3. Seal `DAGGate.eval` itself as well: the direct definitional read must fail exactly once (GC05-NEG), while the
   reader route still passes (GC05-POS).
Every check is an `example` tagged in the comment line before it. -/

set_option maxHeartbeats 0

open Lean Elab Command

run_cmd do
  let env ← getEnv
  let some ci := env.find? ``BoolCircuit.DAGGate.eval | throwError "missing DAGGate.eval"
  let some ce := env.find? ``BoolCircuit.DAGGate.eval_eq | throwError "missing DAGGate.eval_eq"
  let ms := (ci.value!.getUsedConstants ++ ce.type.getUsedConstants).filter (Lean.Meta.isMatcherCore env)
  let ms := ms.foldl (fun acc m => if acc.contains m then acc else acc.push m) #[]
  for m in ms do
    let home := (env.getModuleIdxFor? m).map fun i => env.header.moduleNames[i.toNat]!
    let red := match Lean.getReducibilityStatusCore env m with
      | .reducible => "reducible" | .semireducible => "semireducible" | .irreducible => "irreducible"
    logInfo m!"GC05-MATCHER {m} home={home} status={red} inEvalValue={ci.value!.getUsedConstants.contains m} inEvalEqType={ce.type.getUsedConstants.contains m}"
    let after ← liftCoreM (Lean.getReducibilityStatus m)
    logInfo m!"GC05-SEALED {m} irreducible={after == .irreducible}"
  logInfo m!"GC05-MATCHER-COUNT {ms.size}"

namespace BoolCircuit

-- GC05-A1: `.and`, matcher sealed, reader route, term-mode `rfl` after the reader
example (args : List ℕ) (vals : List Bool) :
    DAGGate.eval ⟨.and, args⟩ vals = args.all fun a => vals.getD a false :=
  (DAGGate.eval_eq _ _).trans rfl

-- GC05-A2: `.not`, matcher sealed, reader route, tactic form as in `homGate_encrypts`
example (args : List ℕ) (vals : List Bool) :
    DAGGate.eval ⟨.not, args⟩ vals = !(args.all fun a => vals.getD a false) := by
  rw [DAGGate.eval_eq]

-- GC05-A3: `.or` after `cases` on the kind, matcher sealed, reader route
example (k : GateKind) (hk : k = .or) (args : List ℕ) (vals : List Bool) :
    DAGGate.eval ⟨k, args⟩ vals = args.any fun a => vals.getD a false := by
  subst hk
  rw [DAGGate.eval_eq]


-- GC05-NEG: the definition itself sealed: the direct read must fail
example (args : List ℕ) (vals : List Bool) :
    DAGGate.eval ⟨.and, args⟩ vals = args.all fun a => vals.getD a false :=
  rfl

-- GC05-POS: both sealed, reader route still passes
example (args : List ℕ) (vals : List Bool) :
    DAGGate.eval ⟨.and, args⟩ vals = args.all fun a => vals.getD a false :=
  (DAGGate.eval_eq _ _).trans rfl

end BoolCircuit
