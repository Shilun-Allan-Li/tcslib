#!/usr/bin/env bash
# summarize.sh (gsw-core r1 review, Phase 2): no Lean. Summaries of the probe, seal and control runs.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
R=$SP/dl-review/gsw-core-r1; P=$R/p2; TZ=$R/p2-tools/seqzk-tools
cd $P; mkdir -p summary
for v in seals/A seals/B seals-coe/A seals-coe/B; do
  python3 -I $TZ/sealsum.py $v seal-runs statements/touched.json summary/sealsum-$(echo $v | tr / -).tsv
done
for v in controls/A controls/B controls-strict/A controls-strict/B; do
  echo "== $v"; python3 -I $TZ/ctlcheck2.py $v/controls-plan.json control-runs summary/ctlcheck-$(echo $v | tr / -).json
done > summary/ctlcheck.log 2>&1
# raw error counts in both forms for every probe/seal/control log
python3 -I - > summary/error-counts.tsv <<'EOF'
import os, re, json
for d in ('build-mathlib-extra', 'build', 'probe-runs', 'seal-runs', 'control-runs'):
    md = os.path.join(d, 'mods')
    if not os.path.isdir(md): continue
    tot = [0, 0, 0, 0]
    for f in sorted(os.listdir(md)):
        t = open(os.path.join(md, f), encoding='utf-8', errors='replace').read()
        c = len(re.findall(r'^\S+\.lean:\d+:\d+: error:', t, re.M)); p = len(re.findall(r'^\S+\.lean:\d+:\d+: error\(', t, re.M))
        s = t.count("declaration uses 'sorry'")
        tot[0] += 1; tot[1] += c; tot[2] += p; tot[3] += s
        if d != 'build': print(f'{d}\t{f}\terr_colon={c}\terr_paren={p}\tsorry={s}')
    print(f'TOTAL\t{d}\tlogs={tot[0]}\terr_colon={tot[1]}\terr_paren={tot[2]}\tsorry={tot[3]}')
EOF
cat summary/error-counts.tsv | grep TOTAL
