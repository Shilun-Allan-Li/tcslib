#!/usr/bin/env bash
# finish-restore.sh (gsw-core r1 review, Phase 2): restore $SP/dl-oleans to the base snapshot 457ba704... after the build
# and the probes. First make sure no Lean process of this job runs (build/current.pid, probe-runs/, seal-runs/,
# control-runs/ current.pid; ps).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
P=$SP/dl-review/gsw-core-r1/p2; TL=$SP/dl-review/gsw-core-r1/p2-tools/gsr-p2-tools/int-stmt-tools
T=$SP/dl-oleans; BK=$SP/dl-gswcore-backup
ln -sfn $TL/review $P/tools
bash $TL/restore_derand.sh $T $BK $P 2>&1 | tee $P/restore/restore-console.txt
rm $P/tools
python3 -I $TL/restoreplan.py $T $P/tree/snapshot-pre.txt $P/order/order.txt $P/restore/restoreplan-check \
  | tee $P/restore/restoreplan-check.out
python3 -I $TL/review/snapshot.py $T $P/restore/snapshot-verify.txt | tee $P/restore/snapshot-verify.out
sha256sum $P/tree/snapshot-pre.txt $P/tree/snapshot-post.txt $P/restore/snapshot-verify.txt | tee $P/restore/snapshot-sha.txt
# then, if SNAPSHOT EQUAL, restoreplan extra 0 / changed 0 / missing 0 and the digest is 457ba704...: rm -r $BK
