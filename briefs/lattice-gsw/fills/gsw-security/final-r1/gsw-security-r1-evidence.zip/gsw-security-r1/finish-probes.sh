#!/usr/bin/env bash
# gsw-security r1 review, Phase 2 probes (after finish-post-build.sh; before the restore). One Lean process at a time,
# every probe through runfull.py (probefull.sh: lean -DmaxErrors=0, no -o: nothing is written to the tree).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/gsw-security-r1
W=$SP/wt-gsws-x; TR=$SP/dl-oleans-2; M2=a51294c525a060598fe06d7aa83b2c660af8f4f2; RT=$E/rule10-tools; AT=$RT/archived-gate10-tools
MODS="TCSlib.Cryptography.Hashing.SIS.Columns TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security"
cd $E
mkdir -p $W/GsProbe probes; cp p2/probes/GsAxioms.lean p2/probes/GsCollect.lean $W/GsProbe/
printf 'GsProbe/GsAxioms\nGsProbe/GsCollect\n' > probes/order-1.txt
python3 -I $RT/runfull.py $W probes/order-1.txt $TR probe-runs-1
COL=probe-runs-1/mods/GsProbe_GsCollect.log
for v in "ab_gsws:A:seals/A:GsProbe/SA:SealA_:0" "ab_gsws:B:seals/B:GsProbe/SB:SealB_:1" "coe_gsws:A:seals-coe/A:GsProbe/CA:SealA_:0" "coe_gsws:B:seals-coe/B:GsProbe/CB:SealB_:1"; do
  IFS=: read tool letter out sub prefix ev <<< "$v"
  SEAL_EVAL=$([ $ev = 1 ] && echo 1 || echo 0) GITDIR=/home/user/tcslib python3 -I $RT/mkseals_$tool.py $AT $COL $W $M2 $out $sub $prefix $MODS | tee $out.out
done
ls $W/GsProbe/SA/*.lean $W/GsProbe/SB/*.lean $W/GsProbe/CA/*.lean $W/GsProbe/CB/*.lean | sed "s|^$W/||; s|\.lean$||" > probes/order-seals.txt
python3 -I $RT/runfull.py $W probes/order-seals.txt $TR seal-runs
for d in seals/A seals/B seals-coe/A seals-coe/B; do echo "## $d"; python3 -I $RT/sealtab.py $d seal-runs $d.tsv; done | tee seal-summary.txt
for v in "seals-coe/A:GsProbe/KCA:controls-coe-A" "seals/A:GsProbe/KSA:controls-strict-A" "seals-coe/B:GsProbe/KCB:controls-coe-B" "seals/B:GsProbe/KSB:controls-strict-B"; do
  IFS=: read sd sub out <<< "$v"
  python3 -I $RT/mkctl_gsws.py $AT $sd $W $sub $out | tee $out.out
  python3 -I -c "import json,sys; [print(p['module']) for p in json.load(open('$out/controls-plan.json'))]" > probes/order-$out.txt
  python3 -I $RT/runfull.py $W probes/order-$out.txt $TR control-runs-$out
  python3 -I $RT/ctlcheck2.py $out/controls-plan.json control-runs-$out $out/ctlcheck.json | tee $out/ctlcheck.log
done
python3 -I $E/tools/logcount.py errors $E/probe-runs-1 > probes/errors-probe-runs-1.txt
for d in seal-runs control-runs-controls-coe-A control-runs-controls-strict-A control-runs-controls-coe-B control-runs-controls-strict-B; do echo "## $d"; python3 -I $E/tools/logcount.py errors $E/$d; done > probes/errors-seals-controls.txt
cat probes/errors-probe-runs-1.txt probes/errors-seals-controls.txt
# keep probe sources as evidence, then remove them from the export
mkdir -p probes/sources; cp -r $W/GsProbe probes/sources/; rm -r $W/GsProbe
