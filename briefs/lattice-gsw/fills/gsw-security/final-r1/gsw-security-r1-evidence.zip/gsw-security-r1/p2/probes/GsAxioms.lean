import Lean
import TCSlib.Cryptography.Hashing.SIS.Columns
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security

/-! gsw-security r1 maintainer review: axioms of the 6 targets and of every stored constant of the two
owned modules, and a dependency trace (constant closure through types and values, theorem bodies
included) listing every reached constant whose type or value mentions `sorryAx`. -/

set_option maxHeartbeats 0
set_option maxRecDepth 65536

#print axioms TCSlib.Cryptography.Hashing.SIS.hashColumns_eq_mul
#print axioms TCSlib.Cryptography.Hashing.SIS.distAdv_hashColumns_uniform_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.real_uniformKey_advantage
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.uniformKey_uniform_advantage_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.distAdv_encrypt_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.distAdv_encrypt_le_of_width

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let owners : List Name := [`TCSlib.Cryptography.Hashing.SIS.Columns,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security]
  let G := `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW
  let S := `TCSlib.Cryptography.Hashing.SIS
  let targets : List Name := [S ++ `hashColumns_eq_mul, S ++ `distAdv_hashColumns_uniform_le,
    G ++ `real_uniformKey_advantage, G ++ `uniformKey_uniform_advantage_le, G ++ `distAdv_encrypt_le,
    G ++ `distAdv_encrypt_le_of_width]
  let std : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut stored := 0
  let mut nonstd := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless owners.contains env.header.moduleNames[mi.toNat]! do continue
    stored := stored + 1
    let axs ← liftCoreM <| collectAxioms n
    let bad := axs.toList.filter (fun a => !std.contains a)
    if !bad.isEmpty then
      nonstd := nonstd + 1
      logInfo m!"GSREV-NONSTD {n} {bad}"
  logInfo m!"GSREV-STORED {stored} nonstandard={nonstd}"
  for t in targets do
    unless env.contains t do throwError "unknown target {t}"
    let mut visited : NameSet := {}
    let mut stack : Array Name := #[t]
    let mut sorried : Array Name := #[]
    let mut gsw : Array Name := #[]
    while !stack.isEmpty do
      let n := stack.back!
      stack := stack.pop
      if visited.contains n then continue
      visited := visited.insert n
      let some ci := env.find? n | continue
      if let some mi := env.getModuleIdxFor? n then
        let home := env.header.moduleNames[mi.toNat]!
        if (`TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW).isPrefixOf home &&
            home != `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security &&
            (ci matches .thmInfo _) then
          gsw := gsw.push n
      let uses := ci.type.getUsedConstants ++
        ((ci.value? (allowOpaque := true)).map (·.getUsedConstants)).getD #[]
      if uses.contains ``sorryAx then sorried := sorried.push n
      for u in uses do
        unless visited.contains u do stack := stack.push u
    logInfo m!"GSREV-TRACE {t} visited={visited.size} sorried={(sorried.qsort Name.lt).toList} gsw_core_theorems={(gsw.qsort Name.lt).toList}"
  logInfo m!"GSREV-EOF"
