"""mkctl_gsws.py (gsw-security r1 review): mkctl_seqzk.py (verbatim harness: archived build_seals.seal_command via
request_payload_adapter, ControlS/ControlU pairs, covering subset of the seal records) with gsw-security rows: the SIS hash
(hash_eq), hashColumns (hashColumns_apply), Regev.augmented (augmented_eq), Regev.hashParameters (its simps reader
hashParameters_dimension), Regev.extractionError (extractionError_eq), LWE.sample (sample_fst), LWE.decisionAdvantage
(decisionAdvantage_eq), GSW encrypt (encrypt_eq), GSW lift (lift_apply), acceptProb (acceptProb_def), distAdv (distAdv_def)
and the FinDist CoeFun instance (FinDist.coe_mk); namespace GswSecControls. Each negative is the bare rfl unfolding, each
positive the published reader. Original header follows.
mkctl_seqzk.py (seq-zk review): mkctl_canon.py with seq-zk rows (PolyExpr.eval, the FinDist CoeFun instance,
ZK / ZK_iff, StatZK / the approved StatZK_iff, Protocol.seqRep / its simps reader seqRep_verifierFirst, Composability.prefixProver (Phases helper) / prefixProver_coins) and namespace
SeqZKControls. Previously:
mkctl_canon.py (canonizer review): mkctl_scot.py with canonizer rows (PolyExpr.eval, the FinDist CoeFun instance,
Turing.unaryFin, Turing.oneTapeFormat and Turing.oneTapeMachineFormat with the two pre-approved readers as positives) and
namespace SeqZKControls. Previously: mkctl_scot.py (sc-ot review): mkctl_learning.py with sc-ot rows (PolyExpr.eval, the FinDist CoeFun
instance, NUPPT.layout, Strategy.encodeMsgs, otFunctionality, and the helper definitions OT.mask, OT.simSeg, OT.inA2,
OT.bobView, OT.hcBit, foreign to the later helpers and the owned file; each negative the rfl unfolding, each positive
its published reader) and namespace ScOtControls. Previously: mkctl_learning.py (learning-r1 review): mkctl_lamport.py with learning rows (PolyExpr.eval, FinDist.uniform, the FinDist
CoeFun instance, PAC.label, uprob, acceptProb, and the helper definitions LearnPRF.firstBit, tupleWord, learnerFn,
foreign to the later helpers and the owned file) and namespace LearningControls. Previously: mkctl_lamport.py (lamport review): mkctl_dlcrh.py with lamport rows (padFin, PolyExpr.eval, ProbComp.expect, ProbComp.sample, OracleComp.bind (the three names of the patch-4 opacity block), LamportFill.secretWord, LamportFill.signatureBlock, LamportMachine.u). Previously: mkctl_dlcrh.py (dl-crh review): mkctl_extnosrc.py with dl-crh rows (padFin, PolyExpr.eval, Authentication.splitBits, Candidates.expSampleRaw (new reader expSampleRaw_eq), FromDiscreteLog.modularDifference, FromDiscreteLog.residueFinEquiv). Previously: mkctl_extnosrc.py: mkctl_dlfolds.py with ext-nosrc rows (padFin, PolyExpr.eval, FinDist.uniform, the FinDist CoeFun instance, Rejection.mixture, Rejection.select). Previously: mkctl_dlfolds.py: mkctl_dl.py with the dl-folds rows (iterEmit, rAns, finA, cntRead, ansRead, coinBlock, fwdHandler, logEmit, chunkMap, PolyExpr.eval, padFin). Original: mkctl_dl.py (attempt 2: rU negative row is the bare unfolding `rU w = pairFstD (pairFstD w)`; attempt 1 used `rU (input ..) = 1^n`, not rfl-true unsealed): the nm-cca2 review mkctl.py (verbatim harness) with dl-consolidation rows B (head names: Games.castImpl,
FunFamily.blocks, EnsembleLemmas.padL, xorPerm, InteractiveHandler.rU, PK/SK indCodec, splitHalf, ChallengeSim.chRun,
plus padFin, zeroBits, PolyExpr.eval) and a covering subset of seal records (see below). Original header follows.
mkctl.py <archived-tools-dir> <seals-dir> <worktree> <probe-subdir> <outdir>
nm-cca2 review (attempt 3: PK indImpl row stated at the spec type, as in the pk-cpa-cca1 attempt 2): the pk-cpa-cca1 review mkctl.py with its own rows B (below; the generic pairEncode/padFin/zeroBits/simulate/
inLens/acDin/castImpl/seedIn/decAnswer/decOpen rows kept verbatim, plus PK outLens, PK indImpl, PolyExpr.eval, InteractiveHandler.finInput
and the NMCCA2 helper definitions fwdHandler, finU, logEmit, cntRead, decHandler, encHandler, guessBit), seal records Seal?_*.json
(A = PolyExpr.eval exempt, B = sealed) and namespace NmControls. Original header:
Sensitivity controls for the pk-cpa-cca1 review (the bitwise-cpa review's mkctl.py with the not-cca2 review's inLens/decAnswer/prfScheme rows
and rows for the PRFGame helper definitions (attempt 2: pkHState/pkSeedTapes rows dropped, indImpl row stated at the spec type), FixedLengthScheme.indImpl and decOpen appended to B; bitwise-cpa header follows:
B keeps every adaptive-cpa row and adds padCt, seedIn, coinBlock, blockState, PublicKeyScheme.padded, BitPublicKeyScheme.bitwise, and the
BitwiseSim rows qDin, qHandler, plantAns (foreign to BitwiseCPA.lean only); originally:
B keeps the pairEncode/padFin/zeroBits rows, the padded-cpa chRun/recAdvIn rows, and adds simulate, PK inLens and seven AdaptiveCPA rows), built like levin/final/tools/mkcontrols.py
(same archived harness: build_seals.seal_command via request_payload_adapter). For each whole-file
seal record Seal_<F>.json: ControlS_<F> imports F and installs F's exact request set, then body
readings (negative: must fail exactly once sealed) and published-reader positives; ControlU_<F> is
the same without the seal (all must pass). Bodies are chosen by which definitions F's request set
contains (see B)."""
import sys, json, importlib.util
from pathlib import Path
tools, sealdir, wt, sub, outdir = sys.argv[1:6]
sys.dont_write_bytecode = True
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bs = load(Path(tools) / 'build_seals.py', 'levin_bs'); controls = load(Path(tools) / 'build_controls.py', 'levin_controls')
adapter = load(Path(tools) / 'request_payload_adapter.py', 'levin_adapter'); adapter.configure_builders(bs, controls)
import os
CHUNK = int(os.environ.get('SEAL_CHUNK', '0'))
if CHUNK:
    _orig = bs.seal_command
    def _chunked(label, rows, *, end):
        if len(rows) <= CHUNK: return _orig(label, rows, end=end)
        return b''.join(_orig(f'{label}_part{i // CHUNK + 1}', rows[i:i + CHUNK], end=end) for i in range(0, len(rows), CHUNK))
    bs.seal_command = _chunked
FD = 'TCSlib.InformationTheory.FinDist'
C = 'TCSlib.Cryptography'
G = C + '.AdvancedEncryption.Homomorphic.GSW'
RG = C + '.Encryption.PublicKey.Regev'
def row(name, neg_body, pos_body):
    return [(name, True, neg_body), (name + "Reader", False, pos_body)]
SIS_BIND = (f"(P : {C}.SIS.Parameters)\n    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus))")
LWE_KEY = ("(pk : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n"
           "      (Fin P.samples → ZMod P.modulus))")
LWE_SEED = ("(r : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n"
            "      ((Fin P.dimension → ZMod P.modulus) × (Fin P.samples → χ.Coins)))")
GSW_ARGS = (f"(P : {G}.Parameters)\n    (pk : Matrix (Fin P.lwe.samples) (Fin P.lwe.dimension) (ZMod P.lwe.modulus) ×\n"
            "      (Fin P.lwe.samples → ZMod P.lwe.modulus))\n"
            f"    (μ : Bool) (R : Matrix (Fin P.lwe.samples) (Fin ({G}.Parameters.columns P)) Bool)")
GSW_RHS = (f"{RG}.augmented P.lwe pk * {G}.lift P R +\n"
           f"      (μ.toNat : ZMod P.lwe.modulus) • {G}.gadget P")
B = {
 C + '.Hashing.SIS.hash': row("ctlHash",
   f"theorem ctlHash {SIS_BIND} (x : Fin P.columns → Bool) :\n"
   f"    {C}.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) := rfl\n",
   f"theorem ctlHashReader {SIS_BIND} (x : Fin P.columns → Bool) :\n"
   f"    {C}.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) :=\n"
   f"  {C}.Hashing.SIS.hash_eq P A x\n"),
 C + '.Hashing.SIS.hashColumns': row("ctlHashColumns",
   f"theorem ctlHashColumns {SIS_BIND} (N : ℕ)\n    (R : Matrix (Fin P.columns) (Fin N) Bool) (i : Fin P.dimension) (j : Fin N) :\n"
   f"    {C}.Hashing.SIS.hashColumns P N A R i j = {C}.Hashing.SIS.hash P A (fun c => R c j) i := rfl\n",
   f"theorem ctlHashColumnsReader {SIS_BIND} (N : ℕ)\n    (R : Matrix (Fin P.columns) (Fin N) Bool) (i : Fin P.dimension) (j : Fin N) :\n"
   f"    {C}.Hashing.SIS.hashColumns P N A R i j = {C}.Hashing.SIS.hash P A (fun c => R c j) i :=\n"
   f"  {C}.Hashing.SIS.hashColumns_apply P N A R i j\n"),
 RG + '.augmented': row("ctlAugmented",
   f"theorem ctlAugmented (P : {C}.LWE.Parameters)\n    {LWE_KEY} :\n"
   f"    {RG}.augmented P pk = Fin.snoc pk.1.transpose pk.2 := rfl\n",
   f"theorem ctlAugmentedReader (P : {C}.LWE.Parameters)\n    {LWE_KEY} :\n"
   f"    {RG}.augmented P pk = Fin.snoc pk.1.transpose pk.2 :=\n  {RG}.augmented_eq P pk\n"),
 RG + '.hashParameters': row("ctlHashParameters",
   f"theorem ctlHashParameters (P : {C}.LWE.Parameters) :\n"
   f"    ({RG}.hashParameters P).dimension = P.dimension + 1 := rfl\n",
   f"theorem ctlHashParametersReader (P : {C}.LWE.Parameters) :\n"
   f"    ({RG}.hashParameters P).dimension = P.dimension + 1 :=\n  {RG}.hashParameters_dimension P\n"),
 RG + '.extractionError': row("ctlExtractionError",
   f"theorem ctlExtractionError (P : {C}.LWE.Parameters) :\n    {RG}.extractionError P =\n"
   f"      (1 / 2) * Real.sqrt ((P.modulus : ℝ) ^ (P.dimension + 1) / (2 : ℝ) ^ P.samples) := rfl\n",
   f"theorem ctlExtractionErrorReader (P : {C}.LWE.Parameters) :\n    {RG}.extractionError P =\n"
   f"      (1 / 2) * Real.sqrt ((P.modulus : ℝ) ^ (P.dimension + 1) / (2 : ℝ) ^ P.samples) :=\n"
   f"  {RG}.extractionError_eq P\n"),
 C + '.LWE.sample': row("ctlSample",
   f"theorem ctlSample (P : {C}.LWE.Parameters) (χ : {C}.LWE.Noise)\n    {LWE_SEED} :\n"
   f"    ({C}.LWE.sample P χ r).1 = r.1 := rfl\n",
   f"theorem ctlSampleReader (P : {C}.LWE.Parameters) (χ : {C}.LWE.Noise)\n    {LWE_SEED} :\n"
   f"    ({C}.LWE.sample P χ r).1 = r.1 :=\n  {C}.LWE.sample_fst P χ r\n"),
 C + '.LWE.decisionAdvantage': row("ctlDecisionAdvantage",
   f"theorem ctlDecisionAdvantage {{ρ : Type}} [Fintype ρ] [Nonempty ρ] (P : {C}.LWE.Parameters)\n"
   f"    (χ : {C}.LWE.Noise)\n    (D : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n"
   f"      (Fin P.samples → ZMod P.modulus)) → ρ → Bool) :\n"
   f"    {C}.LWE.decisionAdvantage P χ D = {C}.distAdv ({C}.LWE.sample P χ)\n"
   f"      (id : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n"
   f"        (Fin P.samples → ZMod P.modulus)) → _) D := rfl\n",
   f"theorem ctlDecisionAdvantageReader {{ρ : Type}} [Fintype ρ] [Nonempty ρ] (P : {C}.LWE.Parameters)\n"
   f"    (χ : {C}.LWE.Noise)\n    (D : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n"
   f"      (Fin P.samples → ZMod P.modulus)) → ρ → Bool) :\n"
   f"    {C}.LWE.decisionAdvantage P χ D = {C}.distAdv ({C}.LWE.sample P χ)\n"
   f"      (id : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×\n"
   f"        (Fin P.samples → ZMod P.modulus)) → _) D :=\n  {C}.LWE.decisionAdvantage_eq P χ D\n"),
 G + '.encrypt': row("ctlEncrypt",
   f"theorem ctlEncrypt {GSW_ARGS} :\n    {G}.encrypt P pk μ R =\n      {GSW_RHS} := rfl\n",
   f"theorem ctlEncryptReader {GSW_ARGS} :\n    {G}.encrypt P pk μ R =\n      {GSW_RHS} :=\n"
   f"  {G}.encrypt_eq P pk μ R\n"),
 G + '.lift': row("ctlLift",
   f"theorem ctlLift (P : {G}.Parameters) (X : Matrix (Fin 2) (Fin 3) Bool) (i : Fin 2) (j : Fin 3) :\n"
   f"    {G}.lift P X i j = ((X i j).toNat : ZMod P.lwe.modulus) := rfl\n",
   f"theorem ctlLiftReader (P : {G}.Parameters) (X : Matrix (Fin 2) (Fin 3) Bool) (i : Fin 2) (j : Fin 3) :\n"
   f"    {G}.lift P X i j = ((X i j).toNat : ZMod P.lwe.modulus) :=\n  {G}.lift_apply P X i j\n"),
 C + '.acceptProb': row("ctlAcceptProb",
   f"theorem ctlAcceptProb {{σ γ ρ : Type}} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :\n"
   f"    {C}.acceptProb X D = {C}.uprob fun z : σ × ρ => D (X z.1) z.2 = true := rfl\n",
   f"theorem ctlAcceptProbReader {{σ γ ρ : Type}} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :\n"
   f"    {C}.acceptProb X D = {C}.uprob fun z : σ × ρ => D (X z.1) z.2 = true :=\n"
   f"  {C}.acceptProb_def X D\n"),
 C + '.distAdv': row("ctlDistAdv",
   f"theorem ctlDistAdv {{σ τ γ ρ : Type}} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)\n"
   f"    (D : γ → ρ → Bool) :\n    {C}.distAdv X Y D = |{C}.acceptProb X D - {C}.acceptProb Y D| := rfl\n",
   f"theorem ctlDistAdvReader {{σ τ γ ρ : Type}} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)\n"
   f"    (D : γ → ρ → Bool) :\n    {C}.distAdv X Y D = |{C}.acceptProb X D - {C}.acceptProb Y D| :=\n"
   f"  {C}.distAdv_def X Y D\n"),
 FD + '.instCoeFunForallReal': row("ctlCoe",
   f"theorem ctlCoe {{α : Type}} [Fintype α] (p : {FD} α) (a : α) : p a = p.prob a := rfl\n",
   f"theorem ctlCoeReader {{α : Type}} [Fintype α] (f : α → ℝ) (h₁ : ∀ a, 0 ≤ f a) (h₂ : ∑ a, f a = 1) (a : α) :\n    (⟨f, h₁, h₂⟩ : {FD} α) a = f a := {FD}.coe_mk f h₁ h₂ a\n"),
}
OP = ''
def assemble(label, module, rows, bodies, sealed):
    src = (f"import Lean\nimport {module}\n\nset_option maxHeartbeats 0\nset_option autoImplicit false\n"
           "set_option relaxedAutoImplicit false\n\n").encode()
    if sealed: src += bs.seal_command(label, rows, end=False)
    src += b"namespace GswSecControls\n\n"
    expect = []
    for name, target, negative, body in bodies:
        start = src.count(b"\n") + 1
        src += body.encode() + b"\n"
        expect.append(dict(control=name, target=target, negative=negative, start_line=start,
                           end_line=start + body.count('\n') - 1))
    src += b"end GswSecControls\n\n"
    if sealed: src += bs.seal_command(label, rows, end=True)
    return src, expect
out = Path(outdir); out.mkdir(parents=True, exist_ok=True); plan = []
# dl-consolidation review: controls only for a covering subset of the seal records: for each target of B
# (and each variant letter), the seal record with the fewest requests whose request set contains it.
recs = [json.load(open(p)) for p in sorted(Path(sealdir).glob('Seal*_*.json'))]
chosen = {}
for t in B:
    for letter in sorted({r['label'].split('_')[0][-1] for r in recs}):
        c = [r for r in recs if r['label'].split('_')[0][-1] == letter and t in {x['spelling'] for x in r['rows']}]
        if c:
            r = min(c, key=lambda r: (len(r['rows']), r['label'])); chosen[r['label']] = r
print('chosen', sorted(chosen))
for rec in [chosen[k] for k in sorted(chosen)]:
    module = rec['module']; rows = rec['rows']
    have = {r['spelling'] for r in rows}
    bodies = [(n, t, neg, b) for t, lst in B.items() if t in have for (n, neg, b) in lst]
    for sealed in (True, False):
        lab = ('ControlS_' if sealed else 'ControlU_') + rec['label'][4:]  # nm-cca2: keep the A/B letter of 'SealA_'/'SealB_'
        src, expect = assemble(lab, module, rows, bodies, sealed)
        p = Path(wt) / sub / (lab + '.lean'); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(src)
        (out / (lab + '.lean.txt')).write_bytes(src)
        plan.append(dict(label=lab, module=f'{sub}/{lab}', owner=module, kind='own-seal', sealed=sealed,
                         requested=len(rows) if sealed else 0, controls=expect,
                         expected_errors=[e['start_line'] for e in expect if e['negative']] if sealed else []))
(out / 'controls-plan.json').write_text(json.dumps(plan, indent=1))
print(len(plan), 'control probes;', sum(len(p['expected_errors']) for p in plan), 'expected sealed failures')
