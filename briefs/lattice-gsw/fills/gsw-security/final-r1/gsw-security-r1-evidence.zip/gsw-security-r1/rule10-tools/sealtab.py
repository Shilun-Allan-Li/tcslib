#!/usr/bin/env python3
"""sealtab.py (gsw-security r1 review) <seal-records-dir> <rundir> <out.tsv>: per seal probe of <seal-records-dir>
(<label>.json from mkseals_*_gsws.py): module, requests, rc, `error:` and `error(` counts (G26-N1), the install record
(G06-SEAL label=) and the EOF record (G06-SEAL-END label=), and every error mapped back to its source line through the
record's source_to_probe_lines. Prints one row per probe."""
import json, os, re, sys
recdir, rd, out = sys.argv[1:4]
res = {}
for l in open(os.path.join(rd, 'results.jsonl')):
    x = json.loads(l)
    if 'module' in x: res[x['module']] = x
rows = []
for n in sorted(os.listdir(recdir)):
    if not n.endswith('.json') or n == 'manifest.json': continue
    r = json.load(open(os.path.join(recdir, n)))
    m = r['probe_module']
    if m not in res: rows.append((r['label'], r['module'], r['requested'], 'NOT-RUN', '', '', '', '', '')); continue
    log = open(os.path.join(rd, 'mods', m.replace('/', '_') + '.log'), encoding='utf-8', errors='replace').read()
    ec = [int(x.group(1)) for x in re.finditer(r'^\S+\.lean:(\d+):\d+: error:', log, re.M)]
    ep = [int(x.group(1)) for x in re.finditer(r'^\S+\.lean:(\d+):\d+: error\(', log, re.M)]
    p2s = {d['probe_line']: d['source_line'] for d in r['source_to_probe_lines']}
    src = [f'probe:{e}/src:{p2s.get(e)}' for e in sorted(ec + ep)]
    inst = ('G06-SEAL label=' + r['label']) in log
    eof = ('G06-SEAL-END label=' + r['label']) in log
    rows.append((r['label'], r['module'], r['requested'], res[m]['rc'], len(ec), len(ep), int(inst), int(eof), ','.join(src)))
with open(out, 'w') as f:
    f.write('label\tmodule\trequests\trc\terror_colon\terror_paren\tinstall\teof\terrors_at\n')
    for x in rows: f.write('\t'.join(map(str, x)) + '\n')
for x in rows: print('\t'.join(map(str, x)))
