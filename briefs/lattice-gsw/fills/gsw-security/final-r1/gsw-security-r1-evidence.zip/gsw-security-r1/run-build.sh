#!/usr/bin/env bash
# gsw-security r1 review, Phase 2 build (M2 = tip e2f5850f x a9f97edd): the 650-module queue through runner.py
# (scripts/lean_check_tree.sh, one Lean process, TCSLIB_OLEANS=dl-oleans-2), detached.
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
cd $SP/dl-review/gsw-security-r1
echo "start $(date -u +%FT%TZ)"
python3 -I tools-used/review/runner.py $SP/wt-gsws-x plan/queue.txt $SP/dl-oleans-2 build
rc=$?
echo "runner exit $rc $(date -u +%FT%TZ)"
echo $rc > build/runner-rc.txt
