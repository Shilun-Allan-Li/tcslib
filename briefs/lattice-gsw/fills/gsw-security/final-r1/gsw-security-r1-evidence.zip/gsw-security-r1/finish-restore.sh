#!/usr/bin/env bash
# gsw-security r1 review: restore dl-oleans-2 to the base snapshot 457ba704... after the build and the probes.
# First make sure no Lean process of this job runs (cat build/current.pid, probe-runs*/current.pid; ps).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/gsw-security-r1
T=$SP/dl-oleans-2; BK=$SP/dl-gsws-backup
bash $E/tools-used/restore_gsws.sh $T $BK $E
python3 -I $E/tools-used/restoreplan.py $T $E/tree/snapshot-pre.txt $E/order/order.txt $E/restore/verify-nodelete > $E/restore/verify-nodelete.out; cat $E/restore/verify-nodelete.out
python3 -I $E/tools-used/review/snapshot.py $T $E/restore/snapshot-recheck.txt > $E/restore/snapshot-recheck.out; cat $E/restore/snapshot-recheck.out
cmp $E/tree/snapshot-pre.txt $E/restore/snapshot-recheck.txt && echo "RECHECK EQUAL"
sha256sum $E/tree/snapshot-pre.txt $E/tree/snapshot-post.txt $E/restore/snapshot-recheck.txt | tee $E/restore/snapshot-hashes.txt
# then, if SNAPSHOT EQUAL and verify-nodelete reports extra 0 / changed 0 / missing 0: rm -r "${BK:?}"
