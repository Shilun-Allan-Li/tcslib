#!/usr/bin/env bash
# gsw-security r1 review, Phase 2 post-build steps (after build/runner-rc.txt reads 0; before the probes and the restore).
# No Lean process. Reads the tree; writes only under this evidence directory.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad; E=$SP/dl-review/gsw-security-r1
R=/home/user/tcslib; TR=$SP/dl-oleans-2
M2=a51294c525a060598fe06d7aa83b2c660af8f4f2; TIP=e2f5850fcd1b38738f7ad2f2cd413c840803ef90
cd $E
python3 -I tools-used/permod.py build build/per-module.tsv > build/permod.out; tail -3 build/permod.out
python3 -I tools-used/review/buildsum.py build/results.jsonl > build/buildsum.txt; head -1 build/buildsum.txt
cp state/state.json state/state-before-m2.json
python3 -I tools-used/stateplan.py update $R $M2 state/state.json build/results.jsonl $TR | tee build/state-update.out
cp state/state.json state/state-after-m2.json
python3 -I tools-used/stateplan.py check $R $M2 order/order.txt state/state.json $TR build/statecheck.txt; tail -1 build/statecheck.txt
mkdir -p records tree-final admissions
cat refs/base-records-from-int-317.jsonl build/results.jsonl > records/records-final.jsonl
python3 -I tools-used/treecheck_ml.py $TR order/order.txt records/records-final.jsonl $R $M2 tree-final/snapshot-M2.txt > tree-final/tree-check-M2.txt; cat tree-final/tree-check-M2.txt
python3 -I tools-used/tipcensus.py $R $TIP admissions/census-tip-e2f5850f.txt base=refs/base-records-from-int-317.jsonl int331=refs/int331-records-final.jsonl intx=refs/intx-build-x1-results.jsonl g39=refs/g39-records-final-b.jsonl this=build/results.jsonl
python3 -I tools-used/tipcensus.py $R $M2 admissions/census-M2-a51294c5.txt base=refs/base-records-from-int-317.jsonl int331=refs/int331-records-final.jsonl intx=refs/intx-build-x1-results.jsonl g39=refs/g39-records-final-b.jsonl this=build/results.jsonl
diff <(grep -v TOTAL admissions/census-tip-e2f5850f.txt | sed 's/  \[.*//') <(grep -v TOTAL admissions/census-M2-a51294c5.txt | sed 's/  \[.*//') > admissions/census-tip-vs-M2.diff; cat admissions/census-tip-vs-M2.diff
python3 -I tools-used/refunion2.py build/results.jsonl build/refunion int317-base=refs/base-records-from-int-317.jsonl int331-records-final=refs/int331-records-final.jsonl intx-x1=refs/intx-build-x1-results.jsonl g39-final-b=refs/g39-records-final-b.jsonl int331-b2=refs/int331-build-2-results.jsonl int331-b3=refs/int331-build-3-results.jsonl > build/refunion.txt; tail -3 build/refunion.txt
python3 -I tools-used/logcheck.py build/results.jsonl build/logcheck.txt base=refs/base-records-from-int-317.jsonl int331=refs/int331-records-final.jsonl intx=refs/intx-build-x1-results.jsonl g39=refs/g39-records-final-b.jsonl int331-b2=refs/int331-build-2-results.jsonl; tail -2 build/logcheck.txt
echo "zero-byte files under the tree: $(find $TR -type f -size 0 | wc -l)" | tee tree-final/zero-byte-files.txt; find $TR -type f -size 0 >> tree-final/zero-byte-files.txt
