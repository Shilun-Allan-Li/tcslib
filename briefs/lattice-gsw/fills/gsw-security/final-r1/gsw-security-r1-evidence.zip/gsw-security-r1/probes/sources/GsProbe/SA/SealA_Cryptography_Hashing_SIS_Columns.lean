/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import Lean
import TCSlib.Cryptography.Hashing.SIS.Universality
import TCSlib.Cryptography.Foundations.Probability
import TCSlib.Cryptography.Pseudorandom.Indistinguishability
/- G06-HARNESS INSTALL SealA_Cryptography_Hashing_SIS_Columns -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_Hashing_SIS_Columns"
  let payload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.Hashing.SIS.hash\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.SIS.IsSolution\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.acceptProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.copies\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.distAdv\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.invProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.mixDist\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyAvgRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyHybrid\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.predProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.pushSampler\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.sunglassRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.uexp\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.Cryptography.uprob\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.InformationTheory.FinDist.HasMinEntropy\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_1\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_inst\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.collision\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.map\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.probTrue\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.prod\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.uniform\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.IsUniversal\tTCSlib.InformationTheory.UniversalHashing\nTCSlib.InformationTheory.hashPair\tTCSlib.InformationTheory.LeftoverHash\nTCSlib.InformationTheory.statDist\tTCSlib.InformationTheory.StatisticalDistance"
  let expectedRequests : Nat := 32
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"collisionDifference\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Hashing.SIS.hash\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"hash\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.IsSolution\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"IsSolution\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.acceptProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"acceptProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.copies\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"copies\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.distAdv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"distAdv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.invProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"invProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.mixDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"mixDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyAvgRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyAvgRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyHybrid\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyHybrid\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.predProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"predProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.pushSampler\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"pushSampler\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.sunglassRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"sunglassRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uexp\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uexp\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uprob\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uprob\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.HasMinEntropy\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"HasMinEntropy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.collision\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"collision\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"instCoeFunForallReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.map\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"map\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.probTrue\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"probTrue\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.prod\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"prod\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.uniform\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"uniform\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.IsUniversal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"IsUniversal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"UniversalHashing\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.hashPair\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"hashPair\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"LeftoverHash\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.statDist\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"statDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"StatisticalDistance\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"


set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Leftover hashing of many independent columns under one public matrix

## Main definitions

* `hashColumns`: hash `N` independent binary columns with the same matrix, `A ↦ A R`.

## Main results

* `distAdv_hashColumns_uniform_le`: `(A, A R)` is within `N` times the single-column
  leftover-hash error of `(A, U)` with `U` uniform.

## References

* [Pei16] C. Peikert, *A Decade of Lattice Cryptography*, author version dated
  17 February 2016, Section 5.2.1 (leftover hashing in Regev encryption) and Section 6.1.3
  ("`[Ā | ĀR]` is very close to uniformly distributed").
* [GSW13] C. Gentry, A. Sahai, B. Waters, CRYPTO 2013; author version dated 8 June 2013,
  Section 3.2, Lemma 1 (`(A, R·A)` close to uniform).
* [Vad12] S. Vadhan, *Pseudorandomness*, 2012, Theorem 6.18.

The bound is a column-by-column hybrid over the existing single-column
`distAdv_hash_uniform_le`. It is not a matrix leftover-hash lemma: the family `R ↦ A R` is not
universal on whole matrices, and no such claim is made. No SIS hardness is used.
-/

namespace TCSlib.Cryptography.Hashing.SIS

open TCSlib.Cryptography.SIS (Parameters)

/-- Hash `N` binary columns with one matrix: column `j` of `hashColumns P N A R` is
`hash P A (R · j)`, so `hashColumns P N A R = A R` modulo `q` [Pei16, Section 6.1.3, `ĀR`]. -/
def hashColumns (P : Parameters) (N : ℕ)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus))
    (R : Matrix (Fin P.columns) (Fin N) Bool) :
    Matrix (Fin P.dimension) (Fin N) (ZMod P.modulus) :=
  fun i j => hash P A (fun c => R c j) i

/-- Entry `(i,j)` of `hashColumns P N A R` is coordinate `i` of the hash of column `j`. -/
theorem hashColumns_apply (P : Parameters) (N : ℕ)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus))
    (R : Matrix (Fin P.columns) (Fin N) Bool) (i : Fin P.dimension) (j : Fin N) :
    hashColumns P N A R i j = hash P A (fun c => R c j) i := rfl

/-- `hashColumns` is matrix multiplication by the `{0,1}` lift of `R`.

**Proof sketch.** Entrywise: by `hashColumns_apply`, `hash_eq` and `Matrix.mul_apply'` both
sides are the same dot product of row `i` of `A` with the lifted column `j` of `R`. -/
theorem hashColumns_eq_mul (P : Parameters) (N : ℕ)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus))
    (R : Matrix (Fin P.columns) (Fin N) Bool) :
    hashColumns P N A R = A * Matrix.of fun c j => ((R c j).toNat : ZMod P.modulus) := by
  ext i j
  rw [hashColumns_apply, hash_eq, Matrix.mul_apply']
  rfl

/-- **Column hybrid for leftover hashing** [GSW13, Section 3.2, Lemma 1, statistical half;
Pei16, Section 6.1.3]: any independently randomized test distinguishes `(A, A R)` from a
uniform `(A, U)`, for uniform `A` and uniform binary `R` with `N` columns, with advantage at
most `N` times the single-column error `½·√(q^{dimension}/2^{columns})`.

**Proof sketch.** Hybrid `H_k`, on seeds `(A, (x, u))` with binary columns `x j` and uniform
columns `u j`: column `j` of the second component is `u j` for `j < k` and `hash A (x j)`
otherwise, all under the same `A`. The `k`-th test plants its challenge column at `k`,
simulates the other columns from coins `(x, u)` carried beside `D`'s own coins (a product of
finite nonempty types), and runs `D`. By `acceptProb_bind`, a seed relabelling
(`acceptProb_comp_equiv`) and `acceptProb_update`, it accepts `(A, hash A r)` exactly as `D`
accepts `H_k`, and a uniform `(A, y)` exactly as `D` accepts `H_{k+1}`. `H_0` is the real
sampler and `H_N` the ideal one after transposing the seeds and dropping the unused columns
(`acceptProb_comp_equiv`, `acceptProb_fst`). `abs_sub_le_sum_hybrids` bounds the end-to-end
gap by the `N` neighbouring gaps, each at most the single-column error by
`distAdv_hash_uniform_le`. At `N = 0` the sum is empty. -/
theorem distAdv_hashColumns_uniform_le {ρ : Type*} [Fintype ρ] [Nonempty ρ]
    (P : Parameters) (N : ℕ)
    (D : (Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus) ×
      Matrix (Fin P.dimension) (Fin N) (ZMod P.modulus)) → ρ → Bool) :
    distAdv (fun r : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus) ×
        Matrix (Fin P.columns) (Fin N) Bool => (r.1, hashColumns P N r.1 r.2))
      (id : (Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus) ×
        Matrix (Fin P.dimension) (Fin N) (ZMod P.modulus)) → _) D ≤
      N * ((1 / 2) * Real.sqrt ((P.modulus : ℝ) ^ P.dimension / (2 : ℝ) ^ P.columns)) := by
  classical
  let Key := Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)
  let In := Fin P.columns → Bool
  let Out := Fin P.dimension → ZMod P.modulus
  let Mat := Matrix (Fin P.dimension) (Fin N) (ZMod P.modulus)
  let Cols := (Fin N → In) × (Fin N → Out)
  -- Hybrid `k`: columns `j < k` are uniform, the others hash binary columns under `A`.
  let hyb (k : ℕ) (s : Key × Cols) : Key × Mat :=
    (s.1, Matrix.of fun i j => if (j : ℕ) < k then s.2.2 j i else hash P s.1 (s.2.1 j) i)
  -- The `k`-th test plants its challenge at column `k` and simulates the other columns.
  let plant (k : ℕ) (z : Key × Out) (c : Cols) : Key × Mat :=
    (z.1, Matrix.of fun i j => if (j : ℕ) < k then c.2 j i else if (j : ℕ) = k then z.2 i
      else hash P z.1 (c.1 j) i)
  let test (k : ℕ) (z : Key × Out) (c : Cols × ρ) : Bool := D (plant k z c.1) c.2
  -- Step 1: on a real challenge, the `k`-th test runs `D` on hybrid `k`.
  have hleft (k : ℕ) (hk : k < N) :
      acceptProb (fun r : Key × In => (r.1, hash P r.1 r.2)) (test k) =
        acceptProb (hyb k) D := by
    let e : (Key × In) × Cols ≃ In × ((Fin N → In) × (Key × (Fin N → Out))) :=
      ⟨fun w => (w.1.2, (w.2.1, (w.1.1, w.2.2))), fun v => ((v.2.2.1, v.1), (v.2.1, v.2.2.2)),
        fun _ => rfl, fun _ => rfl⟩
    let e' : (Fin N → In) × (Key × (Fin N → Out)) ≃ Key × Cols :=
      ⟨fun v => (v.2.1, (v.1, v.2.2)), fun s => (s.2.1, (s.1, s.2.2)), fun _ => rfl, fun _ => rfl⟩
    refine (acceptProb_bind _ (plant k) D).trans (Eq.trans ?_
      ((acceptProb_comp_equiv e
        (fun w => hyb k (e' (Function.update w.2.1 ⟨k, hk⟩ w.1, w.2.2))) D).trans
      ((acceptProb_update (ρ := ρ) (⟨k, hk⟩ : Fin N) (fun c v => hyb k (e' (c, v))) D).trans
        (acceptProb_comp_equiv e' (hyb k) D))))
    refine congrArg (fun X => acceptProb X D) ?_
    funext w
    refine Prod.ext rfl ?_
    ext i j
    simp only [plant, hyb, e, e', Equiv.coe_fn_mk, Matrix.of_apply]
    by_cases hj : (j : ℕ) = k
    · obtain rfl : j = ⟨k, hk⟩ := Fin.ext hj
      simp only [lt_irrefl, if_false, if_true, Function.update_self]
    · have hne : j ≠ ⟨k, hk⟩ := fun h => hj (congrArg Fin.val h)
      simp only [hj, if_false, Function.update_of_ne hne]
  -- Step 2: on a uniform challenge, the `k`-th test runs `D` on hybrid `k + 1`.
  have hright (k : ℕ) (hk : k < N) :
      acceptProb (id : Key × Out → Key × Out) (test k) = acceptProb (hyb (k + 1)) D := by
    let e : (Key × Out) × Cols ≃ Out × ((Fin N → Out) × (Key × (Fin N → In))) :=
      ⟨fun w => (w.1.2, (w.2.2, (w.1.1, w.2.1))), fun v => ((v.2.2.1, v.1), (v.2.2.2, v.2.1)),
        fun _ => rfl, fun _ => rfl⟩
    let e' : (Fin N → Out) × (Key × (Fin N → In)) ≃ Key × Cols :=
      ⟨fun v => (v.2.1, (v.2.2, v.1)), fun s => (s.2.2, (s.1, s.2.1)), fun _ => rfl, fun _ => rfl⟩
    refine (acceptProb_bind _ (plant k) D).trans (Eq.trans ?_
      ((acceptProb_comp_equiv e
        (fun w => hyb (k + 1) (e' (Function.update w.2.1 ⟨k, hk⟩ w.1, w.2.2))) D).trans
      ((acceptProb_update (ρ := ρ) (⟨k, hk⟩ : Fin N) (fun c v => hyb (k + 1) (e' (c, v))) D).trans
        (acceptProb_comp_equiv e' (hyb (k + 1)) D))))
    refine congrArg (fun X => acceptProb X D) ?_
    funext w
    refine Prod.ext rfl ?_
    ext i j
    simp only [plant, hyb, e, e', Equiv.coe_fn_mk, Matrix.of_apply, id_eq]
    rcases lt_trichotomy (j : ℕ) k with h | h | h
    · have hne : j ≠ ⟨k, hk⟩ := fun h' => h.ne (congrArg Fin.val h')
      simp only [h, Nat.lt_succ_of_lt h, if_true, Function.update_of_ne hne]
    · obtain rfl : j = ⟨k, hk⟩ := Fin.ext h
      simp only [lt_irrefl, Nat.lt_succ_self, if_false, if_true, Function.update_self]
    · have hne : j ≠ ⟨k, hk⟩ := fun h' => h.ne' (congrArg Fin.val h')
      simp only [not_lt.mpr h.le, not_lt.mpr (Nat.succ_le_of_lt h), h.ne', if_false]
  -- Step 3: hybrid `0` is the real sampler and hybrid `N` the ideal one, after relabelling.
  have hzero : acceptProb (fun r : Key × Matrix (Fin P.columns) (Fin N) Bool =>
      (r.1, hashColumns P N r.1 r.2)) D = acceptProb (hyb 0) D := by
    let e : Key × Cols ≃ (Key × Matrix (Fin P.columns) (Fin N) Bool) × (Fin N → Out) :=
      ⟨fun s => ((s.1, fun c j => s.2.1 j c), s.2.2), fun t => (t.1.1, (fun j c => t.1.2 c j, t.2)),
        fun _ => rfl, fun _ => rfl⟩
    refine (acceptProb_fst (τ := Fin N → Out) _ D).symm.trans (Eq.trans
      (acceptProb_comp_equiv e (fun t => (t.1.1, hashColumns P N t.1.1 t.1.2)) D).symm ?_)
    refine congrArg (fun X => acceptProb X D) ?_
    funext s
    refine Prod.ext rfl ?_
    ext i j
    simp only [hyb, e, Equiv.coe_fn_mk, Matrix.of_apply, hashColumns_apply, Nat.not_lt_zero,
      if_false]
  have hfull : acceptProb (id : Key × Mat → Key × Mat) D = acceptProb (hyb N) D := by
    let e : Key × Cols ≃ (Key × Mat) × (Fin N → In) :=
      ⟨fun s => ((s.1, Matrix.of fun i j => s.2.2 j i), s.2.1),
        fun t => (t.1.1, (t.2, fun j i => t.1.2 i j)), fun _ => rfl, fun _ => rfl⟩
    refine (acceptProb_fst (τ := Fin N → In) _ D).symm.trans (Eq.trans
      (acceptProb_comp_equiv e (fun t => id t.1) D).symm ?_)
    refine congrArg (fun X => acceptProb X D) ?_
    funext s
    refine Prod.ext rfl ?_
    ext i j
    simp only [hyb, e, Equiv.coe_fn_mk, Matrix.of_apply, id_eq, j.isLt, if_true]
  -- Step 4: telescope the neighbouring gaps and bound each by the single-column lemma.
  have hgap (k : ℕ) (hk : k ∈ Finset.range N) :
      |acceptProb (hyb k) D - acceptProb (hyb (k + 1)) D| ≤
        (1 / 2) * Real.sqrt ((P.modulus : ℝ) ^ P.dimension / (2 : ℝ) ^ P.columns) := by
    have h := distAdv_hash_uniform_le P (test k)
    rwa [distAdv_def, hleft k (Finset.mem_range.1 hk), hright k (Finset.mem_range.1 hk)] at h
  rw [distAdv_def, hzero, hfull]
  refine (abs_sub_le_sum_hybrids (fun k => acceptProb (hyb k) D) N).trans
    ((Finset.sum_le_sum hgap).trans_eq ?_)
  rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]

end TCSlib.Cryptography.Hashing.SIS
/- G06-HARNESS EOF-VERIFY SealA_Cryptography_Hashing_SIS_Columns -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "SealA_Cryptography_Hashing_SIS_Columns"
  let payload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.Hashing.SIS.hash\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.SIS.IsSolution\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.acceptProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.copies\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.distAdv\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.invProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.mixDist\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyAvgRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyHybrid\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.predProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.pushSampler\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.sunglassRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.uexp\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.Cryptography.uprob\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.InformationTheory.FinDist.HasMinEntropy\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_1\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_inst\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.collision\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.map\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.probTrue\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.prod\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.uniform\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.IsUniversal\tTCSlib.InformationTheory.UniversalHashing\nTCSlib.InformationTheory.hashPair\tTCSlib.InformationTheory.LeftoverHash\nTCSlib.InformationTheory.statDist\tTCSlib.InformationTheory.StatisticalDistance"
  let expectedRequests : Nat := 32
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"collisionDifference\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Hashing.SIS.hash\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"hash\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.IsSolution\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"IsSolution\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.acceptProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"acceptProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.copies\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"copies\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.distAdv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"distAdv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.invProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"invProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.mixDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"mixDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyAvgRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyAvgRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyHybrid\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyHybrid\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.predProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"predProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.pushSampler\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"pushSampler\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.sunglassRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"sunglassRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uexp\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uexp\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uprob\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uprob\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.HasMinEntropy\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"HasMinEntropy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.collision\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"collision\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"instCoeFunForallReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.map\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"map\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.probTrue\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"probTrue\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.prod\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"prod\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.uniform\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"uniform\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.IsUniversal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"IsUniversal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"UniversalHashing\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.hashPair\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"hashPair\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"LeftoverHash\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.statDist\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"statDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"StatisticalDistance\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

