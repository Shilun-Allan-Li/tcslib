import Lean
import TCSlib.Cryptography.Hashing.SIS.Columns

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace GswSecControls

theorem ctlHash (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (x : Fin P.columns → Bool) :
    TCSlib.Cryptography.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) := rfl

theorem ctlHashReader (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (x : Fin P.columns → Bool) :
    TCSlib.Cryptography.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) :=
  TCSlib.Cryptography.Hashing.SIS.hash_eq P A x

theorem ctlAcceptProb {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :
    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true := rfl

theorem ctlAcceptProbReader {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :
    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true :=
  TCSlib.Cryptography.acceptProb_def X D

theorem ctlDistAdv {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) :
    TCSlib.Cryptography.distAdv X Y D = |TCSlib.Cryptography.acceptProb X D - TCSlib.Cryptography.acceptProb Y D| := rfl

theorem ctlDistAdvReader {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) :
    TCSlib.Cryptography.distAdv X Y D = |TCSlib.Cryptography.acceptProb X D - TCSlib.Cryptography.acceptProb Y D| :=
  TCSlib.Cryptography.distAdv_def X Y D

theorem ctlCoe {α : Type} [Fintype α] (p : TCSlib.InformationTheory.FinDist α) (a : α) : p a = p.prob a := rfl

theorem ctlCoeReader {α : Type} [Fintype α] (f : α → ℝ) (h₁ : ∀ a, 0 ≤ f a) (h₂ : ∑ a, f a = 1) (a : α) :
    (⟨f, h₁, h₂⟩ : TCSlib.InformationTheory.FinDist α) a = f a := TCSlib.InformationTheory.FinDist.coe_mk f h₁ h₂ a

end GswSecControls

