import Lean
import TCSlib.Cryptography.Hashing.SIS.Columns

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

/- G06-HARNESS INSTALL ControlS_B_Cryptography_Hashing_SIS_Columns -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "ControlS_B_Cryptography_Hashing_SIS_Columns"
  let payload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.Hashing.SIS.hash\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.SIS.IsSolution\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.acceptProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.copies\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.distAdv\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.invProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.mixDist\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyAvgRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyHybrid\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.predProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.pushSampler\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.sunglassRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.uexp\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.Cryptography.uprob\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.InformationTheory.FinDist.HasMinEntropy\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_1\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_inst\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.collision\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.map\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.probTrue\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.prod\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.uniform\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.IsUniversal\tTCSlib.InformationTheory.UniversalHashing\nTCSlib.InformationTheory.hashPair\tTCSlib.InformationTheory.LeftoverHash\nTCSlib.InformationTheory.statDist\tTCSlib.InformationTheory.StatisticalDistance"
  let expectedRequests : Nat := 32
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"collisionDifference\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Hashing.SIS.hash\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"hash\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.IsSolution\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"IsSolution\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.acceptProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"acceptProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.copies\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"copies\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.distAdv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"distAdv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.invProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"invProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.mixDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"mixDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyAvgRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyAvgRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyHybrid\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyHybrid\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.predProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"predProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.pushSampler\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"pushSampler\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.sunglassRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"sunglassRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uexp\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uexp\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uprob\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uprob\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.HasMinEntropy\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"HasMinEntropy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.collision\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"collision\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"instCoeFunForallReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.map\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"map\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.probTrue\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"probTrue\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.prod\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"prod\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.uniform\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"uniform\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.IsUniversal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"IsUniversal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"UniversalHashing\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.hashPair\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"hashPair\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"LeftoverHash\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.statDist\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"statDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"StatisticalDistance\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut resolved : Array Lean.Name := #[]
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  let mut active : Nat := 0
  let mut already : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=install spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let before ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    if before == .irreducible then
      already := already + 1
    else
      let id := Lean.mkIdent n
      Lean.Elab.Command.elabCommand (← `(command| attribute [local irreducible] $id:ident))
      active := active + 1
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed for {spelling}"
    resolved := resolved.push n
    verified := verified + 1
    Lean.logInfo m!"G06-NAME label={label} spelling={spelling} actual={n.toString} home={home} before={repr before} installed={repr installed}"
  unless active + already == requests.size do throwError "G06-HARNESS {label}: installation count mismatch"
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  let maskExt := Lean.Meta.globalInstanceExtension
  let maskEnv ← Lean.getEnv
  let scopes := maskExt.ext.getState maskEnv
  unless scopes.stateStack.length == 1 do
    throwError "G06-HARNESS {label}: unfolding mask requires base scope"
  let mut scopedNames : Std.HashSet Lean.Name := {}
  for (_, payloads) in scopes.scopedEntries.map.toList do
    for n in payloads do
      scopedNames := scopedNames.insert n
  let mut removed : Nat := 0
  for n in resolved do
    if scopedNames.contains n then
      throwError "G06-HARNESS {label}: scoped unfolding payload intersects request {n}"
    if Lean.Meta.isGlobalInstance maskEnv n then
      removed := removed + 1
  -- InstanceEntry's BEq checks only val, so compare every field explicitly.
  let entryFields (e : Lean.Meta.InstanceEntry) :=
    (e.keys, Lean.ExprStructEq.mk e.val, e.priority, e.globalName?, e.synthOrder, e.attrKind)
  let lookupSnapshot (e : Lean.Environment) :=
    let s := Lean.Meta.instanceExtension.getState e
    (s.discrTree.toArray.map (fun (ks, entry) => (ks, entryFields entry)),
      s.instanceNames.toArray.map (fun (n, entry) => (n, entryFields entry)), s.erased.toList)
  let beforeLookup := lookupSnapshot env
  Lean.modifyEnv fun current =>
    maskExt.modifyState current fun membership =>
      resolved.foldl (fun s n => s.erase n) membership
  let maskedEnv ← Lean.getEnv
  unless beforeLookup == lookupSnapshot maskedEnv do
    throwError "G06-HARNESS {label}: typeclass lookup state changed"
  for n in resolved do
    if Lean.Meta.isGlobalInstance maskedEnv n then
      throwError "G06-HARNESS {label}: unfolding membership after mask for {n}"
  Lean.logInfo m!"G06-MASK label={label} phase=install requested={requests.size} verified={resolved.size} removed={removed} scope_depth=1 scoped_names={scopedNames.size} tc_state=preserved"
  Lean.logInfo m!"G06-SEAL label={label} requested={requests.size} active={active} already_irreducible={already} verified={verified}"

namespace GswSecControls

theorem ctlHash (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (x : Fin P.columns → Bool) :
    TCSlib.Cryptography.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) := rfl

theorem ctlHashReader (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (x : Fin P.columns → Bool) :
    TCSlib.Cryptography.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) :=
  TCSlib.Cryptography.Hashing.SIS.hash_eq P A x

theorem ctlAcceptProb {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :
    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true := rfl

theorem ctlAcceptProbReader {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :
    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true :=
  TCSlib.Cryptography.acceptProb_def X D

theorem ctlDistAdv {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) :
    TCSlib.Cryptography.distAdv X Y D = |TCSlib.Cryptography.acceptProb X D - TCSlib.Cryptography.acceptProb Y D| := rfl

theorem ctlDistAdvReader {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) :
    TCSlib.Cryptography.distAdv X Y D = |TCSlib.Cryptography.acceptProb X D - TCSlib.Cryptography.acceptProb Y D| :=
  TCSlib.Cryptography.distAdv_def X Y D

theorem ctlCoe {α : Type} [Fintype α] (p : TCSlib.InformationTheory.FinDist α) (a : α) : p a = p.prob a := rfl

theorem ctlCoeReader {α : Type} [Fintype α] (f : α → ℝ) (h₁ : ∀ a, 0 ≤ f a) (h₂ : ∑ a, f a = 1) (a : α) :
    (⟨f, h₁, h₂⟩ : TCSlib.InformationTheory.FinDist α) a = f a := TCSlib.InformationTheory.FinDist.coe_mk f h₁ h₂ a

end GswSecControls

/- G06-HARNESS EOF-VERIFY ControlS_B_Cryptography_Hashing_SIS_Columns -/
set_option maxHeartbeats 0
run_cmd do
  let label : String := "ControlS_B_Cryptography_Hashing_SIS_Columns"
  let payload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.Hashing.SIS.hash\tTCSlib.Cryptography.Hashing.SIS.Basic\nTCSlib.Cryptography.SIS.IsSolution\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\tTCSlib.Cryptography.SIS.Basic\nTCSlib.Cryptography.acceptProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.copies\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.distAdv\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.invProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.mixDist\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyAvgRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyHybrid\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.multicopyRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.predProb\tTCSlib.Cryptography.Foundations.Experiments\nTCSlib.Cryptography.pushSampler\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.sunglassRed\tTCSlib.Cryptography.Pseudorandom.Indistinguishability\nTCSlib.Cryptography.uexp\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.Cryptography.uprob\tTCSlib.Cryptography.Foundations.Probability\nTCSlib.InformationTheory.FinDist.HasMinEntropy\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_1\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist._sizeOf_inst\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.collision\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.map\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.probTrue\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.prod\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.FinDist.uniform\tTCSlib.InformationTheory.FinDist\nTCSlib.InformationTheory.IsUniversal\tTCSlib.InformationTheory.UniversalHashing\nTCSlib.InformationTheory.hashPair\tTCSlib.InformationTheory.LeftoverHash\nTCSlib.InformationTheory.statDist\tTCSlib.InformationTheory.StatisticalDistance"
  let expectedRequests : Nat := 32
  let mut requests : Array (String × String) := #[]
  let payloadLines := if payload.isEmpty then [] else payload.splitOn "\n"
  for line in payloadLines do
    match line.splitOn "\t" with
    | [spelling, home] =>
      unless !spelling.isEmpty && !home.isEmpty do throwError "G06-HARNESS {label}: empty request field"
      requests := requests.push (spelling, home)
    | _ => throwError "G06-HARNESS {label}: malformed serialized request row"
  unless requests.size == expectedRequests do throwError "G06-HARNESS {label}: serialized request count differs: {requests.size} vs {expectedRequests}"
  let rec nameParts : Lean.Name → List (String × String)
    | .anonymous => []
    | .str p s => nameParts p ++ [("str", s)]
    | .num p n => nameParts p ++ [("num", toString n)]
  let nameKey (n : Lean.Name) : String := (Lean.toJson (nameParts n)).compress
  let componentPayload : String := "TCSlib.Cryptography.Hashing.SIS.collisionDifference\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"collisionDifference\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.Hashing.SIS.hash\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"hash\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Hashing\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.IsSolution\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"IsSolution\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.SIS.Parameters._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\ttrue\tfalse\ttrue\nTCSlib.Cryptography.SIS.Parameters.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Parameters\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"SIS\"],[\"str\",\"Basic\"]]\tfalse\tfalse\ttrue\nTCSlib.Cryptography.acceptProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"acceptProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.copies\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"copies\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.distAdv\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"distAdv\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.invProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"invProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.mixDist\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"mixDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyAvgRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyAvgRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyHybrid\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyHybrid\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.multicopyRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"multicopyRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.predProb\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"predProb\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Experiments\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.pushSampler\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"pushSampler\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.sunglassRed\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"sunglassRed\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Pseudorandom\"],[\"str\",\"Indistinguishability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uexp\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uexp\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.Cryptography.uprob\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"uprob\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"Cryptography\"],[\"str\",\"Foundations\"],[\"str\",\"Probability\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.HasMinEntropy\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"HasMinEntropy\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist._sizeOf_1\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_1\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist._sizeOf_inst\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"_sizeOf_inst\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.collision\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"collision\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.instCoeFunForallReal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"instCoeFunForallReal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\ttrue\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.map\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"map\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.mk._flat_ctor\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"mk\"],[\"str\",\"_flat_ctor\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\ttrue\nTCSlib.InformationTheory.FinDist.probTrue\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"probTrue\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.prod\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"prod\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.FinDist.uniform\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"],[\"str\",\"uniform\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"FinDist\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.IsUniversal\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"IsUniversal\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"UniversalHashing\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.hashPair\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"hashPair\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"LeftoverHash\"]]\tfalse\tfalse\tfalse\nTCSlib.InformationTheory.statDist\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"statDist\"]]\t[[\"str\",\"TCSlib\"],[\"str\",\"InformationTheory\"],[\"str\",\"StatisticalDistance\"]]\tfalse\tfalse\tfalse"
  let mut components : Std.HashMap String (String × String × String × String × String) := {}
  for line in (if componentPayload.isEmpty then [] else componentPayload.splitOn "\n") do
    match line.splitOn "\t" with
    | [n, nk, hk, i, m, a] =>
      if (components[n]?).isSome then throwError "G06-HARNESS {label}: duplicate component request"
      components := components.insert n (nk, hk, i, m, a)
    | _ => throwError "G06-HARNESS {label}: malformed component request"
  unless components.size == requests.size do throwError "G06-HARNESS {label}: component count differs"
  let env ← Lean.getEnv
  let mut catalog : Std.HashMap String (Array Lean.Name) := {}
  let mut verified : Nat := 0
  for (n, _) in env.constants.toList do
    let some mi := env.getModuleIdxFor? n | continue
    unless (`TCSlib).isPrefixOf env.header.moduleNames[mi.toNat]! do continue
    let ns := (catalog[n.toString]?).getD #[]
    catalog := catalog.insert n.toString (ns.push n)
  for (spelling, expectedHome) in requests do
    let ns := (catalog[spelling]?).getD #[]
    unless ns.size == 1 do throwError "G06-HARNESS {label}: absent/ambiguous imported name {spelling}; candidates={ns.size}"
    let n := ns[0]!
    let some mi := env.getModuleIdxFor? n | throwError "G06-HARNESS {label}: no home for {spelling}"
    let home := env.header.moduleNames[mi.toNat]!
    unless home.toString == expectedHome do throwError "G06-HARNESS {label}: home differs for {spelling}: {home}"
    let some ci := env.find? n | throwError "G06-HARNESS {label}: no constant for {spelling}"
    unless ci.isDefinition do throwError "G06-HARNESS {label}: requested nondefinition {spelling}"
    let some (nk, hk, ei, em, ea) := components[spelling]?
      | throwError "G06-HARNESS {label}: missing component request"
    unless nameKey n == nk && nameKey home == hk do
      throwError "G06-HARNESS {label}: actual Name components differ"
    let instanceFlag := Lean.Meta.isInstanceCore env n
    let matcherFlag := (Lean.Meta.Match.Extension.getMatcherInfo? env n).isSome
    let abbrevFlag := match ci with
      | .defnInfo d => match d.hints with | .abbrev => true | _ => false
      | _ => false
    unless toString instanceFlag == ei && toString matcherFlag == em && toString abbrevFlag == ea do
      throwError "G06-HARNESS {label}: definition/instance metadata differs"
    Lean.logInfo m!"G06-COMPONENT label={label} phase=eof spelling={spelling} key={nk} home_key={hk} instance={instanceFlag}"
    let installed ← Lean.Elab.Command.liftCoreM <| Lean.getReducibilityStatus n
    unless installed == .irreducible do throwError "G06-HARNESS {label}: seal not installed at EOF for {spelling}"
    if Lean.Meta.isGlobalInstance env n then
      throwError "G06-HARNESS {label}: unfolding membership at EOF for {spelling}"
    verified := verified + 1
  unless verified == requests.size do throwError "G06-HARNESS {label}: verification count mismatch"
  Lean.logInfo m!"G06-MASK label={label} phase=eof requested={requests.size} verified={verified}"
  Lean.logInfo m!"G06-SEAL-END label={label} requested={requests.size} verified={verified}"

