import Lean
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security

set_option maxHeartbeats 0
set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace GswSecControls

theorem ctlHash (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (x : Fin P.columns → Bool) :
    TCSlib.Cryptography.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) := rfl

theorem ctlHashReader (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (x : Fin P.columns → Bool) :
    TCSlib.Cryptography.Hashing.SIS.hash P A x = A.mulVec (fun i => ((x i).toNat : ZMod P.modulus)) :=
  TCSlib.Cryptography.Hashing.SIS.hash_eq P A x

theorem ctlHashColumns (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (N : ℕ)
    (R : Matrix (Fin P.columns) (Fin N) Bool) (i : Fin P.dimension) (j : Fin N) :
    TCSlib.Cryptography.Hashing.SIS.hashColumns P N A R i j = TCSlib.Cryptography.Hashing.SIS.hash P A (fun c => R c j) i := rfl

theorem ctlHashColumnsReader (P : TCSlib.Cryptography.SIS.Parameters)
    (A : Matrix (Fin P.dimension) (Fin P.columns) (ZMod P.modulus)) (N : ℕ)
    (R : Matrix (Fin P.columns) (Fin N) Bool) (i : Fin P.dimension) (j : Fin N) :
    TCSlib.Cryptography.Hashing.SIS.hashColumns P N A R i j = TCSlib.Cryptography.Hashing.SIS.hash P A (fun c => R c j) i :=
  TCSlib.Cryptography.Hashing.SIS.hashColumns_apply P N A R i j

theorem ctlAugmented (P : TCSlib.Cryptography.LWE.Parameters)
    (pk : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      (Fin P.samples → ZMod P.modulus)) :
    TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented P pk = Fin.snoc pk.1.transpose pk.2 := rfl

theorem ctlAugmentedReader (P : TCSlib.Cryptography.LWE.Parameters)
    (pk : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      (Fin P.samples → ZMod P.modulus)) :
    TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented P pk = Fin.snoc pk.1.transpose pk.2 :=
  TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented_eq P pk

theorem ctlHashParameters (P : TCSlib.Cryptography.LWE.Parameters) :
    (TCSlib.Cryptography.Encryption.PublicKey.Regev.hashParameters P).dimension = P.dimension + 1 := rfl

theorem ctlHashParametersReader (P : TCSlib.Cryptography.LWE.Parameters) :
    (TCSlib.Cryptography.Encryption.PublicKey.Regev.hashParameters P).dimension = P.dimension + 1 :=
  TCSlib.Cryptography.Encryption.PublicKey.Regev.hashParameters_dimension P

theorem ctlExtractionError (P : TCSlib.Cryptography.LWE.Parameters) :
    TCSlib.Cryptography.Encryption.PublicKey.Regev.extractionError P =
      (1 / 2) * Real.sqrt ((P.modulus : ℝ) ^ (P.dimension + 1) / (2 : ℝ) ^ P.samples) := rfl

theorem ctlExtractionErrorReader (P : TCSlib.Cryptography.LWE.Parameters) :
    TCSlib.Cryptography.Encryption.PublicKey.Regev.extractionError P =
      (1 / 2) * Real.sqrt ((P.modulus : ℝ) ^ (P.dimension + 1) / (2 : ℝ) ^ P.samples) :=
  TCSlib.Cryptography.Encryption.PublicKey.Regev.extractionError_eq P

theorem ctlSample (P : TCSlib.Cryptography.LWE.Parameters) (χ : TCSlib.Cryptography.LWE.Noise)
    (r : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      ((Fin P.dimension → ZMod P.modulus) × (Fin P.samples → χ.Coins))) :
    (TCSlib.Cryptography.LWE.sample P χ r).1 = r.1 := rfl

theorem ctlSampleReader (P : TCSlib.Cryptography.LWE.Parameters) (χ : TCSlib.Cryptography.LWE.Noise)
    (r : Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      ((Fin P.dimension → ZMod P.modulus) × (Fin P.samples → χ.Coins))) :
    (TCSlib.Cryptography.LWE.sample P χ r).1 = r.1 :=
  TCSlib.Cryptography.LWE.sample_fst P χ r

theorem ctlDecisionAdvantage {ρ : Type} [Fintype ρ] [Nonempty ρ] (P : TCSlib.Cryptography.LWE.Parameters)
    (χ : TCSlib.Cryptography.LWE.Noise)
    (D : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      (Fin P.samples → ZMod P.modulus)) → ρ → Bool) :
    TCSlib.Cryptography.LWE.decisionAdvantage P χ D = TCSlib.Cryptography.distAdv (TCSlib.Cryptography.LWE.sample P χ)
      (id : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
        (Fin P.samples → ZMod P.modulus)) → _) D := rfl

theorem ctlDecisionAdvantageReader {ρ : Type} [Fintype ρ] [Nonempty ρ] (P : TCSlib.Cryptography.LWE.Parameters)
    (χ : TCSlib.Cryptography.LWE.Noise)
    (D : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
      (Fin P.samples → ZMod P.modulus)) → ρ → Bool) :
    TCSlib.Cryptography.LWE.decisionAdvantage P χ D = TCSlib.Cryptography.distAdv (TCSlib.Cryptography.LWE.sample P χ)
      (id : (Matrix (Fin P.samples) (Fin P.dimension) (ZMod P.modulus) ×
        (Fin P.samples → ZMod P.modulus)) → _) D :=
  TCSlib.Cryptography.LWE.decisionAdvantage_eq P χ D

theorem ctlEncrypt (P : TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters)
    (pk : Matrix (Fin P.lwe.samples) (Fin P.lwe.dimension) (ZMod P.lwe.modulus) ×
      (Fin P.lwe.samples → ZMod P.lwe.modulus))
    (μ : Bool) (R : Matrix (Fin P.lwe.samples) (Fin (TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters.columns P)) Bool) :
    TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypt P pk μ R =
      TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented P.lwe pk * TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.lift P R +
      (μ.toNat : ZMod P.lwe.modulus) • TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.gadget P := rfl

theorem ctlEncryptReader (P : TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters)
    (pk : Matrix (Fin P.lwe.samples) (Fin P.lwe.dimension) (ZMod P.lwe.modulus) ×
      (Fin P.lwe.samples → ZMod P.lwe.modulus))
    (μ : Bool) (R : Matrix (Fin P.lwe.samples) (Fin (TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters.columns P)) Bool) :
    TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypt P pk μ R =
      TCSlib.Cryptography.Encryption.PublicKey.Regev.augmented P.lwe pk * TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.lift P R +
      (μ.toNat : ZMod P.lwe.modulus) • TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.gadget P :=
  TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypt_eq P pk μ R

theorem ctlLift (P : TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters) (X : Matrix (Fin 2) (Fin 3) Bool) (i : Fin 2) (j : Fin 3) :
    TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.lift P X i j = ((X i j).toNat : ZMod P.lwe.modulus) := rfl

theorem ctlLiftReader (P : TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters) (X : Matrix (Fin 2) (Fin 3) Bool) (i : Fin 2) (j : Fin 3) :
    TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.lift P X i j = ((X i j).toNat : ZMod P.lwe.modulus) :=
  TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.lift_apply P X i j

theorem ctlAcceptProb {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :
    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true := rfl

theorem ctlAcceptProbReader {σ γ ρ : Type} [Fintype σ] [Fintype ρ] (X : σ → γ) (D : γ → ρ → Bool) :
    TCSlib.Cryptography.acceptProb X D = TCSlib.Cryptography.uprob fun z : σ × ρ => D (X z.1) z.2 = true :=
  TCSlib.Cryptography.acceptProb_def X D

theorem ctlDistAdv {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) :
    TCSlib.Cryptography.distAdv X Y D = |TCSlib.Cryptography.acceptProb X D - TCSlib.Cryptography.acceptProb Y D| := rfl

theorem ctlDistAdvReader {σ τ γ ρ : Type} [Fintype σ] [Fintype τ] [Fintype ρ] (X : σ → γ) (Y : τ → γ)
    (D : γ → ρ → Bool) :
    TCSlib.Cryptography.distAdv X Y D = |TCSlib.Cryptography.acceptProb X D - TCSlib.Cryptography.acceptProb Y D| :=
  TCSlib.Cryptography.distAdv_def X Y D

end GswSecControls

