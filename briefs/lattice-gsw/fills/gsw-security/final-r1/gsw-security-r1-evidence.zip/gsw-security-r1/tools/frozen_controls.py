#!/usr/bin/env python3
"""Controls for frozen_check.py: mutate the delivered final file and check that
the checker reports exactly the expected difference(s).
Usage: frozen_controls.py <checker.py> <base.lean> <final.lean> <targets> <outdir>
"""
import os
import re
import subprocess
import sys

checker, base, final, targets, outdir = sys.argv[1:6]
os.makedirs(outdir, exist_ok=True)
src = open(final, encoding="utf-8").read()
tlist = targets.split(",")
first_target = tlist[0]


def run(name, text, expect_prefix, expect_n):
    p = os.path.join(outdir, f"control_{name}.lean")
    open(p, "w", encoding="utf-8").write(text)
    r = subprocess.run([sys.executable, "-I", checker, base, p, targets],
                       capture_output=True, text=True)
    out = r.stdout
    open(os.path.join(outdir, f"control_{name}.txt"), "w").write(out)
    diffs = [ln for ln in out.splitlines() if ln.startswith("DIFF ")]
    hits = [d for d in diffs if d[5:].startswith(expect_prefix)]
    ok = (len(diffs) == expect_n and len(hits) == expect_n)
    print(f"{name}: differences={len(diffs)} expected {expect_n}x {expect_prefix} -> "
          f"{'OK' if ok else 'FAIL'}")
    return ok


results = []
# 1. one character in a target header (the first target's name occurrence in its type)
m = re.search(r"\ntheorem " + re.escape(first_target) + r"\b[^\n]*\n", src)
hdr_start = m.end()
# change the first 'P' after the header's first line into 'Q'
k = src.index("(P : ", hdr_start - 200)
mut = src[:k + 1] + "Q" + src[k + 2:]
results.append(run("header_onechar", mut, "HEADER-CHANGED", 1))
# 2. delete a reader (the first `theorem *_eq` or `*_apply` with body `rfl`)
rm = re.search(r"\n(/--(?:(?!-/).)*-/\n)?theorem (\w+_(?:eq|apply)) (?:(?!\n\n).)*?:= rfl\n",
               src, re.S)
reader = rm.group(2)
mut = src[:rm.start()] + "\n" + src[rm.end():]
results.append(run("reader_deleted", mut, "REMOVED", 1))
print(f"  (deleted reader: {reader})")
# 3. one character in a definition body
dm = re.search(r"\ndef (\w+)[^\n]*\n", src)
dname = dm.group(1)
body_at = src.index(":=", dm.end()) if " where" not in src[dm.start():dm.end()] else None
if body_at is None:
    body_at = src.index("where", dm.start())
j = src.index("\n", body_at) + 1
# flip a character in the next line (the body)
line_end = src.index("\n", j)
seg = src[j:line_end]
pos = len(seg) - 1
mut = src[:j + pos] + ("X" if seg[pos] != "X" else "Y") + src[j + pos + 1:]
results.append(run("def_body_onechar", mut, "NONTARGET-CHANGED", 1))
print(f"  (def mutated: {dname})")
# 4. one character in a target's statement prose (before the sketch)
tm = re.search(r"/--((?:(?!-/).)*?)\*\*Proof sketch\.\*\*(?:(?!-/).)*-/\ntheorem "
               + re.escape(first_target) + r"\b", src, re.S)
pk = tm.start(1) + 2
mut = src[:pk] + ("X" if src[pk] != "X" else "Y") + src[pk + 1:]
results.append(run("target_prose_onechar", mut, "TARGET-PROSE-CHANGED", 1))
# 5. a sketch-only edit of a target must report 0 differences
sk = src.index("**Proof sketch.**", tm.start()) + len("**Proof sketch.**")
mut = src[:sk] + " Edited." + src[sk:]
results.append(run("target_sketch_edit_allowed", mut, "", 0))
# 6. an `open`/`set_option` line removed
om = re.search(r"\nset_option autoImplicit false\n", src)
mut = src[:om.start()] + "\n" + src[om.end():]
results.append(run("option_removed", mut, "OTHER-REMOVED-OR-CHANGED", 1))
# 7. an extra non-import command added
mut = src.replace("\nset_option autoImplicit false\n",
                  "\nset_option autoImplicit false\nset_option pp.all true\n", 1)
results.append(run("option_added", mut, "OTHER-ADDED-OR-CHANGED", 1))
# 8. identity -> 0 diffs
results.append(run("identity", src, "", 0))
# 9. swap the order of the first two theorems (each with its docstring) -> ORDER-CHANGED
items = list(re.finditer(r"\n(/--(?:(?!-/).)*-/\n)(@\[[^\n]*\]\n)?(def|theorem) (\w+)"
                         r"(?:(?!\n/--|\nattribute |\nend ).)*", src, re.S))
a, b = items[0], items[1]
mut = src[:a.start()] + src[b.start():b.end()] + src[a.end():b.start()] + \
    src[a.start():a.end()] + src[b.end():]
results.append(run("order_swap", mut, "ORDER-CHANGED", 1))
print(f"  (swapped: {a.group(4)} <-> {b.group(4)})")
# 10. one character in an `attribute`/`open` command -> one removal + one addition
am = re.search(r"\n(attribute \[|open )", src)
k = am.end()
mut = src[:k] + ("X" if src[k] != "X" else "Y") + src[k + 1:]
results.append(run("command_onechar", mut, "OTHER-", 2))
print(f"  (command mutated: {am.group(1).strip()})")
print("ALL_CONTROLS", "OK" if all(results) else "FAIL")
