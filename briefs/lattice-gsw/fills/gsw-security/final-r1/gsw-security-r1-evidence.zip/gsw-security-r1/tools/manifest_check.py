#!/usr/bin/env python3
"""Verify a SHA256SUMS manifest: exact path set (nothing missing, nothing extra,
no leading ./), and every hash. Usage: manifest_check.py <root> <manifest-relpath>
The manifest covers every file under the manifest's directory except itself."""
import hashlib
import os
import sys

root = os.path.abspath(sys.argv[1])
man = sys.argv[2]
mdir = os.path.dirname(os.path.join(root, man))
listed = {}
bad_lines = []
dot = 0
with open(os.path.join(root, man), encoding="utf-8") as f:
    for ln in f:
        ln = ln.rstrip("\n")
        if not ln:
            continue
        parts = ln.split("  ", 1)
        if len(parts) != 2 or len(parts[0]) != 64:
            bad_lines.append(ln)
            continue
        h, p = parts
        if p.startswith("./"):
            dot += 1
        if p in listed:
            bad_lines.append("DUP " + p)
        listed[p] = h
present = set()
for dp, dn, fn in os.walk(mdir):
    for n in fn:
        rel = os.path.relpath(os.path.join(dp, n), mdir)
        present.add(rel)
present.discard(os.path.basename(man))
missing = sorted(set(listed) - present)
extra = sorted(present - set(listed))
mism = []
for p, h in listed.items():
    fp = os.path.join(mdir, p)
    if os.path.isfile(fp):
        with open(fp, "rb") as g:
            if hashlib.sha256(g.read()).hexdigest() != h:
                mism.append(p)
print(f"manifest={man} listed={len(listed)} present={len(present)} "
      f"missing={len(missing)} extra={len(extra)} hash_mismatch={len(mism)} "
      f"leading_dot={dot} bad_lines={len(bad_lines)}")
for x in missing:
    print("MISSING", x)
for x in extra:
    print("EXTRA", x)
for x in mism:
    print("MISMATCH", x)
for x in bad_lines:
    print("BADLINE", x)
ok = not (missing or extra or mism or dot or bad_lines)
print("RESULT", "PASS" if ok else "FAIL")
