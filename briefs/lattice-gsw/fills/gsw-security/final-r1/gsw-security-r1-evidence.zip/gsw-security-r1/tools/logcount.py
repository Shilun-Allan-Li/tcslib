#!/usr/bin/env python3
"""Count error forms in every raw log under a directory, and sorry warnings per module
in a sweep directory. Usage:
  logcount.py errors <dir>            -> per-log counts of `error:` and `error(` (G26-N1)
  logcount.py sorries <sweepdir> <base-sorries.txt>
"""
import os
import re
import sys

ERR_COLON = re.compile(r"^\S+\.lean:\d+:\d+: error:", re.M)
ERR_PAREN = re.compile(r"^\S+\.lean:\d+:\d+: error\(", re.M)
ANY_ERR = re.compile(r"error", re.I)
SORRY = re.compile(r"^(\S+)\.lean:(\d+):(\d+): warning: declaration uses 'sorry'", re.M)


def errors(d):
    tot_c = tot_p = 0
    rows = []
    for dp, _, fn in os.walk(d):
        for n in sorted(fn):
            if not n.endswith(".log"):
                continue
            p = os.path.join(dp, n)
            t = open(p, encoding="utf-8", errors="replace").read()
            c = len(ERR_COLON.findall(t))
            q = len(ERR_PAREN.findall(t))
            tot_c += c
            tot_p += q
            rows.append((os.path.relpath(p, d), c, q))
    for r, c, q in sorted(rows):
        if c or q:
            print(f"{r}\terror:={c}\terror(={q}")
    print(f"TOTAL logs={len(rows)} error:={tot_c} error(={tot_p}")


def sorries(d, base):
    cur = {}
    for n in sorted(os.listdir(d)):
        if not n.endswith(".log"):
            continue
        t = open(os.path.join(d, n), encoding="utf-8", errors="replace").read()
        for m in SORRY.finditer(t):
            mod = m.group(1)
            cur.setdefault(mod, []).append(int(m.group(2)))
    nmods = len(cur)
    nwarn = sum(len(v) for v in cur.values())
    print(f"sorry warnings: {nwarn} in {nmods} modules")
    exp = {}
    for ln in open(base, encoding="utf-8"):
        ln = ln.strip()
        if not ln or ln.startswith("TOTAL"):
            continue
        mod, k, names = ln.split(": ", 2)
        exp[mod] = int(k)
    for mod, lines in sorted(cur.items()):
        key = next((e for e in exp if mod.endswith(e)), None)
        print(f"{mod}\t{len(lines)}\tbase={exp.get(key)}\tlines={lines}")
    for e, k in exp.items():
        if not any(m.endswith(e) for m in cur):
            print(f"ABSENT-NOW {e}\tbase={k}")


if __name__ == "__main__":
    if sys.argv[1] == "errors":
        errors(sys.argv[2])
    else:
        sorries(sys.argv[2], sys.argv[3])
