#!/usr/bin/env python3
"""Line widths (Python len), file sizes, micro-sign, tabs and trailing spaces.
Usage: widths.py <file>..."""
import sys

bad = 0
for p in sys.argv[1:]:
    lines = open(p, encoding="utf-8").read().split("\n")
    if lines and lines[-1] == "":
        lines = lines[:-1]
    mx = max((len(x) for x in lines), default=0)
    over = [(i + 1, len(x)) for i, x in enumerate(lines) if len(x) > 100]
    micro = [i + 1 for i, x in enumerate(lines) if "µ" in x]
    tabs = [i + 1 for i, x in enumerate(lines) if "\t" in x]
    trail = [i + 1 for i, x in enumerate(lines) if x != x.rstrip()]
    ok = not over and len(lines) <= 1000 and not micro
    bad += not ok
    print(f"{p}: lines={len(lines)} max_width={mx} over100={over} micro_sign={micro} "
          f"tabs={tabs} trailing_ws={trail} -> {'PASS' if ok else 'FAIL'}")
print("RESULT", "PASS" if not bad else "FAIL")
