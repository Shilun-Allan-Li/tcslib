#!/usr/bin/env python3
"""Independent frozen-statement check (maintainer review, gsw-security r1).

Usage: frozen_check.py <base.lean> <final.lean> <comma-separated target names>

Splits each file into top-level items (module doc, imports, options, opens,
namespaces, attribute commands, declarations with their docstrings and
attributes). For every declaration present at base it checks, byte for byte:
  * the header (docstring excluded): attributes, modifiers, keyword, name,
    binders and type, up to the first depth-0 `:=`, `where` or `|` (after the
    name) that begins the proof or body;
  * non-targets: the whole item (docstring + header + body) is identical;
  * targets: the docstring prose before `**Proof sketch.**` is identical (the
    sketch paragraph and the body may change);
  * order: the base declarations appear in the same relative order at final;
  * nothing is deleted.
Non-declaration items (imports, options, opens, namespaces, module docstring,
`attribute [...]` commands, `end`) must be unchanged and in order; the only
allowed additions are `import` lines. New declarations are listed as ADDED.
Prints every difference; exit status 0 iff there are none.
"""
import re
import sys

DECL_KW = ("theorem", "lemma", "def", "abbrev", "instance", "structure", "class",
           "inductive", "example", "opaque", "axiom")
MODS = ("private", "protected", "noncomputable", "partial", "unsafe", "nonrec")
CMD_START = re.compile(
    r"^(/--|/-!|/-|@\[|theorem\b|lemma\b|def\b|abbrev\b|instance\b|structure\b|"
    r"class\b|inductive\b|example\b|opaque\b|axiom\b|private\b|protected\b|"
    r"noncomputable\b|partial\b|unsafe\b|nonrec\b|attribute\b|open\b|namespace\b|"
    r"end\b|section\b|variable\b|set_option\b|import\b|local\b|scoped\b|universe\b|#)")


def block_comment_end(text, i):
    """Index just after the block comment starting at text[i:i+2] == '/-'."""
    depth = 0
    n = len(text)
    while i < n:
        if text.startswith("/-", i):
            depth += 1
            i += 2
        elif text.startswith("-/", i):
            depth -= 1
            i += 2
            if depth == 0:
                return i
        else:
            i += 1
    raise ValueError("unterminated comment")


def split_items(text):
    """Return a list of top-level items as raw strings (exact bytes, concatenation
    of items plus separators reproduces the file)."""
    lines = text.splitlines(keepends=True)
    # compute line start offsets
    offs = []
    o = 0
    for ln in lines:
        offs.append(o)
        o += len(ln)
    # mark which lines are inside a block comment that started earlier
    starts = []
    i = 0
    n = len(text)
    li = 0
    in_comment_until = -1
    for li, ln in enumerate(lines):
        off = offs[li]
        if off < in_comment_until:
            continue
        if CMD_START.match(ln):
            starts.append(li)
            if ln.startswith("/-"):
                in_comment_until = block_comment_end(text, off)
    items = []
    # merge: docstring and attribute lines attach to the following declaration
    groups = []
    k = 0
    while k < len(starts):
        s = starts[k]
        e = starts[k + 1] if k + 1 < len(starts) else len(lines)
        groups.append((s, e))
        k += 1
    merged = []
    pending = None
    for s, e in groups:
        first = lines[s]
        is_doc = first.startswith("/--")
        is_attr = first.startswith("@[")
        if pending is not None:
            s = pending
            pending = None
        if (is_doc or is_attr) and not _doc_then_other(lines, s, e):
            pending = s
            continue
        merged.append((s, e))
    if pending is not None:
        merged.append((pending, len(lines)))
    for s, e in merged:
        items.append("".join(lines[s:e]))
    prefix = "".join(lines[: merged[0][0]]) if merged else text
    return prefix, items


def _doc_then_other(lines, s, e):
    """True if the group [s, e) already contains a declaration keyword line after
    the doc/attr (so it is self-contained)."""
    body = "".join(lines[s:e])
    # strip leading docstring
    t = body
    if t.startswith("/--"):
        j = block_comment_end(t, 0)
        t = t[j:]
    t = t.lstrip()
    while t.startswith("@["):
        d = 0
        for idx, ch in enumerate(t):
            if ch == "[":
                d += 1
            elif ch == "]":
                d -= 1
                if d == 0:
                    t = t[idx + 1:].lstrip()
                    break
        else:
            return False
    return bool(t)


def strip_doc(item):
    """(docstring or '', rest) for an item."""
    if item.startswith("/--"):
        j = block_comment_end(item, 0)
        return item[:j], item[j:]
    return "", item


def decl_info(item):
    """Return (kind, name, header, body) for a declaration item, else None."""
    doc, rest = strip_doc(item)
    r = rest.lstrip("\n")
    t = r
    # skip attributes
    pos = 0
    toks = t
    m_attr = re.match(r"(\s*@\[[^\]]*(?:\[[^\]]*\][^\]]*)*\]\s*)*", toks)
    after_attr = toks[m_attr.end():] if m_attr else toks
    words = after_attr.split()
    w = 0
    while w < len(words) and words[w] in MODS:
        w += 1
    if w >= len(words) or words[w] not in DECL_KW:
        return None
    kind = words[w]
    name = words[w + 1] if kind not in ("example", "instance") else (
        words[w + 1] if w + 1 < len(words) else "")
    # find header end: first depth-0 ':=' / 'where' / '|' after the name
    kw_idx = after_attr.find(kind)
    start_scan = (len(r) - len(after_attr)) + kw_idx + len(kind)
    name_idx = r.find(name, start_scan) + len(name) if name else start_scan
    depth = 0
    i = name_idx
    n = len(r)
    hdr_end = n
    while i < n:
        c = r[i]
        if r.startswith("--", i):
            j = r.find("\n", i)
            i = n if j < 0 else j
            continue
        if r.startswith("/-", i):
            i = block_comment_end(r, i)
            continue
        if c == '"':
            j = i + 1
            while j < n and r[j] != '"':
                j += 2 if r[j] == "\\" else 1
            i = j + 1
            continue
        if c in "([{⟨⦃":
            depth += 1
        elif c in ")]}⟩⦄":
            depth -= 1
        elif depth == 0:
            if r.startswith(":=", i):
                hdr_end = i
                break
            if re.match(r"\bwhere\b", r[i:i + 6]) and (i == 0 or not r[i - 1].isalnum()):
                hdr_end = i
                break
            if c == "|" and r[r.rfind("\n", 0, i) + 1:i].strip() == "":
                hdr_end = i
                break
        i += 1
    return kind, name, r[:hdr_end], r[hdr_end:], doc


def prose_before_sketch(doc):
    k = doc.find("**Proof sketch.**")
    return doc if k < 0 else doc[:k]


def analyse(path):
    text = open(path, encoding="utf-8").read()
    prefix, items = split_items(text)
    decls = []
    others = []
    for idx, it in enumerate(items):
        info = decl_info(it)
        if info is None:
            others.append((idx, it.rstrip("\n")))
        else:
            kind, name, hdr, body, doc = info
            decls.append({"idx": idx, "kind": kind, "name": name, "header": hdr,
                          "body": body, "doc": doc, "item": it})
    return prefix, decls, others


def main():
    base, final, targets = sys.argv[1], sys.argv[2], set(sys.argv[3].split(","))
    pb, db, ob = analyse(base)
    pf, df, of = analyse(final)
    diffs = []
    fmap = {}
    for d in df:
        if d["name"] in fmap:
            diffs.append(f"DUPLICATE-NAME at final: {d['name']}")
        fmap[d["name"]] = d
    print(f"base: {len(db)} declarations, {len(ob)} other items; "
          f"final: {len(df)} declarations, {len(of)} other items")
    for d in db:
        nm = d["name"]
        g = fmap.get(nm)
        if g is None:
            diffs.append(f"REMOVED {d['kind']} {nm}")
            continue
        if d["kind"] != g["kind"]:
            diffs.append(f"KIND-CHANGED {nm}: {d['kind']} -> {g['kind']}")
        if d["header"] != g["header"]:
            diffs.append(f"HEADER-CHANGED {nm}\n--- base\n{d['header']}\n+++ final\n{g['header']}")
        if nm in targets:
            if prose_before_sketch(d["doc"]) != prose_before_sketch(g["doc"]):
                diffs.append(f"TARGET-PROSE-CHANGED {nm}")
            if "**Proof sketch.**" not in g["doc"]:
                diffs.append(f"TARGET-SKETCH-MISSING {nm}")
        else:
            if d["item"].rstrip("\n") != g["item"].rstrip("\n"):
                part = []
                if d["doc"] != g["doc"]:
                    part.append("docstring")
                if d["body"].rstrip("\n") != g["body"].rstrip("\n"):
                    part.append("body")
                diffs.append(f"NONTARGET-CHANGED {nm} ({', '.join(part) or 'layout'})")
    # order of base declarations at final
    base_names = [d["name"] for d in db]
    final_order = [d["name"] for d in df if d["name"] in set(base_names)]
    order_ok = final_order == [x for x in base_names if x in fmap]
    if not order_ok:
        diffs.append(f"ORDER-CHANGED base={base_names} final={final_order}")
    added = [d["name"] for d in df if d["name"] not in {x["name"] for x in db}]
    # non-declaration items: unchanged and in order, only import additions allowed
    bo = [x for _, x in ob]
    fo = [x for _, x in of]
    # align by longest common subsequence (difflib), so one removal or one
    # addition is reported once
    import difflib
    added_other = []
    missing_other = []
    sm = difflib.SequenceMatcher(a=bo, b=fo, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ("delete", "replace"):
            missing_other.extend(bo[i1:i2])
        if tag in ("insert", "replace"):
            added_other.extend(fo[j1:j2])
    for x in added_other:
        if x.startswith("import ") and "\n" not in x.strip():
            print(f"ADDED-IMPORT {x.strip()}")
        else:
            diffs.append(f"OTHER-ADDED-OR-CHANGED:\n{x}")
    for x in missing_other:
        diffs.append(f"OTHER-REMOVED-OR-CHANGED:\n{x}")
    if pb != pf:
        diffs.append("PREFIX-CHANGED (text before the first command)")
    for nm in added:
        print(f"ADDED-DECL {nm}")
    for t in sorted(targets):
        if t not in {d['name'] for d in db}:
            diffs.append(f"TARGET-NOT-FOUND-AT-BASE {t}")
    print(f"order_ok={order_ok} added_decls={len(added)} differences={len(diffs)}")
    for x in diffs:
        print("DIFF", x)
    print("RESULT", "PASS" if not diffs else "FAIL")
    print("DECLS-BASE " + " ".join(f"{d['kind']}:{d['name']}" for d in db))
    sys.exit(0 if not diffs else 1)



def dump(path):
    """Print every declaration's extracted header (for inspection)."""
    _, decls, others = analyse(path)
    for d in decls:
        print(f"===== {d['kind']} {d['name']} (doc {len(d['doc'])} chars, body {len(d['body'])} chars)")
        print(d["header"].rstrip())
    for _, x in others:
        print(f"----- other: {x.splitlines()[0][:90]}")


if __name__ == "__main__":
    if sys.argv[1] == "--dump":
        dump(sys.argv[2])
    else:
        main()
