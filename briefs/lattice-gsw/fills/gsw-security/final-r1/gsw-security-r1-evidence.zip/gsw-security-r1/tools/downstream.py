#!/usr/bin/env python3
"""Downstream modules (transitive importers) of the given modules in a checkout, in a
topological (imports-first) order, including the changed modules themselves.
Usage: downstream.py <repo> <Module.Name>...  (also scans audits/ and the root TCSlib.lean)"""
import os
import re
import sys

repo = sys.argv[1]
roots = sys.argv[2:]
IMP = re.compile(r"^import\s+(\S+)", re.M)
mods = {}
for top in ("TCSlib", "audits"):
    for dp, _, fn in os.walk(os.path.join(repo, top)):
        for n in fn:
            if n.endswith(".lean"):
                rel = os.path.relpath(os.path.join(dp, n), repo)[:-5]
                mods[rel.replace("/", ".")] = rel
if os.path.isfile(os.path.join(repo, "TCSlib.lean")):
    mods["TCSlib"] = "TCSlib"
imports = {}
for m, rel in mods.items():
    txt = open(os.path.join(repo, rel + ".lean"), encoding="utf-8").read()
    imports[m] = [i for i in IMP.findall(txt) if i in mods]
down = set(roots)
changed = True
while changed:
    changed = False
    for m, ims in imports.items():
        if m not in down and any(i in down for i in ims):
            down.add(m)
            changed = True
# topological order restricted to `down`
order, seen = [], set()


def visit(m):
    if m in seen:
        return
    seen.add(m)
    for i in imports.get(m, []):
        if i in down:
            visit(i)
    order.append(m)


for m in sorted(down):
    visit(m)
for m in order:
    print(mods[m])
print(f"# {len(order)} modules downstream of {' '.join(roots)} (inclusive)", file=sys.stderr)
