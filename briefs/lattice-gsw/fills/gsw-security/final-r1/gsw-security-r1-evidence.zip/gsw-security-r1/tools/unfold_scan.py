#!/usr/bin/env python3
"""Explicit-unfold scan (source level): every name passed to simp/simp only/simpa/rw/rwa/
erw/nth_rewrite/unfold/delta/dsimp/simp_rw/conv in the given files' tactic blocks is
classified against the TCSlib definitions of the checkout (by `def`/`abbrev`/`structure`
keyword) and the file's own declarations and local `let`/`have`/`set` names.

Usage: unfold_scan.py <repo> <file>...
Prints each item; FOREIGN-DEF items are Rule 10 candidates (an `abbrev` is notation)."""
import os
import re
import sys

repo = sys.argv[1]
files = sys.argv[2:]
DEF_RE = re.compile(r"^(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable)\s+)*"
                    r"(def|abbrev|structure|class|inductive|opaque)\s+([^\s(:{\[]+)", re.M)
# collect TCSlib definitions: short name -> set of (kind, file)
defs = {}
for dp, _, fn in os.walk(os.path.join(repo, "TCSlib")):
    for n in fn:
        if not n.endswith(".lean"):
            continue
        p = os.path.join(dp, n)
        rel = os.path.relpath(p, repo)
        for m in DEF_RE.finditer(open(p, encoding="utf-8").read()):
            short = m.group(2).split(".")[-1]
            defs.setdefault(short, set()).add((m.group(1), rel))
TAC = re.compile(r"\b(simp only|simp_rw|simpa only|simpa|simp|rwa|rw|erw|nth_rewrite \d+|"
                 r"unfold|delta|dsimp only|dsimp)\b[ \t]*(\[[^\]]*\]|[^\n\[]*)")
total_foreign = 0
for f in files:
    src = open(os.path.join(repo, f), encoding="utf-8").read()
    # strip comments and docstrings
    code = re.sub(r"/-.*?-/", lambda m: "\n" * m.group(0).count("\n"), src, flags=re.S)
    code = re.sub(r"--[^\n]*", "", code)
    locals_ = set(re.findall(r"\b(?:let|have|set|obtain)\s+([A-Za-z_][\w'₀-₉]*)", code))
    locals_ |= set(re.findall(r"\(([A-Za-z_][\w'₀-₉]*)\s*:", code))
    own = set(m.group(2).split(".")[-1] for m in DEF_RE.finditer(src))
    print(f"== {f}: locals={sorted(locals_)}")
    for m in TAC.finditer(code):
        ln_no = code.count("\n", 0, m.start()) + 1
        if True:
            arg = m.group(2)
            # head identifier of each top-level comma-separated rule (arguments to a
            # rule, e.g. `abs_sub_comm (acceptProb ..)`, are terms, not rewrite rules)
            body = arg[1:-1] if arg.startswith("[") else arg
            entries, depth, cur = [], 0, ""
            for ch in body:
                if ch in "([{⟨":
                    depth += 1
                elif ch in ")]}⟩":
                    depth -= 1
                if ch == "," and depth == 0:
                    entries.append(cur)
                    cur = ""
                else:
                    cur += ch
            entries.append(cur)
            names = []
            for e in entries:
                mm = re.match(r"\s*(?:←\s*)?([A-Za-z_][\w.'₀-₉]*)", e)
                if mm:
                    names.append(mm.group(1))
            for nm in names:
                if nm in ("at", "only", "using", "with", "fun", "by"):
                    continue
                short = nm.split(".")[-1]
                if nm in locals_ or short in locals_:
                    cls = "LOCAL"
                elif short in own:
                    cls = "OWN-DEF"
                elif short in defs:
                    kinds = defs[short]
                    if all(k == "abbrev" for k, _ in kinds):
                        cls = "FOREIGN-ABBREV(notation)"
                    else:
                        cls = "FOREIGN-DEF?" + ";".join(sorted(f"{k}:{p}" for k, p in kinds))
                        total_foreign += 1
                else:
                    cls = "LEMMA/OTHER"
                print(f"{f}:{ln_no}\t{m.group(1)}\t{nm}\t{cls}")
print(f"FOREIGN-DEF candidates: {total_foreign}")
