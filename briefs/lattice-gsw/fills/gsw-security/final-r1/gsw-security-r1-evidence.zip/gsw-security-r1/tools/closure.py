#!/usr/bin/env python3
"""TCSlib import closure of modules in a checkout.
Usage: closure.py <repo> <Module.Name>... [--diff <Module.Name>]
Prints the TCSlib modules in the transitive import closure (excluding the roots)."""
import os
import re
import sys

repo = sys.argv[1]
args = sys.argv[2:]
IMP = re.compile(r"^import\s+(\S+)", re.M)


def imports(mod):
    p = os.path.join(repo, *mod.split(".")) + ".lean"
    if not os.path.isfile(p):
        return []
    txt = open(p, encoding="utf-8").read()
    # only the header: imports precede the first non-import command
    return [m for m in IMP.findall(txt) if m.startswith("TCSlib")]


def closure(roots):
    seen = set()
    stack = list(roots)
    while stack:
        m = stack.pop()
        for i in imports(m):
            if i not in seen:
                seen.add(i)
                stack.append(i)
    return seen


c = closure(args)
for m in sorted(c):
    print(m)
print(f"# {len(c)} TCSlib modules in the closure of {' '.join(args)}", file=sys.stderr)
