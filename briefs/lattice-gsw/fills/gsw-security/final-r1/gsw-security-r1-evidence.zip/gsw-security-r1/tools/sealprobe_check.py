#!/usr/bin/env python3
"""Check the delivered seal probes against the sources they claim to seal.
For each probe (.lean) with a linemap (.linemap.json: probe line -> source line or null),
verify that the mapped probe lines reproduce the source file exactly (every source line
mapped once, in order) and report the harness markers and error counts of its log.
Usage: sealprobe_check.py <seal-dir> <source-root-for-this-seal-set>
  (<source-root>/<source> is the file at the seal's revision)"""
import json
import os
import re
import sys

d, src_root = sys.argv[1], sys.argv[2]
man = json.load(open(os.path.join(d, "manifest.json")))
ok_all = True
for row in man:
    base = os.path.basename(row["probe"])
    probe = os.path.join(d, base)
    lm = json.load(open(probe[:-5] + ".linemap.json"))
    plines = open(probe, encoding="utf-8").read().split("\n")
    src = open(os.path.join(src_root, row["source"]), encoding="utf-8").read().split("\n")
    mapped = [(i, s) for i, s in enumerate(lm) if s is not None]
    # linemap entries are 1-based source line numbers (or 0-based); detect
    srcidx = [s for _, s in mapped]
    # source line numbers are 1-based and contiguous from the first line after the
    # hoisted header (copyright and imports) to the last line
    lo = min(srcidx)
    if src and src[-1] == "":
        src = src[:-1]
    seq_ok = srcidx == list(range(lo, len(src) + 1))
    # probe index convention: 0-based (plines[i]) or 1-based (plines[i-1])
    t0 = all(i < len(plines) and plines[i] == src[s - 1] for i, s in mapped)
    t1 = all(0 < i <= len(plines) and plines[i - 1] == src[s - 1] for i, s in mapped)
    text_ok = t0 or t1
    header = src[:lo - 1]
    header_ok = all(h.startswith("import ") or h.strip() == "" or h.startswith("/-")
                    or h.startswith("Copyright") or h.startswith("Released")
                    or h.startswith("Authors") or h.startswith("-/") for h in header)
    hoisted_imports = [h for h in header if h.startswith("import ")]
    imports_ok = all(h in plines for h in hoisted_imports)
    text_ok = text_ok and header_ok and imports_ok
    unmapped_src = lo - 1
    log = open(probe[:-5] + ".log", encoding="utf-8", errors="replace").read()
    inst = len(re.findall(r"GSWSEC-INSTALL", log))
    eof = len(re.findall(r"GSWSEC-EOF", log))
    m = re.search(r"GSWSEC-INSTALL \S+ requested=(\d+) active=(\d+) already=(\d+) excluded=(\d+)",
                  log)
    ec = len(re.findall(r"^\S+\.lean:\d+:\d+: error:", log, re.M))
    ep = len(re.findall(r"^\S+\.lean:\d+:\d+: error\(", log, re.M))
    exitm = re.search(r"EXIT (\d+)", log)
    maxerr = "maxErrors=0" in log or "-DmaxErrors=0" in open(probe, encoding="utf-8").read()
    ok = seq_ok and text_ok and inst == 1 and eof == 1 and ec == 0 and ep == 0
    ok_all &= ok
    print(f"{base}: mapped={len(srcidx)} src_lines={len(src)} unmapped_src={unmapped_src} "
          f"order_ok={seq_ok} text_ok={text_ok} INSTALL={inst} EOF={eof} "
          f"requested={m.group(1) if m else '?'} error:={ec} error(={ep} "
          f"exit={exitm.group(1) if exitm else '?'} -> {'OK' if ok else 'CHECK'}")
print("RESULT", "OK" if ok_all else "CHECK")
