#!/bin/bash
# Gate 50 staging: duplication sweep greps (the judgement is in pack-r1.md, question 6).
# Usage: dupsweep.sh <repo> <tip> <tooldir>. Mathlib/Batteries sources: <repo>/.lake/packages (revs printed).
R=$1; TIP=$2; TD=$3; ML=$R/.lake/packages/mathlib; BT=$R/.lake/packages/batteries
H66=597fb736e545706a058cc212243a13f6dadfeceb; H68=1953898b18a33ab2cd533820c5754a1aacffeb44
cd "$R"
echo "# dup-sweep.txt (staging greps, no Lean)"
echo "tip $TIP; #366 $H66; #368 $H68; Mathlib $(git -C $ML rev-parse HEAD); Batteries $(git -C $BT rev-parse HEAD 2>/dev/null)"
echo; echo "## 1. inventory: declarations whose keyword line is added (tools/newdecls.py)"
echo "### #360 (merge 76efe1ba -> 32ec2ef5)"; python3 -I $TD/newdecls.py . 76efe1ba28356d67da965ce8f68a7afc8c363d1b 32ec2ef521b5d3ed17fcdf06acde099083275667
echo "### addendum, in-house and external units, LE-gf1..4 (32ec2ef5 -> ccca6f80)"; python3 -I $TD/newdecls.py . 32ec2ef521b5d3ed17fcdf06acde099083275667 ccca6f804552f72b400c09e7a3bd694371bdf568
echo "### LE-g50 (93ae671e -> $H66): added"; python3 -I $TD/newdecls.py . 93ae671e8f638e86def66dd5ac0a312c8bec4f5c $H66; echo "(end)"
echo "### LE-g50: removed keyword lines"; git diff -U0 93ae671e $H66 | grep -E '^-(private )?(theorem|lemma|def) '; echo "(end)"
echo "### #368 ($H68^ -> $H68)"; python3 -I $TD/newdecls.py . 55f553715f280be36827ad86a94c93db39ec56c3 $H68
echo; echo "## 2. the 23 public names: other declarations of the same last component (TCSlib + audits at the tip and at #366; Mathlib; Batteries)"
N='carryBit_zero|carryBit_succ|eval_eq|depth_lit|size_lit|maxFanin_lit|gatesAcyclic_iff|isWellFormed_iff|gadgetCorrect_iff|vertexValue_eq|vertexDepth_eq|isPolySize_iff|hasFaninTwo_iff|hasPolylogDepth_iff|inTreeNC_iff|maxDepth_le_of_forall|maxFaninL_le_of_forall|prefixVal_eq_of_false|prefixVal_testBit|depth_getD_le|maxFanin_getD_le|decrypt_eq_decode_dotProduct|hybridPlant_eq'
for r in $TIP $H66 $H68; do echo "-- $r"; git grep -n -E "^\s*(private |protected )?(theorem|lemma|def|abbrev) [A-Za-z_.']*\.?($N)\b" $r -- 'TCSlib/*.lean' 'audits/*.lean' | sed "s|^$r:||"; done
echo "-- Mathlib + Batteries (exact last components except the generic eval_eq)"
grep -rn -E "(theorem|lemma) ([A-Za-z_.']*\.)?(maxDepth_le_of_forall|maxFaninL_le_of_forall|prefixVal_eq_of_false|prefixVal_testBit|depth_getD_le|maxFanin_getD_le|decrypt_eq_decode_dotProduct|hybridPlant_eq|vertexValue_eq|vertexDepth_eq|gadgetCorrect_iff|inTreeNC_iff)\b" $ML/Mathlib $BT/Batteries | sed "s|$R/.lake/packages/||"; echo "(end)"
echo; echo "## 3. list-maximum bounds over TreeCircuit lists (U1/U2 shapes) at the head"
git grep -n -E "(maxDepth|maxFaninL) \(.*\.map|maxDepth_map|maxFaninL_map|induction cs with" $H66 -- 'TCSlib/Complexity/*.lean' | sed "s|^$H66:||"
echo; echo "## 4. Mathlib cycle lemmas used or near the U3 helpers"
grep -n -E "theorem (IsCycle\.pow_eq_pow_iff|IsCycle\.isCycleOn|IsCycleOn\.pow_apply_eq_pow_apply|IsCycleOn\.pow_apply_eq|card_cycleType_eq_one|lcm_cycleType|sum_cycleType|cycleType_inv|cycleType_conj|SameCycle\.exists_pow_eq')\b" -r $ML/Mathlib/GroupTheory/Perm | sed "s|$ML/||"
echo "-- the U3 private helpers at the head:"; git grep -n -E "^private theorem (isFiveCycle_|IsFiveCycle\.)" $H66 -- TCSlib/Complexity/BranchingPrograms/Barrington.lean | sed "s|^$H66:||"
echo; echo "## 5. Nat.log / Finset sums (GF-F01, GF-F03 closed by LE-gf1, LE-gf4): uses at the head"
git grep -n -E "pow_log_le_add_one|pow_log_le_self|sum_le_card_nsmul|sum_le_sum" $H66 -- 'TCSlib/Complexity/BranchingPrograms/*.lean' 'TCSlib/Complexity/CircuitComplexity/FormulaArith/*.lean' 'TCSlib/Complexity/CircuitComplexity/NAND*.lean' | sed "s|^$H66:||"
grep -n -E "theorem (pow_log_le_add_one|sum_le_card_nsmul)\b" -r $ML/Mathlib/Data/Nat/Log.lean $ML/Mathlib/Algebra/Order/BigOperators/Group/Finset.lean | sed "s|$ML/||"
echo; echo "## 6. prefixVal relatives (Batteries ofBits; TCSlib)"
grep -n -E "theorem ofBits_testBit|def ofBits" $BT/Batteries/Data/Nat/*.lean | sed "s|$R/.lake/packages/||"
git grep -n -E "theorem [A-Za-z_.']*prefixVal[A-Za-z_.']*" $H66 -- 'TCSlib/*.lean' | sed "s|^$H66:||"
echo; echo "## 7. #368: the residual step and the hybridPlant lambda elsewhere (tip and #368)"
for r in $TIP $H68; do echo "-- $r"; git grep -n -E "secretVector_eq|Fin\.sum_univ_castSucc|decryptColumn P C \(Fin\.last|hybridPlant" $r -- 'TCSlib/Cryptography/*.lean' | sed "s|^$r:||"; done
echo; echo "## 8. records: ledger rows and notes mentioning the swept names (at the tip)"
git grep -n -E "maxDepth_map_le|depth_subst_le|pow_apply_eq_iff|IsCycleOn|maxDepth_le_of_forall" $TIP -- briefs/pass-shelat-ch5-8/duplication-ledger.md LatticeCryptographyPlan.md | cut -c1-240 | sed "s|^$TIP:||"; echo "(end)"
