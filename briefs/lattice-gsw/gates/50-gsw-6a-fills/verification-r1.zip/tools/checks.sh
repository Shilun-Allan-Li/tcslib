#!/bin/bash
# Gate 50 staging: git-object checks (no Lean). Usage: checks.sh <repo> <outdir> <records-tip> <tooldir>
set -u
R=$1; O=$2; TIP=$3; TD=$4
cd "$R"
L=( -- '*.lean' lean-toolchain lake-manifest.json lakefile.lean )
H66=597fb736e545706a058cc212243a13f6dadfeceb; H68=1953898b18a33ab2cd533820c5754a1aacffeb44
B66=555f0fe1b10a20d1be72386a97c6fe7a2f39c204; B68=55f553715f280be36827ad86a94c93db39ec56c3
T8=2dd2e60ed0cdd4681a7bd12fe4a86825e98db664
sig() { if git cat-file -p $1 | grep -q '^gpgsig '; then git cat-file -p $1 | grep -q 'BEGIN SSH SIGNATURE' && echo SSH || echo PGP; else echo none; fi; }
{
echo "# series.txt: #366 first-parent commits since the branch point 036d8239, and #368's commit (git objects; read-only)"
echo "records tip at staging (before this pack): $TIP"
for c in $(git rev-list --first-parent --reverse 036d823933c8248bd8894c7963e15dd0f1837075..$H66) $H68; do
  echo; echo "== $(git rev-parse $c)"
  git cat-file -p $c | sed -n '/^gpgsig/q;p' | grep -E '^(tree|parent|author|committer) '
  echo "gpgsig: $(sig $c)"
  echo "subject: $(git log -1 --format=%s $c)"
  echo "trailers: $(git log -1 --format=%B $c | grep -cE '^(Co-Authored-By|Claude-Session):') trailer lines (Co-Authored-By or Claude-Session)"
  git diff-tree --no-commit-id --numstat -r -m --first-parent $c
done
echo
echo "== ancestry"
echo "merge-base(#366 head, tip) = $(git merge-base $H66 $TIP)   (REST base.sha of #366: $B66)"
echo "merge-base(#368 head, tip) = $(git merge-base $H68 $TIP)   (REST base.sha of #368: $B68)"
echo "merge-base(#366, #368) = $(git merge-base $H66 $H68)"
echo "#366 first-parent commits since 036d8239: $(git rev-list --first-parent --count 036d8239..$H66); #368 commits on its base: $(git rev-list --count $B68..$H68)"
echo "is #359 d154c883 an ancestor of #366: $(git merge-base --is-ancestor d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 && echo yes || echo no)"
echo "is #358 a616adca an ancestor of #366: $(git merge-base --is-ancestor a616adcac0760ab56b1b0a2a4869f4763843f9ab $H66 && echo yes || echo no)"
echo "is #360 cc05f76c an ancestor of #366: $(git merge-base --is-ancestor cc05f76c43cd2d2f565ff0dfaec1c85b47e06d25 $H66 && echo yes || echo no)"
} > "$O/series.txt"

{
echo "# lean-equality.txt (paths: *.lean lean-toolchain lake-manifest.json lakefile.lean; empty list = equal)"
echo "## tip $TIP vs snapshot #8's T $T8:"; git diff --name-only $T8 $TIP "${L[@]}"; echo "(end)"
echo "## tip vs #366's REST base $B66:"; git diff --name-only $B66 $TIP "${L[@]}"; echo "(end)"
echo "## #368 base $B68 (snapshot #7 T a1fa7b65's Lean) vs snapshot #7's T:"; git diff --name-only a1fa7b652f0c235b54fc067e09b669e983daaf71 $B68 "${L[@]}"; echo "(end)"
echo "## the branch's own change: git diff 036d8239 ccca6f80 vs git diff $B66 93ae671e (byte-equal, as phase 2 records)"
cmp <(git diff 036d823933c8248bd8894c7963e15dd0f1837075 ccca6f804552f72b400c09e7a3bd694371bdf568) <(git diff $B66 93ae671e8f638e86def66dd5ac0a312c8bec4f5c) && echo EQUAL || echo DIFFERENT
echo "sha256 of git diff $B66 93ae671e: $(git diff $B66 93ae671e | sha256sum | cut -d' ' -f1)"
echo "## LE-g50 diff (93ae671e..$H66): sha256 $(git diff 93ae671e $H66 | sha256sum | cut -d' ' -f1); stat:"; git diff --stat 93ae671e $H66
echo "## LE-g50 against the records copy in le-g50-evidence.zip (log/le-g50.diff): see verification checks/leg50-diff-vs-evidence.txt"
echo "## #366 after LE-g50 vs before, Lean paths:"; git diff --name-only 93ae671e $H66 "${L[@]}"; echo "(end)"
echo "## #366 PR view (merge base..head) diffstat:"; git diff --stat $B66 $H66 | tail -1
echo "## #368 PR view diffstat:"; git diff --stat $B68 $H68
echo "## #368: Lean diff of R = merge-tree(tip, #368) against T8 equals the PR's own Lean diff?"
R68=$(git merge-tree --write-tree $TIP $H68 | head -1)
cmp <(git diff $T8 $R68 "${L[@]}") <(git diff $B68 $H68 "${L[@]}") && echo "EQUAL (R = $R68)" || echo "DIFFERENT (R = $R68)"
echo "R vs the recorded replay tree ab098201a13ad10829914bfbc6bedcbb2fe52e9e:"; git diff --name-only $R68 ab098201a13ad10829914bfbc6bedcbb2fe52e9e "${L[@]}"; echo "(end)"
} > "$O/lean-equality.txt"

{
echo "# mergetrees.txt: git merge-tree --write-tree (git $(git --version | awk '{print $3}'))"
for pair in "$TIP $H66" "$TIP $H68" "$H66 $H68"; do
  set -- $pair; t=$(git merge-tree --write-tree $1 $2); rc=$?
  echo; echo "$1 x $2: rc=$rc tree=$(echo "$t" | head -1)"
done
M66=$(git merge-tree --write-tree $TIP $H66 | head -1)
echo; echo "merge-tree(tip, #366) vs #366 head tree df05652d, Lean paths:"; git diff --name-only $M66 $H66 "${L[@]}"; echo "(end; empty = Lean-equal: the adoption condition of olean-replay-6a-land8)"
echo "merge-tree(tip, #366) vs tip, all paths:"; git diff --stat $TIP $M66 | tail -1
M3=$(git merge-tree --write-tree $H66 $H68 | head -1)
echo "merge-tree(#366, #368) vs #366 head, paths:"; git diff --name-only $H66 $M3
echo "(the two PRs share no path:)"; comm -12 <(git diff --name-only $B66 $H66 | sort) <(git diff --name-only $B68 $H68 | sort); echo "(end)"
} > "$O/mergetrees.txt"

{
echo "# frozen.txt: declaration headers and docstrings, Gate 45's frozen #359 head d154c883 -> #366 head $H66 (tools/frozen.py; no Lean)"
echo "# The diff d154c883..head also carries the tip's own Lean changes (cleanup Stage 1, #365); files outside the 6a/#360 set are listed but are not 6a."
echo "## controls (must give CHANGED 1 and DOC 1)"
python3 -I "$TD/frozen.py" --control "$R" d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 TCSlib/Complexity/BranchingPrograms/Defs.lean
python3 -I "$TD/frozen.py" --control "$R" d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean
echo "## run"
python3 -I "$TD/frozen.py" "$R" d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 $(git diff --name-only d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 -- 'TCSlib/Complexity/BranchingPrograms' 'TCSlib/Complexity/CircuitComplexity')
echo "## docstring changes of public declarations: confined to the **Proof sketch.** paragraph?"
python3 -I "$TD/docsketch.py" "$R" d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 $(git diff --name-only d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 -- 'TCSlib/Complexity/BranchingPrograms' 'TCSlib/Complexity/CircuitComplexity')
echo "## #368: $B68 -> $H68"
python3 -I "$TD/frozen.py" "$R" $B68 $H68 TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean TCSlib/Cryptography/Encryption/PublicKey/EnsembleSecurity.lean
echo "## in-house unit files: removed lines other than '  sorry' (d154c883 -> head)"
for f in BranchingPrograms/Defs BranchingPrograms/Eval BranchingPrograms/Barrington CircuitComplexity/FormulaArith/Combinators CircuitComplexity/NANDForm; do
  echo "-- $f"; git diff -U0 d154c8830fc8ffc52671b41992e7dbef61e30959 $H66 -- TCSlib/Complexity/$f.lean | grep -E '^-' | grep -v '^---' | grep -vE '^-\s+sorry\s*$'; done
echo "(end)"
} > "$O/frozen.txt"
