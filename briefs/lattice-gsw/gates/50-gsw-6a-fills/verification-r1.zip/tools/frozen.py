"""Gate 50 staging: frozen-statement check without Lean (git blobs only).
Usage: frozen.py <repo> <base> <head> <file>...
For every declaration (keyword line at column 0 after optional modifiers) it extracts the header
(from the keyword to the first ':=' / ' where' / a line starting with '|' at top level of the header,
comments stripped, whitespace normalized) and the docstring just above it. It prints, per file:
headers ADDED/REMOVED/CHANGED (public and private separately) and declarations whose docstring changed.
Controls: --control flips one header character and one docstring character in the head copy of the
first file and must report exactly one CHANGED header and one changed docstring."""
import re, subprocess, sys
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*((?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*'
                r'(theorem|lemma|def|abbrev|instance|structure|inductive|class)\b\s*([^\s:({\[]*)')
def blob(R, rev, p):
    r = subprocess.run(['git', '-C', R, 'show', f'{rev}:{p}'], capture_output=True)
    return r.stdout.decode('utf-8') if r.returncode == 0 else None
def strip_comments(t):
    out, i, depth = [], 0, 0
    while i < len(t):
        if t.startswith('/-', i):
            depth += 1; i += 2; continue
        if depth and t.startswith('-/', i):
            depth -= 1; i += 2; continue
        if depth:
            out.append('\n' if t[i] == '\n' else ' '); i += 1; continue
        if t.startswith('--', i):
            j = t.find('\n', i); j = len(t) if j < 0 else j
            out.append(' ' * (j - i)); i = j; continue
        out.append(t[i]); i += 1
    return ''.join(out)
def decls(t):
    lines = t.split('\n'); code = strip_comments(t).split('\n')
    ns, res = [], {}
    for k, l in enumerate(code):
        m = re.match(r'^namespace\s+(\S+)', l)
        if m: ns.append(m.group(1)); continue
        m = re.match(r'^end\s+(\S+)\s*$', l)
        if m and ns and ns[-1] == m.group(1): ns.pop(); continue
        m = KW.match(l)
        if not m or not l or l[0].isspace(): continue
        name = m.group(3) or f'<anon:{k+1}>'
        priv = 'private' in (m.group(1) or '') or l.startswith('private')
        hdr = []
        for j in range(k, len(code)):
            s = code[j]
            if j > k and (s.startswith('|') or (s and not s[0].isspace())): break
            cut = None
            for tok in (':=', ' where'):
                p = s.find(tok)
                if p >= 0 and (cut is None or p < cut): cut = p
            if cut is not None:
                hdr.append(s[:cut]); break
            hdr.append(s)
        h = ' '.join(' '.join(hdr).split())
        # docstring: the /-- ... -/ block ending on the line above (allow attribute lines between)
        d, j = '', k - 1
        while j >= 0 and lines[j].startswith('@['): j -= 1
        if j >= 0 and lines[j].rstrip().endswith('-/'):
            e = j
            while j >= 0 and '/--' not in lines[j]: j -= 1
            if j >= 0: d = '\n'.join(lines[j:e + 1])
        full = '.'.join(ns + [name])
        res[full] = (h, d, priv, k + 1)
    return res
def compare(R, base, head, files, mut=None):
    tot = {'ADDED': 0, 'REMOVED': 0, 'CHANGED': 0, 'DOC': 0}
    for f in files:
        b, h = blob(R, base, f), blob(R, head, f)
        if mut and f == files[0]: h = mut(h)
        B = decls(b) if b else {}; H = decls(h) if h else {}
        rows = []
        for n in sorted(set(B) | set(H)):
            if n not in B: rows.append(('ADDED', n, H[n][2])); tot['ADDED'] += 1
            elif n not in H: rows.append(('REMOVED', n, B[n][2])); tot['REMOVED'] += 1
            else:
                if B[n][0] != H[n][0]: rows.append(('CHANGED', n, H[n][2])); tot['CHANGED'] += 1
                if B[n][1] != H[n][1]: rows.append(('DOC', n, H[n][2])); tot['DOC'] += 1
        print(f'## {f}: base {len(B)} decls, head {len(H)} decls')
        for kind, n, p in rows:
            print(f'{kind}\t{"private" if p else "public"}\t{n}')
    return tot
if __name__ == '__main__':
    args = sys.argv[1:]
    ctl = args[0] == '--control'
    if ctl: args = args[1:]
    R, base, head, files = args[0], args[1], args[2], args[3:]
    if ctl:
        def mut(t):
            i = t.find('\ntheorem ')
            j = t.find(' : ', i)          # first typed binder or the statement colon of that theorem
            t = t[:j] + ' :  (' + t[j + 3:j + 4] + t[j + 4:] if False else t[:j + 3] + 'X' + t[j + 3:]
            k = t.find('/--', i - 400 if i > 400 else 0)
            k = t.rfind('/--', 0, i)
            t = t[:k + 4] + 'Z' + t[k + 4:]
            return t
        print(compare(R, base, base, files[:1], mut))
    else:
        print('TOTAL', compare(R, base, head, files))
