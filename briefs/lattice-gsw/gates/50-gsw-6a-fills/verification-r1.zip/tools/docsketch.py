"""Gate 50 staging: for each public declaration whose docstring differs between <base> and <head>, report
whether the difference is confined to its '**Proof sketch.**' paragraph (sketch text = from that marker to
the end of the docstring). Usage: docsketch.py <repo> <base> <head> <file>..."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from frozen import blob, decls
R, base, head, files = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:]
def pre(d):
    i = d.find('**Proof sketch.**')
    return d if i < 0 else d[:i]
n_ok = n_other = 0
for f in files:
    b, h = blob(R, base, f), blob(R, head, f)
    if not b or not h: continue
    B, H = decls(b), decls(h)
    for n in sorted(set(B) & set(H)):
        if B[n][1] != H[n][1] and not H[n][2]:
            if pre(B[n][1]) == pre(H[n][1]):
                n_ok += 1; print(f'SKETCH-ONLY\t{f}\t{n}')
            else:
                n_other += 1; print(f'OUTSIDE-SKETCH\t{f}\t{n}')
print(f'sketch-only {n_ok}; outside the sketch {n_other}')
