"""Gate 50 staging: source-head-r1.json (pins, commits, per-file hashes, line counts and widths).
Usage: srchead.py <repo> <tip> <out>"""
import hashlib, json, subprocess, sys
R, TIP, OUT = sys.argv[1:4]
def g(*a):
    return subprocess.run(['git', '-C', R, *a], check=True, capture_output=True).stdout
def blob(rev, p):
    r = subprocess.run(['git', '-C', R, 'show', f'{rev}:{p}'], capture_output=True)
    return r.stdout if r.returncode == 0 else None
def stats(b):
    if b is None: return None
    t = b.decode('utf-8'); L = t.split('\n')
    if L and L[-1] == '': L = L[:-1]
    return {'sha256': hashlib.sha256(b).hexdigest(), 'lines': len(L), 'max_width': max((len(x) for x in L), default=0),
            'over_100': sum(len(x) > 100 for x in L), 'tabs': sum('\t' in x for x in L),
            'trailing_space': sum(x != x.rstrip(' ') for x in L)}
def commit(c):
    raw = g('cat-file', '-p', c).decode(); hdr = raw.split('\n\n', 1)[0]
    files = g('diff-tree', '--no-commit-id', '--name-only', '-r', '-m', '--first-parent', c).decode().split()
    return {'commit': g('rev-parse', c).decode().strip(),
            'parents': [l.split()[1] for l in hdr.split('\n') if l.startswith('parent ')],
            'tree': [l.split()[1] for l in hdr.split('\n') if l.startswith('tree ')][0],
            'author': g('log', '-1', '--format=%an <%ae> %aI', c).decode().strip(),
            'committer_date': g('log', '-1', '--format=%cI', c).decode().strip(),
            'signature': ('SSH' if 'BEGIN SSH SIGNATURE' in raw else 'PGP' if 'BEGIN PGP SIGNATURE' in raw else 'none'),
            'subject': g('log', '-1', '--format=%s', c).decode().strip(),
            'files_first_parent': len(files) if len(files) > 40 else files}
H66, B66 = '597fb736e545706a058cc212243a13f6dadfeceb', '555f0fe1b10a20d1be72386a97c6fe7a2f39c204'
H68, B68 = '1953898b18a33ab2cd533820c5754a1aacffeb44', '55f553715f280be36827ad86a94c93db39ec56c3'
fp = g('rev-list', '--first-parent', '--reverse', f'036d823933c8248bd8894c7963e15dd0f1837075..{H66}').decode().split()
f66 = g('diff', '--name-only', B66, H66).decode().split()
f68 = g('diff', '--name-only', B68, H68).decode().split()
out = {
 'records_tip_before_pack': TIP,
 'records_pin': 'the commit that files briefs/lattice-gsw/gates/50-gsw-6a-fills/ (named in dispatch-r1.md)',
 'mathlib': '029db123ddaa7f8fd0d18cea3b1b33bf84dacd1e', 'batteries': '39260e31b7b3f7f05643da95242463b462dc05f1',
 'snapshot8': {'T': '2dd2e60ed0cdd4681a7bd12fe4a86825e98db664', 'map_sha256': '286777672d4e61f1be0ba98fca72b01d8cd9aa281eb811d100d7fe499679c49c'},
 'prs': {
  '366': {'state': 'open (draft)', 'branch': 'land/gsw-6a-fills', 'head': H66, 'head_tree': g('rev-parse', H66 + '^{tree}').decode().strip(),
          'merge_base': B66, 'branch_point': '036d823933c8248bd8894c7963e15dd0f1837075',
          'segments': {'gate45_in_base_#358_#359': '036d8239..76efe1ba', '#360': '76efe1ba..32ec2ef5 (= 8c5875fa..cc05f76c)',
                       'addendum_units_LE-gf1..4': '32ec2ef5..ccca6f80', 'tip_merges': 'ccca6f80..93ae671e', 'LE-g50': '93ae671e..597fb736'},
          'replays': {'snapshot6_phase2': 'ccca6f80, map 5f48b3e4 (tree deleted, superseded)',
                      'snapshot7_rereplay': '93ae671e, olean-replay-6a-land7, map 11d9fbfd0692b6332e917e84ea318147187d443c34c22a73d40827a913484dc6',
                      'LE-g50': '597fb736, olean-replay-6a-land8, map 963ddeb472f70afe9a5ae8d2a30574d3fde2348efdf20b9a9ab237b31273cf33'},
          'first_parent_commits': [commit(c) for c in fp],
          'file_stats': {p: {'base': stats(blob(B66, p)), 'gate45_frozen_d154c883': stats(blob('d154c8830fc8ffc52671b41992e7dbef61e30959', p)),
                             'head': stats(blob(H66, p))} for p in f66}},
  '368': {'state': 'open (draft)', 'branch': 'land/gsw-6b-owner-prereqs', 'head': H68, 'head_tree': g('rev-parse', H68 + '^{tree}').decode().strip(),
          'merge_base': B68,
          'replays': {'snapshot7': '1953898b on 55f55371, olean-replay-6b-prereq, map 6247b348 (evidence.zip)',
                      'snapshot8': 'R = merge-tree(tip, 1953898b) = tree ab098201a13ad10829914bfbc6bedcbb2fe52e9e, map 5a88ccf5 (evidence-s8.zip)'},
          'commits': [commit(H68)],
          'file_stats': {p: {'base': stats(blob(B68, p)), 'head': stats(blob(H68, p))} for p in f68}},
 }}
json.dump(out, open(OUT, 'w'), indent=1, sort_keys=True, ensure_ascii=False)
open(OUT, 'a').write('\n')
print('ok', len(fp), len(f66), len(f68))
