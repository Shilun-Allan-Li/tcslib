# List declarations whose keyword line is added in `git diff A B`, with the header (up to ':=' or 'where').
import subprocess, sys, re
repo, a, b = sys.argv[1:4]
diff = subprocess.run(['git','-C',repo,'diff','-U0',a,b,'--','*.lean'],capture_output=True,text=True).stdout
kw = re.compile(r'^\+\s*(?:@\[[^\]]*\]\s*)?((?:private|protected|noncomputable|nonrec|partial)\s+)*(theorem|lemma|def|abbrev|instance|structure|inductive)\s+([^\s:({\[]+)')
cur=None; out=[]
for line in diff.splitlines():
    if line.startswith('+++ '): cur=line[6:]; continue
    m=kw.match(line)
    if m:
        priv = 'private' if 'private' in line.split(m.group(2))[0] else 'public'
        out.append((cur,m.group(3),m.group(2),priv))
for f,n,k,p in out: print(f"{p}\t{k}\t{n}\t{f}")
