# Duplication-ledger extract (five-column header and DL-54): briefs/pass-shelat-ch5-8/duplication-ledger.md at f19b8056488fb01214d00915064669dda7e65cc2, lines 58-61, 86 (verbatim)

Rows from DL-30 on use a five-column layout.

| Id | New declaration (where) | Existing copy (where) | Status | Resolution |
|---|---|---|---|---|
| DL-54 | (none landed: LE-ren drops the delivered `TreeCircuit.rename`, `rename_eval`, `depth_rename` from the GSW phase 6a statements, G6A-F01) | `TreeCircuit.reidx`, `reidx_eval`, `reidx_depth` (`BooleanAnalysis/LMN/CircuitReindex.lean:24/29/46`), which the 6a formula layer uses instead | Accepted (Seyoon, 2026-11-17, 6a ruling Q1) | Move the `reidx` family into the `Complexity/` formula combinators (`Combinators`) later, so the core formula layer need not import a `BooleanAnalysis/LMN` file (deferred, out of the Pass–shelat cleanup). |
