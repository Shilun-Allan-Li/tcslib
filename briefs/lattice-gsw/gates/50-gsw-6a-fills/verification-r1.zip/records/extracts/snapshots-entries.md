# Olean snapshot register extract: briefs/pass-shelat-ch5-8/maintainer/snapshots.md at f19b8056488fb01214d00915064669dda7e65cc2, lines 16-19, 27-28 (verbatim)

## Entries

| # | T (records commit) | Map SHA-256 | Modules (files) | Date (UTC) | Status |
|---|---|---|---|---|---|
| 7 | `a1fa7b652f0c235b54fc067e09b669e983daaf71` (merge of #355, with #347; Lean = TS2 `13fc8060`) | `5105c5149901c5c4375083c1f6ad998b70c909905e4fbf430c9e96117a0f7300` | 1434 (1465) | 2026-11-17 | superseded; oleans deleted at adoption of #8; map and manifest kept; evidence `olean-snapshot-7-adopt/` |
| 8 | `2dd2e60ed0cdd4681a7bd12fe4a86825e98db664` (merge of #365; Lean = `9710ac7d`, #7's T × `5eaddd17`) | `286777672d4e61f1be0ba98fca72b01d8cd9aa281eb811d100d7fe499679c49c` | 1434 (1465) | 2026-11-17 | **current**; evidence `olean-snapshot-8-adopt/` |
