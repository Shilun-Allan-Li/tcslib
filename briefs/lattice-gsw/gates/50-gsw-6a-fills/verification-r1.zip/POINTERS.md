# POINTERS · what is not copied

- **The Lean sources** are in `sources-r1.zip` beside this ZIP (heads, the Gate-45 freeze, the merge base, before LE-g50,
  #368 base and head), and in the repository at the pinned commits.
- **The worker's delivery** (`inbox/fills/gsw-6a-fills/` on `exchange/pass-shelat-ch5-8`, final
  `607034428468ffd88adec313eb293e3e60520f59`: REPORT, 7 patches, `src/`, 939 evidence files) is not copied; phase 1
  recounted it and the phase-1 ZIP holds the recount.
- **The issued fills package** is `briefs/lattice-gsw/phase6/issued-fills-r1/` at the records pin; only `brief.md`,
  `targets.txt` and `fill-environment-addendum.md` are copied (`tools/`, `order.txt`, `closures.txt`, `roots.txt` and
  `base-sorries.txt` are not).
- **#360's addendum** (`vertexValue_eq`, `vertexDepth_eq`) has its record in `records/phase6/readers-q3/
  addendum-vertex-readers.md`; its evidence directory (`$SP/fill86/rd/ev/`) was never filed in the records. The
  addendum's downstream is covered by #366's phase-2 replay.
- **The in-house drafts' own build evidence** (`$SP/fill12/`, `$SP/fill86/`) is not filed; their content is covered by
  phase 2, the #7 re-replay and LE-g50.
- **Gate 45's pack and evidence** are `briefs/lattice-gsw/gates/45-gsw-6a/` at the records pin (only the findings and
  resolutions are copied).
- **The olean trees** (`olean-replay-6a-land8`, the #368 replays, the snapshots) are on the maintainer's host only.
