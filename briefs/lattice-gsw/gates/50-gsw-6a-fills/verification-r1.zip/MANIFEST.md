# verification-r1.zip · Gate 50 (#366 at 597fb736 with LE-g50, and #368 at 1953898b) round 1

Provenance of every entry. `SHA256SUMS` lists every entry except itself. Records were read at the records tip
`f19b8056488fb01214d00915064669dda7e65cc2` (the parent of the records pin); each was written unchanged from its git blob
(origins below, as `git <rev>:<path> (blob …)`).

## evidence/ (nested unchanged; the records' own `evidence-SHA256SUMS` beside them)
- `fills-final-r1/`: phase 1 (`aaf8be4f…`), phase 2 on #6 (`68d89dff…`), the #7 re-replay (`1799ff74…`), LE-g50 on #8
  (`51151f44…`), `landing-edits-proposed.diff` (`01c07a11…`).
- `readers-q3/`: #360's review evidence (`1c828ee0…`).
- `owner-prereqs-6b/`: #368 on #7 (`77620ab8…`) and on #8 (`e97aed58…`).

## snapshots/
- `olean-snapshot-7-adopt/`, `olean-snapshot-8-adopt/`: the adoption records of snapshots #7 (T `a1fa7b65`) and #8 (T
  `2dd2e60e`).

## records/
- `phase6/`: `fills-final-r1/review.md` (phase 1 and final verdict), `fills-final-r1/phase2.md` (phase 2, the #7
  re-replay, LE-g50), `inhouse-u1-u2/REPORT.md`, `readers-q3/review.md` and `addendum-vertex-readers.md` (#360),
  `checkpoint1-6b-review.md` (Q-C1, G6B-C1-F03), `rulings.md`, `plan-section.md` (r3), and the issued fills job's
  `brief.md`, `targets.txt` and `fill-environment-addendum.md`.
- `gate45/`: Gate 45's findings and resolutions, rounds 1 and 2.
- `policy.md`.
- `extracts/`: verbatim line ranges (each file's first line names its source and ranges) of the decision log
  (`LatticeCryptographyPlan.md`), the duplication ledger (header and DL-54) and the snapshot register (#7, #8).

## checks/ and tools/ (written at staging; git objects only, no Lean)
- `series.txt`: #366's 22 first-parent commits and #368's commit: parents, trees, authors, signature kinds, trailers,
  numstat; ancestry.
- `lean-equality.txt`: the tip vs snapshot #8's T and #366's merge base; the branch's own change across the tip merges;
  LE-g50's diff; #368's merge with the tip vs its #8 replay tree `ab098201`.
- `mergetrees.txt`: #366 × tip, #368 × tip, #366 × #368.
- `frozen.txt`: declaration headers and docstrings from Gate 45's `d154c883` to the head, with two controls; whether the
  docstring changes are confined to proof sketches; #368's two files; the in-house files' removed lines.
- `leg50-diff-vs-evidence.txt`: LE-g50's git diff vs the copy in its evidence ZIP.
- `dup-sweep.txt`: the duplication sweep's greps (inventory of new declarations, names, shapes, Mathlib relatives,
  records). The judgement is in `pack-r1.md`, question 6.
- `tools/`: `checks.sh`, `dupsweep.sh`, `frozen.py`, `docsketch.py`, `newdecls.py`, `srchead.py`.

## pr/
- `pr366-rest-fields.json`, `pr368-rest-fields.json`: number, title, state, draft, head and base refs and SHAs, counts and
  timestamps, from the REST API at staging.

## Origins of the records, evidence and snapshot entries
```text
aaf8be4f1b684000e12d6ebe6d6a1e9ea1f1577f4d933bb6ae612af1b6253ee9  evidence/fills-final-r1/gsw-6a-fills-final-r1-phase1-evidence.zip  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/gsw-6a-fills-final-r1-phase1-evidence.zip (blob ec85e954a236)
68d89dff5a5fd7d30c0f077be898c046e3f6962d4eb73488b500d5428be482ee  evidence/fills-final-r1/gsw-6a-fills-final-r1-phase2-evidence.zip  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/gsw-6a-fills-final-r1-phase2-evidence.zip (blob c717b1c74b2e)
1799ff74f510a2d44590bdbceb8e1e62cd023ca9d9aba43047eca44c06d80fac  evidence/fills-final-r1/gsw-6a-fills-final-r1-phase2-s7-evidence.zip  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/gsw-6a-fills-final-r1-phase2-s7-evidence.zip (blob 0ed1521bddc2)
51151f449278f1bd4921393c86d5c9190eb9b30b4a5c0c4e31eaa9f8d3740893  evidence/fills-final-r1/le-g50-evidence.zip  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/le-g50-evidence.zip (blob 4afb698d2792)
01c07a1194c76da3170e6724371b7fe07f7026a2237f1910fb1272a7c1b453cc  evidence/fills-final-r1/landing-edits-proposed.diff  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/landing-edits-proposed.diff (blob a0db7863d355)
4f4645ce0498383a1d9d22f5824277e6603073e705e1b722d6d3ad203d5614b5  evidence/fills-final-r1/evidence-SHA256SUMS  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/evidence-SHA256SUMS (blob 45ee7f1374e7)
1c828ee08b5b9d668efe74f317d2c7eaab9d867ef83a2b1fa66b39fe5a6e0e6b  evidence/readers-q3/gsw-6a-readers-q3-evidence.zip  git f19b8056488f:briefs/lattice-gsw/phase6/readers-q3/gsw-6a-readers-q3-evidence.zip (blob b3d39b360cdb)
d3920d1f7a913b1d208e9f355dbdae6f419eb26d2013ec90de4e6ad35f16ccec  evidence/readers-q3/evidence-SHA256SUMS  git f19b8056488f:briefs/lattice-gsw/phase6/readers-q3/evidence-SHA256SUMS (blob 83995e96f978)
77620ab881f951caba8fefce74a84247407aeaa13cdaf74c0cc3a591ea56f129  evidence/owner-prereqs-6b/evidence.zip  git f19b8056488f:briefs/lattice-gsw/phase6/owner-prereqs-6b/evidence.zip (blob 622f950c3a38)
e97aed5847d150d1cc9466b23c66a52e8dd2b978cabd44841a480c35fbe8dd29  evidence/owner-prereqs-6b/evidence-s8.zip  git f19b8056488f:briefs/lattice-gsw/phase6/owner-prereqs-6b/evidence-s8.zip (blob 7ef1e9ddacd1)
f32c527d08627ee06998fdb7eb9f895b0eb9e4ec8f1e7aee597587b6477c10be  evidence/owner-prereqs-6b/evidence-SHA256SUMS  git f19b8056488f:briefs/lattice-gsw/phase6/owner-prereqs-6b/evidence-SHA256SUMS (blob 27d6e7a2f017)
3ef5c8d3213cb18f1344f10984e4a113bbd21a4aeae487b29dfaf649a6d73144  snapshots/olean-snapshot-7-adopt/README.md  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/README.md (blob dbe70a024b06)
357946f1b933bb47a37f507097b64ebc74612b524977aed5288d0294863f1725  snapshots/olean-snapshot-7-adopt/basecheck.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/basecheck.out (blob 1d6977c4a07d)
4bdd94df083f9cf95b2c1cab008ad123acb6f763f4d8cb8ea0891b3555ce1de2  snapshots/olean-snapshot-7-adopt/olean-snapshot.files-a1fa7b65.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/olean-snapshot.files-a1fa7b65.txt (blob dd283ca582d6)
5105c5149901c5c4375083c1f6ad998b70c909905e4fbf430c9e96117a0f7300  snapshots/olean-snapshot-7-adopt/olean-snapshot.map-a1fa7b65.tsv  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/olean-snapshot.map-a1fa7b65.tsv (blob 66ad08b55783)
8736bb0768f77e8b4864afb3ab7ad269326d3f10e9c84061b79965275e8d5441  snapshots/olean-snapshot-7-adopt/outputs.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/outputs.txt (blob cb0a0a2c04d0)
5e1f93de69319591cba8059fc783b1bb749d60e3d1e0398862067d672ce6d46b  snapshots/olean-snapshot-7-adopt/procscan-pre-overlay.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/procscan-pre-overlay.txt (blob b99b0f7552f0)
f7542dd8e00ca5cd6b6a23bea84eac5cc0f583ac8c3ac54ae9d219f4bcf8e43d  snapshots/olean-snapshot-7-adopt/procscan-pre-swap.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/procscan-pre-swap.txt (blob def6e4dbb779)
957381de4e4ab08e9c7134b109005048a60b12b1364880eeaeacafd272d2fdea  snapshots/olean-snapshot-7-adopt/replay-statecheck.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/replay-statecheck.out (blob 9db80e9ee60f)
4014c9b35e6f1ea99fcd502dab746764e94f5c72c3c42b4b17a896db806e1fcb  snapshots/olean-snapshot-7-adopt/replay-verify.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/replay-verify.out (blob 9a5eebadb397)
f9798e14e75c8914c795d43c3e8b1a472c2599ed46f7012b9cf1b22a02d40065  snapshots/olean-snapshot-7-adopt/state-init-a1fa7b65.json.gz  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/state-init-a1fa7b65.json.gz (blob e7598e44e16f)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/step3-diff.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/step3-diff.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/tip-since-T-diff.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/tip-since-T-diff.txt (blob e69de29bb2d1)
8d38b622c3879c97587c8bad1c4964c7648be54537240876086b031e32a3c92f  snapshots/olean-snapshot-7-adopt/tools/procscan.sh  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/tools/procscan.sh (blob 7bbf95db5607)
1661287c5215960f9d555a821148a81914d5fbb31edee00de5b342c3bdf8057d  snapshots/olean-snapshot-7-adopt/tools/replayverify.py  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/tools/replayverify.py (blob 7219dfff2ad7)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/v6-final/changed.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v6-final/changed.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/v6-final/extra.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v6-final/extra.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/v6-final/missing.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v6-final/missing.txt (blob e69de29bb2d1)
dd3e138c8bb0a8db91ee1e5844b52657b08d1f5d6ce7b5a36380fc54441a19e8  snapshots/olean-snapshot-7-adopt/v7-statecheck.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v7-statecheck.out (blob 07620d7af09a)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/v7/changed.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v7/changed.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/v7/extra.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v7/extra.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-7-adopt/v7/missing.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-7-adopt/v7/missing.txt (blob e69de29bb2d1)
261c4285c59cfd33f5fd50744d9baab24201328980bbfb8af5736b4edf7062af  snapshots/olean-snapshot-8-adopt/README.md  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/README.md (blob 1c254a559c24)
34288f5a24c518623a97195305c7c0317aaf04280475256131d14642f9542b12  snapshots/olean-snapshot-8-adopt/basecheck.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/basecheck.out (blob e8fe83d71713)
3d3b3e114c59a446841c382ff3941e02602d23f85edb76d2b608b6933809d6f2  snapshots/olean-snapshot-8-adopt/land7-after-swap.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/land7-after-swap.out (blob ef6cd1929438)
597e410e33ed6d634024870d2928dacbc077578143b58d71b6ddbecee0c3c047  snapshots/olean-snapshot-8-adopt/olean-snapshot.files-2dd2e60e.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/olean-snapshot.files-2dd2e60e.txt (blob 41c8e5acdebd)
286777672d4e61f1be0ba98fca72b01d8cd9aa281eb811d100d7fe499679c49c  snapshots/olean-snapshot-8-adopt/olean-snapshot.map-2dd2e60e.tsv  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/olean-snapshot.map-2dd2e60e.tsv (blob ce41c27a048c)
687822f081ac71639bfabe931b2ad9c4a5553acde8990184a175b76b133c443d  snapshots/olean-snapshot-8-adopt/outputs.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/outputs.txt (blob 8dc982c63697)
b93fb44dc7f2b1d1d71476d81d760e57642decc68b29f09eeb21848979d1c91c  snapshots/olean-snapshot-8-adopt/procscan-pre-overlay.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/procscan-pre-overlay.txt (blob 461cf040013e)
01ed39f413aa825a269a4f7e23679a9a4e4af2052e79fd142f2ea4b501dd5487  snapshots/olean-snapshot-8-adopt/procscan-pre-swap.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/procscan-pre-swap.txt (blob 51f9f93f7b4f)
0162c9014959d2b831b8ea09e9e95d8b032c857494d6a01777cb2a08b6272926  snapshots/olean-snapshot-8-adopt/replay-statecheck.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/replay-statecheck.out (blob 9d3e87e2f4a6)
36c2e465a266e01534c3fa0002951fb64d85028f1d95a2510a8746fde50abf23  snapshots/olean-snapshot-8-adopt/replay-verify.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/replay-verify.out (blob b966aef4c6be)
cc593c25c6bdfef20c5047903ad4df8c1194266de257877861e7cc6cdb26bedd  snapshots/olean-snapshot-8-adopt/state-init-2dd2e60e.json.gz  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/state-init-2dd2e60e.json.gz (blob 8aa033da6da3)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/step3-diff.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/step3-diff.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/tip-since-T-diff.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/tip-since-T-diff.txt (blob e69de29bb2d1)
8d38b622c3879c97587c8bad1c4964c7648be54537240876086b031e32a3c92f  snapshots/olean-snapshot-8-adopt/tools/procscan.sh  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/tools/procscan.sh (blob 7bbf95db5607)
1661287c5215960f9d555a821148a81914d5fbb31edee00de5b342c3bdf8057d  snapshots/olean-snapshot-8-adopt/tools/replayverify.py  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/tools/replayverify.py (blob 7219dfff2ad7)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/v7-final/changed.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v7-final/changed.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/v7-final/extra.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v7-final/extra.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/v7-final/missing.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v7-final/missing.txt (blob e69de29bb2d1)
54abbff274673647aadda70ae07a64cc285cb881212abf91e0fa1e28fb103ef7  snapshots/olean-snapshot-8-adopt/v8-statecheck.out  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v8-statecheck.out (blob d576df1c1cb2)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/v8/changed.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v8/changed.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/v8/extra.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v8/extra.txt (blob e69de29bb2d1)
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  snapshots/olean-snapshot-8-adopt/v8/missing.txt  git f19b8056488f:briefs/pass-shelat-ch5-8/maintainer/olean-snapshot-8-adopt/v8/missing.txt (blob e69de29bb2d1)
b8d76fa92ad722748a6d8b7e5237e8db1d4a89d8e62411e200fccbd227bb59b5  records/phase6/fills-final-r1/review.md  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/review.md (blob 032d71054d44)
34b0e4529c0fc67d9bab0f8ff959b1c428a70483a61cf854cf017370416bbf2c  records/phase6/fills-final-r1/phase2.md  git f19b8056488f:briefs/lattice-gsw/phase6/fills-final-r1/phase2.md (blob 1e117d63a521)
9f4fe1d51ea4f77227dcb88fab6d2269bf9d4f32163bb9128683f9e2d1391711  records/phase6/inhouse-u1-u2/REPORT.md  git f19b8056488f:briefs/lattice-gsw/phase6/inhouse-u1-u2/REPORT.md (blob f164d3b87981)
ae448305070fde33941c531f1d823f9a0c82cb268718620ee9b321a0df950f5a  records/phase6/readers-q3/review.md  git f19b8056488f:briefs/lattice-gsw/phase6/readers-q3/review.md (blob df2fd5f3ba9c)
ca42f7db9849219fb1faf6688db8e072de06f99b787e130f57d590afa0832591  records/phase6/readers-q3/addendum-vertex-readers.md  git f19b8056488f:briefs/lattice-gsw/phase6/readers-q3/addendum-vertex-readers.md (blob 65b81954ac25)
5fe57fc9075fd1988add49222b66c37deb2ac40ba5a5c6fc1371f1a8eeb34358  records/phase6/checkpoint1-6b-review.md  git f19b8056488f:briefs/lattice-gsw/phase6/checkpoint1-6b-review.md (blob 7da4e271778a)
312fef4576b388222d69eddec186c2ac4259e5de95488fca42e6861438ad3d5d  records/phase6/rulings.md  git f19b8056488f:briefs/lattice-gsw/phase6/rulings.md (blob 9b07ed400635)
06824b3db875e7388771b6f7a5e78d62bf7d77fa35571fc3a9deeebc329214fd  records/phase6/plan-section.md  git f19b8056488f:briefs/lattice-gsw/phase6/plan-section.md (blob e209dd7ee5bc)
eba5b9f5c7cce2eeebc8f5b43a5f44bad1c1d94409f7fd860e3f9a0f50c7bce4  records/phase6/issued-fills-r1/brief.md  git f19b8056488f:briefs/lattice-gsw/phase6/issued-fills-r1/brief.md (blob 67015aee49eb)
90040eaacd15c2e5683d788d5ca303339315221b16ea2de417f5fdc6115e1ebf  records/phase6/issued-fills-r1/targets.txt  git f19b8056488f:briefs/lattice-gsw/phase6/issued-fills-r1/targets.txt (blob a12072b50daa)
0eff871c9d8916be2df9edfa8b8b24bdeb06d4ad613bb37d1dcbd7731ca7fe6c  records/phase6/issued-fills-r1/fill-environment-addendum.md  git f19b8056488f:briefs/lattice-gsw/phase6/issued-fills-r1/fill-environment-addendum.md (blob b021633bc5a5)
dc8cd2d29b03165470cf9e943f8f185dc03cb89a576cd91e3cc9c57e60654b3c  records/gate45/findings-r1.md  git f19b8056488f:briefs/lattice-gsw/gates/45-gsw-6a/findings-r1.md (blob 44544ee2d87e)
0a7ed19136085dfe2e9b9e47ef219bde31141e5e8086dfc12b165aee35813540  records/gate45/findings-r2.md  git f19b8056488f:briefs/lattice-gsw/gates/45-gsw-6a/findings-r2.md (blob c4252c2fa5aa)
4de570d238c38732329eee4008e496b70fdbb7a40673564f9741a48be97c92ab  records/gate45/resolutions-r1.md  git f19b8056488f:briefs/lattice-gsw/gates/45-gsw-6a/resolutions-r1.md (blob d989d2ca0fc8)
6b2484b2325ff07d31966b97d015c7014b442ef758d20ec04fb76173e7b90cda  records/gate45/resolutions-r2.md  git f19b8056488f:briefs/lattice-gsw/gates/45-gsw-6a/resolutions-r2.md (blob e5346733902a)
6599b12230e3879bc0e1fb22c0376ea6201bca8b7edd79dfc55da43986f991d4  records/policy.md  git f19b8056488f:policy.md (blob 0ecbc562afdf)
c038544aeb776597cebaba7006e6f33b6f34e47e1c0911b57091ac8b44a318fb  records/extracts/decision-log-lattice.md  extract (verbatim line ranges; header names them)
a19ab26131501fe8f32f02622de7c8da4bece7c6d9c1cb3a8b2b8202080123c4  records/extracts/duplication-ledger-header-DL54.md  extract (verbatim line ranges; header names them)
bd5b669f658bd0104a6c8b8f27e1a2a477f1cc60e00d95174284ee43ab29ae9d  records/extracts/snapshots-entries.md  extract (verbatim line ranges; header names them)
```
