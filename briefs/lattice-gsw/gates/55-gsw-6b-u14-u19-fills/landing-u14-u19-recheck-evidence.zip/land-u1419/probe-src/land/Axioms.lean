import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Bootstrap
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Leveled
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Circular
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.LeveledSecurity
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.PolyRatio
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Asymptotic
open Lean Elab Command

/-! land-u1419 re-check on the landing head of `land/gsw-6b-u14-u19` (records tip + U14+U16 + U15+U17 + U18+U19 +
LE-u1517-doc + LE-u1819-doc): axiom census of every constant stored by the six owner modules, with the `sorryAx` trace;
the 15 targets and the two allowed public helpers by name; a `sorry` control. (Form: g6b-u1517-1819 `full/Axioms`.) -/

theorem g6bSorryControl : (1 : Nat) = 2 := sorry

/-- Constants in the dependency closure of `n` that use `sorryAx` directly. -/
partial def sorrySources (env : Environment) (n : Name) : StateM (NameSet × NameSet) Unit := do
  let (vis, _) ← get
  if vis.contains n then return
  modify fun (v, s) => (v.insert n, s)
  match env.find? n with
  | none => return
  | some ci =>
    let used := ci.type.getUsedConstants ++ ((ci.value?.map (·.getUsedConstants)).getD #[])
    if used.contains ``sorryAx then modify fun (v, s) => (v, s.insert n)
    for m in used do sorrySources env m

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Bootstrap, `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Leveled, `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Circular, `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.LeveledSecurity, `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.PolyRatio, `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Asymptotic]
  let pfx := `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW
  let targets : List Name := [`encrypts_bootNAND, `encrypts_bootGate, `decrypt_fheEval, `decrypt_fheEvalCircuit, `decrypt_keygen_fheEvalCircuit, `bootNoise_le, `encrypts_leveledEval, `decrypt_keygen_leveledEvalCircuit, `distAdv_fheView_noEvk_le, `distAdv_levelHybrid_le, `distAdv_leveledView_le, `Parameters.ofFamily_columns_le, `bootRatio_le_poly, `decrypt_fheEval_of_ratio, `decrypt_leveledEval_of_ratio, `indCPA_of_dlweAssumption, `leveledINDCPA_of_dlweAssumption].map (pfx ++ ·)
  let idxs := mods.filterMap env.getModuleIdx?
  IO.println s!"OWNERS\t{mods.length}\t{idxs.length}"
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        let mi := (env.header.moduleNames[i.toNat]!).toString
        let tr := if axs.contains ``sorryAx then
            let ((), (_, s)) := (sorrySources env n).run ({}, {})
            s!"\tTRACE\t{(s.toList.map toString).toArray.qsort (· < ·) |>.toList}"
          else ""
        out := out.push s!"{tag}\t{mi.splitOn "." |>.getLast!}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}{tr}"
    | none => pure ()
  for n in targets do
    if env.contains n then
      let axs ← liftCoreM (Lean.collectAxioms n)
      out := out.push s!"TARGET\t-\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    else
      out := out.push s!"MISSING\t-\t{n}\t-"
  for l in out.qsort (· < ·) do
    IO.println l
  let c ← liftCoreM (Lean.collectAxioms `g6bSorryControl)
  IO.println s!"CONTROL\tg6bSorryControl\t{c.toList}"

#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypts_bootNAND
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypts_bootGate
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt_fheEval
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt_fheEvalCircuit
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt_keygen_fheEvalCircuit
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.bootNoise_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.encrypts_leveledEval
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt_keygen_leveledEvalCircuit
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.distAdv_fheView_noEvk_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.distAdv_levelHybrid_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.distAdv_leveledView_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Parameters.ofFamily_columns_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.bootRatio_le_poly
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt_fheEval_of_ratio
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.decrypt_leveledEval_of_ratio
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.indCPA_of_dlweAssumption
#print axioms TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.leveledINDCPA_of_dlweAssumption
