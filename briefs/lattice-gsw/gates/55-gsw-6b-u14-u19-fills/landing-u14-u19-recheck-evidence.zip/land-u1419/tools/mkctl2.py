"""mkctl2.py <sealed-probe.lean> <head-source.lean> <pairs.tsv> <out-sealed.lean> <out-open.lean>: the g6b-u1213 mkctl.py
liveness pairs (appended to the canonical coe-A sealed copy of an owner, sealed, and to the owner's head source, open),
extended by g6b-u1416 with CUSTOM rows. pairs.tsv rows: <definition>\t<reader> (full names; NEG reads the body with
`by intros; first | exact rfl | exact Iff.rfl` on the reader's statement, POS goes through the reader), or
CUSTOM\t<definition>\t<NEG example line>\t<POS example line> (given verbatim). Prints the NEG/POS line numbers."""
import sys
sealed, src, pairs, outs, outo = sys.argv[1:6]
P = [l.rstrip('\n').split('\t') for l in open(pairs, encoding='utf-8') if l.strip() and not l.startswith('#')]
for base, out, tag in ((sealed, outs, 'sealed'), (src, outo, 'open')):
    L = open(base, encoding='utf-8').read().rstrip('\n').split('\n')
    L += ['', 'set_option linter.unusedTactic false', 'set_option linter.unreachableTactic false',
          'set_option linter.unusedVariables false', '']
    for i, row in enumerate(P, 1):
        L.append(f'section G6bCtl{i}')
        if row[0] == 'CUSTOM':
            d, negl, posl = row[1], row[2], row[3]
            L.append(negl); neg = len(L); L.append(posl); pos = len(L); r = '(custom)'
        else:
            d, r = row
            L.append(f'example : type_of% @{r} := by intros; first | exact rfl | exact Iff.rfl'); neg = len(L)
            L.append(f'example : type_of% @{r} := @{r}'); pos = len(L)
        L.append(f'end G6bCtl{i}')
        print(f'{tag}\t{i}\t{d}\t{r}\tNEG {neg}\tPOS {pos}')
    open(out, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
