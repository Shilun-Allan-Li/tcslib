#!/usr/bin/env bash
# land-u1419 re-check (copied from g6b-u1517-1819): one replay of a head on snapshot #11 (snapshots.md job recipe): cp -al copy, Mathlib overlay,
# NthRootLemmas (built by mathlibextra.sh through the slot check in the first tree, hard-linked in later trees), plan at
# the head against B6, build through runq.sh, accept (permod, stateplan update/check, link counts, admissions).
# Usage: replay.sh <name> <head> [<tree to link NthRootLemmas from>]
set -eu
# fix from g6b-u1517-1819 P2-7: the slot poll must not abort under set -e when pgrep finds 0 processes
N=$1; H=$2; FROM=${3:-}
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/land-u1419; T=$G/recipe/olean-advance-a6d01b1b/tools-used; W=$G/wt; R=/home/user/tcslib; B=bff0567b6c4b6b724c8fd20ff3ef92258eb3fc9d
OUT=$G/olean-replay-$N; A=$G/run/$N; mkdir -p $A
free=$(df -BM --output=avail / | tail -1 | tr -dc 0-9); echo "disk before copy ${free}M" > $A/disk.log; [ "$free" -ge 2000 ]
test ! -e $OUT
test "$(git -C $W rev-parse HEAD)" = "$H"
cp -al $SP/olean-snapshot $OUT
(cd $OUT && find . -type f | wc -l; find . -type f -links 1 | wc -l) > $A/copy.log
bash $T/mloverlay.sh $OUT > $A/mloverlay.log
X=Mathlib/Analysis/SpecialFunctions/Pow/NthRootLemmas
if [ -n "$FROM" ]; then ln $FROM/$X.olean $OUT/$X.olean; else
  while :; do n=$(pgrep -fc "bin/lean " || true); free=$(df -BM --output=avail / | tail -1 | tr -dc 0-9)
    [ "$free" -ge 2000 ]; [ "$n" -le 2 ] && break
    echo "wait slots=$n before mathlibextra $(date -u +%FT%TZ)" >> $G/logs/slot.log; sleep 60; done
  echo "start mathlibextra slots=$n disk=${free}M $(date -u +%FT%TZ)" >> $G/logs/slot.log
  bash $T/mathlibextra.sh $OUT $X $A/mathlibextra.log
  echo "end mathlibextra $(date -u +%FT%TZ)" >> $G/logs/slot.log
fi
sha256sum $OUT/$X.olean > $A/nthroot.sha256
python3 -I $T/downorder.py $R $H $B $A/order > $A/downorder.log
python3 -I $T/fullorder.py $R $H $A/full-order.txt > $A/fullorder.log
python3 -I $T/stateplan.py init $R $B $SP/olean-snapshot.files-bff0567b.txt $A/state.json > $A/init.log
python3 -I $T/stateplan.py plan $R $H $A/full-order.txt $A/state.json $A/plan > $A/plan.log
bash $G/tools/runq.sh $T/runner.py $W $A/plan/queue.txt $OUT $A/build 1
python3 -I $T/permod.py $A/build $A/build/permod.tsv > $A/permod.log 2>&1
python3 -I $T/stateplan.py update $R $H $A/state.json $A/build/results.jsonl $OUT > $A/update.log
python3 -I $T/stateplan.py check $R $H $A/full-order.txt $A/state.json $OUT $A/check.txt > $A/check.log
(cd $OUT && find . -name '*.olean' -type f -links 1 | sort) > $A/links1.txt
(cd $OUT && find . -name '*.olean' -type f -links 1 | sort | xargs sha256sum) > $A/rebuilt-oleans.sha256
python3 -I $G/tools/admissions.py /home/user/tcslib/briefs/lattice-gsw/phase6/issued-6b-fills-r1/base-sorries.txt $A/build $W > $A/admissions.txt
cat $A/downorder.log $A/plan.log; tail -1 $A/permod.log; cat $A/update.log; tail -1 $A/check.log; echo "links1 $(wc -l < $A/links1.txt)"; head -4 $A/admissions.txt
