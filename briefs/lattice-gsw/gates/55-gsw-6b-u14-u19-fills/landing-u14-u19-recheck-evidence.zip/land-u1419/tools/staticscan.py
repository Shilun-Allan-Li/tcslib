"""staticscan.py <base> <head>...pairs as name=base:head: comment-stripped counts of sorry/admit/native_decide/axiom/opaque,
new set_option/attribute/@[...] lines vs base, lines, max width (Python len), lines over 100, tabs, trailing spaces,
micro sign U+00B5."""
import sys, re
def strip(s):
    s = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), s, flags=re.S)
    return re.sub(r'--[^\n]*', '', s)
for arg in sys.argv[1:]:
    name, paths = arg.split('='); bp, hp = paths.split(':')
    for tag, p in (('base', bp), ('head', hp)):
        s = open(p, encoding='utf-8').read(); c = strip(s); L = s.split('\n')
        toks = {t: len(re.findall(r'\b' + t + r'\b', c)) for t in ('sorry', 'admit', 'native_decide', 'axiom', 'opaque')}
        opts = sorted(l.strip() for l in c.split('\n') if re.match(r'\s*(set_option|attribute|@\[)', l))
        print(f'{name} {tag}: lines {len(L) - (L[-1] == "")} maxwidth {max(map(len, L))} over100 {sum(len(l) > 100 for l in L)} '
              f'tabs {s.count(chr(9))} trailing {sum(l != l.rstrip() for l in L)} micro {s.count(chr(0xB5))} tokens {toks}')
        print(f'  options/attributes: {opts}')
