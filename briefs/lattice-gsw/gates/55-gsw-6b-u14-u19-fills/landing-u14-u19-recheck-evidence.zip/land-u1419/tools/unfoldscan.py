"""unfoldscan.py <collector-log> <file>...: every identifier passed to rw/rwa/simp/simp only/simpa/simp_all/dsimp/unfold/
delta/field_simp/norm_num [..] or after `unfold`/`delta`, in the proof text of each file (comments stripped), resolved
against the collector's CAT rows (every TCSlib definition of the closure). Prints each identifier with DEF (matches a
TCSlib definition by full name or by a dotted suffix) or '-' and a summary."""
import sys, re, json
log, files = sys.argv[1], sys.argv[2:]
defs = set()
for l in open(log, encoding='utf-8'):
    if l.startswith('CAT '):
        r = json.loads(l[4:]); defs.add(r['name']['display'])
def isdef(tok):
    t = tok.lstrip('←').strip()
    return [d for d in defs if d == t or d.endswith('.' + t)]
tot, hits = 0, 0
for f in files:
    src = open(f, encoding='utf-8').read()
    src = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), src, flags=re.S)
    src = re.sub(r'--[^\n]*', '', src)
    ids = []
    for m in re.finditer(r'\b(rw|rwa|rewrite|simp|simp only|simpa|simp_all|dsimp|dsimp only|field_simp|norm_num|unfold|delta|erw)\b(\s+only)?\s*\[([^\]]*)\]', src):
        ln = src[:m.start()].count('\n') + 1
        for tok in m.group(3).split(','):
            tok = tok.strip()
            tok = re.sub(r'^←\s*', '', tok)
            tok = re.sub(r'\s.*$', '', tok, flags=re.S)
            if tok: ids.append((ln, m.group(1), tok))
    for m in re.finditer(r'\b(unfold|delta)\s+([^\[\n][^\n]*)', src):
        ln = src[:m.start()].count('\n') + 1
        for tok in m.group(2).split():
            if re.match(r'^[A-Za-z_]', tok): ids.append((ln, m.group(1), tok))
    for ln, tac, tok in ids:
        d = isdef(tok); tot += 1; hits += bool(d)
        print(f'{f.split("/")[-1]}\t{ln}\t{tac}\t{tok}\t{"DEF " + ",".join(sorted(d)[:3]) if d else "-"}')
print(f'SUMMARY identifiers {tot}; resolving to a TCSlib definition {hits}')
