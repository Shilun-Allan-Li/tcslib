#!/usr/bin/env bash
# land-u1419 phase 2 (the g6b-u1213 probes.sh, paths moved): copy named probe sources from probe-src/ into the scratch worktree's
# G6bProbe/ and run them one at a time through runq.sh + the recipe's runner_full.py (lean -DmaxErrors=0, no -o).
# Usage: probes.sh <batch-name> <tree> <expected-head> <ProbeName>...
set -u
B=$1; TREE=$2; HEADX=$3; shift 3
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
G=$SP/land-u1419; W=$G/wt; PS=$G/probe-src; R=$G/runs/$B
S=$G/recipe/olean-advance-a6d01b1b/tools-used
export TMPDIR=$G/tmp; mkdir -p $TMPDIR $R $W/G6bProbe
test "$(git -C $W rev-parse HEAD)" = "$HEADX" || { echo "worktree not at $HEADX"; exit 1; }
: > $R/queue.txt
for p in "$@"; do
  mkdir -p "$(dirname $W/G6bProbe/$p.lean)"; cp $PS/$p.lean $W/G6bProbe/$p.lean
  sha256sum $W/G6bProbe/$p.lean >> $R/probe-sources.sha256; echo G6bProbe/$p >> $R/queue.txt
done
bash $G/tools/runq.sh $S/runner_full.py $W $R/queue.txt $TREE $R 0
python3 -I -c 'import json,sys
for l in open(sys.argv[1]):
  r=json.loads(l)
  if "module" in r: print(r["module"], "rc", r["rc"], "errors", r["errors"], "sorry", r["sorry"], "warnings", r["warnings"], r["seconds"], "s")' $R/results.jsonl
