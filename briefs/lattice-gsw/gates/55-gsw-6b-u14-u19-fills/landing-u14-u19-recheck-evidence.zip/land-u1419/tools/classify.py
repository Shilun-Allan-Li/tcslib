"""classify.py <repo> <base-rev> <head-rev> <targets.tsv>: (1) every removed line of `git diff base head` over the six
owned files, classified against the base file (sorry body / module docstring sentence / proof-sketch paragraph line /
private-helper docstring / comment / other); (2) for each target: header (keyword through the line holding `:= by`) and
statement prose (its docstring up to `**Proof sketch.**`) byte-identical between base and head."""
import sys, subprocess, re
repo, base, head, tg = sys.argv[1:5]
G = 'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/'
OWN = ['Bootstrap', 'Leveled', 'Circular', 'LeveledSecurity', 'PolyRatio', 'Asymptotic']
show = lambda r, p: subprocess.run(['git', '-C', repo, 'show', f'{r}:{p}'], capture_output=True, check=True).stdout.decode().split('\n')
def ctx(lines):
    """per line: ('module'|'doc-prose'|'doc-sketch'|'code'|'comment', owner-decl-line)"""
    out = []; state = 'code'; depth = 0; sk = False; kind = None
    for i, l in enumerate(lines):
        if state == 'code':
            s = l.lstrip()
            if s.startswith('/-!'): state, kind, sk = 'doc', 'module', False
            elif s.startswith('/--'): state, kind, sk = 'doc', 'decl', False
            elif s.startswith('/-'): state, kind, sk = 'doc', 'comment', False
            elif s.startswith('--'): out.append('comment'); continue
            else: out.append('code'); continue
        if '**Proof sketch.**' in l: sk = True
        out.append('module' if kind == 'module' else 'comment' if kind == 'comment' else ('doc-sketch' if sk else 'doc-prose'))
        if '-/' in l: state = 'code'
    return out
def next_decl(lines, i):
    for j in range(i, len(lines)):
        m = re.match(r'^(private\s+)?(theorem|lemma|def|abbrev|instance|structure)\s+(\S+)', lines[j])
        if m: return (bool(m.group(1)), m.group(3))
    return (None, None)
total = {}
print('## removed lines, classified against', base[:12])
for o in OWN:
    p = G + o + '.lean'; B = show(base, p); c = ctx(B)
    d = subprocess.run(['git', '-C', repo, 'diff', '-U0', base, head, '--', p], capture_output=True, text=True).stdout
    ln = None; counts = {}; others = []
    for l in d.split('\n'):
        m = re.match(r'^@@ -(\d+)(?:,(\d+))? ', l)
        if m: ln = int(m.group(1)); continue
        if l.startswith('-') and not l.startswith('---'):
            t = l[1:]; k = c[ln - 1]
            if k == 'code' and t.strip() == 'sorry': cl = 'sorry body'
            elif k == 'module': cl = 'module docstring line'
            elif k == 'doc-sketch':
                priv, nm = next_decl(B, ln - 1); cl = f'proof-sketch line ({nm})'
            elif k == 'doc-prose':
                priv, nm = next_decl(B, ln - 1); cl = f'docstring prose before the sketch ({"private " if priv else ""}{nm})'
            elif k == 'comment': cl = 'comment'
            else: cl = 'code (other)'
            counts[cl] = counts.get(cl, 0) + 1
            if not cl.startswith(('sorry', 'proof-sketch')): others.append((ln, cl, t))
            ln += 1
    for k, v in sorted(counts.items()): print(f'{o}.lean: {k}: {v}')
    for ln_, cl, t in others: print(f'    {o}.lean:{ln_} [{cl}] {t}')
print('## targets: header and statement prose, base vs head')
def block(lines, name):
    pat = re.compile(r'^(theorem|lemma)\s+' + re.escape(name) + r'(\s|$)')
    i = next(k for k, l in enumerate(lines) if pat.match(l))
    j = i
    while ':= by' not in lines[j] and not lines[j].rstrip().endswith(':='): j += 1
    hdr = '\n'.join(lines[i:j + 1])
    k = i - 1
    while not lines[k].lstrip().startswith('/--'): k -= 1
    doc = lines[k:i]; prose = []
    for l in doc:
        if '**Proof sketch.**' in l: break
        prose.append(l)
    return hdr, '\n'.join(prose), j - i + 1
ok = True
for row in open(tg):
    if not row.strip() or row.startswith('#'): continue
    o, name, label = row.rstrip('\n').split('\t')
    p = G + o + '.lean'
    hb, pb, nb = block(show(base, p), name); hh, ph, nh = block(show(head, p), name)
    good = hb == hh and pb == ph; ok &= good
    print(f'{label}\t{o}.lean\t{name}\theader {nb} lines {"same" if hb == hh else "DIFFERENT"}\tprose {"same" if pb == ph else "DIFFERENT"}')
print('RESULT', 'OK' if ok else 'FAIL')
