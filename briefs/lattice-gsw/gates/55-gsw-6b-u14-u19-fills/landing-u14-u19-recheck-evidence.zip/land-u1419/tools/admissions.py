"""admissions.py <base-sorries.txt> <build-logdir> <worktree>: the admissions at a replay head = base-sorries.txt with
every rebuilt module's row replaced by the declarations its build log warns about ('declaration uses sorry', named from
the source line of the warning)."""
import sys, re, os, glob
bs, bdir, wt = sys.argv[1:4]
base = {}
for l in open(bs):
    if not l.strip() or l.startswith('TOTAL'): continue
    m, n, names = l.rstrip('\n').split(': ', 2)
    base[m] = [x.strip() for x in names.split(',')]
rebuilt = {}
for lp in glob.glob(os.path.join(bdir, 'mods', '*.log')):
    mod = None
    for l in open(lp, encoding='utf-8'):
        mm = re.match(r"^(\S+)\.lean:(\d+):\d+: warning: declaration uses 'sorry'", l)
        if mm:
            mod, ln = mm.group(1), int(mm.group(2))
            src = open(os.path.join(wt, mod + '.lean'), encoding='utf-8').read().split('\n')
            nm = re.match(r'^(?:private\s+)?(?:theorem|lemma|def)\s+(\S+)', src[ln-1])
            rebuilt.setdefault(mod, []).append(nm.group(1) if nm else f'?line{ln}')
import json
recs = [json.loads(l) for l in open(os.path.join(bdir, 'results.jsonl')) if '"module"' in l]
built = {r['module'] for r in recs}
head = {m: ns for m, ns in base.items() if m not in built}
for m in built:
    if rebuilt.get(m): head[m] = rebuilt[m]
tot = lambda d: sum(len(v) for v in d.values())
print(f'base: {tot(base)} declarations in {len(base)} modules; rebuilt modules {len(built)}')
print(f'head: {tot(head)} declarations in {len(head)} modules')
print('removed vs base:', {m: sorted(set(base[m]) - set(head.get(m, []))) for m in base if set(base[m]) - set(head.get(m, []))})
print('added vs base:', {m: sorted(set(head[m]) - set(base.get(m, []))) for m in head if set(head[m]) - set(base.get(m, []))})
for m in sorted(head): print(f'{m}: {len(head[m])}: {", ".join(head[m])}')
