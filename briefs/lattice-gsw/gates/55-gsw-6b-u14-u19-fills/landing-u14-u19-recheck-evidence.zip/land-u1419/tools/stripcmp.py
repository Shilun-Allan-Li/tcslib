# Strip Lean comments (line `--`, nested block `/- -/` incl. docstrings `/--`, `/-!`), respecting string and
# char literals; then drop trailing whitespace and lines left blank. Compare two revisions of a file.
# Usage: python3 -I stripcmp.py <repo> <rev-a> <rev-b> <path>...
import subprocess, sys, hashlib
def strip(s):
    out=[]; i=0; n=len(s); depth=0
    while i<n:
        if depth==0:
            if s.startswith('/-',i): depth=1; i+=2; continue
            if s.startswith('--',i):
                j=s.find('\n',i); i=n if j<0 else j; continue
            c=s[i]
            if c=='"':
                j=i+1
                while j<n and s[j]!='"':
                    j+= 2 if s[j]=='\\' else 1
                out.append(s[i:j+1]); i=j+1; continue
            out.append(c); i+=1
        else:
            if s.startswith('/-',i): depth+=1; i+=2; continue
            if s.startswith('-/',i): depth-=1; i+=2; continue
            i+=1
    lines=[l.rstrip() for l in ''.join(out).split('\n')]
    return '\n'.join(l for l in lines if l.strip())+'\n'
repo,a,b=sys.argv[1:4]; ok=True
for p in sys.argv[4:]:
    sa=subprocess.run(['git','-C',repo,'show',f'{a}:{p}'],capture_output=True,check=True).stdout.decode()
    sb=subprocess.run(['git','-C',repo,'show',f'{b}:{p}'],capture_output=True,check=True).stdout.decode()
    xa,xb=strip(sa),strip(sb)
    ha=hashlib.sha256(xa.encode()).hexdigest(); hb=hashlib.sha256(xb.encode()).hexdigest()
    raw_same = sa==sb
    print(f"{p}: raw {'same' if raw_same else 'differs'}; stripped {a[:12]} {ha[:16]} {len(xa.splitlines())} lines, {b[:12]} {hb[:16]} {len(xb.splitlines())} lines -> {'IDENTICAL' if xa==xb else 'DIFFERENT'}")
    ok &= xa==xb
print("RESULT", "OK" if ok else "FAIL")
