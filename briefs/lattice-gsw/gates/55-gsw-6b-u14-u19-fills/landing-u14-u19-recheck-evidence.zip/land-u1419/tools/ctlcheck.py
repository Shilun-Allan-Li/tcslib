"""ctlcheck.py <ctl-lines.tsv> <controls run dir> <probe prefix>: per owner, the error lines of the sealed and open control
probes against the NEG/POS lines: sealed must have exactly one error at each NEG line and none elsewhere, open none."""
import sys, re, collections
lines, rd, pre = sys.argv[1:4]
exp = collections.defaultdict(lambda: {'NEG': [], 'POS': []})
for l in open(lines):
    o, tag, i, d, r, neg, pos = l.rstrip('\n').split('\t')
    exp[(o, tag)]['NEG'].append(int(neg.split()[1])); exp[(o, tag)]['POS'].append(int(pos.split()[1]))
ok = True
for (o, tag), e in sorted(exp.items()):
    log = open(f'{rd}/mods/{pre}_{"Sealed" if tag == "sealed" else "Open"}_{o}.log', encoding='utf-8').read()
    errs = collections.Counter(int(m.group(1)) for m in re.finditer(r'^\S+\.lean:(\d+):\d+: error', log, re.M))
    want = {n: 1 for n in e['NEG']} if tag == 'sealed' else {}
    good = dict(errs) == want
    ok &= good
    print(f'{o} {tag} errors at {dict(errs)} expected NEG lines {e["NEG"] if tag == "sealed" else []} POS lines {e["POS"]} {"OK" if good else "BAD"}')
print('ALL_OK' if ok else 'NOT_OK')
