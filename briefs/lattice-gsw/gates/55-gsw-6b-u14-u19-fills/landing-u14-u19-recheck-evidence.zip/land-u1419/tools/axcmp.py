"""axcmp.py <worker AxiomProbe log> <my census log>: compare the worker's (name -> axioms) rows (lines 'AX\t<mod>\t<name>\t[..]')
with this review's census rows ('DECL|AUX\t<mod>\t<name>\t[..]'). Private names are compared without their `_private.<module>.0.` prefix."""
import sys, re
def norm(n):
    return re.sub(r'^_private\.[A-Za-z0-9_.]*?\.0\.', '', n)
def load(p, tags):
    d = {}
    for l in open(p, encoding='utf-8'):
        f = l.rstrip('\n').split('\t')
        if f[0] in tags and len(f) >= 4: d[norm(f[2])] = f[3]
    return d
w, m = load(sys.argv[1], ('AX',)), load(sys.argv[2], ('DECL', 'AUX'))
print(f'worker {len(w)} constants; review {len(m)}; only worker {sorted(set(w) - set(m))}; only review {sorted(set(m) - set(w))}')
diff = [n for n in set(w) & set(m) if w[n] != m[n]]
print('axiom sets differing:', diff[:10]); print('RESULT', 'SAME' if not diff and set(w) == set(m) else 'DIFFERENT')
