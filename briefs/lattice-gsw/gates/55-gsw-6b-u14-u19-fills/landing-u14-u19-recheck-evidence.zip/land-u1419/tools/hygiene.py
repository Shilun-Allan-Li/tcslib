"""hygiene.py <file>...: every theorem/lemma/def (private included) with a proof body: body lines (header end to the next
blank line), whether its docstring has **Proof sketch.**, a formula (backticked text with = ≤ < ↔), 'Glue', and the count
of `--` step comments in the body. Flags: body >= 20 lines without a sketch; a private helper without a formula."""
import sys, re
for f in sys.argv[1:]:
    L = open(f, encoding='utf-8').read().split('\n'); i = 0
    while i < len(L):
        m = re.match(r'^(private )?(noncomputable )?(theorem|lemma|def) (\S+)', L[i])
        if not m: i += 1; continue
        d = i - 1
        while d >= 0 and not L[d].startswith('/--'): d -= 1
        doc = '\n'.join(L[d:i]) if d >= 0 and all(not re.match(r'^(theorem|lemma|def|private|end|/-!)', x) for x in L[d+1:i]) else ''
        h = i
        while not (L[h].rstrip().endswith(':=') or L[h].rstrip().endswith(':= by') or ':= rfl' in L[h] or ':= Iff.rfl' in L[h]): h += 1
        e = h + 1
        while e < len(L) and L[e].strip() != '' and not L[e].startswith('end '): e += 1
        body = L[h+1:e]; n = len(body)
        sk = '**Proof sketch.**' in doc; fm = bool(re.search(r'`[^`]*(=|≤|<|↔)[^`]*`', doc)); glue = 'Glue' in doc
        com = sum(1 for x in body if x.strip().startswith('--'))
        flag = (n >= 20 and not sk) or (m.group(1) and not fm)
        if n > 1 or m.group(1):
            print(f'{f.split("/")[-1]}\t{m.group(4)}\t{"private" if m.group(1) else "public"}\tbody {n}\tsketch {sk}\tformula {fm}\tglue {glue}\tstep-comments {com}\t{"FLAG" if flag else "ok"}')
        i = e
