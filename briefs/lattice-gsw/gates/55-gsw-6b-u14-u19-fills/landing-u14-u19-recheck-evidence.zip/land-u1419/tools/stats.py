"""stats.py <repo> <rev>... : per owned file and rev: blob, sha256, lines, max width, >100, tabs, trailing spaces,
micro sign, and code-token counts (comments/docstrings/strings stripped) of sorry/admit/native_decide/axiom/opaque;
plus `sorry` code tokens per base-sorries module at each rev. JSON to stdout."""
import sys, subprocess, hashlib, re, json
sys.path.insert(0, '')
repo, revs = sys.argv[1], sys.argv[2:]
G = 'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/'
OWN = [G + f + '.lean' for f in ('Bootstrap', 'Leveled', 'Circular', 'LeveledSecurity', 'PolyRatio', 'Asymptotic')]
BS = '/home/user/tcslib/briefs/lattice-gsw/phase6/issued-6b-fills-r1/base-sorries.txt'
def strip(s):
    out=[]; i=0; n=len(s); d=0
    while i<n:
        if d==0:
            if s.startswith('/-',i): d=1; i+=2; continue
            if s.startswith('--',i):
                j=s.find('\n',i); i=n if j<0 else j; continue
            if s[i]=='"':
                j=i+1
                while j<n and s[j]!='"': j+=2 if s[j]=='\\' else 1
                i=j+1; out.append('""'); continue
            out.append(s[i]); i+=1
        else:
            if s.startswith('/-',i): d+=1; i+=2; continue
            if s.startswith('-/',i): d-=1; i+=2; continue
            i+=1
    return ''.join(out)
show = lambda r, p: subprocess.run(['git', '-C', repo, 'show', f'{r}:{p}'], capture_output=True, check=True).stdout
res = {}
for r in revs:
    R = {}
    for p in OWN:
        b = show(r, p); s = b.decode(); ls = s.split('\n')
        if ls and ls[-1] == '': ls = ls[:-1]
        c = strip(s)
        R[p] = {'git_blob': subprocess.run(['git', '-C', repo, 'rev-parse', f'{r}:{p}'], capture_output=True, text=True).stdout.strip(),
                'sha256': hashlib.sha256(b).hexdigest(), 'lines': len(ls), 'max_width': max(len(l) for l in ls),
                'over_100': sum(len(l) > 100 for l in ls), 'tabs': s.count('\t'), 'trailing_space': sum(l != l.rstrip() for l in ls),
                'micro_sign': s.count('µ'),
                **{f'{k}_in_code': len(re.findall(r'(?<![\w.])' + k + r'(?![\w])', c)) for k in ('sorry', 'admit', 'native_decide', 'axiom', 'opaque')}}
    mods = {}
    for l in open(BS):
        if l.startswith('TOTAL') or not l.strip(): continue
        m = l.split(':')[0]
        mods[m] = len(re.findall(r'(?<![\w.])sorry(?![\w])', strip(show(r, m + '.lean').decode())))
    R['base_sorries_modules_sorry_tokens'] = mods
    res[r] = R
print(json.dumps(res, indent=1, ensure_ascii=False))
