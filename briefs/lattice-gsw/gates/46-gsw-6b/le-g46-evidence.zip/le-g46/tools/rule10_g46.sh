#!/usr/bin/env bash
# rule10_g46.sh <phase>... (LE-g46, maintainer, 2026-11-18): rule10_g6b.sh (gsw-6b landing phase 2) re-pointed to the
# LE-g46 head, canonical coe-A only. Owners: the four modules LE-g46 edits (Leveled, LeveledSecurity, PolyRatio,
# Asymptotic). Export $W/wtx of 7563734a, tree $SP/olean-replay-6b-stmt-g46, touched.json against the records tip
# 38123ccb (as phase 2), collector and mkseals_coe.py unchanged (seal tools $SP/g6a-p2/tools/seal/review), every probe
# through gated_full.sh (runner_full.py, lean -DmaxErrors=0, no -o; slot gate: wait while 3 or more lean run).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
W=$SP/le-g46-work; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RUN="bash $W/tools/recipe/gated_full.sh"
B=38123ccbebef878cd25dd2d2761de1b40ba7e421; H=7563734a8badba842223e0687c719b3b4692e9d2
GSW=TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW
MODS="$GSW.Leveled $GSW.LeveledSecurity $GSW.PolyRatio $GSW.Asymptotic"
files() { for m in "$@"; do echo -n "$(echo $m | tr . /).lean "; done; }
FILES=$(files $MODS); X=$W/wtx; TREE=$SP/olean-replay-6b-stmt-g46
R=$W/run/rule10; TJ=$W/run/statements/touched-g46.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$W/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
PP=G46Seal
mkdir -p $R/order $R/probe-sources $X/$PP $W/run/statements $W/tmp
for ph in "$@"; do
echo "phase $ph start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
touched)
  python3 -I $T/review/touched.py /home/user/tcslib $B $H $TJ $FILES > $W/run/statements/touched-g46.tsv; echo "touched rc=$?";;
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "LE-g46 coe-A collector" $X/$PP/CollectHead.lean
  cp $X/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  $RUN $X $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  ( cd $T && python3 -I $T/review/mkseals_coe.py $G $LOG $X $H $R/seals-coe/A $PP/C SealA_ $MODS > $R/mkseals-coe-A.log )
  (cd $X && ls $PP/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  $RUN $X $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
esac
echo "phase $ph done $(date -u +%FT%TZ)"
done
