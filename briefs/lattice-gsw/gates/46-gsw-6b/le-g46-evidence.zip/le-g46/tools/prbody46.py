"""prbody46.py <before.md> <after.md>: #377 body edits for LE-g46 (exact-once replacements; new footer)."""
import sys
s = open(sys.argv[1], encoding='utf-8').read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)
rep("- **Size:** 12 files from the tip, +2166/−1, counting O2. No file is over 351 lines or over 99 characters wide.",
    "- **Size:** 12 files from the tip, +2202/−1, counting O2. No file is over 362 lines or over 99 characters wide.")
rep("- **`680be9fa45a9cf5deeb7a59820e8e86aaaa4f068`**: one signed landing-edit commit. It applies LE-6b1, LE-6b2 and LE-6b3 byte-identical to `briefs/lattice-gsw/phase6/final-6b-r1/landing-edits-proposed.diff` (5 files, +17/−21).",
    "- **`680be9fa45a9cf5deeb7a59820e8e86aaaa4f068`**: one signed landing-edit commit. It applies LE-6b1, LE-6b2 and LE-6b3 byte-identical to `briefs/lattice-gsw/phase6/final-6b-r1/landing-edits-proposed.diff` (5 files, +17/−21).\n"
    "- **`7563734a8badba842223e0687c719b3b4692e9d2`** (head, tree `c56db4c4`): one signed commit, **LE-g46**, from the Gate 46 pre-dispatch sweep (4 files, +63/−27; below).")
rep("## Checks (maintainer phase 2:",
    "- **LE-g46** (rulings of 2026-11-18 on the Gate 46 sweep, `briefs/lattice-gsw/gates/46-gsw-6b/dup-sweep.md`):\n"
    "  - **S1 / DL-61, proof only.** `GSW.encodeFheView_length` and `GSW.encodeLeveledView_length` (`Asymptotic.lean`) no longer re-derive inline the length of a flatten of constant-length blocks (`List.length_flatten`, `List.ofFn_comp'`, `List.ofFn_const`, `List.sum_replicate_nat`). They apply the public `TCSlib.Cryptography.length_flatten_map_const` (`Foundations/BitLists.lean`) after Mathlib's `List.ofFn_eq_map`, with core's `List.length_finRange`. Statements and docstrings are unchanged; the comment-stripped diff of `Asymptotic.lean` is exactly the two proofs.\n"
    "  - **[Gen09] citations, docs only.** The Gentry thesis passages were ingested on 2026-11-16 (records `bdcadd85`, `blueprint/src/references/gentry-2009-fhe-thesis.md`). The sentences \"no ingested passage gives them … will be cited here once it is ingested\" in `Leveled` (module docstring and `levelKey`), `LeveledSecurity`, `PolyRatio` and `Asymptotic` are replaced by the citations: the key chain [Gen09, §4.1, `KeyGen` of `E^(d)`, pp. 46–47, p056-b003], its reverse order (p056-b002; Gentry's level `i` is level `L − i` here), the layered circuits (p057-b001), correctness [Gen09, Thm 4.2.1, p059-b001] and the hybrid [Gen09, Thm 4.2.3 and its proof, pp. 50–51, p060-b001, p061-b001], with the remaining deviations (zeros instead of a fresh key's bits, position hybrids, DLWE steps, phase 5's challenge step). Each file's References gains [Gen09]. `Leveled`, `LeveledSecurity` and `PolyRatio` are comment-strip identical to `680be9fa`, with mutation controls caught.\n\n"
    "## Checks (maintainer phase 2:")
rep("- **Output map** (Mathlib excluded): 1487 entries, `52ed7825…`.",
    "- **Output map** (Mathlib excluded): 1487 entries, `52ed7825…`.\n\n"
    "## LE-g46 recheck (`briefs/lattice-gsw/gates/46-gsw-6b/le-g46.md`)\n"
    "- **Replay** on `olean-replay-6b-stmt-g46`, a `cp -al` copy of R2: 8 modules rebuilt (`Leveled`, `LeveledSecurity`, `PolyRatio`, `Asymptotic`, `GSW`, `Homomorphic`, `AdvancedEncryption`, root), 1448 reused. All rc 0, 0 `error:`/`error(`; the `sorry` warnings are exactly the same 24 targets (EXACT; only line numbers shift). State check 1456/1456 OK; rebuilt oleans link count 1. Against R2 only the 4 edited oleans change (docstrings are stored in oleans). Snapshot #10 and R2 rehash 0/0/0. Output map `65ca0263…`.\n"
    "- **Admissions 216**, per module equal to R2. **decls2** `680be9fa` → head: 0 ADDED, 0 CHANGED, 0 REMOVED.\n"
    "- **Axioms:** the two lemmas still use `[propext, Quot.sound]`; their dependency closures grow from 913/914 to 1009 constants (they now reach `length_flatten_map_const`, `List.ofFn_eq_map`, `List.length_finRange`). No declaration uses either lemma. The census has 174 constants: the only change is the dropped auxiliary `encodeLeveledView_length._simp_1_1`; `sorryAx` is in exactly the 24 targets.\n"
    "- **Canonical coe-A** on the 4 edited owners: 0 errors; request sets equal R2's (Leveled 479, LeveledSecurity 1561, PolyRatio 1394, Asymptotic 1653). Asymptotic stores 25 constants instead of 26 (the dropped auxiliary).\n"
    "- **Lint:** `campaign_style_lint --check8b` FAIL/WARN identical (92/103 over 540 files; only the 4 line-count INFO lines change); `style_lint` 0 findings in the 12 files.")
rep("- The P6-Q19 B reconstruction disclosure (key chain and hybrid order) is in the leveled module docstrings.",
    "- The P6-Q19 B disclosure in the leveled module docstrings now cites [Gen09] for the key chain and the hybrid order (LE-g46) and states the remaining deviations.")
rep("- **Gate 46 (Codex) audits both** this PR and PR O2 (#376).",
    "- **Gate 46 (Codex) audits both** this PR and PR O2 (#376). Its pre-dispatch sweep found S1, fixed by LE-g46.")
rep("On merge, `olean-replay-6b-stmt` is adoptable if the merge's Lean paths equal tree `956fc086` (the head's tree).",
    "On merge, `olean-replay-6b-stmt-g46` is adoptable if the merge's Lean paths equal tree `c56db4c4` (the head's tree; LE-g46). `olean-replay-6b-stmt` (tree `956fc086`) is superseded for this PR.")
i = s.index('\n---\n_Generated by')
s = s[:i] + '\n🤖 Generated with [Claude Code](https://claude.com/claude-code)\n\nhttps://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA'
assert s.endswith('https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA')
open(sys.argv[2], 'w', encoding='utf-8').write(s)
print('OK', len(s))
