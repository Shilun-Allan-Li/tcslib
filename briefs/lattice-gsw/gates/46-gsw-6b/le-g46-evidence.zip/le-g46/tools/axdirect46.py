"""axdirect46.py <base.log> <head.log>: compare the AxiomsG46 probe outputs (axioms, CLOSURE sizes, DIRECT sets)."""
import sys, re
def parse(p):
    t = open(p, encoding='utf-8').read()
    ax = dict(re.findall(r"'(\S+)' depends on axioms: \[([^\]]*)\]", t))
    ax = {k: ' '.join(v.split()) for k, v in ax.items()}
    cl = dict(re.findall(r'CLOSURE\t(\S+)\t(\d+)', t))
    di = {k: set(x.strip() for x in v.replace('\n', ' ').split(',') if x.strip())
          for k, v in re.findall(r'DIRECT\t(\S+)\t\[([^\]]*)\]', t)}
    return ax, cl, di
(ab, cb, db), (ah, ch, dh) = parse(sys.argv[1]), parse(sys.argv[2])
ok = True
for n in sorted(set(ab) | set(ah)):
    same = ab.get(n) == ah.get(n); ok &= same
    print(f'AXIOMS\t{n}\tbase [{ab.get(n)}]\thead [{ah.get(n)}]\t' + ('SAME' if same else 'DIFF'))
for n in sorted(set(cb) | set(ch)):
    print(f'CLOSURE\t{n}\tbase {cb.get(n)}\thead {ch.get(n)}')
    print(f'  DIRECT only base: {sorted(db.get(n, set()) - dh.get(n, set()))}')
    print(f'  DIRECT only head: {sorted(dh.get(n, set()) - db.get(n, set()))}')
print('RESULT', 'AXIOMS SAME' if ok else 'AXIOMS DIFFER')
