#!/usr/bin/env bash
# run-build-g46.sh <tag> (LE-g46 replay): phase 2's run-build-6b.sh re-pointed: export $W/wtx of the LE-g46 head on
# $SP/olean-replay-6b-stmt-g46 (cp -al of R2). <W>/run/plan/queue.txt (imports-first) through the recipe's runner.py
# (unmodified), one module per call; slot gate before each module (wait while 3 or more lean processes run); stop if
# free disk < 1.5 GB. Logs under $W/run/build-<tag>.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
W=$SP/le-g46-work; RUNNER=$W/tools/recipe/runner.py; OUT=$SP/olean-replay-6b-stmt-g46
Q=$W/run/plan/queue.txt; E=$W/run/build-$1; WX=$W/wtx
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$W/tmp
mkdir -p $E/one $W/tmp
echo "start $(date -u +%FT%TZ) queue $Q" >> $E/runner.start; df -m / | tail -1 >> $E/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $E/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $E/slot-log.txt
  echo "$m" > $E/one/order.txt
  python3 -I $RUNNER $WX $E/one/order.txt $OUT $E < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $E/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $E/runner.exit; exit 2; }
done < $Q
echo "runner exit 0 $(date -u +%FT%TZ)" >> $E/runner.exit; df -m / | tail -1 >> $E/runner.exit
