"""edit.py <file> <old.txt> <new.txt>: replace the unique occurrence of old by new (asserts exactly once)."""
import sys
f, o, n = sys.argv[1:4]
s = open(f, encoding='utf-8').read()
old = open(o, encoding='utf-8').read(); new = open(n, encoding='utf-8').read()
c = s.count(old)
assert c == 1, f"{o}: {c} occurrences"
open(f, 'w', encoding='utf-8').write(s.replace(old, new))
print("OK", f, o)
