"""sealcmp46.py <ours-seals-coe-A-dir> <ours.tsv> <ref-seals-coe-A-dir> <ref.tsv>: per owner seal JSON in ours, the request
set (rows[].spelling), its count, term names, closure modules and stored constants compared with the reference record of
the same label; the sealsum rows (requested, rc, errors, install, EOF, failing) compared. RESULT OK when all equal."""
import sys, json, os, glob
o, ot, r, rt = sys.argv[1:5]
rows = lambda p: {l.split('\t')[0]: l.rstrip('\n').split('\t')[1:] for l in open(p) if l.strip()}
OT, RT = rows(ot), rows(rt); bad = 0
for p in sorted(glob.glob(os.path.join(o, 'Seal*.json'))):
    lab = os.path.basename(p)[:-5]; a = json.load(open(p)); b = json.load(open(os.path.join(r, lab + '.json')))
    sa = {x['spelling'] for x in a['rows']}; sb = {x['spelling'] for x in b['rows']}
    eqs = sa == sb and a['requested'] == b['requested']
    ck = {k: a.get(k) == b.get(k) for k in ('term_names', 'closure_modules', 'stored_constants', 'term_excluded')}
    eqr = OT.get(lab) == RT.get(lab)
    bad += not (eqs and all(ck.values()) and eqr)
    print(f'{lab}\trequests {a["requested"]}/{b["requested"]}\tset ' + ('EQUAL' if sa == sb else f'DIFF +{sorted(sa-sb)} -{sorted(sb-sa)}')
          + '\t' + ' '.join(f'{k} {"equal" if v else "DIFF"}' for k, v in ck.items())
          + f'\tsealsum {OT.get(lab)} vs {RT.get(lab)} ' + ('equal' if eqr else 'DIFF'))
print('RESULT', 'OK' if bad == 0 else 'FAIL')
