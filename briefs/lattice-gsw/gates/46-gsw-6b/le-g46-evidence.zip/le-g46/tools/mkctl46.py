"""mkctl46.py <out.json>: LE-g46 comment-strip controls (M2/M3 as phase 2's controls-6b.json; N1 inside the new Gen09 text)."""
import json, sys
G = "TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/"
d = {
 G + "Leveled.lean": {"m2": ["  leveledEval P lk (Cc.toNANDForm hC).layerNAND (literalCts P cts)\n",
                            "  leveledEval P lk (Cc.toNANDForm hC).layerNAND (literalCts P (cts))\n"],
                     "m3": "  leveledEval P lk (Cc.toNANDForm hC).layerNAND (literalCts P cts)\n",
                     "n1": ["with trivial gates added where needed", "with trivial gates added if needed"]},
 G + "LeveledSecurity.lean": {"m2": ["noncomputable def levelTerm (P : Parameters)", "noncomputable def levelTerm' (P : Parameters)"],
                             "m3": "      D (Function.update (fun d => (Regev.keygen P.lwe χ (c.1.1 d)).1) e.succ v.1,\n",
                             "n1": ["a replaced level key encrypts `0`, not", "a replaced level key encrypts `0` and not"]},
 G + "PolyRatio.lean": {"m2": ["def pBoot (F : LWE.Family) : PolyExpr :=\n  .mul", "def pBoot (F : LWE.Family) : PolyExpr :=\n  .add"],
                       "m3": "    F.samplesBound\n\n",
                       "n1": ["concerns security and is used in", "concerns security and is applied in"]},
}
json.dump(d, open(sys.argv[1], 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
