"""prbody46b.py <before.md> <after.md>: LE-g46b edits to the #377 description, each an exact-once replacement."""
import sys
b = open(sys.argv[1], encoding='utf-8', newline='').read()
R = [
 ("- **Size:** 12 files from the tip, +2202/−1, counting O2.",
  "- **Size:** 12 files from the tip, +2207/−1, counting O2."),
 ("- **`7563734a8badba842223e0687c719b3b4692e9d2`** (head, tree `c56db4c4`): one signed commit, **LE-g46**, from the Gate 46 pre-dispatch sweep (4 files, +63/−27; below).\n",
  "- **`7563734a8badba842223e0687c719b3b4692e9d2`** (tree `c56db4c4`): one signed commit, **LE-g46**, from the Gate 46 pre-dispatch sweep (4 files, +63/−27; below).\n"
  "- **`e8553378636dc896f36fc2a5ab23c8336dbfcecb`** (head, tree `129bbf9d`): one signed commit, **LE-g46b**, docs only, fixing Gate 46's two documentation minors G46-01 and G46-02 (2 files, +11/−6; below).\n"),
 ("Each file's References gains [Gen09]. `Leveled`, `LeveledSecurity` and `PolyRatio` are comment-strip identical to `680be9fa`, with mutation controls caught.\n",
  "Each file's References gains [Gen09]. `Leveled`, `LeveledSecurity` and `PolyRatio` are comment-strip identical to `680be9fa`, with mutation controls caught.\n"
  "- **LE-g46b** (Gate 46 round 1, `briefs/lattice-gsw/gates/46-gsw-6b/findings-r1.md`; ruling of 2026-11-18: docs-only landing edit now):\n"
  "  - **G46-01** (`Circular.lean`, `WeakCircularSecure` docstring). The remark that quantifying over every function forces `ε` near `1` is now restricted to parameters under which decryption is correct: an unbounded test can enumerate the key-generation seeds, take any seed whose public key is `pk` and decrypt the challenge with that seed's secret; recovering the original `s` uniquely is unnecessary. The docstring adds that the definition also admits parameters that do not decrypt correctly, to which the argument does not apply.\n"
  "  - **G46-02** (`Asymptotic.lean`, `encodeCiphertext` docstring). The attribution [Pei16, Def 4.2.3, p024-b001] (decision-LWE) is removed. The encoding is marked as glue, a local encoding choice; [Pei16, §5.4.3, p052-b001] is cited only for the base-two representation of the canonical residue (anchor verified in `blueprint/src/references/peikert2016-lattice-survey.md`). The module's References entry for [Pei16] now names §5.4.3.\n"
  "  - Both files are comment-strip identical to `7563734a` (code characters 2417 = 2417 and 8533 = 8533), with mutation controls caught and the negative control equal. No statement, proof or declaration changes.\n"),
 ("- **Lint:** `campaign_style_lint --check8b` FAIL/WARN identical (92/103 over 540 files; only the 4 line-count INFO lines change); `style_lint` 0 findings in the 12 files.\n\n## Disclosed\n",
  "- **Lint:** `campaign_style_lint --check8b` FAIL/WARN identical (92/103 over 540 files; only the 4 line-count INFO lines change); `style_lint` 0 findings in the 12 files.\n\n"
  "## LE-g46b recheck (`briefs/lattice-gsw/gates/46-gsw-6b/le-g46b.md`)\n"
  "- **Replay** on `olean-replay-6b-stmt-g46b`, a `cp -al` copy of `olean-replay-6b-stmt-g46` (LE-g46): 6 modules rebuilt (`Circular`, `Asymptotic`, `GSW`, `Homomorphic`, `AdvancedEncryption`, root), 1450 reused. All rc 0, 0 `error:`/`error(`; the `sorry` warnings are exactly the same 24 targets (EXACT; only line numbers shift). State check 1456/1456 OK; rebuilt oleans link count 1. Against the LE-g46 tree only the 2 edited oleans change; the facades and root rebuild byte-identical. Snapshot #10 and the LE-g46 tree rehash 0/0/0. Output map `e7bb03b4…`.\n"
  "- **decls2** `7563734a` → head: 0 ADDED, 0 CHANGED, 0 REMOVED. Tip → head is unchanged: 136 ADDED, 0, 0.\n"
  "- **Lint:** `campaign_style_lint --check8b` FAIL/WARN identical (92/103 over 540 files; only the 2 line-count INFO lines change); `style_lint` 0 findings in the 12 files.\n\n"
  "## Disclosed\n"),
 ("- **Gate 46 (Codex) audits both** this PR and PR O2 (#376). Its pre-dispatch sweep found S1, fixed by LE-g46.\n",
  "- **Gate 46 (Codex) audits both** this PR and PR O2 (#376). Its pre-dispatch sweep found S1, fixed by LE-g46.\n"
  "- **Gate 46 round 1: CLEAR** (`briefs/lattice-gsw/gates/46-gsw-6b/findings-r1.md`, audited head `7563734a`): 0 blockers, 0 majors. The two documentation minors G46-01 and G46-02 are fixed by LE-g46b (`e8553378`). G46-03 (note, known: the A4 domination hypotheses, the retained rule-15 item) stands; its merge condition, that this PR waits for the lattice-wide remediation plan, is met by `briefs/efficiency-gaps/audit-r1.md` §5 and `rulings-r1.md` (EF-R1). Resolutions: `resolutions-r1.md` beside the findings.\n"),
 ("On merge, `olean-replay-6b-stmt-g46` is adoptable if the merge's Lean paths equal tree `c56db4c4` (the head's tree; LE-g46). `olean-replay-6b-stmt` (tree `956fc086`) is superseded for this PR.",
  "On merge, `olean-replay-6b-stmt-g46b` is adoptable if the merge's Lean paths equal tree `129bbf9d` (the head's tree; LE-g46b). `olean-replay-6b-stmt-g46` (tree `c56db4c4`) and `olean-replay-6b-stmt` (tree `956fc086`) are superseded for this PR."),
]
for old, new in R:
    n = b.count(old)
    assert n == 1, (n, old[:80])
    b = b.replace(old, new)
END = "\n🤖 Generated with [Claude Code](https://claude.com/claude-code)\n\nhttps://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA"
assert b.endswith(END)
open(sys.argv[2], 'w', encoding='utf-8', newline='').write(b)
print('replacements', len(R), 'length', len(b))
