"""warncmp6b.py <our-logdir> <queue> <ref-logdir>: per module, the multiset of warning headlines
(`<file>:<line>:<col>: warning: <text>` first line) in our log vs the reference log of the same module
(the delivery's sweep). Reports SAME (equal with positions), SAME-TEXT (equal ignoring line:col), DIFF, or NOREF."""
import sys, os, re, collections
ours, q, ref = sys.argv[1:4]
H = re.compile(r'^(\S+\.lean):(\d+):(\d+): warning: (.*)$')
def heads(p):
    return [m.groups() for m in map(H.match, open(p, encoding='utf-8', errors='replace').read().split('\n')) if m]
tot = collections.Counter()
for m in [l.strip() for l in open(q) if l.strip()]:
    f = m.replace('/', '_') + '.log'; a = heads(os.path.join(ours, 'mods', f)); rp = os.path.join(ref, 'mods', f)
    if not os.path.exists(rp): st = 'NOREF'
    else:
        b = heads(rp)
        if sorted(a) == sorted(b): st = 'SAME'
        elif sorted((x[0], x[3]) for x in a) == sorted((x[0], x[3]) for x in b): st = 'SAME-TEXT'
        else: st = 'DIFF'
    tot[st] += 1
    print(f'{st}\t{m}\t{len(a)}\t' + ' | '.join(sorted(set(x[3][:60] for x in a))))
print('TOTAL', dict(tot))
