"""admmap6b.py <wt> <logdir> <queue> <targets.tsv>: each `declaration uses 'sorry'` warning of the run's module logs is
mapped to the column-0 declaration enclosing its line in the exported source <wt>; the (file, name) pairs are compared
with targets.tsv (file basename, short name). Prints EXACT when admitted = targets as sets with no duplicates."""
import sys, os, re, collections
wt, ld, q, tf = sys.argv[1:5]
DECL = re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|nonrec|partial|unsafe)\s+)*'
                  r'(theorem|lemma|def|abbrev|instance|example|structure|inductive|axiom|opaque)\s+(\S+)')
W = re.compile(r"^(\S+\.lean):(\d+):(\d+): warning: declaration uses 'sorry'")
got = []
for m in [l.strip() for l in open(q) if l.strip()]:
    for l in open(os.path.join(ld, 'mods', m.replace('/', '_') + '.log'), encoding='utf-8', errors='replace'):
        w = W.match(l)
        if not w: continue
        src = open(os.path.join(wt, w.group(1)), encoding='utf-8').read().split('\n'); ln = int(w.group(2))
        name = None
        for i in range(ln - 1, -1, -1):
            d = DECL.match(src[i])
            if d: name = d.group(2); break
        got.append((os.path.basename(w.group(1)), name, ln))
T = [tuple(l.rstrip('\n').split('\t')) for l in open(tf) if l.strip()]
g = collections.Counter((a, b) for a, b, _ in got); t = collections.Counter(T)
for a, b, ln in got: print(f'ADMITTED\t{a}\t{b}\t{ln}\t{"target" if (a, b) in t else "NOT-A-TARGET"}')
miss = sorted(set(t) - set(g)); extra = sorted(set(g) - set(t)); twice = sorted(k for k, v in g.items() if v > 1)
print(f'targets {len(T)}; admitted {len(got)}; matched {sum(1 for k in g if k in t)}; not a target {extra}; twice {twice}; missing {miss}')
print('RESULT', 'EXACT' if not (miss or extra or twice) and len(got) == len(T) else 'FAIL')
