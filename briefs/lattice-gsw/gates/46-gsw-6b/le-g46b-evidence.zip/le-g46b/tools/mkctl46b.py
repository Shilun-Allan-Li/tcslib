"""mkctl46b.py <out.json>: LE-g46b comment-strip controls for commentstrip50.py (M2 one code token, M3 one code
line commented out, N1 one word inside the new docstring text; each string occurs once in the edited file)."""
import json, sys
G = "TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/"
d = {
 G + "Circular.lean": {"m2": ["def WeakCircularSecure (P : Parameters)", "def WeakCircularSecure' (P : Parameters)"],
                      "m3": "  distAdv (fheView P χ false) (fheView P χ true) D ≤ ε\n",
                      "n1": ["Recovering the original `s` uniquely is unnecessary.",
                             "Recovering the original `s` exactly is unnecessary."]},
 G + "Asymptotic.lean": {"m2": ["def encodeCiphertext (P : Parameters)", "def encodeCiphertext' (P : Parameters)"],
                        "m3": "  Encoding.Modular.encodeMatrix P.width C\n",
                        "n1": ["which the cited sources do not fix", "which the cited sources do not specify"]},
}
json.dump(d, open(sys.argv[1], 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
