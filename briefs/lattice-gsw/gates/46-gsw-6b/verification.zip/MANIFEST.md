# verification.zip · Gate 46 round 1 (GSW 6b: #376 O2 and #377 statements)

Staged 2026-11-18 by the maintainer's staging session. No Lean, no `lake`; git objects, `python3 -I` and grep only.
`SHA256SUMS` lists every other entry of this ZIP.

- `checks/` (git-object checks at staging; scripts in `tools/`):
  - `series.txt` (`tools/series.sh`): both PRs' commits (tree, parents, author, committer, signature presence, numstat),
    the PR diff stats, the changed paths, and per-file blob equality with the worker heads `5bd5ada5`/`8f92fe7d`.
  - `lean-equality.txt` (`tools/leanequal.sh`): Lean equality of the PR cut tip `38123ccb`, #376's REST base `1a9a3295`
    and the staging records tip `dab31951` with snapshot #10's T `cf6a2266`; the scope (exactly 12 paths, no 6a or
    phase-5 file); merge-tree of each head with `dab31951` and its Lean equality with the adoption trees.
  - `le-identity.txt` (`tools/leident.sh`): `landing-edits-proposed.diff` applied to the worker's files equals #377's
    head (5/5); the comment-stripped diff of the LE commit (`tools/strip.py`).
  - `targets.txt` (`tools/targets.py`): every comment-stripped `sorry`, its declaration, tag/Glue and sketch presence,
    and the mapping to `issued-6b-r1/targets.txt`.
  - `anchors.txt` (`tools/anchors.py`): every `pNNN-bNNN` anchor resolved in the ingest of its tag at `dab31951`.
  - `sizes.tsv` (`tools/sourcehead.py`): lines, widths, tabs and trailing spaces of the 12 files.
  - `dup-sweep.txt` (`tools/dupsweep46.sh`, `tools/closure.py`): the pre-dispatch duplication sweep's greps; the
    judgement is `dup-sweep.md` in the gate directory.
  - `evidence-verify.txt`: the records' evidence sums, the inner manifests of the phase-1/phase-2 ZIPs from fresh
    extracts, the axiom summary, the DECL reconciliation and the admissions result.
- `evidence/`: `gsw-6b-final-r1-phase1-evidence.zip`, `gsw-6b-final-r1-phase2-evidence.zip`,
  `landing-edits-proposed.diff` and `evidence-SHA256SUMS`, copied unchanged from
  `briefs/lattice-gsw/phase6/final-6b-r1/` at the records tip.
- `records/`: copies at the records tip `dab31951abb5c892dc6279c229e49497ec95de10` (equal at the pin):
  `phase6/final-6b-r1/{review,phase2}.md`, `phase6/checkpoint1-6b-review.md`, `phase6/plan-section.md` (r3),
  `phase6/rulings.md`, the issued package `phase6/issued-6b-r1/` (README, brief, dispatch, addendum, targets, census,
  pins, SHA256SUMS), `policy.md`, Gate 45's findings r1/r2, Gate 50's findings r1, and `extracts/` (decision-log rows
  567-593; the ledger header, DL-54 and DL-61, the last added at staging).
- `pr/`: the REST fields of #376/#377 at staging (with the SHA-256 of each body, equal to the gate directory's
  `pr376-description.md`/`pr377-description.md`).
