#!/bin/bash
# Gate 46 staging: pre-dispatch duplication sweep greps (no Lean). The judgement is in dup-sweep.md.
# Usage: dupsweep46.sh <repo> <tooldir> <decls2 tsv (phase-2 tip-vs-stmt)>
set -u
R=$1; TD=$2; TSV=$3; cd "$R"
TIP=38123ccbebef878cd25dd2d2761de1b40ba7e421; REC=$(git rev-parse dab31951); MAIN=$(git rev-parse origin/main)
O2=04ba2446f541c39dd02aefaa97a9eb31dbbda748; ST=680be9fa45a9cf5deeb7a59820e8e86aaaa4f068
ML=.lake/packages/mathlib; BT=.lake/packages/batteries; CORE=$(ls -d ~/.elan/toolchains/*v4.25.0/src/lean/Init | head -1)
echo "# dup-sweep.txt (Gate 46 staging greps, no Lean)"
echo "records $REC (Lean = PR cut tip $TIP = snapshot #10); main $MAIN; #376 $O2; #377 $ST"
echo "Mathlib $(git -C $ML rev-parse HEAD); Batteries $(git -C $BT rev-parse HEAD); core $(basename $(dirname $(dirname $(dirname $CORE))))"
echo; echo "## 1. inventory"
echo "decls2 (phase 2, tip -> #377 head): $(wc -l < $TSV) rows, kinds: $(cut -f1 $TSV | sort | uniq -c | tr -s ' ' | tr '\n' ';')"
echo "of which in BitEncoding.lean (#376, O2): $(grep -c 'LWE/BitEncoding.lean' $TSV)"
echo "independent count of added keyword lines (theorem|lemma|def|abbrev|instance|structure), tip -> #377:"
git diff -U0 $TIP $ST -- 'TCSlib/*.lean' | grep -E '^\+(@\[[^]]*\] *)?(private |protected |noncomputable )*(theorem|lemma|def|abbrev|instance|structure) ' | sed -E 's/^\+(@\[[^]]*\] *)?//' | awk '{print $1=="noncomputable"?$2:$1}' | sort | uniq -c
echo "private declarations added: $(git diff -U0 $TIP $ST -- 'TCSlib/*.lean' | grep -c -E '^\+private ')"
echo "simps-generated names (not in decls2): Parameters.ofFamily_lwe, _width; fheView_fst, _snd"
cut -f2,3,4 $TSV | sed 's/TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW./GSW./; s/TCSlib.Cryptography.//' | sort
echo; echo "## 2. same last component declared elsewhere (TCSlib + audits at records and main; Mathlib; Batteries)"
cut -f3 $TSV | sed 's/.*\.//' | sort -u > /tmp/g46short.$$
pat=$(paste -sd'|' /tmp/g46short.$$)
for r in $REC $MAIN; do echo "-- $r"; git grep -n -E "^\s*(@\[[^]]*\]\s*)?(private |protected |noncomputable )*(theorem|lemma|def|abbrev|instance|structure|class|inductive) ([A-Za-z_.']*\.)?($pat)( |$|:)" $r -- 'TCSlib/*.lean' 'audits/*.lean' | sed "s|^$r:||" | cut -c1-170; done
gpat=$(grep -v -x -E "select|select_eq|Coins|Coins_eq|PublicKey|PublicKey_eq|Secret|Secret_eq|Seeds|Seeds_eq|KeySeed|KeySeed_eq" /tmp/g46short.$$ | paste -sd'|')
echo "-- Mathlib + Batteries (generic short names select/Coins/PublicKey/Secret/Seeds/KeySeed excluded)"
grep -rn -E "^\s*(@\[[^]]*\]\s*)?(private |protected |noncomputable )*(theorem|lemma|def|abbrev|instance|structure) ([A-Za-z_.']*\.)?($gpat)( |$|:)" $ML/Mathlib $BT/Batteries | sed 's|.lake/packages/||'; echo "(end)"
rm -f /tmp/g46short.$$
echo; echo "## 3. every proof body at the head that is not rfl / Iff.rfl / sorry (read by hand)"
for f in $(git diff --name-only $TIP $ST); do
  git show $ST:$f | python3 -I $TD/strip.py | awk -v F=$(basename $f) -F: '
    { line=$0; sub(/^[0-9]+:/,"",line) }
    line ~ /:= by$|:= by |^  ⟨/ && line !~ /:= by\s*$/ { print F":"$1": "line; next }
    line ~ /:= by\s*$/ { inblk=1; hdr=$1; next }
    inblk && line ~ /^    / { next }
    inblk && line ~ /^  [^ ]/ && line !~ /^  sorry\s*$/ { print F":"$1": "line }
    line !~ /^  / { inblk=0 }'
done
echo; echo "## 4. shape greps"
echo "### 4a. length of a flatten of constant-length blocks (encodeFheView_length, encodeLeveledView_length)"
git grep -n -E "theorem [A-Za-z_.']*(length_flatten|flatten_length|length_join|length_flatMap)[A-Za-z_']*" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||" | cut -c1-170
echo "-- closure of GSW/Asymptotic at #377 (tools/closure.py): $(python3 -I $TD/closure.py . $ST TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Asymptotic | wc -l) modules; members among the files above:"
python3 -I $TD/closure.py . $ST TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Asymptotic | grep -E "BitLists|HybridMachine|Lamport|CommitmentLemmas|EnsemblesLemmas|NPPoly|PSubsetPPolyTableau|Programs.Util.List|FromPRF.ReductionMachine|UniversalLemmas|StateLoop"
echo "-- the statements"
git show $REC:TCSlib/Cryptography/Foundations/BitLists.lean | sed -n '173,179p'
git show $REC:TCSlib/Cryptography/Authentication/Signatures/Lamport.lean | sed -n '122,124p'
git show $REC:TCSlib/Cryptography/Encryption/PublicKey/HybridMachine.lean | sed -n '104,106p'
git show $REC:TCSlib/Cryptography/ZeroKnowledge/CommitmentLemmas.lean | sed -n '210,212p'
echo "-- core / Mathlib / Batteries"
grep -n -E "theorem (length_flatten|length_flatMap|sum_replicate_nat|ofFn_const|ofFn_comp'|ofFn_eq_map|length_finRange)\b" $CORE/Data/List/Lemmas.lean $CORE/Data/List/OfFn.lean $CORE/Data/List/FinRange.lean $ML/Mathlib/Data/List/OfFn.lean $ML/Mathlib/Data/List/FinRange.lean 2>/dev/null | sed "s|$CORE|core:Init|; s|$ML/||"
grep -rn -E "theorem [A-Za-z_.']*(flatten|join)[A-Za-z_.']*ofFn|theorem [A-Za-z_.']*ofFn[A-Za-z_.']*(flatten|join)" $ML/Mathlib $BT/Batteries $CORE | sed "s|$CORE|core:Init|; s|.lake/packages/||"; echo "(end)"
echo "-- the two proofs"
git show $ST:TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Asymptotic.lean | sed -n '123,130p;152,160p'
echo "### 4b. O2 (decode_iff_mem_Ico's inline steps): ZMod val/sub lemmas in Mathlib; TCSlib"
grep -rn -E "theorem (val_sub|val_add_of_lt|val_add_of_le|val_neg_of_ne_zero|neg_val|valMinAbs_natAbs_eq_min|val_natCast_of_lt)\b" $ML/Mathlib/Data/ZMod | sed "s|$ML/||"
grep -n -E "theorem coe_sub_iff_lt|theorem coe_sub_iff_le" $ML/Mathlib/Data/Fin/Basic.lean $CORE/Data/Fin/Lemmas.lean 2>/dev/null | sed "s|$CORE|core:Init|; s|$ML/||"
git grep -n -E "(theorem|lemma) [A-Za-z_.']*(val_sub|sub_val|valMinAbs)[A-Za-z_']*|modulus / 2 / 2|decodeLo|decodeHi" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||"; echo "(end)"
echo "### 4c. NeZero P.columns, width positivity (neZero_columns, LE-6b3)"
git grep -n -E "NeZero .*columns|width_pos|width_ne_zero|columns_pos|columns_ne_zero" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||"; echo "(end)"
grep -n -E "theorem one_lt_two_pow_iff" $CORE/Data/Nat/Lemmas.lean $CORE/Data/Nat/Basic.lean 2>/dev/null | sed "s|$CORE|core:Init|"
echo "### 4d. definitions: bodies of the new definitions against phase 5, LWE, Regev and 6a (same body anywhere else?)"
git grep -n -E "decomposeVec P \(secretVector|vecMul \(decryptColumn|mul P \(gadget P - |evalWith \(select|modSumInterval \(fun|Fin\.append cts|homNot P \[cts|encodeMatrix P\.width|encodeChallenge P\.lwe P\.width|residueBits\.eval κ\b.*width|RatioBounded|ofFamily|ReductionEfficient|WeakCircular|hybridPlant \(encrypt" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||" | cut -c1-170; echo "(end)"
echo "### 4e. G15 (distAdv_fheView_noEvk_le) and its relatives"
git grep -n -E "^theorem (distAdv_encrypt_le|distAdv_encrypt_le_of_width|real_uniformKey_advantage)\b" $REC -- 'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Security.lean' | sed "s|^$REC:||"
git grep -n -E "^theorem (acceptProb_fst|acceptProb_snd|acceptProb_comp_equiv|uprob_fst|distAdv_comp)\b" $REC -- 'TCSlib/Cryptography/*.lean' | sed "s|^$REC:||"
echo "### 4f. G8 decDepth_le against F10, G11/L1 against phase 5, G14/A2 readers"
git grep -n -E "^theorem (modSumDepth_le|modSumInterval_eval|encrypts_encrypt|encrypts_keygen_encrypt|decrypt_eq_decode_dotProduct|vecMul_secretVector_augmented|gadget_mulVec_decomposeVec|eval_encrypts|decrypt_keygen_eval|homGate_encrypts|decode_codepoint_add|distAdv_multi_le_sum|abs_sub_le_sum_hybrids|hybridPlant_eq)\b" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||"
git grep -n -E "theorem (negligible_polyExpr_mul|Negligible\.polyExpr_mul)\b" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||"
echo "### 4g. other bootstrapping / circular-security / leveled-FHE material in TCSlib"
git grep -l -i -E "bootstrap|circular secur|leveled fhe|levelKey|evalKey" $REC -- 'TCSlib/*.lean' | sed "s|^$REC:||"; echo "(end)"
echo; echo "## 5. ledger and records mentions of the swept names (records $REC)"
git grep -n -E "length_flatten|encodeFheView|encodeLeveledView|neZero_columns|decDepth_le|hsub" $REC -- briefs/pass-shelat-ch5-8/duplication-ledger.md LatticeCryptographyPlan.md briefs/lattice-gsw/phase6/final-6b-r1/review.md | cut -c1-220 | sed "s|^$REC:||"; echo "(end)"
