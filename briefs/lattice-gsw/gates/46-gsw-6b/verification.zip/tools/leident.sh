#!/bin/bash
# Gate 46 staging: LE-6b1..3 identity. Applies the records' landing-edits-proposed.diff to the worker head's
# files and compares with #377's head; then the comment-stripped diff of the LE commit. Usage: leident.sh <repo> <tooldir>
set -u
R=$1; TD=$2; cd "$R"
W=8f92fe7d53967bc488a4075fb38210e7d40b9031; PICK=75c683b295cca1a6cba918eb49a5d7c256739b7a
ST=680be9fa45a9cf5deeb7a59820e8e86aaaa4f068; D=briefs/lattice-gsw/phase6/final-6b-r1/landing-edits-proposed.diff
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
echo "# le-identity.txt"; echo "proposed diff $(git hash-object $D | cut -c1-12) sha256 $(sha256sum $D | cut -d' ' -f1)"
FILES=$(git diff --name-only $PICK $ST)
for f in $FILES; do mkdir -p "$T/$(dirname $f)"; git show $W:$f > "$T/$f"; done
(cd "$T" && git apply --unsafe-paths "$R/$D" && echo "git apply: rc 0") || echo "git apply FAILED"
for f in $FILES; do a=$(git hash-object "$T/$f"); b=$(git rev-parse $ST:$f); [ "$a" = "$b" ] && s=IDENTICAL || s=DIFFERS; echo "$f proposal-applied $a head $b $s"; done
echo; echo "## files of the LE commit whose comment-stripped text changes (tools/strip.py)"
for f in $FILES; do
  git show $PICK:$f | python3 -I $TD/strip.py | sed 's/^[0-9]*://' > "$T/a"; git show $ST:$f | python3 -I $TD/strip.py | sed 's/^[0-9]*://' > "$T/b"
  if cmp -s "$T/a" "$T/b"; then echo "$f: code EQUAL"; else echo "$f: code DIFFERS"; diff "$T/a" "$T/b" | sed 's/^/    /'; fi
done
