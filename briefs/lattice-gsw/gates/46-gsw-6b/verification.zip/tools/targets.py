# Gate 46 staging: locate every `sorry` (comment-stripped) at #377's head, name its enclosing declaration,
# check docstring tag/sketch presence, and map to the issued targets.txt. Usage: targets.py <repo> <rev> <targets.txt>
import sys, subprocess, re
repo, rev, tfile = sys.argv[1:4]
files = subprocess.run(['git','-C',repo,'diff','--name-only','38123ccbebef878cd25dd2d2761de1b40ba7e421',rev],
                       capture_output=True,text=True).stdout.split()
def strip(src):
    out=[];i=0;d=0;n=len(src)
    while i<n:
        if src.startswith('/-',i): d+=1;i+=2;continue
        if d and src.startswith('-/',i): d-=1;i+=2;continue
        if d: out.append('\n' if src[i]=='\n' else ' ');i+=1;continue
        if src.startswith('--',i):
            j=src.find('\n',i);j=n if j<0 else j;out.append(' '*(j-i));i=j;continue
        out.append(src[i]);i+=1
    return ''.join(out)
decl=re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:private |protected |noncomputable )*(theorem|lemma|def|abbrev|instance|structure)\s+([^\s(:{\[]+)')
rows=[]; found=[]
for f in files:
    src=subprocess.run(['git','-C',repo,'show',f'{rev}:{f}'],capture_output=True,text=True).stdout
    lines=src.split('\n'); sl=strip(src).split('\n'); cur=None; curline=0
    for k,l in enumerate(sl,1):
        m=decl.match(l)
        if m: cur=m.group(2); curline=k
        if re.search(r'\bsorry\b',l):
            # docstring immediately above the declaration
            j=curline-2; doc=[]
            while j>=0 and not lines[j].lstrip().startswith('/--'): doc.append(lines[j]); j-=1
            doc.append(lines[j] if j>=0 else ''); dtext=' '.join(reversed(doc))
            tag='yes' if re.search(r'\[(BV14|BV11|AP14|GSW13|Pei16|Bar89),',dtext) else ('Glue' if 'Glue' in dtext else 'NO')
            sk='**Proof sketch.**' in dtext
            found.append((f.split('/')[-1],k,cur,tag,sk))
print(f"# targets.txt (rev {rev}; comment-stripped `sorry` occurrences)")
for f,k,c,t,s in found: print(f"{f}:{k}\t{c}\ttag={t}\tsketch={'yes' if s else 'NO'}")
per={}
for f,*_ in found: per[f]=per.get(f,0)+1
print("total",len(found),"distinct declarations",len({c for _,_,c,_,_ in found}),"per file",per)
issued=[l.split('\t') for l in open(tfile,encoding='utf-8') if l.strip() and not l.startswith('#')]
names={c for _,_,c,_,_ in found}
print("\n## issued targets.txt rows (kind target) against the admitted set")
for r in issued:
    if r[4]!='target': continue
    n=r[3]; print(f"{r[1]}\t{n}\t{'ADMITTED' if n in names else 'not admitted under this name'}")
print("\n## admitted names not in targets.txt:",sorted(names-{r[3] for r in issued}))
