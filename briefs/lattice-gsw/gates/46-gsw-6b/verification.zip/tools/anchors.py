# Gate 46 staging: every `pNNN-bNNN` anchor in the changed files, attributed to the tag of its bracket part,
# checked against that ingest's `<a id="pdf-…-pNNN-bNNN">` at a records revision; also counts [Gen09].
# Usage: anchors.py <repo> <rev-lean> <rev-records>
import sys, subprocess, re
repo, rev, rec = sys.argv[1:4]
REF = {'BV14':'brakerski-vaikuntanathan-2014-fhe','BV11':'brakerski-vaikuntanathan-2011-fhe',
       'AP14':'alperin-sheriff-peikert-2014-bootstrapping','GSW13':'gentry-sahai-waters-2013-fhe',
       'Pei16':'peikert2016-lattice-survey','Bar89':'barrington-1989-bounded-width-bp'}
def show(r,p): return subprocess.run(['git','-C',repo,'show',f'{r}:{p}'],capture_output=True,text=True).stdout
ids = {k: set(re.findall(r'id="pdf-[0-9a-f]+-(p\d{3}-b\d{3})"', show(rec, f'blueprint/src/references/{v}.md')))
       for k, v in REF.items()}
files = subprocess.run(['git','-C',repo,'diff','--name-only','38123ccbebef878cd25dd2d2761de1b40ba7e421',rev],
                       capture_output=True,text=True).stdout.split()
tot=ok=0; bad=[]; gen=0; unattr=[]
for f in files:
    t = show(rev,f); gen += len(re.findall(r'\[Gen09', t))
    flat = re.sub(r'\s+',' ',t)
    for grp in re.findall(r'\[([^\[\]]*)\]', flat):
        tag=None
        for part in grp.split(';'):
            m = re.match(r'\s*(BV14|BV11|AP14|GSW13|Pei16|Bar89)\b', part)
            if m: tag=m.group(1)
            for a in re.findall(r'p\d{3}-b\d{3}', part):
                tot+=1
                if tag is None: unattr.append((f,a)); continue
                if a in ids[tag]: ok+=1
                else: bad.append((f,tag,a))
print(f"# anchors.txt (Lean {rev}, ingests at {rec})")
print("ingest anchor counts:", {k:len(v) for k,v in ids.items()})
print(f"anchor occurrences {tot}; resolved in the cited ingest {ok}; missing {len(bad)}; unattributed {len(unattr)}")
for b in bad: print("MISSING", *b)
for u in unattr: print("UNATTRIBUTED", *u)
print("[Gen09] occurrences:", gen)
