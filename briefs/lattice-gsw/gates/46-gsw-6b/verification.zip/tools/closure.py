# Usage: closure.py <repo> <rev> <Module> [<Module>...]: print the TCSlib import closure (git objects only).
import sys, subprocess, re
repo, rev, roots = sys.argv[1], sys.argv[2], sys.argv[3:]
def src(mod):
    p = mod.replace('.', '/') + '.lean'
    r = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{p}'], capture_output=True, text=True)
    return r.stdout if r.returncode == 0 else None
seen, stack = set(), list(roots)
while stack:
    m = stack.pop()
    if m in seen: continue
    seen.add(m); s = src(m)
    if s is None: continue
    for imp in re.findall(r'^import\s+(TCSlib[\w.]*)', s, re.M):
        stack.append(imp)
for m in sorted(seen): print(m)
