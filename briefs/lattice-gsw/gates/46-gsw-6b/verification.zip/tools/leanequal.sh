#!/bin/bash
# Gate 46 staging: Lean equality, scope and merge-tree checks (git objects only). Usage: leanequal.sh <repo>
set -u
R=$1; cd "$R"
TIP=38123ccbebef878cd25dd2d2761de1b40ba7e421; REC=$(git rev-parse dab31951)
O2=04ba2446f541c39dd02aefaa97a9eb31dbbda748; ST=680be9fa45a9cf5deeb7a59820e8e86aaaa4f068
S10=$(git rev-parse cf6a2266); RB=$(git rev-parse 1a9a3295)
P=(TCSlib TCSlib.lean lean-toolchain lake-manifest.json lakefile.lean scripts audits)
echo "# lean-equality.txt"
echo "snapshot #10 T $S10; PR cut tip $TIP; staging records tip $REC; #376 REST base.sha $RB"
for x in $TIP $RB $REC; do echo "Lean paths $S10 -> $x: $(git diff --name-only $S10 $x -- "${P[@]}" | wc -l) changed"; done
echo "ancestry: $(git merge-base --is-ancestor $S10 $TIP && echo 'S10<=TIP') $(git merge-base --is-ancestor $TIP $RB && echo 'TIP<=RESTbase') $(git merge-base --is-ancestor $RB $REC && echo 'RESTbase<=REC')"
echo "records-only commits TIP..REC: $(git rev-list --count $TIP..$REC); their paths outside briefs/ and the plan: $(git diff --name-only $TIP $REC | grep -v -E '^(briefs/|[A-Za-z0-9-]*Plan\.md$)' | wc -l)"
echo; echo "# scope: paths of TIP..#377 against the issued brief's 12"
git diff --name-only $TIP $ST
echo "count $(git diff --name-only $TIP $ST | wc -l)"
echo "6a (Complexity/) or phase-5 GSW files touched: $(git diff --name-only $TIP $ST | grep -E '^TCSlib/Complexity/|GSW/(Gadget|Noise|Scheme|Eval|Security|Symmetric)\.lean$|^TCSlib.lean$|machine-library-design|ComputationalModels|^blueprint/|^audits/' | wc -l)"
echo; echo "# merge-tree with the staging records tip (git $(git --version | cut -d' ' -f3))"
for h in $O2 $ST; do t=$(git merge-tree --write-tree $REC $h); rc=$?; echo "$REC x $h: rc $rc tree $t"; done
echo "adoption trees: R1 8b615e060f72d72749f67abd39f820d117e0a806 = $(git rev-parse $O2^{tree}) (#376 head tree); R2 956fc086044551e8f04298ab70dd5aa451069c16 = $(git rev-parse $ST^{tree}) (#377 head tree)"
for pair in "$O2 8b615e060f72d72749f67abd39f820d117e0a806" "$ST 956fc086044551e8f04298ab70dd5aa451069c16"; do
  set -- $pair; t=$(git merge-tree --write-tree $REC $1)
  echo "Lean diff merge-tree(REC,$1) vs $2: $(git diff --name-only $t $2 -- "${P[@]}" | wc -l) paths"
done
