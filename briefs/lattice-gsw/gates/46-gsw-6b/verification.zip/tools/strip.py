# Print a Lean file with block comments/docstrings and line comments removed (keeps line numbers).
import sys, re
src = sys.stdin.read()
out = []; i = 0; depth = 0; n = len(src)
while i < n:
    if src.startswith('/-', i):
        depth += 1; i += 2; continue
    if depth and src.startswith('-/', i):
        depth -= 1; i += 2; continue
    if depth:
        if src[i] == '\n': out.append('\n')
        i += 1; continue
    if src.startswith('--', i):
        j = src.find('\n', i); i = n if j < 0 else j; continue
    out.append(src[i]); i += 1
for k, line in enumerate(''.join(out).split('\n'), 1):
    if line.strip(): print(f"{k}:{line}")
