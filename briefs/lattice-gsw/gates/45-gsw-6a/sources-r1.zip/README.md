# Gate 45 source bundle

Every entry is read from git objects; SHA-256 of the bytes and the origin `rev:path`.

- `head-73aedcda/`: the 17 Lean paths of the 18-path series (#358 + #359) at the #359 head `73aedcdaaaffef7e69ab012d9b9195f150bae68d`
  (`machine-library-design.md` is not copied; its changed lines are in `pr359.diff.txt`).
- `o1-a616adca/`: #358's 4 files at its head `a616adcac0760ab56b1b0a2a4869f4763843f9ab`.
- `base-e1d39836/`: the series Lean files that exist at the merge base `e1d39836ed4a69a34914c35f4c73c71de853dcc6` (Lean-equal to `3f540c22360c869069a0fba684e23ce6f3cb20db`, snapshot #5).
- `context-73aedcda/`: unchanged modules the new files import or cite (`Basic`, `TreeDAG`, `DAGCircuit`, `DAGTransform`,
  `DAGFanin`, `Adder`, `NCAC`), the duplication-relevant `Hierarchy` (`widenCircuit`), `Parity` (dual-rail XOR, P6-Q6),
  `LayeredDAG` (`toLayered`) and `BooleanAnalysis/LMN/CircuitReindex` (the `reidx` family of LE-ren); blob-equal at tip and head.
- `references/`: the Bar89, BV14 and BV11 ingests (`.md`, `.raw.md`) that the 112 anchors cite. [AB09, p. 118] is a
  pre-existing library tag with no ingest; [AP14] and [Gen09] are not cited by the series.

| Entry | SHA-256 | Origin |
|---|---|---|
| `head-73aedcda/TCSlib.lean` | `9e5aeeb7598b7af644836a58f29cc3382b02e00f839c4478f174ecd855676f3b` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib.lean` |
| `head-73aedcda/TCSlib/Complexity/BranchingPrograms.lean` | `eb3b2700e88e5d05b88c737fb34371187e8b3a100cba24a5cca80beb87d28709` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/BranchingPrograms.lean` |
| `head-73aedcda/TCSlib/Complexity/BranchingPrograms/Barrington.lean` | `0b608b9336ac6a6a48227a097c8a79f0cd5619dded8bc22c6dd1c0b26e3dfba6` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/BranchingPrograms/Barrington.lean` |
| `head-73aedcda/TCSlib/Complexity/BranchingPrograms/BarringtonConverse.lean` | `16663708223833cf70b86518f5f254c3b7a5c2ecba66cd6bba32fc717ece63dd` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/BranchingPrograms/BarringtonConverse.lean` |
| `head-73aedcda/TCSlib/Complexity/BranchingPrograms/Defs.lean` | `0067e3a13ad09c94ce7424094aa62c6971ba3a803d5ea8eefaef6f62c036a8f2` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/BranchingPrograms/Defs.lean` |
| `head-73aedcda/TCSlib/Complexity/BranchingPrograms/Eval.lean` | `67cae626f0a43691cfe83c3e97760b305f6deb464ba46421837b372e2740b0e0` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/BranchingPrograms/Eval.lean` |
| `head-73aedcda/TCSlib/Complexity/BranchingPrograms/NC1.lean` | `63062599ab4bee887bba0afef19d2e5c7d1c6465d8808c39247cc77070b03f13` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/BranchingPrograms/NC1.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity.lean` | `5356732e92a06d9e317dbecb9a10e3f322fcb4d01df90b6996a987f56f0d8251` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/FormulaArith.lean` | `0cdc9004710fc0220762b59fdab54937d999cbe81ac7737c277f36561be6e7dd` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/FormulaArith.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/FormulaArith/CarrySave.lean` | `d541a3f699e4dcd980d48adec08f89c42ec777766b5ccb1505ae2a158636b03a` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/FormulaArith/CarrySave.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean` | `acd5b7f21d7b9d98c331c6e50b616d81015f784aab8546fd555c3806213891a7` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/FormulaArith/Compare.lean` | `6e895de7d97ee9bee81cd52881e593d824c8231d45b6b3276c84198d17c9edb7` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/FormulaArith/Compare.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean` | `1b2ae77a9a8bdc78cdd247d2fb656040ed7ec39a9992248bfab9ec2971ca2c13` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/FormulaArith/ModSum.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/NANDForm.lean` | `a9f4665587351d5470af45451e3444e55cd7d48558de6c56ad533588ba7f2359` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/NANDForm.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/NANDLayering.lean` | `06b50b373928bee06b0c8299b734b8863a180288e70dc5b4d21f468433c977b7` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/NANDLayering.lean` |
| `head-73aedcda/TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean` | `41ebf40a5c9c40aed48698e304cb1974f234ba1d81e293e9d7c0f66d90ef9e72` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean` |
| `head-73aedcda/TCSlib/ComputationalModels.lean` | `28a5b64bbf9ffb2b0b93642deed791966f543df981e6468666cca18b2b310863` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/ComputationalModels.lean` |
| `o1-a616adca/TCSlib/Complexity/CircuitComplexity.lean` | `fc9721cd4a8f186300b73b29cb5b4f143b424b7207a456eaa99d9f9773732841` | `a616adcac0760ab56b1b0a2a4869f4763843f9ab:TCSlib/Complexity/CircuitComplexity.lean` |
| `o1-a616adca/TCSlib/Complexity/CircuitComplexity/FormulaArith.lean` | `402ea58e8db7aec9e5290445fce1b2a7ce96e8cc8be456d8c29f4ed538122a5e` | `a616adcac0760ab56b1b0a2a4869f4763843f9ab:TCSlib/Complexity/CircuitComplexity/FormulaArith.lean` |
| `o1-a616adca/TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean` | `7884da47b2a95bb3073473313b7403218371d4e2ba01e613e85cfb7871fe4175` | `a616adcac0760ab56b1b0a2a4869f4763843f9ab:TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean` |
| `o1-a616adca/TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean` | `41ebf40a5c9c40aed48698e304cb1974f234ba1d81e293e9d7c0f66d90ef9e72` | `a616adcac0760ab56b1b0a2a4869f4763843f9ab:TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean` |
| `base-e1d39836/TCSlib.lean` | `ca8cbfc85cdc17731929d589adcc832d8deea9c48a41df5c5af127c0039f5bcf` | `e1d39836ed4a69a34914c35f4c73c71de853dcc6:TCSlib.lean` |
| `base-e1d39836/TCSlib/Complexity/CircuitComplexity.lean` | `9278c7fb9132dcf7d398762133bf81f192d219fe81019c85818cabb16d79fd98` | `e1d39836ed4a69a34914c35f4c73c71de853dcc6:TCSlib/Complexity/CircuitComplexity.lean` |
| `base-e1d39836/TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean` | `d162dd43c3d7fff48900a7882b49ed82bfee0337fc84cb131b88ab6b8e66e071` | `e1d39836ed4a69a34914c35f4c73c71de853dcc6:TCSlib/Complexity/CircuitComplexity/TreeNCAC.lean` |
| `base-e1d39836/TCSlib/ComputationalModels.lean` | `768fa29e52a6cee6b91518d13d23b87c7d4dc05d79a78e063cdd573583e88a22` | `e1d39836ed4a69a34914c35f4c73c71de853dcc6:TCSlib/ComputationalModels.lean` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/Basic.lean` | `05d5f8769bfa5384b306f4f9d51f092d6e23368c748f994438a98bbf56bf39af` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/Basic.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/TreeDAG.lean` | `2b9824996de35e2f56a69e589113bebaf035a5c05de4062eef781151cb01f8a2` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/TreeDAG.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean` | `f827741cefa617d447e7af0b0634bb1c3457ae0c45ddf5f894af685fea81b5fc` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/DAGTransform.lean` | `023b6115dd010206120f1c0cb642db8f5588db7c4be5d9e699572b4f68488a9f` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/DAGTransform.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/DAGFanin.lean` | `b98f2bba415114f9b18fd1e34427d35d32df526a043787359c49c5d925b1c9ed` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/DAGFanin.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/Adder.lean` | `24559b1e5fc92322ecababf99d32fe31bcb80c861e452e8eb655e6b5f790eb10` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/Adder.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/NCAC.lean` | `31ddab1d40e3a085d56fd2564c494fc567ba538fead8651c7157091ded23a2d7` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/NCAC.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/Hierarchy.lean` | `707438cf44e40a0aace5f55206b9ffe7f2e0ced3918dc3d0691b260e6e70e277` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/Hierarchy.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/Parity.lean` | `bd6aae96d48e9ee6d9b018420d395728b939ee16d378d358efef14c4b3b63fee` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/Parity.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/Complexity/CircuitComplexity/LayeredDAG.lean` | `bf677328d1f77e164ce3de30bf51602a1b9e05f147000f312560bffab2be0684` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/Complexity/CircuitComplexity/LayeredDAG.lean (blob-equal at the tip)` |
| `context-73aedcda/TCSlib/BooleanAnalysis/LMN/CircuitReindex.lean` | `926e74954dca0c5aa0e82dc369c66f93dacb8ffa7a2c78063dfc5e2f1dab71b8` | `73aedcdaaaffef7e69ab012d9b9195f150bae68d:TCSlib/BooleanAnalysis/LMN/CircuitReindex.lean (blob-equal at the tip)` |
| `references/barrington-1989-bounded-width-bp.md` | `0e14d97efe06b4c9f0e2f7672d744885b4e53fa2a3777c3694a664322620c71a` | `8c5875fa268a622e4e166da5f7a992715097c2c7:blueprint/src/references/barrington-1989-bounded-width-bp.md` |
| `references/barrington-1989-bounded-width-bp.raw.md` | `683a83f4b325b665406e0091196c697dff5a84e211b2ea1006b1e38339ee747a` | `8c5875fa268a622e4e166da5f7a992715097c2c7:blueprint/src/references/barrington-1989-bounded-width-bp.raw.md` |
| `references/brakerski-vaikuntanathan-2014-fhe.md` | `3da79813fa63acfea4a83229c46f2f8947a7a754657fac8f4d6bf1e7891e9392` | `8c5875fa268a622e4e166da5f7a992715097c2c7:blueprint/src/references/brakerski-vaikuntanathan-2014-fhe.md` |
| `references/brakerski-vaikuntanathan-2014-fhe.raw.md` | `cef46d05faa5e68165d8c60f4b826c37365c7af73d675020bd0e244bf3f8642b` | `8c5875fa268a622e4e166da5f7a992715097c2c7:blueprint/src/references/brakerski-vaikuntanathan-2014-fhe.raw.md` |
| `references/brakerski-vaikuntanathan-2011-fhe.md` | `f415fdbd4488316e2044e0a8e767c75b69964ff48fb6294617b35ae125177eba` | `8c5875fa268a622e4e166da5f7a992715097c2c7:blueprint/src/references/brakerski-vaikuntanathan-2011-fhe.md` |
| `references/brakerski-vaikuntanathan-2011-fhe.raw.md` | `baac9ae3fe77c7d3b0930e3116f3abaf24c49adf7c4b4cae29ad53702c677ac8` | `8c5875fa268a622e4e166da5f7a992715097c2c7:blueprint/src/references/brakerski-vaikuntanathan-2011-fhe.raw.md` |
