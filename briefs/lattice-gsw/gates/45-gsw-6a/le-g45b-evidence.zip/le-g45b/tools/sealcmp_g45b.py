r"""sealcmp_g45b.py <new-rule10-dir> <ref-rule10-dir> <out> (LE-g45b, new; LE-g45's sealcmp_g45.py reduced to one
comparison): canonical coe-A seal records of each owner in <new> (LE-g45b head d154c883) against the same owner's
record in <ref> (LE-g45's head ad9c4fc7). Per owner: requested count, request name set (rows[].spelling), closure-module
count, sealsum row (requested, rc, errors, install, eof, failing declarations), and the seal log's error lines with the
probe line/column numbers removed. Probe and source SHA-256 are printed only (the sources differ in comments)."""
import sys, json, glob, os, re, csv
nd, rd, out = sys.argv[1:4]
def recs(d):
    r = {}
    for p in glob.glob(os.path.join(d, 'seals-coe', 'A', 'Seal*.json')):
        x = json.load(open(p)); r[x['label']] = x
    return r
def tsv(d):
    return {row[0]: row for row in csv.reader(open(os.path.join(d, 'seals-coe-A.tsv')), delimiter='\t') if row}
def errs(d, lab):
    ps = glob.glob(os.path.join(d, 'seal-runs', 'mods', f'*{lab}.log'))
    if not ps: return None
    return [re.sub(r'^\S+\.lean:\d+:\d+: ', '', l.rstrip('\n')) for l in open(ps[0], encoding='utf-8', errors='replace')
            if re.match(r'^\S+\.lean:\d+:\d+: error', l)]
N, R = recs(nd), recs(rd); NT, RT = tsv(nd), tsv(rd)
L = []; allok = bool(N)
for lab in sorted(N):
    h, b = N[lab], R.get(lab)
    if b is None:
        L.append(f'{lab}\tNO REFERENCE RECORD'); allok = False; continue
    sh, sb = {x['spelling'] for x in h['rows']}, {x['spelling'] for x in b['rows']}
    eh, eb = errs(nd, lab), errs(rd, lab)
    ok = h['requested'] == b['requested'] and sh == sb and NT[lab][1:] == RT[lab][1:] and eh == eb and eh is not None
    allok &= ok
    L.append(f"{lab}\tg45b-vs-g45 {'SAME' if ok else 'DIFF'}\trequested={h['requested']}/{b['requested']}\tnames_equal={sh == sb}"
             f"\tclosure_modules={h['closure_modules']}/{b['closure_modules']}\tsealsum_g45b={NT[lab][1:]}\tsealsum_g45={RT[lab][1:]}"
             f"\terrors_equal_mod_lines={eh == eb}\terror_lines={eh}"
             f"\tprobe_sha_equal={h.get('probe_sha256') == b.get('probe_sha256')}"
             f"\tsource_sha_equal={h.get('source_sha256') == b.get('source_sha256')}")
L.append('RESULT ' + ('OK' if allok else 'FAIL'))
open(out, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))
