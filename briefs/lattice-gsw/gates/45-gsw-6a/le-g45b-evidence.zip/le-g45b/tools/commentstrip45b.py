"""commentstrip45b.py <repo> <revA> <revB|DIR:<worktree>> <path>...  (LE-g45b)
Gate 44's commentstrip.py (LE-g44 check), extended: remove every comment (line comments `--` to end of line,
block comments `/- ... -/` with nesting, which covers `/--` doc comments and `/-!` module docs), honouring
string literals and char literals, and compare the stripped texts of <revA>:<path> and <revB>:<path>
(or the worktree file) byte for byte. Prints per file the SHA-256 of both raw and stripped texts, comment
character counts and EQUAL/DIFFER.
Mutation controls (always run): three code mutations of each revB file, each must give DIFFER:
  M1 one space added after the first `:=` of the code;
  M2 one code token changed (the per-file substitution below, asserted to occur once, outside comments);
  M3 one code line commented out by prefixing `-- ` (code hidden inside a comment).
Plus one negative control N1 (a word inside a docstring changed), which must stay EQUAL.
Exit 1 on any DIFFER of the real comparison, any uncaught mutation, or a failed negative control."""
import sys, subprocess, hashlib, os

IDCH = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.!?\'')

def strip(s):
    out = []; i = 0; n = len(s); depth = 0; com = 0
    while i < n:
        if depth:
            if s.startswith('/-', i): depth += 1; i += 2; com += 2; continue
            if s.startswith('-/', i): depth -= 1; i += 2; com += 2; continue
            i += 1; com += 1; continue
        c = s[i]
        if c == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1; continue
        if c == "'" and (i == 0 or s[i - 1] not in IDCH and not s[i - 1].isalnum()):
            if i + 2 < n and s[i + 1] != '\\' and s[i + 2] == "'":
                out.append(s[i:i + 3]); i += 3; continue
            if i + 3 < n and s[i + 1] == '\\' and s[i + 3] == "'":
                out.append(s[i:i + 4]); i += 4; continue
        if s.startswith('/-', i): depth = 1; i += 2; com += 2; continue
        if s.startswith('--', i):
            j = s.find('\n', i)
            j = n if j < 0 else j
            com += j - i; i = j; continue
        out.append(c); i += 1
    assert depth == 0, 'unterminated block comment'
    return ''.join(out), com

def show(repo, rev, path):
    if rev.startswith('DIR:'):
        return open(os.path.join(rev[4:], path), encoding='utf-8').read()
    return subprocess.run(['git', '-C', repo, 'show', f'{rev}:{path}'], check=True,
                          capture_output=True).stdout.decode('utf-8')

# per-file M2 code-token substitutions, M3 code line, N1 docstring-word substitution
CTL = {
  'TCSlib/Complexity/BranchingPrograms/Barrington.lean': (
     ('  List.formPerm [0, 1, 2, 3, 4]\n\n/-- Reader of `sigma1`',
      '  List.formPerm [0, 1, 2, 4, 3]\n\n/-- Reader of `sigma1`'),
     'theorem sigma1_eq : sigma1 = List.formPerm [0, 1, 2, 3, 4] := rfl\n',
     ('one-based cycle notation, implemented in zero-based form',
      'one-based cycle notation, implemented in 0-based form')),
  'TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean': (
     ('def TreeCircuit.const (b : Bool) : TreeCircuit n :=\n  .node b []',
      'def TreeCircuit.const (b : Bool) : TreeCircuit n :=\n  .node (!b) []'),
     '  rw [TreeCircuit.const_eq]; exact eval_node_nil b x\n',
     ('the other value lemmas of the fan-in-2', 'the remaining value lemmas of the fan-in-2')),
}

def h(t): return hashlib.sha256(t.encode()).hexdigest()

def main():
    repo, a, b, paths = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:]
    bad = 0
    for p in paths:
        ra, rb = show(repo, a, p), show(repo, b, p)
        sa, ca = strip(ra); sb, cb = strip(rb)
        eq = sa == sb; bad += not eq
        print(f'{p}\n  raw {a[:12]} {h(ra)}\n  raw {b[:12]} {h(rb)}\n  raw texts '
              + ('equal' if ra == rb else 'differ')
              + f'\n  stripped {a[:12]} {h(sa)}\n  stripped {b[:12]} {h(sb)}\n'
              f'  comment-chars {ca} -> {cb}; code-chars {len(sa)} -> {len(sb)}\n  RESULT '
              + ('EQUAL' if eq else 'DIFFER'))
        (m2o, m2n), m3, (n1o, n1n) = CTL[p]
        # M1 must hit code: first `:=` outside comments
        sk = sb.find(':=')
        m1 = sb[:sk] + ':= ' + sb[sk + 2:]
        assert rb.count(m2o) == 1 and rb.count(m3) == 1 and rb.count(n1o) == 1, p
        m2 = strip(rb.replace(m2o, m2n))[0]
        m3t = strip(rb.replace(m3, '-- ' + m3))[0]
        n1 = strip(rb.replace(n1o, n1n))[0]
        for tag, desc, t in (('M1', 'space after first code `:=`', m1),
                             ('M2', f'code token {m2o.splitlines()[-1 if p.endswith('Combinators.lean') else 0].strip()!r} -> '
                                    f'{m2n.splitlines()[-1 if p.endswith('Combinators.lean') else 0].strip()!r}', m2),
                             ('M3', f'code line commented out: {m3.strip()!r}', m3t)):
            caught = t != sa
            bad += not caught
            print(f'  control {tag} ({desc}): ' + ('DIFFER (caught)' if caught else 'EQUAL (NOT CAUGHT)'))
        ok = n1 == sa
        bad += not ok
        print(f'  negative control N1 (docstring word {n1o.split()[-3]!r}... changed): '
              + ('EQUAL (as required)' if ok else 'DIFFER (FALSE POSITIVE)'))
    print('RESULT', 'OK' if bad == 0 else 'FAIL')
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
