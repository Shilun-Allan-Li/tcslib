"""edit.py <worktree>: LE-g45b's exact docstring edits, each old string asserted to occur exactly once.
Comments/docstrings only: (1) Barrington's remaining "0-based" phrasings of Bar89's one-based cycle notation;
(2) Combinators' `## Main results`: const_eval leaves the "(F3; targets)" bullet (proved by LE-g45 from
BoolCircuit.eval_node_nil, which LE-g45 homed in this file)."""
import sys, os
W = sys.argv[1]
def sub(path, old, new):
    p = os.path.join(W, path); s = open(p, encoding='utf-8').read()
    assert s.count(old) == 1, (path, s.count(old), old[:60])
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
C = 'TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean'
B = 'TCSlib/Complexity/BranchingPrograms/Barrington.lean'
# (1) Barrington module docstring, Main definitions (:23)
sub(B, '''* `BranchingProgram.sigma1`, `sigma2` — Lemma 3's five-cycles `(12345)`, `(13542)`, 0-based.
''', '''* `BranchingProgram.sigma1`, `sigma2` — Lemma 3's five-cycles `(12345)`, `(13542)` in Bar89's
  one-based cycle notation, implemented in zero-based form as `(0 1 2 3 4)`, `(0 2 4 3 1)`.
''')
# (1) sigma1 docstring (:109)
sub(B, '''/-- Bar89's `(12345)`, 0-based: the five-cycle `0 ↦ 1 ↦ 2 ↦ 3 ↦ 4 ↦ 0`, Mathlib's `c[0,1,2,3,4]`,
written `sigma1 = List.formPerm [0, 1, 2, 3, 4]` [Bar89, Lemma 3, p003-b005]. -/''',
'''/-- Bar89's `(12345)` in its one-based cycle notation, whose zero-based form `(0 1 2 3 4)` is what
the code implements: the five-cycle `0 ↦ 1 ↦ 2 ↦ 3 ↦ 4 ↦ 0`, Mathlib's `c[0,1,2,3,4]`, written
`sigma1 = List.formPerm [0, 1, 2, 3, 4]` [Bar89, Lemma 3, p003-b005]. -/''')
# (1) sigma2 docstring (:117)
sub(B, '''/-- Bar89's `(13542)`, 0-based: the five-cycle `0 ↦ 2 ↦ 4 ↦ 3 ↦ 1 ↦ 0`, Mathlib's `c[0,2,4,3,1]`,
written `sigma2 = List.formPerm [0, 2, 4, 3, 1]` [Bar89, Lemma 3, p003-b005]. -/''',
'''/-- Bar89's `(13542)` in its one-based cycle notation, whose zero-based form `(0 2 4 3 1)` is what
the code implements: the five-cycle `0 ↦ 2 ↦ 4 ↦ 3 ↦ 1 ↦ 0`, Mathlib's `c[0,2,4,3,1]`, written
`sigma2 = List.formPerm [0, 2, 4, 3, 1]` [Bar89, Lemma 3, p003-b005]. -/''')
# (2) Combinators module docstring, Main results
sub(C, '''* `BoolCircuit.TreeCircuit.balanced_nil`, `balanced_singleton` — the readers on short lists.
''', '''* `BoolCircuit.TreeCircuit.balanced_nil`, `balanced_singleton` — the readers on short lists.
* `BoolCircuit.TreeCircuit.const_eval` — the constant formula evaluates to its constant (F3);
  proved from `BoolCircuit.eval_node_nil` (an empty gate is a constant), which moved here from
  `Hierarchy.lean`.
''')
sub(C, '''* `BoolCircuit.TreeCircuit.const_eval`, `xor3_eval`, `maj3_eval`, and the value, depth and
  fan-in lemmas of every gadget (F3; targets).
''', '''* `BoolCircuit.TreeCircuit.xor3_eval`, `maj3_eval`, the other value lemmas of the fan-in-2
  gadgets, and the depth and fan-in lemmas of every gadget (F3; targets).
''')
print('edit OK')
