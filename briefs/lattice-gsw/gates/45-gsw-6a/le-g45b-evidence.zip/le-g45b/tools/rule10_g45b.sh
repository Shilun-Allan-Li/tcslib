#!/usr/bin/env bash
# rule10_g45b.sh <phase>... (LE-g45b, 2026-11-17): LE-g45's rule10_g45.sh re-pointed to LE-g45b. Changes:
# (1) one series only, head: export wtx of d154c883 on olean-replay-6a-stmt-g45b; the comparison baseline is LE-g45's head
#     records (le-g45-work/run/rule10/head, ad9c4fc7), not a re-run of the base; owners = the two edited modules
#     Combinators, Barrington;
# (2) touched.json against the records tip e1d39836, regenerated at d154c883 over LE-g45's 17 files;
# (3) phases: collect, coeA, probes (AxiomsStmt and AxiomsG45, unchanged from LE-g45's probe-src);
# (4) every probe through gated_full.sh (slot check before each); SEAL_CHUNK=1000; tools unchanged (g6a-p2/tools).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/le-g45b-work; E=$X/run; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RUN="bash $X/tools/gated_full.sh"
C=TCSlib.Complexity.CircuitComplexity; BPm=TCSlib.Complexity.BranchingPrograms
MODS="$C.FormulaArith.Combinators $BPm.Barrington"
PP=G45Seal
W=$X/wtx; TREE=$SP/olean-replay-6a-stmt-g45b; NAME=head; H=d154c8830fc8ffc52671b41992e7dbef61e30959
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP $E/tmp
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "LE-g45b $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  $RUN $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
probes)
  D=$E/probes/$NAME; mkdir -p $D $W/G6aProbe; : > $D/order.txt
  for p in $PROBES; do cp $X/probe-src/$p.lean $W/G6aProbe/$p.lean; cp $X/probe-src/$p.lean $D/$p.lean.txt; echo G6aProbe/$p >> $D/order.txt; done
  $RUN $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
