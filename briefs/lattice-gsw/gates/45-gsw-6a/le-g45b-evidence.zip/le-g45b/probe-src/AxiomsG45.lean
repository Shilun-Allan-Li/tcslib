import TCSlib.Complexity.CircuitComplexity.Hierarchy
open Lean Elab Command

/-! LE-g45 (maintainer): the moved `eval_node_nil`, the new citation `const_eval`, and Hierarchy's two users of
`eval_node_nil`: statements, home modules and axioms. -/

#check @BoolCircuit.eval_node_nil
#check @BoolCircuit.TreeCircuit.const_eval
#print axioms BoolCircuit.eval_node_nil
#print axioms BoolCircuit.TreeCircuit.const_eval
#print axioms BoolCircuit.restrictCircuit_eval
#print axioms Language.zero_inTreeSize

#eval show CommandElabM Unit from do
  let env ← getEnv
  for n in [``BoolCircuit.eval_node_nil, ``BoolCircuit.TreeCircuit.const_eval,
      ``BoolCircuit.restrictCircuit_eval, ``Language.zero_inTreeSize] do
    match env.getModuleIdxFor? n with
    | some i => logInfo m!"HOME {n} {env.header.moduleNames[i.toNat]!}"
    | none => logInfo m!"HOME {n} none"
