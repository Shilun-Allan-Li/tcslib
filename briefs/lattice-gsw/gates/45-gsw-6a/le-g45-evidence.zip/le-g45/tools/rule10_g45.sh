#!/usr/bin/env bash
# rule10_g45.sh <series> <phase>... (LE-g45, 2026-11-17): the snapshot-#5 re-replay driver g6a-r5/scripts/rule10_g6a5.sh
# (and phase 2's rule10_g6a.sh scan phase) re-pointed to LE-g45. Changes:
# (1) series: head (export wtx of ad9c4fc7, tree olean-replay-6a-stmt-g45), base (export wtb of 73aedcda, tree
#     olean-replay-6a-stmt, read only: runner_full.py runs lean without -o); owners = the three edited modules
#     Combinators, Barrington, Hierarchy;
# (2) touched.json against the records tip e1d39836 (as the re-replay), regenerated with Hierarchy added;
# (3) phases: collect, coeA (canonical coe-A seals), probes, scan (explicit-unfold scan of the three files);
# (4) every probe through gated_full.sh (runner_full.py one probe per call, slot check before each); SEAL_CHUNK=1000;
#     tools unchanged (g6a-p2/tools).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/le-g45-work; E=$X/run; T=$SP/g6a-p2/tools/seal; G=$T/review/archived-gate10-tools; RUN="bash $X/tools/gated_full.sh"
C=TCSlib.Complexity.CircuitComplexity; BPm=TCSlib.Complexity.BranchingPrograms
MODS="$C.FormulaArith.Combinators $BPm.Barrington $C.Hierarchy"
SF="TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean TCSlib/Complexity/BranchingPrograms/Barrington.lean TCSlib/Complexity/CircuitComplexity/Hierarchy.lean"
PP=G45Seal
case $1 in
head) W=$X/wtx; TREE=$SP/olean-replay-6a-stmt-g45; NAME=head; H=ad9c4fc701ed145cbc96acceefaad447398c8321;;
base) W=$X/wtb; TREE=$SP/olean-replay-6a-stmt; NAME=base; H=73aedcdaaaffef7e69ab012d9b9195f150bae68d;;
*) echo "unknown series $1"; exit 2;;
esac
shift
R=$E/rule10/$NAME; TJ=$E/statements/touched-$NAME.json
export GIT_DIR=/home/user/tcslib/.git TCSLIB_OLEANS_TREE=$TREE TMPDIR=$E/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP $E/tmp
for ph in "$@"; do
echo "phase $ph series $NAME start $(date -u +%FT%TZ) rev $H tree $TREE"
case $ph in
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "LE-g45 $NAME collector" $W/$PP/CollectHead.lean
  cp $W/$PP/CollectHead.lean $R/probe-sources/CollectHead.lean.txt
  printf "$PP/CollectHead\n" > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?";;
coeA)
  LOG=$R/probe-runs/mods/${PP}_CollectHead.log
  python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/ZC SealA_ $MODS > $R/mkseals-coe-A.log
  (cd $W && ls $PP/ZC/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  $RUN $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I $T/review/sealsum.py $R/seals-coe/A $R/seal-runs $TJ $R/seals-coe-A.tsv
  cat $R/mkseals-coe-A.log $R/seals-coe-A.tsv;;
scan)
  S=$E/scan/$NAME; mkdir -p $S
  echo $SF > $S/files.txt
  SCAN_IMPORTS="$MODS" python3 -I $T/scan1_g40.py $G/scan_explicit.py $W $TJ $S/items-head.json $W/$PP/ScanKindsHead.lean $SF > $S/scan1.out 2>&1
  cp $W/$PP/ScanKindsHead.lean $S/ScanKindsHead.lean.txt
  echo $PP/ScanKindsHead > $S/order.txt
  $RUN $W $S/order.txt $TREE $S/runs > $S/scan-runner.out 2>&1
  python3 -I $T/scan2.py $S/items-head.json $S/runs/mods/${PP}_ScanKindsHead.log $S/explicit-head.json > $S/scan2-head.log 2>&1; echo "scan2 rc=$?";;
probes)
  # $PROBES: probe basenames from $X/probe-src (phase 2's AxiomsStmt unchanged, and this job's AxiomsG45), copied under $W/G6aProbe/
  D=$E/probes/$NAME; mkdir -p $D $W/G6aProbe; : > $D/order.txt
  for p in $PROBES; do cp $X/probe-src/$p.lean $W/G6aProbe/$p.lean; cp $X/probe-src/$p.lean $D/$p.lean.txt; echo G6aProbe/$p >> $D/order.txt; done
  $RUN $W $D/order.txt $TREE $D/runs > $D/runner.out 2>&1; echo "probes rc=$?";;
esac
echo "phase $ph series $NAME done $(date -u +%FT%TZ)"
done
