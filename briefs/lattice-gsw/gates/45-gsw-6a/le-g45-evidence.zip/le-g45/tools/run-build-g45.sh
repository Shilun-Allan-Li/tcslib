#!/usr/bin/env bash
# run-build-g45.sh (LE-g45): LE-g48's run-build-g48.sh with this job's paths. New head ad9c4fc7 (73aedcda + LE-g45) on
# $SP/olean-replay-6a-stmt-g45 (cp -al of #359's replay tree olean-replay-6a-stmt), plan/queue.txt (16 modules), through the
# recipe's runner.py (unmodified), one module per call; before each module the host's Lean slot count is checked (wait,
# polling 30 s, while 3 or more lean processes run); stop if free disk falls under 1.5 GB.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
B=$SP/le-g45-work; OUT=$SP/olean-replay-6a-stmt-g45; RUNNER=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/runner.py
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$B/run/tmp
mkdir -p $B/run/build/one $B/run/tmp
echo "start $(date -u +%FT%TZ)" > $B/run/build/runner.start; df -m / | tail -1 > $B/run/build/df-launch.txt
while read -r m; do
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $B/run/build/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $B/run/build/slot-log.txt
  echo "$m" > $B/run/build/one/order.txt
  python3 -I $RUNNER $B/wtx $B/run/build/one/order.txt $OUT $B/run/build < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $B/run/build/runner.exit; exit 1; }
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 1536 ] && { echo "DISK LOW $avail MB after $m" >> $B/run/build/runner.exit; exit 2; }
done < $B/run/plan/queue.txt
echo "runner exit 0 $(date -u +%FT%TZ)" >> $B/run/build/runner.exit; df -m / | tail -1 >> $B/run/build/runner.exit
