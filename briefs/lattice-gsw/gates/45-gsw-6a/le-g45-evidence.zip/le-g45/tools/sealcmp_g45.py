r"""sealcmp_g45.py <head-rule10-dir> <base-rule10-dir> <r5-stmt-rule10-dir> <out> (LE-g45, new): canonical coe-A seal records of
the three owners at the new head against the old head (base, run here) and, for Combinators and Barrington, against the
snapshot-#5 re-replay's records of the old head (rule10/stmt). Per owner: requested count, request name set
(rows[].spelling), closure-module count, sealsum row (requested, rc, errors, install, eof, failing declarations), and the
seal log's error lines with the probe line/column numbers removed. Probe and source SHA-256 differ by construction
(the sources differ) and are printed only."""
import sys, json, glob, os, re, csv
hd, bd, r5, out = sys.argv[1:5]
def recs(d):
    r = {}
    for p in glob.glob(os.path.join(d, 'seals-coe', 'A', 'Seal*.json')):
        x = json.load(open(p)); r[x['label']] = x
    return r
def tsv(d):
    return {row[0]: row for row in csv.reader(open(os.path.join(d, 'seals-coe-A.tsv')), delimiter='\t') if row}
def errs(d, lab):
    ps = glob.glob(os.path.join(d, 'seal-runs', 'mods', f'*{lab}.log'))
    if not ps: return None
    return [re.sub(r'^\S+\.lean:\d+:\d+: ', '', l.rstrip('\n')) for l in open(ps[0], encoding='utf-8', errors='replace')
            if re.match(r'^\S+\.lean:\d+:\d+: error', l)]
H, B, F = recs(hd), recs(bd), recs(r5); HT, BT, FT = tsv(hd), tsv(bd), tsv(r5)
L = []; allok = True
for lab in sorted(H):
    h, b = H[lab], B.get(lab)
    sh, sb = {x['spelling'] for x in h['rows']}, {x['spelling'] for x in b['rows']}
    eh, eb = errs(hd, lab), errs(bd, lab)
    ok = h['requested'] == b['requested'] and sh == sb and HT[lab][1:6] == BT[lab][1:6] and HT[lab][6:] == BT[lab][6:] and eh == eb
    allok &= ok
    L.append(f"{lab}\thead-vs-base {'SAME' if ok else 'DIFF'}\trequested={h['requested']}/{b['requested']}\tnames_equal={sh == sb}"
             f"\tclosure_modules={h['closure_modules']}/{b['closure_modules']}\tsealsum_head={HT[lab][1:]}\tsealsum_base={BT[lab][1:]}"
             f"\terrors_equal_mod_lines={eh == eb}\tprobe_sha_equal={h['probe_sha256'] == b['probe_sha256']}\tsource_sha_equal={h['source_sha256'] == b['source_sha256']}")
    if eh: L.append(f"  error lines (head, line numbers removed): {eh}")
    if not sh == sb: L.append(f"  only-head {sorted(sh - sb)}; only-base {sorted(sb - sh)}")
    f = F.get(lab)
    if f is not None:
        sf = {x['spelling'] for x in f['rows']}
        ok2 = f['requested'] == h['requested'] and sf == sh and FT[lab][1:] == HT[lab][1:]
        allok &= ok2
        L.append(f"  vs re-replay #5 record of 73aedcda: {'SAME' if ok2 else 'DIFF'} requested={f['requested']} names_equal={sf == sh} "
                 f"sealsum={FT[lab][1:]} base_source_sha_equal={f['source_sha256'] == b['source_sha256']} base_probe_sha_equal={f['probe_sha256'] == b['probe_sha256']}")
L.append(f"RESULT {'OK' if allok else 'CHECK'}")
open(out, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))
