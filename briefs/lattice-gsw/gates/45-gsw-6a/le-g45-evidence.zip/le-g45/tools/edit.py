"""edit.py <worktree>: LE-g45's exact edits (G45-01..03), each old string asserted to occur exactly once."""
import sys, os
W = sys.argv[1]
def sub(path, old, new):
    p = os.path.join(W, path); s = open(p, encoding='utf-8').read()
    assert s.count(old) == 1, (path, s.count(old), old[:60])
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
H = 'TCSlib/Complexity/CircuitComplexity/Hierarchy.lean'
C = 'TCSlib/Complexity/CircuitComplexity/FormulaArith/Combinators.lean'
B = 'TCSlib/Complexity/BranchingPrograms/Barrington.lean'
# G45-01: remove eval_node_nil from Hierarchy (with its trailing blank line)
sub(H, '''/-! ## Reindexing a circuit -/

/-- An empty gate is a constant: the empty `AND` is `true`, the empty `OR` is `false`. -/
theorem eval_node_nil (b : Bool) (x : Fin n → Bool) :
    (TreeCircuit.node b ([] : List (TreeCircuit n))).eval x = b := by
  cases b <;> simp [TreeCircuit.eval]

/-- A circuit on `m` variables''', '''/-! ## Reindexing a circuit -/

/-- A circuit on `m` variables''')
# G45-01: insert it into Combinators before TreeCircuit.const; proof through TreeDAG's readers (Rule 10)
sub(C, '''/-! ### Constants and the fan-in-2 gadgets (F3) -/

/-- The constant formula with value `b`''', '''/-! ### Constants and the fan-in-2 gadgets (F3) -/

/-- An empty gate is a constant: the empty `AND` is `true`, the empty `OR` is `false`. -/
theorem eval_node_nil (b : Bool) (x : Fin n → Bool) :
    (TreeCircuit.node b ([] : List (TreeCircuit n))).eval x = b := by
  cases b <;> simp [TreeCircuit.eval_node_true, TreeCircuit.eval_node_false]

/-- The constant formula with value `b`''')
# G45-01: const_eval becomes a proved citation
sub(C, '''/-- **F3, constant: value.** The constant formula evaluates to its constant:
`(TreeCircuit.const b).eval x = b`.  Glue.

**Proof sketch.** `const_eq`, then `eval_node_true` (`[].all _ = true`) for `b = true` and
`eval_node_false` (`[].any _ = false`) for `b = false`. -/
theorem TreeCircuit.const_eval (b : Bool) (x : Fin n → Bool) :
    (TreeCircuit.const b : TreeCircuit n).eval x = b := by
  sorry
''', '''/-- **F3, constant: value.** The constant formula evaluates to its constant:
`(TreeCircuit.const b).eval x = b`.  This is `BoolCircuit.eval_node_nil` read through
`const_eq`. -/
theorem TreeCircuit.const_eval (b : Bool) (x : Fin n → Bool) :
    (TreeCircuit.const b : TreeCircuit n).eval x = b := by
  rw [TreeCircuit.const_eq]; exact eval_node_nil b x
''')
# G45-02
sub(C, '''It was the private `combine` of `TreeNCAC.lean`, promoted
unchanged; `BoolCircuit.TreeCircuit.toBinary` now calls it from there.''',
'''It was the private `combine` of `TreeNCAC.lean`, promoted
with its computation unchanged; its proofs carry the five Q2-approved Rule 10 repairs.
`BoolCircuit.TreeCircuit.toBinary` now calls it from there.''')
# G45-03
sub(B, '''  product `sigma2⁻¹ * sigma1⁻¹ * sigma2 * sigma1`, which is `(13254)` 0-based, i.e. the cycle
  `0 ↦ 2 ↦ 1 ↦ 4 ↦ 3 ↦ 0`; the right-to-left reading gives `(14352)` instead (r3 §H3.6).''',
'''  product `sigma2⁻¹ * sigma1⁻¹ * sigma2 * sigma1`.  That is `(13254)` in Bar89's one-based cycle
  notation, whose zero-based form `(0 2 1 4 3)`, the cycle `0 ↦ 2 ↦ 1 ↦ 4 ↦ 3 ↦ 0`, is what the
  code implements; the right-to-left reading gives `(14352)` instead (r3 §H3.6).''')
sub(B, '''`IsFiveCycle (sigma2⁻¹ * sigma1⁻¹ * sigma2 * sigma1)`; the product is `(13254)` 0-based,
`List.formPerm [0, 2, 1, 4, 3]` [Bar89, Lemma 3, p003-b005: "`(12345)(13542)(54321)(24531) =
(13254)`"].''',
'''`IsFiveCycle (sigma2⁻¹ * sigma1⁻¹ * sigma2 * sigma1)`; the product is `(13254)` in Bar89's
one-based cycle notation, whose zero-based form `(0 2 1 4 3)` is what the code implements,
`List.formPerm [0, 2, 1, 4, 3]` [Bar89, Lemma 3, p003-b005: "`(12345)(13542)(54321)(24531) =
(13254)`"].''')
print('ok')
