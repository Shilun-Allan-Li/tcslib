# Questions for Seyoon: statement text changed by the API (meaning unchanged)

**QS1. `Hashing.SIS.hashColumns_eq_mul`: `Matrix.of` on the right-hand side.**
The draft's `hashColumns P N A R = A * fun c j => ((R c j).toNat : ZMod P.modulus)` does not
elaborate: a lambda is not a `Matrix`, so no `HMul` instance applies. The committed statement is
`hashColumns P N A R = A * Matrix.of fun c j => ((R c j).toNat : ZMod P.modulus)`, the same matrix.
- (A, rec.) Accept `Matrix.of` (Mathlib's way to build a matrix from a function; its reader is
  `Matrix.of_apply`).
- (B) State it with GSW's existing `lift` instead. Not possible here: `lift` takes a GSW
  `Parameters`, and `Columns` is GSW-independent.

**QS2. `GSW.Encrypts.mul_bit` and `GSW.Encrypts.mul_le`: `GSW.mul` qualified.**
Inside a declaration named `Encrypts.*`, Lean resolves the bare `mul` to the theorem
`Encrypts.mul` (declared just before), so the draft's `(mul P C₁ C₂)` fails. The committed
statements write `(GSW.mul P C₁ C₂)`, the same constant `TCSlib.Cryptography.AdvancedEncryption.
Homomorphic.GSW.mul` that `Encrypts.mul` and `chain` use.
- (A, rec.) Accept the qualification.
- (B) Rename the theorem `Encrypts.mul` (e.g. `Encrypts.mul_left`) so the bare `mul` resolves.
  This renames a frozen target and the sketches that cite it.
