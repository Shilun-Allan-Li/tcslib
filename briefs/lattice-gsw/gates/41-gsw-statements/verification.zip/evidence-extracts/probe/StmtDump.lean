import TCSlib.Cryptography.AdvancedEncryption
import TCSlib.Cryptography.Hashing.SIS
import TCSlib.Complexity.CircuitComplexity.DAGCircuit
open Lean Elab Command Meta

/-! Statement dump: every constant of the new GSW modules, `Hashing.SIS.Columns` and the
`DAGCircuit` additions, with its type printed with full names, and the TCSlib/Mathlib constants
its type mentions (to check name resolution). -/

set_option pp.fullNames true in
set_option pp.funBinderTypes true in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Gadget,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Noise,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Scheme,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Eval,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Symmetric,
    `TCSlib.Cryptography.Hashing.SIS.Columns]
  let idxs := mods.filterMap env.getModuleIdx?
  let extra : List Name := [`BoolCircuit.DAGGate.depth_eq, `BoolCircuit.DAGGate.getD_lt_depth,
    `BoolCircuit.DAGCircuit.depths_eq, `BoolCircuit.DAGCircuit.depthAt_eq,
    `BoolCircuit.DAGCircuit.depth_eq, `BoolCircuit.runWith_rel]
  let mut out : Array (String × String) := #[]
  for (n, c) in env.constants.toList do
    let inMods := match env.getModuleIdxFor? n with
      | some i => idxs.contains i
      | none => false
    if (inMods && !n.isInternal) || extra.contains n then
      let fmt ← liftTermElabM <| ppExpr c.type
      let consts := c.type.getUsedConstants.filter fun d =>
        (`TCSlib).isPrefixOf d || (`BoolCircuit).isPrefixOf d || (`Randomized).isPrefixOf d
      out := out.push (n.toString, s!"{n}\n  : {fmt}\n  TCSLIB-CONSTS {consts.toList}")
  for (_, s) in out.qsort (fun a b => a.1 < b.1) do
    IO.println s
