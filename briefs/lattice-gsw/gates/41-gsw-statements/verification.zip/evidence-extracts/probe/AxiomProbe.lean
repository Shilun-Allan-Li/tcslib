import TCSlib.Cryptography.AdvancedEncryption
import TCSlib.Cryptography.Hashing.SIS
open Lean Elab Command

/-! Axiom census: every constant (declarations and auxiliary constants) of the new GSW modules,
`Hashing.SIS.Columns`, the three facades, and `Complexity.CircuitComplexity.DAGCircuit`. -/

#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods : List Name := [`TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Gadget,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Noise,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Scheme,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Eval,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Security,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW.Symmetric,
    `TCSlib.Cryptography.Hashing.SIS.Columns,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic.GSW,
    `TCSlib.Cryptography.AdvancedEncryption.Homomorphic, `TCSlib.Cryptography.AdvancedEncryption,
    `TCSlib.Cryptography.Hashing.SIS, `TCSlib.Complexity.CircuitComplexity.DAGCircuit]
  let names := env.header.moduleNames
  let idxs := mods.filterMap env.getModuleIdx?
  let mut out : Array String := #[]
  for (n, _) in env.constants.toList do
    match env.getModuleIdxFor? n with
    | some i =>
      if idxs.contains i then
        let axs ← liftCoreM (Lean.collectAxioms n)
        let tag := if n.isInternal then "AUX" else "DECL"
        out := out.push s!"{tag}\t{names[i.toNat]!}\t{n}\t{axs.qsort (·.toString < ·.toString) |>.toList}"
    | none => pure ()
  for l in out.qsort (· < ·) do
    IO.println l
