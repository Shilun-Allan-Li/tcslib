# GSW statement phase: `UNCHECKED` markers and their resolution

The drafts (`briefs/lattice-gsw/draft/`, records commit 5bbeb9e8) carried 23 `UNCHECKED` comment
blocks. Each was checked against the real API: by elaboration (the module compiles with rc 0 at
`stmt/gsw`), by the full-name statement dump (`statements.txt`, `probe/StmtDump.lean`), and by a
`#check` probe of every cited name (`apicheck.txt`, `probe/ApiCheck.lean`). All 23 comment blocks
are removed from the committed files: all 23 marked uses are correct as drafted. Four other places
needed a change (found by elaboration and by the `#check` probe); none changes a statement's
meaning.

## Changes (4)

| # | File | Draft | Fix | Kind |
|---|---|---|---|---|
| F1 | `Hashing/SIS/Columns.lean`, `hashColumns_eq_mul` | `A * fun c j => ((R c j).toNat : ZMod P.modulus)` | `A * Matrix.of fun c j => …` | statement text; a bare lambda has no `HMul (Matrix …) (… → … → …)` instance (elaboration error). Same matrix. Question QS1. |
| F2 | `GSW/Noise.lean`, `Encrypts.mul_bit`, `Encrypts.mul_le` | `(mul P C₁ C₂)` | `(GSW.mul P C₁ C₂)` | statement text; inside a declaration named `Encrypts.*`, the bare `mul` resolves to the theorem `Encrypts.mul` (elaboration error). Same constant `GSW.mul`. Question QS2. |
| F3 | `GSW/Eval.lean`, sketch of `homGate_encrypts` | `List.forall₂_map` | `List.forall₂_map_left_iff` and `List.forall₂_map_right_iff` | docstring only; `List.forall₂_map` does not exist. |
| F4 | `GSW/Symmetric.lean`, sketch of `distAdv_symEncrypt_le` | `Symmetric.Regev.distAdv_encrypt_le` | `Encryption.Symmetric.Regev.distAdv_encrypt_le` | docstring only; the short name does not resolve from the GSW namespace. |

Not an `UNCHECKED` place, but also fixed: the draft facade `Homomorphic/GSW.lean` lacked the
closing `-/` of its module docstring ("unterminated comment"); added. The draft banner comments
(`-- DRAFT …`, `-- OPTIONAL UNIT …`, `-- Depends on …`) were dropped, and every file gained the
`Authors: TCSlib contributors` line of its sibling `AdvancedEncryption` files.

## The 23 marked places, verified as drafted

| File | Marker | Verification |
|---|---|---|
| Gadget | `Lossy.gadget (b w) : Matrix (Fin (w * b)) (Fin w) ℤ`, here `b = ℓ`, `w = n+1` | `gadget` elaborates; `Fin P.columns` is `Fin ((n+1)*ℓ)` by the reducible `Parameters.columns`. |
| Gadget | `ZMod.val_lt` under the `NeZero` instance of `LWE.Basic` | `digit` elaborates. |
| Gadget | `Randomized.blocksEquiv (n b)` | `decomposeVec` elaborates; root namespace `Randomized`. |
| Gadget | `Lossy.digits`, `digits_eq` (sketch) | exist with the quoted types. |
| Gadget | `Lossy.gadget_mulVec` (sketch) | exists with the quoted type. |
| Gadget | `Lossy.digits_val` (sketch) | exists with the quoted type. |
| Gadget | `LWE.binaryErrorSum_bound` (sketch) | exists with the quoted type. |
| Noise | `Matrix.vecMul_vecMul`, `vecMul_smul`, `add_vecMul` (sketch; Mathlib `Data/Matrix/Mul.lean` 818, 773, 750) | exist; line numbers match the pinned Mathlib. |
| Scheme | `open Encryption.PublicKey` to reach `Regev.*` | kept: the statement dump shows that only `Regev.{augmented, decrypt, extractionError, keygen}` resolve into `Encryption.PublicKey`; no GSW name is captured. |
| Scheme | `Regev.augmented`, `augmented_eq` | exist with the quoted types; `encrypt` elaborates. |
| Scheme | `Regev.decrypt`; `Fin.init` at the non-dependent family | `decrypt` elaborates. |
| Scheme | `Regev.keygen` | exists with the quoted type. |
| Scheme | `LWE.BitEncoding.decode_codepoint_add` (sketch) | exists with the quoted type. |
| Eval | `open Encryption.PublicKey` | as in Scheme. |
| Eval | `runWith` with `β : Type`; `Ciphertext P : Type` | `evalValues` elaborates. |
| Eval | `DAGGate.eval_eq` (sketch) | exists with the quoted type. |
| Security | `open Encryption.PublicKey` | as in Scheme. |
| Security | `LWE.decisionAdvantage` with coin type `Matrix (Fin m) (Fin N) Bool × ρ` | `real_uniformKey_advantage` elaborates. |
| Security | `Regev.extractionError`, `augmented_bijective` | exist. |
| Security | `Regev.two_extractionError_le` | exists with the quoted type. |
| Symmetric | `open Encryption.PublicKey` | as in Scheme. |
| Symmetric | seed type of the samplers inferred from `LWE.sample` | `distAdv_symEncrypt_le` elaborates. |
| Columns | `distAdv_hash_uniform_le`, `abs_sub_le_sum_hybrids` (sketch) | exist with the quoted types. |

(By file: Gadget 7, Noise 1, Scheme 5, Eval 3, Security 4, Symmetric 2, Columns 1 = 23.)

Also checked, cited only in sketches: `acceptProb_comp_equiv`, `uprob_comp_equiv`, `distAdv_def`,
`Equiv.prodAssoc`, `Fin.sum_univ_castSucc`, `Fin.snoc_castSucc`, `Fin.snoc_last`,
`Matrix.dotProduct_mulVec`, `Nat.pow_le_pow_right`, `Int.natAbs_{add_le,mul,neg}`,
`DAGCircuit.{depthAt_gate,depthAt_input,eval_eq,values_eq}`, `Regev.{keygen_fst,keygen_snd,
decrypt_eq,extractionError_eq,real_uniformKey_advantage,distAdv_encrypt_le}`, `LWE.{sample_fst,
sample_snd,noisyValues_apply,decisionAdvantage_eq}`, `LWE.Noise.bounded_iff`,
`Hashing.SIS.hash_eq`. `distAdv_multi_le_sum` (cited in the Security module docstring) is
`TCSlib.Cryptography.distAdv_multi_le_sum` (EnsembleSecurity.lean:134), as the docstring says; the
plan section's `PublicKeyScheme.distAdv_multi_le_sum` is not its name.
