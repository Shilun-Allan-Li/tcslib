"""stage4041.py <records-repo> <records-pin> <exchange-wt> <40|41>: write the outbox of the Gate 40 (pairings) or
Gate 41 (GSW) statement gate (the Gate 27/28 statement-gate layout): README.md, pack.md, bundle.md, BUNDLE-FILES.txt,
LEAN-HEAD.txt, RECORDS.txt, SHA256SUMS, and byte copies (git show at the records pin, checked equal to the working
tree) of the gate directory's files: pr.diff.txt, pr-description.md, source-head.json, sources.zip, verification.zip
and source-excerpts/. bundle.md concatenates, under `## ===== <path> =====` headers, the pack, the records it needs,
the source excerpts and the Lean files at the head(s), as listed in BUNDLE-FILES.txt (`<rev> <path>` per section).

pincheck: before writing, every verification.zip member that the ZIP's PROVENANCE marks "filed by the pin commit"
is compared with that path's blob at the pin (byte-identical, or the stage stops)."""
import hashlib, os, re, subprocess, sys, zipfile

repo, pin, wt, gate = sys.argv[1:5]


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


show = lambda rev, path: git('show', f'{rev}:{path}')
sha = lambda b: hashlib.sha256(b).hexdigest()
pin = git('rev-parse', pin).decode().strip()

if gate == '40':
    G = 'briefs/pairings/gates/40-pairings-statements'
    OUT = 'outbox/gates/40-pairings-statements-gate'
    LEAN = '#331 110c2f9db810d243693b9a5e8976a5ad205f1bab\n'
    H = '110c2f9db810d243693b9a5e8976a5ad205f1bab'
    stem = 'gate40-pairings-statements'
    recs = [f'{G}/pack.md', 'policy.md', 'PairingCryptographyPlan.md', 'briefs/pairings/statement-phase/EVIDENCE.md',
            f'{G}/source-excerpts/Jou00-excerpts.md', f'{G}/source-excerpts/BB04-excerpts.md']
    lean = ['TCSlib/Cryptography/Pairing/Group.lean', 'TCSlib/Cryptography/Pairing/Assumptions.lean',
            'TCSlib/Cryptography/Pairing/Operations.lean', 'TCSlib/Cryptography/KeyExchange/Joux.lean',
            'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/Defs.lean',
            'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyen.lean',
            'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenMachine.lean',
            'TCSlib/Cryptography/AdvancedEncryption/IdentityBased/BonehBoyenSecurity.lean',
            'TCSlib/Cryptography/Pairing.lean', 'TCSlib/Cryptography/KeyExchange.lean',
            'TCSlib/Cryptography/AdvancedEncryption/IdentityBased.lean',
            'TCSlib/Cryptography/AdvancedEncryption.lean']
    lean = [(H, p) for p in lean]
    readme = f"""# Codex audit · Gate 40 pairings (#331, statement)

Audit draft PR #331 at {H} using the scope in pack.md: a **statement audit** of the pairing campaign
(PairingCryptographyPlan.md, rulings Q1-Q13 and the location ruling): the bilinear bundle and generator, BDH and
Decision BDH, Joux's tripartite Diffie-Hellman, the IBE interface and the selective-identity game, and the Boneh-Boyen
system BB1, with the four sorried targets T1-T4, and an audit **as proofs** of the results the PR already proves (Joux
correctness and key indistinguishability, jouxGame_eq_dbdhGame, BB1 correctness, and bb1_sidSecure from T2-T4).
Campaign records are pinned at {pin}.

The bundle contains the pack, policy, the campaign plan, the statement-phase EVIDENCE.md, text excerpts of the
passages of [Jou00] and [BB04] that the statements use (the PDFs are not committed, ruling Q12), and the 12 new Lean
modules at the head.

Also:
- pr.diff.txt: the full diff from the PR base 523d80d2d4dd8e4ed6799358831e5b3806c6187b to the head;
- pr-description.md: the PR description as fetched from GitHub on 2026-11-16;
- source-head.json: the head hashes, line counts and over-width counts of the changed files;
- sources.zip: the source closure at the head of every changed module (86 files; the library root TCSlib.lean is
  included as a file, not as a closure root);
- source-excerpts/: the two excerpt files (also in bundle.md);
- verification.zip: the statement evidence stmt-pairings-r2.zip with its manifest and PROVENANCE, byte copies of the
  entries the pack cites, the round-1 evidence, the cited records, context files for the duplication question and the
  pack's git-object re-checks (pack-checks/); its entries are exactly its SHA256SUMS plus SHA256SUMS.

Check SHA256SUMS before using the pack.

Return {stem}-findings.md as Markdown in the chat. If you have several evidence files, return a ZIP containing
that Markdown and the evidence. The user dispatches and merges.
"""
else:
    G = 'briefs/lattice-gsw/gates/41-gsw-statements'
    OUT = 'outbox/gates/41-gsw-statements-gate'
    LEAN = '#332 94eae71b779c4ca0f76c138d699f4d737dbd6cee\n#333 48d796a8a68cd50897047f01825a8132dd19e8d8\n'
    H = '48d796a8a68cd50897047f01825a8132dd19e8d8'
    stem = 'gate41-gsw-statements'
    recs = [f'{G}/pack.md', 'policy.md', 'briefs/lattice-gsw/rulings.md', 'briefs/lattice-gsw/questions.md',
            'briefs/lattice-gsw/plan-section.md', 'briefs/lattice-gsw/statement-phase/EVIDENCE.md',
            f'{G}/source-excerpts/GSW13-excerpts.md', f'{G}/source-excerpts/AP14-excerpts.md',
            f'{G}/source-excerpts/Pei16-excerpts.md', f'{G}/source-excerpts/BV14-excerpts.md']
    lean = ['TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Gadget.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Noise.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Scheme.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Eval.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Security.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW/Symmetric.lean',
            'TCSlib/Cryptography/Hashing/SIS/Columns.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic/GSW.lean',
            'TCSlib/Cryptography/AdvancedEncryption/Homomorphic.lean',
            'TCSlib/Cryptography/AdvancedEncryption.lean']
    lean = [('94eae71b779c4ca0f76c138d699f4d737dbd6cee', lean[0])] + [(H, p) for p in lean[1:]]
    readme = f"""# Codex audit · Gate 41 GSW statements (#332 and #333, audited together)

Audit draft PR #332 (DAGCircuit depth readers and runWith_rel) at 94eae71b779c4ca0f76c138d699f4d737dbd6cee and
draft PR #333 (GSW leveled homomorphic encryption from LWE, phase 5 of the lattice campaign; stacked on #332) at
{H}, using the scope in pack.md: a **statement audit** of the 35 sorried GSW targets (gadget, noise algebra,
public-key scheme, circuit evaluation and leveled correctness, IND-CPA, the optional secret-key unit, the column
leftover-hash lemma), under rulings Q1-Q16 (Q9 changed) and QS1-QS2, and an audit as proofs of #332's two proved
results (DAGGate.getD_lt_depth, runWith_rel). Campaign records are pinned at {pin}.

The bundle contains the pack, policy, the rulings, questions and plan section, the statement-phase EVIDENCE.md, text
excerpts of the passages of [GSW13], [AP14], [Pei16] and [BV14] that the statements use (the PDFs are not committed),
DAGCircuit.lean at #332's head and the GSW and Columns modules and facades at #333's head.

Also:
- pr.diff.txt: the full diff from the common base 523d80d2d4dd8e4ed6799358831e5b3806c6187b to #333's head (it
  contains #332's single commit; its DAGCircuit.lean part is exactly #332's diff);
- pr-description.md: the two PR descriptions as fetched from GitHub on 2026-11-16;
- source-head.json: the head hashes, line counts and over-width counts of the changed files;
- sources.zip: the source closure at #333's head of every changed module (118 files; the library root TCSlib.lean is
  included as a file, not as a closure root);
- source-excerpts/: the four excerpt files (also in bundle.md);
- verification.zip: the statement evidence stmt-gsw.zip with its manifest and PROVENANCE, byte copies of the entries
  the pack cites, the cited records, context files for the reuse and duplication questions and the pack's git-object
  re-checks (pack-checks/); its entries are exactly its SHA256SUMS plus SHA256SUMS.

Check SHA256SUMS before using the pack.

Return {stem}-findings.md as Markdown in the chat. If you have several evidence files, return a ZIP containing
that Markdown and the evidence. The user dispatches and merges.
"""

# pincheck
vz = zipfile.ZipFile(os.path.join(repo, G, 'verification.zip'))
prov = vz.read('PROVENANCE.txt').decode()
filed = re.findall(r'^  (\S+)  <-  filed by the pin commit: (\S+)$', prov, re.M)
assert filed
for member, path in filed:
    assert vz.read(member) == show(pin, path), f'pincheck: {member} != {pin[:8]}:{path}'
print(f'pincheck: {len(filed)} members equal to their blobs at the pin')

files = {}
srcmap = {f: f'{G}/{f}' for f in ['pack.md', 'pr.diff.txt', 'pr-description.md', 'source-head.json', 'sources.zip',
                                  'verification.zip']}
for e in git('ls-tree', '--name-only', pin, f'{G}/source-excerpts/').decode().split():
    srcmap[f'source-excerpts/{os.path.basename(e)}'] = e
for f, s in srcmap.items():
    b = show(pin, s)
    assert open(os.path.join(repo, s), 'rb').read() == b, f'working tree differs from {pin[:8]}: {s}'
    files[f] = b
sections, listing = [], []
for p in recs:
    sections.append(f'## ===== {p} =====\n\n' + show(pin, p).decode())
    listing.append(f'{pin} {p}')
for rev, p in lean:
    sections.append(f'## ===== {p} (Lean, at {rev}) =====\n\n```lean\n' + show(rev, p).decode() + '```\n')
    listing.append(f'{rev} {p}')
files['bundle.md'] = '\n'.join(sections).encode()
files['BUNDLE-FILES.txt'] = ('\n'.join(listing) + '\n').encode()
files['LEAN-HEAD.txt'] = LEAN.encode()
files['RECORDS.txt'] = f'{pin}\n'.encode()
files['README.md'] = readme.encode()
out = os.path.join(wt, OUT)
assert not os.path.exists(out), out
for p, b in files.items():
    os.makedirs(os.path.dirname(os.path.join(out, p)), exist_ok=True)
    open(os.path.join(out, p), 'wb').write(b)
files['SHA256SUMS'] = ''.join(f'{sha(files[p])}  {p}\n' for p in sorted(files)).encode()
open(os.path.join(out, 'SHA256SUMS'), 'wb').write(files['SHA256SUMS'])
print(OUT, len(files) - 1, 'listed; SHA256SUMS', sha(files['SHA256SUMS']), '; bundle', sha(files['bundle.md']),
      f'({len(sections)} sections); verification.zip', sha(files['verification.zip']))
