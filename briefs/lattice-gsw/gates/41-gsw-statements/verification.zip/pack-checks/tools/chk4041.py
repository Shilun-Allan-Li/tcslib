"""chk4041.py <repo> <40|41> <out-dir>: the pack re-checks of the Gate 40 (pairings, #331) and Gate 41 (DAGCircuit
readers #332 and GSW #333) statement gates, from git objects alone (no Lean, no lake). Writes:
  series.txt      commits base..head: author, committer, parents, tree, gpgsig header; the PR diff equals base..head
  files.txt       name-status, numstat, line counts, widths and SHA-256 of every changed file at the head; whether each
                  pre-existing file changes by insertion only
  decls.txt       every declaration of every changed Lean file at the head: kind, line, private, attributes, body
                  (sorry / rfl / Iff.rfl / proof), docstring present, source tag present, `**Proof sketch.**` present
  sorries.txt     `sorry` count per file (outside comments) and the declarations that carry them
  readers.txt     for each public def/abbrev/structure: its reader (an `_eq`/`_apply`/`_iff`/`_def` theorem or a
                  simps attribute) if any
  facades.txt     each facade's imports against the modules of its folder
  mergetrees.txt  `git merge-tree --write-tree` of each head with the records tip, the open #324, #326, #327 and the
                  campaign's other statement heads; conflicts; the modules whose import closure meets the Lean changes
                  of both sides (they need a rebuild after that merge)
  names.txt       new public declaration names (namespace-qualified by a textual namespace stack) that already exist
                  at the tip
  dupscan.txt     where the tip already has the concepts the PR introduces (keyword scan of TCSlib at the tip)
"""
import hashlib, json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo, closure, downstream, decls

repo, gate, out = sys.argv[1:4]
R = Repo(repo)
os.makedirs(out, exist_ok=True)
TIP = R.rp('origin/cryptography/pass-shelat-ch2-4')
BASE = R.rp('523d80d2d4dd8e4ed6799358831e5b3806c6187b')
HEADS = {331: R.rp('110c2f9db810d243693b9a5e8976a5ad205f1bab'),
         332: R.rp('94eae71b779c4ca0f76c138d699f4d737dbd6cee'),
         333: R.rp('48d796a8a68cd50897047f01825a8132dd19e8d8')}
OPEN = {324: R.rp('4bd2d80bfb58fab5243c66c9f1a697a30b533756'),
        326: R.rp('c27005d67298f79c785a4e8ac1648da0a67d3614'),
        327: R.rp('bd19c433a4cf3d4027ffc891d7d3c06e927e9dfa')}
MINE = [331] if gate == '40' else [332, 333]
sha = lambda b: hashlib.sha256(b).hexdigest()
W = {}


def w(name, s):
    W.setdefault(name, []).append(s)


# ---------------------------------------------------------------- series
for pr in MINE:
    h = HEADS[pr]
    mb = R.git('merge-base', TIP, h).stdout.strip()
    w('series', f'#{pr} head {h}\n  merge-base with origin/cryptography/pass-shelat-ch2-4 ({TIP}): {mb}'
                f'{" = 523d80d2 (stated base)" if mb == BASE else " (DIFFERS from 523d80d2)"}')
    w('series', f'  base..head: {R.git("rev-list", "--count", f"{BASE}..{h}").stdout.strip()} commits')
    for c in R.git('rev-list', '--reverse', f'{BASE}..{h}').stdout.split():
        raw = R.git('cat-file', '-p', c).stdout
        hdr = raw.split('\n\n', 1)[0]
        tree = re.search(r'^tree (\S+)', hdr, re.M).group(1)
        parents = re.findall(r'^parent (\S+)', hdr, re.M)
        au = re.search(r'^author (.*?) \d+ [+-]\d+$', hdr, re.M).group(1)
        co = re.search(r'^committer (.*?) \d+ [+-]\d+$', hdr, re.M).group(1)
        subj = raw.split('\n\n', 1)[1].splitlines()[0]
        sig = 'gpgsig=1' if re.search(r'^gpgsig ', hdr, re.M) else 'gpgsig=0'
        w('series', f'  {c} tree {tree} parents {" ".join(parents)}\n    author {au}; committer {co}; {sig}\n'
                    f'    "{subj}"')
    d1 = R.gitb('diff', f'{TIP}...{h}')
    d2 = R.gitb('diff', f'{BASE}..{h}')
    w('series', f'  diff {TIP[:8]}...{h[:8]} == diff {BASE[:8]}..{h[:8]}: {d1 == d2} ({len(d2)} bytes, sha256 {sha(d2)})')
    recs = R.git('diff', '--name-only', f'{BASE}..{TIP}').stdout.split()
    lean_tip = [p for p in recs if p.endswith('.lean') or p.startswith('TCSlib') or p in ('lakefile.lean',
                                                                                         'lake-manifest.json')]
    w('series', f'  base..tip changes {len(recs)} paths, {len(lean_tip)} under TCSlib/ or Lake files: '
                + (', '.join(lean_tip) if lean_tip else '-'))
if gate == '41':
    d332 = R.gitb('diff', f'{BASE}..{HEADS[332]}')
    d333dag = R.gitb('diff', f'{BASE}..{HEADS[333]}', '--', 'TCSlib/Complexity/CircuitComplexity/DAGCircuit.lean')
    par = R.git('rev-parse', f'{HEADS[333]}~1^2', check=False).stdout.strip()
    w('series', f'#333 is stacked on #332: {R.anc(HEADS[332], HEADS[333])}; #332 changes only DAGCircuit.lean, and '
                f'#333\'s diff of that file from the base is #332\'s diff: {d332 == d333dag}')
    w('series', f'  {HEADS[333][:8]}~1 = {R.rp(HEADS[333] + "~1")}, {HEADS[333][:8]}~2 = {R.rp(HEADS[333] + "~2")}')

# ---------------------------------------------------------------- files
H = HEADS[MINE[-1]]
st = {}
for l in R.git('diff', '--name-status', '--no-renames', BASE, H).stdout.splitlines():
    s, p = l.split('\t')
    st[p] = s
num = {}
for l in R.git('diff', '--numstat', '--no-renames', BASE, H).stdout.splitlines():
    a, d, p = l.split('\t')
    num[p] = (int(a), int(d))
w('files', f'base {BASE} .. head {H}: {len(st)} files, +{sum(a for a, _ in num.values())} '
           f'-{sum(d for _, d in num.values())}')
w('files', 'status  +add  -del  lines  max-width  >100  sha256  path')
for p in sorted(st):
    b = R.blob(H, p)
    t = b.decode()
    L = t.splitlines()
    w('files', f'{st[p]}  +{num[p][0]}  -{num[p][1]}  {len(L)}  {max(map(len, L))}  {sum(len(x) > 100 for x in L)}  '
               f'{sha(b)[:16]}…  {p}')
pre = [p for p in st if st[p] == 'M']
for p in pre:
    old = R.blob(BASE, p).decode().splitlines()
    new = R.blob(H, p).decode().splitlines()
    # insertion-only: the old file is a subsequence of the new one
    it = iter(new)
    sub = all(any(x == y for y in it) for x in old)
    w('files', f'pre-existing {p}: {len(old)} -> {len(new)} lines; old file is a subsequence of the new '
               f'(insertions only): {sub}')

# ---------------------------------------------------------------- decls, sorries, readers
lean = sorted(p for p in st if p.endswith('.lean') and st[p] != 'D')


def strip_comments(t):
    t = re.sub(r'/-.*?-/', lambda m: '\n' * m.group(0).count('\n'), t, flags=re.S)
    return re.sub(r'--[^\n]*', '', t)


def body_kind(text, line):
    Ls = text.split('\n')
    j = line - 1
    block = []
    while j < len(Ls):
        block.append(Ls[j])
        j += 1
        if j < len(Ls) and (Ls[j].strip() == '' or re.match(r'^(/--|theorem|lemma|def|abbrev|@\[|noncomputable|'
                                                             r'structure|instance|end |namespace|section|open|attribute|'
                                                             r'private|variable)', Ls[j])):
            break
    b = '\n'.join(block)
    b2 = strip_comments(b)
    if re.search(r'\bsorry\b', b2):
        return 'SORRY'
    m = re.search(r':=\s*(by\s+)?(.*)$', b2, re.S)
    if not m:
        return 'fields'
    m2 = re.search(r':=\s*(rfl|Iff\.rfl)\s*$', b2)
    if m2:
        return m2.group(1)
    tail = m.group(2).strip()
    return 'proof' if m.group(1) or tail.startswith(('by', 'fun', '(', '⟨', '_')) or '\n' in tail else 'term'


def doc_attrs(text, line, doc, attrs):
    """the docstring and attributes of the declaration at `line`, looking above attribute lines."""
    Ls = text.split('\n')
    k = line - 2
    extra = []
    while k >= 0 and Ls[k].lstrip().startswith('@['):
        extra.insert(0, Ls[k].strip())
        k -= 1
    if not doc and extra and k >= 0 and Ls[k].rstrip().endswith('-/'):
        s = k
        while s >= 0 and '/--' not in Ls[s]:
            s -= 1
        doc = '\n'.join(Ls[s:k + 1])
    return doc, ' '.join(extra + ([attrs] if attrs else []))


allnames = {}
for p in lean:
    t = R.show(H, p)
    ds = decls(t)
    pub = [k for k, v in ds.items() if not v[4]]
    w('decls', f'== {p} ({len(t.splitlines())} lines; {len(ds)} declarations, {len(pub)} public)')
    w('decls', 'line  kind  vis  body  doc  tag  sketch  attrs  name')
    for name, (kind, ln, header, doc, priv) in sorted(ds.items(), key=lambda kv: kv[1][1]):
        if p.endswith('DAGCircuit.lean'):
            old = R.show(BASE, p)
            if re.search(r'(?m)^(?:@\[[^\]]*\]\s*)?(?:private\s+|noncomputable\s+)*(?:theorem|lemma|def|abbrev|structure|'
                         r'inductive|instance)\s+' + re.escape(name.split('#')[0]) + r'\b', old):
                continue
        bk = body_kind(t, ln) if kind in ('theorem', 'lemma') else ('SORRY' if re.search(
            r'\bsorry\b', strip_comments(header)) else kind)
        attrs = ' '.join(re.findall(r'@\[[^\]]*\]', t.split('\n')[ln - 1]))
        doc, attrs = doc_attrs(t, ln, doc, attrs)
        tag = bool(re.search(r'\[(BB04|Jou00|PS10|GSW13|AP14|Pei16|BV14|AB09|Wu24|Vad12)\b', doc))
        sk = '**Proof sketch.**' in doc
        w('decls', f'{ln}  {kind}  {"priv" if priv else "pub"}  {bk}  {"Y" if doc else "N"}  {"Y" if tag else "-"}  '
                   f'{"Y" if sk else "-"}  {attrs or "-"}  {name}')
        allnames.setdefault(p, []).append((name, kind, ln, priv, bk, bool(doc), tag, sk, attrs))
    tc = strip_comments(t)
    n = len(re.findall(r'\bsorry\b', tc))
    s_decls = [x[0] for x in allnames.get(p, []) if x[4] == 'SORRY']
    w('sorries', f'{n:3d}  {p}' + (f'\n       {", ".join(s_decls)}' if s_decls else ''))
    simps = []
    for m in re.finditer(r'(?m)^attribute \[simps[^\]]*\]((?:[^\n]*)(?:\n[ \t]+[^\n]*)*)', t):
        simps += re.findall(r'[\w.]+', m.group(1))
    inline_simps = [x[0] for x in allnames.get(p, []) if 'simps' in x[8]]
    for name, kind, ln, priv, bk, *_ in allnames.get(p, []):
        if priv or kind not in ('def', 'abbrev', 'structure'):
            continue
        short = name.split('.')[-1]
        cands = [x[0] for x in allnames[p] if x[1] in ('theorem', 'lemma') and
                 x[0].split('.')[-1].lower().startswith(short.lower() + '_')]
        if name in simps or name in inline_simps or short in simps:
            cands.append('simps')
        if kind == 'structure':
            cands.append('(structure: fields are projections)')
        w('readers', f'{"OK " if cands else "-- "} {p.split("/")[-1]}:{ln} {kind} {name}: {", ".join(cands) or "none"}')
tot = sum(len(re.findall(r'\bsorry\b', strip_comments(R.show(H, p)))) for p in lean)
w('sorries', f'total {tot}')

# ---------------------------------------------------------------- facades
for p in lean:
    t = R.show(H, p)
    folder = p[:-5]
    kids = sorted(q for q in R.git('ls-tree', '--name-only', f'{H}:{os.path.dirname(p)}/'
                                   f'{os.path.basename(folder)}', check=False).stdout.split() if q.endswith('.lean'))
    if not kids:
        continue
    imps = set(re.findall(r'(?m)^import\s+(\S+)', t))
    mod = folder.replace('/', '.')
    for k in kids:
        km = f'{mod}.{k[:-5]}'
        listed = f'`{k[:-5]}`' in t
        w('facades', f'{p}: child {km}: imported {km in imps}; listed in the docstring {listed}')
for p in ('TCSlib.lean',):
    if p in st:
        t = R.show(H, p)
        for q in lean:
            if q.count('/') == 2 and q.startswith('TCSlib/Cryptography/') and q.endswith('.lean'):
                m = q[:-5].replace('/', '.')
                w('facades', f'TCSlib.lean imports {m}: {("import " + m) in t}')

# ---------------------------------------------------------------- merge trees
g_cache = {}


def graph(rev):
    if rev not in g_cache:
        g_cache[rev] = R.graph(rev)
    return g_cache[rev]


def own(x):
    """the Lean change set a side brings: a statement head from 523d80d2, the tip from 523d80d2, an open PR from its
    merge base with the tip."""
    if x in HEADS.values() or x == TIP:
        return set(R.lean_changed(BASE, x))
    return set(R.lean_changed(R.git('merge-base', x, TIP).stdout.strip(), x))


def joint(a, b, tree):
    mb = R.git('merge-base', a, b).stdout.strip()
    ca = own(a)
    cb = own(b)
    g = {}
    for p in R.git('ls-tree', '-r', '--name-only', tree).stdout.split():
        if p.endswith('.lean') and p.startswith(('TCSlib', 'audits')):
            g[p] = [m.replace('.', '/') + '.lean' for m in re.findall(r'(?m)^import\s+(\S+)', R.show(tree, p))
                    if m.startswith(('TCSlib', 'audits'))]
    both = sorted(p for p in g if closure(g, [p]) & ca and closure(g, [p]) & cb)
    return mb, ca, cb, both


others = {'tip': TIP, **{f'#{k}': v for k, v in OPEN.items()},
          **{f'#{k}': v for k, v in HEADS.items() if k not in MINE}}
for pr in MINE:
    h = HEADS[pr]
    for nm, o in others.items():
        if nm == '#332' and pr == 333:
            continue
        r = R.git('merge-tree', '--write-tree', '--name-only', '--messages', h, o, check=False)
        lines = r.stdout.split('\n')
        tree = lines[0]
        confl = [l for l in lines[1:] if l and not l.startswith(('Auto-merging', 'CONFLICT')) and l.strip()]
        msgs = [l for l in lines[1:] if l.startswith('CONFLICT')]
        mb, ca, cb, both = joint(h, o, tree)
        w('mergetrees', f'#{pr} {h[:8]} x {nm} {o[:8]}: rc {r.returncode} ({"clean" if r.returncode == 0 else "CONFLICT"}),'
                        f' tree {tree}; merge-base {mb[:8]}')
        for m in msgs:
            w('mergetrees', f'    {m}')
        w('mergetrees', f'    Lean files each side changes (statement heads and tip from 523d80d2, open PRs from their merge base with the tip): this side {len(ca)}, other side {len(cb)}; '
                        f'shared changed files: {sorted(ca & cb) or "none"}')
        w('mergetrees', f'    modules whose closure meets both sides (rebuild after this merge): {len(both)}'
                        + (f'\n      ' + '\n      '.join(both) if both and len(both) <= 60 else
                           (f' (first 60)\n      ' + '\n      '.join(both[:60]) if both else '')))

# ---------------------------------------------------------------- names
NS = re.compile(r'^\s*(namespace|end|section)\b\s*(\S*)')


def fullnames(text):
    stack, res = [], {}
    Ls = text.split('\n')
    for i, l in enumerate(Ls):
        m = NS.match(l)
        if m:
            kw, nm = m.groups()
            if kw == 'namespace':
                stack.append(('n', nm))
            elif kw == 'section':
                stack.append(('s', nm))
            elif stack:
                stack.pop()
            continue
        m = re.match(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*'
                     r'(theorem|lemma|def|abbrev|structure|inductive|instance|class)\s+([^\s({:\[]+)', l)
        if m and 'private' not in l.split(m.group(2))[0]:
            nm = m.group(2)
            if nm.startswith('_root_.'):
                full = nm[len('_root_.'):]
            else:
                full = '.'.join([x for k, x in stack if k == 'n' and x] + [nm])
            res[full] = i + 1
    return res


tipnames = {}
for p in R.git('ls-tree', '-r', '--name-only', TIP, 'TCSlib').stdout.split():
    if p.endswith('.lean'):
        for n_, ln in fullnames(R.show(TIP, p)).items():
            tipnames.setdefault(n_, []).append(f'{p}:{ln}')
new = {}
for p in lean:
    for n_, ln in fullnames(R.show(H, p)).items():
        if p.endswith('DAGCircuit.lean') and n_ in fullnames(R.show(BASE, p)):
            continue
        new[n_] = f'{p}:{ln}'
clash = {n_: tipnames[n_] for n_ in new if n_ in tipnames}
short = {}
for n_ in tipnames:
    short.setdefault(n_.split('.')[-1], []).append(n_)
w('names', f'{len(new)} new public declarations (textual namespace stack); {len(tipnames)} public names at the tip '
           f'{TIP[:8]}; exact full-name clashes: {len(clash)}')
for n_, locs in sorted(clash.items()):
    w('names', f'  CLASH {n_}: new {new[n_]}; tip {locs}')
w('names', 'new names whose last component also names a declaration at the tip (same short name, other namespace):')
for n_ in sorted(new):
    s = n_.split('.')[-1]
    hits = [x for x in short.get(s, []) if x != n_]
    if hits and not s.endswith(('_eq', '_iff', '_apply')):
        w('names', f'  {n_}  ~  {", ".join(sorted(hits)[:6])}{" …" if len(hits) > 6 else ""}')
w('names', 'all new public names:\n  ' + '\n  '.join(f'{n_}  {new[n_]}' for n_ in sorted(new)))

# ---------------------------------------------------------------- dupscan
KEYS40 = [r'\bbilinear', r'\bpairing\b', r'\bBDH\b|\bbdh', r'\bDDH\b|\bddh', r'\bIBE\b|identity-based', r'tripartite',
          r'\bElGamal\b|\bEl Gamal\b|\begCanon\b', r'\bGroupPKScheme\b', r'\bExpGroupGen\b', r'\bguessAdv\b',
          r'\bexists_handlerMachine\b', r'\bsampleBelowL\b', r'\bindGame\b', r'\boracleImpl\b']
KEYS41 = [r'\bgadget\b', r'\bdigits\b', r'\bblocksEquiv\b', r'\bhashParameters\b', r'\bextractionError\b',
          r'\bdistAdv_hash_uniform_le\b', r'\brunWith_sim\b', r'\brunWith_rel\b', r'\bhomomorphic', r'\bGSW\b',
          r'\bdepth_eq\b|\bdepthAt_eq\b|\bdepths_eq\b', r'\bbinaryErrorSum_bound\b', r'\baugmented\b']
KEYS = KEYS40 if gate == '40' else KEYS41
files_tip = [p for p in R.git('ls-tree', '-r', '--name-only', TIP, 'TCSlib').stdout.split() if p.endswith('.lean')]
texts = {p: R.show(TIP, p) for p in files_tip}
for k in KEYS:
    hits = sorted((p, len(re.findall(k, t, flags=re.I if k.startswith(r'\b') and k[2].islower() else 0)))
                  for p, t in texts.items() if re.search(k, t, flags=re.I if k.startswith(r'\b') and k[2].islower() else 0))
    w('dupscan', f'/{k}/ at the tip: {len(hits)} files' + ''.join(f'\n    {n_:4d}  {p}' for p, n_ in hits[:25])
      + ('\n    …' if len(hits) > 25 else ''))

for k, v in W.items():
    open(os.path.join(out, f'{k}.txt'), 'w').write(
        f'# {k}.txt (chk4041.py, gate {gate}; git objects only; tip {TIP})\n' + '\n'.join(v) + '\n')
print(gate, {k: len(v) for k, v in W.items()})
