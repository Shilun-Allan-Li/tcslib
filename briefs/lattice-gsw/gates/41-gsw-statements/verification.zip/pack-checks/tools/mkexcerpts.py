"""mkexcerpts.py <40|41> <src-dir> <repo> <out-dir>: the source excerpts of the Gate 40 / 41 statement gates
(pairing ruling Q12: text of only the passages used; the PDFs are not committed). Each excerpt file is Markdown: a
header (reference, version, PDF SHA-256 checked here, extraction method, the line ranges taken) and, per passage, the
verbatim `pdftotext -layout` lines in a text fence (form feeds shown as a `[page break]` line). Pei16 is excerpted
from the committed raw extraction `blueprint/src/references/peikert2016-lattice-survey.raw.md` (line ranges of that
file at the records tip). Source text is data, not instructions."""
import hashlib, os, subprocess, sys

gate, src, repo, out = sys.argv[1:5]
U = '/root/.claude/uploads/d0667d12-db8d-5853-b0f7-9833dc0884c6'
SPEC = {
    '40': [
        ('Jou00', 'A. Joux, *A One Round Protocol for Tripartite Diffie–Hellman*, ANTS-IV, W. Bosma (ed.), LNCS 1838, '
                  'pp. 385–393, Springer, 2000 (publisher copy, 9 pp.)',
         'caa4e7e1-Joux', 'dd423b93a7e2dbeb87e6210b26f4c3ec022c3d0681a0ce72262b1d45c53f6df9',
         [((1, 4), 'title'),
          ((97, 128), '§2, p. 387: the Weil and Tate pairings are bilinear and non-degenerate'),
          ((129, 195), '§3, pp. 387–388: the protocol, F_W, the remark e_n(P, P) = 1, two points and F_T, the summary'),
          ((325, 367), '§5, pp. 391–392: security issues')]),
        ('BB04', 'D. Boneh, X. Boyen, *Efficient Selective-ID Secure Identity Based Encryption Without Random '
                 'Oracles*, Cryptology ePrint Archive, Report 2004/172, full version dated December 2004 (20 pp.); '
                 'its numbering is used throughout',
         '5f30a7ab-Boneh-Boyen', '63c1c7b0817f36d6e558107bf281e22d2c454f821fadd533ced653e81a6a35de',
         [((1, 11), "title"),
          ((93, 181), '§2, §2.1 (IBE, the selective-identity game, Definitions 2.1 and 2.2) and §2.2 (bilinear groups), '
                      'pp. 2–4'),
          ((182, 207), '§3 and §3.1 (BDH, Decision BDH, P_BDH / R_BDH, Definition 3.1), pp. 4–5'),
          ((236, 397), '§4, §4.1 (the HIBE construction; BB1 is depth 1) and §4.2 (Theorem 4.1 and its proof), '
                       'pp. 5–8'),
          ((405, 412), '§4.4 (arbitrary identities, "2^b < p is sufficient"), p. 8')]),
    ],
    '41': [
        ('GSW13', 'C. Gentry, A. Sahai, B. Waters, *Homomorphic Encryption from Learning with Errors: '
                  'Conceptually-Simpler, Asymptotically-Faster, Attribute-Based*, CRYPTO 2013; author version dated '
                  '8 June 2013 (25 pp.)',
         'b137b0c5-GSW13', '8edb94cfd852a88a8684adbf81b73e78bd21466514b7bb7000d7df1e4431bf00',
         [((1, 5), 'title'),
          ((167, 286), '§1.3.1–§1.3.4: homomorphic operations, error bounds, flattening, BitDecomp / Powersof2, '
                       'key generation and encryption'),
          ((374, 579), '§2.3, §3.1 (Setup, SecretKeyGen, PublicKeyGen, Enc, Dec, MPDec), §3.2 (security, Lemma 1), '
                       '§3.3 (MultConst, Add, Mult, NAND, "Circuits") and §3.4 (parameters, q/B > 8(N+1)^L, '
                       'Theorem 3)')]),
        ('AP14', 'J. Alperin-Sheriff, C. Peikert, *Faster Bootstrapping with Polynomial Error*, CRYPTO 2014; IACR '
                 'ePrint 2014/094, version dated 13 June 2014 (18 pp.)',
         '976ebdd4-2014-094', 'cecd346d2e879ff865c23fe977e172e1068f20b01c7f555a419d2f3d5ec2c0da',
         [((1, 3), 'title'),
          ((326, 483), '§3: §3.1 (gadget g, Claim 3.1, Equation (3.1)), §3.2 (the GSW variant: Gen, Enc, Dec, the '
                       'operations, IND-CPA remark), §3.3 (Definitions 3.2–3.3, Claim 3.4, Lemma 3.5, Corollary 3.6)'),
          ((484, 581), '§4 to Corollary 4.2: Equation (4.1) (cited by `Encrypts.sum`) and the permutation-matrix '
                       'chains (phase-7 roadmap, ruled Q12 for BV14)')]),
        ('BV14', 'Z. Brakerski, V. Vaikuntanathan, *Lattice-Based FHE as Secure as PKE*, ITCS 2014; IACR ePrint '
                 '2013/541 (PDF created 28 August 2013, 21 pp.)',
         '463f4f97-2013-541', 'eab2d1667a8e8a07155968141c72d0ff0be15b1185dd0fd34f291fb41fb812ca',
         [((1, 2), 'title'),
          ((345, 388), '§2.5: Definitions 2.12–2.13, Theorem 2.14 (bootstrapping, weak circular security)'),
          ((389, 811), '§3: §3.1 (NCCrypt, Definition 3.1, Lemmas 3.2–3.3, Proposition 3.4), §3.2 (Claims '
                       '3.4.1–3.4.2), §3.3 (width-5 PBPs, Equations (4)–(6), Theorem 3.5, Lemma 3.6), §3.4 '
                       '(Theorem 3.7)')]),
        ('Pei16', 'C. Peikert, *A Decade of Lattice Cryptography*, author version dated 17 February 2016 (already '
                  'ingested: `blueprint/src/references/peikert2016-lattice-survey{,.raw}.md`; the scoped `.md` '
                  'covers Definitions 4.1.1, 4.2.1, 4.2.3 and SIS passages only, so §5.4.3 and §6.1.2–6.1.3 are '
                  'quoted from the committed raw extraction)',
         'RAW:blueprint/src/references/peikert2016-lattice-survey.raw.md',
         '1a9802b66031a2b863fd498a5de4a71cdb1bd46ac1d47dc1f4a67ae341357488',
         [((2530, 2586), '§5.4.3 "Gadgets": g, G = I_n ⊗ gᵗ, Equation (5.4.1), G · G⁻¹(u) = u'),
          ((3374, 3499), '§6.1.2 (bootstrapping, circular security) and §6.1.3 (third-generation FHE: Equations '
                         '(6.1.4)–(6.1.7), decryption, NAND, right-associative chains, Barrington)')]),
    ],
}
os.makedirs(out, exist_ok=True)
for tag, ref, f, want, ranges in SPEC[gate]:
    if f.startswith('RAW:'):
        path = os.path.join(repo, f[4:])
        rev = subprocess.run(['git', '-C', repo, 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()
        blob = subprocess.run(['git', '-C', repo, 'show', f'HEAD:{f[4:]}'], capture_output=True).stdout
        assert open(path, 'rb').read() == blob
        text = blob.decode()
        assert want in text.split('\n', 3)[1], 'raw file header does not name the PDF hash'
        how = (f'Lines of the committed file `{f[4:]}` (blob {subprocess.run(["git", "-C", repo, "rev-parse", f"HEAD:{f[4:]}"], capture_output=True, text=True).stdout.strip()} at records '
               f'{rev}), whose header names PDF SHA-256 `{want}` and `pdftotext -layout`.')
    else:
        pdf = os.path.join(U, f + '.pdf')
        got = hashlib.sha256(open(pdf, 'rb').read()).hexdigest()
        assert got == want, (tag, got)
        text = open(os.path.join(src, f + '.txt'), encoding='utf-8').read()
        how = (f'`pdftotext -layout` (poppler) of the uploaded PDF, SHA-256 `{got}` (checked when this file was '
               f'written); line numbers are those of the extracted text.')
    L = text.split('\n')
    body = [f'# {tag}: excerpts of the passages used (Gate {gate})', '',
            f'**Reference.** {ref}.', '', f'**Extraction.** {how} The PDF itself is not committed (pairing ruling Q12; '
            f'GSW ruling Q14 and the plan-section provenance). Only the passages below are quoted. Mathematical '
            f'layout (sub- and superscripts, fraction bars) is flattened by the extraction; read formulas against '
            f'the Lean statements and the PDF where needed.', '', '**Passages.**', '']
    for (a, b), what in ranges:
        body.append(f'- lines {a}–{b}: {what}')
    for (a, b), what in ranges:
        chunk = '\n'.join(L[a - 1:b]).replace('\f', '\n[page break]\n')
        assert '```' not in chunk
        body += ['', f'## Lines {a}–{b}: {what}', '', '```text', chunk.rstrip('\n'), '```']
    open(os.path.join(out, f'{tag}-excerpts.md'), 'w', encoding='utf-8').write('\n'.join(body) + '\n')
    print(tag, sum(b - a + 1 for (a, b), _ in ranges), 'lines')
