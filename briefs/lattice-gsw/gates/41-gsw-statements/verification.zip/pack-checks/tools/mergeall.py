"""mergeall.py <repo> <out.txt>: merge every open head onto the records tip, in two orders, with `git merge-tree
--write-tree` and throw-away `git commit-tree` objects (no ref is written, nothing is checked out). Order A: #324,
#326, #327, #331, #332, #333; order B: #332, #333, #331, #327, #326, #324. The only expected conflict is #331 against
#333 in `TCSlib.lean` and `TCSlib/Cryptography/AdvancedEncryption.lean` (both PRs add the shared facade); it is
resolved here by the union the plans prescribe ("whichever lands second adds its child import"), and the resolved
files are printed. The two final trees are compared."""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gitlib import Repo

repo, out = sys.argv[1:3]
R = Repo(repo)
TIP = R.rp('origin/cryptography/pass-shelat-ch2-4')
H = {324: '4bd2d80bfb58fab5243c66c9f1a697a30b533756', 326: 'c27005d67298f79c785a4e8ac1648da0a67d3614',
     327: 'bd19c433a4cf3d4027ffc891d7d3c06e927e9dfa', 331: '110c2f9db810d243693b9a5e8976a5ad205f1bab',
     332: '94eae71b779c4ca0f76c138d699f4d737dbd6cee', 333: '48d796a8a68cd50897047f01825a8132dd19e8d8'}
ENV = dict(os.environ, GIT_AUTHOR_NAME='trial', GIT_AUTHOR_EMAIL='trial@invalid', GIT_COMMITTER_NAME='trial',
           GIT_COMMITTER_EMAIL='trial@invalid', GIT_AUTHOR_DATE='2026-11-16T00:00:00Z',
           GIT_COMMITTER_DATE='2026-11-16T00:00:00Z')
log = []

FACADE = '''/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.AdvancedEncryption.Homomorphic
import TCSlib.Cryptography.AdvancedEncryption.IdentityBased

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Advanced encryption primitives

Encryption primitives beyond private-key and public-key encryption.

## Contents

* `Homomorphic`: homomorphic encryption; leveled Gentry–Sahai–Waters encryption from LWE.
* `IdentityBased`: identity-based encryption, selective-identity security and the Boneh–Boyen
  system (BB1).

## References

* [BB04] D. Boneh, X. Boyen, *Efficient Selective-ID Secure Identity Based Encryption Without
  Random Oracles*, full version, Cryptology ePrint Archive, Report 2004/172, December 2004.
* [GSW13] C. Gentry, A. Sahai, B. Waters, *Homomorphic Encryption from Learning with Errors:
  Conceptually-Simpler, Asymptotically-Faster, Attribute-Based*, CRYPTO 2013; author version
  dated 8 June 2013.
-/
'''


def git(*a, inp=None):
    return subprocess.run(['git', '-C', repo, *a], input=inp, capture_output=True, env=ENV)


def resolve_tree(base_commit, head, tree_with_conflicts):
    """write a tree equal to the conflicted merge tree except the two facade files, resolved by union."""
    ours = R.show(base_commit, 'TCSlib.lean').split('\n')
    theirs = R.show(head, 'TCSlib.lean').split('\n')
    # ours, plus each import line of theirs that ours lacks, inserted after the import that precedes it in theirs
    root = list(ours)
    for k, l in enumerate(theirs):
        if l.startswith('import ') and l not in root:
            prev = next(x for x in reversed(theirs[:k]) if x.startswith('import '))
            root.insert(root.index(prev) + 1, l)
    root_txt = '\n'.join(root)
    blob_root = git('hash-object', '-w', '--stdin', inp=root_txt.encode()).stdout.decode().strip()
    blob_fac = git('hash-object', '-w', '--stdin', inp=FACADE.encode()).stdout.decode().strip()
    idx = os.path.join(os.environ.get('TMPDIR', '/tmp'), 'mergeall.index')
    e = dict(ENV, GIT_INDEX_FILE=idx)
    subprocess.run(['git', '-C', repo, 'read-tree', tree_with_conflicts], env=e, check=True)
    for path, blob in (('TCSlib.lean', blob_root), ('TCSlib/Cryptography/AdvancedEncryption.lean', blob_fac)):
        subprocess.run(['git', '-C', repo, 'update-index', '--add', '--cacheinfo', f'100644,{blob},{path}'], env=e,
                       check=True)
    t = subprocess.run(['git', '-C', repo, 'write-tree'], env=e, capture_output=True, text=True, check=True).stdout.strip()
    os.remove(idx)
    return t, root_txt


def run(order, name):
    cur = TIP
    log.append(f'== order {name}: tip {TIP[:8]} then ' + ', '.join(f'#{k}' for k in order))
    for k in order:
        r = R.git('merge-tree', '--write-tree', '--name-only', '--messages', cur, H[k], check=False)
        lines = r.stdout.split('\n')
        tree = lines[0]
        confl = [l for l in lines[1:] if l.startswith('CONFLICT')]
        if r.returncode != 0:
            assert sorted(l.split()[-1] for l in confl) == ['TCSlib.lean', 'TCSlib/Cryptography/AdvancedEncryption.lean'], confl
            tree, root_txt = resolve_tree(cur, H[k], tree)
            log.append(f'  + #{k}: CONFLICT in TCSlib.lean and AdvancedEncryption.lean, resolved by union -> tree {tree}')
            log.append('    resolved TCSlib.lean imports: ' + '; '.join(l[7:] for l in root_txt.split('\n')
                                                                       if l.startswith('import TCSlib.Cryptography.')
                                                                       and l[7:].split('.')[2] in (
                                                                           'Pairing', 'KeyExchange', 'AdvancedEncryption',
                                                                           'Implications', 'Randomness')))
        else:
            log.append(f'  + #{k}: clean -> tree {tree}')
        c = git('commit-tree', tree, '-p', cur, '-p', H[k], '-m', f'trial {k}').stdout.decode().strip()
        cur = c
    return R.git('rev-parse', f'{cur}^{{tree}}').stdout.strip()


ta = run([324, 326, 327, 331, 332, 333], 'A')
tb = run([332, 333, 331, 327, 326, 324], 'B')
log.append(f'final trees: A {ta}, B {tb}; equal: {ta == tb}')
fac = R.show(ta, 'TCSlib/Cryptography/AdvancedEncryption.lean')
log.append('resolved TCSlib/Cryptography/AdvancedEncryption.lean (union of the two drafts):\n' + fac)
open(out, 'w').write('# mergeall.txt (mergeall.py; git objects only, throw-away commit objects, no refs)\n'
                     + '\n'.join(log) + '\n')
print('\n'.join(log[:20]))
