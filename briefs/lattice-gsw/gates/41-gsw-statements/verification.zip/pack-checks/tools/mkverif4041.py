"""mkverif4041.py <repo> <40|41> <checks-dir> <tools-dir> <out.zip>: the verification ZIP of the Gate 40 (pairings,
#331) or Gate 41 (DAGCircuit readers #332 and GSW #333) statement gate.

Members are byte-identical originals:
- evidence/: the statement-phase evidence ZIP with its manifest (`SHA256SUMS`, the ZIP's own inner manifest) and its
  PROVENANCE, as filed in the records by the pin commit (taken from the working tree; the pin commit adds exactly
  these bytes, checked after the commit by `pincheck` in stage4041.py);
- evidence-extracts/: byte copies of the evidence-ZIP entries the pack cites (read from the ZIP);
- records/: the campaign records the pack cites, at the records commit REC (HEAD when this ZIP is built, before the
  pin), each checked equal to the working tree or named as the pre-pin version;
- round1/ (Gate 40 only): the round-1 statement evidence already in the records (briefs/pairings/statement-phase/
  evidence/), at REC;
- source-excerpts/: the text excerpts of the passages used, as filed by the pin commit (working tree);
- context/: existing library files at the records tip that the duplication and reuse questions compare against;
- pack-checks/: the pack's re-checks from git objects, with their scripts.
Writes PROVENANCE.txt and SHA256SUMS (every other entry)."""
import collections, hashlib, io, os, subprocess, sys, zipfile

repo, gate, chk, tools, out = sys.argv[1:6]


def git(*a):
    return subprocess.run(['git', '-C', repo, *a], check=True, capture_output=True).stdout


REC = git('rev-parse', 'HEAD').decode().strip()
TIP = git('rev-parse', 'origin/cryptography/pass-shelat-ch2-4').decode().strip()
sha = lambda b: hashlib.sha256(b).hexdigest()
members = []


def rec(path, dst, allow_changed=False):
    b = git('show', f'{REC}:{path}')
    wt = open(os.path.join(repo, path), 'rb').read()
    note = f'records {REC[:8]}:{path}'
    if wt != b:
        assert allow_changed, f'working tree differs from {REC[:8]} for {path}'
        note += ' (pre-pin version; the pin commit appends a row)'
    members.append((dst, b, note))


def wtfile(path, dst):
    members.append((dst, open(os.path.join(repo, path), 'rb').read(), f'filed by the pin commit: {path}'))


def ctx(path):
    members.append((f'context/{path}', git('show', f'{TIP}:{path}'), f'records tip {TIP[:8]}:{path}'))


if gate == '40':
    EV = 'briefs/pairings/statement-phase/evidence-r2'
    ZIP, TOP = 'stmt-pairings-r2.zip', 'stmt-pairings-r2'
    EXC = 'briefs/pairings/gates/40-pairings-statements/source-excerpts'
    excerpts = ['Jou00-excerpts.md', 'BB04-excerpts.md']
    records = [('PairingCryptographyPlan.md', True), ('briefs/pairings/README.md', False),
               ('briefs/pairings/statement-phase/EVIDENCE.md', True), ('policy.md', False)]
    cited = ['PROVENANCE.txt', 'axioms.txt', 'build/closure/summary.txt', 'build/closure-need.txt',
             'build/root/summary.txt', 'git/commits.txt', 'git/rebase-range-diff.txt', 'statements/T4-identity.txt',
             'statements/T4-block.txt', 'seal/summary.txt', 'rule10/modules.txt', 'rule10/seal-order.txt',
             'rule10/seal-seals-A.tsv', 'rule10/seal-seals-B.tsv', 'rule10/seal-seals-coe-A.tsv',
             'rule10/seal-seals-coe-B.tsv', 'lint/style_lint.txt', 'lint/campaign-Pairing.txt',
             'lint/campaign-KeyExchange.txt', 'lint/campaign-AdvancedEncryption.txt', 'tree/snapshot-pre.txt',
             'tree/snapshot-post.txt', 'probe/AxiomProbe.lean']
    context = ['TCSlib/Cryptography/Candidates/DDH.lean', 'TCSlib/Cryptography/Candidates/DiscreteLog.lean',
               'TCSlib/Cryptography/Encryption/PublicKey/ElGamal.lean', 'TCSlib/Cryptography/Games/Advantage.lean',
               'TCSlib/Cryptography/Encryption/PublicKey/OracleSecurity.lean']
    title = 'Gate 40 (pairings, draft PR #331, Lean head 110c2f9db810d243693b9a5e8976a5ad205f1bab)'
else:
    EV = 'briefs/lattice-gsw/statement-phase/evidence'
    ZIP, TOP = 'stmt-gsw.zip', 'stmt-gsw'
    EXC = 'briefs/lattice-gsw/gates/41-gsw-statements/source-excerpts'
    excerpts = ['GSW13-excerpts.md', 'AP14-excerpts.md', 'BV14-excerpts.md', 'Pei16-excerpts.md']
    records = [('LatticeCryptographyPlan.md', True), ('briefs/lattice-gsw/plan-section.md', False),
               ('briefs/lattice-gsw/questions.md', False), ('briefs/lattice-gsw/rulings.md', False),
               ('briefs/lattice-gsw/statement-phase/EVIDENCE.md', True), ('policy.md', False),
               ('briefs/lattice-gsw/draft/shared/DAGCircuit-additions.lean', False)]
    cited = ['PROVENANCE.txt', 'axioms.txt', 'unchecked-fixes.md', 'questions-statement-changes.md',
             'build/closure-need.txt', 'build/final/summary.txt', 'build/root/summary.txt',
             'build/iterations-summary.txt', 'git/commits.txt', 'git/signing.txt', 'statements/statements.txt',
             'statements/apicheck.txt', 'draft/draft-to-final.diff', 'rule10/touched.tsv', 'rule10/seal-seals-A.tsv',
             'rule10/seal-seals-B.tsv', 'rule10/seal-seals-coe-A.tsv', 'rule10/seal-seals-coe-B.tsv',
             'lint/sizes-widths.txt', 'lint/style_lint.txt', 'lint/campaign-AdvancedEncryption.txt',
             'lint/campaign-Hashing.txt', 'lint/dag-base.txt', 'lint/dag-head.txt', 'rule10/controls/summary.txt',
             'rule10/controls/Control_neg_sealed.lean', 'rule10/controls/Control_neg_sealed.lean.log',
             'tree/snapshot-pre.txt', 'tree/snapshot-post.txt', 'probe/AxiomProbe.lean', 'probe/ApiCheck.lean',
             'probe/StmtDump.lean']
    context = ['TCSlib/Cryptography/SecureComputation/Garbling.lean',
               'TCSlib/Cryptography/Encryption/PublicKey/Regev/Experiments.lean',
               'TCSlib/Cryptography/Encryption/PublicKey/Regev/Basic.lean',
               'TCSlib/Cryptography/TrapdoorFunctions/Lossy/Gadget.lean',
               'TCSlib/Cryptography/Hashing/SIS/Universality.lean', 'TCSlib/Cryptography/LWE/Basic.lean',
               'TCSlib/Cryptography/LWE/BitEncoding.lean', 'TCSlib/Cryptography/Encryption/Symmetric/Regev.lean']
    title = ('Gate 41 (DAGCircuit readers, draft PR #332, Lean head 94eae71b779c4ca0f76c138d699f4d737dbd6cee; GSW, '
             'draft PR #333, Lean head 48d796a8a68cd50897047f01825a8132dd19e8d8)')

for f in (ZIP, 'SHA256SUMS', 'PROVENANCE.txt'):
    wtfile(f'{EV}/{f}', f'evidence/{f}')
z = zipfile.ZipFile(os.path.join(repo, EV, ZIP))
inner = {l.split('  ', 1)[1][2:]: l.split('  ', 1)[0] for l in z.read(f'{TOP}/SHA256SUMS').decode().splitlines()}
assert z.read(f'{TOP}/SHA256SUMS') == open(os.path.join(repo, EV, 'SHA256SUMS'), 'rb').read()
assert all(sha(z.read(f'{TOP}/{p}')) == h for p, h in inner.items()), 'evidence ZIP inner manifest'
missing = []
for c in cited:
    n = f'{TOP}/{c}'
    if n not in z.namelist():
        missing.append(c)
        continue
    members.append((f'evidence-extracts/{c}', z.read(n), f'{ZIP} entry {n} (manifest {inner.get(c, "-")[:12]}…)'))
assert not missing, missing
for p, allow in records:
    rec(p, f'records/{p}', allow)
if gate == '40':
    r1 = git('ls-tree', '-r', '--name-only', REC, 'briefs/pairings/statement-phase/evidence/').decode().split()
    for p in r1:
        rec(p, 'round1/' + p[len('briefs/pairings/statement-phase/evidence/'):])
for e in excerpts:
    wtfile(f'{EXC}/{e}', f'source-excerpts/{e}')
for c in context:
    ctx(c)
for c in sorted(os.listdir(chk)):
    members.append((f'pack-checks/{c}', open(os.path.join(chk, c), 'rb').read(), f'pack re-check (git objects): {c}'))
for t in ['chk4041.py', 'mergeall.py', 'gitlib.py', 'mksources4041.py', 'mkexcerpts.py', 'mkverif4041.py',
          'stage4041.py', 'verifyout.py']:
    members.append((f'pack-checks/tools/{t}', open(os.path.join(tools, t), 'rb').read(), f'pack tool: {t}'))
prov = (f'{title}: verification.zip\n\nBuilt from git objects and the records working tree, records commit REC = {REC} '
        f'(before the pin), records tip {TIP}. No Lean or lake was run.\n'
        + __doc__.split('\n\n', 1)[1] + '\nSources:\n' + ''.join(f'  {p}  <-  {d}\n' for p, _, d in sorted(members)))
members.append(('PROVENANCE.txt', prov.encode(), 'generated'))
members.sort(key=lambda m: m[0])
assert len({p for p, _, _ in members}) == len(members), 'duplicate member'
sums = ''.join(f'{sha(b)}  {p}\n' for p, b, _ in members)
members.append(('SHA256SUMS', sums.encode(), 'generated'))
with zipfile.ZipFile(out, 'w') as zz:
    for p, b, _ in members:
        zi = zipfile.ZipInfo(p, date_time=(2026, 11, 16, 0, 0, 0))
        zi.external_attr = 0o100644 << 16
        zi.compress_type = zipfile.ZIP_STORED if p.endswith('.zip') else zipfile.ZIP_DEFLATED
        zz.writestr(zi, b)
with zipfile.ZipFile(out) as zz:
    listed = zz.namelist()
    inn = {l.split('  ', 1)[1] for l in zz.read('SHA256SUMS').decode().splitlines()}
    assert set(listed) == inn | {'SHA256SUMS'} and len(listed) == len(inn) + 1
    for l in zz.read('SHA256SUMS').decode().splitlines():
        h, p = l.split('  ', 1)
        assert sha(zz.read(p)) == h, p
print(f'OK gate {gate}: {len(listed)} entries {dict(collections.Counter(n.split("/")[0] for n in listed))}; '
      f'sha256 {sha(open(out, "rb").read())}; REC {REC}')
