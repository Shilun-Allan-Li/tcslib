"""verifyout.py <dir>: check an outbox extracted from a fresh `git archive`: SHA256SUMS lists exactly the files
present (except itself) and every hash verifies; each ZIP whose name ends in verification*.zip has entries exactly its
SHA256SUMS plus SHA256SUMS, all verifying; each evidence ZIP next to an evidence-SHA256SUMS manifest matches it."""
import hashlib, os, sys, zipfile
d = sys.argv[1]
sha = lambda b: hashlib.sha256(b).hexdigest()
present = sorted(os.path.relpath(os.path.join(r, f), d) for r, _, fs in os.walk(d) for f in fs)
lines = open(os.path.join(d, 'SHA256SUMS')).read().splitlines()
listed = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in lines}
assert set(listed) == set(present) - {'SHA256SUMS'}, sorted(set(listed) ^ (set(present) - {'SHA256SUMS'}))
bad = [p for p, h in listed.items() if sha(open(os.path.join(d, p), 'rb').read()) != h]
assert not bad, bad
print(f'{d}: SHA256SUMS {sha(open(os.path.join(d, "SHA256SUMS"), "rb").read())}; {len(listed)}/{len(listed)} OK')
for p in present:
    if os.path.basename(p).startswith('verification') and p.endswith('.zip'):
        z = zipfile.ZipFile(os.path.join(d, p))
        inner = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in z.read('SHA256SUMS').decode().splitlines()}
        assert set(z.namelist()) == set(inner) | {'SHA256SUMS'}
        assert all(sha(z.read(n)) == h for n, h in inner.items())
        print(f'  {p}: {len(inner)}/{len(inner)} inner OK ({len(z.namelist())} entries)')
    if p.endswith('evidence.zip'):
        man = os.path.join(d, os.path.dirname(p), 'evidence-SHA256SUMS')
        if os.path.exists(man):
            z = zipfile.ZipFile(os.path.join(d, p))
            m = {l.split('  ', 1)[1]: l.split('  ', 1)[0] for l in open(man).read().splitlines() if l.strip()}
            files = {n for n in z.namelist() if not n.endswith('/')}
            assert files - {'SHA256SUMS'} == set(m), sorted(files ^ set(m))[:5]
            assert all(sha(z.read(n)) == h for n, h in m.items())
            print(f'  {p}: {len(m)}/{len(m)} against its manifest')
