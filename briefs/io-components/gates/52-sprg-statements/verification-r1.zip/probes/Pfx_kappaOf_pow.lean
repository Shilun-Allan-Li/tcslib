/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.Obfuscation.StructuredSeed.Defs
import TCSlib.Cryptography.Obfuscation.StructuredSeed.LPN
import TCSlib.Cryptography.Asymptotic.UniversalPadding.Parameter
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Log
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Logic.Equiv.Fin.Basic
import Mathlib.Algebra.BigOperators.Fin

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Rational parameters and dimensions of the JLS construction

## Main definitions

* `Params`: rational noise exponent, fixed degree/schedule, and efficient Boolean PRG.
* Rounded dimensions, inverse parameter maps, and explicit public/private coordinates.
* `Params.lpnFamily_raw`: the construction's dimension-indexed exact LPN family.

## Main results

* Inverse-schedule identities and eventual parameter side conditions.
* Every algorithm takes a public prime; Params contains no prime schedule.

## References

* [JLS26] A. Jain, H. Lin, A. Sahai, *Indistinguishability Obfuscation from
  Well-Founded Assumptions*, J. ACM 73(1), Article 1, February 2026, §§2-4.
* [PS10] R. Pass, a. shelat, *A Course in Cryptography*, lecture notes,
  3rd ed., January 2010, Definition 26.8 (non-uniform PPT adversaries).
-/

namespace TCSlib.Cryptography.Obfuscation.StructuredSeed

open Complexity

/-- The construction fixes degree, rational noise exponent, polynomial schedule
exponent, and an efficient Boolean PRG [JLS26, Theorem 4.1, p. 11; §4, p. 15].
Dv9: no prime is stored. SP-W1: δ is rational data, per the user's ruling,
so the exact rounded noise schedule can have a uniform implementation.
Dv11 requires positive degree, and Dv4 carries the multilinear representation. -/
structure Params where
  d : ℕ
  one_le_d : 1 ≤ d
  δ : ℚ
  δ_pos : 0 < δ
  δ_lt_one : δ < 1
  E : ℕ
  one_le_E : 1 ≤ E
  G : BoolPRG
  R : G.MultilinearRep d

namespace Params

/-- Half-degree is `D = (d+1)/2` [JLS26, §4, p. 15]. Dv11 ensures D>0. -/
def D (P : Params) : ℕ := (P.d + 1) / 2

/-- Half-degree equals (d+1)/2; glue. -/
theorem D_eq (P : Params) : P.D = (P.d + 1) / 2 := rfl

/-- LPN dimension is `ℓ(κ)=κ^E` [JLS26, §4, p. 15]. Dv1 fixes a polynomial schedule. -/
def ℓ (P : Params) (κ : ℕ) : ℕ := κ ^ P.E

/-- The LPN dimension equals κ^E; glue. -/
theorem ℓ_eq (P : Params) (κ : ℕ) : P.ℓ κ = κ ^ P.E := rfl

/-- Boolean seed length is `n=ℓ^D` [JLS26, §4, p. 15]. Dv1 makes this an exact power. -/
def n (P : Params) (κ : ℕ) : ℕ := P.ℓ κ ^ P.D

/-- The Boolean seed length is ℓ^D; glue. -/
theorem n_eq (P : Params) (κ : ℕ) : P.n κ = P.ℓ κ ^ P.D := rfl

/-- Output length is the underlying generator's `m=G.outLen(n)`
[JLS26, §4, p. 15]. Dv5 uses a stretch lower bound rather than exact equality. -/
def m (P : Params) (κ : ℕ) : ℕ := P.G.outLen (P.n κ)

/-- Output length reads the generator's schedule; glue. -/
theorem m_eq (P : Params) (κ : ℕ) : P.m κ = P.G.outLen (P.n κ) := rfl

/-- The rounded square-root noise denominator is max 1 floor(L^(δ/2))
[JLS26, §4, p. 15]. Dv3 rounds in the noisier direction; SP-W1 uses rational δ. -/
noncomputable def noiseWidth (P : Params) (L : ℕ) : ℕ :=
  max 1 ⌊(L : ℝ) ^ ((P.δ : ℝ) / 2)⌋₊

/-- The rounded noise width is the stated real-power floor; glue. -/
theorem noiseWidth_eq (P : Params) (L : ℕ) :
    P.noiseWidth L = max 1 ⌊(L : ℝ) ^ ((P.δ : ℝ) / 2)⌋₊ := rfl

/-- The exact LPN denominator at dimension L is noiseWidth(L)^2
[JLS26, Definition 2.3, pp. 9-10]. Dv3 uses the rounded rational rate 1/W. -/
noncomputable def noiseDenAt (P : Params) (L : ℕ) : ℕ := P.noiseWidth L ^ 2

/-- The noise denominator is the square of noiseWidth; glue. -/
theorem noiseDenAt_eq (P : Params) (L : ℕ) : P.noiseDenAt L = P.noiseWidth L ^ 2 := rfl

/-- At κ, `w=noiseWidth(ℓ κ)` [JLS26, §4, p. 15]. Dv3 and SP-W1 fix rounding. -/
noncomputable def w (P : Params) (κ : ℕ) : ℕ := P.noiseWidth (P.ℓ κ)

/-- The construction's noise width is indexed by ℓ; glue. -/
theorem w_eq (P : Params) (κ : ℕ) : P.w κ = P.noiseWidth (P.ℓ κ) := rfl

/-- The noise denominator is `W=w^2` [JLS26, §4, p. 15]. Dv3 rounds the rate to 1/W. -/
noncomputable def W (P : Params) (κ : ℕ) : ℕ := P.w κ ^ 2

/-- W is the square of w; glue. -/
theorem W_eq (P : Params) (κ : ℕ) : P.W κ = P.w κ ^ 2 := rfl

/-- The two descriptions of W agree at ℓ(κ); glue. -/
theorem W_eq_noiseDenAt (P : Params) (κ : ℕ) : P.W κ = P.noiseDenAt (P.ℓ κ) := rfl

/-- Slack is `t=κ` [JLS26, §4, p. 15]. -/
def t (_P : Params) (κ : ℕ) : ℕ := κ

/-- Slack equals κ; glue. -/
theorem t_eq (P : Params) (κ : ℕ) : P.t κ = κ := rfl

/-- Grid side is `rc=t*w` [JLS26, §4, p. 15]. Dv3 makes capacity an exact square. -/
noncomputable def rc (P : Params) (κ : ℕ) : ℕ := P.t κ * P.w κ

/-- The grid side is t*w; glue. -/
theorem rc_eq (P : Params) (κ : ℕ) : P.rc κ = P.t κ * P.w κ := rfl

/-- Bucket capacity is `cap=rc^2` [JLS26, §4, p. 15]. Dv3 fixes integral rounding. -/
noncomputable def cap (P : Params) (κ : ℕ) : ℕ := P.rc κ ^ 2

/-- Capacity is the squared grid side; glue. -/
theorem cap_eq (P : Params) (κ : ℕ) : P.cap κ = P.rc κ ^ 2 := rfl

/-- Bucket count is max 1 ceil(m*t/W) [JLS26, §4, p. 15]. Dv3 keeps the draw inhabited. -/
noncomputable def B (P : Params) (κ : ℕ) : ℕ :=
  max 1 ((P.m κ * P.t κ + P.W κ - 1) / P.W κ)

/-- Bucket count is the positive rounded quotient; glue. -/
theorem B_eq (P : Params) (κ : ℕ) :
    P.B κ = max 1 ((P.m κ * P.t κ + P.W κ - 1) / P.W κ) := rfl

/-- Bad-output threshold is floor(m*log₂(n)/W) [JLS26, §4, p. 15]. Dv3 fixes the floor. -/
noncomputable def Γ (P : Params) (κ : ℕ) : ℕ :=
  P.m κ * Nat.log 2 (P.n κ) / P.W κ

/-- The bad-output threshold is the integer quotient; glue. -/
theorem Γ_eq (P : Params) (κ : ℕ) :
    P.Γ κ = P.m κ * Nat.log 2 (P.n κ) / P.W κ := rfl

/-- The inverse LPN schedule is the greatest κ with κ^E≤L [JLS26, Remark 2.1, p. 9].
Dv1 and Dv3 reindex the fixed LPN family by its own secret dimension. -/
def kappaOf (P : Params) (L : ℕ) : ℕ :=
  Nat.findGreatest (fun κ => κ ^ P.E ≤ L) L

/-- The LPN inverse is a bounded greatest search; glue. -/
theorem kappaOf_eq (P : Params) (L : ℕ) :
    P.kappaOf L = Nat.findGreatest (fun κ => κ ^ P.E ≤ L) L := rfl

/-- The inverse Boolean schedule uses exponent E*D [JLS26, Remark 2.1, p. 9].
Dv1 reindexes the Boolean assumption by its seed length. -/
def kappaOfN (P : Params) (N : ℕ) : ℕ :=
  Nat.findGreatest (fun κ => κ ^ (P.E * P.D) ≤ N) N

/-- The Boolean inverse is a bounded greatest search; glue. -/
theorem kappaOfN_eq (P : Params) (N : ℕ) :
    P.kappaOfN N = Nat.findGreatest (fun κ => κ ^ (P.E * P.D) ≤ N) N := rfl

/-- The public seed contains κ blocks of n residues and one error flag
[JLS26, SdSamp', pp. 15-16]. Dv2 counts field elements before their bit widths. -/
def pubLen (P : Params) (κ : ℕ) : ℕ := κ * P.n κ + 1

/-- Public length is κ*n+1; glue. -/
theorem pubLen_eq (P : Params) (κ : ℕ) : P.pubLen κ = κ * P.n κ + 1 := rfl

/-- One instance's private coordinates are tensor, U and V positions
[JLS26, Equation (2), p. 16]. Dv15 retains explicit finite coordinate types. -/
abbrev SVar (P : Params) (κ : ℕ) : Type :=
  (Fin P.D → Fin (P.ℓ κ + 1)) ⊕
    (Fin (P.B κ) × ((Fin (P.rc κ) × Fin (P.t κ)) ⊕ (Fin (P.t κ) × Fin (P.rc κ))))

/-- The private-coordinate type is the tensor/factor sum; glue. -/
theorem SVar_eq (P : Params) (κ : ℕ) : P.SVar κ =
    ((Fin P.D → Fin (P.ℓ κ + 1)) ⊕
      (Fin (P.B κ) × ((Fin (P.rc κ) × Fin (P.t κ)) ⊕
        (Fin (P.t κ) × Fin (P.rc κ))))) := rfl

/-- One private instance has (ℓ+1)^D+ B*(rc*t+t*rc) coordinates
[JLS26, Equation (2), p. 16]. Dv2 uses integral dimensions. -/
noncomputable def sLen (P : Params) (κ : ℕ) : ℕ :=
  (P.ℓ κ + 1) ^ P.D + P.B κ * (P.rc κ * P.t κ + P.t κ * P.rc κ)

/-- The instance-private length is the explicit dimension formula; glue. -/
theorem sLen_eq (P : Params) (κ : ℕ) : P.sLen κ =
    (P.ℓ κ + 1) ^ P.D + P.B κ * (P.rc κ * P.t κ + P.t κ * P.rc κ) := rfl

/-- Structured private variables are κ copies of flag, S and flag*S
[JLS26, SdSamp', p. 16]. Dv15 transports these coordinates explicitly to Fin. -/
abbrev Priv (P : Params) (κ : ℕ) : Type :=
  Fin κ × (Unit ⊕ (P.SVar κ ⊕ P.SVar κ))

/-- The structured-private type has three components per repetition; glue. -/
theorem priv_eq (P : Params) (κ : ℕ) :
    P.Priv κ = (Fin κ × (Unit ⊕ (P.SVar κ ⊕ P.SVar κ))) := rfl

/-- Private length is κ*(1+2*sLen) [JLS26, SdSamp', p. 16]. Dv2 counts residues. -/
noncomputable def privLen (P : Params) (κ : ℕ) : ℕ := κ * (1 + (P.sLen κ + P.sLen κ))

/-- Private length is the explicit flag/two-copy formula; glue. -/
theorem privLen_eq (P : Params) (κ : ℕ) :
    P.privLen κ = κ * (1 + (P.sLen κ + P.sLen κ)) := rfl

/-- The tensor/factor coordinate enumeration is explicit [JLS26, Equation (2), p. 16].
Dv15 uses only the published Fin sum, product and function equivalences. -/
noncomputable def sVarEquiv (P : Params) (κ : ℕ) : P.SVar κ ≃ Fin (P.sLen κ) :=
  (Equiv.sumCongr finFunctionFinEquiv
    ((Equiv.prodCongr (Equiv.refl _)
      ((Equiv.sumCongr finProdFinEquiv finProdFinEquiv).trans finSumFinEquiv)).trans
        finProdFinEquiv)).trans finSumFinEquiv

/-- The private-coordinate enumeration is its stated composition; glue. -/
theorem sVarEquiv_eq (P : Params) (κ : ℕ) : P.sVarEquiv κ =
    (Equiv.sumCongr finFunctionFinEquiv
      ((Equiv.prodCongr (Equiv.refl _)
        ((Equiv.sumCongr finProdFinEquiv finProdFinEquiv).trans finSumFinEquiv)).trans
          finProdFinEquiv)).trans finSumFinEquiv := rfl

/-- The complete private-variable enumeration uses the same explicit equivalences
[JLS26, SdSamp', p. 16]. Dv15 adds no classical enumeration. -/
noncomputable def privEquiv (P : Params) (κ : ℕ) : P.Priv κ ≃ Fin (P.privLen κ) :=
  (Equiv.prodCongr (Equiv.refl _)
    ((Equiv.sumCongr finOneEquiv.symm
      ((Equiv.sumCongr (P.sVarEquiv κ) (P.sVarEquiv κ)).trans finSumFinEquiv)).trans
        finSumFinEquiv)).trans finProdFinEquiv

/-- The complete-private enumeration is its stated composition; glue. -/
theorem privEquiv_eq (P : Params) (κ : ℕ) : P.privEquiv κ =
    (Equiv.prodCongr (Equiv.refl _)
      ((Equiv.sumCongr finOneEquiv.symm
        ((Equiv.sumCongr (P.sVarEquiv κ) (P.sVarEquiv κ)).trans finSumFinEquiv)).trans
          finSumFinEquiv)).trans finProdFinEquiv := rfl

/-- Structured public variables are the repeated n-vectors and the error flag
[JLS26, SdSamp', p. 16]. Dv15 provides a fixed coordinate enumeration. -/
abbrev Pub (P : Params) (κ : ℕ) : Type := (Fin κ × Fin (P.n κ)) ⊕ Unit

/-- The structured public type is a vector-block sum with one flag; glue. -/
theorem pub_eq (P : Params) (κ : ℕ) :
    P.Pub κ = ((Fin κ × Fin (P.n κ)) ⊕ Unit) := rfl

/-- The public-variable enumeration splits repeated blocks from the flag
[JLS26, SdSamp', p. 16]. Dv15 uses explicit Fin equivalences. -/
def pubEquiv (P : Params) (κ : ℕ) : P.Pub κ ≃ Fin (P.pubLen κ) :=
  (Equiv.sumCongr finProdFinEquiv finOneEquiv.symm).trans finSumFinEquiv

/-- The public enumeration is its explicit sum/product composition; glue. -/
theorem pubEquiv_eq (P : Params) (κ : ℕ) : P.pubEquiv κ =
    (Equiv.sumCongr finProdFinEquiv finOneEquiv.symm).trans finSumFinEquiv := rfl

/-- The construction index contains I, bucket placement and the LPN matrix
[JLS26, IdSamp', p. 15]. Dv3 transposes A, and Dv15 derives grid positions. -/
abbrev Idx' (P : Params) (κ : ℕ) (pp : PrimeParam κ) : Type :=
  P.G.Idx (P.n κ) × ((Fin (P.m κ) → Fin (P.B κ)) ×
    Matrix (Fin (P.n κ)) (Fin (P.ℓ κ)) (ZMod pp.p))

/-- The construction index is the stated triple; glue. -/
theorem idx'_eq (P : Params) (κ : ℕ) (pp : PrimeParam κ) : P.Idx' κ pp =
    (P.G.Idx (P.n κ) × ((Fin (P.m κ) → Fin (P.B κ)) ×
      Matrix (Fin (P.n κ)) (Fin (P.ℓ κ)) (ZMod pp.p))) := rfl

/-- Half-degree is positive [JLS26, §4, p. 15]. Dv11 assumes d≥1.

**Proof sketch.** Divide the inequality d+1≥2 by two. -/
theorem D_pos (P : Params) : 0 < P.D := sorry

/-- Noise width is positive at every dimension [JLS26, §4, p. 15]. Dv3 uses max 1.

**Proof sketch.** The maximum dominates one. -/
theorem noiseWidth_pos (P : Params) (L : ℕ) : 0 < P.noiseWidth L := sorry

/-- The scalar denominator is positive [JLS26, §4, p. 15]. Dv3 squares a positive width.

**Proof sketch.** Use noiseWidth positivity and positivity of its square. -/
theorem noiseDenAt_pos (P : Params) (L : ℕ) : 0 < P.noiseDenAt L := sorry

/-- W is positive at every κ [JLS26, §4, p. 15]. Dv3 keeps noise seeds nonempty.

**Proof sketch.** Use the width lower bound and the square formula. -/
theorem W_pos (P : Params) (κ : ℕ) : 0 < P.W κ := sorry

/-- Bucket count is positive at every κ [JLS26, §4, p. 15]. Dv3 uses max 1.

**Proof sketch.** The maximum dominates one. -/
theorem B_pos (P : Params) (κ : ℕ) : 0 < P.B κ := sorry

instance instWNeZero (P : Params) (κ : ℕ) : NeZero (P.W κ) := ⟨Nat.ne_of_gt (P.W_pos κ)⟩
instance instBNeZero (P : Params) (κ : ℕ) : NeZero (P.B κ) := ⟨Nat.ne_of_gt (P.B_pos κ)⟩


-- io-c0 probe: the signature of `kappaOf_pow`, with `kappaOf_pow` itself not yet declared
example (P : Params) (κ : ℕ) : P.kappaOf (P.ℓ κ) = κ := by
  exact?
