import TCSlib.Cryptography.Obfuscation

/-! io-c0 Gate 52 probe: headline statements (`#check`/`#print`) and their axioms. Scratch only. -/

open TCSlib.Cryptography.Obfuscation.StructuredSeed

-- Def 3.1 / 3.2 (syntax, game, security)
#check @SPRG.Raw
#check @SPRG
#check @SPRG.Raw.game
#check @SPRG.Raw.Secure
#check @SPRG.Raw.SubexpSecure
#print SPRG.Raw.HasPolyStretch
-- Def 3.3 (complexity), Q-S4 composite form and its efficient variant
#print SPRG.Raw.HasComplexity
#print SPRG.Raw.HasComplexityEff
#check @SPRG.Raw.HasComplexityEff.hasComplexity
#print SPRG.HasComplexity
#print SPRG.HasComplexityEff
-- Def 3.4 (Boolean PRG) and Def 2.3 (LPN)
#check @BoolPRG
#check @BoolPRG.Secure
#check @BoolPRG.MultilinearRep
#check @LPNFamily.Raw.Assumption
#check @lpnNoise_law
-- Claim 4.1 / Claim 4.2 / Lemma 4.2 / Prop 4.1
#check @jls_hasPolyStretch
#check @Params.claim42
#check @lemma42
#check @prop41
-- Theorem 4.1 (raw, subexponential, existence, conditional on targets)
#check @jls_hasComplexity
#check @jls_secure
#check @jls_subexpSmall
#check @jls_subexpSecure
#check @theorem41
#check @theorem41_subexp
#check @exists_sprg_raw
#check @exists_sprg_raw_subexp
#check @theorem41_of_targets
#check @exists_sprg_of_targets
#check @exists_sprg_of_targets_subexp
#check @jlsSPRG
#print Params.Targets
-- Axioms of the REPORT's 19 headline prints (+ lemma42, G4_degrees)
#print axioms prop41
#print axioms Params.claim42
#print axioms Params.G4_eval_eq
#print axioms jls_hasComplexity
#print axioms jls_hasPolyStretch
#print axioms lpnNoise_law
#print axioms jls_secure
#print axioms jls_subexpSmall
#print axioms jls_subexpSecure
#print axioms theorem41
#print axioms theorem41_subexp
#print axioms exists_sprg_raw
#print axioms exists_sprg_raw_subexp
#print axioms PrimeSchedule.nonempty
#print axioms Params.realizable_of_targets
#print axioms jlsSPRG
#print axioms theorem41_of_targets
#print axioms exists_sprg_of_targets
#print axioms exists_sprg_of_targets_subexp
#print axioms lemma42
#print axioms Params.G4_degrees

-- control: a fresh sorry must report sorryAx
theorem ioc0SorryControl : (1 : ℕ) = 2 := sorry
#print axioms ioc0SorryControl
