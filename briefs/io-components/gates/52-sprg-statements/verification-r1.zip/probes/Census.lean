import TCSlib.Cryptography.Obfuscation
import Lean

/-! io-c0 Gate 52 probe: axiom census of every constant stored by the 22 new modules. -/

open Lean Elab Command Meta

namespace IOC0Census

def newMods : Array Name := #[
  `TCSlib.Cryptography.Obfuscation,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.BoolPRG,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Buckets,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Claim42,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Claim42.Load,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Correctness,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Defs,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Degree,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Encoding,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Hybrids,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.LPN,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Params,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.PolyTerms,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Polys,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Reductions.LPN,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Reductions.PRG,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Samplers,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Security,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.SparseFactor,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Stretch,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Targets]

end IOC0Census

open Lean Elab Command Meta in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods := IOC0Census.newMods
  let present := mods.filter fun m => env.header.moduleNames.contains m
  let mut out : Array String := #[s!"MODULES {present.size} of {mods.size}"]
  let std : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut n := 0
  for (c, ci) in env.constants.map₁.toList do
    let some idx := env.getModuleIdxFor? c | continue
    let mn := env.header.moduleNames[idx.toNat]!
    unless mods.contains mn do continue
    n := n + 1
    let axs ← collectAxioms c
    let kind := match ci with
      | .thmInfo _ => "thm" | .defnInfo _ => "def" | .axiomInfo _ => "axiom"
      | .inductInfo _ => "induct" | .ctorInfo _ => "ctor" | .recInfo _ => "rec"
      | .opaqueInfo _ => "opaque" | .quotInfo _ => "quot"
    let priv := isPrivateName c
    let internal := c.isInternal
    let aux := isAuxRecursor env c || isNoConfusion env c || (Meta.isMatcherCore env c) ||
      (match ci with | .recInfo _ => true | _ => false)
    let ranged := (← findDeclarationRangesCore? c).isSome
    let direct := ci.getUsedConstantsAsSet.contains ``sorryAx
    let nonstd := axs.filter fun a => !(std.contains a) && a != ``sorryAx
    let axStr := ",".intercalate ((axs.qsort (·.toString < ·.toString)).toList.map toString)
    out := out.push s!"ROW\t{c}\t{mn}\t{kind}\t{priv}\t{internal}\t{aux}\t{ranged}\t{direct}\t{nonstd.size}\t{axStr}"
  out := out.push s!"TOTAL {n}"
  logInfo (String.intercalate "\n" out.toList)
