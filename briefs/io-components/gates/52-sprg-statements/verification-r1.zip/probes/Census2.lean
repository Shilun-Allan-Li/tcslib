import TCSlib.Cryptography.Obfuscation
import Lean

/-! io-c0 Gate 52 probe: axiom census of every constant stored by the 22 new modules. -/

open Lean Elab Command Meta

namespace IOC0Census

def newMods : Array Name := #[
  `TCSlib.Cryptography.Obfuscation,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.BoolPRG,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Buckets,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Claim42,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Claim42.Load,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Correctness,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Defs,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Degree,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Encoding,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Hybrids,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.LPN,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Params,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.PolyTerms,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Polys,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Reductions.LPN,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Reductions.PRG,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Samplers,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Security,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.SparseFactor,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Stretch,
  `TCSlib.Cryptography.Obfuscation.StructuredSeed.Targets]

end IOC0Census

/-- io-c0: memoized axiom collection mirroring `Lean.CollectAxioms.collect` (same edges per constant kind).
Results are memoized only when no strictly-earlier on-stack constant was reached (Tarjan-style low link),
so cyclic (inductive/constructor) dependencies never memoize a partial set. -/
partial def IOC0Census.axGo (env : Lean.Environment) (depth : Nat) (c : Lean.Name) :
    StateM (Std.HashMap Lean.Name (Array Lean.Name) × Std.HashMap Lean.Name Nat)
      (Array Lean.Name × Nat) := do
  let inf := 1000000000
  let (memo, onStack) ← get
  if let some s := memo[c]? then return (s, inf)
  if let some d := onStack[c]? then return (#[], d)
  modify fun (m, st) => (m, st.insert c depth)
  let mut acc : Array Lean.Name := #[]
  let mut low := inf
  let deps : Array Lean.Name := match env.find? c with
    | some (.axiomInfo v) => v.type.getUsedConstants
    | some (.defnInfo v) => v.type.getUsedConstants ++ v.value.getUsedConstants
    | some (.thmInfo v) => v.type.getUsedConstants ++ v.value.getUsedConstants
    | some (.opaqueInfo v) => v.type.getUsedConstants ++ v.value.getUsedConstants
    | some (.quotInfo _) => #[]
    | some (.ctorInfo v) => v.type.getUsedConstants
    | some (.recInfo v) => v.type.getUsedConstants
    | some (.inductInfo v) => v.type.getUsedConstants ++ v.ctors.toArray
    | none => #[]
  if let some (.axiomInfo _) := env.find? c then acc := acc.push c
  for d in deps do
    let (s, l) ← IOC0Census.axGo env (depth + 1) d
    for a in s do
      unless acc.contains a do acc := acc.push a
    low := min low l
  modify fun (m, st) => (m, st.erase c)
  if low ≥ depth then modify fun (m, st) => (m.insert c acc, st)
  return (acc, low)

open Lean Elab Command Meta in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods := IOC0Census.newMods
  let present := mods.filter fun m => env.header.moduleNames.contains m
  let mut out : Array String := #[s!"MODULES {present.size} of {mods.size}"]
  let std : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut n := 0
  let mut st : Std.HashMap Name (Array Name) × Std.HashMap Name Nat := ({}, {})
  for (c, ci) in env.constants.map₁.toList do
    let some idx := env.getModuleIdxFor? c | continue
    let mn := env.header.moduleNames[idx.toNat]!
    unless mods.contains mn do continue
    n := n + 1
    let ((axs, _), st') := (IOC0Census.axGo env 0 c).run st
    st := st'
    let kind := match ci with
      | .thmInfo _ => "thm" | .defnInfo _ => "def" | .axiomInfo _ => "axiom"
      | .inductInfo _ => "induct" | .ctorInfo _ => "ctor" | .recInfo _ => "rec"
      | .opaqueInfo _ => "opaque" | .quotInfo _ => "quot"
    let priv := isPrivateName c
    let internal := c.isInternal
    let aux := isAuxRecursor env c || isNoConfusion env c || (Meta.isMatcherCore env c) ||
      (match ci with | .recInfo _ => true | _ => false)
    let ranged := (← findDeclarationRangesCore? c).isSome
    let direct := ci.getUsedConstantsAsSet.contains ``sorryAx
    let nonstd := axs.filter fun a => !(std.contains a) && a != ``sorryAx
    let axStr := ",".intercalate ((axs.qsort (·.toString < ·.toString)).toList.map toString)
    out := out.push s!"ROW\t{c}\t{mn}\t{kind}\t{priv}\t{internal}\t{aux}\t{ranged}\t{direct}\t{nonstd.size}\t{axStr}"
  out := out.push s!"TOTAL {n}"
  logInfo (String.intercalate "\n" out.toList)
