import TCSlib.Cryptography.Obfuscation

/-! io-c0 Gate 52 probe: duplication (G52-03 kappaOf/kappaOfN vs PadQuad.nu; G52-04 equivalence families).
Scratch only; every probe is an `example`. -/

open TCSlib.Cryptography TCSlib.Cryptography.Obfuscation.StructuredSeed

-- G52-03 (a): the two inverses ARE `PadQuad.nu` definitionally (same body).
example (P : Params) (L : ℕ) : P.kappaOf L = PadQuad.nu P.E L := rfl
example (P : Params) (N : ℕ) : P.kappaOfN N = PadQuad.nu (P.E * P.D) N := rfl
-- G52-03 (b): the sorry'd readers follow from the public PadQuad API by a term (no new proof).
example (P : Params) (L : ℕ) : P.kappaOf L ≤ L := PadQuad.nu_le P.E L
example (P : Params) (N : ℕ) : P.kappaOfN N ≤ N := PadQuad.nu_le (P.E * P.D) N
example (P : Params) (L : ℕ) : P.kappaOf L ^ P.E ≤ L := PadQuad.nu_pow_le P.one_le_E L
example (P : Params) (κ : ℕ) : κ ≤ P.kappaOf (P.ℓ κ) := PadQuad.le_nu P.one_le_E le_rfl
example (P : Params) (κ : ℕ) : P.kappaOf (P.ℓ κ) = κ :=
  le_antisymm
    ((Nat.pow_le_pow_iff_left (by have := P.one_le_E; omega)).mp
      (PadQuad.nu_pow_le P.one_le_E (P.ℓ κ)))
    (PadQuad.le_nu P.one_le_E le_rfl)
-- G52-03 (c): what `exact?` finds for the unfolded reader goal (the folded goal is probed in Pfx_*.lean).
example (P : Params) (L : ℕ) : Nat.findGreatest (fun κ => κ ^ P.E ≤ L) L ≤ L := by exact?

-- G52-04: on the construction's own LPN family, each LPN-side equivalence is the
-- Encoding-side one by `rfl` (the two families are the same terms at the shared modulus).
example (P : Params) (π : PrimeSchedule) (L : ℕ) :
    (P.lpnFamily_raw π).residueEquiv L = ConstructionEncoding.residueEquiv (π (P.kappaOf L)) := rfl
example (P : Params) (π : PrimeSchedule) (L n : ℕ) :
    (P.lpnFamily_raw π).vectorEquiv L n = ConstructionEncoding.vectorEquiv (π (P.kappaOf L)) n := rfl
example (P : Params) (π : PrimeSchedule) (L : ℕ) :
    (P.lpnFamily_raw π).matrixEquiv L =
      ConstructionEncoding.matrixEquiv (π (P.kappaOf L)) ((P.lpnFamily_raw π).samples L) L := rfl
example (P : Params) (π : PrimeSchedule) (L : ℕ) :
    (P.lpnFamily_raw π).noiseSeedEquiv L =
      ConstructionEncoding.noiseSeedEquiv (π (P.kappaOf L)) ((P.lpnFamily_raw π).noiseDen L) := rfl
example (P : Params) (π : PrimeSchedule) (L : ℕ) :
    (P.lpnFamily_raw π).noiseVectorEquiv L =
      ConstructionEncoding.noiseVectorEquiv (π (P.kappaOf L)) ((P.lpnFamily_raw π).noiseDen L)
        ((P.lpnFamily_raw π).samples L) := rfl
-- G52-04: is there a ready-made generic equivalence in the imported environment?
example (q n : ℕ) : (Fin n → Fin q) ≃ Fin (q ^ n) := by exact?
example (q n : ℕ) [NeZero q] : (Fin n → ZMod q) ≃ Fin (q ^ n) := by exact?
