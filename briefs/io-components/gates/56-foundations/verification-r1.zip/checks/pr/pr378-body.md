The sampler bridge of the iO-components campaign (`IOComponentsPlan.md`; design `briefs/io-components/sampler-bridge/design-r1.md`; Seyoon's rulings, records `1a9a3295`). It lets algorithms stated with exact non-dyadic laws, such as uniform ℤ_p for prime p or LWE/LPN noise, be run from fair coins while **keeping perfect correctness**. Stacked on #374.

**Head:** `3473adda66d9c61c51ba640ed4c701e5cde0b6b1` (10 SSH-signed commits on `cbce64d1`; 10 files). The original delivery was `51dc7672` (9 commits, +1877); the landing edit below adds one commit.

## Modules
- `Games/Closeness.lean`: `ProbComp.Close ε`, closeness on every [0,1]-valued test. It is preserved by sequencing, and an m-query oracle simulation costs m·ε (needs `0 ≤ ε`). `advantage_le_of_close` sums the failure terms in any game.
- `CoinSampling/Basic.lean`: `CoinSampler Ω s`, which decodes s coins to `Option Ω` (`none` = give up), exact on success; the exact mixture identity; `pi`/`prod` decoders.
- `CoinSampling/Buckets.lean`: `bucket N s`, one trial below ⌊2^s/N⌋·N, then `x mod N` [Lem19, §3.2, Alg. 4, one-round variant]. Failure is exactly (2^s mod N)/2^s < N/2^s. Also weighted buckets for rational laws.
- `CoinSampling/Transfer.lean`: `OutputsSubset`. With a default-value fallback, every output of the coin version is an output of the exact version, so every `AllOutputs` property transfers without re-proof; branch fallbacks via `allOutputs_draw_bind`.
- `CoinSampling/Asymptotic.lean`: `drawSlack q t = q(κ)·2^(−t(κ))`, which is negligible, and `SubexpSmall` for every c < 1 when t ≥ κ (#374's API).
- `CoinSampling/Instances.lean`: `zmod q` for every modulus (not only powers of 2), LWE noise seeds, and LWE challenge-transfer lemmas.
- `CoinSampling/Efficiency.lean`: `UniformSampler`, one `PolyTimeComputable` map that reads the modulus from its input, built only from proved `BinArith` mod/sub/lt and the `toLE`/`fromLEPoly` adapters. It gives `NUPPT.ofPolyTimeUniform` machines: no advice, no κ-indexed programs, no hard-wired modulus.

## Checks (maintainer, on a `cp -al` copy of olean snapshot #10)
- Every module and root `TCSlib.lean`: `lean_check_tree.sh` rc 0, 0 errors, 0 warnings, no `sorry`. The snapshot verifies 0/0/0.
- Axioms: `collectAxioms` over every declaration of all 7 modules finds only `propext`, `Classical.choice` and `Quot.sound`, the efficiency layer included. A control flags `sorryAx` on `Turing.FinTM.lengthBitsTM_computes`.
- `style_lint`: 0 findings on the new files. Every line is ≤ 100 characters.
- Non-vacuity: `zmod 3 4` outputs each residue with probability 5/16 and fails with probability exactly 1/16.

## Reuse and disclosed overlaps
Reuses `uniformFromBits`, `rejectionSample`, the `StatClose` API, `OneWay.statClose_pi`, the Games `expect`/`AllOutputs`/`simulate`, `Negligible.polyExpr_mul`, `SubexpSmall.*`, `BinArith`, `NumberTheory.bitsToNat_eq_listToNat`, and Mathlib's `finProdFinEquiv`, `ZMod.finEquiv` and `Nat.count_modEq_card`.

Disclosed overlaps:
- the mixture identity versus the step inside `statClose_getD_of_uniform_of_some`. Follow-up after cleanup S2-A: move the identity into `Asymptotic/Sampling.lean` and re-derive the old lemma from it, proof-only;
- `uprob_apply_coord`;
- `polyExpr_eval_le_mul_pow`;
- three private `rfl` readers for `BinArith.lt/sub/mod`, since `ClassP/BinaryArith` publishes no equation lemmas. They read the Complexity owner's definitions, so `Efficiency.lean`'s canonical coe-A seal has exactly these 3 errors. This is recorded as bounded debt (ledger DL-70); the public readers go into the Complexity owner PR, after which these private readers are re-pointed.

`Asymptotic/Sampling.lean`, which is in Stage 2's scope, is not touched.

Full report: `briefs/io-components/sampler-bridge/IMPL-REPORT.md`.

## Landing edit (2026-11-19; Q-L2-1 (b), under the reader ruling EF-W1-R (A))
Commit `3473adda` adds three `rfl` readers beside `bucketSampler` in `CoinSampling/Efficiency.lean`:
- `bucketSampler_Ω : bucketSampler.Ω y = Fin ⟦y⟧`;
- `bucketSampler_enc_cast`, the encoding of an `Ω`-typed draw;
- `bucketSampler_fail`, the failure at `Fin ⟦y⟧`.

With them, consumers such as #384's `drawSamplable_residue` read the bucket sampler through published readers rather than through its definition (Rule 10). decls2: 3 added. The owner and its downstream rebuild with rc 0, and the paired controls (3 NEG, 3 POS) are exact. Records: `briefs/efficiency-gaps/wave1/EF-D1/final-r1/landing-r2.md`.

## Gate
Audited by a Codex gate (to be staged). Seyoon merges after #374.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA
