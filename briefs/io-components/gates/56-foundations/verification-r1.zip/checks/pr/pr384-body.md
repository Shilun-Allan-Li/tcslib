The shared sampler-efficiency contract of the iO-components campaign and the efficiency remediation (`IOComponentsPlan.md`, ruling Q-E1 (A); wave-1 ruling Q-W1-1 (A)). Standing rule 15 requires every primitive's definition to carry its honest algorithms' efficiency. This file gives the one predicate those definitions use for samplers. Stacked on #378.

**Head:** `40e12f64293833056e311ab7aaf5a62fb3006353` on #378's `3473adda`. The original delivery was one SSH-signed commit, `8e01b720`, adding `TCSlib/Cryptography/CoinSampling/Contract.lean` (373 lines) plus one import line and one Contents bullet in the `CoinSampling` facade. The landing edits below add three commits.

## Content (`namespace TCSlib.Cryptography.CoinSampling`)
- `DrawSamplable y encDraw`: a #378 `UniformSampler` with an explicit equivalence to the draw type, failure probability ≤ 2^−κ at a polynomial coin count, and the parameter word `y` on the input.
- `CoreComputable y encDraw encOut core`: a `PolyTimeComputable` map computing the deterministic core on the encoded draw.
- `SamplesEfficiently := DrawSamplable ∧ CoreComputable`.
- **Honest samplers only, uniform** [PS10, Def 23.4]: no advice, no κ-indexed program, no hard-wired modulus. The law stays the exact `core <$> sample Draw`.
- Readers: the `_iff`s, `samplesEfficiently_iff_exists`, the projections and `.intro`.
- Closure: `coreComputable_id`, `.map`, `.map_output`, `.pair` and `.congr`.
- Non-vacuity: uniform `ZMod q`, with q given on the input, via `bucketSampler`.
- Disclosed limits:
  - There is no product-of-draws sampler. A `UniformSampler` fixes its sampler from the coin count alone, so a product needs a concrete product sampler with a coin splitter.
  - An unused `Fintype` binder was dropped.

## Landing edits (2026-11-19)
- **`f96ae32e`** (rulings EF-D1-W2 (B) and EF-H11-R5 (A), ledger DL-66) adds to `Contract.lean` the sampler helpers that #387 (EF-D1) and EF-H11 had each stated locally:
  - `DrawSamplable.comap` (new) and `samplesEfficiently_comap` (EF-H11's) reindex a sampler along a map of public inputs;
  - `drawSamplable_restrict` (EF-D1's) is now derived from `comap`;
  - `natToList_two_pow`, `polyTimeComputable_twoPowWord` and `seedModulusWord` with four readers (EF-D1's) sit beside `modulusWord`.

  Statements are the originals apart from the namespace. No import and no existing statement changes.
- **Merge `21f549c2`** brings in #378's `bucketSampler` readers.
- **`40e12f64`** (Q-L2-1 (b)) re-proves `drawSamplable_residue` through them, proof only.

decls2: 10 added in `Contract.lean`, plus #378's 3. Re-check on the iO base merged with `bff0567b`: rc 0, and all new constants use standard axioms. The coe-A seal of `Contract.lean` is now **0 errors**; it had 3 pre-existing errors before these edits. `iO/phase-a-base` takes this head in merge `5382668b`. Records: `briefs/efficiency-gaps/wave1/EF-D1/final-r1/landing-r2.md`.

## Checks of the original delivery (maintainer, on `cp -al` copies of olean snapshot #10)
- The contract branch and the merged `iO/phase-a-base` (`5ed465f6`: #374 + #378 + this + #380) were checked in dependency order, root `TCSlib.lean` included. Every module: rc 0, 0 errors, 0 warnings, no `sorry`. The snapshot is unmodified (0/0/0).
- `#print axioms` on all 28 declarations: standard axioms only.
- `style_lint`: 0 findings. Every line is ≤ 100 characters.

Report: `briefs/io-components/contract/REPORT.md`.

## Gate
A Codex gate for the foundation PRs (#374, #378, #380, #384) is to be staged. Seyoon merges after #378.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01PqpVTiuDcjSqhyfbqnsVxA
