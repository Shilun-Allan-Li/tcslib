Paired controls for the four readers that LE-g56-s1 uses (CoinSampler.congr_dec, bucket_dec,
ProbComp.close_iff, OracleComp.outputsSubset_iff). Sealed.lean = Unsealed.lean plus
`attribute [local irreducible]` on the four definitions read (CoinSampler.congr, bucket,
ProbComp.Close, OracleComp.OutputsSubset). Run from the merge worktree (ef93fdb1) with
LEAN_PATH = the r2 replay tree plus the lake packages: lean -DmaxErrors=0 <file> (no -o), one process.
Expected and found: Sealed rc 1 with exactly 4 errors, at the 4 --NEG lines (17, 21, 29, 34); every --POS
line passes. Unsealed rc 0, 0 errors.
