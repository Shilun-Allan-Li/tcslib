r"""keycmp.py <repo> <revA> <revB> <order.txt> <mapA.tsv> <mapB.tsv> (Gate 54): for every module of <order.txt>, compare
its import-closure key (stateplan.py's Merkle key: path, source SHA-256, sorted local-import keys) at <revA> and at <revB>,
and its olean hash in the two maps. Modules with equal keys must have equal oleans (deterministic builds); prints counts
and every exception."""
import sys, re, json, hashlib, subprocess
repo, ra, rb, order, ma, mb = sys.argv[1:7]
sha = lambda b: hashlib.sha256(b).hexdigest(); local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
class K:
    def __init__(s, rev): s.rev, s.k, s.src = rev, {}, {}
    def source(s, m):
        if m not in s.src:
            p = subprocess.run(['git', '-C', repo, 'show', f'{s.rev}:{m}.lean'], capture_output=True); s.src[m] = p.stdout if p.returncode == 0 else None
        return s.src[m]
    def key(s, m):
        if m in s.k: return s.k[m]
        src = s.source(m)
        if src is None: s.k[m] = None; return None
        imps = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', src.decode('utf-8', 'replace'), re.M) if local(i)]
        s.k[m] = sha(('\n'.join([m, sha(src)] + sorted(f'{i}={s.key(i)}' for i in imps))).encode()); return s.k[m]
sys.setrecursionlimit(100000)
A, B = K(ra), K(rb); MA = dict(l.rstrip('\n').split('\t') for l in open(ma)); MB = dict(l.rstrip('\n').split('\t') for l in open(mb))
c = {}; ex = []
for m in [l.strip() for l in open(order) if l.strip()]:
    ke = A.key(m) == B.key(m); oe = MA.get(m) is not None and MA.get(m) == MB.get(m)
    c[(ke, oe)] = c.get((ke, oe), 0) + 1
    if ke and not oe: ex.append(m)
for (ke, oe), n in sorted(c.items()): print(f'key {"equal" if ke else "differs"}, olean {"equal" if oe else "differs/absent"}: {n}')
print('equal key but different olean:', ex); print('RESULT', 'OK' if not ex else 'FAIL')
