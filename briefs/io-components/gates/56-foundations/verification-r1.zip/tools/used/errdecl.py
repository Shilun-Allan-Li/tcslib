"""errdecl.py <wt> <rev> <seal.json> <probe log>: probe errors mapped to source lines (record's line map) and to the
enclosing top-level declaration of the source at <rev> (nearest preceding column-0 declaration keyword line)."""
import sys, json, re, subprocess
wt, rev, recf, logf = sys.argv[1:5]
rec = json.load(open(recf)); pm = {d['probe_line']: d['source_line'] for d in rec['source_to_probe_lines']}
src = subprocess.run(['git', '-C', wt, 'show', f"{rev}:{rec['source']}"], capture_output=True, text=True).stdout.split('\n')
KW = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|nonrec)\s+)*(?:theorem|lemma|def|abbrev|instance|structure)\s+(\S+)')
def decl(n):
    for i in range(n - 1, -1, -1):
        m = KW.match(src[i])
        if m: return m.group(1)
    return '?'
out = set()
for m in re.finditer(r'^\S+\.lean:(\d+):\d+: error', open(logf, encoding='utf-8', errors='replace').read(), re.M):
    sl = pm.get(int(m.group(1)))
    if sl and not src[sl - 1].startswith(('import', 'set_option')): out.add(decl(sl))
print(','.join(sorted(out)))
