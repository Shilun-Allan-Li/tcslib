r"""stmtcmp.py <repo> (Gate 56): the statement (header up to `:=`/`where`/` := by`) of each promoted helper in #384's
Contract.lean at 40e12f64 against its original (EF-H11 71acf81c SecretSharing/Efficient.lean; EF-D1 delivery bd4c6f2d
LWE/Efficient.lean), whitespace-normalised, with the original's namespace prefix removed. Prints EQUAL/DIFF per name."""
import sys, re, subprocess
repo = sys.argv[1]
show = lambda rev, p: subprocess.run(['git', '-C', repo, 'show', f'{rev}:{p}'], capture_output=True, text=True, check=True).stdout
NEW = show('5b17523b3360572ef266c44c7da8633d7f651280', 'TCSlib/Cryptography/CoinSampling/Contract.lean')
H11 = show('71acf81c9be540fdfbb6826c96a46a3f0a119abc', 'TCSlib/Cryptography/SecretSharing/Efficient.lean')
D1 = show('bd4c6f2d826b2fb91c02d720d8bd6b60c2a3795e', 'TCSlib/Cryptography/LWE/Efficient.lean')
def stmt(src, name):
    m = re.search(r'^(theorem|def|lemma|abbrev)\s+' + re.escape(name) + r'\b(.*?)(:=|\bwhere\b)', src, re.S | re.M)
    if not m: return None
    s = m.group(1) + ' ' + name + m.group(2)
    s = re.sub(r'--[^\n]*', '', s)
    return ' '.join(s.split())
norm = lambda s: s and re.sub(r'\b(CoinSampling|SecretSharing|LWE)\.', '', s)
rows = [('samplesEfficiently_comap', H11), ('drawSamplable_restrict', D1), ('natToList_two_pow', D1),
        ('polyTimeComputable_twoPowWord', D1), ('seedModulusWord', D1), ('seedModulusWord_eq', D1),
        ('seedModulusWord_eq_cons', D1), ('listToNat_seedModulusWord', D1), ('length_seedModulusWord', D1)]
for n, src in rows:
    a, b = stmt(src, n), stmt(NEW, n)
    tag = 'EQUAL' if a is not None and norm(a) == norm(b) else ('MISSING-ORIG' if a is None else 'DIFF')
    print(tag, n); 
    if tag != 'EQUAL': print('  orig:', a); print('  new :', b)
