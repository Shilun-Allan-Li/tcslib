r"""downstream.py <repo> <rev> <order.txt> <seeds.txt> <out>: modules of <order.txt> whose import closure at <rev>
contains a seed (seeds included), in <order.txt> order. Parsing as fullorder.py (^import\s+(\S+), local TCSlib/audits)."""
import sys, re, subprocess
repo, rev, order, seeds, out = sys.argv[1:6]
mods = [l.strip() for l in open(order) if l.strip()]
S = set(l.strip() for l in open(seeds) if l.strip())
local = lambda n: n.split('.')[0] in ('TCSlib', 'audits')
imp = {}
for m in mods:
    s = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{m}.lean'], capture_output=True, text=True, check=True).stdout
    imp[m] = [i.replace('.', '/') for i in re.findall(r'^import\s+(\S+)', s, re.M) if local(i)]
hit = {}
for m in mods:  # imports-first order
    hit[m] = m in S or any(hit.get(i, False) for i in imp[m])
res = [m for m in mods if hit[m]]
open(out, 'w').write(''.join(m + '\n' for m in res)); print(f'seeds {len(S)}; downstream incl. seeds {len(res)}')
