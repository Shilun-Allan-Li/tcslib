r"""mksourcehead.py <repo> <out.json> (Gate 56, restaged r1 on the LE-g56-s1 heads): pins of the four foundation PRs, iO/phase-a-base, the records tip, the
scratch merge and the manifest, read from git objects only (python3 -I)."""
import sys, json, subprocess
repo, out = sys.argv[1:3]
g = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True, check=True).stdout.strip()
REC = '1b18206f5d3fee9214bfaa0fff74262836b67f48'; BASE = '686bf03f25faafb5e3db20899be25e427b82099c'
MB = 'a2bf4bac0d545fce1fcb4014ef12b44f9651a658'; SCR = 'ef93fdb1a31cf0523c49a05407b45f2ccb09148e'
prs = [(374, 'foundations/subexp', 'cryptography/pass-shelat-ch2-4', MB, 'cbce64d1c135c710b7c036968ed9d4f21414aa72'),
       (378, 'foundations/coin-sampling', 'foundations/subexp', 'cbce64d1c135c710b7c036968ed9d4f21414aa72',
        '2bf61a2eed72d3aad1de95134be8f89da9424af7'),
       (384, 'foundations/coin-contract', 'foundations/coin-sampling', '2bf61a2eed72d3aad1de95134be8f89da9424af7',
        '5b17523b3360572ef266c44c7da8633d7f651280'),
       (380, 'foundations/realization', 'foundations/subexp', 'cbce64d1c135c710b7c036968ed9d4f21414aa72',
        'cdc0934f36365533d410607d0664a0570ae92679')]
def commits(a, b):
    res = []
    for c in g('rev-list', '--reverse', f'{a}..{b}').split():
        raw = g('cat-file', '-p', c)
        res.append(dict(commit=c, parents=g('rev-list', '--parents', '-n1', c).split()[1:],
                        subject=g('log', '-1', '--format=%s', c), author=g('log', '-1', '--format=%an <%ae>', c),
                        author_date=g('log', '-1', '--format=%aI', c),
                        signature='ssh' if '-----BEGIN SSH SIGNATURE-----' in raw else ('gpgsig' if 'gpgsig' in raw else None),
                        files=g('diff-tree', '--no-commit-id', '--name-only', '-r', '-m', '--first-parent', c).split(),
                        tcslib_tree=g('rev-parse', f'{c}:TCSlib')))
    return res
d = dict(gate=56, round=1, restaged='2026-11-19 on the LE-g56-s1 heads (Q-G56-1 (A)); supersedes the draft r1 of records 057fe893/0cd8a194',
         superseded_heads={'378': '3473adda66d9c61c51ba640ed4c701e5cde0b6b1', '384': '40e12f64293833056e311ab7aaf5a62fb3006353', 'iO/phase-a-base': '5382668bc9cc496355c83e7b77909d9647e089b3'}, name='Foundations: #374 Subexponential, #378 CoinSampling, #384 SamplesEfficiently, #380 RealizesOn',
         staged='2026-11-19', toolchain=g('show', f'{BASE}:lean-toolchain'))
man = json.loads(g('show', f'{BASE}:lake-manifest.json'))
d['manifest_packages'] = {p['name']: p['rev'] for p in man['packages']}
d['prs'] = []
for n, br, bbr, base, head in prs:
    files = {}
    for f in g('diff', '--name-only', base, head).split():
        files[f] = dict(blob=g('rev-parse', f'{head}:{f}'), lines=len(g('show', f'{head}:{f}').split('\n')),
                        base_blob=(g('rev-parse', f'{base}:{f}') if f in g('ls-tree', '-r', '--name-only', base, f) else None))
    d['prs'].append(dict(number=n, branch=br, base_branch=bbr, diff_base=base, merge_base=g('merge-base', base, head),
                         head=head, head_tree=g('rev-parse', f'{head}^{{tree}}'), head_tcslib_tree=g('rev-parse', f'{head}:TCSlib'),
                         shortstat=g('diff', '--shortstat', base, head), commits=commits(base, head), files=files,
                         diff_file=f'pr{n}.diff.txt'))
d['phase_a_base'] = dict(branch='iO/phase-a-base', head=BASE, tcslib_tree=g('rev-parse', f'{BASE}:TCSlib'),
                         merge_base_with_records=g('merge-base', BASE, REC), parents=g('rev-list', '--parents', '-n1', BASE).split()[1:],
                         changed_paths_vs_merge_base=g('diff', '--name-only', MB, BASE, '--', 'TCSlib', 'TCSlib.lean').split())
d['records'] = dict(branch='cryptography/pass-shelat-ch2-4', tip_at_staging=REC, tip_tcslib_tree=g('rev-parse', f'{REC}:TCSlib'),
                    lean_paths_changed_since_merge_base=g('diff', '--name-only', MB, REC, '--', 'TCSlib', 'TCSlib.lean', 'audits',
                                                          'lean-toolchain', 'lake-manifest.json', 'lakefile.lean').split())
mt = g('merge-tree', '--write-tree', REC, BASE)
d['merged'] = dict(merge_tree=mt.split()[0], merge_tree_output_lines=len(mt.split('\n')), tcslib_tree=g('rev-parse', f'{mt.split()[0]}:TCSlib'),
                   scratch_commit=SCR, scratch_commit_parents=g('rev-list', '--parents', '-n1', SCR).split()[1:], scratch_commit_on_any_ref=False)
d['unchanged'] = {f: {k: g('rev-parse', f'{r}:{f}') for k, r in (('merge_base', MB), ('records_tip', REC), ('phase_a_base', BASE), ('merge', SCR))}
                  for f in ('lean-toolchain', 'lake-manifest.json', 'lakefile.lean', 'audits')}
recs = ['IOComponentsPlan.md', 'policy.md', 'briefs/io-components/subexp/REPORT.md', 'briefs/io-components/sampler-bridge/design-r1.md',
        'briefs/io-components/sampler-bridge/IMPL-REPORT.md', 'briefs/io-components/contract/REPORT.md', 'briefs/io-components/realization/REPORT.md',
        'briefs/efficiency-gaps/wave1/EF-D1/final-r1/landing-r2.md', 'briefs/pass-shelat-ch5-8/duplication-ledger.md',
        'briefs/pass-shelat-ch5-8/MAINTAINER-HANDOFF.md', 'briefs/io-components/gates/51-phfe-statements/findings-r1.md',
        'briefs/io-components/sprg/design-r3.md', 'briefs/io-components/sprg/rulings.md', 'briefs/io-components/phfe/rulings.md']
import hashlib
d['records_sha256_at_staging_tip'] = {p: hashlib.sha256(subprocess.run(['git', '-C', repo, 'show', f'{REC}:{p}'], capture_output=True, check=True).stdout).hexdigest() for p in recs}
json.dump(d, open(out, 'w'), indent=1, sort_keys=True, ensure_ascii=False); open(out, 'a').write('\n')
print('ok', len(d['prs']))
