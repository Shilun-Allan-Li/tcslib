#!/usr/bin/env bash
# run-replay-r2.sh (Gate 56 restaged r1, merged-tree replay on the LE-g56-s1 heads; adapted from Gate 54's run-replay.sh): the recipe's runner.py (unmodified),
# one module per call, through scripts/lean_check_tree.sh with TCSLIB_OLEANS=OUT, worktree = the scratch merge commit;
# slot gate before each module (wait while 3 or more lean processes run on the host); stop if free disk < 2,000 MB.
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
B=$SP/g56/r2/replay; OUT=$SP/g56/olean-replay-g56r2; RUNNER=$SP/snaptools3/olean-advance-a6d01b1b/tools-used/runner.py
Q=${1:-$B/queue-g56.txt}; E=${2:-$B/build}; WX=$SP/g56/mwt
export PATH=$HOME/.elan/bin:$PATH TMPDIR=$B/tmp
mkdir -p $E/one $B/tmp
echo "start $(date -u +%FT%TZ) queue $Q head $(git -C $WX rev-parse HEAD)" >> $E/runner.start; df -m / | tail -1 >> $E/df-launch.txt
while read -r m; do
  avail=$(df -m / | tail -1 | awk '{print $4}'); [ "$avail" -lt 2000 ] && { echo "DISK LOW $avail MB before $m" >> $E/runner.exit; exit 2; }
  while [ "$(pgrep -c -x lean)" -ge 3 ]; do echo "wait $(date -u +%FT%TZ) $(pgrep -c -x lean) lean" >> $E/slot-waits.txt; sleep 30; done
  echo "slot $(date -u +%FT%TZ) $(pgrep -c -x lean) lean before $m" >> $E/slot-log.txt
  echo "$m" > $E/one/order.txt
  python3 -I $RUNNER $WX $E/one/order.txt $OUT $E < /dev/null || { echo "runner FAIL $m $(date -u +%FT%TZ)" >> $E/runner.exit; exit 1; }
done < $Q
echo "runner exit 0 $(date -u +%FT%TZ)" >> $E/runner.exit; df -m / | tail -1 >> $E/runner.exit
