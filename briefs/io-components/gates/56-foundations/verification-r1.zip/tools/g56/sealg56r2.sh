#!/usr/bin/env bash
# sealg56r2.sh <name> <phase> <dotted owner>... (Gate 56: canonical coe-A seals of the foundation owners (#374, #378, #384, #380) on the merged-tree replay output; Gate 54 sealg54.sh with worktree, tree and output re-pointed to Gate 56, coe-B not generated):
# phases: collect (collector over the owners, on the D1 working tree), mkseals (coe A and coe B whole-file seals of the
# owners at the worktree HEAD; mkseals_coe.py, archived Gate 06/10 instrumenter unmodified), run (the probes through the
# gated runner: one Lean process at a time, wait while 3 or more lean processes run; lean -DmaxErrors=0, no -o).
set -u
SP=/tmp/claude-0/-home-user-tcslib/d0667d12-db8d-5853-b0f7-9833dc0884c6/scratchpad
X=$SP/g56/r2; T=$SP/s2a-d4/tools/seal; G=$T/review/archived-gate10-tools; W=$SP/g56/mwt; TREE=$SP/g56/olean-replay-g56r2
NAME=$1; PH=$2; shift 2; MODS="$@"
R=$X/seal/$NAME; PP=G56SealR2_$NAME
export TMPDIR=$X/tmp PATH=$HOME/.elan/bin:$PATH SEAL_CHUNK=1000
mkdir -p $R/order $R/probe-sources $W/$PP $X/tmp
H=$(git -C $W rev-parse HEAD)
RUN="bash $SP/s2a-d4/tools/gated_full.sh"
case $PH in
collect)
  printf '%s\n' $MODS > $R/order/owners.txt
  python3 -I $T/review/mkcollect.py $T/review/NmCollect.template.lean $R/order/owners.txt "Gate 56 r2 $NAME collector" $W/$PP/Collect.lean
  cp $W/$PP/Collect.lean $R/probe-sources/Collect.lean.txt
  echo $PP/Collect > $R/order/probes.txt
  $RUN $W $R/order/probes.txt $TREE $R/probe-runs > $R/probe-runner.out 2>&1; echo "collector rc=$?"; tail -1 $R/probe-runs/results.jsonl;;
mkseals)
  LOG=$R/probe-runs/mods/${PP}_Collect.log
  ( cd $T && python3 -I $T/review/mkseals_coe.py $G $LOG $W $H $R/seals-coe/A $PP/C SealA_ $MODS > $R/mkseals-coe-A.log )
  (cd $W && ls $PP/C/*.lean | sed 's/\.lean$//' | LC_ALL=C sort) > $R/order/seals.txt
  echo "head $H" > $R/head.txt; cat $R/mkseals-coe-*.log | tail -20;;
run)
  $RUN $W $R/order/seals.txt $TREE $R/seal-runs > $R/seal-runner.out 2>&1
  python3 -I -c "
import json,sys
for l in open('$R/seal-runs/results.jsonl'):
    r=json.loads(l)
    if 'module' in r: print(r['module'], r['rc'], r['errors'], r['seconds'])
";;
esac
