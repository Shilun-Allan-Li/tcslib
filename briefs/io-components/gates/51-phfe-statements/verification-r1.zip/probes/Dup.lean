import TCSlib.Cryptography.AdvancedEncryption
import TCSlib.Cryptography.Pairing
import TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity

/-! io-c0 Gate 51 probe: duplication items (S2 GT exponent laws; S3 inline `foldr pairEncode []` vs
`PrivateKeyScheme.encodeList`). Scratch only; every probe is an `example`. -/

open TCSlib.Cryptography TCSlib.Cryptography.Pairing Turing

-- S3: the inline fold IS `encodeList` (extensionally; by induction, no new lemma needed) ...
example : (fun l : List (List Bool) => l.foldr pairEncode []) = PrivateKeyScheme.encodeList := by
  funext l
  induction l with
  | nil => rfl
  | cons m ms ih => simp only [List.foldr_cons, PrivateKeyScheme.encodeList, ih]
-- ... and definitionally on every literal list the delivery spells out (here two and four entries).
example (a b : List Bool) : [a, b].foldr pairEncode [] = PrivateKeyScheme.encodeList [a, b] := rfl
example (a b c d : List Bool) :
    [a, b, c, d].foldr pairEncode [] = PrivateKeyScheme.encodeList [a, b, c, d] := rfl
-- S3: is the bridge already a named lemma?
example (l : List (List Bool)) : l.foldr pairEncode [] = PrivateKeyScheme.encodeList l := by exact?

-- S2: the two GT laws restated against the base API only (Pairing.Group), each closed by the
-- base source-group proof pattern with `card_GT` in place of `card_G`.
example {wG wT : ℕ} (B : BilinearGroup wG wT) (gT : B.GT) (a b : ZMod B.order) :
    gT ^ (a + b).val = gT ^ a.val * gT ^ b.val := by
  rw [ZMod.val_add, ← pow_add, ← pow_mod_card gT (a.val + b.val), B.card_GT]
example {wG wT : ℕ} (B : BilinearGroup wG wT) (gT : B.GT) (a : ZMod B.order) :
    gT ^ (-a).val = (gT ^ a.val)⁻¹ := by
  rw [eq_inv_iff_mul_eq_one, ← pow_add, ← pow_mod_card gT ((-a).val + a.val), B.card_GT,
    ← ZMod.val_add, neg_add_cancel, ZMod.val_zero, pow_zero]
-- S2: the base source-group lemmas do not apply to GT (they are stated for `B.G`):
#check @BilinearGroup.pow_val_add
#check @BilinearGroup.pow_val_neg
#check @BilinearGroup.pow_val_mul_GT
