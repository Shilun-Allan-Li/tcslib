/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Raw
import TCSlib.Cryptography.Encoding.ModularDecode
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Fin.Tuple.Basic
import Mathlib.LinearAlgebra.Matrix.Kronecker
import Mathlib.Algebra.MvPolynomial.Eval
import Mathlib.Algebra.MvPolynomial.Degrees

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Polynomial classes for partially hiding functional encryption

A coefficient tensor represents public-input polynomials of degree at most d by
padding the public input with 1. Its tuple coordinates use the published explicit
base-(l+1) equivalence. The two private-input classes are [GJLS21, §9, pp.57–58]
and [Wee20, §3, p.6], restricted to these polynomial vectors.

All wire words are interpreted modulo the supplied positive modulus. The modular
parser is reused at the word modulus 2^w, where every width-w chunk is canonical;
its representatives are then cast into the supplied modulus. No word is rejected
merely because its integer representative is at least the supplied modulus.

## Main definitions

* `PolyTensor`, `polyTensorEval`: padded coefficient tensors and their evaluation.
* `decodeResidues`, `decodeTensor`, `encodeTensor`: canonical wire interpretation.
* `phfeClass`, `quadClass`: the two classes, with positive modulus as class parameter.
* `BidegreeAtMost`: monomial-wise bounds on public and private degrees.

## Main results

* `decodeResidues_parse`, `decodeResidues_apply`: total modular interpretation.
* `decodeTensor_encodeTensorBits`: tensor round trip under width coverage.
* `phfeClass_eval_eq_quad`: the embedding by duplicating the private input.
* `pad_one`: every polynomial of public degree at most d and private degree at most
  two is represented after padding the private input with 1.

## References

* [GJLS21] R. Gay, A. Jain, H. Lin, A. Sahai, *Indistinguishability Obfuscation from
  Simple-to-State Hard Problems: New Assumptions, New Techniques, and Simplification*,
  EUROCRYPT 2021; full version, ePrint 2020/764, §9, printed pp.57–58.
* [Wee20] H. Wee, *Functional Encryption for Quadratic Functions from k-Lin, Revisited*,
  TCC 2020; full version, ePrint 2020/1420, §3, p.6.
-/

namespace TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption

open Complexity Turing
open TCSlib.Cryptography.NumberTheory (listToNat)

/-- A degree-d polynomial vector is represented by coefficients on padded tuples.
[GJLS21, §9, pp.57–58; Wee20, §3, p.6]. The representation uses ordered tuples
rather than monomials, with the padded constant accounting for smaller degrees. -/
abbrev PolyTensor (p : ℕ+) (l n d : ℕ) : Type :=
  Fin n → (Fin d → Fin (l + 1)) → ZMod (p : ℕ)

/-- A coefficient tensor has one residue for each output and padded monomial tuple. -/
theorem polyTensor_eq (p : ℕ+) (l n d : ℕ) :
    PolyTensor p l n d = (Fin n → (Fin d → Fin (l + 1)) → ZMod (p : ℕ)) := rfl

/-- The padded public input appends the constant 1, so tuples of fixed length d
can represent every smaller public degree. [GJLS21, §9, pp.57–58]. -/
def xhat {p : ℕ+} {l : ℕ} (x : Fin l → ZMod (p : ℕ)) :
    Fin (l + 1) → ZMod (p : ℕ) := Fin.snoc x 1

/-- Public-input padding is exactly `Fin.snoc x 1`. -/
theorem xhat_eq {p : ℕ+} {l : ℕ} (x : Fin l → ZMod (p : ℕ)) :
    xhat x = Fin.snoc x 1 := rfl

/-- Padding preserves each public-input coordinate. -/
theorem xhat_castSucc {p : ℕ+} {l : ℕ} (x : Fin l → ZMod (p : ℕ)) (i : Fin l) :
    xhat x i.castSucc = x i := Fin.snoc_castSucc (α := fun _ => ZMod (p : ℕ)) 1 x i

/-- The final padded public-input coordinate equals 1. -/
theorem xhat_last {p : ℕ+} {l : ℕ} (x : Fin l → ZMod (p : ℕ)) :
    xhat x (Fin.last l) = 1 := Fin.snoc_last (α := fun _ => ZMod (p : ℕ)) 1 x

/-- Tensor evaluation sums each coefficient times its padded public monomial.
[GJLS21, §9, pp.57–58; Wee20, §3, p.6]. -/
def polyTensorEval {p : ℕ+} {l n d : ℕ} (C : PolyTensor p l n d)
    (x : Fin l → ZMod (p : ℕ)) : Fin n → ZMod (p : ℕ) :=
  fun j => ∑ tau : Fin d → Fin (l + 1), C j tau * ∏ i : Fin d, xhat x (tau i)

/-- Tensor evaluation is the displayed sum over padded tuples. -/
theorem polyTensorEval_eq {p : ℕ+} {l n d : ℕ} (C : PolyTensor p l n d)
    (x : Fin l → ZMod (p : ℕ)) (j : Fin n) :
    polyTensorEval C x j =
      ∑ tau : Fin d → Fin (l + 1), C j tau * ∏ i : Fin d, xhat x (tau i) := rfl

/-- Padded monomial tuples have the explicit base-(l+1) coordinate ordering
provided by `finFunctionFinEquiv`; no arbitrary finite-type enumeration is chosen. -/
def tupleCoord (l d : ℕ) : (Fin d → Fin (l + 1)) ≃ Fin ((l + 1) ^ d) :=
  finFunctionFinEquiv

/-- Tuple coordinates use the published finite-function equivalence. -/
theorem tupleCoord_eq (l d : ℕ) : tupleCoord l d = finFunctionFinEquiv := rfl

/-- Parse a fixed-length residue word at its word modulus and cast each resulting
integer into the supplied positive modulus. The explicit zero fallback is
unreachable by `decodeResidues_parse`. This is total modular decoding glue. -/
def decodeResidues (p : ℕ+) (count width : ℕ)
    (word : Fin (count * width) → Bool) : Fin count → ZMod (p : ℕ) :=
  fun i => ((((Encoding.Modular.decodeVector (q := 2 ^ width) (length := count)
    width (List.ofFn word)).getD 0) i).val : ZMod (p : ℕ))

/-- Residue decoding is the word-modulus parser followed by representative casting,
with the displayed explicit fallback. -/
theorem decodeResidues_eq (p : ℕ+) (count width : ℕ)
    (word : Fin (count * width) → Bool) :
    decodeResidues p count width word = fun i =>
      ((((Encoding.Modular.decodeVector (q := 2 ^ width) (length := count)
        width (List.ofFn word)).getD 0) i).val : ZMod (p : ℕ)) := rfl

/-- Every fixed-length word passes the word-modulus parser: each width-bit block
is less than 2^width. In particular the decoding fallback is never used.

**Proof sketch.** The vector length is `List.length_ofFn`; a taken block has at
most width bits. Apply the existing integer bound `listToNat_lt_two_pow`, then
monotonicity of powers, and use the published parser equation to open its guard. -/
theorem decodeResidues_parse (count width : ℕ) (word : Fin (count * width) → Bool) :
    Encoding.Modular.decodeVector (q := 2 ^ width) (length := count) width
        (List.ofFn word) =
      some (fun i : Fin count =>
        (listToNat (((List.ofFn word).drop (i.val * width)).take width) : ZMod (2 ^ width))) :=
  (Encoding.Modular.decodeVector_eq width (List.ofFn word)).trans
    (if_pos ⟨List.length_ofFn, fun i =>
      lt_of_lt_of_le (Candidates.listToNat_lt_two_pow _)
        (Nat.pow_le_pow_right (Nat.succ_pos 1) (List.length_take_le _ _))⟩)

/-- Each decoded residue is the integer represented by its block, reduced modulo
p. This reader explicitly rules out rejection of representatives at least p. -/
theorem decodeResidues_apply (p : ℕ+) (count width : ℕ)
    (word : Fin (count * width) → Bool) (i : Fin count) :
    decodeResidues p count width word i =
      (listToNat (((List.ofFn word).drop (i.val * width)).take width) : ZMod (p : ℕ)) :=
  (congrArg
      (fun o : Option (Fin count → ZMod (2 ^ width)) =>
        (((o.getD 0) i).val : ZMod (p : ℕ)))
      (decodeResidues_parse count width word)).trans
    (congrArg (fun a : ℕ => (a : ZMod (p : ℕ)))
      (ZMod.val_cast_of_lt (lt_of_lt_of_le (Candidates.listToNat_lt_two_pow _)
        (Nat.pow_le_pow_right (Nat.succ_pos 1) (List.length_take_le _ _)))))

/-- Equal modulus values give the same decoded residues after the natural cast.
This is the reader used when replacing a drawn order by a fixed prime schedule.

**Proof sketch.** Positive naturals with the same value are equal. Substitute
that equality and use the residue representative casting identity coordinatewise. -/
theorem decodeResidues_modulus (p q : ℕ+) (hpq : (p : ℕ) = (q : ℕ)) (count width : ℕ)
    (word : Fin (count * width) → Bool) :
    (fun i => ((decodeResidues p count width word i).val : ZMod (q : ℕ))) =
      decodeResidues q count width word := sorry

/-- Total decoding inverts a canonical vector encoding when its residues fit.

**Proof sketch.** Reinterpret the same integer representatives at the word
modulus, use the published modular-vector round trip, then cast each representative
back into p. The width hypothesis prevents any truncation of an original residue. -/
theorem decodeResidues_encodeVector (p : ℕ+) (count width : ℕ)
    (hwidth : (p : ℕ) ≤ 2 ^ width) (v : Fin count → ZMod (p : ℕ))
    (word : Fin (count * width) → Bool)
    (hword : List.ofFn word = Encoding.Modular.encodeVector width v) :
    decodeResidues p count width word = v := sorry

/-- Encode a coefficient tensor as a row-major modular matrix using the explicit
padded-tuple ordering. This reuses the published modular matrix encoder. -/
def encodeTensor {p : ℕ+} {l n d : ℕ} (width : ℕ) (C : PolyTensor p l n d) : List Bool :=
  Encoding.Modular.encodeMatrix width (fun j k => C j ((tupleCoord l d).symm k))

/-- Tensor encoding is the displayed row-major matrix encoding. -/
theorem encodeTensor_eq {p : ℕ+} {l n d : ℕ} (width : ℕ) (C : PolyTensor p l n d) :
    encodeTensor width C =
      Encoding.Modular.encodeMatrix width (fun j k => C j ((tupleCoord l d).symm k)) := rfl

/-- A tensor encoding has exactly n(l+1)^d residue blocks of the supplied width. -/
theorem encodeTensor_length {p : ℕ+} {l n d : ℕ} (width : ℕ) (C : PolyTensor p l n d) :
    (encodeTensor width C).length = n * (l + 1) ^ d * width :=
  Encoding.Modular.encodeMatrix_length width (fun j k => C j ((tupleCoord l d).symm k))

/-- View the tensor's canonical encoding as a fixed-width bit vector. -/
def encodeTensorBits {p : ℕ+} {l n d : ℕ} (width : ℕ) (C : PolyTensor p l n d) :
    Fin (n * (l + 1) ^ d * width) → Bool :=
  fun i => (encodeTensor width C).getD i.val false

/-- Tensor bit encoding reads the corresponding position of the canonical word. -/
theorem encodeTensorBits_eq {p : ℕ+} {l n d : ℕ} (width : ℕ) (C : PolyTensor p l n d) :
    encodeTensorBits width C = fun i => (encodeTensor width C).getD i.val false := rfl

/-- Writing the fixed-width tensor bits gives exactly its canonical word.

**Proof sketch.** The encoder's length is already known. Apply the list reading
round trip at that length; no padding or truncation occurs at any finite index. -/
theorem ofFn_encodeTensorBits {p : ℕ+} {l n d : ℕ} (width : ℕ)
    (C : PolyTensor p l n d) : List.ofFn (encodeTensorBits width C) = encodeTensor width C :=
  sorry

/-- Decode a coefficient tensor by total modular vector decoding and the explicit
row/tuple finite-product coordinates. This is wire-representation glue. -/
def decodeTensor (p : ℕ+) (l n d width : ℕ)
    (word : Fin (n * (l + 1) ^ d * width) → Bool) : PolyTensor p l n d :=
  fun j tau => decodeResidues p (n * (l + 1) ^ d) width word
    (finProdFinEquiv (j, tupleCoord l d tau))

/-- Tensor decoding reads the residue at the output/tuple product coordinate. -/
theorem decodeTensor_eq (p : ℕ+) (l n d width : ℕ)
    (word : Fin (n * (l + 1) ^ d * width) → Bool) :
    decodeTensor p l n d width word = fun j tau =>
      decodeResidues p (n * (l + 1) ^ d) width word
        (finProdFinEquiv (j, tupleCoord l d tau)) := rfl

/-- Tensor decoding inverts its canonical encoding under width coverage.

**Proof sketch.** Use the row-major modular matrix round trip, the total modular
interpretation, and the explicit tuple equivalence's inverse laws coordinatewise. -/
theorem decodeTensor_encodeTensorBits {p : ℕ+} {l n d : ℕ} (width : ℕ)
    (hwidth : (p : ℕ) ≤ 2 ^ width) (C : PolyTensor p l n d) :
    decodeTensor p l n d width (encodeTensorBits width C) = C := sorry

/-- Fixed-width coefficient descriptions are injective when every residue fits.

**Proof sketch.** Apply the tensor decoder to equal descriptions and use its
round trip. This delegates the actual modular encoding argument to the published API. -/
theorem encodeTensorBits_injective {p : ℕ+} {l n d : ℕ} (width : ℕ)
    (hwidth : (p : ℕ) ≤ 2 ^ width) :
    Function.Injective (encodeTensorBits (p := p) (l := l) (n := n) (d := d) width) := sorry

/-- The private tensor is the Kronecker product z1 ⊗ z2 in row-major pair order.
[Wee20, §3, p.6]. -/
def privateTensor {p : ℕ+} {n1 n2 : ℕ} (z1 : Fin n1 → ZMod (p : ℕ))
    (z2 : Fin n2 → ZMod (p : ℕ)) : Fin (n1 * n2) → ZMod (p : ℕ) :=
  fun i => Matrix.kroneckerMap (fun a b => a * b)
    (fun (_ : Fin 1) j => z1 j) (fun (_ : Fin 1) j => z2 j)
    (0, 0) (finProdFinEquiv.symm i)

/-- The private tensor is the displayed flattened Kronecker product. -/
theorem privateTensor_eq {p : ℕ+} {n1 n2 : ℕ} (z1 : Fin n1 → ZMod (p : ℕ))
    (z2 : Fin n2 → ZMod (p : ℕ)) :
    privateTensor z1 z2 = fun i => Matrix.kroneckerMap (fun a b => a * b)
      (fun (_ : Fin 1) j => z1 j) (fun (_ : Fin 1) j => z2 j)
      (0, 0) (finProdFinEquiv.symm i) := rfl

/-- The quadratic class evaluates the private tensor against the polynomial vector.
[Wee20, §3, p.6]. Polynomial vectors are the fixed-degree subclass used here. -/
def quadEval {p : ℕ+} {l n1 n2 d : ℕ} (C : PolyTensor p l (n1 * n2) d)
    (x : Fin l → ZMod (p : ℕ)) (z1 : Fin n1 → ZMod (p : ℕ))
    (z2 : Fin n2 → ZMod (p : ℕ)) : ZMod (p : ℕ) :=
  dotProduct (privateTensor z1 z2) (polyTensorEval C x)

/-- Quadratic evaluation is the displayed dot product. -/
theorem quadEval_eq {p : ℕ+} {l n1 n2 d : ℕ} (C : PolyTensor p l (n1 * n2) d)
    (x : Fin l → ZMod (p : ℕ)) (z1 : Fin n1 → ZMod (p : ℕ))
    (z2 : Fin n2 → ZMod (p : ℕ)) :
    quadEval C x z1 z2 = dotProduct (privateTensor z1 z2) (polyTensorEval C x) := rfl

/-- The PHFE class is the quadratic class restricted to the diagonal private input.
[GJLS21, §9, pp.57–58; Wee20, §3, p.6]. -/
def phfeEval {p : ℕ+} {l n d : ℕ} (C : PolyTensor p l (n * n) d)
    (x : Fin l → ZMod (p : ℕ)) (y : Fin n → ZMod (p : ℕ)) : ZMod (p : ℕ) :=
  quadEval C x y y

/-- PHFE evaluation is quadratic evaluation at the duplicated private input. -/
theorem phfeEval_eq {p : ℕ+} {l n d : ℕ} (C : PolyTensor p l (n * n) d)
    (x : Fin l → ZMod (p : ℕ)) (y : Fin n → ZMod (p : ℕ)) :
    phfeEval C x y = quadEval C x y y := rfl


-- io-c0 probe: the signature of `phfeEval_sum`, with `phfeEval_sum` itself not yet declared
example {p : ℕ+} {l n d : ℕ} (C : PolyTensor p l (n * n) d)
    (x : Fin l → ZMod (p : ℕ)) (y : Fin n → ZMod (p : ℕ)) :
    phfeEval C x y = ∑ j : Fin n, ∑ k : Fin n,
      polyTensorEval C x (finProdFinEquiv (j, k)) * y j * y k := by
  exact?
