import TCSlib.Cryptography.AdvancedEncryption
import TCSlib.Cryptography.Pairing

/-! io-c0 Gate 51 probe: headline statements (`#check`/`#print`) and their axioms. Scratch only. -/

open TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption

-- GJLS21 Def 4.1 (syntax: raw bundle, efficient interface)
#check @FEScheme.Raw
#check @FEScheme
#check @FEScheme.Raw.Simulator.Raw
#check @FEScheme.Raw.Simulator
#check @FEScheme.Raw.SASimulator.Raw
#check @FEScheme.Raw.SASimulator
-- Def 4.2 (correctness)
#print FEScheme.Raw.Correct
#print FEScheme.Raw.CorrectExcept
#check @FEScheme.Raw.Correct.correctExcept_zero
-- Def 4.3 (simulation security) and the semi-adaptive notion
#check @FEScheme.Raw.simGame
#check @FEScheme.Raw.simAdv
#print FEScheme.Raw.SimSecureWith
#print FEScheme.Raw.SimSecure
#print FEScheme.Raw.SubexpSimSecureWith
#print FEScheme.Raw.SubexpSimSecure
#print FEScheme.Raw.SASimSecureWith
#print FEScheme.Raw.SASimSecure
#check @FEScheme.Raw.saGame
-- The derivation of Def 4.3 from the semi-adaptive bound
#check @TwoStage.toSA
#check @FEScheme.Raw.SASimulator.Raw.toSim
#check @FEScheme.Raw.expect_simGame_eq_saGame
#check @FEScheme.Raw.simAdv_eq_saSimAdv
-- Def 4.6 and the §9 class
#print Wee20.LinearEfficient
#check @phfeClass
#check @pad_one
-- Correctness and security headlines
#check @Wee20.wee20PHFE_raw_correct
#check @Wee20.wee20PHFE_raw_correctExcept_zero
#check @Wee20.wee20PHFE_saSimAdv_le
#check @Wee20.wee20PHFE_simAdv_le
#check @Wee20.wee20PHFE_saSimAdv_dlin_le
#check @Wee20.wee20PHFE_simAdv_dlin_le
#check @Wee20.wee20PHFE_raw_saSimSecureWith
#check @Wee20.wee20PHFE_raw_simSecureWith
#check @Wee20.wee20PHFE_raw_subexpSASimSecureWith
#check @Wee20.wee20PHFE_raw_subexpSimSecureWith
#check @Wee20.wee20PHFE_correct
#check @Wee20.wee20PHFE_correctExcept_zero
#check @Wee20.wee20PHFE_simSecure
#check @Wee20.wee20PHFE_saSimSecure
#check @Wee20.wee20PHFE_subexpSimSecure
#check @Wee20.wee20PHFE_subexpSASimSecure
#check @Wee20.wee20PHFE_gjls21
-- Axioms
#print axioms FEScheme.Raw.Correct.correctExcept_zero
#print axioms FEScheme.Raw.expect_simGame_eq_saGame
#print axioms FEScheme.Raw.simAdv_eq_saSimAdv
#print axioms pad_one
#print axioms Wee20.wee20PHFE_raw_correct
#print axioms Wee20.wee20PHFE_raw_correctExcept_zero
#print axioms Wee20.wee20PHFE_saSimAdv_le
#print axioms Wee20.wee20PHFE_simAdv_le
#print axioms Wee20.wee20PHFE_saSimAdv_dlin_le
#print axioms Wee20.wee20PHFE_simAdv_dlin_le
#print axioms Wee20.wee20PHFE_raw_saSimSecureWith
#print axioms Wee20.wee20PHFE_raw_simSecureWith
#print axioms Wee20.wee20PHFE_raw_subexpSASimSecureWith
#print axioms Wee20.wee20PHFE_raw_subexpSimSecureWith
#print axioms Wee20.wee20PHFE_correct
#print axioms Wee20.wee20PHFE_correctExcept_zero
#print axioms Wee20.wee20PHFE_simSecure
#print axioms Wee20.wee20PHFE_saSimSecure
#print axioms Wee20.wee20PHFE_subexpSimSecure
#print axioms Wee20.wee20PHFE_subexpSASimSecure
#print axioms Wee20.wee20PHFE_gjls21

-- control: a fresh sorry must report sorryAx
theorem ioc0SorryControl : (1 : ℕ) = 2 := sorry
#print axioms ioc0SorryControl
