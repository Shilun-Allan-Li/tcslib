/-
Copyright (c) 2026 TCSlib contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: TCSlib contributors
-/
import TCSlib.Cryptography.Pairing.Exponents
import TCSlib.Cryptography.Pairing.MatrixDH.Parameters
import TCSlib.Cryptography.Asymptotic.Adversary
import TCSlib.Cryptography.Games.Advantage
import TCSlib.Cryptography.Foundations.Subexponential
import Mathlib.Data.Fin.VecNotation

set_option maxHeartbeats 0
set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# The decisional linear assumption on symmetric bilinear groups

The primary experiment is the tuple form of DLIN in [JLS26, §1.1]: its real tuple contains
`g^a, g^b, g^(ar), g^(bs), g^(r+s)` and its random tuple replaces only the last coordinate
by `g^t`. The public input also includes the group description and the generator `g`, drawn
uniformly from the nonidentity source-group elements, as in the pairing library.

The matrix experiment follows [GJLS21, Definition 3.3], with the two source groups identified:
`A = ((a, 0), (0, b), (1, 1))`, real vector `A(r,s)` and a fully uniform random vector.
The two real laws agree. Their random laws need an explicit correction when `a` or `b` is
zero: conditioned on both being nonzero, multiplication by them bijects the first two
coordinates; the exceptional probability is `2/p - 1/p^2`. No unconditional equality of the
random laws is asserted.

## Main definitions

* `dlinStr`: public serialization of the description, generator and five group elements.
* `dlinMatrix`: the scalar DLIN matrix of [GJLS21, §3].
* `BilinearGen.DLINChallenge`, `BilinearGen.dlinEnc`: reachable public challenges and their
  encoding, without recording generator coins in the challenge.
* `BilinearGen.dlinGame`, `BilinearGen.dlinAdv`: the canonical tuple experiment and advantage.
* `BilinearGen.DLINAssumption`, `BilinearGen.SubexpDLIN`: polynomial and subexponential DLIN.
* `BilinearGen.dlinMatrixGame`, `BilinearGen.dlinMatrixAdv`, `BilinearGen.dlinMatrixSlack`:
  the matrix experiment and its explicit comparison with the canonical experiment.

## Main results

* `dlinMatrix_mulVec`: the real vector has coordinates `ar, bs, r+s`.
* `BilinearGen.dlinEnc_injective`, `BilinearGen.length_dlinEnc`: public encoding is faithful
  and has a fixed polynomial length on reachable challenges.
* `BilinearGen.dlinMatrixGame_real_accept`: the canonical and matrix real laws agree.
* `BilinearGen.dlinMatrixGame_random_gap_le`, `BilinearGen.dlinMatrixAdv_le`: the zero-
  coordinate event bounds the difference between the two presentations.

The generator's coin strings are sampled before the group-dependent draws. A typed challenge
stores the actual public description and a reachability proposition, rather than the coins
that produced it. Thus duplicate generator coin strings do not create duplicate public
objects. No finite-type instance on a dependent sum is introduced.

## References

* [JLS26] A. Jain, H. Lin, and A. Sahai, *Indistinguishability Obfuscation from Well-Founded
  Assumptions*, Journal of the ACM 73(1), Article 1, 2026, §1.1, p. 3 (DLIN), §1.4,
  pp. 7–8 (public-key PHFE), Theorem 5.1, p. 21 (symmetric DLIN implies bilateral DLIN).
* [GJLS21] R. Gay, A. Jain, H. Lin, and A. Sahai, *Indistinguishability Obfuscation from
  Simple-to-State Hard Problems: New Assumptions, New Techniques, and Simplification*,
  EUROCRYPT 2021; Cryptology ePrint Archive 2020/764, revision 2025-01-03, §3, p. 17
  (the DLIN matrix), Definition 3.3, p. 18 (bilateral DLIN).
-/

namespace TCSlib.Cryptography.Pairing

open Complexity Turing TCSlib.Cryptography.Games
open scoped Matrix

/-- Serialize a public DLIN tuple as the description followed by the generator and five
source-group points [JLS26, §1.1, p. 3]. The generator is explicit because it is randomized
in the library convention; the paper's generator is canonical. -/
def dlinStr {wG wT : ℕ} (B : BilinearGroup wG wT) (d : List Bool)
    (g a b u v w : B.G) : List Bool :=
  pairEncode d (pairEncode (List.ofFn (B.encG g))
    (pairEncode (List.ofFn (B.encG a)) (pairEncode (List.ofFn (B.encG b))
      (pairEncode (List.ofFn (B.encG u))
        (pairEncode (List.ofFn (B.encG v)) (List.ofFn (B.encG w)))))))

/-- The DLIN input is the nested pair of the description and the six encoded group points. -/
theorem dlinStr_eq {wG wT : ℕ} (B : BilinearGroup wG wT) (d : List Bool)
    (g a b u v w : B.G) :
    dlinStr B d g a b u v w =
      pairEncode d (pairEncode (List.ofFn (B.encG g))
        (pairEncode (List.ofFn (B.encG a)) (pairEncode (List.ofFn (B.encG b))
          (pairEncode (List.ofFn (B.encG u))
            (pairEncode (List.ofFn (B.encG v)) (List.ofFn (B.encG w))))))) := rfl

/-- Fixed-width group encodings make the tuple length depend only on the description length
and group width. This is serialization glue for [JLS26, §1.1, p. 3].

**Proof sketch.** Apply `length_pairEncode` to the six nested pairs and `List.length_ofFn`
to each group encoding; collect the coefficients of the fixed width. -/
theorem length_dlinStr {wG wT : ℕ} (B : BilinearGroup wG wT) (d : List Bool)
    (g a b u v w : B.G) :
    (dlinStr B d g a b u v w).length = 2 * d.length + 11 * wG + 12 := sorry

/-- The DLIN matrix has rows `(a,0)`, `(0,b)`, and `(1,1)`
[GJLS21, §3, p. 17, the distribution preceding Definition 3.3]. -/
def dlinMatrix {p : ℕ} (a b : ZMod p) : Matrix (Fin 3) (Fin 2) (ZMod p) :=
  ![![a, 0], ![0, b], ![1, 1]]

/-- The three rows of the scalar DLIN matrix are its displayed definition. -/
theorem dlinMatrix_eq {p : ℕ} (a b : ZMod p) :
    dlinMatrix a b = ![![a, 0], ![0, b], ![1, 1]] := rfl


-- io-c0 probe: the signature of `dlinMatrix_mulVec`, with `dlinMatrix_mulVec` itself not yet declared
example {p : ℕ} (a b r s : ZMod p) :
    dlinMatrix a b *ᵥ ![r, s] = ![a * r, b * s, r + s] := by
  exact?
