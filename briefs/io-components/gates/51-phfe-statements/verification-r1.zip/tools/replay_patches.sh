#!/usr/bin/env bash
# replay_patches.sh <scratch-repo> <base> <patchdir> <workdir>: (io-c0, new) rebuild the commit chain of a
# format-patch series without a worktree: per patch, `git mailinfo` for author/date/message, `git apply --cached`
# on a private index, `git write-tree`, `git commit-tree` with committer = author and committer date = author date.
# Empty patches (marker commits) keep the parent's tree. Prints one line per patch: rebuilt commit, tree.
set -eu
R=$1; BASE=$2; PD=$3; WD=$4; mkdir -p $WD
export GIT_DIR=$R GIT_INDEX_FILE=$WD/index
git read-tree $BASE; parent=$BASE
for p in $(ls $PD/0*.patch | sort); do
  git mailinfo -b $WD/msg $WD/patch < $p > $WD/info
  an=$(sed -n 's/^Author: //p' $WD/info); ae=$(sed -n 's/^Email: //p' $WD/info)
  ad=$(sed -n 's/^Date: //p' $WD/info); subj=$(sed -n 's/^Subject: //p' $WD/info)
  if [ -s $WD/patch ]; then git apply --cached --whitespace=nowarn $WD/patch; fi
  tree=$(git write-tree)
  { printf '%s\n' "$subj"; if [ -s $WD/msg ]; then printf '\n'; cat $WD/msg; fi; } > $WD/fullmsg
  c=$(GIT_AUTHOR_NAME="$an" GIT_AUTHOR_EMAIL="$ae" GIT_AUTHOR_DATE="$ad" GIT_COMMITTER_NAME="$an" \
      GIT_COMMITTER_EMAIL="$ae" GIT_COMMITTER_DATE="$ad" git commit-tree $tree -p $parent -F $WD/fullmsg)
  echo "$(basename $p) $c $tree"; parent=$c
done
rm -f $WD/index
