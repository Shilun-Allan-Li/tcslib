"""sorrycount.py <repo> <rev> <paths.txt>: (io-c0, new) count `sorry` tokens (\bsorry\b) per file at <rev>,
total lines and files; also tokens outside line/block comments (a crude comment stripper)."""
import sys, re, subprocess
repo, rev, paths = sys.argv[1:4]; T = Tc = L = 0
for p in [l.strip() for l in open(paths) if l.strip().endswith('.lean')]:
    s = subprocess.run(['git', '-C', repo, 'show', f'{rev}:{p}'], capture_output=True, check=True).stdout.decode()
    nc = re.sub(r'/-.*?-/', '', s, flags=re.S); nc = re.sub(r'--[^\n]*', '', nc)
    t = len(re.findall(r'\bsorry\b', s)); tc = len(re.findall(r'\bsorry\b', nc)); T += t; Tc += tc; L += s.count('\n')
    print(f'{t}\t{tc}\t{p}')
print(f'TOTAL tokens {T}; outside comments {Tc}; lines {L}')
