"""censum.py <census.log> <out.tsv>: (io-c0, new) summarize the Census probe's ROW lines.
Columns: name, module, kind, private, internal, aux, ranged, direct-sorryAx, nonstandard-count, axioms.
public = not private, not internal (no `_`-component), not an auxiliary recursor/noConfusion/matcher/recursor."""
import sys, collections
rows = []
for l in open(sys.argv[1], encoding='utf-8', errors='replace'):
    l = l.rstrip('\n')
    if 'ROW\t' in l:
        f = l[l.index('ROW\t') + 4:].split('\t')
        rows.append(dict(name=f[0], mod=f[1], kind=f[2], priv=f[3] == 'true', internal=f[4] == 'true',
                         aux=f[5] == 'true', ranged=f[6] == 'true', direct=f[7] == 'true', nonstd=int(f[8]), ax=f[9]))
    elif l.startswith('MODULES') or l.startswith('TOTAL') or 'MODULES ' in l or 'TOTAL ' in l:
        print(l.strip())
with open(sys.argv[2], 'w') as o:
    o.write('name\tmodule\tkind\tprivate\tinternal\taux\tranged\tdirect\tnonstd\taxioms\n')
    for r in sorted(rows, key=lambda r: r['name']):
        o.write('\t'.join(str(r[k]) for k in ('name', 'mod', 'kind', 'priv', 'internal', 'aux', 'ranged', 'direct', 'nonstd', 'ax')) + '\n')
def cls(r):
    a = r['ax'].split(',') if r['ax'] else []
    return 'NONSTANDARD' if r['nonstd'] else ('sorryAx' if 'sorryAx' in a else 'standard-only')
def show(title, rs):
    c = collections.Counter(cls(r) for r in rs)
    print(f"{title}: {len(rs)}; standard-only {c['standard-only']}; via sorryAx {c['sorryAx']}; NONSTANDARD {c['NONSTANDARD']}")
show('all stored constants', rows)
pub = [r for r in rows if not r['priv'] and not r['internal'] and not r['aux']]
show('public (non-private, non-internal, non-auxiliary)', pub)
show('  of which source-declared (have a declaration range)', [r for r in pub if r['ranged']])
show('  public theorems', [r for r in pub if r['kind'] == 'thm'])
show('  public non-theorems', [r for r in pub if r['kind'] != 'thm'])
d = [r for r in rows if r['direct']]
print(f"direct sorryAx (value/type mentions sorryAx): {len(d)}; kinds {dict(collections.Counter(r['kind'] for r in d))}; "
      f"public {sum(1 for r in d if r in pub)}")
tr = [r for r in rows if cls(r) == 'sorryAx' and not r['direct']]
print(f"transitive-only sorryAx dependents: {len(tr)} (public {sum(1 for r in tr if r in pub)}; public theorems "
      f"{sum(1 for r in tr if r in pub and r['kind']=='thm')}; kinds {dict(collections.Counter(r['kind'] for r in tr))})")
print('axiom sets:', dict(collections.Counter(r['ax'] for r in rows)))
print('by kind:', dict(collections.Counter(r['kind'] for r in rows)))
for r in rows:
    if r['nonstd']: print('NONSTANDARD', r['name'], r['ax'])
