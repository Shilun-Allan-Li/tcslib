"""mlmissing.py <mathlib-root> <module>...: (io-c0, new) the missing-olean upstream of Mathlib modules in the pinned
package build (imports-first), reading `import` lines from the pinned sources."""
import sys, os, re
root = sys.argv[1]; lib = os.path.join(root, '.lake/build/lib/lean'); seen = set(); order = []
def visit(m):
    if m in seen: return
    seen.add(m); p = m.replace('.', '/')
    if os.path.exists(os.path.join(lib, p + '.olean')): return
    src = open(os.path.join(root, p + '.lean'), encoding='utf-8').read()
    for i in re.findall(r'^(?:public\s+)?import\s+(\S+)', src, re.M):
        if i.startswith('Mathlib.'): visit(i)
        elif not os.path.exists(os.path.join(lib, i.replace('.', '/') + '.olean')): print('non-Mathlib import, check:', i)
    order.append(m)
for m in sys.argv[2:]: visit(m)
print('\n'.join(order))
