"""axparse.py <log>: (io-c0, new) parse `#print axioms` output (multi-line lists) into `name<TAB>axioms` rows,
flagging any axiom outside {propext, Classical.choice, Quot.sound, sorryAx}."""
import sys, re
t = open(sys.argv[1], encoding='utf-8', errors='replace').read()
std = {'propext', 'Classical.choice', 'Quot.sound'}
rows = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", t, re.S)
rows += [(n, '') for n in re.findall(r"'([^']+)' does not depend on any axioms", t)]
for n, a in rows:
    ax = sorted(x.strip() for x in a.replace('\n', ' ').split(',') if x.strip())
    other = [x for x in ax if x not in std and x != 'sorryAx']
    cls = 'NONSTANDARD' if other else ('sorryAx' if 'sorryAx' in ax else 'standard-only')
    print(f'{n}\t{",".join(ax)}\t{cls}')
print(f'# {len(rows)} prints', file=sys.stderr)
