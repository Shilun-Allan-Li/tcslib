#!/usr/bin/env bash
# accept.sh <job dir> <rev> <out tree>: (io-c0, new) recipe step 5 for one replay: permod, stateplan update + check over the
# full order, link counts of rebuilt oleans, and the queue/new-module sorry tallies. Writes <job>/accept/.
set -u
J=$1; REV=$2; OUT=$3; W=$(dirname $J); T=$W/recipe/olean-advance-a6d01b1b/tools-used; R=$W/git.git; A=$J/accept; mkdir -p $A
python3 -I $T/permod.py $J/build $A/permod.tsv | tee $A/permod.txt
cp $J/plan/state-start.json $J/plan/state.json
python3 -I $T/stateplan.py update $R $REV $J/plan/state.json $J/build/results.jsonl $OUT | tee $A/update.txt
python3 -I $T/stateplan.py check $R $REV $J/plan/full-order.txt $J/plan/state.json $OUT $A/check-out | tee $A/check.txt
python3 -I $T/stateplan.py check $R $REV $J/plan/order/order-noroot.txt $J/plan/state.json $OUT $A/check-closure-out | tee -a $A/check.txt
n=0; bad=0; while read m; do c=$(stat -c %h $OUT/$m.olean); n=$((n+1)); [ "$c" = 1 ] || { bad=$((bad+1)); echo "LINKS $c $m"; }; done < $J/plan/plan-full/queue.txt
echo "rebuilt $n; link count != 1: $bad" | tee $A/links.txt
echo "tree files with link count 1 (non-Mathlib): $(find $OUT -type f -links 1 ! -path "$OUT/Mathlib/*" | wc -l)" | tee -a $A/links.txt
echo "tree regular files: $(find $OUT -type f | wc -l); symlinks: $(find $OUT -type l | wc -l)" | tee -a $A/links.txt
