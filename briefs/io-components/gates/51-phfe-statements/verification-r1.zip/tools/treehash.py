r"""treehash.py (io-c0, new): rehash an olean tree that holds symlinks (snapmap.py refuses them).
  treehash.py make   <dir> <map.tsv>   one line per entry: F<TAB>path<TAB>sha256 (regular file) or L<TAB>path<TAB>target (symlink)
  treehash.py verify <dir> <map.tsv>   prints extra/changed/missing counts and RESULT OK iff all 0."""
import sys, os, hashlib
def scan(d):
    out = {}
    for r, ds, fs in os.walk(d):
        for f in fs + [x for x in ds if os.path.islink(os.path.join(r, x))]:
            p = os.path.join(r, f); rel = os.path.relpath(p, d)
            if os.path.islink(p): out[rel] = ('L', os.readlink(p))
            else:
                h = hashlib.sha256()
                with open(p, 'rb') as fh:
                    for b in iter(lambda: fh.read(1 << 20), b''): h.update(b)
                out[rel] = ('F', h.hexdigest())
    return out
cmd, d, mp = sys.argv[1:4]; S = scan(d)
if cmd == 'make':
    with open(mp, 'w') as o:
        for k in sorted(S): o.write(f'{S[k][0]}\t{k}\t{S[k][1]}\n')
    print(f'entries {len(S)}; files {sum(v[0]=="F" for v in S.values())}; symlinks {sum(v[0]=="L" for v in S.values())}; map sha256 {hashlib.sha256(open(mp,"rb").read()).hexdigest()}')
else:
    M = {}
    for l in open(mp):
        t, p, v = l.rstrip('\n').split('\t'); M[p] = (t, v)
    extra = sorted(set(S) - set(M)); missing = sorted(set(M) - set(S)); changed = sorted(k for k in S if k in M and S[k] != M[k])
    for n, xs in (('extra', extra), ('changed', changed), ('missing', missing)):
        for x in xs[:20]: print(n, x)
    print(f'map {mp} sha256 {hashlib.sha256(open(mp,"rb").read()).hexdigest()}; on disk {len(S)}; extra {len(extra)}; changed {len(changed)}; missing {len(missing)}; RESULT {"OK" if not (extra or changed or missing) else "FAIL"}')
