r"""mkprefix.py <src.lean> <decl> <out.lean> [tactic]: (io-c0, new) exact?-style duplication probe for a delivered lemma.
Copies <src.lean> up to (not including) the line that starts `theorem <decl>` (so the environment is exactly the module
prefix before the lemma, and the lemma itself is NOT in scope), then appends the lemma's own signature as an `example`
closed by <tactic> (default `exact?`). The signature is the text from `theorem <decl>` to the first `:=`
at bracket depth 0. A docstring left dangling just before the cut is dropped."""
import sys, re
src, decl, out = sys.argv[1:4]; tac = sys.argv[4] if len(sys.argv) > 4 else 'exact?'
lines = open(src, encoding='utf-8').read().split('\n')
idx = [i for i, l in enumerate(lines) if re.match(r'^(private\s+)?theorem\s+' + re.escape(decl) + r'(\s|$)', l)]
assert len(idx) == 1, (decl, idx)
i = idx[0]; text = '\n'.join(lines[i:]); depth = 0; j = None
for k, ch in enumerate(text):
    if ch in '([{⟨': depth += 1
    elif ch in ')]}⟩': depth -= 1
    elif ch == ':' and depth == 0 and text[k:k+2] == ':=': j = k; break
sig = text[:j].rstrip(); sig = re.sub(r'^(private\s+)?theorem\s+' + re.escape(decl), 'example', sig)
pre = lines[:i]
# drop a dangling docstring that belonged to the lemma
k = len(pre) - 1
while k >= 0 and pre[k].strip() == '': k -= 1
if k >= 0 and pre[k].rstrip().endswith('-/'):
    s = k
    while s >= 0 and '/--' not in pre[s]: s -= 1
    if s >= 0: pre = pre[:s]
body = '\n'.join(pre) + f'\n\n-- io-c0 probe: the signature of `{decl}`, with `{decl}` itself not yet declared\n' + sig + f' := by\n  {tac}\n'
open(out, 'w', encoding='utf-8').write(body); print(out, len(pre), 'prefix lines')
