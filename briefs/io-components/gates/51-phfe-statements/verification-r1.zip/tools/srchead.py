"""srchead.py <source-head.json> <results.jsonl> <tree>: (io-c0, new) compare the gate's src_files SHA-256 with the
replayed export (every listed path, .lean or not) and with the runner's recorded source hashes."""
import sys, json, hashlib, os
sh = json.load(open(sys.argv[1])); mine = {}
for l in open(sys.argv[2]):
    r = json.loads(l)
    if 'module' in r: mine[r['module'] + '.lean'] = r['source_sha256']
bad = []; n = 0
for f in sh['src_files']:
    p = f['path']; n += 1
    h = hashlib.sha256(open(os.path.join(sys.argv[3], p), 'rb').read()).hexdigest()
    if h != f['sha256'] or (p in mine and mine[p] != h): bad.append(p)
print(f'gate src_files {n}; export and runner match {n - len(bad)}; mismatches {bad}; totals {sh["totals"]}')
