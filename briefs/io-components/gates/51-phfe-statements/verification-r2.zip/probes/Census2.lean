import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Classes
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Correctness
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Efficient
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Raw
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Simulator
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FiniteRandomness
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.Defs
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.Layered
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.PathAlgebra
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.PrefixAlgebra
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PolynomialTensorAlgebra
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Run
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Data
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.FromTwoStage
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Games
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Security
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Simulator
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation.Games
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation.Security
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation.TwoStage
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Linear
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearCorrect
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Data
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Endpoint
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Fresh
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Games
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Keys
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Reductions
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Slack
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Theorems
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSimulator
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Adapter
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.CommittedSimulator
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Core
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Correctness
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Data
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Embedding
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Encodings
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Headlines
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Raw
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Security
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Simulator
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Widths
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Quadratic
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticCorrect
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Advice
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Compose
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Data
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Derived
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Fresh
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Games
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Reduction
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Theorems
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSimulator
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Assembly
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.CircuitEfficiency
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Garbling
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.LinearEfficiency
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.MatrixDH
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Scheme
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Sim
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.WireDraws
import TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.WireLemmas
import TCSlib.Cryptography.Pairing.Exponents
import TCSlib.Cryptography.Pairing.Linear
import TCSlib.Cryptography.Pairing.MatrixDH
import TCSlib.Cryptography.Pairing.MatrixDH.AdaptiveShear
import TCSlib.Cryptography.Pairing.MatrixDH.ColumnLaws
import TCSlib.Cryptography.Pairing.MatrixDH.Defs
import TCSlib.Cryptography.Pairing.MatrixDH.Diagonal
import TCSlib.Cryptography.Pairing.MatrixDH.FiniteLinear
import TCSlib.Cryptography.Pairing.MatrixDH.Hardness
import TCSlib.Cryptography.Pairing.MatrixDH.Parameters
import TCSlib.Cryptography.Pairing.MatrixDH.SelfReduction
import TCSlib.Cryptography.Pairing.MatrixDH.Widths

/-! io-r2 Gate 51 r2 probe: axiom census of every constant stored by the 86 new modules. Scratch only. -/

namespace IOC0Census

open Lean in
def newMods : Array Name := #[
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Classes,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Correctness,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Efficient,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Raw,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Defs.Simulator,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FiniteRandomness,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.Defs,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.Layered,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.PathAlgebra,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PartialGarbling.PrefixAlgebra,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.PolynomialTensorAlgebra,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Run,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Data,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.FromTwoStage,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Games,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Security,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.SemiAdaptive.Simulator,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation.Games,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation.Security,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Simulation.TwoStage,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Linear,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearCorrect,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Data,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Endpoint,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Fresh,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Games,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Keys,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Reductions,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Slack,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSecurity.Theorems,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearSimulator,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Adapter,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.CommittedSimulator,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Core,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Correctness,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Data,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Embedding,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Encodings,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Headlines,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Raw,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Security,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Simulator,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.Widths,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Quadratic,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticCorrect,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Advice,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Compose,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Data,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Derived,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Fresh,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Games,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Reduction,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSecurity.Theorems,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.QuadraticSimulator,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Assembly,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.CircuitEfficiency,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Garbling,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.LinearEfficiency,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.MatrixDH,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Scheme,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets.Sim,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.WireDraws,
  `TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.WireLemmas,
  `TCSlib.Cryptography.Pairing.Exponents,
  `TCSlib.Cryptography.Pairing.Linear,
  `TCSlib.Cryptography.Pairing.MatrixDH,
  `TCSlib.Cryptography.Pairing.MatrixDH.AdaptiveShear,
  `TCSlib.Cryptography.Pairing.MatrixDH.ColumnLaws,
  `TCSlib.Cryptography.Pairing.MatrixDH.Defs,
  `TCSlib.Cryptography.Pairing.MatrixDH.Diagonal,
  `TCSlib.Cryptography.Pairing.MatrixDH.FiniteLinear,
  `TCSlib.Cryptography.Pairing.MatrixDH.Hardness,
  `TCSlib.Cryptography.Pairing.MatrixDH.Parameters,
  `TCSlib.Cryptography.Pairing.MatrixDH.SelfReduction,
  `TCSlib.Cryptography.Pairing.MatrixDH.Widths
]

end IOC0Census


/-- io-c0: memoized axiom collection mirroring `Lean.CollectAxioms.collect` (same edges per constant kind).
Results are memoized only when no strictly-earlier on-stack constant was reached (Tarjan-style low link),
so cyclic (inductive/constructor) dependencies never memoize a partial set. -/
partial def IOC0Census.axGo (env : Lean.Environment) (depth : Nat) (c : Lean.Name) :
    StateM (Std.HashMap Lean.Name (Array Lean.Name) × Std.HashMap Lean.Name Nat)
      (Array Lean.Name × Nat) := do
  let inf := 1000000000
  let (memo, onStack) ← get
  if let some s := memo[c]? then return (s, inf)
  if let some d := onStack[c]? then return (#[], d)
  modify fun (m, st) => (m, st.insert c depth)
  let mut acc : Array Lean.Name := #[]
  let mut low := inf
  let deps : Array Lean.Name := match env.find? c with
    | some (.axiomInfo v) => v.type.getUsedConstants
    | some (.defnInfo v) => v.type.getUsedConstants ++ v.value.getUsedConstants
    | some (.thmInfo v) => v.type.getUsedConstants ++ v.value.getUsedConstants
    | some (.opaqueInfo v) => v.type.getUsedConstants ++ v.value.getUsedConstants
    | some (.quotInfo _) => #[]
    | some (.ctorInfo v) => v.type.getUsedConstants
    | some (.recInfo v) => v.type.getUsedConstants
    | some (.inductInfo v) => v.type.getUsedConstants ++ v.ctors.toArray
    | none => #[]
  if let some (.axiomInfo _) := env.find? c then acc := acc.push c
  for d in deps do
    let (s, l) ← IOC0Census.axGo env (depth + 1) d
    for a in s do
      unless acc.contains a do acc := acc.push a
    low := min low l
  modify fun (m, st) => (m, st.erase c)
  if low ≥ depth then modify fun (m, st) => (m.insert c acc, st)
  return (acc, low)

open Lean Elab Command Meta in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let mods := IOC0Census.newMods
  let present := mods.filter fun m => env.header.moduleNames.contains m
  let mut out : Array String := #[s!"MODULES {present.size} of {mods.size}"]
  let std : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut n := 0
  let mut st : Std.HashMap Name (Array Name) × Std.HashMap Name Nat := ({}, {})
  for (c, ci) in env.constants.map₁.toList do
    let some idx := env.getModuleIdxFor? c | continue
    let mn := env.header.moduleNames[idx.toNat]!
    unless mods.contains mn do continue
    n := n + 1
    let ((axs, _), st') := (IOC0Census.axGo env 0 c).run st
    st := st'
    let kind := match ci with
      | .thmInfo _ => "thm" | .defnInfo _ => "def" | .axiomInfo _ => "axiom"
      | .inductInfo _ => "induct" | .ctorInfo _ => "ctor" | .recInfo _ => "rec"
      | .opaqueInfo _ => "opaque" | .quotInfo _ => "quot"
    let priv := isPrivateName c
    let internal := c.isInternal
    let aux := isAuxRecursor env c || isNoConfusion env c || (Meta.isMatcherCore env c) ||
      (match ci with | .recInfo _ => true | _ => false)
    let ranged := (← findDeclarationRangesCore? c).isSome
    let direct := ci.getUsedConstantsAsSet.contains ``sorryAx
    let nonstd := axs.filter fun a => !(std.contains a) && a != ``sorryAx
    let axStr := ",".intercalate ((axs.qsort (·.toString < ·.toString)).toList.map toString)
    out := out.push s!"ROW\t{c}\t{mn}\t{kind}\t{priv}\t{internal}\t{aux}\t{ranged}\t{direct}\t{nonstd.size}\t{axStr}"
  out := out.push s!"TOTAL {n}"
  logInfo (String.intercalate "\n" out.toList)
