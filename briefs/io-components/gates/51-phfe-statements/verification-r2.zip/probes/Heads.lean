import TCSlib.Cryptography.AdvancedEncryption
import TCSlib.Cryptography.Pairing
import TCSlib.Cryptography.Encryption.PrivateKey.EnsembleSecurity

/-! io-r2 Gate 51 r2 probe: repaired statements (`#check`/`#print`), spec-shape `example`s and axioms.
Scratch only; nothing here is part of the delivery. -/

open TCSlib.Cryptography TCSlib.Cryptography.Pairing TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption
open Complexity TCSlib.Cryptography.CoinSampling Turing

set_option autoImplicit false

-- R2 (G51-03): the new fields of both efficient simulator interfaces
#check @FEScheme.Raw.Simulator.state_bounded
#check @FEScheme.Raw.Simulator.value_bounded
#check @FEScheme.Raw.SASimulator.state_bounded
#check @FEScheme.Raw.SASimulator.value_bounded
#print FEScheme.Raw.Simulator
#print FEScheme.Raw.SASimulator
-- R2: the fields have exactly the spec's statements (with the r1 fixed-width `List.ofFn` adapter for the state word)
example {C : FnClass} {S : FEScheme.Raw C} (Sim : FEScheme.Raw.Simulator S) :
    ∃ b : PolyExpr, ∀ κ (pp : PublicParams S.G κ) (st : Sim.St κ pp),
      (List.ofFn (Sim.encSt κ pp st)).length ≤ b.eval κ := Sim.state_bounded
example {C : FnClass} {S : FEScheme.Raw C} (Sim : FEScheme.Raw.Simulator S) :
    ∃ b : PolyExpr, ∀ κ (pp : PublicParams S.G κ)
      (v : C.Out κ (S.cprm κ pp)),
      (C.encValue κ (S.cprm κ pp) v).length ≤ b.eval κ := Sim.value_bounded
example {C : FnClass} {S : FEScheme.Raw C} (Sim : FEScheme.Raw.SASimulator S) :
    ∃ b : PolyExpr, ∀ κ (pp : PublicParams S.G κ) (st : Sim.St κ pp),
      (List.ofFn (Sim.encSt κ pp st)).length ≤ b.eval κ := Sim.state_bounded
example {C : FnClass} {S : FEScheme.Raw C} (Sim : FEScheme.Raw.SASimulator S) :
    ∃ b : PolyExpr, ∀ κ (pp : PublicParams S.G κ)
      (v : C.Out κ (S.cprm κ pp)),
      (C.encValue κ (S.cprm κ pp) v).length ≤ b.eval κ := Sim.value_bounded
-- R2: SimTargets' four bound fields
#check @Wee20.SimTargets.sim_state_bounded
#check @Wee20.SimTargets.sim_value_bounded
#check @Wee20.SimTargets.sa_state_bounded
#check @Wee20.SimTargets.sa_value_bounded
#check @Wee20.simTargets_iff
-- R2: each SimTargets bound field is discharged by the corresponding proved concrete lemma
example (G : BilinearGen) (ℓ n : PolyExpr) (d : ℕ) (hT : Wee20.SimTargets G ℓ n d) :
    type_of% hT.sim_state_bounded :=
  Wee20.wee20Sim_raw_state_bounded G ℓ n d (layeredPG_raw ℓ (n.mul n) d)
example (G : BilinearGen) (ℓ n : PolyExpr) (d : ℕ) (hT : Wee20.SimTargets G ℓ n d) :
    type_of% hT.sim_value_bounded :=
  Wee20.wee20Sim_raw_value_bounded G ℓ n d (layeredPG_raw ℓ (n.mul n) d)
example (G : BilinearGen) (ℓ n : PolyExpr) (d : ℕ) (hT : Wee20.SimTargets G ℓ n d) :
    type_of% hT.sa_state_bounded :=
  Wee20.wee20SASim_raw_state_bounded G ℓ n d (layeredPG_raw ℓ (n.mul n) d)
example (G : BilinearGen) (ℓ n : PolyExpr) (d : ℕ) (hT : Wee20.SimTargets G ℓ n d) :
    type_of% hT.sa_value_bounded :=
  Wee20.wee20SASim_raw_value_bounded G ℓ n d (layeredPG_raw ℓ (n.mul n) d)
-- R2: the concrete lemmas
#check @Wee20.wee20Sim_raw_state_bounded
#check @Wee20.wee20Sim_raw_value_bounded
#check @Wee20.wee20SASim_raw_state_bounded
#check @Wee20.wee20SASim_raw_value_bounded
#check @Wee20.wee20PHFE_raw_value_bounded
#check @Wee20.PHFE.valueEncoding_length_le
-- R3 (G51-04): sampler parameter maps
#check @FEScheme.pubGen_eff
#check @FEScheme.setup_eff
#check @FEScheme.enc_eff
#check @FEScheme.keyGen_eff
#check @FEScheme.Raw.Simulator.setup_eff
#check @FEScheme.Raw.Simulator.enc_eff
#check @FEScheme.Raw.Simulator.key_eff
#check @FEScheme.Raw.SASimulator.setup_eff
#check @FEScheme.Raw.SASimulator.enc_eff
#check @FEScheme.Raw.SASimulator.key_eff
#check @Wee20.SchemeTargets.pubGen_eff
#check @Wee20.SchemeTargets.setup_eff
#check @Wee20.SchemeTargets.enc_eff
#check @Wee20.SchemeTargets.keyGen_eff
#check @Wee20.schemeTargets_iff
#check @Wee20.SimTargets.sim_setup_eff
#check @Wee20.SimTargets.sim_enc_eff
#check @Wee20.SimTargets.sim_key_eff
#check @Wee20.SimTargets.sa_setup_eff
#check @Wee20.SimTargets.sa_enc_eff
#check @Wee20.SimTargets.sa_key_eff
-- R3: the spec's exact pubGen_eff map
example (C : FnClass) (S : FEScheme C) : SamplesEfficiently
    (fun κ (d : GroupDescription S.G κ) => NUPPT.advInput κ d.val)
    (fun κ d (g : GeneratorDraw S.G κ d) => List.ofFn ((S.G.group κ d.val).encG g.val))
    (fun κ _ (pp : PublicParams S.G κ) => pp.encode) (publicParamsCore S.G) := S.pubGen_eff
#check @SamplesEfficiently
#check @NUPPT.advInput
-- R1 (G51-02): the circuit target, its reader, the Targets field and the headline
#print Wee20.CircuitLinearEfficient
#check @Wee20.circuitLinearEfficient_iff
#check @Wee20.Targets.circuitLinear
#check @Wee20.targets_iff
#print Wee20.Targets
#check @Wee20.wee20PHFE_gjls21
#print BoolCircuit.MultiDAGCircuit.size
#print BoolCircuit.MultiDAGCircuit.IsFaninTwo
#check @BoolCircuit.MultiDAGCircuit.eval
-- R1: the third conjunct of the headline is exactly `CircuitLinearEfficient G`
example (G : BilinearGen) (ℓ n : PolyExpr) (d : ℕ) (hT : Wee20.Targets G ℓ n d) (p : ℕ → ℕ)
    (hp : ∀ κ r, (G.inst κ r).order = p κ) (hpb : ∀ κ, 2 ^ κ ≤ p κ)
    (hR : Wee20.Wee20Realizable43 G ℓ n d (layeredPG_raw ℓ (n.mul n) d) p hp)
    (h : G.DLINAssumption) : Wee20.CircuitLinearEfficient G :=
  (Wee20.wee20PHFE_gjls21 G ℓ n d hT p hp hpb hR h).2.2
#print Wee20.LinearEfficient
-- G51-05: MddhPreTargets without the `_D` binder
#print Wee20.MddhPreTargets
#check @Wee20.mddhPreTargets_iff
#check @Wee20.mddhRealizable_of_preTarget
-- G51-09: the replaced folds are `encodeList`
#print PrivateKeyScheme.encodeList
example : (fun l : List (List Bool) => l.foldr pairEncode []) = PrivateKeyScheme.encodeList := by
  funext l
  induction l with
  | nil => rfl
  | cons m ms ih => simp only [List.foldr_cons, PrivateKeyScheme.encodeList, ih]
#check @FEScheme.Raw.Omega.encode_eq
#check @FEScheme.Raw.viewWord_eq
#check @FEScheme.Raw.viewWordBits_eq
#check @Wee20.Wire.quadraticEncDraw_eq
-- G51-01: familywise SimSecureWith (formal quantifiers unchanged)
#print FEScheme.Raw.SimSecureWith
-- Axioms: every changed (51) and added (8) declaration of r2, the PHFE headlines, and the 3 proof/sketch-only changes
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Omega.encode
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Omega.encode_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator.Raw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator.Raw.encInputWord
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator.Raw.encInputWord_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator.Raw.keyInputWord
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator.Raw.keyInputWord_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SASimulator.Raw.toSim
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.SimSecureWith
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Simulator
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Simulator.Raw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Simulator.Raw.encInputWord
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Simulator.Raw.encInputWord_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Simulator.Raw.keyInputWord
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.Simulator.Raw.keyInputWord_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.viewWordBits
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.viewWordBits_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.FEScheme.Raw.viewWord_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.LinearEfficient
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.MddhPreTargets
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.SchemeTargets
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.SimTargets
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Targets
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearKeyDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearKeyDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSetupDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSetupDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSimKeyDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSimKeyDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSimSetupDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSimSetupDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSimState
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.linearSimState_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticEncDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticEncDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticSetupDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticSetupDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticSimSetupDraw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticSimSetupDraw_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticSimState
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.Wire.quadraticSimState_eq
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.mddhPreTargets_iff
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.schemeTargets_iff
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.simTargets_iff
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.targets_iff
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_gjls21
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20SASim
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20SASim_raw
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20Sim
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20Sim_raw_state_bounded
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20Sim_raw_value_bounded
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.valueEncoding_length_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_value_bounded
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20SASim_raw_state_bounded
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20SASim_raw_value_bounded
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.CircuitLinearEfficient
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.circuitLinearEfficient_iff
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_correct
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_correctExcept_zero
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_saSimAdv_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_simAdv_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_saSimAdv_dlin_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_simAdv_dlin_le
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_saSimSecureWith
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_simSecureWith
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_subexpSASimSecureWith
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_raw_subexpSimSecureWith
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_correct
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_correctExcept_zero
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_simSecure
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_saSimSecure
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_subexpSimSecure
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.wee20PHFE_subexpSASimSecure
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.mddhRealizable_of_preTarget
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.quadraticSimState_injective
#print axioms TCSlib.Cryptography.AdvancedEncryption.FunctionalEncryption.Wee20.PHFE.quadraticSimState_length

-- control: a fresh sorry must report sorryAx
theorem ior2SorryControl : (1 : ℕ) = 2 := sorry
#print axioms ior2SorryControl
