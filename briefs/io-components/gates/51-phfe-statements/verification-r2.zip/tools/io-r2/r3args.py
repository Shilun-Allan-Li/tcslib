r"""r3args.py <old-tree> <new-tree> <paths.txt>: (io-r2, new) per file, the ordered `SamplesEfficiently` applications
(comments stripped), each split into its four explicit arguments (balanced (), or one token). Compares old vs new:
arguments 2-4 must be equal after whitespace normalisation; argument 1 must become `fun κ π => NUPPT.advInput κ (y κ π)`
for the old y (accepted forms: the old lambda body wrapped, or an old identifier y applied to κ π)."""
import sys, re, os
def apps(path):
    if not os.path.exists(path): return []
    s = open(path, encoding='utf-8').read()
    s = re.sub(r'/-.*?-/', ' ', s, flags=re.S); s = re.sub(r'--[^\n]*', '', s); out = []
    for m in re.finditer(r'\bSamplesEfficiently\b', s):
        i = m.end(); args = []
        while len(args) < 4:
            while s[i].isspace(): i += 1
            if s[i] == '(':
                dep, j = 0, i
                while True:
                    if s[j] == '(': dep += 1
                    elif s[j] == ')':
                        dep -= 1
                        if dep == 0: break
                    j += 1
                if s[j + 1] == '.':
                    t = re.match(r'[^\s()]+', s[j + 1:]).group(0); args.append(s[i:j + 1] + t); i = j + 1 + len(t)
                else:
                    args.append(' '.join(s[i + 1:j].split())); i = j + 1
            else:
                t = re.match(r'[^\s()]+', s[i:]).group(0); args.append(t); i += len(t)
        out.append(args)
    return out
def norm(x): return re.sub(r'\s+', ' ', x.replace('( ', '(').replace(' )', ')')).strip()
old, new, paths = sys.argv[1:4]; tot = same = 0
for p in [l.strip() for l in open(paths) if l.strip().endswith('.lean')]:
    A, B = apps(os.path.join(old, p)), apps(os.path.join(new, p))
    if not A and not B: continue
    print(f'{p.split("FunctionalEncryption/")[-1]}: old {len(A)} new {len(B)}')
    for a, b in zip(A, B):
        tot += 1; r24 = [norm(x) for x in a[1:]] == [norm(x) for x in b[1:]]
        m = re.match(r'fun (\w+) (.*?) => NUPPT\.advInput \1 (.*)$', b[0])
        ok1 = False
        if m:
            body = m.group(3)
            if body.startswith('(') and body.endswith(')'): body = body[1:-1]
            mo = re.match(r'fun (\w+) (.*?) => (.*)$', a[0])
            if mo: ok1 = norm(mo.group(3)) == norm(body) and mo.group(1) == m.group(1)
            else: ok1 = norm(body) in (norm(f'{a[0]} {m.group(1)} {m.group(2)}'),)
        same += r24 and ok1
        print(f"  {'OK ' if r24 and ok1 else 'BAD'} args2-4 equal={r24} arg1 = advInput(old)={ok1}")
print(f'TOTAL {tot}; conforming {same}')
