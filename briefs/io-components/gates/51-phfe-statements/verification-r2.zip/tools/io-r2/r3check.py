r"""r3check.py <tree> <paths.txt>: (io-r2, new) for every `SamplesEfficiently` token in the listed .lean files (comments
stripped), extract the first explicit argument (balanced parentheses, or one identifier token) and test that it has the
form `fun <κ> <binders> => NUPPT.advInput <κ> …` with the same κ name. Prints one line per occurrence and a summary."""
import sys, re, os
tree, paths = sys.argv[1:3]; tot = ok = 0
for p in [l.strip() for l in open(paths) if l.strip().endswith('.lean')]:
    s = open(os.path.join(tree, p), encoding='utf-8').read()
    s = re.sub(r'/-.*?-/', lambda m: re.sub(r'[^\n]', ' ', m.group(0)), s, flags=re.S); s = re.sub(r'--[^\n]*', '', s)
    for m in re.finditer(r'\bSamplesEfficiently\b', s):
        i = m.end()
        while s[i].isspace(): i += 1
        if s[i] == '(':
            dep, j = 0, i
            while True:
                if s[j] == '(': dep += 1
                elif s[j] == ')':
                    dep -= 1
                    if dep == 0: break
                j += 1
            arg = s[i + 1:j]
        else:
            arg = re.match(r'\S+', s[i:]).group(0)
        a = ' '.join(arg.split()); tot += 1
        mm = re.match(r'fun (\w+)\b.*?=> NUPPT\.advInput (\w+)\b', a)
        good = bool(mm and mm.group(1) == mm.group(2)); ok += good
        line = s.count('\n', 0, m.start()) + 1
        print(f"{'OK ' if good else 'BAD'}\t{p.split('FunctionalEncryption/')[-1]}:{line}\t{a[:150]}")
print(f'TOTAL {tot}; kappa-prefixed {ok}; other {tot - ok}')
