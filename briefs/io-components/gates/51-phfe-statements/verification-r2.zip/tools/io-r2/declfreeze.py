r"""declfreeze.py <old-root> <new-root> <paths.txt> <out.tsv>: (io-r2, new) text freeze by declaration.
Per file (paths relative to both roots; a file may be missing on one side), every column-0 declaration
(theorem/lemma/def/abbrev/structure/class/inductive/instance/opaque/axiom, with modifiers/attributes) is keyed by its
namespace-qualified name (instances/examples without a name: file + ordinal). Fields:
  header = theorem/lemma: text from the keyword to the first depth-0 `:=` (or `|`/` where`), else the whole declaration
           (definition bodies, structure fields), comments removed, whitespace collapsed;
  prose  = the preceding `/-- … -/` docstring up to its `**Proof sketch` marker (the opening statement prose);
  sketch = the whole docstring (SKETCH-ONLY = only the proof-sketch part changed);
  body   = the whole declaration text (proof included), whitespace collapsed.
Writes one row per name: status (SAME / HEADER / PROSE / HEADER+PROSE / SKETCH-ONLY / BODY-ONLY / ADDED / REMOVED), kind, file, name."""
import sys, re, os, hashlib
KW = r'(theorem|lemma|def|abbrev|structure|class|inductive|instance|opaque|axiom)'
DECL = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|partial|unsafe|nonrec)\s+)*' + KW + r'\b\s*([^\s:({\[]*)')
STOP = re.compile(r'^(/--|/-!|namespace\b|end\b|section\b|noncomputable section\b|variable\b|open\b|#|set_option\b|local\b|attribute\b|universe\b|@\[|(?:(?:private|protected|noncomputable|partial|unsafe|nonrec)\s+)*' + KW + r'\b|example\b|scoped\b|notation\b|macro\b|syntax\b|elab\b|omit\b|include\b)')
def strip_comments(t):
    t = re.sub(r'/-(?!-).*?-/', ' ', t, flags=re.S); return re.sub(r'--[^\n]*', '', t)
def norm(t): return ' '.join(t.split())
def header(kind, body):
    if kind not in ('theorem', 'lemma'): return body
    dep = 0; i = 0
    while i < len(body):
        c = body[i]
        if c in '([{⟨': dep += 1
        elif c in ')]}⟩': dep -= 1
        elif dep == 0 and body.startswith(':=', i): return body[:i]
        elif dep == 0 and body.startswith(' | ', i): return body[:i]
        i += 1
    return body
def parse(path):
    if not os.path.exists(path): return {}
    L = open(path, encoding='utf-8').read().split('\n'); ns = []; out = {}; i = 0; doc = None; anon = 0
    while i < len(L):
        l = L[i]
        if l.startswith('/--'):
            j = i
            while '-/' not in L[j][(3 if j == i else 0):]: j += 1
            doc = '\n'.join(L[i:j + 1]); i = j + 1; continue
        m = re.match(r'^namespace\s+(\S+)', l)
        if m: ns.append(m.group(1)); doc = None; i += 1; continue
        m = re.match(r'^(?:noncomputable\s+)?section\b\s*(\S*)', l)
        if m: ns.append(('§', m.group(1))); doc = None; i += 1; continue
        m = re.match(r'^end\b\s*(\S*)', l)
        if m and ns: ns.pop(); doc = None; i += 1; continue
        m = DECL.match(l)
        if m:
            kind, name = m.group(1), m.group(2)
            j = i + 1
            while j < len(L) and not (L[j][:1].strip() and STOP.match(L[j])): j += 1
            text = '\n'.join(L[i:j]); body = norm(strip_comments(text))
            if not name: anon += 1; name = f'<{kind}#{anon}>'
            pre = '.'.join(x for x in ns if isinstance(x, str))
            full = name[len('_root_.'):] if name.startswith('_root_.') else (pre + '.' + name if pre else name)
            dd = doc or ''; out[full] = dict(kind=kind, header=norm(header(kind, body)), prose=norm(re.split(r'\*\*Proof sketch', dd)[0]), sketch=norm(dd), body=body, line=i + 1)
            doc = None; i = j; continue
        if l.strip() and not l.startswith(' '): doc = None if not l.startswith('@[') else doc
        i += 1
    return out
old, new, paths, outp = sys.argv[1:5]; rows = []; cnt = {}
for p in [l.strip() for l in open(paths) if l.strip().endswith('.lean')]:
    A, B = parse(os.path.join(old, p)), parse(os.path.join(new, p))
    for n in sorted(set(A) | set(B)):
        if n not in A: st = 'ADDED'
        elif n not in B: st = 'REMOVED'
        else:
            h = A[n]['header'] != B[n]['header']; pr = A[n]['prose'] != B[n]['prose']
            st = 'HEADER+PROSE' if h and pr else 'HEADER' if h else 'PROSE' if pr else ('SKETCH-ONLY' if A[n]['sketch'] != B[n]['sketch'] else 'BODY-ONLY' if A[n]['body'] != B[n]['body'] else 'SAME')
        k = (B.get(n) or A.get(n))['kind']; cnt[st] = cnt.get(st, 0) + 1; rows.append((st, k, p, n))
with open(outp, 'w') as f:
    for r in rows: f.write('\t'.join(r) + '\n')
print(' '.join(f'{k} {v}' for k, v in sorted(cnt.items())), '| old', sum(v for k, v in cnt.items() if k != 'ADDED'), 'new', sum(v for k, v in cnt.items() if k != 'REMOVED'))
